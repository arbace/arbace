//line aot_arbace_core__init.ae:1
package aot_arbace_core

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_core__init_A_Load__O() any { A_arbace_core__init_A_Init(); A_arbace_core__init_A_Unit0__O(); A_arbace_core__init_A_Unit1__O(); A_arbace_core__init_A_Unit2__O(); A_arbace_core__init_A_Unit3__O(); A_arbace_core__init_A_Unit4__O(); A_arbace_core__init_A_Unit5__O(); A_arbace_core__init_A_Unit6__O(); A_arbace_core__init_A_Unit7__O(); A_arbace_core__init_A_Unit8__O(); A_arbace_core__init_A_Unit9__O(); A_arbace_core__init_A_Unit10__O(); A_arbace_core__init_A_Unit11__O(); A_arbace_core__init_A_Unit12__O(); A_arbace_core__init_A_Unit13__O(); A_arbace_core__init_A_Unit14__O(); A_arbace_core__init_A_Unit15__O(); A_arbace_core__init_A_Unit16__O(); A_arbace_core__init_A_Unit17__O(); A_arbace_core__init_A_Unit18__O(); A_arbace_core__init_A_Unit19__O(); A_arbace_core__init_A_Unit20__O(); A_arbace_core__init_A_Unit21__O(); A_arbace_core__init_A_Unit22__O(); A_arbace_core__init_A_Unit23__O(); A_arbace_core__init_A_Unit24__O(); A_arbace_core__init_A_Unit25__O(); A_arbace_core__init_A_Unit26__O(); A_arbace_core__init_A_Unit27__O(); A_arbace_core__init_A_Unit28__O(); A_arbace_core__init_A_Unit29__O(); A_arbace_core__init_A_Unit30__O(); A_arbace_core__init_A_Unit31__O(); A_arbace_core__init_A_Unit32__O(); A_arbace_core__init_A_Unit33__O(); A_arbace_core__init_A_Unit34__O(); A_arbace_core__init_A_Unit35__O(); A_arbace_core__init_A_Unit36__O(); A_arbace_core__init_A_Unit37__O(); A_arbace_core__init_A_Unit38__O(); A_arbace_core__init_A_Unit39__O(); A_arbace_core__init_A_Unit40__O(); A_arbace_core__init_A_Unit41__O(); A_arbace_core__init_A_Unit42__O(); A_arbace_core__init_A_Unit43__O(); A_arbace_core__init_A_Unit44__O(); A_arbace_core__init_A_Unit45__O(); A_arbace_core__init_A_Unit46__O(); A_arbace_core__init_A_Unit47__O(); A_arbace_core__init_A_Unit48__O(); A_arbace_core__init_A_Unit49__O(); A_arbace_core__init_A_Unit50__O(); A_arbace_core__init_A_Unit51__O(); A_arbace_core__init_A_Unit52__O(); A_arbace_core__init_A_Unit53__O(); A_arbace_core__init_A_Unit54__O(); A_arbace_core__init_A_Unit55__O(); A_arbace_core__init_A_Unit56__O(); A_arbace_core__init_A_Unit57__O(); A_arbace_core__init_A_Unit58__O(); A_arbace_core__init_A_Unit59__O(); A_arbace_core__init_A_Unit60__O(); A_arbace_core__init_A_Unit61__O(); A_arbace_core__init_A_Unit62__O(); A_arbace_core__init_A_Unit63__O(); A_arbace_core__init_A_Unit64__O(); A_arbace_core__init_A_Unit65__O(); A_arbace_core__init_A_Unit66__O(); A_arbace_core__init_A_Unit67__O(); A_arbace_core__init_A_Unit68__O(); A_arbace_core__init_A_Unit69__O(); A_arbace_core__init_A_Unit70__O(); A_arbace_core__init_A_Unit71__O(); A_arbace_core__init_A_Unit72__O(); A_arbace_core__init_A_Unit73__O(); A_arbace_core__init_A_Unit74__O(); A_arbace_core__init_A_Unit75__O(); A_arbace_core__init_A_Unit76__O(); A_arbace_core__init_A_Unit77__O(); A_arbace_core__init_A_Unit78__O(); A_arbace_core__init_A_Unit79__O(); A_arbace_core__init_A_Unit80__O(); A_arbace_core__init_A_Unit81__O(); A_arbace_core__init_A_Unit82__O(); A_arbace_core__init_A_Unit83__O(); A_arbace_core__init_A_Unit84__O(); A_arbace_core__init_A_Unit85__O(); A_arbace_core__init_A_Unit86__O(); A_arbace_core__init_A_Unit87__O(); A_arbace_core__init_A_Unit88__O(); A_arbace_core__init_A_Unit89__O(); A_arbace_core__init_A_Unit90__O(); A_arbace_core__init_A_Unit91__O(); A_arbace_core__init_A_Unit92__O(); A_arbace_core__init_A_Unit93__O(); A_arbace_core__init_A_Unit94__O(); A_arbace_core__init_A_Unit95__O(); A_arbace_core__init_A_Unit96__O(); A_arbace_core__init_A_Unit97__O(); A_arbace_core__init_A_Unit98__O(); A_arbace_core__init_A_Unit99__O(); A_arbace_core__init_A_Unit100__O(); A_arbace_core__init_A_Unit101__O(); A_arbace_core__init_A_Unit102__O(); A_arbace_core__init_A_Unit103__O(); A_arbace_core__init_A_Unit104__O(); A_arbace_core__init_A_Unit105__O(); A_arbace_core__init_A_Unit106__O(); A_arbace_core__init_A_Unit107__O(); A_arbace_core__init_A_Unit108__O(); A_arbace_core__init_A_Unit109__O(); A_arbace_core__init_A_Unit110__O(); A_arbace_core__init_A_Unit111__O(); A_arbace_core__init_A_Unit112__O(); A_arbace_core__init_A_Unit113__O(); A_arbace_core__init_A_Unit114__O(); A_arbace_core__init_A_Unit115__O(); A_arbace_core__init_A_Unit116__O(); A_arbace_core__init_A_Unit117__O(); A_arbace_core__init_A_Unit118__O(); A_arbace_core__init_A_Unit119__O(); A_arbace_core__init_A_Unit120__O(); A_arbace_core__init_A_Unit121__O(); A_arbace_core__init_A_Unit122__O(); A_arbace_core__init_A_Unit123__O(); A_arbace_core__init_A_Unit124__O(); A_arbace_core__init_A_Unit125__O(); A_arbace_core__init_A_Unit126__O(); A_arbace_core__init_A_Unit127__O(); A_arbace_core__init_A_Unit128__O(); A_arbace_core__init_A_Unit129__O(); A_arbace_core__init_A_Unit130__O(); A_arbace_core__init_A_Unit131__O(); A_arbace_core__init_A_Unit132__O(); A_arbace_core__init_A_Unit133__O(); A_arbace_core__init_A_Unit134__O(); A_arbace_core__init_A_Unit135__O(); A_arbace_core__init_A_Unit136__O(); A_arbace_core__init_A_Unit137__O(); A_arbace_core__init_A_Unit138__O(); A_arbace_core__init_A_Unit139__O(); A_arbace_core__init_A_Unit140__O(); A_arbace_core__init_A_Unit141__O(); A_arbace_core__init_A_Unit142__O(); A_arbace_core__init_A_Unit143__O(); A_arbace_core__init_A_Unit144__O(); A_arbace_core__init_A_Unit145__O(); A_arbace_core__init_A_Unit146__O(); A_arbace_core__init_A_Unit147__O(); A_arbace_core__init_A_Unit148__O(); A_arbace_core__init_A_Unit149__O(); A_arbace_core__init_A_Unit150__O(); A_arbace_core__init_A_Unit151__O(); A_arbace_core__init_A_Unit152__O(); A_arbace_core__init_A_Unit153__O(); A_arbace_core__init_A_Unit154__O(); A_arbace_core__init_A_Unit155__O(); A_arbace_core__init_A_Unit156__O(); A_arbace_core__init_A_Unit157__O(); A_arbace_core__init_A_Unit158__O(); A_arbace_core__init_A_Unit159__O(); A_arbace_core__init_A_Unit160__O(); A_arbace_core__init_A_Unit161__O(); A_arbace_core__init_A_Unit162__O(); A_arbace_core__init_A_Unit163__O(); A_arbace_core__init_A_Unit164__O(); A_arbace_core__init_A_Unit165__O(); A_arbace_core__init_A_Unit166__O(); A_arbace_core__init_A_Unit167__O(); A_arbace_core__init_A_Unit168__O(); A_arbace_core__init_A_Unit169__O(); A_arbace_core__init_A_Unit170__O(); A_arbace_core__init_A_Unit171__O(); A_arbace_core__init_A_Unit172__O(); A_arbace_core__init_A_Unit173__O(); A_arbace_core__init_A_Unit174__O(); A_arbace_core__init_A_Unit175__O(); A_arbace_core__init_A_Unit176__O(); A_arbace_core__init_A_Unit177__O(); A_arbace_core__init_A_Unit178__O(); A_arbace_core__init_A_Unit179__O(); A_arbace_core__init_A_Unit180__O(); A_arbace_core__init_A_Unit181__O(); A_arbace_core__init_A_Unit182__O(); A_arbace_core__init_A_Unit183__O(); A_arbace_core__init_A_Unit184__O(); A_arbace_core__init_A_Unit185__O(); A_arbace_core__init_A_Unit186__O(); A_arbace_core__init_A_Unit187__O(); A_arbace_core__init_A_Unit188__O(); A_arbace_core__init_A_Unit189__O(); A_arbace_core__init_A_Unit190__O(); A_arbace_core__init_A_Unit191__O(); A_arbace_core__init_A_Unit192__O(); A_arbace_core__init_A_Unit193__O(); A_arbace_core__init_A_Unit194__O(); A_arbace_core__init_A_Unit195__O(); A_arbace_core__init_A_Unit196__O(); A_arbace_core__init_A_Unit197__O(); A_arbace_core__init_A_Unit198__O(); A_arbace_core__init_A_Unit199__O(); A_arbace_core__init_A_Unit200__O(); A_arbace_core__init_A_Unit201__O(); A_arbace_core__init_A_Unit202__O(); A_arbace_core__init_A_Unit203__O(); A_arbace_core__init_A_Unit204__O(); A_arbace_core__init_A_Unit205__O(); A_arbace_core__init_A_Unit206__O(); A_arbace_core__init_A_Unit207__O(); A_arbace_core__init_A_Unit208__O(); A_arbace_core__init_A_Unit209__O(); A_arbace_core__init_A_Unit210__O(); A_arbace_core__init_A_Unit211__O(); A_arbace_core__init_A_Unit212__O(); A_arbace_core__init_A_Unit213__O(); A_arbace_core__init_A_Unit214__O(); A_arbace_core__init_A_Unit215__O(); A_arbace_core__init_A_Unit216__O(); A_arbace_core__init_A_Unit217__O(); A_arbace_core__init_A_Unit218__O(); A_arbace_core__init_A_Unit219__O(); A_arbace_core__init_A_Unit220__O(); A_arbace_core__init_A_Unit221__O(); A_arbace_core__init_A_Unit222__O(); A_arbace_core__init_A_Unit223__O(); A_arbace_core__init_A_Unit224__O(); A_arbace_core__init_A_Unit225__O(); A_arbace_core__init_A_Unit226__O(); A_arbace_core__init_A_Unit227__O(); A_arbace_core__init_A_Unit228__O(); A_arbace_core__init_A_Unit229__O(); A_arbace_core__init_A_Unit230__O(); A_arbace_core__init_A_Unit231__O(); A_arbace_core__init_A_Unit232__O(); A_arbace_core__init_A_Unit233__O(); A_arbace_core__init_A_Unit234__O(); A_arbace_core__init_A_Unit235__O(); A_arbace_core__init_A_Unit236__O(); A_arbace_core__init_A_Unit237__O(); A_arbace_core__init_A_Unit238__O(); A_arbace_core__init_A_Unit239__O(); A_arbace_core__init_A_Unit240__O(); A_arbace_core__init_A_Unit241__O(); A_arbace_core__init_A_Unit242__O(); A_arbace_core__init_A_Unit243__O(); A_arbace_core__init_A_Unit244__O(); A_arbace_core__init_A_Unit245__O(); A_arbace_core__init_A_Unit246__O(); A_arbace_core__init_A_Unit247__O(); A_arbace_core__init_A_Unit248__O(); A_arbace_core__init_A_Unit249__O(); A_arbace_core__init_A_Unit250__O(); A_arbace_core__init_A_Unit251__O(); A_arbace_core__init_A_Unit252__O(); A_arbace_core__init_A_Unit253__O(); A_arbace_core__init_A_Unit254__O(); A_arbace_core__init_A_Unit255__O(); A_arbace_core__init_A_Unit256__O(); A_arbace_core__init_A_Unit257__O(); A_arbace_core__init_A_Unit258__O(); A_arbace_core__init_A_Unit259__O(); A_arbace_core__init_A_Unit260__O(); A_arbace_core__init_A_Unit261__O(); A_arbace_core__init_A_Unit262__O(); A_arbace_core__init_A_Unit263__O(); A_arbace_core__init_A_Unit264__O(); A_arbace_core__init_A_Unit265__O(); A_arbace_core__init_A_Unit266__O(); A_arbace_core__init_A_Unit267__O(); A_arbace_core__init_A_Unit268__O(); A_arbace_core__init_A_Unit269__O(); A_arbace_core__init_A_Unit270__O(); A_arbace_core__init_A_Unit271__O(); A_arbace_core__init_A_Unit272__O(); A_arbace_core__init_A_Unit273__O(); A_arbace_core__init_A_Unit274__O(); A_arbace_core__init_A_Unit275__O(); A_arbace_core__init_A_Unit276__O(); A_arbace_core__init_A_Unit277__O(); A_arbace_core__init_A_Unit278__O(); A_arbace_core__init_A_Unit279__O(); A_arbace_core__init_A_Unit280__O(); A_arbace_core__init_A_Unit281__O(); A_arbace_core__init_A_Unit282__O(); A_arbace_core__init_A_Unit283__O(); A_arbace_core__init_A_Unit284__O(); A_arbace_core__init_A_Unit285__O(); A_arbace_core__init_A_Unit286__O(); A_arbace_core__init_A_Unit287__O(); A_arbace_core__init_A_Unit288__O(); A_arbace_core__init_A_Unit289__O(); A_arbace_core__init_A_Unit290__O(); A_arbace_core__init_A_Unit291__O(); A_arbace_core__init_A_Unit292__O(); A_arbace_core__init_A_Unit293__O(); A_arbace_core__init_A_Unit294__O(); A_arbace_core__init_A_Unit295__O(); A_arbace_core__init_A_Unit296__O(); A_arbace_core__init_A_Unit297__O(); A_arbace_core__init_A_Unit298__O(); A_arbace_core__init_A_Unit299__O(); A_arbace_core__init_A_Unit300__O(); A_arbace_core__init_A_Unit301__O(); A_arbace_core__init_A_Unit302__O(); A_arbace_core__init_A_Unit303__O(); A_arbace_core__init_A_Unit304__O(); A_arbace_core__init_A_Unit305__O(); A_arbace_core__init_A_Unit306__O(); A_arbace_core__init_A_Unit307__O(); A_arbace_core__init_A_Unit308__O(); A_arbace_core__init_A_Unit309__O(); A_arbace_core__init_A_Unit310__O(); A_arbace_core__init_A_Unit311__O(); A_arbace_core__init_A_Unit312__O(); A_arbace_core__init_A_Unit313__O(); A_arbace_core__init_A_Unit314__O(); A_arbace_core__init_A_Unit315__O(); A_arbace_core__init_A_Unit316__O(); A_arbace_core__init_A_Unit317__O(); A_arbace_core__init_A_Unit318__O(); A_arbace_core__init_A_Unit319__O(); A_arbace_core__init_A_Unit320__O(); A_arbace_core__init_A_Unit321__O(); A_arbace_core__init_A_Unit322__O(); A_arbace_core__init_A_Unit323__O(); A_arbace_core__init_A_Unit324__O(); A_arbace_core__init_A_Unit325__O(); A_arbace_core__init_A_Unit326__O(); A_arbace_core__init_A_Unit327__O(); A_arbace_core__init_A_Unit328__O(); A_arbace_core__init_A_Unit329__O(); A_arbace_core__init_A_Unit330__O(); A_arbace_core__init_A_Unit331__O(); A_arbace_core__init_A_Unit332__O(); A_arbace_core__init_A_Unit333__O(); A_arbace_core__init_A_Unit334__O(); A_arbace_core__init_A_Unit335__O(); A_arbace_core__init_A_Unit336__O(); A_arbace_core__init_A_Unit337__O(); A_arbace_core__init_A_Unit338__O(); A_arbace_core__init_A_Unit339__O(); A_arbace_core__init_A_Unit340__O(); A_arbace_core__init_A_Unit341__O(); A_arbace_core__init_A_Unit342__O(); A_arbace_core__init_A_Unit343__O(); A_arbace_core__init_A_Unit344__O(); A_arbace_core__init_A_Unit345__O(); A_arbace_core__init_A_Unit346__O(); A_arbace_core__init_A_Unit347__O(); A_arbace_core__init_A_Unit348__O(); A_arbace_core__init_A_Unit349__O(); A_arbace_core__init_A_Unit350__O(); A_arbace_core__init_A_Unit351__O(); A_arbace_core__init_A_Unit352__O(); A_arbace_core__init_A_Unit353__O(); A_arbace_core__init_A_Unit354__O(); A_arbace_core__init_A_Unit355__O(); A_arbace_core__init_A_Unit356__O(); A_arbace_core__init_A_Unit357__O(); A_arbace_core__init_A_Unit358__O(); A_arbace_core__init_A_Unit359__O(); A_arbace_core__init_A_Unit360__O(); A_arbace_core__init_A_Unit361__O(); A_arbace_core__init_A_Unit362__O(); A_arbace_core__init_A_Unit363__O(); A_arbace_core__init_A_Unit364__O(); A_arbace_core__init_A_Unit365__O(); A_arbace_core__init_A_Unit366__O(); A_arbace_core__init_A_Unit367__O(); A_arbace_core__init_A_Unit368__O(); A_arbace_core__init_A_Unit369__O(); A_arbace_core__init_A_Unit370__O(); A_arbace_core__init_A_Unit371__O(); A_arbace_core__init_A_Unit372__O(); A_arbace_core__init_A_Unit373__O(); A_arbace_core__init_A_Unit374__O(); A_arbace_core__init_A_Unit375__O(); A_arbace_core__init_A_Unit376__O(); A_arbace_core__init_A_Unit377__O(); A_arbace_core__init_A_Unit378__O(); A_arbace_core__init_A_Unit379__O(); A_arbace_core__init_A_Unit380__O(); A_arbace_core__init_A_Unit381__O(); A_arbace_core__init_A_Unit382__O(); A_arbace_core__init_A_Unit383__O(); A_arbace_core__init_A_Unit384__O(); A_arbace_core__init_A_Unit385__O(); A_arbace_core__init_A_Unit386__O(); A_arbace_core__init_A_Unit387__O(); A_arbace_core__init_A_Unit388__O(); A_arbace_core__init_A_Unit389__O(); A_arbace_core__init_A_Unit390__O(); A_arbace_core__init_A_Unit391__O(); A_arbace_core__init_A_Unit392__O(); A_arbace_core__init_A_Unit393__O(); A_arbace_core__init_A_Unit394__O(); A_arbace_core__init_A_Unit395__O(); A_arbace_core__init_A_Unit396__O(); A_arbace_core__init_A_Unit397__O(); A_arbace_core__init_A_Unit398__O(); A_arbace_core__init_A_Unit399__O(); A_arbace_core__init_A_Unit400__O(); A_arbace_core__init_A_Unit401__O(); A_arbace_core__init_A_Unit402__O(); A_arbace_core__init_A_Unit403__O(); A_arbace_core__init_A_Unit404__O(); A_arbace_core__init_A_Unit405__O(); A_arbace_core__init_A_Unit406__O(); A_arbace_core__init_A_Unit407__O(); A_arbace_core__init_A_Unit408__O(); A_arbace_core__init_A_Unit409__O(); A_arbace_core__init_A_Unit410__O(); A_arbace_core__init_A_Unit411__O(); A_arbace_core__init_A_Unit412__O(); A_arbace_core__init_A_Unit413__O(); A_arbace_core__init_A_Unit414__O(); A_arbace_core__init_A_Unit415__O(); A_arbace_core__init_A_Unit416__O(); A_arbace_core__init_A_Unit417__O(); A_arbace_core__init_A_Unit418__O(); A_arbace_core__init_A_Unit419__O(); A_arbace_core__init_A_Unit420__O(); A_arbace_core__init_A_Unit421__O(); A_arbace_core__init_A_Unit422__O(); A_arbace_core__init_A_Unit423__O(); A_arbace_core__init_A_Unit424__O(); A_arbace_core__init_A_Unit425__O(); A_arbace_core__init_A_Unit426__O(); A_arbace_core__init_A_Unit427__O(); A_arbace_core__init_A_Unit428__O(); A_arbace_core__init_A_Unit429__O(); A_arbace_core__init_A_Unit430__O(); A_arbace_core__init_A_Unit431__O(); A_arbace_core__init_A_Unit432__O(); A_arbace_core__init_A_Unit433__O(); A_arbace_core__init_A_Unit434__O(); A_arbace_core__init_A_Unit435__O(); A_arbace_core__init_A_Unit436__O(); A_arbace_core__init_A_Unit437__O(); A_arbace_core__init_A_Unit438__O(); A_arbace_core__init_A_Unit439__O(); A_arbace_core__init_A_Unit440__O(); A_arbace_core__init_A_Unit441__O(); A_arbace_core__init_A_Unit442__O(); A_arbace_core__init_A_Unit443__O(); A_arbace_core__init_A_Unit444__O(); A_arbace_core__init_A_Unit445__O(); A_arbace_core__init_A_Unit446__O(); A_arbace_core__init_A_Unit447__O(); A_arbace_core__init_A_Unit448__O(); A_arbace_core__init_A_Unit449__O(); A_arbace_core__init_A_Unit450__O(); A_arbace_core__init_A_Unit451__O(); A_arbace_core__init_A_Unit452__O(); A_arbace_core__init_A_Unit453__O(); A_arbace_core__init_A_Unit454__O(); A_arbace_core__init_A_Unit455__O(); A_arbace_core__init_A_Unit456__O(); A_arbace_core__init_A_Unit457__O(); A_arbace_core__init_A_Unit458__O(); A_arbace_core__init_A_Unit459__O(); A_arbace_core__init_A_Unit460__O(); A_arbace_core__init_A_Unit461__O(); A_arbace_core__init_A_Unit462__O(); A_arbace_core__init_A_Unit463__O(); A_arbace_core__init_A_Unit464__O(); A_arbace_core__init_A_Unit465__O(); A_arbace_core__init_A_Unit466__O(); A_arbace_core__init_A_Unit467__O(); A_arbace_core__init_A_Unit468__O(); A_arbace_core__init_A_Unit469__O(); A_arbace_core__init_A_Unit470__O(); A_arbace_core__init_A_Unit471__O(); A_arbace_core__init_A_Unit472__O(); A_arbace_core__init_A_Unit473__O(); A_arbace_core__init_A_Unit474__O(); A_arbace_core__init_A_Unit475__O(); A_arbace_core__init_A_Unit476__O(); A_arbace_core__init_A_Unit477__O(); A_arbace_core__init_A_Unit478__O(); A_arbace_core__init_A_Unit479__O(); A_arbace_core__init_A_Unit480__O(); A_arbace_core__init_A_Unit481__O(); A_arbace_core__init_A_Unit482__O(); A_arbace_core__init_A_Unit483__O(); A_arbace_core__init_A_Unit484__O(); A_arbace_core__init_A_Unit485__O(); A_arbace_core__init_A_Unit486__O(); A_arbace_core__init_A_Unit487__O(); A_arbace_core__init_A_Unit488__O(); A_arbace_core__init_A_Unit489__O(); A_arbace_core__init_A_Unit490__O(); A_arbace_core__init_A_Unit491__O(); A_arbace_core__init_A_Unit492__O(); A_arbace_core__init_A_Unit493__O(); A_arbace_core__init_A_Unit494__O(); A_arbace_core__init_A_Unit495__O(); A_arbace_core__init_A_Unit496__O(); A_arbace_core__init_A_Unit497__O(); A_arbace_core__init_A_Unit498__O(); A_arbace_core__init_A_Unit499__O(); A_arbace_core__init_A_Unit500__O(); A_arbace_core__init_A_Unit501__O(); A_arbace_core__init_A_Unit502__O(); A_arbace_core__init_A_Unit503__O(); A_arbace_core__init_A_Unit504__O(); A_arbace_core__init_A_Unit505__O(); A_arbace_core__init_A_Unit506__O(); A_arbace_core__init_A_Unit507__O(); A_arbace_core__init_A_Unit508__O(); A_arbace_core__init_A_Unit509__O(); A_arbace_core__init_A_Unit510__O(); A_arbace_core__init_A_Unit511__O(); A_arbace_core__init_A_Unit512__O(); A_arbace_core__init_A_Unit513__O(); A_arbace_core__init_A_Unit514__O(); A_arbace_core__init_A_Unit515__O(); A_arbace_core__init_A_Unit516__O(); A_arbace_core__init_A_Unit517__O(); A_arbace_core__init_A_Unit518__O(); A_arbace_core__init_A_Unit519__O(); A_arbace_core__init_A_Unit520__O(); A_arbace_core__init_A_Unit521__O(); A_arbace_core__init_A_Unit522__O(); A_arbace_core__init_A_Unit523__O(); A_arbace_core__init_A_Unit524__O(); A_arbace_core__init_A_Unit525__O(); A_arbace_core__init_A_Unit526__O(); A_arbace_core__init_A_Unit527__O(); A_arbace_core__init_A_Unit528__O(); A_arbace_core__init_A_Unit529__O(); A_arbace_core__init_A_Unit530__O(); A_arbace_core__init_A_Unit531__O(); A_arbace_core__init_A_Unit532__O(); A_arbace_core__init_A_Unit533__O(); A_arbace_core__init_A_Unit534__O(); A_arbace_core__init_A_Unit535__O(); A_arbace_core__init_A_Unit536__O(); A_arbace_core__init_A_Unit537__O(); A_arbace_core__init_A_Unit538__O(); A_arbace_core__init_A_Unit539__O(); A_arbace_core__init_A_Unit540__O(); A_arbace_core__init_A_Unit541__O(); A_arbace_core__init_A_Unit542__O(); A_arbace_core__init_A_Unit543__O(); A_arbace_core__init_A_Unit544__O(); A_arbace_core__init_A_Unit545__O(); A_arbace_core__init_A_Unit546__O(); A_arbace_core__init_A_Unit547__O(); A_arbace_core__init_A_Unit548__O(); A_arbace_core__init_A_Unit549__O(); A_arbace_core__init_A_Unit550__O(); A_arbace_core__init_A_Unit551__O(); A_arbace_core__init_A_Unit552__O(); A_arbace_core__init_A_Unit553__O(); A_arbace_core__init_A_Unit554__O(); A_arbace_core__init_A_Unit555__O(); A_arbace_core__init_A_Unit556__O(); A_arbace_core__init_A_Unit557__O(); A_arbace_core__init_A_Unit558__O(); A_arbace_core__init_A_Unit559__O(); A_arbace_core__init_A_Unit560__O(); A_arbace_core__init_A_Unit561__O(); A_arbace_core__init_A_Unit562__O(); A_arbace_core__init_A_Unit563__O(); A_arbace_core__init_A_Unit564__O(); A_arbace_core__init_A_Unit565__O(); A_arbace_core__init_A_Unit566__O(); A_arbace_core__init_A_Unit567__O(); A_arbace_core__init_A_Unit568__O(); A_arbace_core__init_A_Unit569__O(); A_arbace_core__init_A_Unit570__O(); A_arbace_core__init_A_Unit571__O(); A_arbace_core__init_A_Unit572__O(); A_arbace_core__init_A_Unit573__O(); A_arbace_core__init_A_Unit574__O(); A_arbace_core__init_A_Unit575__O(); A_arbace_core__init_A_Unit576__O(); A_arbace_core__init_A_Unit577__O(); A_arbace_core__init_A_Unit578__O(); A_arbace_core__init_A_Unit579__O(); A_arbace_core__init_A_Unit580__O(); A_arbace_core__init_A_Unit581__O(); A_arbace_core__init_A_Unit582__O(); A_arbace_core__init_A_Unit583__O(); A_arbace_core__init_A_Unit584__O(); A_arbace_core__init_A_Unit585__O(); A_arbace_core__init_A_Unit586__O(); A_arbace_core__init_A_Unit587__O(); A_arbace_core__init_A_Unit588__O(); A_arbace_core__init_A_Unit589__O(); A_arbace_core__init_A_Unit590__O(); A_arbace_core__init_A_Unit591__O(); A_arbace_core__init_A_Unit592__O(); A_arbace_core__init_A_Unit593__O(); A_arbace_core__init_A_Unit594__O(); A_arbace_core__init_A_Unit595__O(); A_arbace_core__init_A_Unit596__O(); A_arbace_core__init_A_Unit597__O(); A_arbace_core__init_A_Unit598__O(); A_arbace_core__init_A_Unit599__O(); A_arbace_core__init_A_Unit600__O(); A_arbace_core__init_A_Unit601__O(); A_arbace_core__init_A_Unit602__O(); A_arbace_core__init_A_Unit603__O(); A_arbace_core__init_A_Unit604__O(); A_arbace_core__init_A_Unit605__O(); A_arbace_core__init_A_Unit606__O(); A_arbace_core__init_A_Unit607__O(); A_arbace_core__init_A_Unit608__O(); A_arbace_core__init_A_Unit609__O(); A_arbace_core__init_A_Unit610__O(); A_arbace_core__init_A_Unit611__O(); A_arbace_core__init_A_Unit612__O(); A_arbace_core__init_A_Unit613__O(); A_arbace_core__init_A_Unit614__O(); A_arbace_core__init_A_Unit615__O(); A_arbace_core__init_A_Unit616__O(); A_arbace_core__init_A_Unit617__O(); A_arbace_core__init_A_Unit618__O(); A_arbace_core__init_A_Unit619__O(); A_arbace_core__init_A_Unit620__O(); A_arbace_core__init_A_Unit621__O(); A_arbace_core__init_A_Unit622__O(); A_arbace_core__init_A_Unit623__O(); A_arbace_core__init_A_Unit624__O(); A_arbace_core__init_A_Unit625__O(); A_arbace_core__init_A_Unit626__O(); A_arbace_core__init_A_Unit627__O(); A_arbace_core__init_A_Unit628__O(); A_arbace_core__init_A_Unit629__O(); A_arbace_core__init_A_Unit630__O(); A_arbace_core__init_A_Unit631__O(); A_arbace_core__init_A_Unit632__O(); A_arbace_core__init_A_Unit633__O(); A_arbace_core__init_A_Unit634__O(); A_arbace_core__init_A_Unit635__O(); A_arbace_core__init_A_Unit636__O(); A_arbace_core__init_A_Unit637__O(); A_arbace_core__init_A_Unit638__O(); A_arbace_core__init_A_Unit639__O(); A_arbace_core__init_A_Unit640__O(); A_arbace_core__init_A_Unit641__O(); A_arbace_core__init_A_Unit642__O(); A_arbace_core__init_A_Unit643__O(); A_arbace_core__init_A_Unit644__O(); A_arbace_core__init_A_Unit645__O(); A_arbace_core__init_A_Unit646__O(); A_arbace_core__init_A_Unit647__O(); A_arbace_core__init_A_Unit648__O(); A_arbace_core__init_A_Unit649__O(); A_arbace_core__init_A_Unit650__O(); A_arbace_core__init_A_Unit651__O(); A_arbace_core__init_A_Unit652__O(); A_arbace_core__init_A_Unit653__O(); A_arbace_core__init_A_Unit654__O(); A_arbace_core__init_A_Unit655__O(); A_arbace_core__init_A_Unit656__O(); A_arbace_core__init_A_Unit657__O(); A_arbace_core__init_A_Unit658__O(); A_arbace_core__init_A_Unit659__O(); A_arbace_core__init_A_Unit660__O(); A_arbace_core__init_A_Unit661__O(); A_arbace_core__init_A_Unit662__O(); A_arbace_core__init_A_Unit663__O(); A_arbace_core__init_A_Unit664__O(); A_arbace_core__init_A_Unit665__O(); A_arbace_core__init_A_Unit666__O(); A_arbace_core__init_A_Unit667__O(); A_arbace_core__init_A_Unit668__O(); A_arbace_core__init_A_Unit669__O(); A_arbace_core__init_A_Unit670__O(); A_arbace_core__init_A_Unit671__O(); A_arbace_core__init_A_Unit672__O(); A_arbace_core__init_A_Unit673__O(); A_arbace_core__init_A_Unit674__O(); A_arbace_core__init_A_Unit675__O(); A_arbace_core__init_A_Unit676__O(); A_arbace_core__init_A_Unit677__O(); A_arbace_core__init_A_Unit678__O(); A_arbace_core__init_A_Unit679__O(); A_arbace_core__init_A_Unit680__O(); A_arbace_core__init_A_Unit681__O(); A_arbace_core__init_A_Unit682__O(); A_arbace_core__init_A_Unit683__O(); A_arbace_core__init_A_Unit684__O(); A_arbace_core__init_A_Unit685__O(); A_arbace_core__init_A_Unit686__O(); A_arbace_core__init_A_Unit687__O(); A_arbace_core__init_A_Unit688__O(); A_arbace_core__init_A_Unit689__O(); A_arbace_core__init_A_Unit690__O(); A_arbace_core__init_A_Unit691__O(); A_arbace_core__init_A_Unit692__O(); A_arbace_core__init_A_Unit693__O(); A_arbace_core__init_A_Unit694__O(); A_arbace_core__init_A_Unit695__O(); A_arbace_core__init_A_Unit696__O(); A_arbace_core__init_A_Unit697__O(); A_arbace_core__init_A_Unit698__O(); A_arbace_core__init_A_Unit699__O(); A_arbace_core__init_A_Unit700__O(); A_arbace_core__init_A_Unit701__O(); A_arbace_core__init_A_Unit702__O(); A_arbace_core__init_A_Unit703__O(); A_arbace_core__init_A_Unit704__O(); A_arbace_core__init_A_Unit705__O(); A_arbace_core__init_A_Unit706__O(); A_arbace_core__init_A_Unit707__O(); A_arbace_core__init_A_Unit708__O(); A_arbace_core__init_A_Unit709__O(); A_arbace_core__init_A_Unit710__O(); A_arbace_core__init_A_Unit711__O(); A_arbace_core__init_A_Unit712__O(); A_arbace_core__init_A_Unit713__O(); A_arbace_core__init_A_Unit714__O(); A_arbace_core__init_A_Unit715__O(); A_arbace_core__init_A_Unit716__O(); A_arbace_core__init_A_Unit717__O(); A_arbace_core__init_A_Unit718__O(); A_arbace_core__init_A_Unit719__O(); A_arbace_core__init_A_Unit720__O(); A_arbace_core__init_A_Unit721__O(); A_arbace_core__init_A_Unit722__O(); A_arbace_core__init_A_Unit723__O(); A_arbace_core__init_A_Unit724__O(); A_arbace_core__init_A_Unit725__O(); A_arbace_core__init_A_Unit726__O(); A_arbace_core__init_A_Unit727__O(); A_arbace_core__init_A_Unit728__O(); A_arbace_core__init_A_Unit729__O(); A_arbace_core__init_A_Unit730__O(); A_arbace_core__init_A_Unit731__O(); A_arbace_core__init_A_Unit732__O(); A_arbace_core__init_A_Unit733__O(); A_arbace_core__init_A_Unit734__O(); A_arbace_core__init_A_Unit735__O(); A_arbace_core__init_A_Unit736__O(); A_arbace_core__init_A_Unit737__O(); A_arbace_core__init_A_Unit738__O(); A_arbace_core__init_A_Unit739__O(); A_arbace_core__init_A_Unit740__O(); A_arbace_core__init_A_Unit741__O(); A_arbace_core__init_A_Unit742__O(); A_arbace_core__init_A_Unit743__O(); A_arbace_core__init_A_Unit744__O(); A_arbace_core__init_A_Unit745__O(); A_arbace_core__init_A_Unit746__O(); A_arbace_core__init_A_Unit747__O(); A_arbace_core__init_A_Unit748__O(); A_arbace_core__init_A_Unit749__O(); A_arbace_core__init_A_Unit750__O(); A_arbace_core__init_A_Unit751__O(); A_arbace_core__init_A_Unit752__O(); A_arbace_core__init_A_Unit753__O(); A_arbace_core__init_A_Unit754__O(); A_arbace_core__init_A_Unit755__O(); A_arbace_core__init_A_Unit756__O(); A_arbace_core__init_A_Unit757__O(); A_arbace_core__init_A_Unit758__O(); A_arbace_core__init_A_Unit759__O(); A_arbace_core__init_A_Unit760__O(); A_arbace_core__init_A_Unit761__O(); A_arbace_core__init_A_Unit762__O(); A_arbace_core__init_A_Unit763__O(); A_arbace_core__init_A_Unit764__O(); A_arbace_core__init_A_Unit765__O(); A_arbace_core__init_A_Unit766__O(); A_arbace_core__init_A_Unit767__O(); A_arbace_core__init_A_Unit768__O(); A_arbace_core__init_A_Unit769__O(); A_arbace_core__init_A_Unit770__O(); A_arbace_core__init_A_Unit771__O(); A_arbace_core__init_A_Unit772__O(); A_arbace_core__init_A_Unit773__O(); A_arbace_core__init_A_Unit774__O(); A_arbace_core__init_A_Unit775__O(); A_arbace_core__init_A_Unit776__O(); A_arbace_core__init_A_Unit777__O(); A_arbace_core__init_A_Unit778__O(); A_arbace_core__init_A_Unit779__O(); A_arbace_core__init_A_Unit780__O(); A_arbace_core__init_A_Unit781__O(); A_arbace_core__init_A_Unit782__O(); A_arbace_core__init_A_Unit783__O(); A_arbace_core__init_A_Unit784__O(); A_arbace_core__init_A_Unit785__O(); A_arbace_core__init_A_Unit786__O(); A_arbace_core__init_A_Unit787__O(); A_arbace_core__init_A_Unit788__O(); A_arbace_core__init_A_Unit789__O(); A_arbace_core__init_A_Unit790__O(); A_arbace_core__init_A_Unit791__O(); A_arbace_core__init_A_Unit792__O(); A_arbace_core__init_A_Unit793__O(); A_arbace_core__init_A_Unit794__O(); A_arbace_core__init_A_Unit795__O(); A_arbace_core__init_A_Unit796__O(); A_arbace_core__init_A_Unit797__O(); A_arbace_core__init_A_Unit798__O(); A_arbace_core__init_A_Unit799__O(); A_arbace_core__init_A_Unit800__O(); A_arbace_core__init_A_Unit801__O(); A_arbace_core__init_A_Unit802__O(); A_arbace_core__init_A_Unit803__O(); A_arbace_core__init_A_Unit804__O(); A_arbace_core__init_A_Unit805__O(); A_arbace_core__init_A_Unit806__O(); A_arbace_core__init_A_Unit807__O(); A_arbace_core__init_A_Unit808__O(); A_arbace_core__init_A_Unit809__O(); A_arbace_core__init_A_Unit810__O(); A_arbace_core__init_A_Unit811__O(); A_arbace_core__init_A_Unit812__O(); A_arbace_core__init_A_Unit813__O(); A_arbace_core__init_A_Unit814__O(); A_arbace_core__init_A_Unit815__O(); A_arbace_core__init_A_Unit816__O(); A_arbace_core__init_A_Unit817__O(); A_arbace_core__init_A_Unit818__O(); A_arbace_core__init_A_Unit819__O(); A_arbace_core__init_A_Unit820__O(); A_arbace_core__init_A_Unit821__O(); A_arbace_core__init_A_Unit822__O(); A_arbace_core__init_A_Unit823__O(); A_arbace_core__init_A_Unit824__O(); A_arbace_core__init_A_Unit825__O(); A_arbace_core__init_A_Unit826__O(); A_arbace_core__init_A_Unit827__O(); A_arbace_core__init_A_Unit828__O(); A_arbace_core__init_A_Unit829__O(); A_arbace_core__init_A_Unit830__O(); A_arbace_core__init_A_Unit831__O(); A_arbace_core__init_A_Unit832__O(); A_arbace_core__init_A_Unit833__O(); A_arbace_core__init_A_Unit834__O(); A_arbace_core__init_A_Unit835__O(); A_arbace_core__init_A_Unit836__O(); A_arbace_core__init_A_Unit837__O(); A_arbace_core__init_A_Unit838__O(); A_arbace_core__init_A_Unit839__O(); A_arbace_core__init_A_Unit840__O(); A_arbace_core__init_A_Unit841__O(); A_arbace_core__init_A_Unit842__O(); A_arbace_core__init_A_Unit843__O(); A_arbace_core__init_A_Unit844__O(); A_arbace_core__init_A_Unit845__O(); A_arbace_core__init_A_Unit846__O(); A_arbace_core__init_A_Unit847__O(); A_arbace_core__init_A_Unit848__O(); A_arbace_core__init_A_Unit849__O(); A_arbace_core__init_A_Unit850__O(); A_arbace_core__init_A_Unit851__O(); A_arbace_core__init_A_Unit852__O(); A_arbace_core__init_A_Unit853__O(); A_arbace_core__init_A_Unit854__O(); A_arbace_core__init_A_Unit855__O(); A_arbace_core__init_A_Unit856__O(); A_arbace_core__init_A_Unit857__O(); A_arbace_core__init_A_Unit858__O(); A_arbace_core__init_A_Unit859__O(); A_arbace_core__init_A_Unit860__O(); A_arbace_core__init_A_Unit861__O(); A_arbace_core__init_A_Unit862__O(); A_arbace_core__init_A_Unit863__O(); A_arbace_core__init_A_Unit864__O(); A_arbace_core__init_A_Unit865__O(); A_arbace_core__init_A_Unit866__O(); A_arbace_core__init_A_Unit867__O(); A_arbace_core__init_A_Unit868__O(); A_arbace_core__init_A_Unit869__O(); A_arbace_core__init_A_Unit870__O(); A_arbace_core__init_A_Unit871__O(); A_arbace_core__init_A_Unit872__O(); A_arbace_core__init_A_Unit873__O(); A_arbace_core__init_A_Unit874__O(); A_arbace_core__init_A_Unit875__O(); A_arbace_core__init_A_Unit876__O(); A_arbace_core__init_A_Unit877__O(); A_arbace_core__init_A_Unit878__O(); A_arbace_core__init_A_Unit879__O(); A_arbace_core__init_A_Unit880__O(); A_arbace_core__init_A_Unit881__O(); A_arbace_core__init_A_Unit882__O(); A_arbace_core__init_A_Unit883__O(); A_arbace_core__init_A_Unit884__O(); A_arbace_core__init_A_Unit885__O(); A_arbace_core__init_A_Unit886__O(); A_arbace_core__init_A_Unit887__O(); A_arbace_core__init_A_Unit888__O(); A_arbace_core__init_A_Unit889__O(); A_arbace_core__init_A_Unit890__O(); A_arbace_core__init_A_Unit891__O(); A_arbace_core__init_A_Unit892__O(); A_arbace_core__init_A_Unit893__O(); A_arbace_core__init_A_Unit894__O(); A_arbace_core__init_A_Unit895__O(); A_arbace_core__init_A_Unit896__O(); A_arbace_core__init_A_Unit897__O(); A_arbace_core__init_A_Unit898__O(); A_arbace_core__init_A_Unit899__O(); A_arbace_core__init_A_Unit900__O(); A_arbace_core__init_A_Unit901__O(); return nil }



func A_arbace_core__init_A_Unit0__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; var tmp2 *lang.Var = tmp1; jrt.NN(tmp2).Set_O__O(lang.Namespace_FindOrCreate_Symbol__Namespace(lang.Symbol_Cast(A_arbace_core__init_A_const_1)).Ref()); return A_arbace_core__init_A_const_0 }



func A_arbace_core__init_A_Unit1__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(13, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_2; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_3)); return A_arbace_core__init_A_const_2 }
func A_arbace_core__init_A_Unit2__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(14, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_5)); return A_arbace_core__init_A_const_4 }

func A_arbace_core__init_A_Unit3__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(16, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_6; var tmp2 lang.IFn; lang.PersistentList_Init(); tmp2 = lang.PersistentList_creator; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_core__init_A_const_6; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_7)); return A_arbace_core__init_A_const_6 }





func A_arbace_core__init_A_Unit4__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(22, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_8; var tmp2 any = A_arbace_core_cons__1927000000_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_core_cons__1927000000_A_fn_class; if






	fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_711, false); A_arbace_core_cons__1927000000_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; /*line :22:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_9)); return A_arbace_core__init_A_const_8 }









func A_arbace_core__init_A_Unit5__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(32, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_10; var tmp2 any = A_arbace_core_let__1927000002_A_New(); var tmp3 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_core_let__1927000002_A_fn_class; if


	fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_712, true); A_arbace_core_let__1927000002_A_fn_class = fncls__2d; tmp3 = fncls__2d } else { tmp3 = fncls__2 }; /*line :32:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_11)); return A_arbace_core__init_A_const_10 }




func A_arbace_core__init_A_Unit6__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(37, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_12; var tmp2 any = A_arbace_core_loop__1927000004_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_core_loop__1927000004_A_fn_class; if


	fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_713, true); A_arbace_core_loop__1927000004_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; /*line :37:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_13)); return A_arbace_core__init_A_const_12 }




func A_arbace_core__init_A_Unit7__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(42, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_14; var tmp2 any = A_arbace_core_fn__1927000006_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_core_fn__1927000006_A_fn_class; if


	fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_714, true); A_arbace_core_fn__1927000006_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; /*line :42:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_15)); return A_arbace_core__init_A_const_14 }






func A_arbace_core__init_A_Unit8__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(49, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_16; var tmp2 any = A_arbace_core_first__1927000008_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_core_first__1927000008_A_fn_class; if





	fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_715, false); A_arbace_core_first__1927000008_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; /*line :49:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_17)); return A_arbace_core__init_A_const_16 }







func A_arbace_core__init_A_Unit9__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(57, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_18; var tmp2 any = A_arbace_core_next__1927000010_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_core_next__1927000010_A_fn_class; if






	fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_716, false); A_arbace_core_next__1927000010_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; /*line :57:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_19)); return A_arbace_core__init_A_const_18 }








func A_arbace_core__init_A_Unit10__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(66, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_20; var tmp2 any = A_arbace_core_rest__1927000012_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_core_rest__1927000012_A_fn_class; if






	fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_717, false); A_arbace_core_rest__1927000012_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; /*line :66:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_21)); return A_arbace_core__init_A_const_20 }








func A_arbace_core__init_A_Unit11__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(75, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_22; var tmp2 any = A_arbace_core_conj__1927000014_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_core_conj__1927000014_A_fn_class; if








	fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_718, true); A_arbace_core_conj__1927000014_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; /*line :75:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_23)); return A_arbace_core__init_A_const_22 }

















func A_arbace_core__init_A_Unit12__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(93, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_24; var tmp2 any = A_arbace_core_second__1927000016_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_core_second__1927000016_A_fn_class; if




	fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_719, false); A_arbace_core_second__1927000016_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; /*line :93:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_25)); return A_arbace_core__init_A_const_24 }






func A_arbace_core__init_A_Unit13__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(100, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_26; var tmp2 any = A_arbace_core_ffirst__1927000018_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_core_ffirst__1927000018_A_fn_class; if




	fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_720, false); A_arbace_core_ffirst__1927000018_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; /*line :100:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_27)); return A_arbace_core__init_A_const_26 }






func A_arbace_core__init_A_Unit14__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(107, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_28; var tmp2 any = A_arbace_core_nfirst__1927000020_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_core_nfirst__1927000020_A_fn_class; if




	fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_721, false); A_arbace_core_nfirst__1927000020_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; /*line :107:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_29)); return A_arbace_core__init_A_const_28 }






func A_arbace_core__init_A_Unit15__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(114, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_30; var tmp2 any = A_arbace_core_fnext__1927000022_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_core_fnext__1927000022_A_fn_class; if




	fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_722, false); A_arbace_core_fnext__1927000022_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; /*line :114:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_31)); return A_arbace_core__init_A_const_30 }






func A_arbace_core__init_A_Unit16__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(121, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_32; var tmp2 any = A_arbace_core_nnext__1927000024_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_core_nnext__1927000024_A_fn_class; if




	fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_723, false); A_arbace_core_nnext__1927000024_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; /*line :121:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_33)); return A_arbace_core__init_A_const_32 }






func A_arbace_core__init_A_Unit17__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(128, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_34; var tmp2 any = A_arbace_core_seq__1927000026_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_core_seq__1927000026_A_fn_class; if










	fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_724, false); A_arbace_core_seq__1927000026_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; /*line :128:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_35)); return A_arbace_core__init_A_const_34 }












func A_arbace_core__init_A_Unit18__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(141, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_36; var tmp2 any = A_arbace_core_instance_QMARK___1927000028_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_core_instance_QMARK___1927000028_A_fn_class; if




	fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_725, false); A_arbace_core_instance_QMARK___1927000028_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; /*line :141:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_37)); return A_arbace_core__init_A_const_36 }






func A_arbace_core__init_A_Unit19__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(148, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_38; var tmp2 any = A_arbace_core_seq_QMARK___1927000030_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_core_seq_QMARK___1927000030_A_fn_class; if




	fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_726, false); A_arbace_core_seq_QMARK___1927000030_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; /*line :148:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_39)); return A_arbace_core__init_A_const_38 }






func A_arbace_core__init_A_Unit20__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(155, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_40; var tmp2 any = A_arbace_core_char_QMARK___1927000032_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_core_char_QMARK___1927000032_A_fn_class; if




	fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_727, false); A_arbace_core_char_QMARK___1927000032_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; /*line :155:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_41)); return A_arbace_core__init_A_const_40 }






func A_arbace_core__init_A_Unit21__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(162, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_42; var tmp2 any = A_arbace_core_string_QMARK___1927000034_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_core_string_QMARK___1927000034_A_fn_class; if




	fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_728, false); A_arbace_core_string_QMARK___1927000034_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; /*line :162:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_43)); return A_arbace_core__init_A_const_42 }






func A_arbace_core__init_A_Unit22__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(169, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_44; var tmp2 any = A_arbace_core_map_QMARK___1927000036_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_core_map_QMARK___1927000036_A_fn_class; if




	fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_729, false); A_arbace_core_map_QMARK___1927000036_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; /*line :169:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_45)); return A_arbace_core__init_A_const_44 }






func A_arbace_core__init_A_Unit23__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(176, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_46; var tmp2 any = A_arbace_core_vector_QMARK___1927000038_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_core_vector_QMARK___1927000038_A_fn_class; if




	fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_730, false); A_arbace_core_vector_QMARK___1927000038_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; /*line :176:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_47)); return A_arbace_core__init_A_const_46 }






func A_arbace_core__init_A_Unit24__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(183, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_48; var tmp2 any = A_arbace_core_assoc__1927000040_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_core_assoc__1927000040_A_fn_class; if








	fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_731, true); A_arbace_core_assoc__1927000040_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; /*line :183:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_49)); return A_arbace_core__init_A_const_48 }




















func A_arbace_core__init_A_Unit25__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(204, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_50; var tmp2 any = A_arbace_core_meta__1927000044_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_core_meta__1927000044_A_fn_class; if






	fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_732, false); A_arbace_core_meta__1927000044_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; /*line :204:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_50; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_52; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_54; var tmp9 any = A_arbace_core__init_A_const_55; var tmp10 *jrt.Boolean; jrt.Boolean_Init(); tmp10 = jrt.Boolean_TRUE; var tmp11 any = tmp10.Ref(); var tmp12 any = A_arbace_core__init_A_const_56; var tmp13 any = A_arbace_core_fn__1927000042_A_New(); var tmp14 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_core_fn__1927000042_A_fn_class; if




	fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_735, false); A_arbace_core_fn__1927000042_A_fn_class = fncls__23d; tmp14 = fncls__23d } else { tmp14 = fncls__23 }; /*line :204:1*/tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_733, tmp8, Lit_734, tmp9, tmp11, tmp12, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil), A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_58, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_50 }









func A_arbace_core__init_A_Unit26__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(214, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_62; var tmp2 any = A_arbace_core_with_meta__1927000046_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_core_with_meta__1927000046_A_fn_class; if





	fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_737, false); A_arbace_core_with_meta__1927000046_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; /*line :214:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_63)); return A_arbace_core__init_A_const_62 }








func A_arbace_core__init_A_Unit27__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(223, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_64; var tmp2 any = A_arbace_core_assert_valid_fdecl_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_core_assert_valid_fdecl_A_fn_class; if
						fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_738, false); A_arbace_core_assert_valid_fdecl_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; /*line :223:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_65)); return A_arbace_core__init_A_const_64.SetDynamic_Z__Var(true).Ref() }


func A_arbace_core__init_A_Unit28__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(226, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_66; var tmp2 any = A_arbace_core_sigs_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_core_sigs_A_fn_class; if


	fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_739, false); A_arbace_core_sigs_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; /*line :226:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_67)); return A_arbace_core__init_A_const_66 }





































func A_arbace_core__init_A_Unit29__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(264, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_68; var tmp2 any = A_arbace_core_last__1927000054_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_core_last__1927000054_A_fn_class; if




	fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_740, false); A_arbace_core_last__1927000054_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; /*line :264:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_69)); return A_arbace_core__init_A_const_68 }









func A_arbace_core__init_A_Unit30__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(274, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_70; var tmp2 any = A_arbace_core_butlast__1927000056_A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_core_butlast__1927000056_A_fn_class; if




	fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_741, false); A_arbace_core_butlast__1927000056_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; /*line :274:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_71)); return A_arbace_core__init_A_const_70 }










func A_arbace_core__init_A_Unit31__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(285, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_72; var tmp2 any = A_arbace_core_defn__1927000058_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_core_defn__1927000058_A_fn_class; if








	fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_742, true); A_arbace_core_defn__1927000058_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; /*line :285:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_73)); return A_arbace_core__init_A_const_72 }




















































func A_arbace_core__init_A_Unit32__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(338, 1); A_arbace_core__init_A_const_72.SetMacro__V(); return nil }

func A_arbace_core__init_A_Unit33__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(340, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_74; var tmp2 any = A_arbace_core_to_array_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_core_to_array_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_743, false); A_arbace_core_to_array_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_75)); return A_arbace_core__init_A_const_74 }







func A_arbace_core__init_A_Unit34__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(348, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_76; var tmp2 any = A_arbace_core_cast_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_core_cast_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_744, false); A_arbace_core_cast_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_77)); return A_arbace_core__init_A_const_76 }






func A_arbace_core__init_A_Unit35__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(355, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_78; var tmp2 any = A_arbace_core_vector_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_core_vector_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_745, true); A_arbace_core_vector_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 6)); var tmp4 *lang.Var = A_arbace_core__init_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_79)); return A_arbace_core__init_A_const_78 }













func A_arbace_core__init_A_Unit36__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(369, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_80; var tmp2 any = A_arbace_core_vec_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_core_vec_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_746, false); A_arbace_core_vec_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_81)); return A_arbace_core__init_A_const_80 }











func A_arbace_core__init_A_Unit37__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(381, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_82; var tmp2 any = A_arbace_core_hash_map_A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_core_hash_map_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_747, true); A_arbace_core_hash_map_A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_core__init_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_83)); return A_arbace_core__init_A_const_82 }









func A_arbace_core__init_A_Unit38__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(391, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_84; var tmp2 any = A_arbace_core_hash_set_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_core_hash_set_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_748, true); A_arbace_core_hash_set_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_core__init_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_85)); return A_arbace_core__init_A_const_84 }








func A_arbace_core__init_A_Unit39__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(400, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_86; var tmp2 any = A_arbace_core_sorted_map_A_New(); var tmp3 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_core_sorted_map_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_749, true); A_arbace_core_sorted_map_A_fn_class = fncls__36d; tmp3 = fncls__36d } else { tmp3 = fncls__36 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_core__init_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_87)); return A_arbace_core__init_A_const_86 }








func A_arbace_core__init_A_Unit40__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(409, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_88; var tmp2 any = A_arbace_core_sorted_map_by_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_core_sorted_map_by_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_750, true); A_arbace_core_sorted_map_by_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_core__init_A_const_88; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_89)); return A_arbace_core__init_A_const_88 }









func A_arbace_core__init_A_Unit41__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(419, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_90; var tmp2 any = A_arbace_core_sorted_set_A_New(); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_core_sorted_set_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_751, true); A_arbace_core_sorted_set_A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_core__init_A_const_90; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_91)); return A_arbace_core__init_A_const_90 }







func A_arbace_core__init_A_Unit42__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(427, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_92; var tmp2 any = A_arbace_core_sorted_set_by_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_core_sorted_set_by_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_752, true); A_arbace_core_sorted_set_by_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_core__init_A_const_92; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_93)); return A_arbace_core__init_A_const_92 }










func A_arbace_core__init_A_Unit43__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(438, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_94; var tmp2 any = A_arbace_core_nil_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_core_nil_QMARK__A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_753, false); A_arbace_core_nil_QMARK__A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_94; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_95; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_96; var tmp9 any = A_arbace_core__init_A_const_97; var tmp10 any = A_arbace_core__init_A_const_54; var tmp11 any = A_arbace_core__init_A_const_55; var tmp12 *jrt.Boolean; jrt.Boolean_Init(); tmp12 = jrt.Boolean_TRUE; var tmp13 any = tmp12.Ref(); var tmp14 any = A_arbace_core__init_A_const_56; var tmp15 any = A_arbace_core_nil_QMARK___inliner__1927000072_A_New(); var tmp16 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_core_nil_QMARK___inliner__1927000072_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_755, false); A_arbace_core_nil_QMARK___inliner__1927000072_A_fn_class = fncls__41d; tmp16 = fncls__41d } else { tmp16 = fncls__41 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_754, tmp8, tmp9, tmp10, Lit_734, tmp11, tmp13, tmp14, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil), A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_98, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_94 }







func A_arbace_core__init_A_Unit44__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(446, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_99; var tmp2 any = A_arbace_core_defmacro_A_New(); var tmp3 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_core_defmacro_A_fn_class; if







	fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_756, true); A_arbace_core_defmacro_A_fn_class = fncls__42d; tmp3 = fncls__42d } else { tmp3 = fncls__42 }; /*line :446:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_99; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_100)); return A_arbace_core__init_A_const_99 }













































func A_arbace_core__init_A_Unit45__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(492, 1); A_arbace_core__init_A_const_99.SetMacro__V(); return nil }

func A_arbace_core__init_A_Unit46__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(494, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_101; var tmp2 any = A_arbace_core_when_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_core_when_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_757, true); A_arbace_core_when_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_101; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_102)); return A_arbace_core__init_A_const_101 }
//line :494:1
func A_arbace_core__init_A_Unit47__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(494, 1); A_arbace_core__init_A_const_101.SetMacro__V(); return nil }
//line :494:1
func A_arbace_core__init_A_Unit48__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(494, 1); return A_arbace_core__init_A_const_101 }





func A_arbace_core__init_A_Unit49__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(500, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_103; var tmp2 any = A_arbace_core_when_not_A_New(); var tmp3 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_core_when_not_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_758, true); A_arbace_core_when_not_A_fn_class = fncls__44d; tmp3 = fncls__44d } else { tmp3 = fncls__44 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_103; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_104)); return A_arbace_core__init_A_const_103 }
//line :500:1
func A_arbace_core__init_A_Unit50__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(500, 1); A_arbace_core__init_A_const_103.SetMacro__V(); return nil }
//line :500:1
func A_arbace_core__init_A_Unit51__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(500, 1); return A_arbace_core__init_A_const_103 }





func A_arbace_core__init_A_Unit52__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(506, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_105; var tmp2 any = A_arbace_core_false_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_core_false_QMARK__A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_759, false); A_arbace_core_false_QMARK__A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_105; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_106)); return A_arbace_core__init_A_const_105 }






func A_arbace_core__init_A_Unit53__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(513, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_107; var tmp2 any = A_arbace_core_true_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_core_true_QMARK__A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_760, false); A_arbace_core_true_QMARK__A_fn_class = fncls__46d; tmp3 = fncls__46d } else { tmp3 = fncls__46 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_107; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_108)); return A_arbace_core__init_A_const_107 }






func A_arbace_core__init_A_Unit54__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(520, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_109; var tmp2 any = A_arbace_core_boolean_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_core_boolean_QMARK__A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_761, false); A_arbace_core_boolean_QMARK__A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_109; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_110)); return A_arbace_core__init_A_const_109 }




func A_arbace_core__init_A_Unit55__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(525, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_111; var tmp2 any = A_arbace_core_not_A_New(); var tmp3 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_core_not_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_762, false); A_arbace_core_not_A_fn_class = fncls__48d; tmp3 = fncls__48d } else { tmp3 = fncls__48 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_111; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_112)); return A_arbace_core__init_A_const_111 }






func A_arbace_core__init_A_Unit56__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(532, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_113; var tmp2 any = A_arbace_core_some_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_core_some_QMARK__A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_763, false); A_arbace_core_some_QMARK__A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_113; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_114)); return A_arbace_core__init_A_const_113 }






func A_arbace_core__init_A_Unit57__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(539, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_115; var tmp2 any = A_arbace_core_any_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_core_any_QMARK__A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_764, false); A_arbace_core_any_QMARK__A_fn_class = fncls__50d; tmp3 = fncls__50d } else { tmp3 = fncls__50 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_115; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_116)); return A_arbace_core__init_A_const_115 }





func A_arbace_core__init_A_Unit58__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(545, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_117; var tmp2 any = A_arbace_core_str_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_core_str_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_765, true); A_arbace_core_str_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_core__init_A_const_117; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_118)); return A_arbace_core__init_A_const_117 }
















func A_arbace_core__init_A_Unit59__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(562, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_119; var tmp2 any = A_arbace_core_symbol_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_core_symbol_QMARK__A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_766, false); A_arbace_core_symbol_QMARK__A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_119; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_120)); return A_arbace_core__init_A_const_119 }





func A_arbace_core__init_A_Unit60__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(568, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_121; var tmp2 any = A_arbace_core_keyword_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_core_keyword_QMARK__A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_767, false); A_arbace_core_keyword_QMARK__A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_121; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_122)); return A_arbace_core__init_A_const_121 }





func A_arbace_core__init_A_Unit61__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(574, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_123; var tmp2 any = A_arbace_core_cond_A_New(); var tmp3 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_core_cond_A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_768, true); A_arbace_core_cond_A_fn_class = fncls__54d; tmp3 = fncls__54d } else { tmp3 = fncls__54 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_123; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_124)); return A_arbace_core__init_A_const_123 }
//line :574:1
func A_arbace_core__init_A_Unit62__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(574, 1); A_arbace_core__init_A_const_123.SetMacro__V(); return nil }
//line :574:1
func A_arbace_core__init_A_Unit63__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(574, 1); return A_arbace_core__init_A_const_123 }














func A_arbace_core__init_A_Unit64__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(589, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_125; var tmp2 any = A_arbace_core_symbol_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_core_symbol_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_769, false); A_arbace_core_symbol_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_125; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_126)); return A_arbace_core__init_A_const_125 }














func A_arbace_core__init_A_Unit65__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(604, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_127; var tmp2 any = A_arbace_core_gensym_A_New(); var tmp3 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_core_gensym_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_770, false); A_arbace_core_gensym_A_fn_class = fncls__56d; tmp3 = fncls__56d } else { tmp3 = fncls__56 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_127; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_128)); return A_arbace_core__init_A_const_127 }








func A_arbace_core__init_A_Unit66__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(613, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_129; var tmp2 any = A_arbace_core_keyword_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_core_keyword_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_771, false); A_arbace_core_keyword_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_129; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_130)); return A_arbace_core__init_A_const_129 }










func A_arbace_core__init_A_Unit67__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(624, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_131; var tmp2 any = A_arbace_core_find_keyword_A_New(); var tmp3 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_core_find_keyword_A_fn_class; if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_772, false); A_arbace_core_find_keyword_A_fn_class = fncls__58d; tmp3 = fncls__58d } else { tmp3 = fncls__58 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_131; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_132)); return A_arbace_core__init_A_const_131 }












func A_arbace_core__init_A_Unit68__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(637, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_133; var tmp2 any = A_arbace_core_spread_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_core_spread_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_773, false); A_arbace_core_spread_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_133; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_134)); return A_arbace_core__init_A_const_133 }








func A_arbace_core__init_A_Unit69__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(646, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_135; var tmp2 any = A_arbace_core_list_STAR__A_New(); var tmp3 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_core_list_STAR__A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_774, true); A_arbace_core_list_STAR__A_fn_class = fncls__60d; tmp3 = fncls__60d } else { tmp3 = fncls__60 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 4)); var tmp4 *lang.Var = A_arbace_core__init_A_const_135; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_136)); return A_arbace_core__init_A_const_135 }











func A_arbace_core__init_A_Unit70__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(658, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_137; var tmp2 any = A_arbace_core_apply_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_core_apply_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_775, true); A_arbace_core_apply_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 5)); var tmp4 *lang.Var = A_arbace_core__init_A_const_137; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_138)); return A_arbace_core__init_A_const_137 }














func A_arbace_core__init_A_Unit71__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(673, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_139; var tmp2 any = A_arbace_core_vary_meta_A_New(); var tmp3 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_core_vary_meta_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_776, true); A_arbace_core_vary_meta_A_fn_class = fncls__62d; tmp3 = fncls__62d } else { tmp3 = fncls__62 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_139; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_140)); return A_arbace_core__init_A_const_139 }







func A_arbace_core__init_A_Unit72__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(681, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_141; var tmp2 any = A_arbace_core_lazy_seq_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_core_lazy_seq_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_777, true); A_arbace_core_lazy_seq_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_141; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_142)); return A_arbace_core__init_A_const_141 }
//line :681:1
func A_arbace_core__init_A_Unit73__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(681, 1); A_arbace_core__init_A_const_141.SetMacro__V(); return nil }
//line :681:1
func A_arbace_core__init_A_Unit74__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(681, 1); return A_arbace_core__init_A_const_141 }








func A_arbace_core__init_A_Unit75__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(690, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_143; var tmp2 any = A_arbace_core_chunk_buffer_A_New(); var tmp3 *jrt.Class; var fncls__64 *jrt.Class = A_arbace_core_chunk_buffer_A_fn_class; if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_778, false); A_arbace_core_chunk_buffer_A_fn_class = fncls__64d; tmp3 = fncls__64d } else { tmp3 = fncls__64 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_143; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_144)); return A_arbace_core__init_A_const_143 }


func A_arbace_core__init_A_Unit76__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(693, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_145; var tmp2 any = A_arbace_core_chunk_append_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_core_chunk_append_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_779, false); A_arbace_core_chunk_append_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_145; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_146)); return A_arbace_core__init_A_const_145 }


func A_arbace_core__init_A_Unit77__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(696, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_147; var tmp2 any = A_arbace_core_chunk_A_New(); var tmp3 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_core_chunk_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_780, false); A_arbace_core_chunk_A_fn_class = fncls__66d; tmp3 = fncls__66d } else { tmp3 = fncls__66 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_147; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_148)); return A_arbace_core__init_A_const_147 }


func A_arbace_core__init_A_Unit78__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(699, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_149; var tmp2 any = A_arbace_core_chunk_first_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_core_chunk_first_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_781, false); A_arbace_core_chunk_first_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_149; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_150)); return A_arbace_core__init_A_const_149 }


func A_arbace_core__init_A_Unit79__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(702, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_151; var tmp2 any = A_arbace_core_chunk_rest_A_New(); var tmp3 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_core_chunk_rest_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_782, false); A_arbace_core_chunk_rest_A_fn_class = fncls__68d; tmp3 = fncls__68d } else { tmp3 = fncls__68 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_151; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_152)); return A_arbace_core__init_A_const_151 }


func A_arbace_core__init_A_Unit80__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(705, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_153; var tmp2 any = A_arbace_core_chunk_next_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_core_chunk_next_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_783, false); A_arbace_core_chunk_next_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_153; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_154)); return A_arbace_core__init_A_const_153 }


func A_arbace_core__init_A_Unit81__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(708, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_155; var tmp2 any = A_arbace_core_chunk_cons_A_New(); var tmp3 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_core_chunk_cons_A_fn_class; if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_784, false); A_arbace_core_chunk_cons_A_fn_class = fncls__70d; tmp3 = fncls__70d } else { tmp3 = fncls__70 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_155; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_156)); return A_arbace_core__init_A_const_155 }




func A_arbace_core__init_A_Unit82__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(713, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_157; var tmp2 any = A_arbace_core_chunked_seq_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_core_chunked_seq_QMARK__A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_785, false); A_arbace_core_chunked_seq_QMARK__A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_157; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_158)); return A_arbace_core__init_A_const_157 }


func A_arbace_core__init_A_Unit83__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(716, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_159; var tmp2 any = A_arbace_core_concat_A_New(); var tmp3 *jrt.Class; var fncls__72 *jrt.Class = A_arbace_core_concat_A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_786, true); A_arbace_core_concat_A_fn_class = fncls__72d; tmp3 = fncls__72d } else { tmp3 = fncls__72 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_159; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_160)); return A_arbace_core__init_A_const_159 }



























func A_arbace_core__init_A_Unit84__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(744, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_161; var tmp2 any = A_arbace_core_delay_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_core_delay_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_787, true); A_arbace_core_delay_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_161; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_162)); return A_arbace_core__init_A_const_161 }
//line :744:1
func A_arbace_core__init_A_Unit85__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(744, 1); A_arbace_core__init_A_const_161.SetMacro__V(); return nil }
//line :744:1
func A_arbace_core__init_A_Unit86__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(744, 1); return A_arbace_core__init_A_const_161 }








func A_arbace_core__init_A_Unit87__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(753, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_163; var tmp2 any = A_arbace_core_delay_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__74 *jrt.Class = A_arbace_core_delay_QMARK__A_fn_class; if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_788, false); A_arbace_core_delay_QMARK__A_fn_class = fncls__74d; tmp3 = fncls__74d } else { tmp3 = fncls__74 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_163; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_164)); return A_arbace_core__init_A_const_163 }





func A_arbace_core__init_A_Unit88__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(759, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_165; var tmp2 any = A_arbace_core_force_A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_core_force_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_789, false); A_arbace_core_force_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_165; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_166)); return A_arbace_core__init_A_const_165 }





func A_arbace_core__init_A_Unit89__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(765, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_167; var tmp2 any = A_arbace_core_if_not_A_New(); var tmp3 *jrt.Class; var fncls__76 *jrt.Class = A_arbace_core_if_not_A_fn_class; if fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_790, false); A_arbace_core_if_not_A_fn_class = fncls__76d; tmp3 = fncls__76d } else { tmp3 = fncls__76 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_167; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_168)); return A_arbace_core__init_A_const_167 }
//line :765:1
func A_arbace_core__init_A_Unit90__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(765, 1); A_arbace_core__init_A_const_167.SetMacro__V(); return nil }
//line :765:1
func A_arbace_core__init_A_Unit91__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(765, 1); return A_arbace_core__init_A_const_167 }







func A_arbace_core__init_A_Unit92__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(773, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_169; var tmp2 any = A_arbace_core_identical_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_core_identical_QMARK__A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_791, false); A_arbace_core_identical_QMARK__A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_169; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_170; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_identical_QMARK___inliner__1927000158_A_New(); var tmp10 *jrt.Class; var fncls__78 *jrt.Class = A_arbace_core_identical_QMARK___inliner__1927000158_A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_793, false); A_arbace_core_identical_QMARK___inliner__1927000158_A_fn_class = fncls__78d; tmp10 = fncls__78d } else { tmp10 = fncls__78 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_792, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_171, A_arbace_core__init_A_const_172, A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_173, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_169 }







func A_arbace_core__init_A_Unit93__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(781, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_174; var tmp2 any = A_arbace_core__EQ__A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_core__EQ__A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_794, true); A_arbace_core__EQ__A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_174; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_175; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core__EQ___inliner__1927000161_A_New(); var tmp10 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_core__EQ___inliner__1927000161_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_796, false); A_arbace_core__EQ___inliner__1927000161_A_fn_class = fncls__80d; tmp10 = fncls__80d } else { tmp10 = fncls__80 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_795, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_171, A_arbace_core__init_A_const_176, A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_177, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_174 }



































func A_arbace_core__init_A_Unit94__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(817, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_178; var tmp2 any = A_arbace_core_not_EQ__A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_core_not_EQ__A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_797, true); A_arbace_core_not_EQ__A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_178; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_179)); return A_arbace_core__init_A_const_178 }









func A_arbace_core__init_A_Unit95__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(827, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_180; var tmp2 any = A_arbace_core_compare_A_New(); var tmp3 *jrt.Class; var fncls__82 *jrt.Class = A_arbace_core_compare_A_fn_class; if fncls__82 == nil { var fncls__82d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_798, false); A_arbace_core_compare_A_fn_class = fncls__82d; tmp3 = fncls__82d } else { tmp3 = fncls__82 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_180; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_181; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_compare__inliner__1927000165_A_New(); var tmp10 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_core_compare__inliner__1927000165_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_800, false); A_arbace_core_compare__inliner__1927000165_A_fn_class = fncls__83d; tmp10 = fncls__83d } else { tmp10 = fncls__83 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_799, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_182, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_180 }










func A_arbace_core__init_A_Unit96__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(838, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_183; var tmp2 any = A_arbace_core_and_A_New(); var tmp3 *jrt.Class; var fncls__84 *jrt.Class = A_arbace_core_and_A_fn_class; if fncls__84 == nil { var fncls__84d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_801, true); A_arbace_core_and_A_fn_class = fncls__84d; tmp3 = fncls__84d } else { tmp3 = fncls__84 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_183; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_184)); return A_arbace_core__init_A_const_183 }
//line :838:1
func A_arbace_core__init_A_Unit97__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(838, 1); A_arbace_core__init_A_const_183.SetMacro__V(); return nil }
//line :838:1
func A_arbace_core__init_A_Unit98__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(838, 1); return A_arbace_core__init_A_const_183 }











func A_arbace_core__init_A_Unit99__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(850, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_185; var tmp2 any = A_arbace_core_or_A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_core_or_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_802, true); A_arbace_core_or_A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_185; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_186)); return A_arbace_core__init_A_const_185 }
//line :850:1
func A_arbace_core__init_A_Unit100__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(850, 1); A_arbace_core__init_A_const_185.SetMacro__V(); return nil }
//line :850:1
func A_arbace_core__init_A_Unit101__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(850, 1); return A_arbace_core__init_A_const_185 }












func A_arbace_core__init_A_Unit102__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(863, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_187; var tmp2 any = A_arbace_core_zero_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__86 *jrt.Class = A_arbace_core_zero_QMARK__A_fn_class; if fncls__86 == nil { var fncls__86d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_803, false); A_arbace_core_zero_QMARK__A_fn_class = fncls__86d; tmp3 = fncls__86d } else { tmp3 = fncls__86 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_187; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_188; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_zero_QMARK___inliner__1927000180_A_New(); var tmp10 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_core_zero_QMARK___inliner__1927000180_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_805, false); A_arbace_core_zero_QMARK___inliner__1927000180_A_fn_class = fncls__87d; tmp10 = fncls__87d } else { tmp10 = fncls__87 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_804, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_189, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_187 }






func A_arbace_core__init_A_Unit103__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(870, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_190; var tmp2 any = A_arbace_core_count_A_New(); var tmp3 *jrt.Class; var fncls__88 *jrt.Class = A_arbace_core_count_A_fn_class; if fncls__88 == nil { var fncls__88d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_806, false); A_arbace_core_count_A_fn_class = fncls__88d; tmp3 = fncls__88d } else { tmp3 = fncls__88 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_190; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_191; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_count__inliner__1927000183_A_New(); var tmp10 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_core_count__inliner__1927000183_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_808, false); A_arbace_core_count__inliner__1927000183_A_fn_class = fncls__89d; tmp10 = fncls__89d } else { tmp10 = fncls__89 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_807, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_192, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_190 }







func A_arbace_core__init_A_Unit104__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(878, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_193; var tmp2 any = A_arbace_core_int_A_New(); var tmp3 *jrt.Class; var fncls__90 *jrt.Class = A_arbace_core_int_A_fn_class; if fncls__90 == nil { var fncls__90d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_809, false); A_arbace_core_int_A_fn_class = fncls__90d; tmp3 = fncls__90d } else { tmp3 = fncls__90 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_193; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_194; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_int__inliner__1927000186_A_New(); var tmp10 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_core_int__inliner__1927000186_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_811, false); A_arbace_core_int__inliner__1927000186_A_fn_class = fncls__91d; tmp10 = fncls__91d } else { tmp10 = fncls__91 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_810, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_195, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_193 }






func A_arbace_core__init_A_Unit105__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(885, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_196; var tmp2 any = A_arbace_core_nth_A_New(); var tmp3 *jrt.Class; var fncls__92 *jrt.Class = A_arbace_core_nth_A_fn_class; if fncls__92 == nil { var fncls__92d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_812, false); A_arbace_core_nth_A_fn_class = fncls__92d; tmp3 = fncls__92d } else { tmp3 = fncls__92 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_196; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_197; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_nth__inliner__1927000189_A_New(); var tmp10 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_core_nth__inliner__1927000189_A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_814, true); A_arbace_core_nth__inliner__1927000189_A_fn_class = fncls__93d; tmp10 = fncls__93d } else { tmp10 = fncls__93 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_813, tmp8, lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp9, tmp10, nil, 2), A_arbace_core__init_A_const_171, A_arbace_core__init_A_const_198, A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_199, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_196 }










func A_arbace_core__init_A_Unit106__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(896, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_200; var tmp2 any = A_arbace_core__LT__A_New(); var tmp3 *jrt.Class; var fncls__94 *jrt.Class = A_arbace_core__LT__A_fn_class; if fncls__94 == nil { var fncls__94d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_815, true); A_arbace_core__LT__A_fn_class = fncls__94d; tmp3 = fncls__94d } else { tmp3 = fncls__94 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_200; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_201; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core__LT___inliner__1927000192_A_New(); var tmp10 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_core__LT___inliner__1927000192_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_817, false); A_arbace_core__LT___inliner__1927000192_A_fn_class = fncls__95d; tmp10 = fncls__95d } else { tmp10 = fncls__95 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_816, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_171, A_arbace_core__init_A_const_202, A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_203, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_200 }














func A_arbace_core__init_A_Unit107__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(911, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_204; var tmp2 any = A_arbace_core_inc_SINGLEQUOTE__A_New(); var tmp3 *jrt.Class; var fncls__96 *jrt.Class = A_arbace_core_inc_SINGLEQUOTE__A_fn_class; if fncls__96 == nil { var fncls__96d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_818, false); A_arbace_core_inc_SINGLEQUOTE__A_fn_class = fncls__96d; tmp3 = fncls__96d } else { tmp3 = fncls__96 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_204; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_205; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_inc_SINGLEQUOTE___inliner__1927000195_A_New(); var tmp10 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_core_inc_SINGLEQUOTE___inliner__1927000195_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_820, false); A_arbace_core_inc_SINGLEQUOTE___inliner__1927000195_A_fn_class = fncls__97d; tmp10 = fncls__97d } else { tmp10 = fncls__97 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_819, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_206, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_204 }






func A_arbace_core__init_A_Unit108__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(918, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_207; var tmp2 any = A_arbace_core_inc_A_New(); var tmp3 *jrt.Class; var fncls__98 *jrt.Class = A_arbace_core_inc_A_fn_class; if fncls__98 == nil { var fncls__98d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_821, false); A_arbace_core_inc_A_fn_class = fncls__98d; tmp3 = fncls__98d } else { tmp3 = fncls__98 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_207; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_208; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_inc__inliner__1927000198_A_New(); var tmp10 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_core_inc__inliner__1927000198_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_823, false); A_arbace_core_inc__inliner__1927000198_A_fn_class = fncls__99d; tmp10 = fncls__99d } else { tmp10 = fncls__99 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_822, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_824, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_209, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_207 }







func A_arbace_core__init_A_Unit109__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(926, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_210; var tmp2 any = A_arbace_core_reduce0_A_New(); var tmp3 *jrt.Class; var fncls__100 *jrt.Class = A_arbace_core_reduce0_A_fn_class; if fncls__100 == nil { var fncls__100d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_825, false); A_arbace_core_reduce0_A_fn_class = fncls__100d; tmp3 = fncls__100d } else { tmp3 = fncls__100 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_210; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_211)); return A_arbace_core__init_A_const_210 }
















func A_arbace_core__init_A_Unit110__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(943, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_212; tmp1.BindRoot_O__V(A_arbace_core__init_A_const_210.GetRawRoot__O()); var tmp2 *lang.Var = A_arbace_core__init_A_const_212; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_213)); return A_arbace_core__init_A_const_212 }

func A_arbace_core__init_A_Unit111__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(945, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_214; var tmp2 any = A_arbace_core_reverse_A_New(); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_core_reverse_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_826, false); A_arbace_core_reverse_A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_214; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_215)); return A_arbace_core__init_A_const_214 }







func A_arbace_core__init_A_Unit112__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(953, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_216; var tmp2 any = A_arbace_core_nary_inline_A_New(); var tmp3 *jrt.Class; var fncls__102 *jrt.Class = A_arbace_core_nary_inline_A_fn_class; if fncls__102 == nil { var fncls__102d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_827, false); A_arbace_core_nary_inline_A_fn_class = fncls__102d; tmp3 = fncls__102d } else { tmp3 = fncls__102 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_216; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_217)); return A_arbace_core__init_A_const_216 }













func A_arbace_core__init_A_Unit113__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(967, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_218; var tmp2 any = A_arbace_core__GT_1_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_core__GT_1_QMARK__A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_828, false); A_arbace_core__GT_1_QMARK__A_fn_class = fncls__103d; tmp3 = fncls__103d } else { tmp3 = fncls__103 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_218; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_219)); return A_arbace_core__init_A_const_218 }
func A_arbace_core__init_A_Unit114__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(968, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_220; var tmp2 any = A_arbace_core__GT_0_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__104 *jrt.Class = A_arbace_core__GT_0_QMARK__A_fn_class; if fncls__104 == nil { var fncls__104d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_829, false); A_arbace_core__GT_0_QMARK__A_fn_class = fncls__104d; tmp3 = fncls__104d } else { tmp3 = fncls__104 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_220; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_221)); return A_arbace_core__init_A_const_220 }

func A_arbace_core__init_A_Unit115__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(970, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_222; var tmp2 any = A_arbace_core__PLUS__SINGLEQUOTE__A_New(); var tmp3 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_core__PLUS__SINGLEQUOTE__A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_830, true); A_arbace_core__PLUS__SINGLEQUOTE__A_fn_class = fncls__105d; tmp3 = fncls__105d } else { tmp3 = fncls__105 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_222; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_223; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = lang.IFn_Cast(A_arbace_core__init_A_const_216.GetRawRoot__O()).Invoke_O__O(A_arbace_core__init_A_const_225); var tmp10 any = A_arbace_core__init_A_const_171; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_831, tmp8, tmp9, tmp10, A_arbace_core__init_A_const_218.GetRawRoot__O(), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_224, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_222 }











func A_arbace_core__init_A_Unit116__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(982, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_226; var tmp2 any = A_arbace_core__PLUS__A_New(); var tmp3 *jrt.Class; var fncls__106 *jrt.Class = A_arbace_core__PLUS__A_fn_class; if fncls__106 == nil { var fncls__106d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_832, true); A_arbace_core__PLUS__A_fn_class = fncls__106d; tmp3 = fncls__106d } else { tmp3 = fncls__106 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_226; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_227; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = lang.IFn_Cast(A_arbace_core__init_A_const_216.GetRawRoot__O()).Invoke_O_O__O(A_arbace_core__init_A_const_229, A_arbace_core__init_A_const_230); var tmp10 any = A_arbace_core__init_A_const_171; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_833, tmp8, tmp9, tmp10, A_arbace_core__init_A_const_218.GetRawRoot__O(), A_arbace_core__init_A_const_54, Lit_824, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_228, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_226 }











func A_arbace_core__init_A_Unit117__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(994, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_231; var tmp2 any = A_arbace_core__STAR__SINGLEQUOTE__A_New(); var tmp3 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_core__STAR__SINGLEQUOTE__A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_834, true); A_arbace_core__STAR__SINGLEQUOTE__A_fn_class = fncls__107d; tmp3 = fncls__107d } else { tmp3 = fncls__107 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_231; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_232; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = lang.IFn_Cast(A_arbace_core__init_A_const_216.GetRawRoot__O()).Invoke_O__O(A_arbace_core__init_A_const_234); var tmp10 any = A_arbace_core__init_A_const_171; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_835, tmp8, tmp9, tmp10, A_arbace_core__init_A_const_218.GetRawRoot__O(), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_233, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_231 }











func A_arbace_core__init_A_Unit118__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1006, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_235; var tmp2 any = A_arbace_core__STAR__A_New(); var tmp3 *jrt.Class; var fncls__108 *jrt.Class = A_arbace_core__STAR__A_fn_class; if fncls__108 == nil { var fncls__108d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_836, true); A_arbace_core__STAR__A_fn_class = fncls__108d; tmp3 = fncls__108d } else { tmp3 = fncls__108 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_235; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_236; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = lang.IFn_Cast(A_arbace_core__init_A_const_216.GetRawRoot__O()).Invoke_O_O__O(A_arbace_core__init_A_const_238, A_arbace_core__init_A_const_239); var tmp10 any = A_arbace_core__init_A_const_171; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_837, tmp8, tmp9, tmp10, A_arbace_core__init_A_const_218.GetRawRoot__O(), A_arbace_core__init_A_const_54, Lit_824, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_237, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_235 }











func A_arbace_core__init_A_Unit119__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1018, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_240; var tmp2 any = A_arbace_core__SLASH__A_New(); var tmp3 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_core__SLASH__A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_838, true); A_arbace_core__SLASH__A_fn_class = fncls__109d; tmp3 = fncls__109d } else { tmp3 = fncls__109 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_240; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_241; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = lang.IFn_Cast(A_arbace_core__init_A_const_216.GetRawRoot__O()).Invoke_O__O(A_arbace_core__init_A_const_243); var tmp10 any = A_arbace_core__init_A_const_171; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_839, tmp8, tmp9, tmp10, A_arbace_core__init_A_const_218.GetRawRoot__O(), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_242, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_240 }










func A_arbace_core__init_A_Unit120__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1029, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_244; var tmp2 any = A_arbace_core___SINGLEQUOTE__A_New(); var tmp3 *jrt.Class; var fncls__110 *jrt.Class = A_arbace_core___SINGLEQUOTE__A_fn_class; if fncls__110 == nil { var fncls__110d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_840, true); A_arbace_core___SINGLEQUOTE__A_fn_class = fncls__110d; tmp3 = fncls__110d } else { tmp3 = fncls__110 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_244; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_245; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = lang.IFn_Cast(A_arbace_core__init_A_const_216.GetRawRoot__O()).Invoke_O__O(A_arbace_core__init_A_const_247); var tmp10 any = A_arbace_core__init_A_const_171; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_841, tmp8, tmp9, tmp10, A_arbace_core__init_A_const_220.GetRawRoot__O(), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_246, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_244 }











func A_arbace_core__init_A_Unit121__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1041, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_248; var tmp2 any = A_arbace_core___A_New(); var tmp3 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_core___A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_842, true); A_arbace_core___A_fn_class = fncls__111d; tmp3 = fncls__111d } else { tmp3 = fncls__111 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_248; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_249; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = lang.IFn_Cast(A_arbace_core__init_A_const_216.GetRawRoot__O()).Invoke_O_O__O(A_arbace_core__init_A_const_251, A_arbace_core__init_A_const_252); var tmp10 any = A_arbace_core__init_A_const_171; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_843, tmp8, tmp9, tmp10, A_arbace_core__init_A_const_220.GetRawRoot__O(), A_arbace_core__init_A_const_54, Lit_824, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_250, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_248 }











func A_arbace_core__init_A_Unit122__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1053, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_253; var tmp2 any = A_arbace_core__LT__EQ__A_New(); var tmp3 *jrt.Class; var fncls__112 *jrt.Class = A_arbace_core__LT__EQ__A_fn_class; if fncls__112 == nil { var fncls__112d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_844, true); A_arbace_core__LT__EQ__A_fn_class = fncls__112d; tmp3 = fncls__112d } else { tmp3 = fncls__112 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_253; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_254; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core__LT__EQ___inliner__1927000217_A_New(); var tmp10 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_core__LT__EQ___inliner__1927000217_A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_846, false); A_arbace_core__LT__EQ___inliner__1927000217_A_fn_class = fncls__113d; tmp10 = fncls__113d } else { tmp10 = fncls__113 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_845, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_171, A_arbace_core__init_A_const_255, A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_256, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_253 }














func A_arbace_core__init_A_Unit123__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1068, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_257; var tmp2 any = A_arbace_core__GT__A_New(); var tmp3 *jrt.Class; var fncls__114 *jrt.Class = A_arbace_core__GT__A_fn_class; if fncls__114 == nil { var fncls__114d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_847, true); A_arbace_core__GT__A_fn_class = fncls__114d; tmp3 = fncls__114d } else { tmp3 = fncls__114 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_257; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_258; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core__GT___inliner__1927000220_A_New(); var tmp10 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_core__GT___inliner__1927000220_A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_849, false); A_arbace_core__GT___inliner__1927000220_A_fn_class = fncls__115d; tmp10 = fncls__115d } else { tmp10 = fncls__115 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_848, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_171, A_arbace_core__init_A_const_259, A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_260, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_257 }














func A_arbace_core__init_A_Unit124__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1083, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_261; var tmp2 any = A_arbace_core__GT__EQ__A_New(); var tmp3 *jrt.Class; var fncls__116 *jrt.Class = A_arbace_core__GT__EQ__A_fn_class; if fncls__116 == nil { var fncls__116d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_850, true); A_arbace_core__GT__EQ__A_fn_class = fncls__116d; tmp3 = fncls__116d } else { tmp3 = fncls__116 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_261; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_262; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core__GT__EQ___inliner__1927000223_A_New(); var tmp10 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_core__GT__EQ___inliner__1927000223_A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_852, false); A_arbace_core__GT__EQ___inliner__1927000223_A_fn_class = fncls__117d; tmp10 = fncls__117d } else { tmp10 = fncls__117 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_851, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_171, A_arbace_core__init_A_const_263, A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_264, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_261 }














func A_arbace_core__init_A_Unit125__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1098, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_265; var tmp2 any = A_arbace_core__EQ__EQ__A_New(); var tmp3 *jrt.Class; var fncls__118 *jrt.Class = A_arbace_core__EQ__EQ__A_fn_class; if fncls__118 == nil { var fncls__118d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_853, true); A_arbace_core__EQ__EQ__A_fn_class = fncls__118d; tmp3 = fncls__118d } else { tmp3 = fncls__118 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_265; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_266; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core__EQ__EQ___inliner__1927000226_A_New(); var tmp10 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_core__EQ__EQ___inliner__1927000226_A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_855, false); A_arbace_core__EQ__EQ___inliner__1927000226_A_fn_class = fncls__119d; tmp10 = fncls__119d } else { tmp10 = fncls__119 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_854, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_171, A_arbace_core__init_A_const_267, A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_268, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_265 }














func A_arbace_core__init_A_Unit126__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1113, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_269; var tmp2 any = A_arbace_core_max_A_New(); var tmp3 *jrt.Class; var fncls__120 *jrt.Class = A_arbace_core_max_A_fn_class; if fncls__120 == nil { var fncls__120d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_856, true); A_arbace_core_max_A_fn_class = fncls__120d; tmp3 = fncls__120d } else { tmp3 = fncls__120 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_269; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_270; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_54; var tmp9 any = A_arbace_core__init_A_const_171; var tmp10 any = A_arbace_core__init_A_const_218.GetRawRoot__O(); var tmp11 any = A_arbace_core__init_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_857, tmp8, Lit_734, tmp9, tmp10, tmp11, lang.IFn_Cast(A_arbace_core__init_A_const_216.GetRawRoot__O()).Invoke_O__O(A_arbace_core__init_A_const_272), A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_271, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_269 }









func A_arbace_core__init_A_Unit127__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1123, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_273; var tmp2 any = A_arbace_core_min_A_New(); var tmp3 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_core_min_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_858, true); A_arbace_core_min_A_fn_class = fncls__121d; tmp3 = fncls__121d } else { tmp3 = fncls__121 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_273; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_274; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_54; var tmp9 any = A_arbace_core__init_A_const_171; var tmp10 any = A_arbace_core__init_A_const_218.GetRawRoot__O(); var tmp11 any = A_arbace_core__init_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_859, tmp8, Lit_734, tmp9, tmp10, tmp11, lang.IFn_Cast(A_arbace_core__init_A_const_216.GetRawRoot__O()).Invoke_O__O(A_arbace_core__init_A_const_276), A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_275, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_273 }









func A_arbace_core__init_A_Unit128__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1133, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_277; var tmp2 any = A_arbace_core_abs_A_New(); var tmp3 *jrt.Class; var fncls__122 *jrt.Class = A_arbace_core_abs_A_fn_class; if fncls__122 == nil { var fncls__122d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_860, false); A_arbace_core_abs_A_fn_class = fncls__122d; tmp3 = fncls__122d } else { tmp3 = fncls__122 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_277; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_278; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_171; var tmp9 any = A_arbace_core__init_A_const_279; var tmp10 any = A_arbace_core__init_A_const_56; var tmp11 any = A_arbace_core_abs__inliner__1927000231_A_New(); var tmp12 *jrt.Class; var fncls__123 *jrt.Class = A_arbace_core_abs__inliner__1927000231_A_fn_class; if fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_862, false); A_arbace_core_abs__inliner__1927000231_A_fn_class = fncls__123d; tmp12 = fncls__123d } else { tmp12 = fncls__123 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_861, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_core__init_A_const_54, Lit_863, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_280, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_277 }











func A_arbace_core__init_A_Unit129__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1145, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_281; var tmp2 any = A_arbace_core_dec_SINGLEQUOTE__A_New(); var tmp3 *jrt.Class; var fncls__124 *jrt.Class = A_arbace_core_dec_SINGLEQUOTE__A_fn_class; if fncls__124 == nil { var fncls__124d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_864, false); A_arbace_core_dec_SINGLEQUOTE__A_fn_class = fncls__124d; tmp3 = fncls__124d } else { tmp3 = fncls__124 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_281; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_282; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_dec_SINGLEQUOTE___inliner__1927000234_A_New(); var tmp10 *jrt.Class; var fncls__125 *jrt.Class = A_arbace_core_dec_SINGLEQUOTE___inliner__1927000234_A_fn_class; if fncls__125 == nil { var fncls__125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_866, false); A_arbace_core_dec_SINGLEQUOTE___inliner__1927000234_A_fn_class = fncls__125d; tmp10 = fncls__125d } else { tmp10 = fncls__125 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_865, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_283, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_281 }






func A_arbace_core__init_A_Unit130__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1152, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_284; var tmp2 any = A_arbace_core_dec_A_New(); var tmp3 *jrt.Class; var fncls__126 *jrt.Class = A_arbace_core_dec_A_fn_class; if fncls__126 == nil { var fncls__126d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_867, false); A_arbace_core_dec_A_fn_class = fncls__126d; tmp3 = fncls__126d } else { tmp3 = fncls__126 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_284; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_285; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_dec__inliner__1927000237_A_New(); var tmp10 *jrt.Class; var fncls__127 *jrt.Class = A_arbace_core_dec__inliner__1927000237_A_fn_class; if fncls__127 == nil { var fncls__127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_869, false); A_arbace_core_dec__inliner__1927000237_A_fn_class = fncls__127d; tmp10 = fncls__127d } else { tmp10 = fncls__127 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_868, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_824, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_286, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_284 }






func A_arbace_core__init_A_Unit131__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1159, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_287; var tmp2 any = A_arbace_core_unchecked_inc_int_A_New(); var tmp3 *jrt.Class; var fncls__128 *jrt.Class = A_arbace_core_unchecked_inc_int_A_fn_class; if fncls__128 == nil { var fncls__128d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_870, false); A_arbace_core_unchecked_inc_int_A_fn_class = fncls__128d; tmp3 = fncls__128d } else { tmp3 = fncls__128 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_287; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_288; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_unchecked_inc_int__inliner__1927000240_A_New(); var tmp10 *jrt.Class; var fncls__129 *jrt.Class = A_arbace_core_unchecked_inc_int__inliner__1927000240_A_fn_class; if fncls__129 == nil { var fncls__129d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_872, false); A_arbace_core_unchecked_inc_int__inliner__1927000240_A_fn_class = fncls__129d; tmp10 = fncls__129d } else { tmp10 = fncls__129 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_871, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_289, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_287 }






func A_arbace_core__init_A_Unit132__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1166, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_290; var tmp2 any = A_arbace_core_unchecked_inc_A_New(); var tmp3 *jrt.Class; var fncls__130 *jrt.Class = A_arbace_core_unchecked_inc_A_fn_class; if fncls__130 == nil { var fncls__130d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_873, false); A_arbace_core_unchecked_inc_A_fn_class = fncls__130d; tmp3 = fncls__130d } else { tmp3 = fncls__130 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_290; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_291; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_unchecked_inc__inliner__1927000243_A_New(); var tmp10 *jrt.Class; var fncls__131 *jrt.Class = A_arbace_core_unchecked_inc__inliner__1927000243_A_fn_class; if fncls__131 == nil { var fncls__131d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_875, false); A_arbace_core_unchecked_inc__inliner__1927000243_A_fn_class = fncls__131d; tmp10 = fncls__131d } else { tmp10 = fncls__131 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_874, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_292, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_290 }






func A_arbace_core__init_A_Unit133__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1173, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_293; var tmp2 any = A_arbace_core_unchecked_dec_int_A_New(); var tmp3 *jrt.Class; var fncls__132 *jrt.Class = A_arbace_core_unchecked_dec_int_A_fn_class; if fncls__132 == nil { var fncls__132d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_876, false); A_arbace_core_unchecked_dec_int_A_fn_class = fncls__132d; tmp3 = fncls__132d } else { tmp3 = fncls__132 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_293; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_294; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_unchecked_dec_int__inliner__1927000246_A_New(); var tmp10 *jrt.Class; var fncls__133 *jrt.Class = A_arbace_core_unchecked_dec_int__inliner__1927000246_A_fn_class; if fncls__133 == nil { var fncls__133d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_878, false); A_arbace_core_unchecked_dec_int__inliner__1927000246_A_fn_class = fncls__133d; tmp10 = fncls__133d } else { tmp10 = fncls__133 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_877, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_295, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_293 }






func A_arbace_core__init_A_Unit134__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1180, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_296; var tmp2 any = A_arbace_core_unchecked_dec_A_New(); var tmp3 *jrt.Class; var fncls__134 *jrt.Class = A_arbace_core_unchecked_dec_A_fn_class; if fncls__134 == nil { var fncls__134d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_879, false); A_arbace_core_unchecked_dec_A_fn_class = fncls__134d; tmp3 = fncls__134d } else { tmp3 = fncls__134 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_296; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_297; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_unchecked_dec__inliner__1927000249_A_New(); var tmp10 *jrt.Class; var fncls__135 *jrt.Class = A_arbace_core_unchecked_dec__inliner__1927000249_A_fn_class; if fncls__135 == nil { var fncls__135d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_881, false); A_arbace_core_unchecked_dec__inliner__1927000249_A_fn_class = fncls__135d; tmp10 = fncls__135d } else { tmp10 = fncls__135 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_880, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_298, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_296 }






func A_arbace_core__init_A_Unit135__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1187, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_299; var tmp2 any = A_arbace_core_unchecked_negate_int_A_New(); var tmp3 *jrt.Class; var fncls__136 *jrt.Class = A_arbace_core_unchecked_negate_int_A_fn_class; if fncls__136 == nil { var fncls__136d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_882, false); A_arbace_core_unchecked_negate_int_A_fn_class = fncls__136d; tmp3 = fncls__136d } else { tmp3 = fncls__136 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_299; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_300; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_unchecked_negate_int__inliner__1927000252_A_New(); var tmp10 *jrt.Class; var fncls__137 *jrt.Class = A_arbace_core_unchecked_negate_int__inliner__1927000252_A_fn_class; if fncls__137 == nil { var fncls__137d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_884, false); A_arbace_core_unchecked_negate_int__inliner__1927000252_A_fn_class = fncls__137d; tmp10 = fncls__137d } else { tmp10 = fncls__137 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_883, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_301, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_299 }






func A_arbace_core__init_A_Unit136__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1194, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_302; var tmp2 any = A_arbace_core_unchecked_negate_A_New(); var tmp3 *jrt.Class; var fncls__138 *jrt.Class = A_arbace_core_unchecked_negate_A_fn_class; if fncls__138 == nil { var fncls__138d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_885, false); A_arbace_core_unchecked_negate_A_fn_class = fncls__138d; tmp3 = fncls__138d } else { tmp3 = fncls__138 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_302; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_303; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_unchecked_negate__inliner__1927000255_A_New(); var tmp10 *jrt.Class; var fncls__139 *jrt.Class = A_arbace_core_unchecked_negate__inliner__1927000255_A_fn_class; if fncls__139 == nil { var fncls__139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_887, false); A_arbace_core_unchecked_negate__inliner__1927000255_A_fn_class = fncls__139d; tmp10 = fncls__139d } else { tmp10 = fncls__139 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_886, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_304, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_302 }






func A_arbace_core__init_A_Unit137__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1201, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_305; var tmp2 any = A_arbace_core_unchecked_add_int_A_New(); var tmp3 *jrt.Class; var fncls__140 *jrt.Class = A_arbace_core_unchecked_add_int_A_fn_class; if fncls__140 == nil { var fncls__140d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_888, false); A_arbace_core_unchecked_add_int_A_fn_class = fncls__140d; tmp3 = fncls__140d } else { tmp3 = fncls__140 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_305; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_306; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_unchecked_add_int__inliner__1927000258_A_New(); var tmp10 *jrt.Class; var fncls__141 *jrt.Class = A_arbace_core_unchecked_add_int__inliner__1927000258_A_fn_class; if fncls__141 == nil { var fncls__141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_890, false); A_arbace_core_unchecked_add_int__inliner__1927000258_A_fn_class = fncls__141d; tmp10 = fncls__141d } else { tmp10 = fncls__141 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_889, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_307, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_305 }






func A_arbace_core__init_A_Unit138__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1208, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_308; var tmp2 any = A_arbace_core_unchecked_add_A_New(); var tmp3 *jrt.Class; var fncls__142 *jrt.Class = A_arbace_core_unchecked_add_A_fn_class; if fncls__142 == nil { var fncls__142d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_891, false); A_arbace_core_unchecked_add_A_fn_class = fncls__142d; tmp3 = fncls__142d } else { tmp3 = fncls__142 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_308; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_309; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_unchecked_add__inliner__1927000261_A_New(); var tmp10 *jrt.Class; var fncls__143 *jrt.Class = A_arbace_core_unchecked_add__inliner__1927000261_A_fn_class; if fncls__143 == nil { var fncls__143d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_893, false); A_arbace_core_unchecked_add__inliner__1927000261_A_fn_class = fncls__143d; tmp10 = fncls__143d } else { tmp10 = fncls__143 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_892, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_310, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_308 }






func A_arbace_core__init_A_Unit139__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1215, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_311; var tmp2 any = A_arbace_core_unchecked_subtract_int_A_New(); var tmp3 *jrt.Class; var fncls__144 *jrt.Class = A_arbace_core_unchecked_subtract_int_A_fn_class; if fncls__144 == nil { var fncls__144d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_894, false); A_arbace_core_unchecked_subtract_int_A_fn_class = fncls__144d; tmp3 = fncls__144d } else { tmp3 = fncls__144 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_311; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_312; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_unchecked_subtract_int__inliner__1927000264_A_New(); var tmp10 *jrt.Class; var fncls__145 *jrt.Class = A_arbace_core_unchecked_subtract_int__inliner__1927000264_A_fn_class; if fncls__145 == nil { var fncls__145d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_896, false); A_arbace_core_unchecked_subtract_int__inliner__1927000264_A_fn_class = fncls__145d; tmp10 = fncls__145d } else { tmp10 = fncls__145 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_895, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_313, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_311 }






func A_arbace_core__init_A_Unit140__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1222, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_314; var tmp2 any = A_arbace_core_unchecked_subtract_A_New(); var tmp3 *jrt.Class; var fncls__146 *jrt.Class = A_arbace_core_unchecked_subtract_A_fn_class; if fncls__146 == nil { var fncls__146d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_897, false); A_arbace_core_unchecked_subtract_A_fn_class = fncls__146d; tmp3 = fncls__146d } else { tmp3 = fncls__146 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_314; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_315; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_unchecked_subtract__inliner__1927000267_A_New(); var tmp10 *jrt.Class; var fncls__147 *jrt.Class = A_arbace_core_unchecked_subtract__inliner__1927000267_A_fn_class; if fncls__147 == nil { var fncls__147d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_899, false); A_arbace_core_unchecked_subtract__inliner__1927000267_A_fn_class = fncls__147d; tmp10 = fncls__147d } else { tmp10 = fncls__147 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_898, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_316, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_314 }






func A_arbace_core__init_A_Unit141__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1229, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_317; var tmp2 any = A_arbace_core_unchecked_multiply_int_A_New(); var tmp3 *jrt.Class; var fncls__148 *jrt.Class = A_arbace_core_unchecked_multiply_int_A_fn_class; if fncls__148 == nil { var fncls__148d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_900, false); A_arbace_core_unchecked_multiply_int_A_fn_class = fncls__148d; tmp3 = fncls__148d } else { tmp3 = fncls__148 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_317; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_318; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_unchecked_multiply_int__inliner__1927000270_A_New(); var tmp10 *jrt.Class; var fncls__149 *jrt.Class = A_arbace_core_unchecked_multiply_int__inliner__1927000270_A_fn_class; if fncls__149 == nil { var fncls__149d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_902, false); A_arbace_core_unchecked_multiply_int__inliner__1927000270_A_fn_class = fncls__149d; tmp10 = fncls__149d } else { tmp10 = fncls__149 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_901, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_319, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_317 }






func A_arbace_core__init_A_Unit142__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1236, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_320; var tmp2 any = A_arbace_core_unchecked_multiply_A_New(); var tmp3 *jrt.Class; var fncls__150 *jrt.Class = A_arbace_core_unchecked_multiply_A_fn_class; if fncls__150 == nil { var fncls__150d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_903, false); A_arbace_core_unchecked_multiply_A_fn_class = fncls__150d; tmp3 = fncls__150d } else { tmp3 = fncls__150 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_320; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_321; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_unchecked_multiply__inliner__1927000273_A_New(); var tmp10 *jrt.Class; var fncls__151 *jrt.Class = A_arbace_core_unchecked_multiply__inliner__1927000273_A_fn_class; if fncls__151 == nil { var fncls__151d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_905, false); A_arbace_core_unchecked_multiply__inliner__1927000273_A_fn_class = fncls__151d; tmp10 = fncls__151d } else { tmp10 = fncls__151 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_904, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_322, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_320 }






func A_arbace_core__init_A_Unit143__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1243, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_323; var tmp2 any = A_arbace_core_unchecked_divide_int_A_New(); var tmp3 *jrt.Class; var fncls__152 *jrt.Class = A_arbace_core_unchecked_divide_int_A_fn_class; if fncls__152 == nil { var fncls__152d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_906, false); A_arbace_core_unchecked_divide_int_A_fn_class = fncls__152d; tmp3 = fncls__152d } else { tmp3 = fncls__152 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_323; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_324; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_unchecked_divide_int__inliner__1927000276_A_New(); var tmp10 *jrt.Class; var fncls__153 *jrt.Class = A_arbace_core_unchecked_divide_int__inliner__1927000276_A_fn_class; if fncls__153 == nil { var fncls__153d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_908, false); A_arbace_core_unchecked_divide_int__inliner__1927000276_A_fn_class = fncls__153d; tmp10 = fncls__153d } else { tmp10 = fncls__153 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_907, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_325, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_323 }






func A_arbace_core__init_A_Unit144__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1250, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_326; var tmp2 any = A_arbace_core_unchecked_remainder_int_A_New(); var tmp3 *jrt.Class; var fncls__154 *jrt.Class = A_arbace_core_unchecked_remainder_int_A_fn_class; if fncls__154 == nil { var fncls__154d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_909, false); A_arbace_core_unchecked_remainder_int_A_fn_class = fncls__154d; tmp3 = fncls__154d } else { tmp3 = fncls__154 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_326; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_327; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_unchecked_remainder_int__inliner__1927000279_A_New(); var tmp10 *jrt.Class; var fncls__155 *jrt.Class = A_arbace_core_unchecked_remainder_int__inliner__1927000279_A_fn_class; if fncls__155 == nil { var fncls__155d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_911, false); A_arbace_core_unchecked_remainder_int__inliner__1927000279_A_fn_class = fncls__155d; tmp10 = fncls__155d } else { tmp10 = fncls__155 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_910, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_328, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_326 }






func A_arbace_core__init_A_Unit145__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1257, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_329; var tmp2 any = A_arbace_core_pos_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__156 *jrt.Class = A_arbace_core_pos_QMARK__A_fn_class; if fncls__156 == nil { var fncls__156d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_912, false); A_arbace_core_pos_QMARK__A_fn_class = fncls__156d; tmp3 = fncls__156d } else { tmp3 = fncls__156 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_329; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_330; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_pos_QMARK___inliner__1927000282_A_New(); var tmp10 *jrt.Class; var fncls__157 *jrt.Class = A_arbace_core_pos_QMARK___inliner__1927000282_A_fn_class; if fncls__157 == nil { var fncls__157d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_914, false); A_arbace_core_pos_QMARK___inliner__1927000282_A_fn_class = fncls__157d; tmp10 = fncls__157d } else { tmp10 = fncls__157 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_913, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_331, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_329 }






func A_arbace_core__init_A_Unit146__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1264, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_332; var tmp2 any = A_arbace_core_neg_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__158 *jrt.Class = A_arbace_core_neg_QMARK__A_fn_class; if fncls__158 == nil { var fncls__158d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_915, false); A_arbace_core_neg_QMARK__A_fn_class = fncls__158d; tmp3 = fncls__158d } else { tmp3 = fncls__158 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_332; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_333; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_neg_QMARK___inliner__1927000285_A_New(); var tmp10 *jrt.Class; var fncls__159 *jrt.Class = A_arbace_core_neg_QMARK___inliner__1927000285_A_fn_class; if fncls__159 == nil { var fncls__159d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_917, false); A_arbace_core_neg_QMARK___inliner__1927000285_A_fn_class = fncls__159d; tmp10 = fncls__159d } else { tmp10 = fncls__159 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_916, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_334, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_332 }






func A_arbace_core__init_A_Unit147__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1271, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_335; var tmp2 any = A_arbace_core_quot_A_New(); var tmp3 *jrt.Class; var fncls__160 *jrt.Class = A_arbace_core_quot_A_fn_class; if fncls__160 == nil { var fncls__160d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_918, false); A_arbace_core_quot_A_fn_class = fncls__160d; tmp3 = fncls__160d } else { tmp3 = fncls__160 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_335; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_336; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_54; var tmp9 any = A_arbace_core__init_A_const_55; var tmp10 *jrt.Boolean; jrt.Boolean_Init(); tmp10 = jrt.Boolean_TRUE; var tmp11 any = tmp10.Ref(); var tmp12 any = A_arbace_core__init_A_const_56; var tmp13 any = A_arbace_core_quot__inliner__1927000288_A_New(); var tmp14 *jrt.Class; var fncls__161 *jrt.Class = A_arbace_core_quot__inliner__1927000288_A_fn_class; if fncls__161 == nil { var fncls__161d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_920, false); A_arbace_core_quot__inliner__1927000288_A_fn_class = fncls__161d; tmp14 = fncls__161d } else { tmp14 = fncls__161 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_919, tmp8, Lit_734, tmp9, tmp11, tmp12, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil), A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_337, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_335 }







func A_arbace_core__init_A_Unit148__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1279, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_338; var tmp2 any = A_arbace_core_rem_A_New(); var tmp3 *jrt.Class; var fncls__162 *jrt.Class = A_arbace_core_rem_A_fn_class; if fncls__162 == nil { var fncls__162d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_921, false); A_arbace_core_rem_A_fn_class = fncls__162d; tmp3 = fncls__162d } else { tmp3 = fncls__162 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_338; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_339; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_54; var tmp9 any = A_arbace_core__init_A_const_55; var tmp10 *jrt.Boolean; jrt.Boolean_Init(); tmp10 = jrt.Boolean_TRUE; var tmp11 any = tmp10.Ref(); var tmp12 any = A_arbace_core__init_A_const_56; var tmp13 any = A_arbace_core_rem__inliner__1927000291_A_New(); var tmp14 *jrt.Class; var fncls__163 *jrt.Class = A_arbace_core_rem__inliner__1927000291_A_fn_class; if fncls__163 == nil { var fncls__163d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_923, false); A_arbace_core_rem__inliner__1927000291_A_fn_class = fncls__163d; tmp14 = fncls__163d } else { tmp14 = fncls__163 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_922, tmp8, Lit_734, tmp9, tmp11, tmp12, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil), A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_340, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_338 }







func A_arbace_core__init_A_Unit149__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1287, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_341; var tmp2 any = A_arbace_core_rationalize_A_New(); var tmp3 *jrt.Class; var fncls__164 *jrt.Class = A_arbace_core_rationalize_A_fn_class; if fncls__164 == nil { var fncls__164d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_924, false); A_arbace_core_rationalize_A_fn_class = fncls__164d; tmp3 = fncls__164d } else { tmp3 = fncls__164 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_341; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_342)); return A_arbace_core__init_A_const_341 }








func A_arbace_core__init_A_Unit150__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1296, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_343; var tmp2 any = A_arbace_core_bit_not_A_New(); var tmp3 *jrt.Class; var fncls__165 *jrt.Class = A_arbace_core_bit_not_A_fn_class; if fncls__165 == nil { var fncls__165d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_925, false); A_arbace_core_bit_not_A_fn_class = fncls__165d; tmp3 = fncls__165d } else { tmp3 = fncls__165 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_343; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_344; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_bit_not__inliner__1927000295_A_New(); var tmp10 *jrt.Class; var fncls__166 *jrt.Class = A_arbace_core_bit_not__inliner__1927000295_A_fn_class; if fncls__166 == nil { var fncls__166d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_927, false); A_arbace_core_bit_not__inliner__1927000295_A_fn_class = fncls__166d; tmp10 = fncls__166d } else { tmp10 = fncls__166 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_926, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_345, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_343 }





func A_arbace_core__init_A_Unit151__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1302, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_346; var tmp2 any = A_arbace_core_bit_and_A_New(); var tmp3 *jrt.Class; var fncls__167 *jrt.Class = A_arbace_core_bit_and_A_fn_class; if fncls__167 == nil { var fncls__167d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_928, true); A_arbace_core_bit_and_A_fn_class = fncls__167d; tmp3 = fncls__167d } else { tmp3 = fncls__167 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_346; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_347; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = lang.IFn_Cast(A_arbace_core__init_A_const_216.GetRawRoot__O()).Invoke_O__O(A_arbace_core__init_A_const_349); var tmp10 any = A_arbace_core__init_A_const_171; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_929, tmp8, tmp9, tmp10, A_arbace_core__init_A_const_218.GetRawRoot__O(), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_348, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_346 }








func A_arbace_core__init_A_Unit152__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1311, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_350; var tmp2 any = A_arbace_core_bit_or_A_New(); var tmp3 *jrt.Class; var fncls__168 *jrt.Class = A_arbace_core_bit_or_A_fn_class; if fncls__168 == nil { var fncls__168d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_930, true); A_arbace_core_bit_or_A_fn_class = fncls__168d; tmp3 = fncls__168d } else { tmp3 = fncls__168 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_350; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_351; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = lang.IFn_Cast(A_arbace_core__init_A_const_216.GetRawRoot__O()).Invoke_O__O(A_arbace_core__init_A_const_353); var tmp10 any = A_arbace_core__init_A_const_171; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_931, tmp8, tmp9, tmp10, A_arbace_core__init_A_const_218.GetRawRoot__O(), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_352, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_350 }








func A_arbace_core__init_A_Unit153__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1320, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_354; var tmp2 any = A_arbace_core_bit_xor_A_New(); var tmp3 *jrt.Class; var fncls__169 *jrt.Class = A_arbace_core_bit_xor_A_fn_class; if fncls__169 == nil { var fncls__169d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_932, true); A_arbace_core_bit_xor_A_fn_class = fncls__169d; tmp3 = fncls__169d } else { tmp3 = fncls__169 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_354; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_355; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = lang.IFn_Cast(A_arbace_core__init_A_const_216.GetRawRoot__O()).Invoke_O__O(A_arbace_core__init_A_const_357); var tmp10 any = A_arbace_core__init_A_const_171; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_933, tmp8, tmp9, tmp10, A_arbace_core__init_A_const_218.GetRawRoot__O(), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_356, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_354 }








func A_arbace_core__init_A_Unit154__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1329, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_358; var tmp2 any = A_arbace_core_bit_and_not_A_New(); var tmp3 *jrt.Class; var fncls__170 *jrt.Class = A_arbace_core_bit_and_not_A_fn_class; if fncls__170 == nil { var fncls__170d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_934, true); A_arbace_core_bit_and_not_A_fn_class = fncls__170d; tmp3 = fncls__170d } else { tmp3 = fncls__170 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_358; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_359; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = lang.IFn_Cast(A_arbace_core__init_A_const_216.GetRawRoot__O()).Invoke_O__O(A_arbace_core__init_A_const_361); var tmp10 any = A_arbace_core__init_A_const_171; var tmp11 any = A_arbace_core__init_A_const_218.GetRawRoot__O(); var tmp12 any = A_arbace_core__init_A_const_54; var tmp13 any = A_arbace_core__init_A_const_55; var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_935, tmp8, tmp9, tmp10, tmp11, tmp12, Lit_734, tmp13, tmp14.Ref(), A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_360, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_358 }









func A_arbace_core__init_A_Unit155__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1339, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_362; var tmp2 any = A_arbace_core_bit_clear_A_New(); var tmp3 *jrt.Class; var fncls__171 *jrt.Class = A_arbace_core_bit_clear_A_fn_class; if fncls__171 == nil { var fncls__171d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_936, false); A_arbace_core_bit_clear_A_fn_class = fncls__171d; tmp3 = fncls__171d } else { tmp3 = fncls__171 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_362; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_363)); return A_arbace_core__init_A_const_362 }





func A_arbace_core__init_A_Unit156__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1345, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_364; var tmp2 any = A_arbace_core_bit_set_A_New(); var tmp3 *jrt.Class; var fncls__172 *jrt.Class = A_arbace_core_bit_set_A_fn_class; if fncls__172 == nil { var fncls__172d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_937, false); A_arbace_core_bit_set_A_fn_class = fncls__172d; tmp3 = fncls__172d } else { tmp3 = fncls__172 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_364; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_365)); return A_arbace_core__init_A_const_364 }





func A_arbace_core__init_A_Unit157__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1351, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_366; var tmp2 any = A_arbace_core_bit_flip_A_New(); var tmp3 *jrt.Class; var fncls__173 *jrt.Class = A_arbace_core_bit_flip_A_fn_class; if fncls__173 == nil { var fncls__173d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_938, false); A_arbace_core_bit_flip_A_fn_class = fncls__173d; tmp3 = fncls__173d } else { tmp3 = fncls__173 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_366; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_367)); return A_arbace_core__init_A_const_366 }





func A_arbace_core__init_A_Unit158__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1357, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_368; var tmp2 any = A_arbace_core_bit_test_A_New(); var tmp3 *jrt.Class; var fncls__174 *jrt.Class = A_arbace_core_bit_test_A_fn_class; if fncls__174 == nil { var fncls__174d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_939, false); A_arbace_core_bit_test_A_fn_class = fncls__174d; tmp3 = fncls__174d } else { tmp3 = fncls__174 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_368; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_369)); return A_arbace_core__init_A_const_368 }





func A_arbace_core__init_A_Unit159__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1363, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_370; var tmp2 any = A_arbace_core_bit_shift_left_A_New(); var tmp3 *jrt.Class; var fncls__175 *jrt.Class = A_arbace_core_bit_shift_left_A_fn_class; if fncls__175 == nil { var fncls__175d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_940, false); A_arbace_core_bit_shift_left_A_fn_class = fncls__175d; tmp3 = fncls__175d } else { tmp3 = fncls__175 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_370; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_371; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_bit_shift_left__inliner__1927000306_A_New(); var tmp10 *jrt.Class; var fncls__176 *jrt.Class = A_arbace_core_bit_shift_left__inliner__1927000306_A_fn_class; if fncls__176 == nil { var fncls__176d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_942, false); A_arbace_core_bit_shift_left__inliner__1927000306_A_fn_class = fncls__176d; tmp10 = fncls__176d } else { tmp10 = fncls__176 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_941, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_372, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_370 }





func A_arbace_core__init_A_Unit160__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1369, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_373; var tmp2 any = A_arbace_core_bit_shift_right_A_New(); var tmp3 *jrt.Class; var fncls__177 *jrt.Class = A_arbace_core_bit_shift_right_A_fn_class; if fncls__177 == nil { var fncls__177d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_943, false); A_arbace_core_bit_shift_right_A_fn_class = fncls__177d; tmp3 = fncls__177d } else { tmp3 = fncls__177 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_373; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_374; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_bit_shift_right__inliner__1927000309_A_New(); var tmp10 *jrt.Class; var fncls__178 *jrt.Class = A_arbace_core_bit_shift_right__inliner__1927000309_A_fn_class; if fncls__178 == nil { var fncls__178d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_945, false); A_arbace_core_bit_shift_right__inliner__1927000309_A_fn_class = fncls__178d; tmp10 = fncls__178d } else { tmp10 = fncls__178 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_944, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_375, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_373 }





func A_arbace_core__init_A_Unit161__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1375, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_376; var tmp2 any = A_arbace_core_unsigned_bit_shift_right_A_New(); var tmp3 *jrt.Class; var fncls__179 *jrt.Class = A_arbace_core_unsigned_bit_shift_right_A_fn_class; if fncls__179 == nil { var fncls__179d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_946, false); A_arbace_core_unsigned_bit_shift_right_A_fn_class = fncls__179d; tmp3 = fncls__179d } else { tmp3 = fncls__179 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_376; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_377; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_unsigned_bit_shift_right__inliner__1927000312_A_New(); var tmp10 *jrt.Class; var fncls__180 *jrt.Class = A_arbace_core_unsigned_bit_shift_right__inliner__1927000312_A_fn_class; if fncls__180 == nil { var fncls__180d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_948, false); A_arbace_core_unsigned_bit_shift_right__inliner__1927000312_A_fn_class = fncls__180d; tmp10 = fncls__180d } else { tmp10 = fncls__180 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_947, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_949, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_378, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_376 }





func A_arbace_core__init_A_Unit162__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1381, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_379; var tmp2 any = A_arbace_core_integer_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__181 *jrt.Class = A_arbace_core_integer_QMARK__A_fn_class; if fncls__181 == nil { var fncls__181d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_950, false); A_arbace_core_integer_QMARK__A_fn_class = fncls__181d; tmp3 = fncls__181d } else { tmp3 = fncls__181 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_379; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_380)); return A_arbace_core__init_A_const_379 }











func A_arbace_core__init_A_Unit163__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1393, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_381; var tmp2 any = A_arbace_core_even_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__182 *jrt.Class = A_arbace_core_even_QMARK__A_fn_class; if fncls__182 == nil { var fncls__182d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_951, false); A_arbace_core_even_QMARK__A_fn_class = fncls__182d; tmp3 = fncls__182d } else { tmp3 = fncls__182 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_381; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_382)); return A_arbace_core__init_A_const_381 }







func A_arbace_core__init_A_Unit164__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1401, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_383; var tmp2 any = A_arbace_core_odd_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__183 *jrt.Class = A_arbace_core_odd_QMARK__A_fn_class; if fncls__183 == nil { var fncls__183d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_952, false); A_arbace_core_odd_QMARK__A_fn_class = fncls__183d; tmp3 = fncls__183d } else { tmp3 = fncls__183 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_383; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_384)); return A_arbace_core__init_A_const_383 }





func A_arbace_core__init_A_Unit165__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1407, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_385; var tmp2 any = A_arbace_core_int_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__184 *jrt.Class = A_arbace_core_int_QMARK__A_fn_class; if fncls__184 == nil { var fncls__184d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_953, false); A_arbace_core_int_QMARK__A_fn_class = fncls__184d; tmp3 = fncls__184d } else { tmp3 = fncls__184 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_385; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_386)); return A_arbace_core__init_A_const_385 }







func A_arbace_core__init_A_Unit166__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1415, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_387; var tmp2 any = A_arbace_core_pos_int_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__185 *jrt.Class = A_arbace_core_pos_int_QMARK__A_fn_class; if fncls__185 == nil { var fncls__185d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_954, false); A_arbace_core_pos_int_QMARK__A_fn_class = fncls__185d; tmp3 = fncls__185d } else { tmp3 = fncls__185 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_387; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_388)); return A_arbace_core__init_A_const_387 }





func A_arbace_core__init_A_Unit167__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1421, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_389; var tmp2 any = A_arbace_core_neg_int_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__186 *jrt.Class = A_arbace_core_neg_int_QMARK__A_fn_class; if fncls__186 == nil { var fncls__186d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_955, false); A_arbace_core_neg_int_QMARK__A_fn_class = fncls__186d; tmp3 = fncls__186d } else { tmp3 = fncls__186 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_389; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_390)); return A_arbace_core__init_A_const_389 }





func A_arbace_core__init_A_Unit168__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1427, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_391; var tmp2 any = A_arbace_core_nat_int_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__187 *jrt.Class = A_arbace_core_nat_int_QMARK__A_fn_class; if fncls__187 == nil { var fncls__187d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_956, false); A_arbace_core_nat_int_QMARK__A_fn_class = fncls__187d; tmp3 = fncls__187d } else { tmp3 = fncls__187 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_391; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_392)); return A_arbace_core__init_A_const_391 }





func A_arbace_core__init_A_Unit169__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1433, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_393; var tmp2 any = A_arbace_core_double_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__188 *jrt.Class = A_arbace_core_double_QMARK__A_fn_class; if fncls__188 == nil { var fncls__188d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_957, false); A_arbace_core_double_QMARK__A_fn_class = fncls__188d; tmp3 = fncls__188d } else { tmp3 = fncls__188 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_393; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_394)); return A_arbace_core__init_A_const_393 }






func A_arbace_core__init_A_Unit170__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1440, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_395; var tmp2 any = A_arbace_core_complement_A_New(); var tmp3 *jrt.Class; var fncls__189 *jrt.Class = A_arbace_core_complement_A_fn_class; if fncls__189 == nil { var fncls__189d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_958, false); A_arbace_core_complement_A_fn_class = fncls__189d; tmp3 = fncls__189d } else { tmp3 = fncls__189 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_395; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_396)); return A_arbace_core__init_A_const_395 }











func A_arbace_core__init_A_Unit171__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1452, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_397; var tmp2 any = A_arbace_core_constantly_A_New(); var tmp3 *jrt.Class; var fncls__190 *jrt.Class = A_arbace_core_constantly_A_fn_class; if fncls__190 == nil { var fncls__190d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_959, false); A_arbace_core_constantly_A_fn_class = fncls__190d; tmp3 = fncls__190d } else { tmp3 = fncls__190 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_397; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_398)); return A_arbace_core__init_A_const_397 }









func A_arbace_core__init_A_Unit172__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1462, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_399; var tmp2 any = A_arbace_core_identity_A_New(); var tmp3 *jrt.Class; var fncls__191 *jrt.Class = A_arbace_core_identity_A_fn_class; if fncls__191 == nil { var fncls__191d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_960, false); A_arbace_core_identity_A_fn_class = fncls__191d; tmp3 = fncls__191d } else { tmp3 = fncls__191 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_399; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_400)); return A_arbace_core__init_A_const_399 }








func A_arbace_core__init_A_Unit173__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1471, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_401; var tmp2 any = A_arbace_core_peek_A_New(); var tmp3 *jrt.Class; var fncls__192 *jrt.Class = A_arbace_core_peek_A_fn_class; if fncls__192 == nil { var fncls__192d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_961, false); A_arbace_core_peek_A_fn_class = fncls__192d; tmp3 = fncls__192d } else { tmp3 = fncls__192 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_401; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_402)); return A_arbace_core__init_A_const_401 }






func A_arbace_core__init_A_Unit174__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1478, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_403; var tmp2 any = A_arbace_core_pop_A_New(); var tmp3 *jrt.Class; var fncls__193 *jrt.Class = A_arbace_core_pop_A_fn_class; if fncls__193 == nil { var fncls__193d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_962, false); A_arbace_core_pop_A_fn_class = fncls__193d; tmp3 = fncls__193d } else { tmp3 = fncls__193 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_403; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_404)); return A_arbace_core__init_A_const_403 }










func A_arbace_core__init_A_Unit175__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1489, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_405; var tmp2 any = A_arbace_core_map_entry_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__194 *jrt.Class = A_arbace_core_map_entry_QMARK__A_fn_class; if fncls__194 == nil { var fncls__194d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_963, false); A_arbace_core_map_entry_QMARK__A_fn_class = fncls__194d; tmp3 = fncls__194d } else { tmp3 = fncls__194 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_405; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_406)); return A_arbace_core__init_A_const_405 }





func A_arbace_core__init_A_Unit176__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1495, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_407; var tmp2 any = A_arbace_core_contains_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__195 *jrt.Class = A_arbace_core_contains_QMARK__A_fn_class; if fncls__195 == nil { var fncls__195d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_964, false); A_arbace_core_contains_QMARK__A_fn_class = fncls__195d; tmp3 = fncls__195d } else { tmp3 = fncls__195 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_407; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_408)); return A_arbace_core__init_A_const_407 }









func A_arbace_core__init_A_Unit177__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1505, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_409; var tmp2 any = A_arbace_core_get_A_New(); var tmp3 *jrt.Class; var fncls__196 *jrt.Class = A_arbace_core_get_A_fn_class; if fncls__196 == nil { var fncls__196d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_965, false); A_arbace_core_get_A_fn_class = fncls__196d; tmp3 = fncls__196d } else { tmp3 = fncls__196 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_409; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_410; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_get__inliner__1927000334_A_New(); var tmp10 *jrt.Class; var fncls__197 *jrt.Class = A_arbace_core_get__inliner__1927000334_A_fn_class; if fncls__197 == nil { var fncls__197d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_967, true); A_arbace_core_get__inliner__1927000334_A_fn_class = fncls__197d; tmp10 = fncls__197d } else { tmp10 = fncls__197 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_966, tmp8, lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp9, tmp10, nil, 2), A_arbace_core__init_A_const_171, A_arbace_core__init_A_const_411, A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_412, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_409 }










func A_arbace_core__init_A_Unit178__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1516, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_413; var tmp2 any = A_arbace_core_req_BANG__A_New(); var tmp3 *jrt.Class; var fncls__198 *jrt.Class = A_arbace_core_req_BANG__A_fn_class; if fncls__198 == nil { var fncls__198d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_968, false); A_arbace_core_req_BANG__A_fn_class = fncls__198d; tmp3 = fncls__198d } else { tmp3 = fncls__198 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_413; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_414; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_req_BANG___inliner__1927000337_A_New(); var tmp10 *jrt.Class; var fncls__199 *jrt.Class = A_arbace_core_req_BANG___inliner__1927000337_A_fn_class; if fncls__199 == nil { var fncls__199d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_970, false); A_arbace_core_req_BANG___inliner__1927000337_A_fn_class = fncls__199d; tmp10 = fncls__199d } else { tmp10 = fncls__199 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_969, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_171, A_arbace_core__init_A_const_415, A_arbace_core__init_A_const_54, Lit_971, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_416, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_413 }







func A_arbace_core__init_A_Unit179__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1524, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_417; var tmp2 any = A_arbace_core_dissoc_A_New(); var tmp3 *jrt.Class; var fncls__200 *jrt.Class = A_arbace_core_dissoc_A_fn_class; if fncls__200 == nil { var fncls__200d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_972, true); A_arbace_core_dissoc_A_fn_class = fncls__200d; tmp3 = fncls__200d } else { tmp3 = fncls__200 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_417; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_418)); return A_arbace_core__init_A_const_417 }













func A_arbace_core__init_A_Unit180__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1538, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_419; var tmp2 any = A_arbace_core_disj_A_New(); var tmp3 *jrt.Class; var fncls__201 *jrt.Class = A_arbace_core_disj_A_fn_class; if fncls__201 == nil { var fncls__201d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_973, true); A_arbace_core_disj_A_fn_class = fncls__201d; tmp3 = fncls__201d } else { tmp3 = fncls__201 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_419; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_420)); return A_arbace_core__init_A_const_419 }















func A_arbace_core__init_A_Unit181__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1554, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_421; var tmp2 any = A_arbace_core_find_A_New(); var tmp3 *jrt.Class; var fncls__202 *jrt.Class = A_arbace_core_find_A_fn_class; if fncls__202 == nil { var fncls__202d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_974, false); A_arbace_core_find_A_fn_class = fncls__202d; tmp3 = fncls__202d } else { tmp3 = fncls__202 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_421; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_422)); return A_arbace_core__init_A_const_421 }





func A_arbace_core__init_A_Unit182__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1560, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_423; var tmp2 any = A_arbace_core_keys_A_New(); var tmp3 *jrt.Class; var fncls__203 *jrt.Class = A_arbace_core_keys_A_fn_class; if fncls__203 == nil { var fncls__203d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_975, false); A_arbace_core_keys_A_fn_class = fncls__203d; tmp3 = fncls__203d } else { tmp3 = fncls__203 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_423; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_424)); return A_arbace_core__init_A_const_423 }





func A_arbace_core__init_A_Unit183__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1566, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_425; var tmp2 any = A_arbace_core_vals_A_New(); var tmp3 *jrt.Class; var fncls__204 *jrt.Class = A_arbace_core_vals_A_fn_class; if fncls__204 == nil { var fncls__204d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_976, false); A_arbace_core_vals_A_fn_class = fncls__204d; tmp3 = fncls__204d } else { tmp3 = fncls__204 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_425; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_426)); return A_arbace_core__init_A_const_425 }





func A_arbace_core__init_A_Unit184__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1572, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_427; var tmp2 any = A_arbace_core_key_A_New(); var tmp3 *jrt.Class; var fncls__205 *jrt.Class = A_arbace_core_key_A_fn_class; if fncls__205 == nil { var fncls__205d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_977, false); A_arbace_core_key_A_fn_class = fncls__205d; tmp3 = fncls__205d } else { tmp3 = fncls__205 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_427; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_428)); return A_arbace_core__init_A_const_427 }






func A_arbace_core__init_A_Unit185__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1579, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_429; var tmp2 any = A_arbace_core_val_A_New(); var tmp3 *jrt.Class; var fncls__206 *jrt.Class = A_arbace_core_val_A_fn_class; if fncls__206 == nil { var fncls__206d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_978, false); A_arbace_core_val_A_fn_class = fncls__206d; tmp3 = fncls__206d } else { tmp3 = fncls__206 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_429; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_430)); return A_arbace_core__init_A_const_429 }






func A_arbace_core__init_A_Unit186__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1586, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_431; var tmp2 any = A_arbace_core_rseq_A_New(); var tmp3 *jrt.Class; var fncls__207 *jrt.Class = A_arbace_core_rseq_A_fn_class; if fncls__207 == nil { var fncls__207d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_979, false); A_arbace_core_rseq_A_fn_class = fncls__207d; tmp3 = fncls__207d } else { tmp3 = fncls__207 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_431; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_432)); return A_arbace_core__init_A_const_431 }







func A_arbace_core__init_A_Unit187__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1594, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_433; var tmp2 any = A_arbace_core_name_A_New(); var tmp3 *jrt.Class; var fncls__208 *jrt.Class = A_arbace_core_name_A_fn_class; if fncls__208 == nil { var fncls__208d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_980, false); A_arbace_core_name_A_fn_class = fncls__208d; tmp3 = fncls__208d } else { tmp3 = fncls__208 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_433; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_434)); return A_arbace_core__init_A_const_433 }







func A_arbace_core__init_A_Unit188__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1602, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_435; var tmp2 any = A_arbace_core_namespace_A_New(); var tmp3 *jrt.Class; var fncls__209 *jrt.Class = A_arbace_core_namespace_A_fn_class; if fncls__209 == nil { var fncls__209d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_981, false); A_arbace_core_namespace_A_fn_class = fncls__209d; tmp3 = fncls__209d } else { tmp3 = fncls__209 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_435; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_436)); return A_arbace_core__init_A_const_435 }







func A_arbace_core__init_A_Unit189__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1610, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_437; var tmp2 any = A_arbace_core_boolean_A_New(); var tmp3 *jrt.Class; var fncls__210 *jrt.Class = A_arbace_core_boolean_A_fn_class; if fncls__210 == nil { var fncls__210d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_982, false); A_arbace_core_boolean_A_fn_class = fncls__210d; tmp3 = fncls__210d } else { tmp3 = fncls__210 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_437; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_438; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_boolean__inliner__1927000350_A_New(); var tmp10 *jrt.Class; var fncls__211 *jrt.Class = A_arbace_core_boolean__inliner__1927000350_A_fn_class; if fncls__211 == nil { var fncls__211d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_984, false); A_arbace_core_boolean__inliner__1927000350_A_fn_class = fncls__211d; tmp10 = fncls__211d } else { tmp10 = fncls__211 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_983, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_439, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_437 }






func A_arbace_core__init_A_Unit190__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1617, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_440; var tmp2 any = A_arbace_core_ident_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__212 *jrt.Class = A_arbace_core_ident_QMARK__A_fn_class; if fncls__212 == nil { var fncls__212d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_985, false); A_arbace_core_ident_QMARK__A_fn_class = fncls__212d; tmp3 = fncls__212d } else { tmp3 = fncls__212 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_440; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_441)); return A_arbace_core__init_A_const_440 }




func A_arbace_core__init_A_Unit191__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1622, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_442; var tmp2 any = A_arbace_core_simple_ident_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__213 *jrt.Class = A_arbace_core_simple_ident_QMARK__A_fn_class; if fncls__213 == nil { var fncls__213d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_986, false); A_arbace_core_simple_ident_QMARK__A_fn_class = fncls__213d; tmp3 = fncls__213d } else { tmp3 = fncls__213 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_442; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_443)); return A_arbace_core__init_A_const_442 }




func A_arbace_core__init_A_Unit192__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1627, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_444; var tmp2 any = A_arbace_core_qualified_ident_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__214 *jrt.Class = A_arbace_core_qualified_ident_QMARK__A_fn_class; if fncls__214 == nil { var fncls__214d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_987, false); A_arbace_core_qualified_ident_QMARK__A_fn_class = fncls__214d; tmp3 = fncls__214d } else { tmp3 = fncls__214 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_444; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_445)); return A_arbace_core__init_A_const_444 }




func A_arbace_core__init_A_Unit193__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1632, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_446; var tmp2 any = A_arbace_core_simple_symbol_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__215 *jrt.Class = A_arbace_core_simple_symbol_QMARK__A_fn_class; if fncls__215 == nil { var fncls__215d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_988, false); A_arbace_core_simple_symbol_QMARK__A_fn_class = fncls__215d; tmp3 = fncls__215d } else { tmp3 = fncls__215 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_446; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_447)); return A_arbace_core__init_A_const_446 }




func A_arbace_core__init_A_Unit194__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1637, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_448; var tmp2 any = A_arbace_core_qualified_symbol_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__216 *jrt.Class = A_arbace_core_qualified_symbol_QMARK__A_fn_class; if fncls__216 == nil { var fncls__216d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_989, false); A_arbace_core_qualified_symbol_QMARK__A_fn_class = fncls__216d; tmp3 = fncls__216d } else { tmp3 = fncls__216 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_448; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_449)); return A_arbace_core__init_A_const_448 }




func A_arbace_core__init_A_Unit195__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1642, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_450; var tmp2 any = A_arbace_core_simple_keyword_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__217 *jrt.Class = A_arbace_core_simple_keyword_QMARK__A_fn_class; if fncls__217 == nil { var fncls__217d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_990, false); A_arbace_core_simple_keyword_QMARK__A_fn_class = fncls__217d; tmp3 = fncls__217d } else { tmp3 = fncls__217 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_450; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_451)); return A_arbace_core__init_A_const_450 }




func A_arbace_core__init_A_Unit196__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1647, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_452; var tmp2 any = A_arbace_core_qualified_keyword_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__218 *jrt.Class = A_arbace_core_qualified_keyword_QMARK__A_fn_class; if fncls__218 == nil { var fncls__218d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_991, false); A_arbace_core_qualified_keyword_QMARK__A_fn_class = fncls__218d; tmp3 = fncls__218d } else { tmp3 = fncls__218 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_452; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_453)); return A_arbace_core__init_A_const_452 }




func A_arbace_core__init_A_Unit197__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1652, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_454; var tmp2 any = A_arbace_core_locking_A_New(); var tmp3 *jrt.Class; var fncls__219 *jrt.Class = A_arbace_core_locking_A_fn_class; if fncls__219 == nil { var fncls__219d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_992, true); A_arbace_core_locking_A_fn_class = fncls__219d; tmp3 = fncls__219d } else { tmp3 = fncls__219 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_454; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_455)); return A_arbace_core__init_A_const_454 }
//line :1652:1
func A_arbace_core__init_A_Unit198__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1652, 1); A_arbace_core__init_A_const_454.SetMacro__V(); return nil }
//line :1652:1
func A_arbace_core__init_A_Unit199__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1652, 1); return A_arbace_core__init_A_const_454 }













func A_arbace_core__init_A_Unit200__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1666, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_456; var tmp2 any = A_arbace_core__DOT__DOT__A_New(); var tmp3 *jrt.Class; var fncls__220 *jrt.Class = A_arbace_core__DOT__DOT__A_fn_class; if fncls__220 == nil { var fncls__220d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_993, true); A_arbace_core__DOT__DOT__A_fn_class = fncls__220d; tmp3 = fncls__220d } else { tmp3 = fncls__220 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 4)); var tmp4 *lang.Var = A_arbace_core__init_A_const_456; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_457)); return A_arbace_core__init_A_const_456 }
//line :1666:1
func A_arbace_core__init_A_Unit201__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1666, 1); A_arbace_core__init_A_const_456.SetMacro__V(); return nil }
//line :1666:1
func A_arbace_core__init_A_Unit202__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1666, 1); return A_arbace_core__init_A_const_456 }

















func A_arbace_core__init_A_Unit203__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1684, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_458; var tmp2 any = A_arbace_core___GT__A_New(); var tmp3 *jrt.Class; var fncls__221 *jrt.Class = A_arbace_core___GT__A_fn_class; if fncls__221 == nil { var fncls__221d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_994, true); A_arbace_core___GT__A_fn_class = fncls__221d; tmp3 = fncls__221d } else { tmp3 = fncls__221 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_458; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_459)); return A_arbace_core__init_A_const_458 }
//line :1684:1
func A_arbace_core__init_A_Unit204__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1684, 1); A_arbace_core__init_A_const_458.SetMacro__V(); return nil }
//line :1684:1
func A_arbace_core__init_A_Unit205__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1684, 1); return A_arbace_core__init_A_const_458 }















func A_arbace_core__init_A_Unit206__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1700, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_460; var tmp2 any = A_arbace_core___GT__GT__A_New(); var tmp3 *jrt.Class; var fncls__222 *jrt.Class = A_arbace_core___GT__GT__A_fn_class; if fncls__222 == nil { var fncls__222d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_995, true); A_arbace_core___GT__GT__A_fn_class = fncls__222d; tmp3 = fncls__222d } else { tmp3 = fncls__222 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_460; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_461)); return A_arbace_core__init_A_const_460 }
//line :1700:1
func A_arbace_core__init_A_Unit207__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1700, 1); A_arbace_core__init_A_const_460.SetMacro__V(); return nil }
//line :1700:1
func A_arbace_core__init_A_Unit208__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1700, 1); return A_arbace_core__init_A_const_460 }















func A_arbace_core__init_A_Unit209__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1716, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_462; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_463)); return A_arbace_core__init_A_const_462 }

func A_arbace_core__init_A_Unit210__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1718, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_464; var tmp2 any = A_arbace_core_check_valid_options_A_New(); var tmp3 *jrt.Class; var fncls__223 *jrt.Class = A_arbace_core_check_valid_options_A_fn_class; if fncls__223 == nil { var fncls__223d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_996, true); A_arbace_core_check_valid_options_A_fn_class = fncls__223d; tmp3 = fncls__223d } else { tmp3 = fncls__223 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_core__init_A_const_464; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_465)); return A_arbace_core__init_A_const_464 }











func A_arbace_core__init_A_Unit211__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1730, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_466; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_467)); return A_arbace_core__init_A_const_466 }

func A_arbace_core__init_A_Unit212__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1732, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_468; var tmp2 any = A_arbace_core_defmulti_A_New(); var tmp3 *jrt.Class; var fncls__224 *jrt.Class = A_arbace_core_defmulti_A_fn_class; if fncls__224 == nil { var fncls__224d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_997, true); A_arbace_core_defmulti_A_fn_class = fncls__224d; tmp3 = fncls__224d } else { tmp3 = fncls__224 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_468; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_469)); return A_arbace_core__init_A_const_468 }
//line :1732:1
func A_arbace_core__init_A_Unit213__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1732, 1); A_arbace_core__init_A_const_468.SetMacro__V(); return nil }
//line :1732:1
func A_arbace_core__init_A_Unit214__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1732, 1); return A_arbace_core__init_A_const_468 }

























































func A_arbace_core__init_A_Unit215__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1790, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_470; var tmp2 any = A_arbace_core_defmethod_A_New(); var tmp3 *jrt.Class; var fncls__225 *jrt.Class = A_arbace_core_defmethod_A_fn_class; if fncls__225 == nil { var fncls__225d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_998, true); A_arbace_core_defmethod_A_fn_class = fncls__225d; tmp3 = fncls__225d } else { tmp3 = fncls__225 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 4)); var tmp4 *lang.Var = A_arbace_core__init_A_const_470; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_471)); return A_arbace_core__init_A_const_470 }
//line :1790:1
func A_arbace_core__init_A_Unit216__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1790, 1); A_arbace_core__init_A_const_470.SetMacro__V(); return nil }
//line :1790:1
func A_arbace_core__init_A_Unit217__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1790, 1); return A_arbace_core__init_A_const_470 }





func A_arbace_core__init_A_Unit218__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1796, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_472; var tmp2 any = A_arbace_core_remove_all_methods_A_New(); var tmp3 *jrt.Class; var fncls__226 *jrt.Class = A_arbace_core_remove_all_methods_A_fn_class; if fncls__226 == nil { var fncls__226d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_999, false); A_arbace_core_remove_all_methods_A_fn_class = fncls__226d; tmp3 = fncls__226d } else { tmp3 = fncls__226 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_472; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_473)); return A_arbace_core__init_A_const_472 }






func A_arbace_core__init_A_Unit219__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1803, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_474; var tmp2 any = A_arbace_core_remove_method_A_New(); var tmp3 *jrt.Class; var fncls__227 *jrt.Class = A_arbace_core_remove_method_A_fn_class; if fncls__227 == nil { var fncls__227d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1000, false); A_arbace_core_remove_method_A_fn_class = fncls__227d; tmp3 = fncls__227d } else { tmp3 = fncls__227 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_474; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_475)); return A_arbace_core__init_A_const_474 }






func A_arbace_core__init_A_Unit220__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1810, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_476; var tmp2 any = A_arbace_core_prefer_method_A_New(); var tmp3 *jrt.Class; var fncls__228 *jrt.Class = A_arbace_core_prefer_method_A_fn_class; if fncls__228 == nil { var fncls__228d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1001, false); A_arbace_core_prefer_method_A_fn_class = fncls__228d; tmp3 = fncls__228d } else { tmp3 = fncls__228 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_476; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_477)); return A_arbace_core__init_A_const_476 }







func A_arbace_core__init_A_Unit221__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1818, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_478; var tmp2 any = A_arbace_core_methods_A_New(); var tmp3 *jrt.Class; var fncls__229 *jrt.Class = A_arbace_core_methods_A_fn_class; if fncls__229 == nil { var fncls__229d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1002, false); A_arbace_core_methods_A_fn_class = fncls__229d; tmp3 = fncls__229d } else { tmp3 = fncls__229 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_478; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_479)); return A_arbace_core__init_A_const_478 }





func A_arbace_core__init_A_Unit222__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1824, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_480; var tmp2 any = A_arbace_core_get_method_A_New(); var tmp3 *jrt.Class; var fncls__230 *jrt.Class = A_arbace_core_get_method_A_fn_class; if fncls__230 == nil { var fncls__230d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1003, false); A_arbace_core_get_method_A_fn_class = fncls__230d; tmp3 = fncls__230d } else { tmp3 = fncls__230 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_480; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_481)); return A_arbace_core__init_A_const_480 }






func A_arbace_core__init_A_Unit223__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1831, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_482; var tmp2 any = A_arbace_core_prefers_A_New(); var tmp3 *jrt.Class; var fncls__231 *jrt.Class = A_arbace_core_prefers_A_fn_class; if fncls__231 == nil { var fncls__231d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1004, false); A_arbace_core_prefers_A_fn_class = fncls__231d; tmp3 = fncls__231d } else { tmp3 = fncls__231 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_482; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_483)); return A_arbace_core__init_A_const_482 }







func A_arbace_core__init_A_Unit224__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1839, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_484; var tmp2 any = A_arbace_core_assert_args_A_New(); var tmp3 *jrt.Class; var fncls__232 *jrt.Class = A_arbace_core_assert_args_A_fn_class; if fncls__232 == nil { var fncls__232d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1005, true); A_arbace_core_assert_args_A_fn_class = fncls__232d; tmp3 = fncls__232d } else { tmp3 = fncls__232 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_484; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_485)); return A_arbace_core__init_A_const_484 }
//line :1839:1
func A_arbace_core__init_A_Unit225__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1839, 1); A_arbace_core__init_A_const_484.SetMacro__V(); return nil }
//line :1839:1
func A_arbace_core__init_A_Unit226__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1839, 1); return A_arbace_core__init_A_const_484 }








func A_arbace_core__init_A_Unit227__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1848, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_486; var tmp2 any = A_arbace_core_if_let_A_New(); var tmp3 *jrt.Class; var fncls__233 *jrt.Class = A_arbace_core_if_let_A_fn_class; if fncls__233 == nil { var fncls__233d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1006, true); A_arbace_core_if_let_A_fn_class = fncls__233d; tmp3 = fncls__233d } else { tmp3 = fncls__233 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 5)); var tmp4 *lang.Var = A_arbace_core__init_A_const_486; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_487)); return A_arbace_core__init_A_const_486 }
//line :1848:1
func A_arbace_core__init_A_Unit228__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1848, 1); A_arbace_core__init_A_const_486.SetMacro__V(); return nil }
//line :1848:1
func A_arbace_core__init_A_Unit229__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1848, 1); return A_arbace_core__init_A_const_486 }



















func A_arbace_core__init_A_Unit230__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1868, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_488; var tmp2 any = A_arbace_core_when_let_A_New(); var tmp3 *jrt.Class; var fncls__234 *jrt.Class = A_arbace_core_when_let_A_fn_class; if fncls__234 == nil { var fncls__234d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1007, true); A_arbace_core_when_let_A_fn_class = fncls__234d; tmp3 = fncls__234d } else { tmp3 = fncls__234 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_488; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_489)); return A_arbace_core__init_A_const_488 }
//line :1868:1
func A_arbace_core__init_A_Unit231__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1868, 1); A_arbace_core__init_A_const_488.SetMacro__V(); return nil }
//line :1868:1
func A_arbace_core__init_A_Unit232__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1868, 1); return A_arbace_core__init_A_const_488 }














func A_arbace_core__init_A_Unit233__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1883, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_490; var tmp2 any = A_arbace_core_if_some_A_New(); var tmp3 *jrt.Class; var fncls__235 *jrt.Class = A_arbace_core_if_some_A_fn_class; if fncls__235 == nil { var fncls__235d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1008, true); A_arbace_core_if_some_A_fn_class = fncls__235d; tmp3 = fncls__235d } else { tmp3 = fncls__235 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 5)); var tmp4 *lang.Var = A_arbace_core__init_A_const_490; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_491)); return A_arbace_core__init_A_const_490 }
//line :1883:1
func A_arbace_core__init_A_Unit234__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1883, 1); A_arbace_core__init_A_const_490.SetMacro__V(); return nil }
//line :1883:1
func A_arbace_core__init_A_Unit235__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1883, 1); return A_arbace_core__init_A_const_490 }



















func A_arbace_core__init_A_Unit236__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1903, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_492; var tmp2 any = A_arbace_core_when_some_A_New(); var tmp3 *jrt.Class; var fncls__236 *jrt.Class = A_arbace_core_when_some_A_fn_class; if fncls__236 == nil { var fncls__236d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1009, true); A_arbace_core_when_some_A_fn_class = fncls__236d; tmp3 = fncls__236d } else { tmp3 = fncls__236 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_492; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_493)); return A_arbace_core__init_A_const_492 }
//line :1903:1
func A_arbace_core__init_A_Unit237__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1903, 1); A_arbace_core__init_A_const_492.SetMacro__V(); return nil }
//line :1903:1
func A_arbace_core__init_A_Unit238__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1903, 1); return A_arbace_core__init_A_const_492 }
















func A_arbace_core__init_A_Unit239__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1920, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_494; var tmp2 any = A_arbace_core_push_thread_bindings_A_New(); var tmp3 *jrt.Class; var fncls__237 *jrt.Class = A_arbace_core_push_thread_bindings_A_fn_class; if fncls__237 == nil { var fncls__237d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1010, false); A_arbace_core_push_thread_bindings_A_fn_class = fncls__237d; tmp3 = fncls__237d } else { tmp3 = fncls__237 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_494; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_495)); return A_arbace_core__init_A_const_494 }

















func A_arbace_core__init_A_Unit240__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1938, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_496; var tmp2 any = A_arbace_core_pop_thread_bindings_A_New(); var tmp3 *jrt.Class; var fncls__238 *jrt.Class = A_arbace_core_pop_thread_bindings_A_fn_class; if fncls__238 == nil { var fncls__238d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1011, false); A_arbace_core_pop_thread_bindings_A_fn_class = fncls__238d; tmp3 = fncls__238d } else { tmp3 = fncls__238 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_496; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_497)); return A_arbace_core__init_A_const_496 }







func A_arbace_core__init_A_Unit241__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1946, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_498; var tmp2 any = A_arbace_core_get_thread_bindings_A_New(); var tmp3 *jrt.Class; var fncls__239 *jrt.Class = A_arbace_core_get_thread_bindings_A_fn_class; if fncls__239 == nil { var fncls__239d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1012, false); A_arbace_core_get_thread_bindings_A_fn_class = fncls__239d; tmp3 = fncls__239d } else { tmp3 = fncls__239 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_498; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_499)); return A_arbace_core__init_A_const_498 }







func A_arbace_core__init_A_Unit242__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1954, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_500; var tmp2 any = A_arbace_core_binding_A_New(); var tmp3 *jrt.Class; var fncls__240 *jrt.Class = A_arbace_core_binding_A_fn_class; if fncls__240 == nil { var fncls__240d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1013, true); A_arbace_core_binding_A_fn_class = fncls__240d; tmp3 = fncls__240d } else { tmp3 = fncls__240 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_500; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_501)); return A_arbace_core__init_A_const_500 }
//line :1954:1
func A_arbace_core__init_A_Unit243__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1954, 1); A_arbace_core__init_A_const_500.SetMacro__V(); return nil }
//line :1954:1
func A_arbace_core__init_A_Unit244__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1954, 1); return A_arbace_core__init_A_const_500 }

























func A_arbace_core__init_A_Unit245__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1980, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_502; var tmp2 any = A_arbace_core_with_bindings_STAR__A_New(); var tmp3 *jrt.Class; var fncls__241 *jrt.Class = A_arbace_core_with_bindings_STAR__A_fn_class; if fncls__241 == nil { var fncls__241d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1014, true); A_arbace_core_with_bindings_STAR__A_fn_class = fncls__241d; tmp3 = fncls__241d } else { tmp3 = fncls__241 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_502; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_503)); return A_arbace_core__init_A_const_502 }












func A_arbace_core__init_A_Unit246__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1993, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_504; var tmp2 any = A_arbace_core_with_bindings_A_New(); var tmp3 *jrt.Class; var fncls__242 *jrt.Class = A_arbace_core_with_bindings_A_fn_class; if fncls__242 == nil { var fncls__242d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1015, true); A_arbace_core_with_bindings_A_fn_class = fncls__242d; tmp3 = fncls__242d } else { tmp3 = fncls__242 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_504; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_505)); return A_arbace_core__init_A_const_504 }
//line :1993:1
func A_arbace_core__init_A_Unit247__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1993, 1); A_arbace_core__init_A_const_504.SetMacro__V(); return nil }
//line :1993:1
func A_arbace_core__init_A_Unit248__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1993, 1); return A_arbace_core__init_A_const_504 }







func A_arbace_core__init_A_Unit249__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2001, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_506; var tmp2 any = A_arbace_core_bound_fn_STAR__A_New(); var tmp3 *jrt.Class; var fncls__243 *jrt.Class = A_arbace_core_bound_fn_STAR__A_fn_class; if fncls__243 == nil { var fncls__243d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1016, false); A_arbace_core_bound_fn_STAR__A_fn_class = fncls__243d; tmp3 = fncls__243d } else { tmp3 = fncls__243 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_506; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_507)); return A_arbace_core__init_A_const_506 }











func A_arbace_core__init_A_Unit250__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2013, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_508; var tmp2 any = A_arbace_core_bound_fn_A_New(); var tmp3 *jrt.Class; var fncls__244 *jrt.Class = A_arbace_core_bound_fn_A_fn_class; if fncls__244 == nil { var fncls__244d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1017, true); A_arbace_core_bound_fn_A_fn_class = fncls__244d; tmp3 = fncls__244d } else { tmp3 = fncls__244 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_508; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_509)); return A_arbace_core__init_A_const_508 }
//line :2013:1
func A_arbace_core__init_A_Unit251__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2013, 1); A_arbace_core__init_A_const_508.SetMacro__V(); return nil }
//line :2013:1
func A_arbace_core__init_A_Unit252__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2013, 1); return A_arbace_core__init_A_const_508 }








func A_arbace_core__init_A_Unit253__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2022, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_510; var tmp2 any = A_arbace_core_find_var_A_New(); var tmp3 *jrt.Class; var fncls__245 *jrt.Class = A_arbace_core_find_var_A_fn_class; if fncls__245 == nil { var fncls__245d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1018, false); A_arbace_core_find_var_A_fn_class = fncls__245d; tmp3 = fncls__245d } else { tmp3 = fncls__245 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_510; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_511)); return A_arbace_core__init_A_const_510 }






func A_arbace_core__init_A_Unit254__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2029, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_512; var tmp2 any = A_arbace_core_binding_conveyor_fn_A_New(); var tmp3 *jrt.Class; var fncls__246 *jrt.Class = A_arbace_core_binding_conveyor_fn_A_fn_class; if fncls__246 == nil { var fncls__246d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1019, false); A_arbace_core_binding_conveyor_fn_A_fn_class = fncls__246d; tmp3 = fncls__246d } else { tmp3 = fncls__246 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_512; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_513)); return A_arbace_core__init_A_const_512 }






















func A_arbace_core__init_A_Unit255__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2052, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_514; var tmp2 any = A_arbace_core_setup_reference_A_New(); var tmp3 *jrt.Class; var fncls__247 *jrt.Class = A_arbace_core_setup_reference_A_fn_class; if fncls__247 == nil { var fncls__247d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1020, false); A_arbace_core_setup_reference_A_fn_class = fncls__247d; tmp3 = fncls__247d } else { tmp3 = fncls__247 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_514; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_515)); return A_arbace_core__init_A_const_514 }








func A_arbace_core__init_A_Unit256__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2061, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_516; var tmp2 any = A_arbace_core_agent_A_New(); var tmp3 *jrt.Class; var fncls__248 *jrt.Class = A_arbace_core_agent_A_fn_class; if fncls__248 == nil { var fncls__248d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1021, true); A_arbace_core_agent_A_fn_class = fncls__248d; tmp3 = fncls__248d } else { tmp3 = fncls__248 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_core__init_A_const_516; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_517)); return A_arbace_core__init_A_const_516 }


































func A_arbace_core__init_A_Unit257__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2096, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_518; var tmp2 any = A_arbace_core_set_agent_send_executor_BANG__A_New(); var tmp3 *jrt.Class; var fncls__249 *jrt.Class = A_arbace_core_set_agent_send_executor_BANG__A_fn_class; if fncls__249 == nil { var fncls__249d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1022, false); A_arbace_core_set_agent_send_executor_BANG__A_fn_class = fncls__249d; tmp3 = fncls__249d } else { tmp3 = fncls__249 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_518; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_519)); return A_arbace_core__init_A_const_518 }





func A_arbace_core__init_A_Unit258__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2102, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_520; var tmp2 any = A_arbace_core_set_agent_send_off_executor_BANG__A_New(); var tmp3 *jrt.Class; var fncls__250 *jrt.Class = A_arbace_core_set_agent_send_off_executor_BANG__A_fn_class; if fncls__250 == nil { var fncls__250d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1023, false); A_arbace_core_set_agent_send_off_executor_BANG__A_fn_class = fncls__250d; tmp3 = fncls__250d } else { tmp3 = fncls__250 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_520; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_521)); return A_arbace_core__init_A_const_520 }





func A_arbace_core__init_A_Unit259__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2108, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_522; var tmp2 any = A_arbace_core_send_via_A_New(); var tmp3 *jrt.Class; var fncls__251 *jrt.Class = A_arbace_core_send_via_A_fn_class; if fncls__251 == nil { var fncls__251d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1024, true); A_arbace_core_send_via_A_fn_class = fncls__251d; tmp3 = fncls__251d } else { tmp3 = fncls__251 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_522; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_523)); return A_arbace_core__init_A_const_522 }









func A_arbace_core__init_A_Unit260__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2118, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_524; var tmp2 any = A_arbace_core_send_A_New(); var tmp3 *jrt.Class; var fncls__252 *jrt.Class = A_arbace_core_send_A_fn_class; if fncls__252 == nil { var fncls__252d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1025, true); A_arbace_core_send_A_fn_class = fncls__252d; tmp3 = fncls__252d } else { tmp3 = fncls__252 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_524; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_525)); return A_arbace_core__init_A_const_524 }










func A_arbace_core__init_A_Unit261__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2129, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_526; var tmp2 any = A_arbace_core_send_off_A_New(); var tmp3 *jrt.Class; var fncls__253 *jrt.Class = A_arbace_core_send_off_A_fn_class; if fncls__253 == nil { var fncls__253d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1026, true); A_arbace_core_send_off_A_fn_class = fncls__253d; tmp3 = fncls__253d } else { tmp3 = fncls__253 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_526; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_527)); return A_arbace_core__init_A_const_526 }










func A_arbace_core__init_A_Unit262__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2140, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_528; var tmp2 any = A_arbace_core_release_pending_sends_A_New(); var tmp3 *jrt.Class; var fncls__254 *jrt.Class = A_arbace_core_release_pending_sends_A_fn_class; if fncls__254 == nil { var fncls__254d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1027, false); A_arbace_core_release_pending_sends_A_fn_class = fncls__254d; tmp3 = fncls__254d } else { tmp3 = fncls__254 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_528; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_529)); return A_arbace_core__init_A_const_528 }










func A_arbace_core__init_A_Unit263__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2151, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_530; var tmp2 any = A_arbace_core_add_watch_A_New(); var tmp3 *jrt.Class; var fncls__255 *jrt.Class = A_arbace_core_add_watch_A_fn_class; if fncls__255 == nil { var fncls__255d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1028, false); A_arbace_core_add_watch_A_fn_class = fncls__255d; tmp3 = fncls__255d } else { tmp3 = fncls__255 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_530; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_531)); return A_arbace_core__init_A_const_530 }

















func A_arbace_core__init_A_Unit264__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2169, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_532; var tmp2 any = A_arbace_core_remove_watch_A_New(); var tmp3 *jrt.Class; var fncls__256 *jrt.Class = A_arbace_core_remove_watch_A_fn_class; if fncls__256 == nil { var fncls__256d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1029, false); A_arbace_core_remove_watch_A_fn_class = fncls__256d; tmp3 = fncls__256d } else { tmp3 = fncls__256 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_532; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_533)); return A_arbace_core__init_A_const_532 }






func A_arbace_core__init_A_Unit265__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2176, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_534; var tmp2 any = A_arbace_core_agent_error_A_New(); var tmp3 *jrt.Class; var fncls__257 *jrt.Class = A_arbace_core_agent_error_A_fn_class; if fncls__257 == nil { var fncls__257d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1030, false); A_arbace_core_agent_error_A_fn_class = fncls__257d; tmp3 = fncls__257d } else { tmp3 = fncls__257 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_534; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_535)); return A_arbace_core__init_A_const_534 }







func A_arbace_core__init_A_Unit266__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2184, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_536; var tmp2 any = A_arbace_core_restart_agent_A_New(); var tmp3 *jrt.Class; var fncls__258 *jrt.Class = A_arbace_core_restart_agent_A_fn_class; if fncls__258 == nil { var fncls__258d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1031, true); A_arbace_core_restart_agent_A_fn_class = fncls__258d; tmp3 = fncls__258d } else { tmp3 = fncls__258 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_536; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_537)); return A_arbace_core__init_A_const_536 }
















func A_arbace_core__init_A_Unit267__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2201, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_538; var tmp2 any = A_arbace_core_set_error_handler_BANG__A_New(); var tmp3 *jrt.Class; var fncls__259 *jrt.Class = A_arbace_core_set_error_handler_BANG__A_fn_class; if fncls__259 == nil { var fncls__259d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1032, false); A_arbace_core_set_error_handler_BANG__A_fn_class = fncls__259d; tmp3 = fncls__259d } else { tmp3 = fncls__259 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_538; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_539)); return A_arbace_core__init_A_const_538 }









func A_arbace_core__init_A_Unit268__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2211, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_540; var tmp2 any = A_arbace_core_error_handler_A_New(); var tmp3 *jrt.Class; var fncls__260 *jrt.Class = A_arbace_core_error_handler_A_fn_class; if fncls__260 == nil { var fncls__260d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1033, false); A_arbace_core_error_handler_A_fn_class = fncls__260d; tmp3 = fncls__260d } else { tmp3 = fncls__260 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_540; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_541)); return A_arbace_core__init_A_const_540 }







func A_arbace_core__init_A_Unit269__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2219, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_542; var tmp2 any = A_arbace_core_set_error_mode_BANG__A_New(); var tmp3 *jrt.Class; var fncls__261 *jrt.Class = A_arbace_core_set_error_mode_BANG__A_fn_class; if fncls__261 == nil { var fncls__261d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1034, false); A_arbace_core_set_error_mode_BANG__A_fn_class = fncls__261d; tmp3 = fncls__261d } else { tmp3 = fncls__261 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_542; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_543)); return A_arbace_core__init_A_const_542 }
















func A_arbace_core__init_A_Unit270__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2236, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_544; var tmp2 any = A_arbace_core_error_mode_A_New(); var tmp3 *jrt.Class; var fncls__262 *jrt.Class = A_arbace_core_error_mode_A_fn_class; if fncls__262 == nil { var fncls__262d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1035, false); A_arbace_core_error_mode_A_fn_class = fncls__262d; tmp3 = fncls__262d } else { tmp3 = fncls__262 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_544; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_545)); return A_arbace_core__init_A_const_544 }






func A_arbace_core__init_A_Unit271__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2243, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_546; var tmp2 any = A_arbace_core_agent_errors_A_New(); var tmp3 *jrt.Class; var fncls__263 *jrt.Class = A_arbace_core_agent_errors_A_fn_class; if fncls__263 == nil { var fncls__263d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1036, false); A_arbace_core_agent_errors_A_fn_class = fncls__263d; tmp3 = fncls__263d } else { tmp3 = fncls__263 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_546; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_547)); return A_arbace_core__init_A_const_546 }









func A_arbace_core__init_A_Unit272__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2253, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_548; var tmp2 any = A_arbace_core_clear_agent_errors_A_New(); var tmp3 *jrt.Class; var fncls__264 *jrt.Class = A_arbace_core_clear_agent_errors_A_fn_class; if fncls__264 == nil { var fncls__264d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1037, false); A_arbace_core_clear_agent_errors_A_fn_class = fncls__264d; tmp3 = fncls__264d } else { tmp3 = fncls__264 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_548; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_549)); return A_arbace_core__init_A_const_548 }







func A_arbace_core__init_A_Unit273__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2261, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_550; var tmp2 any = A_arbace_core_shutdown_agents_A_New(); var tmp3 *jrt.Class; var fncls__265 *jrt.Class = A_arbace_core_shutdown_agents_A_fn_class; if fncls__265 == nil { var fncls__265d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1038, false); A_arbace_core_shutdown_agents_A_fn_class = fncls__265d; tmp3 = fncls__265d } else { tmp3 = fncls__265 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_550; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_551)); return A_arbace_core__init_A_const_550 }







func A_arbace_core__init_A_Unit274__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2269, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_552; var tmp2 any = A_arbace_core_ref_A_New(); var tmp3 *jrt.Class; var fncls__266 *jrt.Class = A_arbace_core_ref_A_fn_class; if fncls__266 == nil { var fncls__266d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1039, true); A_arbace_core_ref_A_fn_class = fncls__266d; tmp3 = fncls__266d } else { tmp3 = fncls__266 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_core__init_A_const_552; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_553)); return A_arbace_core__init_A_const_552 }



































func A_arbace_core__init_A_Unit275__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2305, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_554; var tmp2 any = A_arbace_core_deref_future_A_New(); var tmp3 *jrt.Class; var fncls__267 *jrt.Class = A_arbace_core_deref_future_A_fn_class; if fncls__267 == nil { var fncls__267d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1040, false); A_arbace_core_deref_future_A_fn_class = fncls__267d; tmp3 = fncls__267d } else { tmp3 = fncls__267 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_554; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_555)); return A_arbace_core__init_A_const_554 }







func A_arbace_core__init_A_Unit276__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2313, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_556; var tmp2 any = A_arbace_core_deref_A_New(); var tmp3 *jrt.Class; var fncls__268 *jrt.Class = A_arbace_core_deref_A_fn_class; if fncls__268 == nil { var fncls__268d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1041, false); A_arbace_core_deref_A_fn_class = fncls__268d; tmp3 = fncls__268d } else { tmp3 = fncls__268 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_556; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_557)); return A_arbace_core__init_A_const_556 }




















func A_arbace_core__init_A_Unit277__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2334, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_558; var tmp2 any = A_arbace_core_atom_A_New(); var tmp3 *jrt.Class; var fncls__269 *jrt.Class = A_arbace_core_atom_A_fn_class; if fncls__269 == nil { var fncls__269d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1042, true); A_arbace_core_atom_A_fn_class = fncls__269d; tmp3 = fncls__269d } else { tmp3 = fncls__269 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_core__init_A_const_558; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_559)); return A_arbace_core__init_A_const_558 }

















func A_arbace_core__init_A_Unit278__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2352, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_560; var tmp2 any = A_arbace_core_swap_BANG__A_New(); var tmp3 *jrt.Class; var fncls__270 *jrt.Class = A_arbace_core_swap_BANG__A_fn_class; if fncls__270 == nil { var fncls__270d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1043, true); A_arbace_core_swap_BANG__A_fn_class = fncls__270d; tmp3 = fncls__270d } else { tmp3 = fncls__270 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 4)); var tmp4 *lang.Var = A_arbace_core__init_A_const_560; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_561)); return A_arbace_core__init_A_const_560 }











func A_arbace_core__init_A_Unit279__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2364, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_562; var tmp2 any = A_arbace_core_swap_vals_BANG__A_New(); var tmp3 *jrt.Class; var fncls__271 *jrt.Class = A_arbace_core_swap_vals_BANG__A_fn_class; if fncls__271 == nil { var fncls__271d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1044, true); A_arbace_core_swap_vals_BANG__A_fn_class = fncls__271d; tmp3 = fncls__271d } else { tmp3 = fncls__271 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 4)); var tmp4 *lang.Var = A_arbace_core__init_A_const_562; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_563)); return A_arbace_core__init_A_const_562 }










func A_arbace_core__init_A_Unit280__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2375, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_564; var tmp2 any = A_arbace_core_compare_and_set_BANG__A_New(); var tmp3 *jrt.Class; var fncls__272 *jrt.Class = A_arbace_core_compare_and_set_BANG__A_fn_class; if fncls__272 == nil { var fncls__272d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1045, false); A_arbace_core_compare_and_set_BANG__A_fn_class = fncls__272d; tmp3 = fncls__272d } else { tmp3 = fncls__272 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_564; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_565)); return A_arbace_core__init_A_const_564 }







func A_arbace_core__init_A_Unit281__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2383, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_566; var tmp2 any = A_arbace_core_reset_BANG__A_New(); var tmp3 *jrt.Class; var fncls__273 *jrt.Class = A_arbace_core_reset_BANG__A_fn_class; if fncls__273 == nil { var fncls__273d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1046, false); A_arbace_core_reset_BANG__A_fn_class = fncls__273d; tmp3 = fncls__273d } else { tmp3 = fncls__273 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_566; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_567)); return A_arbace_core__init_A_const_566 }






func A_arbace_core__init_A_Unit282__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2390, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_568; var tmp2 any = A_arbace_core_reset_vals_BANG__A_New(); var tmp3 *jrt.Class; var fncls__274 *jrt.Class = A_arbace_core_reset_vals_BANG__A_fn_class; if fncls__274 == nil { var fncls__274d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1047, false); A_arbace_core_reset_vals_BANG__A_fn_class = fncls__274d; tmp3 = fncls__274d } else { tmp3 = fncls__274 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_568; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_569)); return A_arbace_core__init_A_const_568 }





func A_arbace_core__init_A_Unit283__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2396, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_570; var tmp2 any = A_arbace_core_set_validator_BANG__A_New(); var tmp3 *jrt.Class; var fncls__275 *jrt.Class = A_arbace_core_set_validator_BANG__A_fn_class; if fncls__275 == nil { var fncls__275d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1048, false); A_arbace_core_set_validator_BANG__A_fn_class = fncls__275d; tmp3 = fncls__275d } else { tmp3 = fncls__275 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_570; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_571)); return A_arbace_core__init_A_const_570 }










func A_arbace_core__init_A_Unit284__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2407, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_572; var tmp2 any = A_arbace_core_get_validator_A_New(); var tmp3 *jrt.Class; var fncls__276 *jrt.Class = A_arbace_core_get_validator_A_fn_class; if fncls__276 == nil { var fncls__276d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1049, false); A_arbace_core_get_validator_A_fn_class = fncls__276d; tmp3 = fncls__276d } else { tmp3 = fncls__276 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_572; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_573)); return A_arbace_core__init_A_const_572 }





func A_arbace_core__init_A_Unit285__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2413, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_574; var tmp2 any = A_arbace_core_alter_meta_BANG__A_New(); var tmp3 *jrt.Class; var fncls__277 *jrt.Class = A_arbace_core_alter_meta_BANG__A_fn_class; if fncls__277 == nil { var fncls__277d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1050, true); A_arbace_core_alter_meta_BANG__A_fn_class = fncls__277d; tmp3 = fncls__277d } else { tmp3 = fncls__277 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_574; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_575)); return A_arbace_core__init_A_const_574 }









func A_arbace_core__init_A_Unit286__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2423, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_576; var tmp2 any = A_arbace_core_reset_meta_BANG__A_New(); var tmp3 *jrt.Class; var fncls__278 *jrt.Class = A_arbace_core_reset_meta_BANG__A_fn_class; if fncls__278 == nil { var fncls__278d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1051, false); A_arbace_core_reset_meta_BANG__A_fn_class = fncls__278d; tmp3 = fncls__278d } else { tmp3 = fncls__278 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_576; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_577)); return A_arbace_core__init_A_const_576 }





func A_arbace_core__init_A_Unit287__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2429, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_578; var tmp2 any = A_arbace_core_commute_A_New(); var tmp3 *jrt.Class; var fncls__279 *jrt.Class = A_arbace_core_commute_A_fn_class; if fncls__279 == nil { var fncls__279d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1052, true); A_arbace_core_commute_A_fn_class = fncls__279d; tmp3 = fncls__279d } else { tmp3 = fncls__279 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_578; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_579)); return A_arbace_core__init_A_const_578 }




















func A_arbace_core__init_A_Unit288__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2450, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_580; var tmp2 any = A_arbace_core_alter_A_New(); var tmp3 *jrt.Class; var fncls__280 *jrt.Class = A_arbace_core_alter_A_fn_class; if fncls__280 == nil { var fncls__280d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1053, true); A_arbace_core_alter_A_fn_class = fncls__280d; tmp3 = fncls__280d } else { tmp3 = fncls__280 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_580; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_581)); return A_arbace_core__init_A_const_580 }











func A_arbace_core__init_A_Unit289__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2462, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_582; var tmp2 any = A_arbace_core_ref_set_A_New(); var tmp3 *jrt.Class; var fncls__281 *jrt.Class = A_arbace_core_ref_set_A_fn_class; if fncls__281 == nil { var fncls__281d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1054, false); A_arbace_core_ref_set_A_fn_class = fncls__281d; tmp3 = fncls__281d } else { tmp3 = fncls__281 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_582; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_583)); return A_arbace_core__init_A_const_582 }







func A_arbace_core__init_A_Unit290__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2470, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_584; var tmp2 any = A_arbace_core_ref_history_count_A_New(); var tmp3 *jrt.Class; var fncls__282 *jrt.Class = A_arbace_core_ref_history_count_A_fn_class; if fncls__282 == nil { var fncls__282d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1055, false); A_arbace_core_ref_history_count_A_fn_class = fncls__282d; tmp3 = fncls__282d } else { tmp3 = fncls__282 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_584; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_585)); return A_arbace_core__init_A_const_584 }






func A_arbace_core__init_A_Unit291__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2477, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_586; var tmp2 any = A_arbace_core_ref_min_history_A_New(); var tmp3 *jrt.Class; var fncls__283 *jrt.Class = A_arbace_core_ref_min_history_A_fn_class; if fncls__283 == nil { var fncls__283d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1056, false); A_arbace_core_ref_min_history_A_fn_class = fncls__283d; tmp3 = fncls__283d } else { tmp3 = fncls__283 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_586; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_587)); return A_arbace_core__init_A_const_586 }








func A_arbace_core__init_A_Unit292__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2486, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_588; var tmp2 any = A_arbace_core_ref_max_history_A_New(); var tmp3 *jrt.Class; var fncls__284 *jrt.Class = A_arbace_core_ref_max_history_A_fn_class; if fncls__284 == nil { var fncls__284d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1057, false); A_arbace_core_ref_max_history_A_fn_class = fncls__284d; tmp3 = fncls__284d } else { tmp3 = fncls__284 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_588; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_589)); return A_arbace_core__init_A_const_588 }








func A_arbace_core__init_A_Unit293__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2495, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_590; var tmp2 any = A_arbace_core_ensure_A_New(); var tmp3 *jrt.Class; var fncls__285 *jrt.Class = A_arbace_core_ensure_A_fn_class; if fncls__285 == nil { var fncls__285d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1058, false); A_arbace_core_ensure_A_fn_class = fncls__285d; tmp3 = fncls__285d } else { tmp3 = fncls__285 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_590; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_591)); return A_arbace_core__init_A_const_590 }









func A_arbace_core__init_A_Unit294__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2505, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_592; var tmp2 any = A_arbace_core_sync_A_New(); var tmp3 *jrt.Class; var fncls__286 *jrt.Class = A_arbace_core_sync_A_fn_class; if fncls__286 == nil { var fncls__286d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1059, true); A_arbace_core_sync_A_fn_class = fncls__286d; tmp3 = fncls__286d } else { tmp3 = fncls__286 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_592; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_593)); return A_arbace_core__init_A_const_592 }
//line :2505:1
func A_arbace_core__init_A_Unit295__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2505, 1); A_arbace_core__init_A_const_592.SetMacro__V(); return nil }
//line :2505:1
func A_arbace_core__init_A_Unit296__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2505, 1); return A_arbace_core__init_A_const_592 }












func A_arbace_core__init_A_Unit297__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2518, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_594; var tmp2 any = A_arbace_core_io_BANG__A_New(); var tmp3 *jrt.Class; var fncls__287 *jrt.Class = A_arbace_core_io_BANG__A_fn_class; if fncls__287 == nil { var fncls__287d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1060, true); A_arbace_core_io_BANG__A_fn_class = fncls__287d; tmp3 = fncls__287d } else { tmp3 = fncls__287 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_594; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_595)); return A_arbace_core__init_A_const_594 }
//line :2518:1
func A_arbace_core__init_A_Unit298__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2518, 1); A_arbace_core__init_A_const_594.SetMacro__V(); return nil }
//line :2518:1
func A_arbace_core__init_A_Unit299__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2518, 1); return A_arbace_core__init_A_const_594 }












func A_arbace_core__init_A_Unit300__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2531, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_596; var tmp2 any = A_arbace_core_volatile_BANG__A_New(); var tmp3 *jrt.Class; var fncls__288 *jrt.Class = A_arbace_core_volatile_BANG__A_fn_class; if fncls__288 == nil { var fncls__288d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1061, false); A_arbace_core_volatile_BANG__A_fn_class = fncls__288d; tmp3 = fncls__288d } else { tmp3 = fncls__288 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_596; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_597)); return A_arbace_core__init_A_const_596 }






func A_arbace_core__init_A_Unit301__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2538, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_598; var tmp2 any = A_arbace_core_vreset_BANG__A_New(); var tmp3 *jrt.Class; var fncls__289 *jrt.Class = A_arbace_core_vreset_BANG__A_fn_class; if fncls__289 == nil { var fncls__289d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1062, false); A_arbace_core_vreset_BANG__A_fn_class = fncls__289d; tmp3 = fncls__289d } else { tmp3 = fncls__289 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_598; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_599)); return A_arbace_core__init_A_const_598 }






func A_arbace_core__init_A_Unit302__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2545, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_600; var tmp2 any = A_arbace_core_vswap_BANG__A_New(); var tmp3 *jrt.Class; var fncls__290 *jrt.Class = A_arbace_core_vswap_BANG__A_fn_class; if fncls__290 == nil { var fncls__290d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1063, true); A_arbace_core_vswap_BANG__A_fn_class = fncls__290d; tmp3 = fncls__290d } else { tmp3 = fncls__290 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 4)); var tmp4 *lang.Var = A_arbace_core__init_A_const_600; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_601)); return A_arbace_core__init_A_const_600 }
//line :2545:1
func A_arbace_core__init_A_Unit303__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2545, 1); A_arbace_core__init_A_const_600.SetMacro__V(); return nil }
//line :2545:1
func A_arbace_core__init_A_Unit304__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2545, 1); return A_arbace_core__init_A_const_600 }








func A_arbace_core__init_A_Unit305__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2554, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_602; var tmp2 any = A_arbace_core_volatile_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__291 *jrt.Class = A_arbace_core_volatile_QMARK__A_fn_class; if fncls__291 == nil { var fncls__291d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1064, false); A_arbace_core_volatile_QMARK__A_fn_class = fncls__291d; tmp3 = fncls__291d } else { tmp3 = fncls__291 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_602; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_603)); return A_arbace_core__init_A_const_602 }







func A_arbace_core__init_A_Unit306__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2562, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_604; var tmp2 any = A_arbace_core_comp_A_New(); var tmp3 *jrt.Class; var fncls__292 *jrt.Class = A_arbace_core_comp_A_fn_class; if fncls__292 == nil { var fncls__292d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1065, true); A_arbace_core_comp_A_fn_class = fncls__292d; tmp3 = fncls__292d } else { tmp3 = fncls__292 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_604; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_605)); return A_arbace_core__init_A_const_604 }


















func A_arbace_core__init_A_Unit307__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2581, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_606; var tmp2 any = A_arbace_core_juxt_A_New(); var tmp3 *jrt.Class; var fncls__293 *jrt.Class = A_arbace_core_juxt_A_fn_class; if fncls__293 == nil { var fncls__293d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1066, true); A_arbace_core_juxt_A_fn_class = fncls__293d; tmp3 = fncls__293d } else { tmp3 = fncls__293 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_606; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_607)); return A_arbace_core__init_A_const_606 }





































func A_arbace_core__init_A_Unit308__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2619, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_608; var tmp2 any = A_arbace_core_partial_A_New(); var tmp3 *jrt.Class; var fncls__294 *jrt.Class = A_arbace_core_partial_A_fn_class; if fncls__294 == nil { var fncls__294d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1067, true); A_arbace_core_partial_A_fn_class = fncls__294d; tmp3 = fncls__294d } else { tmp3 = fncls__294 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 4)); var tmp4 *lang.Var = A_arbace_core__init_A_const_608; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_609)); return A_arbace_core__init_A_const_608 }
































func A_arbace_core__init_A_Unit309__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2652, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_610; var tmp2 any = A_arbace_core_sequence_A_New(); var tmp3 *jrt.Class; var fncls__295 *jrt.Class = A_arbace_core_sequence_A_fn_class; if fncls__295 == nil { var fncls__295d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1068, true); A_arbace_core_sequence_A_fn_class = fncls__295d; tmp3 = fncls__295d } else { tmp3 = fncls__295 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_610; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_611)); return A_arbace_core__init_A_const_610 }
























func A_arbace_core__init_A_Unit310__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2677, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_612; var tmp2 any = A_arbace_core_every_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__296 *jrt.Class = A_arbace_core_every_QMARK__A_fn_class; if fncls__296 == nil { var fncls__296d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1069, false); A_arbace_core_every_QMARK__A_fn_class = fncls__296d; tmp3 = fncls__296d } else { tmp3 = fncls__296 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_612; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_613)); return A_arbace_core__init_A_const_612 }











func A_arbace_core__init_A_Unit311__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2689, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_614; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_core__init_A_const_604.GetRawRoot__O()).Invoke_O_O__O(A_arbace_core__init_A_const_111.GetRawRoot__O(), A_arbace_core__init_A_const_612.GetRawRoot__O())); var tmp2 *lang.Var = A_arbace_core__init_A_const_614; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_615)); return A_arbace_core__init_A_const_614 }







func A_arbace_core__init_A_Unit312__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2697, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_616; var tmp2 any = A_arbace_core_some_A_New(); var tmp3 *jrt.Class; var fncls__297 *jrt.Class = A_arbace_core_some_A_fn_class; if fncls__297 == nil { var fncls__297d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1070, false); A_arbace_core_some_A_fn_class = fncls__297d; tmp3 = fncls__297d } else { tmp3 = fncls__297 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_616; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_617)); return A_arbace_core__init_A_const_616 }










func A_arbace_core__init_A_Unit313__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2708, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_618; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_core__init_A_const_604.GetRawRoot__O()).Invoke_O_O__O(A_arbace_core__init_A_const_111.GetRawRoot__O(), A_arbace_core__init_A_const_616.GetRawRoot__O())); var tmp2 *lang.Var = A_arbace_core__init_A_const_618; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_619)); return A_arbace_core__init_A_const_618 }








func A_arbace_core__init_A_Unit314__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2717, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_620; var tmp2 any = A_arbace_core_dotimes_A_New(); var tmp3 *jrt.Class; var fncls__298 *jrt.Class = A_arbace_core_dotimes_A_fn_class; if fncls__298 == nil { var fncls__298d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1071, true); A_arbace_core_dotimes_A_fn_class = fncls__298d; tmp3 = fncls__298d } else { tmp3 = fncls__298 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_620; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_621)); return A_arbace_core__init_A_const_620 }
//line :2717:1
func A_arbace_core__init_A_Unit315__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2717, 1); A_arbace_core__init_A_const_620.SetMacro__V(); return nil }
//line :2717:1
func A_arbace_core__init_A_Unit316__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2717, 1); return A_arbace_core__init_A_const_620 }














func A_arbace_core__init_A_Unit317__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2732, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_462; var tmp2 any = A_arbace_core_map_A_New(); var tmp3 *jrt.Class; var fncls__299 *jrt.Class = A_arbace_core_map_A_fn_class; if fncls__299 == nil { var fncls__299d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1072, true); A_arbace_core_map_A_fn_class = fncls__299d; tmp3 = fncls__299d } else { tmp3 = fncls__299 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 4)); var tmp4 *lang.Var = A_arbace_core__init_A_const_462; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_622)); return A_arbace_core__init_A_const_462 }
















































func A_arbace_core__init_A_Unit318__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2781, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_623; var tmp2 any = A_arbace_core_declare_A_New(); var tmp3 *jrt.Class; var fncls__300 *jrt.Class = A_arbace_core_declare_A_fn_class; if fncls__300 == nil { var fncls__300d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1073, true); A_arbace_core_declare_A_fn_class = fncls__300d; tmp3 = fncls__300d } else { tmp3 = fncls__300 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_623; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_624)); return A_arbace_core__init_A_const_623 }
//line :2781:1
func A_arbace_core__init_A_Unit319__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2781, 1); A_arbace_core__init_A_const_623.SetMacro__V(); return nil }
//line :2781:1
func A_arbace_core__init_A_Unit320__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2781, 1); return A_arbace_core__init_A_const_623 }




func A_arbace_core__init_A_Unit321__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2786, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_625; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_626)); return A_arbace_core__init_A_const_625 }
//line :2786:1
func A_arbace_core__init_A_Unit322__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2786, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_627; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_628)); return A_arbace_core__init_A_const_627 }

func A_arbace_core__init_A_Unit323__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2788, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_629; var tmp2 any = A_arbace_core_mapcat_A_New(); var tmp3 *jrt.Class; var fncls__301 *jrt.Class = A_arbace_core_mapcat_A_fn_class; if fncls__301 == nil { var fncls__301d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1074, true); A_arbace_core_mapcat_A_fn_class = fncls__301d; tmp3 = fncls__301d } else { tmp3 = fncls__301 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_core__init_A_const_629; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_630)); return A_arbace_core__init_A_const_629 }









func A_arbace_core__init_A_Unit324__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2798, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_631; var tmp2 any = A_arbace_core_filter_A_New(); var tmp3 *jrt.Class; var fncls__302 *jrt.Class = A_arbace_core_filter_A_fn_class; if fncls__302 == nil { var fncls__302d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1075, false); A_arbace_core_filter_A_fn_class = fncls__302d; tmp3 = fncls__302d } else { tmp3 = fncls__302 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_631; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_632)); return A_arbace_core__init_A_const_631 }































func A_arbace_core__init_A_Unit325__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2830, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_633; var tmp2 any = A_arbace_core_remove_A_New(); var tmp3 *jrt.Class; var fncls__303 *jrt.Class = A_arbace_core_remove_A_fn_class; if fncls__303 == nil { var fncls__303d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1076, false); A_arbace_core_remove_A_fn_class = fncls__303d; tmp3 = fncls__303d } else { tmp3 = fncls__303 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_633; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_634)); return A_arbace_core__init_A_const_633 }









func A_arbace_core__init_A_Unit326__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2840, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_635; var tmp2 any = A_arbace_core_reduced_A_New(); var tmp3 *jrt.Class; var fncls__304 *jrt.Class = A_arbace_core_reduced_A_fn_class; if fncls__304 == nil { var fncls__304d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1077, false); A_arbace_core_reduced_A_fn_class = fncls__304d; tmp3 = fncls__304d } else { tmp3 = fncls__304 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_635; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_636)); return A_arbace_core__init_A_const_635 }





func A_arbace_core__init_A_Unit327__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2846, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_637; var tmp2 any = A_arbace_core_reduced_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__305 *jrt.Class = A_arbace_core_reduced_QMARK__A_fn_class; if fncls__305 == nil { var fncls__305d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1078, false); A_arbace_core_reduced_QMARK__A_fn_class = fncls__305d; tmp3 = fncls__305d } else { tmp3 = fncls__305 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_637; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_638; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_reduced_QMARK___inliner__1927000608_A_New(); var tmp10 *jrt.Class; var fncls__306 *jrt.Class = A_arbace_core_reduced_QMARK___inliner__1927000608_A_fn_class; if fncls__306 == nil { var fncls__306d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1080, false); A_arbace_core_reduced_QMARK___inliner__1927000608_A_fn_class = fncls__306d; tmp10 = fncls__306d } else { tmp10 = fncls__306 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_1079, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_171, A_arbace_core__init_A_const_639, A_arbace_core__init_A_const_54, Lit_1081, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_640, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_637 }






func A_arbace_core__init_A_Unit328__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2853, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_641; var tmp2 any = A_arbace_core_ensure_reduced_A_New(); var tmp3 *jrt.Class; var fncls__307 *jrt.Class = A_arbace_core_ensure_reduced_A_fn_class; if fncls__307 == nil { var fncls__307d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1082, false); A_arbace_core_ensure_reduced_A_fn_class = fncls__307d; tmp3 = fncls__307d } else { tmp3 = fncls__307 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_641; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_642)); return A_arbace_core__init_A_const_641 }





func A_arbace_core__init_A_Unit329__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2859, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_643; var tmp2 any = A_arbace_core_unreduced_A_New(); var tmp3 *jrt.Class; var fncls__308 *jrt.Class = A_arbace_core_unreduced_A_fn_class; if fncls__308 == nil { var fncls__308d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1083, false); A_arbace_core_unreduced_A_fn_class = fncls__308d; tmp3 = fncls__308d } else { tmp3 = fncls__308 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_643; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_644)); return A_arbace_core__init_A_const_643 }





func A_arbace_core__init_A_Unit330__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2865, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_645; var tmp2 any = A_arbace_core_take_A_New(); var tmp3 *jrt.Class; var fncls__309 *jrt.Class = A_arbace_core_take_A_fn_class; if fncls__309 == nil { var fncls__309d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1084, false); A_arbace_core_take_A_fn_class = fncls__309d; tmp3 = fncls__309d } else { tmp3 = fncls__309 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_645; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_646)); return A_arbace_core__init_A_const_645 }


























func A_arbace_core__init_A_Unit331__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2892, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_647; var tmp2 any = A_arbace_core_take_while_A_New(); var tmp3 *jrt.Class; var fncls__310 *jrt.Class = A_arbace_core_take_while_A_fn_class; if fncls__310 == nil { var fncls__310d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1085, false); A_arbace_core_take_while_A_fn_class = fncls__310d; tmp3 = fncls__310d } else { tmp3 = fncls__310 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_647; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_648)); return A_arbace_core__init_A_const_647 }




















func A_arbace_core__init_A_Unit332__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2913, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_649; var tmp2 any = A_arbace_core_drop_A_New(); var tmp3 *jrt.Class; var fncls__311 *jrt.Class = A_arbace_core_drop_A_fn_class; if fncls__311 == nil { var fncls__311d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1086, false); A_arbace_core_drop_A_fn_class = fncls__311d; tmp3 = fncls__311d } else { tmp3 = fncls__311 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_649; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_650)); return A_arbace_core__init_A_const_649 }






























func A_arbace_core__init_A_Unit333__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2944, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_651; var tmp2 any = A_arbace_core_drop_last_A_New(); var tmp3 *jrt.Class; var fncls__312 *jrt.Class = A_arbace_core_drop_last_A_fn_class; if fncls__312 == nil { var fncls__312d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1087, false); A_arbace_core_drop_last_A_fn_class = fncls__312d; tmp3 = fncls__312d } else { tmp3 = fncls__312 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_651; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_652)); return A_arbace_core__init_A_const_651 }






func A_arbace_core__init_A_Unit334__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2951, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_653; var tmp2 any = A_arbace_core_take_last_A_New(); var tmp3 *jrt.Class; var fncls__313 *jrt.Class = A_arbace_core_take_last_A_fn_class; if fncls__313 == nil { var fncls__313d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1088, false); A_arbace_core_take_last_A_fn_class = fncls__313d; tmp3 = fncls__313d } else { tmp3 = fncls__313 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_653; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_654)); return A_arbace_core__init_A_const_653 }










func A_arbace_core__init_A_Unit335__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2962, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_655; var tmp2 any = A_arbace_core_drop_while_A_New(); var tmp3 *jrt.Class; var fncls__314 *jrt.Class = A_arbace_core_drop_while_A_fn_class; if fncls__314 == nil { var fncls__314d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1089, false); A_arbace_core_drop_while_A_fn_class = fncls__314d; tmp3 = fncls__314d } else { tmp3 = fncls__314 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_655; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_656)); return A_arbace_core__init_A_const_655 }


























func A_arbace_core__init_A_Unit336__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2989, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_657; var tmp2 any = A_arbace_core_cycle_A_New(); var tmp3 *jrt.Class; var fncls__315 *jrt.Class = A_arbace_core_cycle_A_fn_class; if fncls__315 == nil { var fncls__315d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1090, false); A_arbace_core_cycle_A_fn_class = fncls__315d; tmp3 = fncls__315d } else { tmp3 = fncls__315 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_657; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_658)); return A_arbace_core__init_A_const_657 }





func A_arbace_core__init_A_Unit337__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(2995, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_659; var tmp2 any = A_arbace_core_split_at_A_New(); var tmp3 *jrt.Class; var fncls__316 *jrt.Class = A_arbace_core_split_at_A_fn_class; if fncls__316 == nil { var fncls__316d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1091, false); A_arbace_core_split_at_A_fn_class = fncls__316d; tmp3 = fncls__316d } else { tmp3 = fncls__316 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_659; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_660)); return A_arbace_core__init_A_const_659 }






func A_arbace_core__init_A_Unit338__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3002, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_661; var tmp2 any = A_arbace_core_split_with_A_New(); var tmp3 *jrt.Class; var fncls__317 *jrt.Class = A_arbace_core_split_with_A_fn_class; if fncls__317 == nil { var fncls__317d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1092, false); A_arbace_core_split_with_A_fn_class = fncls__317d; tmp3 = fncls__317d } else { tmp3 = fncls__317 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_661; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_662)); return A_arbace_core__init_A_const_661 }






func A_arbace_core__init_A_Unit339__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3009, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_663; var tmp2 any = A_arbace_core_repeat_A_New(); var tmp3 *jrt.Class; var fncls__318 *jrt.Class = A_arbace_core_repeat_A_fn_class; if fncls__318 == nil { var fncls__318d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1093, false); A_arbace_core_repeat_A_fn_class = fncls__318d; tmp3 = fncls__318d } else { tmp3 = fncls__318 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_663; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_664)); return A_arbace_core__init_A_const_663 }






func A_arbace_core__init_A_Unit340__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3016, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_665; var tmp2 any = A_arbace_core_replicate_A_New(); var tmp3 *jrt.Class; var fncls__319 *jrt.Class = A_arbace_core_replicate_A_fn_class; if fncls__319 == nil { var fncls__319d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1094, false); A_arbace_core_replicate_A_fn_class = fncls__319d; tmp3 = fncls__319d } else { tmp3 = fncls__319 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_665; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_666)); return A_arbace_core__init_A_const_665 }






func A_arbace_core__init_A_Unit341__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3023, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_667; var tmp2 any = A_arbace_core_iterate_A_New(); var tmp3 *jrt.Class; var fncls__320 *jrt.Class = A_arbace_core_iterate_A_fn_class; if fncls__320 == nil { var fncls__320d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1095, false); A_arbace_core_iterate_A_fn_class = fncls__320d; tmp3 = fncls__320d } else { tmp3 = fncls__320 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_667; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_668)); return A_arbace_core__init_A_const_667 }






func A_arbace_core__init_A_Unit342__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3030, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_669; var tmp2 any = A_arbace_core_range_A_New(); var tmp3 *jrt.Class; var fncls__321 *jrt.Class = A_arbace_core_range_A_fn_class; if fncls__321 == nil { var fncls__321d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1096, false); A_arbace_core_range_A_fn_class = fncls__321d; tmp3 = fncls__321d } else { tmp3 = fncls__321 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_669; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_670)); return A_arbace_core__init_A_const_669 }





















func A_arbace_core__init_A_Unit343__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3052, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_671; var tmp2 any = A_arbace_core_line_seq_A_New(); var tmp3 *jrt.Class; var fncls__322 *jrt.Class = A_arbace_core_line_seq_A_fn_class; if fncls__322 == nil { var fncls__322d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1097, false); A_arbace_core_line_seq_A_fn_class = fncls__322d; tmp3 = fncls__322d } else { tmp3 = fncls__322 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_671; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_672)); return A_arbace_core__init_A_const_671 }








func A_arbace_core__init_A_Unit344__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3061, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_673; var tmp2 any = A_arbace_core_comparator_A_New(); var tmp3 *jrt.Class; var fncls__323 *jrt.Class = A_arbace_core_comparator_A_fn_class; if fncls__323 == nil { var fncls__323d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1098, false); A_arbace_core_comparator_A_fn_class = fncls__323d; tmp3 = fncls__323d } else { tmp3 = fncls__323 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_673; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_674)); return A_arbace_core__init_A_const_673 }







func A_arbace_core__init_A_Unit345__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3069, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_675; var tmp2 any = A_arbace_core_sort_A_New(); var tmp3 *jrt.Class; var fncls__324 *jrt.Class = A_arbace_core_sort_A_fn_class; if fncls__324 == nil { var fncls__324d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1099, false); A_arbace_core_sort_A_fn_class = fncls__324d; tmp3 = fncls__324d } else { tmp3 = fncls__324 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_675; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_676)); return A_arbace_core__init_A_const_675 }
















func A_arbace_core__init_A_Unit346__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3086, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_677; var tmp2 any = A_arbace_core_sort_by_A_New(); var tmp3 *jrt.Class; var fncls__325 *jrt.Class = A_arbace_core_sort_by_A_fn_class; if fncls__325 == nil { var fncls__325d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1100, false); A_arbace_core_sort_by_A_fn_class = fncls__325d; tmp3 = fncls__325d } else { tmp3 = fncls__325 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_677; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_678)); return A_arbace_core__init_A_const_677 }













func A_arbace_core__init_A_Unit347__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3100, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_679; var tmp2 any = A_arbace_core_dorun_A_New(); var tmp3 *jrt.Class; var fncls__326 *jrt.Class = A_arbace_core_dorun_A_fn_class; if fncls__326 == nil { var fncls__326d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1101, false); A_arbace_core_dorun_A_fn_class = fncls__326d; tmp3 = fncls__326d } else { tmp3 = fncls__326 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_679; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_680)); return A_arbace_core__init_A_const_679 }














func A_arbace_core__init_A_Unit348__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3115, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_681; var tmp2 any = A_arbace_core_doall_A_New(); var tmp3 *jrt.Class; var fncls__327 *jrt.Class = A_arbace_core_doall_A_fn_class; if fncls__327 == nil { var fncls__327d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1102, false); A_arbace_core_doall_A_fn_class = fncls__327d; tmp3 = fncls__327d } else { tmp3 = fncls__327 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_681; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_682)); return A_arbace_core__init_A_const_681 }















func A_arbace_core__init_A_Unit349__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3131, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_683; var tmp2 any = A_arbace_core_nthnext_A_New(); var tmp3 *jrt.Class; var fncls__328 *jrt.Class = A_arbace_core_nthnext_A_fn_class; if fncls__328 == nil { var fncls__328d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1103, false); A_arbace_core_nthnext_A_fn_class = fncls__328d; tmp3 = fncls__328d } else { tmp3 = fncls__328 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_683; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_684)); return A_arbace_core__init_A_const_683 }













func A_arbace_core__init_A_Unit350__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3145, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_685; var tmp2 any = A_arbace_core_nthrest_A_New(); var tmp3 *jrt.Class; var fncls__329 *jrt.Class = A_arbace_core_nthrest_A_fn_class; if fncls__329 == nil { var fncls__329d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1104, false); A_arbace_core_nthrest_A_fn_class = fncls__329d; tmp3 = fncls__329d } else { tmp3 = fncls__329 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_685; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_686)); return A_arbace_core__init_A_const_685 }















func A_arbace_core__init_A_Unit351__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3161, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_687; var tmp2 any = A_arbace_core_partition_A_New(); var tmp3 *jrt.Class; var fncls__330 *jrt.Class = A_arbace_core_partition_A_fn_class; if fncls__330 == nil { var fncls__330d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1105, false); A_arbace_core_partition_A_fn_class = fncls__330d; tmp3 = fncls__330d } else { tmp3 = fncls__330 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_687; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_688)); return A_arbace_core__init_A_const_687 }

























func A_arbace_core__init_A_Unit352__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3187, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_689; var tmp2 any = A_arbace_core_eval_A_New(); var tmp3 *jrt.Class; var fncls__331 *jrt.Class = A_arbace_core_eval_A_fn_class; if fncls__331 == nil { var fncls__331d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1106, false); A_arbace_core_eval_A_fn_class = fncls__331d; tmp3 = fncls__331d } else { tmp3 = fncls__331 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_689; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_690)); return A_arbace_core__init_A_const_689 }





func A_arbace_core__init_A_Unit353__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3193, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_691; var tmp2 any = A_arbace_core_doseq_A_New(); var tmp3 *jrt.Class; var fncls__332 *jrt.Class = A_arbace_core_doseq_A_fn_class; if fncls__332 == nil { var fncls__332d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1107, true); A_arbace_core_doseq_A_fn_class = fncls__332d; tmp3 = fncls__332d } else { tmp3 = fncls__332 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_691; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_692)); return A_arbace_core__init_A_const_691 }
//line :3193:1
func A_arbace_core__init_A_Unit354__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3193, 1); A_arbace_core__init_A_const_691.SetMacro__V(); return nil }
//line :3193:1
func A_arbace_core__init_A_Unit355__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3193, 1); return A_arbace_core__init_A_const_691 }

























































func A_arbace_core__init_A_Unit356__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3251, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_693; var tmp2 any = A_arbace_core_await_A_New(); var tmp3 *jrt.Class; var fncls__333 *jrt.Class = A_arbace_core_await_A_fn_class; if fncls__333 == nil { var fncls__333d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1108, true); A_arbace_core_await_A_fn_class = fncls__333d; tmp3 = fncls__333d } else { tmp3 = fncls__333 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_core__init_A_const_693; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_694)); return A_arbace_core__init_A_const_693 }
















func A_arbace_core__init_A_Unit357__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3268, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_695; var tmp2 any = A_arbace_core_await1_A_New(); var tmp3 *jrt.Class; var fncls__334 *jrt.Class = A_arbace_core_await1_A_fn_class; if fncls__334 == nil { var fncls__334d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1109, false); A_arbace_core_await1_A_fn_class = fncls__334d; tmp3 = fncls__334d } else { tmp3 = fncls__334 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_695; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_696)); return A_arbace_core__init_A_const_695 }




func A_arbace_core__init_A_Unit358__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3273, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_697; var tmp2 any = A_arbace_core_await_for_A_New(); var tmp3 *jrt.Class; var fncls__335 *jrt.Class = A_arbace_core_await_for_A_fn_class; if fncls__335 == nil { var fncls__335d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1110, true); A_arbace_core_await_for_A_fn_class = fncls__335d; tmp3 = fncls__335d } else { tmp3 = fncls__335 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_core__init_A_const_697; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_698)); return A_arbace_core__init_A_const_697 }
















func A_arbace_core__init_A_Unit359__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3290, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_620; var tmp2 any = A_arbace_core_dotimes__1_A_New(); var tmp3 *jrt.Class; var fncls__336 *jrt.Class = A_arbace_core_dotimes__1_A_fn_class; if fncls__336 == nil { var fncls__336d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1111, true); A_arbace_core_dotimes__1_A_fn_class = fncls__336d; tmp3 = fncls__336d } else { tmp3 = fncls__336 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_620; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_699)); return A_arbace_core__init_A_const_620 }
//line :3290:1
func A_arbace_core__init_A_Unit360__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3290, 1); A_arbace_core__init_A_const_620.SetMacro__V(); return nil }
//line :3290:1
func A_arbace_core__init_A_Unit361__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3290, 1); return A_arbace_core__init_A_const_620 }




























func A_arbace_core__init_A_Unit362__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3319, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_700; var tmp2 any = A_arbace_core_transient_A_New(); var tmp3 *jrt.Class; var fncls__337 *jrt.Class = A_arbace_core_transient_A_fn_class; if fncls__337 == nil { var fncls__337d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1112, false); A_arbace_core_transient_A_fn_class = fncls__337d; tmp3 = fncls__337d } else { tmp3 = fncls__337 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_700; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_701)); return A_arbace_core__init_A_const_700 }














func A_arbace_core__init_A_Unit363__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3334, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_702; var tmp2 any = A_arbace_core_persistent_BANG__A_New(); var tmp3 *jrt.Class; var fncls__338 *jrt.Class = A_arbace_core_persistent_BANG__A_fn_class; if fncls__338 == nil { var fncls__338d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1113, false); A_arbace_core_persistent_BANG__A_fn_class = fncls__338d; tmp3 = fncls__338d } else { tmp3 = fncls__338 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_702; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_703)); return A_arbace_core__init_A_const_702 }








func A_arbace_core__init_A_Unit364__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3343, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_704; var tmp2 any = A_arbace_core_conj_BANG__A_New(); var tmp3 *jrt.Class; var fncls__339 *jrt.Class = A_arbace_core_conj_BANG__A_fn_class; if fncls__339 == nil { var fncls__339d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1114, false); A_arbace_core_conj_BANG__A_fn_class = fncls__339d; tmp3 = fncls__339d } else { tmp3 = fncls__339 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_704; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_705)); return A_arbace_core__init_A_const_704 }









func A_arbace_core__init_A_Unit365__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3353, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_706; var tmp2 any = A_arbace_core_assoc_BANG__A_New(); var tmp3 *jrt.Class; var fncls__340 *jrt.Class = A_arbace_core_assoc_BANG__A_fn_class; if fncls__340 == nil { var fncls__340d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1115, true); A_arbace_core_assoc_BANG__A_fn_class = fncls__340d; tmp3 = fncls__340d } else { tmp3 = fncls__340 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_706; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_707)); return A_arbace_core__init_A_const_706 }












func A_arbace_core__init_A_Unit366__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3366, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_708; var tmp2 any = A_arbace_core_dissoc_BANG__A_New(); var tmp3 *jrt.Class; var fncls__341 *jrt.Class = A_arbace_core_dissoc_BANG__A_fn_class; if fncls__341 == nil { var fncls__341d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1116, true); A_arbace_core_dissoc_BANG__A_fn_class = fncls__341d; tmp3 = fncls__341d } else { tmp3 = fncls__341 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_708; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_709)); return A_arbace_core__init_A_const_708 }










func A_arbace_core__init_A_Unit367__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3377, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_710; var tmp2 any = A_arbace_core_pop_BANG__A_New(); var tmp3 *jrt.Class; var fncls__342 *jrt.Class = A_arbace_core_pop_BANG__A_fn_class; if fncls__342 == nil { var fncls__342d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1117, false); A_arbace_core_pop_BANG__A_fn_class = fncls__342d; tmp3 = fncls__342d } else { tmp3 = fncls__342 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_710; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_711)); return A_arbace_core__init_A_const_710 }







func A_arbace_core__init_A_Unit368__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3385, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_712; var tmp2 any = A_arbace_core_disj_BANG__A_New(); var tmp3 *jrt.Class; var fncls__343 *jrt.Class = A_arbace_core_disj_BANG__A_fn_class; if fncls__343 == nil { var fncls__343d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1118, true); A_arbace_core_disj_BANG__A_fn_class = fncls__343d; tmp3 = fncls__343d } else { tmp3 = fncls__343 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_712; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_713)); return A_arbace_core__init_A_const_712 }













func A_arbace_core__init_A_Unit369__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3399, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_714; var tmp2 any = A_arbace_core_merge_with_A_New(); var tmp3 *jrt.Class; var fncls__344 *jrt.Class = A_arbace_core_merge_with_A_fn_class; if fncls__344 == nil { var fncls__344d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1119, true); A_arbace_core_merge_with_A_fn_class = fncls__344d; tmp3 = fncls__344d } else { tmp3 = fncls__344 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_714; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_715)); return A_arbace_core__init_A_const_714 }

































func A_arbace_core__init_A_Unit370__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3433, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_716; var tmp2 any = A_arbace_core_into0_A_New(); var tmp3 *jrt.Class; var fncls__345 *jrt.Class = A_arbace_core_into0_A_fn_class; if fncls__345 == nil { var fncls__345d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1120, false); A_arbace_core_into0_A_fn_class = fncls__345d; tmp3 = fncls__345d } else { tmp3 = fncls__345 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_716; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_717)); return A_arbace_core__init_A_const_716 }









func A_arbace_core__init_A_Unit371__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3443, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_718; tmp1.BindRoot_O__V(A_arbace_core__init_A_const_716.GetRawRoot__O()); var tmp2 *lang.Var = A_arbace_core__init_A_const_718; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_719)); return A_arbace_core__init_A_const_718 }

func A_arbace_core__init_A_Unit372__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3445, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_720; var tmp2 any = A_arbace_core_merge_A_New(); var tmp3 *jrt.Class; var fncls__346 *jrt.Class = A_arbace_core_merge_A_fn_class; if fncls__346 == nil { var fncls__346d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1121, true); A_arbace_core_merge_A_fn_class = fncls__346d; tmp3 = fncls__346d } else { tmp3 = fncls__346 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_720; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_721)); return A_arbace_core__init_A_const_720 }











func A_arbace_core__init_A_Unit373__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3457, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_722; var tmp2 any = A_arbace_core_import_A_New(); var tmp3 *jrt.Class; var fncls__347 *jrt.Class = A_arbace_core_import_A_fn_class; if fncls__347 == nil { var fncls__347d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1122, true); A_arbace_core_import_A_fn_class = fncls__347d; tmp3 = fncls__347d } else { tmp3 = fncls__347 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_722; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_723)); return A_arbace_core__init_A_const_722 }
//line :3457:1
func A_arbace_core__init_A_Unit374__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3457, 1); A_arbace_core__init_A_const_722.SetMacro__V(); return nil }
//line :3457:1
func A_arbace_core__init_A_Unit375__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3457, 1); return A_arbace_core__init_A_const_722 }

















func A_arbace_core__init_A_Unit376__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3475, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_724; var tmp2 any = A_arbace_core_into_array_A_New(); var tmp3 *jrt.Class; var fncls__348 *jrt.Class = A_arbace_core_into_array_A_fn_class; if fncls__348 == nil { var fncls__348d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1123, false); A_arbace_core_into_array_A_fn_class = fncls__348d; tmp3 = fncls__348d } else { tmp3 = fncls__348 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_724; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_725)); return A_arbace_core__init_A_const_724 }












func A_arbace_core__init_A_Unit377__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3488, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_726; var tmp2 any = A_arbace_core_array_A_New(); var tmp3 *jrt.Class; var fncls__349 *jrt.Class = A_arbace_core_array_A_fn_class; if fncls__349 == nil { var fncls__349d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1124, true); A_arbace_core_array_A_fn_class = fncls__349d; tmp3 = fncls__349d } else { tmp3 = fncls__349 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_core__init_A_const_726; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_727)); return A_arbace_core__init_A_const_726 }



func A_arbace_core__init_A_Unit378__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3492, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_728; var tmp2 any = A_arbace_core_class_A_New(); var tmp3 *jrt.Class; var fncls__350 *jrt.Class = A_arbace_core_class_A_fn_class; if fncls__350 == nil { var fncls__350d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1125, false); A_arbace_core_class_A_fn_class = fncls__350d; tmp3 = fncls__350d } else { tmp3 = fncls__350 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_728; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_729)); return A_arbace_core__init_A_const_728 }





func A_arbace_core__init_A_Unit379__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3498, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_730; var tmp2 any = A_arbace_core_type_A_New(); var tmp3 *jrt.Class; var fncls__351 *jrt.Class = A_arbace_core_type_A_fn_class; if fncls__351 == nil { var fncls__351d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1126, false); A_arbace_core_type_A_fn_class = fncls__351d; tmp3 = fncls__351d } else { tmp3 = fncls__351 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_730; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_731)); return A_arbace_core__init_A_const_730 }






func A_arbace_core__init_A_Unit380__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3505, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_732; var tmp2 any = A_arbace_core_num_A_New(); var tmp3 *jrt.Class; var fncls__352 *jrt.Class = A_arbace_core_num_A_fn_class; if fncls__352 == nil { var fncls__352d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1127, false); A_arbace_core_num_A_fn_class = fncls__352d; tmp3 = fncls__352d } else { tmp3 = fncls__352 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_732; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_733; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_96; var tmp9 any = A_arbace_core__init_A_const_734; var tmp10 any = A_arbace_core__init_A_const_56; var tmp11 any = A_arbace_core_num__inliner__1927000745_A_New(); var tmp12 *jrt.Class; var fncls__353 *jrt.Class = A_arbace_core_num__inliner__1927000745_A_fn_class; if fncls__353 == nil { var fncls__353d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1129, false); A_arbace_core_num__inliner__1927000745_A_fn_class = fncls__353d; tmp12 = fncls__353d } else { tmp12 = fncls__353 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_1128, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_735, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_732 }






func A_arbace_core__init_A_Unit381__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3512, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_736; var tmp2 any = A_arbace_core_long_A_New(); var tmp3 *jrt.Class; var fncls__354 *jrt.Class = A_arbace_core_long_A_fn_class; if fncls__354 == nil { var fncls__354d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1130, false); A_arbace_core_long_A_fn_class = fncls__354d; tmp3 = fncls__354d } else { tmp3 = fncls__354 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_736; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_737; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_long__inliner__1927000748_A_New(); var tmp10 *jrt.Class; var fncls__355 *jrt.Class = A_arbace_core_long__inliner__1927000748_A_fn_class; if fncls__355 == nil { var fncls__355d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1132, false); A_arbace_core_long__inliner__1927000748_A_fn_class = fncls__355d; tmp10 = fncls__355d } else { tmp10 = fncls__355 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_1131, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_738, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_736 }





func A_arbace_core__init_A_Unit382__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3518, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_739; var tmp2 any = A_arbace_core_float_A_New(); var tmp3 *jrt.Class; var fncls__356 *jrt.Class = A_arbace_core_float_A_fn_class; if fncls__356 == nil { var fncls__356d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1133, false); A_arbace_core_float_A_fn_class = fncls__356d; tmp3 = fncls__356d } else { tmp3 = fncls__356 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_739; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_740; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_float__inliner__1927000751_A_New(); var tmp10 *jrt.Class; var fncls__357 *jrt.Class = A_arbace_core_float__inliner__1927000751_A_fn_class; if fncls__357 == nil { var fncls__357d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1135, false); A_arbace_core_float__inliner__1927000751_A_fn_class = fncls__357d; tmp10 = fncls__357d } else { tmp10 = fncls__357 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_1134, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_741, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_739 }





func A_arbace_core__init_A_Unit383__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3524, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_742; var tmp2 any = A_arbace_core_double_A_New(); var tmp3 *jrt.Class; var fncls__358 *jrt.Class = A_arbace_core_double_A_fn_class; if fncls__358 == nil { var fncls__358d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1136, false); A_arbace_core_double_A_fn_class = fncls__358d; tmp3 = fncls__358d } else { tmp3 = fncls__358 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_742; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_743; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_double__inliner__1927000754_A_New(); var tmp10 *jrt.Class; var fncls__359 *jrt.Class = A_arbace_core_double__inliner__1927000754_A_fn_class; if fncls__359 == nil { var fncls__359d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1138, false); A_arbace_core_double__inliner__1927000754_A_fn_class = fncls__359d; tmp10 = fncls__359d } else { tmp10 = fncls__359 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_1137, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_744, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_742 }





func A_arbace_core__init_A_Unit384__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3530, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_745; var tmp2 any = A_arbace_core_short_A_New(); var tmp3 *jrt.Class; var fncls__360 *jrt.Class = A_arbace_core_short_A_fn_class; if fncls__360 == nil { var fncls__360d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1139, false); A_arbace_core_short_A_fn_class = fncls__360d; tmp3 = fncls__360d } else { tmp3 = fncls__360 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_745; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_746; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_short__inliner__1927000757_A_New(); var tmp10 *jrt.Class; var fncls__361 *jrt.Class = A_arbace_core_short__inliner__1927000757_A_fn_class; if fncls__361 == nil { var fncls__361d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1141, false); A_arbace_core_short__inliner__1927000757_A_fn_class = fncls__361d; tmp10 = fncls__361d } else { tmp10 = fncls__361 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_1140, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_747, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_745 }





func A_arbace_core__init_A_Unit385__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3536, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_748; var tmp2 any = A_arbace_core_byte_A_New(); var tmp3 *jrt.Class; var fncls__362 *jrt.Class = A_arbace_core_byte_A_fn_class; if fncls__362 == nil { var fncls__362d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1142, false); A_arbace_core_byte_A_fn_class = fncls__362d; tmp3 = fncls__362d } else { tmp3 = fncls__362 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_748; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_749; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_byte__inliner__1927000760_A_New(); var tmp10 *jrt.Class; var fncls__363 *jrt.Class = A_arbace_core_byte__inliner__1927000760_A_fn_class; if fncls__363 == nil { var fncls__363d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1144, false); A_arbace_core_byte__inliner__1927000760_A_fn_class = fncls__363d; tmp10 = fncls__363d } else { tmp10 = fncls__363 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_1143, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_750, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_748 }





func A_arbace_core__init_A_Unit386__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3542, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_751; var tmp2 any = A_arbace_core_char_A_New(); var tmp3 *jrt.Class; var fncls__364 *jrt.Class = A_arbace_core_char_A_fn_class; if fncls__364 == nil { var fncls__364d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1145, false); A_arbace_core_char_A_fn_class = fncls__364d; tmp3 = fncls__364d } else { tmp3 = fncls__364 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_751; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_752; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_char__inliner__1927000763_A_New(); var tmp10 *jrt.Class; var fncls__365 *jrt.Class = A_arbace_core_char__inliner__1927000763_A_fn_class; if fncls__365 == nil { var fncls__365d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1147, false); A_arbace_core_char__inliner__1927000763_A_fn_class = fncls__365d; tmp10 = fncls__365d } else { tmp10 = fncls__365 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_1146, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_1148, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_753, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_751 }





func A_arbace_core__init_A_Unit387__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3548, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_754; var tmp2 any = A_arbace_core_unchecked_byte_A_New(); var tmp3 *jrt.Class; var fncls__366 *jrt.Class = A_arbace_core_unchecked_byte_A_fn_class; if fncls__366 == nil { var fncls__366d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1149, false); A_arbace_core_unchecked_byte_A_fn_class = fncls__366d; tmp3 = fncls__366d } else { tmp3 = fncls__366 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_754; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_755; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_unchecked_byte__inliner__1927000766_A_New(); var tmp10 *jrt.Class; var fncls__367 *jrt.Class = A_arbace_core_unchecked_byte__inliner__1927000766_A_fn_class; if fncls__367 == nil { var fncls__367d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1151, false); A_arbace_core_unchecked_byte__inliner__1927000766_A_fn_class = fncls__367d; tmp10 = fncls__367d } else { tmp10 = fncls__367 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_1150, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_1152, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_756, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_754 }





func A_arbace_core__init_A_Unit388__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3554, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_757; var tmp2 any = A_arbace_core_unchecked_short_A_New(); var tmp3 *jrt.Class; var fncls__368 *jrt.Class = A_arbace_core_unchecked_short_A_fn_class; if fncls__368 == nil { var fncls__368d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1153, false); A_arbace_core_unchecked_short_A_fn_class = fncls__368d; tmp3 = fncls__368d } else { tmp3 = fncls__368 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_757; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_758; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_unchecked_short__inliner__1927000769_A_New(); var tmp10 *jrt.Class; var fncls__369 *jrt.Class = A_arbace_core_unchecked_short__inliner__1927000769_A_fn_class; if fncls__369 == nil { var fncls__369d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1155, false); A_arbace_core_unchecked_short__inliner__1927000769_A_fn_class = fncls__369d; tmp10 = fncls__369d } else { tmp10 = fncls__369 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_1154, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_1152, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_759, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_757 }





func A_arbace_core__init_A_Unit389__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3560, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_760; var tmp2 any = A_arbace_core_unchecked_char_A_New(); var tmp3 *jrt.Class; var fncls__370 *jrt.Class = A_arbace_core_unchecked_char_A_fn_class; if fncls__370 == nil { var fncls__370d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1156, false); A_arbace_core_unchecked_char_A_fn_class = fncls__370d; tmp3 = fncls__370d } else { tmp3 = fncls__370 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_760; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_761; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_unchecked_char__inliner__1927000772_A_New(); var tmp10 *jrt.Class; var fncls__371 *jrt.Class = A_arbace_core_unchecked_char__inliner__1927000772_A_fn_class; if fncls__371 == nil { var fncls__371d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1158, false); A_arbace_core_unchecked_char__inliner__1927000772_A_fn_class = fncls__371d; tmp10 = fncls__371d } else { tmp10 = fncls__371 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_1157, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_1152, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_762, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_760 }





func A_arbace_core__init_A_Unit390__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3566, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_763; var tmp2 any = A_arbace_core_unchecked_int_A_New(); var tmp3 *jrt.Class; var fncls__372 *jrt.Class = A_arbace_core_unchecked_int_A_fn_class; if fncls__372 == nil { var fncls__372d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1159, false); A_arbace_core_unchecked_int_A_fn_class = fncls__372d; tmp3 = fncls__372d } else { tmp3 = fncls__372 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_763; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_764; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_unchecked_int__inliner__1927000775_A_New(); var tmp10 *jrt.Class; var fncls__373 *jrt.Class = A_arbace_core_unchecked_int__inliner__1927000775_A_fn_class; if fncls__373 == nil { var fncls__373d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1161, false); A_arbace_core_unchecked_int__inliner__1927000775_A_fn_class = fncls__373d; tmp10 = fncls__373d } else { tmp10 = fncls__373 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_1160, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_1152, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_765, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_763 }





func A_arbace_core__init_A_Unit391__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3572, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_766; var tmp2 any = A_arbace_core_unchecked_long_A_New(); var tmp3 *jrt.Class; var fncls__374 *jrt.Class = A_arbace_core_unchecked_long_A_fn_class; if fncls__374 == nil { var fncls__374d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1162, false); A_arbace_core_unchecked_long_A_fn_class = fncls__374d; tmp3 = fncls__374d } else { tmp3 = fncls__374 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_766; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_767; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_unchecked_long__inliner__1927000778_A_New(); var tmp10 *jrt.Class; var fncls__375 *jrt.Class = A_arbace_core_unchecked_long__inliner__1927000778_A_fn_class; if fncls__375 == nil { var fncls__375d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1164, false); A_arbace_core_unchecked_long__inliner__1927000778_A_fn_class = fncls__375d; tmp10 = fncls__375d } else { tmp10 = fncls__375 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_1163, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_1152, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_768, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_766 }





func A_arbace_core__init_A_Unit392__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3578, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_769; var tmp2 any = A_arbace_core_unchecked_float_A_New(); var tmp3 *jrt.Class; var fncls__376 *jrt.Class = A_arbace_core_unchecked_float_A_fn_class; if fncls__376 == nil { var fncls__376d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1165, false); A_arbace_core_unchecked_float_A_fn_class = fncls__376d; tmp3 = fncls__376d } else { tmp3 = fncls__376 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_769; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_770; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_unchecked_float__inliner__1927000781_A_New(); var tmp10 *jrt.Class; var fncls__377 *jrt.Class = A_arbace_core_unchecked_float__inliner__1927000781_A_fn_class; if fncls__377 == nil { var fncls__377d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1167, false); A_arbace_core_unchecked_float__inliner__1927000781_A_fn_class = fncls__377d; tmp10 = fncls__377d } else { tmp10 = fncls__377 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_1166, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_1152, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_771, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_769 }





func A_arbace_core__init_A_Unit393__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3584, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_772; var tmp2 any = A_arbace_core_unchecked_double_A_New(); var tmp3 *jrt.Class; var fncls__378 *jrt.Class = A_arbace_core_unchecked_double_A_fn_class; if fncls__378 == nil { var fncls__378d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1168, false); A_arbace_core_unchecked_double_A_fn_class = fncls__378d; tmp3 = fncls__378d } else { tmp3 = fncls__378 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_772; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_773; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_unchecked_double__inliner__1927000784_A_New(); var tmp10 *jrt.Class; var fncls__379 *jrt.Class = A_arbace_core_unchecked_double__inliner__1927000784_A_fn_class; if fncls__379 == nil { var fncls__379d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1170, false); A_arbace_core_unchecked_double__inliner__1927000784_A_fn_class = fncls__379d; tmp10 = fncls__379d } else { tmp10 = fncls__379 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_1169, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_1152, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_774, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_772 }





func A_arbace_core__init_A_Unit394__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3590, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_775; var tmp2 any = A_arbace_core_number_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__380 *jrt.Class = A_arbace_core_number_QMARK__A_fn_class; if fncls__380 == nil { var fncls__380d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1171, false); A_arbace_core_number_QMARK__A_fn_class = fncls__380d; tmp3 = fncls__380d } else { tmp3 = fncls__380 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_775; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_776)); return A_arbace_core__init_A_const_775 }






func A_arbace_core__init_A_Unit395__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3597, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_777; var tmp2 any = A_arbace_core_mod_A_New(); var tmp3 *jrt.Class; var fncls__381 *jrt.Class = A_arbace_core_mod_A_fn_class; if fncls__381 == nil { var fncls__381d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1172, false); A_arbace_core_mod_A_fn_class = fncls__381d; tmp3 = fncls__381d } else { tmp3 = fncls__381 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_777; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_778)); return A_arbace_core__init_A_const_777 }









func A_arbace_core__init_A_Unit396__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3607, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_779; var tmp2 any = A_arbace_core_ratio_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__382 *jrt.Class = A_arbace_core_ratio_QMARK__A_fn_class; if fncls__382 == nil { var fncls__382d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1173, false); A_arbace_core_ratio_QMARK__A_fn_class = fncls__382d; tmp3 = fncls__382d } else { tmp3 = fncls__382 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_779; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_780)); return A_arbace_core__init_A_const_779 }





func A_arbace_core__init_A_Unit397__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3613, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_781; var tmp2 any = A_arbace_core_numerator_A_New(); var tmp3 *jrt.Class; var fncls__383 *jrt.Class = A_arbace_core_numerator_A_fn_class; if fncls__383 == nil { var fncls__383d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1174, false); A_arbace_core_numerator_A_fn_class = fncls__383d; tmp3 = fncls__383d } else { tmp3 = fncls__383 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_781; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_782)); return A_arbace_core__init_A_const_781 }







func A_arbace_core__init_A_Unit398__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3621, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_783; var tmp2 any = A_arbace_core_denominator_A_New(); var tmp3 *jrt.Class; var fncls__384 *jrt.Class = A_arbace_core_denominator_A_fn_class; if fncls__384 == nil { var fncls__384d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1175, false); A_arbace_core_denominator_A_fn_class = fncls__384d; tmp3 = fncls__384d } else { tmp3 = fncls__384 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_783; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_784)); return A_arbace_core__init_A_const_783 }







func A_arbace_core__init_A_Unit399__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3629, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_785; var tmp2 any = A_arbace_core_decimal_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__385 *jrt.Class = A_arbace_core_decimal_QMARK__A_fn_class; if fncls__385 == nil { var fncls__385d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1176, false); A_arbace_core_decimal_QMARK__A_fn_class = fncls__385d; tmp3 = fncls__385d } else { tmp3 = fncls__385 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_785; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_786)); return A_arbace_core__init_A_const_785 }





func A_arbace_core__init_A_Unit400__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3635, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_787; var tmp2 any = A_arbace_core_float_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__386 *jrt.Class = A_arbace_core_float_QMARK__A_fn_class; if fncls__386 == nil { var fncls__386d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1177, false); A_arbace_core_float_QMARK__A_fn_class = fncls__386d; tmp3 = fncls__386d } else { tmp3 = fncls__386 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_787; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_788)); return A_arbace_core__init_A_const_787 }







func A_arbace_core__init_A_Unit401__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3643, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_789; var tmp2 any = A_arbace_core_rational_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__387 *jrt.Class = A_arbace_core_rational_QMARK__A_fn_class; if fncls__387 == nil { var fncls__387d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1178, false); A_arbace_core_rational_QMARK__A_fn_class = fncls__387d; tmp3 = fncls__387d } else { tmp3 = fncls__387 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_789; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_790)); return A_arbace_core__init_A_const_789 }






func A_arbace_core__init_A_Unit402__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3650, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_791; var tmp2 any = A_arbace_core_bigint_A_New(); var tmp3 *jrt.Class; var fncls__388 *jrt.Class = A_arbace_core_bigint_A_fn_class; if fncls__388 == nil { var fncls__388d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1179, false); A_arbace_core_bigint_A_fn_class = fncls__388d; tmp3 = fncls__388d } else { tmp3 = fncls__388 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_791; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_792)); return A_arbace_core__init_A_const_791 }













func A_arbace_core__init_A_Unit403__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3664, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_793; var tmp2 any = A_arbace_core_biginteger_A_New(); var tmp3 *jrt.Class; var fncls__389 *jrt.Class = A_arbace_core_biginteger_A_fn_class; if fncls__389 == nil { var fncls__389d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1180, false); A_arbace_core_biginteger_A_fn_class = fncls__389d; tmp3 = fncls__389d } else { tmp3 = fncls__389 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_793; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_794)); return A_arbace_core__init_A_const_793 }













func A_arbace_core__init_A_Unit404__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3678, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_795; var tmp2 any = A_arbace_core_bigdec_A_New(); var tmp3 *jrt.Class; var fncls__390 *jrt.Class = A_arbace_core_bigdec_A_fn_class; if fncls__390 == nil { var fncls__390d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1181, false); A_arbace_core_bigdec_A_fn_class = fncls__390d; tmp3 = fncls__390d } else { tmp3 = fncls__390 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_795; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_796)); return A_arbace_core__init_A_const_795 }













func A_arbace_core__init_A_Unit405__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3692, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_797; var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_FALSE; tmp1.BindRoot_O__V(tmp2.Ref()); var tmp3 *lang.Var = A_arbace_core__init_A_const_797; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_798)); return A_arbace_core__init_A_const_797.SetDynamic_Z__Var(true).Ref() }

func A_arbace_core__init_A_Unit406__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3694, 1); var v__1927000386__auto____1 any; var tmp1 *lang.Var = A_arbace_core__init_A_const_799; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_800)); v__1927000386__auto____1 = A_arbace_core__init_A_const_799; var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { tmp2 = lang.MultiFn_InstanceOf(lang.IFn_Cast(A_arbace_core__init_A_const_556.GetRawRoot__O()).Invoke_O__O(v__1927000386__auto____1)) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { var tmp3 *lang.Var = A_arbace_core__init_A_const_799; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_802)); var tmp4 *lang.Var = A_arbace_core__init_A_const_799; var tmp5 *jrt.String = Lit_1182; var tmp6 any = A_arbace_core_eval1927000798_fn__1927000799_A_New(); var tmp7 *jrt.Class; var fncls__391 *jrt.Class = A_arbace_core_eval1927000798_fn__1927000799_A_fn_class; if fncls__391 == nil { var fncls__391d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1183, false); A_arbace_core_eval1927000798_fn__1927000799_A_fn_class = fncls__391d; tmp7 = fncls__391d } else { tmp7 = fncls__391 }; var tmp8 lang.IFn = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp9 any = A_arbace_core__init_A_const_801; tmp4.BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp5, tmp8, tmp9, A_arbace_core__init_A_const_466)); return A_arbace_core__init_A_const_799 } }


func A_arbace_core__init_A_Unit407__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3697, 1); var v__1927000386__auto____1 any; var tmp1 *lang.Var = A_arbace_core__init_A_const_803; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_804)); v__1927000386__auto____1 = A_arbace_core__init_A_const_803; var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { tmp2 = lang.MultiFn_InstanceOf(lang.IFn_Cast(A_arbace_core__init_A_const_556.GetRawRoot__O()).Invoke_O__O(v__1927000386__auto____1)) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { var tmp3 *lang.Var = A_arbace_core__init_A_const_803; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_805)); var tmp4 *lang.Var = A_arbace_core__init_A_const_803; var tmp5 *jrt.String = Lit_1184; var tmp6 any = A_arbace_core_eval1927000802_fn__1927000803_A_New(); var tmp7 *jrt.Class; var fncls__392 *jrt.Class = A_arbace_core_eval1927000802_fn__1927000803_A_fn_class; if fncls__392 == nil { var fncls__392d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1185, false); A_arbace_core_eval1927000802_fn__1927000803_A_fn_class = fncls__392d; tmp7 = fncls__392d } else { tmp7 = fncls__392 }; var tmp8 lang.IFn = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp9 any = A_arbace_core__init_A_const_801; tmp4.BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp5, tmp8, tmp9, A_arbace_core__init_A_const_466)); return A_arbace_core__init_A_const_803 } }

func A_arbace_core__init_A_Unit408__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3699, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_806; var tmp2 any = A_arbace_core_pr_on_A_New(); var tmp3 *jrt.Class; var fncls__393 *jrt.Class = A_arbace_core_pr_on_A_fn_class; if fncls__393 == nil { var fncls__393d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1186, false); A_arbace_core_pr_on_A_fn_class = fncls__393d; tmp3 = fncls__393d } else { tmp3 = fncls__393 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_806; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_807)); return A_arbace_core__init_A_const_806 }








func A_arbace_core__init_A_Unit409__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3708, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_808; var tmp2 any = A_arbace_core_pr_A_New(); var tmp3 *jrt.Class; var fncls__394 *jrt.Class = A_arbace_core_pr_A_fn_class; if fncls__394 == nil { var fncls__394d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1187, true); A_arbace_core_pr_A_fn_class = fncls__394d; tmp3 = fncls__394d } else { tmp3 = fncls__394 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_core__init_A_const_808; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_809)); return A_arbace_core__init_A_const_808.SetDynamic_Z__Var(true).Ref() }
















func A_arbace_core__init_A_Unit410__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3725, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_810; tmp1.BindRoot_O__V(jrt.System_GetProperty_String__String(Lit_1188).Ref()); var tmp2 *lang.Var = A_arbace_core__init_A_const_810; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_811)); return A_arbace_core__init_A_const_810 }


func A_arbace_core__init_A_Unit411__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3728, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_812; var tmp2 any = A_arbace_core_newline_A_New(); var tmp3 *jrt.Class; var fncls__395 *jrt.Class = A_arbace_core_newline_A_fn_class; if fncls__395 == nil { var fncls__395d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1189, false); A_arbace_core_newline_A_fn_class = fncls__395d; tmp3 = fncls__395d } else { tmp3 = fncls__395 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_812; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_813)); return A_arbace_core__init_A_const_812 }







func A_arbace_core__init_A_Unit412__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3736, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_814; var tmp2 any = A_arbace_core_flush_A_New(); var tmp3 *jrt.Class; var fncls__396 *jrt.Class = A_arbace_core_flush_A_fn_class; if fncls__396 == nil { var fncls__396d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1190, false); A_arbace_core_flush_A_fn_class = fncls__396d; tmp3 = fncls__396d } else { tmp3 = fncls__396 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_814; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_815)); return A_arbace_core__init_A_const_814 }








func A_arbace_core__init_A_Unit413__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3745, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_816; var tmp2 any = A_arbace_core_prn_A_New(); var tmp3 *jrt.Class; var fncls__397 *jrt.Class = A_arbace_core_prn_A_fn_class; if fncls__397 == nil { var fncls__397d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1191, true); A_arbace_core_prn_A_fn_class = fncls__397d; tmp3 = fncls__397d } else { tmp3 = fncls__397 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_core__init_A_const_816; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_817)); return A_arbace_core__init_A_const_816 }









func A_arbace_core__init_A_Unit414__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3755, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_818; var tmp2 any = A_arbace_core_print_A_New(); var tmp3 *jrt.Class; var fncls__398 *jrt.Class = A_arbace_core_print_A_fn_class; if fncls__398 == nil { var fncls__398d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1192, true); A_arbace_core_print_A_fn_class = fncls__398d; tmp3 = fncls__398d } else { tmp3 = fncls__398 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_core__init_A_const_818; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_819)); return A_arbace_core__init_A_const_818 }








func A_arbace_core__init_A_Unit415__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3764, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_820; var tmp2 any = A_arbace_core_println_A_New(); var tmp3 *jrt.Class; var fncls__399 *jrt.Class = A_arbace_core_println_A_fn_class; if fncls__399 == nil { var fncls__399d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1193, true); A_arbace_core_println_A_fn_class = fncls__399d; tmp3 = fncls__399d } else { tmp3 = fncls__399 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_core__init_A_const_820; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_821)); return A_arbace_core__init_A_const_820 }







func A_arbace_core__init_A_Unit416__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3772, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_822; var tmp2 any = A_arbace_core_read_A_New(); var tmp3 *jrt.Class; var fncls__400 *jrt.Class = A_arbace_core_read_A_fn_class; if fncls__400 == nil { var fncls__400d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1194, false); A_arbace_core_read_A_fn_class = fncls__400d; tmp3 = fncls__400d } else { tmp3 = fncls__400 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_822; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_823)); return A_arbace_core__init_A_const_822 }




























func A_arbace_core__init_A_Unit417__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3801, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_824; var tmp2 any = A_arbace_core_read_PLUS_string_A_New(); var tmp3 *jrt.Class; var fncls__401 *jrt.Class = A_arbace_core_read_PLUS_string_A_fn_class; if fncls__401 == nil { var fncls__401d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1195, false); A_arbace_core_read_PLUS_string_A_fn_class = fncls__401d; tmp3 = fncls__401d } else { tmp3 = fncls__401 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_824; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_825)); return A_arbace_core__init_A_const_824 }

























func A_arbace_core__init_A_Unit418__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3827, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_826; var tmp2 any = A_arbace_core_read_line_A_New(); var tmp3 *jrt.Class; var fncls__402 *jrt.Class = A_arbace_core_read_line_A_fn_class; if fncls__402 == nil { var fncls__402d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1196, false); A_arbace_core_read_line_A_fn_class = fncls__402d; tmp3 = fncls__402d } else { tmp3 = fncls__402 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_826; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_827)); return A_arbace_core__init_A_const_826 }








func A_arbace_core__init_A_Unit419__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3836, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_828; var tmp2 any = A_arbace_core_read_string_A_New(); var tmp3 *jrt.Class; var fncls__403 *jrt.Class = A_arbace_core_read_string_A_fn_class; if fncls__403 == nil { var fncls__403d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1197, false); A_arbace_core_read_string_A_fn_class = fncls__403d; tmp3 = fncls__403d } else { tmp3 = fncls__403 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_828; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_829)); return A_arbace_core__init_A_const_828 }












func A_arbace_core__init_A_Unit420__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3849, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_830; var tmp2 any = A_arbace_core_subvec_A_New(); var tmp3 *jrt.Class; var fncls__404 *jrt.Class = A_arbace_core_subvec_A_fn_class; if fncls__404 == nil { var fncls__404d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1198, false); A_arbace_core_subvec_A_fn_class = fncls__404d; tmp3 = fncls__404d } else { tmp3 = fncls__404 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_830; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_831)); return A_arbace_core__init_A_const_830 }












func A_arbace_core__init_A_Unit421__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3862, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_832; var tmp2 any = A_arbace_core_with_open_A_New(); var tmp3 *jrt.Class; var fncls__405 *jrt.Class = A_arbace_core_with_open_A_fn_class; if fncls__405 == nil { var fncls__405d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1199, true); A_arbace_core_with_open_A_fn_class = fncls__405d; tmp3 = fncls__405d } else { tmp3 = fncls__405 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_832; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_833)); return A_arbace_core__init_A_const_832 }
//line :3862:1
func A_arbace_core__init_A_Unit422__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3862, 1); A_arbace_core__init_A_const_832.SetMacro__V(); return nil }
//line :3862:1
func A_arbace_core__init_A_Unit423__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3862, 1); return A_arbace_core__init_A_const_832 }




















func A_arbace_core__init_A_Unit424__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3883, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_834; var tmp2 any = A_arbace_core_doto_A_New(); var tmp3 *jrt.Class; var fncls__406 *jrt.Class = A_arbace_core_doto_A_fn_class; if fncls__406 == nil { var fncls__406d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1200, true); A_arbace_core_doto_A_fn_class = fncls__406d; tmp3 = fncls__406d } else { tmp3 = fncls__406 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_834; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_835)); return A_arbace_core__init_A_const_834 }
//line :3883:1
func A_arbace_core__init_A_Unit425__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3883, 1); A_arbace_core__init_A_const_834.SetMacro__V(); return nil }
//line :3883:1
func A_arbace_core__init_A_Unit426__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3883, 1); return A_arbace_core__init_A_const_834 }


















func A_arbace_core__init_A_Unit427__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3902, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_836; var tmp2 any = A_arbace_core_memfn_A_New(); var tmp3 *jrt.Class; var fncls__407 *jrt.Class = A_arbace_core_memfn_A_fn_class; if fncls__407 == nil { var fncls__407d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1201, true); A_arbace_core_memfn_A_fn_class = fncls__407d; tmp3 = fncls__407d } else { tmp3 = fncls__407 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_836; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_837)); return A_arbace_core__init_A_const_836 }
//line :3902:1
func A_arbace_core__init_A_Unit428__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3902, 1); A_arbace_core__init_A_const_836.SetMacro__V(); return nil }
//line :3902:1
func A_arbace_core__init_A_Unit429__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3902, 1); return A_arbace_core__init_A_const_836 }












func A_arbace_core__init_A_Unit430__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3915, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_838; var tmp2 any = A_arbace_core_time_A_New(); var tmp3 *jrt.Class; var fncls__408 *jrt.Class = A_arbace_core_time_A_fn_class; if fncls__408 == nil { var fncls__408d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1202, false); A_arbace_core_time_A_fn_class = fncls__408d; tmp3 = fncls__408d } else { tmp3 = fncls__408 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_838; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_839)); return A_arbace_core__init_A_const_838 }
//line :3915:1
func A_arbace_core__init_A_Unit431__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3915, 1); A_arbace_core__init_A_const_838.SetMacro__V(); return nil }
//line :3915:1
func A_arbace_core__init_A_Unit432__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3915, 1); return A_arbace_core__init_A_const_838 }









func A_arbace_core__init_A_Unit433__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3925, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_1203)); return nil }

func A_arbace_core__init_A_Unit434__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3927, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_840; var tmp2 any = A_arbace_core_alength_A_New(); var tmp3 *jrt.Class; var fncls__409 *jrt.Class = A_arbace_core_alength_A_fn_class; if fncls__409 == nil { var fncls__409d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1204, false); A_arbace_core_alength_A_fn_class = fncls__409d; tmp3 = fncls__409d } else { tmp3 = fncls__409 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_840; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_841; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_alength__inliner__1927000844_A_New(); var tmp10 *jrt.Class; var fncls__410 *jrt.Class = A_arbace_core_alength__inliner__1927000844_A_fn_class; if fncls__410 == nil { var fncls__410d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1206, false); A_arbace_core_alength__inliner__1927000844_A_fn_class = fncls__410d; tmp10 = fncls__410d } else { tmp10 = fncls__410 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_1205, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_842, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_840 }






func A_arbace_core__init_A_Unit435__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3934, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_843; var tmp2 any = A_arbace_core_aclone_A_New(); var tmp3 *jrt.Class; var fncls__411 *jrt.Class = A_arbace_core_aclone_A_fn_class; if fncls__411 == nil { var fncls__411d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1207, false); A_arbace_core_aclone_A_fn_class = fncls__411d; tmp3 = fncls__411d } else { tmp3 = fncls__411 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_843; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_844; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_aclone__inliner__1927000847_A_New(); var tmp10 *jrt.Class; var fncls__412 *jrt.Class = A_arbace_core_aclone__inliner__1927000847_A_fn_class; if fncls__412 == nil { var fncls__412d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1209, false); A_arbace_core_aclone__inliner__1927000847_A_fn_class = fncls__412d; tmp10 = fncls__412d } else { tmp10 = fncls__412 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_1208, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_845, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_843 }






func A_arbace_core__init_A_Unit436__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3941, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_846; var tmp2 any = A_arbace_core_aget_A_New(); var tmp3 *jrt.Class; var fncls__413 *jrt.Class = A_arbace_core_aget_A_fn_class; if fncls__413 == nil { var fncls__413d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1210, true); A_arbace_core_aget_A_fn_class = fncls__413d; tmp3 = fncls__413d } else { tmp3 = fncls__413 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_846; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_847; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_aget__inliner__1927000850_A_New(); var tmp10 *jrt.Class; var fncls__414 *jrt.Class = A_arbace_core_aget__inliner__1927000850_A_fn_class; if fncls__414 == nil { var fncls__414d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1212, false); A_arbace_core_aget__inliner__1927000850_A_fn_class = fncls__414d; tmp10 = fncls__414d } else { tmp10 = fncls__414 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_1211, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_171, A_arbace_core__init_A_const_848, A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_849, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_846 }










func A_arbace_core__init_A_Unit437__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3952, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_850; var tmp2 any = A_arbace_core_aset_A_New(); var tmp3 *jrt.Class; var fncls__415 *jrt.Class = A_arbace_core_aset_A_fn_class; if fncls__415 == nil { var fncls__415d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1213, true); A_arbace_core_aset_A_fn_class = fncls__415d; tmp3 = fncls__415d } else { tmp3 = fncls__415 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_850; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_851; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_aset__inliner__1927000853_A_New(); var tmp10 *jrt.Class; var fncls__416 *jrt.Class = A_arbace_core_aset__inliner__1927000853_A_fn_class; if fncls__416 == nil { var fncls__416d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1215, false); A_arbace_core_aset__inliner__1927000853_A_fn_class = fncls__416d; tmp10 = fncls__416d } else { tmp10 = fncls__416 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_1214, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_171, A_arbace_core__init_A_const_852, A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_853, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_850 }











func A_arbace_core__init_A_Unit438__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3964, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_854; var tmp2 any = A_arbace_core_def_aset_A_New(); var tmp3 *jrt.Class; var fncls__417 *jrt.Class = A_arbace_core_def_aset_A_fn_class; if fncls__417 == nil { var fncls__417d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1216, false); A_arbace_core_def_aset_A_fn_class = fncls__417d; tmp3 = fncls__417d } else { tmp3 = fncls__417 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_854; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_855)); return A_arbace_core__init_A_const_854 }
//line :3964:1
func A_arbace_core__init_A_Unit439__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3964, 1); A_arbace_core__init_A_const_854.SetMacro__V(); return nil }
//line :3964:1
func A_arbace_core__init_A_Unit440__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3964, 1); return A_arbace_core__init_A_const_854 }










func A_arbace_core__init_A_Unit441__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3975, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_856; var tmp2 any = A_arbace_core_aset_int_A_New(); var tmp3 *jrt.Class; var fncls__418 *jrt.Class = A_arbace_core_aset_int_A_fn_class; if fncls__418 == nil { var fncls__418d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1217, true); A_arbace_core_aset_int_A_fn_class = fncls__418d; tmp3 = fncls__418d } else { tmp3 = fncls__418 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_856; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_857)); return A_arbace_core__init_A_const_856 }




func A_arbace_core__init_A_Unit442__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3980, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_858; var tmp2 any = A_arbace_core_aset_long_A_New(); var tmp3 *jrt.Class; var fncls__419 *jrt.Class = A_arbace_core_aset_long_A_fn_class; if fncls__419 == nil { var fncls__419d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1218, true); A_arbace_core_aset_long_A_fn_class = fncls__419d; tmp3 = fncls__419d } else { tmp3 = fncls__419 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_858; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_859)); return A_arbace_core__init_A_const_858 }




func A_arbace_core__init_A_Unit443__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3985, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_860; var tmp2 any = A_arbace_core_aset_boolean_A_New(); var tmp3 *jrt.Class; var fncls__420 *jrt.Class = A_arbace_core_aset_boolean_A_fn_class; if fncls__420 == nil { var fncls__420d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1219, true); A_arbace_core_aset_boolean_A_fn_class = fncls__420d; tmp3 = fncls__420d } else { tmp3 = fncls__420 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_860; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_861)); return A_arbace_core__init_A_const_860 }




func A_arbace_core__init_A_Unit444__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3990, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_862; var tmp2 any = A_arbace_core_aset_float_A_New(); var tmp3 *jrt.Class; var fncls__421 *jrt.Class = A_arbace_core_aset_float_A_fn_class; if fncls__421 == nil { var fncls__421d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1220, true); A_arbace_core_aset_float_A_fn_class = fncls__421d; tmp3 = fncls__421d } else { tmp3 = fncls__421 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_862; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_863)); return A_arbace_core__init_A_const_862 }




func A_arbace_core__init_A_Unit445__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(3995, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_864; var tmp2 any = A_arbace_core_aset_double_A_New(); var tmp3 *jrt.Class; var fncls__422 *jrt.Class = A_arbace_core_aset_double_A_fn_class; if fncls__422 == nil { var fncls__422d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1221, true); A_arbace_core_aset_double_A_fn_class = fncls__422d; tmp3 = fncls__422d } else { tmp3 = fncls__422 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_864; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_865)); return A_arbace_core__init_A_const_864 }




func A_arbace_core__init_A_Unit446__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4000, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_866; var tmp2 any = A_arbace_core_aset_short_A_New(); var tmp3 *jrt.Class; var fncls__423 *jrt.Class = A_arbace_core_aset_short_A_fn_class; if fncls__423 == nil { var fncls__423d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1222, true); A_arbace_core_aset_short_A_fn_class = fncls__423d; tmp3 = fncls__423d } else { tmp3 = fncls__423 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_866; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_867)); return A_arbace_core__init_A_const_866 }




func A_arbace_core__init_A_Unit447__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4005, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_868; var tmp2 any = A_arbace_core_aset_byte_A_New(); var tmp3 *jrt.Class; var fncls__424 *jrt.Class = A_arbace_core_aset_byte_A_fn_class; if fncls__424 == nil { var fncls__424d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1223, true); A_arbace_core_aset_byte_A_fn_class = fncls__424d; tmp3 = fncls__424d } else { tmp3 = fncls__424 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_868; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_869)); return A_arbace_core__init_A_const_868 }




func A_arbace_core__init_A_Unit448__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4010, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_870; var tmp2 any = A_arbace_core_aset_char_A_New(); var tmp3 *jrt.Class; var fncls__425 *jrt.Class = A_arbace_core_aset_char_A_fn_class; if fncls__425 == nil { var fncls__425d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1224, true); A_arbace_core_aset_char_A_fn_class = fncls__425d; tmp3 = fncls__425d } else { tmp3 = fncls__425 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_870; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_871)); return A_arbace_core__init_A_const_870 }




func A_arbace_core__init_A_Unit449__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4015, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_872; var tmp2 any = A_arbace_core_make_array_A_New(); var tmp3 *jrt.Class; var fncls__426 *jrt.Class = A_arbace_core_make_array_A_fn_class; if fncls__426 == nil { var fncls__426d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1225, true); A_arbace_core_make_array_A_fn_class = fncls__426d; tmp3 = fncls__426d } else { tmp3 = fncls__426 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_872; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_873)); return A_arbace_core__init_A_const_872 }
















func A_arbace_core__init_A_Unit450__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4032, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_874; var tmp2 any = A_arbace_core_to_array_2d_A_New(); var tmp3 *jrt.Class; var fncls__427 *jrt.Class = A_arbace_core_to_array_2d_A_fn_class; if fncls__427 == nil { var fncls__427d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1226, false); A_arbace_core_to_array_2d_A_fn_class = fncls__427d; tmp3 = fncls__427d } else { tmp3 = fncls__427 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_874; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_875)); return A_arbace_core__init_A_const_874 }














func A_arbace_core__init_A_Unit451__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4047, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_876; var tmp2 any = A_arbace_core_macroexpand_1_A_New(); var tmp3 *jrt.Class; var fncls__428 *jrt.Class = A_arbace_core_macroexpand_1_A_fn_class; if fncls__428 == nil { var fncls__428d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1227, false); A_arbace_core_macroexpand_1_A_fn_class = fncls__428d; tmp3 = fncls__428d } else { tmp3 = fncls__428 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_876; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_877)); return A_arbace_core__init_A_const_876 }







func A_arbace_core__init_A_Unit452__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4055, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_878; var tmp2 any = A_arbace_core_macroexpand_A_New(); var tmp3 *jrt.Class; var fncls__429 *jrt.Class = A_arbace_core_macroexpand_A_fn_class; if fncls__429 == nil { var fncls__429d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1228, false); A_arbace_core_macroexpand_A_fn_class = fncls__429d; tmp3 = fncls__429d } else { tmp3 = fncls__429 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_878; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_879)); return A_arbace_core__init_A_const_878 }











func A_arbace_core__init_A_Unit453__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4067, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_880; var tmp2 any = A_arbace_core_create_struct_A_New(); var tmp3 *jrt.Class; var fncls__430 *jrt.Class = A_arbace_core_create_struct_A_fn_class; if fncls__430 == nil { var fncls__430d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1229, true); A_arbace_core_create_struct_A_fn_class = fncls__430d; tmp3 = fncls__430d } else { tmp3 = fncls__430 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_core__init_A_const_880; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_881)); return A_arbace_core__init_A_const_880 }






func A_arbace_core__init_A_Unit454__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4074, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_882; var tmp2 any = A_arbace_core_defstruct_A_New(); var tmp3 *jrt.Class; var fncls__431 *jrt.Class = A_arbace_core_defstruct_A_fn_class; if fncls__431 == nil { var fncls__431d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1230, true); A_arbace_core_defstruct_A_fn_class = fncls__431d; tmp3 = fncls__431d } else { tmp3 = fncls__431 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_882; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_883)); return A_arbace_core__init_A_const_882 }
//line :4074:1
func A_arbace_core__init_A_Unit455__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4074, 1); A_arbace_core__init_A_const_882.SetMacro__V(); return nil }
//line :4074:1
func A_arbace_core__init_A_Unit456__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4074, 1); return A_arbace_core__init_A_const_882 }






func A_arbace_core__init_A_Unit457__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4081, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_884; var tmp2 any = A_arbace_core_struct_map_A_New(); var tmp3 *jrt.Class; var fncls__432 *jrt.Class = A_arbace_core_struct_map_A_fn_class; if fncls__432 == nil { var fncls__432d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1231, true); A_arbace_core_struct_map_A_fn_class = fncls__432d; tmp3 = fncls__432d } else { tmp3 = fncls__432 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_core__init_A_const_884; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_885)); return A_arbace_core__init_A_const_884 }









func A_arbace_core__init_A_Unit458__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4091, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_886; var tmp2 any = A_arbace_core_struct_A_New(); var tmp3 *jrt.Class; var fncls__433 *jrt.Class = A_arbace_core_struct_A_fn_class; if fncls__433 == nil { var fncls__433d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1232, true); A_arbace_core_struct_A_fn_class = fncls__433d; tmp3 = fncls__433d } else { tmp3 = fncls__433 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_core__init_A_const_886; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_887)); return A_arbace_core__init_A_const_886 }








func A_arbace_core__init_A_Unit459__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4100, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_888; var tmp2 any = A_arbace_core_accessor_A_New(); var tmp3 *jrt.Class; var fncls__434 *jrt.Class = A_arbace_core_accessor_A_fn_class; if fncls__434 == nil { var fncls__434d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1233, false); A_arbace_core_accessor_A_fn_class = fncls__434d; tmp3 = fncls__434d } else { tmp3 = fncls__434 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_888; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_889)); return A_arbace_core__init_A_const_888 }










func A_arbace_core__init_A_Unit460__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4111, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_890; var tmp2 any = A_arbace_core_load_reader_A_New(); var tmp3 *jrt.Class; var fncls__435 *jrt.Class = A_arbace_core_load_reader_A_fn_class; if fncls__435 == nil { var fncls__435d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1234, false); A_arbace_core_load_reader_A_fn_class = fncls__435d; tmp3 = fncls__435d } else { tmp3 = fncls__435 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_890; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_891)); return A_arbace_core__init_A_const_890 }






func A_arbace_core__init_A_Unit461__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4118, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_892; var tmp2 any = A_arbace_core_load_string_A_New(); var tmp3 *jrt.Class; var fncls__436 *jrt.Class = A_arbace_core_load_string_A_fn_class; if fncls__436 == nil { var fncls__436d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1235, false); A_arbace_core_load_string_A_fn_class = fncls__436d; tmp3 = fncls__436d } else { tmp3 = fncls__436 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_892; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_893)); return A_arbace_core__init_A_const_892 }









func A_arbace_core__init_A_Unit462__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4128, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_894; var tmp2 any = A_arbace_core_set_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__437 *jrt.Class = A_arbace_core_set_QMARK__A_fn_class; if fncls__437 == nil { var fncls__437d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1236, false); A_arbace_core_set_QMARK__A_fn_class = fncls__437d; tmp3 = fncls__437d } else { tmp3 = fncls__437 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_894; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_895)); return A_arbace_core__init_A_const_894 }





func A_arbace_core__init_A_Unit463__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4134, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_896; var tmp2 any = A_arbace_core_set_A_New(); var tmp3 *jrt.Class; var fncls__438 *jrt.Class = A_arbace_core_set_A_fn_class; if fncls__438 == nil { var fncls__438d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1237, false); A_arbace_core_set_A_fn_class = fncls__438d; tmp3 = fncls__438d } else { tmp3 = fncls__438 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_896; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_897)); return A_arbace_core__init_A_const_896 }










func A_arbace_core__init_A_Unit464__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4145, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_898; var tmp2 any = A_arbace_core_filter_key_A_New(); var tmp3 *jrt.Class; var fncls__439 *jrt.Class = A_arbace_core_filter_key_A_fn_class; if fncls__439 == nil { var fncls__439d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1238, false); A_arbace_core_filter_key_A_fn_class = fncls__439d; tmp3 = fncls__439d } else { tmp3 = fncls__439 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_898; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_899)); return A_arbace_core__init_A_const_898 }









func A_arbace_core__init_A_Unit465__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4155, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_900; var tmp2 any = A_arbace_core_find_ns_A_New(); var tmp3 *jrt.Class; var fncls__440 *jrt.Class = A_arbace_core_find_ns_A_fn_class; if fncls__440 == nil { var fncls__440d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1239, false); A_arbace_core_find_ns_A_fn_class = fncls__440d; tmp3 = fncls__440d } else { tmp3 = fncls__440 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_900; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_901)); return A_arbace_core__init_A_const_900 }





func A_arbace_core__init_A_Unit466__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4161, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_902; var tmp2 any = A_arbace_core_create_ns_A_New(); var tmp3 *jrt.Class; var fncls__441 *jrt.Class = A_arbace_core_create_ns_A_fn_class; if fncls__441 == nil { var fncls__441d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1240, false); A_arbace_core_create_ns_A_fn_class = fncls__441d; tmp3 = fncls__441d } else { tmp3 = fncls__441 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_902; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_903)); return A_arbace_core__init_A_const_902 }







func A_arbace_core__init_A_Unit467__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4169, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_904; var tmp2 any = A_arbace_core_remove_ns_A_New(); var tmp3 *jrt.Class; var fncls__442 *jrt.Class = A_arbace_core_remove_ns_A_fn_class; if fncls__442 == nil { var fncls__442d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1241, false); A_arbace_core_remove_ns_A_fn_class = fncls__442d; tmp3 = fncls__442d } else { tmp3 = fncls__442 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_904; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_905)); return A_arbace_core__init_A_const_904 }






func A_arbace_core__init_A_Unit468__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4176, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_906; var tmp2 any = A_arbace_core_all_ns_A_New(); var tmp3 *jrt.Class; var fncls__443 *jrt.Class = A_arbace_core_all_ns_A_fn_class; if fncls__443 == nil { var fncls__443d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1242, false); A_arbace_core_all_ns_A_fn_class = fncls__443d; tmp3 = fncls__443d } else { tmp3 = fncls__443 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_906; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_907)); return A_arbace_core__init_A_const_906 }





func A_arbace_core__init_A_Unit469__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4182, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_908; var tmp2 any = A_arbace_core_the_ns_A_New(); var tmp3 *jrt.Class; var fncls__444 *jrt.Class = A_arbace_core_the_ns_A_fn_class; if fncls__444 == nil { var fncls__444d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1243, false); A_arbace_core_the_ns_A_fn_class = fncls__444d; tmp3 = fncls__444d } else { tmp3 = fncls__444 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_908; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_909)); return A_arbace_core__init_A_const_908 }










func A_arbace_core__init_A_Unit470__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4193, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_910; var tmp2 any = A_arbace_core_ns_name_A_New(); var tmp3 *jrt.Class; var fncls__445 *jrt.Class = A_arbace_core_ns_name_A_fn_class; if fncls__445 == nil { var fncls__445d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1244, false); A_arbace_core_ns_name_A_fn_class = fncls__445d; tmp3 = fncls__445d } else { tmp3 = fncls__445 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_910; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_911)); return A_arbace_core__init_A_const_910 }






func A_arbace_core__init_A_Unit471__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4200, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_912; var tmp2 any = A_arbace_core_ns_map_A_New(); var tmp3 *jrt.Class; var fncls__446 *jrt.Class = A_arbace_core_ns_map_A_fn_class; if fncls__446 == nil { var fncls__446d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1245, false); A_arbace_core_ns_map_A_fn_class = fncls__446d; tmp3 = fncls__446d } else { tmp3 = fncls__446 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_912; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_913)); return A_arbace_core__init_A_const_912 }






func A_arbace_core__init_A_Unit472__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4207, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_914; var tmp2 any = A_arbace_core_ns_unmap_A_New(); var tmp3 *jrt.Class; var fncls__447 *jrt.Class = A_arbace_core_ns_unmap_A_fn_class; if fncls__447 == nil { var fncls__447d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1246, false); A_arbace_core_ns_unmap_A_fn_class = fncls__447d; tmp3 = fncls__447d } else { tmp3 = fncls__447 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_914; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_915)); return A_arbace_core__init_A_const_914 }










func A_arbace_core__init_A_Unit473__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4218, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_916; var tmp2 any = A_arbace_core_ns_publics_A_New(); var tmp3 *jrt.Class; var fncls__448 *jrt.Class = A_arbace_core_ns_publics_A_fn_class; if fncls__448 == nil { var fncls__448d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1247, false); A_arbace_core_ns_publics_A_fn_class = fncls__448d; tmp3 = fncls__448d } else { tmp3 = fncls__448 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_916; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_917)); return A_arbace_core__init_A_const_916 }










func A_arbace_core__init_A_Unit474__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4229, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_918; var tmp2 any = A_arbace_core_ns_imports_A_New(); var tmp3 *jrt.Class; var fncls__449 *jrt.Class = A_arbace_core_ns_imports_A_fn_class; if fncls__449 == nil { var fncls__449d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1248, false); A_arbace_core_ns_imports_A_fn_class = fncls__449d; tmp3 = fncls__449d } else { tmp3 = fncls__449 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_918; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_919)); return A_arbace_core__init_A_const_918 }






func A_arbace_core__init_A_Unit475__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4236, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_920; var tmp2 any = A_arbace_core_ns_interns_A_New(); var tmp3 *jrt.Class; var fncls__450 *jrt.Class = A_arbace_core_ns_interns_A_fn_class; if fncls__450 == nil { var fncls__450d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1249, false); A_arbace_core_ns_interns_A_fn_class = fncls__450d; tmp3 = fncls__450d } else { tmp3 = fncls__450 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_920; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_921)); return A_arbace_core__init_A_const_920 }









func A_arbace_core__init_A_Unit476__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4246, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_922; var tmp2 any = A_arbace_core_refer_A_New(); var tmp3 *jrt.Class; var fncls__451 *jrt.Class = A_arbace_core_refer_A_fn_class; if fncls__451 == nil { var fncls__451d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1250, true); A_arbace_core_refer_A_fn_class = fncls__451d; tmp3 = fncls__451d } else { tmp3 = fncls__451 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_core__init_A_const_922; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_923)); return A_arbace_core__init_A_const_922 }




































func A_arbace_core__init_A_Unit477__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4283, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_924; var tmp2 any = A_arbace_core_ns_refers_A_New(); var tmp3 *jrt.Class; var fncls__452 *jrt.Class = A_arbace_core_ns_refers_A_fn_class; if fncls__452 == nil { var fncls__452d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1251, false); A_arbace_core_ns_refers_A_fn_class = fncls__452d; tmp3 = fncls__452d } else { tmp3 = fncls__452 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_924; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_925)); return A_arbace_core__init_A_const_924 }









func A_arbace_core__init_A_Unit478__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4293, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_926; var tmp2 any = A_arbace_core_alias_A_New(); var tmp3 *jrt.Class; var fncls__453 *jrt.Class = A_arbace_core_alias_A_fn_class; if fncls__453 == nil { var fncls__453d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1252, false); A_arbace_core_alias_A_fn_class = fncls__453d; tmp3 = fncls__453d } else { tmp3 = fncls__453 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_926; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_927)); return A_arbace_core__init_A_const_926 }









func A_arbace_core__init_A_Unit479__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4303, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_928; var tmp2 any = A_arbace_core_ns_aliases_A_New(); var tmp3 *jrt.Class; var fncls__454 *jrt.Class = A_arbace_core_ns_aliases_A_fn_class; if fncls__454 == nil { var fncls__454d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1253, false); A_arbace_core_ns_aliases_A_fn_class = fncls__454d; tmp3 = fncls__454d } else { tmp3 = fncls__454 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_928; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_929)); return A_arbace_core__init_A_const_928 }






func A_arbace_core__init_A_Unit480__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4310, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_930; var tmp2 any = A_arbace_core_ns_unalias_A_New(); var tmp3 *jrt.Class; var fncls__455 *jrt.Class = A_arbace_core_ns_unalias_A_fn_class; if fncls__455 == nil { var fncls__455d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1254, false); A_arbace_core_ns_unalias_A_fn_class = fncls__455d; tmp3 = fncls__455d } else { tmp3 = fncls__455 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_930; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_931)); return A_arbace_core__init_A_const_930 }






func A_arbace_core__init_A_Unit481__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4317, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_932; var tmp2 any = A_arbace_core_take_nth_A_New(); var tmp3 *jrt.Class; var fncls__456 *jrt.Class = A_arbace_core_take_nth_A_fn_class; if fncls__456 == nil { var fncls__456d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1255, false); A_arbace_core_take_nth_A_fn_class = fncls__456d; tmp3 = fncls__456d } else { tmp3 = fncls__456 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_932; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_933)); return A_arbace_core__init_A_const_932 }




















func A_arbace_core__init_A_Unit482__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4338, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_934; var tmp2 any = A_arbace_core_interleave_A_New(); var tmp3 *jrt.Class; var fncls__457 *jrt.Class = A_arbace_core_interleave_A_fn_class; if fncls__457 == nil { var fncls__457d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1256, true); A_arbace_core_interleave_A_fn_class = fncls__457d; tmp3 = fncls__457d } else { tmp3 = fncls__457 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_934; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_935)); return A_arbace_core__init_A_const_934 }

















func A_arbace_core__init_A_Unit483__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4356, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_936; var tmp2 any = A_arbace_core_var_get_A_New(); var tmp3 *jrt.Class; var fncls__458 *jrt.Class = A_arbace_core_var_get_A_fn_class; if fncls__458 == nil { var fncls__458d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1257, false); A_arbace_core_var_get_A_fn_class = fncls__458d; tmp3 = fncls__458d } else { tmp3 = fncls__458 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_936; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_937)); return A_arbace_core__init_A_const_936 }





func A_arbace_core__init_A_Unit484__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4362, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_938; var tmp2 any = A_arbace_core_var_set_A_New(); var tmp3 *jrt.Class; var fncls__459 *jrt.Class = A_arbace_core_var_set_A_fn_class; if fncls__459 == nil { var fncls__459d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1258, false); A_arbace_core_var_set_A_fn_class = fncls__459d; tmp3 = fncls__459d } else { tmp3 = fncls__459 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_938; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_939)); return A_arbace_core__init_A_const_938 }






func A_arbace_core__init_A_Unit485__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4369, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_940; var tmp2 any = A_arbace_core_with_local_vars_A_New(); var tmp3 *jrt.Class; var fncls__460 *jrt.Class = A_arbace_core_with_local_vars_A_fn_class; if fncls__460 == nil { var fncls__460d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1259, true); A_arbace_core_with_local_vars_A_fn_class = fncls__460d; tmp3 = fncls__460d } else { tmp3 = fncls__460 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_940; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_941)); return A_arbace_core__init_A_const_940 }
//line :4369:1
func A_arbace_core__init_A_Unit486__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4369, 1); A_arbace_core__init_A_const_940.SetMacro__V(); return nil }
//line :4369:1
func A_arbace_core__init_A_Unit487__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4369, 1); return A_arbace_core__init_A_const_940 }


















func A_arbace_core__init_A_Unit488__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4388, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_942; var tmp2 any = A_arbace_core_ns_resolve_A_New(); var tmp3 *jrt.Class; var fncls__461 *jrt.Class = A_arbace_core_ns_resolve_A_fn_class; if fncls__461 == nil { var fncls__461d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1260, false); A_arbace_core_ns_resolve_A_fn_class = fncls__461d; tmp3 = fncls__461d } else { tmp3 = fncls__461 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_942; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_943)); return A_arbace_core__init_A_const_942 }












func A_arbace_core__init_A_Unit489__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4401, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_944; var tmp2 any = A_arbace_core_resolve_A_New(); var tmp3 *jrt.Class; var fncls__462 *jrt.Class = A_arbace_core_resolve_A_fn_class; if fncls__462 == nil { var fncls__462d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1261, false); A_arbace_core_resolve_A_fn_class = fncls__462d; tmp3 = fncls__462d } else { tmp3 = fncls__462 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_944; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_945)); return A_arbace_core__init_A_const_944 }






func A_arbace_core__init_A_Unit490__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4408, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_946; var tmp2 any = A_arbace_core_array_map_A_New(); var tmp3 *jrt.Class; var fncls__463 *jrt.Class = A_arbace_core_array_map_A_fn_class; if fncls__463 == nil { var fncls__463d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1262, true); A_arbace_core_array_map_A_fn_class = fncls__463d; tmp3 = fncls__463d } else { tmp3 = fncls__463 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_core__init_A_const_946; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_947)); return A_arbace_core__init_A_const_946 }











func A_arbace_core__init_A_Unit491__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4420, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_948; var tmp2 any = A_arbace_core_zipmap_A_New(); var tmp3 *jrt.Class; var fncls__464 *jrt.Class = A_arbace_core_zipmap_A_fn_class; if fncls__464 == nil { var fncls__464d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1263, false); A_arbace_core_zipmap_A_fn_class = fncls__464d; tmp3 = fncls__464d } else { tmp3 = fncls__464 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_948; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_949)); return A_arbace_core__init_A_const_948 }













func A_arbace_core__init_A_Unit492__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4434, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_950; var tmp2 any = A_arbace_core_repeatedly_A_New(); var tmp3 *jrt.Class; var fncls__465 *jrt.Class = A_arbace_core_repeatedly_A_fn_class; if fncls__465 == nil { var fncls__465d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1264, false); A_arbace_core_repeatedly_A_fn_class = fncls__465d; tmp3 = fncls__465d } else { tmp3 = fncls__465 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_950; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_951)); return A_arbace_core__init_A_const_950 }








func A_arbace_core__init_A_Unit493__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4443, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_952; var tmp2 any = A_arbace_core_counted_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__466 *jrt.Class = A_arbace_core_counted_QMARK__A_fn_class; if fncls__466 == nil { var fncls__466d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1265, false); A_arbace_core_counted_QMARK__A_fn_class = fncls__466d; tmp3 = fncls__466d } else { tmp3 = fncls__466 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_952; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_953)); return A_arbace_core__init_A_const_952 }





func A_arbace_core__init_A_Unit494__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4449, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_954; var tmp2 any = A_arbace_core_empty_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__467 *jrt.Class = A_arbace_core_empty_QMARK__A_fn_class; if fncls__467 == nil { var fncls__467d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1266, false); A_arbace_core_empty_QMARK__A_fn_class = fncls__467d; tmp3 = fncls__467d } else { tmp3 = fncls__467 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_954; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_955)); return A_arbace_core__init_A_const_954 }









func A_arbace_core__init_A_Unit495__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4459, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_956; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_957)); return A_arbace_core__init_A_const_956 }

func A_arbace_core__init_A_Unit496__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4461, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_958; var tmp2 any = A_arbace_core_some_vals_A_New(); var tmp3 *jrt.Class; var fncls__468 *jrt.Class = A_arbace_core_some_vals_A_fn_class; if fncls__468 == nil { var fncls__468d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1267, false); A_arbace_core_some_vals_A_fn_class = fncls__468d; tmp3 = fncls__468d } else { tmp3 = fncls__468 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_958; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_959)); return A_arbace_core__init_A_const_958 }










func A_arbace_core__init_A_Unit497__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4472, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_960; var tmp2 any = A_arbace_core_seq_to_map_for_destructuring_A_New(); var tmp3 *jrt.Class; var fncls__469 *jrt.Class = A_arbace_core_seq_to_map_for_destructuring_A_fn_class; if fncls__469 == nil { var fncls__469d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1268, false); A_arbace_core_seq_to_map_for_destructuring_A_fn_class = fncls__469d; tmp3 = fncls__469d } else { tmp3 = fncls__469 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_960; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_961)); return A_arbace_core__init_A_const_960 }









func A_arbace_core__init_A_Unit498__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4482, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_962; var tmp2 any = A_arbace_core_destvec_STAR__A_New(); var tmp3 *jrt.Class; var fncls__470 *jrt.Class = A_arbace_core_destvec_STAR__A_fn_class; if fncls__470 == nil { var fncls__470d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1269, false); A_arbace_core_destvec_STAR__A_fn_class = fncls__470d; tmp3 = fncls__470d } else { tmp3 = fncls__470 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_962; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_963)); return A_arbace_core__init_A_const_962 }




































func A_arbace_core__init_A_Unit499__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4519, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_964; var tmp2 any = A_arbace_core_destmap_STAR__A_New(); var tmp3 *jrt.Class; var fncls__471 *jrt.Class = A_arbace_core_destmap_STAR__A_fn_class; if fncls__471 == nil { var fncls__471d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1270, false); A_arbace_core_destmap_STAR__A_fn_class = fncls__471d; tmp3 = fncls__471d } else { tmp3 = fncls__471 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_964; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_965)); return A_arbace_core__init_A_const_964 }
































































































































































func A_arbace_core__init_A_Unit500__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4680, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_966; var tmp2 any = A_arbace_core_destructure_A_New(); var tmp3 *jrt.Class; var fncls__472 *jrt.Class = A_arbace_core_destructure_A_fn_class; if fncls__472 == nil { var fncls__472d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1271, false); A_arbace_core_destructure_A_fn_class = fncls__472d; tmp3 = fncls__472d } else { tmp3 = fncls__472 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_966; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_967)); return A_arbace_core__init_A_const_966 }












func A_arbace_core__init_A_Unit501__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4693, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_10; var tmp2 any = A_arbace_core_let_A_New(); var tmp3 *jrt.Class; var fncls__473 *jrt.Class = A_arbace_core_let_A_fn_class; if fncls__473 == nil { var fncls__473d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1272, true); A_arbace_core_let_A_fn_class = fncls__473d; tmp3 = fncls__473d } else { tmp3 = fncls__473 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_968)); return A_arbace_core__init_A_const_10 }
//line :4693:1
func A_arbace_core__init_A_Unit502__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4693, 1); A_arbace_core__init_A_const_10.SetMacro__V(); return nil }
//line :4693:1
func A_arbace_core__init_A_Unit503__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4693, 1); return A_arbace_core__init_A_const_10 }

















func A_arbace_core__init_A_Unit504__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4711, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_969; var tmp2 any = A_arbace_core_maybe_destructured_A_New(); var tmp3 *jrt.Class; var fncls__474 *jrt.Class = A_arbace_core_maybe_destructured_A_fn_class; if fncls__474 == nil { var fncls__474d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1273, false); A_arbace_core_maybe_destructured_A_fn_class = fncls__474d; tmp3 = fncls__474d } else { tmp3 = fncls__474 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_969; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_970)); return A_arbace_core__init_A_const_969 }


















func A_arbace_core__init_A_Unit505__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4730, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_14; var tmp2 any = A_arbace_core_fn_A_New(); var tmp3 *jrt.Class; var fncls__475 *jrt.Class = A_arbace_core_fn_A_fn_class; if fncls__475 == nil { var fncls__475d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1274, true); A_arbace_core_fn_A_fn_class = fncls__475d; tmp3 = fncls__475d } else { tmp3 = fncls__475 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_971)); return A_arbace_core__init_A_const_14 }
//line :4730:1
func A_arbace_core__init_A_Unit506__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4730, 1); A_arbace_core__init_A_const_14.SetMacro__V(); return nil }
//line :4730:1
func A_arbace_core__init_A_Unit507__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4730, 1); return A_arbace_core__init_A_const_14 }































































func A_arbace_core__init_A_Unit508__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4794, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_12; var tmp2 any = A_arbace_core_loop_A_New(); var tmp3 *jrt.Class; var fncls__476 *jrt.Class = A_arbace_core_loop_A_fn_class; if fncls__476 == nil { var fncls__476d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1275, true); A_arbace_core_loop_A_fn_class = fncls__476d; tmp3 = fncls__476d } else { tmp3 = fncls__476 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_972)); return A_arbace_core__init_A_const_12 }
//line :4794:1
func A_arbace_core__init_A_Unit509__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4794, 1); A_arbace_core__init_A_const_12.SetMacro__V(); return nil }
//line :4794:1
func A_arbace_core__init_A_Unit510__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4794, 1); return A_arbace_core__init_A_const_12 }
























func A_arbace_core__init_A_Unit511__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4819, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_973; var tmp2 any = A_arbace_core_when_first_A_New(); var tmp3 *jrt.Class; var fncls__477 *jrt.Class = A_arbace_core_when_first_A_fn_class; if fncls__477 == nil { var fncls__477d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1276, true); A_arbace_core_when_first_A_fn_class = fncls__477d; tmp3 = fncls__477d } else { tmp3 = fncls__477 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_973; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_974)); return A_arbace_core__init_A_const_973 }
//line :4819:1
func A_arbace_core__init_A_Unit512__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4819, 1); A_arbace_core__init_A_const_973.SetMacro__V(); return nil }
//line :4819:1
func A_arbace_core__init_A_Unit513__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4819, 1); return A_arbace_core__init_A_const_973 }













func A_arbace_core__init_A_Unit514__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4833, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_975; var tmp2 any = A_arbace_core_lazy_cat_A_New(); var tmp3 *jrt.Class; var fncls__478 *jrt.Class = A_arbace_core_lazy_cat_A_fn_class; if fncls__478 == nil { var fncls__478d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1277, true); A_arbace_core_lazy_cat_A_fn_class = fncls__478d; tmp3 = fncls__478d } else { tmp3 = fncls__478 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_975; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_976)); return A_arbace_core__init_A_const_975 }
//line :4833:1
func A_arbace_core__init_A_Unit515__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4833, 1); A_arbace_core__init_A_const_975.SetMacro__V(); return nil }
//line :4833:1
func A_arbace_core__init_A_Unit516__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4833, 1); return A_arbace_core__init_A_const_975 }









func A_arbace_core__init_A_Unit517__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4843, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_977; var tmp2 any = A_arbace_core_for_A_New(); var tmp3 *jrt.Class; var fncls__479 *jrt.Class = A_arbace_core_for_A_fn_class; if fncls__479 == nil { var fncls__479d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1278, false); A_arbace_core_for_A_fn_class = fncls__479d; tmp3 = fncls__479d } else { tmp3 = fncls__479 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_977; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_978)); return A_arbace_core__init_A_const_977 }
//line :4843:1
func A_arbace_core__init_A_Unit518__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4843, 1); A_arbace_core__init_A_const_977.SetMacro__V(); return nil }
//line :4843:1
func A_arbace_core__init_A_Unit519__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4843, 1); return A_arbace_core__init_A_const_977 }






















































































func A_arbace_core__init_A_Unit520__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4930, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_979; var tmp2 any = A_arbace_core_comment_A_New(); var tmp3 *jrt.Class; var fncls__480 *jrt.Class = A_arbace_core_comment_A_fn_class; if fncls__480 == nil { var fncls__480d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1279, true); A_arbace_core_comment_A_fn_class = fncls__480d; tmp3 = fncls__480d } else { tmp3 = fncls__480 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_979; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_980)); return A_arbace_core__init_A_const_979 }
//line :4930:1
func A_arbace_core__init_A_Unit521__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4930, 1); A_arbace_core__init_A_const_979.SetMacro__V(); return nil }
//line :4930:1
func A_arbace_core__init_A_Unit522__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4930, 1); return A_arbace_core__init_A_const_979 }




func A_arbace_core__init_A_Unit523__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4935, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_981; var tmp2 any = A_arbace_core_with_out_str_A_New(); var tmp3 *jrt.Class; var fncls__481 *jrt.Class = A_arbace_core_with_out_str_A_fn_class; if fncls__481 == nil { var fncls__481d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1280, true); A_arbace_core_with_out_str_A_fn_class = fncls__481d; tmp3 = fncls__481d } else { tmp3 = fncls__481 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_981; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_982)); return A_arbace_core__init_A_const_981 }
//line :4935:1
func A_arbace_core__init_A_Unit524__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4935, 1); A_arbace_core__init_A_const_981.SetMacro__V(); return nil }
//line :4935:1
func A_arbace_core__init_A_Unit525__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4935, 1); return A_arbace_core__init_A_const_981 }










func A_arbace_core__init_A_Unit526__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4946, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_983; var tmp2 any = A_arbace_core_with_in_str_A_New(); var tmp3 *jrt.Class; var fncls__482 *jrt.Class = A_arbace_core_with_in_str_A_fn_class; if fncls__482 == nil { var fncls__482d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1281, true); A_arbace_core_with_in_str_A_fn_class = fncls__482d; tmp3 = fncls__482d } else { tmp3 = fncls__482 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_983; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_984)); return A_arbace_core__init_A_const_983 }
//line :4946:1
func A_arbace_core__init_A_Unit527__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4946, 1); A_arbace_core__init_A_const_983.SetMacro__V(); return nil }
//line :4946:1
func A_arbace_core__init_A_Unit528__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4946, 1); return A_arbace_core__init_A_const_983 }








func A_arbace_core__init_A_Unit529__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4955, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_985; var tmp2 any = A_arbace_core_pr_str_A_New(); var tmp3 *jrt.Class; var fncls__483 *jrt.Class = A_arbace_core_pr_str_A_fn_class; if fncls__483 == nil { var fncls__483d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1282, true); A_arbace_core_pr_str_A_fn_class = fncls__483d; tmp3 = fncls__483d } else { tmp3 = fncls__483 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_core__init_A_const_985; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_986)); return A_arbace_core__init_A_const_985 }








func A_arbace_core__init_A_Unit530__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4964, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_987; var tmp2 any = A_arbace_core_prn_str_A_New(); var tmp3 *jrt.Class; var fncls__484 *jrt.Class = A_arbace_core_prn_str_A_fn_class; if fncls__484 == nil { var fncls__484d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1283, true); A_arbace_core_prn_str_A_fn_class = fncls__484d; tmp3 = fncls__484d } else { tmp3 = fncls__484 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_core__init_A_const_987; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_988)); return A_arbace_core__init_A_const_987 }








func A_arbace_core__init_A_Unit531__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4973, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_989; var tmp2 any = A_arbace_core_print_str_A_New(); var tmp3 *jrt.Class; var fncls__485 *jrt.Class = A_arbace_core_print_str_A_fn_class; if fncls__485 == nil { var fncls__485d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1284, true); A_arbace_core_print_str_A_fn_class = fncls__485d; tmp3 = fncls__485d } else { tmp3 = fncls__485 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_core__init_A_const_989; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_990)); return A_arbace_core__init_A_const_989 }








func A_arbace_core__init_A_Unit532__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4982, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_991; var tmp2 any = A_arbace_core_println_str_A_New(); var tmp3 *jrt.Class; var fncls__486 *jrt.Class = A_arbace_core_println_str_A_fn_class; if fncls__486 == nil { var fncls__486d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1285, true); A_arbace_core_println_str_A_fn_class = fncls__486d; tmp3 = fncls__486d } else { tmp3 = fncls__486 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_core__init_A_const_991; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_992)); return A_arbace_core__init_A_const_991 }








func A_arbace_core__init_A_Unit533__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4991, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_1286)); return nil }
//line :4991:1
func A_arbace_core__init_A_Unit534__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4991, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_1287)); return nil }

func A_arbace_core__init_A_Unit535__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4993, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_993; var tmp2 any = A_arbace_core_elide_top_frames_A_New(); var tmp3 *jrt.Class; var fncls__487 *jrt.Class = A_arbace_core_elide_top_frames_A_fn_class; if fncls__487 == nil { var fncls__487d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1288, false); A_arbace_core_elide_top_frames_A_fn_class = fncls__487d; tmp3 = fncls__487d } else { tmp3 = fncls__487 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_993; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_994)); return A_arbace_core__init_A_const_993 }








func A_arbace_core__init_A_Unit536__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5002, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_995; var tmp2 any = A_arbace_core_ex_info_A_New(); var tmp3 *jrt.Class; var fncls__488 *jrt.Class = A_arbace_core_ex_info_A_fn_class; if fncls__488 == nil { var fncls__488d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_332, false); A_arbace_core_ex_info_A_fn_class = fncls__488d; tmp3 = fncls__488d } else { tmp3 = fncls__488 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_995; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_996)); return A_arbace_core__init_A_const_995 }








func A_arbace_core__init_A_Unit537__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5011, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_997; var tmp2 any = A_arbace_core_ex_data_A_New(); var tmp3 *jrt.Class; var fncls__489 *jrt.Class = A_arbace_core_ex_data_A_fn_class; if fncls__489 == nil { var fncls__489d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1289, false); A_arbace_core_ex_data_A_fn_class = fncls__489d; tmp3 = fncls__489d } else { tmp3 = fncls__489 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_997; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_998)); return A_arbace_core__init_A_const_997 }







func A_arbace_core__init_A_Unit538__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5019, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_999; var tmp2 any = A_arbace_core_ex_message_A_New(); var tmp3 *jrt.Class; var fncls__490 *jrt.Class = A_arbace_core_ex_message_A_fn_class; if fncls__490 == nil { var fncls__490d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1290, false); A_arbace_core_ex_message_A_fn_class = fncls__490d; tmp3 = fncls__490d } else { tmp3 = fncls__490 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_999; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1000)); return A_arbace_core__init_A_const_999 }







func A_arbace_core__init_A_Unit539__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5027, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1001; var tmp2 any = A_arbace_core_ex_cause_A_New(); var tmp3 *jrt.Class; var fncls__491 *jrt.Class = A_arbace_core_ex_cause_A_fn_class; if fncls__491 == nil { var fncls__491d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1291, false); A_arbace_core_ex_cause_A_fn_class = fncls__491d; tmp3 = fncls__491d } else { tmp3 = fncls__491 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1001; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1002)); return A_arbace_core__init_A_const_1001 }








func A_arbace_core__init_A_Unit540__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5036, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1003; var tmp2 any = A_arbace_core_assert_A_New(); var tmp3 *jrt.Class; var fncls__492 *jrt.Class = A_arbace_core_assert_A_fn_class; if fncls__492 == nil { var fncls__492d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1292, false); A_arbace_core_assert_A_fn_class = fncls__492d; tmp3 = fncls__492d } else { tmp3 = fncls__492 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1003; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1004)); return A_arbace_core__init_A_const_1003 }
//line :5036:1
func A_arbace_core__init_A_Unit541__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5036, 1); A_arbace_core__init_A_const_1003.SetMacro__V(); return nil }
//line :5036:1
func A_arbace_core__init_A_Unit542__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5036, 1); return A_arbace_core__init_A_const_1003 }















func A_arbace_core__init_A_Unit543__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5052, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1005; var tmp2 any = A_arbace_core_test_A_New(); var tmp3 *jrt.Class; var fncls__493 *jrt.Class = A_arbace_core_test_A_fn_class; if fncls__493 == nil { var fncls__493d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1293, false); A_arbace_core_test_A_fn_class = fncls__493d; tmp3 = fncls__493d } else { tmp3 = fncls__493 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1005; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1006)); return A_arbace_core__init_A_const_1005 }









func A_arbace_core__init_A_Unit544__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5062, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1007; var tmp2 any = A_arbace_core_re_pattern_A_New(); var tmp3 *jrt.Class; var fncls__494 *jrt.Class = A_arbace_core_re_pattern_A_fn_class; if fncls__494 == nil { var fncls__494d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1294, false); A_arbace_core_re_pattern_A_fn_class = fncls__494d; tmp3 = fncls__494d } else { tmp3 = fncls__494 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1007; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1008)); return A_arbace_core__init_A_const_1007 }









func A_arbace_core__init_A_Unit545__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5072, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1009; var tmp2 any = A_arbace_core_re_matcher_A_New(); var tmp3 *jrt.Class; var fncls__495 *jrt.Class = A_arbace_core_re_matcher_A_fn_class; if fncls__495 == nil { var fncls__495d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1295, false); A_arbace_core_re_matcher_A_fn_class = fncls__495d; tmp3 = fncls__495d } else { tmp3 = fncls__495 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1009; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1010)); return A_arbace_core__init_A_const_1009 }








func A_arbace_core__init_A_Unit546__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5081, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1011; var tmp2 any = A_arbace_core_re_groups_A_New(); var tmp3 *jrt.Class; var fncls__496 *jrt.Class = A_arbace_core_re_groups_A_fn_class; if fncls__496 == nil { var fncls__496d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1296, false); A_arbace_core_re_groups_A_fn_class = fncls__496d; tmp3 = fncls__496d } else { tmp3 = fncls__496 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1011; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1012)); return A_arbace_core__init_A_const_1011 }















func A_arbace_core__init_A_Unit547__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5097, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1013; var tmp2 any = A_arbace_core_re_seq_A_New(); var tmp3 *jrt.Class; var fncls__497 *jrt.Class = A_arbace_core_re_seq_A_fn_class; if fncls__497 == nil { var fncls__497d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1297, false); A_arbace_core_re_seq_A_fn_class = fncls__497d; tmp3 = fncls__497d } else { tmp3 = fncls__497 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1013; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1014)); return A_arbace_core__init_A_const_1013 }











func A_arbace_core__init_A_Unit548__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5109, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1015; var tmp2 any = A_arbace_core_re_matches_A_New(); var tmp3 *jrt.Class; var fncls__498 *jrt.Class = A_arbace_core_re_matches_A_fn_class; if fncls__498 == nil { var fncls__498d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1298, false); A_arbace_core_re_matches_A_fn_class = fncls__498d; tmp3 = fncls__498d } else { tmp3 = fncls__498 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1015; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1016)); return A_arbace_core__init_A_const_1015 }










func A_arbace_core__init_A_Unit549__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5120, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1017; var tmp2 any = A_arbace_core_re_find_A_New(); var tmp3 *jrt.Class; var fncls__499 *jrt.Class = A_arbace_core_re_find_A_fn_class; if fncls__499 == nil { var fncls__499d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1299, false); A_arbace_core_re_find_A_fn_class = fncls__499d; tmp3 = fncls__499d } else { tmp3 = fncls__499 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1017; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1018)); return A_arbace_core__init_A_const_1017 }












func A_arbace_core__init_A_Unit550__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5133, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1019; var tmp2 any = A_arbace_core_rand_A_New(); var tmp3 *jrt.Class; var fncls__500 *jrt.Class = A_arbace_core_rand_A_fn_class; if fncls__500 == nil { var fncls__500d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1300, false); A_arbace_core_rand_A_fn_class = fncls__500d; tmp3 = fncls__500d } else { tmp3 = fncls__500 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1019; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1020)); return A_arbace_core__init_A_const_1019 }







func A_arbace_core__init_A_Unit551__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5141, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1021; var tmp2 any = A_arbace_core_rand_int_A_New(); var tmp3 *jrt.Class; var fncls__501 *jrt.Class = A_arbace_core_rand_int_A_fn_class; if fncls__501 == nil { var fncls__501d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1301, false); A_arbace_core_rand_int_A_fn_class = fncls__501d; tmp3 = fncls__501d } else { tmp3 = fncls__501 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1021; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1022)); return A_arbace_core__init_A_const_1021 }





func A_arbace_core__init_A_Unit552__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5147, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1023; var tmp2 any = A_arbace_core_defn__A_New(); var tmp3 *jrt.Class; var fncls__502 *jrt.Class = A_arbace_core_defn__A_fn_class; if fncls__502 == nil { var fncls__502d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1302, true); A_arbace_core_defn__A_fn_class = fncls__502d; tmp3 = fncls__502d } else { tmp3 = fncls__502 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1023; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1024)); return A_arbace_core__init_A_const_1023 }
//line :5147:1
func A_arbace_core__init_A_Unit553__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5147, 1); A_arbace_core__init_A_const_1023.SetMacro__V(); return nil }
//line :5147:1
func A_arbace_core__init_A_Unit554__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5147, 1); return A_arbace_core__init_A_const_1023 }





func A_arbace_core__init_A_Unit555__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5153, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1025; var tmp2 any = A_arbace_core_tree_seq_A_New(); var tmp3 *jrt.Class; var fncls__503 *jrt.Class = A_arbace_core_tree_seq_A_fn_class; if fncls__503 == nil { var fncls__503d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1303, false); A_arbace_core_tree_seq_A_fn_class = fncls__503d; tmp3 = fncls__503d } else { tmp3 = fncls__503 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1025; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1026)); return A_arbace_core__init_A_const_1025 }
















func A_arbace_core__init_A_Unit556__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5170, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1027; var tmp2 any = A_arbace_core_file_seq_A_New(); var tmp3 *jrt.Class; var fncls__504 *jrt.Class = A_arbace_core_file_seq_A_fn_class; if fncls__504 == nil { var fncls__504d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1304, false); A_arbace_core_file_seq_A_fn_class = fncls__504d; tmp3 = fncls__504d } else { tmp3 = fncls__504 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1027; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1028)); return A_arbace_core__init_A_const_1027 }









func A_arbace_core__init_A_Unit557__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5180, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1029; var tmp2 any = A_arbace_core_xml_seq_A_New(); var tmp3 *jrt.Class; var fncls__505 *jrt.Class = A_arbace_core_xml_seq_A_fn_class; if fncls__505 == nil { var fncls__505d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1305, false); A_arbace_core_xml_seq_A_fn_class = fncls__505d; tmp3 = fncls__505d } else { tmp3 = fncls__505 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1029; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1030)); return A_arbace_core__init_A_const_1029 }









func A_arbace_core__init_A_Unit558__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5190, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1031; var tmp2 any = A_arbace_core_special_symbol_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__506 *jrt.Class = A_arbace_core_special_symbol_QMARK__A_fn_class; if fncls__506 == nil { var fncls__506d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1306, false); A_arbace_core_special_symbol_QMARK__A_fn_class = fncls__506d; tmp3 = fncls__506d } else { tmp3 = fncls__506 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1031; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1032)); return A_arbace_core__init_A_const_1031 }






func A_arbace_core__init_A_Unit559__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5197, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1033; var tmp2 any = A_arbace_core_var_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__507 *jrt.Class = A_arbace_core_var_QMARK__A_fn_class; if fncls__507 == nil { var fncls__507d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1307, false); A_arbace_core_var_QMARK__A_fn_class = fncls__507d; tmp3 = fncls__507d } else { tmp3 = fncls__507 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1033; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1034)); return A_arbace_core__init_A_const_1033 }





func A_arbace_core__init_A_Unit560__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5203, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1035; var tmp2 any = A_arbace_core_subs_A_New(); var tmp3 *jrt.Class; var fncls__508 *jrt.Class = A_arbace_core_subs_A_fn_class; if fncls__508 == nil { var fncls__508d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1308, false); A_arbace_core_subs_A_fn_class = fncls__508d; tmp3 = fncls__508d } else { tmp3 = fncls__508 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1035; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1036)); return A_arbace_core__init_A_const_1035 }







func A_arbace_core__init_A_Unit561__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5211, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1037; var tmp2 any = A_arbace_core_max_key_A_New(); var tmp3 *jrt.Class; var fncls__509 *jrt.Class = A_arbace_core_max_key_A_fn_class; if fncls__509 == nil { var fncls__509d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1309, true); A_arbace_core_max_key_A_fn_class = fncls__509d; tmp3 = fncls__509d } else { tmp3 = fncls__509 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1037; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1038)); return A_arbace_core__init_A_const_1037 }



















func A_arbace_core__init_A_Unit562__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5231, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1039; var tmp2 any = A_arbace_core_min_key_A_New(); var tmp3 *jrt.Class; var fncls__510 *jrt.Class = A_arbace_core_min_key_A_fn_class; if fncls__510 == nil { var fncls__510d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1310, true); A_arbace_core_min_key_A_fn_class = fncls__510d; tmp3 = fncls__510d } else { tmp3 = fncls__510 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1039; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1040)); return A_arbace_core__init_A_const_1039 }



















func A_arbace_core__init_A_Unit563__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5251, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1041; var tmp2 any = A_arbace_core_distinct_A_New(); var tmp3 *jrt.Class; var fncls__511 *jrt.Class = A_arbace_core_distinct_A_fn_class; if fncls__511 == nil { var fncls__511d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1311, false); A_arbace_core_distinct_A_fn_class = fncls__511d; tmp3 = fncls__511d } else { tmp3 = fncls__511 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1041; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1042)); return A_arbace_core__init_A_const_1041 }


























func A_arbace_core__init_A_Unit564__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5278, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1043; var tmp2 any = A_arbace_core_replace_A_New(); var tmp3 *jrt.Class; var fncls__512 *jrt.Class = A_arbace_core_replace_A_fn_class; if fncls__512 == nil { var fncls__512d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1312, false); A_arbace_core_replace_A_fn_class = fncls__512d; tmp3 = fncls__512d } else { tmp3 = fncls__512 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1043; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1044)); return A_arbace_core__init_A_const_1043 }

















func A_arbace_core__init_A_Unit565__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5296, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1045; var tmp2 any = A_arbace_core_dosync_A_New(); var tmp3 *jrt.Class; var fncls__513 *jrt.Class = A_arbace_core_dosync_A_fn_class; if fncls__513 == nil { var fncls__513d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1313, true); A_arbace_core_dosync_A_fn_class = fncls__513d; tmp3 = fncls__513d } else { tmp3 = fncls__513 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1045; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1046)); return A_arbace_core__init_A_const_1045 }
//line :5296:1
func A_arbace_core__init_A_Unit566__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5296, 1); A_arbace_core__init_A_const_1045.SetMacro__V(); return nil }
//line :5296:1
func A_arbace_core__init_A_Unit567__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5296, 1); return A_arbace_core__init_A_const_1045 }









func A_arbace_core__init_A_Unit568__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5306, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1047; var tmp2 any = A_arbace_core_with_precision_A_New(); var tmp3 *jrt.Class; var fncls__514 *jrt.Class = A_arbace_core_with_precision_A_fn_class; if fncls__514 == nil { var fncls__514d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1314, true); A_arbace_core_with_precision_A_fn_class = fncls__514d; tmp3 = fncls__514d } else { tmp3 = fncls__514 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1047; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1048)); return A_arbace_core__init_A_const_1047 }
//line :5306:1
func A_arbace_core__init_A_Unit569__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5306, 1); A_arbace_core__init_A_const_1047.SetMacro__V(); return nil }
//line :5306:1
func A_arbace_core__init_A_Unit570__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5306, 1); return A_arbace_core__init_A_const_1047 }
















func A_arbace_core__init_A_Unit571__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5323, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1049; var tmp2 any = A_arbace_core_mk_bound_fn_A_New(); var tmp3 *jrt.Class; var fncls__515 *jrt.Class = A_arbace_core_mk_bound_fn_A_fn_class; if fncls__515 == nil { var fncls__515d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1315, false); A_arbace_core_mk_bound_fn_A_fn_class = fncls__515d; tmp3 = fncls__515d } else { tmp3 = fncls__515 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1049; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1050)); return A_arbace_core__init_A_const_1049 }





func A_arbace_core__init_A_Unit572__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5329, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1051; var tmp2 any = A_arbace_core_subseq_A_New(); var tmp3 *jrt.Class; var fncls__516 *jrt.Class = A_arbace_core_subseq_A_fn_class; if fncls__516 == nil { var fncls__516d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1316, false); A_arbace_core_subseq_A_fn_class = fncls__516d; tmp3 = fncls__516d } else { tmp3 = fncls__516 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1051; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1052)); return A_arbace_core__init_A_const_1051 }
















func A_arbace_core__init_A_Unit573__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5346, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1053; var tmp2 any = A_arbace_core_rsubseq_A_New(); var tmp3 *jrt.Class; var fncls__517 *jrt.Class = A_arbace_core_rsubseq_A_fn_class; if fncls__517 == nil { var fncls__517d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1317, false); A_arbace_core_rsubseq_A_fn_class = fncls__517d; tmp3 = fncls__517d } else { tmp3 = fncls__517 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1053; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1054)); return A_arbace_core__init_A_const_1053 }
















func A_arbace_core__init_A_Unit574__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5363, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1055; var tmp2 any = A_arbace_core_add_classpath_A_New(); var tmp3 *jrt.Class; var fncls__518 *jrt.Class = A_arbace_core_add_classpath_A_fn_class; if fncls__518 == nil { var fncls__518d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1318, false); A_arbace_core_add_classpath_A_fn_class = fncls__518d; tmp3 = fncls__518d } else { tmp3 = fncls__518 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1055; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1056)); return A_arbace_core__init_A_const_1055 }










func A_arbace_core__init_A_Unit575__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5374, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1057; var tmp2 any = A_arbace_core_hash_A_New(); var tmp3 *jrt.Class; var fncls__519 *jrt.Class = A_arbace_core_hash_A_fn_class; if fncls__519 == nil { var fncls__519d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1319, false); A_arbace_core_hash_A_fn_class = fncls__519d; tmp3 = fncls__519d } else { tmp3 = fncls__519 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1057; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1058)); return A_arbace_core__init_A_const_1057 }








func A_arbace_core__init_A_Unit576__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5383, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1059; var tmp2 any = A_arbace_core_mix_collection_hash_A_New(); var tmp3 *jrt.Class; var fncls__520 *jrt.Class = A_arbace_core_mix_collection_hash_A_fn_class; if fncls__520 == nil { var fncls__520d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1320, false); A_arbace_core_mix_collection_hash_A_fn_class = fncls__520d; tmp3 = fncls__520d } else { tmp3 = fncls__520 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1059; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1060)); return A_arbace_core__init_A_const_1059 }










func A_arbace_core__init_A_Unit577__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5394, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1061; var tmp2 any = A_arbace_core_hash_ordered_coll_A_New(); var tmp3 *jrt.Class; var fncls__521 *jrt.Class = A_arbace_core_hash_ordered_coll_A_fn_class; if fncls__521 == nil { var fncls__521d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1321, false); A_arbace_core_hash_ordered_coll_A_fn_class = fncls__521d; tmp3 = fncls__521d } else { tmp3 = fncls__521 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1061; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1062)); return A_arbace_core__init_A_const_1061 }








func A_arbace_core__init_A_Unit578__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5403, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1063; var tmp2 any = A_arbace_core_hash_unordered_coll_A_New(); var tmp3 *jrt.Class; var fncls__522 *jrt.Class = A_arbace_core_hash_unordered_coll_A_fn_class; if fncls__522 == nil { var fncls__522d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1322, false); A_arbace_core_hash_unordered_coll_A_fn_class = fncls__522d; tmp3 = fncls__522d } else { tmp3 = fncls__522 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1063; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1064)); return A_arbace_core__init_A_const_1063 }










func A_arbace_core__init_A_Unit579__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5414, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1065; var tmp2 any = A_arbace_core_interpose_A_New(); var tmp3 *jrt.Class; var fncls__523 *jrt.Class = A_arbace_core_interpose_A_fn_class; if fncls__523 == nil { var fncls__523d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1323, false); A_arbace_core_interpose_A_fn_class = fncls__523d; tmp3 = fncls__523d } else { tmp3 = fncls__523 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1065; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1066)); return A_arbace_core__init_A_const_1065 }






















func A_arbace_core__init_A_Unit580__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5437, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1067; var tmp2 any = A_arbace_core_definline_A_New(); var tmp3 *jrt.Class; var fncls__524 *jrt.Class = A_arbace_core_definline_A_fn_class; if fncls__524 == nil { var fncls__524d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1324, true); A_arbace_core_definline_A_fn_class = fncls__524d; tmp3 = fncls__524d } else { tmp3 = fncls__524 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1067; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1068)); return A_arbace_core__init_A_const_1067 }
//line :5437:1
func A_arbace_core__init_A_Unit581__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5437, 1); A_arbace_core__init_A_const_1067.SetMacro__V(); return nil }
//line :5437:1
func A_arbace_core__init_A_Unit582__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5437, 1); return A_arbace_core__init_A_const_1067 }











func A_arbace_core__init_A_Unit583__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5449, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1069; var tmp2 any = A_arbace_core_empty_A_New(); var tmp3 *jrt.Class; var fncls__525 *jrt.Class = A_arbace_core_empty_A_fn_class; if fncls__525 == nil { var fncls__525d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1325, false); A_arbace_core_empty_A_fn_class = fncls__525d; tmp3 = fncls__525d } else { tmp3 = fncls__525 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1069; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1070)); return A_arbace_core__init_A_const_1069 }







func A_arbace_core__init_A_Unit584__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5457, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1071; var tmp2 any = A_arbace_core_amap_A_New(); var tmp3 *jrt.Class; var fncls__526 *jrt.Class = A_arbace_core_amap_A_fn_class; if fncls__526 == nil { var fncls__526d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1326, false); A_arbace_core_amap_A_fn_class = fncls__526d; tmp3 = fncls__526d } else { tmp3 = fncls__526 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1071; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1072)); return A_arbace_core__init_A_const_1071 }
//line :5457:1
func A_arbace_core__init_A_Unit585__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5457, 1); A_arbace_core__init_A_const_1071.SetMacro__V(); return nil }
//line :5457:1
func A_arbace_core__init_A_Unit586__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5457, 1); return A_arbace_core__init_A_const_1071 }















func A_arbace_core__init_A_Unit587__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5473, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1073; var tmp2 any = A_arbace_core_areduce_A_New(); var tmp3 *jrt.Class; var fncls__527 *jrt.Class = A_arbace_core_areduce_A_fn_class; if fncls__527 == nil { var fncls__527d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1327, false); A_arbace_core_areduce_A_fn_class = fncls__527d; tmp3 = fncls__527d } else { tmp3 = fncls__527 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1073; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1074)); return A_arbace_core__init_A_const_1073 }
//line :5473:1
func A_arbace_core__init_A_Unit588__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5473, 1); A_arbace_core__init_A_const_1073.SetMacro__V(); return nil }
//line :5473:1
func A_arbace_core__init_A_Unit589__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5473, 1); return A_arbace_core__init_A_const_1073 }











func A_arbace_core__init_A_Unit590__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5485, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1075; var tmp2 any = A_arbace_core_float_array_A_New(); var tmp3 *jrt.Class; var fncls__528 *jrt.Class = A_arbace_core_float_array_A_fn_class; if fncls__528 == nil { var fncls__528d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1328, false); A_arbace_core_float_array_A_fn_class = fncls__528d; tmp3 = fncls__528d } else { tmp3 = fncls__528 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1075; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_1076; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_float_array__inliner__1927001257_A_New(); var tmp10 *jrt.Class; var fncls__529 *jrt.Class = A_arbace_core_float_array__inliner__1927001257_A_fn_class; if fncls__529 == nil { var fncls__529d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1330, true); A_arbace_core_float_array__inliner__1927001257_A_fn_class = fncls__529d; tmp10 = fncls__529d } else { tmp10 = fncls__529 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_1329, tmp8, lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp9, tmp10, nil, 0), A_arbace_core__init_A_const_171, A_arbace_core__init_A_const_1077, A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_1078, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_1075 }







func A_arbace_core__init_A_Unit591__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5493, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1079; var tmp2 any = A_arbace_core_boolean_array_A_New(); var tmp3 *jrt.Class; var fncls__530 *jrt.Class = A_arbace_core_boolean_array_A_fn_class; if fncls__530 == nil { var fncls__530d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1331, false); A_arbace_core_boolean_array_A_fn_class = fncls__530d; tmp3 = fncls__530d } else { tmp3 = fncls__530 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1079; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_1080; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_boolean_array__inliner__1927001260_A_New(); var tmp10 *jrt.Class; var fncls__531 *jrt.Class = A_arbace_core_boolean_array__inliner__1927001260_A_fn_class; if fncls__531 == nil { var fncls__531d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1333, true); A_arbace_core_boolean_array__inliner__1927001260_A_fn_class = fncls__531d; tmp10 = fncls__531d } else { tmp10 = fncls__531 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_1332, tmp8, lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp9, tmp10, nil, 0), A_arbace_core__init_A_const_171, A_arbace_core__init_A_const_1081, A_arbace_core__init_A_const_54, Lit_1148, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_1082, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_1079 }







func A_arbace_core__init_A_Unit592__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5501, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1083; var tmp2 any = A_arbace_core_byte_array_A_New(); var tmp3 *jrt.Class; var fncls__532 *jrt.Class = A_arbace_core_byte_array_A_fn_class; if fncls__532 == nil { var fncls__532d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1334, false); A_arbace_core_byte_array_A_fn_class = fncls__532d; tmp3 = fncls__532d } else { tmp3 = fncls__532 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1083; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_1084; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_byte_array__inliner__1927001263_A_New(); var tmp10 *jrt.Class; var fncls__533 *jrt.Class = A_arbace_core_byte_array__inliner__1927001263_A_fn_class; if fncls__533 == nil { var fncls__533d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1336, true); A_arbace_core_byte_array__inliner__1927001263_A_fn_class = fncls__533d; tmp10 = fncls__533d } else { tmp10 = fncls__533 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_1335, tmp8, lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp9, tmp10, nil, 0), A_arbace_core__init_A_const_171, A_arbace_core__init_A_const_1085, A_arbace_core__init_A_const_54, Lit_1148, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_1086, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_1083 }







func A_arbace_core__init_A_Unit593__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5509, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1087; var tmp2 any = A_arbace_core_char_array_A_New(); var tmp3 *jrt.Class; var fncls__534 *jrt.Class = A_arbace_core_char_array_A_fn_class; if fncls__534 == nil { var fncls__534d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1337, false); A_arbace_core_char_array_A_fn_class = fncls__534d; tmp3 = fncls__534d } else { tmp3 = fncls__534 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1087; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_1088; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_char_array__inliner__1927001266_A_New(); var tmp10 *jrt.Class; var fncls__535 *jrt.Class = A_arbace_core_char_array__inliner__1927001266_A_fn_class; if fncls__535 == nil { var fncls__535d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1339, true); A_arbace_core_char_array__inliner__1927001266_A_fn_class = fncls__535d; tmp10 = fncls__535d } else { tmp10 = fncls__535 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_1338, tmp8, lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp9, tmp10, nil, 0), A_arbace_core__init_A_const_171, A_arbace_core__init_A_const_1089, A_arbace_core__init_A_const_54, Lit_1148, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_1090, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_1087 }







func A_arbace_core__init_A_Unit594__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5517, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1091; var tmp2 any = A_arbace_core_short_array_A_New(); var tmp3 *jrt.Class; var fncls__536 *jrt.Class = A_arbace_core_short_array_A_fn_class; if fncls__536 == nil { var fncls__536d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1340, false); A_arbace_core_short_array_A_fn_class = fncls__536d; tmp3 = fncls__536d } else { tmp3 = fncls__536 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1091; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_1092; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_short_array__inliner__1927001269_A_New(); var tmp10 *jrt.Class; var fncls__537 *jrt.Class = A_arbace_core_short_array__inliner__1927001269_A_fn_class; if fncls__537 == nil { var fncls__537d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1342, true); A_arbace_core_short_array__inliner__1927001269_A_fn_class = fncls__537d; tmp10 = fncls__537d } else { tmp10 = fncls__537 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_1341, tmp8, lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp9, tmp10, nil, 0), A_arbace_core__init_A_const_171, A_arbace_core__init_A_const_1093, A_arbace_core__init_A_const_54, Lit_1148, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_1094, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_1091 }







func A_arbace_core__init_A_Unit595__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5525, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1095; var tmp2 any = A_arbace_core_double_array_A_New(); var tmp3 *jrt.Class; var fncls__538 *jrt.Class = A_arbace_core_double_array_A_fn_class; if fncls__538 == nil { var fncls__538d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1343, false); A_arbace_core_double_array_A_fn_class = fncls__538d; tmp3 = fncls__538d } else { tmp3 = fncls__538 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1095; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_1096; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_double_array__inliner__1927001272_A_New(); var tmp10 *jrt.Class; var fncls__539 *jrt.Class = A_arbace_core_double_array__inliner__1927001272_A_fn_class; if fncls__539 == nil { var fncls__539d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1345, true); A_arbace_core_double_array__inliner__1927001272_A_fn_class = fncls__539d; tmp10 = fncls__539d } else { tmp10 = fncls__539 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_1344, tmp8, lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp9, tmp10, nil, 0), A_arbace_core__init_A_const_171, A_arbace_core__init_A_const_1097, A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_1098, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_1095 }







func A_arbace_core__init_A_Unit596__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5533, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1099; var tmp2 any = A_arbace_core_object_array_A_New(); var tmp3 *jrt.Class; var fncls__540 *jrt.Class = A_arbace_core_object_array_A_fn_class; if fncls__540 == nil { var fncls__540d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1346, false); A_arbace_core_object_array_A_fn_class = fncls__540d; tmp3 = fncls__540d } else { tmp3 = fncls__540 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1099; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_1100; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_object_array__inliner__1927001275_A_New(); var tmp10 *jrt.Class; var fncls__541 *jrt.Class = A_arbace_core_object_array__inliner__1927001275_A_fn_class; if fncls__541 == nil { var fncls__541d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1348, false); A_arbace_core_object_array__inliner__1927001275_A_fn_class = fncls__541d; tmp10 = fncls__541d } else { tmp10 = fncls__541 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_1347, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), A_arbace_core__init_A_const_171, A_arbace_core__init_A_const_1101, A_arbace_core__init_A_const_54, Lit_824, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_1102, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_1099 }






func A_arbace_core__init_A_Unit597__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5540, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1103; var tmp2 any = A_arbace_core_int_array_A_New(); var tmp3 *jrt.Class; var fncls__542 *jrt.Class = A_arbace_core_int_array_A_fn_class; if fncls__542 == nil { var fncls__542d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1349, false); A_arbace_core_int_array_A_fn_class = fncls__542d; tmp3 = fncls__542d } else { tmp3 = fncls__542 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1103; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_1104; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_int_array__inliner__1927001278_A_New(); var tmp10 *jrt.Class; var fncls__543 *jrt.Class = A_arbace_core_int_array__inliner__1927001278_A_fn_class; if fncls__543 == nil { var fncls__543d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1351, true); A_arbace_core_int_array__inliner__1927001278_A_fn_class = fncls__543d; tmp10 = fncls__543d } else { tmp10 = fncls__543 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_1350, tmp8, lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp9, tmp10, nil, 0), A_arbace_core__init_A_const_171, A_arbace_core__init_A_const_1105, A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_1106, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_1103 }







func A_arbace_core__init_A_Unit598__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5548, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1107; var tmp2 any = A_arbace_core_long_array_A_New(); var tmp3 *jrt.Class; var fncls__544 *jrt.Class = A_arbace_core_long_array_A_fn_class; if fncls__544 == nil { var fncls__544d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1352, false); A_arbace_core_long_array_A_fn_class = fncls__544d; tmp3 = fncls__544d } else { tmp3 = fncls__544 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1107; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_1108; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_56; var tmp9 any = A_arbace_core_long_array__inliner__1927001281_A_New(); var tmp10 *jrt.Class; var fncls__545 *jrt.Class = A_arbace_core_long_array__inliner__1927001281_A_fn_class; if fncls__545 == nil { var fncls__545d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1354, true); A_arbace_core_long_array__inliner__1927001281_A_fn_class = fncls__545d; tmp10 = fncls__545d } else { tmp10 = fncls__545 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_1353, tmp8, lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp9, tmp10, nil, 0), A_arbace_core__init_A_const_171, A_arbace_core__init_A_const_1109, A_arbace_core__init_A_const_54, Lit_734, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_1110, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_1107 }







func A_arbace_core__init_A_Unit599__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5556, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1111; var tmp2 any = A_arbace_core_booleans_A_New(); var tmp3 *jrt.Class; var fncls__546 *jrt.Class = A_arbace_core_booleans_A_fn_class; if fncls__546 == nil { var fncls__546d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1355, false); A_arbace_core_booleans_A_fn_class = fncls__546d; tmp3 = fncls__546d } else { tmp3 = fncls__546 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1111; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1112)); return A_arbace_core__init_A_const_1111 }
//line :5556:1
func A_arbace_core__init_A_Unit600__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5556, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_574.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1111; var tmp3 any = A_arbace_core__init_A_const_48.GetRawRoot__O(); var tmp4 any = A_arbace_core__init_A_const_56; var tmp5 any = A_arbace_core_eval1927001289_booleans__1927001290_A_New(); var tmp6 *jrt.Class; var fncls__547 *jrt.Class = A_arbace_core_eval1927001289_booleans__1927001290_A_fn_class; if fncls__547 == nil { var fncls__547d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1356, false); A_arbace_core_eval1927001289_booleans__1927001290_A_fn_class = fncls__547d; tmp6 = fncls__547d } else { tmp6 = fncls__547 }; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)) }
//line :5556:1
func A_arbace_core__init_A_Unit601__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5556, 1); return A_arbace_core__init_A_const_1111 }




func A_arbace_core__init_A_Unit602__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5561, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1113; var tmp2 any = A_arbace_core_bytes_A_New(); var tmp3 *jrt.Class; var fncls__548 *jrt.Class = A_arbace_core_bytes_A_fn_class; if fncls__548 == nil { var fncls__548d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1357, false); A_arbace_core_bytes_A_fn_class = fncls__548d; tmp3 = fncls__548d } else { tmp3 = fncls__548 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1113; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1114)); return A_arbace_core__init_A_const_1113 }
//line :5561:1
func A_arbace_core__init_A_Unit603__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5561, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_574.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1113; var tmp3 any = A_arbace_core__init_A_const_48.GetRawRoot__O(); var tmp4 any = A_arbace_core__init_A_const_56; var tmp5 any = A_arbace_core_eval1927001300_bytes__1927001301_A_New(); var tmp6 *jrt.Class; var fncls__549 *jrt.Class = A_arbace_core_eval1927001300_bytes__1927001301_A_fn_class; if fncls__549 == nil { var fncls__549d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1358, false); A_arbace_core_eval1927001300_bytes__1927001301_A_fn_class = fncls__549d; tmp6 = fncls__549d } else { tmp6 = fncls__549 }; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)) }
//line :5561:1
func A_arbace_core__init_A_Unit604__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5561, 1); return A_arbace_core__init_A_const_1113 }




func A_arbace_core__init_A_Unit605__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5566, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1115; var tmp2 any = A_arbace_core_chars_A_New(); var tmp3 *jrt.Class; var fncls__550 *jrt.Class = A_arbace_core_chars_A_fn_class; if fncls__550 == nil { var fncls__550d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1359, false); A_arbace_core_chars_A_fn_class = fncls__550d; tmp3 = fncls__550d } else { tmp3 = fncls__550 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1115; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1116)); return A_arbace_core__init_A_const_1115 }
//line :5566:1
func A_arbace_core__init_A_Unit606__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5566, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_574.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1115; var tmp3 any = A_arbace_core__init_A_const_48.GetRawRoot__O(); var tmp4 any = A_arbace_core__init_A_const_56; var tmp5 any = A_arbace_core_eval1927001311_chars__1927001312_A_New(); var tmp6 *jrt.Class; var fncls__551 *jrt.Class = A_arbace_core_eval1927001311_chars__1927001312_A_fn_class; if fncls__551 == nil { var fncls__551d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1360, false); A_arbace_core_eval1927001311_chars__1927001312_A_fn_class = fncls__551d; tmp6 = fncls__551d } else { tmp6 = fncls__551 }; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)) }
//line :5566:1
func A_arbace_core__init_A_Unit607__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5566, 1); return A_arbace_core__init_A_const_1115 }




func A_arbace_core__init_A_Unit608__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5571, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1117; var tmp2 any = A_arbace_core_shorts_A_New(); var tmp3 *jrt.Class; var fncls__552 *jrt.Class = A_arbace_core_shorts_A_fn_class; if fncls__552 == nil { var fncls__552d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1361, false); A_arbace_core_shorts_A_fn_class = fncls__552d; tmp3 = fncls__552d } else { tmp3 = fncls__552 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1117; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1118)); return A_arbace_core__init_A_const_1117 }
//line :5571:1
func A_arbace_core__init_A_Unit609__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5571, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_574.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1117; var tmp3 any = A_arbace_core__init_A_const_48.GetRawRoot__O(); var tmp4 any = A_arbace_core__init_A_const_56; var tmp5 any = A_arbace_core_eval1927001322_shorts__1927001323_A_New(); var tmp6 *jrt.Class; var fncls__553 *jrt.Class = A_arbace_core_eval1927001322_shorts__1927001323_A_fn_class; if fncls__553 == nil { var fncls__553d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1362, false); A_arbace_core_eval1927001322_shorts__1927001323_A_fn_class = fncls__553d; tmp6 = fncls__553d } else { tmp6 = fncls__553 }; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)) }
//line :5571:1
func A_arbace_core__init_A_Unit610__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5571, 1); return A_arbace_core__init_A_const_1117 }




func A_arbace_core__init_A_Unit611__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5576, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1119; var tmp2 any = A_arbace_core_floats_A_New(); var tmp3 *jrt.Class; var fncls__554 *jrt.Class = A_arbace_core_floats_A_fn_class; if fncls__554 == nil { var fncls__554d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1363, false); A_arbace_core_floats_A_fn_class = fncls__554d; tmp3 = fncls__554d } else { tmp3 = fncls__554 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1119; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1120)); return A_arbace_core__init_A_const_1119 }
//line :5576:1
func A_arbace_core__init_A_Unit612__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5576, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_574.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1119; var tmp3 any = A_arbace_core__init_A_const_48.GetRawRoot__O(); var tmp4 any = A_arbace_core__init_A_const_56; var tmp5 any = A_arbace_core_eval1927001333_floats__1927001334_A_New(); var tmp6 *jrt.Class; var fncls__555 *jrt.Class = A_arbace_core_eval1927001333_floats__1927001334_A_fn_class; if fncls__555 == nil { var fncls__555d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1364, false); A_arbace_core_eval1927001333_floats__1927001334_A_fn_class = fncls__555d; tmp6 = fncls__555d } else { tmp6 = fncls__555 }; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)) }
//line :5576:1
func A_arbace_core__init_A_Unit613__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5576, 1); return A_arbace_core__init_A_const_1119 }




func A_arbace_core__init_A_Unit614__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5581, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1121; var tmp2 any = A_arbace_core_ints_A_New(); var tmp3 *jrt.Class; var fncls__556 *jrt.Class = A_arbace_core_ints_A_fn_class; if fncls__556 == nil { var fncls__556d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1365, false); A_arbace_core_ints_A_fn_class = fncls__556d; tmp3 = fncls__556d } else { tmp3 = fncls__556 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1121; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1122)); return A_arbace_core__init_A_const_1121 }
//line :5581:1
func A_arbace_core__init_A_Unit615__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5581, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_574.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1121; var tmp3 any = A_arbace_core__init_A_const_48.GetRawRoot__O(); var tmp4 any = A_arbace_core__init_A_const_56; var tmp5 any = A_arbace_core_eval1927001344_ints__1927001345_A_New(); var tmp6 *jrt.Class; var fncls__557 *jrt.Class = A_arbace_core_eval1927001344_ints__1927001345_A_fn_class; if fncls__557 == nil { var fncls__557d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1366, false); A_arbace_core_eval1927001344_ints__1927001345_A_fn_class = fncls__557d; tmp6 = fncls__557d } else { tmp6 = fncls__557 }; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)) }
//line :5581:1
func A_arbace_core__init_A_Unit616__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5581, 1); return A_arbace_core__init_A_const_1121 }




func A_arbace_core__init_A_Unit617__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5586, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1123; var tmp2 any = A_arbace_core_doubles_A_New(); var tmp3 *jrt.Class; var fncls__558 *jrt.Class = A_arbace_core_doubles_A_fn_class; if fncls__558 == nil { var fncls__558d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1367, false); A_arbace_core_doubles_A_fn_class = fncls__558d; tmp3 = fncls__558d } else { tmp3 = fncls__558 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1123; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1124)); return A_arbace_core__init_A_const_1123 }
//line :5586:1
func A_arbace_core__init_A_Unit618__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5586, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_574.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1123; var tmp3 any = A_arbace_core__init_A_const_48.GetRawRoot__O(); var tmp4 any = A_arbace_core__init_A_const_56; var tmp5 any = A_arbace_core_eval1927001355_doubles__1927001356_A_New(); var tmp6 *jrt.Class; var fncls__559 *jrt.Class = A_arbace_core_eval1927001355_doubles__1927001356_A_fn_class; if fncls__559 == nil { var fncls__559d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1368, false); A_arbace_core_eval1927001355_doubles__1927001356_A_fn_class = fncls__559d; tmp6 = fncls__559d } else { tmp6 = fncls__559 }; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)) }
//line :5586:1
func A_arbace_core__init_A_Unit619__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5586, 1); return A_arbace_core__init_A_const_1123 }




func A_arbace_core__init_A_Unit620__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5591, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1125; var tmp2 any = A_arbace_core_longs_A_New(); var tmp3 *jrt.Class; var fncls__560 *jrt.Class = A_arbace_core_longs_A_fn_class; if fncls__560 == nil { var fncls__560d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1369, false); A_arbace_core_longs_A_fn_class = fncls__560d; tmp3 = fncls__560d } else { tmp3 = fncls__560 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1125; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1126)); return A_arbace_core__init_A_const_1125 }
//line :5591:1
func A_arbace_core__init_A_Unit621__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5591, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_574.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1125; var tmp3 any = A_arbace_core__init_A_const_48.GetRawRoot__O(); var tmp4 any = A_arbace_core__init_A_const_56; var tmp5 any = A_arbace_core_eval1927001366_longs__1927001367_A_New(); var tmp6 *jrt.Class; var fncls__561 *jrt.Class = A_arbace_core_eval1927001366_longs__1927001367_A_fn_class; if fncls__561 == nil { var fncls__561d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1370, false); A_arbace_core_eval1927001366_longs__1927001367_A_fn_class = fncls__561d; tmp6 = fncls__561d } else { tmp6 = fncls__561 }; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)) }
//line :5591:1
func A_arbace_core__init_A_Unit622__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5591, 1); return A_arbace_core__init_A_const_1125 }




func A_arbace_core__init_A_Unit623__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5596, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1127; var tmp2 any = A_arbace_core_bytes_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__562 *jrt.Class = A_arbace_core_bytes_QMARK__A_fn_class; if fncls__562 == nil { var fncls__562d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1371, false); A_arbace_core_bytes_QMARK__A_fn_class = fncls__562d; tmp3 = fncls__562d } else { tmp3 = fncls__562 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1127; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1128)); return A_arbace_core__init_A_const_1127 }






func A_arbace_core__init_A_Unit624__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5603, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_1372)); return nil }
//line :5603:1
func A_arbace_core__init_A_Unit625__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5603, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_1373)); return nil }

func A_arbace_core__init_A_Unit626__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5605, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1129; var tmp2 any = A_arbace_core_seque_A_New(); var tmp3 *jrt.Class; var fncls__563 *jrt.Class = A_arbace_core_seque_A_fn_class; if fncls__563 == nil { var fncls__563d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1374, false); A_arbace_core_seque_A_fn_class = fncls__563d; tmp3 = fncls__563d } else { tmp3 = fncls__563 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1129; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1130)); return A_arbace_core__init_A_const_1129 }













































func A_arbace_core__init_A_Unit627__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5651, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1131; var tmp2 any = A_arbace_core_class_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__564 *jrt.Class = A_arbace_core_class_QMARK__A_fn_class; if fncls__564 == nil { var fncls__564d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1375, false); A_arbace_core_class_QMARK__A_fn_class = fncls__564d; tmp3 = fncls__564d } else { tmp3 = fncls__564 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1131; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1132)); return A_arbace_core__init_A_const_1131 }





func A_arbace_core__init_A_Unit628__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5657, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1133; var tmp2 any = A_arbace_core_alter_var_root_A_New(); var tmp3 *jrt.Class; var fncls__565 *jrt.Class = A_arbace_core_alter_var_root_A_fn_class; if fncls__565 == nil { var fncls__565d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1376, true); A_arbace_core_alter_var_root_A_fn_class = fncls__565d; tmp3 = fncls__565d } else { tmp3 = fncls__565 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1133; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1134)); return A_arbace_core__init_A_const_1133 }






func A_arbace_core__init_A_Unit629__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5664, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1135; var tmp2 any = A_arbace_core_bound_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__566 *jrt.Class = A_arbace_core_bound_QMARK__A_fn_class; if fncls__566 == nil { var fncls__566d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1377, true); A_arbace_core_bound_QMARK__A_fn_class = fncls__566d; tmp3 = fncls__566d } else { tmp3 = fncls__566 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1135; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1136)); return A_arbace_core__init_A_const_1135 }







func A_arbace_core__init_A_Unit630__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5672, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1137; var tmp2 any = A_arbace_core_thread_bound_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__567 *jrt.Class = A_arbace_core_thread_bound_QMARK__A_fn_class; if fncls__567 == nil { var fncls__567d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1378, true); A_arbace_core_thread_bound_QMARK__A_fn_class = fncls__567d; tmp3 = fncls__567d } else { tmp3 = fncls__567 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1137; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1138)); return A_arbace_core__init_A_const_1137 }







func A_arbace_core__init_A_Unit631__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5680, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1139; var tmp2 any = A_arbace_core_make_hierarchy_A_New(); var tmp3 *jrt.Class; var fncls__568 *jrt.Class = A_arbace_core_make_hierarchy_A_fn_class; if fncls__568 == nil { var fncls__568d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1379, false); A_arbace_core_make_hierarchy_A_fn_class = fncls__568d; tmp3 = fncls__568d } else { tmp3 = fncls__568 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1139; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1140)); return A_arbace_core__init_A_const_1139 }





func A_arbace_core__init_A_Unit632__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5686, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_466; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_core__init_A_const_1139.GetRawRoot__O()).Invoke__O()); var tmp2 *lang.Var = A_arbace_core__init_A_const_466; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1141)); return A_arbace_core__init_A_const_466 }


func A_arbace_core__init_A_Unit633__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5689, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1142; var tmp2 any = A_arbace_core_not_empty_A_New(); var tmp3 *jrt.Class; var fncls__569 *jrt.Class = A_arbace_core_not_empty_A_fn_class; if fncls__569 == nil { var fncls__569d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1380, false); A_arbace_core_not_empty_A_fn_class = fncls__569d; tmp3 = fncls__569d } else { tmp3 = fncls__569 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1142; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1143)); return A_arbace_core__init_A_const_1142 }





func A_arbace_core__init_A_Unit634__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5695, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1144; var tmp2 any = A_arbace_core_bases_A_New(); var tmp3 *jrt.Class; var fncls__570 *jrt.Class = A_arbace_core_bases_A_fn_class; if fncls__570 == nil { var fncls__570d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1381, false); A_arbace_core_bases_A_fn_class = fncls__570d; tmp3 = fncls__570d } else { tmp3 = fncls__570 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1144; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1145)); return A_arbace_core__init_A_const_1144 }









func A_arbace_core__init_A_Unit635__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5705, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1146; var tmp2 any = A_arbace_core_supers_A_New(); var tmp3 *jrt.Class; var fncls__571 *jrt.Class = A_arbace_core_supers_A_fn_class; if fncls__571 == nil { var fncls__571d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1382, false); A_arbace_core_supers_A_fn_class = fncls__571d; tmp3 = fncls__571d } else { tmp3 = fncls__571 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1146; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1147)); return A_arbace_core__init_A_const_1146 }










func A_arbace_core__init_A_Unit636__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5716, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1148; var tmp2 any = A_arbace_core_isa_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__572 *jrt.Class = A_arbace_core_isa_QMARK__A_fn_class; if fncls__572 == nil { var fncls__572d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1383, false); A_arbace_core_isa_QMARK__A_fn_class = fncls__572d; tmp3 = fncls__572d } else { tmp3 = fncls__572 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1148; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1149)); return A_arbace_core__init_A_const_1148 }




















func A_arbace_core__init_A_Unit637__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5737, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1150; var tmp2 any = A_arbace_core_parents_A_New(); var tmp3 *jrt.Class; var fncls__573 *jrt.Class = A_arbace_core_parents_A_fn_class; if fncls__573 == nil { var fncls__573d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1384, false); A_arbace_core_parents_A_fn_class = fncls__573d; tmp3 = fncls__573d } else { tmp3 = fncls__573 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1150; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1151)); return A_arbace_core__init_A_const_1150 }












func A_arbace_core__init_A_Unit638__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5750, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1152; var tmp2 any = A_arbace_core_ancestors_A_New(); var tmp3 *jrt.Class; var fncls__574 *jrt.Class = A_arbace_core_ancestors_A_fn_class; if fncls__574 == nil { var fncls__574d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1385, false); A_arbace_core_ancestors_A_fn_class = fncls__574d; tmp3 = fncls__574d } else { tmp3 = fncls__574 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1152; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1153)); return A_arbace_core__init_A_const_1152 }















func A_arbace_core__init_A_Unit639__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5766, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1154; var tmp2 any = A_arbace_core_descendants_A_New(); var tmp3 *jrt.Class; var fncls__575 *jrt.Class = A_arbace_core_descendants_A_fn_class; if fncls__575 == nil { var fncls__575d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1386, false); A_arbace_core_descendants_A_fn_class = fncls__575d; tmp3 = fncls__575d } else { tmp3 = fncls__575 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1154; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1155)); return A_arbace_core__init_A_const_1154 }











func A_arbace_core__init_A_Unit640__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5778, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1156; var tmp2 any = A_arbace_core_derive_A_New(); var tmp3 *jrt.Class; var fncls__576 *jrt.Class = A_arbace_core_derive_A_fn_class; if fncls__576 == nil { var fncls__576d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1387, false); A_arbace_core_derive_A_fn_class = fncls__576d; tmp3 = fncls__576d } else { tmp3 = fncls__576 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1156; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1157)); return A_arbace_core__init_A_const_1156 }



































func A_arbace_core__init_A_Unit641__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5814, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1158; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1159)); return A_arbace_core__init_A_const_1158 }

func A_arbace_core__init_A_Unit642__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5816, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1160; var tmp2 any = A_arbace_core_underive_A_New(); var tmp3 *jrt.Class; var fncls__577 *jrt.Class = A_arbace_core_underive_A_fn_class; if fncls__577 == nil { var fncls__577d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1388, false); A_arbace_core_underive_A_fn_class = fncls__577d; tmp3 = fncls__577d } else { tmp3 = fncls__577 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1160; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1161)); return A_arbace_core__init_A_const_1160 }



















func A_arbace_core__init_A_Unit643__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5836, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1162; var tmp2 any = A_arbace_core_distinct_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__578 *jrt.Class = A_arbace_core_distinct_QMARK__A_fn_class; if fncls__578 == nil { var fncls__578d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1389, true); A_arbace_core_distinct_QMARK__A_fn_class = fncls__578d; tmp3 = fncls__578d } else { tmp3 = fncls__578 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1162; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1163)); return A_arbace_core__init_A_const_1162 }
















func A_arbace_core__init_A_Unit644__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5853, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1164; var tmp2 any = A_arbace_core_resultset_seq_A_New(); var tmp3 *jrt.Class; var fncls__579 *jrt.Class = A_arbace_core_resultset_seq_A_fn_class; if fncls__579 == nil { var fncls__579d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1390, false); A_arbace_core_resultset_seq_A_fn_class = fncls__579d; tmp3 = fncls__579d } else { tmp3 = fncls__579 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1164; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1165)); return A_arbace_core__init_A_const_1164 }


















func A_arbace_core__init_A_Unit645__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5872, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1166; var tmp2 any = A_arbace_core_iterator_seq_A_New(); var tmp3 *jrt.Class; var fncls__580 *jrt.Class = A_arbace_core_iterator_seq_A_fn_class; if fncls__580 == nil { var fncls__580d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1391, false); A_arbace_core_iterator_seq_A_fn_class = fncls__580d; tmp3 = fncls__580d } else { tmp3 = fncls__580 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1166; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1167)); return A_arbace_core__init_A_const_1166 }









func A_arbace_core__init_A_Unit646__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5882, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1168; var tmp2 any = A_arbace_core_enumeration_seq_A_New(); var tmp3 *jrt.Class; var fncls__581 *jrt.Class = A_arbace_core_enumeration_seq_A_fn_class; if fncls__581 == nil { var fncls__581d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1392, false); A_arbace_core_enumeration_seq_A_fn_class = fncls__581d; tmp3 = fncls__581d } else { tmp3 = fncls__581 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1168; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1169)); return A_arbace_core__init_A_const_1168 }






func A_arbace_core__init_A_Unit647__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5889, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1170; var tmp2 any = A_arbace_core_format_A_New(); var tmp3 *jrt.Class; var fncls__582 *jrt.Class = A_arbace_core_format_A_fn_class; if fncls__582 == nil { var fncls__582d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1393, true); A_arbace_core_format_A_fn_class = fncls__582d; tmp3 = fncls__582d } else { tmp3 = fncls__582 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1170; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1171)); return A_arbace_core__init_A_const_1170 }







func A_arbace_core__init_A_Unit648__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5897, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1172; var tmp2 any = A_arbace_core_printf_A_New(); var tmp3 *jrt.Class; var fncls__583 *jrt.Class = A_arbace_core_printf_A_fn_class; if fncls__583 == nil { var fncls__583d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1394, true); A_arbace_core_printf_A_fn_class = fncls__583d; tmp3 = fncls__583d } else { tmp3 = fncls__583 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1172; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1173)); return A_arbace_core__init_A_const_1172 }






func A_arbace_core__init_A_Unit649__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5904, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1174; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1175)); return A_arbace_core__init_A_const_1174 }

func A_arbace_core__init_A_Unit650__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5906, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1176; var tmp2 any = A_arbace_core_with_loading_context_A_New(); var tmp3 *jrt.Class; var fncls__584 *jrt.Class = A_arbace_core_with_loading_context_A_fn_class; if fncls__584 == nil { var fncls__584d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1395, true); A_arbace_core_with_loading_context_A_fn_class = fncls__584d; tmp3 = fncls__584d } else { tmp3 = fncls__584 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1176; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1177)); return A_arbace_core__init_A_const_1176 }
//line :5906:1
func A_arbace_core__init_A_Unit651__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5906, 1); A_arbace_core__init_A_const_1176.SetMacro__V(); return nil }
//line :5906:1
func A_arbace_core__init_A_Unit652__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5906, 1); return A_arbace_core__init_A_const_1176 }








func A_arbace_core__init_A_Unit653__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5915, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1178; var tmp2 any = A_arbace_core_ns_A_New(); var tmp3 *jrt.Class; var fncls__585 *jrt.Class = A_arbace_core_ns_A_fn_class; if fncls__585 == nil { var fncls__585d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1396, true); A_arbace_core_ns_A_fn_class = fncls__585d; tmp3 = fncls__585d } else { tmp3 = fncls__585 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1178; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1179)); return A_arbace_core__init_A_const_1178 }
//line :5915:1
func A_arbace_core__init_A_Unit654__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5915, 1); A_arbace_core__init_A_const_1178.SetMacro__V(); return nil }
//line :5915:1
func A_arbace_core__init_A_Unit655__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5915, 1); return A_arbace_core__init_A_const_1178 }

























































func A_arbace_core__init_A_Unit656__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5973, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1180; var tmp2 any = A_arbace_core_refer_clojure_A_New(); var tmp3 *jrt.Class; var fncls__586 *jrt.Class = A_arbace_core_refer_clojure_A_fn_class; if fncls__586 == nil { var fncls__586d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1397, true); A_arbace_core_refer_clojure_A_fn_class = fncls__586d; tmp3 = fncls__586d } else { tmp3 = fncls__586 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1180; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1181)); return A_arbace_core__init_A_const_1180 }
//line :5973:1
func A_arbace_core__init_A_Unit657__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5973, 1); A_arbace_core__init_A_const_1180.SetMacro__V(); return nil }
//line :5973:1
func A_arbace_core__init_A_Unit658__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5973, 1); return A_arbace_core__init_A_const_1180 }





func A_arbace_core__init_A_Unit659__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5979, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1182; var tmp2 any = A_arbace_core_defonce_A_New(); var tmp3 *jrt.Class; var fncls__587 *jrt.Class = A_arbace_core_defonce_A_fn_class; if fncls__587 == nil { var fncls__587d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1398, false); A_arbace_core_defonce_A_fn_class = fncls__587d; tmp3 = fncls__587d } else { tmp3 = fncls__587 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1182; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1183)); return A_arbace_core__init_A_const_1182 }
//line :5979:1
func A_arbace_core__init_A_Unit660__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5979, 1); A_arbace_core__init_A_const_1182.SetMacro__V(); return nil }
//line :5979:1
func A_arbace_core__init_A_Unit661__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5979, 1); return A_arbace_core__init_A_const_1182 }










func A_arbace_core__init_A_Unit662__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5990, 1); var v__1927001498__auto____1 any; A_arbace_core__init_A_const_1184.SetDynamic_Z__Var(true); var tmp1 *lang.Var = A_arbace_core__init_A_const_1184; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1185)); v__1927001498__auto____1 = A_arbace_core__init_A_const_1184; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { A_arbace_core__init_A_const_1184.SetDynamic_Z__Var(true); var tmp2 *lang.Var = A_arbace_core__init_A_const_1184; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1186)); var tmp3 *lang.Var = A_arbace_core__init_A_const_1184; tmp3.BindRoot_O__V(lang.IFn_Cast(A_arbace_core__init_A_const_552.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_core__init_A_const_90.GetRawRoot__O()).Invoke__O())); return A_arbace_core__init_A_const_1184 } }




func A_arbace_core__init_A_Unit663__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(5995, 1); var v__1927001498__auto____1 any; A_arbace_core__init_A_const_1187.SetDynamic_Z__Var(true); var tmp1 *lang.Var = A_arbace_core__init_A_const_1187; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1188)); v__1927001498__auto____1 = A_arbace_core__init_A_const_1187; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { A_arbace_core__init_A_const_1187.SetDynamic_Z__Var(true); var tmp2 *lang.Var = A_arbace_core__init_A_const_1187; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1189)); var tmp3 *lang.Var = A_arbace_core__init_A_const_1187; var tmp4 *lang.PersistentList_EmptyList; lang.PersistentList_Init(); tmp4 = lang.PersistentList_EMPTY; tmp3.BindRoot_O__V(tmp4.Ref()); return A_arbace_core__init_A_const_1187 } }




func A_arbace_core__init_A_Unit664__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6000, 1); var v__1927001498__auto____1 any; A_arbace_core__init_A_const_1190.SetDynamic_Z__Var(true); var tmp1 *lang.Var = A_arbace_core__init_A_const_1190; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1191)); v__1927001498__auto____1 = A_arbace_core__init_A_const_1190; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { A_arbace_core__init_A_const_1190.SetDynamic_Z__Var(true); var tmp2 *lang.Var = A_arbace_core__init_A_const_1190; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1192)); var tmp3 *lang.Var = A_arbace_core__init_A_const_1190; var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_FALSE; tmp3.BindRoot_O__V(tmp4.Ref()); return A_arbace_core__init_A_const_1190 } }




func A_arbace_core__init_A_Unit665__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6005, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1193; var tmp2 any = A_arbace_core_throw_if_A_New(); var tmp3 *jrt.Class; var fncls__588 *jrt.Class = A_arbace_core_throw_if_A_fn_class; if fncls__588 == nil { var fncls__588d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1399, true); A_arbace_core_throw_if_A_fn_class = fncls__588d; tmp3 = fncls__588d } else { tmp3 = fncls__588 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1193; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1194)); return A_arbace_core__init_A_const_1193 }















func A_arbace_core__init_A_Unit666__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6021, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1195; var tmp2 any = A_arbace_core_libspec_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__589 *jrt.Class = A_arbace_core_libspec_QMARK__A_fn_class; if fncls__589 == nil { var fncls__589d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1400, false); A_arbace_core_libspec_QMARK__A_fn_class = fncls__589d; tmp3 = fncls__589d } else { tmp3 = fncls__589 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1195; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1196)); return A_arbace_core__init_A_const_1195 }








func A_arbace_core__init_A_Unit667__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6030, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1197; var tmp2 any = A_arbace_core_prependss_A_New(); var tmp3 *jrt.Class; var fncls__590 *jrt.Class = A_arbace_core_prependss_A_fn_class; if fncls__590 == nil { var fncls__590d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1401, false); A_arbace_core_prependss_A_fn_class = fncls__590d; tmp3 = fncls__590d } else { tmp3 = fncls__590 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1197; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1198)); return A_arbace_core__init_A_const_1197 }






func A_arbace_core__init_A_Unit668__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6037, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1199; var tmp2 any = A_arbace_core_root_resource_A_New(); var tmp3 *jrt.Class; var fncls__591 *jrt.Class = A_arbace_core_root_resource_A_fn_class; if fncls__591 == nil { var fncls__591d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1402, false); A_arbace_core_root_resource_A_fn_class = fncls__591d; tmp3 = fncls__591d } else { tmp3 = fncls__591 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1199; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1200)); return A_arbace_core__init_A_const_1199 }








func A_arbace_core__init_A_Unit669__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6046, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1201; var tmp2 any = A_arbace_core_root_directory_A_New(); var tmp3 *jrt.Class; var fncls__592 *jrt.Class = A_arbace_core_root_directory_A_fn_class; if fncls__592 == nil { var fncls__592d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1403, false); A_arbace_core_root_directory_A_fn_class = fncls__592d; tmp3 = fncls__592d } else { tmp3 = fncls__592 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1201; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1202)); return A_arbace_core__init_A_const_1201 }





func A_arbace_core__init_A_Unit670__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6052, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1203; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1204)); return A_arbace_core__init_A_const_1203 }

func A_arbace_core__init_A_Unit671__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6054, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1205; var tmp2 any = A_arbace_core_load_one_A_New(); var tmp3 *jrt.Class; var fncls__593 *jrt.Class = A_arbace_core_load_one_A_fn_class; if fncls__593 == nil { var fncls__593d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1404, false); A_arbace_core_load_one_A_fn_class = fncls__593d; tmp3 = fncls__593d } else { tmp3 = fncls__593 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1205; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1206)); return A_arbace_core__init_A_const_1205 }












func A_arbace_core__init_A_Unit672__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6067, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1207; var tmp2 any = A_arbace_core_load_all_A_New(); var tmp3 *jrt.Class; var fncls__594 *jrt.Class = A_arbace_core_load_all_A_fn_class; if fncls__594 == nil { var fncls__594d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1405, false); A_arbace_core_load_all_A_fn_class = fncls__594d; tmp3 = fncls__594d } else { tmp3 = fncls__594 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1207; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1208)); return A_arbace_core__init_A_const_1207 }











func A_arbace_core__init_A_Unit673__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6079, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1209; var tmp2 any = A_arbace_core_load_lib_A_New(); var tmp3 *jrt.Class; var fncls__595 *jrt.Class = A_arbace_core_load_lib_A_fn_class; if fncls__595 == nil { var fncls__595d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1406, true); A_arbace_core_load_lib_A_fn_class = fncls__595d; tmp3 = fncls__595d } else { tmp3 = fncls__595 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1209; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1210)); return A_arbace_core__init_A_const_1209 }














































func A_arbace_core__init_A_Unit674__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6126, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1211; var tmp2 any = A_arbace_core_load_libs_A_New(); var tmp3 *jrt.Class; var fncls__596 *jrt.Class = A_arbace_core_load_libs_A_fn_class; if fncls__596 == nil { var fncls__596d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1407, true); A_arbace_core_load_libs_A_fn_class = fncls__596d; tmp3 = fncls__596d } else { tmp3 = fncls__596 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1211; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1212)); return A_arbace_core__init_A_const_1211 }






















func A_arbace_core__init_A_Unit675__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6149, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1213; var tmp2 any = A_arbace_core_check_cyclic_dependency_A_New(); var tmp3 *jrt.Class; var fncls__597 *jrt.Class = A_arbace_core_check_cyclic_dependency_A_fn_class; if fncls__597 == nil { var fncls__597d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1408, false); A_arbace_core_check_cyclic_dependency_A_fn_class = fncls__597d; tmp3 = fncls__597d } else { tmp3 = fncls__597 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1213; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1214)); return A_arbace_core__init_A_const_1213 }














func A_arbace_core__init_A_Unit676__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6164, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1215; var tmp2 any = A_arbace_core_require_A_New(); var tmp3 *jrt.Class; var fncls__598 *jrt.Class = A_arbace_core_require_A_fn_class; if fncls__598 == nil { var fncls__598d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1409, true); A_arbace_core_require_A_fn_class = fncls__598d; tmp3 = fncls__598d } else { tmp3 = fncls__598 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1215; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1216)); return A_arbace_core__init_A_const_1215 }






































































func A_arbace_core__init_A_Unit677__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6235, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1217; var tmp2 any = A_arbace_core_serialized_require_A_New(); var tmp3 *jrt.Class; var fncls__599 *jrt.Class = A_arbace_core_serialized_require_A_fn_class; if fncls__599 == nil { var fncls__599d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1410, true); A_arbace_core_serialized_require_A_fn_class = fncls__599d; tmp3 = fncls__599d } else { tmp3 = fncls__599 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1217; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1218)); return A_arbace_core__init_A_const_1217 }








func A_arbace_core__init_A_Unit678__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6244, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1219; var tmp2 any = A_arbace_core_requiring_resolve_A_New(); var tmp3 *jrt.Class; var fncls__600 *jrt.Class = A_arbace_core_requiring_resolve_A_fn_class; if fncls__600 == nil { var fncls__600d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1411, false); A_arbace_core_requiring_resolve_A_fn_class = fncls__600d; tmp3 = fncls__600d } else { tmp3 = fncls__600 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1219; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1220)); return A_arbace_core__init_A_const_1219 }










func A_arbace_core__init_A_Unit679__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6255, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1221; var tmp2 any = A_arbace_core_use_A_New(); var tmp3 *jrt.Class; var fncls__601 *jrt.Class = A_arbace_core_use_A_fn_class; if fncls__601 == nil { var fncls__601d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1412, true); A_arbace_core_use_A_fn_class = fncls__601d; tmp3 = fncls__601d } else { tmp3 = fncls__601 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1221; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1222)); return A_arbace_core__init_A_const_1221 }










func A_arbace_core__init_A_Unit680__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6266, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1223; var tmp2 any = A_arbace_core_loaded_libs_A_New(); var tmp3 *jrt.Class; var fncls__602 *jrt.Class = A_arbace_core_loaded_libs_A_fn_class; if fncls__602 == nil { var fncls__602d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1413, false); A_arbace_core_loaded_libs_A_fn_class = fncls__602d; tmp3 = fncls__602d } else { tmp3 = fncls__602 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1223; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1224)); return A_arbace_core__init_A_const_1223 }




func A_arbace_core__init_A_Unit681__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6271, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1203; var tmp2 any = A_arbace_core_load_A_New(); var tmp3 *jrt.Class; var fncls__603 *jrt.Class = A_arbace_core_load_A_fn_class; if fncls__603 == nil { var fncls__603d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1414, true); A_arbace_core_load_A_fn_class = fncls__603d; tmp3 = fncls__603d } else { tmp3 = fncls__603 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1203; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1225)); return A_arbace_core__init_A_const_1203 }


















func A_arbace_core__init_A_Unit682__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6290, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1226; var tmp2 any = A_arbace_core_compile_A_New(); var tmp3 *jrt.Class; var fncls__604 *jrt.Class = A_arbace_core_compile_A_fn_class; if fncls__604 == nil { var fncls__604d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1415, false); A_arbace_core_compile_A_fn_class = fncls__604d; tmp3 = fncls__604d } else { tmp3 = fncls__604 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1226; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1227)); return A_arbace_core__init_A_const_1226 }











func A_arbace_core__init_A_Unit683__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6302, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1228; var tmp2 any = A_arbace_core_get_in_A_New(); var tmp3 *jrt.Class; var fncls__605 *jrt.Class = A_arbace_core_get_in_A_fn_class; if fncls__605 == nil { var fncls__605d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1416, false); A_arbace_core_get_in_A_fn_class = fncls__605d; tmp3 = fncls__605d } else { tmp3 = fncls__605 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1228; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1229)); return A_arbace_core__init_A_const_1228 }


















func A_arbace_core__init_A_Unit684__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6321, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1230; var tmp2 any = A_arbace_core_assoc_in_A_New(); var tmp3 *jrt.Class; var fncls__606 *jrt.Class = A_arbace_core_assoc_in_A_fn_class; if fncls__606 == nil { var fncls__606d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1417, false); A_arbace_core_assoc_in_A_fn_class = fncls__606d; tmp3 = fncls__606d } else { tmp3 = fncls__606 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1230; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1231)); return A_arbace_core__init_A_const_1230 }










func A_arbace_core__init_A_Unit685__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6332, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1232; var tmp2 any = A_arbace_core_update_in_A_New(); var tmp3 *jrt.Class; var fncls__607 *jrt.Class = A_arbace_core_update_in_A_fn_class; if fncls__607 == nil { var fncls__607d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1418, true); A_arbace_core_update_in_A_fn_class = fncls__607d; tmp3 = fncls__607d } else { tmp3 = fncls__607 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1232; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1233)); return A_arbace_core__init_A_const_1232 }















func A_arbace_core__init_A_Unit686__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6348, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1234; var tmp2 any = A_arbace_core_update_A_New(); var tmp3 *jrt.Class; var fncls__608 *jrt.Class = A_arbace_core_update_A_fn_class; if fncls__608 == nil { var fncls__608d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1419, true); A_arbace_core_update_A_fn_class = fncls__608d; tmp3 = fncls__608d } else { tmp3 = fncls__608 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 6)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1234; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1235)); return A_arbace_core__init_A_const_1234 }

















func A_arbace_core__init_A_Unit687__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6366, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1236; var tmp2 any = A_arbace_core_coll_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__609 *jrt.Class = A_arbace_core_coll_QMARK__A_fn_class; if fncls__609 == nil { var fncls__609d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1420, false); A_arbace_core_coll_QMARK__A_fn_class = fncls__609d; tmp3 = fncls__609d } else { tmp3 = fncls__609 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1236; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1237)); return A_arbace_core__init_A_const_1236 }





func A_arbace_core__init_A_Unit688__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6372, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1238; var tmp2 any = A_arbace_core_list_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__610 *jrt.Class = A_arbace_core_list_QMARK__A_fn_class; if fncls__610 == nil { var fncls__610d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1421, false); A_arbace_core_list_QMARK__A_fn_class = fncls__610d; tmp3 = fncls__610d } else { tmp3 = fncls__610 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1238; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1239)); return A_arbace_core__init_A_const_1238 }





func A_arbace_core__init_A_Unit689__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6378, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1240; var tmp2 any = A_arbace_core_seqable_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__611 *jrt.Class = A_arbace_core_seqable_QMARK__A_fn_class; if fncls__611 == nil { var fncls__611d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1422, false); A_arbace_core_seqable_QMARK__A_fn_class = fncls__611d; tmp3 = fncls__611d } else { tmp3 = fncls__611 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1240; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1241)); return A_arbace_core__init_A_const_1240 }




func A_arbace_core__init_A_Unit690__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6383, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1242; var tmp2 any = A_arbace_core_ifn_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__612 *jrt.Class = A_arbace_core_ifn_QMARK__A_fn_class; if fncls__612 == nil { var fncls__612d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1423, false); A_arbace_core_ifn_QMARK__A_fn_class = fncls__612d; tmp3 = fncls__612d } else { tmp3 = fncls__612 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1242; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1243)); return A_arbace_core__init_A_const_1242 }






func A_arbace_core__init_A_Unit691__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6390, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1244; var tmp2 any = A_arbace_core_fn_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__613 *jrt.Class = A_arbace_core_fn_QMARK__A_fn_class; if fncls__613 == nil { var fncls__613d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1424, false); A_arbace_core_fn_QMARK__A_fn_class = fncls__613d; tmp3 = fncls__613d } else { tmp3 = fncls__613 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1244; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1245)); return A_arbace_core__init_A_const_1244 }





func A_arbace_core__init_A_Unit692__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6396, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1246; var tmp2 any = A_arbace_core_associative_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__614 *jrt.Class = A_arbace_core_associative_QMARK__A_fn_class; if fncls__614 == nil { var fncls__614d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1425, false); A_arbace_core_associative_QMARK__A_fn_class = fncls__614d; tmp3 = fncls__614d } else { tmp3 = fncls__614 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1246; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1247)); return A_arbace_core__init_A_const_1246 }





func A_arbace_core__init_A_Unit693__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6402, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1248; var tmp2 any = A_arbace_core_sequential_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__615 *jrt.Class = A_arbace_core_sequential_QMARK__A_fn_class; if fncls__615 == nil { var fncls__615d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1426, false); A_arbace_core_sequential_QMARK__A_fn_class = fncls__615d; tmp3 = fncls__615d } else { tmp3 = fncls__615 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1248; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1249)); return A_arbace_core__init_A_const_1248 }





func A_arbace_core__init_A_Unit694__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6408, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1250; var tmp2 any = A_arbace_core_sorted_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__616 *jrt.Class = A_arbace_core_sorted_QMARK__A_fn_class; if fncls__616 == nil { var fncls__616d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1427, false); A_arbace_core_sorted_QMARK__A_fn_class = fncls__616d; tmp3 = fncls__616d } else { tmp3 = fncls__616 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1250; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1251)); return A_arbace_core__init_A_const_1250 }





func A_arbace_core__init_A_Unit695__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6414, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1252; var tmp2 any = A_arbace_core_reversible_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__617 *jrt.Class = A_arbace_core_reversible_QMARK__A_fn_class; if fncls__617 == nil { var fncls__617d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1428, false); A_arbace_core_reversible_QMARK__A_fn_class = fncls__617d; tmp3 = fncls__617d } else { tmp3 = fncls__617 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1252; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1253)); return A_arbace_core__init_A_const_1252 }





func A_arbace_core__init_A_Unit696__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6420, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1254; var tmp2 any = A_arbace_core_indexed_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__618 *jrt.Class = A_arbace_core_indexed_QMARK__A_fn_class; if fncls__618 == nil { var fncls__618d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1429, false); A_arbace_core_indexed_QMARK__A_fn_class = fncls__618d; tmp3 = fncls__618d } else { tmp3 = fncls__618 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1254; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1255)); return A_arbace_core__init_A_const_1254 }




func A_arbace_core__init_A_Unit697__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6425, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1256; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1257)); return A_arbace_core__init_A_const_1256.SetDynamic_Z__Var(true).Ref() }




func A_arbace_core__init_A_Unit698__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6430, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1258; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1259)); return A_arbace_core__init_A_const_1258.SetDynamic_Z__Var(true).Ref() }




func A_arbace_core__init_A_Unit699__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6435, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1260; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1261)); return A_arbace_core__init_A_const_1260.SetDynamic_Z__Var(true).Ref() }




func A_arbace_core__init_A_Unit700__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6440, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1262; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1263)); return A_arbace_core__init_A_const_1262.SetDynamic_Z__Var(true).Ref() }




func A_arbace_core__init_A_Unit701__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6445, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1264; var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_FALSE; tmp1.BindRoot_O__V(tmp2.Ref()); var tmp3 *lang.Var = A_arbace_core__init_A_const_1264; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1265)); return A_arbace_core__init_A_const_1264.SetDynamic_Z__Var(true).Ref() }




func A_arbace_core__init_A_Unit702__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6450, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1266; var tmp2 any = A_arbace_core_trampoline_A_New(); var tmp3 *jrt.Class; var fncls__619 *jrt.Class = A_arbace_core_trampoline_A_fn_class; if fncls__619 == nil { var fncls__619d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1430, true); A_arbace_core_trampoline_A_fn_class = fncls__619d; tmp3 = fncls__619d } else { tmp3 = fncls__619 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1266; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1267)); return A_arbace_core__init_A_const_1266 }

















func A_arbace_core__init_A_Unit703__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6468, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1268; var tmp2 any = A_arbace_core_intern_A_New(); var tmp3 *jrt.Class; var fncls__620 *jrt.Class = A_arbace_core_intern_A_fn_class; if fncls__620 == nil { var fncls__620d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1431, false); A_arbace_core_intern_A_fn_class = fncls__620d; tmp3 = fncls__620d } else { tmp3 = fncls__620 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1268; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1269)); return A_arbace_core__init_A_const_1268 }















func A_arbace_core__init_A_Unit704__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6484, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1270; var tmp2 any = A_arbace_core_while_A_New(); var tmp3 *jrt.Class; var fncls__621 *jrt.Class = A_arbace_core_while_A_fn_class; if fncls__621 == nil { var fncls__621d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1432, true); A_arbace_core_while_A_fn_class = fncls__621d; tmp3 = fncls__621d } else { tmp3 = fncls__621 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1270; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1271)); return A_arbace_core__init_A_const_1270 }
//line :6484:1
func A_arbace_core__init_A_Unit705__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6484, 1); A_arbace_core__init_A_const_1270.SetMacro__V(); return nil }
//line :6484:1
func A_arbace_core__init_A_Unit706__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6484, 1); return A_arbace_core__init_A_const_1270 }









func A_arbace_core__init_A_Unit707__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6494, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1272; var tmp2 any = A_arbace_core_memoize_A_New(); var tmp3 *jrt.Class; var fncls__622 *jrt.Class = A_arbace_core_memoize_A_fn_class; if fncls__622 == nil { var fncls__622d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1433, false); A_arbace_core_memoize_A_fn_class = fncls__622d; tmp3 = fncls__622d } else { tmp3 = fncls__622 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1272; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1273)); return A_arbace_core__init_A_const_1272 }















func A_arbace_core__init_A_Unit708__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6510, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1274; var tmp2 any = A_arbace_core_condp_A_New(); var tmp3 *jrt.Class; var fncls__623 *jrt.Class = A_arbace_core_condp_A_fn_class; if fncls__623 == nil { var fncls__623d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1434, true); A_arbace_core_condp_A_fn_class = fncls__623d; tmp3 = fncls__623d } else { tmp3 = fncls__623 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 4)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1274; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1275)); return A_arbace_core__init_A_const_1274 }
//line :6510:1
func A_arbace_core__init_A_Unit709__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6510, 1); A_arbace_core__init_A_const_1274.SetMacro__V(); return nil }
//line :6510:1
func A_arbace_core__init_A_Unit710__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6510, 1); return A_arbace_core__init_A_const_1274 }










































func A_arbace_core__init_A_Unit711__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6553, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_574.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1276; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_core__init_A_const_48.GetRawRoot__O(), A_arbace_core__init_A_const_54, Lit_734) }
func A_arbace_core__init_A_Unit712__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6554, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_574.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1277; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_core__init_A_const_48.GetRawRoot__O(), A_arbace_core__init_A_const_54, Lit_734) }
func A_arbace_core__init_A_Unit713__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6555, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_574.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1278; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_core__init_A_const_48.GetRawRoot__O(), A_arbace_core__init_A_const_54, Lit_734) }

func A_arbace_core__init_A_Unit714__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6557, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1279; var tmp2 any = A_arbace_core_add_doc_and_meta_A_New(); var tmp3 *jrt.Class; var fncls__624 *jrt.Class = A_arbace_core_add_doc_and_meta_A_fn_class; if fncls__624 == nil { var fncls__624d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1435, false); A_arbace_core_add_doc_and_meta_A_fn_class = fncls__624d; tmp3 = fncls__624d } else { tmp3 = fncls__624 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1279; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1280)); return A_arbace_core__init_A_const_1279 }
//line :6557:1
func A_arbace_core__init_A_Unit715__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6557, 1); A_arbace_core__init_A_const_1279.SetMacro__V(); return nil }
//line :6557:1
func A_arbace_core__init_A_Unit716__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6557, 1); return A_arbace_core__init_A_const_1279 }


func A_arbace_core__init_A_Unit717__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6560, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_574.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1281; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_core__init_A_const_720.GetRawRoot__O(), lang.IFn_Cast(A_arbace_core__init_A_const_48.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core__init_A_const_1282, A_arbace_core__init_A_const_53, Lit_1436)) }





func A_arbace_core__init_A_Unit718__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6566, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_574.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1283; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_core__init_A_const_720.GetRawRoot__O(), lang.IFn_Cast(A_arbace_core__init_A_const_48.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core__init_A_const_1284, A_arbace_core__init_A_const_53, Lit_1437)) }




func A_arbace_core__init_A_Unit719__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6571, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_574.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1285; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_core__init_A_const_720.GetRawRoot__O(), lang.IFn_Cast(A_arbace_core__init_A_const_48.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core__init_A_const_1286, A_arbace_core__init_A_const_53, Lit_1438)) }






func A_arbace_core__init_A_Unit720__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6578, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_574.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1287; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_core__init_A_const_720.GetRawRoot__O(), lang.IFn_Cast(A_arbace_core__init_A_const_48.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core__init_A_const_1288, A_arbace_core__init_A_const_53, Lit_1439)) }







func A_arbace_core__init_A_Unit721__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6586, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_574.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1289; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_core__init_A_const_720.GetRawRoot__O(), lang.IFn_Cast(A_arbace_core__init_A_const_48.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core__init_A_const_1290, A_arbace_core__init_A_const_53, Lit_1440)) }



func A_arbace_core__init_A_Unit722__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6590, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_574.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1291; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_core__init_A_const_720.GetRawRoot__O(), lang.IFn_Cast(A_arbace_core__init_A_const_48.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core__init_A_const_1292, A_arbace_core__init_A_const_53, Lit_1441)) }






func A_arbace_core__init_A_Unit723__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6597, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_574.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1293; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_core__init_A_const_720.GetRawRoot__O(), lang.IFn_Cast(A_arbace_core__init_A_const_48.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core__init_A_const_1294, A_arbace_core__init_A_const_53, Lit_1442)) }











func A_arbace_core__init_A_Unit724__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6609, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_574.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1295; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_core__init_A_const_720.GetRawRoot__O(), lang.IFn_Cast(A_arbace_core__init_A_const_48.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core__init_A_const_1296, A_arbace_core__init_A_const_53, Lit_1443)) }



func A_arbace_core__init_A_Unit725__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6613, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_574.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1297; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_core__init_A_const_720.GetRawRoot__O(), lang.IFn_Cast(A_arbace_core__init_A_const_48.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core__init_A_const_1298, A_arbace_core__init_A_const_53, Lit_1444)) }





func A_arbace_core__init_A_Unit726__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6619, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_574.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1299; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_core__init_A_const_720.GetRawRoot__O(), lang.IFn_Cast(A_arbace_core__init_A_const_48.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core__init_A_const_1300, A_arbace_core__init_A_const_53, Lit_1445)) }





func A_arbace_core__init_A_Unit727__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6625, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_574.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1301; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_core__init_A_const_720.GetRawRoot__O(), lang.IFn_Cast(A_arbace_core__init_A_const_48.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core__init_A_const_1302, A_arbace_core__init_A_const_53, Lit_1446)) }





func A_arbace_core__init_A_Unit728__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6631, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_574.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1303; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_core__init_A_const_720.GetRawRoot__O(), lang.IFn_Cast(A_arbace_core__init_A_const_48.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core__init_A_const_1304, A_arbace_core__init_A_const_53, Lit_1447)) }





func A_arbace_core__init_A_Unit729__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6637, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_574.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1305; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_core__init_A_const_720.GetRawRoot__O(), lang.IFn_Cast(A_arbace_core__init_A_const_48.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core__init_A_const_1306, A_arbace_core__init_A_const_53, Lit_1448)) }






func A_arbace_core__init_A_Unit730__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6644, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_574.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1307; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_core__init_A_const_720.GetRawRoot__O(), lang.IFn_Cast(A_arbace_core__init_A_const_48.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core__init_A_const_1308, A_arbace_core__init_A_const_53, Lit_1449)) }






func A_arbace_core__init_A_Unit731__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6651, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_574.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1309; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_core__init_A_const_720.GetRawRoot__O(), lang.IFn_Cast(A_arbace_core__init_A_const_48.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core__init_A_const_1310, A_arbace_core__init_A_const_53, Lit_1450)) }






func A_arbace_core__init_A_Unit732__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6658, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_574.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1311; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_core__init_A_const_720.GetRawRoot__O(), lang.IFn_Cast(A_arbace_core__init_A_const_48.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core__init_A_const_1312, A_arbace_core__init_A_const_53, Lit_1451)) }

























func A_arbace_core__init_A_Unit733__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6684, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_574.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1313; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_core__init_A_const_720.GetRawRoot__O(), lang.IFn_Cast(A_arbace_core__init_A_const_48.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core__init_A_const_1314, A_arbace_core__init_A_const_53, Lit_1452)) }




func A_arbace_core__init_A_Unit734__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6689, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1315; var tmp2 any = A_arbace_core_future_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__625 *jrt.Class = A_arbace_core_future_QMARK__A_fn_class; if fncls__625 == nil { var fncls__625d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1453, false); A_arbace_core_future_QMARK__A_fn_class = fncls__625d; tmp3 = fncls__625d } else { tmp3 = fncls__625 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1315; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1316)); return A_arbace_core__init_A_const_1315 }





func A_arbace_core__init_A_Unit735__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6695, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1317; var tmp2 any = A_arbace_core_future_done_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__626 *jrt.Class = A_arbace_core_future_done_QMARK__A_fn_class; if fncls__626 == nil { var fncls__626d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1454, false); A_arbace_core_future_done_QMARK__A_fn_class = fncls__626d; tmp3 = fncls__626d } else { tmp3 = fncls__626 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1317; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1318)); return A_arbace_core__init_A_const_1317 }





func A_arbace_core__init_A_Unit736__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6701, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1319; var tmp2 any = A_arbace_core_letfn_A_New(); var tmp3 *jrt.Class; var fncls__627 *jrt.Class = A_arbace_core_letfn_A_fn_class; if fncls__627 == nil { var fncls__627d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1455, true); A_arbace_core_letfn_A_fn_class = fncls__627d; tmp3 = fncls__627d } else { tmp3 = fncls__627 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1319; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1320)); return A_arbace_core__init_A_const_1319 }
//line :6701:1
func A_arbace_core__init_A_Unit737__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6701, 1); A_arbace_core__init_A_const_1319.SetMacro__V(); return nil }
//line :6701:1
func A_arbace_core__init_A_Unit738__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6701, 1); return A_arbace_core__init_A_const_1319 }












func A_arbace_core__init_A_Unit739__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6714, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1321; var tmp2 any = A_arbace_core_fnil_A_New(); var tmp3 *jrt.Class; var fncls__628 *jrt.Class = A_arbace_core_fnil_A_fn_class; if fncls__628 == nil { var fncls__628d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1456, false); A_arbace_core_fnil_A_fn_class = fncls__628d; tmp3 = fncls__628d } else { tmp3 = fncls__628 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1321; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1322)); return A_arbace_core__init_A_const_1321 }

























func A_arbace_core__init_A_Unit740__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6740, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1323; var tmp2 any = A_arbace_core_shift_mask_A_New(); var tmp3 *jrt.Class; var fncls__629 *jrt.Class = A_arbace_core_shift_mask_A_fn_class; if fncls__629 == nil { var fncls__629d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1457, false); A_arbace_core_shift_mask_A_fn_class = fncls__629d; tmp3 = fncls__629d } else { tmp3 = fncls__629 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1323; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1324)); return A_arbace_core__init_A_const_1323 }


func A_arbace_core__init_A_Unit741__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6743, 1); A_arbace_core__init_A_const_1325.BindRoot_O__V(A_arbace_core__init_A_const_1326); var tmp1 *lang.Var = A_arbace_core__init_A_const_1325; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1327)); return A_arbace_core__init_A_const_1325 }
func A_arbace_core__init_A_Unit742__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6744, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1328; tmp1.BindRoot_O__V(jrt.Long_ValueOf_J__Long(lang.Numbers_ShiftLeft_J_O__J(1, A_arbace_core__init_A_const_1325.GetRawRoot__O())).Ref()); var tmp2 *lang.Var = A_arbace_core__init_A_const_1328; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1329)); return A_arbace_core__init_A_const_1328 }

func A_arbace_core__init_A_Unit743__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6746, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1330; var tmp2 any = A_arbace_core_maybe_min_hash_A_New(); var tmp3 *jrt.Class; var fncls__630 *jrt.Class = A_arbace_core_maybe_min_hash_A_fn_class; if fncls__630 == nil { var fncls__630d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1458, false); A_arbace_core_maybe_min_hash_A_fn_class = fncls__630d; tmp3 = fncls__630d } else { tmp3 = fncls__630 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1330; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1331)); return A_arbace_core__init_A_const_1330 }









func A_arbace_core__init_A_Unit744__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6756, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1332; var tmp2 any = A_arbace_core_case_map_A_New(); var tmp3 *jrt.Class; var fncls__631 *jrt.Class = A_arbace_core_case_map_A_fn_class; if fncls__631 == nil { var fncls__631d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1459, false); A_arbace_core_case_map_A_fn_class = fncls__631d; tmp3 = fncls__631d } else { tmp3 = fncls__631 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1332; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1333)); return A_arbace_core__init_A_const_1332 }










func A_arbace_core__init_A_Unit745__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6767, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1334; var tmp2 any = A_arbace_core_fits_table_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__632 *jrt.Class = A_arbace_core_fits_table_QMARK__A_fn_class; if fncls__632 == nil { var fncls__632d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1460, false); A_arbace_core_fits_table_QMARK__A_fn_class = fncls__632d; tmp3 = fncls__632d } else { tmp3 = fncls__632 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1334; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1335)); return A_arbace_core__init_A_const_1334 }





func A_arbace_core__init_A_Unit746__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6773, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1336; var tmp2 any = A_arbace_core_prep_ints_A_New(); var tmp3 *jrt.Class; var fncls__633 *jrt.Class = A_arbace_core_prep_ints_A_fn_class; if fncls__633 == nil { var fncls__633d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1461, false); A_arbace_core_prep_ints_A_fn_class = fncls__633d; tmp3 = fncls__633d } else { tmp3 = fncls__633 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1336; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1337)); return A_arbace_core__init_A_const_1336 }















func A_arbace_core__init_A_Unit747__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6789, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1338; var tmp2 any = A_arbace_core_merge_hash_collisions_A_New(); var tmp3 *jrt.Class; var fncls__634 *jrt.Class = A_arbace_core_merge_hash_collisions_A_fn_class; if fncls__634 == nil { var fncls__634d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1462, false); A_arbace_core_merge_hash_collisions_A_fn_class = fncls__634d; tmp3 = fncls__634d } else { tmp3 = fncls__634 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1338; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1339)); return A_arbace_core__init_A_const_1338 }



































func A_arbace_core__init_A_Unit748__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6825, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1340; var tmp2 any = A_arbace_core_prep_hashes_A_New(); var tmp3 *jrt.Class; var fncls__635 *jrt.Class = A_arbace_core_prep_hashes_A_fn_class; if fncls__635 == nil { var fncls__635d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1463, false); A_arbace_core_prep_hashes_A_fn_class = fncls__635d; tmp3 = fncls__635d } else { tmp3 = fncls__635 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1340; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1341)); return A_arbace_core__init_A_const_1340 }



























func A_arbace_core__init_A_Unit749__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6853, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1342; var tmp2 any = A_arbace_core_case_A_New(); var tmp3 *jrt.Class; var fncls__636 *jrt.Class = A_arbace_core_case_A_fn_class; if fncls__636 == nil { var fncls__636d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1464, true); A_arbace_core_case_A_fn_class = fncls__636d; tmp3 = fncls__636d } else { tmp3 = fncls__636 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1342; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1343)); return A_arbace_core__init_A_const_1342 }
//line :6853:1
func A_arbace_core__init_A_Unit750__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6853, 1); A_arbace_core__init_A_const_1342.SetMacro__V(); return nil }
//line :6853:1
func A_arbace_core__init_A_Unit751__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6853, 1); return A_arbace_core__init_A_const_1342 }






























































func A_arbace_core__init_A_Unit752__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6916, 1); return lang.IFn_Cast(A_arbace_core__init_A_const_574.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_core__init_A_const_900.GetRawRoot__O()).Invoke_O__O(A_arbace_core__init_A_const_1344), A_arbace_core__init_A_const_48.GetRawRoot__O(), A_arbace_core__init_A_const_53, Lit_1465) }
func A_arbace_core__init_A_Unit753__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6917, 1); return lang.IFn_Cast(A_arbace_core__init_A_const_1203.GetRawRoot__O()).Invoke_O__O(Lit_1466) }

func A_arbace_core__init_A_Unit754__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6919, 1); return lang.IFn_Cast(A_arbace_core__init_A_const_1203.GetRawRoot__O()).Invoke_O__O(Lit_1467) }
func A_arbace_core__init_A_Unit755__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6920, 1); return lang.IFn_Cast(A_arbace_core__init_A_const_1203.GetRawRoot__O()).Invoke_O__O(Lit_1468) }
func A_arbace_core__init_A_Unit756__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6921, 1); return lang.IFn_Cast(A_arbace_core__init_A_const_1203.GetRawRoot__O()).Invoke_O__O(Lit_1469) }
func A_arbace_core__init_A_Unit757__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6922, 1); return lang.IFn_Cast(A_arbace_core__init_A_const_1203.GetRawRoot__O()).Invoke_O__O(Lit_1470) }
func A_arbace_core__init_A_Unit758__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6923, 1); return lang.IFn_Cast(A_arbace_core__init_A_const_1203.GetRawRoot__O()).Invoke_O__O(Lit_1471) }
func A_arbace_core__init_A_Unit759__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6924, 1); return lang.IFn_Cast(A_arbace_core__init_A_const_1203.GetRawRoot__O()).Invoke_O__O(Lit_1472) }

func A_arbace_core__init_A_Unit760__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6926, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1345; var tmp2 any = A_arbace_core_stream_reduce_BANG__A_New(); var tmp3 *jrt.Class; var fncls__637 *jrt.Class = A_arbace_core_stream_reduce_BANG__A_fn_class; if fncls__637 == nil { var fncls__637d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1473, false); A_arbace_core_stream_reduce_BANG__A_fn_class = fncls__637d; tmp3 = fncls__637d } else { tmp3 = fncls__637 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1345; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1346)); return A_arbace_core__init_A_const_1345 }








func A_arbace_core__init_A_Unit761__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6935, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1347; var tmp2 any = A_arbace_core_stream_seq_BANG__A_New(); var tmp3 *jrt.Class; var fncls__638 *jrt.Class = A_arbace_core_stream_seq_BANG__A_fn_class; if fncls__638 == nil { var fncls__638d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1474, false); A_arbace_core_stream_seq_BANG__A_fn_class = fncls__638d; tmp3 = fncls__638d } else { tmp3 = fncls__638 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1347; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1348)); return A_arbace_core__init_A_const_1347 }






func A_arbace_core__init_A_Unit762__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6942, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1349; var tmp2 any = A_arbace_core_stream_transduce_BANG__A_New(); var tmp3 *jrt.Class; var fncls__639 *jrt.Class = A_arbace_core_stream_transduce_BANG__A_fn_class; if fncls__639 == nil { var fncls__639d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1475, false); A_arbace_core_stream_transduce_BANG__A_fn_class = fncls__639d; tmp3 = fncls__639d } else { tmp3 = fncls__639 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1349; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1350)); return A_arbace_core__init_A_const_1349 }









func A_arbace_core__init_A_Unit763__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6952, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1351; var tmp2 any = A_arbace_core_stream_into_BANG__A_New(); var tmp3 *jrt.Class; var fncls__640 *jrt.Class = A_arbace_core_stream_into_BANG__A_fn_class; if fncls__640 == nil { var fncls__640d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1476, false); A_arbace_core_stream_into_BANG__A_fn_class = fncls__640d; tmp3 = fncls__640d } else { tmp3 = fncls__640 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1351; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1352)); return A_arbace_core__init_A_const_1351 }












func A_arbace_core__init_A_Unit764__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6965, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1353; var tmp2 any = A_arbace_core_when_class_A_New(); var tmp3 *jrt.Class; var fncls__641 *jrt.Class = A_arbace_core_when_class_A_fn_class; if fncls__641 == nil { var fncls__641d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1477, true); A_arbace_core_when_class_A_fn_class = fncls__641d; tmp3 = fncls__641d } else { tmp3 = fncls__641 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1353; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1354)); return A_arbace_core__init_A_const_1353 }
//line :6965:1
func A_arbace_core__init_A_Unit765__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6965, 1); A_arbace_core__init_A_const_1353.SetMacro__V(); return nil }
//line :6965:1
func A_arbace_core__init_A_Unit766__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6965, 1); return A_arbace_core__init_A_const_1353 }







func A_arbace_core__init_A_Unit767__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6973, 1); return lang.IFn_Cast(A_arbace_core__init_A_const_1203.GetRawRoot__O()).Invoke_O__O(Lit_1478) }

func A_arbace_core__init_A_Unit768__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6975, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_core__init_A_const_1355; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1356)); v__1927001498__auto____1 = A_arbace_core__init_A_const_1355; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_core__init_A_const_1355; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1357)); var tmp3 *lang.Var = A_arbace_core__init_A_const_1355; var tmp4 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp4 = lang.PersistentArrayMap_EMPTY; tmp3.BindRoot_O__V(tmp4.Ref()); return A_arbace_core__init_A_const_1355 } }
//line :6975:1
func A_arbace_core__init_A_Unit769__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6975, 1); return A_arbace_core__init_A_const_1358 }
//line :6975:1
func A_arbace_core__init_A_Unit770__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6975, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_574.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1355; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_core__init_A_const_48.GetRawRoot__O(), A_arbace_core__init_A_const_53, nil) }
//line :6975:1
func A_arbace_core__init_A_Unit771__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6975, 1); return A_arbace_core__init_A_const_1359.Invoke_O_O__O(A_arbace_core__init_A_const_1355, A_arbace_core__init_A_const_1360) }
//line :6975:1
func A_arbace_core__init_A_Unit772__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6975, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_1133.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1355; var tmp3 any = A_arbace_core__init_A_const_720.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_48.GetRawRoot__O()); var tmp5 any = A_arbace_core__init_A_const_1361; var tmp6 any = A_arbace_core__init_A_const_1362; var tmp7 any = A_arbace_core__init_A_const_1363; var tmp8 any = A_arbace_core__init_A_const_1364; var tmp9 any = A_arbace_core__init_A_const_1355; var tmp10 any = A_arbace_core__init_A_const_1365; var tmp11 any = A_arbace_core__init_A_const_1366; var tmp12 any = A_arbace_core__init_A_const_1367; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_62.GetRawRoot__O()); var tmp14 any = A_arbace_core__init_A_const_1368; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_720.GetRawRoot__O()); var tmp16 any = A_arbace_core__init_A_const_1369; var tmp17 any = lang.IFn_Cast(A_arbace_core__init_A_const_1268.GetRawRoot__O()).Invoke_O_O__O(A_arbace_core__init_A_const_1295.Get__O(), tmp13.Invoke_O_O__O(tmp14, tmp15.Invoke_O_O__O(tmp16, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_core__init_A_const_1370, A_arbace_core__init_A_const_1355))))); var tmp18 any = A_arbace_core_eval1927001833_fn__1927001834_A_New(); var tmp19 *jrt.Class; var fncls__642 *jrt.Class = A_arbace_core_eval1927001833_fn__1927001834_A_fn_class; if fncls__642 == nil { var fncls__642d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1479, false); A_arbace_core_eval1927001833_fn__1927001834_A_fn_class = fncls__642d; tmp19 = fncls__642d } else { tmp19 = fncls__642 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp17, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil))))) }
//line :6975:1
func A_arbace_core__init_A_Unit773__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6975, 1); return lang.IFn_Cast(A_arbace_core__init_A_const_1371.GetRawRoot__O()).Invoke_O__O(A_arbace_core__init_A_const_1355.GetRawRoot__O()) }
//line :6975:1
func A_arbace_core__init_A_Unit774__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6975, 1); return A_arbace_core__init_A_const_1372 }


func A_arbace_core__init_A_Unit775__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6978, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_1373.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1374; var tmp3 any = A_arbace_core__init_A_const_1355.GetRawRoot__O(); var tmp4 any = A_arbace_core__init_A_const_1375; var tmp5 any = A_arbace_core_eval1927001847_fn__1927001848_A_New(); var tmp6 *jrt.Class; var fncls__643 *jrt.Class = A_arbace_core_eval1927001847_fn__1927001848_A_fn_class; if fncls__643 == nil { var fncls__643d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1480, false); A_arbace_core_eval1927001847_fn__1927001848_A_fn_class = fncls__643d; tmp6 = fncls__643d } else { tmp6 = fncls__643 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }



func A_arbace_core__init_A_Unit776__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6982, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1376; var tmp2 any = A_arbace_core_inst_ms_A_New(); var tmp3 *jrt.Class; var fncls__644 *jrt.Class = A_arbace_core_inst_ms_A_fn_class; if fncls__644 == nil { var fncls__644d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1481, false); A_arbace_core_inst_ms_A_fn_class = fncls__644d; tmp3 = fncls__644d } else { tmp3 = fncls__644 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1376; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1377)); return A_arbace_core__init_A_const_1376 }





func A_arbace_core__init_A_Unit777__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6988, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1378; var tmp2 any = A_arbace_core_inst_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__645 *jrt.Class = A_arbace_core_inst_QMARK__A_fn_class; if fncls__645 == nil { var fncls__645d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1482, false); A_arbace_core_inst_QMARK__A_fn_class = fncls__645d; tmp3 = fncls__645d } else { tmp3 = fncls__645 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1378; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1379)); return A_arbace_core__init_A_const_1378 }





func A_arbace_core__init_A_Unit778__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6994, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_1373.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1380; var tmp3 any = A_arbace_core__init_A_const_1355.GetRawRoot__O(); var tmp4 any = A_arbace_core__init_A_const_1375; var tmp5 any = A_arbace_core_eval1927001853_fn__1927001854_A_New(); var tmp6 *jrt.Class; var fncls__646 *jrt.Class = A_arbace_core_eval1927001853_fn__1927001854_A_fn_class; if fncls__646 == nil { var fncls__646d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1483, false); A_arbace_core_eval1927001853_fn__1927001854_A_fn_class = fncls__646d; tmp6 = fncls__646d } else { tmp6 = fncls__646 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }



func A_arbace_core__init_A_Unit779__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(6998, 1); return lang.IFn_Cast(A_arbace_core__init_A_const_1203.GetRawRoot__O()).Invoke_O__O(Lit_1484) }

func A_arbace_core__init_A_Unit780__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7000, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1381; var tmp2 any = A_arbace_core_uuid_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__647 *jrt.Class = A_arbace_core_uuid_QMARK__A_fn_class; if fncls__647 == nil { var fncls__647d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1485, false); A_arbace_core_uuid_QMARK__A_fn_class = fncls__647d; tmp3 = fncls__647d } else { tmp3 = fncls__647 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1381; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1382)); return A_arbace_core__init_A_const_1381 }




func A_arbace_core__init_A_Unit781__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7005, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1383; var tmp2 any = A_arbace_core_random_uuid_A_New(); var tmp3 *jrt.Class; var fncls__648 *jrt.Class = A_arbace_core_random_uuid_A_fn_class; if fncls__648 == nil { var fncls__648d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1486, false); A_arbace_core_random_uuid_A_fn_class = fncls__648d; tmp3 = fncls__648d } else { tmp3 = fncls__648 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1383; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1384)); return A_arbace_core__init_A_const_1383 }







func A_arbace_core__init_A_Unit782__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7013, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1385; var tmp2 any = A_arbace_core_reduce_A_New(); var tmp3 *jrt.Class; var fncls__649 *jrt.Class = A_arbace_core_reduce_A_fn_class; if fncls__649 == nil { var fncls__649d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1487, false); A_arbace_core_reduce_A_fn_class = fncls__649d; tmp3 = fncls__649d } else { tmp3 = fncls__649 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1385; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1386)); return A_arbace_core__init_A_const_1385 }



















func A_arbace_core__init_A_Unit783__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7033, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_1133.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_212; var tmp3 any = A_arbace_core_eval1927001862_fn__1927001863_A_New(); var tmp4 *jrt.Class; var fncls__650 *jrt.Class = A_arbace_core_eval1927001862_fn__1927001863_A_fn_class; if fncls__650 == nil { var fncls__650d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1488, false); A_arbace_core_eval1927001862_fn__1927001863_A_fn_class = fncls__650d; tmp4 = fncls__650d } else { tmp4 = fncls__650 }; return tmp1.Invoke_O_O__O(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) }

func A_arbace_core__init_A_Unit784__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7035, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_1373.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1387.GetRawRoot__O(); var tmp3 any = A_arbace_core__init_A_const_1388; var tmp4 any = A_arbace_core_eval1927001866_fn__1927001867_A_New(); var tmp5 *jrt.Class; var fncls__651 *jrt.Class = A_arbace_core_eval1927001866_fn__1927001867_A_fn_class; if fncls__651 == nil { var fncls__651d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1489, false); A_arbace_core_eval1927001866_fn__1927001867_A_fn_class = fncls__651d; tmp5 = fncls__651d } else { tmp5 = fncls__651 }; return tmp1.Invoke_O_O_O__O(nil, tmp2, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)))) }
//line :7035:1
func A_arbace_core__init_A_Unit785__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7035, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_1373.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1389; var tmp3 any = A_arbace_core__init_A_const_1387.GetRawRoot__O(); var tmp4 any = A_arbace_core__init_A_const_1388; var tmp5 any = A_arbace_core_eval1927001870_fn__1927001871_A_New(); var tmp6 *jrt.Class; var fncls__652 *jrt.Class = A_arbace_core_eval1927001870_fn__1927001871_A_fn_class; if fncls__652 == nil { var fncls__652d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1490, false); A_arbace_core_eval1927001870_fn__1927001871_A_fn_class = fncls__652d; tmp6 = fncls__652d } else { tmp6 = fncls__652 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :7035:1
func A_arbace_core__init_A_Unit786__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7035, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_1373.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1390; var tmp3 any = A_arbace_core__init_A_const_1387.GetRawRoot__O(); var tmp4 any = A_arbace_core__init_A_const_1388; var tmp5 any = A_arbace_core_eval1927001876_fn__1927001877_A_New(); var tmp6 *jrt.Class; var fncls__653 *jrt.Class = A_arbace_core_eval1927001876_fn__1927001877_A_fn_class; if fncls__653 == nil { var fncls__653d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1491, false); A_arbace_core_eval1927001876_fn__1927001877_A_fn_class = fncls__653d; tmp6 = fncls__653d } else { tmp6 = fncls__653 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }





















func A_arbace_core__init_A_Unit787__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7057, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_956; var tmp2 any = A_arbace_core_reduce_kv_A_New(); var tmp3 *jrt.Class; var fncls__654 *jrt.Class = A_arbace_core_reduce_kv_A_fn_class; if fncls__654 == nil { var fncls__654d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1492, false); A_arbace_core_reduce_kv_A_fn_class = fncls__654d; tmp3 = fncls__654d } else { tmp3 = fncls__654 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_956; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1391)); return A_arbace_core__init_A_const_956 }












func A_arbace_core__init_A_Unit788__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7070, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1392; var tmp2 any = A_arbace_core_completing_A_New(); var tmp3 *jrt.Class; var fncls__655 *jrt.Class = A_arbace_core_completing_A_fn_class; if fncls__655 == nil { var fncls__655d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1493, false); A_arbace_core_completing_A_fn_class = fncls__655d; tmp3 = fncls__655d } else { tmp3 = fncls__655 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1392; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1393)); return A_arbace_core__init_A_const_1392 }











func A_arbace_core__init_A_Unit789__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7082, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1394; var tmp2 any = A_arbace_core_transduce_A_New(); var tmp3 *jrt.Class; var fncls__656 *jrt.Class = A_arbace_core_transduce_A_fn_class; if fncls__656 == nil { var fncls__656d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1494, false); A_arbace_core_transduce_A_fn_class = fncls__656d; tmp3 = fncls__656d } else { tmp3 = fncls__656 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1394; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1395)); return A_arbace_core__init_A_const_1394 }
















func A_arbace_core__init_A_Unit790__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7099, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1396; var tmp2 any = A_arbace_core_into_A_New(); var tmp3 *jrt.Class; var fncls__657 *jrt.Class = A_arbace_core_into_A_fn_class; if fncls__657 == nil { var fncls__657d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1495, false); A_arbace_core_into_A_fn_class = fncls__657d; tmp3 = fncls__657d } else { tmp3 = fncls__657 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1396; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1397)); return A_arbace_core__init_A_const_1396 }

























func A_arbace_core__init_A_Unit791__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7125, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_1133.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_718; var tmp3 any = A_arbace_core_eval1927001888_fn__1927001889_A_New(); var tmp4 *jrt.Class; var fncls__658 *jrt.Class = A_arbace_core_eval1927001888_fn__1927001889_A_fn_class; if fncls__658 == nil { var fncls__658d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1496, false); A_arbace_core_eval1927001888_fn__1927001889_A_fn_class = fncls__658d; tmp4 = fncls__658d } else { tmp4 = fncls__658 }; return tmp1.Invoke_O_O__O(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) }

func A_arbace_core__init_A_Unit792__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7127, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1398; var tmp2 any = A_arbace_core_mapv_A_New(); var tmp3 *jrt.Class; var fncls__659 *jrt.Class = A_arbace_core_mapv_A_fn_class; if fncls__659 == nil { var fncls__659d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1497, true); A_arbace_core_mapv_A_fn_class = fncls__659d; tmp3 = fncls__659d } else { tmp3 = fncls__659 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 4)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1398; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1399)); return A_arbace_core__init_A_const_1398 }

















func A_arbace_core__init_A_Unit793__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7145, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1400; var tmp2 any = A_arbace_core_filterv_A_New(); var tmp3 *jrt.Class; var fncls__660 *jrt.Class = A_arbace_core_filterv_A_fn_class; if fncls__660 == nil { var fncls__660d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1498, false); A_arbace_core_filterv_A_fn_class = fncls__660d; tmp3 = fncls__660d } else { tmp3 = fncls__660 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1400; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1401)); return A_arbace_core__init_A_const_1400 }










func A_arbace_core__init_A_Unit794__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7156, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_627; var tmp2 any = A_arbace_core_select_keys_A_New(); var tmp3 *jrt.Class; var fncls__661 *jrt.Class = A_arbace_core_select_keys_A_fn_class; if fncls__661 == nil { var fncls__661d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1499, false); A_arbace_core_select_keys_A_fn_class = fncls__661d; tmp3 = fncls__661d } else { tmp3 = fncls__661 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_627; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1402)); return A_arbace_core__init_A_const_627 }















func A_arbace_core__init_A_Unit795__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7172, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1403; var tmp2 any = A_arbace_core_merge_deep_A_New(); var tmp3 *jrt.Class; var fncls__662 *jrt.Class = A_arbace_core_merge_deep_A_fn_class; if fncls__662 == nil { var fncls__662d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1500, true); A_arbace_core_merge_deep_A_fn_class = fncls__662d; tmp3 = fncls__662d } else { tmp3 = fncls__662 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1403; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1404)); return A_arbace_core__init_A_const_1403 }













func A_arbace_core__init_A_Unit796__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7186, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1405; var tmp2 any = A_arbace_core_merge_deep_with_A_New(); var tmp3 *jrt.Class; var fncls__663 *jrt.Class = A_arbace_core_merge_deep_with_A_fn_class; if fncls__663 == nil { var fncls__663d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1501, true); A_arbace_core_merge_deep_with_A_fn_class = fncls__663d; tmp3 = fncls__663d } else { tmp3 = fncls__663 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1405; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1406)); return A_arbace_core__init_A_const_1405 }













func A_arbace_core__init_A_Unit797__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7200, 1); return lang.IFn_Cast(A_arbace_core__init_A_const_1215.GetRawRoot__O()).Invoke_O__O(A_arbace_core__init_A_const_1407) }

func A_arbace_core__init_A_Unit798__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7202, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1408; var tmp2 any = A_arbace_core_normalize_slurp_opts_A_New(); var tmp3 *jrt.Class; var fncls__664 *jrt.Class = A_arbace_core_normalize_slurp_opts_A_fn_class; if fncls__664 == nil { var fncls__664d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1502, false); A_arbace_core_normalize_slurp_opts_A_fn_class = fncls__664d; tmp3 = fncls__664d } else { tmp3 = fncls__664 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1408; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1409)); return A_arbace_core__init_A_const_1408 }







func A_arbace_core__init_A_Unit799__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7210, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1410; var tmp2 any = A_arbace_core_slurp_A_New(); var tmp3 *jrt.Class; var fncls__665 *jrt.Class = A_arbace_core_slurp_A_fn_class; if fncls__665 == nil { var fncls__665d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1503, true); A_arbace_core_slurp_A_fn_class = fncls__665d; tmp3 = fncls__665d } else { tmp3 = fncls__665 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1410; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1411)); return A_arbace_core__init_A_const_1410 }











func A_arbace_core__init_A_Unit800__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7222, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1412; var tmp2 any = A_arbace_core_spit_A_New(); var tmp3 *jrt.Class; var fncls__666 *jrt.Class = A_arbace_core_spit_A_fn_class; if fncls__666 == nil { var fncls__666d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1504, true); A_arbace_core_spit_A_fn_class = fncls__666d; tmp3 = fncls__666d } else { tmp3 = fncls__666 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1412; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1413)); return A_arbace_core__init_A_const_1412 }








func A_arbace_core__init_A_Unit801__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7231, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1414; var tmp2 any = A_arbace_core_future_call_A_New(); var tmp3 *jrt.Class; var fncls__667 *jrt.Class = A_arbace_core_future_call_A_fn_class; if fncls__667 == nil { var fncls__667d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1505, false); A_arbace_core_future_call_A_fn_class = fncls__667d; tmp3 = fncls__667d } else { tmp3 = fncls__667 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1414; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1415)); return A_arbace_core__init_A_const_1414 }


























func A_arbace_core__init_A_Unit802__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7258, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1416; var tmp2 any = A_arbace_core_future_A_New(); var tmp3 *jrt.Class; var fncls__668 *jrt.Class = A_arbace_core_future_A_fn_class; if fncls__668 == nil { var fncls__668d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1506, true); A_arbace_core_future_A_fn_class = fncls__668d; tmp3 = fncls__668d } else { tmp3 = fncls__668 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1416; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1417)); return A_arbace_core__init_A_const_1416 }
//line :7258:1
func A_arbace_core__init_A_Unit803__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7258, 1); A_arbace_core__init_A_const_1416.SetMacro__V(); return nil }
//line :7258:1
func A_arbace_core__init_A_Unit804__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7258, 1); return A_arbace_core__init_A_const_1416 }








func A_arbace_core__init_A_Unit805__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7267, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1418; var tmp2 any = A_arbace_core_future_cancel_A_New(); var tmp3 *jrt.Class; var fncls__669 *jrt.Class = A_arbace_core_future_cancel_A_fn_class; if fncls__669 == nil { var fncls__669d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1507, false); A_arbace_core_future_cancel_A_fn_class = fncls__669d; tmp3 = fncls__669d } else { tmp3 = fncls__669 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1418; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1419)); return A_arbace_core__init_A_const_1418 }





func A_arbace_core__init_A_Unit806__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7273, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1420; var tmp2 any = A_arbace_core_future_cancelled_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__670 *jrt.Class = A_arbace_core_future_cancelled_QMARK__A_fn_class; if fncls__670 == nil { var fncls__670d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1508, false); A_arbace_core_future_cancelled_QMARK__A_fn_class = fncls__670d; tmp3 = fncls__670d } else { tmp3 = fncls__670 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1420; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1421)); return A_arbace_core__init_A_const_1420 }





func A_arbace_core__init_A_Unit807__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7279, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1422; var tmp2 any = A_arbace_core_pmap_A_New(); var tmp3 *jrt.Class; var fncls__671 *jrt.Class = A_arbace_core_pmap_A_fn_class; if fncls__671 == nil { var fncls__671d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1509, true); A_arbace_core_pmap_A_fn_class = fncls__671d; tmp3 = fncls__671d } else { tmp3 = fncls__671 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1422; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1423)); return A_arbace_core__init_A_const_1422 }
























func A_arbace_core__init_A_Unit808__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7304, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1424; var tmp2 any = A_arbace_core_pcalls_A_New(); var tmp3 *jrt.Class; var fncls__672 *jrt.Class = A_arbace_core_pcalls_A_fn_class; if fncls__672 == nil { var fncls__672d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1510, true); A_arbace_core_pcalls_A_fn_class = fncls__672d; tmp3 = fncls__672d } else { tmp3 = fncls__672 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1424; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1425)); return A_arbace_core__init_A_const_1424 }






func A_arbace_core__init_A_Unit809__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7311, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1426; var tmp2 any = A_arbace_core_pvalues_A_New(); var tmp3 *jrt.Class; var fncls__673 *jrt.Class = A_arbace_core_pvalues_A_fn_class; if fncls__673 == nil { var fncls__673d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1511, true); A_arbace_core_pvalues_A_fn_class = fncls__673d; tmp3 = fncls__673d } else { tmp3 = fncls__673 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1426; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1427)); return A_arbace_core__init_A_const_1426 }
//line :7311:1
func A_arbace_core__init_A_Unit810__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7311, 1); A_arbace_core__init_A_const_1426.SetMacro__V(); return nil }
//line :7311:1
func A_arbace_core__init_A_Unit811__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7311, 1); return A_arbace_core__init_A_const_1426 }









func A_arbace_core__init_A_Unit812__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7321, 1); var version_string__1 any = Lit_1512; var vec__1927001955__2 any = lang.IFn_Cast(A_arbace_core__init_A_const_1015.GetRawRoot__O()).Invoke_O_O__O(A_arbace_core__init_A_const_1435, version_string__1); var ___3 any = lang.RT_Nth_O_I_O__O(vec__1927001955__2, lang.RT_IntCast_J__I(0), nil); var major__4 any = lang.RT_Nth_O_I_O__O(vec__1927001955__2, lang.RT_IntCast_J__I(1), nil); var minor__5 any = lang.RT_Nth_O_I_O__O(vec__1927001955__2, lang.RT_IntCast_J__I(2), nil); var incremental__6 any = lang.RT_Nth_O_I_O__O(vec__1927001955__2, lang.RT_IntCast_J__I(3), nil); var qualifier__7 any = lang.RT_Nth_O_I_O__O(vec__1927001955__2, lang.RT_IntCast_J__I(4), nil); var snapshot__8 any = lang.RT_Nth_O_I_O__O(vec__1927001955__2, lang.RT_IntCast_J__I(5), nil); var clojure_version__9 any; var tmp1 any = A_arbace_core__init_A_const_1428; var tmp2 any = jrt.Integer_ValueOf_String__Integer(jrt.String_Cast(major__4)).Ref(); var tmp3 any = A_arbace_core__init_A_const_1429; var tmp4 any = jrt.Integer_ValueOf_String__Integer(jrt.String_Cast(minor__5)).Ref(); var tmp5 any = A_arbace_core__init_A_const_1430; var tmp6 any = jrt.Integer_ValueOf_String__Integer(jrt.String_Cast(incremental__6)).Ref(); var tmp7 any = A_arbace_core__init_A_const_1431; var tmp8 any; _ = ___3; _ = snapshot__8; if







	lang.Util_Equiv_O_O__Z(qualifier__7, Lit_1513) { tmp8 = nil } else { tmp8 = qualifier__7 }; clojure_version__9 = /*line :7321:1*/lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8));








	A_arbace_core__init_A_const_1432.SetDynamic_Z__Var(true); var tmp9 *lang.Var = A_arbace_core__init_A_const_1432; tmp9.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1434)); var tmp10 *lang.Var = A_arbace_core__init_A_const_1432; var tmp11 any; if
	jrt.NN(jrt.String_Cast(version_string__1)).Contains_CharSequence__Z(Lit_1513) {
		var tmp12 any = A_arbace_core__init_A_const_1433; var tmp13 *jrt.Boolean; jrt.Boolean_Init(); tmp13 = jrt.Boolean_TRUE; tmp11 = lang.RT_Assoc_O_O_O__Associative(clojure_version__9, tmp12, tmp13.Ref()) } else {
//line :7331:1
			tmp11 = clojure_version__9 }; /*line :7330:1*/tmp10.BindRoot_O__V(tmp11); return A_arbace_core__init_A_const_1432 }




func A_arbace_core__init_A_Unit813__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7335, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_574.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1432; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_core__init_A_const_720.GetRawRoot__O(), lang.IFn_Cast(A_arbace_core__init_A_const_48.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core__init_A_const_1436, A_arbace_core__init_A_const_53, Lit_1514)) }






func A_arbace_core__init_A_Unit814__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7342, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1437; var tmp2 any = A_arbace_core_clojure_version_A_New(); var tmp3 *jrt.Class; var fncls__674 *jrt.Class = A_arbace_core_clojure_version_A_fn_class; if fncls__674 == nil { var fncls__674d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1515, false); A_arbace_core_clojure_version_A_fn_class = fncls__674d; tmp3 = fncls__674d } else { tmp3 = fncls__674 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1437; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1438)); return A_arbace_core__init_A_const_1437 }





















func A_arbace_core__init_A_Unit815__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7364, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1439; var tmp2 any = A_arbace_core_fn__1927001963_A_New(); var tmp3 *jrt.Class; var fncls__675 *jrt.Class = A_arbace_core_fn__1927001963_A_fn_class; if
						fncls__675 == nil { var fncls__675d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1516, false); A_arbace_core_fn__1927001963_A_fn_class = fncls__675d; tmp3 = fncls__675d } else { tmp3 = fncls__675 }; /*line :7364:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()); var tmp4 *lang.Var = A_arbace_core__init_A_const_1439; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1440)); return A_arbace_core__init_A_const_1439.SetDynamic_Z__Var(true).Ref() }












func A_arbace_core__init_A_Unit816__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7377, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_574.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1439; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_core__init_A_const_720.GetRawRoot__O(), lang.IFn_Cast(A_arbace_core__init_A_const_48.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_core__init_A_const_1441, A_arbace_core__init_A_const_53, Lit_1517)) }









func A_arbace_core__init_A_Unit817__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7387, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1442; var tmp2 any = A_arbace_core_arbace_version_A_New(); var tmp3 *jrt.Class; var fncls__676 *jrt.Class = A_arbace_core_arbace_version_A_fn_class; if fncls__676 == nil { var fncls__676d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1518, false); A_arbace_core_arbace_version_A_fn_class = fncls__676d; tmp3 = fncls__676d } else { tmp3 = fncls__676 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1442; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1443)); return A_arbace_core__init_A_const_1442 }







func A_arbace_core__init_A_Unit818__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7395, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1444; var tmp2 any = A_arbace_core_promise_A_New(); var tmp3 *jrt.Class; var fncls__677 *jrt.Class = A_arbace_core_promise_A_fn_class; if fncls__677 == nil { var fncls__677d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1519, false); A_arbace_core_promise_A_fn_class = fncls__677d; tmp3 = fncls__677d } else { tmp3 = fncls__677 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1444; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1445)); return A_arbace_core__init_A_const_1444 }






























func A_arbace_core__init_A_Unit819__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7426, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1446; var tmp2 any = A_arbace_core_deliver_A_New(); var tmp3 *jrt.Class; var fncls__678 *jrt.Class = A_arbace_core_deliver_A_fn_class; if fncls__678 == nil { var fncls__678d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1520, false); A_arbace_core_deliver_A_fn_class = fncls__678d; tmp3 = fncls__678d } else { tmp3 = fncls__678 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1446; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1447)); return A_arbace_core__init_A_const_1446 }






func A_arbace_core__init_A_Unit820__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7433, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1158; var tmp2 any = A_arbace_core_flatten_A_New(); var tmp3 *jrt.Class; var fncls__679 *jrt.Class = A_arbace_core_flatten_A_fn_class; if fncls__679 == nil { var fncls__679d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1521, false); A_arbace_core_flatten_A_fn_class = fncls__679d; tmp3 = fncls__679d } else { tmp3 = fncls__679 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1158; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1448)); return A_arbace_core__init_A_const_1158 }









func A_arbace_core__init_A_Unit821__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7443, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1449; var tmp2 any = A_arbace_core_group_by_A_New(); var tmp3 *jrt.Class; var fncls__680 *jrt.Class = A_arbace_core_group_by_A_fn_class; if fncls__680 == nil { var fncls__680d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1522, false); A_arbace_core_group_by_A_fn_class = fncls__680d; tmp3 = fncls__680d } else { tmp3 = fncls__680 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1449; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1450)); return A_arbace_core__init_A_const_1449 }













func A_arbace_core__init_A_Unit822__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7457, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1451; var tmp2 any = A_arbace_core_partition_by_A_New(); var tmp3 *jrt.Class; var fncls__681 *jrt.Class = A_arbace_core_partition_by_A_fn_class; if fncls__681 == nil { var fncls__681d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1523, false); A_arbace_core_partition_by_A_fn_class = fncls__681d; tmp3 = fncls__681d } else { tmp3 = fncls__681 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1451; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1452)); return A_arbace_core__init_A_const_1451 }










































func A_arbace_core__init_A_Unit823__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7500, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1453; var tmp2 any = A_arbace_core_frequencies_A_New(); var tmp3 *jrt.Class; var fncls__682 *jrt.Class = A_arbace_core_frequencies_A_fn_class; if fncls__682 == nil { var fncls__682d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1524, false); A_arbace_core_frequencies_A_fn_class = fncls__682d; tmp3 = fncls__682d } else { tmp3 = fncls__682 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1453; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1454)); return A_arbace_core__init_A_const_1453 }










func A_arbace_core__init_A_Unit824__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7511, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1455; var tmp2 any = A_arbace_core_reductions_A_New(); var tmp3 *jrt.Class; var fncls__683 *jrt.Class = A_arbace_core_reductions_A_fn_class; if fncls__683 == nil { var fncls__683d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1525, false); A_arbace_core_reductions_A_fn_class = fncls__683d; tmp3 = fncls__683d } else { tmp3 = fncls__683 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1455; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1456)); return A_arbace_core__init_A_const_1455 }
















func A_arbace_core__init_A_Unit825__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7528, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1457; var tmp2 any = A_arbace_core_rand_nth_A_New(); var tmp3 *jrt.Class; var fncls__684 *jrt.Class = A_arbace_core_rand_nth_A_fn_class; if fncls__684 == nil { var fncls__684d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1526, false); A_arbace_core_rand_nth_A_fn_class = fncls__684d; tmp3 = fncls__684d } else { tmp3 = fncls__684 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1457; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1458)); return A_arbace_core__init_A_const_1457 }








func A_arbace_core__init_A_Unit826__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7537, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1459; var tmp2 any = A_arbace_core_partition_all_A_New(); var tmp3 *jrt.Class; var fncls__685 *jrt.Class = A_arbace_core_partition_all_A_fn_class; if fncls__685 == nil { var fncls__685d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1527, false); A_arbace_core_partition_all_A_fn_class = fncls__685d; tmp3 = fncls__685d } else { tmp3 = fncls__685 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1459; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1460)); return A_arbace_core__init_A_const_1459 }

































func A_arbace_core__init_A_Unit827__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7571, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1461; var tmp2 any = A_arbace_core_splitv_at_A_New(); var tmp3 *jrt.Class; var fncls__686 *jrt.Class = A_arbace_core_splitv_at_A_fn_class; if fncls__686 == nil { var fncls__686d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1528, false); A_arbace_core_splitv_at_A_fn_class = fncls__686d; tmp3 = fncls__686d } else { tmp3 = fncls__686 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1461; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1462)); return A_arbace_core__init_A_const_1461 }





func A_arbace_core__init_A_Unit828__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7577, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1463; var tmp2 any = A_arbace_core_partitionv_A_New(); var tmp3 *jrt.Class; var fncls__687 *jrt.Class = A_arbace_core_partitionv_A_fn_class; if fncls__687 == nil { var fncls__687d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1529, false); A_arbace_core_partitionv_A_fn_class = fncls__687d; tmp3 = fncls__687d } else { tmp3 = fncls__687 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1463; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1464)); return A_arbace_core__init_A_const_1463 }






















func A_arbace_core__init_A_Unit829__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7600, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1465; var tmp2 any = A_arbace_core_partitionv_all_A_New(); var tmp3 *jrt.Class; var fncls__688 *jrt.Class = A_arbace_core_partitionv_all_A_fn_class; if fncls__688 == nil { var fncls__688d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1530, false); A_arbace_core_partitionv_all_A_fn_class = fncls__688d; tmp3 = fncls__688d } else { tmp3 = fncls__688 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1465; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1466)); return A_arbace_core__init_A_const_1465 }














func A_arbace_core__init_A_Unit830__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7615, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1467; var tmp2 any = A_arbace_core_shuffle_A_New(); var tmp3 *jrt.Class; var fncls__689 *jrt.Class = A_arbace_core_shuffle_A_fn_class; if fncls__689 == nil { var fncls__689d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1531, false); A_arbace_core_shuffle_A_fn_class = fncls__689d; tmp3 = fncls__689d } else { tmp3 = fncls__689 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1467; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1468)); return A_arbace_core__init_A_const_1467 }








func A_arbace_core__init_A_Unit831__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7624, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1469; var tmp2 any = A_arbace_core_map_indexed_A_New(); var tmp3 *jrt.Class; var fncls__690 *jrt.Class = A_arbace_core_map_indexed_A_fn_class; if fncls__690 == nil { var fncls__690d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1532, false); A_arbace_core_map_indexed_A_fn_class = fncls__690d; tmp3 = fncls__690d } else { tmp3 = fncls__690 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1469; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1470)); return A_arbace_core__init_A_const_1469 }





























func A_arbace_core__init_A_Unit832__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7654, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1471; var tmp2 any = A_arbace_core_keep_A_New(); var tmp3 *jrt.Class; var fncls__691 *jrt.Class = A_arbace_core_keep_A_fn_class; if fncls__691 == nil { var fncls__691d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1533, false); A_arbace_core_keep_A_fn_class = fncls__691d; tmp3 = fncls__691d } else { tmp3 = fncls__691 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1471; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1472)); return A_arbace_core__init_A_const_1471 }
































func A_arbace_core__init_A_Unit833__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7687, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1473; var tmp2 any = A_arbace_core_keep_indexed_A_New(); var tmp3 *jrt.Class; var fncls__692 *jrt.Class = A_arbace_core_keep_indexed_A_fn_class; if fncls__692 == nil { var fncls__692d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1534, false); A_arbace_core_keep_indexed_A_fn_class = fncls__692d; tmp3 = fncls__692d } else { tmp3 = fncls__692 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1473; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1474)); return A_arbace_core__init_A_const_1473 }





































func A_arbace_core__init_A_Unit834__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7725, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1475; var tmp2 any = A_arbace_core_bounded_count_A_New(); var tmp3 *jrt.Class; var fncls__693 *jrt.Class = A_arbace_core_bounded_count_A_fn_class; if fncls__693 == nil { var fncls__693d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1535, false); A_arbace_core_bounded_count_A_fn_class = fncls__693d; tmp3 = fncls__693d } else { tmp3 = fncls__693 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1475; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1476)); return A_arbace_core__init_A_const_1475 }











func A_arbace_core__init_A_Unit835__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7737, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1477; var tmp2 any = A_arbace_core_every_pred_A_New(); var tmp3 *jrt.Class; var fncls__694 *jrt.Class = A_arbace_core_every_pred_A_fn_class; if fncls__694 == nil { var fncls__694d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1536, true); A_arbace_core_every_pred_A_fn_class = fncls__694d; tmp3 = fncls__694d } else { tmp3 = fncls__694 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1477; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1478)); return A_arbace_core__init_A_const_1477 }







































func A_arbace_core__init_A_Unit836__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7777, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1479; var tmp2 any = A_arbace_core_some_fn_A_New(); var tmp3 *jrt.Class; var fncls__695 *jrt.Class = A_arbace_core_some_fn_A_fn_class; if fncls__695 == nil { var fncls__695d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1537, true); A_arbace_core_some_fn_A_fn_class = fncls__695d; tmp3 = fncls__695d } else { tmp3 = fncls__695 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1479; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1480)); return A_arbace_core__init_A_const_1479 }







































func A_arbace_core__init_A_Unit837__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7817, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_64; var tmp2 any = A_arbace_core_assert_valid_fdecl__1_A_New(); var tmp3 *jrt.Class; var fncls__696 *jrt.Class = A_arbace_core_assert_valid_fdecl__1_A_fn_class; if fncls__696 == nil { var fncls__696d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1538, false); A_arbace_core_assert_valid_fdecl__1_A_fn_class = fncls__696d; tmp3 = fncls__696d } else { tmp3 = fncls__696 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1481)); return A_arbace_core__init_A_const_64.SetDynamic_Z__Var(true).Ref() }





















func A_arbace_core__init_A_Unit838__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7839, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1482; var tmp2 any = A_arbace_core_with_redefs_fn_A_New(); var tmp3 *jrt.Class; var fncls__697 *jrt.Class = A_arbace_core_with_redefs_fn_A_fn_class; if fncls__697 == nil { var fncls__697d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1539, false); A_arbace_core_with_redefs_fn_A_fn_class = fncls__697d; tmp3 = fncls__697d } else { tmp3 = fncls__697 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1482; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1483)); return A_arbace_core__init_A_const_1482 }



















func A_arbace_core__init_A_Unit839__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7859, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1484; var tmp2 any = A_arbace_core_with_redefs_A_New(); var tmp3 *jrt.Class; var fncls__698 *jrt.Class = A_arbace_core_with_redefs_A_fn_class; if fncls__698 == nil { var fncls__698d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1540, true); A_arbace_core_with_redefs_A_fn_class = fncls__698d; tmp3 = fncls__698d } else { tmp3 = fncls__698 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1484; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1485)); return A_arbace_core__init_A_const_1484 }
//line :7859:1
func A_arbace_core__init_A_Unit840__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7859, 1); A_arbace_core__init_A_const_1484.SetMacro__V(); return nil }
//line :7859:1
func A_arbace_core__init_A_Unit841__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7859, 1); return A_arbace_core__init_A_const_1484 }














func A_arbace_core__init_A_Unit842__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7874, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1486; var tmp2 any = A_arbace_core_realized_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__699 *jrt.Class = A_arbace_core_realized_QMARK__A_fn_class; if fncls__699 == nil { var fncls__699d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1541, false); A_arbace_core_realized_QMARK__A_fn_class = fncls__699d; tmp3 = fncls__699d } else { tmp3 = fncls__699 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1486; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1487)); return A_arbace_core__init_A_const_1486 }




func A_arbace_core__init_A_Unit843__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7879, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1488; var tmp2 any = A_arbace_core_cond__GT__A_New(); var tmp3 *jrt.Class; var fncls__700 *jrt.Class = A_arbace_core_cond__GT__A_fn_class; if fncls__700 == nil { var fncls__700d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1542, true); A_arbace_core_cond__GT__A_fn_class = fncls__700d; tmp3 = fncls__700d } else { tmp3 = fncls__700 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1488; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1489)); return A_arbace_core__init_A_const_1488 }
//line :7879:1
func A_arbace_core__init_A_Unit844__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7879, 1); A_arbace_core__init_A_const_1488.SetMacro__V(); return nil }
//line :7879:1
func A_arbace_core__init_A_Unit845__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7879, 1); return A_arbace_core__init_A_const_1488 }
















func A_arbace_core__init_A_Unit846__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7896, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1490; var tmp2 any = A_arbace_core_cond__GT__GT__A_New(); var tmp3 *jrt.Class; var fncls__701 *jrt.Class = A_arbace_core_cond__GT__GT__A_fn_class; if fncls__701 == nil { var fncls__701d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1543, true); A_arbace_core_cond__GT__GT__A_fn_class = fncls__701d; tmp3 = fncls__701d } else { tmp3 = fncls__701 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1490; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1491)); return A_arbace_core__init_A_const_1490 }
//line :7896:1
func A_arbace_core__init_A_Unit847__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7896, 1); A_arbace_core__init_A_const_1490.SetMacro__V(); return nil }
//line :7896:1
func A_arbace_core__init_A_Unit848__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7896, 1); return A_arbace_core__init_A_const_1490 }
















func A_arbace_core__init_A_Unit849__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7913, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1492; var tmp2 any = A_arbace_core_as__GT__A_New(); var tmp3 *jrt.Class; var fncls__702 *jrt.Class = A_arbace_core_as__GT__A_fn_class; if fncls__702 == nil { var fncls__702d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1544, true); A_arbace_core_as__GT__A_fn_class = fncls__702d; tmp3 = fncls__702d } else { tmp3 = fncls__702 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 4)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1492; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1493)); return A_arbace_core__init_A_const_1492 }
//line :7913:1
func A_arbace_core__init_A_Unit850__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7913, 1); A_arbace_core__init_A_const_1492.SetMacro__V(); return nil }
//line :7913:1
func A_arbace_core__init_A_Unit851__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7913, 1); return A_arbace_core__init_A_const_1492 }











func A_arbace_core__init_A_Unit852__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7925, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1494; var tmp2 any = A_arbace_core_some__GT__A_New(); var tmp3 *jrt.Class; var fncls__703 *jrt.Class = A_arbace_core_some__GT__A_fn_class; if fncls__703 == nil { var fncls__703d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1545, true); A_arbace_core_some__GT__A_fn_class = fncls__703d; tmp3 = fncls__703d } else { tmp3 = fncls__703 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1494; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1495)); return A_arbace_core__init_A_const_1494 }
//line :7925:1
func A_arbace_core__init_A_Unit853__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7925, 1); A_arbace_core__init_A_const_1494.SetMacro__V(); return nil }
//line :7925:1
func A_arbace_core__init_A_Unit854__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7925, 1); return A_arbace_core__init_A_const_1494 }













func A_arbace_core__init_A_Unit855__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7939, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1496; var tmp2 any = A_arbace_core_some__GT__GT__A_New(); var tmp3 *jrt.Class; var fncls__704 *jrt.Class = A_arbace_core_some__GT__GT__A_fn_class; if fncls__704 == nil { var fncls__704d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1546, true); A_arbace_core_some__GT__GT__A_fn_class = fncls__704d; tmp3 = fncls__704d } else { tmp3 = fncls__704 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1496; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1497)); return A_arbace_core__init_A_const_1496 }
//line :7939:1
func A_arbace_core__init_A_Unit856__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7939, 1); A_arbace_core__init_A_const_1496.SetMacro__V(); return nil }
//line :7939:1
func A_arbace_core__init_A_Unit857__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7939, 1); return A_arbace_core__init_A_const_1496 }













func A_arbace_core__init_A_Unit858__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7953, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1498; var tmp2 any = A_arbace_core_preserving_reduced_A_New(); var tmp3 *jrt.Class; var fncls__705 *jrt.Class = A_arbace_core_preserving_reduced_A_fn_class; if fncls__705 == nil { var fncls__705d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1547, false); A_arbace_core_preserving_reduced_A_fn_class = fncls__705d; tmp3 = fncls__705d } else { tmp3 = fncls__705 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1498; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1499)); return A_arbace_core__init_A_const_1498 }






func A_arbace_core__init_A_Unit859__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7960, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_625; var tmp2 any = A_arbace_core_cat_A_New(); var tmp3 *jrt.Class; var fncls__706 *jrt.Class = A_arbace_core_cat_A_fn_class; if fncls__706 == nil { var fncls__706d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1548, false); A_arbace_core_cat_A_fn_class = fncls__706d; tmp3 = fncls__706d } else { tmp3 = fncls__706 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_625; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1500)); return A_arbace_core__init_A_const_625 }











func A_arbace_core__init_A_Unit860__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7972, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1501; var tmp2 any = A_arbace_core_halt_when_A_New(); var tmp3 *jrt.Class; var fncls__707 *jrt.Class = A_arbace_core_halt_when_A_fn_class; if fncls__707 == nil { var fncls__707d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1549, false); A_arbace_core_halt_when_A_fn_class = fncls__707d; tmp3 = fncls__707d } else { tmp3 = fncls__707 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1501; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1502)); return A_arbace_core__init_A_const_1501 }























func A_arbace_core__init_A_Unit861__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7996, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1503; var tmp2 any = A_arbace_core_dedupe_A_New(); var tmp3 *jrt.Class; var fncls__708 *jrt.Class = A_arbace_core_dedupe_A_fn_class; if fncls__708 == nil { var fncls__708d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1550, false); A_arbace_core_dedupe_A_fn_class = fncls__708d; tmp3 = fncls__708d } else { tmp3 = fncls__708 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1503; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1504)); return A_arbace_core__init_A_const_1503 }

















func A_arbace_core__init_A_Unit862__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8014, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1505; var tmp2 any = A_arbace_core_random_sample_A_New(); var tmp3 *jrt.Class; var fncls__709 *jrt.Class = A_arbace_core_random_sample_A_fn_class; if fncls__709 == nil { var fncls__709d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1551, false); A_arbace_core_random_sample_A_fn_class = fncls__709d; tmp3 = fncls__709d } else { tmp3 = fncls__709 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1505; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1506)); return A_arbace_core__init_A_const_1505 }








func A_arbace_core__init_A_Unit863__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8023, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_1552)); var tmp2 *lang.Var = A_arbace_core__init_A_const_1508; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1509)); var tmp3 *lang.Var = A_arbace_core__init_A_const_1508; var tmp4 any = A_arbace_core_eval1927002196___GT_Eduction__1927002198_A_New(); var tmp5 *jrt.Class; var fncls__710 *jrt.Class = A_arbace_core_eval1927002196___GT_Eduction__1927002198_A_fn_class; if fncls__710 == nil { var fncls__710d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1553, false); A_arbace_core_eval1927002196___GT_Eduction__1927002198_A_fn_class = fncls__710d; tmp5 = fncls__710d } else { tmp5 = fncls__710 }; tmp3.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)); return A_arbace_core__init_A_const_1507 }











func A_arbace_core__init_A_Unit864__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8035, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1510; var tmp2 any = A_arbace_core_eduction_A_New(); var tmp3 *jrt.Class; var fncls__711 *jrt.Class = A_arbace_core_eduction_A_fn_class; if fncls__711 == nil { var fncls__711d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1554, true); A_arbace_core_eduction_A_fn_class = fncls__711d; tmp3 = fncls__711d } else { tmp3 = fncls__711 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1510; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1511)); return A_arbace_core__init_A_const_1510 }









func A_arbace_core__init_A_Unit865__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8045, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_core__init_A_const_799.GetRawRoot__O()); var tmp2 any = A_arbace_core__init_A_const_1507; var tmp3 any = A_arbace_core_eval1927002202_fn__1927002203_A_New(); var tmp4 *jrt.Class; var fncls__712 *jrt.Class = A_arbace_core_eval1927002202_fn__1927002203_A_fn_class; if fncls__712 == nil { var fncls__712d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1555, false); A_arbace_core_eval1927002202_fn__1927002203_A_fn_class = fncls__712d; tmp4 = fncls__712d } else { tmp4 = fncls__712 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_core__init_A_Unit866__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8051, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1512; var tmp2 any = A_arbace_core_run_BANG__A_New(); var tmp3 *jrt.Class; var fncls__713 *jrt.Class = A_arbace_core_run_BANG__A_fn_class; if fncls__713 == nil { var fncls__713d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1556, false); A_arbace_core_run_BANG__A_fn_class = fncls__713d; tmp3 = fncls__713d } else { tmp3 = fncls__713 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1512; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1513)); return A_arbace_core__init_A_const_1512 }







func A_arbace_core__init_A_Unit867__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8059, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1514; var tmp2 any = A_arbace_core_iteration_A_New(); var tmp3 *jrt.Class; var fncls__714 *jrt.Class = A_arbace_core_iteration_A_fn_class; if fncls__714 == nil { var fncls__714d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1557, true); A_arbace_core_iteration_A_fn_class = fncls__714d; tmp3 = fncls__714d } else { tmp3 = fncls__714 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1514; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1515)); return A_arbace_core__init_A_const_1514 }














































func A_arbace_core__init_A_Unit868__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8106, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1516; var tmp2 any = A_arbace_core_tagged_literal_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__715 *jrt.Class = A_arbace_core_tagged_literal_QMARK__A_fn_class; if fncls__715 == nil { var fncls__715d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1558, false); A_arbace_core_tagged_literal_QMARK__A_fn_class = fncls__715d; tmp3 = fncls__715d } else { tmp3 = fncls__715 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1516; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1517)); return A_arbace_core__init_A_const_1516 }





func A_arbace_core__init_A_Unit869__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8112, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1518; var tmp2 any = A_arbace_core_tagged_literal_A_New(); var tmp3 *jrt.Class; var fncls__716 *jrt.Class = A_arbace_core_tagged_literal_A_fn_class; if fncls__716 == nil { var fncls__716d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1559, false); A_arbace_core_tagged_literal_A_fn_class = fncls__716d; tmp3 = fncls__716d } else { tmp3 = fncls__716 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1518; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1519)); return A_arbace_core__init_A_const_1518 }






func A_arbace_core__init_A_Unit870__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8119, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1520; var tmp2 any = A_arbace_core_reader_conditional_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__717 *jrt.Class = A_arbace_core_reader_conditional_QMARK__A_fn_class; if fncls__717 == nil { var fncls__717d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1560, false); A_arbace_core_reader_conditional_QMARK__A_fn_class = fncls__717d; tmp3 = fncls__717d } else { tmp3 = fncls__717 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1520; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1521)); return A_arbace_core__init_A_const_1520 }





func A_arbace_core__init_A_Unit871__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8125, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1522; var tmp2 any = A_arbace_core_reader_conditional_A_New(); var tmp3 *jrt.Class; var fncls__718 *jrt.Class = A_arbace_core_reader_conditional_A_fn_class; if fncls__718 == nil { var fncls__718d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1561, false); A_arbace_core_reader_conditional_A_fn_class = fncls__718d; tmp3 = fncls__718d } else { tmp3 = fncls__718 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1522; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1523)); return A_arbace_core__init_A_const_1522 }








func A_arbace_core__init_A_Unit872__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8134, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1524; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_core__init_A_const_720.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_core__init_A_const_1526, A_arbace_core__init_A_const_1527)), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_core__init_A_const_1528, A_arbace_core__init_A_const_1529)))); var tmp2 *lang.Var = A_arbace_core__init_A_const_1524; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1525)); return A_arbace_core__init_A_const_1524 }






func A_arbace_core__init_A_Unit873__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8141, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1530; var tmp2 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY; tmp1.BindRoot_O__V(tmp2.Ref()); var tmp3 *lang.Var = A_arbace_core__init_A_const_1530; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1531)); return A_arbace_core__init_A_const_1530.SetDynamic_Z__Var(true).Ref() }































func A_arbace_core__init_A_Unit874__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8173, 1); A_arbace_core__init_A_const_1532.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_core__init_A_const_1532; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1533)); return A_arbace_core__init_A_const_1532.SetDynamic_Z__Var(true).Ref() }






func A_arbace_core__init_A_Unit875__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8180, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1534; var tmp2 any = A_arbace_core_data_reader_urls_A_New(); var tmp3 *jrt.Class; var fncls__719 *jrt.Class = A_arbace_core_data_reader_urls_A_fn_class; if fncls__719 == nil { var fncls__719d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1562, false); A_arbace_core_data_reader_urls_A_fn_class = fncls__719d; tmp3 = fncls__719d } else { tmp3 = fncls__719 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1534; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1535)); return A_arbace_core__init_A_const_1534 }






func A_arbace_core__init_A_Unit876__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8187, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1536; var tmp2 any = A_arbace_core_data_reader_var_A_New(); var tmp3 *jrt.Class; var fncls__720 *jrt.Class = A_arbace_core_data_reader_var_A_fn_class; if fncls__720 == nil { var fncls__720d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1563, false); A_arbace_core_data_reader_var_A_fn_class = fncls__720d; tmp3 = fncls__720d } else { tmp3 = fncls__720 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1536; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1537)); return A_arbace_core__init_A_const_1536 }



func A_arbace_core__init_A_Unit877__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8191, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1538; var tmp2 any = A_arbace_core_load_data_reader_file_A_New(); var tmp3 *jrt.Class; var fncls__721 *jrt.Class = A_arbace_core_load_data_reader_file_A_fn_class; if fncls__721 == nil { var fncls__721d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1564, false); A_arbace_core_load_data_reader_file_A_fn_class = fncls__721d; tmp3 = fncls__721d } else { tmp3 = fncls__721 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1538; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1539)); return A_arbace_core__init_A_const_1538 }




























func A_arbace_core__init_A_Unit878__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8220, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1540; var tmp2 any = A_arbace_core_load_data_readers_A_New(); var tmp3 *jrt.Class; var fncls__722 *jrt.Class = A_arbace_core_load_data_readers_A_fn_class; if fncls__722 == nil { var fncls__722d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1565, false); A_arbace_core_load_data_readers_A_fn_class = fncls__722d; tmp3 = fncls__722d } else { tmp3 = fncls__722 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1540; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1541)); return A_arbace_core__init_A_const_1540 }





func A_arbace_core__init_A_Unit879__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8226, 1); var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
						tmp1 = lang.IFn_Cast(A_arbace_core__init_A_const_1540.GetRawRoot__O()).Invoke__O(); return nil }(); if /*line :8226:1*/ tmp2 != nil { if true { var t__3 jrt.Throwable_I = tmp2


		t__3.PrintStackTrace__V()
//line :8226:1
		panic(jrt.Thrown(t__3)) } }; return tmp1 }





func A_arbace_core__init_A_Unit880__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8232, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1542; var tmp2 any = A_arbace_core_uri_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__723 *jrt.Class = A_arbace_core_uri_QMARK__A_fn_class; if fncls__723 == nil { var fncls__723d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1566, false); A_arbace_core_uri_QMARK__A_fn_class = fncls__723d; tmp3 = fncls__723d } else { tmp3 = fncls__723 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1542; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1543)); return A_arbace_core__init_A_const_1542 }




func A_arbace_core__init_A_Unit881__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8237, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_core__init_A_const_1544; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1545)); v__1927001498__auto____1 = A_arbace_core__init_A_const_1544; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_core__init_A_const_1544; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1546)); var tmp3 *lang.Var = A_arbace_core__init_A_const_1544; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_core__init_A_const_558.GetRawRoot__O()); var tmp5 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp5 = lang.PersistentHashSet_EMPTY; tmp3.BindRoot_O__V(tmp4.Invoke_O__O(tmp5.Ref())); return A_arbace_core__init_A_const_1544 } }
func A_arbace_core__init_A_Unit882__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8238, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_core__init_A_const_1547; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1548)); v__1927001498__auto____1 = A_arbace_core__init_A_const_1547; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_core__init_A_const_1547; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1549)); var tmp3 *lang.Var = A_arbace_core__init_A_const_1547; tmp3.BindRoot_O__V(jrt.ArrayBlockingQueue_New_I(lang.RT_IntCast_J__I(1024))); return A_arbace_core__init_A_const_1547 } }

func A_arbace_core__init_A_Unit883__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8240, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_core__init_A_const_1550; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1551)); v__1927001498__auto____1 = A_arbace_core__init_A_const_1550; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_core__init_A_const_1550; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1552)); var tmp3 *lang.Var = A_arbace_core__init_A_const_1550; var tmp4 any = A_arbace_core_eval1927002249_fn__1927002250_A_New(); var tmp5 *jrt.Class; var fncls__724 *jrt.Class = A_arbace_core_eval1927002249_fn__1927002250_A_fn_class
						if fncls__724 == nil { var fncls__724d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1567, false); A_arbace_core_eval1927002249_fn__1927002250_A_fn_class = fncls__724d; tmp5 = fncls__724d } else { tmp5 = fncls__724 }
//line :8240:1
	tmp3.BindRoot_O__V(lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil))); return A_arbace_core__init_A_const_1550 } }














func A_arbace_core__init_A_Unit884__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8255, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1553; var tmp2 any = A_arbace_core_add_tap_A_New(); var tmp3 *jrt.Class; var fncls__725 *jrt.Class = A_arbace_core_add_tap_A_fn_class; if fncls__725 == nil { var fncls__725d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1568, false); A_arbace_core_add_tap_A_fn_class = fncls__725d; tmp3 = fncls__725d } else { tmp3 = fncls__725 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1553; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1554)); return A_arbace_core__init_A_const_1553 }










func A_arbace_core__init_A_Unit885__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8266, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1555; var tmp2 any = A_arbace_core_remove_tap_A_New(); var tmp3 *jrt.Class; var fncls__726 *jrt.Class = A_arbace_core_remove_tap_A_fn_class; if fncls__726 == nil { var fncls__726d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1569, false); A_arbace_core_remove_tap_A_fn_class = fncls__726d; tmp3 = fncls__726d } else { tmp3 = fncls__726 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1555; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1556)); return A_arbace_core__init_A_const_1555 }






func A_arbace_core__init_A_Unit886__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8273, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1557; var tmp2 any = A_arbace_core_tap_GT__A_New(); var tmp3 *jrt.Class; var fncls__727 *jrt.Class = A_arbace_core_tap_GT__A_fn_class; if fncls__727 == nil { var fncls__727d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1570, false); A_arbace_core_tap_GT__A_fn_class = fncls__727d; tmp3 = fncls__727d } else { tmp3 = fncls__727 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1557; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1558)); return A_arbace_core__init_A_const_1557 }







func A_arbace_core__init_A_Unit887__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8281, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1559; var tmp2 any = A_arbace_core_tap__GT__A_New(); var tmp3 *jrt.Class; var fncls__728 *jrt.Class = A_arbace_core_tap__GT__A_fn_class; if fncls__728 == nil { var fncls__728d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1571, false); A_arbace_core_tap__GT__A_fn_class = fncls__728d; tmp3 = fncls__728d } else { tmp3 = fncls__728 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1559; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1560)); return A_arbace_core__init_A_const_1559 }





func A_arbace_core__init_A_Unit888__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8287, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1561; var tmp2 any = A_arbace_core_update_vals_A_New(); var tmp3 *jrt.Class; var fncls__729 *jrt.Class = A_arbace_core_update_vals_A_fn_class; if fncls__729 == nil { var fncls__729d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1572, false); A_arbace_core_update_vals_A_fn_class = fncls__729d; tmp3 = fncls__729d } else { tmp3 = fncls__729 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1561; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1562)); return A_arbace_core__init_A_const_1561 }














func A_arbace_core__init_A_Unit889__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8302, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1563; var tmp2 any = A_arbace_core_update_keys_A_New(); var tmp3 *jrt.Class; var fncls__730 *jrt.Class = A_arbace_core_update_keys_A_fn_class; if fncls__730 == nil { var fncls__730d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1573, false); A_arbace_core_update_keys_A_fn_class = fncls__730d; tmp3 = fncls__730d } else { tmp3 = fncls__730 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1563; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1564)); return A_arbace_core__init_A_const_1563 }














func A_arbace_core__init_A_Unit890__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8317, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1565; var tmp2 any = A_arbace_core_parsing_err_A_New(); var tmp3 *jrt.Class; var fncls__731 *jrt.Class = A_arbace_core_parsing_err_A_fn_class; if fncls__731 == nil { var fncls__731d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1574, false); A_arbace_core_parsing_err_A_fn_class = fncls__731d; tmp3 = fncls__731d } else { tmp3 = fncls__731 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1565; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1566)); return A_arbace_core__init_A_const_1565 }




func A_arbace_core__init_A_Unit891__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8322, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1567; var tmp2 any = A_arbace_core_parse_long_A_New(); var tmp3 *jrt.Class; var fncls__732 *jrt.Class = A_arbace_core_parse_long_A_fn_class; if fncls__732 == nil { var fncls__732d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1575, false); A_arbace_core_parse_long_A_fn_class = fncls__732d; tmp3 = fncls__732d } else { tmp3 = fncls__732 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1567; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1568)); return A_arbace_core__init_A_const_1567 }










func A_arbace_core__init_A_Unit892__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8333, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1569; var tmp2 any = A_arbace_core_parse_double_A_New(); var tmp3 *jrt.Class; var fncls__733 *jrt.Class = A_arbace_core_parse_double_A_fn_class; if fncls__733 == nil { var fncls__733d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1576, false); A_arbace_core_parse_double_A_fn_class = fncls__733d; tmp3 = fncls__733d } else { tmp3 = fncls__733 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1569; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1570)); return A_arbace_core__init_A_const_1569 }












func A_arbace_core__init_A_Unit893__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8346, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1571; var tmp2 any = A_arbace_core_parse_uuid_A_New(); var tmp3 *jrt.Class; var fncls__734 *jrt.Class = A_arbace_core_parse_uuid_A_fn_class; if fncls__734 == nil { var fncls__734d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1577, false); A_arbace_core_parse_uuid_A_fn_class = fncls__734d; tmp3 = fncls__734d } else { tmp3 = fncls__734 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1571; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1572)); return A_arbace_core__init_A_const_1571 }










func A_arbace_core__init_A_Unit894__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8357, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1573; var tmp2 any = A_arbace_core_parse_boolean_A_New(); var tmp3 *jrt.Class; var fncls__735 *jrt.Class = A_arbace_core_parse_boolean_A_fn_class; if fncls__735 == nil { var fncls__735d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1578, false); A_arbace_core_parse_boolean_A_fn_class = fncls__735d; tmp3 = fncls__735d } else { tmp3 = fncls__735 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1573; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1574)); return A_arbace_core__init_A_const_1573 }










func A_arbace_core__init_A_Unit895__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8368, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1575; var tmp2 any = A_arbace_core_NaN_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__736 *jrt.Class = A_arbace_core_NaN_QMARK__A_fn_class; if fncls__736 == nil { var fncls__736d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1579, false); A_arbace_core_NaN_QMARK__A_fn_class = fncls__736d; tmp3 = fncls__736d } else { tmp3 = fncls__736 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1575; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_1576; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_171; var tmp9 any = A_arbace_core__init_A_const_1577; var tmp10 any = A_arbace_core__init_A_const_56; var tmp11 any = A_arbace_core_NaN_QMARK___inliner__1927002281_A_New(); var tmp12 *jrt.Class; var fncls__737 *jrt.Class = A_arbace_core_NaN_QMARK___inliner__1927002281_A_fn_class; if fncls__737 == nil { var fncls__737d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1581, false); A_arbace_core_NaN_QMARK___inliner__1927002281_A_fn_class = fncls__737d; tmp12 = fncls__737d } else { tmp12 = fncls__737 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_1580, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_core__init_A_const_54, Lit_863, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_1578, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_1575 }








func A_arbace_core__init_A_Unit896__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8377, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1579; var tmp2 any = A_arbace_core_infinite_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__738 *jrt.Class = A_arbace_core_infinite_QMARK__A_fn_class; if fncls__738 == nil { var fncls__738d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1582, false); A_arbace_core_infinite_QMARK__A_fn_class = fncls__738d; tmp3 = fncls__738d } else { tmp3 = fncls__738 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1579; var tmp5 any = A_arbace_core__init_A_const_51; var tmp6 any = A_arbace_core__init_A_const_1580; var tmp7 any = A_arbace_core__init_A_const_53; var tmp8 any = A_arbace_core__init_A_const_171; var tmp9 any = A_arbace_core__init_A_const_1581; var tmp10 any = A_arbace_core__init_A_const_56; var tmp11 any = A_arbace_core_infinite_QMARK___inliner__1927002284_A_New(); var tmp12 *jrt.Class; var fncls__739 *jrt.Class = A_arbace_core_infinite_QMARK___inliner__1927002284_A_fn_class; if fncls__739 == nil { var fncls__739d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1584, false); A_arbace_core_infinite_QMARK___inliner__1927002284_A_fn_class = fncls__739d; tmp12 = fncls__739d } else { tmp12 = fncls__739 }; tmp4.SetMeta_IPersistentMap__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, Lit_1583, tmp8, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_core__init_A_const_54, Lit_863, A_arbace_core__init_A_const_57, A_arbace_core__init_A_const_1582, A_arbace_core__init_A_const_59, A_arbace_core__init_A_const_60, A_arbace_core__init_A_const_61, Lit_736))); return A_arbace_core__init_A_const_1579 }







func A_arbace_core__init_A_Unit897__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8385, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1583; var tmp2 any = A_arbace_core_selector_impl_A_New(); var tmp3 *jrt.Class; var fncls__740 *jrt.Class = A_arbace_core_selector_impl_A_fn_class; if fncls__740 == nil { var fncls__740d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1585, false); A_arbace_core_selector_impl_A_fn_class = fncls__740d; tmp3 = fncls__740d } else { tmp3 = fncls__740 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1583; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1584)); return A_arbace_core__init_A_const_1583 }












func A_arbace_core__init_A_Unit898__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8398, 1); var tmp1 *lang.Var = A_arbace_core__init_A_const_1585; var tmp2 any = A_arbace_core_selector_A_New(); var tmp3 *jrt.Class; var fncls__741 *jrt.Class = A_arbace_core_selector_A_fn_class; if fncls__741 == nil { var fncls__741d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1586, false); A_arbace_core_selector_A_fn_class = fncls__741d; tmp3 = fncls__741d } else { tmp3 = fncls__741 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core__init_A_const_1585; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core__init_A_const_1586)); return A_arbace_core__init_A_const_1585 }
//line :8398:1
func A_arbace_core__init_A_Unit899__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8398, 1); A_arbace_core__init_A_const_1585.SetMacro__V(); return nil }
//line :8398:1
func A_arbace_core__init_A_Unit900__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8398, 1); return A_arbace_core__init_A_const_1585 }
























func A_arbace_core__init_A_Unit901__O() any { A_arbace_core__init_A_Init(); lang.Compiler_AOT_At_I_I__V(8423, 1); return lang.IFn_Cast(A_arbace_core__init_A_const_1203.GetRawRoot__O()).Invoke_O__O(Lit_1587) }



type A_arbace_core__init_A struct{ jrt.Object }

var A_arbace_core__init_A_const_pool *jrt.RefArray

var A_arbace_core__init_A_const_0 any

var A_arbace_core__init_A_const_1 any

var A_arbace_core__init_A_const_2 *lang.Var

var A_arbace_core__init_A_const_3 any

var A_arbace_core__init_A_const_4 *lang.Var

var A_arbace_core__init_A_const_5 any

var A_arbace_core__init_A_const_6 *lang.Var

var A_arbace_core__init_A_const_7 any

var A_arbace_core__init_A_const_8 *lang.Var

var A_arbace_core__init_A_const_9 any

var A_arbace_core__init_A_const_10 *lang.Var

var A_arbace_core__init_A_const_11 any

var A_arbace_core__init_A_const_12 *lang.Var

var A_arbace_core__init_A_const_13 any

var A_arbace_core__init_A_const_14 *lang.Var

var A_arbace_core__init_A_const_15 any

var A_arbace_core__init_A_const_16 *lang.Var

var A_arbace_core__init_A_const_17 any

var A_arbace_core__init_A_const_18 *lang.Var

var A_arbace_core__init_A_const_19 any

var A_arbace_core__init_A_const_20 *lang.Var

var A_arbace_core__init_A_const_21 any

var A_arbace_core__init_A_const_22 *lang.Var

var A_arbace_core__init_A_const_23 any

var A_arbace_core__init_A_const_24 *lang.Var

var A_arbace_core__init_A_const_25 any

var A_arbace_core__init_A_const_26 *lang.Var

var A_arbace_core__init_A_const_27 any

var A_arbace_core__init_A_const_28 *lang.Var

var A_arbace_core__init_A_const_29 any

var A_arbace_core__init_A_const_30 *lang.Var

var A_arbace_core__init_A_const_31 any

var A_arbace_core__init_A_const_32 *lang.Var

var A_arbace_core__init_A_const_33 any

var A_arbace_core__init_A_const_34 *lang.Var

var A_arbace_core__init_A_const_35 any

var A_arbace_core__init_A_const_36 *lang.Var

var A_arbace_core__init_A_const_37 any

var A_arbace_core__init_A_const_38 *lang.Var

var A_arbace_core__init_A_const_39 any

var A_arbace_core__init_A_const_40 *lang.Var

var A_arbace_core__init_A_const_41 any

var A_arbace_core__init_A_const_42 *lang.Var

var A_arbace_core__init_A_const_43 any

var A_arbace_core__init_A_const_44 *lang.Var

var A_arbace_core__init_A_const_45 any

var A_arbace_core__init_A_const_46 *lang.Var

var A_arbace_core__init_A_const_47 any

var A_arbace_core__init_A_const_48 *lang.Var

var A_arbace_core__init_A_const_49 any

var A_arbace_core__init_A_const_50 *lang.Var

var A_arbace_core__init_A_const_51 *lang.Keyword

var A_arbace_core__init_A_const_52 any

var A_arbace_core__init_A_const_53 *lang.Keyword

var A_arbace_core__init_A_const_54 *lang.Keyword

var A_arbace_core__init_A_const_55 *lang.Keyword

var A_arbace_core__init_A_const_56 *lang.Keyword

var A_arbace_core__init_A_const_57 *lang.Keyword

var A_arbace_core__init_A_const_58 any

var A_arbace_core__init_A_const_59 *lang.Keyword

var A_arbace_core__init_A_const_60 any

var A_arbace_core__init_A_const_61 *lang.Keyword

var A_arbace_core__init_A_const_62 *lang.Var

var A_arbace_core__init_A_const_63 any

var A_arbace_core__init_A_const_64 *lang.Var

var A_arbace_core__init_A_const_65 any

var A_arbace_core__init_A_const_66 *lang.Var

var A_arbace_core__init_A_const_67 any

var A_arbace_core__init_A_const_68 *lang.Var

var A_arbace_core__init_A_const_69 any

var A_arbace_core__init_A_const_70 *lang.Var

var A_arbace_core__init_A_const_71 any

var A_arbace_core__init_A_const_72 *lang.Var

var A_arbace_core__init_A_const_73 any

var A_arbace_core__init_A_const_74 *lang.Var

var A_arbace_core__init_A_const_75 any

var A_arbace_core__init_A_const_76 *lang.Var

var A_arbace_core__init_A_const_77 any

var A_arbace_core__init_A_const_78 *lang.Var

var A_arbace_core__init_A_const_79 any

var A_arbace_core__init_A_const_80 *lang.Var

var A_arbace_core__init_A_const_81 any

var A_arbace_core__init_A_const_82 *lang.Var

var A_arbace_core__init_A_const_83 any

var A_arbace_core__init_A_const_84 *lang.Var

var A_arbace_core__init_A_const_85 any

var A_arbace_core__init_A_const_86 *lang.Var

var A_arbace_core__init_A_const_87 any

var A_arbace_core__init_A_const_88 *lang.Var

var A_arbace_core__init_A_const_89 any

var A_arbace_core__init_A_const_90 *lang.Var

var A_arbace_core__init_A_const_91 any

var A_arbace_core__init_A_const_92 *lang.Var

var A_arbace_core__init_A_const_93 any

var A_arbace_core__init_A_const_94 *lang.Var

var A_arbace_core__init_A_const_95 any

var A_arbace_core__init_A_const_96 *lang.Keyword

var A_arbace_core__init_A_const_97 *jrt.Class

var A_arbace_core__init_A_const_98 any

var A_arbace_core__init_A_const_99 *lang.Var

var A_arbace_core__init_A_const_100 any

var A_arbace_core__init_A_const_101 *lang.Var

var A_arbace_core__init_A_const_102 any

var A_arbace_core__init_A_const_103 *lang.Var

var A_arbace_core__init_A_const_104 any

var A_arbace_core__init_A_const_105 *lang.Var

var A_arbace_core__init_A_const_106 any

var A_arbace_core__init_A_const_107 *lang.Var

var A_arbace_core__init_A_const_108 any

var A_arbace_core__init_A_const_109 *lang.Var

var A_arbace_core__init_A_const_110 any

var A_arbace_core__init_A_const_111 *lang.Var

var A_arbace_core__init_A_const_112 any

var A_arbace_core__init_A_const_113 *lang.Var

var A_arbace_core__init_A_const_114 any

var A_arbace_core__init_A_const_115 *lang.Var

var A_arbace_core__init_A_const_116 any

var A_arbace_core__init_A_const_117 *lang.Var

var A_arbace_core__init_A_const_118 any

var A_arbace_core__init_A_const_119 *lang.Var

var A_arbace_core__init_A_const_120 any

var A_arbace_core__init_A_const_121 *lang.Var

var A_arbace_core__init_A_const_122 any

var A_arbace_core__init_A_const_123 *lang.Var

var A_arbace_core__init_A_const_124 any

var A_arbace_core__init_A_const_125 *lang.Var

var A_arbace_core__init_A_const_126 any

var A_arbace_core__init_A_const_127 *lang.Var

var A_arbace_core__init_A_const_128 any

var A_arbace_core__init_A_const_129 *lang.Var

var A_arbace_core__init_A_const_130 any

var A_arbace_core__init_A_const_131 *lang.Var

var A_arbace_core__init_A_const_132 any

var A_arbace_core__init_A_const_133 *lang.Var

var A_arbace_core__init_A_const_134 any

var A_arbace_core__init_A_const_135 *lang.Var

var A_arbace_core__init_A_const_136 any

var A_arbace_core__init_A_const_137 *lang.Var

var A_arbace_core__init_A_const_138 any

var A_arbace_core__init_A_const_139 *lang.Var

var A_arbace_core__init_A_const_140 any

var A_arbace_core__init_A_const_141 *lang.Var

var A_arbace_core__init_A_const_142 any

var A_arbace_core__init_A_const_143 *lang.Var

var A_arbace_core__init_A_const_144 any

var A_arbace_core__init_A_const_145 *lang.Var

var A_arbace_core__init_A_const_146 any

var A_arbace_core__init_A_const_147 *lang.Var

var A_arbace_core__init_A_const_148 any

var A_arbace_core__init_A_const_149 *lang.Var

var A_arbace_core__init_A_const_150 any

var A_arbace_core__init_A_const_151 *lang.Var

var A_arbace_core__init_A_const_152 any

var A_arbace_core__init_A_const_153 *lang.Var

var A_arbace_core__init_A_const_154 any

var A_arbace_core__init_A_const_155 *lang.Var

var A_arbace_core__init_A_const_156 any

var A_arbace_core__init_A_const_157 *lang.Var

var A_arbace_core__init_A_const_158 any

var A_arbace_core__init_A_const_159 *lang.Var

var A_arbace_core__init_A_const_160 any

var A_arbace_core__init_A_const_161 *lang.Var

var A_arbace_core__init_A_const_162 any

var A_arbace_core__init_A_const_163 *lang.Var

var A_arbace_core__init_A_const_164 any

var A_arbace_core__init_A_const_165 *lang.Var

var A_arbace_core__init_A_const_166 any

var A_arbace_core__init_A_const_167 *lang.Var

var A_arbace_core__init_A_const_168 any

var A_arbace_core__init_A_const_169 *lang.Var

var A_arbace_core__init_A_const_170 any

var A_arbace_core__init_A_const_171 *lang.Keyword

var A_arbace_core__init_A_const_172 any

var A_arbace_core__init_A_const_173 any

var A_arbace_core__init_A_const_174 *lang.Var

var A_arbace_core__init_A_const_175 any

var A_arbace_core__init_A_const_176 any

var A_arbace_core__init_A_const_177 any

var A_arbace_core__init_A_const_178 *lang.Var

var A_arbace_core__init_A_const_179 any

var A_arbace_core__init_A_const_180 *lang.Var

var A_arbace_core__init_A_const_181 any

var A_arbace_core__init_A_const_182 any

var A_arbace_core__init_A_const_183 *lang.Var

var A_arbace_core__init_A_const_184 any

var A_arbace_core__init_A_const_185 *lang.Var

var A_arbace_core__init_A_const_186 any

var A_arbace_core__init_A_const_187 *lang.Var

var A_arbace_core__init_A_const_188 any

var A_arbace_core__init_A_const_189 any

var A_arbace_core__init_A_const_190 *lang.Var

var A_arbace_core__init_A_const_191 any

var A_arbace_core__init_A_const_192 any

var A_arbace_core__init_A_const_193 *lang.Var

var A_arbace_core__init_A_const_194 any

var A_arbace_core__init_A_const_195 any

var A_arbace_core__init_A_const_196 *lang.Var

var A_arbace_core__init_A_const_197 any

var A_arbace_core__init_A_const_198 any

var A_arbace_core__init_A_const_199 any

var A_arbace_core__init_A_const_200 *lang.Var

var A_arbace_core__init_A_const_201 any

var A_arbace_core__init_A_const_202 any

var A_arbace_core__init_A_const_203 any

var A_arbace_core__init_A_const_204 *lang.Var

var A_arbace_core__init_A_const_205 any

var A_arbace_core__init_A_const_206 any

var A_arbace_core__init_A_const_207 *lang.Var

var A_arbace_core__init_A_const_208 any

var A_arbace_core__init_A_const_209 any

var A_arbace_core__init_A_const_210 *lang.Var

var A_arbace_core__init_A_const_211 any

var A_arbace_core__init_A_const_212 *lang.Var

var A_arbace_core__init_A_const_213 any

var A_arbace_core__init_A_const_214 *lang.Var

var A_arbace_core__init_A_const_215 any

var A_arbace_core__init_A_const_216 *lang.Var

var A_arbace_core__init_A_const_217 any

var A_arbace_core__init_A_const_218 *lang.Var

var A_arbace_core__init_A_const_219 any

var A_arbace_core__init_A_const_220 *lang.Var

var A_arbace_core__init_A_const_221 any

var A_arbace_core__init_A_const_222 *lang.Var

var A_arbace_core__init_A_const_223 any

var A_arbace_core__init_A_const_224 any

var A_arbace_core__init_A_const_225 any

var A_arbace_core__init_A_const_226 *lang.Var

var A_arbace_core__init_A_const_227 any

var A_arbace_core__init_A_const_228 any

var A_arbace_core__init_A_const_229 any

var A_arbace_core__init_A_const_230 any

var A_arbace_core__init_A_const_231 *lang.Var

var A_arbace_core__init_A_const_232 any

var A_arbace_core__init_A_const_233 any

var A_arbace_core__init_A_const_234 any

var A_arbace_core__init_A_const_235 *lang.Var

var A_arbace_core__init_A_const_236 any

var A_arbace_core__init_A_const_237 any

var A_arbace_core__init_A_const_238 any

var A_arbace_core__init_A_const_239 any

var A_arbace_core__init_A_const_240 *lang.Var

var A_arbace_core__init_A_const_241 any

var A_arbace_core__init_A_const_242 any

var A_arbace_core__init_A_const_243 any

var A_arbace_core__init_A_const_244 *lang.Var

var A_arbace_core__init_A_const_245 any

var A_arbace_core__init_A_const_246 any

var A_arbace_core__init_A_const_247 any

var A_arbace_core__init_A_const_248 *lang.Var

var A_arbace_core__init_A_const_249 any

var A_arbace_core__init_A_const_250 any

var A_arbace_core__init_A_const_251 any

var A_arbace_core__init_A_const_252 any

var A_arbace_core__init_A_const_253 *lang.Var

var A_arbace_core__init_A_const_254 any

var A_arbace_core__init_A_const_255 any

var A_arbace_core__init_A_const_256 any

var A_arbace_core__init_A_const_257 *lang.Var

var A_arbace_core__init_A_const_258 any

var A_arbace_core__init_A_const_259 any

var A_arbace_core__init_A_const_260 any

var A_arbace_core__init_A_const_261 *lang.Var

var A_arbace_core__init_A_const_262 any

var A_arbace_core__init_A_const_263 any

var A_arbace_core__init_A_const_264 any

var A_arbace_core__init_A_const_265 *lang.Var

var A_arbace_core__init_A_const_266 any

var A_arbace_core__init_A_const_267 any

var A_arbace_core__init_A_const_268 any

var A_arbace_core__init_A_const_269 *lang.Var

var A_arbace_core__init_A_const_270 any

var A_arbace_core__init_A_const_271 any

var A_arbace_core__init_A_const_272 any

var A_arbace_core__init_A_const_273 *lang.Var

var A_arbace_core__init_A_const_274 any

var A_arbace_core__init_A_const_275 any

var A_arbace_core__init_A_const_276 any

var A_arbace_core__init_A_const_277 *lang.Var

var A_arbace_core__init_A_const_278 any

var A_arbace_core__init_A_const_279 any

var A_arbace_core__init_A_const_280 any

var A_arbace_core__init_A_const_281 *lang.Var

var A_arbace_core__init_A_const_282 any

var A_arbace_core__init_A_const_283 any

var A_arbace_core__init_A_const_284 *lang.Var

var A_arbace_core__init_A_const_285 any

var A_arbace_core__init_A_const_286 any

var A_arbace_core__init_A_const_287 *lang.Var

var A_arbace_core__init_A_const_288 any

var A_arbace_core__init_A_const_289 any

var A_arbace_core__init_A_const_290 *lang.Var

var A_arbace_core__init_A_const_291 any

var A_arbace_core__init_A_const_292 any

var A_arbace_core__init_A_const_293 *lang.Var

var A_arbace_core__init_A_const_294 any

var A_arbace_core__init_A_const_295 any

var A_arbace_core__init_A_const_296 *lang.Var

var A_arbace_core__init_A_const_297 any

var A_arbace_core__init_A_const_298 any

var A_arbace_core__init_A_const_299 *lang.Var

var A_arbace_core__init_A_const_300 any

var A_arbace_core__init_A_const_301 any

var A_arbace_core__init_A_const_302 *lang.Var

var A_arbace_core__init_A_const_303 any

var A_arbace_core__init_A_const_304 any

var A_arbace_core__init_A_const_305 *lang.Var

var A_arbace_core__init_A_const_306 any

var A_arbace_core__init_A_const_307 any

var A_arbace_core__init_A_const_308 *lang.Var

var A_arbace_core__init_A_const_309 any

var A_arbace_core__init_A_const_310 any

var A_arbace_core__init_A_const_311 *lang.Var

var A_arbace_core__init_A_const_312 any

var A_arbace_core__init_A_const_313 any

var A_arbace_core__init_A_const_314 *lang.Var

var A_arbace_core__init_A_const_315 any

var A_arbace_core__init_A_const_316 any

var A_arbace_core__init_A_const_317 *lang.Var

var A_arbace_core__init_A_const_318 any

var A_arbace_core__init_A_const_319 any

var A_arbace_core__init_A_const_320 *lang.Var

var A_arbace_core__init_A_const_321 any

var A_arbace_core__init_A_const_322 any

var A_arbace_core__init_A_const_323 *lang.Var

var A_arbace_core__init_A_const_324 any

var A_arbace_core__init_A_const_325 any

var A_arbace_core__init_A_const_326 *lang.Var

var A_arbace_core__init_A_const_327 any

var A_arbace_core__init_A_const_328 any

var A_arbace_core__init_A_const_329 *lang.Var

var A_arbace_core__init_A_const_330 any

var A_arbace_core__init_A_const_331 any

var A_arbace_core__init_A_const_332 *lang.Var

var A_arbace_core__init_A_const_333 any

var A_arbace_core__init_A_const_334 any

var A_arbace_core__init_A_const_335 *lang.Var

var A_arbace_core__init_A_const_336 any

var A_arbace_core__init_A_const_337 any

var A_arbace_core__init_A_const_338 *lang.Var

var A_arbace_core__init_A_const_339 any

var A_arbace_core__init_A_const_340 any

var A_arbace_core__init_A_const_341 *lang.Var

var A_arbace_core__init_A_const_342 any

var A_arbace_core__init_A_const_343 *lang.Var

var A_arbace_core__init_A_const_344 any

var A_arbace_core__init_A_const_345 any

var A_arbace_core__init_A_const_346 *lang.Var

var A_arbace_core__init_A_const_347 any

var A_arbace_core__init_A_const_348 any

var A_arbace_core__init_A_const_349 any

var A_arbace_core__init_A_const_350 *lang.Var

var A_arbace_core__init_A_const_351 any

var A_arbace_core__init_A_const_352 any

var A_arbace_core__init_A_const_353 any

var A_arbace_core__init_A_const_354 *lang.Var

var A_arbace_core__init_A_const_355 any

var A_arbace_core__init_A_const_356 any

var A_arbace_core__init_A_const_357 any

var A_arbace_core__init_A_const_358 *lang.Var

var A_arbace_core__init_A_const_359 any

var A_arbace_core__init_A_const_360 any

var A_arbace_core__init_A_const_361 any

var A_arbace_core__init_A_const_362 *lang.Var

var A_arbace_core__init_A_const_363 any

var A_arbace_core__init_A_const_364 *lang.Var

var A_arbace_core__init_A_const_365 any

var A_arbace_core__init_A_const_366 *lang.Var

var A_arbace_core__init_A_const_367 any

var A_arbace_core__init_A_const_368 *lang.Var

var A_arbace_core__init_A_const_369 any

var A_arbace_core__init_A_const_370 *lang.Var

var A_arbace_core__init_A_const_371 any

var A_arbace_core__init_A_const_372 any

var A_arbace_core__init_A_const_373 *lang.Var

var A_arbace_core__init_A_const_374 any

var A_arbace_core__init_A_const_375 any

var A_arbace_core__init_A_const_376 *lang.Var

var A_arbace_core__init_A_const_377 any

var A_arbace_core__init_A_const_378 any

var A_arbace_core__init_A_const_379 *lang.Var

var A_arbace_core__init_A_const_380 any

var A_arbace_core__init_A_const_381 *lang.Var

var A_arbace_core__init_A_const_382 any

var A_arbace_core__init_A_const_383 *lang.Var

var A_arbace_core__init_A_const_384 any

var A_arbace_core__init_A_const_385 *lang.Var

var A_arbace_core__init_A_const_386 any

var A_arbace_core__init_A_const_387 *lang.Var

var A_arbace_core__init_A_const_388 any

var A_arbace_core__init_A_const_389 *lang.Var

var A_arbace_core__init_A_const_390 any

var A_arbace_core__init_A_const_391 *lang.Var

var A_arbace_core__init_A_const_392 any

var A_arbace_core__init_A_const_393 *lang.Var

var A_arbace_core__init_A_const_394 any

var A_arbace_core__init_A_const_395 *lang.Var

var A_arbace_core__init_A_const_396 any

var A_arbace_core__init_A_const_397 *lang.Var

var A_arbace_core__init_A_const_398 any

var A_arbace_core__init_A_const_399 *lang.Var

var A_arbace_core__init_A_const_400 any

var A_arbace_core__init_A_const_401 *lang.Var

var A_arbace_core__init_A_const_402 any

var A_arbace_core__init_A_const_403 *lang.Var

var A_arbace_core__init_A_const_404 any

var A_arbace_core__init_A_const_405 *lang.Var

var A_arbace_core__init_A_const_406 any

var A_arbace_core__init_A_const_407 *lang.Var

var A_arbace_core__init_A_const_408 any

var A_arbace_core__init_A_const_409 *lang.Var

var A_arbace_core__init_A_const_410 any

var A_arbace_core__init_A_const_411 any

var A_arbace_core__init_A_const_412 any

var A_arbace_core__init_A_const_413 *lang.Var

var A_arbace_core__init_A_const_414 any

var A_arbace_core__init_A_const_415 any

var A_arbace_core__init_A_const_416 any

var A_arbace_core__init_A_const_417 *lang.Var

var A_arbace_core__init_A_const_418 any

var A_arbace_core__init_A_const_419 *lang.Var

var A_arbace_core__init_A_const_420 any

var A_arbace_core__init_A_const_421 *lang.Var

var A_arbace_core__init_A_const_422 any

var A_arbace_core__init_A_const_423 *lang.Var

var A_arbace_core__init_A_const_424 any

var A_arbace_core__init_A_const_425 *lang.Var

var A_arbace_core__init_A_const_426 any

var A_arbace_core__init_A_const_427 *lang.Var

var A_arbace_core__init_A_const_428 any

var A_arbace_core__init_A_const_429 *lang.Var

var A_arbace_core__init_A_const_430 any

var A_arbace_core__init_A_const_431 *lang.Var

var A_arbace_core__init_A_const_432 any

var A_arbace_core__init_A_const_433 *lang.Var

var A_arbace_core__init_A_const_434 any

var A_arbace_core__init_A_const_435 *lang.Var

var A_arbace_core__init_A_const_436 any

var A_arbace_core__init_A_const_437 *lang.Var

var A_arbace_core__init_A_const_438 any

var A_arbace_core__init_A_const_439 any

var A_arbace_core__init_A_const_440 *lang.Var

var A_arbace_core__init_A_const_441 any

var A_arbace_core__init_A_const_442 *lang.Var

var A_arbace_core__init_A_const_443 any

var A_arbace_core__init_A_const_444 *lang.Var

var A_arbace_core__init_A_const_445 any

var A_arbace_core__init_A_const_446 *lang.Var

var A_arbace_core__init_A_const_447 any

var A_arbace_core__init_A_const_448 *lang.Var

var A_arbace_core__init_A_const_449 any

var A_arbace_core__init_A_const_450 *lang.Var

var A_arbace_core__init_A_const_451 any

var A_arbace_core__init_A_const_452 *lang.Var

var A_arbace_core__init_A_const_453 any

var A_arbace_core__init_A_const_454 *lang.Var

var A_arbace_core__init_A_const_455 any

var A_arbace_core__init_A_const_456 *lang.Var

var A_arbace_core__init_A_const_457 any

var A_arbace_core__init_A_const_458 *lang.Var

var A_arbace_core__init_A_const_459 any

var A_arbace_core__init_A_const_460 *lang.Var

var A_arbace_core__init_A_const_461 any

var A_arbace_core__init_A_const_462 *lang.Var

var A_arbace_core__init_A_const_463 any

var A_arbace_core__init_A_const_464 *lang.Var

var A_arbace_core__init_A_const_465 any

var A_arbace_core__init_A_const_466 *lang.Var

var A_arbace_core__init_A_const_467 any

var A_arbace_core__init_A_const_468 *lang.Var

var A_arbace_core__init_A_const_469 any

var A_arbace_core__init_A_const_470 *lang.Var

var A_arbace_core__init_A_const_471 any

var A_arbace_core__init_A_const_472 *lang.Var

var A_arbace_core__init_A_const_473 any

var A_arbace_core__init_A_const_474 *lang.Var

var A_arbace_core__init_A_const_475 any

var A_arbace_core__init_A_const_476 *lang.Var

var A_arbace_core__init_A_const_477 any

var A_arbace_core__init_A_const_478 *lang.Var

var A_arbace_core__init_A_const_479 any

var A_arbace_core__init_A_const_480 *lang.Var

var A_arbace_core__init_A_const_481 any

var A_arbace_core__init_A_const_482 *lang.Var

var A_arbace_core__init_A_const_483 any

var A_arbace_core__init_A_const_484 *lang.Var

var A_arbace_core__init_A_const_485 any

var A_arbace_core__init_A_const_486 *lang.Var

var A_arbace_core__init_A_const_487 any

var A_arbace_core__init_A_const_488 *lang.Var

var A_arbace_core__init_A_const_489 any

var A_arbace_core__init_A_const_490 *lang.Var

var A_arbace_core__init_A_const_491 any

var A_arbace_core__init_A_const_492 *lang.Var

var A_arbace_core__init_A_const_493 any

var A_arbace_core__init_A_const_494 *lang.Var

var A_arbace_core__init_A_const_495 any

var A_arbace_core__init_A_const_496 *lang.Var

var A_arbace_core__init_A_const_497 any

var A_arbace_core__init_A_const_498 *lang.Var

var A_arbace_core__init_A_const_499 any

var A_arbace_core__init_A_const_500 *lang.Var

var A_arbace_core__init_A_const_501 any

var A_arbace_core__init_A_const_502 *lang.Var

var A_arbace_core__init_A_const_503 any

var A_arbace_core__init_A_const_504 *lang.Var

var A_arbace_core__init_A_const_505 any

var A_arbace_core__init_A_const_506 *lang.Var

var A_arbace_core__init_A_const_507 any

var A_arbace_core__init_A_const_508 *lang.Var

var A_arbace_core__init_A_const_509 any

var A_arbace_core__init_A_const_510 *lang.Var

var A_arbace_core__init_A_const_511 any

var A_arbace_core__init_A_const_512 *lang.Var

var A_arbace_core__init_A_const_513 any

var A_arbace_core__init_A_const_514 *lang.Var

var A_arbace_core__init_A_const_515 any

var A_arbace_core__init_A_const_516 *lang.Var

var A_arbace_core__init_A_const_517 any

var A_arbace_core__init_A_const_518 *lang.Var

var A_arbace_core__init_A_const_519 any

var A_arbace_core__init_A_const_520 *lang.Var

var A_arbace_core__init_A_const_521 any

var A_arbace_core__init_A_const_522 *lang.Var

var A_arbace_core__init_A_const_523 any

var A_arbace_core__init_A_const_524 *lang.Var

var A_arbace_core__init_A_const_525 any

var A_arbace_core__init_A_const_526 *lang.Var

var A_arbace_core__init_A_const_527 any

var A_arbace_core__init_A_const_528 *lang.Var

var A_arbace_core__init_A_const_529 any

var A_arbace_core__init_A_const_530 *lang.Var

var A_arbace_core__init_A_const_531 any

var A_arbace_core__init_A_const_532 *lang.Var

var A_arbace_core__init_A_const_533 any

var A_arbace_core__init_A_const_534 *lang.Var

var A_arbace_core__init_A_const_535 any

var A_arbace_core__init_A_const_536 *lang.Var

var A_arbace_core__init_A_const_537 any

var A_arbace_core__init_A_const_538 *lang.Var

var A_arbace_core__init_A_const_539 any

var A_arbace_core__init_A_const_540 *lang.Var

var A_arbace_core__init_A_const_541 any

var A_arbace_core__init_A_const_542 *lang.Var

var A_arbace_core__init_A_const_543 any

var A_arbace_core__init_A_const_544 *lang.Var

var A_arbace_core__init_A_const_545 any

var A_arbace_core__init_A_const_546 *lang.Var

var A_arbace_core__init_A_const_547 any

var A_arbace_core__init_A_const_548 *lang.Var

var A_arbace_core__init_A_const_549 any

var A_arbace_core__init_A_const_550 *lang.Var

var A_arbace_core__init_A_const_551 any

var A_arbace_core__init_A_const_552 *lang.Var

var A_arbace_core__init_A_const_553 any

var A_arbace_core__init_A_const_554 *lang.Var

var A_arbace_core__init_A_const_555 any

var A_arbace_core__init_A_const_556 *lang.Var

var A_arbace_core__init_A_const_557 any

var A_arbace_core__init_A_const_558 *lang.Var

var A_arbace_core__init_A_const_559 any

var A_arbace_core__init_A_const_560 *lang.Var

var A_arbace_core__init_A_const_561 any

var A_arbace_core__init_A_const_562 *lang.Var

var A_arbace_core__init_A_const_563 any

var A_arbace_core__init_A_const_564 *lang.Var

var A_arbace_core__init_A_const_565 any

var A_arbace_core__init_A_const_566 *lang.Var

var A_arbace_core__init_A_const_567 any

var A_arbace_core__init_A_const_568 *lang.Var

var A_arbace_core__init_A_const_569 any

var A_arbace_core__init_A_const_570 *lang.Var

var A_arbace_core__init_A_const_571 any

var A_arbace_core__init_A_const_572 *lang.Var

var A_arbace_core__init_A_const_573 any

var A_arbace_core__init_A_const_574 *lang.Var

var A_arbace_core__init_A_const_575 any

var A_arbace_core__init_A_const_576 *lang.Var

var A_arbace_core__init_A_const_577 any

var A_arbace_core__init_A_const_578 *lang.Var

var A_arbace_core__init_A_const_579 any

var A_arbace_core__init_A_const_580 *lang.Var

var A_arbace_core__init_A_const_581 any

var A_arbace_core__init_A_const_582 *lang.Var

var A_arbace_core__init_A_const_583 any

var A_arbace_core__init_A_const_584 *lang.Var

var A_arbace_core__init_A_const_585 any

var A_arbace_core__init_A_const_586 *lang.Var

var A_arbace_core__init_A_const_587 any

var A_arbace_core__init_A_const_588 *lang.Var

var A_arbace_core__init_A_const_589 any

var A_arbace_core__init_A_const_590 *lang.Var

var A_arbace_core__init_A_const_591 any

var A_arbace_core__init_A_const_592 *lang.Var

var A_arbace_core__init_A_const_593 any

var A_arbace_core__init_A_const_594 *lang.Var

var A_arbace_core__init_A_const_595 any

var A_arbace_core__init_A_const_596 *lang.Var

var A_arbace_core__init_A_const_597 any

var A_arbace_core__init_A_const_598 *lang.Var

var A_arbace_core__init_A_const_599 any

var A_arbace_core__init_A_const_600 *lang.Var

var A_arbace_core__init_A_const_601 any

var A_arbace_core__init_A_const_602 *lang.Var

var A_arbace_core__init_A_const_603 any

var A_arbace_core__init_A_const_604 *lang.Var

var A_arbace_core__init_A_const_605 any

var A_arbace_core__init_A_const_606 *lang.Var

var A_arbace_core__init_A_const_607 any

var A_arbace_core__init_A_const_608 *lang.Var

var A_arbace_core__init_A_const_609 any

var A_arbace_core__init_A_const_610 *lang.Var

var A_arbace_core__init_A_const_611 any

var A_arbace_core__init_A_const_612 *lang.Var

var A_arbace_core__init_A_const_613 any

var A_arbace_core__init_A_const_614 *lang.Var

var A_arbace_core__init_A_const_615 any

var A_arbace_core__init_A_const_616 *lang.Var

var A_arbace_core__init_A_const_617 any

var A_arbace_core__init_A_const_618 *lang.Var

var A_arbace_core__init_A_const_619 any

var A_arbace_core__init_A_const_620 *lang.Var

var A_arbace_core__init_A_const_621 any

var A_arbace_core__init_A_const_622 any

var A_arbace_core__init_A_const_623 *lang.Var

var A_arbace_core__init_A_const_624 any

var A_arbace_core__init_A_const_625 *lang.Var

var A_arbace_core__init_A_const_626 any

var A_arbace_core__init_A_const_627 *lang.Var

var A_arbace_core__init_A_const_628 any

var A_arbace_core__init_A_const_629 *lang.Var

var A_arbace_core__init_A_const_630 any

var A_arbace_core__init_A_const_631 *lang.Var

var A_arbace_core__init_A_const_632 any

var A_arbace_core__init_A_const_633 *lang.Var

var A_arbace_core__init_A_const_634 any

var A_arbace_core__init_A_const_635 *lang.Var

var A_arbace_core__init_A_const_636 any

var A_arbace_core__init_A_const_637 *lang.Var

var A_arbace_core__init_A_const_638 any

var A_arbace_core__init_A_const_639 any

var A_arbace_core__init_A_const_640 any

var A_arbace_core__init_A_const_641 *lang.Var

var A_arbace_core__init_A_const_642 any

var A_arbace_core__init_A_const_643 *lang.Var

var A_arbace_core__init_A_const_644 any

var A_arbace_core__init_A_const_645 *lang.Var

var A_arbace_core__init_A_const_646 any

var A_arbace_core__init_A_const_647 *lang.Var

var A_arbace_core__init_A_const_648 any

var A_arbace_core__init_A_const_649 *lang.Var

var A_arbace_core__init_A_const_650 any

var A_arbace_core__init_A_const_651 *lang.Var

var A_arbace_core__init_A_const_652 any

var A_arbace_core__init_A_const_653 *lang.Var

var A_arbace_core__init_A_const_654 any

var A_arbace_core__init_A_const_655 *lang.Var

var A_arbace_core__init_A_const_656 any

var A_arbace_core__init_A_const_657 *lang.Var

var A_arbace_core__init_A_const_658 any

var A_arbace_core__init_A_const_659 *lang.Var

var A_arbace_core__init_A_const_660 any

var A_arbace_core__init_A_const_661 *lang.Var

var A_arbace_core__init_A_const_662 any

var A_arbace_core__init_A_const_663 *lang.Var

var A_arbace_core__init_A_const_664 any

var A_arbace_core__init_A_const_665 *lang.Var

var A_arbace_core__init_A_const_666 any

var A_arbace_core__init_A_const_667 *lang.Var

var A_arbace_core__init_A_const_668 any

var A_arbace_core__init_A_const_669 *lang.Var

var A_arbace_core__init_A_const_670 any

var A_arbace_core__init_A_const_671 *lang.Var

var A_arbace_core__init_A_const_672 any

var A_arbace_core__init_A_const_673 *lang.Var

var A_arbace_core__init_A_const_674 any

var A_arbace_core__init_A_const_675 *lang.Var

var A_arbace_core__init_A_const_676 any

var A_arbace_core__init_A_const_677 *lang.Var

var A_arbace_core__init_A_const_678 any

var A_arbace_core__init_A_const_679 *lang.Var

var A_arbace_core__init_A_const_680 any

var A_arbace_core__init_A_const_681 *lang.Var

var A_arbace_core__init_A_const_682 any

var A_arbace_core__init_A_const_683 *lang.Var

var A_arbace_core__init_A_const_684 any

var A_arbace_core__init_A_const_685 *lang.Var

var A_arbace_core__init_A_const_686 any

var A_arbace_core__init_A_const_687 *lang.Var

var A_arbace_core__init_A_const_688 any

var A_arbace_core__init_A_const_689 *lang.Var

var A_arbace_core__init_A_const_690 any

var A_arbace_core__init_A_const_691 *lang.Var

var A_arbace_core__init_A_const_692 any

var A_arbace_core__init_A_const_693 *lang.Var

var A_arbace_core__init_A_const_694 any

var A_arbace_core__init_A_const_695 *lang.Var

var A_arbace_core__init_A_const_696 any

var A_arbace_core__init_A_const_697 *lang.Var

var A_arbace_core__init_A_const_698 any

var A_arbace_core__init_A_const_699 any

var A_arbace_core__init_A_const_700 *lang.Var

var A_arbace_core__init_A_const_701 any

var A_arbace_core__init_A_const_702 *lang.Var

var A_arbace_core__init_A_const_703 any

var A_arbace_core__init_A_const_704 *lang.Var

var A_arbace_core__init_A_const_705 any

var A_arbace_core__init_A_const_706 *lang.Var

var A_arbace_core__init_A_const_707 any

var A_arbace_core__init_A_const_708 *lang.Var

var A_arbace_core__init_A_const_709 any

var A_arbace_core__init_A_const_710 *lang.Var

var A_arbace_core__init_A_const_711 any

var A_arbace_core__init_A_const_712 *lang.Var

var A_arbace_core__init_A_const_713 any

var A_arbace_core__init_A_const_714 *lang.Var

var A_arbace_core__init_A_const_715 any

var A_arbace_core__init_A_const_716 *lang.Var

var A_arbace_core__init_A_const_717 any

var A_arbace_core__init_A_const_718 *lang.Var

var A_arbace_core__init_A_const_719 any

var A_arbace_core__init_A_const_720 *lang.Var

var A_arbace_core__init_A_const_721 any

var A_arbace_core__init_A_const_722 *lang.Var

var A_arbace_core__init_A_const_723 any

var A_arbace_core__init_A_const_724 *lang.Var

var A_arbace_core__init_A_const_725 any

var A_arbace_core__init_A_const_726 *lang.Var

var A_arbace_core__init_A_const_727 any

var A_arbace_core__init_A_const_728 *lang.Var

var A_arbace_core__init_A_const_729 any

var A_arbace_core__init_A_const_730 *lang.Var

var A_arbace_core__init_A_const_731 any

var A_arbace_core__init_A_const_732 *lang.Var

var A_arbace_core__init_A_const_733 any

var A_arbace_core__init_A_const_734 *jrt.Class

var A_arbace_core__init_A_const_735 any

var A_arbace_core__init_A_const_736 *lang.Var

var A_arbace_core__init_A_const_737 any

var A_arbace_core__init_A_const_738 any

var A_arbace_core__init_A_const_739 *lang.Var

var A_arbace_core__init_A_const_740 any

var A_arbace_core__init_A_const_741 any

var A_arbace_core__init_A_const_742 *lang.Var

var A_arbace_core__init_A_const_743 any

var A_arbace_core__init_A_const_744 any

var A_arbace_core__init_A_const_745 *lang.Var

var A_arbace_core__init_A_const_746 any

var A_arbace_core__init_A_const_747 any

var A_arbace_core__init_A_const_748 *lang.Var

var A_arbace_core__init_A_const_749 any

var A_arbace_core__init_A_const_750 any

var A_arbace_core__init_A_const_751 *lang.Var

var A_arbace_core__init_A_const_752 any

var A_arbace_core__init_A_const_753 any

var A_arbace_core__init_A_const_754 *lang.Var

var A_arbace_core__init_A_const_755 any

var A_arbace_core__init_A_const_756 any

var A_arbace_core__init_A_const_757 *lang.Var

var A_arbace_core__init_A_const_758 any

var A_arbace_core__init_A_const_759 any

var A_arbace_core__init_A_const_760 *lang.Var

var A_arbace_core__init_A_const_761 any

var A_arbace_core__init_A_const_762 any

var A_arbace_core__init_A_const_763 *lang.Var

var A_arbace_core__init_A_const_764 any

var A_arbace_core__init_A_const_765 any

var A_arbace_core__init_A_const_766 *lang.Var

var A_arbace_core__init_A_const_767 any

var A_arbace_core__init_A_const_768 any

var A_arbace_core__init_A_const_769 *lang.Var

var A_arbace_core__init_A_const_770 any

var A_arbace_core__init_A_const_771 any

var A_arbace_core__init_A_const_772 *lang.Var

var A_arbace_core__init_A_const_773 any

var A_arbace_core__init_A_const_774 any

var A_arbace_core__init_A_const_775 *lang.Var

var A_arbace_core__init_A_const_776 any

var A_arbace_core__init_A_const_777 *lang.Var

var A_arbace_core__init_A_const_778 any

var A_arbace_core__init_A_const_779 *lang.Var

var A_arbace_core__init_A_const_780 any

var A_arbace_core__init_A_const_781 *lang.Var

var A_arbace_core__init_A_const_782 any

var A_arbace_core__init_A_const_783 *lang.Var

var A_arbace_core__init_A_const_784 any

var A_arbace_core__init_A_const_785 *lang.Var

var A_arbace_core__init_A_const_786 any

var A_arbace_core__init_A_const_787 *lang.Var

var A_arbace_core__init_A_const_788 any

var A_arbace_core__init_A_const_789 *lang.Var

var A_arbace_core__init_A_const_790 any

var A_arbace_core__init_A_const_791 *lang.Var

var A_arbace_core__init_A_const_792 any

var A_arbace_core__init_A_const_793 *lang.Var

var A_arbace_core__init_A_const_794 any

var A_arbace_core__init_A_const_795 *lang.Var

var A_arbace_core__init_A_const_796 any

var A_arbace_core__init_A_const_797 *lang.Var

var A_arbace_core__init_A_const_798 any

var A_arbace_core__init_A_const_799 *lang.Var

var A_arbace_core__init_A_const_800 any

var A_arbace_core__init_A_const_801 *lang.Keyword

var A_arbace_core__init_A_const_802 any

var A_arbace_core__init_A_const_803 *lang.Var

var A_arbace_core__init_A_const_804 any

var A_arbace_core__init_A_const_805 any

var A_arbace_core__init_A_const_806 *lang.Var

var A_arbace_core__init_A_const_807 any

var A_arbace_core__init_A_const_808 *lang.Var

var A_arbace_core__init_A_const_809 any

var A_arbace_core__init_A_const_810 *lang.Var

var A_arbace_core__init_A_const_811 any

var A_arbace_core__init_A_const_812 *lang.Var

var A_arbace_core__init_A_const_813 any

var A_arbace_core__init_A_const_814 *lang.Var

var A_arbace_core__init_A_const_815 any

var A_arbace_core__init_A_const_816 *lang.Var

var A_arbace_core__init_A_const_817 any

var A_arbace_core__init_A_const_818 *lang.Var

var A_arbace_core__init_A_const_819 any

var A_arbace_core__init_A_const_820 *lang.Var

var A_arbace_core__init_A_const_821 any

var A_arbace_core__init_A_const_822 *lang.Var

var A_arbace_core__init_A_const_823 any

var A_arbace_core__init_A_const_824 *lang.Var

var A_arbace_core__init_A_const_825 any

var A_arbace_core__init_A_const_826 *lang.Var

var A_arbace_core__init_A_const_827 any

var A_arbace_core__init_A_const_828 *lang.Var

var A_arbace_core__init_A_const_829 any

var A_arbace_core__init_A_const_830 *lang.Var

var A_arbace_core__init_A_const_831 any

var A_arbace_core__init_A_const_832 *lang.Var

var A_arbace_core__init_A_const_833 any

var A_arbace_core__init_A_const_834 *lang.Var

var A_arbace_core__init_A_const_835 any

var A_arbace_core__init_A_const_836 *lang.Var

var A_arbace_core__init_A_const_837 any

var A_arbace_core__init_A_const_838 *lang.Var

var A_arbace_core__init_A_const_839 any

var A_arbace_core__init_A_const_840 *lang.Var

var A_arbace_core__init_A_const_841 any

var A_arbace_core__init_A_const_842 any

var A_arbace_core__init_A_const_843 *lang.Var

var A_arbace_core__init_A_const_844 any

var A_arbace_core__init_A_const_845 any

var A_arbace_core__init_A_const_846 *lang.Var

var A_arbace_core__init_A_const_847 any

var A_arbace_core__init_A_const_848 any

var A_arbace_core__init_A_const_849 any

var A_arbace_core__init_A_const_850 *lang.Var

var A_arbace_core__init_A_const_851 any

var A_arbace_core__init_A_const_852 any

var A_arbace_core__init_A_const_853 any

var A_arbace_core__init_A_const_854 *lang.Var

var A_arbace_core__init_A_const_855 any

var A_arbace_core__init_A_const_856 *lang.Var

var A_arbace_core__init_A_const_857 any

var A_arbace_core__init_A_const_858 *lang.Var

var A_arbace_core__init_A_const_859 any

var A_arbace_core__init_A_const_860 *lang.Var

var A_arbace_core__init_A_const_861 any

var A_arbace_core__init_A_const_862 *lang.Var

var A_arbace_core__init_A_const_863 any

var A_arbace_core__init_A_const_864 *lang.Var

var A_arbace_core__init_A_const_865 any

var A_arbace_core__init_A_const_866 *lang.Var

var A_arbace_core__init_A_const_867 any

var A_arbace_core__init_A_const_868 *lang.Var

var A_arbace_core__init_A_const_869 any

var A_arbace_core__init_A_const_870 *lang.Var

var A_arbace_core__init_A_const_871 any

var A_arbace_core__init_A_const_872 *lang.Var

var A_arbace_core__init_A_const_873 any

var A_arbace_core__init_A_const_874 *lang.Var

var A_arbace_core__init_A_const_875 any

var A_arbace_core__init_A_const_876 *lang.Var

var A_arbace_core__init_A_const_877 any

var A_arbace_core__init_A_const_878 *lang.Var

var A_arbace_core__init_A_const_879 any

var A_arbace_core__init_A_const_880 *lang.Var

var A_arbace_core__init_A_const_881 any

var A_arbace_core__init_A_const_882 *lang.Var

var A_arbace_core__init_A_const_883 any

var A_arbace_core__init_A_const_884 *lang.Var

var A_arbace_core__init_A_const_885 any

var A_arbace_core__init_A_const_886 *lang.Var

var A_arbace_core__init_A_const_887 any

var A_arbace_core__init_A_const_888 *lang.Var

var A_arbace_core__init_A_const_889 any

var A_arbace_core__init_A_const_890 *lang.Var

var A_arbace_core__init_A_const_891 any

var A_arbace_core__init_A_const_892 *lang.Var

var A_arbace_core__init_A_const_893 any

var A_arbace_core__init_A_const_894 *lang.Var

var A_arbace_core__init_A_const_895 any

var A_arbace_core__init_A_const_896 *lang.Var

var A_arbace_core__init_A_const_897 any

var A_arbace_core__init_A_const_898 *lang.Var

var A_arbace_core__init_A_const_899 any

var A_arbace_core__init_A_const_900 *lang.Var

var A_arbace_core__init_A_const_901 any

var A_arbace_core__init_A_const_902 *lang.Var

var A_arbace_core__init_A_const_903 any

var A_arbace_core__init_A_const_904 *lang.Var

var A_arbace_core__init_A_const_905 any

var A_arbace_core__init_A_const_906 *lang.Var

var A_arbace_core__init_A_const_907 any

var A_arbace_core__init_A_const_908 *lang.Var

var A_arbace_core__init_A_const_909 any

var A_arbace_core__init_A_const_910 *lang.Var

var A_arbace_core__init_A_const_911 any

var A_arbace_core__init_A_const_912 *lang.Var

var A_arbace_core__init_A_const_913 any

var A_arbace_core__init_A_const_914 *lang.Var

var A_arbace_core__init_A_const_915 any

var A_arbace_core__init_A_const_916 *lang.Var

var A_arbace_core__init_A_const_917 any

var A_arbace_core__init_A_const_918 *lang.Var

var A_arbace_core__init_A_const_919 any

var A_arbace_core__init_A_const_920 *lang.Var

var A_arbace_core__init_A_const_921 any

var A_arbace_core__init_A_const_922 *lang.Var

var A_arbace_core__init_A_const_923 any

var A_arbace_core__init_A_const_924 *lang.Var

var A_arbace_core__init_A_const_925 any

var A_arbace_core__init_A_const_926 *lang.Var

var A_arbace_core__init_A_const_927 any

var A_arbace_core__init_A_const_928 *lang.Var

var A_arbace_core__init_A_const_929 any

var A_arbace_core__init_A_const_930 *lang.Var

var A_arbace_core__init_A_const_931 any

var A_arbace_core__init_A_const_932 *lang.Var

var A_arbace_core__init_A_const_933 any

var A_arbace_core__init_A_const_934 *lang.Var

var A_arbace_core__init_A_const_935 any

var A_arbace_core__init_A_const_936 *lang.Var

var A_arbace_core__init_A_const_937 any

var A_arbace_core__init_A_const_938 *lang.Var

var A_arbace_core__init_A_const_939 any

var A_arbace_core__init_A_const_940 *lang.Var

var A_arbace_core__init_A_const_941 any

var A_arbace_core__init_A_const_942 *lang.Var

var A_arbace_core__init_A_const_943 any

var A_arbace_core__init_A_const_944 *lang.Var

var A_arbace_core__init_A_const_945 any

var A_arbace_core__init_A_const_946 *lang.Var

var A_arbace_core__init_A_const_947 any

var A_arbace_core__init_A_const_948 *lang.Var

var A_arbace_core__init_A_const_949 any

var A_arbace_core__init_A_const_950 *lang.Var

var A_arbace_core__init_A_const_951 any

var A_arbace_core__init_A_const_952 *lang.Var

var A_arbace_core__init_A_const_953 any

var A_arbace_core__init_A_const_954 *lang.Var

var A_arbace_core__init_A_const_955 any

var A_arbace_core__init_A_const_956 *lang.Var

var A_arbace_core__init_A_const_957 any

var A_arbace_core__init_A_const_958 *lang.Var

var A_arbace_core__init_A_const_959 any

var A_arbace_core__init_A_const_960 *lang.Var

var A_arbace_core__init_A_const_961 any

var A_arbace_core__init_A_const_962 *lang.Var

var A_arbace_core__init_A_const_963 any

var A_arbace_core__init_A_const_964 *lang.Var

var A_arbace_core__init_A_const_965 any

var A_arbace_core__init_A_const_966 *lang.Var

var A_arbace_core__init_A_const_967 any

var A_arbace_core__init_A_const_968 any

var A_arbace_core__init_A_const_969 *lang.Var

var A_arbace_core__init_A_const_970 any

var A_arbace_core__init_A_const_971 any

var A_arbace_core__init_A_const_972 any

var A_arbace_core__init_A_const_973 *lang.Var

var A_arbace_core__init_A_const_974 any

var A_arbace_core__init_A_const_975 *lang.Var

var A_arbace_core__init_A_const_976 any

var A_arbace_core__init_A_const_977 *lang.Var

var A_arbace_core__init_A_const_978 any

var A_arbace_core__init_A_const_979 *lang.Var

var A_arbace_core__init_A_const_980 any

var A_arbace_core__init_A_const_981 *lang.Var

var A_arbace_core__init_A_const_982 any

var A_arbace_core__init_A_const_983 *lang.Var

var A_arbace_core__init_A_const_984 any

var A_arbace_core__init_A_const_985 *lang.Var

var A_arbace_core__init_A_const_986 any

var A_arbace_core__init_A_const_987 *lang.Var

var A_arbace_core__init_A_const_988 any

var A_arbace_core__init_A_const_989 *lang.Var

var A_arbace_core__init_A_const_990 any

var A_arbace_core__init_A_const_991 *lang.Var

var A_arbace_core__init_A_const_992 any

var A_arbace_core__init_A_const_993 *lang.Var

var A_arbace_core__init_A_const_994 any

var A_arbace_core__init_A_const_995 *lang.Var

var A_arbace_core__init_A_const_996 any

var A_arbace_core__init_A_const_997 *lang.Var

var A_arbace_core__init_A_const_998 any

var A_arbace_core__init_A_const_999 *lang.Var

var A_arbace_core__init_A_const_1000 any

var A_arbace_core__init_A_const_1001 *lang.Var

var A_arbace_core__init_A_const_1002 any

var A_arbace_core__init_A_const_1003 *lang.Var

var A_arbace_core__init_A_const_1004 any

var A_arbace_core__init_A_const_1005 *lang.Var

var A_arbace_core__init_A_const_1006 any

var A_arbace_core__init_A_const_1007 *lang.Var

var A_arbace_core__init_A_const_1008 any

var A_arbace_core__init_A_const_1009 *lang.Var

var A_arbace_core__init_A_const_1010 any

var A_arbace_core__init_A_const_1011 *lang.Var

var A_arbace_core__init_A_const_1012 any

var A_arbace_core__init_A_const_1013 *lang.Var

var A_arbace_core__init_A_const_1014 any

var A_arbace_core__init_A_const_1015 *lang.Var

var A_arbace_core__init_A_const_1016 any

var A_arbace_core__init_A_const_1017 *lang.Var

var A_arbace_core__init_A_const_1018 any

var A_arbace_core__init_A_const_1019 *lang.Var

var A_arbace_core__init_A_const_1020 any

var A_arbace_core__init_A_const_1021 *lang.Var

var A_arbace_core__init_A_const_1022 any

var A_arbace_core__init_A_const_1023 *lang.Var

var A_arbace_core__init_A_const_1024 any

var A_arbace_core__init_A_const_1025 *lang.Var

var A_arbace_core__init_A_const_1026 any

var A_arbace_core__init_A_const_1027 *lang.Var

var A_arbace_core__init_A_const_1028 any

var A_arbace_core__init_A_const_1029 *lang.Var

var A_arbace_core__init_A_const_1030 any

var A_arbace_core__init_A_const_1031 *lang.Var

var A_arbace_core__init_A_const_1032 any

var A_arbace_core__init_A_const_1033 *lang.Var

var A_arbace_core__init_A_const_1034 any

var A_arbace_core__init_A_const_1035 *lang.Var

var A_arbace_core__init_A_const_1036 any

var A_arbace_core__init_A_const_1037 *lang.Var

var A_arbace_core__init_A_const_1038 any

var A_arbace_core__init_A_const_1039 *lang.Var

var A_arbace_core__init_A_const_1040 any

var A_arbace_core__init_A_const_1041 *lang.Var

var A_arbace_core__init_A_const_1042 any

var A_arbace_core__init_A_const_1043 *lang.Var

var A_arbace_core__init_A_const_1044 any

var A_arbace_core__init_A_const_1045 *lang.Var

var A_arbace_core__init_A_const_1046 any

var A_arbace_core__init_A_const_1047 *lang.Var

var A_arbace_core__init_A_const_1048 any

var A_arbace_core__init_A_const_1049 *lang.Var

var A_arbace_core__init_A_const_1050 any

var A_arbace_core__init_A_const_1051 *lang.Var

var A_arbace_core__init_A_const_1052 any

var A_arbace_core__init_A_const_1053 *lang.Var

var A_arbace_core__init_A_const_1054 any

var A_arbace_core__init_A_const_1055 *lang.Var

var A_arbace_core__init_A_const_1056 any

var A_arbace_core__init_A_const_1057 *lang.Var

var A_arbace_core__init_A_const_1058 any

var A_arbace_core__init_A_const_1059 *lang.Var

var A_arbace_core__init_A_const_1060 any

var A_arbace_core__init_A_const_1061 *lang.Var

var A_arbace_core__init_A_const_1062 any

var A_arbace_core__init_A_const_1063 *lang.Var

var A_arbace_core__init_A_const_1064 any

var A_arbace_core__init_A_const_1065 *lang.Var

var A_arbace_core__init_A_const_1066 any

var A_arbace_core__init_A_const_1067 *lang.Var

var A_arbace_core__init_A_const_1068 any

var A_arbace_core__init_A_const_1069 *lang.Var

var A_arbace_core__init_A_const_1070 any

var A_arbace_core__init_A_const_1071 *lang.Var

var A_arbace_core__init_A_const_1072 any

var A_arbace_core__init_A_const_1073 *lang.Var

var A_arbace_core__init_A_const_1074 any

var A_arbace_core__init_A_const_1075 *lang.Var

var A_arbace_core__init_A_const_1076 any

var A_arbace_core__init_A_const_1077 any

var A_arbace_core__init_A_const_1078 any

var A_arbace_core__init_A_const_1079 *lang.Var

var A_arbace_core__init_A_const_1080 any

var A_arbace_core__init_A_const_1081 any

var A_arbace_core__init_A_const_1082 any

var A_arbace_core__init_A_const_1083 *lang.Var

var A_arbace_core__init_A_const_1084 any

var A_arbace_core__init_A_const_1085 any

var A_arbace_core__init_A_const_1086 any

var A_arbace_core__init_A_const_1087 *lang.Var

var A_arbace_core__init_A_const_1088 any

var A_arbace_core__init_A_const_1089 any

var A_arbace_core__init_A_const_1090 any

var A_arbace_core__init_A_const_1091 *lang.Var

var A_arbace_core__init_A_const_1092 any

var A_arbace_core__init_A_const_1093 any

var A_arbace_core__init_A_const_1094 any

var A_arbace_core__init_A_const_1095 *lang.Var

var A_arbace_core__init_A_const_1096 any

var A_arbace_core__init_A_const_1097 any

var A_arbace_core__init_A_const_1098 any

var A_arbace_core__init_A_const_1099 *lang.Var

var A_arbace_core__init_A_const_1100 any

var A_arbace_core__init_A_const_1101 any

var A_arbace_core__init_A_const_1102 any

var A_arbace_core__init_A_const_1103 *lang.Var

var A_arbace_core__init_A_const_1104 any

var A_arbace_core__init_A_const_1105 any

var A_arbace_core__init_A_const_1106 any

var A_arbace_core__init_A_const_1107 *lang.Var

var A_arbace_core__init_A_const_1108 any

var A_arbace_core__init_A_const_1109 any

var A_arbace_core__init_A_const_1110 any

var A_arbace_core__init_A_const_1111 *lang.Var

var A_arbace_core__init_A_const_1112 any

var A_arbace_core__init_A_const_1113 *lang.Var

var A_arbace_core__init_A_const_1114 any

var A_arbace_core__init_A_const_1115 *lang.Var

var A_arbace_core__init_A_const_1116 any

var A_arbace_core__init_A_const_1117 *lang.Var

var A_arbace_core__init_A_const_1118 any

var A_arbace_core__init_A_const_1119 *lang.Var

var A_arbace_core__init_A_const_1120 any

var A_arbace_core__init_A_const_1121 *lang.Var

var A_arbace_core__init_A_const_1122 any

var A_arbace_core__init_A_const_1123 *lang.Var

var A_arbace_core__init_A_const_1124 any

var A_arbace_core__init_A_const_1125 *lang.Var

var A_arbace_core__init_A_const_1126 any

var A_arbace_core__init_A_const_1127 *lang.Var

var A_arbace_core__init_A_const_1128 any

var A_arbace_core__init_A_const_1129 *lang.Var

var A_arbace_core__init_A_const_1130 any

var A_arbace_core__init_A_const_1131 *lang.Var

var A_arbace_core__init_A_const_1132 any

var A_arbace_core__init_A_const_1133 *lang.Var

var A_arbace_core__init_A_const_1134 any

var A_arbace_core__init_A_const_1135 *lang.Var

var A_arbace_core__init_A_const_1136 any

var A_arbace_core__init_A_const_1137 *lang.Var

var A_arbace_core__init_A_const_1138 any

var A_arbace_core__init_A_const_1139 *lang.Var

var A_arbace_core__init_A_const_1140 any

var A_arbace_core__init_A_const_1141 any

var A_arbace_core__init_A_const_1142 *lang.Var

var A_arbace_core__init_A_const_1143 any

var A_arbace_core__init_A_const_1144 *lang.Var

var A_arbace_core__init_A_const_1145 any

var A_arbace_core__init_A_const_1146 *lang.Var

var A_arbace_core__init_A_const_1147 any

var A_arbace_core__init_A_const_1148 *lang.Var

var A_arbace_core__init_A_const_1149 any

var A_arbace_core__init_A_const_1150 *lang.Var

var A_arbace_core__init_A_const_1151 any

var A_arbace_core__init_A_const_1152 *lang.Var

var A_arbace_core__init_A_const_1153 any

var A_arbace_core__init_A_const_1154 *lang.Var

var A_arbace_core__init_A_const_1155 any

var A_arbace_core__init_A_const_1156 *lang.Var

var A_arbace_core__init_A_const_1157 any

var A_arbace_core__init_A_const_1158 *lang.Var

var A_arbace_core__init_A_const_1159 any

var A_arbace_core__init_A_const_1160 *lang.Var

var A_arbace_core__init_A_const_1161 any

var A_arbace_core__init_A_const_1162 *lang.Var

var A_arbace_core__init_A_const_1163 any

var A_arbace_core__init_A_const_1164 *lang.Var

var A_arbace_core__init_A_const_1165 any

var A_arbace_core__init_A_const_1166 *lang.Var

var A_arbace_core__init_A_const_1167 any

var A_arbace_core__init_A_const_1168 *lang.Var

var A_arbace_core__init_A_const_1169 any

var A_arbace_core__init_A_const_1170 *lang.Var

var A_arbace_core__init_A_const_1171 any

var A_arbace_core__init_A_const_1172 *lang.Var

var A_arbace_core__init_A_const_1173 any

var A_arbace_core__init_A_const_1174 *lang.Var

var A_arbace_core__init_A_const_1175 any

var A_arbace_core__init_A_const_1176 *lang.Var

var A_arbace_core__init_A_const_1177 any

var A_arbace_core__init_A_const_1178 *lang.Var

var A_arbace_core__init_A_const_1179 any

var A_arbace_core__init_A_const_1180 *lang.Var

var A_arbace_core__init_A_const_1181 any

var A_arbace_core__init_A_const_1182 *lang.Var

var A_arbace_core__init_A_const_1183 any

var A_arbace_core__init_A_const_1184 *lang.Var

var A_arbace_core__init_A_const_1185 any

var A_arbace_core__init_A_const_1186 any

var A_arbace_core__init_A_const_1187 *lang.Var

var A_arbace_core__init_A_const_1188 any

var A_arbace_core__init_A_const_1189 any

var A_arbace_core__init_A_const_1190 *lang.Var

var A_arbace_core__init_A_const_1191 any

var A_arbace_core__init_A_const_1192 any

var A_arbace_core__init_A_const_1193 *lang.Var

var A_arbace_core__init_A_const_1194 any

var A_arbace_core__init_A_const_1195 *lang.Var

var A_arbace_core__init_A_const_1196 any

var A_arbace_core__init_A_const_1197 *lang.Var

var A_arbace_core__init_A_const_1198 any

var A_arbace_core__init_A_const_1199 *lang.Var

var A_arbace_core__init_A_const_1200 any

var A_arbace_core__init_A_const_1201 *lang.Var

var A_arbace_core__init_A_const_1202 any

var A_arbace_core__init_A_const_1203 *lang.Var

var A_arbace_core__init_A_const_1204 any

var A_arbace_core__init_A_const_1205 *lang.Var

var A_arbace_core__init_A_const_1206 any

var A_arbace_core__init_A_const_1207 *lang.Var

var A_arbace_core__init_A_const_1208 any

var A_arbace_core__init_A_const_1209 *lang.Var

var A_arbace_core__init_A_const_1210 any

var A_arbace_core__init_A_const_1211 *lang.Var

var A_arbace_core__init_A_const_1212 any

var A_arbace_core__init_A_const_1213 *lang.Var

var A_arbace_core__init_A_const_1214 any

var A_arbace_core__init_A_const_1215 *lang.Var

var A_arbace_core__init_A_const_1216 any

var A_arbace_core__init_A_const_1217 *lang.Var

var A_arbace_core__init_A_const_1218 any

var A_arbace_core__init_A_const_1219 *lang.Var

var A_arbace_core__init_A_const_1220 any

var A_arbace_core__init_A_const_1221 *lang.Var

var A_arbace_core__init_A_const_1222 any

var A_arbace_core__init_A_const_1223 *lang.Var

var A_arbace_core__init_A_const_1224 any

var A_arbace_core__init_A_const_1225 any

var A_arbace_core__init_A_const_1226 *lang.Var

var A_arbace_core__init_A_const_1227 any

var A_arbace_core__init_A_const_1228 *lang.Var

var A_arbace_core__init_A_const_1229 any

var A_arbace_core__init_A_const_1230 *lang.Var

var A_arbace_core__init_A_const_1231 any

var A_arbace_core__init_A_const_1232 *lang.Var

var A_arbace_core__init_A_const_1233 any

var A_arbace_core__init_A_const_1234 *lang.Var

var A_arbace_core__init_A_const_1235 any

var A_arbace_core__init_A_const_1236 *lang.Var

var A_arbace_core__init_A_const_1237 any

var A_arbace_core__init_A_const_1238 *lang.Var

var A_arbace_core__init_A_const_1239 any

var A_arbace_core__init_A_const_1240 *lang.Var

var A_arbace_core__init_A_const_1241 any

var A_arbace_core__init_A_const_1242 *lang.Var

var A_arbace_core__init_A_const_1243 any

var A_arbace_core__init_A_const_1244 *lang.Var

var A_arbace_core__init_A_const_1245 any

var A_arbace_core__init_A_const_1246 *lang.Var

var A_arbace_core__init_A_const_1247 any

var A_arbace_core__init_A_const_1248 *lang.Var

var A_arbace_core__init_A_const_1249 any

var A_arbace_core__init_A_const_1250 *lang.Var

var A_arbace_core__init_A_const_1251 any

var A_arbace_core__init_A_const_1252 *lang.Var

var A_arbace_core__init_A_const_1253 any

var A_arbace_core__init_A_const_1254 *lang.Var

var A_arbace_core__init_A_const_1255 any

var A_arbace_core__init_A_const_1256 *lang.Var

var A_arbace_core__init_A_const_1257 any

var A_arbace_core__init_A_const_1258 *lang.Var

var A_arbace_core__init_A_const_1259 any

var A_arbace_core__init_A_const_1260 *lang.Var

var A_arbace_core__init_A_const_1261 any

var A_arbace_core__init_A_const_1262 *lang.Var

var A_arbace_core__init_A_const_1263 any

var A_arbace_core__init_A_const_1264 *lang.Var

var A_arbace_core__init_A_const_1265 any

var A_arbace_core__init_A_const_1266 *lang.Var

var A_arbace_core__init_A_const_1267 any

var A_arbace_core__init_A_const_1268 *lang.Var

var A_arbace_core__init_A_const_1269 any

var A_arbace_core__init_A_const_1270 *lang.Var

var A_arbace_core__init_A_const_1271 any

var A_arbace_core__init_A_const_1272 *lang.Var

var A_arbace_core__init_A_const_1273 any

var A_arbace_core__init_A_const_1274 *lang.Var

var A_arbace_core__init_A_const_1275 any

var A_arbace_core__init_A_const_1276 *lang.Var

var A_arbace_core__init_A_const_1277 *lang.Var

var A_arbace_core__init_A_const_1278 *lang.Var

var A_arbace_core__init_A_const_1279 *lang.Var

var A_arbace_core__init_A_const_1280 any

var A_arbace_core__init_A_const_1281 *lang.Var

var A_arbace_core__init_A_const_1282 any

var A_arbace_core__init_A_const_1283 *lang.Var

var A_arbace_core__init_A_const_1284 any

var A_arbace_core__init_A_const_1285 *lang.Var

var A_arbace_core__init_A_const_1286 any

var A_arbace_core__init_A_const_1287 *lang.Var

var A_arbace_core__init_A_const_1288 any

var A_arbace_core__init_A_const_1289 *lang.Var

var A_arbace_core__init_A_const_1290 any

var A_arbace_core__init_A_const_1291 *lang.Var

var A_arbace_core__init_A_const_1292 any

var A_arbace_core__init_A_const_1293 *lang.Var

var A_arbace_core__init_A_const_1294 any

var A_arbace_core__init_A_const_1295 *lang.Var

var A_arbace_core__init_A_const_1296 any

var A_arbace_core__init_A_const_1297 *lang.Var

var A_arbace_core__init_A_const_1298 any

var A_arbace_core__init_A_const_1299 *lang.Var

var A_arbace_core__init_A_const_1300 any

var A_arbace_core__init_A_const_1301 *lang.Var

var A_arbace_core__init_A_const_1302 any

var A_arbace_core__init_A_const_1303 *lang.Var

var A_arbace_core__init_A_const_1304 any

var A_arbace_core__init_A_const_1305 *lang.Var

var A_arbace_core__init_A_const_1306 any

var A_arbace_core__init_A_const_1307 *lang.Var

var A_arbace_core__init_A_const_1308 any

var A_arbace_core__init_A_const_1309 *lang.Var

var A_arbace_core__init_A_const_1310 any

var A_arbace_core__init_A_const_1311 *lang.Var

var A_arbace_core__init_A_const_1312 any

var A_arbace_core__init_A_const_1313 *lang.Var

var A_arbace_core__init_A_const_1314 any

var A_arbace_core__init_A_const_1315 *lang.Var

var A_arbace_core__init_A_const_1316 any

var A_arbace_core__init_A_const_1317 *lang.Var

var A_arbace_core__init_A_const_1318 any

var A_arbace_core__init_A_const_1319 *lang.Var

var A_arbace_core__init_A_const_1320 any

var A_arbace_core__init_A_const_1321 *lang.Var

var A_arbace_core__init_A_const_1322 any

var A_arbace_core__init_A_const_1323 *lang.Var

var A_arbace_core__init_A_const_1324 any

var A_arbace_core__init_A_const_1325 *lang.Var

var A_arbace_core__init_A_const_1326 any

var A_arbace_core__init_A_const_1327 any

var A_arbace_core__init_A_const_1328 *lang.Var

var A_arbace_core__init_A_const_1329 any

var A_arbace_core__init_A_const_1330 *lang.Var

var A_arbace_core__init_A_const_1331 any

var A_arbace_core__init_A_const_1332 *lang.Var

var A_arbace_core__init_A_const_1333 any

var A_arbace_core__init_A_const_1334 *lang.Var

var A_arbace_core__init_A_const_1335 any

var A_arbace_core__init_A_const_1336 *lang.Var

var A_arbace_core__init_A_const_1337 any

var A_arbace_core__init_A_const_1338 *lang.Var

var A_arbace_core__init_A_const_1339 any

var A_arbace_core__init_A_const_1340 *lang.Var

var A_arbace_core__init_A_const_1341 any

var A_arbace_core__init_A_const_1342 *lang.Var

var A_arbace_core__init_A_const_1343 any

var A_arbace_core__init_A_const_1344 any

var A_arbace_core__init_A_const_1345 *lang.Var

var A_arbace_core__init_A_const_1346 any

var A_arbace_core__init_A_const_1347 *lang.Var

var A_arbace_core__init_A_const_1348 any

var A_arbace_core__init_A_const_1349 *lang.Var

var A_arbace_core__init_A_const_1350 any

var A_arbace_core__init_A_const_1351 *lang.Var

var A_arbace_core__init_A_const_1352 any

var A_arbace_core__init_A_const_1353 *lang.Var

var A_arbace_core__init_A_const_1354 any

var A_arbace_core__init_A_const_1355 *lang.Var

var A_arbace_core__init_A_const_1356 any

var A_arbace_core__init_A_const_1357 any

var A_arbace_core__init_A_const_1358 *jrt.Class

var A_arbace_core__init_A_const_1359 *lang.Var

var A_arbace_core__init_A_const_1360 any

var A_arbace_core__init_A_const_1361 any

var A_arbace_core__init_A_const_1362 *lang.Keyword

var A_arbace_core__init_A_const_1363 any

var A_arbace_core__init_A_const_1364 *lang.Keyword

var A_arbace_core__init_A_const_1365 *lang.Keyword

var A_arbace_core__init_A_const_1366 any

var A_arbace_core__init_A_const_1367 *lang.Keyword

var A_arbace_core__init_A_const_1368 any

var A_arbace_core__init_A_const_1369 any

var A_arbace_core__init_A_const_1370 *lang.Keyword

var A_arbace_core__init_A_const_1371 *lang.Var

var A_arbace_core__init_A_const_1372 any

var A_arbace_core__init_A_const_1373 *lang.Var

var A_arbace_core__init_A_const_1374 *jrt.Class

var A_arbace_core__init_A_const_1375 *lang.Keyword

var A_arbace_core__init_A_const_1376 *lang.Var

var A_arbace_core__init_A_const_1377 any

var A_arbace_core__init_A_const_1378 *lang.Var

var A_arbace_core__init_A_const_1379 any

var A_arbace_core__init_A_const_1380 *jrt.Class

var A_arbace_core__init_A_const_1381 *lang.Var

var A_arbace_core__init_A_const_1382 any

var A_arbace_core__init_A_const_1383 *lang.Var

var A_arbace_core__init_A_const_1384 any

var A_arbace_core__init_A_const_1385 *lang.Var

var A_arbace_core__init_A_const_1386 any

var A_arbace_core__init_A_const_1387 *lang.Var

var A_arbace_core__init_A_const_1388 *lang.Keyword

var A_arbace_core__init_A_const_1389 *jrt.Class

var A_arbace_core__init_A_const_1390 *jrt.Class

var A_arbace_core__init_A_const_1391 any

var A_arbace_core__init_A_const_1392 *lang.Var

var A_arbace_core__init_A_const_1393 any

var A_arbace_core__init_A_const_1394 *lang.Var

var A_arbace_core__init_A_const_1395 any

var A_arbace_core__init_A_const_1396 *lang.Var

var A_arbace_core__init_A_const_1397 any

var A_arbace_core__init_A_const_1398 *lang.Var

var A_arbace_core__init_A_const_1399 any

var A_arbace_core__init_A_const_1400 *lang.Var

var A_arbace_core__init_A_const_1401 any

var A_arbace_core__init_A_const_1402 any

var A_arbace_core__init_A_const_1403 *lang.Var

var A_arbace_core__init_A_const_1404 any

var A_arbace_core__init_A_const_1405 *lang.Var

var A_arbace_core__init_A_const_1406 any

var A_arbace_core__init_A_const_1407 any

var A_arbace_core__init_A_const_1408 *lang.Var

var A_arbace_core__init_A_const_1409 any

var A_arbace_core__init_A_const_1410 *lang.Var

var A_arbace_core__init_A_const_1411 any

var A_arbace_core__init_A_const_1412 *lang.Var

var A_arbace_core__init_A_const_1413 any

var A_arbace_core__init_A_const_1414 *lang.Var

var A_arbace_core__init_A_const_1415 any

var A_arbace_core__init_A_const_1416 *lang.Var

var A_arbace_core__init_A_const_1417 any

var A_arbace_core__init_A_const_1418 *lang.Var

var A_arbace_core__init_A_const_1419 any

var A_arbace_core__init_A_const_1420 *lang.Var

var A_arbace_core__init_A_const_1421 any

var A_arbace_core__init_A_const_1422 *lang.Var

var A_arbace_core__init_A_const_1423 any

var A_arbace_core__init_A_const_1424 *lang.Var

var A_arbace_core__init_A_const_1425 any

var A_arbace_core__init_A_const_1426 *lang.Var

var A_arbace_core__init_A_const_1427 any

var A_arbace_core__init_A_const_1428 *lang.Keyword

var A_arbace_core__init_A_const_1429 *lang.Keyword

var A_arbace_core__init_A_const_1430 *lang.Keyword

var A_arbace_core__init_A_const_1431 *lang.Keyword

var A_arbace_core__init_A_const_1432 *lang.Var

var A_arbace_core__init_A_const_1433 *lang.Keyword

var A_arbace_core__init_A_const_1434 any

var A_arbace_core__init_A_const_1435 any

var A_arbace_core__init_A_const_1436 any

var A_arbace_core__init_A_const_1437 *lang.Var

var A_arbace_core__init_A_const_1438 any

var A_arbace_core__init_A_const_1439 *lang.Var

var A_arbace_core__init_A_const_1440 any

var A_arbace_core__init_A_const_1441 any

var A_arbace_core__init_A_const_1442 *lang.Var

var A_arbace_core__init_A_const_1443 any

var A_arbace_core__init_A_const_1444 *lang.Var

var A_arbace_core__init_A_const_1445 any

var A_arbace_core__init_A_const_1446 *lang.Var

var A_arbace_core__init_A_const_1447 any

var A_arbace_core__init_A_const_1448 any

var A_arbace_core__init_A_const_1449 *lang.Var

var A_arbace_core__init_A_const_1450 any

var A_arbace_core__init_A_const_1451 *lang.Var

var A_arbace_core__init_A_const_1452 any

var A_arbace_core__init_A_const_1453 *lang.Var

var A_arbace_core__init_A_const_1454 any

var A_arbace_core__init_A_const_1455 *lang.Var

var A_arbace_core__init_A_const_1456 any

var A_arbace_core__init_A_const_1457 *lang.Var

var A_arbace_core__init_A_const_1458 any

var A_arbace_core__init_A_const_1459 *lang.Var

var A_arbace_core__init_A_const_1460 any

var A_arbace_core__init_A_const_1461 *lang.Var

var A_arbace_core__init_A_const_1462 any

var A_arbace_core__init_A_const_1463 *lang.Var

var A_arbace_core__init_A_const_1464 any

var A_arbace_core__init_A_const_1465 *lang.Var

var A_arbace_core__init_A_const_1466 any

var A_arbace_core__init_A_const_1467 *lang.Var

var A_arbace_core__init_A_const_1468 any

var A_arbace_core__init_A_const_1469 *lang.Var

var A_arbace_core__init_A_const_1470 any

var A_arbace_core__init_A_const_1471 *lang.Var

var A_arbace_core__init_A_const_1472 any

var A_arbace_core__init_A_const_1473 *lang.Var

var A_arbace_core__init_A_const_1474 any

var A_arbace_core__init_A_const_1475 *lang.Var

var A_arbace_core__init_A_const_1476 any

var A_arbace_core__init_A_const_1477 *lang.Var

var A_arbace_core__init_A_const_1478 any

var A_arbace_core__init_A_const_1479 *lang.Var

var A_arbace_core__init_A_const_1480 any

var A_arbace_core__init_A_const_1481 any

var A_arbace_core__init_A_const_1482 *lang.Var

var A_arbace_core__init_A_const_1483 any

var A_arbace_core__init_A_const_1484 *lang.Var

var A_arbace_core__init_A_const_1485 any

var A_arbace_core__init_A_const_1486 *lang.Var

var A_arbace_core__init_A_const_1487 any

var A_arbace_core__init_A_const_1488 *lang.Var

var A_arbace_core__init_A_const_1489 any

var A_arbace_core__init_A_const_1490 *lang.Var

var A_arbace_core__init_A_const_1491 any

var A_arbace_core__init_A_const_1492 *lang.Var

var A_arbace_core__init_A_const_1493 any

var A_arbace_core__init_A_const_1494 *lang.Var

var A_arbace_core__init_A_const_1495 any

var A_arbace_core__init_A_const_1496 *lang.Var

var A_arbace_core__init_A_const_1497 any

var A_arbace_core__init_A_const_1498 *lang.Var

var A_arbace_core__init_A_const_1499 any

var A_arbace_core__init_A_const_1500 any

var A_arbace_core__init_A_const_1501 *lang.Var

var A_arbace_core__init_A_const_1502 any

var A_arbace_core__init_A_const_1503 *lang.Var

var A_arbace_core__init_A_const_1504 any

var A_arbace_core__init_A_const_1505 *lang.Var

var A_arbace_core__init_A_const_1506 any

var A_arbace_core__init_A_const_1507 *jrt.Class

var A_arbace_core__init_A_const_1508 *lang.Var

var A_arbace_core__init_A_const_1509 any

var A_arbace_core__init_A_const_1510 *lang.Var

var A_arbace_core__init_A_const_1511 any

var A_arbace_core__init_A_const_1512 *lang.Var

var A_arbace_core__init_A_const_1513 any

var A_arbace_core__init_A_const_1514 *lang.Var

var A_arbace_core__init_A_const_1515 any

var A_arbace_core__init_A_const_1516 *lang.Var

var A_arbace_core__init_A_const_1517 any

var A_arbace_core__init_A_const_1518 *lang.Var

var A_arbace_core__init_A_const_1519 any

var A_arbace_core__init_A_const_1520 *lang.Var

var A_arbace_core__init_A_const_1521 any

var A_arbace_core__init_A_const_1522 *lang.Var

var A_arbace_core__init_A_const_1523 any

var A_arbace_core__init_A_const_1524 *lang.Var

var A_arbace_core__init_A_const_1525 any

var A_arbace_core__init_A_const_1526 any

var A_arbace_core__init_A_const_1527 *lang.Var

var A_arbace_core__init_A_const_1528 any

var A_arbace_core__init_A_const_1529 *lang.Var

var A_arbace_core__init_A_const_1530 *lang.Var

var A_arbace_core__init_A_const_1531 any

var A_arbace_core__init_A_const_1532 *lang.Var

var A_arbace_core__init_A_const_1533 any

var A_arbace_core__init_A_const_1534 *lang.Var

var A_arbace_core__init_A_const_1535 any

var A_arbace_core__init_A_const_1536 *lang.Var

var A_arbace_core__init_A_const_1537 any

var A_arbace_core__init_A_const_1538 *lang.Var

var A_arbace_core__init_A_const_1539 any

var A_arbace_core__init_A_const_1540 *lang.Var

var A_arbace_core__init_A_const_1541 any

var A_arbace_core__init_A_const_1542 *lang.Var

var A_arbace_core__init_A_const_1543 any

var A_arbace_core__init_A_const_1544 *lang.Var

var A_arbace_core__init_A_const_1545 any

var A_arbace_core__init_A_const_1546 any

var A_arbace_core__init_A_const_1547 *lang.Var

var A_arbace_core__init_A_const_1548 any

var A_arbace_core__init_A_const_1549 any

var A_arbace_core__init_A_const_1550 *lang.Var

var A_arbace_core__init_A_const_1551 any

var A_arbace_core__init_A_const_1552 any

var A_arbace_core__init_A_const_1553 *lang.Var

var A_arbace_core__init_A_const_1554 any

var A_arbace_core__init_A_const_1555 *lang.Var

var A_arbace_core__init_A_const_1556 any

var A_arbace_core__init_A_const_1557 *lang.Var

var A_arbace_core__init_A_const_1558 any

var A_arbace_core__init_A_const_1559 *lang.Var

var A_arbace_core__init_A_const_1560 any

var A_arbace_core__init_A_const_1561 *lang.Var

var A_arbace_core__init_A_const_1562 any

var A_arbace_core__init_A_const_1563 *lang.Var

var A_arbace_core__init_A_const_1564 any

var A_arbace_core__init_A_const_1565 *lang.Var

var A_arbace_core__init_A_const_1566 any

var A_arbace_core__init_A_const_1567 *lang.Var

var A_arbace_core__init_A_const_1568 any

var A_arbace_core__init_A_const_1569 *lang.Var

var A_arbace_core__init_A_const_1570 any

var A_arbace_core__init_A_const_1571 *lang.Var

var A_arbace_core__init_A_const_1572 any

var A_arbace_core__init_A_const_1573 *lang.Var

var A_arbace_core__init_A_const_1574 any

var A_arbace_core__init_A_const_1575 *lang.Var

var A_arbace_core__init_A_const_1576 any

var A_arbace_core__init_A_const_1577 any

var A_arbace_core__init_A_const_1578 any

var A_arbace_core__init_A_const_1579 *lang.Var

var A_arbace_core__init_A_const_1580 any

var A_arbace_core__init_A_const_1581 any

var A_arbace_core__init_A_const_1582 any

var A_arbace_core__init_A_const_1583 *lang.Var

var A_arbace_core__init_A_const_1584 any

var A_arbace_core__init_A_const_1585 *lang.Var

var A_arbace_core__init_A_const_1586 any

var A_arbace_core__init_A_init jrt.ClassInit

func A_arbace_core__init_A_Init() { if !A_arbace_core__init_A_init.Done() { A_arbace_core__init_A_init.Run(A_arbace_core__init_A_clinit) } }

func A_arbace_core__init_A_clinit() { A_arbace_core__init_A_clinit_p0(); A_arbace_core__init_A_clinit_p1(); A_arbace_core__init_A_clinit_p2(); A_arbace_core__init_A_clinit_p3(); A_arbace_core__init_A_clinit_p4(); A_arbace_core__init_A_clinit_p5(); A_arbace_core__init_A_clinit_p6(); A_arbace_core__init_A_clinit_p7(); A_arbace_core__init_A_clinit_p8(); A_arbace_core__init_A_clinit_p9(); A_arbace_core__init_A_clinit_p10(); A_arbace_core__init_A_clinit_p11(); A_arbace_core__init_A_clinit_p12(); A_arbace_core__init_A_clinit_p13(); A_arbace_core__init_A_clinit_p14(); A_arbace_core__init_A_clinit_p15(); A_arbace_core__init_A_clinit_p16(); A_arbace_core__init_A_clinit_p17(); A_arbace_core__init_A_clinit_p18(); A_arbace_core__init_A_clinit_p19(); A_arbace_core__init_A_clinit_p20(); A_arbace_core__init_A_clinit_p21(); A_arbace_core__init_A_clinit_p22(); A_arbace_core__init_A_clinit_p23(); A_arbace_core__init_A_clinit_p24(); A_arbace_core__init_A_clinit_p25(); A_arbace_core__init_A_clinit_p26(); A_arbace_core__init_A_clinit_p27(); A_arbace_core__init_A_clinit_p28(); A_arbace_core__init_A_clinit_p29(); A_arbace_core__init_A_clinit_p30(); A_arbace_core__init_A_clinit_p31(); A_arbace_core__init_A_clinit_p32(); A_arbace_core__init_A_clinit_p33(); A_arbace_core__init_A_clinit_p34(); A_arbace_core__init_A_clinit_p35(); A_arbace_core__init_A_clinit_p36(); A_arbace_core__init_A_clinit_p37(); A_arbace_core__init_A_clinit_p38(); A_arbace_core__init_A_clinit_p39(); A_arbace_core__init_A_clinit_p40(); A_arbace_core__init_A_clinit_p41(); A_arbace_core__init_A_clinit_p42(); A_arbace_core__init_A_clinit_p43(); A_arbace_core__init_A_clinit_p44(); A_arbace_core__init_A_clinit_p45(); A_arbace_core__init_A_clinit_p46(); A_arbace_core__init_A_clinit_p47(); A_arbace_core__init_A_clinit_p48(); A_arbace_core__init_A_clinit_p49(); A_arbace_core__init_A_clinit_p50(); A_arbace_core__init_A_clinit_p51(); A_arbace_core__init_A_clinit_p52(); A_arbace_core__init_A_clinit_p53(); A_arbace_core__init_A_clinit_p54(); A_arbace_core__init_A_clinit_p55(); A_arbace_core__init_A_clinit_p56(); A_arbace_core__init_A_clinit_p57(); A_arbace_core__init_A_clinit_p58(); A_arbace_core__init_A_clinit_p59(); A_arbace_core__init_A_clinit_p60(); A_arbace_core__init_A_clinit_p61(); A_arbace_core__init_A_clinit_p62(); A_arbace_core__init_A_clinit_p63(); A_arbace_core__init_A_clinit_p64(); A_arbace_core__init_A_clinit_p65(); A_arbace_core__init_A_clinit_p66(); A_arbace_core__init_A_clinit_p67(); A_arbace_core__init_A_clinit_p68(); A_arbace_core__init_A_clinit_p69(); A_arbace_core__init_A_clinit_p70(); A_arbace_core__init_A_clinit_p71(); A_arbace_core__init_A_clinit_p72(); A_arbace_core__init_A_clinit_p73(); A_arbace_core__init_A_clinit_p74(); A_arbace_core__init_A_clinit_p75(); A_arbace_core__init_A_clinit_p76(); A_arbace_core__init_A_clinit_p77(); A_arbace_core__init_A_clinit_p78(); A_arbace_core__init_A_clinit_p79(); A_arbace_core__init_A_clinit_p80(); A_arbace_core__init_A_clinit_p81(); A_arbace_core__init_A_clinit_p82(); A_arbace_core__init_A_clinit_p83(); A_arbace_core__init_A_clinit_p84(); A_arbace_core__init_A_clinit_p85(); A_arbace_core__init_A_clinit_p86(); A_arbace_core__init_A_clinit_p87(); A_arbace_core__init_A_clinit_p88(); A_arbace_core__init_A_clinit_p89(); A_arbace_core__init_A_clinit_p90(); A_arbace_core__init_A_clinit_p91(); A_arbace_core__init_A_clinit_p92(); A_arbace_core__init_A_clinit_p93(); A_arbace_core__init_A_clinit_p94(); A_arbace_core__init_A_clinit_p95(); A_arbace_core__init_A_clinit_p96(); A_arbace_core__init_A_clinit_p97(); A_arbace_core__init_A_clinit_p98(); A_arbace_core__init_A_clinit_p99(); A_arbace_core__init_A_clinit_p100(); A_arbace_core__init_A_clinit_p101(); A_arbace_core__init_A_clinit_p102(); A_arbace_core__init_A_clinit_p103(); A_arbace_core__init_A_clinit_p104(); A_arbace_core__init_A_clinit_p105(); A_arbace_core__init_A_clinit_p106(); A_arbace_core__init_A_clinit_p107(); A_arbace_core__init_A_clinit_p108(); A_arbace_core__init_A_clinit_p109(); A_arbace_core__init_A_clinit_p110(); A_arbace_core__init_A_clinit_p111(); A_arbace_core__init_A_clinit_p112(); A_arbace_core__init_A_clinit_p113(); A_arbace_core__init_A_clinit_p114(); A_arbace_core__init_A_clinit_p115(); A_arbace_core__init_A_clinit_p116(); A_arbace_core__init_A_clinit_p117(); A_arbace_core__init_A_clinit_p118(); A_arbace_core__init_A_clinit_p119() }

func A_arbace_core__init_A_clinit_p0() { A_arbace_core__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_710, 1936); A_arbace_core__init_A_const_0 = A_arbace_core__init_A_const_pool.A[349]; A_arbace_core__init_A_const_1 = A_arbace_core__init_A_const_pool.A[350]; A_arbace_core__init_A_const_2 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[351]); A_arbace_core__init_A_const_3 = A_arbace_core__init_A_const_pool.A[352]; A_arbace_core__init_A_const_4 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[353]); A_arbace_core__init_A_const_5 = A_arbace_core__init_A_const_pool.A[354]; A_arbace_core__init_A_const_6 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[355]); A_arbace_core__init_A_const_7 = A_arbace_core__init_A_const_pool.A[356]; A_arbace_core__init_A_const_8 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[357]); A_arbace_core__init_A_const_9 = A_arbace_core__init_A_const_pool.A[358]; A_arbace_core__init_A_const_10 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[359]); A_arbace_core__init_A_const_11 = A_arbace_core__init_A_const_pool.A[360]; A_arbace_core__init_A_const_12 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[361]) }

func A_arbace_core__init_A_clinit_p1() { A_arbace_core__init_A_const_13 = A_arbace_core__init_A_const_pool.A[362]; A_arbace_core__init_A_const_14 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[363]); A_arbace_core__init_A_const_15 = A_arbace_core__init_A_const_pool.A[364]; A_arbace_core__init_A_const_16 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[365]); A_arbace_core__init_A_const_17 = A_arbace_core__init_A_const_pool.A[366]; A_arbace_core__init_A_const_18 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[367]); A_arbace_core__init_A_const_19 = A_arbace_core__init_A_const_pool.A[368]; A_arbace_core__init_A_const_20 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[369]); A_arbace_core__init_A_const_21 = A_arbace_core__init_A_const_pool.A[370]; A_arbace_core__init_A_const_22 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[371]); A_arbace_core__init_A_const_23 = A_arbace_core__init_A_const_pool.A[372]; A_arbace_core__init_A_const_24 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[373]); A_arbace_core__init_A_const_25 = A_arbace_core__init_A_const_pool.A[374] }

func A_arbace_core__init_A_clinit_p2() { A_arbace_core__init_A_const_26 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[375]); A_arbace_core__init_A_const_27 = A_arbace_core__init_A_const_pool.A[376]; A_arbace_core__init_A_const_28 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[377]); A_arbace_core__init_A_const_29 = A_arbace_core__init_A_const_pool.A[378]; A_arbace_core__init_A_const_30 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[379]); A_arbace_core__init_A_const_31 = A_arbace_core__init_A_const_pool.A[380]; A_arbace_core__init_A_const_32 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[381]); A_arbace_core__init_A_const_33 = A_arbace_core__init_A_const_pool.A[382]; A_arbace_core__init_A_const_34 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[383]); A_arbace_core__init_A_const_35 = A_arbace_core__init_A_const_pool.A[384]; A_arbace_core__init_A_const_36 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[385]); A_arbace_core__init_A_const_37 = A_arbace_core__init_A_const_pool.A[386]; A_arbace_core__init_A_const_38 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[387]) }

func A_arbace_core__init_A_clinit_p3() { A_arbace_core__init_A_const_39 = A_arbace_core__init_A_const_pool.A[388]; A_arbace_core__init_A_const_40 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[389]); A_arbace_core__init_A_const_41 = A_arbace_core__init_A_const_pool.A[390]; A_arbace_core__init_A_const_42 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[391]); A_arbace_core__init_A_const_43 = A_arbace_core__init_A_const_pool.A[392]; A_arbace_core__init_A_const_44 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[393]); A_arbace_core__init_A_const_45 = A_arbace_core__init_A_const_pool.A[394]; A_arbace_core__init_A_const_46 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[395]); A_arbace_core__init_A_const_47 = A_arbace_core__init_A_const_pool.A[396]; A_arbace_core__init_A_const_48 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[397]); A_arbace_core__init_A_const_49 = A_arbace_core__init_A_const_pool.A[398]; A_arbace_core__init_A_const_50 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[399]); A_arbace_core__init_A_const_51 = lang.Keyword_Cast(A_arbace_core__init_A_const_pool.A[400]) }

func A_arbace_core__init_A_clinit_p4() { A_arbace_core__init_A_const_52 = A_arbace_core__init_A_const_pool.A[401]; A_arbace_core__init_A_const_53 = lang.Keyword_Cast(A_arbace_core__init_A_const_pool.A[402]); A_arbace_core__init_A_const_54 = lang.Keyword_Cast(A_arbace_core__init_A_const_pool.A[403]); A_arbace_core__init_A_const_55 = lang.Keyword_Cast(A_arbace_core__init_A_const_pool.A[404]); A_arbace_core__init_A_const_56 = lang.Keyword_Cast(A_arbace_core__init_A_const_pool.A[405]); A_arbace_core__init_A_const_57 = lang.Keyword_Cast(A_arbace_core__init_A_const_pool.A[406]); A_arbace_core__init_A_const_58 = A_arbace_core__init_A_const_pool.A[407]; A_arbace_core__init_A_const_59 = lang.Keyword_Cast(A_arbace_core__init_A_const_pool.A[408]); A_arbace_core__init_A_const_60 = A_arbace_core__init_A_const_pool.A[409]; A_arbace_core__init_A_const_61 = lang.Keyword_Cast(A_arbace_core__init_A_const_pool.A[410]); A_arbace_core__init_A_const_62 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[411]); A_arbace_core__init_A_const_63 = A_arbace_core__init_A_const_pool.A[412]; A_arbace_core__init_A_const_64 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[413]) }

func A_arbace_core__init_A_clinit_p5() { A_arbace_core__init_A_const_65 = A_arbace_core__init_A_const_pool.A[414]; A_arbace_core__init_A_const_66 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[415]); A_arbace_core__init_A_const_67 = A_arbace_core__init_A_const_pool.A[416]; A_arbace_core__init_A_const_68 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[417]); A_arbace_core__init_A_const_69 = A_arbace_core__init_A_const_pool.A[418]; A_arbace_core__init_A_const_70 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[419]); A_arbace_core__init_A_const_71 = A_arbace_core__init_A_const_pool.A[420]; A_arbace_core__init_A_const_72 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[421]); A_arbace_core__init_A_const_73 = A_arbace_core__init_A_const_pool.A[422]; A_arbace_core__init_A_const_74 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[423]); A_arbace_core__init_A_const_75 = A_arbace_core__init_A_const_pool.A[424]; A_arbace_core__init_A_const_76 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[425]); A_arbace_core__init_A_const_77 = A_arbace_core__init_A_const_pool.A[426] }

func A_arbace_core__init_A_clinit_p6() { A_arbace_core__init_A_const_78 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[427]); A_arbace_core__init_A_const_79 = A_arbace_core__init_A_const_pool.A[428]; A_arbace_core__init_A_const_80 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[429]); A_arbace_core__init_A_const_81 = A_arbace_core__init_A_const_pool.A[430]; A_arbace_core__init_A_const_82 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[431]); A_arbace_core__init_A_const_83 = A_arbace_core__init_A_const_pool.A[432]; A_arbace_core__init_A_const_84 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[433]); A_arbace_core__init_A_const_85 = A_arbace_core__init_A_const_pool.A[434]; A_arbace_core__init_A_const_86 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[435]); A_arbace_core__init_A_const_87 = A_arbace_core__init_A_const_pool.A[436]; A_arbace_core__init_A_const_88 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[437]); A_arbace_core__init_A_const_89 = A_arbace_core__init_A_const_pool.A[438]; A_arbace_core__init_A_const_90 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[439]) }

func A_arbace_core__init_A_clinit_p7() { A_arbace_core__init_A_const_91 = A_arbace_core__init_A_const_pool.A[440]; A_arbace_core__init_A_const_92 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[441]); A_arbace_core__init_A_const_93 = A_arbace_core__init_A_const_pool.A[442]; A_arbace_core__init_A_const_94 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[443]); A_arbace_core__init_A_const_95 = A_arbace_core__init_A_const_pool.A[444]; A_arbace_core__init_A_const_96 = lang.Keyword_Cast(A_arbace_core__init_A_const_pool.A[445]); A_arbace_core__init_A_const_97 = jrt.Class_Cast(A_arbace_core__init_A_const_pool.A[446]); A_arbace_core__init_A_const_98 = A_arbace_core__init_A_const_pool.A[447]; A_arbace_core__init_A_const_99 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[448]); A_arbace_core__init_A_const_100 = A_arbace_core__init_A_const_pool.A[449]; A_arbace_core__init_A_const_101 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[450]); A_arbace_core__init_A_const_102 = A_arbace_core__init_A_const_pool.A[451]; A_arbace_core__init_A_const_103 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[452]) }

func A_arbace_core__init_A_clinit_p8() { A_arbace_core__init_A_const_104 = A_arbace_core__init_A_const_pool.A[453]; A_arbace_core__init_A_const_105 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[454]); A_arbace_core__init_A_const_106 = A_arbace_core__init_A_const_pool.A[455]; A_arbace_core__init_A_const_107 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[456]); A_arbace_core__init_A_const_108 = A_arbace_core__init_A_const_pool.A[457]; A_arbace_core__init_A_const_109 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[458]); A_arbace_core__init_A_const_110 = A_arbace_core__init_A_const_pool.A[459]; A_arbace_core__init_A_const_111 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[460]); A_arbace_core__init_A_const_112 = A_arbace_core__init_A_const_pool.A[461]; A_arbace_core__init_A_const_113 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[462]); A_arbace_core__init_A_const_114 = A_arbace_core__init_A_const_pool.A[463]; A_arbace_core__init_A_const_115 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[464]); A_arbace_core__init_A_const_116 = A_arbace_core__init_A_const_pool.A[465] }

func A_arbace_core__init_A_clinit_p9() { A_arbace_core__init_A_const_117 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[466]); A_arbace_core__init_A_const_118 = A_arbace_core__init_A_const_pool.A[467]; A_arbace_core__init_A_const_119 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[468]); A_arbace_core__init_A_const_120 = A_arbace_core__init_A_const_pool.A[469]; A_arbace_core__init_A_const_121 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[470]); A_arbace_core__init_A_const_122 = A_arbace_core__init_A_const_pool.A[471]; A_arbace_core__init_A_const_123 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[472]); A_arbace_core__init_A_const_124 = A_arbace_core__init_A_const_pool.A[473]; A_arbace_core__init_A_const_125 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[474]); A_arbace_core__init_A_const_126 = A_arbace_core__init_A_const_pool.A[475]; A_arbace_core__init_A_const_127 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[476]); A_arbace_core__init_A_const_128 = A_arbace_core__init_A_const_pool.A[477]; A_arbace_core__init_A_const_129 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[478]) }

func A_arbace_core__init_A_clinit_p10() { A_arbace_core__init_A_const_130 = A_arbace_core__init_A_const_pool.A[479]; A_arbace_core__init_A_const_131 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[480]); A_arbace_core__init_A_const_132 = A_arbace_core__init_A_const_pool.A[481]; A_arbace_core__init_A_const_133 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[482]); A_arbace_core__init_A_const_134 = A_arbace_core__init_A_const_pool.A[483]; A_arbace_core__init_A_const_135 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[484]); A_arbace_core__init_A_const_136 = A_arbace_core__init_A_const_pool.A[485]; A_arbace_core__init_A_const_137 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[486]); A_arbace_core__init_A_const_138 = A_arbace_core__init_A_const_pool.A[487]; A_arbace_core__init_A_const_139 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[488]); A_arbace_core__init_A_const_140 = A_arbace_core__init_A_const_pool.A[489]; A_arbace_core__init_A_const_141 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[490]); A_arbace_core__init_A_const_142 = A_arbace_core__init_A_const_pool.A[491] }

func A_arbace_core__init_A_clinit_p11() { A_arbace_core__init_A_const_143 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[492]); A_arbace_core__init_A_const_144 = A_arbace_core__init_A_const_pool.A[493]; A_arbace_core__init_A_const_145 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[494]); A_arbace_core__init_A_const_146 = A_arbace_core__init_A_const_pool.A[495]; A_arbace_core__init_A_const_147 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[496]); A_arbace_core__init_A_const_148 = A_arbace_core__init_A_const_pool.A[497]; A_arbace_core__init_A_const_149 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[498]); A_arbace_core__init_A_const_150 = A_arbace_core__init_A_const_pool.A[499]; A_arbace_core__init_A_const_151 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[500]); A_arbace_core__init_A_const_152 = A_arbace_core__init_A_const_pool.A[501]; A_arbace_core__init_A_const_153 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[502]); A_arbace_core__init_A_const_154 = A_arbace_core__init_A_const_pool.A[503]; A_arbace_core__init_A_const_155 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[504]) }

func A_arbace_core__init_A_clinit_p12() { A_arbace_core__init_A_const_156 = A_arbace_core__init_A_const_pool.A[505]; A_arbace_core__init_A_const_157 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[506]); A_arbace_core__init_A_const_158 = A_arbace_core__init_A_const_pool.A[507]; A_arbace_core__init_A_const_159 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[508]); A_arbace_core__init_A_const_160 = A_arbace_core__init_A_const_pool.A[509]; A_arbace_core__init_A_const_161 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[510]); A_arbace_core__init_A_const_162 = A_arbace_core__init_A_const_pool.A[511]; A_arbace_core__init_A_const_163 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[512]); A_arbace_core__init_A_const_164 = A_arbace_core__init_A_const_pool.A[513]; A_arbace_core__init_A_const_165 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[514]); A_arbace_core__init_A_const_166 = A_arbace_core__init_A_const_pool.A[515]; A_arbace_core__init_A_const_167 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[516]); A_arbace_core__init_A_const_168 = A_arbace_core__init_A_const_pool.A[517] }

func A_arbace_core__init_A_clinit_p13() { A_arbace_core__init_A_const_169 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[518]); A_arbace_core__init_A_const_170 = A_arbace_core__init_A_const_pool.A[519]; A_arbace_core__init_A_const_171 = lang.Keyword_Cast(A_arbace_core__init_A_const_pool.A[520]); A_arbace_core__init_A_const_172 = A_arbace_core__init_A_const_pool.A[521]; A_arbace_core__init_A_const_173 = A_arbace_core__init_A_const_pool.A[522]; A_arbace_core__init_A_const_174 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[523]); A_arbace_core__init_A_const_175 = A_arbace_core__init_A_const_pool.A[524]; A_arbace_core__init_A_const_176 = A_arbace_core__init_A_const_pool.A[525]; A_arbace_core__init_A_const_177 = A_arbace_core__init_A_const_pool.A[526]; A_arbace_core__init_A_const_178 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[527]); A_arbace_core__init_A_const_179 = A_arbace_core__init_A_const_pool.A[528]; A_arbace_core__init_A_const_180 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[529]); A_arbace_core__init_A_const_181 = A_arbace_core__init_A_const_pool.A[530]; A_arbace_core__init_A_const_182 = A_arbace_core__init_A_const_pool.A[531] }

func A_arbace_core__init_A_clinit_p14() { A_arbace_core__init_A_const_183 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[532]); A_arbace_core__init_A_const_184 = A_arbace_core__init_A_const_pool.A[533]; A_arbace_core__init_A_const_185 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[534]); A_arbace_core__init_A_const_186 = A_arbace_core__init_A_const_pool.A[535]; A_arbace_core__init_A_const_187 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[536]); A_arbace_core__init_A_const_188 = A_arbace_core__init_A_const_pool.A[537]; A_arbace_core__init_A_const_189 = A_arbace_core__init_A_const_pool.A[538]; A_arbace_core__init_A_const_190 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[539]); A_arbace_core__init_A_const_191 = A_arbace_core__init_A_const_pool.A[540]; A_arbace_core__init_A_const_192 = A_arbace_core__init_A_const_pool.A[541]; A_arbace_core__init_A_const_193 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[542]); A_arbace_core__init_A_const_194 = A_arbace_core__init_A_const_pool.A[543]; A_arbace_core__init_A_const_195 = A_arbace_core__init_A_const_pool.A[544]; A_arbace_core__init_A_const_196 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[545]) }

func A_arbace_core__init_A_clinit_p15() { A_arbace_core__init_A_const_197 = A_arbace_core__init_A_const_pool.A[546]; A_arbace_core__init_A_const_198 = A_arbace_core__init_A_const_pool.A[547]; A_arbace_core__init_A_const_199 = A_arbace_core__init_A_const_pool.A[548]; A_arbace_core__init_A_const_200 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[549]); A_arbace_core__init_A_const_201 = A_arbace_core__init_A_const_pool.A[550]; A_arbace_core__init_A_const_202 = A_arbace_core__init_A_const_pool.A[551]; A_arbace_core__init_A_const_203 = A_arbace_core__init_A_const_pool.A[552]; A_arbace_core__init_A_const_204 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[553]); A_arbace_core__init_A_const_205 = A_arbace_core__init_A_const_pool.A[554]; A_arbace_core__init_A_const_206 = A_arbace_core__init_A_const_pool.A[555]; A_arbace_core__init_A_const_207 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[556]); A_arbace_core__init_A_const_208 = A_arbace_core__init_A_const_pool.A[557]; A_arbace_core__init_A_const_209 = A_arbace_core__init_A_const_pool.A[558]; A_arbace_core__init_A_const_210 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[559]) }

func A_arbace_core__init_A_clinit_p16() { A_arbace_core__init_A_const_211 = A_arbace_core__init_A_const_pool.A[560]; A_arbace_core__init_A_const_212 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[561]); A_arbace_core__init_A_const_213 = A_arbace_core__init_A_const_pool.A[562]; A_arbace_core__init_A_const_214 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[563]); A_arbace_core__init_A_const_215 = A_arbace_core__init_A_const_pool.A[564]; A_arbace_core__init_A_const_216 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[565]); A_arbace_core__init_A_const_217 = A_arbace_core__init_A_const_pool.A[566]; A_arbace_core__init_A_const_218 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[567]); A_arbace_core__init_A_const_219 = A_arbace_core__init_A_const_pool.A[568]; A_arbace_core__init_A_const_220 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[569]); A_arbace_core__init_A_const_221 = A_arbace_core__init_A_const_pool.A[570]; A_arbace_core__init_A_const_222 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[571]); A_arbace_core__init_A_const_223 = A_arbace_core__init_A_const_pool.A[572]; A_arbace_core__init_A_const_224 = A_arbace_core__init_A_const_pool.A[573] }

func A_arbace_core__init_A_clinit_p17() { A_arbace_core__init_A_const_225 = A_arbace_core__init_A_const_pool.A[574]; A_arbace_core__init_A_const_226 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[575]); A_arbace_core__init_A_const_227 = A_arbace_core__init_A_const_pool.A[576]; A_arbace_core__init_A_const_228 = A_arbace_core__init_A_const_pool.A[577]; A_arbace_core__init_A_const_229 = A_arbace_core__init_A_const_pool.A[578]; A_arbace_core__init_A_const_230 = A_arbace_core__init_A_const_pool.A[579]; A_arbace_core__init_A_const_231 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[580]); A_arbace_core__init_A_const_232 = A_arbace_core__init_A_const_pool.A[581]; A_arbace_core__init_A_const_233 = A_arbace_core__init_A_const_pool.A[582]; A_arbace_core__init_A_const_234 = A_arbace_core__init_A_const_pool.A[583]; A_arbace_core__init_A_const_235 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[584]); A_arbace_core__init_A_const_236 = A_arbace_core__init_A_const_pool.A[585]; A_arbace_core__init_A_const_237 = A_arbace_core__init_A_const_pool.A[586]; A_arbace_core__init_A_const_238 = A_arbace_core__init_A_const_pool.A[587]; A_arbace_core__init_A_const_239 = A_arbace_core__init_A_const_pool.A[588] }

func A_arbace_core__init_A_clinit_p18() { A_arbace_core__init_A_const_240 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[589]); A_arbace_core__init_A_const_241 = A_arbace_core__init_A_const_pool.A[590]; A_arbace_core__init_A_const_242 = A_arbace_core__init_A_const_pool.A[591]; A_arbace_core__init_A_const_243 = A_arbace_core__init_A_const_pool.A[592]; A_arbace_core__init_A_const_244 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[593]); A_arbace_core__init_A_const_245 = A_arbace_core__init_A_const_pool.A[594]; A_arbace_core__init_A_const_246 = A_arbace_core__init_A_const_pool.A[595]; A_arbace_core__init_A_const_247 = A_arbace_core__init_A_const_pool.A[596]; A_arbace_core__init_A_const_248 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[597]); A_arbace_core__init_A_const_249 = A_arbace_core__init_A_const_pool.A[598]; A_arbace_core__init_A_const_250 = A_arbace_core__init_A_const_pool.A[599]; A_arbace_core__init_A_const_251 = A_arbace_core__init_A_const_pool.A[600]; A_arbace_core__init_A_const_252 = A_arbace_core__init_A_const_pool.A[601]; A_arbace_core__init_A_const_253 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[602]) }

func A_arbace_core__init_A_clinit_p19() { A_arbace_core__init_A_const_254 = A_arbace_core__init_A_const_pool.A[603]; A_arbace_core__init_A_const_255 = A_arbace_core__init_A_const_pool.A[604]; A_arbace_core__init_A_const_256 = A_arbace_core__init_A_const_pool.A[605]; A_arbace_core__init_A_const_257 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[606]); A_arbace_core__init_A_const_258 = A_arbace_core__init_A_const_pool.A[607]; A_arbace_core__init_A_const_259 = A_arbace_core__init_A_const_pool.A[608]; A_arbace_core__init_A_const_260 = A_arbace_core__init_A_const_pool.A[609]; A_arbace_core__init_A_const_261 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[610]); A_arbace_core__init_A_const_262 = A_arbace_core__init_A_const_pool.A[611]; A_arbace_core__init_A_const_263 = A_arbace_core__init_A_const_pool.A[612]; A_arbace_core__init_A_const_264 = A_arbace_core__init_A_const_pool.A[613]; A_arbace_core__init_A_const_265 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[614]); A_arbace_core__init_A_const_266 = A_arbace_core__init_A_const_pool.A[615]; A_arbace_core__init_A_const_267 = A_arbace_core__init_A_const_pool.A[616]; A_arbace_core__init_A_const_268 = A_arbace_core__init_A_const_pool.A[617] }

func A_arbace_core__init_A_clinit_p20() { A_arbace_core__init_A_const_269 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[618]); A_arbace_core__init_A_const_270 = A_arbace_core__init_A_const_pool.A[619]; A_arbace_core__init_A_const_271 = A_arbace_core__init_A_const_pool.A[620]; A_arbace_core__init_A_const_272 = A_arbace_core__init_A_const_pool.A[621]; A_arbace_core__init_A_const_273 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[622]); A_arbace_core__init_A_const_274 = A_arbace_core__init_A_const_pool.A[623]; A_arbace_core__init_A_const_275 = A_arbace_core__init_A_const_pool.A[624]; A_arbace_core__init_A_const_276 = A_arbace_core__init_A_const_pool.A[625]; A_arbace_core__init_A_const_277 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[626]); A_arbace_core__init_A_const_278 = A_arbace_core__init_A_const_pool.A[627]; A_arbace_core__init_A_const_279 = A_arbace_core__init_A_const_pool.A[628]; A_arbace_core__init_A_const_280 = A_arbace_core__init_A_const_pool.A[629]; A_arbace_core__init_A_const_281 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[630]); A_arbace_core__init_A_const_282 = A_arbace_core__init_A_const_pool.A[631] }

func A_arbace_core__init_A_clinit_p21() { A_arbace_core__init_A_const_283 = A_arbace_core__init_A_const_pool.A[632]; A_arbace_core__init_A_const_284 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[633]); A_arbace_core__init_A_const_285 = A_arbace_core__init_A_const_pool.A[634]; A_arbace_core__init_A_const_286 = A_arbace_core__init_A_const_pool.A[635]; A_arbace_core__init_A_const_287 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[636]); A_arbace_core__init_A_const_288 = A_arbace_core__init_A_const_pool.A[637]; A_arbace_core__init_A_const_289 = A_arbace_core__init_A_const_pool.A[638]; A_arbace_core__init_A_const_290 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[639]); A_arbace_core__init_A_const_291 = A_arbace_core__init_A_const_pool.A[640]; A_arbace_core__init_A_const_292 = A_arbace_core__init_A_const_pool.A[641]; A_arbace_core__init_A_const_293 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[642]); A_arbace_core__init_A_const_294 = A_arbace_core__init_A_const_pool.A[643]; A_arbace_core__init_A_const_295 = A_arbace_core__init_A_const_pool.A[644]; A_arbace_core__init_A_const_296 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[645]) }

func A_arbace_core__init_A_clinit_p22() { A_arbace_core__init_A_const_297 = A_arbace_core__init_A_const_pool.A[646]; A_arbace_core__init_A_const_298 = A_arbace_core__init_A_const_pool.A[647]; A_arbace_core__init_A_const_299 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[648]); A_arbace_core__init_A_const_300 = A_arbace_core__init_A_const_pool.A[649]; A_arbace_core__init_A_const_301 = A_arbace_core__init_A_const_pool.A[650]; A_arbace_core__init_A_const_302 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[651]); A_arbace_core__init_A_const_303 = A_arbace_core__init_A_const_pool.A[652]; A_arbace_core__init_A_const_304 = A_arbace_core__init_A_const_pool.A[653]; A_arbace_core__init_A_const_305 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[654]); A_arbace_core__init_A_const_306 = A_arbace_core__init_A_const_pool.A[655]; A_arbace_core__init_A_const_307 = A_arbace_core__init_A_const_pool.A[656]; A_arbace_core__init_A_const_308 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[657]); A_arbace_core__init_A_const_309 = A_arbace_core__init_A_const_pool.A[658]; A_arbace_core__init_A_const_310 = A_arbace_core__init_A_const_pool.A[659] }

func A_arbace_core__init_A_clinit_p23() { A_arbace_core__init_A_const_311 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[660]); A_arbace_core__init_A_const_312 = A_arbace_core__init_A_const_pool.A[661]; A_arbace_core__init_A_const_313 = A_arbace_core__init_A_const_pool.A[662]; A_arbace_core__init_A_const_314 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[663]); A_arbace_core__init_A_const_315 = A_arbace_core__init_A_const_pool.A[664]; A_arbace_core__init_A_const_316 = A_arbace_core__init_A_const_pool.A[665]; A_arbace_core__init_A_const_317 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[666]); A_arbace_core__init_A_const_318 = A_arbace_core__init_A_const_pool.A[667]; A_arbace_core__init_A_const_319 = A_arbace_core__init_A_const_pool.A[668]; A_arbace_core__init_A_const_320 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[669]); A_arbace_core__init_A_const_321 = A_arbace_core__init_A_const_pool.A[670]; A_arbace_core__init_A_const_322 = A_arbace_core__init_A_const_pool.A[671]; A_arbace_core__init_A_const_323 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[672]); A_arbace_core__init_A_const_324 = A_arbace_core__init_A_const_pool.A[673] }

func A_arbace_core__init_A_clinit_p24() { A_arbace_core__init_A_const_325 = A_arbace_core__init_A_const_pool.A[674]; A_arbace_core__init_A_const_326 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[675]); A_arbace_core__init_A_const_327 = A_arbace_core__init_A_const_pool.A[676]; A_arbace_core__init_A_const_328 = A_arbace_core__init_A_const_pool.A[677]; A_arbace_core__init_A_const_329 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[678]); A_arbace_core__init_A_const_330 = A_arbace_core__init_A_const_pool.A[679]; A_arbace_core__init_A_const_331 = A_arbace_core__init_A_const_pool.A[680]; A_arbace_core__init_A_const_332 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[681]); A_arbace_core__init_A_const_333 = A_arbace_core__init_A_const_pool.A[682]; A_arbace_core__init_A_const_334 = A_arbace_core__init_A_const_pool.A[683]; A_arbace_core__init_A_const_335 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[684]); A_arbace_core__init_A_const_336 = A_arbace_core__init_A_const_pool.A[685]; A_arbace_core__init_A_const_337 = A_arbace_core__init_A_const_pool.A[686]; A_arbace_core__init_A_const_338 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[687]) }

func A_arbace_core__init_A_clinit_p25() { A_arbace_core__init_A_const_339 = A_arbace_core__init_A_const_pool.A[688]; A_arbace_core__init_A_const_340 = A_arbace_core__init_A_const_pool.A[689]; A_arbace_core__init_A_const_341 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[690]); A_arbace_core__init_A_const_342 = A_arbace_core__init_A_const_pool.A[691]; A_arbace_core__init_A_const_343 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[692]); A_arbace_core__init_A_const_344 = A_arbace_core__init_A_const_pool.A[693]; A_arbace_core__init_A_const_345 = A_arbace_core__init_A_const_pool.A[694]; A_arbace_core__init_A_const_346 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[695]); A_arbace_core__init_A_const_347 = A_arbace_core__init_A_const_pool.A[696]; A_arbace_core__init_A_const_348 = A_arbace_core__init_A_const_pool.A[697]; A_arbace_core__init_A_const_349 = A_arbace_core__init_A_const_pool.A[698]; A_arbace_core__init_A_const_350 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[699]); A_arbace_core__init_A_const_351 = A_arbace_core__init_A_const_pool.A[700]; A_arbace_core__init_A_const_352 = A_arbace_core__init_A_const_pool.A[701] }

func A_arbace_core__init_A_clinit_p26() { A_arbace_core__init_A_const_353 = A_arbace_core__init_A_const_pool.A[702]; A_arbace_core__init_A_const_354 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[703]); A_arbace_core__init_A_const_355 = A_arbace_core__init_A_const_pool.A[704]; A_arbace_core__init_A_const_356 = A_arbace_core__init_A_const_pool.A[705]; A_arbace_core__init_A_const_357 = A_arbace_core__init_A_const_pool.A[706]; A_arbace_core__init_A_const_358 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[707]); A_arbace_core__init_A_const_359 = A_arbace_core__init_A_const_pool.A[708]; A_arbace_core__init_A_const_360 = A_arbace_core__init_A_const_pool.A[709]; A_arbace_core__init_A_const_361 = A_arbace_core__init_A_const_pool.A[710]; A_arbace_core__init_A_const_362 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[711]); A_arbace_core__init_A_const_363 = A_arbace_core__init_A_const_pool.A[712]; A_arbace_core__init_A_const_364 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[713]); A_arbace_core__init_A_const_365 = A_arbace_core__init_A_const_pool.A[714]; A_arbace_core__init_A_const_366 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[715]) }

func A_arbace_core__init_A_clinit_p27() { A_arbace_core__init_A_const_367 = A_arbace_core__init_A_const_pool.A[716]; A_arbace_core__init_A_const_368 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[717]); A_arbace_core__init_A_const_369 = A_arbace_core__init_A_const_pool.A[718]; A_arbace_core__init_A_const_370 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[719]); A_arbace_core__init_A_const_371 = A_arbace_core__init_A_const_pool.A[720]; A_arbace_core__init_A_const_372 = A_arbace_core__init_A_const_pool.A[721]; A_arbace_core__init_A_const_373 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[722]); A_arbace_core__init_A_const_374 = A_arbace_core__init_A_const_pool.A[723]; A_arbace_core__init_A_const_375 = A_arbace_core__init_A_const_pool.A[724]; A_arbace_core__init_A_const_376 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[725]); A_arbace_core__init_A_const_377 = A_arbace_core__init_A_const_pool.A[726]; A_arbace_core__init_A_const_378 = A_arbace_core__init_A_const_pool.A[727]; A_arbace_core__init_A_const_379 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[728]); A_arbace_core__init_A_const_380 = A_arbace_core__init_A_const_pool.A[729] }

func A_arbace_core__init_A_clinit_p28() { A_arbace_core__init_A_const_381 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[730]); A_arbace_core__init_A_const_382 = A_arbace_core__init_A_const_pool.A[731]; A_arbace_core__init_A_const_383 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[732]); A_arbace_core__init_A_const_384 = A_arbace_core__init_A_const_pool.A[733]; A_arbace_core__init_A_const_385 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[734]); A_arbace_core__init_A_const_386 = A_arbace_core__init_A_const_pool.A[735]; A_arbace_core__init_A_const_387 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[736]); A_arbace_core__init_A_const_388 = A_arbace_core__init_A_const_pool.A[737]; A_arbace_core__init_A_const_389 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[738]); A_arbace_core__init_A_const_390 = A_arbace_core__init_A_const_pool.A[739]; A_arbace_core__init_A_const_391 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[740]); A_arbace_core__init_A_const_392 = A_arbace_core__init_A_const_pool.A[741]; A_arbace_core__init_A_const_393 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[742]) }

func A_arbace_core__init_A_clinit_p29() { A_arbace_core__init_A_const_394 = A_arbace_core__init_A_const_pool.A[743]; A_arbace_core__init_A_const_395 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[744]); A_arbace_core__init_A_const_396 = A_arbace_core__init_A_const_pool.A[745]; A_arbace_core__init_A_const_397 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[746]); A_arbace_core__init_A_const_398 = A_arbace_core__init_A_const_pool.A[747]; A_arbace_core__init_A_const_399 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[748]); A_arbace_core__init_A_const_400 = A_arbace_core__init_A_const_pool.A[749]; A_arbace_core__init_A_const_401 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[750]); A_arbace_core__init_A_const_402 = A_arbace_core__init_A_const_pool.A[751]; A_arbace_core__init_A_const_403 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[752]); A_arbace_core__init_A_const_404 = A_arbace_core__init_A_const_pool.A[753]; A_arbace_core__init_A_const_405 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[754]); A_arbace_core__init_A_const_406 = A_arbace_core__init_A_const_pool.A[755] }

func A_arbace_core__init_A_clinit_p30() { A_arbace_core__init_A_const_407 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[756]); A_arbace_core__init_A_const_408 = A_arbace_core__init_A_const_pool.A[757]; A_arbace_core__init_A_const_409 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[758]); A_arbace_core__init_A_const_410 = A_arbace_core__init_A_const_pool.A[759]; A_arbace_core__init_A_const_411 = A_arbace_core__init_A_const_pool.A[760]; A_arbace_core__init_A_const_412 = A_arbace_core__init_A_const_pool.A[761]; A_arbace_core__init_A_const_413 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[762]); A_arbace_core__init_A_const_414 = A_arbace_core__init_A_const_pool.A[763]; A_arbace_core__init_A_const_415 = A_arbace_core__init_A_const_pool.A[764]; A_arbace_core__init_A_const_416 = A_arbace_core__init_A_const_pool.A[765]; A_arbace_core__init_A_const_417 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[766]); A_arbace_core__init_A_const_418 = A_arbace_core__init_A_const_pool.A[767]; A_arbace_core__init_A_const_419 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[768]); A_arbace_core__init_A_const_420 = A_arbace_core__init_A_const_pool.A[769] }

func A_arbace_core__init_A_clinit_p31() { A_arbace_core__init_A_const_421 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[770]); A_arbace_core__init_A_const_422 = A_arbace_core__init_A_const_pool.A[771]; A_arbace_core__init_A_const_423 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[772]); A_arbace_core__init_A_const_424 = A_arbace_core__init_A_const_pool.A[773]; A_arbace_core__init_A_const_425 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[774]); A_arbace_core__init_A_const_426 = A_arbace_core__init_A_const_pool.A[775]; A_arbace_core__init_A_const_427 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[776]); A_arbace_core__init_A_const_428 = A_arbace_core__init_A_const_pool.A[777]; A_arbace_core__init_A_const_429 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[778]); A_arbace_core__init_A_const_430 = A_arbace_core__init_A_const_pool.A[779]; A_arbace_core__init_A_const_431 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[780]); A_arbace_core__init_A_const_432 = A_arbace_core__init_A_const_pool.A[781]; A_arbace_core__init_A_const_433 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[782]) }

func A_arbace_core__init_A_clinit_p32() { A_arbace_core__init_A_const_434 = A_arbace_core__init_A_const_pool.A[783]; A_arbace_core__init_A_const_435 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[784]); A_arbace_core__init_A_const_436 = A_arbace_core__init_A_const_pool.A[785]; A_arbace_core__init_A_const_437 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[786]); A_arbace_core__init_A_const_438 = A_arbace_core__init_A_const_pool.A[787]; A_arbace_core__init_A_const_439 = A_arbace_core__init_A_const_pool.A[788]; A_arbace_core__init_A_const_440 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[789]); A_arbace_core__init_A_const_441 = A_arbace_core__init_A_const_pool.A[790]; A_arbace_core__init_A_const_442 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[791]); A_arbace_core__init_A_const_443 = A_arbace_core__init_A_const_pool.A[792]; A_arbace_core__init_A_const_444 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[793]); A_arbace_core__init_A_const_445 = A_arbace_core__init_A_const_pool.A[794]; A_arbace_core__init_A_const_446 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[795]); A_arbace_core__init_A_const_447 = A_arbace_core__init_A_const_pool.A[796] }

func A_arbace_core__init_A_clinit_p33() { A_arbace_core__init_A_const_448 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[797]); A_arbace_core__init_A_const_449 = A_arbace_core__init_A_const_pool.A[798]; A_arbace_core__init_A_const_450 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[799]); A_arbace_core__init_A_const_451 = A_arbace_core__init_A_const_pool.A[800]; A_arbace_core__init_A_const_452 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[801]); A_arbace_core__init_A_const_453 = A_arbace_core__init_A_const_pool.A[802]; A_arbace_core__init_A_const_454 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[803]); A_arbace_core__init_A_const_455 = A_arbace_core__init_A_const_pool.A[804]; A_arbace_core__init_A_const_456 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[805]); A_arbace_core__init_A_const_457 = A_arbace_core__init_A_const_pool.A[806]; A_arbace_core__init_A_const_458 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[807]); A_arbace_core__init_A_const_459 = A_arbace_core__init_A_const_pool.A[808]; A_arbace_core__init_A_const_460 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[809]) }

func A_arbace_core__init_A_clinit_p34() { A_arbace_core__init_A_const_461 = A_arbace_core__init_A_const_pool.A[810]; A_arbace_core__init_A_const_462 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[811]); A_arbace_core__init_A_const_463 = A_arbace_core__init_A_const_pool.A[812]; A_arbace_core__init_A_const_464 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[813]); A_arbace_core__init_A_const_465 = A_arbace_core__init_A_const_pool.A[814]; A_arbace_core__init_A_const_466 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[815]); A_arbace_core__init_A_const_467 = A_arbace_core__init_A_const_pool.A[816]; A_arbace_core__init_A_const_468 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[817]); A_arbace_core__init_A_const_469 = A_arbace_core__init_A_const_pool.A[818]; A_arbace_core__init_A_const_470 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[819]); A_arbace_core__init_A_const_471 = A_arbace_core__init_A_const_pool.A[820]; A_arbace_core__init_A_const_472 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[821]); A_arbace_core__init_A_const_473 = A_arbace_core__init_A_const_pool.A[822] }

func A_arbace_core__init_A_clinit_p35() { A_arbace_core__init_A_const_474 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[823]); A_arbace_core__init_A_const_475 = A_arbace_core__init_A_const_pool.A[824]; A_arbace_core__init_A_const_476 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[825]); A_arbace_core__init_A_const_477 = A_arbace_core__init_A_const_pool.A[826]; A_arbace_core__init_A_const_478 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[827]); A_arbace_core__init_A_const_479 = A_arbace_core__init_A_const_pool.A[828]; A_arbace_core__init_A_const_480 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[829]); A_arbace_core__init_A_const_481 = A_arbace_core__init_A_const_pool.A[830]; A_arbace_core__init_A_const_482 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[831]); A_arbace_core__init_A_const_483 = A_arbace_core__init_A_const_pool.A[832]; A_arbace_core__init_A_const_484 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[833]); A_arbace_core__init_A_const_485 = A_arbace_core__init_A_const_pool.A[834]; A_arbace_core__init_A_const_486 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[835]) }

func A_arbace_core__init_A_clinit_p36() { A_arbace_core__init_A_const_487 = A_arbace_core__init_A_const_pool.A[836]; A_arbace_core__init_A_const_488 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[837]); A_arbace_core__init_A_const_489 = A_arbace_core__init_A_const_pool.A[838]; A_arbace_core__init_A_const_490 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[839]); A_arbace_core__init_A_const_491 = A_arbace_core__init_A_const_pool.A[840]; A_arbace_core__init_A_const_492 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[841]); A_arbace_core__init_A_const_493 = A_arbace_core__init_A_const_pool.A[842]; A_arbace_core__init_A_const_494 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[843]); A_arbace_core__init_A_const_495 = A_arbace_core__init_A_const_pool.A[844]; A_arbace_core__init_A_const_496 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[845]); A_arbace_core__init_A_const_497 = A_arbace_core__init_A_const_pool.A[846]; A_arbace_core__init_A_const_498 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[847]); A_arbace_core__init_A_const_499 = A_arbace_core__init_A_const_pool.A[848] }

func A_arbace_core__init_A_clinit_p37() { A_arbace_core__init_A_const_500 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[849]); A_arbace_core__init_A_const_501 = A_arbace_core__init_A_const_pool.A[850]; A_arbace_core__init_A_const_502 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[851]); A_arbace_core__init_A_const_503 = A_arbace_core__init_A_const_pool.A[852]; A_arbace_core__init_A_const_504 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[853]); A_arbace_core__init_A_const_505 = A_arbace_core__init_A_const_pool.A[854]; A_arbace_core__init_A_const_506 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[855]); A_arbace_core__init_A_const_507 = A_arbace_core__init_A_const_pool.A[856]; A_arbace_core__init_A_const_508 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[857]); A_arbace_core__init_A_const_509 = A_arbace_core__init_A_const_pool.A[858]; A_arbace_core__init_A_const_510 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[859]); A_arbace_core__init_A_const_511 = A_arbace_core__init_A_const_pool.A[860]; A_arbace_core__init_A_const_512 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[861]) }

func A_arbace_core__init_A_clinit_p38() { A_arbace_core__init_A_const_513 = A_arbace_core__init_A_const_pool.A[862]; A_arbace_core__init_A_const_514 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[863]); A_arbace_core__init_A_const_515 = A_arbace_core__init_A_const_pool.A[864]; A_arbace_core__init_A_const_516 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[865]); A_arbace_core__init_A_const_517 = A_arbace_core__init_A_const_pool.A[866]; A_arbace_core__init_A_const_518 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[867]); A_arbace_core__init_A_const_519 = A_arbace_core__init_A_const_pool.A[868]; A_arbace_core__init_A_const_520 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[869]); A_arbace_core__init_A_const_521 = A_arbace_core__init_A_const_pool.A[870]; A_arbace_core__init_A_const_522 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[871]); A_arbace_core__init_A_const_523 = A_arbace_core__init_A_const_pool.A[872]; A_arbace_core__init_A_const_524 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[873]); A_arbace_core__init_A_const_525 = A_arbace_core__init_A_const_pool.A[874] }

func A_arbace_core__init_A_clinit_p39() { A_arbace_core__init_A_const_526 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[875]); A_arbace_core__init_A_const_527 = A_arbace_core__init_A_const_pool.A[876]; A_arbace_core__init_A_const_528 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[877]); A_arbace_core__init_A_const_529 = A_arbace_core__init_A_const_pool.A[878]; A_arbace_core__init_A_const_530 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[879]); A_arbace_core__init_A_const_531 = A_arbace_core__init_A_const_pool.A[880]; A_arbace_core__init_A_const_532 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[881]); A_arbace_core__init_A_const_533 = A_arbace_core__init_A_const_pool.A[882]; A_arbace_core__init_A_const_534 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[883]); A_arbace_core__init_A_const_535 = A_arbace_core__init_A_const_pool.A[884]; A_arbace_core__init_A_const_536 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[885]); A_arbace_core__init_A_const_537 = A_arbace_core__init_A_const_pool.A[886]; A_arbace_core__init_A_const_538 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[887]) }

func A_arbace_core__init_A_clinit_p40() { A_arbace_core__init_A_const_539 = A_arbace_core__init_A_const_pool.A[888]; A_arbace_core__init_A_const_540 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[889]); A_arbace_core__init_A_const_541 = A_arbace_core__init_A_const_pool.A[890]; A_arbace_core__init_A_const_542 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[891]); A_arbace_core__init_A_const_543 = A_arbace_core__init_A_const_pool.A[892]; A_arbace_core__init_A_const_544 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[893]); A_arbace_core__init_A_const_545 = A_arbace_core__init_A_const_pool.A[894]; A_arbace_core__init_A_const_546 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[895]); A_arbace_core__init_A_const_547 = A_arbace_core__init_A_const_pool.A[896]; A_arbace_core__init_A_const_548 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[897]); A_arbace_core__init_A_const_549 = A_arbace_core__init_A_const_pool.A[898]; A_arbace_core__init_A_const_550 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[899]); A_arbace_core__init_A_const_551 = A_arbace_core__init_A_const_pool.A[900] }

func A_arbace_core__init_A_clinit_p41() { A_arbace_core__init_A_const_552 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[901]); A_arbace_core__init_A_const_553 = A_arbace_core__init_A_const_pool.A[902]; A_arbace_core__init_A_const_554 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[903]); A_arbace_core__init_A_const_555 = A_arbace_core__init_A_const_pool.A[904]; A_arbace_core__init_A_const_556 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[905]); A_arbace_core__init_A_const_557 = A_arbace_core__init_A_const_pool.A[906]; A_arbace_core__init_A_const_558 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[907]); A_arbace_core__init_A_const_559 = A_arbace_core__init_A_const_pool.A[908]; A_arbace_core__init_A_const_560 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[909]); A_arbace_core__init_A_const_561 = A_arbace_core__init_A_const_pool.A[910]; A_arbace_core__init_A_const_562 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[911]); A_arbace_core__init_A_const_563 = A_arbace_core__init_A_const_pool.A[912]; A_arbace_core__init_A_const_564 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[913]) }

func A_arbace_core__init_A_clinit_p42() { A_arbace_core__init_A_const_565 = A_arbace_core__init_A_const_pool.A[914]; A_arbace_core__init_A_const_566 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[915]); A_arbace_core__init_A_const_567 = A_arbace_core__init_A_const_pool.A[916]; A_arbace_core__init_A_const_568 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[917]); A_arbace_core__init_A_const_569 = A_arbace_core__init_A_const_pool.A[918]; A_arbace_core__init_A_const_570 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[919]); A_arbace_core__init_A_const_571 = A_arbace_core__init_A_const_pool.A[920]; A_arbace_core__init_A_const_572 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[921]); A_arbace_core__init_A_const_573 = A_arbace_core__init_A_const_pool.A[922]; A_arbace_core__init_A_const_574 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[923]); A_arbace_core__init_A_const_575 = A_arbace_core__init_A_const_pool.A[924]; A_arbace_core__init_A_const_576 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[925]); A_arbace_core__init_A_const_577 = A_arbace_core__init_A_const_pool.A[926] }

func A_arbace_core__init_A_clinit_p43() { A_arbace_core__init_A_const_578 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[927]); A_arbace_core__init_A_const_579 = A_arbace_core__init_A_const_pool.A[928]; A_arbace_core__init_A_const_580 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[929]); A_arbace_core__init_A_const_581 = A_arbace_core__init_A_const_pool.A[930]; A_arbace_core__init_A_const_582 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[931]); A_arbace_core__init_A_const_583 = A_arbace_core__init_A_const_pool.A[932]; A_arbace_core__init_A_const_584 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[933]); A_arbace_core__init_A_const_585 = A_arbace_core__init_A_const_pool.A[934]; A_arbace_core__init_A_const_586 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[935]); A_arbace_core__init_A_const_587 = A_arbace_core__init_A_const_pool.A[936]; A_arbace_core__init_A_const_588 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[937]); A_arbace_core__init_A_const_589 = A_arbace_core__init_A_const_pool.A[938]; A_arbace_core__init_A_const_590 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[939]) }

func A_arbace_core__init_A_clinit_p44() { A_arbace_core__init_A_const_591 = A_arbace_core__init_A_const_pool.A[940]; A_arbace_core__init_A_const_592 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[941]); A_arbace_core__init_A_const_593 = A_arbace_core__init_A_const_pool.A[942]; A_arbace_core__init_A_const_594 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[943]); A_arbace_core__init_A_const_595 = A_arbace_core__init_A_const_pool.A[944]; A_arbace_core__init_A_const_596 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[945]); A_arbace_core__init_A_const_597 = A_arbace_core__init_A_const_pool.A[946]; A_arbace_core__init_A_const_598 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[947]); A_arbace_core__init_A_const_599 = A_arbace_core__init_A_const_pool.A[948]; A_arbace_core__init_A_const_600 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[949]); A_arbace_core__init_A_const_601 = A_arbace_core__init_A_const_pool.A[950]; A_arbace_core__init_A_const_602 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[951]); A_arbace_core__init_A_const_603 = A_arbace_core__init_A_const_pool.A[952] }

func A_arbace_core__init_A_clinit_p45() { A_arbace_core__init_A_const_604 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[953]); A_arbace_core__init_A_const_605 = A_arbace_core__init_A_const_pool.A[954]; A_arbace_core__init_A_const_606 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[955]); A_arbace_core__init_A_const_607 = A_arbace_core__init_A_const_pool.A[956]; A_arbace_core__init_A_const_608 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[957]); A_arbace_core__init_A_const_609 = A_arbace_core__init_A_const_pool.A[958]; A_arbace_core__init_A_const_610 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[959]); A_arbace_core__init_A_const_611 = A_arbace_core__init_A_const_pool.A[960]; A_arbace_core__init_A_const_612 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[961]); A_arbace_core__init_A_const_613 = A_arbace_core__init_A_const_pool.A[962]; A_arbace_core__init_A_const_614 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[963]); A_arbace_core__init_A_const_615 = A_arbace_core__init_A_const_pool.A[964]; A_arbace_core__init_A_const_616 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[965]) }

func A_arbace_core__init_A_clinit_p46() { A_arbace_core__init_A_const_617 = A_arbace_core__init_A_const_pool.A[966]; A_arbace_core__init_A_const_618 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[967]); A_arbace_core__init_A_const_619 = A_arbace_core__init_A_const_pool.A[968]; A_arbace_core__init_A_const_620 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[969]); A_arbace_core__init_A_const_621 = A_arbace_core__init_A_const_pool.A[970]; A_arbace_core__init_A_const_622 = A_arbace_core__init_A_const_pool.A[971]; A_arbace_core__init_A_const_623 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[972]); A_arbace_core__init_A_const_624 = A_arbace_core__init_A_const_pool.A[973]; A_arbace_core__init_A_const_625 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[974]); A_arbace_core__init_A_const_626 = A_arbace_core__init_A_const_pool.A[975]; A_arbace_core__init_A_const_627 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[976]); A_arbace_core__init_A_const_628 = A_arbace_core__init_A_const_pool.A[977]; A_arbace_core__init_A_const_629 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[978]); A_arbace_core__init_A_const_630 = A_arbace_core__init_A_const_pool.A[979] }

func A_arbace_core__init_A_clinit_p47() { A_arbace_core__init_A_const_631 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[980]); A_arbace_core__init_A_const_632 = A_arbace_core__init_A_const_pool.A[981]; A_arbace_core__init_A_const_633 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[982]); A_arbace_core__init_A_const_634 = A_arbace_core__init_A_const_pool.A[983]; A_arbace_core__init_A_const_635 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[984]); A_arbace_core__init_A_const_636 = A_arbace_core__init_A_const_pool.A[985]; A_arbace_core__init_A_const_637 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[986]); A_arbace_core__init_A_const_638 = A_arbace_core__init_A_const_pool.A[987]; A_arbace_core__init_A_const_639 = A_arbace_core__init_A_const_pool.A[988]; A_arbace_core__init_A_const_640 = A_arbace_core__init_A_const_pool.A[989]; A_arbace_core__init_A_const_641 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[990]); A_arbace_core__init_A_const_642 = A_arbace_core__init_A_const_pool.A[991]; A_arbace_core__init_A_const_643 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[992]); A_arbace_core__init_A_const_644 = A_arbace_core__init_A_const_pool.A[993] }

func A_arbace_core__init_A_clinit_p48() { A_arbace_core__init_A_const_645 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[994]); A_arbace_core__init_A_const_646 = A_arbace_core__init_A_const_pool.A[995]; A_arbace_core__init_A_const_647 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[996]); A_arbace_core__init_A_const_648 = A_arbace_core__init_A_const_pool.A[997]; A_arbace_core__init_A_const_649 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[998]); A_arbace_core__init_A_const_650 = A_arbace_core__init_A_const_pool.A[999]; A_arbace_core__init_A_const_651 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1000]); A_arbace_core__init_A_const_652 = A_arbace_core__init_A_const_pool.A[1001]; A_arbace_core__init_A_const_653 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1002]); A_arbace_core__init_A_const_654 = A_arbace_core__init_A_const_pool.A[1003]; A_arbace_core__init_A_const_655 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1004]); A_arbace_core__init_A_const_656 = A_arbace_core__init_A_const_pool.A[1005]; A_arbace_core__init_A_const_657 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1006]) }

func A_arbace_core__init_A_clinit_p49() { A_arbace_core__init_A_const_658 = A_arbace_core__init_A_const_pool.A[1007]; A_arbace_core__init_A_const_659 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1008]); A_arbace_core__init_A_const_660 = A_arbace_core__init_A_const_pool.A[1009]; A_arbace_core__init_A_const_661 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1010]); A_arbace_core__init_A_const_662 = A_arbace_core__init_A_const_pool.A[1011]; A_arbace_core__init_A_const_663 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1012]); A_arbace_core__init_A_const_664 = A_arbace_core__init_A_const_pool.A[1013]; A_arbace_core__init_A_const_665 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1014]); A_arbace_core__init_A_const_666 = A_arbace_core__init_A_const_pool.A[1015]; A_arbace_core__init_A_const_667 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1016]); A_arbace_core__init_A_const_668 = A_arbace_core__init_A_const_pool.A[1017]; A_arbace_core__init_A_const_669 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1018]); A_arbace_core__init_A_const_670 = A_arbace_core__init_A_const_pool.A[1019] }

func A_arbace_core__init_A_clinit_p50() { A_arbace_core__init_A_const_671 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1020]); A_arbace_core__init_A_const_672 = A_arbace_core__init_A_const_pool.A[1021]; A_arbace_core__init_A_const_673 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1022]); A_arbace_core__init_A_const_674 = A_arbace_core__init_A_const_pool.A[1023]; A_arbace_core__init_A_const_675 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1024]); A_arbace_core__init_A_const_676 = A_arbace_core__init_A_const_pool.A[1025]; A_arbace_core__init_A_const_677 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1026]); A_arbace_core__init_A_const_678 = A_arbace_core__init_A_const_pool.A[1027]; A_arbace_core__init_A_const_679 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1028]); A_arbace_core__init_A_const_680 = A_arbace_core__init_A_const_pool.A[1029]; A_arbace_core__init_A_const_681 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1030]); A_arbace_core__init_A_const_682 = A_arbace_core__init_A_const_pool.A[1031]; A_arbace_core__init_A_const_683 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1032]) }

func A_arbace_core__init_A_clinit_p51() { A_arbace_core__init_A_const_684 = A_arbace_core__init_A_const_pool.A[1033]; A_arbace_core__init_A_const_685 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1034]); A_arbace_core__init_A_const_686 = A_arbace_core__init_A_const_pool.A[1035]; A_arbace_core__init_A_const_687 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1036]); A_arbace_core__init_A_const_688 = A_arbace_core__init_A_const_pool.A[1037]; A_arbace_core__init_A_const_689 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1038]); A_arbace_core__init_A_const_690 = A_arbace_core__init_A_const_pool.A[1039]; A_arbace_core__init_A_const_691 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1040]); A_arbace_core__init_A_const_692 = A_arbace_core__init_A_const_pool.A[1041]; A_arbace_core__init_A_const_693 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1042]); A_arbace_core__init_A_const_694 = A_arbace_core__init_A_const_pool.A[1043]; A_arbace_core__init_A_const_695 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1044]); A_arbace_core__init_A_const_696 = A_arbace_core__init_A_const_pool.A[1045] }

func A_arbace_core__init_A_clinit_p52() { A_arbace_core__init_A_const_697 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1046]); A_arbace_core__init_A_const_698 = A_arbace_core__init_A_const_pool.A[1047]; A_arbace_core__init_A_const_699 = A_arbace_core__init_A_const_pool.A[1048]; A_arbace_core__init_A_const_700 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1049]); A_arbace_core__init_A_const_701 = A_arbace_core__init_A_const_pool.A[1050]; A_arbace_core__init_A_const_702 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1051]); A_arbace_core__init_A_const_703 = A_arbace_core__init_A_const_pool.A[1052]; A_arbace_core__init_A_const_704 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1053]); A_arbace_core__init_A_const_705 = A_arbace_core__init_A_const_pool.A[1054]; A_arbace_core__init_A_const_706 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1055]); A_arbace_core__init_A_const_707 = A_arbace_core__init_A_const_pool.A[1056]; A_arbace_core__init_A_const_708 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1057]); A_arbace_core__init_A_const_709 = A_arbace_core__init_A_const_pool.A[1058] }

func A_arbace_core__init_A_clinit_p53() { A_arbace_core__init_A_const_710 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1059]); A_arbace_core__init_A_const_711 = A_arbace_core__init_A_const_pool.A[1060]; A_arbace_core__init_A_const_712 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1061]); A_arbace_core__init_A_const_713 = A_arbace_core__init_A_const_pool.A[1062]; A_arbace_core__init_A_const_714 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1063]); A_arbace_core__init_A_const_715 = A_arbace_core__init_A_const_pool.A[1064]; A_arbace_core__init_A_const_716 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1065]); A_arbace_core__init_A_const_717 = A_arbace_core__init_A_const_pool.A[1066]; A_arbace_core__init_A_const_718 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1067]); A_arbace_core__init_A_const_719 = A_arbace_core__init_A_const_pool.A[1068]; A_arbace_core__init_A_const_720 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1069]); A_arbace_core__init_A_const_721 = A_arbace_core__init_A_const_pool.A[1070]; A_arbace_core__init_A_const_722 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1071]) }

func A_arbace_core__init_A_clinit_p54() { A_arbace_core__init_A_const_723 = A_arbace_core__init_A_const_pool.A[1072]; A_arbace_core__init_A_const_724 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1073]); A_arbace_core__init_A_const_725 = A_arbace_core__init_A_const_pool.A[1074]; A_arbace_core__init_A_const_726 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1075]); A_arbace_core__init_A_const_727 = A_arbace_core__init_A_const_pool.A[1076]; A_arbace_core__init_A_const_728 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1077]); A_arbace_core__init_A_const_729 = A_arbace_core__init_A_const_pool.A[1078]; A_arbace_core__init_A_const_730 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1079]); A_arbace_core__init_A_const_731 = A_arbace_core__init_A_const_pool.A[1080]; A_arbace_core__init_A_const_732 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1081]); A_arbace_core__init_A_const_733 = A_arbace_core__init_A_const_pool.A[1082]; A_arbace_core__init_A_const_734 = jrt.Class_Cast(A_arbace_core__init_A_const_pool.A[1083]); A_arbace_core__init_A_const_735 = A_arbace_core__init_A_const_pool.A[1084] }

func A_arbace_core__init_A_clinit_p55() { A_arbace_core__init_A_const_736 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1085]); A_arbace_core__init_A_const_737 = A_arbace_core__init_A_const_pool.A[1086]; A_arbace_core__init_A_const_738 = A_arbace_core__init_A_const_pool.A[1087]; A_arbace_core__init_A_const_739 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1088]); A_arbace_core__init_A_const_740 = A_arbace_core__init_A_const_pool.A[1089]; A_arbace_core__init_A_const_741 = A_arbace_core__init_A_const_pool.A[1090]; A_arbace_core__init_A_const_742 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1091]); A_arbace_core__init_A_const_743 = A_arbace_core__init_A_const_pool.A[1092]; A_arbace_core__init_A_const_744 = A_arbace_core__init_A_const_pool.A[1093]; A_arbace_core__init_A_const_745 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1094]); A_arbace_core__init_A_const_746 = A_arbace_core__init_A_const_pool.A[1095]; A_arbace_core__init_A_const_747 = A_arbace_core__init_A_const_pool.A[1096]; A_arbace_core__init_A_const_748 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1097]); A_arbace_core__init_A_const_749 = A_arbace_core__init_A_const_pool.A[1098] }

func A_arbace_core__init_A_clinit_p56() { A_arbace_core__init_A_const_750 = A_arbace_core__init_A_const_pool.A[1099]; A_arbace_core__init_A_const_751 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1100]); A_arbace_core__init_A_const_752 = A_arbace_core__init_A_const_pool.A[1101]; A_arbace_core__init_A_const_753 = A_arbace_core__init_A_const_pool.A[1102]; A_arbace_core__init_A_const_754 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1103]); A_arbace_core__init_A_const_755 = A_arbace_core__init_A_const_pool.A[1104]; A_arbace_core__init_A_const_756 = A_arbace_core__init_A_const_pool.A[1105]; A_arbace_core__init_A_const_757 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1106]); A_arbace_core__init_A_const_758 = A_arbace_core__init_A_const_pool.A[1107]; A_arbace_core__init_A_const_759 = A_arbace_core__init_A_const_pool.A[1108]; A_arbace_core__init_A_const_760 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1109]); A_arbace_core__init_A_const_761 = A_arbace_core__init_A_const_pool.A[1110]; A_arbace_core__init_A_const_762 = A_arbace_core__init_A_const_pool.A[1111]; A_arbace_core__init_A_const_763 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1112]) }

func A_arbace_core__init_A_clinit_p57() { A_arbace_core__init_A_const_764 = A_arbace_core__init_A_const_pool.A[1113]; A_arbace_core__init_A_const_765 = A_arbace_core__init_A_const_pool.A[1114]; A_arbace_core__init_A_const_766 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1115]); A_arbace_core__init_A_const_767 = A_arbace_core__init_A_const_pool.A[1116]; A_arbace_core__init_A_const_768 = A_arbace_core__init_A_const_pool.A[1117]; A_arbace_core__init_A_const_769 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1118]); A_arbace_core__init_A_const_770 = A_arbace_core__init_A_const_pool.A[1119]; A_arbace_core__init_A_const_771 = A_arbace_core__init_A_const_pool.A[1120]; A_arbace_core__init_A_const_772 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1121]); A_arbace_core__init_A_const_773 = A_arbace_core__init_A_const_pool.A[1122]; A_arbace_core__init_A_const_774 = A_arbace_core__init_A_const_pool.A[1123]; A_arbace_core__init_A_const_775 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1124]); A_arbace_core__init_A_const_776 = A_arbace_core__init_A_const_pool.A[1125]; A_arbace_core__init_A_const_777 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1126]) }

func A_arbace_core__init_A_clinit_p58() { A_arbace_core__init_A_const_778 = A_arbace_core__init_A_const_pool.A[1127]; A_arbace_core__init_A_const_779 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1128]); A_arbace_core__init_A_const_780 = A_arbace_core__init_A_const_pool.A[1129]; A_arbace_core__init_A_const_781 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1130]); A_arbace_core__init_A_const_782 = A_arbace_core__init_A_const_pool.A[1131]; A_arbace_core__init_A_const_783 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1132]); A_arbace_core__init_A_const_784 = A_arbace_core__init_A_const_pool.A[1133]; A_arbace_core__init_A_const_785 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1134]); A_arbace_core__init_A_const_786 = A_arbace_core__init_A_const_pool.A[1135]; A_arbace_core__init_A_const_787 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1136]); A_arbace_core__init_A_const_788 = A_arbace_core__init_A_const_pool.A[1137]; A_arbace_core__init_A_const_789 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1138]); A_arbace_core__init_A_const_790 = A_arbace_core__init_A_const_pool.A[1139] }

func A_arbace_core__init_A_clinit_p59() { A_arbace_core__init_A_const_791 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1140]); A_arbace_core__init_A_const_792 = A_arbace_core__init_A_const_pool.A[1141]; A_arbace_core__init_A_const_793 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1142]); A_arbace_core__init_A_const_794 = A_arbace_core__init_A_const_pool.A[1143]; A_arbace_core__init_A_const_795 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1144]); A_arbace_core__init_A_const_796 = A_arbace_core__init_A_const_pool.A[1145]; A_arbace_core__init_A_const_797 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1146]); A_arbace_core__init_A_const_798 = A_arbace_core__init_A_const_pool.A[1147]; A_arbace_core__init_A_const_799 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1148]); A_arbace_core__init_A_const_800 = A_arbace_core__init_A_const_pool.A[1149]; A_arbace_core__init_A_const_801 = lang.Keyword_Cast(A_arbace_core__init_A_const_pool.A[1150]); A_arbace_core__init_A_const_802 = A_arbace_core__init_A_const_pool.A[1151]; A_arbace_core__init_A_const_803 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1152]) }

func A_arbace_core__init_A_clinit_p60() { A_arbace_core__init_A_const_804 = A_arbace_core__init_A_const_pool.A[1153]; A_arbace_core__init_A_const_805 = A_arbace_core__init_A_const_pool.A[1154]; A_arbace_core__init_A_const_806 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1155]); A_arbace_core__init_A_const_807 = A_arbace_core__init_A_const_pool.A[1156]; A_arbace_core__init_A_const_808 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1157]); A_arbace_core__init_A_const_809 = A_arbace_core__init_A_const_pool.A[1158]; A_arbace_core__init_A_const_810 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1159]); A_arbace_core__init_A_const_811 = A_arbace_core__init_A_const_pool.A[1160]; A_arbace_core__init_A_const_812 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1161]); A_arbace_core__init_A_const_813 = A_arbace_core__init_A_const_pool.A[1162]; A_arbace_core__init_A_const_814 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1163]); A_arbace_core__init_A_const_815 = A_arbace_core__init_A_const_pool.A[1164]; A_arbace_core__init_A_const_816 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1165]); A_arbace_core__init_A_const_817 = A_arbace_core__init_A_const_pool.A[1166] }

func A_arbace_core__init_A_clinit_p61() { A_arbace_core__init_A_const_818 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1167]); A_arbace_core__init_A_const_819 = A_arbace_core__init_A_const_pool.A[1168]; A_arbace_core__init_A_const_820 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1169]); A_arbace_core__init_A_const_821 = A_arbace_core__init_A_const_pool.A[1170]; A_arbace_core__init_A_const_822 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1171]); A_arbace_core__init_A_const_823 = A_arbace_core__init_A_const_pool.A[1172]; A_arbace_core__init_A_const_824 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1173]); A_arbace_core__init_A_const_825 = A_arbace_core__init_A_const_pool.A[1174]; A_arbace_core__init_A_const_826 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1175]); A_arbace_core__init_A_const_827 = A_arbace_core__init_A_const_pool.A[1176]; A_arbace_core__init_A_const_828 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1177]); A_arbace_core__init_A_const_829 = A_arbace_core__init_A_const_pool.A[1178]; A_arbace_core__init_A_const_830 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1179]) }

func A_arbace_core__init_A_clinit_p62() { A_arbace_core__init_A_const_831 = A_arbace_core__init_A_const_pool.A[1180]; A_arbace_core__init_A_const_832 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1181]); A_arbace_core__init_A_const_833 = A_arbace_core__init_A_const_pool.A[1182]; A_arbace_core__init_A_const_834 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1183]); A_arbace_core__init_A_const_835 = A_arbace_core__init_A_const_pool.A[1184]; A_arbace_core__init_A_const_836 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1185]); A_arbace_core__init_A_const_837 = A_arbace_core__init_A_const_pool.A[1186]; A_arbace_core__init_A_const_838 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1187]); A_arbace_core__init_A_const_839 = A_arbace_core__init_A_const_pool.A[1188]; A_arbace_core__init_A_const_840 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1189]); A_arbace_core__init_A_const_841 = A_arbace_core__init_A_const_pool.A[1190]; A_arbace_core__init_A_const_842 = A_arbace_core__init_A_const_pool.A[1191]; A_arbace_core__init_A_const_843 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1192]); A_arbace_core__init_A_const_844 = A_arbace_core__init_A_const_pool.A[1193] }

func A_arbace_core__init_A_clinit_p63() { A_arbace_core__init_A_const_845 = A_arbace_core__init_A_const_pool.A[1194]; A_arbace_core__init_A_const_846 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1195]); A_arbace_core__init_A_const_847 = A_arbace_core__init_A_const_pool.A[1196]; A_arbace_core__init_A_const_848 = A_arbace_core__init_A_const_pool.A[1197]; A_arbace_core__init_A_const_849 = A_arbace_core__init_A_const_pool.A[1198]; A_arbace_core__init_A_const_850 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1199]); A_arbace_core__init_A_const_851 = A_arbace_core__init_A_const_pool.A[1200]; A_arbace_core__init_A_const_852 = A_arbace_core__init_A_const_pool.A[1201]; A_arbace_core__init_A_const_853 = A_arbace_core__init_A_const_pool.A[1202]; A_arbace_core__init_A_const_854 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1203]); A_arbace_core__init_A_const_855 = A_arbace_core__init_A_const_pool.A[1204]; A_arbace_core__init_A_const_856 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1205]); A_arbace_core__init_A_const_857 = A_arbace_core__init_A_const_pool.A[1206]; A_arbace_core__init_A_const_858 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1207]) }

func A_arbace_core__init_A_clinit_p64() { A_arbace_core__init_A_const_859 = A_arbace_core__init_A_const_pool.A[1208]; A_arbace_core__init_A_const_860 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1209]); A_arbace_core__init_A_const_861 = A_arbace_core__init_A_const_pool.A[1210]; A_arbace_core__init_A_const_862 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1211]); A_arbace_core__init_A_const_863 = A_arbace_core__init_A_const_pool.A[1212]; A_arbace_core__init_A_const_864 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1213]); A_arbace_core__init_A_const_865 = A_arbace_core__init_A_const_pool.A[1214]; A_arbace_core__init_A_const_866 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1215]); A_arbace_core__init_A_const_867 = A_arbace_core__init_A_const_pool.A[1216]; A_arbace_core__init_A_const_868 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1217]); A_arbace_core__init_A_const_869 = A_arbace_core__init_A_const_pool.A[1218]; A_arbace_core__init_A_const_870 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1219]); A_arbace_core__init_A_const_871 = A_arbace_core__init_A_const_pool.A[1220] }

func A_arbace_core__init_A_clinit_p65() { A_arbace_core__init_A_const_872 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1221]); A_arbace_core__init_A_const_873 = A_arbace_core__init_A_const_pool.A[1222]; A_arbace_core__init_A_const_874 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1223]); A_arbace_core__init_A_const_875 = A_arbace_core__init_A_const_pool.A[1224]; A_arbace_core__init_A_const_876 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1225]); A_arbace_core__init_A_const_877 = A_arbace_core__init_A_const_pool.A[1226]; A_arbace_core__init_A_const_878 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1227]); A_arbace_core__init_A_const_879 = A_arbace_core__init_A_const_pool.A[1228]; A_arbace_core__init_A_const_880 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1229]); A_arbace_core__init_A_const_881 = A_arbace_core__init_A_const_pool.A[1230]; A_arbace_core__init_A_const_882 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1231]); A_arbace_core__init_A_const_883 = A_arbace_core__init_A_const_pool.A[1232]; A_arbace_core__init_A_const_884 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1233]) }

func A_arbace_core__init_A_clinit_p66() { A_arbace_core__init_A_const_885 = A_arbace_core__init_A_const_pool.A[1234]; A_arbace_core__init_A_const_886 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1235]); A_arbace_core__init_A_const_887 = A_arbace_core__init_A_const_pool.A[1236]; A_arbace_core__init_A_const_888 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1237]); A_arbace_core__init_A_const_889 = A_arbace_core__init_A_const_pool.A[1238]; A_arbace_core__init_A_const_890 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1239]); A_arbace_core__init_A_const_891 = A_arbace_core__init_A_const_pool.A[1240]; A_arbace_core__init_A_const_892 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1241]); A_arbace_core__init_A_const_893 = A_arbace_core__init_A_const_pool.A[1242]; A_arbace_core__init_A_const_894 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1243]); A_arbace_core__init_A_const_895 = A_arbace_core__init_A_const_pool.A[1244]; A_arbace_core__init_A_const_896 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1245]); A_arbace_core__init_A_const_897 = A_arbace_core__init_A_const_pool.A[1246] }

func A_arbace_core__init_A_clinit_p67() { A_arbace_core__init_A_const_898 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1247]); A_arbace_core__init_A_const_899 = A_arbace_core__init_A_const_pool.A[1248]; A_arbace_core__init_A_const_900 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1249]); A_arbace_core__init_A_const_901 = A_arbace_core__init_A_const_pool.A[1250]; A_arbace_core__init_A_const_902 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1251]); A_arbace_core__init_A_const_903 = A_arbace_core__init_A_const_pool.A[1252]; A_arbace_core__init_A_const_904 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1253]); A_arbace_core__init_A_const_905 = A_arbace_core__init_A_const_pool.A[1254]; A_arbace_core__init_A_const_906 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1255]); A_arbace_core__init_A_const_907 = A_arbace_core__init_A_const_pool.A[1256]; A_arbace_core__init_A_const_908 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1257]); A_arbace_core__init_A_const_909 = A_arbace_core__init_A_const_pool.A[1258]; A_arbace_core__init_A_const_910 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1259]) }

func A_arbace_core__init_A_clinit_p68() { A_arbace_core__init_A_const_911 = A_arbace_core__init_A_const_pool.A[1260]; A_arbace_core__init_A_const_912 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1261]); A_arbace_core__init_A_const_913 = A_arbace_core__init_A_const_pool.A[1262]; A_arbace_core__init_A_const_914 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1263]); A_arbace_core__init_A_const_915 = A_arbace_core__init_A_const_pool.A[1264]; A_arbace_core__init_A_const_916 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1265]); A_arbace_core__init_A_const_917 = A_arbace_core__init_A_const_pool.A[1266]; A_arbace_core__init_A_const_918 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1267]); A_arbace_core__init_A_const_919 = A_arbace_core__init_A_const_pool.A[1268]; A_arbace_core__init_A_const_920 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1269]); A_arbace_core__init_A_const_921 = A_arbace_core__init_A_const_pool.A[1270]; A_arbace_core__init_A_const_922 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1271]); A_arbace_core__init_A_const_923 = A_arbace_core__init_A_const_pool.A[1272] }

func A_arbace_core__init_A_clinit_p69() { A_arbace_core__init_A_const_924 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1273]); A_arbace_core__init_A_const_925 = A_arbace_core__init_A_const_pool.A[1274]; A_arbace_core__init_A_const_926 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1275]); A_arbace_core__init_A_const_927 = A_arbace_core__init_A_const_pool.A[1276]; A_arbace_core__init_A_const_928 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1277]); A_arbace_core__init_A_const_929 = A_arbace_core__init_A_const_pool.A[1278]; A_arbace_core__init_A_const_930 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1279]); A_arbace_core__init_A_const_931 = A_arbace_core__init_A_const_pool.A[1280]; A_arbace_core__init_A_const_932 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1281]); A_arbace_core__init_A_const_933 = A_arbace_core__init_A_const_pool.A[1282]; A_arbace_core__init_A_const_934 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1283]); A_arbace_core__init_A_const_935 = A_arbace_core__init_A_const_pool.A[1284]; A_arbace_core__init_A_const_936 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1285]) }

func A_arbace_core__init_A_clinit_p70() { A_arbace_core__init_A_const_937 = A_arbace_core__init_A_const_pool.A[1286]; A_arbace_core__init_A_const_938 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1287]); A_arbace_core__init_A_const_939 = A_arbace_core__init_A_const_pool.A[1288]; A_arbace_core__init_A_const_940 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1289]); A_arbace_core__init_A_const_941 = A_arbace_core__init_A_const_pool.A[1290]; A_arbace_core__init_A_const_942 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1291]); A_arbace_core__init_A_const_943 = A_arbace_core__init_A_const_pool.A[1292]; A_arbace_core__init_A_const_944 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1293]); A_arbace_core__init_A_const_945 = A_arbace_core__init_A_const_pool.A[1294]; A_arbace_core__init_A_const_946 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1295]); A_arbace_core__init_A_const_947 = A_arbace_core__init_A_const_pool.A[1296]; A_arbace_core__init_A_const_948 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1297]); A_arbace_core__init_A_const_949 = A_arbace_core__init_A_const_pool.A[1298] }

func A_arbace_core__init_A_clinit_p71() { A_arbace_core__init_A_const_950 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1299]); A_arbace_core__init_A_const_951 = A_arbace_core__init_A_const_pool.A[1300]; A_arbace_core__init_A_const_952 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1301]); A_arbace_core__init_A_const_953 = A_arbace_core__init_A_const_pool.A[1302]; A_arbace_core__init_A_const_954 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1303]); A_arbace_core__init_A_const_955 = A_arbace_core__init_A_const_pool.A[1304]; A_arbace_core__init_A_const_956 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1305]); A_arbace_core__init_A_const_957 = A_arbace_core__init_A_const_pool.A[1306]; A_arbace_core__init_A_const_958 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1307]); A_arbace_core__init_A_const_959 = A_arbace_core__init_A_const_pool.A[1308]; A_arbace_core__init_A_const_960 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1309]); A_arbace_core__init_A_const_961 = A_arbace_core__init_A_const_pool.A[1310]; A_arbace_core__init_A_const_962 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1311]) }

func A_arbace_core__init_A_clinit_p72() { A_arbace_core__init_A_const_963 = A_arbace_core__init_A_const_pool.A[1312]; A_arbace_core__init_A_const_964 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1313]); A_arbace_core__init_A_const_965 = A_arbace_core__init_A_const_pool.A[1314]; A_arbace_core__init_A_const_966 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1315]); A_arbace_core__init_A_const_967 = A_arbace_core__init_A_const_pool.A[1316]; A_arbace_core__init_A_const_968 = A_arbace_core__init_A_const_pool.A[1317]; A_arbace_core__init_A_const_969 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1318]); A_arbace_core__init_A_const_970 = A_arbace_core__init_A_const_pool.A[1319]; A_arbace_core__init_A_const_971 = A_arbace_core__init_A_const_pool.A[1320]; A_arbace_core__init_A_const_972 = A_arbace_core__init_A_const_pool.A[1321]; A_arbace_core__init_A_const_973 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1322]); A_arbace_core__init_A_const_974 = A_arbace_core__init_A_const_pool.A[1323]; A_arbace_core__init_A_const_975 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1324]); A_arbace_core__init_A_const_976 = A_arbace_core__init_A_const_pool.A[1325] }

func A_arbace_core__init_A_clinit_p73() { A_arbace_core__init_A_const_977 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1326]); A_arbace_core__init_A_const_978 = A_arbace_core__init_A_const_pool.A[1327]; A_arbace_core__init_A_const_979 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1328]); A_arbace_core__init_A_const_980 = A_arbace_core__init_A_const_pool.A[1329]; A_arbace_core__init_A_const_981 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1330]); A_arbace_core__init_A_const_982 = A_arbace_core__init_A_const_pool.A[1331]; A_arbace_core__init_A_const_983 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1332]); A_arbace_core__init_A_const_984 = A_arbace_core__init_A_const_pool.A[1333]; A_arbace_core__init_A_const_985 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1334]); A_arbace_core__init_A_const_986 = A_arbace_core__init_A_const_pool.A[1335]; A_arbace_core__init_A_const_987 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1336]); A_arbace_core__init_A_const_988 = A_arbace_core__init_A_const_pool.A[1337]; A_arbace_core__init_A_const_989 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1338]) }

func A_arbace_core__init_A_clinit_p74() { A_arbace_core__init_A_const_990 = A_arbace_core__init_A_const_pool.A[1339]; A_arbace_core__init_A_const_991 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1340]); A_arbace_core__init_A_const_992 = A_arbace_core__init_A_const_pool.A[1341]; A_arbace_core__init_A_const_993 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1342]); A_arbace_core__init_A_const_994 = A_arbace_core__init_A_const_pool.A[1343]; A_arbace_core__init_A_const_995 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1344]); A_arbace_core__init_A_const_996 = A_arbace_core__init_A_const_pool.A[1345]; A_arbace_core__init_A_const_997 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1346]); A_arbace_core__init_A_const_998 = A_arbace_core__init_A_const_pool.A[1347]; A_arbace_core__init_A_const_999 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1348]); A_arbace_core__init_A_const_1000 = A_arbace_core__init_A_const_pool.A[1349]; A_arbace_core__init_A_const_1001 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1350]); A_arbace_core__init_A_const_1002 = A_arbace_core__init_A_const_pool.A[1351] }

func A_arbace_core__init_A_clinit_p75() { A_arbace_core__init_A_const_1003 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1352]); A_arbace_core__init_A_const_1004 = A_arbace_core__init_A_const_pool.A[1353]; A_arbace_core__init_A_const_1005 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1354]); A_arbace_core__init_A_const_1006 = A_arbace_core__init_A_const_pool.A[1355]; A_arbace_core__init_A_const_1007 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1356]); A_arbace_core__init_A_const_1008 = A_arbace_core__init_A_const_pool.A[1357]; A_arbace_core__init_A_const_1009 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1358]); A_arbace_core__init_A_const_1010 = A_arbace_core__init_A_const_pool.A[1359]; A_arbace_core__init_A_const_1011 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1360]); A_arbace_core__init_A_const_1012 = A_arbace_core__init_A_const_pool.A[1361]; A_arbace_core__init_A_const_1013 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1362]); A_arbace_core__init_A_const_1014 = A_arbace_core__init_A_const_pool.A[1363]; A_arbace_core__init_A_const_1015 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1364]) }

func A_arbace_core__init_A_clinit_p76() { A_arbace_core__init_A_const_1016 = A_arbace_core__init_A_const_pool.A[1365]; A_arbace_core__init_A_const_1017 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1366]); A_arbace_core__init_A_const_1018 = A_arbace_core__init_A_const_pool.A[1367]; A_arbace_core__init_A_const_1019 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1368]); A_arbace_core__init_A_const_1020 = A_arbace_core__init_A_const_pool.A[1369]; A_arbace_core__init_A_const_1021 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1370]); A_arbace_core__init_A_const_1022 = A_arbace_core__init_A_const_pool.A[1371]; A_arbace_core__init_A_const_1023 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1372]); A_arbace_core__init_A_const_1024 = A_arbace_core__init_A_const_pool.A[1373]; A_arbace_core__init_A_const_1025 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1374]); A_arbace_core__init_A_const_1026 = A_arbace_core__init_A_const_pool.A[1375]; A_arbace_core__init_A_const_1027 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1376]); A_arbace_core__init_A_const_1028 = A_arbace_core__init_A_const_pool.A[1377] }

func A_arbace_core__init_A_clinit_p77() { A_arbace_core__init_A_const_1029 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1378]); A_arbace_core__init_A_const_1030 = A_arbace_core__init_A_const_pool.A[1379]; A_arbace_core__init_A_const_1031 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1380]); A_arbace_core__init_A_const_1032 = A_arbace_core__init_A_const_pool.A[1381]; A_arbace_core__init_A_const_1033 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1382]); A_arbace_core__init_A_const_1034 = A_arbace_core__init_A_const_pool.A[1383]; A_arbace_core__init_A_const_1035 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1384]); A_arbace_core__init_A_const_1036 = A_arbace_core__init_A_const_pool.A[1385]; A_arbace_core__init_A_const_1037 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1386]); A_arbace_core__init_A_const_1038 = A_arbace_core__init_A_const_pool.A[1387]; A_arbace_core__init_A_const_1039 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1388]); A_arbace_core__init_A_const_1040 = A_arbace_core__init_A_const_pool.A[1389]; A_arbace_core__init_A_const_1041 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1390]) }

func A_arbace_core__init_A_clinit_p78() { A_arbace_core__init_A_const_1042 = A_arbace_core__init_A_const_pool.A[1391]; A_arbace_core__init_A_const_1043 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1392]); A_arbace_core__init_A_const_1044 = A_arbace_core__init_A_const_pool.A[1393]; A_arbace_core__init_A_const_1045 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1394]); A_arbace_core__init_A_const_1046 = A_arbace_core__init_A_const_pool.A[1395]; A_arbace_core__init_A_const_1047 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1396]); A_arbace_core__init_A_const_1048 = A_arbace_core__init_A_const_pool.A[1397]; A_arbace_core__init_A_const_1049 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1398]); A_arbace_core__init_A_const_1050 = A_arbace_core__init_A_const_pool.A[1399]; A_arbace_core__init_A_const_1051 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1400]); A_arbace_core__init_A_const_1052 = A_arbace_core__init_A_const_pool.A[1401]; A_arbace_core__init_A_const_1053 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1402]); A_arbace_core__init_A_const_1054 = A_arbace_core__init_A_const_pool.A[1403] }

func A_arbace_core__init_A_clinit_p79() { A_arbace_core__init_A_const_1055 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1404]); A_arbace_core__init_A_const_1056 = A_arbace_core__init_A_const_pool.A[1405]; A_arbace_core__init_A_const_1057 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1406]); A_arbace_core__init_A_const_1058 = A_arbace_core__init_A_const_pool.A[1407]; A_arbace_core__init_A_const_1059 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1408]); A_arbace_core__init_A_const_1060 = A_arbace_core__init_A_const_pool.A[1409]; A_arbace_core__init_A_const_1061 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1410]); A_arbace_core__init_A_const_1062 = A_arbace_core__init_A_const_pool.A[1411]; A_arbace_core__init_A_const_1063 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1412]); A_arbace_core__init_A_const_1064 = A_arbace_core__init_A_const_pool.A[1413]; A_arbace_core__init_A_const_1065 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1414]); A_arbace_core__init_A_const_1066 = A_arbace_core__init_A_const_pool.A[1415]; A_arbace_core__init_A_const_1067 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1416]) }

func A_arbace_core__init_A_clinit_p80() { A_arbace_core__init_A_const_1068 = A_arbace_core__init_A_const_pool.A[1417]; A_arbace_core__init_A_const_1069 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1418]); A_arbace_core__init_A_const_1070 = A_arbace_core__init_A_const_pool.A[1419]; A_arbace_core__init_A_const_1071 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1420]); A_arbace_core__init_A_const_1072 = A_arbace_core__init_A_const_pool.A[1421]; A_arbace_core__init_A_const_1073 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1422]); A_arbace_core__init_A_const_1074 = A_arbace_core__init_A_const_pool.A[1423]; A_arbace_core__init_A_const_1075 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1424]); A_arbace_core__init_A_const_1076 = A_arbace_core__init_A_const_pool.A[1425]; A_arbace_core__init_A_const_1077 = A_arbace_core__init_A_const_pool.A[1426]; A_arbace_core__init_A_const_1078 = A_arbace_core__init_A_const_pool.A[1427]; A_arbace_core__init_A_const_1079 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1428]); A_arbace_core__init_A_const_1080 = A_arbace_core__init_A_const_pool.A[1429]; A_arbace_core__init_A_const_1081 = A_arbace_core__init_A_const_pool.A[1430] }

func A_arbace_core__init_A_clinit_p81() { A_arbace_core__init_A_const_1082 = A_arbace_core__init_A_const_pool.A[1431]; A_arbace_core__init_A_const_1083 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1432]); A_arbace_core__init_A_const_1084 = A_arbace_core__init_A_const_pool.A[1433]; A_arbace_core__init_A_const_1085 = A_arbace_core__init_A_const_pool.A[1434]; A_arbace_core__init_A_const_1086 = A_arbace_core__init_A_const_pool.A[1435]; A_arbace_core__init_A_const_1087 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1436]); A_arbace_core__init_A_const_1088 = A_arbace_core__init_A_const_pool.A[1437]; A_arbace_core__init_A_const_1089 = A_arbace_core__init_A_const_pool.A[1438]; A_arbace_core__init_A_const_1090 = A_arbace_core__init_A_const_pool.A[1439]; A_arbace_core__init_A_const_1091 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1440]); A_arbace_core__init_A_const_1092 = A_arbace_core__init_A_const_pool.A[1441]; A_arbace_core__init_A_const_1093 = A_arbace_core__init_A_const_pool.A[1442]; A_arbace_core__init_A_const_1094 = A_arbace_core__init_A_const_pool.A[1443]; A_arbace_core__init_A_const_1095 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1444]) }

func A_arbace_core__init_A_clinit_p82() { A_arbace_core__init_A_const_1096 = A_arbace_core__init_A_const_pool.A[1445]; A_arbace_core__init_A_const_1097 = A_arbace_core__init_A_const_pool.A[1446]; A_arbace_core__init_A_const_1098 = A_arbace_core__init_A_const_pool.A[1447]; A_arbace_core__init_A_const_1099 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1448]); A_arbace_core__init_A_const_1100 = A_arbace_core__init_A_const_pool.A[1449]; A_arbace_core__init_A_const_1101 = A_arbace_core__init_A_const_pool.A[1450]; A_arbace_core__init_A_const_1102 = A_arbace_core__init_A_const_pool.A[1451]; A_arbace_core__init_A_const_1103 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1452]); A_arbace_core__init_A_const_1104 = A_arbace_core__init_A_const_pool.A[1453]; A_arbace_core__init_A_const_1105 = A_arbace_core__init_A_const_pool.A[1454]; A_arbace_core__init_A_const_1106 = A_arbace_core__init_A_const_pool.A[1455]; A_arbace_core__init_A_const_1107 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1456]); A_arbace_core__init_A_const_1108 = A_arbace_core__init_A_const_pool.A[1457]; A_arbace_core__init_A_const_1109 = A_arbace_core__init_A_const_pool.A[1458]; A_arbace_core__init_A_const_1110 = A_arbace_core__init_A_const_pool.A[1459] }

func A_arbace_core__init_A_clinit_p83() { A_arbace_core__init_A_const_1111 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1460]); A_arbace_core__init_A_const_1112 = A_arbace_core__init_A_const_pool.A[1461]; A_arbace_core__init_A_const_1113 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1462]); A_arbace_core__init_A_const_1114 = A_arbace_core__init_A_const_pool.A[1463]; A_arbace_core__init_A_const_1115 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1464]); A_arbace_core__init_A_const_1116 = A_arbace_core__init_A_const_pool.A[1465]; A_arbace_core__init_A_const_1117 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1466]); A_arbace_core__init_A_const_1118 = A_arbace_core__init_A_const_pool.A[1467]; A_arbace_core__init_A_const_1119 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1468]); A_arbace_core__init_A_const_1120 = A_arbace_core__init_A_const_pool.A[1469]; A_arbace_core__init_A_const_1121 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1470]); A_arbace_core__init_A_const_1122 = A_arbace_core__init_A_const_pool.A[1471]; A_arbace_core__init_A_const_1123 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1472]) }

func A_arbace_core__init_A_clinit_p84() { A_arbace_core__init_A_const_1124 = A_arbace_core__init_A_const_pool.A[1473]; A_arbace_core__init_A_const_1125 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1474]); A_arbace_core__init_A_const_1126 = A_arbace_core__init_A_const_pool.A[1475]; A_arbace_core__init_A_const_1127 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1476]); A_arbace_core__init_A_const_1128 = A_arbace_core__init_A_const_pool.A[1477]; A_arbace_core__init_A_const_1129 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1478]); A_arbace_core__init_A_const_1130 = A_arbace_core__init_A_const_pool.A[1479]; A_arbace_core__init_A_const_1131 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1480]); A_arbace_core__init_A_const_1132 = A_arbace_core__init_A_const_pool.A[1481]; A_arbace_core__init_A_const_1133 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1482]); A_arbace_core__init_A_const_1134 = A_arbace_core__init_A_const_pool.A[1483]; A_arbace_core__init_A_const_1135 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1484]); A_arbace_core__init_A_const_1136 = A_arbace_core__init_A_const_pool.A[1485] }

func A_arbace_core__init_A_clinit_p85() { A_arbace_core__init_A_const_1137 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1486]); A_arbace_core__init_A_const_1138 = A_arbace_core__init_A_const_pool.A[1487]; A_arbace_core__init_A_const_1139 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1488]); A_arbace_core__init_A_const_1140 = A_arbace_core__init_A_const_pool.A[1489]; A_arbace_core__init_A_const_1141 = A_arbace_core__init_A_const_pool.A[1490]; A_arbace_core__init_A_const_1142 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1491]); A_arbace_core__init_A_const_1143 = A_arbace_core__init_A_const_pool.A[1492]; A_arbace_core__init_A_const_1144 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1493]); A_arbace_core__init_A_const_1145 = A_arbace_core__init_A_const_pool.A[1494]; A_arbace_core__init_A_const_1146 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1495]); A_arbace_core__init_A_const_1147 = A_arbace_core__init_A_const_pool.A[1496]; A_arbace_core__init_A_const_1148 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1497]); A_arbace_core__init_A_const_1149 = A_arbace_core__init_A_const_pool.A[1498] }

func A_arbace_core__init_A_clinit_p86() { A_arbace_core__init_A_const_1150 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1499]); A_arbace_core__init_A_const_1151 = A_arbace_core__init_A_const_pool.A[1500]; A_arbace_core__init_A_const_1152 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1501]); A_arbace_core__init_A_const_1153 = A_arbace_core__init_A_const_pool.A[1502]; A_arbace_core__init_A_const_1154 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1503]); A_arbace_core__init_A_const_1155 = A_arbace_core__init_A_const_pool.A[1504]; A_arbace_core__init_A_const_1156 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1505]); A_arbace_core__init_A_const_1157 = A_arbace_core__init_A_const_pool.A[1506]; A_arbace_core__init_A_const_1158 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1507]); A_arbace_core__init_A_const_1159 = A_arbace_core__init_A_const_pool.A[1508]; A_arbace_core__init_A_const_1160 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1509]); A_arbace_core__init_A_const_1161 = A_arbace_core__init_A_const_pool.A[1510]; A_arbace_core__init_A_const_1162 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1511]) }

func A_arbace_core__init_A_clinit_p87() { A_arbace_core__init_A_const_1163 = A_arbace_core__init_A_const_pool.A[1512]; A_arbace_core__init_A_const_1164 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1513]); A_arbace_core__init_A_const_1165 = A_arbace_core__init_A_const_pool.A[1514]; A_arbace_core__init_A_const_1166 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1515]); A_arbace_core__init_A_const_1167 = A_arbace_core__init_A_const_pool.A[1516]; A_arbace_core__init_A_const_1168 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1517]); A_arbace_core__init_A_const_1169 = A_arbace_core__init_A_const_pool.A[1518]; A_arbace_core__init_A_const_1170 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1519]); A_arbace_core__init_A_const_1171 = A_arbace_core__init_A_const_pool.A[1520]; A_arbace_core__init_A_const_1172 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1521]); A_arbace_core__init_A_const_1173 = A_arbace_core__init_A_const_pool.A[1522]; A_arbace_core__init_A_const_1174 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1523]); A_arbace_core__init_A_const_1175 = A_arbace_core__init_A_const_pool.A[1524] }

func A_arbace_core__init_A_clinit_p88() { A_arbace_core__init_A_const_1176 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1525]); A_arbace_core__init_A_const_1177 = A_arbace_core__init_A_const_pool.A[1526]; A_arbace_core__init_A_const_1178 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1527]); A_arbace_core__init_A_const_1179 = A_arbace_core__init_A_const_pool.A[1528]; A_arbace_core__init_A_const_1180 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1529]); A_arbace_core__init_A_const_1181 = A_arbace_core__init_A_const_pool.A[1530]; A_arbace_core__init_A_const_1182 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1531]); A_arbace_core__init_A_const_1183 = A_arbace_core__init_A_const_pool.A[1532]; A_arbace_core__init_A_const_1184 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1533]); A_arbace_core__init_A_const_1185 = A_arbace_core__init_A_const_pool.A[1534]; A_arbace_core__init_A_const_1186 = A_arbace_core__init_A_const_pool.A[1535]; A_arbace_core__init_A_const_1187 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1536]); A_arbace_core__init_A_const_1188 = A_arbace_core__init_A_const_pool.A[1537]; A_arbace_core__init_A_const_1189 = A_arbace_core__init_A_const_pool.A[1538] }

func A_arbace_core__init_A_clinit_p89() { A_arbace_core__init_A_const_1190 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1539]); A_arbace_core__init_A_const_1191 = A_arbace_core__init_A_const_pool.A[1540]; A_arbace_core__init_A_const_1192 = A_arbace_core__init_A_const_pool.A[1541]; A_arbace_core__init_A_const_1193 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1542]); A_arbace_core__init_A_const_1194 = A_arbace_core__init_A_const_pool.A[1543]; A_arbace_core__init_A_const_1195 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1544]); A_arbace_core__init_A_const_1196 = A_arbace_core__init_A_const_pool.A[1545]; A_arbace_core__init_A_const_1197 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1546]); A_arbace_core__init_A_const_1198 = A_arbace_core__init_A_const_pool.A[1547]; A_arbace_core__init_A_const_1199 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1548]); A_arbace_core__init_A_const_1200 = A_arbace_core__init_A_const_pool.A[1549]; A_arbace_core__init_A_const_1201 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1550]); A_arbace_core__init_A_const_1202 = A_arbace_core__init_A_const_pool.A[1551] }

func A_arbace_core__init_A_clinit_p90() { A_arbace_core__init_A_const_1203 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1552]); A_arbace_core__init_A_const_1204 = A_arbace_core__init_A_const_pool.A[1553]; A_arbace_core__init_A_const_1205 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1554]); A_arbace_core__init_A_const_1206 = A_arbace_core__init_A_const_pool.A[1555]; A_arbace_core__init_A_const_1207 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1556]); A_arbace_core__init_A_const_1208 = A_arbace_core__init_A_const_pool.A[1557]; A_arbace_core__init_A_const_1209 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1558]); A_arbace_core__init_A_const_1210 = A_arbace_core__init_A_const_pool.A[1559]; A_arbace_core__init_A_const_1211 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1560]); A_arbace_core__init_A_const_1212 = A_arbace_core__init_A_const_pool.A[1561]; A_arbace_core__init_A_const_1213 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1562]); A_arbace_core__init_A_const_1214 = A_arbace_core__init_A_const_pool.A[1563]; A_arbace_core__init_A_const_1215 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1564]) }

func A_arbace_core__init_A_clinit_p91() { A_arbace_core__init_A_const_1216 = A_arbace_core__init_A_const_pool.A[1565]; A_arbace_core__init_A_const_1217 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1566]); A_arbace_core__init_A_const_1218 = A_arbace_core__init_A_const_pool.A[1567]; A_arbace_core__init_A_const_1219 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1568]); A_arbace_core__init_A_const_1220 = A_arbace_core__init_A_const_pool.A[1569]; A_arbace_core__init_A_const_1221 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1570]); A_arbace_core__init_A_const_1222 = A_arbace_core__init_A_const_pool.A[1571]; A_arbace_core__init_A_const_1223 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1572]); A_arbace_core__init_A_const_1224 = A_arbace_core__init_A_const_pool.A[1573]; A_arbace_core__init_A_const_1225 = A_arbace_core__init_A_const_pool.A[1574]; A_arbace_core__init_A_const_1226 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1575]); A_arbace_core__init_A_const_1227 = A_arbace_core__init_A_const_pool.A[1576]; A_arbace_core__init_A_const_1228 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1577]); A_arbace_core__init_A_const_1229 = A_arbace_core__init_A_const_pool.A[1578] }

func A_arbace_core__init_A_clinit_p92() { A_arbace_core__init_A_const_1230 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1579]); A_arbace_core__init_A_const_1231 = A_arbace_core__init_A_const_pool.A[1580]; A_arbace_core__init_A_const_1232 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1581]); A_arbace_core__init_A_const_1233 = A_arbace_core__init_A_const_pool.A[1582]; A_arbace_core__init_A_const_1234 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1583]); A_arbace_core__init_A_const_1235 = A_arbace_core__init_A_const_pool.A[1584]; A_arbace_core__init_A_const_1236 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1585]); A_arbace_core__init_A_const_1237 = A_arbace_core__init_A_const_pool.A[1586]; A_arbace_core__init_A_const_1238 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1587]); A_arbace_core__init_A_const_1239 = A_arbace_core__init_A_const_pool.A[1588]; A_arbace_core__init_A_const_1240 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1589]); A_arbace_core__init_A_const_1241 = A_arbace_core__init_A_const_pool.A[1590]; A_arbace_core__init_A_const_1242 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1591]) }

func A_arbace_core__init_A_clinit_p93() { A_arbace_core__init_A_const_1243 = A_arbace_core__init_A_const_pool.A[1592]; A_arbace_core__init_A_const_1244 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1593]); A_arbace_core__init_A_const_1245 = A_arbace_core__init_A_const_pool.A[1594]; A_arbace_core__init_A_const_1246 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1595]); A_arbace_core__init_A_const_1247 = A_arbace_core__init_A_const_pool.A[1596]; A_arbace_core__init_A_const_1248 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1597]); A_arbace_core__init_A_const_1249 = A_arbace_core__init_A_const_pool.A[1598]; A_arbace_core__init_A_const_1250 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1599]); A_arbace_core__init_A_const_1251 = A_arbace_core__init_A_const_pool.A[1600]; A_arbace_core__init_A_const_1252 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1601]); A_arbace_core__init_A_const_1253 = A_arbace_core__init_A_const_pool.A[1602]; A_arbace_core__init_A_const_1254 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1603]); A_arbace_core__init_A_const_1255 = A_arbace_core__init_A_const_pool.A[1604] }

func A_arbace_core__init_A_clinit_p94() { A_arbace_core__init_A_const_1256 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1605]); A_arbace_core__init_A_const_1257 = A_arbace_core__init_A_const_pool.A[1606]; A_arbace_core__init_A_const_1258 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1607]); A_arbace_core__init_A_const_1259 = A_arbace_core__init_A_const_pool.A[1608]; A_arbace_core__init_A_const_1260 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1609]); A_arbace_core__init_A_const_1261 = A_arbace_core__init_A_const_pool.A[1610]; A_arbace_core__init_A_const_1262 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1611]); A_arbace_core__init_A_const_1263 = A_arbace_core__init_A_const_pool.A[1612]; A_arbace_core__init_A_const_1264 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1613]); A_arbace_core__init_A_const_1265 = A_arbace_core__init_A_const_pool.A[1614]; A_arbace_core__init_A_const_1266 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1615]); A_arbace_core__init_A_const_1267 = A_arbace_core__init_A_const_pool.A[1616]; A_arbace_core__init_A_const_1268 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1617]) }

func A_arbace_core__init_A_clinit_p95() { A_arbace_core__init_A_const_1269 = A_arbace_core__init_A_const_pool.A[1618]; A_arbace_core__init_A_const_1270 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1619]); A_arbace_core__init_A_const_1271 = A_arbace_core__init_A_const_pool.A[1620]; A_arbace_core__init_A_const_1272 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1621]); A_arbace_core__init_A_const_1273 = A_arbace_core__init_A_const_pool.A[1622]; A_arbace_core__init_A_const_1274 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1623]); A_arbace_core__init_A_const_1275 = A_arbace_core__init_A_const_pool.A[1624]; A_arbace_core__init_A_const_1276 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1625]); A_arbace_core__init_A_const_1277 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1626]); A_arbace_core__init_A_const_1278 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1627]); A_arbace_core__init_A_const_1279 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1628]); A_arbace_core__init_A_const_1280 = A_arbace_core__init_A_const_pool.A[1629]; A_arbace_core__init_A_const_1281 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1630]) }

func A_arbace_core__init_A_clinit_p96() { A_arbace_core__init_A_const_1282 = A_arbace_core__init_A_const_pool.A[1631]; A_arbace_core__init_A_const_1283 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1632]); A_arbace_core__init_A_const_1284 = A_arbace_core__init_A_const_pool.A[1633]; A_arbace_core__init_A_const_1285 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1634]); A_arbace_core__init_A_const_1286 = A_arbace_core__init_A_const_pool.A[1635]; A_arbace_core__init_A_const_1287 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1636]); A_arbace_core__init_A_const_1288 = A_arbace_core__init_A_const_pool.A[1637]; A_arbace_core__init_A_const_1289 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1638]); A_arbace_core__init_A_const_1290 = A_arbace_core__init_A_const_pool.A[1639]; A_arbace_core__init_A_const_1291 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1640]); A_arbace_core__init_A_const_1292 = A_arbace_core__init_A_const_pool.A[1641]; A_arbace_core__init_A_const_1293 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1642]); A_arbace_core__init_A_const_1294 = A_arbace_core__init_A_const_pool.A[1643] }

func A_arbace_core__init_A_clinit_p97() { A_arbace_core__init_A_const_1295 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1644]); A_arbace_core__init_A_const_1296 = A_arbace_core__init_A_const_pool.A[1645]; A_arbace_core__init_A_const_1297 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1646]); A_arbace_core__init_A_const_1298 = A_arbace_core__init_A_const_pool.A[1647]; A_arbace_core__init_A_const_1299 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1648]); A_arbace_core__init_A_const_1300 = A_arbace_core__init_A_const_pool.A[1649]; A_arbace_core__init_A_const_1301 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1650]); A_arbace_core__init_A_const_1302 = A_arbace_core__init_A_const_pool.A[1651]; A_arbace_core__init_A_const_1303 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1652]); A_arbace_core__init_A_const_1304 = A_arbace_core__init_A_const_pool.A[1653]; A_arbace_core__init_A_const_1305 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1654]); A_arbace_core__init_A_const_1306 = A_arbace_core__init_A_const_pool.A[1655]; A_arbace_core__init_A_const_1307 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1656]) }

func A_arbace_core__init_A_clinit_p98() { A_arbace_core__init_A_const_1308 = A_arbace_core__init_A_const_pool.A[1657]; A_arbace_core__init_A_const_1309 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1658]); A_arbace_core__init_A_const_1310 = A_arbace_core__init_A_const_pool.A[1659]; A_arbace_core__init_A_const_1311 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1660]); A_arbace_core__init_A_const_1312 = A_arbace_core__init_A_const_pool.A[1661]; A_arbace_core__init_A_const_1313 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1662]); A_arbace_core__init_A_const_1314 = A_arbace_core__init_A_const_pool.A[1663]; A_arbace_core__init_A_const_1315 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1664]); A_arbace_core__init_A_const_1316 = A_arbace_core__init_A_const_pool.A[1665]; A_arbace_core__init_A_const_1317 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1666]); A_arbace_core__init_A_const_1318 = A_arbace_core__init_A_const_pool.A[1667]; A_arbace_core__init_A_const_1319 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1668]); A_arbace_core__init_A_const_1320 = A_arbace_core__init_A_const_pool.A[1669] }

func A_arbace_core__init_A_clinit_p99() { A_arbace_core__init_A_const_1321 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1670]); A_arbace_core__init_A_const_1322 = A_arbace_core__init_A_const_pool.A[1671]; A_arbace_core__init_A_const_1323 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1672]); A_arbace_core__init_A_const_1324 = A_arbace_core__init_A_const_pool.A[1673]; A_arbace_core__init_A_const_1325 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1674]); A_arbace_core__init_A_const_1326 = A_arbace_core__init_A_const_pool.A[1675]; A_arbace_core__init_A_const_1327 = A_arbace_core__init_A_const_pool.A[1676]; A_arbace_core__init_A_const_1328 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1677]); A_arbace_core__init_A_const_1329 = A_arbace_core__init_A_const_pool.A[1678]; A_arbace_core__init_A_const_1330 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1679]); A_arbace_core__init_A_const_1331 = A_arbace_core__init_A_const_pool.A[1680]; A_arbace_core__init_A_const_1332 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1681]); A_arbace_core__init_A_const_1333 = A_arbace_core__init_A_const_pool.A[1682] }

func A_arbace_core__init_A_clinit_p100() { A_arbace_core__init_A_const_1334 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1683]); A_arbace_core__init_A_const_1335 = A_arbace_core__init_A_const_pool.A[1684]; A_arbace_core__init_A_const_1336 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1685]); A_arbace_core__init_A_const_1337 = A_arbace_core__init_A_const_pool.A[1686]; A_arbace_core__init_A_const_1338 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1687]); A_arbace_core__init_A_const_1339 = A_arbace_core__init_A_const_pool.A[1688]; A_arbace_core__init_A_const_1340 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1689]); A_arbace_core__init_A_const_1341 = A_arbace_core__init_A_const_pool.A[1690]; A_arbace_core__init_A_const_1342 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1691]); A_arbace_core__init_A_const_1343 = A_arbace_core__init_A_const_pool.A[1692]; A_arbace_core__init_A_const_1344 = A_arbace_core__init_A_const_pool.A[1693]; A_arbace_core__init_A_const_1345 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1694]); A_arbace_core__init_A_const_1346 = A_arbace_core__init_A_const_pool.A[1695] }

func A_arbace_core__init_A_clinit_p101() { A_arbace_core__init_A_const_1347 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1696]); A_arbace_core__init_A_const_1348 = A_arbace_core__init_A_const_pool.A[1697]; A_arbace_core__init_A_const_1349 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1698]); A_arbace_core__init_A_const_1350 = A_arbace_core__init_A_const_pool.A[1699]; A_arbace_core__init_A_const_1351 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1700]); A_arbace_core__init_A_const_1352 = A_arbace_core__init_A_const_pool.A[1701]; A_arbace_core__init_A_const_1353 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1702]); A_arbace_core__init_A_const_1354 = A_arbace_core__init_A_const_pool.A[1703]; A_arbace_core__init_A_const_1355 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1704]); A_arbace_core__init_A_const_1356 = A_arbace_core__init_A_const_pool.A[1705]; A_arbace_core__init_A_const_1357 = A_arbace_core__init_A_const_pool.A[1706]; A_arbace_core__init_A_const_1358 = jrt.Class_Cast(A_arbace_core__init_A_const_pool.A[1707]); A_arbace_core__init_A_const_1359 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1708]) }

func A_arbace_core__init_A_clinit_p102() { A_arbace_core__init_A_const_1360 = A_arbace_core__init_A_const_pool.A[1709]; A_arbace_core__init_A_const_1361 = A_arbace_core__init_A_const_pool.A[1710]; A_arbace_core__init_A_const_1362 = lang.Keyword_Cast(A_arbace_core__init_A_const_pool.A[1711]); A_arbace_core__init_A_const_1363 = A_arbace_core__init_A_const_pool.A[1712]; A_arbace_core__init_A_const_1364 = lang.Keyword_Cast(A_arbace_core__init_A_const_pool.A[1713]); A_arbace_core__init_A_const_1365 = lang.Keyword_Cast(A_arbace_core__init_A_const_pool.A[1714]); A_arbace_core__init_A_const_1366 = A_arbace_core__init_A_const_pool.A[1715]; A_arbace_core__init_A_const_1367 = lang.Keyword_Cast(A_arbace_core__init_A_const_pool.A[1716]); A_arbace_core__init_A_const_1368 = A_arbace_core__init_A_const_pool.A[1717]; A_arbace_core__init_A_const_1369 = A_arbace_core__init_A_const_pool.A[1718]; A_arbace_core__init_A_const_1370 = lang.Keyword_Cast(A_arbace_core__init_A_const_pool.A[1719]); A_arbace_core__init_A_const_1371 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1720]); A_arbace_core__init_A_const_1372 = A_arbace_core__init_A_const_pool.A[1721] }

func A_arbace_core__init_A_clinit_p103() { A_arbace_core__init_A_const_1373 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1722]); A_arbace_core__init_A_const_1374 = jrt.Class_Cast(A_arbace_core__init_A_const_pool.A[1723]); A_arbace_core__init_A_const_1375 = lang.Keyword_Cast(A_arbace_core__init_A_const_pool.A[1724]); A_arbace_core__init_A_const_1376 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1725]); A_arbace_core__init_A_const_1377 = A_arbace_core__init_A_const_pool.A[1726]; A_arbace_core__init_A_const_1378 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1727]); A_arbace_core__init_A_const_1379 = A_arbace_core__init_A_const_pool.A[1728]; A_arbace_core__init_A_const_1380 = jrt.Class_Cast(A_arbace_core__init_A_const_pool.A[1729]); A_arbace_core__init_A_const_1381 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1730]); A_arbace_core__init_A_const_1382 = A_arbace_core__init_A_const_pool.A[1731]; A_arbace_core__init_A_const_1383 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1732]); A_arbace_core__init_A_const_1384 = A_arbace_core__init_A_const_pool.A[1733]; A_arbace_core__init_A_const_1385 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1734]) }

func A_arbace_core__init_A_clinit_p104() { A_arbace_core__init_A_const_1386 = A_arbace_core__init_A_const_pool.A[1735]; A_arbace_core__init_A_const_1387 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1736]); A_arbace_core__init_A_const_1388 = lang.Keyword_Cast(A_arbace_core__init_A_const_pool.A[1737]); A_arbace_core__init_A_const_1389 = jrt.Class_Cast(A_arbace_core__init_A_const_pool.A[1738]); A_arbace_core__init_A_const_1390 = jrt.Class_Cast(A_arbace_core__init_A_const_pool.A[1739]); A_arbace_core__init_A_const_1391 = A_arbace_core__init_A_const_pool.A[1740]; A_arbace_core__init_A_const_1392 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1741]); A_arbace_core__init_A_const_1393 = A_arbace_core__init_A_const_pool.A[1742]; A_arbace_core__init_A_const_1394 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1743]); A_arbace_core__init_A_const_1395 = A_arbace_core__init_A_const_pool.A[1744]; A_arbace_core__init_A_const_1396 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1745]); A_arbace_core__init_A_const_1397 = A_arbace_core__init_A_const_pool.A[1746]; A_arbace_core__init_A_const_1398 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1747]) }

func A_arbace_core__init_A_clinit_p105() { A_arbace_core__init_A_const_1399 = A_arbace_core__init_A_const_pool.A[1748]; A_arbace_core__init_A_const_1400 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1749]); A_arbace_core__init_A_const_1401 = A_arbace_core__init_A_const_pool.A[1750]; A_arbace_core__init_A_const_1402 = A_arbace_core__init_A_const_pool.A[1751]; A_arbace_core__init_A_const_1403 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1752]); A_arbace_core__init_A_const_1404 = A_arbace_core__init_A_const_pool.A[1753]; A_arbace_core__init_A_const_1405 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1754]); A_arbace_core__init_A_const_1406 = A_arbace_core__init_A_const_pool.A[1755]; A_arbace_core__init_A_const_1407 = A_arbace_core__init_A_const_pool.A[1756]; A_arbace_core__init_A_const_1408 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1757]); A_arbace_core__init_A_const_1409 = A_arbace_core__init_A_const_pool.A[1758]; A_arbace_core__init_A_const_1410 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1759]); A_arbace_core__init_A_const_1411 = A_arbace_core__init_A_const_pool.A[1760]; A_arbace_core__init_A_const_1412 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1761]) }

func A_arbace_core__init_A_clinit_p106() { A_arbace_core__init_A_const_1413 = A_arbace_core__init_A_const_pool.A[1762]; A_arbace_core__init_A_const_1414 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1763]); A_arbace_core__init_A_const_1415 = A_arbace_core__init_A_const_pool.A[1764]; A_arbace_core__init_A_const_1416 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1765]); A_arbace_core__init_A_const_1417 = A_arbace_core__init_A_const_pool.A[1766]; A_arbace_core__init_A_const_1418 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1767]); A_arbace_core__init_A_const_1419 = A_arbace_core__init_A_const_pool.A[1768]; A_arbace_core__init_A_const_1420 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1769]); A_arbace_core__init_A_const_1421 = A_arbace_core__init_A_const_pool.A[1770]; A_arbace_core__init_A_const_1422 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1771]); A_arbace_core__init_A_const_1423 = A_arbace_core__init_A_const_pool.A[1772]; A_arbace_core__init_A_const_1424 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1773]); A_arbace_core__init_A_const_1425 = A_arbace_core__init_A_const_pool.A[1774] }

func A_arbace_core__init_A_clinit_p107() { A_arbace_core__init_A_const_1426 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1775]); A_arbace_core__init_A_const_1427 = A_arbace_core__init_A_const_pool.A[1776]; A_arbace_core__init_A_const_1428 = lang.Keyword_Cast(A_arbace_core__init_A_const_pool.A[1777]); A_arbace_core__init_A_const_1429 = lang.Keyword_Cast(A_arbace_core__init_A_const_pool.A[1778]); A_arbace_core__init_A_const_1430 = lang.Keyword_Cast(A_arbace_core__init_A_const_pool.A[1779]); A_arbace_core__init_A_const_1431 = lang.Keyword_Cast(A_arbace_core__init_A_const_pool.A[1780]); A_arbace_core__init_A_const_1432 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1781]); A_arbace_core__init_A_const_1433 = lang.Keyword_Cast(A_arbace_core__init_A_const_pool.A[1782]); A_arbace_core__init_A_const_1434 = A_arbace_core__init_A_const_pool.A[1783]; A_arbace_core__init_A_const_1435 = A_arbace_core__init_A_const_pool.A[1784]; A_arbace_core__init_A_const_1436 = A_arbace_core__init_A_const_pool.A[1785]; A_arbace_core__init_A_const_1437 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1786]); A_arbace_core__init_A_const_1438 = A_arbace_core__init_A_const_pool.A[1787] }

func A_arbace_core__init_A_clinit_p108() { A_arbace_core__init_A_const_1439 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1788]); A_arbace_core__init_A_const_1440 = A_arbace_core__init_A_const_pool.A[1789]; A_arbace_core__init_A_const_1441 = A_arbace_core__init_A_const_pool.A[1790]; A_arbace_core__init_A_const_1442 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1791]); A_arbace_core__init_A_const_1443 = A_arbace_core__init_A_const_pool.A[1792]; A_arbace_core__init_A_const_1444 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1793]); A_arbace_core__init_A_const_1445 = A_arbace_core__init_A_const_pool.A[1794]; A_arbace_core__init_A_const_1446 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1795]); A_arbace_core__init_A_const_1447 = A_arbace_core__init_A_const_pool.A[1796]; A_arbace_core__init_A_const_1448 = A_arbace_core__init_A_const_pool.A[1797]; A_arbace_core__init_A_const_1449 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1798]); A_arbace_core__init_A_const_1450 = A_arbace_core__init_A_const_pool.A[1799]; A_arbace_core__init_A_const_1451 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1800]); A_arbace_core__init_A_const_1452 = A_arbace_core__init_A_const_pool.A[1801] }

func A_arbace_core__init_A_clinit_p109() { A_arbace_core__init_A_const_1453 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1802]); A_arbace_core__init_A_const_1454 = A_arbace_core__init_A_const_pool.A[1803]; A_arbace_core__init_A_const_1455 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1804]); A_arbace_core__init_A_const_1456 = A_arbace_core__init_A_const_pool.A[1805]; A_arbace_core__init_A_const_1457 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1806]); A_arbace_core__init_A_const_1458 = A_arbace_core__init_A_const_pool.A[1807]; A_arbace_core__init_A_const_1459 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1808]); A_arbace_core__init_A_const_1460 = A_arbace_core__init_A_const_pool.A[1809]; A_arbace_core__init_A_const_1461 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1810]); A_arbace_core__init_A_const_1462 = A_arbace_core__init_A_const_pool.A[1811]; A_arbace_core__init_A_const_1463 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1812]); A_arbace_core__init_A_const_1464 = A_arbace_core__init_A_const_pool.A[1813]; A_arbace_core__init_A_const_1465 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1814]) }

func A_arbace_core__init_A_clinit_p110() { A_arbace_core__init_A_const_1466 = A_arbace_core__init_A_const_pool.A[1815]; A_arbace_core__init_A_const_1467 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1816]); A_arbace_core__init_A_const_1468 = A_arbace_core__init_A_const_pool.A[1817]; A_arbace_core__init_A_const_1469 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1818]); A_arbace_core__init_A_const_1470 = A_arbace_core__init_A_const_pool.A[1819]; A_arbace_core__init_A_const_1471 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1820]); A_arbace_core__init_A_const_1472 = A_arbace_core__init_A_const_pool.A[1821]; A_arbace_core__init_A_const_1473 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1822]); A_arbace_core__init_A_const_1474 = A_arbace_core__init_A_const_pool.A[1823]; A_arbace_core__init_A_const_1475 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1824]); A_arbace_core__init_A_const_1476 = A_arbace_core__init_A_const_pool.A[1825]; A_arbace_core__init_A_const_1477 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1826]); A_arbace_core__init_A_const_1478 = A_arbace_core__init_A_const_pool.A[1827] }

func A_arbace_core__init_A_clinit_p111() { A_arbace_core__init_A_const_1479 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1828]); A_arbace_core__init_A_const_1480 = A_arbace_core__init_A_const_pool.A[1829]; A_arbace_core__init_A_const_1481 = A_arbace_core__init_A_const_pool.A[1830]; A_arbace_core__init_A_const_1482 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1831]); A_arbace_core__init_A_const_1483 = A_arbace_core__init_A_const_pool.A[1832]; A_arbace_core__init_A_const_1484 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1833]); A_arbace_core__init_A_const_1485 = A_arbace_core__init_A_const_pool.A[1834]; A_arbace_core__init_A_const_1486 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1835]); A_arbace_core__init_A_const_1487 = A_arbace_core__init_A_const_pool.A[1836]; A_arbace_core__init_A_const_1488 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1837]); A_arbace_core__init_A_const_1489 = A_arbace_core__init_A_const_pool.A[1838]; A_arbace_core__init_A_const_1490 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1839]); A_arbace_core__init_A_const_1491 = A_arbace_core__init_A_const_pool.A[1840] }

func A_arbace_core__init_A_clinit_p112() { A_arbace_core__init_A_const_1492 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1841]); A_arbace_core__init_A_const_1493 = A_arbace_core__init_A_const_pool.A[1842]; A_arbace_core__init_A_const_1494 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1843]); A_arbace_core__init_A_const_1495 = A_arbace_core__init_A_const_pool.A[1844]; A_arbace_core__init_A_const_1496 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1845]); A_arbace_core__init_A_const_1497 = A_arbace_core__init_A_const_pool.A[1846]; A_arbace_core__init_A_const_1498 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1847]); A_arbace_core__init_A_const_1499 = A_arbace_core__init_A_const_pool.A[1848]; A_arbace_core__init_A_const_1500 = A_arbace_core__init_A_const_pool.A[1849]; A_arbace_core__init_A_const_1501 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1850]); A_arbace_core__init_A_const_1502 = A_arbace_core__init_A_const_pool.A[1851]; A_arbace_core__init_A_const_1503 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1852]); A_arbace_core__init_A_const_1504 = A_arbace_core__init_A_const_pool.A[1853] }

func A_arbace_core__init_A_clinit_p113() { A_arbace_core__init_A_const_1505 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1854]); A_arbace_core__init_A_const_1506 = A_arbace_core__init_A_const_pool.A[1855]; A_arbace_core__init_A_const_1507 = jrt.Class_Cast(A_arbace_core__init_A_const_pool.A[1856]); A_arbace_core__init_A_const_1508 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1857]); A_arbace_core__init_A_const_1509 = A_arbace_core__init_A_const_pool.A[1858]; A_arbace_core__init_A_const_1510 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1859]); A_arbace_core__init_A_const_1511 = A_arbace_core__init_A_const_pool.A[1860]; A_arbace_core__init_A_const_1512 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1861]); A_arbace_core__init_A_const_1513 = A_arbace_core__init_A_const_pool.A[1862]; A_arbace_core__init_A_const_1514 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1863]); A_arbace_core__init_A_const_1515 = A_arbace_core__init_A_const_pool.A[1864]; A_arbace_core__init_A_const_1516 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1865]); A_arbace_core__init_A_const_1517 = A_arbace_core__init_A_const_pool.A[1866] }

func A_arbace_core__init_A_clinit_p114() { A_arbace_core__init_A_const_1518 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1867]); A_arbace_core__init_A_const_1519 = A_arbace_core__init_A_const_pool.A[1868]; A_arbace_core__init_A_const_1520 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1869]); A_arbace_core__init_A_const_1521 = A_arbace_core__init_A_const_pool.A[1870]; A_arbace_core__init_A_const_1522 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1871]); A_arbace_core__init_A_const_1523 = A_arbace_core__init_A_const_pool.A[1872]; A_arbace_core__init_A_const_1524 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1873]); A_arbace_core__init_A_const_1525 = A_arbace_core__init_A_const_pool.A[1874]; A_arbace_core__init_A_const_1526 = A_arbace_core__init_A_const_pool.A[1875]; A_arbace_core__init_A_const_1527 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1876]); A_arbace_core__init_A_const_1528 = A_arbace_core__init_A_const_pool.A[1877]; A_arbace_core__init_A_const_1529 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1878]); A_arbace_core__init_A_const_1530 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1879]) }

func A_arbace_core__init_A_clinit_p115() { A_arbace_core__init_A_const_1531 = A_arbace_core__init_A_const_pool.A[1880]; A_arbace_core__init_A_const_1532 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1881]); A_arbace_core__init_A_const_1533 = A_arbace_core__init_A_const_pool.A[1882]; A_arbace_core__init_A_const_1534 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1883]); A_arbace_core__init_A_const_1535 = A_arbace_core__init_A_const_pool.A[1884]; A_arbace_core__init_A_const_1536 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1885]); A_arbace_core__init_A_const_1537 = A_arbace_core__init_A_const_pool.A[1886]; A_arbace_core__init_A_const_1538 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1887]); A_arbace_core__init_A_const_1539 = A_arbace_core__init_A_const_pool.A[1888]; A_arbace_core__init_A_const_1540 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1889]); A_arbace_core__init_A_const_1541 = A_arbace_core__init_A_const_pool.A[1890]; A_arbace_core__init_A_const_1542 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1891]); A_arbace_core__init_A_const_1543 = A_arbace_core__init_A_const_pool.A[1892] }

func A_arbace_core__init_A_clinit_p116() { A_arbace_core__init_A_const_1544 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1893]); A_arbace_core__init_A_const_1545 = A_arbace_core__init_A_const_pool.A[1894]; A_arbace_core__init_A_const_1546 = A_arbace_core__init_A_const_pool.A[1895]; A_arbace_core__init_A_const_1547 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1896]); A_arbace_core__init_A_const_1548 = A_arbace_core__init_A_const_pool.A[1897]; A_arbace_core__init_A_const_1549 = A_arbace_core__init_A_const_pool.A[1898]; A_arbace_core__init_A_const_1550 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1899]); A_arbace_core__init_A_const_1551 = A_arbace_core__init_A_const_pool.A[1900]; A_arbace_core__init_A_const_1552 = A_arbace_core__init_A_const_pool.A[1901]; A_arbace_core__init_A_const_1553 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1902]); A_arbace_core__init_A_const_1554 = A_arbace_core__init_A_const_pool.A[1903]; A_arbace_core__init_A_const_1555 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1904]); A_arbace_core__init_A_const_1556 = A_arbace_core__init_A_const_pool.A[1905]; A_arbace_core__init_A_const_1557 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1906]) }

func A_arbace_core__init_A_clinit_p117() { A_arbace_core__init_A_const_1558 = A_arbace_core__init_A_const_pool.A[1907]; A_arbace_core__init_A_const_1559 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1908]); A_arbace_core__init_A_const_1560 = A_arbace_core__init_A_const_pool.A[1909]; A_arbace_core__init_A_const_1561 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1910]); A_arbace_core__init_A_const_1562 = A_arbace_core__init_A_const_pool.A[1911]; A_arbace_core__init_A_const_1563 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1912]); A_arbace_core__init_A_const_1564 = A_arbace_core__init_A_const_pool.A[1913]; A_arbace_core__init_A_const_1565 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1914]); A_arbace_core__init_A_const_1566 = A_arbace_core__init_A_const_pool.A[1915]; A_arbace_core__init_A_const_1567 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1916]); A_arbace_core__init_A_const_1568 = A_arbace_core__init_A_const_pool.A[1917]; A_arbace_core__init_A_const_1569 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1918]); A_arbace_core__init_A_const_1570 = A_arbace_core__init_A_const_pool.A[1919] }

func A_arbace_core__init_A_clinit_p118() { A_arbace_core__init_A_const_1571 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1920]); A_arbace_core__init_A_const_1572 = A_arbace_core__init_A_const_pool.A[1921]; A_arbace_core__init_A_const_1573 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1922]); A_arbace_core__init_A_const_1574 = A_arbace_core__init_A_const_pool.A[1923]; A_arbace_core__init_A_const_1575 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1924]); A_arbace_core__init_A_const_1576 = A_arbace_core__init_A_const_pool.A[1925]; A_arbace_core__init_A_const_1577 = A_arbace_core__init_A_const_pool.A[1926]; A_arbace_core__init_A_const_1578 = A_arbace_core__init_A_const_pool.A[1927]; A_arbace_core__init_A_const_1579 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1928]); A_arbace_core__init_A_const_1580 = A_arbace_core__init_A_const_pool.A[1929]; A_arbace_core__init_A_const_1581 = A_arbace_core__init_A_const_pool.A[1930]; A_arbace_core__init_A_const_1582 = A_arbace_core__init_A_const_pool.A[1931]; A_arbace_core__init_A_const_1583 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1932]); A_arbace_core__init_A_const_1584 = A_arbace_core__init_A_const_pool.A[1933] }

func A_arbace_core__init_A_clinit_p119() { A_arbace_core__init_A_const_1585 = lang.Var_Cast(A_arbace_core__init_A_const_pool.A[1934]); A_arbace_core__init_A_const_1586 = A_arbace_core__init_A_const_pool.A[1935] }

func A_arbace_core__init_A_New() *A_arbace_core__init_A { A_arbace_core__init_A_Init(); t := &A_arbace_core__init_A{}; t.Ctor(); return t }

func (t *A_arbace_core__init_A) Ctor() {}

func (t *A_arbace_core__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core__init_A) GetClass__Class() *jrt.Class { return A_arbace_core__init_A_class }

func (t *A_arbace_core__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core__init_A); return ok }

func A_arbace_core__init_A_Cast(x any) *A_arbace_core__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core__init_A_class)) }; return v }
