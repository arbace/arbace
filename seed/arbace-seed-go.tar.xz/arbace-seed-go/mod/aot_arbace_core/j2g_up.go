//line j2g_up.ae:1
package aot_arbace_core

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
func Up_A_arbace_core_ArrayChunk_A_IChunk(p *A_arbace_core_ArrayChunk_A) lang.IChunk { if p == nil { return nil }; return p }

func Up_A_arbace_core_Vec_reify__57000049_A_ListIterator(p *A_arbace_core_Vec_reify__57000049_A) jrt.ListIterator { if p == nil { return nil }; return p }

func Up_A_arbace_core_Vec_reify__57000051_A_Iterator(p *A_arbace_core_Vec_reify__57000051_A) jrt.Iterator { if p == nil { return nil }; return p }

func Up_A_arbace_core_Vec_A_IPersistentStack(p *A_arbace_core_Vec_A) lang.IPersistentStack { if p == nil { return nil }; return p }

func Up_A_arbace_core_Vec_A_IPersistentVector(p *A_arbace_core_Vec_A) lang.IPersistentVector { if p == nil { return nil }; return p }

func Up_A_arbace_core_VecSeq_A_ISeq(p *A_arbace_core_VecSeq_A) lang.ISeq { if p == nil { return nil }; return p }

func Up_APersistentVector_RSeq_ISeq(p *lang.APersistentVector_RSeq) lang.ISeq { if p == nil { return nil }; return p }

func Up_MapEntry_IMapEntry(p *lang.MapEntry) lang.IMapEntry { if p == nil { return nil }; return p }

func Up_PersistentArrayMap_IPersistentMap(p *lang.PersistentArrayMap) lang.IPersistentMap { if p == nil { return nil }; return p }

func Up_PersistentList_EmptyList_IPersistentCollection(p *lang.PersistentList_EmptyList) lang.IPersistentCollection { if p == nil { return nil }; return p }

func Up_Symbol_IObj(p *lang.Symbol) lang.IObj { if p == nil { return nil }; return p }

func Up_Double_Number(p *jrt.Double) jrt.Number_I { if p == nil { return nil }; return p }

func Up_Long_Number(p *jrt.Long) jrt.Number_I { if p == nil { return nil }; return p }
