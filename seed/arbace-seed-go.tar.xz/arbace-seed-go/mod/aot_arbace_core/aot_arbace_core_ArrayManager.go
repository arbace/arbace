//line aot_arbace_core_ArrayManager.ae:1
package aot_arbace_core

import "arbace/jrt"




type A_arbace_core_ArrayManager_A interface{ jrt.Object_I; Is_A_arbace_core_ArrayManager_A(); Array_I__O(p0 int32) any; Alength_O__I(p0 any) int32; Aclone_O__O(p0 any) any; Aget_O_I__O(p0 any, p1 int32) any; Aset_O_I_O__O(p0 any, p1 int32, p2 any) any }

func A_arbace_core_ArrayManager_A_InstanceOf(x any) bool { _, ok := x.(A_arbace_core_ArrayManager_A); if !ok && x != nil && jrt.IsDynamic(x) { d, dyn := x.(jrt.Dynamic); if dyn { ok = d.DynImplements(A_arbace_core_ArrayManager_A_class) } }; return ok }

func A_arbace_core_ArrayManager_A_Cast(x any) A_arbace_core_ArrayManager_A { if x == nil { return nil }; v, ok := x.(A_arbace_core_ArrayManager_A); if ok && jrt.IsDynamic(x) { d, dyn := x.(jrt.Dynamic); if dyn { ok = d.DynImplements(A_arbace_core_ArrayManager_A_class) } }; if !ok { panic(jrt.ClassCast(x, A_arbace_core_ArrayManager_A_class)) }; return v }
