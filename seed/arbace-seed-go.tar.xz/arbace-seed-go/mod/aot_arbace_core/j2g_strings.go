//line j2g_strings.ae:1
package aot_arbace_core

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn4,let*yn5,loop*yn3,fn*ys14,arbace.lang.RT4,metayn5,&formkn3,tagkn3,dockn8,arglistsyn5,quotekn6,inlineyn2,fnyn3,defys11,arbace.core2,fnkn6,rettagys16,arbace.lang.Util9,identicalyn4,&envyn2,doys11,arbace.core4,defnyn1,.yn8,setMacrokn4,linekn6,columnyn3,varyn2,ifys11,arbace.core4,condkn4,elseyn3,newyn19,arbace.lang.LazySeqkn4,onceyn17,arbace.lang.Delayys11,arbace.core3,notys11,arbace.core6,if-notyn16,arbace.lang.Utilys11,arbace.core9,identicalys11,arbace.core5,equivys11,arbace.core7,compareys11,arbace.core3,letyn23,and__1927000168__auto__ys11,arbace.core3,andyn22,or__1927000174__auto__ys11,arbace.core2,oryn19,arbace.lang.Numbersys11,arbace.core6,isZeroyn14,arbace.lang.RTys11,arbace.core5,countyn16,uncheckedIntCastyn7,intCastys11,arbace.core3,nthys11,arbace.core2,ltys11,arbace.core4,incPyn13,unchecked_incyn3,incys11,arbace.core3,lteys11,arbace.core2,gtys11,arbace.core3,gteys19,arbace.lang.Numbers3,absys11,arbace.core4,decPyn13,unchecked_decyn3,decys11,arbace.core17,unchecked_int_incys11,arbace.core13,unchecked_incys11,arbace.core17,unchecked_int_decys11,arbace.core13,unchecked_decys11,arbace.core20,unchecked_int_negateys11,arbace.core15,unchecked_minusys11,arbace.core17,unchecked_int_addys11,arbace.core13,unchecked_addys11,arbace.core22,unchecked_int_subtractys11,arbace.core22,unchecked_int_multiplyys11,arbace.core18,unchecked_multiplyys11,arbace.core20,unchecked_int_divideys11,arbace.core23,unchecked_int_remainderys11,arbace.core5,isPosys11,arbace.core5,isNegys11,arbace.core8,quotientys11,arbace.core9,remainderys11,arbace.core9,shiftLeftys11,arbace.core10,shiftRightys11,arbace.core18,unsignedShiftRightys11,arbace.core3,getys14,arbace.lang.RT3,reqys11,arbace.core11,booleanCastyn26,lockee__1927000360__auto__yn3,tryyn29,locklocal__1927000361__auto__yn13,monitor-enteryn7,finallyyn12,monitor-exityn2,..kn7,defaultkn9,hierarchyyn21,v__1927000386__auto__ys11,arbace.core8,when-notyn8,.hasRootys11,arbace.core9,instance?yn19,arbace.lang.MultiFnys11,arbace.core5,derefys11,arbace.core9,addMethodyn5,throwyn35,java.lang.IllegalArgumentException.ys11,arbace.core3,strys11,arbace.core5,firstyn4,*ns*ys11,arbace.core4,metays11,arbace.core11,assert-argsyn24,temp__1927000408__auto__ys11,arbace.core6,if-letyn24,temp__1927000414__auto__ys11,arbace.core4,whenyn24,temp__1927000420__auto__ys11,arbace.core4,nil?ys11,arbace.core7,if-someyn24,temp__1927000426__auto__ys11,arbace.core20,push-thread-bindingsys11,arbace.core8,hash-mapys11,arbace.core19,pop-thread-bindingsys11,arbace.core14,with-bindings*ys11,arbace.core9,bound-fn*kn4,metakn9,validatorkn13,error-handlerkn10,error-modekn8,continuekn4,failkn13,clear-actionskn11,max-historykn11,min-historyyn30,arbace.lang.LockingTransactionys11,arbace.core16,runInTransactionys30,arbace.lang.LockingTransaction9,isRunningyn31,java.lang.IllegalStateExceptionyn20,arbace.lang.Volatileyn6,.resetyn6,.derefyn21,n__1927000566__auto__ys14,arbace.lang.RT8,longCastys11,arbace.core4,loopys11,arbace.core1,<yn5,recurys11,arbace.core13,unchecked-inckn8,declaredys14,arbace.lang.RT9,isReducedkn3,letkn5,whilekn4,whenyn18,arbace.lang.IChunkys11,arbace.core4,nextys11,arbace.core3,seqyn4,.nthys11,arbace.core8,when-letys11,arbace.core12,chunked-seq?yn21,c__1927000678__auto__ys11,arbace.core11,chunk-firstys11,arbace.core10,chunk-restys11,arbace.core3,intyn21,n__1927000701__auto__ys11,arbace.core4,longys11,arbace.core7,import*kn4,typeys11,arbace.core3,numys11,arbace.core8,longCastyn18,uncheckedFloatCastyn9,floatCastys11,arbace.core10,doubleCastyn18,uncheckedShortCastyn9,shortCastyn17,uncheckedByteCastyn8,byteCastyn17,uncheckedCharCastyn8,charCastys11,arbace.core17,uncheckedByteCastys11,arbace.core18,uncheckedShortCastys11,arbace.core17,uncheckedCharCastys11,arbace.core16,uncheckedIntCastys11,arbace.core17,uncheckedLongCastys11,arbace.core18,uncheckedFloatCastys11,arbace.core19,uncheckedDoubleCastys11,arbace.core9,with-openyn5,closeyn25,start__1927000835__auto__yn16,java.lang.Systemys11,arbace.core8,nanoTimeyn23,ret__1927000836__auto__ys11,arbace.core3,prnys11,arbace.core1,/ys11,arbace.core6,doubleys11,arbace.core1,-ys11,arbace.core7,alengthys11,arbace.core6,acloneys11,arbace.core4,agetys11,arbace.core4,asetyn5,arrayyn3,idxyn3,valyn4,idx2yn1,&yn4,idxvyn25,array__1927000856__auto__yn23,idx__1927000857__auto__yn23,val__1927000858__auto__yn23,java.lang.reflect.Arrayyn24,idx2__1927000859__auto__yn24,idxv__1927000860__auto__ys11,arbace.core5,applyys11,arbace.core13,create-structkn6,renamekn7,excludekn3,allkn5,referkn4,onlyyn15,arbace.lang.Varyn6,createyn10,setDynamicys11,arbace.core18,pushThreadBindingsys11,arbace.core17,popThreadBindingskn2,asyn16,arbace.lang.ISeqkn2,orkn8,defaultskn6,selectkn6,excesskn7,missingyn6,Objectys11,arbace.core4,req!ys11,arbace.core10,identical?ys11,arbace.core5,assockn3,retkn3,selkn4,b->kkn4,subskn4,subakn9,subexcesskn10,submissingyn22,mm__1927000956__auto__ys11,arbace.core5,mergeys11,arbace.core9,some-valsys11,arbace.core11,select-keysys11,arbace.core9,not-emptyys11,arbace.core6,dissocys30,arbace.lang.PersistentArrayMap17,createAsIfByAssocys11,arbace.core8,to-arrayys30,arbace.lang.PersistentArrayMap5,EMPTYkn3,prekn4,postyn1,%ys11,arbace.core6,assertyn22,xs__1927001018__auto__ys11,arbace.core6,concatys11,arbace.core8,lazy-seqys11,arbace.core4,restyn26,iterys__1927001035__auto__yn22,fs__1927001036__auto__ys11,arbace.core4,consys11,arbace.core10,when-firstys11,arbace.core12,chunk-appendyn21,c__1927001037__auto__yn24,size__1927001038__auto__ys11,arbace.core12,chunk-bufferys11,arbace.core10,chunk-consys11,arbace.core5,chunkyn24,iter__1927001039__auto__yn21,s__1927001093__auto__yn20,java.io.StringWriterys11,arbace.core7,bindingys11,arbace.core5,*out*yn21,s__1927001099__auto__ys11,arbace.core2,->yn21,java.io.StringReader.yn40,arbace.lang.LineNumberingPushbackReader.ys11,arbace.core4,*in*yn24,java.lang.AssertionErrorys11,arbace.core6,pr-strkn4,testkn2,okkn7,no-testkn7,privatekn7,contentys11,arbace.core4,synckn8,roundingys11,arbace.core14,*math-context*yn22,java.math.MathContext.yn22,java.math.RoundingModeys11,arbace.core11,alter-meta!yn21,a__1927001243__auto__yn21,l__1927001244__auto__yn21,a__1927001250__auto__yn21,l__1927001251__auto__ys11,arbace.core17,unchecked-inc-intys11,arbace.core11,float_arrayys11,arbace.core13,boolean_arrayys11,arbace.core10,byte_arrayys11,arbace.core10,char_arrayys11,arbace.core11,short_arrayys11,arbace.core12,double_arrayys11,arbace.core12,object_arrayys11,arbace.core9,int_arrayys11,arbace.core10,long_arrayys11,arbace.core8,booleansys11,arbace.core5,bytesys11,arbace.core5,charsys11,arbace.core6,shortsys11,arbace.core6,floatsys11,arbace.core4,intsys11,arbace.core7,doublesys11,arbace.core5,longskn7,parentskn11,descendantskn9,ancestorsyn4,not=yn3,tagyn6,parentyn2,oryn6,class?yn9,instance?yn17,arbace.lang.Namedyn9,namespaceyn3,andyn27,loading__1927001464__auto__ys20,arbace.lang.Compiler6,LOADERyn15,.getClassLoaderyn9,.getClassyn16,java.lang.Objectkn9,gen-classys11,arbace.core9,gen-classkn4,namekn7,impl-nskn4,mainys11,arbace.core5,in-nsyn10,.resetMetays21,arbace.lang.Namespace4,findys11,arbace.core20,with-loading-contextyn11,arbace.corekn13,refer-clojureys11,arbace.core5,referyn7,.equalsys11,arbace.core6,dosyncys11,arbace.core7,commuteys11,arbace.core13,*loaded-libs*ys11,arbace.core4,conjyn21,v__1927001498__auto__kn6,reloadkn10,reload-allkn7,requirekn3,usekn7,verbosekn8,as-aliaskn2,>>yn21,p__1927001616__auto__yn6,letfn*kn7,compactkn6,sparseys11,arbace.core5,condpys11,arbace.core1,=kn4,intskn8,identitykn6,hashesyn5,case*kn3,intkn10,hash-equivkn13,hash-identityys15,java.lang.Class7,forNameyn5,catchyn32,java.lang.ClassNotFoundExceptionyn21,___1927001817__auto__kn8,encodingys11,arbace.core11,future-callys11,arbace.core6,pcallskn5,majorkn5,minorkn11,incrementalkn9,qualifierkn7,interimkn8,describekn6,commitkn5,dirtyks11,arbace.core4,noneys11,arbace.core14,with-redefs-fnyn5,even?yn5,countyn7,clausesys11,arbace.core3,->>ks11,arbace.core4,haltkn5,somefkn2,vfkn2,kfkn5,initkkn3,eofkn9,read-condkn5,allowkn3,urlkn4,formkn8,conflictkn8,mappingsks11,arbace.core7,tap-nilys16,java.lang.Double5,isNaNys16,java.lang.Double10,isInfiniteyn23,map__1927002287__auto__kn5,superkn6,ifaceskn7,bridgesyn40,java.lang.UnsupportedOperationException.yn20,p__840000142__auto__ys11,arbace.core10,init-proxyyn4,thisys11,arbace.core21,proxy-call-with-superkn6,statuskn6,failedkn7,pendingkn5,readykn3,valkn7,messagekn4,datakn2,atkn3,viakn5,tracekn5,causeks12,arbace.error5,phasekn5,phasekn9,splicing?kn7,extendskn7,methodsyn6,floatsyn8,booleansyn5,longsyn7,objectsyn7,doublesyn5,charsyn4,intsyn6,shortsyn5,bytesys11,arbace.core13,gen-interfaceys11,arbace.core6,importkn2,onkn7,load-nskn8,no-printyn6,reify*yn6,__metayn8,__extmapkn22,unsynchronized-mutableyn19,arbace.lang.IRecordyn19,arbace.lang.IHashEqys11,arbace.core6,hasheqyn23,this__231000057__auto__yn21,hq__231000058__auto__yn8,__hasheqys11,arbace.core5,zero?yn20,h__231000059__auto__ys11,arbace.core7,bit-xorys26,arbace.lang.APersistentMap9,mapHasheqyn4,set!ys11,arbace.core8,hashCodeyn23,this__231000060__auto__yn23,hash__231000061__auto__yn6,__hashyn20,h__231000062__auto__ys26,arbace.lang.APersistentMap7,mapHashys11,arbace.core6,equalsyn23,this__231000063__auto__ys26,arbace.lang.APersistentMap9,mapEqualsyn16,arbace.lang.IObjyn23,this__231000064__auto__ys11,arbace.core8,withMetayn23,this__231000065__auto__yn19,arbace.lang.ILookupyn26,arbace.lang.IKeywordLookupys11,arbace.core5,valAtyn23,this__231000066__auto__yn20,k__231000067__auto__yn6,.valAtyn23,this__231000068__auto__yn20,k__231000069__auto__yn23,else__231000070__auto__ys11,arbace.core4,caseys11,arbace.core14,getLookupThunkyn23,this__231000071__auto__yn20,k__231000072__auto__yn6,gclassys11,arbace.core5,classyn7,gtargetys11,arbace.core5,reifyyn24,arbace.lang.ILookupThunkyn5,thunkyn26,arbace.lang.IPersistentMapyn23,this__231000073__auto__ys11,arbace.core1,+ys11,arbace.core5,emptyyn23,this__231000074__auto__yn23,this__231000075__auto__yn20,e__231000076__auto__ys11,arbace.core9,imap-consyn23,this__231000077__auto__ys11,arbace.core7,booleanys11,arbace.core11,containsKeyyn23,this__231000078__auto__yn20,k__231000079__auto__ys11,arbace.core7,entryAtyn23,this__231000080__auto__yn20,k__231000081__auto__yn20,v__231000082__auto__ys20,arbace.lang.MapEntry6,createyn23,this__231000084__auto__ys11,arbace.core8,iteratoryn27,arbace.lang.RecordIterator.ys14,arbace.lang.RT4,iteryn23,this__231000085__auto__yn20,k__231000086__auto__ys11,arbace.core7,withoutyn23,this__231000087__auto__yn20,k__231000088__auto__ys11,arbace.core9,contains?ys11,arbace.core9,with-metays11,arbace.core4,intoyn13,java.util.Mapyn20,java.io.Serializableys11,arbace.core4,sizeyn23,this__231000089__auto__yn6,.countys11,arbace.core7,isEmptyyn23,this__231000090__auto__ys11,arbace.core13,containsValueyn23,this__231000091__auto__yn20,v__231000092__auto__ys11,arbace.core4,someys11,arbace.core4,valsyn23,this__231000093__auto__yn20,k__231000094__auto__ys11,arbace.core3,putyn23,this__231000095__auto__yn20,k__231000096__auto__yn20,v__231000097__auto__ys11,arbace.core6,removeyn23,this__231000098__auto__yn20,k__231000099__auto__ys11,arbace.core6,putAllyn23,this__231000100__auto__yn20,m__231000101__auto__ys11,arbace.core5,clearyn23,this__231000102__auto__ys11,arbace.core6,keySetyn23,this__231000103__auto__ys11,arbace.core3,setys11,arbace.core4,keysys11,arbace.core6,valuesyn23,this__231000104__auto__ys11,arbace.core8,entrySetyn23,this__231000105__auto__yn8,deftype*yn3,intkn10,implementskn16,volatile-mutableyn2,->yn7,overageyn27,arbace.lang.ArityException.ys11,arbace.core4,nameys11,arbace.core7,declareyn5,map->yn20,m__231000174__auto__yn26,arbace.lang.MapEquivalenceyn17,arbace.lang.ITypekn12,on-interfacekn5,implskn3,varyn21,arbace.lang.AFunctionyn24,cache__231000238__auto__yn20,f__231000239__auto__yn24,cache__231000232__auto__yn18,.__methodImplCacheyn20,f__231000233__auto__yn6,.fnForys16,arbace.lang.Util7,classOfyn23,meta__231000234__auto__yn20,m__231000235__auto__yn4,.symys11,arbace.core18,-cache-protocol-fnyn24,cache__231000236__auto__yn20,f__231000237__auto__kn15,method-builderskn8,protocolyn7,booleanyn4,charyn4,longyn6,doubleyn5,shortyn5,floatyn4,voidyn4,byteys11,arbace.core7,defonceys11,arbace.core20,assert-same-protocolys11,arbace.core14,alter-var-rootkn4,sigskn10,method-mapys11,arbace.core6,internys11,arbace.core4,*ns*kn19,extend-via-metadatays11,arbace.core14,-reset-methodsys11,arbace.core6,extendys11,arbace.core11,extend-typeyn24,arbace.core.ArrayManagerys11,arbace.core5,arrayys11,arbace.core1,_yn22,size__57000061__auto__yn19,i__57000062__auto__yn21,val__57000063__auto__yn20,am__57000093__auto__ys11,arbace.core3,amsyn6,class*kn3,topkn4,topskn4,anonkn5,localyn6,label*yn6,break*yn9,continue*yn7,return*yn7,switch*yn7,lambda*yn11,method-ref*yn9,java-str*yn12,java-assert*yn9,for-each*yn15,with-resources*yn12,if-instance*kn5,addedys11,arbace.core4,listkn14,inline-aritiesyn6,andIntyn5,orIntyn6,xorIntyn6,notIntyn12,shiftLeftIntyn13,shiftRightIntyn21,unsignedShiftRightIntyn16,unchecked_divideyn19,unchecked_remainderyn19,unchecked_float_addyn24,unchecked_float_subtractyn24,unchecked_float_multiplyyn22,unchecked_float_divideyn25,unchecked_float_remainderyn22,unchecked_float_negatev11,arbace.core4,consR0,R1,R2,v11,arbace.core5,firstv11,arbace.core4,nextv11,arbace.core6,secondv11,arbace.core5,nnextv11,arbace.core4,listR3,R4,v11,arbace.core4,map?v11,arbace.core9,with-metav11,arbace.core4,conjR5,v11,arbace.core5,assocv11,arbace.core4,seq?v11,arbace.core3,seqv11,arbace.core18,assert-valid-fdeclv11,arbace.core7,string?R6,v11,arbace.core7,vector?v11,arbace.core4,lastv11,arbace.core7,butlastR7,R8,v11,arbace.core4,sigsR9,R10,R11,R12,R13,R14,v11,arbace.core3,vecR4,R15,R16,R17,R18,ML1,R19,m4,R20,i489,R21,i49,R22,R22,R23,R16,R23,R16,v11,arbace.core3,notv11,arbace.core3,strR23,R24,v11,arbace.core7,symbol?R25,v11,arbace.core6,gensymv11,arbace.core8,keyword?v11,arbace.core6,spreadv11,arbace.core5,list*v11,arbace.core5,applyR26,R27,Myn3,fn*m2,R28,Tv11,arbace.core12,chunked-seq?v11,arbace.core10,chunk-consv11,arbace.core11,chunk-firstv11,arbace.core10,chunk-restv11,arbace.core4,restv11,arbace.core6,concatR26,R29,Myn3,fn*m2,R28,Tv11,arbace.core8,hash-mapR28,R23,R30,R31,R18,R32,R33,R18,R32,R34,v11,arbace.core1,=R18,R32,R35,R36,v11,arbace.core6,vectorR37,R23,R38,R36,R39,R23,R40,R18,R41,R42,R18,R43,R44,R18,R43,v11,arbace.core16,*unchecked-math*R45,R46,R18,R43,R47,v11,arbace.core1,<R18,R41,R48,R18,R41,R49,R18,R41,R50,R51,v11,arbace.core10,chunk-nextv11,arbace.core7,reduce0v11,arbace.core7,reduce1R18,R41,R18,R41,R18,R41,R18,R41,v11,arbace.core11,nary-inlinev11,arbace.core2,+'v11,arbace.core4,castC16,java.lang.Numberl0,v11,arbace.core1,+v11,arbace.core2,*'l1,v11,arbace.core1,*v11,arbace.core1,/v11,arbace.core2,-'v11,arbace.core1,-v11,arbace.core2,<=R18,R41,R52,v11,arbace.core1,>R18,R41,R53,v11,arbace.core2,>=R18,R41,R54,v11,arbace.core2,==R18,R41,R34,v11,arbace.core3,maxv11,arbace.core3,minR55,R18,R41,R56,R18,R41,R57,R58,R18,R41,R59,R18,R41,R60,R18,R41,R61,R18,R41,R62,R18,R41,R63,R18,R41,R64,R18,R41,R65,R18,R41,R66,R18,R41,R67,R18,R41,R64,R18,R41,R68,R18,R41,R69,R18,R41,R70,R18,R41,R71,R18,R41,R72,R18,R41,R73,R18,R41,R74,R18,R41,R75,R18,R41,R30,v11,arbace.core7,bit-andv11,arbace.core6,bit-orv11,arbace.core7,bit-xorv11,arbace.core11,bit-and-notR18,R41,R76,R18,R41,R77,R18,R41,R78,v11,arbace.core8,integer?v11,arbace.core5,even?v11,arbace.core4,int?R18,R43,R79,R80,v11,arbace.core6,dissocv11,arbace.core4,disjR18,R43,R81,v11,arbace.core6,ident?v11,arbace.core9,namespaceR36,R82,R83,R36,R84,R85,R83,R86,R87,R88,R18,R18,v11,arbace.core8,hash-setv11,arbace.core4,keysC34,java.lang.IllegalArgumentExceptionv11,arbace.core3,mapR89,R90,v11,arbace.core16,global-hierarchyR36,R91,R11,R92,R38,R93,R94,R95,R96,R11,R26,R95,v11,arbace.core4,namev11,arbace.core19,check-valid-optionsR18,m2,R5,R95,R97,R12,R16,R92,R98,R99,R100,R101,R4,R102,R20,R103,R4,R104,R36,R105,R23,R36,v11,arbace.core4,*ns*R106,R36,R107,R108,R36,R36,R109,R23,R110,R36,R111,R36,R112,R23,R110,R36,R22,R36,R113,R114,R83,R86,R115,v11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsR116,R12,v11,arbace.core19,get-thread-bindingsv11,arbace.core14,with-bindings*R117,R12,R118,R119,v11,arbace.core15,setup-referenceR120,R121,R122,R123,v11,arbace.core19,binding-conveyor-fnv11,arbace.core7,*agent*v11,arbace.core8,send-viaR124,v11,arbace.core11,agent-errorv11,arbace.core13,restart-agentv11,arbace.core3,refR125,R126,v11,arbace.core12,deref-futurev11,arbace.core4,atomR18,R127,R128,R12,R23,R129,R98,R26,R130,R16,m2,R5,R131,R132,R133,v11,arbace.core4,compv11,arbace.core8,identityR36,R134,R135,R136,R108,R137,R138,R139,v11,arbace.core6,every?v11,arbace.core12,chunk-bufferv11,arbace.core5,chunkv11,arbace.core12,chunk-appendR16,R11,v11,arbace.core9,vary-metaR140,v11,arbace.core3,catv11,arbace.core6,filterv11,arbace.core10,complementR141,v11,arbace.core7,reducedv11,arbace.core5,derefv11,arbace.core4,takev11,arbace.core9,volatile!v11,arbace.core14,ensure-reducedv11,arbace.core10,take-whilev11,arbace.core4,dropv11,arbace.core9,drop-lastv11,arbace.core7,vreset!v11,arbace.core10,drop-whilev11,arbace.core6,repeatv11,arbace.core7,iteratev11,arbace.core4,inc'v11,arbace.core8,line-seql-1,v11,arbace.core8,to-arrayv11,arbace.core4,sortv11,arbace.core7,comparev11,arbace.core7,sort-byv11,arbace.core5,dorunv11,arbace.core5,doallv11,arbace.core9,partitionv11,arbace.core7,nthrestR142,R143,R144,m2,R5,R145,R138,R146,R138,R139,R16,R36,R108,R23,R16,R136,R147,R23,R137,R36,R148,R149,R147,R23,R150,R36,R151,R152,R138,R153,R154,R44,R154,R36,R101,v11,arbace.core4,sendv11,arbace.core5,awaitR36,R155,R156,R136,R108,R137,R138,R139,v11,arbace.core9,transientv11,arbace.core10,merge-withv11,arbace.core6,assoc!v11,arbace.core11,persistent!v11,arbace.core3,keyv11,arbace.core3,valv11,arbace.core5,conj!v11,arbace.core5,mergev11,arbace.core5,into1R8,R16,R157,v11,arbace.core10,into-arrayR158,v11,arbace.core5,classR18,R41,R159,R18,R43,R160,R18,R43,R161,R162,R18,R43,R163,R18,R43,R164,R165,R18,R43,R166,R167,R18,R43,R168,R169,R18,R43,R170,R18,R43,R171,R18,R43,R172,R18,R43,R173,R18,R43,R174,R18,R43,R175,R18,R43,R176,v11,arbace.core6,ratio?v11,arbace.core8,decimal?v11,arbace.core6,bigintv11,arbace.core6,float?v11,arbace.core7,number?C20,java.math.BigIntegerC20,java.math.BigDecimalv11,arbace.core11,*print-dup*v11,arbace.core9,print-dupv11,arbace.core12,print-methodv11,arbace.core2,prv11,arbace.core5,*out*c32,v11,arbace.core5,pr-onv11,arbace.core14,system-newlinev11,arbace.core18,*flush-on-newline*v11,arbace.core5,flushv11,arbace.core7,newlinev11,arbace.core16,*print-readably*v11,arbace.core3,prnv11,arbace.core4,readv11,arbace.core4,*in*v11,arbace.core11,read+stringv11,arbace.core6,subvecR16,R36,l2,R83,R177,R86,R18,R178,R36,R12,R18,R36,R179,R18,R180,R181,R182,R183,R100,R184,R185,R186,R18,R180,R181,d4696837146684686336,C14,arbace.lang.RTR18,R43,R187,R18,R43,R188,v11,arbace.core4,agetR18,R43,R189,R154,v11,arbace.core4,asetR18,R43,R190,R154,R17,R8,R191,R192,R193,R191,R192,R194,R195,R196,R197,R198,R199,R18,R200,R201,R195,R202,R203,R189,v11,arbace.core8,aset-intv11,arbace.core9,aset-longv11,arbace.core12,aset-booleanv11,arbace.core10,aset-floatv11,arbace.core11,aset-doublev11,arbace.core10,aset-shortv11,arbace.core9,aset-bytev11,arbace.core9,aset-charv11,arbace.core10,make-arrayv11,arbace.core13,macroexpand-1v11,arbace.core11,macroexpandR11,R204,v11,arbace.core11,load-readerv11,arbace.core4,set?v11,arbace.core7,find-nsv11,arbace.core6,the-nsv11,arbace.core10,filter-keyv11,arbace.core6,ns-mapv11,arbace.core7,partialv11,arbace.core9,instance?C15,java.lang.Classv11,arbace.core10,ns-publicsR205,v11,arbace.core3,setR206,R207,R208,R209,v11,arbace.core10,ns-internsv11,arbace.core4,not=v11,arbace.core8,take-nthv11,arbace.core10,interleaveR36,ML4,R88,R210,R211,R212,m4,R20,i4382,R21,i33,R18,R210,R213,R114,R83,R86,R18,R210,R214,v11,arbace.core9,contains?v11,arbace.core10,ns-resolvev11,arbace.core4,odd?v11,arbace.core10,repeatedlyv11,arbace.core8,counted?v11,arbace.core9,reduce-kvv11,arbace.core5,some?v11,arbace.core4,someS1,R195,R147,R195,R215,R101,R146,R47,m2,R5,R216,R217,R218,v11,arbace.core6,zipmapR219,R220,R221,v11,arbace.core7,keywordR8,v11,arbace.core6,symbolR26,R222,R223,R79,R224,R23,R225,R92,R79,R79,R223,R79,R195,R226,R227,R228,R229,R230,R231,R232,v11,arbace.core4,valsv11,arbace.core11,select-keysv11,arbace.core6,empty?R149,R233,R234,R235,R236,R234,R235,R234,R237,R203,R238,R235,R234,R235,R23,R94,R216,R23,R146,R239,R240,R23,R147,R101,R241,v11,arbace.core8,destvec*v11,arbace.core8,destmap*R0,v11,arbace.core11,destructureR36,R242,R243,R36,R244,R16,R245,R244,R245,v11,arbace.core18,maybe-destructuredR2,R2,R1,R36,R1,R36,R149,R246,R147,R36,R101,R247,R248,v11,arbace.core3,popv11,arbace.core4,peekR36,R108,R23,R138,R249,R36,R250,R251,R147,R23,R247,R249,R138,R249,R252,R249,R12,R248,R136,R253,R36,R108,R23,R138,R139,R16,R254,R138,R139,R12,R248,R136,R149,R147,R23,R150,R36,R255,R152,R256,R154,R44,R257,R23,R136,R154,R23,R137,R36,R148,R258,R259,R153,R258,R259,R36,R101,R36,R260,R36,R261,R26,R262,R263,R264,R100,R177,R265,R266,R267,R268,R263,R269,v11,arbace.core5,printv11,arbace.core7,printlnC27,java.lang.StackTraceElementv11,arbace.core16,elide-top-framesv11,arbace.core8,*assert*R92,R98,R26,R270,R100,R271,R92,R98,R26,R270,R100,R271,R272,R273,R274,v11,arbace.core10,re-matcherv11,arbace.core9,re-groupsv11,arbace.core7,re-findv11,arbace.core4,randR17,R275,v11,arbace.core6,mapcatv11,arbace.core8,tree-seqR276,v11,arbace.core4,findv11,arbace.core5,rangeR277,R278,R263,R279,R280,R18,R281,v11,arbace.core11,mk-bound-fnv11,arbace.core10,split-withR16,R17,v11,arbace.core4,evalR12,R282,R22,R225,R12,R22,R36,R283,R284,R187,R188,R136,R23,R137,R16,R190,R138,R139,R36,R285,R286,R187,R136,R23,R137,R138,R287,R18,R41,R288,R18,R41,R289,R18,R41,R290,R18,R41,R291,R18,R41,R292,R18,R41,R293,R18,R43,R294,R18,R41,R295,R18,R41,R296,R18,R41,R297,R18,R41,R298,R18,R41,R299,R18,R41,R300,R18,R41,R301,R18,R41,R302,R18,R41,R303,R18,R41,R304,v11,arbace.core5,agentv11,arbace.core8,send-offv11,arbace.core21,release-pending-sendsv11,arbace.core5,sequel100,R305,R306,R307,v11,arbace.core5,basesv11,arbace.core9,not-emptyv11,arbace.core5,into0v11,arbace.core6,class?v11,arbace.core6,supersv11,arbace.core4,isa?v11,arbace.core7,parentsv11,arbace.core9,ancestorsv11,arbace.core11,descendantsv11,arbace.core6,pr-strML3,R308,R309,R310,m4,R20,i5791,R21,i12,ML3,R311,ML2,R312,R309,m4,R20,i5792,R21,i16,ML3,R313,R314,R309,m4,R20,i5792,R21,i29,m4,R20,i5792,R21,i12,ML3,R313,R314,R310,m4,R20,i5793,R21,i12,v11,arbace.core9,print-strML2,R315,R310,m4,R20,i5786,R21,i12,ML3,R311,ML2,R312,R309,m4,R20,i5787,R21,i16,ML3,R316,ML3,R313,R314,R309,m4,R20,i5787,R21,i34,ML2,R315,R309,m4,R20,i5787,R21,i68,m4,R20,i5787,R21,i29,m4,R20,i5787,R21,i12,v11,arbace.core14,alter-var-rootv11,arbace.core6,derivev11,arbace.core7,flattenv11,arbace.core9,interposev11,arbace.core14,make-hierarchyv11,arbace.core8,underivev11,arbace.core9,distinct?v11,arbace.core13,create-structv11,arbace.core6,structC16,java.lang.Stringv11,arbace.core6,formatR12,R317,R18,R210,R213,R318,R319,R320,R321,R83,R86,R18,R210,R214,R8,R322,R323,R324,c45,c95,R325,R326,v11,arbace.core6,removeR16,R327,R328,R329,R330,R331,v11,arbace.core8,not-any?R332,R333,R331,R23,R334,R331,R16,R335,R336,R96,R22,R337,R338,R333,R331,R36,R339,R11,R92,R93,R11,v11,arbace.core6,*file*c46,c47,v11,arbace.core13,root-resourcev11,arbace.core4,subsv11,arbace.core7,commutev11,arbace.core13,*loaded-libs*v11,arbace.core4,loadv11,arbace.core8,throw-ifv11,arbace.core8,load-onev11,arbace.core10,sorted-setR340,R341,R342,R343,R344,R345,v11,arbace.core8,load-allv11,arbace.core9,create-nsML4,R206,R209,R205,R208,m4,R20,i6096,R21,i40,v11,arbace.core5,referv11,arbace.core19,*loading-verbosely*v11,arbace.core9,remove-nsv11,arbace.core6,printfv11,arbace.core7,ns-namev11,arbace.core5,aliasS8,R345,R343,R215,R342,R344,R340,R341,R208,c44,v11,arbace.core8,libspec?v11,arbace.core8,load-libv11,arbace.core9,prependssv11,arbace.core15,*pending-paths*v11,arbace.core9,load-libsv11,arbace.core7,requirev11,arbace.core17,qualified-symbol?v11,arbace.core7,resolvev11,arbace.core18,serialized-requirev11,arbace.core14,root-directoryv11,arbace.core23,check-cyclic-dependencyv11,arbace.core15,*compile-files*v11,arbace.core3,getv11,arbace.core8,assoc-inv11,arbace.core10,trampolinev11,arbace.core3,fn?R136,R108,R138,v11,arbace.core5,swap!v11,arbace.core8,split-atR346,l3,R98,R99,R100,R23,R106,R347,R36,R282,R22,R234,R225,R348,R12,v11,arbace.core10,shift-maskl31,v11,arbace.core13,max-mask-bitsv11,arbace.core10,sorted-mapv11,arbace.core21,max-switch-table-sizev11,arbace.core11,fits-table?v11,arbace.core14,maybe-min-hashv11,arbace.core3,intV2,l0,l0,v11,arbace.core8,case-mapR349,R350,v11,arbace.core6,updatev11,arbace.core4,fnilR8,R351,R352,v11,arbace.core6,ffirstV2,l0,l0,v11,arbace.core21,merge-hash-collisionsv11,arbace.core11,prep-hashesm2,R5,C16,java.lang.ObjectR98,R99,R100,R36,R353,R354,R355,v11,arbace.core9,prep-intsR36,R356,R357,R36,R356,R358,R36,R356,R359,v21,arbace.core.protocols16,iterator-reduce!v11,arbace.core12,iterator-seqv11,arbace.core14,stream-reduce!v11,arbace.core17,stream-transduce!R83,R360,R361,R362,R363,v11,arbace.core18,-cache-protocol-fnC16,arbace.core.Instv11,arbace.core8,inst-ms*v11,arbace.core10,satisfies?v11,arbace.core4,Instv21,arbace.core.protocols11,coll-reducev11,arbace.core6,reducev21,arbace.core.protocols9,kv-reducev11,arbace.core10,completingv11,arbace.core9,transducev11,arbace.core4,intov11,arbace.core10,merge-deepv11,arbace.core15,merge-deep-withR364,v11,arbace.core20,normalize-slurp-optsv14,arbace.java.io6,readerv14,arbace.java.io4,copyv14,arbace.java.io6,writerR365,Myn3,fn*m2,R28,Tv11,arbace.core4,pmapv11,arbace.core11,future-callR366,R12,R367,v11,arbace.core17,*clojure-version*R368,R369,R370,R371,v11,arbace.core11,read-stringv11,arbace.core11,*read-eval*C21,java.lang.ClassLoaderm6,R372,s7,unknownR373,nR374,nR372,v11,arbace.core16,*arbace-version*v11,arbace.core16,compare-and-set!v11,arbace.core11,sequential?v11,arbace.core12,partition-byR375,v11,arbace.core9,unreducedv11,arbace.core10,reductionsv11,arbace.core8,rand-intv11,arbace.core13,partition-allv11,arbace.core10,partitionvv11,arbace.core14,partitionv-allv11,arbace.core4,keepR376,R22,R12,R23,R266,R36,ML2,R377,ML2,R378,R379,m4,R20,i7892,R21,i18,m4,R20,i7892,R21,i11,R23,R380,R36,ML2,R377,ML2,R378,R379,m4,R20,i7909,R21,i18,m4,R20,i7909,R21,i11,R36,R23,R110,R266,R36,R23,R110,R380,R36,v11,arbace.core18,preserving-reducedR381,v11,arbace.core9,halt-whenv11,arbace.core8,sequencev11,arbace.core6,dedupev11,arbace.core16,print-sequentialv11,arbace.core12,print-objectR382,R383,R384,R385,C16,java.lang.Threadv11,arbace.core15,enumeration-seqv11,arbace.core6,internm4,R386,nR387,R388,m2,R386,nv11,arbace.core15,data-reader-varv11,arbace.core7,ex-infoR389,R390,R391,R392,v11,arbace.core14,*data-readers*v11,arbace.core21,load-data-reader-filev11,arbace.core16,data-reader-urlsv11,arbace.core4,tapqR393,v11,arbace.core6,tapsetv11,arbace.core5,forcev11,arbace.core8,tap-loopv11,arbace.core4,tap>v11,arbace.core11,parsing-errR394,R395,V4,R219,R220,R221,R207,R12,R396,R36,R235,v11,arbace.core13,selector-implv11,arbace.core4,hashv11,arbace.core10,method-sigv11,arbace.core12,group-by-sigv11,arbace.core13,most-specificR397,C16,java.lang.ObjectS3,s8,toStrings8,hashCodes6,equalsR398,R399,v11,arbace.core18,proxy-super-markerv11,arbace.core13,proxy-methodsV1,C26,arbace.lang.IPersistentMapV1,C26,arbace.lang.IPersistentMapC26,arbace.lang.IPersistentMapv11,arbace.core15,proxy-method-fnv11,arbace.core16,set-proxy-methodv11,arbace.core24,get-super-and-interfacesv11,arbace.core10,proxy-namev11,arbace.core12,define-proxyv11,arbace.core15,get-proxy-classR98,R400,R36,R401,R26,R402,R403,R12,v11,arbace.core14,proxy-mappingsv11,arbace.core12,update-proxyR404,R12,R18,R403,R403,v11,arbace.core14,bean-exported?v11,arbace.core22,bean-accessible-methodv11,arbace.core4,nil?S4,C19,java.lang.CloneableC20,java.lang.ComparableC23,java.lang.AutoCloseableC17,java.io.Closeablev11,arbace.core18,bean-class-methodsv11,arbace.core17,bean-decapitalizev11,arbace.core16,bean-class-readsv11,arbace.core7,reversev11,arbace.core15,bean-propertiesv11,arbace.core10,init-proxyv11,arbace.core13,*print-level*v11,arbace.core14,*print-length*v11,arbace.core12,*print-meta*v11,arbace.core10,print-metav11,arbace.core12,print-simplev11,arbace.core19,print-tagged-objectv11,arbace.core10,print-ctorc34,v11,arbace.core18,char-escape-stringv11,arbace.core16,print-prefix-mapv11,arbace.core22,*print-namespace-maps*v11,arbace.core16,qualified-ident?v11,arbace.core8,strip-nsv11,arbace.core7,lift-nsv11,arbace.core9,print-mapv11,arbace.core20,*verbose-defrecords*v11,arbace.core16,char-name-stringc92,v11,arbace.core21,primitives-classnamesc69,c81,R405,R406,R407,R408,R409,v11,arbace.core12,deref-as-mapR410,v11,arbace.core7,ex-dataR411,R412,v11,arbace.core22,StackTraceElement->vecR413,R414,R415,R416,R417,v11,arbace.core14,Throwable->mapv11,arbace.core15,print-throwableR418,v11,arbace.core14,PrintWriter-onS1,c46,v11,arbace.core11,prim->classv11,arbace.core15,the-array-classS2,c46,c91,R419,R420,v11,arbace.core9,the-classS9,R421,R422,R423,R424,R425,R426,R427,R428,R429,v11,arbace.core29,resolve-unqualified-class-tagv11,arbace.core4,metav11,arbace.core15,namespace-mungeR36,R430,R431,v11,arbace.core10,parse-optsv11,arbace.core11,parse-implsv11,arbace.core4,var?R432,R222,R321,S2,R433,R434,v11,arbace.core16,parse-opts+specsR435,v11,arbace.core10,map-entry?R436,R437,Myn6,__hashm2,R438,TMyn8,__hasheqm2,R438,TR439,R440,R441,R442,R36,R443,R444,R23,R445,R36,R446,R154,R447,R448,R449,R444,R450,R451,R36,R452,R453,R23,R445,R36,R454,R455,R449,R453,R456,R457,R458,R459,R103,R460,R436,R461,R462,R26,v11,arbace.core7,replaceR436,R463,R464,R465,R466,R467,R468,R465,R469,R470,R471,R472,R79,R437,R473,R474,R475,R36,R476,R477,R472,R478,R479,R480,R79,R481,R478,R23,R224,R477,R478,R476,R18,R481,R482,R44,R483,R484,R44,R437,R485,R486,R98,R400,R100,R252,R487,R488,R22,R489,R34,R490,R491,R40,R224,R108,R224,R477,R477,R36,R38,R352,R18,R352,R437,R18,R437,R492,R493,R494,R30,R224,R468,R495,R496,R497,R36,R498,R468,R92,R224,R499,R147,R500,R147,R247,R499,R437,R501,R502,R503,R437,R225,R504,R505,R351,R224,R26,S2,R453,R444,R26,S3,R453,R444,R437,R225,R437,R506,R507,R508,R23,R509,R238,R510,R511,R436,R26,S3,R453,R444,R437,R237,R238,R437,R512,R513,R514,R515,R516,R517,R518,R352,R516,R519,R520,R521,R491,R522,R523,R79,R524,R525,R468,R526,R527,R528,R529,R98,R400,R530,R531,R532,R98,R400,R533,R534,R535,R98,R400,R536,R537,R98,R400,R538,R539,R540,R541,R542,R543,R523,R544,R545,R540,R546,R436,R437,Myn6,__hashm4,R438,TR5,R547,Myn8,__hasheqm4,R438,TR5,R547,R548,S2,R438,R549,R550,l20,R17,V2,R195,R551,R23,R352,R44,R551,R26,R47,R551,R98,R552,R484,R44,R551,R553,R26,S4,R453,R436,R444,R437,R36,R554,R550,R554,R555,v11,arbace.core14,emit-defrecordR431,v11,arbace.core24,build-positional-factoryR17,R555,R556,R23,R94,R557,R511,v11,arbace.core15,validate-fieldsR558,R546,R36,v11,arbace.core13,emit-deftype*R431,v11,arbace.core11,super-chainR559,R560,v11,arbace.core4,prefv11,arbace.core18,find-protocol-implv11,arbace.core11,implements?v11,arbace.core20,find-protocol-methodR561,v11,arbace.core24,expand-method-impl-cachem2,R5,R562,R12,R563,R36,R12,R18,R564,R562,R12,R36,R565,R566,R567,R568,R569,R23,R224,R106,R570,R149,R571,R103,R572,R23,R573,R36,R574,R566,R575,R568,R569,R23,R573,R449,R566,R576,R577,v11,arbace.core6,bound?v11,arbace.core5,*err*v11,arbace.core5,mungeR8,S9,R578,R579,R580,R581,R582,R547,R583,R584,R585,v11,arbace.core9,update-inV1,R5,S1,l0,v11,arbace.core5,countR222,R222,R16,R586,R430,R282,R22,R225,R587,R22,R588,R22,R234,R225,R589,R22,R590,R591,R592,R510,R234,R22,v11,arbace.core19,emit-method-builderR593,R594,v11,arbace.core13,emit-protocolv11,arbace.core14,-reset-methodsv11,arbace.core9,protocol?R12,R12,R595,v11,arbace.core16,emit-hinted-implv11,arbace.core16,emit-extend-typeR16,R596,v11,arbace.core20,emit-extend-protocolv11,arbace.core7,methodsC16,arbace.lang.ISeqC29,arbace.lang.IPersistentVectorR479,R597,R598,R599,R600,R187,R599,R187,R188,R599,R188,R189,R599,R601,R189,R190,R599,R602,R190,R36,R603,R604,R23,R98,R99,R100,v11,arbace.core9,vector-ofv11,arbace.core3,amsl4,v11,arbace.core10,EMPTY-NODER605,R606,R605,R607,R605,R608,R605,R609,R610,R611,R612,R613,R614,R615,R616,R617,R618,R619,R620,R621,R621,R16,R17,R622,R12,R623,R18,R41,R623,R624,R18,R41,R625,R626,R627,R628,R629,R630,R631,R632,R633,R634,R635,R636,R637,R638,R639,")

var Lit_1 *jrt.String = jrt.Intern("arbace.core.proxy$java.io.Writer$ff19274a")

var Lit_2 *jrt.String = jrt.Intern("flush")

var Lit_3 *jrt.String = jrt.Intern("arbace.core$PrintWriter_on$fn__1769000394")

var Lit_4 *jrt.String = jrt.Intern("close")

var Lit_5 *jrt.String = jrt.Intern("arbace.core$PrintWriter_on$fn__1769000396")

var Lit_6 *jrt.String = jrt.Intern("write")

var Lit_7 *jrt.String = jrt.Intern("arbace.core$PrintWriter_on$fn__1769000398")

var Lit_8 *jrt.String = jrt.Intern("arbace.core$Throwable__GT_map$base__1769000359")

var Lit_9 *jrt.String = jrt.Intern("arbace.core$Throwable__GT_map$fn__1769000361")

var Lit_10 *jrt.String = jrt.Intern("No implementation of method: ")

var Lit_11 *jrt.String = jrt.Intern(" of protocol: ")

var Lit_12 *jrt.String = jrt.Intern(" found for class: ")

var Lit_13 *jrt.String = jrt.Intern("nil")

var Lit_14 *jrt.String = jrt.Intern("aclone")

var Lit_15 *jrt.String = jrt.Intern("WARNING: add-classpath is deprecated")

var Lit_16 *jrt.String = jrt.Intern("alength")

var Lit_17 *jrt.String = jrt.Intern("Unrecognized type ")

var Lit_18 *jrt.String = jrt.Intern("arbace.core$ancestors$fn__1927001418")

var Lit_19 *jrt.String = jrt.Intern("No value supplied for key: ")

var Lit_20 *jrt.String = jrt.Intern("aget")

var Lit_21 *jrt.String = jrt.Intern("Assert failed: ")

var Lit_22 *jrt.String = jrt.Intern("\n")

var Lit_23 *jrt.String = jrt.Intern(" requires ")

var Lit_24 *jrt.String = jrt.Intern(" in ")

var Lit_25 *jrt.String = jrt.Intern(":")

var Lit_26 *jrt.String = jrt.Intern("arbace.core$assert_same_protocol$fn__231000264")

var Lit_27 *jrt.String = jrt.Intern("arbace.core$assert_same_protocol$fn__231000266")

var Lit_28 *jrt.String = jrt.Intern("Warning: protocol")

var Lit_29 *jrt.String = jrt.Intern("is overwriting")

var Lit_30 *jrt.String = jrt.Intern("method ")

var Lit_31 *jrt.String = jrt.Intern(" of protocol ")

var Lit_32 *jrt.String = jrt.Intern("sym")

var Lit_33 *jrt.String = jrt.Intern("function ")

var Lit_34 *jrt.String = jrt.Intern("Invalid signature \"")

var Lit_35 *jrt.String = jrt.Intern("\" should be a list")

var Lit_36 *jrt.String = jrt.Intern("Parameter declaration \"")

var Lit_37 *jrt.String = jrt.Intern("\" should be a vector")

var Lit_38 *jrt.String = jrt.Intern("Parameter declaration missing")

var Lit_39 *jrt.String = jrt.Intern("arbace.core$assert_valid_fdecl$fn__1927002102")

var Lit_40 *jrt.String = jrt.Intern("arbace.core$assert_valid_fdecl$fn__1927002104")

var Lit_41 *jrt.String = jrt.Intern("assoc expects even number of arguments after map/vector, found odd number")

var Lit_42 *jrt.String = jrt.Intern("await in transaction")

var Lit_43 *jrt.String = jrt.Intern("Can't await in agent action")

var Lit_44 *jrt.String = jrt.Intern("arbace.core$await$count_down__1927000686")

var Lit_45 *jrt.String = jrt.Intern("await-for in transaction")

var Lit_46 *jrt.String = jrt.Intern("arbace.core$await_for$count_down__1927000694")

var Lit_47 *jrt.String = jrt.Intern("arbace.core$bean$fn__1968000063")

var Lit_48 *jrt.String = jrt.Intern("arbace.core$bean$v__1968000070")

var Lit_49 *jrt.String = jrt.Intern("arbace.core$bean$snapshot__1968000072")

var Lit_50 *jrt.String = jrt.Intern("arbace.core$bean$thisfn__1968000076")

var Lit_51 *jrt.String = jrt.Intern("arbace.core.proxy$arbace.lang.APersistentMap$ff19274a")

var Lit_52 *jrt.String = jrt.Intern("seq")

var Lit_53 *jrt.String = jrt.Intern("arbace.core$bean$fn__1968000080")

var Lit_54 *jrt.String = jrt.Intern("without")

var Lit_55 *jrt.String = jrt.Intern("arbace.core$bean$fn__1968000082")

var Lit_56 *jrt.String = jrt.Intern("count")

var Lit_57 *jrt.String = jrt.Intern("arbace.core$bean$fn__1968000084")

var Lit_58 *jrt.String = jrt.Intern("cons")

var Lit_59 *jrt.String = jrt.Intern("arbace.core$bean$fn__1968000086")

var Lit_60 *jrt.String = jrt.Intern("iterator")

var Lit_61 *jrt.String = jrt.Intern("arbace.core$bean$fn__1968000088")

var Lit_62 *jrt.String = jrt.Intern("entryAt")

var Lit_63 *jrt.String = jrt.Intern("arbace.core$bean$fn__1968000090")

var Lit_64 *jrt.String = jrt.Intern("valAt")

var Lit_65 *jrt.String = jrt.Intern("arbace.core$bean$fn__1968000092")

var Lit_66 *jrt.String = jrt.Intern("containsKey")

var Lit_67 *jrt.String = jrt.Intern("arbace.core$bean$fn__1968000094")

var Lit_68 *jrt.String = jrt.Intern("assoc")

var Lit_69 *jrt.String = jrt.Intern("arbace.core$bean$fn__1968000096")

var Lit_70 *jrt.String = jrt.Intern("arbace.core$bean$fn__1968000063$fn__1968000067")

var Lit_71 *jrt.String = jrt.Intern("arbace.core$bean$snapshot__1968000072$fn__1968000073")

var Lit_72 *jrt.String = jrt.Intern("arbace.core$bean$thisfn__1968000076$fn__1968000077")

var Lit_73 *jrt.String = jrt.Intern("arbace.core$bean_accessible_method$in__1968000006")

var Lit_74 *jrt.String = jrt.Intern("arbace.core$bean_accessible_method$in__1968000006$fn__1968000007")

var Lit_75 *jrt.String = jrt.Intern("arbace.core$bean_class_methods$no_params_QMARK___1968000011")

var Lit_76 *jrt.String = jrt.Intern("arbace.core$bean_class_methods$fn__1968000013")

var Lit_77 *jrt.String = jrt.Intern("arbace.core$bean_class_methods$fn__1968000015")

var Lit_78 *jrt.String = jrt.Intern("arbace.core$bean_class_methods$fn__1968000019")

var Lit_79 *jrt.String = jrt.Intern("arbace.core$bean_class_methods$fn__1968000015$fn__1968000016")

var Lit_80 *jrt.String = jrt.Intern("arbace.core$bean_class_reads$prefixed__1968000025")

var Lit_81 *jrt.String = jrt.Intern("arbace.core$bean_class_reads$fn__1968000028")

var Lit_82 *jrt.String = jrt.Intern("arbace.core$bean_class_reads$pick__1968000033")

var Lit_83 *jrt.String = jrt.Intern("arbace.core$bean_class_reads$fn__1968000038")

var Lit_84 *jrt.String = jrt.Intern("arbace.core$bean_class_reads$fn__1968000044")

var Lit_85 *jrt.String = jrt.Intern("is")

var Lit_86 *jrt.String = jrt.Intern("get")

var Lit_87 *jrt.String = jrt.Intern("arbace.core$bean_class_reads$pick__1968000033$fn__1968000034")

var Lit_88 *jrt.String = jrt.Intern("arbace.core$bean_properties$fn__1968000051")

var Lit_89 *jrt.String = jrt.Intern("arbace.core$bean_properties$fn__1968000059")

var Lit_90 *jrt.String = jrt.Intern("arbace.core$bean_properties$fn__1968000051$fn__1968000053")

var Lit_91 *jrt.String = jrt.Intern("arbace.core$binding$var_ize__1927000435")

var Lit_92 *jrt.String = jrt.Intern("arbace.core$binding_conveyor_fn$fn__1927000457")

var Lit_93 *jrt.String = jrt.Intern("arbace.core$bound_QMARK_$fn__1927001401")

var Lit_94 *jrt.String = jrt.Intern("arbace.core$bound_fn_STAR_$fn__1927000448")

var Lit_95 *jrt.String = jrt.Intern("Positional factory function for class ")

var Lit_96 *jrt.String = jrt.Intern(".")

var Lit_97 *jrt.String = jrt.Intern("arbace.core$build_positional_factory$iter__231000161__231000165")

var Lit_98 *jrt.String = jrt.Intern("arbace.core$build_positional_factory$iter__231000161__231000165$fn__231000166")

var Lit_99 *jrt.String = jrt.Intern("arbace.core$build_positional_factory$iter__231000161__231000165$fn__231000166$fn__231000167")

var Lit_100 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_101 *jrt.String = jrt.Intern("arbace.core$case$assoc_test__1927001769")

var Lit_102 *jrt.String = jrt.Intern("arbace.core$case$fn__1927001772")

var Lit_103 *jrt.String = jrt.Intern("arbace.core$case$fn__1927001779")

var Lit_104 *jrt.String = jrt.Intern("Duplicate case test constant: ")

var Lit_105 *jrt.String = jrt.Intern("arbace.core$case$fn__1927001772$fn__1927001776")

var Lit_106 *jrt.String = jrt.Intern("arbace.core$cat$fn__1927002178")

var Lit_107 *jrt.String = jrt.Intern("arbace.core$check_cyclic_dependency$fn__1927001561")

var Lit_108 *jrt.String = jrt.Intern("->")

var Lit_109 *jrt.String = jrt.Intern("Cyclic load dependency: %s")

var Lit_110 *jrt.String = jrt.Intern("[ ")

var Lit_111 *jrt.String = jrt.Intern(" ]")

var Lit_112 *jrt.String = jrt.Intern("Only these options are valid: ")

var Lit_113 *jrt.String = jrt.Intern("arbace.core$check_valid_options$fn__1927000383")

var Lit_114 *jrt.String = jrt.Intern(", ")

var Lit_115 *jrt.String = jrt.Intern("-")

var Lit_116 *jrt.String = jrt.Intern("-SNAPSHOT")

var Lit_117 *jrt.String = jrt.Intern("arbace.core$comp$fn__1927000519")

var Lit_118 *jrt.String = jrt.Intern("arbace.core$comparator$fn__1927000659")

var Lit_119 *jrt.String = jrt.Intern("arbace.core$compile$fn__1927001578")

var Lit_120 *jrt.String = jrt.Intern("arbace.core$complement$fn__1927000323")

var Lit_121 *jrt.String = jrt.Intern("arbace.core$completing$fn__1927001881")

var Lit_122 *jrt.String = jrt.Intern("arbace.core$concat$cat__1927000141")

var Lit_123 *jrt.String = jrt.Intern("arbace.core$concat$fn__1927000139")

var Lit_124 *jrt.String = jrt.Intern("arbace.core$concat$fn__1927000137")

var Lit_125 *jrt.String = jrt.Intern("arbace.core$concat$fn__1927000135")

var Lit_126 *jrt.String = jrt.Intern("arbace.core$concat$cat__1927000141$fn__1927000142")

var Lit_127 *jrt.String = jrt.Intern("cond requires an even number of forms")

var Lit_128 *jrt.String = jrt.Intern("arbace.core$cond__GT_$fn__1927002133")

var Lit_129 *jrt.String = jrt.Intern("arbace.core$cond__GT__GT_$fn__1927002144")

var Lit_130 *jrt.String = jrt.Intern("pred__")

var Lit_131 *jrt.String = jrt.Intern("expr__")

var Lit_132 *jrt.String = jrt.Intern("arbace.core$condp$emit__1927001617")

var Lit_133 *jrt.String = jrt.Intern("arbace.core$constantly$fn__1927000326")

var Lit_134 *jrt.String = jrt.Intern("getContextClassLoader")

var Lit_135 *jrt.String = jrt.Intern("getResources")

var Lit_136 *jrt.String = jrt.Intern("data_readers.ae")

var Lit_137 *jrt.String = jrt.Intern("data_readers.clj")

var Lit_138 *jrt.String = jrt.Intern("data_readers.cljc")

var Lit_139 *jrt.String = jrt.Intern("arbace.core$declare$fn__1927000591")

var Lit_140 *jrt.String = jrt.Intern("arbace.core$dedupe$fn__1927002186")

var Lit_141 *jrt.String = jrt.Intern("arbace.core$dedupe$fn__1927002186$fn__1927002187")

var Lit_142 *jrt.String = jrt.Intern("defclass")

var Lit_143 *jrt.String = jrt.Intern("defclasses takes defclass forms: ")

var Lit_144 *jrt.String = jrt.Intern("arbace.lang.IProxy")

var Lit_145 *jrt.String = jrt.Intern("proxy")

var Lit_146 *jrt.String = jrt.Intern("__initArbaceFnMappings")

var Lit_147 *jrt.String = jrt.Intern("arbace.core$define_proxy$fn__840000097")

var Lit_148 *jrt.String = jrt.Intern("__updateArbaceFnMappings")

var Lit_149 *jrt.String = jrt.Intern("arbace.core$define_proxy$fn__840000099")

var Lit_150 *jrt.String = jrt.Intern("__getArbaceFnMappings")

var Lit_151 *jrt.String = jrt.Intern("arbace.core$define_proxy$fn__840000101")

var Lit_152 *jrt.String = jrt.Intern("arbace.core$define_proxy$fn__840000111")

var Lit_153 *jrt.String = jrt.Intern("arbace.core$definterface$tag__231000004")

var Lit_154 *jrt.String = jrt.Intern("arbace.core$definterface$psig__231000007")

var Lit_155 *jrt.String = jrt.Intern("arbace.core$defmacro$fn__1927000075")

var Lit_156 *jrt.String = jrt.Intern("arbace.core$defmacro$fn__1927000077")

var Lit_157 *jrt.String = jrt.Intern("arbace.core$defmacro$add_implicit_args__1927000079")

var Lit_158 *jrt.String = jrt.Intern("arbace.core$defmacro$add_args__1927000081")

var Lit_159 *jrt.String = jrt.Intern("arbace.core$defmacro$fn__1927000083")

var Lit_160 *jrt.String = jrt.Intern("The syntax for defmulti has changed. Example: (defmulti name dispatch-fn :default dispatch-value)")

var Lit_161 *jrt.String = jrt.Intern("First argument to defn must be a symbol")

var Lit_162 *jrt.String = jrt.Intern("__inliner")

var Lit_163 *jrt.String = jrt.Intern("arbace")

var Lit_164 *jrt.String = jrt.Intern("arbace.core$defrecord$fn__231000178")

var Lit_165 *jrt.String = jrt.Intern("Factory function for class ")

var Lit_166 *jrt.String = jrt.Intern(", taking a map of keywords to field values.")

var Lit_167 *jrt.String = jrt.Intern("/create")

var Lit_168 *jrt.String = jrt.Intern("arbace.core$deftype$fn__231000194")

var Lit_169 *jrt.String = jrt.Intern("arbace.core$deref_as_map$fn__1769000347")

var Lit_170 *jrt.String = jrt.Intern("arbace.core$derive$tf__1927001422")

var Lit_171 *jrt.String = jrt.Intern("already has")

var Lit_172 *jrt.String = jrt.Intern("as ancestor")

var Lit_173 *jrt.String = jrt.Intern("Cyclic derivation:")

var Lit_174 *jrt.String = jrt.Intern("has")

var Lit_175 *jrt.String = jrt.Intern("arbace.core$derive$tf__1927001422$fn__1927001423")

var Lit_176 *jrt.String = jrt.Intern("Can't get descendants of classes")

var Lit_177 *jrt.String = jrt.Intern("map__")

var Lit_178 *jrt.String = jrt.Intern("temp__")

var Lit_179 *jrt.String = jrt.Intern("arbace.core$destmap_STAR_$fn__1927000957")

var Lit_180 *jrt.String = jrt.Intern("notfound__")

var Lit_181 *jrt.String = jrt.Intern("notfound?__")

var Lit_182 *jrt.String = jrt.Intern("arbace.core$destmap_STAR_$xf__1927000959")

var Lit_183 *jrt.String = jrt.Intern("arbace.core$destmap_STAR_$fn__1927000965")

var Lit_184 *jrt.String = jrt.Intern("arbace.core$destmap_STAR_$fn__1927000967")

var Lit_185 *jrt.String = jrt.Intern("arbace.core$destmap_STAR_$localize__1927000969")

var Lit_186 *jrt.String = jrt.Intern("arbace.core$destmap_STAR_$push1__1927000971")

var Lit_187 *jrt.String = jrt.Intern("arbace.core$destmap_STAR_$fn__1927000973")

var Lit_188 *jrt.String = jrt.Intern("arbace.core$destmap_STAR_$bk__1927000977")

var Lit_189 *jrt.String = jrt.Intern("keys ")

var Lit_190 *jrt.String = jrt.Intern(" appear only in :or")

var Lit_191 *jrt.String = jrt.Intern("symbol ")

var Lit_192 *jrt.String = jrt.Intern(" in :or does not refer to a binding")

var Lit_193 *jrt.String = jrt.Intern("default__")

var Lit_194 *jrt.String = jrt.Intern("!")

var Lit_195 *jrt.String = jrt.Intern("arbace.core$destmap_STAR_$fn__1927000973$fn__1927000974")

var Lit_196 *jrt.String = jrt.Intern("select__")

var Lit_197 *jrt.String = jrt.Intern("all__")

var Lit_198 *jrt.String = jrt.Intern("excess__")

var Lit_199 *jrt.String = jrt.Intern("missing__")

var Lit_200 *jrt.String = jrt.Intern("& can only appear once in ")

var Lit_201 *jrt.String = jrt.Intern("'")

var Lit_202 *jrt.String = jrt.Intern("' - binding symbols can only appear before '&', use keys after")

var Lit_203 *jrt.String = jrt.Intern("Multiple :or defaults for same key: ")

var Lit_204 *jrt.String = jrt.Intern(" '")

var Lit_205 *jrt.String = jrt.Intern("Can't supply default value for required key: ")

var Lit_206 *jrt.String = jrt.Intern("keys")

var Lit_207 *jrt.String = jrt.Intern("arbace.core$destmap_STAR_$xf__1927000959$fn__1927000960")

var Lit_208 *jrt.String = jrt.Intern("syms")

var Lit_209 *jrt.String = jrt.Intern("arbace.core$destmap_STAR_$xf__1927000959$fn__1927000962")

var Lit_210 *jrt.String = jrt.Intern("strs")

var Lit_211 *jrt.String = jrt.Intern("Unsupported map directive: ")

var Lit_212 *jrt.String = jrt.Intern("arbace.core$destructure$pb__1927000980")

var Lit_213 *jrt.String = jrt.Intern("arbace.core$destructure$process_entry__1927000982")

var Lit_214 *jrt.String = jrt.Intern("Unsupported binding form: ")

var Lit_215 *jrt.String = jrt.Intern("vec__")

var Lit_216 *jrt.String = jrt.Intern("seq__")

var Lit_217 *jrt.String = jrt.Intern("first__")

var Lit_218 *jrt.String = jrt.Intern("Unsupported binding form, only :as can follow & parameter")

var Lit_219 *jrt.String = jrt.Intern("arbace.core$distinct$step__1927001171")

var Lit_220 *jrt.String = jrt.Intern("arbace.core$distinct$fn__1927001167")

var Lit_221 *jrt.String = jrt.Intern("arbace.core$distinct$fn__1927001167$fn__1927001168")

var Lit_222 *jrt.String = jrt.Intern("arbace.core$distinct$step__1927001171$fn__1927001172")

var Lit_223 *jrt.String = jrt.Intern("arbace.core$distinct$step__1927001171$fn__1927001172$fn__1927001174")

var Lit_224 *jrt.String = jrt.Intern("arbace.core$doseq$step__1927000679")

var Lit_225 *jrt.String = jrt.Intern("seq_")

var Lit_226 *jrt.String = jrt.Intern("chunk_")

var Lit_227 *jrt.String = jrt.Intern("count_")

var Lit_228 *jrt.String = jrt.Intern("i_")

var Lit_229 *jrt.String = jrt.Intern("arbace.core$doto$fn__1927000823")

var Lit_230 *jrt.String = jrt.Intern("arbace.core$drop$step__1927000631")

var Lit_231 *jrt.String = jrt.Intern("arbace.core$drop$fn__1927000633")

var Lit_232 *jrt.String = jrt.Intern("arbace.core$drop$fn__1927000627")

var Lit_233 *jrt.String = jrt.Intern("arbace.core$drop$fn__1927000627$fn__1927000628")

var Lit_234 *jrt.String = jrt.Intern("arbace.core$drop_last$fn__1927000636")

var Lit_235 *jrt.String = jrt.Intern("arbace.core$drop_while$step__1927000644")

var Lit_236 *jrt.String = jrt.Intern("arbace.core$drop_while$fn__1927000646")

var Lit_237 *jrt.String = jrt.Intern("arbace.core$drop_while$fn__1927000640")

var Lit_238 *jrt.String = jrt.Intern("arbace.core$drop_while$fn__1927000640$fn__1927000641")

var Lit_239 *jrt.String = jrt.Intern("arbace.core$elide_top_frames$fn__1927001115")

var Lit_240 *jrt.String = jrt.Intern("arbace.core$emit_defrecord$fn__231000106")

var Lit_241 *jrt.String = jrt.Intern(":volatile-mutable or :unsynchronized-mutable not supported for record fields")

var Lit_242 *jrt.String = jrt.Intern("arbace.core$emit_defrecord$irecord__231000109")

var Lit_243 *jrt.String = jrt.Intern("arbace.core$emit_defrecord$eqhash__231000115")

var Lit_244 *jrt.String = jrt.Intern("arbace.core$emit_defrecord$iobj__231000121")

var Lit_245 *jrt.String = jrt.Intern("arbace.core$emit_defrecord$ilookup__231000127")

var Lit_246 *jrt.String = jrt.Intern("arbace.core$emit_defrecord$imap__231000137")

var Lit_247 *jrt.String = jrt.Intern("arbace.core$emit_defrecord$ijavamap__231000149")

var Lit_248 *jrt.String = jrt.Intern("arbace.core$emit_defrecord$ilookup__231000127$fn__231000131")

var Lit_249 *jrt.String = jrt.Intern("arbace.core$emit_defrecord$ilookup__231000127$fn__231000133")

var Lit_250 *jrt.String = jrt.Intern("Can't create empty: ")

var Lit_251 *jrt.String = jrt.Intern("arbace.core$emit_defrecord$imap__231000137$fn__231000141")

var Lit_252 *jrt.String = jrt.Intern("arbace.core$emit_defrecord$imap__231000137$fn__231000143")

var Lit_253 *jrt.String = jrt.Intern("arbace.core$emit_defrecord$imap__231000137$fn__231000145")

var Lit_254 *jrt.String = jrt.Intern("arbace.core$emit_extend_protocol$fn__231000355")

var Lit_255 *jrt.String = jrt.Intern("arbace.core$emit_hinted_impl$hint__231000332")

var Lit_256 *jrt.String = jrt.Intern("arbace.core$emit_hinted_impl$fn__231000343")

var Lit_257 *jrt.String = jrt.Intern("arbace.core$emit_hinted_impl$fn__231000345")

var Lit_258 *jrt.String = jrt.Intern("arbace.core$emit_hinted_impl$hint__231000332$fn__231000334")

var Lit_259 *jrt.String = jrt.Intern("arbace.core$emit_impl$fn__231000321")

var Lit_260 *jrt.String = jrt.Intern("arbace.core$emit_impl$fn__231000323")

var Lit_261 *jrt.String = jrt.Intern("arbace.core$emit_method_builder$fn__231000240")

var Lit_262 *jrt.String = jrt.Intern("arbace.core$emit_method_builder$fn__231000244")

var Lit_263 *jrt.String = jrt.Intern("arbace.core$emit_method_builder$fn__231000240$fn__231000241")

var Lit_264 *jrt.String = jrt.Intern("gf__")

var Lit_265 *jrt.String = jrt.Intern("__")

var Lit_266 *jrt.String = jrt.Intern("arbace.core$emit_method_builder$fn__231000244$fn__231000245")

var Lit_267 *jrt.String = jrt.Intern("arbace.core$emit_protocol$fn__231000275")

var Lit_268 *jrt.String = jrt.Intern("arbace.core$emit_protocol$fn__231000281")

var Lit_269 *jrt.String = jrt.Intern("arbace.core$emit_protocol$fn__231000290")

var Lit_270 *jrt.String = jrt.Intern("arbace.core$emit_protocol$fn__231000294")

var Lit_271 *jrt.String = jrt.Intern("arbace.core$emit_protocol$fn__231000296")

var Lit_272 *jrt.String = jrt.Intern("arbace.core$emit_protocol$fn__231000275$pred__231000276__231000278")

var Lit_273 *jrt.String = jrt.Intern("arbace.core$emit_protocol$fn__231000281$resolve_class_symbol__231000285")

var Lit_274 *jrt.String = jrt.Intern("arbace.core$emit_protocol$fn__231000281$fn__231000287")

var Lit_275 *jrt.String = jrt.Intern("Definition of function ")

var Lit_276 *jrt.String = jrt.Intern(" in protocol ")

var Lit_277 *jrt.String = jrt.Intern(" must take at least one arg.")

var Lit_278 *jrt.String = jrt.Intern("Function ")

var Lit_279 *jrt.String = jrt.Intern(" was redefined. Specify all arities in single definition.")

var Lit_280 *jrt.String = jrt.Intern("arbace.core$emit_protocol$fn__231000290$fn__231000291")

var Lit_281 *jrt.String = jrt.Intern("arbace.core$eval1769000030$fn__1769000031$fn__1769000032")

var Lit_282 *jrt.String = jrt.Intern("#go ")

var Lit_283 *jrt.String = jrt.Intern("##Inf")

var Lit_284 *jrt.String = jrt.Intern("##-Inf")

var Lit_285 *jrt.String = jrt.Intern("##NaN")

var Lit_286 *jrt.String = jrt.Intern("arbace.core$eval1769000075$fn__1769000076$fn__1769000077")

var Lit_287 *jrt.String = jrt.Intern("arbace.core$eval1769000081$fn__1769000082$fn__1769000083")

var Lit_288 *jrt.String = jrt.Intern("#=(var ")

var Lit_289 *jrt.String = jrt.Intern("/")

var Lit_290 *jrt.String = jrt.Intern(")")

var Lit_291 *jrt.String = jrt.Intern("(")

var Lit_292 *jrt.String = jrt.Intern(" ")

var Lit_293 *jrt.String = jrt.Intern("arbace.core$eval1769000139$fn__1769000140$fn__1769000141")

var Lit_294 *jrt.String = jrt.Intern("[")

var Lit_295 *jrt.String = jrt.Intern("]")

var Lit_296 *jrt.String = jrt.Intern("#=(")

var Lit_297 *jrt.String = jrt.Intern("/create ")

var Lit_298 *jrt.String = jrt.Intern("#:")

var Lit_299 *jrt.String = jrt.Intern("arbace.core$eval1769000201$fn__1769000202$fn__1769000203")

var Lit_300 *jrt.String = jrt.Intern("#{")

var Lit_301 *jrt.String = jrt.Intern("}")

var Lit_302 *jrt.String = jrt.Intern("#")

var Lit_303 *jrt.String = jrt.Intern("#=(identity ")

var Lit_304 *jrt.String = jrt.Intern("#=(java.lang.Class/forName \"")

var Lit_305 *jrt.String = jrt.Intern("\")")

var Lit_306 *jrt.String = jrt.Intern("#=")

var Lit_307 *jrt.String = jrt.Intern("M")

var Lit_308 *jrt.String = jrt.Intern("N")

var Lit_309 *jrt.String = jrt.Intern("#\"")

var Lit_310 *jrt.String = jrt.Intern("\\E\\\"\\Q")

var Lit_311 *jrt.String = jrt.Intern("\\\"")

var Lit_312 *jrt.String = jrt.Intern("#=(find-ns ")

var Lit_313 *jrt.String = jrt.Intern("#?")

var Lit_314 *jrt.String = jrt.Intern("@")

var Lit_315 *jrt.String = jrt.Intern("arbace.core$eval1927001833$fn__1927001834$G__1927001826__1927001836")

var Lit_316 *jrt.String = jrt.Intern("arbace.core$eval1927001833$fn__1927001834$G__1927001825__1927001839")

var Lit_317 *jrt.String = jrt.Intern("inst_ms_STAR_")

var Lit_318 *jrt.String = jrt.Intern("arbace.core$eval1927001870$fn__1927001871$fn__1927001872")

var Lit_319 *jrt.String = jrt.Intern("arbace.core$eval1927002249$fn__1927002250$fn__1927002252")

var Lit_320 *jrt.String = jrt.Intern("arbace.core/tap-loop")

var Lit_321 *jrt.String = jrt.Intern("arbace.core$eval1927002249$fn__1927002250$fn__1927002252$fn__1927002257")

var Lit_322 *jrt.String = jrt.Intern("arbace.core$eval1927002249$fn__1927002250$fn__1927002252$fn__1927002259")

var Lit_323 *jrt.String = jrt.Intern("Argument must be an integer: ")

var Lit_324 *jrt.String = jrt.Intern("arbace.core$every_pred$epn__1927002062")

var Lit_325 *jrt.String = jrt.Intern("arbace.core$every_pred$ep3__1927002058")

var Lit_326 *jrt.String = jrt.Intern("arbace.core$every_pred$ep2__1927002054")

var Lit_327 *jrt.String = jrt.Intern("arbace.core$every_pred$ep1__1927002052")

var Lit_328 *jrt.String = jrt.Intern("arbace.core$every_pred$ep2__1927002054$fn__1927002055")

var Lit_329 *jrt.String = jrt.Intern("arbace.core$every_pred$ep3__1927002058$fn__1927002059")

var Lit_330 *jrt.String = jrt.Intern("arbace.core$every_pred$epn__1927002062$fn__1927002069")

var Lit_331 *jrt.String = jrt.Intern("arbace.core$every_pred$epn__1927002062$fn__1927002067")

var Lit_332 *jrt.String = jrt.Intern("arbace.core$every_pred$epn__1927002062$fn__1927002065")

var Lit_333 *jrt.String = jrt.Intern("arbace.core$every_pred$epn__1927002062$fn__1927002063")

var Lit_334 *jrt.String = jrt.Intern("arbace.core$ex_info")

var Lit_335 *jrt.String = jrt.Intern("arbace.core$expand_method_impl_cache$fn__231000202")

var Lit_336 *jrt.String = jrt.Intern("arbace.core$expand_method_impl_cache$fn__231000211")

var Lit_337 *jrt.String = jrt.Intern(" is not a protocol")

var Lit_338 *jrt.String = jrt.Intern(" already directly implements ")

var Lit_339 *jrt.String = jrt.Intern(" for protocol:")

var Lit_340 *jrt.String = jrt.Intern("arbace.core$file_seq$fn__1927001150")

var Lit_341 *jrt.String = jrt.Intern("arbace.core$file_seq$fn__1927001152")

var Lit_342 *jrt.String = jrt.Intern("arbace.core$filter$fn__1927000603")

var Lit_343 *jrt.String = jrt.Intern("arbace.core$filter$fn__1927000599")

var Lit_344 *jrt.String = jrt.Intern("arbace.core$filter$fn__1927000599$fn__1927000600")

var Lit_345 *jrt.String = jrt.Intern("arbace.core$filterv$fn__1927001895")

var Lit_346 *jrt.String = jrt.Intern("arbace.core$find_protocol_impl$impl__231000220")

var Lit_347 *jrt.String = jrt.Intern("Parameter declaration ")

var Lit_348 *jrt.String = jrt.Intern(" should be a vector")

var Lit_349 *jrt.String = jrt.Intern("arbace.core$fn$psig__1927000991")

var Lit_350 *jrt.String = jrt.Intern("Invalid signature ")

var Lit_351 *jrt.String = jrt.Intern(" should be a list")

var Lit_352 *jrt.String = jrt.Intern("arbace.core$fn$psig__1927000991$fn__1927000995")

var Lit_353 *jrt.String = jrt.Intern("arbace.core$fn$psig__1927000991$fn__1927000997")

var Lit_354 *jrt.String = jrt.Intern("arbace.core$fn__1927001963$parse__1927001964")

var Lit_355 *jrt.String = jrt.Intern("arbace.version")

var Lit_356 *jrt.String = jrt.Intern("getResourceAsStream")

var Lit_357 *jrt.String = jrt.Intern("arbace/version.edn")

var Lit_358 *jrt.String = jrt.Intern("arbace.core$fn__1927001963$fn__1927001968")

var Lit_359 *jrt.String = jrt.Intern("UTF-8")

var Lit_360 *jrt.String = jrt.Intern("arbace.core$fn__1927001963$parse__1927001964$fn__1927001965")

var Lit_361 *jrt.String = jrt.Intern("arbace.core$fnil$fn__1927001689")

var Lit_362 *jrt.String = jrt.Intern("arbace.core$fnil$fn__1927001687")

var Lit_363 *jrt.String = jrt.Intern("arbace.core$fnil$fn__1927001685")

var Lit_364 *jrt.String = jrt.Intern("arbace.core$for$to_groups__1927001040")

var Lit_365 *jrt.String = jrt.Intern("arbace.core$for$err__1927001048")

var Lit_366 *jrt.String = jrt.Intern("arbace.core$for$emit_bind__1927001051")

var Lit_367 *jrt.String = jrt.Intern("iter__")

var Lit_368 *jrt.String = jrt.Intern("s__")

var Lit_369 *jrt.String = jrt.Intern("arbace.core$for$emit_bind__1927001051$do_mod__1927001065")

var Lit_370 *jrt.String = jrt.Intern("i__")

var Lit_371 *jrt.String = jrt.Intern("b__")

var Lit_372 *jrt.String = jrt.Intern("arbace.core$for$emit_bind__1927001051$do_cmod__1927001074")

var Lit_373 *jrt.String = jrt.Intern("Invalid 'for' keyword ")

var Lit_374 *jrt.String = jrt.Intern("arbace.core$for$to_groups__1927001040$fn__1927001042")

var Lit_375 *jrt.String = jrt.Intern("format")

var Lit_376 *jrt.String = jrt.Intern("arbace.core$frequencies$fn__1927001994")

var Lit_377 *jrt.String = jrt.Intern("arbace.core$gen_interface$fn__750000018")

var Lit_378 *jrt.String = jrt.Intern("Interface methods must not contain '-'")

var Lit_379 *jrt.String = jrt.Intern("G__")

var Lit_380 *jrt.String = jrt.Intern("arbace.core$group_by$fn__1927001979")

var Lit_381 *jrt.String = jrt.Intern("arbace.core$group_by_sig$fn__840000030")

var Lit_382 *jrt.String = jrt.Intern("arbace.core$halt_when$fn__1927002181")

var Lit_383 *jrt.String = jrt.Intern("arbace.core$halt_when$fn__1927002181$fn__1927002182")

var Lit_384 *jrt.String = jrt.Intern("arbace.core$import$fn__1927000728")

var Lit_385 *jrt.String = jrt.Intern("arbace.core$import$fn__1927000730")

var Lit_386 *jrt.String = jrt.Intern("arbace.core$import$fn__1927000732")

var Lit_387 *jrt.String = jrt.Intern("arbace.core$import$fn__1927000732$fn__1927000733")

var Lit_388 *jrt.String = jrt.Intern("arbace.core$interleave$fn__1927000929")

var Lit_389 *jrt.String = jrt.Intern("arbace.core$interleave$fn__1927000927")

var Lit_390 *jrt.String = jrt.Intern("arbace.core$interleave$fn__1927000925")

var Lit_391 *jrt.String = jrt.Intern("arbace.core$interpose$fn__1927001226")

var Lit_392 *jrt.String = jrt.Intern("arbace.core$interpose$fn__1927001226$fn__1927001227")

var Lit_393 *jrt.String = jrt.Intern("arbace.core$into$rf__1927001885")

var Lit_394 *jrt.String = jrt.Intern("I/O in transaction")

var Lit_395 *jrt.String = jrt.Intern("arbace.core$isa_QMARK_$fn__1927001413")

var Lit_396 *jrt.String = jrt.Intern("arbace.core$iteration$reify__1927002219$next__1927002220")

var Lit_397 *jrt.String = jrt.Intern("arbace.core$iteration$reify__1927002219$next__1927002220$fn__1927002221")

var Lit_398 *jrt.String = jrt.Intern("arbace.core$juxt$fn__1927000538")

var Lit_399 *jrt.String = jrt.Intern("arbace.core$juxt$fn__1927000536")

var Lit_400 *jrt.String = jrt.Intern("arbace.core$juxt$fn__1927000534")

var Lit_401 *jrt.String = jrt.Intern("arbace.core$juxt$fn__1927000532")

var Lit_402 *jrt.String = jrt.Intern("arbace.core$juxt$fn__1927000538$fn__1927000547")

var Lit_403 *jrt.String = jrt.Intern("arbace.core$juxt$fn__1927000538$fn__1927000545")

var Lit_404 *jrt.String = jrt.Intern("arbace.core$juxt$fn__1927000538$fn__1927000543")

var Lit_405 *jrt.String = jrt.Intern("arbace.core$juxt$fn__1927000538$fn__1927000541")

var Lit_406 *jrt.String = jrt.Intern("arbace.core$juxt$fn__1927000538$fn__1927000539")

var Lit_407 *jrt.String = jrt.Intern("arbace.core$keep$fn__1927002033")

var Lit_408 *jrt.String = jrt.Intern("arbace.core$keep$fn__1927002029")

var Lit_409 *jrt.String = jrt.Intern("arbace.core$keep$fn__1927002029$fn__1927002030")

var Lit_410 *jrt.String = jrt.Intern("arbace.core$keep_indexed$keepi__1927002040")

var Lit_411 *jrt.String = jrt.Intern("arbace.core$keep_indexed$fn__1927002036")

var Lit_412 *jrt.String = jrt.Intern("arbace.core$keep_indexed$fn__1927002036$fn__1927002037")

var Lit_413 *jrt.String = jrt.Intern("arbace.core$keep_indexed$keepi__1927002040$fn__1927002041")

var Lit_414 *jrt.String = jrt.Intern("arbace.core$lazy_cat$fn__1927001028")

var Lit_415 *jrt.String = jrt.Intern("arbace.core$letfn$fn__1927001678")

var Lit_416 *jrt.String = jrt.Intern("arbace.core$line_seq$fn__1927000656")

var Lit_417 *jrt.String = jrt.Intern("(arbace.core/load \"%s\")\n")

var Lit_418 *jrt.String = jrt.Intern("arbace.core$load$fn__1927001573")

var Lit_419 *jrt.String = jrt.Intern("arbace.core$load$fn__1927001575")

var Lit_420 *jrt.String = jrt.Intern("arbace.core$load_all$fn__1927001523")

var Lit_421 *jrt.String = jrt.Intern("arbace.core$load_all$fn__1927001523$fn__1927001524")

var Lit_422 *jrt.String = jrt.Intern("arbace.core$load_all$fn__1927001523$fn__1927001526")

var Lit_423 *jrt.String = jrt.Intern("cljc")

var Lit_424 *jrt.String = jrt.Intern("Not a valid data-reader map")

var Lit_425 *jrt.String = jrt.Intern("arbace.core$load_data_reader_file$fn__1927002233")

var Lit_426 *jrt.String = jrt.Intern("Invalid form in data-reader file")

var Lit_427 *jrt.String = jrt.Intern("Conflicting data-reader mapping")

var Lit_428 *jrt.String = jrt.Intern("arbace.core$load_data_readers$fn__1927002239")

var Lit_429 *jrt.String = jrt.Intern("Found lib name '%s' containing period with prefix '%s'.  lib names inside prefix lists must not contain periods")

var Lit_430 *jrt.String = jrt.Intern("arbace.core$load_lib$fn__1927001532")

var Lit_431 *jrt.String = jrt.Intern("arbace.core$load_lib$fn__1927001534")

var Lit_432 *jrt.String = jrt.Intern("namespace '%s' not found")

var Lit_433 *jrt.String = jrt.Intern("(arbace.core/in-ns '%s)\n")

var Lit_434 *jrt.String = jrt.Intern("(arbace.core/alias '%s '%s)\n")

var Lit_435 *jrt.String = jrt.Intern("(arbace.core/refer '%s")

var Lit_436 *jrt.String = jrt.Intern(" %s '%s")

var Lit_437 *jrt.String = jrt.Intern(")\n")

var Lit_438 *jrt.String = jrt.Intern("Unsupported option(s) supplied: ")

var Lit_439 *jrt.String = jrt.Intern("Nothing specified to load")

var Lit_440 *jrt.String = jrt.Intern("prefix cannot be nil")

var Lit_441 *jrt.String = jrt.Intern("namespace '%s' not found after loading '%s'")

var Lit_442 *jrt.String = jrt.Intern("arbace.core$load_one$fn__1927001518")

var Lit_443 *jrt.String = jrt.Intern("arbace.core$loop$fn__1927001005")

var Lit_444 *jrt.String = jrt.Intern("arbace.core$loop$fn__1927001008")

var Lit_445 *jrt.String = jrt.Intern("arbace.core$map$step__1927000583")

var Lit_446 *jrt.String = jrt.Intern("arbace.core$map$fn__1927000587")

var Lit_447 *jrt.String = jrt.Intern("arbace.core$map$fn__1927000581")

var Lit_448 *jrt.String = jrt.Intern("arbace.core$map$fn__1927000579")

var Lit_449 *jrt.String = jrt.Intern("arbace.core$map$fn__1927000577")

var Lit_450 *jrt.String = jrt.Intern("arbace.core$map$fn__1927000573")

var Lit_451 *jrt.String = jrt.Intern("arbace.core$map$fn__1927000573$fn__1927000574")

var Lit_452 *jrt.String = jrt.Intern("arbace.core$map$step__1927000583$fn__1927000584")

var Lit_453 *jrt.String = jrt.Intern("arbace.core$map_indexed$mapi__1927002024")

var Lit_454 *jrt.String = jrt.Intern("arbace.core$map_indexed$fn__1927002020")

var Lit_455 *jrt.String = jrt.Intern("arbace.core$map_indexed$fn__1927002020$fn__1927002021")

var Lit_456 *jrt.String = jrt.Intern("arbace.core$map_indexed$mapi__1927002024$fn__1927002025")

var Lit_457 *jrt.String = jrt.Intern("arbace.core$mapv$fn__1927001892")

var Lit_458 *jrt.String = jrt.Intern("p__")

var Lit_459 *jrt.String = jrt.Intern("arbace.core$maybe_min_hash$fn__1927001696")

var Lit_460 *jrt.String = jrt.Intern("arbace.core$maybe_min_hash$iter__1927001703__1927001709")

var Lit_461 *jrt.String = jrt.Intern("arbace.core$maybe_min_hash$fn__1927001719")

var Lit_462 *jrt.String = jrt.Intern("arbace.core$maybe_min_hash$fn__1927001696$fn__1927001700")

var Lit_463 *jrt.String = jrt.Intern("arbace.core$maybe_min_hash$iter__1927001703__1927001709$fn__1927001710")

var Lit_464 *jrt.String = jrt.Intern("arbace.core$maybe_min_hash$iter__1927001703__1927001709$fn__1927001710$iter__1927001705__1927001711")

var Lit_465 *jrt.String = jrt.Intern("arbace.core$maybe_min_hash$iter__1927001703__1927001709$fn__1927001710$iter__1927001705__1927001711$fn__1927001712")

var Lit_466 *jrt.String = jrt.Intern("arbace.core$maybe_min_hash$iter__1927001703__1927001709$fn__1927001710$iter__1927001705__1927001711$fn__1927001712$fn__1927001713")

var Lit_467 *jrt.String = jrt.Intern("target")

var Lit_468 *jrt.String = jrt.Intern("arbace.core$memoize$fn__1927001613")

var Lit_469 *jrt.String = jrt.Intern("arbace.core$merge_deep$fn__1927001901")

var Lit_470 *jrt.String = jrt.Intern("arbace.core$merge_deep_with$fn__1927001904")

var Lit_471 *jrt.String = jrt.Intern("arbace.core$merge_hash_collisions$fn__1927001732")

var Lit_472 *jrt.String = jrt.Intern("arbace.core$merge_hash_collisions$assoc_multi__1927001734")

var Lit_473 *jrt.String = jrt.Intern("arbace.core$merge_hash_collisions$fn__1927001739")

var Lit_474 *jrt.String = jrt.Intern("arbace.core$merge_hash_collisions$fn__1927001744")

var Lit_475 *jrt.String = jrt.Intern("arbace.core$merge_hash_collisions$assoc_multi__1927001734$fn__1927001735")

var Lit_476 *jrt.String = jrt.Intern("arbace.core$merge_with$merge2__1927000720")

var Lit_477 *jrt.String = jrt.Intern("arbace.core$merge_with$this__1927000714")

var Lit_478 *jrt.String = jrt.Intern("arbace.core$merge_with$this__1927000716")

var Lit_479 *jrt.String = jrt.Intern("arbace.core$merge_with$fn__1927000718")

var Lit_480 *jrt.String = jrt.Intern("s")

var Lit_481 *jrt.String = jrt.Intern("-array")

var Lit_482 *jrt.String = jrt.Intern("arbace.core$mk_bound_fn$fn__1927001204")

var Lit_483 *jrt.String = jrt.Intern("arbace.core$most_specific$fn__840000024")

var Lit_484 *jrt.String = jrt.Intern("Incompatible return types")

var Lit_485 *jrt.String = jrt.Intern("arbace.core$most_specific$fn__840000024$fn__840000025")

var Lit_486 *jrt.String = jrt.Intern("arbace.core$nary_inline$fn__1927000203")

var Lit_487 *jrt.String = jrt.Intern("arbace.core$nary_inline$fn__1927000203$fn__1927000204")

var Lit_488 *jrt.String = jrt.Intern("WARNING: (slurp f enc) is deprecated, use (slurp f :encoding enc).")

var Lit_489 *jrt.String = jrt.Intern("arbace.core$ns$process_reference__1927001475")

var Lit_490 *jrt.String = jrt.Intern("arbace.core$ns$fn__1927001482")

var Lit_491 *jrt.String = jrt.Intern("arbace.core$ns$fn__1927001484")

var Lit_492 *jrt.String = jrt.Intern("arbace.core$ns$fn__1927001486")

var Lit_493 *jrt.String = jrt.Intern("arbace.core")

var Lit_494 *jrt.String = jrt.Intern("arbace.core$ns$process_reference__1927001475$fn__1927001479")

var Lit_495 *jrt.String = jrt.Intern("arbace.core$ns_interns$fn__1927000904")

var Lit_496 *jrt.String = jrt.Intern("arbace.core$ns_publics$fn__1927000900")

var Lit_497 *jrt.String = jrt.Intern("arbace.core$ns_refers$fn__1927000912")

var Lit_498 *jrt.String = jrt.Intern("arbace.core$nthrest$fn__1927000669")

var Lit_499 *jrt.String = jrt.Intern("true")

var Lit_500 *jrt.String = jrt.Intern("false")

var Lit_501 *jrt.String = jrt.Intern("arbace.core$parse_opts_PLUS_specs$fn__231000036")

var Lit_502 *jrt.String = jrt.Intern("arbace.core$parse_opts_PLUS_specs$fn__231000039")

var Lit_503 *jrt.String = jrt.Intern("Unsupported option(s) -")

var Lit_504 *jrt.String = jrt.Intern("Expected string, got ")

var Lit_505 *jrt.String = jrt.Intern("arbace.core$partial$fn__1927000557")

var Lit_506 *jrt.String = jrt.Intern("arbace.core$partial$fn__1927000555")

var Lit_507 *jrt.String = jrt.Intern("arbace.core$partial$fn__1927000553")

var Lit_508 *jrt.String = jrt.Intern("arbace.core$partial$fn__1927000551")

var Lit_509 *jrt.String = jrt.Intern("arbace.core$partition$fn__1927000674")

var Lit_510 *jrt.String = jrt.Intern("arbace.core$partition$fn__1927000672")

var Lit_511 *jrt.String = jrt.Intern("arbace.core$partition_all$fn__1927002007")

var Lit_512 *jrt.String = jrt.Intern("arbace.core$partition_all$fn__1927002003")

var Lit_513 *jrt.String = jrt.Intern("arbace.core$partition_all$fn__1927002003$fn__1927002004")

var Lit_514 *jrt.String = jrt.Intern("arbace.core$partition_by$fn__1927001987")

var Lit_515 *jrt.String = jrt.Intern("arbace.core$partition_by$fn__1927001983")

var Lit_516 *jrt.String = jrt.Intern("arbace.core$partition_by$fn__1927001983$fn__1927001984")

var Lit_517 *jrt.String = jrt.Intern("arbace.core$partition_by$fn__1927001987$fn__1927001988")

var Lit_518 *jrt.String = jrt.Intern("arbace.core$partition_by$fn__1927001987$fn__1927001990")

var Lit_519 *jrt.String = jrt.Intern("arbace.core$partitionv$fn__1927002013")

var Lit_520 *jrt.String = jrt.Intern("arbace.core$partitionv$fn__1927002011")

var Lit_521 *jrt.String = jrt.Intern("arbace.core$partitionv_all$fn__1927002016")

var Lit_522 *jrt.String = jrt.Intern("arbace.core$pcalls$fn__1927001944")

var Lit_523 *jrt.String = jrt.Intern("arbace.core$pmap$step__1927001936")

var Lit_524 *jrt.String = jrt.Intern("arbace.core$pmap$fn__1927001940")

var Lit_525 *jrt.String = jrt.Intern("arbace.core$pmap$fn__1927001924")

var Lit_526 *jrt.String = jrt.Intern("arbace.core$pmap$step__1927001929")

var Lit_527 *jrt.String = jrt.Intern("arbace.core$pmap$fn__1927001924$fn__1927001925")

var Lit_528 *jrt.String = jrt.Intern("arbace.core$pmap$step__1927001929$fn__1927001933")

var Lit_529 *jrt.String = jrt.Intern("arbace.core$pmap$step__1927001936$fn__1927001937")

var Lit_530 *jrt.String = jrt.Intern("arbace.core$prep_hashes$hashcode__1927001750")

var Lit_531 *jrt.String = jrt.Intern("arbace.core$prep_hashes$fn__1927001755")

var Lit_532 *jrt.String = jrt.Intern("arbace.core$prep_hashes$fn__1927001763")

var Lit_533 *jrt.String = jrt.Intern("arbace.core$prep_ints$fn__1927001728")

var Lit_534 *jrt.String = jrt.Intern("arbace.core$preserving_reduced$fn__1927002175")

var Lit_535 *jrt.String = jrt.Intern(". ")

var Lit_536 *jrt.String = jrt.Intern("^")

var Lit_537 *jrt.String = jrt.Intern("{")

var Lit_538 *jrt.String = jrt.Intern("arbace.core$print_prefix_map$fn__1769000164")

var Lit_539 *jrt.String = jrt.Intern("...")

var Lit_540 *jrt.String = jrt.Intern("#object[")

var Lit_541 *jrt.String = jrt.Intern("0x%x ")

var Lit_542 *jrt.String = jrt.Intern("#error {\n :cause ")

var Lit_543 *jrt.String = jrt.Intern("arbace.core$print_throwable$print_via__1769000367")

var Lit_544 *jrt.String = jrt.Intern("\n :data ")

var Lit_545 *jrt.String = jrt.Intern("\n :via\n [")

var Lit_546 *jrt.String = jrt.Intern("\n  ")

var Lit_547 *jrt.String = jrt.Intern("\n :trace\n [")

var Lit_548 *jrt.String = jrt.Intern("{:type ")

var Lit_549 *jrt.String = jrt.Intern("\n   :message ")

var Lit_550 *jrt.String = jrt.Intern("\n   :data ")

var Lit_551 *jrt.String = jrt.Intern("\n   :at ")

var Lit_552 *jrt.String = jrt.Intern("arbace.core$proxy$fn__840000146")

var Lit_553 *jrt.String = jrt.Intern("arbace.core$proxy$fn__840000148")

var Lit_554 *jrt.String = jrt.Intern("arbace.core$proxy$fn__840000150")

var Lit_555 *jrt.String = jrt.Intern("Can't resolve: ")

var Lit_556 *jrt.String = jrt.Intern("arbace.core$proxy$fn__840000150$fn__840000155")

var Lit_557 *jrt.String = jrt.Intern("Method '")

var Lit_558 *jrt.String = jrt.Intern("' redefined")

var Lit_559 *jrt.String = jrt.Intern("arbace.core$proxy_method_fn$fn__840000089")

var Lit_560 *jrt.String = jrt.Intern("arbace.core$proxy_method_fn$fn__840000091")

var Lit_561 *jrt.String = jrt.Intern("arbace.core$proxy_methods$fn__840000053")

var Lit_562 *jrt.String = jrt.Intern("arbace.core$proxy_methods$iter__840000060__840000066")

var Lit_563 *jrt.String = jrt.Intern("arbace.core$proxy_methods$abstract_QMARK___840000077")

var Lit_564 *jrt.String = jrt.Intern("arbace.core$proxy_methods$fn__840000082")

var Lit_565 *jrt.String = jrt.Intern("arbace.core$proxy_methods$fn__840000084")

var Lit_566 *jrt.String = jrt.Intern("arbace.core$proxy_methods$fn__840000086")

var Lit_567 *jrt.String = jrt.Intern("arbace.core$proxy_methods$fn__840000053$fn__840000057")

var Lit_568 *jrt.String = jrt.Intern("finalize")

var Lit_569 *jrt.String = jrt.Intern("arbace.core$proxy_methods$iter__840000060__840000066$fn__840000067")

var Lit_570 *jrt.String = jrt.Intern("arbace.core$proxy_methods$iter__840000060__840000066$fn__840000067$iter__840000062__840000068")

var Lit_571 *jrt.String = jrt.Intern("arbace.core$proxy_methods$iter__840000060__840000066$fn__840000067$iter__840000062__840000068$fn__840000069")

var Lit_572 *jrt.String = jrt.Intern("arbace.core$proxy_methods$iter__840000060__840000066$fn__840000067$iter__840000062__840000068$fn__840000069$fn__840000070")

var Lit_573 *jrt.String = jrt.Intern("arbace.core$proxy_name$fn__840000038")

var Lit_574 *jrt.String = jrt.Intern(".proxy")

var Lit_575 *jrt.String = jrt.Intern("$")

var Lit_576 *jrt.String = jrt.Intern("arbace.core$proxy_name$fn__840000040")

var Lit_577 *jrt.String = jrt.Intern("arbace.core$pvalues$fn__1927001948")

var Lit_578 *jrt.String = jrt.Intern("arbace.core$random_sample$fn__1927002193")

var Lit_579 *jrt.String = jrt.Intern("arbace.core$random_sample$fn__1927002191")

var Lit_580 *jrt.String = jrt.Intern("arbace.core$re_seq$step__1927001131")

var Lit_581 *jrt.String = jrt.Intern("arbace.core$re_seq$step__1927001131$fn__1927001132")

var Lit_582 *jrt.String = jrt.Intern("arbace.core$reductions$fn__1927001999")

var Lit_583 *jrt.String = jrt.Intern("arbace.core$reductions$fn__1927001997")

var Lit_584 *jrt.String = jrt.Intern("No namespace: ")

var Lit_585 *jrt.String = jrt.Intern(":only/:refer value must be a sequential collection of symbols")

var Lit_586 *jrt.String = jrt.Intern(" is not public")

var Lit_587 *jrt.String = jrt.Intern(" does not exist")

var Lit_588 *jrt.String = jrt.Intern("arbace.core$repeatedly$fn__1927000943")

var Lit_589 *jrt.String = jrt.Intern("arbace.core$replace$fn__1927001186")

var Lit_590 *jrt.String = jrt.Intern("arbace.core$replace$fn__1927001188")

var Lit_591 *jrt.String = jrt.Intern("arbace.core$replace$fn__1927001184")

var Lit_592 *jrt.String = jrt.Intern("Not a qualified symbol: ")

var Lit_593 *jrt.String = jrt.Intern("java.sql.ResultSet")

var Lit_594 *jrt.String = jrt.Intern("getMetaData")

var Lit_595 *jrt.String = jrt.Intern("java.sql.ResultSetMetaData")

var Lit_596 *jrt.String = jrt.Intern("getColumnCount")

var Lit_597 *jrt.String = jrt.Intern("arbace.core$resultset_seq$fn__1927001447")

var Lit_598 *jrt.String = jrt.Intern("arbace.core$resultset_seq$fn__1927001449")

var Lit_599 *jrt.String = jrt.Intern("ResultSet must have unique column labels")

var Lit_600 *jrt.String = jrt.Intern("arbace.core$resultset_seq$row_values__1927001451")

var Lit_601 *jrt.String = jrt.Intern("arbace.core$resultset_seq$thisfn__1927001455")

var Lit_602 *jrt.String = jrt.Intern("getColumnLabel")

var Lit_603 *jrt.String = jrt.Intern("arbace.core$resultset_seq$row_values__1927001451$fn__1927001452")

var Lit_604 *jrt.String = jrt.Intern("getObject")

var Lit_605 *jrt.String = jrt.Intern("next")

var Lit_606 *jrt.String = jrt.Intern("arbace.core$resultset_seq$thisfn__1927001455$fn__1927001456")

var Lit_607 *jrt.String = jrt.Intern("arbace.core$run_BANG_$fn__1927002208")

var Lit_608 *jrt.String = jrt.Intern("arbace.core$select_keys$this__1927001898")

var Lit_609 *jrt.String = jrt.Intern("expected a map")

var Lit_610 *jrt.String = jrt.Intern("form must contain at least one of :select :excess :missing :all")

var Lit_611 *jrt.String = jrt.Intern("selector")

var Lit_612 *jrt.String = jrt.Intern("arbace.core$send_via$fn__1927000464")

var Lit_613 *jrt.String = jrt.Intern("arbace.core$seque$fn__1927001377")

var Lit_614 *jrt.String = jrt.Intern("arbace.core$seque$log_error__1927001379")

var Lit_615 *jrt.String = jrt.Intern("arbace.core$seque$fill__1927001381")

var Lit_616 *jrt.String = jrt.Intern("arbace.core$seque$drain__1927001393")

var Lit_617 *jrt.String = jrt.Intern("arbace.core$seque$drain__1927001393$fn__1927001394")

var Lit_618 *jrt.String = jrt.Intern("offer")

var Lit_619 *jrt.String = jrt.Intern("arbace.core$sequence$fn__1927000561")

var Lit_620 *jrt.String = jrt.Intern("arbace.core$sigs$asig__1927000049")

var Lit_621 *jrt.String = jrt.Intern("arbace.core$sigs$resolve_tag__1927000051")

var Lit_622 *jrt.String = jrt.Intern("arbace.core$some__GT_$fn__1927002159")

var Lit_623 *jrt.String = jrt.Intern("arbace.core$some__GT__GT_$fn__1927002166")

var Lit_624 *jrt.String = jrt.Intern("arbace.core$some_fn$spn__1927002089")

var Lit_625 *jrt.String = jrt.Intern("arbace.core$some_fn$sp3__1927002085")

var Lit_626 *jrt.String = jrt.Intern("arbace.core$some_fn$sp2__1927002081")

var Lit_627 *jrt.String = jrt.Intern("arbace.core$some_fn$sp1__1927002079")

var Lit_628 *jrt.String = jrt.Intern("arbace.core$some_fn$sp2__1927002081$fn__1927002082")

var Lit_629 *jrt.String = jrt.Intern("arbace.core$some_fn$sp3__1927002085$fn__1927002086")

var Lit_630 *jrt.String = jrt.Intern("arbace.core$some_fn$spn__1927002089$fn__1927002096")

var Lit_631 *jrt.String = jrt.Intern("arbace.core$some_fn$spn__1927002089$fn__1927002094")

var Lit_632 *jrt.String = jrt.Intern("arbace.core$some_fn$spn__1927002089$fn__1927002092")

var Lit_633 *jrt.String = jrt.Intern("arbace.core$some_fn$spn__1927002089$fn__1927002090")

var Lit_634 *jrt.String = jrt.Intern("arbace.core$some_vals$fn__1927000948")

var Lit_635 *jrt.String = jrt.Intern("arbace.core$sort_by$fn__1927000663")

var Lit_636 *jrt.String = jrt.Intern("arbace.core$str$fn__1927000104")

var Lit_637 *jrt.String = jrt.Intern("")

var Lit_638 *jrt.String = jrt.Intern("no conversion to symbol")

var Lit_639 *jrt.String = jrt.Intern("arbace.core$take$fn__1927000617")

var Lit_640 *jrt.String = jrt.Intern("arbace.core$take$fn__1927000613")

var Lit_641 *jrt.String = jrt.Intern("arbace.core$take$fn__1927000613$fn__1927000614")

var Lit_642 *jrt.String = jrt.Intern("arbace.core$take_nth$fn__1927000922")

var Lit_643 *jrt.String = jrt.Intern("arbace.core$take_nth$fn__1927000918")

var Lit_644 *jrt.String = jrt.Intern("arbace.core$take_nth$fn__1927000918$fn__1927000919")

var Lit_645 *jrt.String = jrt.Intern("arbace.core$take_while$fn__1927000624")

var Lit_646 *jrt.String = jrt.Intern("arbace.core$take_while$fn__1927000620")

var Lit_647 *jrt.String = jrt.Intern("arbace.core$take_while$fn__1927000620$fn__1927000621")

var Lit_648 *jrt.String = jrt.Intern("java.lang.")

var Lit_649 *jrt.String = jrt.Intern(" found")

var Lit_650 *jrt.String = jrt.Intern("arbace.core$thread_bound_QMARK_$fn__1927001405")

var Lit_651 *jrt.String = jrt.Intern("arbace.core$throw_if$boring_QMARK___1927001511")

var Lit_652 *jrt.String = jrt.Intern("doInvoke")

var Lit_653 *jrt.String = jrt.Intern("Elapsed time: ")

var Lit_654 *jrt.String = jrt.Intern(" msecs")

var Lit_655 *jrt.String = jrt.Intern("[Ljava.lang.Object;")

var Lit_656 *jrt.String = jrt.Intern("aset")

var Lit_657 *jrt.String = jrt.Intern("arbace.core$trampoline$fn__1927001604")

var Lit_658 *jrt.String = jrt.Intern("arbace.core$tree_seq$walk__1927001145")

var Lit_659 *jrt.String = jrt.Intern("arbace.core$tree_seq$walk__1927001145$fn__1927001146")

var Lit_660 *jrt.String = jrt.Intern("arbace.core$underive$fn__1927001430")

var Lit_661 *jrt.String = jrt.Intern("arbace.core$underive$fn__1927001432")

var Lit_662 *jrt.String = jrt.Intern("arbace.core$update_in$up__1927001587")

var Lit_663 *jrt.String = jrt.Intern("arbace.core$update_keys$fn__1927002272")

var Lit_664 *jrt.String = jrt.Intern("arbace.core$update_vals$fn__1927002269")

var Lit_665 *jrt.String = jrt.Intern("No fields vector given.")

var Lit_666 *jrt.String = jrt.Intern("The names in ")

var Lit_667 *jrt.String = jrt.Intern(" cannot be used as field names for types or records.")

var Lit_668 *jrt.String = jrt.Intern("defrecord and deftype fields must be symbols, ")

var Lit_669 *jrt.String = jrt.Intern(" had: ")

var Lit_670 *jrt.String = jrt.Intern("array")

var Lit_671 *jrt.String = jrt.Intern("with-open only allows Symbols in bindings")

var Lit_672 *jrt.String = jrt.Intern("arbace.core$with_redefs$fn__1927002124")

var Lit_673 *jrt.String = jrt.Intern("arbace.core$with_redefs_fn$root_bind__1927002108")

var Lit_674 *jrt.String = jrt.Intern("arbace.core$with_redefs_fn$fn__1927002120")

var Lit_675 *jrt.String = jrt.Intern("am")

var Lit_676 *jrt.String = jrt.Intern("tag")

var Lit_677 *jrt.String = jrt.Intern("arbace.core.ArrayManager")

var Lit_678 *jrt.String = jrt.Intern("arr")

var Lit_679 *jrt.String = jrt.Intern("off")

var Lit_680 *jrt.String = jrt.Intern("int")

var Lit_681 *jrt.String = jrt.Intern("end")

var Lit_682 *jrt.String = jrt.Intern("dropFirst of empty chunk")

var Lit_683 *jrt.String = jrt.Intern("v11,arbace.core9,transducev11,arbace.core10,completing")

var Lit_684 *jrt.String = jrt.Intern("xform")

var Lit_685 *jrt.String = jrt.Intern("coll")

var Lit_686 *jrt.String = jrt.Intern("kn4,elseR0,l0,v11,arbace.core6,subvecl-1,v11,arbace.core3,seqv11,arbace.core10,EMPTY-NODEl32,l1,v11,arbace.core4,castC29,arbace.lang.IPersistentVectorv11,arbace.core10,into-arrayC16,java.lang.Objectv11,arbace.core6,every?v11,arbace.core4,some")

var Lit_687 *jrt.String = jrt.Intern("cnt")

var Lit_688 *jrt.String = jrt.Intern("shift")

var Lit_689 *jrt.String = jrt.Intern("root")

var Lit_690 *jrt.String = jrt.Intern("arbace.core.VecNode")

var Lit_691 *jrt.String = jrt.Intern("tail")

var Lit_692 *jrt.String = jrt.Intern("_meta")

var Lit_693 *jrt.String = jrt.Intern("tailoff")

var Lit_694 *jrt.String = jrt.Intern("doAssoc")

var Lit_695 *jrt.String = jrt.Intern("arrayFor")

var Lit_696 *jrt.String = jrt.Intern("Key must be integer")

var Lit_697 *jrt.String = jrt.Intern("newPath")

var Lit_698 *jrt.String = jrt.Intern("pushTail")

var Lit_699 *jrt.String = jrt.Intern("arbace.core.Vec$fn__57000046")

var Lit_700 *jrt.String = jrt.Intern("arbace.core.Vec$fn__57000044")

var Lit_701 *jrt.String = jrt.Intern("popTail")

var Lit_702 *jrt.String = jrt.Intern("Can't pop empty vector")

var Lit_703 *jrt.String = jrt.Intern("edit")

var Lit_704 *jrt.String = jrt.Intern("kn4,elsev11,arbace.core5,derefv11,arbace.core3,seqv11,arbace.core5,firstR0,v11,arbace.core4,next")

var Lit_705 *jrt.String = jrt.Intern("vec")

var Lit_706 *jrt.String = jrt.Intern("arbace.core.IVecImpl")

var Lit_707 *jrt.String = jrt.Intern("anode")

var Lit_708 *jrt.String = jrt.Intern("i")

var Lit_709 *jrt.String = jrt.Intern("offset")

var Lit_710 *jrt.String = jrt.Intern("arbace.lang.IPersistentMap")

var Lit_711 *jrt.String = jrt.Intern("arbace.core.VecSeq$fn__57000031")

var Lit_712 *jrt.String = jrt.Intern("kn3,dockn6,authorkn4,linekn6,columnkn4,filekn8,arglistsyn1,&yn5,itemskn5,addedyn1,xyn3,seqkn6,statickn5,macroyn4,collkn3,tagyn2,xsyn16,arbace.lang.ISeqyn5,Classyn3,mapyn3,keyyn3,valyn3,kvsyn3,objkn6,inlineyn16,arbace.lang.IObjyn1,mkn7,privatekn7,dynamicyn4,nameyn11,doc-string?yn9,attr-map?yn7,params*yn12,prepost-map?yn4,bodyyn1,+yn1,ayn1,byn1,cyn1,dyn1,eyn1,fyn4,argsyn7,keyvalsyn4,keysyn10,comparatoryn4,testyn16,java.lang.Stringyn6,Objectyn2,ysyn7,clausesyn2,nsyn13,prefix-stringyn7,arglistyn4,moreyn15,arbace.lang.IFnyn1,yyn1,zyn8,capacityyn23,arbace.lang.ChunkBufferyn23,arbace.lang.IChunkedSeqyn18,arbace.lang.IChunkyn5,chunkyn4,restyn1,syn2,zsyn4,thenyn4,elsekn14,inline-aritiesyn4,nextN11,arbace.coreMyn11,arbace.corem4,R0,s26,The core Clojure language.R1,s11,Rich Hickeyv11,arbace.core7,unquotem6,R2,i13,R3,i1,R4,s14,arbace/core.aev11,arbace.core16,unquote-splicingm6,R2,i14,R3,i1,R4,s14,arbace/core.aev11,arbace.core4,listm12,R5,ML1,V2,R6,R7,m4,R2,i17,R3,i15,R0,s40,Creates a new list containing the items.R8,s3,1.0R2,i16,R3,i1,R4,s14,arbace/core.aev11,arbace.core4,consm14,R5,ML1,V2,R9,R10,m4,R2,i23,R3,i15,R0,s71,Returns a new seq where x is the first element and seq is\n    the rest.R8,s3,1.0R11,TR2,i22,R3,i1,R4,s14,arbace/core.aev11,arbace.core3,letm10,R12,TR8,s3,1.0R2,i32,R3,i1,R4,s14,arbace/core.aev11,arbace.core4,loopm10,R12,TR8,s3,1.0R2,i37,R3,i1,R4,s14,arbace/core.aev11,arbace.core2,fnm10,R12,TR8,s3,1.0R2,i42,R3,i1,R4,s14,arbace/core.aev11,arbace.core5,firstm14,R5,ML1,V1,R13,m4,R2,i50,R3,i15,R0,s101,Returns the first item in the collection. Calls seq on its\n    argument. If coll is nil, returns nil.R8,s3,1.0R11,TR2,i49,R3,i1,R4,s14,arbace/core.aev11,arbace.core4,nextm16,R5,ML1,V1,R13,m4,R2,i58,R3,i15,R14,C16,arbace.lang.ISeqR0,s114,Returns a seq of the items after the first. Calls seq on its\n  argument.  If there are no more items, returns nil.R8,s3,1.0R11,TR2,i57,R3,i1,R4,s14,arbace/core.aev11,arbace.core4,restm16,R5,ML1,V1,R13,m4,R2,i67,R3,i15,R14,C16,arbace.lang.ISeqR0,s87,Returns a possibly empty seq of the items after the first. Calls seq on its\n  argument.R8,s3,1.0R11,TR2,i66,R3,i1,R4,s14,arbace/core.aev11,arbace.core4,conjm14,R5,ML4,V0,V1,R13,V2,R13,R9,V4,R13,R9,R6,R15,m4,R2,i76,R3,i15,R0,s229,conj[oin]. Returns a new collection with the xs\n    'added'. (conj nil item) returns (item).\n    (conj coll) returns coll. (conj) returns [].\n    The 'addition' may happen at different 'places' depending\n    on the concrete type.R8,s3,1.0R11,TR2,i75,R3,i1,R4,s14,arbace/core.aev11,arbace.core6,secondm14,R0,s24,Same as (first (next x))R5,ML1,V1,R9,m4,R2,i95,R3,i15,R8,s3,1.0R11,TR2,i93,R3,i1,R4,s14,arbace/core.aev11,arbace.core6,ffirstm14,R0,s25,Same as (first (first x))R5,ML1,V1,R9,m4,R2,i102,R3,i15,R8,s3,1.0R11,TR2,i100,R3,i1,R4,s14,arbace/core.aev11,arbace.core6,nfirstm14,R0,s24,Same as (next (first x))R5,ML1,V1,R9,m4,R2,i109,R3,i15,R8,s3,1.0R11,TR2,i107,R3,i1,R4,s14,arbace/core.aev11,arbace.core5,fnextm14,R0,s24,Same as (first (next x))R5,ML1,V1,R9,m4,R2,i116,R3,i15,R8,s3,1.0R11,TR2,i114,R3,i1,R4,s14,arbace/core.aev11,arbace.core5,nnextm14,R0,s23,Same as (next (next x))R5,ML1,V1,R9,m4,R2,i123,R3,i15,R8,s3,1.0R11,TR2,i121,R3,i1,R4,s14,arbace/core.aev11,arbace.core3,seqm16,R5,ML1,MV1,R13,m2,R14,R16,m4,R2,i129,R3,i15,R0,s357,Returns a seq on the collection. If the collection is\n    empty, returns nil.  (seq nil) returns nil. seq also works on\n    Strings, native Java arrays (of reference types) and any objects\n    that implement Iterable. Note that seqs cache values, thus seq\n    should not be used on any Iterable whose iterator repeatedly\n    returns the same mutable object.R14,C16,arbace.lang.ISeqR8,s3,1.0R11,TR2,i128,R3,i1,R4,s14,arbace/core.aev11,arbace.core9,instance?m12,R5,ML1,V2,Myn1,cm2,R14,R17,R9,m4,R2,i142,R3,i15,R0,s84,Evaluates x and tests if it is an instance of the class\n    c. Returns true or falseR8,s3,1.0R2,i141,R3,i1,R4,s14,arbace/core.aev11,arbace.core4,seq?m14,R5,ML1,V1,R9,m4,R2,i149,R3,i15,R0,s32,Return true if x implements ISeqR8,s3,1.0R11,TR2,i148,R3,i1,R4,s14,arbace/core.aev11,arbace.core5,char?m14,R5,ML1,V1,R9,m4,R2,i156,R3,i15,R0,s31,Return true if x is a CharacterR8,s3,1.0R11,TR2,i155,R3,i1,R4,s14,arbace/core.aev11,arbace.core7,string?m14,R5,ML1,V1,R9,m4,R2,i163,R3,i15,R0,s28,Return true if x is a StringR8,s3,1.0R11,TR2,i162,R3,i1,R4,s14,arbace/core.aev11,arbace.core4,map?m14,R5,ML1,V1,R9,m4,R2,i170,R3,i15,R0,s42,Return true if x implements IPersistentMapR8,s3,1.0R11,TR2,i169,R3,i1,R4,s14,arbace/core.aev11,arbace.core7,vector?m14,R5,ML1,V1,R9,m4,R2,i177,R3,i15,R0,s45,Return true if x implements IPersistentVectorR8,s3,1.0R11,TR2,i176,R3,i1,R4,s14,arbace/core.aev11,arbace.core5,assocm14,R5,ML2,V3,R18,R19,R20,V5,R18,R19,R20,R6,R21,m4,R2,i184,R3,i15,R0,s261,assoc[iate]. When applied to a map, returns a new map of the\n    same (hashed/sorted) type, that contains the mapping of key(s) to\n    val(s). When applied to a vector, returns a new vector that\n    contains val at index. Note - index must be <= (count vector).R8,s3,1.0R11,TR2,i183,R3,i1,R4,s14,arbace/core.aev11,arbace.core4,metaR5,ML1,V1,R22,m4,R2,i205,R3,i15,R0,R8,R11,R23,R2,i204,R3,i1,R4,v11,arbace.core9,with-metam14,R5,ML1,V2,Myn3,objm2,R14,R24,R25,m4,R2,i215,R3,i15,R0,s84,Returns an object of the same type and value as obj, with\n    map m as its metadata.R8,s3,1.0R11,TR2,i214,R3,i1,R4,s14,arbace/core.aev11,arbace.core18,assert-valid-fdeclm10,R26,TR27,TR2,i223,R3,i1,R4,s14,arbace/core.aev11,arbace.core4,sigsm8,R26,TR2,i226,R3,i1,R4,s14,arbace/core.aev11,arbace.core4,lastm14,R5,ML1,V1,R13,m4,R2,i265,R3,i15,R0,s44,Return the last item in coll, in linear timeR8,s3,1.0R11,TR2,i264,R3,i1,R4,s14,arbace/core.aev11,arbace.core7,butlastm14,R5,ML1,V1,R13,m4,R2,i275,R3,i15,R0,s61,Return a seq of all but the last item in coll, in linear timeR8,s3,1.0R11,TR2,i274,R3,i1,R4,s14,arbace/core.aev11,arbace.core4,defnm12,R0,s261,Same as (def name (fn [params* ] exprs*)) or (def\n    name (fn ([params* ] exprs*)+)) with any doc-string or attrs added\n    to the var metadata. prepost-map defines a map with optional keys\n    :pre and :post that contain collections of pre or post conditions.R5,ML2,V6,R28,R29,R30,V1,R31,R32,R33,V6,R28,R29,R30,ML3,V1,R31,R32,R33,m4,R2,i292,R3,i45,R34,R30,m4,R2,i291,R3,i15,R8,s3,1.0R2,i285,R3,i1,R4,s14,arbace/core.aev11,arbace.core8,to-arraym16,R5,L1,V1,R13,R0,s132,Returns an array of Objects containing the contents of coll, which\n  can be any Collection.  Maps to java.util.Collection.toArray().R14,s19,[Ljava.lang.Object;R8,s3,1.0R11,TR2,i340,R3,i1,R4,s14,arbace/core.aev11,arbace.core4,castm14,R5,L1,V2,Myn1,cm2,R14,R17,R9,R0,s60,Throws a ClassCastException if x is not a c, else returns x.R8,s3,1.0R11,TR2,i348,R3,i1,R4,s14,arbace/core.aev11,arbace.core6,vectorm14,R5,L8,V0,V1,R35,V2,R35,R36,V3,R35,R36,R37,V4,R35,R36,R37,R38,V5,R35,R36,R37,R38,R39,V6,R35,R36,R37,R38,R39,R40,V8,R35,R36,R37,R38,R39,R40,R6,R41,R0,s41,Creates a new vector containing the args.R8,s3,1.0R11,TR2,i355,R3,i1,R4,s14,arbace/core.aev11,arbace.core3,vecm14,R5,L1,V1,R13,R0,s111,Creates a new vector containing the contents of coll. Java arrays\n  will be aliased and should not be modified.R8,s3,1.0R11,TR2,i369,R3,i1,R4,s14,arbace/core.aev11,arbace.core8,hash-mapm14,R5,L2,V0,V2,R6,R42,R0,s142,keyval => key val\n  Returns a new hash map with supplied mappings.  If any keys are\n  equal, they are handled as if by repeated uses of assoc.R8,s3,1.0R11,TR2,i381,R3,i1,R4,s14,arbace/core.aev11,arbace.core8,hash-setm14,R5,L2,V0,V2,R6,R43,R0,s104,Returns a new hash set with supplied keys.  Any equal keys are\n  handled as if by repeated uses of conj.R8,s3,1.0R11,TR2,i391,R3,i1,R4,s14,arbace/core.aev11,arbace.core10,sorted-mapm14,R5,L1,V2,R6,R42,R0,s144,keyval => key val\n  Returns a new sorted map with supplied mappings.  If any keys are\n  equal, they are handled as if by repeated uses of assoc.R8,s3,1.0R11,TR2,i400,R3,i1,R4,s14,arbace/core.aev11,arbace.core13,sorted-map-bym14,R5,L1,V3,R44,R6,R42,R0,s177,keyval => key val\n  Returns a new sorted map with supplied mappings, using the supplied\n  comparator.  If any keys are equal, they are handled as if by\n  repeated uses of assoc.R8,s3,1.0R11,TR2,i409,R3,i1,R4,s14,arbace/core.aev11,arbace.core10,sorted-setm14,R5,L1,V2,R6,R43,R0,s106,Returns a new sorted set with supplied keys.  Any equal keys are\n  handled as if by repeated uses of conj.R8,s3,1.0R11,TR2,i419,R3,i1,R4,s14,arbace/core.aev11,arbace.core13,sorted-set-bym14,R5,L1,V3,R44,R6,R43,R0,s139,Returns a new sorted set with supplied keys, using the supplied\n  comparator.  Any equal keys are handled as if by repeated uses of\n  conj.R8,s3,1.1R11,TR2,i427,R3,i1,R4,s14,arbace/core.aev11,arbace.core4,nil?L1,V1,R9,R14,C17,java.lang.Booleani438,v11,arbace.core8,defmacrom12,R0,s132,Like defn, but the resulting function name is declared as a\n  macro and will be used as a macro by the compiler when it is\n  called.R5,ML2,V5,R28,R29,R30,V1,R31,R33,V6,R28,R29,R30,ML2,V1,R31,R33,m4,R2,i452,R3,i46,R34,R30,m4,R2,i451,R3,i15,R8,s3,1.0R2,i446,R3,i1,R4,s14,arbace/core.aev11,arbace.core4,whenm12,R5,L1,V3,R45,R6,R33,R0,s66,Evaluates test. If logical true, evaluates body in an implicit do.R8,s3,1.0R2,i494,R3,i1,R4,s14,arbace/core.aev11,arbace.core8,when-notm12,R5,L1,V3,R45,R6,R33,R0,s67,Evaluates test. If logical false, evaluates body in an implicit do.R8,s3,1.0R2,i500,R3,i1,R4,s14,arbace/core.aev11,arbace.core6,false?m16,R5,L1,V1,R9,R0,s54,Returns true if x is the value false, false otherwise.R14,C17,java.lang.BooleanR8,s3,1.0R11,TR2,i506,R3,i1,R4,s14,arbace/core.aev11,arbace.core5,true?m16,R5,L1,V1,R9,R0,s53,Returns true if x is the value true, false otherwise.R14,C17,java.lang.BooleanR8,s3,1.0R11,TR2,i513,R3,i1,R4,s14,arbace/core.aev11,arbace.core8,boolean?m12,R5,L1,V1,R9,R0,s29,Return true if x is a BooleanR8,s3,1.9R2,i520,R3,i1,R4,s14,arbace/core.aev11,arbace.core3,notm16,R5,L1,V1,R9,R0,s52,Returns true if x is logical false, false otherwise.R14,C17,java.lang.BooleanR8,s3,1.0R11,TR2,i525,R3,i1,R4,s14,arbace/core.aev11,arbace.core5,some?m16,R5,L1,V1,R9,R0,s46,Returns true if x is not nil, false otherwise.R14,C17,java.lang.BooleanR8,s3,1.6R11,TR2,i532,R3,i1,R4,s14,arbace/core.aev11,arbace.core4,any?m14,R5,L1,V1,R9,R0,s32,Returns true given any argument.R14,C17,java.lang.BooleanR8,s3,1.9R2,i539,R3,i1,R4,s14,arbace/core.aev11,arbace.core3,strm16,R5,L3,MV0,m2,R14,R46,MV1,Myn1,xm2,R14,R47,m2,R14,R46,MV3,R9,R6,R48,m2,R14,R46,R0,s199,With no args, returns the empty string. With one arg x, returns\n  x.toString().  (str nil) returns the empty string. With more than\n  one arg, returns the concatenation of the str values of the args.R14,C16,java.lang.StringR8,s3,1.0R11,TR2,i545,R3,i1,R4,s14,arbace/core.aev11,arbace.core7,symbol?m14,R5,L1,V1,R9,R0,s28,Return true if x is a SymbolR8,s3,1.0R11,TR2,i562,R3,i1,R4,s14,arbace/core.aev11,arbace.core8,keyword?m14,R5,L1,V1,R9,R0,s29,Return true if x is a KeywordR8,s3,1.0R11,TR2,i568,R3,i1,R4,s14,arbace/core.aev11,arbace.core4,condm12,R5,L1,V2,R6,R49,R0,s245,Takes a set of test/expr pairs. It evaluates each test one at a\n  time.  If a test returns logical true, cond evaluates and returns\n  the value of the corresponding expr and doesn't evaluate any of the\n  other tests or exprs. (cond) returns nil.R8,s3,1.0R2,i574,R3,i1,R4,s14,arbace/core.aev11,arbace.core6,symbolm16,R5,L2,V1,R28,V2,R50,R28,R0,s99,Returns a Symbol with the given namespace and name. Arity-1 works\n  on strings, keywords, and vars.R14,C18,arbace.lang.SymbolR8,s3,1.0R11,TR2,i589,R3,i1,R4,s14,arbace/core.aev11,arbace.core6,gensymm14,R5,L2,V0,V1,R51,R0,s175,Returns a new symbol with a unique name. If a prefix string is\n  supplied, the name is prefix# where # is some unique number. If\n  prefix is not supplied, the prefix is 'G__'.R8,s3,1.0R11,TR2,i604,R3,i1,R4,s14,arbace/core.aev11,arbace.core7,keywordm16,R5,L2,V1,R28,V2,R50,R28,R0,s124,Returns a Keyword with the given namespace and name.  Do not use :\n  in the keyword strings, it will be added automatically.R14,C19,arbace.lang.KeywordR8,s3,1.0R11,TR2,i613,R3,i1,R4,s14,arbace/core.aev11,arbace.core12,find-keywordm16,R5,L2,V1,R28,V2,R50,R28,R0,s262,Returns a Keyword with the given namespace and name if one already\n  exists.  This function will not intern a new keyword. If the keyword\n  has not already been interned, it will return nil.  Do not use :\n  in the keyword strings, it will be added automatically.R14,C19,arbace.lang.KeywordR8,s3,1.3R11,TR2,i624,R3,i1,R4,s14,arbace/core.aev11,arbace.core6,spreadm12,R5,L1,V1,R52,R26,TR11,TR2,i637,R3,i1,R4,s14,arbace/core.aev11,arbace.core5,list*m14,R5,L5,V1,R41,V2,R35,R41,V3,R35,R36,R41,V4,R35,R36,R37,R41,V6,R35,R36,R37,R38,R6,R53,R0,s112,Creates a new seq containing the items prepended to the rest, the\n  last of which will be treated as a sequence.R8,s3,1.0R11,TR2,i646,R3,i1,R4,s14,arbace/core.aev11,arbace.core5,applym14,R5,L5,V2,Myn1,fm2,R14,R54,R41,V3,Myn1,fm2,R14,R54,R9,R41,V4,Myn1,fm2,R14,R54,R9,R55,R41,V5,Myn1,fm2,R14,R54,R9,R55,R56,R41,V7,Myn1,fm2,R14,R54,R35,R36,R37,R38,R6,R41,R0,s85,Applies fn f to the argument list formed by prepending intervening arguments to args.R8,s3,1.0R11,TR2,i658,R3,i1,R4,s14,arbace/core.aev11,arbace.core9,vary-metam14,R5,L1,V4,R22,R40,R6,R41,R0,s102,Returns an object of the same type and value as obj, with\n  (apply f (meta obj) args) as its metadata.R8,s3,1.0R11,TR2,i673,R3,i1,R4,s14,arbace/core.aev11,arbace.core8,lazy-seqm12,R5,L1,V2,R6,R33,R0,s241,Takes a body of expressions that returns an ISeq or nil, and yields\n  a Seqable object that will invoke the body only the first time seq\n  is called, and will cache the result and return it on all subsequent\n  seq calls. See also - realized?R8,s3,1.0R2,i681,R3,i1,R4,s14,arbace/core.aev11,arbace.core12,chunk-bufferm12,R14,C23,arbace.lang.ChunkBufferR11,TR5,L1,MV1,R57,m2,R14,R58,R2,i690,R3,i1,R4,s14,arbace/core.aev11,arbace.core12,chunk-appendm10,R11,TR5,L1,V2,Myn1,bm2,R14,R58,R9,R2,i693,R3,i1,R4,s14,arbace/core.aev11,arbace.core5,chunkm12,R14,C18,arbace.lang.IChunkR11,TR5,L1,V1,Myn1,bm2,R14,R58,R2,i696,R3,i1,R4,s14,arbace/core.aev11,arbace.core11,chunk-firstm12,R14,C18,arbace.lang.IChunkR11,TR5,L1,MV1,Myn1,sm2,R14,R59,m2,R14,R60,R2,i699,R3,i1,R4,s14,arbace/core.aev11,arbace.core10,chunk-restm12,R14,C16,arbace.lang.ISeqR11,TR5,L1,MV1,Myn1,sm2,R14,R59,m2,R14,R16,R2,i702,R3,i1,R4,s14,arbace/core.aev11,arbace.core10,chunk-nextm12,R14,C16,arbace.lang.ISeqR11,TR5,L1,MV1,Myn1,sm2,R14,R59,m2,R14,R16,R2,i705,R3,i1,R4,s14,arbace/core.aev11,arbace.core10,chunk-consm10,R11,TR5,L1,V2,R61,R62,R2,i708,R3,i1,R4,s14,arbace/core.aev11,arbace.core12,chunked-seq?m10,R11,TR5,L1,V1,R63,R2,i713,R3,i1,R4,s14,arbace/core.aev11,arbace.core6,concatm14,R5,L4,V0,V1,R9,V2,R9,R55,V4,R9,R55,R6,R64,R0,s88,Returns a lazy seq representing the concatenation of the elements in the supplied colls.R8,s3,1.0R11,TR2,i716,R3,i1,R4,s14,arbace/core.aev11,arbace.core5,delaym12,R5,L1,V2,R6,R33,R0,s235,Takes a body of expressions and yields a Delay object that will\n  invoke the body only the first time it is forced (with force or deref/@), and\n  will cache the result and return it on all subsequent force\n  calls. See also - realized?R8,s3,1.0R2,i744,R3,i1,R4,s14,arbace/core.aev11,arbace.core6,delay?m14,R5,L1,V1,R9,R0,s47,returns true if x is a Delay created with delayR8,s3,1.0R11,TR2,i753,R3,i1,R4,s14,arbace/core.aev11,arbace.core5,forcem14,R5,L1,V1,R9,R0,s86,If x is a Delay, returns the (possibly cached) value of its expression, else returns xR8,s3,1.0R11,TR2,i759,R3,i1,R4,s14,arbace/core.aev11,arbace.core6,if-notm12,R5,L2,V2,R45,R65,V3,R45,R65,R66,R0,s112,Evaluates test. If logical false, evaluates and returns then expr,\n  otherwise else expr, if supplied, else nil.R8,s3,1.0R2,i765,R3,i1,R4,s14,arbace/core.aev11,arbace.core10,identical?L1,V2,R9,R55,R67,S1,l2,i773,v11,arbace.core1,=L3,V1,R9,V2,R9,R55,V4,R9,R55,R6,R53,S1,l2,i781,v11,arbace.core4,not=m16,R5,L3,V1,R9,V2,R9,R55,V4,R9,R55,R6,R53,R0,s27,Same as (not (= obj1 obj2))R14,C17,java.lang.BooleanR8,s3,1.0R11,TR2,i817,R3,i1,R4,s14,arbace/core.aev11,arbace.core7,compareL1,V2,R9,R55,i827,v11,arbace.core3,andm12,R5,L3,V0,V1,R9,V3,R9,R6,R68,R0,s247,Evaluates exprs one at a time, from left to right. If a form\n  returns logical false (nil or false), and returns that value and\n  doesn't evaluate any of the other expressions, otherwise it returns\n  the value of the last expr. (and) returns true.R8,s3,1.0R2,i838,R3,i1,R4,s14,arbace/core.aev11,arbace.core2,orm12,R5,L3,V0,V1,R9,V3,R9,R6,R68,R0,s242,Evaluates exprs one at a time, from left to right. If a form\n  returns a logical true value, or returns that value and doesn't\n  evaluate any of the other expressions, otherwise it returns the\n  value of the last expression. (or) returns nil.R8,s3,1.0R2,i850,R3,i1,R4,s14,arbace/core.ae")

var Lit_713 *jrt.String = jrt.Intern("arbace.core$cons__1927000000")

var Lit_714 *jrt.String = jrt.Intern("arbace.core$let__1927000002")

var Lit_715 *jrt.String = jrt.Intern("arbace.core$loop__1927000004")

var Lit_716 *jrt.String = jrt.Intern("arbace.core$fn__1927000006")

var Lit_717 *jrt.String = jrt.Intern("arbace.core$first__1927000008")

var Lit_718 *jrt.String = jrt.Intern("arbace.core$next__1927000010")

var Lit_719 *jrt.String = jrt.Intern("arbace.core$rest__1927000012")

var Lit_720 *jrt.String = jrt.Intern("arbace.core$conj__1927000014")

var Lit_721 *jrt.String = jrt.Intern("arbace.core$second__1927000016")

var Lit_722 *jrt.String = jrt.Intern("arbace.core$ffirst__1927000018")

var Lit_723 *jrt.String = jrt.Intern("arbace.core$nfirst__1927000020")

var Lit_724 *jrt.String = jrt.Intern("arbace.core$fnext__1927000022")

var Lit_725 *jrt.String = jrt.Intern("arbace.core$nnext__1927000024")

var Lit_726 *jrt.String = jrt.Intern("arbace.core$seq__1927000026")

var Lit_727 *jrt.String = jrt.Intern("arbace.core$instance_QMARK___1927000028")

var Lit_728 *jrt.String = jrt.Intern("arbace.core$seq_QMARK___1927000030")

var Lit_729 *jrt.String = jrt.Intern("arbace.core$char_QMARK___1927000032")

var Lit_730 *jrt.String = jrt.Intern("arbace.core$string_QMARK___1927000034")

var Lit_731 *jrt.String = jrt.Intern("arbace.core$map_QMARK___1927000036")

var Lit_732 *jrt.String = jrt.Intern("arbace.core$vector_QMARK___1927000038")

var Lit_733 *jrt.String = jrt.Intern("arbace.core$assoc__1927000040")

var Lit_734 *jrt.String = jrt.Intern("arbace.core$meta__1927000044")

var Lit_735 *jrt.String = jrt.Intern("Returns the metadata of obj, returns nil if there is no metadata.")

var Lit_736 *jrt.String = jrt.Intern("1.0")

var Lit_737 *jrt.String = jrt.Intern("arbace.core$fn__1927000042")

var Lit_738 *jrt.String = jrt.Intern("arbace/core.ae")

var Lit_739 *jrt.String = jrt.Intern("arbace.core$with_meta__1927000046")

var Lit_740 *jrt.String = jrt.Intern("arbace.core$assert_valid_fdecl")

var Lit_741 *jrt.String = jrt.Intern("arbace.core$sigs")

var Lit_742 *jrt.String = jrt.Intern("arbace.core$last__1927000054")

var Lit_743 *jrt.String = jrt.Intern("arbace.core$butlast__1927000056")

var Lit_744 *jrt.String = jrt.Intern("arbace.core$defn__1927000058")

var Lit_745 *jrt.String = jrt.Intern("arbace.core$to_array")

var Lit_746 *jrt.String = jrt.Intern("arbace.core$cast")

var Lit_747 *jrt.String = jrt.Intern("arbace.core$vector")

var Lit_748 *jrt.String = jrt.Intern("arbace.core$vec")

var Lit_749 *jrt.String = jrt.Intern("arbace.core$hash_map")

var Lit_750 *jrt.String = jrt.Intern("arbace.core$hash_set")

var Lit_751 *jrt.String = jrt.Intern("arbace.core$sorted_map")

var Lit_752 *jrt.String = jrt.Intern("arbace.core$sorted_map_by")

var Lit_753 *jrt.String = jrt.Intern("arbace.core$sorted_set")

var Lit_754 *jrt.String = jrt.Intern("arbace.core$sorted_set_by")

var Lit_755 *jrt.String = jrt.Intern("arbace.core$nil_QMARK_")

var Lit_756 *jrt.String = jrt.Intern("Returns true if x is nil, false otherwise.")

var Lit_757 *jrt.String = jrt.Intern("arbace.core$nil_QMARK___inliner__1927000072")

var Lit_758 *jrt.String = jrt.Intern("arbace.core$defmacro")

var Lit_759 *jrt.String = jrt.Intern("arbace.core$when")

var Lit_760 *jrt.String = jrt.Intern("arbace.core$when_not")

var Lit_761 *jrt.String = jrt.Intern("arbace.core$false_QMARK_")

var Lit_762 *jrt.String = jrt.Intern("arbace.core$true_QMARK_")

var Lit_763 *jrt.String = jrt.Intern("arbace.core$boolean_QMARK_")

var Lit_764 *jrt.String = jrt.Intern("arbace.core$not")

var Lit_765 *jrt.String = jrt.Intern("arbace.core$some_QMARK_")

var Lit_766 *jrt.String = jrt.Intern("arbace.core$any_QMARK_")

var Lit_767 *jrt.String = jrt.Intern("arbace.core$str")

var Lit_768 *jrt.String = jrt.Intern("arbace.core$symbol_QMARK_")

var Lit_769 *jrt.String = jrt.Intern("arbace.core$keyword_QMARK_")

var Lit_770 *jrt.String = jrt.Intern("arbace.core$cond")

var Lit_771 *jrt.String = jrt.Intern("arbace.core$symbol")

var Lit_772 *jrt.String = jrt.Intern("arbace.core$gensym")

var Lit_773 *jrt.String = jrt.Intern("arbace.core$keyword")

var Lit_774 *jrt.String = jrt.Intern("arbace.core$find_keyword")

var Lit_775 *jrt.String = jrt.Intern("arbace.core$spread")

var Lit_776 *jrt.String = jrt.Intern("arbace.core$list_STAR_")

var Lit_777 *jrt.String = jrt.Intern("arbace.core$apply")

var Lit_778 *jrt.String = jrt.Intern("arbace.core$vary_meta")

var Lit_779 *jrt.String = jrt.Intern("arbace.core$lazy_seq")

var Lit_780 *jrt.String = jrt.Intern("arbace.core$chunk_buffer")

var Lit_781 *jrt.String = jrt.Intern("arbace.core$chunk_append")

var Lit_782 *jrt.String = jrt.Intern("arbace.core$chunk")

var Lit_783 *jrt.String = jrt.Intern("arbace.core$chunk_first")

var Lit_784 *jrt.String = jrt.Intern("arbace.core$chunk_rest")

var Lit_785 *jrt.String = jrt.Intern("arbace.core$chunk_next")

var Lit_786 *jrt.String = jrt.Intern("arbace.core$chunk_cons")

var Lit_787 *jrt.String = jrt.Intern("arbace.core$chunked_seq_QMARK_")

var Lit_788 *jrt.String = jrt.Intern("arbace.core$concat")

var Lit_789 *jrt.String = jrt.Intern("arbace.core$delay")

var Lit_790 *jrt.String = jrt.Intern("arbace.core$delay_QMARK_")

var Lit_791 *jrt.String = jrt.Intern("arbace.core$force")

var Lit_792 *jrt.String = jrt.Intern("arbace.core$if_not")

var Lit_793 *jrt.String = jrt.Intern("arbace.core$identical_QMARK_")

var Lit_794 *jrt.String = jrt.Intern("Tests if 2 arguments are the same object")

var Lit_795 *jrt.String = jrt.Intern("arbace.core$identical_QMARK___inliner__1927000158")

var Lit_796 *jrt.String = jrt.Intern("arbace.core$_EQ_")

var Lit_797 *jrt.String = jrt.Intern("Equality. Returns true if x equals y, false if not. Same as\n  Java x.equals(y) except it also works for nil, and compares\n  numbers and collections in a type-independent manner.  Clojure's immutable data\n  structures define equals() (and thus =) as a value, not an identity,\n  comparison.")

var Lit_798 *jrt.String = jrt.Intern("arbace.core$_EQ___inliner__1927000161")

var Lit_799 *jrt.String = jrt.Intern("arbace.core$not_EQ_")

var Lit_800 *jrt.String = jrt.Intern("arbace.core$compare")

var Lit_801 *jrt.String = jrt.Intern("Comparator. Returns a negative number, zero, or a positive number\n  when x is logically 'less than', 'equal to', or 'greater than'\n  y. Same as Java x.compareTo(y) except it also works for nil, and\n  compares numbers and collections in a type-independent manner. x\n  must implement Comparable")

var Lit_802 *jrt.String = jrt.Intern("arbace.core$compare__inliner__1927000165")

var Lit_803 *jrt.String = jrt.Intern("arbace.core$and")

var Lit_804 *jrt.String = jrt.Intern("arbace.core$or")

var Lit_805 *jrt.String = jrt.Intern("yn3,numyn4,collyn1,xyn5,indexyn9,not-foundyn1,yyn1,&yn4,morekn6,statickn7,privatekn8,arglistsyn1,fyn3,valkn4,linekn6,columnkn4,filekn5,redefkn3,dockn5,addedyn2,opyn12,unchecked-opyn1,nyn4,addPyn3,addyn13,unchecked_addyn9,multiplyPyn8,multiplyyn18,unchecked_multiplyyn6,divideyn6,minusPyn5,minusyn15,unchecked_minusyn3,maxyn3,minyn1,ayn3,divyn3,andyn2,oryn3,xoryn6,andNotyn3,keyyn3,mapyn1,myn1,kyn2,ksyn3,setkn3,tagyn26,arbace.lang.IPersistentSetyn19,java.util.Map$Entryyn22,arbace.lang.Reversibleyn17,arbace.lang.Namedyn4,bodyv11,arbace.core5,zero?L1,V1,R0,i863,v11,arbace.core5,countL1,V1,R1,i870,v11,arbace.core3,intL1,V1,R2,i878,v11,arbace.core3,nthL2,V2,R1,R3,V3,R1,R3,R4,S2,l3,l2,i885,v11,arbace.core1,<L3,V1,R2,V2,R2,R5,V4,R2,R5,R6,R7,S1,l2,i896,v11,arbace.core4,inc'L1,V1,R2,i911,v11,arbace.core3,incL1,V1,R2,i918,v11,arbace.core7,reduce0m12,R8,TR9,TR10,L2,V2,R11,R1,V3,R11,R12,R1,R13,i926,R14,i1,R15,s14,arbace/core.aev11,arbace.core7,reduce1m10,R16,TR9,TR13,i943,R14,i1,R15,s14,arbace/core.aev11,arbace.core7,reversem14,R10,L1,V1,R1,R17,s62,Returns a seq of the items in coll in reverse order. Not lazy.R18,s3,1.0R8,TR13,i945,R14,i1,R15,s14,arbace/core.aev11,arbace.core11,nary-inlinem10,R9,TR10,L2,V1,R19,V2,R19,R20,R13,i953,R14,i1,R15,s14,arbace/core.aev11,arbace.core3,>1?m10,R9,TR10,L1,V1,R21,R13,i967,R14,i1,R15,s14,arbace/core.aev11,arbace.core3,>0?m10,R9,TR10,L1,V1,R21,R13,i968,R14,i1,R15,s14,arbace/core.aev11,arbace.core2,+'L4,V0,V1,R2,V2,R2,R5,V4,R2,R5,R6,R7,R22,i970,v11,arbace.core1,+L4,V0,V1,R2,V2,R2,R5,V4,R2,R5,R6,R7,R23,R24,i982,v11,arbace.core2,*'L4,V0,V1,R2,V2,R2,R5,V4,R2,R5,R6,R7,R25,i994,v11,arbace.core1,*L4,V0,V1,R2,V2,R2,R5,V4,R2,R5,R6,R7,R26,R27,i1006,v11,arbace.core1,/L3,V1,R2,V2,R2,R5,V4,R2,R5,R6,R7,R28,i1018,v11,arbace.core2,-'L3,V1,R2,V2,R2,R5,V4,R2,R5,R6,R7,R29,i1029,v11,arbace.core1,-L3,V1,R2,V2,R2,R5,V4,R2,R5,R6,R7,R30,R31,i1041,v11,arbace.core2,<=L3,V1,R2,V2,R2,R5,V4,R2,R5,R6,R7,S1,l2,i1053,v11,arbace.core1,>L3,V1,R2,V2,R2,R5,V4,R2,R5,R6,R7,S1,l2,i1068,v11,arbace.core2,>=L3,V1,R2,V2,R2,R5,V4,R2,R5,R6,R7,S1,l2,i1083,v11,arbace.core2,==L3,V1,R2,V2,R2,R5,V4,R2,R5,R6,R7,S1,l2,i1098,v11,arbace.core3,maxL3,V1,R2,V2,R2,R5,V4,R2,R5,R6,R7,R32,i1113,v11,arbace.core3,minL3,V1,R2,V2,R2,R5,V4,R2,R5,R6,R7,R33,i1123,v11,arbace.core3,absL1,V1,R34,S1,l1,i1133,v11,arbace.core4,dec'L1,V1,R2,i1145,v11,arbace.core3,decL1,V1,R2,i1152,v11,arbace.core17,unchecked-inc-intL1,V1,R2,i1159,v11,arbace.core13,unchecked-incL1,V1,R2,i1166,v11,arbace.core17,unchecked-dec-intL1,V1,R2,i1173,v11,arbace.core13,unchecked-decL1,V1,R2,i1180,v11,arbace.core20,unchecked-negate-intL1,V1,R2,i1187,v11,arbace.core16,unchecked-negateL1,V1,R2,i1194,v11,arbace.core17,unchecked-add-intL1,V2,R2,R5,i1201,v11,arbace.core13,unchecked-addL1,V2,R2,R5,i1208,v11,arbace.core22,unchecked-subtract-intL1,V2,R2,R5,i1215,v11,arbace.core18,unchecked-subtractL1,V2,R2,R5,i1222,v11,arbace.core22,unchecked-multiply-intL1,V2,R2,R5,i1229,v11,arbace.core18,unchecked-multiplyL1,V2,R2,R5,i1236,v11,arbace.core20,unchecked-divide-intL1,V2,R2,R5,i1243,v11,arbace.core23,unchecked-remainder-intL1,V2,R2,R5,i1250,v11,arbace.core4,pos?L1,V1,R0,i1257,v11,arbace.core4,neg?L1,V1,R0,i1264,v11,arbace.core4,quotL1,V2,R0,R35,i1271,v11,arbace.core3,remL1,V2,R0,R35,i1279,v11,arbace.core11,rationalizem14,R10,L1,V1,R0,R17,s33,returns the rational value of numR18,s3,1.0R8,TR13,i1287,R14,i1,R15,s14,arbace/core.aev11,arbace.core7,bit-notL1,V1,R2,i1296,v11,arbace.core7,bit-andL2,V2,R2,R5,V4,R2,R5,R6,R7,R36,i1302,v11,arbace.core6,bit-orL2,V2,R2,R5,V4,R2,R5,R6,R7,R37,i1311,v11,arbace.core7,bit-xorL2,V2,R2,R5,V4,R2,R5,R6,R7,R38,i1320,v11,arbace.core11,bit-and-notL2,V2,R2,R5,V4,R2,R5,R6,R7,R39,i1329,v11,arbace.core9,bit-clearm14,R10,L1,V2,R2,R21,R17,s20,Clear bit at index nR18,s3,1.0R8,TR13,i1339,R14,i1,R15,s14,arbace/core.aev11,arbace.core7,bit-setm14,R10,L1,V2,R2,R21,R17,s18,Set bit at index nR18,s3,1.0R8,TR13,i1345,R14,i1,R15,s14,arbace/core.aev11,arbace.core8,bit-flipm14,R10,L1,V2,R2,R21,R17,s19,Flip bit at index nR18,s3,1.0R8,TR13,i1351,R14,i1,R15,s14,arbace/core.aev11,arbace.core8,bit-testm14,R10,L1,V2,R2,R21,R17,s19,Test bit at index nR18,s3,1.0R8,TR13,i1357,R14,i1,R15,s14,arbace/core.aev11,arbace.core14,bit-shift-leftL1,V2,R2,R21,i1363,v11,arbace.core15,bit-shift-rightL1,V2,R2,R21,i1369,v11,arbace.core24,unsigned-bit-shift-rightL1,V2,R2,R21,i1375,v11,arbace.core8,integer?m14,R10,L1,V1,R21,R17,s31,Returns true if n is an integerR18,s3,1.0R8,TR13,i1381,R14,i1,R15,s14,arbace/core.aev11,arbace.core5,even?m14,R10,L1,V1,R21,R17,s69,Returns true if n is even, throws an exception if n is not an integerR18,s3,1.0R8,TR13,i1393,R14,i1,R15,s14,arbace/core.aev11,arbace.core4,odd?m14,R10,L1,V1,R21,R17,s68,Returns true if n is odd, throws an exception if n is not an integerR18,s3,1.0R8,TR13,i1401,R14,i1,R15,s14,arbace/core.aev11,arbace.core4,int?m12,R10,L1,V1,R2,R17,s45,Return true if x is a fixed precision integerR18,s3,1.9R13,i1407,R14,i1,R15,s14,arbace/core.aev11,arbace.core8,pos-int?m12,R10,L1,V1,R2,R17,s54,Return true if x is a positive fixed precision integerR18,s3,1.9R13,i1415,R14,i1,R15,s14,arbace/core.aev11,arbace.core8,neg-int?m12,R10,L1,V1,R2,R17,s54,Return true if x is a negative fixed precision integerR18,s3,1.9R13,i1421,R14,i1,R15,s14,arbace/core.aev11,arbace.core8,nat-int?m12,R10,L1,V1,R2,R17,s58,Return true if x is a non-negative fixed precision integerR18,s3,1.9R13,i1427,R14,i1,R15,s14,arbace/core.aev11,arbace.core7,double?m12,R10,L1,V1,R2,R17,s28,Return true if x is a DoubleR18,s3,1.9R13,i1433,R14,i1,R15,s14,arbace/core.aev11,arbace.core10,complementm14,R10,L1,V1,R11,R17,s135,Takes a fn f and returns a fn that takes the same arguments as f,\n  has the same effects, if any, and returns the opposite truth value.R18,s3,1.0R8,TR13,i1440,R14,i1,R15,s14,arbace/core.aev11,arbace.core10,constantlym14,R10,L1,V1,R2,R17,s68,Returns a function that takes any number of arguments and returns x.R18,s3,1.0R8,TR13,i1452,R14,i1,R15,s14,arbace/core.aev11,arbace.core8,identitym14,R10,L1,V1,R2,R17,s21,Returns its argument.R18,s3,1.0R8,TR13,i1462,R14,i1,R15,s14,arbace/core.aev11,arbace.core4,peekm14,R10,L1,V1,R1,R17,s137,For a list or queue, same as first, for a vector, same as, but much\n  more efficient than, last. If the collection is empty, returns nil.R18,s3,1.0R8,TR13,i1471,R14,i1,R15,s14,arbace/core.aev11,arbace.core3,popm14,R10,L1,V1,R1,R17,s220,For a list or queue, returns a new list/queue without the first\n  item, for a vector, returns a new vector without the last item. If\n  the collection is empty, throws an exception.  Note - not the same\n  as next/butlast.R18,s3,1.0R8,TR13,i1478,R14,i1,R15,s14,arbace/core.aev11,arbace.core10,map-entry?m12,R10,L1,V1,R2,R17,s31,Return true if x is a map entryR18,s3,1.8R13,i1489,R14,i1,R15,s14,arbace/core.aev11,arbace.core9,contains?m14,R10,L1,V2,R1,R40,R17,s345,Returns true if key is present in the given collection, otherwise\n  returns false.  Note that for numerically indexed collections like\n  vectors and Java arrays, this tests if the numeric key is within the\n  range of indexes. 'contains?' operates constant or logarithmic time;\n  it will not perform a linear search for a value.  See also 'some'.R18,s3,1.0R8,TR13,i1495,R14,i1,R15,s14,arbace/core.aev11,arbace.core3,getL2,V2,R41,R40,V3,R41,R40,R4,S2,l3,l2,i1505,v11,arbace.core4,req!L1,V2,R42,R43,S1,l2,i1516,v11,arbace.core6,dissocm14,R10,L3,V1,R41,V2,R41,R40,V4,R41,R40,R6,R44,R17,s111,dissoc[iate]. Returns a new map of the same (hashed/sorted) type,\n  that does not contain a mapping for key(s).R18,s3,1.0R8,TR13,i1524,R14,i1,R15,s14,arbace/core.aev11,arbace.core4,disjm14,R10,L3,V1,R45,V2,Myn3,setm2,R46,R47,R40,V4,R45,R40,R6,R44,R17,s94,disj[oin]. Returns a new set of the same (hashed/sorted) type, that\n  does not contain key(s).R18,s3,1.0R8,TR13,i1538,R14,i1,R15,s14,arbace/core.aev11,arbace.core4,findm14,R10,L1,V2,R41,R40,R17,s57,Returns the map entry for key, or nil if key not present.R18,s3,1.0R8,TR13,i1554,R14,i1,R15,s14,arbace/core.aev11,arbace.core4,keysm14,R10,L1,V1,R41,R17,s69,Returns a sequence of the map's keys, in the same order as (seq map).R18,s3,1.0R8,TR13,i1560,R14,i1,R15,s14,arbace/core.aev11,arbace.core4,valsm14,R10,L1,V1,R41,R17,s71,Returns a sequence of the map's values, in the same order as (seq map).R18,s3,1.0R8,TR13,i1566,R14,i1,R15,s14,arbace/core.aev11,arbace.core3,keym14,R10,L1,V1,Myn1,em2,R46,R48,R17,s33,Returns the key of the map entry.R18,s3,1.0R8,TR13,i1572,R14,i1,R15,s14,arbace/core.aev11,arbace.core3,valm14,R10,L1,V1,Myn1,em2,R46,R48,R17,s35,Returns the value in the map entry.R18,s3,1.0R8,TR13,i1579,R14,i1,R15,s14,arbace/core.aev11,arbace.core4,rseqm14,R10,L1,V1,Myn3,revm2,R46,R49,R17,s139,Returns, in constant time, a seq of the items in rev (which\n  can be a vector or sorted-map), in reverse order. If rev is empty returns nilR18,s3,1.0R8,TR13,i1586,R14,i1,R15,s14,arbace/core.aev11,arbace.core4,namem16,R10,L1,V1,R2,R17,s55,Returns the name String of a string, symbol or keyword.R46,C16,java.lang.StringR18,s3,1.0R8,TR13,i1594,R14,i1,R15,s14,arbace/core.aev11,arbace.core9,namespacem16,R10,L1,V1,Myn1,xm2,R46,R50,R17,s75,Returns the namespace String of a symbol or keyword, or nil if not present.R46,C16,java.lang.StringR18,s3,1.0R8,TR13,i1602,R14,i1,R15,s14,arbace/core.aev11,arbace.core7,booleanL1,V1,R2,i1610,v11,arbace.core6,ident?m12,R10,L1,V1,R2,R17,s39,Return true if x is a symbol or keywordR18,s3,1.9R13,i1617,R14,i1,R15,s14,arbace/core.aev11,arbace.core13,simple-ident?m12,R10,L1,V1,R2,R17,s59,Return true if x is a symbol or keyword without a namespaceR18,s3,1.9R13,i1622,R14,i1,R15,s14,arbace/core.aev11,arbace.core16,qualified-ident?m12,R10,L1,V1,R2,R17,s56,Return true if x is a symbol or keyword with a namespaceR18,s3,1.9R13,i1627,R14,i1,R15,s14,arbace/core.aev11,arbace.core14,simple-symbol?m12,R10,L1,V1,R2,R17,s48,Return true if x is a symbol without a namespaceR18,s3,1.9R13,i1632,R14,i1,R15,s14,arbace/core.aev11,arbace.core17,qualified-symbol?m12,R10,L1,V1,R2,R17,s45,Return true if x is a symbol with a namespaceR18,s3,1.9R13,i1637,R14,i1,R15,s14,arbace/core.aev11,arbace.core15,simple-keyword?m12,R10,L1,V1,R2,R17,s49,Return true if x is a keyword without a namespaceR18,s3,1.9R13,i1642,R14,i1,R15,s14,arbace/core.aev11,arbace.core18,qualified-keyword?m12,R10,L1,V1,R2,R17,s46,Return true if x is a keyword with a namespaceR18,s3,1.9R13,i1647,R14,i1,R15,s14,arbace/core.aev11,arbace.core7,lockingm12,R10,L1,V3,R2,R6,R51,R17,s119,Executes exprs in an implicit do, while holding the monitor of x.\n  Will release the monitor of x in all circumstances.R18,s3,1.0R13,i1652,R14,i1,R15,s14,arbace/core.ae")

var Lit_806 *jrt.String = jrt.Intern("arbace.core$zero_QMARK_")

var Lit_807 *jrt.String = jrt.Intern("Returns true if num is zero, else false")

var Lit_808 *jrt.String = jrt.Intern("arbace.core$zero_QMARK___inliner__1927000180")

var Lit_809 *jrt.String = jrt.Intern("arbace.core$count")

var Lit_810 *jrt.String = jrt.Intern("Returns the number of items in the collection. (count nil) returns\n  0.  Also works on strings, arrays, and Java Collections and Maps")

var Lit_811 *jrt.String = jrt.Intern("arbace.core$count__inliner__1927000183")

var Lit_812 *jrt.String = jrt.Intern("arbace.core$int")

var Lit_813 *jrt.String = jrt.Intern("Coerce to int")

var Lit_814 *jrt.String = jrt.Intern("arbace.core$int__inliner__1927000186")

var Lit_815 *jrt.String = jrt.Intern("arbace.core$nth")

var Lit_816 *jrt.String = jrt.Intern("Returns the value at the index. get returns nil if index out of\n  bounds, nth throws an exception unless not-found is supplied.  nth\n  also works for strings, Java arrays, regex Matchers and Lists, and,\n  in O(n) time, for sequences.")

var Lit_817 *jrt.String = jrt.Intern("arbace.core$nth__inliner__1927000189")

var Lit_818 *jrt.String = jrt.Intern("arbace.core$_LT_")

var Lit_819 *jrt.String = jrt.Intern("Returns non-nil if nums are in monotonically increasing order,\n  otherwise false.")

var Lit_820 *jrt.String = jrt.Intern("arbace.core$_LT___inliner__1927000192")

var Lit_821 *jrt.String = jrt.Intern("arbace.core$inc_SINGLEQUOTE_")

var Lit_822 *jrt.String = jrt.Intern("Returns a number one greater than num. Supports arbitrary precision.\n  See also: inc")

var Lit_823 *jrt.String = jrt.Intern("arbace.core$inc_SINGLEQUOTE___inliner__1927000195")

var Lit_824 *jrt.String = jrt.Intern("arbace.core$inc")

var Lit_825 *jrt.String = jrt.Intern("Returns a number one greater than num. Does not auto-promote\n  longs, will throw on overflow. See also: inc'")

var Lit_826 *jrt.String = jrt.Intern("arbace.core$inc__inliner__1927000198")

var Lit_827 *jrt.String = jrt.Intern("1.2")

var Lit_828 *jrt.String = jrt.Intern("arbace.core$reduce0")

var Lit_829 *jrt.String = jrt.Intern("arbace.core$reverse")

var Lit_830 *jrt.String = jrt.Intern("arbace.core$nary_inline")

var Lit_831 *jrt.String = jrt.Intern("arbace.core$_GT_1_QMARK_")

var Lit_832 *jrt.String = jrt.Intern("arbace.core$_GT_0_QMARK_")

var Lit_833 *jrt.String = jrt.Intern("arbace.core$_PLUS__SINGLEQUOTE_")

var Lit_834 *jrt.String = jrt.Intern("Returns the sum of nums. (+') returns 0. Supports arbitrary precision.\n  See also: +")

var Lit_835 *jrt.String = jrt.Intern("arbace.core$_PLUS_")

var Lit_836 *jrt.String = jrt.Intern("Returns the sum of nums. (+) returns 0. Does not auto-promote\n  longs, will throw on overflow. See also: +'")

var Lit_837 *jrt.String = jrt.Intern("arbace.core$_STAR__SINGLEQUOTE_")

var Lit_838 *jrt.String = jrt.Intern("Returns the product of nums. (*') returns 1. Supports arbitrary precision.\n  See also: *")

var Lit_839 *jrt.String = jrt.Intern("arbace.core$_STAR_")

var Lit_840 *jrt.String = jrt.Intern("Returns the product of nums. (*) returns 1. Does not auto-promote\n  longs, will throw on overflow. See also: *'")

var Lit_841 *jrt.String = jrt.Intern("arbace.core$_SLASH_")

var Lit_842 *jrt.String = jrt.Intern("If no denominators are supplied, returns 1/numerator,\n  else returns numerator divided by all of the denominators.")

var Lit_843 *jrt.String = jrt.Intern("arbace.core$__SINGLEQUOTE_")

var Lit_844 *jrt.String = jrt.Intern("If no ys are supplied, returns the negation of x, else subtracts\n  the ys from x and returns the result. Supports arbitrary precision.\n  See also: -")

var Lit_845 *jrt.String = jrt.Intern("arbace.core$_")

var Lit_846 *jrt.String = jrt.Intern("If no ys are supplied, returns the negation of x, else subtracts\n  the ys from x and returns the result. Does not auto-promote\n  longs, will throw on overflow. See also: -'")

var Lit_847 *jrt.String = jrt.Intern("arbace.core$_LT__EQ_")

var Lit_848 *jrt.String = jrt.Intern("Returns non-nil if nums are in monotonically non-decreasing order,\n  otherwise false.")

var Lit_849 *jrt.String = jrt.Intern("arbace.core$_LT__EQ___inliner__1927000217")

var Lit_850 *jrt.String = jrt.Intern("arbace.core$_GT_")

var Lit_851 *jrt.String = jrt.Intern("Returns non-nil if nums are in monotonically decreasing order,\n  otherwise false.")

var Lit_852 *jrt.String = jrt.Intern("arbace.core$_GT___inliner__1927000220")

var Lit_853 *jrt.String = jrt.Intern("arbace.core$_GT__EQ_")

var Lit_854 *jrt.String = jrt.Intern("Returns non-nil if nums are in monotonically non-increasing order,\n  otherwise false.")

var Lit_855 *jrt.String = jrt.Intern("arbace.core$_GT__EQ___inliner__1927000223")

var Lit_856 *jrt.String = jrt.Intern("arbace.core$_EQ__EQ_")

var Lit_857 *jrt.String = jrt.Intern("Returns non-nil if nums all have the equivalent\n  value (type-independent), otherwise false")

var Lit_858 *jrt.String = jrt.Intern("arbace.core$_EQ__EQ___inliner__1927000226")

var Lit_859 *jrt.String = jrt.Intern("arbace.core$max")

var Lit_860 *jrt.String = jrt.Intern("Returns the greatest of the nums.")

var Lit_861 *jrt.String = jrt.Intern("arbace.core$min")

var Lit_862 *jrt.String = jrt.Intern("Returns the least of the nums.")

var Lit_863 *jrt.String = jrt.Intern("arbace.core$abs")

var Lit_864 *jrt.String = jrt.Intern("Returns the absolute value of a.\n  If a is Long/MIN_VALUE => Long/MIN_VALUE\n  If a is a double and zero => +0.0\n  If a is a double and ##Inf or ##-Inf => ##Inf\n  If a is a double and ##NaN => ##NaN")

var Lit_865 *jrt.String = jrt.Intern("arbace.core$abs__inliner__1927000231")

var Lit_866 *jrt.String = jrt.Intern("1.11")

var Lit_867 *jrt.String = jrt.Intern("arbace.core$dec_SINGLEQUOTE_")

var Lit_868 *jrt.String = jrt.Intern("Returns a number one less than num. Supports arbitrary precision.\n  See also: dec")

var Lit_869 *jrt.String = jrt.Intern("arbace.core$dec_SINGLEQUOTE___inliner__1927000234")

var Lit_870 *jrt.String = jrt.Intern("arbace.core$dec")

var Lit_871 *jrt.String = jrt.Intern("Returns a number one less than num. Does not auto-promote\n  longs, will throw on overflow. See also: dec'")

var Lit_872 *jrt.String = jrt.Intern("arbace.core$dec__inliner__1927000237")

var Lit_873 *jrt.String = jrt.Intern("arbace.core$unchecked_inc_int")

var Lit_874 *jrt.String = jrt.Intern("Returns a number one greater than x, an int.\n  Note - uses a primitive operator subject to overflow.")

var Lit_875 *jrt.String = jrt.Intern("arbace.core$unchecked_inc_int__inliner__1927000240")

var Lit_876 *jrt.String = jrt.Intern("arbace.core$unchecked_inc")

var Lit_877 *jrt.String = jrt.Intern("Returns a number one greater than x, a long.\n  Note - uses a primitive operator subject to overflow.")

var Lit_878 *jrt.String = jrt.Intern("arbace.core$unchecked_inc__inliner__1927000243")

var Lit_879 *jrt.String = jrt.Intern("arbace.core$unchecked_dec_int")

var Lit_880 *jrt.String = jrt.Intern("Returns a number one less than x, an int.\n  Note - uses a primitive operator subject to overflow.")

var Lit_881 *jrt.String = jrt.Intern("arbace.core$unchecked_dec_int__inliner__1927000246")

var Lit_882 *jrt.String = jrt.Intern("arbace.core$unchecked_dec")

var Lit_883 *jrt.String = jrt.Intern("Returns a number one less than x, a long.\n  Note - uses a primitive operator subject to overflow.")

var Lit_884 *jrt.String = jrt.Intern("arbace.core$unchecked_dec__inliner__1927000249")

var Lit_885 *jrt.String = jrt.Intern("arbace.core$unchecked_negate_int")

var Lit_886 *jrt.String = jrt.Intern("Returns the negation of x, an int.\n  Note - uses a primitive operator subject to overflow.")

var Lit_887 *jrt.String = jrt.Intern("arbace.core$unchecked_negate_int__inliner__1927000252")

var Lit_888 *jrt.String = jrt.Intern("arbace.core$unchecked_negate")

var Lit_889 *jrt.String = jrt.Intern("Returns the negation of x, a long.\n  Note - uses a primitive operator subject to overflow.")

var Lit_890 *jrt.String = jrt.Intern("arbace.core$unchecked_negate__inliner__1927000255")

var Lit_891 *jrt.String = jrt.Intern("arbace.core$unchecked_add_int")

var Lit_892 *jrt.String = jrt.Intern("Returns the sum of x and y, both int.\n  Note - uses a primitive operator subject to overflow.")

var Lit_893 *jrt.String = jrt.Intern("arbace.core$unchecked_add_int__inliner__1927000258")

var Lit_894 *jrt.String = jrt.Intern("arbace.core$unchecked_add")

var Lit_895 *jrt.String = jrt.Intern("Returns the sum of x and y, both long.\n  Note - uses a primitive operator subject to overflow.")

var Lit_896 *jrt.String = jrt.Intern("arbace.core$unchecked_add__inliner__1927000261")

var Lit_897 *jrt.String = jrt.Intern("arbace.core$unchecked_subtract_int")

var Lit_898 *jrt.String = jrt.Intern("Returns the difference of x and y, both int.\n  Note - uses a primitive operator subject to overflow.")

var Lit_899 *jrt.String = jrt.Intern("arbace.core$unchecked_subtract_int__inliner__1927000264")

var Lit_900 *jrt.String = jrt.Intern("arbace.core$unchecked_subtract")

var Lit_901 *jrt.String = jrt.Intern("Returns the difference of x and y, both long.\n  Note - uses a primitive operator subject to overflow.")

var Lit_902 *jrt.String = jrt.Intern("arbace.core$unchecked_subtract__inliner__1927000267")

var Lit_903 *jrt.String = jrt.Intern("arbace.core$unchecked_multiply_int")

var Lit_904 *jrt.String = jrt.Intern("Returns the product of x and y, both int.\n  Note - uses a primitive operator subject to overflow.")

var Lit_905 *jrt.String = jrt.Intern("arbace.core$unchecked_multiply_int__inliner__1927000270")

var Lit_906 *jrt.String = jrt.Intern("arbace.core$unchecked_multiply")

var Lit_907 *jrt.String = jrt.Intern("Returns the product of x and y, both long.\n  Note - uses a primitive operator subject to overflow.")

var Lit_908 *jrt.String = jrt.Intern("arbace.core$unchecked_multiply__inliner__1927000273")

var Lit_909 *jrt.String = jrt.Intern("arbace.core$unchecked_divide_int")

var Lit_910 *jrt.String = jrt.Intern("Returns the division of x by y, both int.\n  Note - uses a primitive operator subject to truncation.")

var Lit_911 *jrt.String = jrt.Intern("arbace.core$unchecked_divide_int__inliner__1927000276")

var Lit_912 *jrt.String = jrt.Intern("arbace.core$unchecked_remainder_int")

var Lit_913 *jrt.String = jrt.Intern("Returns the remainder of division of x by y, both int.\n  Note - uses a primitive operator subject to truncation.")

var Lit_914 *jrt.String = jrt.Intern("arbace.core$unchecked_remainder_int__inliner__1927000279")

var Lit_915 *jrt.String = jrt.Intern("arbace.core$pos_QMARK_")

var Lit_916 *jrt.String = jrt.Intern("Returns true if num is greater than zero, else false")

var Lit_917 *jrt.String = jrt.Intern("arbace.core$pos_QMARK___inliner__1927000282")

var Lit_918 *jrt.String = jrt.Intern("arbace.core$neg_QMARK_")

var Lit_919 *jrt.String = jrt.Intern("Returns true if num is less than zero, else false")

var Lit_920 *jrt.String = jrt.Intern("arbace.core$neg_QMARK___inliner__1927000285")

var Lit_921 *jrt.String = jrt.Intern("arbace.core$quot")

var Lit_922 *jrt.String = jrt.Intern("quot[ient] of dividing numerator by denominator.")

var Lit_923 *jrt.String = jrt.Intern("arbace.core$quot__inliner__1927000288")

var Lit_924 *jrt.String = jrt.Intern("arbace.core$rem")

var Lit_925 *jrt.String = jrt.Intern("remainder of dividing numerator by denominator.")

var Lit_926 *jrt.String = jrt.Intern("arbace.core$rem__inliner__1927000291")

var Lit_927 *jrt.String = jrt.Intern("arbace.core$rationalize")

var Lit_928 *jrt.String = jrt.Intern("arbace.core$bit_not")

var Lit_929 *jrt.String = jrt.Intern("Bitwise complement")

var Lit_930 *jrt.String = jrt.Intern("arbace.core$bit_not__inliner__1927000295")

var Lit_931 *jrt.String = jrt.Intern("arbace.core$bit_and")

var Lit_932 *jrt.String = jrt.Intern("Bitwise and")

var Lit_933 *jrt.String = jrt.Intern("arbace.core$bit_or")

var Lit_934 *jrt.String = jrt.Intern("Bitwise or")

var Lit_935 *jrt.String = jrt.Intern("arbace.core$bit_xor")

var Lit_936 *jrt.String = jrt.Intern("Bitwise exclusive or")

var Lit_937 *jrt.String = jrt.Intern("arbace.core$bit_and_not")

var Lit_938 *jrt.String = jrt.Intern("Bitwise and with complement")

var Lit_939 *jrt.String = jrt.Intern("arbace.core$bit_clear")

var Lit_940 *jrt.String = jrt.Intern("arbace.core$bit_set")

var Lit_941 *jrt.String = jrt.Intern("arbace.core$bit_flip")

var Lit_942 *jrt.String = jrt.Intern("arbace.core$bit_test")

var Lit_943 *jrt.String = jrt.Intern("arbace.core$bit_shift_left")

var Lit_944 *jrt.String = jrt.Intern("Bitwise shift left")

var Lit_945 *jrt.String = jrt.Intern("arbace.core$bit_shift_left__inliner__1927000306")

var Lit_946 *jrt.String = jrt.Intern("arbace.core$bit_shift_right")

var Lit_947 *jrt.String = jrt.Intern("Bitwise shift right")

var Lit_948 *jrt.String = jrt.Intern("arbace.core$bit_shift_right__inliner__1927000309")

var Lit_949 *jrt.String = jrt.Intern("arbace.core$unsigned_bit_shift_right")

var Lit_950 *jrt.String = jrt.Intern("Bitwise shift right, without sign-extension.")

var Lit_951 *jrt.String = jrt.Intern("arbace.core$unsigned_bit_shift_right__inliner__1927000312")

var Lit_952 *jrt.String = jrt.Intern("1.6")

var Lit_953 *jrt.String = jrt.Intern("arbace.core$integer_QMARK_")

var Lit_954 *jrt.String = jrt.Intern("arbace.core$even_QMARK_")

var Lit_955 *jrt.String = jrt.Intern("arbace.core$odd_QMARK_")

var Lit_956 *jrt.String = jrt.Intern("arbace.core$int_QMARK_")

var Lit_957 *jrt.String = jrt.Intern("arbace.core$pos_int_QMARK_")

var Lit_958 *jrt.String = jrt.Intern("arbace.core$neg_int_QMARK_")

var Lit_959 *jrt.String = jrt.Intern("arbace.core$nat_int_QMARK_")

var Lit_960 *jrt.String = jrt.Intern("arbace.core$double_QMARK_")

var Lit_961 *jrt.String = jrt.Intern("arbace.core$complement")

var Lit_962 *jrt.String = jrt.Intern("arbace.core$constantly")

var Lit_963 *jrt.String = jrt.Intern("arbace.core$identity")

var Lit_964 *jrt.String = jrt.Intern("arbace.core$peek")

var Lit_965 *jrt.String = jrt.Intern("arbace.core$pop")

var Lit_966 *jrt.String = jrt.Intern("arbace.core$map_entry_QMARK_")

var Lit_967 *jrt.String = jrt.Intern("arbace.core$contains_QMARK_")

var Lit_968 *jrt.String = jrt.Intern("arbace.core$get")

var Lit_969 *jrt.String = jrt.Intern("Returns the value mapped to key, not-found or nil if key not present\n  in associative collection, set, string, array, or ILookup instance.")

var Lit_970 *jrt.String = jrt.Intern("arbace.core$get__inliner__1927000334")

var Lit_971 *jrt.String = jrt.Intern("arbace.core$req_BANG_")

var Lit_972 *jrt.String = jrt.Intern("Like arity-2 'get', but throws if key not present.")

var Lit_973 *jrt.String = jrt.Intern("arbace.core$req_BANG___inliner__1927000337")

var Lit_974 *jrt.String = jrt.Intern("1.13")

var Lit_975 *jrt.String = jrt.Intern("arbace.core$dissoc")

var Lit_976 *jrt.String = jrt.Intern("arbace.core$disj")

var Lit_977 *jrt.String = jrt.Intern("arbace.core$find")

var Lit_978 *jrt.String = jrt.Intern("arbace.core$keys")

var Lit_979 *jrt.String = jrt.Intern("arbace.core$vals")

var Lit_980 *jrt.String = jrt.Intern("arbace.core$key")

var Lit_981 *jrt.String = jrt.Intern("arbace.core$val")

var Lit_982 *jrt.String = jrt.Intern("arbace.core$rseq")

var Lit_983 *jrt.String = jrt.Intern("arbace.core$name")

var Lit_984 *jrt.String = jrt.Intern("arbace.core$namespace")

var Lit_985 *jrt.String = jrt.Intern("arbace.core$boolean")

var Lit_986 *jrt.String = jrt.Intern("Coerce to boolean")

var Lit_987 *jrt.String = jrt.Intern("arbace.core$boolean__inliner__1927000350")

var Lit_988 *jrt.String = jrt.Intern("arbace.core$ident_QMARK_")

var Lit_989 *jrt.String = jrt.Intern("arbace.core$simple_ident_QMARK_")

var Lit_990 *jrt.String = jrt.Intern("arbace.core$qualified_ident_QMARK_")

var Lit_991 *jrt.String = jrt.Intern("arbace.core$simple_symbol_QMARK_")

var Lit_992 *jrt.String = jrt.Intern("arbace.core$qualified_symbol_QMARK_")

var Lit_993 *jrt.String = jrt.Intern("arbace.core$simple_keyword_QMARK_")

var Lit_994 *jrt.String = jrt.Intern("arbace.core$qualified_keyword_QMARK_")

var Lit_995 *jrt.String = jrt.Intern("arbace.core$locking")

var Lit_996 *jrt.String = jrt.Intern("kn8,arglistsyn1,xyn4,formyn1,&yn4,morekn3,dockn5,addedkn4,linekn6,columnkn4,fileyn5,formskn7,privateyn7,optionsyn10,valid-keysyn4,nameyn10,docstring?yn9,attr-map?yn11,dispatch-fnyn7,multifnyn12,dispatch-valyn7,fn-tailkn3,tagyn19,arbace.lang.MultiFnkn6,staticyn14,dispatch-val-xyn14,dispatch-val-yyn5,pairsyn8,bindingsyn4,thenyn4,elseyn7,oldformyn4,bodyyn11,binding-mapyn1,fyn4,argsyn6,fntailyn3,symyn16,arbace.lang.ARefyn5,stateyn8,executoryn17,arbace.lang.Agentyn16,arbace.lang.IRefyn3,keyyn2,fnyn9,new-stateyn10,handler-fnyn12,mode-keywordyn1,akn10,deprecatedyn27,java.util.concurrent.Futureyn10,timeout-msyn11,timeout-valyn3,refyn17,arbace.lang.IAtomyn1,yyn18,arbace.lang.IAtom2yn29,arbace.lang.IPersistentVectoryn6,oldvalyn6,newvalyn12,validator-fnyn22,arbace.lang.IReferenceyn12,metadata-mapyn15,arbace.lang.Refyn3,funyn3,valyn1,nyn21,flags-ignored-for-nowv11,arbace.core2,..m12,R0,L2,V2,R1,R2,V4,R1,R2,R3,R4,R5,s367,form => fieldName-symbol or (instanceMethodName-symbol args*)\n\n  Expands into a member access (.) of the first member on the first\n  argument, followed by the next member on the result, etc. For\n  instance:\n\n  (.. System (getProperties) (get \"os.name\"))\n\n  expands to:\n\n  (. (. System (getProperties)) (get \"os.name\"))\n\n  but is easier to write, read, and understand.R6,s3,1.0R7,i1666,R8,i1,R9,s14,arbace/core.aev11,arbace.core2,->m12,R0,L1,V3,R1,R3,R10,R5,s226,Threads the expr through the forms. Inserts x as the\n  second item in the first form, making a list of it if it is not a\n  list already. If there are more forms, inserts the first form as the\n  second item in second form, etc.R6,s3,1.0R7,i1684,R8,i1,R9,s14,arbace/core.aev11,arbace.core3,->>m12,R0,L1,V3,R1,R3,R10,R5,s222,Threads the expr through the forms. Inserts x as the\n  last item in the first form, making a list of it if it is not a\n  list already. If there are more forms, inserts the first form as the\n  last item in second form, etc.R6,s3,1.1R7,i1700,R8,i1,R9,s14,arbace/core.aev11,arbace.core3,mapm6,R7,i1716,R8,i1,R9,s14,arbace/core.aev11,arbace.core19,check-valid-optionsm12,R11,TR0,L1,V3,R12,R3,R13,R5,s98,Throws an exception if the given option map contains keys not listed\n  as valid, else returns nil.R7,i1718,R8,i1,R9,s14,arbace/core.aev11,arbace.core16,global-hierarchym6,R7,i1730,R8,i1,R9,s14,arbace/core.aev11,arbace.core8,defmultim12,R0,ML1,V6,R14,R15,R16,R17,R3,R12,m4,R7,i1755,R8,i15,R5,s788,Creates a new multimethod with the associated dispatch function.\n  The docstring and attr-map are optional.\n\n  Options are key-value pairs and may be one of:\n\n  :default\n\n  The default dispatch value, defaults to :default\n\n  :hierarchy\n\n  The value used for hierarchical dispatch (e.g. ::square is-a ::shape)\n\n  Hierarchies are type-like relationships that do not depend upon type\n  inheritance. By default Clojure's multimethods dispatch off of a\n  global hierarchy map.  However, a hierarchy relationship can be\n  created with the derive function used to augment the root ancestor\n  created with make-hierarchy.\n\n  Multimethods expect the value of the hierarchy option to be supplied as\n  a reference type e.g. a var (i.e. via the Var-quote dispatch macro #'\n  or the var special form).R6,s3,1.0R7,i1732,R8,i1,R9,s14,arbace/core.aev11,arbace.core9,defmethodm12,R0,L1,V4,R18,R19,R3,R20,R5,s81,Creates and installs a new method of multimethod associated with dispatch-value. R6,s3,1.0R7,i1790,R8,i1,R9,s14,arbace/core.aev11,arbace.core18,remove-all-methodsm14,R0,L1,V1,Myn7,multifnm2,R21,R22,R5,s42,Removes all of the methods of multimethod.R6,s3,1.2R23,TR7,i1796,R8,i1,R9,s14,arbace/core.aev11,arbace.core13,remove-methodm14,R0,L1,V2,Myn7,multifnm2,R21,R22,R19,R5,s65,Removes the method of multimethod associated with dispatch-value.R6,s3,1.0R23,TR7,i1803,R8,i1,R9,s14,arbace/core.aev11,arbace.core13,prefer-methodm14,R0,L1,V3,Myn7,multifnm2,R21,R22,R24,R25,R5,s106,Causes the multimethod to prefer matches of dispatch-val-x over dispatch-val-y\n   when there is a conflictR6,s3,1.0R23,TR7,i1810,R8,i1,R9,s14,arbace/core.aev11,arbace.core7,methodsm14,R0,L1,V1,Myn7,multifnm2,R21,R22,R5,s69,Given a multimethod, returns a map of dispatch values -> dispatch fnsR6,s3,1.0R23,TR7,i1818,R8,i1,R9,s14,arbace/core.aev11,arbace.core10,get-methodm14,R0,L1,V2,Myn7,multifnm2,R21,R22,R19,R5,s135,Given a multimethod and a dispatch value, returns the dispatch fn\n  that would apply to that value, or nil if none apply and no defaultR6,s3,1.0R23,TR7,i1824,R8,i1,R9,s14,arbace/core.aev11,arbace.core7,prefersm14,R0,L1,V1,Myn7,multifnm2,R21,R22,R5,s76,Given a multimethod, returns a map of preferred value -> set of other valuesR6,s3,1.0R23,TR7,i1831,R8,i1,R9,s14,arbace/core.aev11,arbace.core11,assert-argsm10,R11,TR0,L1,V2,R3,R26,R7,i1839,R8,i1,R9,s14,arbace/core.aev11,arbace.core6,if-letm12,R0,L2,V2,R27,R28,V5,R27,R28,R29,R3,R30,R5,s132,bindings => binding-form test\n\n  If test is true, evaluates then with binding-form bound to the value of\n  test, if not, yields elseR6,s3,1.0R7,i1848,R8,i1,R9,s14,arbace/core.aev11,arbace.core8,when-letm12,R0,L1,V3,R27,R3,R31,R5,s111,bindings => binding-form test\n\n  When test is true, evaluates body with binding-form bound to the value of testR6,s3,1.0R7,i1868,R8,i1,R9,s14,arbace/core.aev11,arbace.core7,if-somem12,R0,L2,V2,R27,R28,V5,R27,R28,R29,R3,R30,R5,s137,bindings => binding-form test\n\n   If test is not nil, evaluates then with binding-form bound to the\n   value of test, if not, yields elseR6,s3,1.6R7,i1883,R8,i1,R9,s14,arbace/core.aev11,arbace.core9,when-somem12,R0,L1,V3,R27,R3,R31,R5,s118,bindings => binding-form test\n\n   When test is not nil, evaluates body with binding-form bound to the\n   value of testR6,s3,1.6R7,i1903,R8,i1,R9,s14,arbace/core.aev11,arbace.core20,push-thread-bindingsm14,R0,L1,V1,R27,R5,s414,WARNING: This is a low-level function. Prefer high-level macros like\n  binding where ever possible.\n\n  Takes a map of Var/value pairs. Binds each Var to the associated value for\n  the current thread. Each call *MUST* be accompanied by a matching call to\n  pop-thread-bindings wrapped in a try-finally!\n\n      (push-thread-bindings bindings)\n      (try\n        ...\n        (finally\n          (pop-thread-bindings)))R6,s3,1.1R23,TR7,i1920,R8,i1,R9,s14,arbace/core.aev11,arbace.core19,pop-thread-bindingsm14,R0,L1,V0,R5,s113,Pop one set of bindings pushed with push-binding before. It is an error to\n  pop bindings without pushing before.R6,s3,1.1R23,TR7,i1938,R8,i1,R9,s14,arbace/core.aev11,arbace.core19,get-thread-bindingsm14,R0,L1,V0,R5,s89,Get a map with the Var/value pairs which is currently in effect for the\n  current thread.R6,s3,1.1R23,TR7,i1946,R8,i1,R9,s14,arbace/core.aev11,arbace.core7,bindingm12,R0,L1,V3,R27,R3,R31,R5,s351,binding => var-symbol init-expr\n\n  Creates new bindings for the (already-existing) vars, with the\n  supplied initial values, executes the exprs in an implicit do, then\n  re-establishes the bindings that existed before.  The new bindings\n  are made in parallel (unlike let); all init-exprs are evaluated\n  before the vars are bound to their new values.R6,s3,1.0R7,i1954,R8,i1,R9,s14,arbace/core.aev11,arbace.core14,with-bindings*m14,R0,L1,V4,R32,R33,R3,R34,R5,s227,Takes a map of Var/value pairs. Installs for the given Vars the associated\n  values as thread-local bindings. Then calls f with the supplied arguments.\n  Pops the installed bindings after f returned. Returns whatever f returns.R6,s3,1.1R23,TR7,i1980,R8,i1,R9,s14,arbace/core.aev11,arbace.core13,with-bindingsm12,R0,L1,V3,R32,R3,R31,R5,s212,Takes a map of Var/value pairs. Installs for the given Vars the associated\n  values as thread-local bindings. Then executes body. Pops the installed\n  bindings after body was evaluated. Returns the value of body.R6,s3,1.1R7,i1993,R8,i1,R9,s14,arbace/core.aev11,arbace.core9,bound-fn*m14,R0,L1,V1,R33,R5,s281,Returns a function, which will install the same bindings in effect as in\n  the thread at the time bound-fn* was called and then call f with any given\n  arguments. This may be used to define a helper function which runs on a\n  different thread, but needs the same bindings in place.R6,s3,1.1R23,TR7,i2001,R8,i1,R9,s14,arbace/core.aev11,arbace.core8,bound-fnm12,R0,L1,V2,R3,R35,R5,s267,Returns a function defined by the given fntail, which will install the\n  same bindings in effect as in the thread at the time bound-fn was called.\n  This may be used to define a helper function which runs on a different\n  thread, but needs the same bindings in place.R6,s3,1.1R7,i2013,R8,i1,R9,s14,arbace/core.aev11,arbace.core8,find-varm14,R0,L1,V1,R36,R5,s98,Returns the global var named by the namespace-qualified symbol, or\n  nil if no var with that name.R6,s3,1.0R23,TR7,i2022,R8,i1,R9,s14,arbace/core.aev11,arbace.core19,binding-conveyor-fnm12,R0,L1,V1,R33,R11,TR6,s3,1.3R7,i2029,R8,i1,R9,s14,arbace/core.aev11,arbace.core15,setup-referencem10,R11,TR0,L1,V2,Myn1,rm2,R21,R37,R12,R7,i2052,R8,i1,R9,s14,arbace/core.aev11,arbace.core5,agentm14,R0,L1,V3,R38,R3,R12,R5,s828,Creates and returns an agent with an initial value of state and\n  zero or more options (in any order):\n\n  :meta metadata-map\n\n  :validator validate-fn\n\n  :error-handler handler-fn\n\n  :error-mode mode-keyword\n\n  If metadata-map is supplied, it will become the metadata on the\n  agent. validate-fn must be nil or a side-effect-free fn of one\n  argument, which will be passed the intended new state on any state\n  change. If the new state is unacceptable, the validate-fn should\n  return false or throw an exception.  handler-fn is called if an\n  action throws an exception or if validate-fn rejects a new state --\n  see set-error-handler! for details.  The mode-keyword may be either\n  :continue (the default if an error-handler is given) or :fail (the\n  default if no error-handler is given) -- see set-error-mode! for\n  details.R6,s3,1.0R23,TR7,i2061,R8,i1,R9,s14,arbace/core.aev11,arbace.core24,set-agent-send-executor!m12,R0,L1,V1,R39,R5,s43,Sets the ExecutorService to be used by sendR6,s3,1.5R7,i2096,R8,i1,R9,s14,arbace/core.aev11,arbace.core28,set-agent-send-off-executor!m12,R0,L1,V1,R39,R5,s47,Sets the ExecutorService to be used by send-offR6,s3,1.5R7,i2102,R8,i1,R9,s14,arbace/core.aev11,arbace.core8,send-viam12,R0,L1,V5,R39,Myn1,am2,R21,R40,R33,R3,R34,R5,s207,Dispatch an action to an agent. Returns the agent immediately.\n  Subsequently, in a thread supplied by executor, the state of the agent\n  will be set to the value of:\n\n  (apply action-fn state-of-agent args)R6,s3,1.5R7,i2108,R8,i1,R9,s14,arbace/core.aev11,arbace.core4,sendm14,R0,L1,V4,Myn1,am2,R21,R40,R33,R3,R34,R5,s205,Dispatch an action to an agent. Returns the agent immediately.\n  Subsequently, in a thread from a thread pool, the state of the agent\n  will be set to the value of:\n\n  (apply action-fn state-of-agent args)R6,s3,1.0R23,TR7,i2118,R8,i1,R9,s14,arbace/core.aev11,arbace.core8,send-offm14,R0,L1,V4,Myn1,am2,R21,R40,R33,R3,R34,R5,s215,Dispatch a potentially blocking action to an agent. Returns the\n  agent immediately. Subsequently, in a separate thread, the state of\n  the agent will be set to the value of:\n\n  (apply action-fn state-of-agent args)R6,s3,1.0R23,TR7,i2129,R8,i1,R9,s14,arbace/core.aev11,arbace.core21,release-pending-sendsm14,R0,L1,V0,R5,s393,Normally, actions sent directly or indirectly during another action\n  are held until the action completes (changes the agent's\n  state). This function can be used to dispatch any pending sent\n  actions immediately. This has no impact on actions sent during a\n  transaction, which are still held until commit. If no action is\n  occurring, does nothing. Returns the number of actions dispatched.R6,s3,1.0R23,TR7,i2140,R8,i1,R9,s14,arbace/core.aev11,arbace.core9,add-watchm14,R0,L1,V3,Myn9,referencem2,R21,R41,R42,R43,R5,s848,Adds a watch function to an agent/atom/var/ref reference. The watch\n  fn must be a fn of 4 args: a key, the reference, its old-state, its\n  new-state. Whenever the reference's state might have been changed,\n  any registered watches will have their functions called. The watch fn\n  will be called synchronously, on the agent's thread if an agent,\n  before any pending sends if agent or ref. Note that an atom's or\n  ref's state may have changed again prior to the fn call, so use\n  old/new-state rather than derefing the reference. Note also that watch\n  fns may be called from multiple threads simultaneously. Var watchers\n  are triggered only by root binding changes, not thread-local\n  set!s. Keys must be unique per reference, and can be used to remove\n  the watch with remove-watch, but are otherwise considered opaque by\n  the watch mechanism.R6,s3,1.0R23,TR7,i2151,R8,i1,R9,s14,arbace/core.aev11,arbace.core12,remove-watchm14,R0,L1,V2,Myn9,referencem2,R21,R41,R42,R5,s51,Removes a watch (set by add-watch) from a referenceR6,s3,1.0R23,TR7,i2169,R8,i1,R9,s14,arbace/core.aev11,arbace.core11,agent-errorm14,R0,L1,V1,Myn1,am2,R21,R40,R5,s140,Returns the exception thrown during an asynchronous action of the\n  agent if the agent is failed.  Returns nil if the agent is not\n  failed.R6,s3,1.2R23,TR7,i2176,R8,i1,R9,s14,arbace/core.aev11,arbace.core13,restart-agentm14,R0,L1,V4,Myn1,am2,R21,R40,R44,R3,R12,R5,s568,When an agent is failed, changes the agent state to new-state and\n  then un-fails the agent so that sends are allowed again.  If\n  a :clear-actions true option is given, any actions queued on the\n  agent that were being held while it was failed will be discarded,\n  otherwise those held actions will proceed.  The new-state must pass\n  the validator if any, or restart will throw an exception and the\n  agent will remain failed with its old state and error.  Watchers, if\n  any, will NOT be notified of the new state.  Throws an exception if\n  the agent is not failed.R6,s3,1.2R23,TR7,i2184,R8,i1,R9,s14,arbace/core.aev11,arbace.core18,set-error-handler!m14,R0,L1,V2,Myn1,am2,R21,R40,R45,R5,s220,Sets the error-handler of agent a to handler-fn.  If an action\n  being run by the agent throws an exception or doesn't pass the\n  validator fn, handler-fn will be called with two arguments: the\n  agent and the exception.R6,s3,1.2R23,TR7,i2201,R8,i1,R9,s14,arbace/core.aev11,arbace.core13,error-handlerm14,R0,L1,V1,Myn1,am2,R21,R40,R5,s87,Returns the error-handler of agent a, or nil if there is none.\n  See set-error-handler!R6,s3,1.2R23,TR7,i2211,R8,i1,R9,s14,arbace/core.aev11,arbace.core15,set-error-mode!m14,R0,L1,V2,Myn1,am2,R21,R40,R46,R5,s658,Sets the error-mode of agent a to mode-keyword, which must be\n  either :fail or :continue.  If an action being run by the agent\n  throws an exception or doesn't pass the validator fn, an\n  error-handler may be called (see set-error-handler!), after which,\n  if the mode is :continue, the agent will continue as if neither the\n  action that caused the error nor the error itself ever happened.\n\n  If the mode is :fail, the agent will become failed and will stop\n  accepting new 'send' and 'send-off' actions, and any previously\n  queued actions will be held until a 'restart-agent'.  Deref will\n  still work, returning the state of the agent before the error.R6,s3,1.2R23,TR7,i2219,R8,i1,R9,s14,arbace/core.aev11,arbace.core10,error-modem14,R0,L1,V1,Myn1,am2,R21,R40,R5,s55,Returns the error-mode of agent a.  See set-error-mode!R6,s3,1.2R23,TR7,i2236,R8,i1,R9,s14,arbace/core.aev11,arbace.core12,agent-errorsm14,R0,L1,V1,R47,R5,s128,DEPRECATED: Use 'agent-error' instead.\n  Returns a sequence of the exceptions thrown during asynchronous\n  actions of the agent.R6,s3,1.0R48,s3,1.2R7,i2243,R8,i1,R9,s14,arbace/core.aev11,arbace.core18,clear-agent-errorsm14,R0,L1,V1,Myn1,am2,R21,R40,R5,s153,DEPRECATED: Use 'restart-agent' instead.\n  Clears any exceptions thrown during asynchronous actions of the\n  agent, allowing subsequent actions to occur.R6,s3,1.0R48,s3,1.2R7,i2253,R8,i1,R9,s14,arbace/core.aev11,arbace.core15,shutdown-agentsm14,R0,L1,V0,R5,s139,Initiates a shutdown of the thread pools that back the agent\n  system. Running actions will complete, but no new actions will be\n  acceptedR6,s3,1.0R23,TR7,i2261,R8,i1,R9,s14,arbace/core.aev11,arbace.core3,refm14,R0,L2,V1,R1,V3,R1,R3,R12,R5,s903,Creates and returns a Ref with an initial value of x and zero or\n  more options (in any order):\n\n  :meta metadata-map\n\n  :validator validate-fn\n\n  :min-history (default 0)\n  :max-history (default 10)\n\n  If metadata-map is supplied, it will become the metadata on the\n  ref. validate-fn must be nil or a side-effect-free fn of one\n  argument, which will be passed the intended new state on any state\n  change. If the new state is unacceptable, the validate-fn should\n  return false or throw an exception. validate-fn will be called on\n  transaction commit, when all refs have their final values.\n\n  Normally refs accumulate history dynamically as needed to deal with\n  read demands. If you know in advance you will need history you can\n  set :min-history to ensure it will be available when first needed (instead\n  of after a read fault). History is limited, and the limit can be set\n  with :max-history.R6,s3,1.0R23,TR7,i2269,R8,i1,R9,s14,arbace/core.aev11,arbace.core12,deref-futurem10,R11,TR0,L2,V1,Myn3,futm2,R21,R49,V3,Myn3,futm2,R21,R49,R50,R51,R7,i2305,R8,i1,R9,s14,arbace/core.aev11,arbace.core5,derefm14,R0,L2,V1,R52,V3,R52,R50,R51,R5,s670,Also reader macro: @ref/@agent/@var/@atom/@delay/@future/@promise. Within a transaction,\n  returns the in-transaction-value of ref, else returns the\n  most-recently-committed value of ref. When applied to a var, agent\n  or atom, returns its current state. When applied to a delay, forces\n  it if not already forced. When applied to a future, will block if\n  computation not complete. When applied to a promise, will block\n  until a value is delivered.  The variant taking a timeout can be\n  used for blocking references (futures and promises), and will return\n  timeout-val if the timeout (in milliseconds) is reached before a\n  value is available. See also - realized?.R6,s3,1.0R23,TR7,i2313,R8,i1,R9,s14,arbace/core.aev11,arbace.core4,atomm14,R0,L2,V1,R1,V3,R1,R3,R12,R5,s450,Creates and returns an Atom with an initial value of x and zero or\n  more options (in any order):\n\n  :meta metadata-map\n\n  :validator validate-fn\n\n  If metadata-map is supplied, it will become the metadata on the\n  atom. validate-fn must be nil or a side-effect-free fn of one\n  argument, which will be passed the intended new state on any state\n  change. If the new state is unacceptable, the validate-fn should\n  return false or throw an exception.R6,s3,1.0R23,TR7,i2334,R8,i1,R9,s14,arbace/core.aev11,arbace.core5,swap!m14,R0,L4,V2,Myn4,atomm2,R21,R53,R33,V3,Myn4,atomm2,R21,R53,R33,R1,V4,Myn4,atomm2,R21,R53,R33,R1,R54,V6,Myn4,atomm2,R21,R53,R33,R1,R54,R3,R34,R5,s208,Atomically swaps the value of atom to be:\n  (apply f current-value-of-atom args). Note that f may be called\n  multiple times, and thus should be free of side effects.  Returns\n  the value that was swapped in.R6,s3,1.0R23,TR7,i2352,R8,i1,R9,s14,arbace/core.aev11,arbace.core10,swap-vals!m12,R0,L4,MV2,Myn4,atomm2,R21,R55,R33,m2,R21,R56,MV3,Myn4,atomm2,R21,R55,R33,R1,m2,R21,R56,MV4,Myn4,atomm2,R21,R55,R33,R1,R54,m2,R21,R56,MV6,Myn4,atomm2,R21,R55,R33,R1,R54,R3,R34,m2,R21,R56,R5,s236,Atomically swaps the value of atom to be:\n  (apply f current-value-of-atom args). Note that f may be called\n  multiple times, and thus should be free of side effects.\n  Returns [old new], the value of the atom before and after the swap.R6,s3,1.9R7,i2364,R8,i1,R9,s14,arbace/core.aev11,arbace.core16,compare-and-set!m14,R0,L1,V3,Myn4,atomm2,R21,R53,R57,R58,R5,s157,Atomically sets the value of atom to newval if and only if the\n  current value of the atom is identical to oldval. Returns true if\n  set happened, else falseR6,s3,1.0R23,TR7,i2375,R8,i1,R9,s14,arbace/core.aev11,arbace.core6,reset!m14,R0,L1,V2,Myn4,atomm2,R21,R53,R58,R5,s88,Sets the value of atom to newval without regard for the\n  current value. Returns newval.R6,s3,1.0R23,TR7,i2383,R8,i1,R9,s14,arbace/core.aev11,arbace.core11,reset-vals!m12,R0,L1,MV2,Myn4,atomm2,R21,R55,R58,m2,R21,R56,R5,s105,Sets the value of atom to newval. Returns [old new], the value of the\n   atom before and after the reset.R6,s3,1.9R7,i2390,R8,i1,R9,s14,arbace/core.aev11,arbace.core14,set-validator!m14,R0,L1,V2,Myn4,irefm2,R21,R41,R59,R5,s431,Sets the validator-fn for a var/ref/agent/atom. validator-fn must be nil or a\n  side-effect-free fn of one argument, which will be passed the intended\n  new state on any state change. If the new state is unacceptable, the\n  validator-fn should return false or throw an exception. If the current state (root\n  value if var) is not acceptable to the new validator, an exception\n  will be thrown and the validator will not be changed.R6,s3,1.0R23,TR7,i2396,R8,i1,R9,s14,arbace/core.aev11,arbace.core13,get-validatorm14,R0,L1,V1,Myn4,irefm2,R21,R41,R5,s47,Gets the validator-fn for a var/ref/agent/atom.R6,s3,1.0R23,TR7,i2407,R8,i1,R9,s14,arbace/core.aev11,arbace.core11,alter-meta!m14,R0,L1,V4,Myn4,irefm2,R21,R60,R33,R3,R34,R5,s139,Atomically sets the metadata for a namespace/var/ref/agent/atom to be:\n\n  (apply f its-current-meta args)\n\n  f must be free of side-effectsR6,s3,1.0R23,TR7,i2413,R8,i1,R9,s14,arbace/core.aev11,arbace.core11,reset-meta!m14,R0,L1,V2,Myn4,irefm2,R21,R60,R61,R5,s65,Atomically resets the metadata for a namespace/var/ref/agent/atomR6,s3,1.0R23,TR7,i2423,R8,i1,R9,s14,arbace/core.aev11,arbace.core7,commutem14,R0,L1,V4,Myn3,refm2,R21,R62,R63,R3,R34,R5,s451,Must be called in a transaction. Sets the in-transaction-value of\n  ref to:\n\n  (apply fun in-transaction-value-of-ref args)\n\n  and returns the in-transaction-value of ref.\n\n  At the commit point of the transaction, sets the value of ref to be:\n\n  (apply fun most-recently-committed-value-of-ref args)\n\n  Thus fun should be commutative, or, failing that, you must accept\n  last-one-in-wins behavior.  commute allows for more concurrency than\n  ref-set.R6,s3,1.0R23,TR7,i2429,R8,i1,R9,s14,arbace/core.aev11,arbace.core5,alterm14,R0,L1,V4,Myn3,refm2,R21,R62,R63,R3,R34,R5,s171,Must be called in a transaction. Sets the in-transaction-value of\n  ref to:\n\n  (apply fun in-transaction-value-of-ref args)\n\n  and returns the in-transaction-value of ref.R6,s3,1.0R23,TR7,i2450,R8,i1,R9,s14,arbace/core.aev11,arbace.core7,ref-setm14,R0,L1,V2,Myn3,refm2,R21,R62,R64,R5,s70,Must be called in a transaction. Sets the value of ref.\n  Returns val.R6,s3,1.0R23,TR7,i2462,R8,i1,R9,s14,arbace/core.aev11,arbace.core17,ref-history-countm14,R0,L1,V1,Myn3,refm2,R21,R62,R5,s34,Returns the history count of a refR6,s3,1.1R23,TR7,i2470,R8,i1,R9,s14,arbace/core.aev11,arbace.core15,ref-min-historym14,R0,L2,V1,Myn3,refm2,R21,R62,V2,Myn3,refm2,R21,R62,R65,R5,s61,Gets the min-history of a ref, or sets it and returns the refR6,s3,1.1R23,TR7,i2477,R8,i1,R9,s14,arbace/core.aev11,arbace.core15,ref-max-historym14,R0,L2,V1,Myn3,refm2,R21,R62,V2,Myn3,refm2,R21,R62,R65,R5,s61,Gets the max-history of a ref, or sets it and returns the refR6,s3,1.1R23,TR7,i2486,R8,i1,R9,s14,arbace/core.aev11,arbace.core6,ensurem14,R0,L1,V1,Myn3,refm2,R21,R62,R5,s188,Must be called in a transaction. Protects the ref from modification\n  by other transactions.  Returns the in-transaction-value of\n  ref. Allows for more concurrency than (ref-set ref @ref)R6,s3,1.0R23,TR7,i2495,R8,i1,R9,s14,arbace/core.aev11,arbace.core4,syncm12,R0,L1,V3,R66,R3,R31,R5,s364,transaction-flags => TBD, pass nil for now\n\n  Runs the exprs (in an implicit do) in a transaction that encompasses\n  exprs and any nested calls.  Starts a transaction if none is already\n  running on this thread. Any uncaught exception will abort the\n  transaction and flow out of sync. The exprs may be run more than\n  once, but any effects on Refs will be atomic.R6,s3,1.0R7,i2505,R8,i1,R9,s14,arbace/core.aev11,arbace.core3,io!m12,R0,L1,V2,R3,R31,R5,s206,If an io! block occurs in a transaction, throws an\n  IllegalStateException, else runs body in an implicit do. If the\n  first expression in body is a literal string, will use that as the\n  exception message.R6,s3,1.0R7,i2518,R8,i1,R9,s14,arbace/core.ae")

var Lit_997 *jrt.String = jrt.Intern("arbace.core$_DOT__DOT_")

var Lit_998 *jrt.String = jrt.Intern("arbace.core$__GT_")

var Lit_999 *jrt.String = jrt.Intern("arbace.core$__GT__GT_")

var Lit_1000 *jrt.String = jrt.Intern("arbace.core$check_valid_options")

var Lit_1001 *jrt.String = jrt.Intern("arbace.core$defmulti")

var Lit_1002 *jrt.String = jrt.Intern("arbace.core$defmethod")

var Lit_1003 *jrt.String = jrt.Intern("arbace.core$remove_all_methods")

var Lit_1004 *jrt.String = jrt.Intern("arbace.core$remove_method")

var Lit_1005 *jrt.String = jrt.Intern("arbace.core$prefer_method")

var Lit_1006 *jrt.String = jrt.Intern("arbace.core$methods")

var Lit_1007 *jrt.String = jrt.Intern("arbace.core$get_method")

var Lit_1008 *jrt.String = jrt.Intern("arbace.core$prefers")

var Lit_1009 *jrt.String = jrt.Intern("arbace.core$assert_args")

var Lit_1010 *jrt.String = jrt.Intern("arbace.core$if_let")

var Lit_1011 *jrt.String = jrt.Intern("arbace.core$when_let")

var Lit_1012 *jrt.String = jrt.Intern("arbace.core$if_some")

var Lit_1013 *jrt.String = jrt.Intern("arbace.core$when_some")

var Lit_1014 *jrt.String = jrt.Intern("arbace.core$push_thread_bindings")

var Lit_1015 *jrt.String = jrt.Intern("arbace.core$pop_thread_bindings")

var Lit_1016 *jrt.String = jrt.Intern("arbace.core$get_thread_bindings")

var Lit_1017 *jrt.String = jrt.Intern("arbace.core$binding")

var Lit_1018 *jrt.String = jrt.Intern("arbace.core$with_bindings_STAR_")

var Lit_1019 *jrt.String = jrt.Intern("arbace.core$with_bindings")

var Lit_1020 *jrt.String = jrt.Intern("arbace.core$bound_fn_STAR_")

var Lit_1021 *jrt.String = jrt.Intern("arbace.core$bound_fn")

var Lit_1022 *jrt.String = jrt.Intern("arbace.core$find_var")

var Lit_1023 *jrt.String = jrt.Intern("arbace.core$binding_conveyor_fn")

var Lit_1024 *jrt.String = jrt.Intern("arbace.core$setup_reference")

var Lit_1025 *jrt.String = jrt.Intern("arbace.core$agent")

var Lit_1026 *jrt.String = jrt.Intern("arbace.core$set_agent_send_executor_BANG_")

var Lit_1027 *jrt.String = jrt.Intern("arbace.core$set_agent_send_off_executor_BANG_")

var Lit_1028 *jrt.String = jrt.Intern("arbace.core$send_via")

var Lit_1029 *jrt.String = jrt.Intern("arbace.core$send")

var Lit_1030 *jrt.String = jrt.Intern("arbace.core$send_off")

var Lit_1031 *jrt.String = jrt.Intern("arbace.core$release_pending_sends")

var Lit_1032 *jrt.String = jrt.Intern("arbace.core$add_watch")

var Lit_1033 *jrt.String = jrt.Intern("arbace.core$remove_watch")

var Lit_1034 *jrt.String = jrt.Intern("arbace.core$agent_error")

var Lit_1035 *jrt.String = jrt.Intern("arbace.core$restart_agent")

var Lit_1036 *jrt.String = jrt.Intern("arbace.core$set_error_handler_BANG_")

var Lit_1037 *jrt.String = jrt.Intern("arbace.core$error_handler")

var Lit_1038 *jrt.String = jrt.Intern("arbace.core$set_error_mode_BANG_")

var Lit_1039 *jrt.String = jrt.Intern("arbace.core$error_mode")

var Lit_1040 *jrt.String = jrt.Intern("arbace.core$agent_errors")

var Lit_1041 *jrt.String = jrt.Intern("arbace.core$clear_agent_errors")

var Lit_1042 *jrt.String = jrt.Intern("arbace.core$shutdown_agents")

var Lit_1043 *jrt.String = jrt.Intern("arbace.core$ref")

var Lit_1044 *jrt.String = jrt.Intern("arbace.core$deref_future")

var Lit_1045 *jrt.String = jrt.Intern("arbace.core$deref")

var Lit_1046 *jrt.String = jrt.Intern("arbace.core$atom")

var Lit_1047 *jrt.String = jrt.Intern("arbace.core$swap_BANG_")

var Lit_1048 *jrt.String = jrt.Intern("arbace.core$swap_vals_BANG_")

var Lit_1049 *jrt.String = jrt.Intern("arbace.core$compare_and_set_BANG_")

var Lit_1050 *jrt.String = jrt.Intern("arbace.core$reset_BANG_")

var Lit_1051 *jrt.String = jrt.Intern("arbace.core$reset_vals_BANG_")

var Lit_1052 *jrt.String = jrt.Intern("arbace.core$set_validator_BANG_")

var Lit_1053 *jrt.String = jrt.Intern("arbace.core$get_validator")

var Lit_1054 *jrt.String = jrt.Intern("arbace.core$alter_meta_BANG_")

var Lit_1055 *jrt.String = jrt.Intern("arbace.core$reset_meta_BANG_")

var Lit_1056 *jrt.String = jrt.Intern("arbace.core$commute")

var Lit_1057 *jrt.String = jrt.Intern("arbace.core$alter")

var Lit_1058 *jrt.String = jrt.Intern("arbace.core$ref_set")

var Lit_1059 *jrt.String = jrt.Intern("arbace.core$ref_history_count")

var Lit_1060 *jrt.String = jrt.Intern("arbace.core$ref_min_history")

var Lit_1061 *jrt.String = jrt.Intern("arbace.core$ref_max_history")

var Lit_1062 *jrt.String = jrt.Intern("arbace.core$ensure")

var Lit_1063 *jrt.String = jrt.Intern("arbace.core$sync")

var Lit_1064 *jrt.String = jrt.Intern("arbace.core$io_BANG_")

var Lit_1065 *jrt.String = jrt.Intern("kn8,arglistsyn3,valkn3,dockn5,addedkn3,tagkn4,linekn6,columnkn4,fileyn20,arbace.lang.Volatileyn6,newvalyn3,volyn1,fyn1,&yn4,argsyn1,xyn1,gyn2,fskn6,staticyn1,hyn4,arg1yn4,arg2yn4,arg3yn4,moreyn4,collyn5,xformyn5,collsyn4,predyn8,bindingsyn4,bodyyn2,c1yn2,c2yn2,c3yn5,nameskn8,declaredyn1,nkn10,deprecatedyn3,endyn5,startyn4,stepyn22,java.io.BufferedReaderyn20,java.util.Comparatoryn5,keyfnyn3,padyn4,formyn9,seq-exprsyn6,agentsyn17,arbace.lang.Agentyn10,timeout-msyn31,arbace.lang.IEditableCollectionyn32,arbace.lang.ITransientCollectionyn33,arbace.lang.ITransientAssociativeyn3,keyyn3,kvsyn25,arbace.lang.ITransientMapyn2,ksyn28,arbace.lang.ITransientVectoryn3,setyn25,arbace.lang.ITransientSetyn1,yyn4,mapskn7,privateyn2,toyn4,fromkn5,redefyn23,import-symbols-or-listsyn4,aseqyn4,typeyn5,itemsyn6,Objectyn15,java.lang.Classyn6,Numberyn3,numyn3,divyn1,rv11,arbace.core9,volatile!m14,R0,L1,V1,R1,R2,s60,Creates and returns a Volatile with an initial value of val.R3,s3,1.7R4,C20,arbace.lang.VolatileR5,i2531,R6,i1,R7,s14,arbace/core.aev11,arbace.core7,vreset!m12,R0,L1,V2,Myn3,volm2,R4,R8,R9,R2,s93,Sets the value of volatile to newval without regard for the\n   current value. Returns newval.R3,s3,1.7R5,i2538,R6,i1,R7,s14,arbace/core.aev11,arbace.core6,vswap!m12,R0,L1,V4,R10,R11,R12,R13,R2,s135,Non-atomically swaps the value of the volatile as if:\n   (apply f current-value-of-vol args). Returns the value that\n   was swapped in.R3,s3,1.7R5,i2545,R6,i1,R7,s14,arbace/core.aev11,arbace.core9,volatile?m12,R0,L1,V1,R14,R2,s32,Returns true if x is a volatile.R3,s3,1.7R5,i2554,R6,i1,R7,s14,arbace/core.aev11,arbace.core4,compm14,R0,L4,V0,V1,R11,V2,R11,R15,V4,R11,R15,R12,R16,R2,s225,Takes a set of functions and returns a fn that is the composition\n  of those fns.  The returned fn takes a variable number of args,\n  applies the rightmost of fns to the args, the next\n  fn (right-to-left) to the result, etc.R3,s3,1.0R17,TR5,i2562,R6,i1,R7,s14,arbace/core.aev11,arbace.core4,juxtm14,R0,L4,V1,R11,V2,R11,R15,V3,R11,R15,R18,V5,R11,R15,R18,R12,R16,R2,s271,Takes a set of functions and returns a fn that is the juxtaposition\n  of those fns.  The returned fn takes a variable number of args, and\n  returns a vector containing the result of applying each fn to the\n  args (left-to-right).\n  ((juxt a b c) x) => [(a x) (b x) (c x)]R3,s3,1.1R17,TR5,i2581,R6,i1,R7,s14,arbace/core.aev11,arbace.core7,partialm14,R0,L5,V1,R11,V2,R11,R19,V3,R11,R19,R20,V4,R11,R19,R20,R21,V6,R11,R19,R20,R21,R12,R22,R2,s202,Takes a function f and fewer than the normal arguments to f, and\n  returns a fn that takes a variable number of additional args. When\n  called, the returned function calls f with args + additional args.R3,s3,1.0R17,TR5,i2619,R6,i1,R7,s14,arbace/core.aev11,arbace.core8,sequencem14,R0,L3,V1,R23,V2,R24,R23,V4,R24,R23,R12,R25,R2,s489,Coerces coll to a (possibly empty) sequence, if it is not already\n  one. Will not force a lazy seq. (sequence nil) yields (), When a\n  transducer is supplied, returns a lazy sequence of applications of\n  the transform to the items in coll(s), i.e. to the set of first\n  items of each coll, followed by the set of second\n  items in each coll, until any one of the colls is exhausted.  Any\n  remaining items in other colls are ignored. The transform should accept\n  number-of-colls argumentsR3,s3,1.0R17,TR5,i2652,R6,i1,R7,s14,arbace/core.aev11,arbace.core6,every?m16,R0,L1,V2,R26,R23,R2,s75,Returns true if (pred x) is logical true for every x in coll, else\n  false.R4,C17,java.lang.BooleanR3,s3,1.0R17,TR5,i2677,R6,i1,R7,s14,arbace/core.aev11,arbace.core10,not-every?m14,R4,C17,java.lang.BooleanR2,s75,Returns false if (pred x) is logical true for every x in\n  coll, else true.R0,ML1,V2,R26,R23,m4,R5,i2693,R6,i15,R3,s3,1.0R5,i2689,R6,i1,R7,s14,arbace/core.aev11,arbace.core4,somem14,R0,L1,V2,R26,R23,R2,s226,Returns the first logical true value of (pred x) for any x in coll,\n  else nil.  One common idiom is to use a set as pred, for example\n  this will return :fred if :fred is in the sequence, otherwise nil:\n  (some #{:fred} coll)R3,s3,1.0R17,TR5,i2697,R6,i1,R7,s14,arbace/core.aev11,arbace.core8,not-any?m14,R4,C17,java.lang.BooleanR2,s73,Returns false if (pred x) is logical true for any x in coll,\n  else true.R0,ML1,V2,R26,R23,m4,R5,i2712,R6,i15,R3,s3,1.0R5,i2708,R6,i1,R7,s14,arbace/core.aev11,arbace.core7,dotimesm12,R0,L1,V3,R27,R12,R28,R2,s126,bindings => name n\n\n  Repeatedly executes body (presumably for side-effects) with name\n  bound to integers from 0 through n-1.R3,s3,1.0R5,i2717,R6,i1,R7,s14,arbace/core.aem14,R0,L5,V1,R11,V2,R11,R23,V3,R11,R29,R30,V4,R11,R29,R30,R31,V6,R11,R29,R30,R31,R12,R25,R2,s371,Returns a lazy sequence consisting of the result of applying f to\n  the set of first items of each coll, followed by applying f to the\n  set of second items in each coll, until any one of the colls is\n  exhausted.  Any remaining items in other colls are ignored. Function\n  f should accept number-of-colls arguments. Returns a transducer when\n  no collection is provided.R3,s3,1.0R17,TR5,i2732,R6,i1,R7,s14,arbace/core.aev11,arbace.core7,declarem12,R0,L1,V2,R12,R32,R2,s85,defs the supplied var names with no bindings, useful for making forward declarations.R3,s3,1.0R5,i2781,R6,i1,R7,s14,arbace/core.aev11,arbace.core3,catm8,R33,TR5,i2786,R6,i1,R7,s14,arbace/core.aev11,arbace.core11,select-keysm8,R33,TR5,i2786,R6,i1,R7,s14,arbace/core.aev11,arbace.core6,mapcatm14,R0,L2,V1,R11,V3,R11,R12,R25,R2,s186,Returns the result of applying concat to the result of applying map\n  to f and colls.  Thus function f should return a collection. Returns\n  a transducer when no collections are providedR3,s3,1.0R17,TR5,i2788,R6,i1,R7,s14,arbace/core.aev11,arbace.core6,filterm14,R0,L2,V1,R26,V2,R26,R23,R2,s180,Returns a lazy sequence of the items in coll for which\n  (pred item) returns logical true. pred must be free of side-effects.\n  Returns a transducer when no collection is provided.R3,s3,1.0R17,TR5,i2798,R6,i1,R7,s14,arbace/core.aev11,arbace.core6,removem14,R0,L2,V1,R26,V2,R26,R23,R2,s181,Returns a lazy sequence of the items in coll for which\n  (pred item) returns logical false. pred must be free of side-effects.\n  Returns a transducer when no collection is provided.R3,s3,1.0R17,TR5,i2830,R6,i1,R7,s14,arbace/core.aev11,arbace.core7,reducedm12,R0,L1,V1,R14,R2,s67,Wraps x in a way such that a reduce will terminate with the value xR3,s3,1.5R5,i2840,R6,i1,R7,s14,arbace/core.aev11,arbace.core8,reduced?L1,V1,R14,S1,l1,i2846,v11,arbace.core14,ensure-reducedm12,R0,L1,V1,R14,R2,s62,If x is already reduced?, returns it, else returns (reduced x)R3,s3,1.7R5,i2853,R6,i1,R7,s14,arbace/core.aev11,arbace.core9,unreducedm12,R0,L1,V1,R14,R2,s51,If x is reduced?, returns (deref x), else returns xR3,s3,1.7R5,i2859,R6,i1,R7,s14,arbace/core.aev11,arbace.core4,takem14,R0,L2,V1,R34,V2,R34,R23,R2,s160,Returns a lazy sequence of the first n items in coll, or all items if\n  there are fewer than n.  Returns a stateful transducer when\n  no collection is provided.R3,s3,1.0R17,TR5,i2865,R6,i1,R7,s14,arbace/core.aev11,arbace.core10,take-whilem14,R0,L2,V1,R26,V2,R26,R23,R2,s185,Returns a lazy sequence of successive items from coll while\n  (pred item) returns logical true. pred must be free of side-effects.\n  Returns a transducer when no collection is provided.R3,s3,1.0R17,TR5,i2892,R6,i1,R7,s14,arbace/core.aev11,arbace.core4,dropm14,R0,L2,V1,R34,V2,R34,R23,R2,s140,Returns a laziness-preserving sequence of all but the first n items in coll.\n  Returns a stateful transducer when no collection is provided.R3,s3,1.0R17,TR5,i2913,R6,i1,R7,s14,arbace/core.aev11,arbace.core9,drop-lastm14,R0,L2,V1,R23,V2,R34,R23,R2,s70,Return a lazy sequence of all but the last n (default 1) items in collR3,s3,1.0R17,TR5,i2944,R6,i1,R7,s14,arbace/core.aev11,arbace.core9,take-lastm14,R0,L1,V2,R34,R23,R2,s141,Returns a seq of the last n items in coll.  Depending on the type\n  of coll may be no better than linear time.  For vectors, see also subvec.R3,s3,1.1R17,TR5,i2951,R6,i1,R7,s14,arbace/core.aev11,arbace.core10,drop-whilem14,R0,L2,V1,R26,V2,R26,R23,R2,s185,Returns a lazy sequence of the items in coll starting from the\n  first item for which (pred item) returns logical false.  Returns a\n  stateful transducer when no collection is provided.R3,s3,1.0R17,TR5,i2962,R6,i1,R7,s14,arbace/core.aev11,arbace.core5,cyclem14,R0,L1,V1,R23,R2,s72,Returns a lazy (infinite!) sequence of repetitions of the items in coll.R3,s3,1.0R17,TR5,i2989,R6,i1,R7,s14,arbace/core.aev11,arbace.core8,split-atm14,R0,L1,V2,R34,R23,R2,s49,Returns a vector of [(take n coll) (drop n coll)]R3,s3,1.0R17,TR5,i2995,R6,i1,R7,s14,arbace/core.aev11,arbace.core10,split-withm14,R0,L1,V2,R26,R23,R2,s67,Returns a vector of [(take-while pred coll) (drop-while pred coll)]R3,s3,1.0R17,TR5,i3002,R6,i1,R7,s14,arbace/core.aev11,arbace.core6,repeatm14,R0,L2,V1,R14,V2,R34,R14,R2,s67,Returns a lazy (infinite!, or length n if supplied) sequence of xs.R3,s3,1.0R17,TR5,i3009,R6,i1,R7,s14,arbace/core.aev11,arbace.core9,replicatem14,R0,L1,V2,R34,R14,R2,s64,DEPRECATED: Use 'repeat' instead.\n   Returns a lazy seq of n xs.R3,s3,1.0R35,s3,1.3R5,i3016,R6,i1,R7,s14,arbace/core.aev11,arbace.core7,iteratem14,R0,L1,V2,R11,R14,R2,s96,Returns a lazy (infinite!) sequence of x, (f x), (f (f x)) etc.\n  f must be free of side-effectsR3,s3,1.0R17,TR5,i3023,R6,i1,R7,s14,arbace/core.aev11,arbace.core5,rangem14,R0,L4,V0,V1,R36,V2,R37,R36,V3,R37,R36,R38,R2,s255,Returns a lazy seq of nums from start (inclusive) to end\n  (exclusive), by step, where start defaults to 0, step to 1, and end to\n  infinity. When step is equal to 0, returns an infinite sequence of\n  start. When start is equal to end, returns empty list.R3,s3,1.0R17,TR5,i3030,R6,i1,R7,s14,arbace/core.aev11,arbace.core8,line-seqm14,R0,L1,V1,Myn3,rdrm2,R4,R39,R2,s110,Returns the lines of text from rdr as a lazy sequence of strings.\n  rdr must implement java.io.BufferedReader.R3,s3,1.0R17,TR5,i3052,R6,i1,R7,s14,arbace/core.aev11,arbace.core10,comparatorm14,R0,L1,V1,R26,R2,s66,Returns an implementation of java.util.Comparator based upon pred.R3,s3,1.0R17,TR5,i3061,R6,i1,R7,s14,arbace/core.aev11,arbace.core4,sortm14,R0,L2,V1,R23,V2,Myn4,compm2,R4,R40,R23,R2,s301,Returns a sorted sequence of the items in coll. If no comparator is\n  supplied, uses compare.  comparator must implement\n  java.util.Comparator.  Guaranteed to be stable: equal elements will\n  not be reordered.  If coll is a Java array, it will be modified.  To\n  avoid this, sort a copy of the array.R3,s3,1.0R17,TR5,i3069,R6,i1,R7,s14,arbace/core.aev11,arbace.core7,sort-bym14,R0,L2,V2,R41,R23,V3,R41,Myn4,compm2,R4,R40,R23,R2,s366,Returns a sorted sequence of the items in coll, where the sort\n  order is determined by comparing (keyfn item).  If no comparator is\n  supplied, uses compare.  comparator must implement\n  java.util.Comparator.  Guaranteed to be stable: equal elements will\n  not be reordered.  If coll is a Java array, it will be modified.  To\n  avoid this, sort a copy of the array.R3,s3,1.0R17,TR5,i3086,R6,i1,R7,s14,arbace/core.aev11,arbace.core5,dorunm14,R0,L2,V1,R23,V2,R34,R23,R2,s323,When lazy sequences are produced via functions that have side\n  effects, any effects other than those needed to produce the first\n  element in the seq do not occur until the seq is consumed. dorun can\n  be used to force any effects. Walks through the successive nexts of\n  the seq, does not retain the head and returns nil.R3,s3,1.0R17,TR5,i3100,R6,i1,R7,s14,arbace/core.aev11,arbace.core5,doallm14,R0,L2,V1,R23,V2,R34,R23,R2,s377,When lazy sequences are produced via functions that have side\n  effects, any effects other than those needed to produce the first\n  element in the seq do not occur until the seq is consumed. doall can\n  be used to force any effects. Walks through the successive nexts of\n  the seq, retains the head and returns it, thus causing the entire\n  seq to reside in memory at one time.R3,s3,1.0R17,TR5,i3115,R6,i1,R7,s14,arbace/core.aev11,arbace.core7,nthnextm14,R0,L1,V2,R23,R34,R2,s53,Returns the nth next of coll, (seq coll) when n is 0.R3,s3,1.0R17,TR5,i3131,R6,i1,R7,s14,arbace/core.aev11,arbace.core7,nthrestm14,R0,L1,V2,R23,R34,R2,s47,Returns the nth rest of coll, coll when n is 0.R3,s3,1.3R17,TR5,i3145,R6,i1,R7,s14,arbace/core.aev11,arbace.core9,partitionm14,R0,L3,V2,R34,R23,V3,R34,R38,R23,V4,R34,R38,R42,R23,R2,s350,Returns a lazy sequence of lists of n items each, at offsets step\n  apart. If step is not supplied, defaults to n, i.e. the partitions\n  do not overlap. If a pad collection is supplied, use its elements as\n  necessary to complete last partition upto n items. In case there are\n  not enough padding elements, return a partition with less than n items.R3,s3,1.0R17,TR5,i3161,R6,i1,R7,s14,arbace/core.aev11,arbace.core4,evalm14,R0,L1,V1,R43,R2,s69,Evaluates the form data structure (not text!) and returns the result.R3,s3,1.0R17,TR5,i3187,R6,i1,R7,s14,arbace/core.aev11,arbace.core5,doseqm12,R0,L1,V3,R44,R12,R28,R2,s164,Repeatedly executes body (presumably for side-effects) with\n  bindings and filtering as provided by \"for\".  Does not retain\n  the head of the sequence. Returns nil.R3,s3,1.0R5,i3193,R6,i1,R7,s14,arbace/core.aev11,arbace.core5,awaitm14,R0,L1,V2,R12,R45,R2,s280,Blocks the current thread (indefinitely!) until all actions\n  dispatched thus far, from this thread or agent, to the agent(s) have\n  occurred.  Will block on failed agents.  Will never return if\n  a failed agent is restarted with :clear-actions true or shutdown-agents was called.R3,s3,1.0R17,TR5,i3251,R6,i1,R7,s14,arbace/core.aev11,arbace.core6,await1m10,R17,TR0,L1,V1,Myn1,am2,R4,R46,R5,i3268,R6,i1,R7,s14,arbace/core.aev11,arbace.core9,await-form14,R0,L1,V3,R47,R12,R45,R2,s247,Blocks the current thread until all actions dispatched thus\n  far (from this thread or agent) to the agents have occurred, or the\n  timeout (in milliseconds) has elapsed. Returns logical false if\n  returning due to timeout, logical true otherwise.R3,s3,1.0R17,TR5,i3273,R6,i1,R7,s14,arbace/core.aem12,R0,L1,V3,R27,R12,R28,R2,s126,bindings => name n\n\n  Repeatedly executes body (presumably for side-effects) with name\n  bound to integers from 0 through n-1.R3,s3,1.0R5,i3290,R6,i1,R7,s14,arbace/core.aev11,arbace.core9,transientm14,R0,L1,V1,Myn4,collm2,R4,R48,R2,s539,Returns a new, transient version of the collection, in constant time.\n\n  Transients support a parallel set of 'changing' operations, with similar names\n  followed by ! - assoc!, conj! etc. These do the same things as their persistent\n  counterparts except the return values are themselves transient.\n\n  Note in particular that transients are not designed to be bashed in-place. You\n  must capture and use the return value in the next call. In this way, they support\n  the same code structure as the functional persistent code they replace.R3,s3,1.1R17,TR5,i3319,R6,i1,R7,s14,arbace/core.aev11,arbace.core11,persistent!m14,R0,L1,V1,Myn4,collm2,R4,R49,R2,s179,Returns a new, persistent version of the transient collection, in\n  constant time. The transient collection cannot be used after this\n  call, any such use will throw an exception.R3,s3,1.1R17,TR5,i3334,R6,i1,R7,s14,arbace/core.aev11,arbace.core5,conj!m14,R0,L3,V0,V1,R23,V2,Myn4,collm2,R4,R49,R14,R2,s134,Adds x to the transient collection, and return coll. The 'addition'\n  may happen at different 'places' depending on the concrete type.R3,s3,1.1R17,TR5,i3343,R6,i1,R7,s14,arbace/core.aev11,arbace.core6,assoc!m14,R0,L2,V3,Myn4,collm2,R4,R50,R51,R1,V5,Myn4,collm2,R4,R50,R51,R1,R12,R52,R2,s183,When applied to a transient map, adds mapping of key(s) to\n  val(s). When applied to a transient vector, sets the val at index.\n  Note - index must be <= (count vector). Returns coll.R3,s3,1.1R17,TR5,i3353,R6,i1,R7,s14,arbace/core.aev11,arbace.core7,dissoc!m14,R0,L2,V2,Myn3,mapm2,R4,R53,R51,V4,Myn3,mapm2,R4,R53,R51,R12,R54,R2,s66,Returns a transient map that doesn't contain a mapping for key(s).R3,s3,1.1R17,TR5,i3366,R6,i1,R7,s14,arbace/core.aev11,arbace.core4,pop!m14,R0,L1,V1,Myn4,collm2,R4,R55,R2,s110,Removes the last item from a transient vector. If\n  the collection is empty, throws an exception. Returns collR3,s3,1.1R17,TR5,i3377,R6,i1,R7,s14,arbace/core.aev11,arbace.core5,disj!m14,R0,L3,V1,R56,V2,Myn3,setm2,R4,R57,R51,V4,Myn3,setm2,R4,R57,R51,R12,R54,R2,s100,disj[oin]. Returns a transient set of the same (hashed/sorted) type, that\n  does not contain key(s).R3,s3,1.1R17,TR5,i3385,R6,i1,R7,s14,arbace/core.aev11,arbace.core10,merge-withm14,R0,L4,V1,R11,V2,R11,R14,V3,R11,R14,R58,V5,R11,R14,R58,R12,R59,R2,s259,Returns a map that consists of the rest of the maps conj-ed onto\n  the first.  If a key occurs in more than one map, the mapping(s)\n  from the latter (left-to-right) will be combined with the mapping in\n  the result by calling (f val-in-result val-in-latter).R3,s3,1.0R17,TR5,i3399,R6,i1,R7,s14,arbace/core.aev11,arbace.core5,into0m16,R60,TR0,L1,V2,R61,R62,R2,s88,Returns a new coll consisting of to-coll with all of the items of\n  from-coll conjoined.R3,s3,1.0R17,TR5,i3433,R6,i1,R7,s14,arbace/core.aev11,arbace.core5,into1m10,R63,TR60,TR5,i3443,R6,i1,R7,s14,arbace/core.aev11,arbace.core5,mergem14,R0,L4,V0,V1,R14,V2,R14,R58,V4,R14,R58,R12,R59,R2,s197,Returns a map that consists of the rest of the maps conj-ed onto\n  the first.  If a key occurs in more than one map, the mapping from\n  the latter (left-to-right) will be the mapping in the result.R3,s3,1.0R17,TR5,i3445,R6,i1,R7,s14,arbace/core.aev11,arbace.core6,importm12,R0,L1,V2,R12,R64,R2,s249,import-list => (package-symbol class-name-symbols*)\n\n  For each name in class-name-symbols, adds a mapping from name to the\n  class named by package.name to the current namespace. Use :import in the ns\n  macro in preference to calling this directly.R3,s3,1.0R5,i3457,R6,i1,R7,s14,arbace/core.aev11,arbace.core10,into-arraym14,R0,L2,V1,R65,V2,R66,R65,R2,s321,Returns an array with components set to the values in aseq. The array's\n  component type is type if provided, or the type of the first value in\n  aseq if present, or Object. All values in aseq must be compatible with\n  the component type. Class objects for the primitive types can be obtained\n  using, e.g., Integer/TYPE.R3,s3,1.0R17,TR5,i3475,R6,i1,R7,s14,arbace/core.aev11,arbace.core5,arraym10,R60,TR0,L1,V2,R12,R67,R5,i3488,R6,i1,R7,s14,arbace/core.aev11,arbace.core5,classm14,R0,L1,MV1,Myn1,xm2,R4,R68,m2,R4,R69,R2,s22,Returns the Class of xR3,s3,1.0R17,TR5,i3492,R6,i1,R7,s14,arbace/core.aev11,arbace.core4,typem14,R0,L1,V1,R14,R2,s53,Returns the :type metadata of x, or its Class if noneR3,s3,1.0R17,TR5,i3498,R6,i1,R7,s14,arbace/core.aev11,arbace.core3,numL1,V1,R14,C16,java.lang.Numberi3505,v11,arbace.core4,longL1,V1,Myn1,xm2,R4,R70,i3512,v11,arbace.core5,floatL1,V1,Myn1,xm2,R4,R70,i3518,v11,arbace.core6,doubleL1,V1,Myn1,xm2,R4,R70,i3524,v11,arbace.core5,shortL1,V1,Myn1,xm2,R4,R70,i3530,v11,arbace.core4,byteL1,V1,Myn1,xm2,R4,R70,i3536,v11,arbace.core4,charL1,V1,R14,i3542,v11,arbace.core14,unchecked-byteL1,V1,Myn1,xm2,R4,R70,i3548,v11,arbace.core15,unchecked-shortL1,V1,Myn1,xm2,R4,R70,i3554,v11,arbace.core14,unchecked-charL1,V1,R14,i3560,v11,arbace.core13,unchecked-intL1,V1,Myn1,xm2,R4,R70,i3566,v11,arbace.core14,unchecked-longL1,V1,Myn1,xm2,R4,R70,i3572,v11,arbace.core15,unchecked-floatL1,V1,Myn1,xm2,R4,R70,i3578,v11,arbace.core16,unchecked-doubleL1,V1,Myn1,xm2,R4,R70,i3584,v11,arbace.core7,number?m14,R0,L1,V1,R14,R2,s29,Returns true if x is a NumberR3,s3,1.0R17,TR5,i3590,R6,i1,R7,s14,arbace/core.aev11,arbace.core3,modm14,R0,L1,V2,R71,R72,R2,s59,Modulus of num and div. Truncates toward negative infinity.R3,s3,1.0R17,TR5,i3597,R6,i1,R7,s14,arbace/core.aev11,arbace.core6,ratio?m14,R0,L1,V1,R34,R2,s28,Returns true if n is a RatioR3,s3,1.0R17,TR5,i3607,R6,i1,R7,s14,arbace/core.aev11,arbace.core9,numeratorm16,R0,L1,V1,R73,R2,s38,Returns the numerator part of a Ratio.R4,C20,java.math.BigIntegerR3,s3,1.2R17,TR5,i3613,R6,i1,R7,s14,arbace/core.aev11,arbace.core11,denominatorm16,R0,L1,V1,R73,R2,s40,Returns the denominator part of a Ratio.R4,C20,java.math.BigIntegerR3,s3,1.2R17,TR5,i3621,R6,i1,R7,s14,arbace/core.aev11,arbace.core8,decimal?m14,R0,L1,V1,R34,R2,s33,Returns true if n is a BigDecimalR3,s3,1.0R17,TR5,i3629,R6,i1,R7,s14,arbace/core.ae")

var Lit_1066 *jrt.String = jrt.Intern("arbace.core$volatile_BANG_")

var Lit_1067 *jrt.String = jrt.Intern("arbace.core$vreset_BANG_")

var Lit_1068 *jrt.String = jrt.Intern("arbace.core$vswap_BANG_")

var Lit_1069 *jrt.String = jrt.Intern("arbace.core$volatile_QMARK_")

var Lit_1070 *jrt.String = jrt.Intern("arbace.core$comp")

var Lit_1071 *jrt.String = jrt.Intern("arbace.core$juxt")

var Lit_1072 *jrt.String = jrt.Intern("arbace.core$partial")

var Lit_1073 *jrt.String = jrt.Intern("arbace.core$sequence")

var Lit_1074 *jrt.String = jrt.Intern("arbace.core$every_QMARK_")

var Lit_1075 *jrt.String = jrt.Intern("arbace.core$some")

var Lit_1076 *jrt.String = jrt.Intern("arbace.core$dotimes")

var Lit_1077 *jrt.String = jrt.Intern("arbace.core$map")

var Lit_1078 *jrt.String = jrt.Intern("arbace.core$declare")

var Lit_1079 *jrt.String = jrt.Intern("arbace.core$mapcat")

var Lit_1080 *jrt.String = jrt.Intern("arbace.core$filter")

var Lit_1081 *jrt.String = jrt.Intern("arbace.core$remove")

var Lit_1082 *jrt.String = jrt.Intern("arbace.core$reduced")

var Lit_1083 *jrt.String = jrt.Intern("arbace.core$reduced_QMARK_")

var Lit_1084 *jrt.String = jrt.Intern("Returns true if x is the result of a call to reduced")

var Lit_1085 *jrt.String = jrt.Intern("arbace.core$reduced_QMARK___inliner__1927000608")

var Lit_1086 *jrt.String = jrt.Intern("1.5")

var Lit_1087 *jrt.String = jrt.Intern("arbace.core$ensure_reduced")

var Lit_1088 *jrt.String = jrt.Intern("arbace.core$unreduced")

var Lit_1089 *jrt.String = jrt.Intern("arbace.core$take")

var Lit_1090 *jrt.String = jrt.Intern("arbace.core$take_while")

var Lit_1091 *jrt.String = jrt.Intern("arbace.core$drop")

var Lit_1092 *jrt.String = jrt.Intern("arbace.core$drop_last")

var Lit_1093 *jrt.String = jrt.Intern("arbace.core$take_last")

var Lit_1094 *jrt.String = jrt.Intern("arbace.core$drop_while")

var Lit_1095 *jrt.String = jrt.Intern("arbace.core$cycle")

var Lit_1096 *jrt.String = jrt.Intern("arbace.core$split_at")

var Lit_1097 *jrt.String = jrt.Intern("arbace.core$split_with")

var Lit_1098 *jrt.String = jrt.Intern("arbace.core$repeat")

var Lit_1099 *jrt.String = jrt.Intern("arbace.core$replicate")

var Lit_1100 *jrt.String = jrt.Intern("arbace.core$iterate")

var Lit_1101 *jrt.String = jrt.Intern("arbace.core$range")

var Lit_1102 *jrt.String = jrt.Intern("arbace.core$line_seq")

var Lit_1103 *jrt.String = jrt.Intern("arbace.core$comparator")

var Lit_1104 *jrt.String = jrt.Intern("arbace.core$sort")

var Lit_1105 *jrt.String = jrt.Intern("arbace.core$sort_by")

var Lit_1106 *jrt.String = jrt.Intern("arbace.core$dorun")

var Lit_1107 *jrt.String = jrt.Intern("arbace.core$doall")

var Lit_1108 *jrt.String = jrt.Intern("arbace.core$nthnext")

var Lit_1109 *jrt.String = jrt.Intern("arbace.core$nthrest")

var Lit_1110 *jrt.String = jrt.Intern("arbace.core$partition")

var Lit_1111 *jrt.String = jrt.Intern("arbace.core$eval")

var Lit_1112 *jrt.String = jrt.Intern("arbace.core$doseq")

var Lit_1113 *jrt.String = jrt.Intern("arbace.core$await")

var Lit_1114 *jrt.String = jrt.Intern("arbace.core$await1")

var Lit_1115 *jrt.String = jrt.Intern("arbace.core$await_for")

var Lit_1116 *jrt.String = jrt.Intern("arbace.core$dotimes__1")

var Lit_1117 *jrt.String = jrt.Intern("arbace.core$transient")

var Lit_1118 *jrt.String = jrt.Intern("arbace.core$persistent_BANG_")

var Lit_1119 *jrt.String = jrt.Intern("arbace.core$conj_BANG_")

var Lit_1120 *jrt.String = jrt.Intern("arbace.core$assoc_BANG_")

var Lit_1121 *jrt.String = jrt.Intern("arbace.core$dissoc_BANG_")

var Lit_1122 *jrt.String = jrt.Intern("arbace.core$pop_BANG_")

var Lit_1123 *jrt.String = jrt.Intern("arbace.core$disj_BANG_")

var Lit_1124 *jrt.String = jrt.Intern("arbace.core$merge_with")

var Lit_1125 *jrt.String = jrt.Intern("arbace.core$into0")

var Lit_1126 *jrt.String = jrt.Intern("arbace.core$merge")

var Lit_1127 *jrt.String = jrt.Intern("arbace.core$import")

var Lit_1128 *jrt.String = jrt.Intern("arbace.core$into_array")

var Lit_1129 *jrt.String = jrt.Intern("arbace.core$array")

var Lit_1130 *jrt.String = jrt.Intern("arbace.core$class")

var Lit_1131 *jrt.String = jrt.Intern("arbace.core$type")

var Lit_1132 *jrt.String = jrt.Intern("arbace.core$num")

var Lit_1133 *jrt.String = jrt.Intern("Coerce to Number")

var Lit_1134 *jrt.String = jrt.Intern("arbace.core$num__inliner__1927000745")

var Lit_1135 *jrt.String = jrt.Intern("arbace.core$long")

var Lit_1136 *jrt.String = jrt.Intern("Coerce to long")

var Lit_1137 *jrt.String = jrt.Intern("arbace.core$long__inliner__1927000748")

var Lit_1138 *jrt.String = jrt.Intern("arbace.core$float")

var Lit_1139 *jrt.String = jrt.Intern("Coerce to float")

var Lit_1140 *jrt.String = jrt.Intern("arbace.core$float__inliner__1927000751")

var Lit_1141 *jrt.String = jrt.Intern("arbace.core$double")

var Lit_1142 *jrt.String = jrt.Intern("Coerce to double")

var Lit_1143 *jrt.String = jrt.Intern("arbace.core$double__inliner__1927000754")

var Lit_1144 *jrt.String = jrt.Intern("arbace.core$short")

var Lit_1145 *jrt.String = jrt.Intern("Coerce to short")

var Lit_1146 *jrt.String = jrt.Intern("arbace.core$short__inliner__1927000757")

var Lit_1147 *jrt.String = jrt.Intern("arbace.core$byte")

var Lit_1148 *jrt.String = jrt.Intern("Coerce to byte")

var Lit_1149 *jrt.String = jrt.Intern("arbace.core$byte__inliner__1927000760")

var Lit_1150 *jrt.String = jrt.Intern("arbace.core$char")

var Lit_1151 *jrt.String = jrt.Intern("Coerce to char")

var Lit_1152 *jrt.String = jrt.Intern("arbace.core$char__inliner__1927000763")

var Lit_1153 *jrt.String = jrt.Intern("1.1")

var Lit_1154 *jrt.String = jrt.Intern("arbace.core$unchecked_byte")

var Lit_1155 *jrt.String = jrt.Intern("Coerce to byte. Subject to rounding or truncation.")

var Lit_1156 *jrt.String = jrt.Intern("arbace.core$unchecked_byte__inliner__1927000766")

var Lit_1157 *jrt.String = jrt.Intern("1.3")

var Lit_1158 *jrt.String = jrt.Intern("arbace.core$unchecked_short")

var Lit_1159 *jrt.String = jrt.Intern("Coerce to short. Subject to rounding or truncation.")

var Lit_1160 *jrt.String = jrt.Intern("arbace.core$unchecked_short__inliner__1927000769")

var Lit_1161 *jrt.String = jrt.Intern("arbace.core$unchecked_char")

var Lit_1162 *jrt.String = jrt.Intern("Coerce to char. Subject to rounding or truncation.")

var Lit_1163 *jrt.String = jrt.Intern("arbace.core$unchecked_char__inliner__1927000772")

var Lit_1164 *jrt.String = jrt.Intern("arbace.core$unchecked_int")

var Lit_1165 *jrt.String = jrt.Intern("Coerce to int. Subject to rounding or truncation.")

var Lit_1166 *jrt.String = jrt.Intern("arbace.core$unchecked_int__inliner__1927000775")

var Lit_1167 *jrt.String = jrt.Intern("arbace.core$unchecked_long")

var Lit_1168 *jrt.String = jrt.Intern("Coerce to long. Subject to rounding or truncation.")

var Lit_1169 *jrt.String = jrt.Intern("arbace.core$unchecked_long__inliner__1927000778")

var Lit_1170 *jrt.String = jrt.Intern("arbace.core$unchecked_float")

var Lit_1171 *jrt.String = jrt.Intern("Coerce to float. Subject to rounding.")

var Lit_1172 *jrt.String = jrt.Intern("arbace.core$unchecked_float__inliner__1927000781")

var Lit_1173 *jrt.String = jrt.Intern("arbace.core$unchecked_double")

var Lit_1174 *jrt.String = jrt.Intern("Coerce to double. Subject to rounding.")

var Lit_1175 *jrt.String = jrt.Intern("arbace.core$unchecked_double__inliner__1927000784")

var Lit_1176 *jrt.String = jrt.Intern("arbace.core$number_QMARK_")

var Lit_1177 *jrt.String = jrt.Intern("arbace.core$mod")

var Lit_1178 *jrt.String = jrt.Intern("arbace.core$ratio_QMARK_")

var Lit_1179 *jrt.String = jrt.Intern("arbace.core$numerator")

var Lit_1180 *jrt.String = jrt.Intern("arbace.core$denominator")

var Lit_1181 *jrt.String = jrt.Intern("arbace.core$decimal_QMARK_")

var Lit_1182 *jrt.String = jrt.Intern("kn8,arglistsyn1,nkn3,dockn5,addedkn6,statickn4,linekn6,columnkn4,fileyn1,xkn3,tagkn7,privatekn7,dynamickn7,defaultyn1,wyn1,&yn4,moreyn6,streamyn10,eof-error?yn9,eof-valueyn10,recursive?yn4,optsyn39,arbace.lang.LineNumberingPushbackReaderyn1,syn1,vyn5,startyn3,endyn8,bindingsyn4,bodyyn5,formsyn4,nameyn4,argsyn4,expryn5,arrayyn3,idxyn4,idxsyn3,valyn4,idx2yn4,idxvyn6,methodyn6,coerceyn5,Classyn3,lenyn3,dimyn9,more-dimsyn20,java.util.Collectionyn4,formyn4,keysyn5,initsyn4,valsyn3,keyyn3,rdryn4,collyn5,keyfnyn4,predyn4,amapyn3,symyn21,arbace.lang.Namespaceyn2,nsyn6,ns-symyn7,filtersyn5,aliasyn13,namespace-symyn2,c1yn2,c2yn5,collsyn15,arbace.lang.Varyn13,name-vals-vecyn3,envyn7,keyvalsyn1,fkn8,declaredyn1,myn2,pbyn4,bvecyn1,bv11,arbace.core6,float?m14,R0,L1,V1,R1,R2,s44,Returns true if n is a floating point numberR3,s3,1.0R4,TR5,i3635,R6,i1,R7,s14,arbace/core.aev11,arbace.core9,rational?m14,R0,L1,V1,R1,R2,s38,Returns true if n is a rational numberR3,s3,1.0R4,TR5,i3643,R6,i1,R7,s14,arbace/core.aev11,arbace.core6,bigintm16,R0,L1,V1,R8,R2,s16,Coerce to BigIntR9,C18,arbace.lang.BigIntR4,TR3,s3,1.3R5,i3650,R6,i1,R7,s14,arbace/core.aev11,arbace.core10,bigintegerm16,R0,L1,V1,R8,R2,s20,Coerce to BigIntegerR9,C20,java.math.BigIntegerR3,s3,1.0R4,TR5,i3664,R6,i1,R7,s14,arbace/core.aev11,arbace.core6,bigdecm16,R0,L1,V1,R8,R2,s20,Coerce to BigDecimalR9,C20,java.math.BigDecimalR3,s3,1.0R4,TR5,i3678,R6,i1,R7,s14,arbace/core.aev11,arbace.core17,print-initializedm10,R10,TR11,TR5,i3692,R6,i1,R7,s14,arbace/core.aev11,arbace.core12,print-methodm6,R5,i3694,R6,i1,R7,s14,arbace/core.aeR12,m6,R5,i3694,R6,i1,R7,s14,arbace/core.aev11,arbace.core9,print-dupm6,R5,i3697,R6,i1,R7,s14,arbace/core.aem6,R5,i3697,R6,i1,R7,s14,arbace/core.aev11,arbace.core5,pr-onm12,R0,L1,V2,R8,R13,R10,TR4,TR5,i3699,R6,i1,R7,s14,arbace/core.aev11,arbace.core2,prm14,R0,L3,V0,V1,R8,V3,R8,R14,R15,R2,s231,Prints the object(s) to the output stream that is the current value\n  of *out*.  Prints the object(s), separated by spaces if there is\n  more than one.  By default, pr and prn print in a way that objects\n  can be read by the readerR11,TR3,s3,1.0R5,i3708,R6,i1,R7,s14,arbace/core.aev11,arbace.core14,system-newlinem10,R9,C16,java.lang.StringR10,TR5,i3725,R6,i1,R7,s14,arbace/core.aev11,arbace.core7,newlinem14,R0,L1,V0,R2,s43,Writes a platform-specific newline to *out*R3,s3,1.0R4,TR5,i3728,R6,i1,R7,s14,arbace/core.aev11,arbace.core5,flushm14,R0,L1,V0,R2,s62,Flushes the output stream that is the current value of\n  *out*R3,s3,1.0R4,TR5,i3736,R6,i1,R7,s14,arbace/core.aev11,arbace.core3,prnm14,R0,L1,V2,R14,R15,R2,s61,Same as pr followed by (newline). Observes *flush-on-newline*R3,s3,1.0R4,TR5,i3745,R6,i1,R7,s14,arbace/core.aev11,arbace.core5,printm14,R0,L1,V2,R14,R15,R2,s136,Prints the object(s) to the output stream that is the current value\n  of *out*.  print and println produce output for human consumption.R3,s3,1.0R4,TR5,i3755,R6,i1,R7,s14,arbace/core.aev11,arbace.core7,printlnm14,R0,L1,V2,R14,R15,R2,s35,Same as print followed by (newline)R3,s3,1.0R4,TR5,i3764,R6,i1,R7,s14,arbace/core.aev11,arbace.core4,readm14,R0,L5,V0,V1,R16,V3,R16,R17,R18,V4,R16,R17,R18,R19,V2,R20,R16,R2,s653,Reads the next object from stream, which must be an instance of\n  java.io.PushbackReader or some derivee.  stream defaults to the\n  current value of *in*.\n\n  Opts is a persistent map with valid keys:\n    :read-cond - :allow to process reader conditionals, or\n                 :preserve to keep all branches\n    :features - persistent set of feature keywords for reader conditionals\n    :eof - on eof, return value unless :eofthrow, then throw.\n           if not specified, will throw\n\n  Note that read can execute code (controlled by *read-eval*),\n  and as such should be used only with trusted sources.\n\n  For data structure interop use arbace.edn/readR3,s3,1.0R4,TR5,i3772,R6,i1,R7,s14,arbace/core.aev11,arbace.core11,read+stringm12,R0,L5,V0,V1,R16,V3,R16,R17,R18,V4,Myn6,streamm2,R9,R21,R17,R18,R19,V2,R20,Myn6,streamm2,R9,R21,R2,s170,Like read, and taking the same args. stream must be a LineNumberingPushbackReader.\n  Returns a vector containing the object read and the (whitespace-trimmed) string read.R3,s4,1.10R5,i3801,R6,i1,R7,s14,arbace/core.aev11,arbace.core9,read-linem14,R0,L1,V0,R2,s67,Reads the next line from stream that is the current value of *in* .R3,s3,1.0R4,TR5,i3827,R6,i1,R7,s14,arbace/core.aev11,arbace.core11,read-stringm14,R0,L2,V1,R22,V2,R20,R22,R2,s278,Reads one object from the string s. Optionally include reader\n  options, as specified in read.\n\n  Note that read-string can execute code (controlled by *read-eval*),\n  and as such should be used only with trusted sources.\n\n  For data structure interop use arbace.edn/read-stringR3,s3,1.0R4,TR5,i3836,R6,i1,R7,s14,arbace/core.aev11,arbace.core6,subvecm14,R0,L2,V2,R23,R24,V3,R23,R24,R25,R2,s276,Returns a persistent vector of the items in vector from\n  start (inclusive) to end (exclusive).  If end is not supplied,\n  defaults to (count vector). This operation is O(1) and very fast, as\n  the resulting vector shares structure with the original and no\n  trimming is done.R3,s3,1.0R4,TR5,i3849,R6,i1,R7,s14,arbace/core.aev11,arbace.core9,with-openm12,R0,L1,V3,R26,R14,R27,R2,s191,bindings => [name init ...]\n\n  Evaluates body in a try expression with names bound to the values\n  of the inits, and a finally clause that calls (.close name) on each\n  name in reverse order.R3,s3,1.0R5,i3862,R6,i1,R7,s14,arbace/core.aev11,arbace.core4,dotom12,R0,L1,V3,R8,R14,R28,R2,s232,Evaluates x then calls all of the methods and functions with the\n  value of x supplied at the front of the given arguments.  The forms\n  are evaluated in order.  Returns x.\n\n  (doto (new java.util.HashMap) (.put \"a\" 1) (.put \"b\" 2))R3,s3,1.0R5,i3883,R6,i1,R7,s14,arbace/core.aev11,arbace.core5,memfnm12,R0,L1,V3,R29,R14,R30,R2,s314,Expands into code that creates a fn that expects to be passed an\n  object and any args and calls the named instance method on the\n  object passing the args. Use when you want to treat a Java method as\n  a first-class fn. name may be type-hinted with the method receiver's\n  type in order to avoid reflective calls.R3,s3,1.0R5,i3902,R6,i1,R7,s14,arbace/core.aev11,arbace.core4,timem12,R0,L1,V1,R31,R2,s72,Evaluates expr and prints the time it took.  Returns the value of\n expr.R3,s3,1.0R5,i3915,R6,i1,R7,s14,arbace/core.aev11,arbace.core7,alengthL1,V1,R32,i3927,v11,arbace.core6,acloneL1,V1,R32,i3934,v11,arbace.core4,agetL2,V2,R32,R33,V4,R32,R33,R14,R34,S1,l2,i3941,v11,arbace.core4,asetL2,V3,R32,R33,R35,V5,R32,R33,R36,R14,R37,S1,l3,i3952,v11,arbace.core8,def-asetm10,R10,TR0,L1,V3,R29,R38,R39,R5,i3964,R6,i1,R7,s14,arbace/core.aev11,arbace.core8,aset-intm12,R2,s73,Sets the value at the index/indices. Works on arrays of int. Returns val.R3,s3,1.0R0,L2,V3,R32,R33,R35,V5,R32,R33,R36,R14,R37,R5,i3975,R6,i1,R7,s14,arbace/core.aev11,arbace.core9,aset-longm12,R2,s74,Sets the value at the index/indices. Works on arrays of long. Returns val.R3,s3,1.0R0,L2,V3,R32,R33,R35,V5,R32,R33,R36,R14,R37,R5,i3980,R6,i1,R7,s14,arbace/core.aev11,arbace.core12,aset-booleanm12,R2,s77,Sets the value at the index/indices. Works on arrays of boolean. Returns val.R3,s3,1.0R0,L2,V3,R32,R33,R35,V5,R32,R33,R36,R14,R37,R5,i3985,R6,i1,R7,s14,arbace/core.aev11,arbace.core10,aset-floatm12,R2,s75,Sets the value at the index/indices. Works on arrays of float. Returns val.R3,s3,1.0R0,L2,V3,R32,R33,R35,V5,R32,R33,R36,R14,R37,R5,i3990,R6,i1,R7,s14,arbace/core.aev11,arbace.core11,aset-doublem12,R2,s76,Sets the value at the index/indices. Works on arrays of double. Returns val.R3,s3,1.0R0,L2,V3,R32,R33,R35,V5,R32,R33,R36,R14,R37,R5,i3995,R6,i1,R7,s14,arbace/core.aev11,arbace.core10,aset-shortm12,R2,s75,Sets the value at the index/indices. Works on arrays of short. Returns val.R3,s3,1.0R0,L2,V3,R32,R33,R35,V5,R32,R33,R36,R14,R37,R5,i4000,R6,i1,R7,s14,arbace/core.aev11,arbace.core9,aset-bytem12,R2,s74,Sets the value at the index/indices. Works on arrays of byte. Returns val.R3,s3,1.0R0,L2,V3,R32,R33,R35,V5,R32,R33,R36,R14,R37,R5,i4005,R6,i1,R7,s14,arbace/core.aev11,arbace.core9,aset-charm12,R2,s74,Sets the value at the index/indices. Works on arrays of char. Returns val.R3,s3,1.0R0,L2,V3,R32,R33,R35,V5,R32,R33,R36,R14,R37,R5,i4010,R6,i1,R7,s14,arbace/core.aev11,arbace.core10,make-arraym14,R0,L2,V2,Myn4,typem2,R9,R40,R41,V4,Myn4,typem2,R9,R40,R42,R14,R43,R2,s303,Creates and returns an array of instances of the specified class of\n  the specified dimension(s).  Note that a class object is required.\n  Class objects can be obtained by using their imported or\n  fully-qualified name.  Class objects for the primitive types can be\n  obtained using, e.g., Integer/TYPE.R3,s3,1.0R4,TR5,i4015,R6,i1,R7,s14,arbace/core.aev11,arbace.core11,to-array-2dm16,R0,L1,V1,Myn4,collm2,R9,R44,R2,s145,Returns a (potentially-ragged) 2-dimensional array of Objects\n  containing the contents of coll, which can be any Collection of any\n  Collection.R9,s20,[[Ljava.lang.Object;R3,s3,1.0R4,TR5,i4032,R6,i1,R7,s14,arbace/core.aev11,arbace.core13,macroexpand-1m14,R0,L1,V1,R45,R2,s76,If form represents a macro form, returns its expansion,\n  else returns form.R3,s3,1.0R4,TR5,i4047,R6,i1,R7,s14,arbace/core.aev11,arbace.core11,macroexpandm14,R0,L1,V1,R45,R2,s174,Repeatedly calls macroexpand-1 on form until it no longer\n  represents a macro form, then returns it.  Note neither\n  macroexpand-1 nor macroexpand expand macros in subforms.R3,s3,1.0R4,TR5,i4055,R6,i1,R7,s14,arbace/core.aev11,arbace.core13,create-structm14,R0,L1,V2,R14,R46,R2,s33,Returns a structure basis object.R3,s3,1.0R4,TR5,i4067,R6,i1,R7,s14,arbace/core.aev11,arbace.core9,defstructm14,R0,L1,V3,R29,R14,R46,R2,s42,Same as (def name (create-struct keys...))R3,s3,1.0R4,TR5,i4074,R6,i1,R7,s14,arbace/core.aev11,arbace.core10,struct-mapm14,R0,L1,V3,R22,R14,R47,R2,s238,Returns a new structmap instance with the keys of the\n  structure-basis. keyvals may contain all, some or none of the basis\n  keys - where values are not supplied they will default to nil.\n  keyvals can also contain keys not in the basis.R3,s3,1.0R4,TR5,i4081,R6,i1,R7,s14,arbace/core.aev11,arbace.core6,structm14,R0,L1,V3,R22,R14,R48,R2,s178,Returns a new structmap instance with the keys of the\n  structure-basis. vals must be supplied for basis keys in order -\n  where values are not supplied they will default to nil.R3,s3,1.0R4,TR5,i4091,R6,i1,R7,s14,arbace/core.aev11,arbace.core8,accessorm14,R0,L1,V2,R22,R49,R2,s291,Returns a fn that, given an instance of a structmap with the basis,\n  returns the value at the key.  The key must be in the basis. The\n  returned function should be (slightly) more efficient than using\n  get, but such use of accessors should be limited to known\n  performance-critical areas.R3,s3,1.0R4,TR5,i4100,R6,i1,R7,s14,arbace/core.aev11,arbace.core11,load-readerm14,R0,L1,V1,R50,R2,s78,Sequentially read and evaluate the set of forms contained in the\n  stream/fileR3,s3,1.0R4,TR5,i4111,R6,i1,R7,s14,arbace/core.aev11,arbace.core11,load-stringm14,R0,L1,V1,R22,R2,s73,Sequentially read and evaluate the set of forms contained in the\n  stringR3,s3,1.0R4,TR5,i4118,R6,i1,R7,s14,arbace/core.aev11,arbace.core4,set?m14,R0,L1,V1,R8,R2,s43,Returns true if x implements IPersistentSetR3,s3,1.0R4,TR5,i4128,R6,i1,R7,s14,arbace/core.aev11,arbace.core3,setm14,R0,L1,V1,R51,R2,s47,Returns a set of the distinct elements of coll.R3,s3,1.0R4,TR5,i4134,R6,i1,R7,s14,arbace/core.aev11,arbace.core10,filter-keym12,R10,TR4,TR0,L1,V3,R52,R53,R54,R5,i4145,R6,i1,R7,s14,arbace/core.aev11,arbace.core7,find-nsm14,R0,L1,V1,R55,R2,s69,Returns the namespace named by the symbol or nil if it doesn't exist.R3,s3,1.0R4,TR5,i4155,R6,i1,R7,s14,arbace/core.aev11,arbace.core9,create-nsm14,R0,L1,V1,R55,R2,s139,Create a new namespace named by the symbol if one doesn't already\n  exist, returns it or the already-existing namespace of the same\n  name.R3,s3,1.0R4,TR5,i4161,R6,i1,R7,s14,arbace/core.aev11,arbace.core9,remove-nsm14,R0,L1,V1,R55,R2,s110,Removes the namespace named by the symbol. Use with caution.\n  Cannot be used to remove the clojure namespace.R3,s3,1.0R4,TR5,i4169,R6,i1,R7,s14,arbace/core.aev11,arbace.core6,all-nsm14,R0,L1,V0,R2,s37,Returns a sequence of all namespaces.R3,s3,1.0R4,TR5,i4176,R6,i1,R7,s14,arbace/core.aev11,arbace.core6,the-nsm14,R0,L1,MV1,R8,m2,R9,R56,R2,s137,If passed a namespace, returns it. Else, when passed a symbol,\n  returns the namespace named by it, throwing an exception if not\n  found.R3,s3,1.0R4,TR5,i4182,R6,i1,R7,s14,arbace/core.aev11,arbace.core7,ns-namem14,R0,L1,V1,R57,R2,s44,Returns the name of the namespace, a symbol.R3,s3,1.0R4,TR5,i4193,R6,i1,R7,s14,arbace/core.aev11,arbace.core6,ns-mapm14,R0,L1,V1,R57,R2,s52,Returns a map of all the mappings for the namespace.R3,s3,1.0R4,TR5,i4200,R6,i1,R7,s14,arbace/core.aev11,arbace.core8,ns-unmapm14,R0,L1,V2,R57,R55,R2,s55,Removes the mappings for the symbol from the namespace.R3,s3,1.0R4,TR5,i4207,R6,i1,R7,s14,arbace/core.aev11,arbace.core10,ns-publicsm14,R0,L1,V1,R57,R2,s62,Returns a map of the public intern mappings for the namespace.R3,s3,1.0R4,TR5,i4218,R6,i1,R7,s14,arbace/core.aev11,arbace.core10,ns-importsm14,R0,L1,V1,R57,R2,s55,Returns a map of the import mappings for the namespace.R3,s3,1.0R4,TR5,i4229,R6,i1,R7,s14,arbace/core.aev11,arbace.core10,ns-internsm14,R0,L1,V1,R57,R2,s55,Returns a map of the intern mappings for the namespace.R3,s3,1.0R4,TR5,i4236,R6,i1,R7,s14,arbace/core.aev11,arbace.core5,referm12,R0,L1,V3,R58,R14,R59,R2,s663,refers to all public vars of ns, subject to filters.\n  filters can include at most one each of:\n\n  :exclude list-of-symbols\n  :only list-of-symbols\n  :rename map-of-fromsymbol-tosymbol\n\n  For each public interned var in the namespace named by the symbol,\n  adds a mapping from the name of the var to the var to the current\n  namespace.  Throws an exception if name is already mapped to\n  something else in the current namespace. Filters can be used to\n  select a subset, via inclusion or exclusion, or to provide a mapping\n  to a symbol different from the var's name, in order to prevent\n  clashes. Use :use in the ns macro in preference to calling this directly.R3,s3,1.0R5,i4246,R6,i1,R7,s14,arbace/core.aev11,arbace.core9,ns-refersm14,R0,L1,V1,R57,R2,s54,Returns a map of the refer mappings for the namespace.R3,s3,1.0R4,TR5,i4283,R6,i1,R7,s14,arbace/core.aev11,arbace.core5,aliasm14,R0,L1,V2,R60,R61,R2,s225,Add an alias in the current namespace to another\n  namespace. Arguments are two symbols: the alias to be used, and\n  the symbolic name of the target namespace. Use :as in the ns macro in preference\n  to calling this directly.R3,s3,1.0R4,TR5,i4293,R6,i1,R7,s14,arbace/core.aev11,arbace.core10,ns-aliasesm14,R0,L1,V1,R57,R2,s47,Returns a map of the aliases for the namespace.R3,s3,1.0R4,TR5,i4303,R6,i1,R7,s14,arbace/core.aev11,arbace.core10,ns-unaliasm14,R0,L1,V2,R57,R55,R2,s52,Removes the alias for the symbol from the namespace.R3,s3,1.0R4,TR5,i4310,R6,i1,R7,s14,arbace/core.aev11,arbace.core8,take-nthm14,R0,L2,V1,R1,V2,R1,R51,R2,s110,Returns a lazy seq of every nth item in coll.  Returns a stateful\n  transducer when no collection is provided.R3,s3,1.0R4,TR5,i4317,R6,i1,R7,s14,arbace/core.aev11,arbace.core10,interleavem14,R0,L4,V0,V1,R62,V2,R62,R63,V4,R62,R63,R14,R64,R2,s71,Returns a lazy seq of the first item in each coll, then the second etc.R3,s3,1.0R4,TR5,i4338,R6,i1,R7,s14,arbace/core.aev11,arbace.core7,var-getm14,R0,L1,V1,Myn1,xm2,R9,R65,R2,s32,Gets the value in the var objectR3,s3,1.0R4,TR5,i4356,R6,i1,R7,s14,arbace/core.aev11,arbace.core7,var-setm14,R0,L1,V2,Myn1,xm2,R9,R65,R35,R2,s79,Sets the value in the var object to val. The var must be\n thread-locally bound.R3,s3,1.0R4,TR5,i4362,R6,i1,R7,s14,arbace/core.aev11,arbace.core15,with-local-varsm12,R0,L1,V3,R66,R14,R27,R2,s249,varbinding=> symbol init-expr\n\n  Executes the exprs in a context in which the symbols are bound to\n  vars with per-thread bindings to the init-exprs.  The symbols refer\n  to the var objects themselves, and must be accessed with var-get and\n  var-setR3,s3,1.0R5,i4369,R6,i1,R7,s14,arbace/core.aev11,arbace.core10,ns-resolvem14,R0,L2,V2,R57,R55,V3,R57,R67,R55,R2,s245,Returns the var or Class to which a symbol will be resolved in the\n  namespace (unless found in the environment), else nil.  Note that\n  if the symbol is fully qualified, the var/Class to which it resolves\n  need not be present in the namespace.R3,s3,1.0R4,TR5,i4388,R6,i1,R7,s14,arbace/core.aev11,arbace.core7,resolvem14,R0,L2,V1,R55,V2,R67,R55,R2,s65,same as (ns-resolve *ns* symbol) or (ns-resolve *ns* &env symbol)R3,s3,1.0R4,TR5,i4401,R6,i1,R7,s14,arbace/core.aev11,arbace.core9,array-mapm14,R0,L2,V0,V2,R14,R68,R2,s99,Constructs an array-map. If any keys are equal, they are handled as\n  if by repeated uses of assoc.R3,s3,1.0R4,TR5,i4408,R6,i1,R7,s14,arbace/core.aev11,arbace.core6,zipmapm14,R0,L1,V2,R46,R48,R2,s61,Returns a map with the keys mapped to the corresponding vals.R3,s3,1.0R4,TR5,i4420,R6,i1,R7,s14,arbace/core.aev11,arbace.core10,repeatedlym14,R0,L2,V1,R69,V2,R1,R69,R2,s141,Takes a function of no args, presumably with side effects, and\n  returns an infinite (or length n if supplied) lazy sequence of calls\n  to itR3,s3,1.0R4,TR5,i4434,R6,i1,R7,s14,arbace/core.aev11,arbace.core8,counted?m14,R0,L1,V1,R51,R2,s54,Returns true if coll implements count in constant timeR3,s3,1.0R4,TR5,i4443,R6,i1,R7,s14,arbace/core.aev11,arbace.core6,empty?m14,R0,L1,V1,R51,R2,s127,Returns true if coll has no items. To check the emptiness of a seq,\n  please use the idiom (seq x) rather than (not (empty? x))R3,s3,1.0R4,TR5,i4449,R6,i1,R7,s14,arbace/core.aev11,arbace.core9,reduce-kvm8,R70,TR5,i4459,R6,i1,R7,s14,arbace/core.aev11,arbace.core9,some-valsm14,R0,L1,V1,R71,R2,s92,Returns a map with only the non-nil values of map m. Returns nil if\n  m has no non-nil vals.R3,s4,1.13R4,TR5,i4461,R6,i1,R7,s14,arbace/core.aev11,arbace.core28,seq-to-map-for-destructuringm12,R0,L1,V1,R22,R2,s103,Builds a map from a seq as described in\n  https://clojure.org/reference/special_forms#keyword-argumentsR3,s4,1.11R5,i4472,R6,i1,R7,s14,arbace/core.aev11,arbace.core8,destvec*m10,R10,TR0,L1,V4,R72,R73,R74,R35,R5,i4482,R6,i1,R7,s14,arbace/core.aev11,arbace.core8,destmap*m10,R10,TR0,L1,V4,R72,R73,R74,R23,R5,i4519,R6,i1,R7,s14,arbace/core.ae")

var Lit_1183 *jrt.String = jrt.Intern("arbace.core$float_QMARK_")

var Lit_1184 *jrt.String = jrt.Intern("arbace.core$rational_QMARK_")

var Lit_1185 *jrt.String = jrt.Intern("arbace.core$bigint")

var Lit_1186 *jrt.String = jrt.Intern("arbace.core$biginteger")

var Lit_1187 *jrt.String = jrt.Intern("arbace.core$bigdec")

var Lit_1188 *jrt.String = jrt.Intern("print-method")

var Lit_1189 *jrt.String = jrt.Intern("arbace.core$eval1927000798$fn__1927000799")

var Lit_1190 *jrt.String = jrt.Intern("print-dup")

var Lit_1191 *jrt.String = jrt.Intern("arbace.core$eval1927000802$fn__1927000803")

var Lit_1192 *jrt.String = jrt.Intern("arbace.core$pr_on")

var Lit_1193 *jrt.String = jrt.Intern("arbace.core$pr")

var Lit_1194 *jrt.String = jrt.Intern("line.separator")

var Lit_1195 *jrt.String = jrt.Intern("arbace.core$newline")

var Lit_1196 *jrt.String = jrt.Intern("arbace.core$flush")

var Lit_1197 *jrt.String = jrt.Intern("arbace.core$prn")

var Lit_1198 *jrt.String = jrt.Intern("arbace.core$print")

var Lit_1199 *jrt.String = jrt.Intern("arbace.core$println")

var Lit_1200 *jrt.String = jrt.Intern("arbace.core$read")

var Lit_1201 *jrt.String = jrt.Intern("arbace.core$read_PLUS_string")

var Lit_1202 *jrt.String = jrt.Intern("arbace.core$read_line")

var Lit_1203 *jrt.String = jrt.Intern("arbace.core$read_string")

var Lit_1204 *jrt.String = jrt.Intern("arbace.core$subvec")

var Lit_1205 *jrt.String = jrt.Intern("arbace.core$with_open")

var Lit_1206 *jrt.String = jrt.Intern("arbace.core$doto")

var Lit_1207 *jrt.String = jrt.Intern("arbace.core$memfn")

var Lit_1208 *jrt.String = jrt.Intern("arbace.core$time")

var Lit_1209 *jrt.String = jrt.Intern("java.lang.reflect.Array")

var Lit_1210 *jrt.String = jrt.Intern("arbace.core$alength")

var Lit_1211 *jrt.String = jrt.Intern("Returns the length of the Java array. Works on arrays of all\n  types.")

var Lit_1212 *jrt.String = jrt.Intern("arbace.core$alength__inliner__1927000844")

var Lit_1213 *jrt.String = jrt.Intern("arbace.core$aclone")

var Lit_1214 *jrt.String = jrt.Intern("Returns a clone of the Java array. Works on arrays of known\n  types.")

var Lit_1215 *jrt.String = jrt.Intern("arbace.core$aclone__inliner__1927000847")

var Lit_1216 *jrt.String = jrt.Intern("arbace.core$aget")

var Lit_1217 *jrt.String = jrt.Intern("Returns the value at the index/indices. Works on Java arrays of all\n  types.")

var Lit_1218 *jrt.String = jrt.Intern("arbace.core$aget__inliner__1927000850")

var Lit_1219 *jrt.String = jrt.Intern("arbace.core$aset")

var Lit_1220 *jrt.String = jrt.Intern("Sets the value at the index/indices. Works on Java arrays of\n  reference types. Returns val.")

var Lit_1221 *jrt.String = jrt.Intern("arbace.core$aset__inliner__1927000853")

var Lit_1222 *jrt.String = jrt.Intern("arbace.core$def_aset")

var Lit_1223 *jrt.String = jrt.Intern("arbace.core$aset_int")

var Lit_1224 *jrt.String = jrt.Intern("arbace.core$aset_long")

var Lit_1225 *jrt.String = jrt.Intern("arbace.core$aset_boolean")

var Lit_1226 *jrt.String = jrt.Intern("arbace.core$aset_float")

var Lit_1227 *jrt.String = jrt.Intern("arbace.core$aset_double")

var Lit_1228 *jrt.String = jrt.Intern("arbace.core$aset_short")

var Lit_1229 *jrt.String = jrt.Intern("arbace.core$aset_byte")

var Lit_1230 *jrt.String = jrt.Intern("arbace.core$aset_char")

var Lit_1231 *jrt.String = jrt.Intern("arbace.core$make_array")

var Lit_1232 *jrt.String = jrt.Intern("arbace.core$to_array_2d")

var Lit_1233 *jrt.String = jrt.Intern("arbace.core$macroexpand_1")

var Lit_1234 *jrt.String = jrt.Intern("arbace.core$macroexpand")

var Lit_1235 *jrt.String = jrt.Intern("arbace.core$create_struct")

var Lit_1236 *jrt.String = jrt.Intern("arbace.core$defstruct")

var Lit_1237 *jrt.String = jrt.Intern("arbace.core$struct_map")

var Lit_1238 *jrt.String = jrt.Intern("arbace.core$struct")

var Lit_1239 *jrt.String = jrt.Intern("arbace.core$accessor")

var Lit_1240 *jrt.String = jrt.Intern("arbace.core$load_reader")

var Lit_1241 *jrt.String = jrt.Intern("arbace.core$load_string")

var Lit_1242 *jrt.String = jrt.Intern("arbace.core$set_QMARK_")

var Lit_1243 *jrt.String = jrt.Intern("arbace.core$set")

var Lit_1244 *jrt.String = jrt.Intern("arbace.core$filter_key")

var Lit_1245 *jrt.String = jrt.Intern("arbace.core$find_ns")

var Lit_1246 *jrt.String = jrt.Intern("arbace.core$create_ns")

var Lit_1247 *jrt.String = jrt.Intern("arbace.core$remove_ns")

var Lit_1248 *jrt.String = jrt.Intern("arbace.core$all_ns")

var Lit_1249 *jrt.String = jrt.Intern("arbace.core$the_ns")

var Lit_1250 *jrt.String = jrt.Intern("arbace.core$ns_name")

var Lit_1251 *jrt.String = jrt.Intern("arbace.core$ns_map")

var Lit_1252 *jrt.String = jrt.Intern("arbace.core$ns_unmap")

var Lit_1253 *jrt.String = jrt.Intern("arbace.core$ns_publics")

var Lit_1254 *jrt.String = jrt.Intern("arbace.core$ns_imports")

var Lit_1255 *jrt.String = jrt.Intern("arbace.core$ns_interns")

var Lit_1256 *jrt.String = jrt.Intern("arbace.core$refer")

var Lit_1257 *jrt.String = jrt.Intern("arbace.core$ns_refers")

var Lit_1258 *jrt.String = jrt.Intern("arbace.core$alias")

var Lit_1259 *jrt.String = jrt.Intern("arbace.core$ns_aliases")

var Lit_1260 *jrt.String = jrt.Intern("arbace.core$ns_unalias")

var Lit_1261 *jrt.String = jrt.Intern("arbace.core$take_nth")

var Lit_1262 *jrt.String = jrt.Intern("arbace.core$interleave")

var Lit_1263 *jrt.String = jrt.Intern("arbace.core$var_get")

var Lit_1264 *jrt.String = jrt.Intern("arbace.core$var_set")

var Lit_1265 *jrt.String = jrt.Intern("arbace.core$with_local_vars")

var Lit_1266 *jrt.String = jrt.Intern("arbace.core$ns_resolve")

var Lit_1267 *jrt.String = jrt.Intern("arbace.core$resolve")

var Lit_1268 *jrt.String = jrt.Intern("arbace.core$array_map")

var Lit_1269 *jrt.String = jrt.Intern("arbace.core$zipmap")

var Lit_1270 *jrt.String = jrt.Intern("arbace.core$repeatedly")

var Lit_1271 *jrt.String = jrt.Intern("arbace.core$counted_QMARK_")

var Lit_1272 *jrt.String = jrt.Intern("arbace.core$empty_QMARK_")

var Lit_1273 *jrt.String = jrt.Intern("arbace.core$some_vals")

var Lit_1274 *jrt.String = jrt.Intern("arbace.core$seq_to_map_for_destructuring")

var Lit_1275 *jrt.String = jrt.Intern("arbace.core$destvec_STAR_")

var Lit_1276 *jrt.String = jrt.Intern("arbace.core$destmap_STAR_")

var Lit_1277 *jrt.String = jrt.Intern("kn8,arglistsyn8,bindingskn4,linekn6,columnkn4,fileyn1,&yn4,bodykn3,dockn5,addedkn12,special-formkn5,formsyn3,letyn9,bindings*yn6,exprs*kn7,privateyn6,paramsyn4,sigsyn2,fnyn5,name?yn7,params*yn1,+yn4,loopyn5,collsyn9,seq-exprsyn9,body-expryn1,syn2,xskn3,tagkn6,staticyn9,Throwableyn10,class-nameyn3,msgyn3,mapyn5,causeyn2,exyn1,xyn7,messageyn1,vyn23,java.util.regex.Patternyn23,java.util.regex.Matcheryn1,nyn4,nameyn5,declsyn7,branch?yn8,childrenyn4,rootyn3,diryn6,Stringyn5,startyn16,java.lang.Stringyn3,endyn1,kyn1,yyn4,moreyn4,collyn4,smapyn5,exprsyn9,precisionyn18,arbace.lang.Sortedyn4,testyn3,keyyn10,start-testyn9,start-keyyn8,end-testyn7,end-keyyn3,urlkn10,deprecatedyn4,longyn3,sepyn4,declyn1,ayn3,idxyn3,retyn4,expryn4,inityn11,size-or-seqyn4,sizeyn15,init-val-or-seqv11,arbace.core11,destructurem8,R0,L1,V1,R1,R2,i4680,R3,i1,R4,s14,arbace/core.aem16,R0,L1,V3,R1,R5,R6,R7,s407,binding => binding-form init-expr\n  binding-form => name, or destructuring-form\n  destructuring-form => map-destructure-form, or seq-destructure-form\n\n  Evaluates the exprs in a lexical context in which the symbols in\n  the binding-forms are bound to their respective init-exprs or parts\n  therein.\n\n  See https://clojure.org/reference/special_forms#binding-forms for\n  more information about destructuring.R8,s3,1.0R9,TR10,V1,ML3,R11,V1,R12,R13,m4,R2,i4704,R3,i47,R2,i4693,R3,i1,R4,s14,arbace/core.aev11,arbace.core18,maybe-destructuredm10,R14,TR0,L1,V2,R15,R6,R2,i4711,R3,i1,R4,s14,arbace/core.aem16,R0,L1,V2,R5,R16,R7,s272,params => positional-params*, or positional-params* & rest-param\n  positional-param => binding-form\n  rest-param => binding-form\n  binding-form => name, or destructuring-form\n\n  Defines a function.\n\n  See https://clojure.org/reference/special_forms#fn for more informationR8,s3,1.0R9,TR10,V2,ML4,R17,R18,V1,R19,R13,m4,R2,i4740,R3,i13,ML4,R17,R18,ML2,V1,R19,R13,m4,R2,i4740,R3,i52,R20,m4,R2,i4740,R3,i42,R2,i4730,R3,i1,R4,s14,arbace/core.aem16,R0,L1,V3,R1,R5,R6,R7,s169,Evaluates the exprs in a lexical context in which the symbols in\n  the binding-forms are bound to their respective init-exprs or parts\n  therein. Acts as a recur target.R8,s3,1.0R9,TR10,V1,ML3,R21,V1,R12,R13,m4,R2,i4798,R3,i47,R2,i4794,R3,i1,R4,s14,arbace/core.aev11,arbace.core10,when-firstm12,R0,L1,V3,R1,R5,R6,R7,s111,bindings => x xs\n\n  Roughly the same as (when (seq xs) (let [x (first xs)] body)) but xs is evaluated only onceR8,s3,1.0R2,i4819,R3,i1,R4,s14,arbace/core.aev11,arbace.core8,lazy-catm12,R0,L1,V2,R5,R22,R7,s223,Expands to code which yields a lazy sequence of the concatenation\n  of the supplied colls.  Each coll expr is not evaluated until it is\n  needed.\n\n  (lazy-cat xs ys zs) === (concat (lazy-seq xs) (lazy-seq ys) (lazy-seq zs))R8,s3,1.0R2,i4833,R3,i1,R4,s14,arbace/core.aev11,arbace.core3,form12,R0,L1,V2,R23,R24,R7,s498,List comprehension. Takes a vector of one or more\n   binding-form/collection-expr pairs, each followed by zero or more\n   modifiers, and yields a lazy sequence of evaluations of expr.\n   Collections are iterated in a nested fashion, rightmost fastest,\n   and nested coll-exprs can refer to bindings created in prior\n   binding-forms.  Supported modifiers are: :let [binding-form expr ...],\n   :while test, :when test.\n\n  (take 100 (for [x (range 100000000) y (range 1000000) :while (< y x)] [x y]))R8,s3,1.0R2,i4843,R3,i1,R4,s14,arbace/core.aev11,arbace.core7,commentm12,R0,L1,V2,R5,R6,R7,s24,Ignores body, yields nilR8,s3,1.0R2,i4930,R3,i1,R4,s14,arbace/core.aev11,arbace.core12,with-out-strm12,R0,L1,V2,R5,R6,R7,s139,Evaluates exprs in a context in which *out* is bound to a fresh\n  StringWriter.  Returns the string created by any nested printing\n  calls.R8,s3,1.0R2,i4935,R3,i1,R4,s14,arbace/core.aev11,arbace.core11,with-in-strm12,R0,L1,V3,R25,R5,R6,R7,s107,Evaluates body in a context in which *in* is bound to a fresh\n  StringReader initialized with the string s.R8,s3,1.0R2,i4946,R3,i1,R4,s14,arbace/core.aev11,arbace.core6,pr-strm16,R0,L1,V2,R5,R26,R7,s28,pr to a string, returning itR27,C16,java.lang.StringR8,s3,1.0R28,TR2,i4955,R3,i1,R4,s14,arbace/core.aev11,arbace.core7,prn-strm16,R0,L1,V2,R5,R26,R7,s29,prn to a string, returning itR27,C16,java.lang.StringR8,s3,1.0R28,TR2,i4964,R3,i1,R4,s14,arbace/core.aev11,arbace.core9,print-strm16,R0,L1,V2,R5,R26,R7,s31,print to a string, returning itR27,C16,java.lang.StringR8,s3,1.0R28,TR2,i4973,R3,i1,R4,s14,arbace/core.aev11,arbace.core11,println-strm16,R0,L1,V2,R5,R26,R7,s33,println to a string, returning itR27,C16,java.lang.StringR8,s3,1.0R28,TR2,i4982,R3,i1,R4,s14,arbace/core.aev11,arbace.core16,elide-top-framesm10,R14,TR0,L1,V2,Myn2,exm2,R27,R29,R30,R2,i4993,R3,i1,R4,s14,arbace/core.aev11,arbace.core7,ex-infom12,R0,L2,V2,R31,R32,V3,R31,R32,R33,R7,s106,Create an instance of ExceptionInfo, a RuntimeException subclass\n   that carries a map of additional data.R8,s3,1.4R2,i5002,R3,i1,R4,s14,arbace/core.aev11,arbace.core7,ex-datam12,R0,L1,V1,R34,R7,s84,Returns exception data (a map) if ex is an IExceptionInfo.\n   Otherwise returns nil.R8,s3,1.4R2,i5011,R3,i1,R4,s14,arbace/core.aev11,arbace.core10,ex-messagem12,R0,L1,V1,R34,R7,s81,Returns the message attached to ex if ex is a Throwable.\n  Otherwise returns nil.R8,s4,1.10R2,i5019,R3,i1,R4,s14,arbace/core.aev11,arbace.core8,ex-causem14,R0,L1,V1,R34,R7,s70,Returns the cause of ex if ex is a Throwable.\n  Otherwise returns nil.R27,C19,java.lang.ThrowableR8,s4,1.10R2,i5027,R3,i1,R4,s14,arbace/core.aev11,arbace.core6,assertm12,R0,L2,V1,R35,V2,R35,R36,R7,s192,Evaluates expression x and throws an AssertionError with optional\n  message if x does not evaluate to logical true.\n\n  Assertion checks are omitted from compiled code if '*assert*' is\n  false.R8,s3,1.0R2,i5036,R3,i1,R4,s14,arbace/core.aev11,arbace.core4,testm12,R0,L1,V1,R37,R7,s101,test [v] finds fn at key :test in var metadata and calls it,\n  presuming failure will throw exceptionR8,s3,1.0R2,i5052,R3,i1,R4,s14,arbace/core.aev11,arbace.core10,re-patternm16,R0,L1,V1,R25,R7,s78,Returns an instance of java.util.regex.Pattern, for use, e.g. in\n  re-matcher.R27,C23,java.util.regex.PatternR8,s3,1.0R28,TR2,i5062,R3,i1,R4,s14,arbace/core.aev11,arbace.core10,re-matcherm16,R0,L1,V2,Myn2,rem2,R27,R38,R25,R7,s75,Returns an instance of java.util.regex.Matcher, for use, e.g. in\n  re-find.R27,C23,java.util.regex.MatcherR8,s3,1.0R28,TR2,i5072,R3,i1,R4,s14,arbace/core.aev11,arbace.core9,re-groupsm14,R0,L1,V1,Myn1,mm2,R27,R39,R7,s228,Returns the groups from the most recent match/find. If there are no\n  nested groups, returns a string of the entire match. If there are\n  nested groups, returns a vector of the groups, the first element\n  being the entire match.R8,s3,1.0R28,TR2,i5081,R3,i1,R4,s14,arbace/core.aev11,arbace.core6,re-seqm14,R0,L1,V2,Myn2,rem2,R27,R38,R25,R7,s151,Returns a lazy sequence of successive matches of pattern in string,\n  using java.util.regex.Matcher.find(), each such match processed with\n  re-groups.R8,s3,1.0R28,TR2,i5097,R3,i1,R4,s14,arbace/core.aev11,arbace.core10,re-matchesm14,R0,L1,V2,Myn2,rem2,R27,R38,R25,R7,s131,Returns the match, if any, of string to pattern, using\n  java.util.regex.Matcher.matches().  Uses re-groups to return the\n  groups.R8,s3,1.0R28,TR2,i5109,R3,i1,R4,s14,arbace/core.aev11,arbace.core7,re-findm14,R0,L2,V1,Myn1,mm2,R27,R39,V2,Myn2,rem2,R27,R38,R25,R7,s139,Returns the next regex match, if any, of string to pattern, using\n  java.util.regex.Matcher.find().  Uses re-groups to return the\n  groups.R8,s3,1.0R28,TR2,i5120,R3,i1,R4,s14,arbace/core.aev11,arbace.core4,randm14,R0,L2,V0,V1,R40,R7,s93,Returns a random floating point number between 0 (inclusive) and\n  n (default 1) (exclusive).R8,s3,1.0R28,TR2,i5133,R3,i1,R4,s14,arbace/core.aev11,arbace.core8,rand-intm14,R0,L1,V1,R40,R7,s65,Returns a random integer between 0 (inclusive) and n (exclusive).R8,s3,1.0R28,TR2,i5141,R3,i1,R4,s14,arbace/core.aev11,arbace.core5,defn-m12,R0,L1,V3,R41,R5,R42,R7,s37,same as defn, yielding non-public defR8,s3,1.0R2,i5147,R3,i1,R4,s14,arbace/core.aev11,arbace.core8,tree-seqm14,R0,L1,V3,R43,R44,R45,R7,s361,Returns a lazy sequence of the nodes in a tree, via a depth-first walk.\n   branch? must be a fn of one arg that returns true if passed a node\n   that can have children (but may not).  children must be a fn of one\n   arg that returns a sequence of the children. Will only be called on\n   nodes for which branch? returns true. Root is the root node of the\n  tree.R8,s3,1.0R28,TR2,i5153,R3,i1,R4,s14,arbace/core.aev11,arbace.core8,file-seqm14,R0,L1,V1,R46,R7,s27,A tree seq on java.io.FilesR8,s3,1.0R28,TR2,i5170,R3,i1,R4,s14,arbace/core.aev11,arbace.core7,xml-seqm14,R0,L1,V1,R45,R7,s47,A tree seq on the xml elements as per xml/parseR8,s3,1.0R28,TR2,i5180,R3,i1,R4,s14,arbace/core.aev11,arbace.core15,special-symbol?m14,R0,L1,V1,R25,R7,s38,Returns true if s names a special formR8,s3,1.0R28,TR2,i5190,R3,i1,R4,s14,arbace/core.aev11,arbace.core4,var?m14,R0,L1,V1,R37,R7,s44,Returns true if v is of type arbace.lang.VarR8,s3,1.0R28,TR2,i5197,R3,i1,R4,s14,arbace/core.aev11,arbace.core4,subsm14,R0,L2,MV2,Myn1,sm2,R27,R47,R48,m2,R27,R49,MV3,Myn1,sm2,R27,R47,R48,R50,m2,R27,R49,R7,s119,Returns the substring of s beginning at start inclusive, and ending\n  at end (defaults to length of string), exclusive.R8,s3,1.0R28,TR2,i5203,R3,i1,R4,s14,arbace/core.aev11,arbace.core7,max-keym14,R0,L3,V2,R51,R35,V3,R51,R35,R52,V5,R51,R35,R52,R5,R53,R7,s113,Returns the x for which (k x), a number, is greatest.\n\n  If there are multiple such xs, the last one is returned.R8,s3,1.0R28,TR2,i5211,R3,i1,R4,s14,arbace/core.aev11,arbace.core7,min-keym14,R0,L3,V2,R51,R35,V3,R51,R35,R52,V5,R51,R35,R52,R5,R53,R7,s110,Returns the x for which (k x), a number, is least.\n\n  If there are multiple such xs, the last one is returned.R8,s3,1.0R28,TR2,i5231,R3,i1,R4,s14,arbace/core.aev11,arbace.core8,distinctm14,R0,L2,V0,V1,R54,R7,s136,Returns a lazy sequence of the elements of coll with duplicates removed.\n  Returns a stateful transducer when no collection is provided.R8,s3,1.0R28,TR2,i5251,R3,i1,R4,s14,arbace/core.aev11,arbace.core7,replacem14,R0,L2,V1,R55,V2,R55,R54,R7,s217,Given a map of replacement pairs and a vector/collection, returns a\n  vector/seq with any elements = a key in smap replaced with the\n  corresponding val in smap.  Returns a transducer when no collection\n  is provided.R8,s3,1.0R28,TR2,i5278,R3,i1,R4,s14,arbace/core.aev11,arbace.core6,dosyncm12,R0,L1,V2,R5,R56,R7,s320,Runs the exprs (in an implicit do) in a transaction that encompasses\n  exprs and any nested calls.  Starts a transaction if none is already\n  running on this thread. Any uncaught exception will abort the\n  transaction and flow out of dosync. The exprs may be run more than\n  once, but any effects on Refs will be atomic.R8,s3,1.0R2,i5296,R3,i1,R4,s14,arbace/core.aev11,arbace.core14,with-precisionm12,R0,L1,V3,R57,R5,R56,R7,s301,Sets the precision and rounding mode to be used for BigDecimal operations.\n\n  Usage: (with-precision 10 (/ 1M 3))\n  or:    (with-precision 10 :rounding HALF_DOWN (/ 1M 3))\n\n  The rounding mode is one of CEILING, FLOOR, HALF_UP, HALF_DOWN,\n  HALF_EVEN, UP, DOWN and UNNECESSARY; it defaults to HALF_UP.R8,s3,1.0R2,i5306,R3,i1,R4,s14,arbace/core.aev11,arbace.core11,mk-bound-fnm10,R0,L1,V3,Myn2,scm2,R27,R58,R59,R60,R14,TR2,i5323,R3,i1,R4,s14,arbace/core.aev11,arbace.core6,subseqm14,R0,L2,V3,Myn2,scm2,R27,R58,R59,R60,V5,Myn2,scm2,R27,R58,R61,R62,R63,R64,R7,s173,sc must be a sorted collection, test(s) one of <, <=, > or\n  >=. Returns a seq of those entries with keys ek for\n  which (test (.. sc comparator (compare ek key)) 0) is trueR8,s3,1.0R28,TR2,i5329,R3,i1,R4,s14,arbace/core.aev11,arbace.core7,rsubseqm14,R0,L2,V3,Myn2,scm2,R27,R58,R59,R60,V5,Myn2,scm2,R27,R58,R61,R62,R63,R64,R7,s181,sc must be a sorted collection, test(s) one of <, <=, > or\n  >=. Returns a reverse seq of those entries with keys ek for\n  which (test (.. sc comparator (compare ek key)) 0) is trueR8,s3,1.0R28,TR2,i5346,R3,i1,R4,s14,arbace/core.aev11,arbace.core13,add-classpathm14,R0,L1,V1,R65,R7,s94,DEPRECATED\n\n  Adds the url (String or URL object) to the classpath per\n  URLClassLoader.addURLR8,s3,1.0R66,s3,1.1R2,i5363,R3,i1,R4,s14,arbace/core.aev11,arbace.core4,hashm14,R0,L1,V1,R35,R7,s175,Returns the hash code of its argument. Note this is the hash code\n  consistent with =, and thus is different than .hashCode for Integer,\n  Short, Byte and Clojure collections.R8,s3,1.0R28,TR2,i5374,R3,i1,R4,s14,arbace/core.aev11,arbace.core19,mix-collection-hashm14,R0,L1,MV2,Myn10,hash-basism2,R27,R67,Myn5,countm2,R27,R67,m2,R27,R67,R7,s311,Mix final collection hash for ordered or unordered collections.\n   hash-basis is the combined collection hash, count is the number\n   of elements included in the basis. Note this is the hash code\n   consistent with =, different from .hashCode.\n   See http://clojure.org/data_structures#hash for full algorithms.R8,s3,1.6R28,TR2,i5383,R3,i1,R4,s14,arbace/core.aev11,arbace.core17,hash-ordered-collm14,R0,L1,MV1,R54,m2,R27,R67,R7,s170,Returns the hash code, consistent with =, for an external ordered\n   collection implementing Iterable.\n   See http://clojure.org/data_structures#hash for full algorithms.R8,s3,1.6R28,TR2,i5394,R3,i1,R4,s14,arbace/core.aev11,arbace.core19,hash-unordered-collm14,R0,L1,MV1,R54,m2,R27,R67,R7,s282,Returns the hash code, consistent with =, for an external unordered\n   collection implementing Iterable. For maps, the iterator should\n   return map entries whose hash is computed as\n     (hash-ordered-coll [k v]).\n   See http://clojure.org/data_structures#hash for full algorithms.R8,s3,1.6R28,TR2,i5403,R3,i1,R4,s14,arbace/core.aev11,arbace.core9,interposem14,R0,L2,V1,R68,V2,R68,R54,R7,s124,Returns a lazy seq of the elements of coll separated by sep.\n  Returns a stateful transducer when no collection is provided.R8,s3,1.0R28,TR2,i5414,R3,i1,R4,s14,arbace/core.aev11,arbace.core9,definlinem12,R0,L1,V3,R41,R5,R69,R7,s194,Experimental - like defmacro, except defines a named function whose\n  body is the expansion, calls to which may be expanded inline as if\n  it were a macro. Cannot be used with variadic (&) args.R8,s3,1.0R2,i5437,R3,i1,R4,s14,arbace/core.aev11,arbace.core5,emptym14,R0,L1,V1,R54,R7,s64,Returns an empty collection of the same category as coll, or nilR8,s3,1.0R28,TR2,i5449,R3,i1,R4,s14,arbace/core.aev11,arbace.core4,amapm12,R0,L1,V4,R70,R71,R72,R73,R7,s215,Maps an expression across an array a, using an index named idx, and\n  return value named ret, initialized to a clone of a, then setting\n  each element of ret to the evaluation of expr, returning the new\n  array ret.R8,s3,1.0R2,i5457,R3,i1,R4,s14,arbace/core.aev11,arbace.core7,areducem12,R0,L1,V5,R70,R71,R72,R74,R73,R7,s186,Reduces an expression across an array a, using an index named idx,\n  and return value named ret, initialized to init, setting ret to the\n  evaluation of expr at each step, returning ret.R8,s3,1.0R2,i5473,R3,i1,R4,s14,arbace/core.aev11,arbace.core11,float-arrayL2,V1,R75,V2,R76,R77,S2,l1,l2,i5485,v11,arbace.core13,boolean-arrayL2,V1,R75,V2,R76,R77,S2,l1,l2,i5493,v11,arbace.core10,byte-arrayL2,V1,R75,V2,R76,R77,S2,l1,l2,i5501,v11,arbace.core10,char-arrayL2,V1,R75,V2,R76,R77,S2,l1,l2,i5509,v11,arbace.core11,short-arrayL2,V1,R75,V2,R76,R77,S2,l1,l2,i5517,v11,arbace.core12,double-arrayL2,V1,R75,V2,R76,R77,S2,l1,l2,i5525,v11,arbace.core12,object-arrayL1,V1,R75,S1,l1,i5533,v11,arbace.core9,int-arrayL2,V1,R75,V2,R76,R77,S2,l1,l2,i5540,v11,arbace.core10,long-arrayL2,V1,R75,V2,R76,R77,S2,l1,l2,i5548,v11,arbace.core8,booleansm12,R0,L1,V1,R26,R7,s18,Casts to boolean[]R8,s3,1.1R2,i5556,R3,i1,R4,s14,arbace/core.ae")

var Lit_1278 *jrt.String = jrt.Intern("arbace.core$destructure")

var Lit_1279 *jrt.String = jrt.Intern("arbace.core$let")

var Lit_1280 *jrt.String = jrt.Intern("arbace.core$maybe_destructured")

var Lit_1281 *jrt.String = jrt.Intern("arbace.core$fn")

var Lit_1282 *jrt.String = jrt.Intern("arbace.core$loop")

var Lit_1283 *jrt.String = jrt.Intern("arbace.core$when_first")

var Lit_1284 *jrt.String = jrt.Intern("arbace.core$lazy_cat")

var Lit_1285 *jrt.String = jrt.Intern("arbace.core$for")

var Lit_1286 *jrt.String = jrt.Intern("arbace.core$comment")

var Lit_1287 *jrt.String = jrt.Intern("arbace.core$with_out_str")

var Lit_1288 *jrt.String = jrt.Intern("arbace.core$with_in_str")

var Lit_1289 *jrt.String = jrt.Intern("arbace.core$pr_str")

var Lit_1290 *jrt.String = jrt.Intern("arbace.core$prn_str")

var Lit_1291 *jrt.String = jrt.Intern("arbace.core$print_str")

var Lit_1292 *jrt.String = jrt.Intern("arbace.core$println_str")

var Lit_1293 *jrt.String = jrt.Intern("arbace.lang.ExceptionInfo")

var Lit_1294 *jrt.String = jrt.Intern("arbace.lang.IExceptionInfo")

var Lit_1295 *jrt.String = jrt.Intern("arbace.core$elide_top_frames")

var Lit_1296 *jrt.String = jrt.Intern("arbace.core$ex_data")

var Lit_1297 *jrt.String = jrt.Intern("arbace.core$ex_message")

var Lit_1298 *jrt.String = jrt.Intern("arbace.core$ex_cause")

var Lit_1299 *jrt.String = jrt.Intern("arbace.core$assert")

var Lit_1300 *jrt.String = jrt.Intern("arbace.core$test")

var Lit_1301 *jrt.String = jrt.Intern("arbace.core$re_pattern")

var Lit_1302 *jrt.String = jrt.Intern("arbace.core$re_matcher")

var Lit_1303 *jrt.String = jrt.Intern("arbace.core$re_groups")

var Lit_1304 *jrt.String = jrt.Intern("arbace.core$re_seq")

var Lit_1305 *jrt.String = jrt.Intern("arbace.core$re_matches")

var Lit_1306 *jrt.String = jrt.Intern("arbace.core$re_find")

var Lit_1307 *jrt.String = jrt.Intern("arbace.core$rand")

var Lit_1308 *jrt.String = jrt.Intern("arbace.core$rand_int")

var Lit_1309 *jrt.String = jrt.Intern("arbace.core$defn_")

var Lit_1310 *jrt.String = jrt.Intern("arbace.core$tree_seq")

var Lit_1311 *jrt.String = jrt.Intern("arbace.core$file_seq")

var Lit_1312 *jrt.String = jrt.Intern("arbace.core$xml_seq")

var Lit_1313 *jrt.String = jrt.Intern("arbace.core$special_symbol_QMARK_")

var Lit_1314 *jrt.String = jrt.Intern("arbace.core$var_QMARK_")

var Lit_1315 *jrt.String = jrt.Intern("arbace.core$subs")

var Lit_1316 *jrt.String = jrt.Intern("arbace.core$max_key")

var Lit_1317 *jrt.String = jrt.Intern("arbace.core$min_key")

var Lit_1318 *jrt.String = jrt.Intern("arbace.core$distinct")

var Lit_1319 *jrt.String = jrt.Intern("arbace.core$replace")

var Lit_1320 *jrt.String = jrt.Intern("arbace.core$dosync")

var Lit_1321 *jrt.String = jrt.Intern("arbace.core$with_precision")

var Lit_1322 *jrt.String = jrt.Intern("arbace.core$mk_bound_fn")

var Lit_1323 *jrt.String = jrt.Intern("arbace.core$subseq")

var Lit_1324 *jrt.String = jrt.Intern("arbace.core$rsubseq")

var Lit_1325 *jrt.String = jrt.Intern("arbace.core$add_classpath")

var Lit_1326 *jrt.String = jrt.Intern("arbace.core$hash")

var Lit_1327 *jrt.String = jrt.Intern("arbace.core$mix_collection_hash")

var Lit_1328 *jrt.String = jrt.Intern("arbace.core$hash_ordered_coll")

var Lit_1329 *jrt.String = jrt.Intern("arbace.core$hash_unordered_coll")

var Lit_1330 *jrt.String = jrt.Intern("arbace.core$interpose")

var Lit_1331 *jrt.String = jrt.Intern("arbace.core$definline")

var Lit_1332 *jrt.String = jrt.Intern("arbace.core$empty")

var Lit_1333 *jrt.String = jrt.Intern("arbace.core$amap")

var Lit_1334 *jrt.String = jrt.Intern("arbace.core$areduce")

var Lit_1335 *jrt.String = jrt.Intern("arbace.core$float_array")

var Lit_1336 *jrt.String = jrt.Intern("Creates an array of floats")

var Lit_1337 *jrt.String = jrt.Intern("arbace.core$float_array__inliner__1927001257")

var Lit_1338 *jrt.String = jrt.Intern("arbace.core$boolean_array")

var Lit_1339 *jrt.String = jrt.Intern("Creates an array of booleans")

var Lit_1340 *jrt.String = jrt.Intern("arbace.core$boolean_array__inliner__1927001260")

var Lit_1341 *jrt.String = jrt.Intern("arbace.core$byte_array")

var Lit_1342 *jrt.String = jrt.Intern("Creates an array of bytes")

var Lit_1343 *jrt.String = jrt.Intern("arbace.core$byte_array__inliner__1927001263")

var Lit_1344 *jrt.String = jrt.Intern("arbace.core$char_array")

var Lit_1345 *jrt.String = jrt.Intern("Creates an array of chars")

var Lit_1346 *jrt.String = jrt.Intern("arbace.core$char_array__inliner__1927001266")

var Lit_1347 *jrt.String = jrt.Intern("arbace.core$short_array")

var Lit_1348 *jrt.String = jrt.Intern("Creates an array of shorts")

var Lit_1349 *jrt.String = jrt.Intern("arbace.core$short_array__inliner__1927001269")

var Lit_1350 *jrt.String = jrt.Intern("arbace.core$double_array")

var Lit_1351 *jrt.String = jrt.Intern("Creates an array of doubles")

var Lit_1352 *jrt.String = jrt.Intern("arbace.core$double_array__inliner__1927001272")

var Lit_1353 *jrt.String = jrt.Intern("arbace.core$object_array")

var Lit_1354 *jrt.String = jrt.Intern("Creates an array of objects")

var Lit_1355 *jrt.String = jrt.Intern("arbace.core$object_array__inliner__1927001275")

var Lit_1356 *jrt.String = jrt.Intern("arbace.core$int_array")

var Lit_1357 *jrt.String = jrt.Intern("Creates an array of ints")

var Lit_1358 *jrt.String = jrt.Intern("arbace.core$int_array__inliner__1927001278")

var Lit_1359 *jrt.String = jrt.Intern("arbace.core$long_array")

var Lit_1360 *jrt.String = jrt.Intern("Creates an array of longs")

var Lit_1361 *jrt.String = jrt.Intern("arbace.core$long_array__inliner__1927001281")

var Lit_1362 *jrt.String = jrt.Intern("arbace.core$booleans")

var Lit_1363 *jrt.String = jrt.Intern("kn8,arglistsyn2,xskn3,dockn5,addedkn4,linekn6,columnkn4,fileyn1,xyn1,syn6,n-or-qkn6,statickn3,tagyn15,arbace.lang.Varyn1,fyn1,&yn4,argsyn4,varskn7,privateyn4,collyn5,Classyn5,childyn6,parentyn1,hyn3,tagkn8,declaredyn1,yyn4,moreyn18,java.sql.ResultSetyn4,iteryn1,eyn3,fmtyn16,java.lang.Stringyn4,bodyyn4,nameyn10,docstring?yn9,attr-map?yn11,references*yn7,filtersyn4,exprkn7,dynamicyn4,predyn3,libkn5,redefyn7,need-nsyn7,requireyn6,prefixyn7,optionsyn4,pathyn3,symyn5,pathsyn1,myn2,ksyn9,not-foundyn1,kyn1,vyn1,zv11,arbace.core5,bytesm12,R0,L1,V1,R1,R2,s15,Casts to byte[]R3,s3,1.1R4,i5561,R5,i1,R6,s14,arbace/core.aev11,arbace.core5,charsm12,R0,L1,V1,R1,R2,s15,Casts to char[]R3,s3,1.1R4,i5566,R5,i1,R6,s14,arbace/core.aev11,arbace.core6,shortsm12,R0,L1,V1,R1,R2,s16,Casts to short[]R3,s3,1.1R4,i5571,R5,i1,R6,s14,arbace/core.aev11,arbace.core6,floatsm12,R0,L1,V1,R1,R2,s16,Casts to float[]R3,s3,1.0R4,i5576,R5,i1,R6,s14,arbace/core.aev11,arbace.core4,intsm12,R0,L1,V1,R1,R2,s14,Casts to int[]R3,s3,1.0R4,i5581,R5,i1,R6,s14,arbace/core.aev11,arbace.core7,doublesm12,R0,L1,V1,R1,R2,s17,Casts to double[]R3,s3,1.0R4,i5586,R5,i1,R6,s14,arbace/core.aev11,arbace.core5,longsm12,R0,L1,V1,R1,R2,s15,Casts to long[]R3,s3,1.0R4,i5591,R5,i1,R6,s14,arbace/core.aev11,arbace.core6,bytes?m12,R0,L1,V1,R7,R2,s32,Return true if x is a byte arrayR3,s3,1.9R4,i5596,R5,i1,R6,s14,arbace/core.aev11,arbace.core5,sequem14,R0,L2,V1,R8,V2,R9,R8,R2,s354,Creates a queued seq on another (presumably lazy) seq s. The queued\n  seq will produce a concrete seq in the background, and can get up to\n  n items ahead of the consumer. n-or-q can be an integer n buffer\n  size, or an instance of java.util.concurrent BlockingQueue. Note\n  that reading from a seque can block if the reader gets ahead of the\n  producer.R3,s3,1.0R10,TR4,i5605,R5,i1,R6,s14,arbace/core.aev11,arbace.core6,class?m14,R0,L1,V1,R7,R2,s41,Returns true if x is an instance of ClassR3,s3,1.0R10,TR4,i5651,R5,i1,R6,s14,arbace/core.aev11,arbace.core14,alter-var-rootm14,R0,L1,V4,Myn1,vm2,R11,R12,R13,R14,R15,R2,s94,Atomically alters the root binding of var v by applying f to its\n  current value plus any argsR3,s3,1.0R10,TR4,i5657,R5,i1,R6,s14,arbace/core.aev11,arbace.core6,bound?m14,R0,L1,V2,R14,R16,R2,s193,Returns true if all of the vars provided as arguments have any bound value, root or thread-local.\n   Implies that deref'ing the provided vars will succeed. Returns true if no vars are provided.R3,s3,1.2R10,TR4,i5664,R5,i1,R6,s14,arbace/core.aev11,arbace.core13,thread-bound?m14,R0,L1,V2,R14,R16,R2,s177,Returns true if all of the vars provided as arguments have thread-local bindings.\n   Implies that set!'ing the provided vars will succeed.  Returns true if no vars are provided.R3,s3,1.2R10,TR4,i5672,R5,i1,R6,s14,arbace/core.aev11,arbace.core14,make-hierarchym14,R0,L1,V0,R2,s57,Creates a hierarchy object for use with derive, isa? etc.R3,s3,1.0R10,TR4,i5680,R5,i1,R6,s14,arbace/core.aem8,R17,TR4,i5686,R5,i1,R6,s14,arbace/core.aev11,arbace.core9,not-emptym14,R0,L1,V1,R18,R2,s40,If coll is empty, returns nil, else collR3,s3,1.0R10,TR4,i5689,R5,i1,R6,s14,arbace/core.aev11,arbace.core5,basesm14,R0,L1,V1,Myn1,cm2,R11,R19,R2,s67,Returns the immediate superclass and direct interfaces of c, if anyR3,s3,1.0R10,TR4,i5695,R5,i1,R6,s14,arbace/core.aev11,arbace.core6,supersm14,R0,L1,V1,Myn5,classm2,R11,R19,R2,s75,Returns the immediate and indirect superclasses and interfaces of c, if anyR3,s3,1.0R10,TR4,i5705,R5,i1,R6,s14,arbace/core.aev11,arbace.core4,isa?m12,R0,L2,V2,R20,R21,V3,R22,R20,R21,R2,s288,Returns true if (= child parent), or child is directly or indirectly derived from\n  parent, either via a Java type inheritance relationship or a\n  relationship established via derive. h must be a hierarchy obtained\n  from make-hierarchy, if not supplied defaults to the global\n  hierarchyR3,s3,1.0R4,i5716,R5,i1,R6,s14,arbace/core.aev11,arbace.core7,parentsm12,R0,L2,V1,R23,V2,R22,R23,R2,s234,Returns the immediate parents of tag, either via a Java type\n  inheritance relationship or a relationship established via derive. h\n  must be a hierarchy obtained from make-hierarchy, if not supplied\n  defaults to the global hierarchyR3,s3,1.0R4,i5737,R5,i1,R6,s14,arbace/core.aev11,arbace.core9,ancestorsm12,R0,L2,V1,R23,V2,R22,R23,R2,s247,Returns the immediate and indirect parents of tag, either via a Java type\n  inheritance relationship or a relationship established via derive. h\n  must be a hierarchy obtained from make-hierarchy, if not supplied\n  defaults to the global hierarchyR3,s3,1.0R4,i5750,R5,i1,R6,s14,arbace/core.aev11,arbace.core11,descendantsm12,R0,L2,V1,R23,V2,R22,R23,R2,s268,Returns the immediate and indirect children of tag, through a\n  relationship established via derive. h must be a hierarchy obtained\n  from make-hierarchy, if not supplied defaults to the global\n  hierarchy. Note: does not work on Java type inheritance\n  relationships.R3,s3,1.0R4,i5766,R5,i1,R6,s14,arbace/core.aev11,arbace.core6,derivem12,R0,L2,V2,R23,R21,V3,R22,R23,R21,R2,s319,Establishes a parent/child relationship between parent and\n  tag. Parent must be a namespace-qualified symbol or keyword and\n  child can be either a namespace-qualified symbol or keyword or a\n  class. h must be a hierarchy obtained from make-hierarchy, if not\n  supplied defaults to, and modifies, the global hierarchy.R3,s3,1.0R4,i5778,R5,i1,R6,s14,arbace/core.aev11,arbace.core7,flattenm8,R24,TR4,i5814,R5,i1,R6,s14,arbace/core.aev11,arbace.core8,underivem12,R0,L2,V2,R23,R21,V3,R22,R23,R21,R2,s180,Removes a parent/child relationship between parent and\n  tag. h must be a hierarchy obtained from make-hierarchy, if not\n  supplied defaults to, and modifies, the global hierarchy.R3,s3,1.0R4,i5816,R5,i1,R6,s14,arbace/core.aev11,arbace.core9,distinct?m16,R0,L3,V1,R7,V2,R7,R25,V4,R7,R25,R14,R26,R2,s45,Returns true if no two of the arguments are =R11,C17,java.lang.BooleanR3,s3,1.0R10,TR4,i5836,R5,i1,R6,s14,arbace/core.aev11,arbace.core13,resultset-seqm12,R0,L1,V1,Myn2,rsm2,R11,R27,R2,s106,Creates and returns a lazy sequence of structmaps corresponding to\n  the rows in the java.sql.ResultSet rsR3,s3,1.0R4,i5853,R5,i1,R6,s14,arbace/core.aev11,arbace.core12,iterator-seqm14,R0,L1,V1,R28,R2,s262,Returns a seq on a java.util.Iterator. Note that most collections\n  providing iterators implement Iterable and thus support seq directly.\n  Seqs cache values, thus iterator-seq should not be used on any\n  iterator that repeatedly returns the same mutable object.R3,s3,1.0R10,TR4,i5872,R5,i1,R6,s14,arbace/core.aev11,arbace.core15,enumeration-seqm14,R0,L1,V1,R29,R2,s40,Returns a seq on a java.util.EnumerationR3,s3,1.0R10,TR4,i5882,R5,i1,R6,s14,arbace/core.aev11,arbace.core6,formatm14,R0,L1,MV3,R30,R14,R15,m2,R11,R31,R2,s98,Formats a string using java.lang.String.format, see java.util.Formatter for format\n  string syntaxR3,s3,1.0R10,TR4,i5889,R5,i1,R6,s14,arbace/core.aev11,arbace.core6,printfm14,R0,L1,V3,R30,R14,R15,R2,s38,Prints formatted output, as per formatR3,s3,1.0R10,TR4,i5897,R5,i1,R6,s14,arbace/core.aev11,arbace.core9,gen-classm8,R24,TR4,i5904,R5,i1,R6,s14,arbace/core.aev11,arbace.core20,with-loading-contextm8,R0,L1,V2,R14,R32,R4,i5906,R5,i1,R6,s14,arbace/core.aev11,arbace.core2,nsm12,R0,ML1,V4,R33,R34,R35,R36,m4,R4,i5936,R5,i15,R2,s1070,Sets *ns* to the namespace named by name (unevaluated), creating it\n  if needed.  references can be zero or more of: (:refer-clojure ...)\n  (:require ...) (:use ...) (:import ...) (:load ...) (:gen-class)\n  with the syntax of refer-clojure/require/use/import/load/gen-class\n  respectively, except the arguments are unevaluated and need not be\n  quoted. (:gen-class ...), when supplied, defaults to :name\n  corresponding to the ns name, :main true, :impl-ns same as ns, and\n  :init-impl-ns true. All options of gen-class are\n  supported. The :gen-class directive is ignored when not\n  compiling. If :gen-class is not supplied, when compiled only an\n  nsname__init.class will be generated. If :refer-clojure is not used, a\n  default (refer 'arbace.core) is used.  Use of ns is preferred to\n  individual calls to in-ns/require/use/import:\n\n  (ns foo.bar\n    (:refer-clojure :exclude [ancestors printf])\n    (:require (clojure.contrib sql combinatorics))\n    (:use (my.lib this that))\n    (:import (java.util Date Timer Random)\n             (java.sql Connection Statement)))R3,s3,1.0R4,i5915,R5,i1,R6,s14,arbace/core.aev11,arbace.core13,refer-clojurem12,R0,L1,V2,R14,R37,R2,s38,Same as (refer 'arbace.core <filters>)R3,s3,1.0R4,i5973,R5,i1,R6,s14,arbace/core.aev11,arbace.core7,defoncem12,R0,L1,V2,R33,R38,R2,s108,defs name to have the root value of the expr iff the named var has no root value,\n  else expr is unevaluatedR3,s3,1.0R4,i5979,R5,i1,R6,s14,arbace/core.aev11,arbace.core13,*loaded-libs*m12,R17,TR2,s57,A ref to a sorted set of symbols representing loaded libsR39,TR4,i5990,R5,i1,R6,s14,arbace/core.aem12,R17,TR2,s57,A ref to a sorted set of symbols representing loaded libsR39,TR4,i5990,R5,i1,R6,s14,arbace/core.aev11,arbace.core15,*pending-paths*m12,R17,TR2,s54,A stack of paths currently being loaded by this threadR39,TR4,i5995,R5,i1,R6,s14,arbace/core.aem12,R17,TR2,s54,A stack of paths currently being loaded by this threadR39,TR4,i5995,R5,i1,R6,s14,arbace/core.aev11,arbace.core19,*loading-verbosely*m12,R17,TR2,s36,True while a verbose load is pendingR39,TR4,i6000,R5,i1,R6,s14,arbace/core.aem12,R17,TR2,s36,True while a verbose load is pendingR39,TR4,i6000,R5,i1,R6,s14,arbace/core.aev11,arbace.core8,throw-ifm12,R17,TR0,L1,V4,R40,R30,R14,R15,R2,s57,Throws a CompilerException with a message if pred is trueR4,i6005,R5,i1,R6,s14,arbace/core.aev11,arbace.core8,libspec?m12,R17,TR0,L1,V1,R7,R2,s30,Returns true if x is a libspecR4,i6021,R5,i1,R6,s14,arbace/core.aev11,arbace.core9,prependssm12,R17,TR0,L1,V2,R7,R18,R2,s34,Prepends a symbol or a seq to collR4,i6030,R5,i1,R6,s14,arbace/core.aev11,arbace.core13,root-resourcem14,R17,TR0,L1,V1,R41,R2,s41,Returns the root directory path for a libR11,C16,java.lang.StringR4,i6037,R5,i1,R6,s14,arbace/core.aev11,arbace.core14,root-directorym12,R17,TR0,L1,V1,R41,R2,s40,Returns the root resource path for a libR4,i6046,R5,i1,R6,s14,arbace/core.aev11,arbace.core4,loadm10,R42,TR24,TR4,i6052,R5,i1,R6,s14,arbace/core.aev11,arbace.core8,load-onem12,R17,TR0,L1,V3,R41,R43,R44,R2,s171,Loads a lib given its name. If need-ns, ensures that the associated\n  namespace exists after loading. If require, records the load so any\n  duplicate loads can be skipped.R4,i6054,R5,i1,R6,s14,arbace/core.aev11,arbace.core8,load-allm12,R17,TR0,L1,V3,R41,R43,R44,R2,s235,Loads a lib given its name and forces a load of any libs it directly or\n  indirectly loads. If need-ns, ensures that the associated namespace\n  exists after loading. If require, records the load so any duplicate loads\n  can be skipped.R4,i6067,R5,i1,R6,s14,arbace/core.aev11,arbace.core8,load-libm12,R17,TR0,L1,V4,R45,R41,R14,R46,R2,s24,Loads a lib with optionsR4,i6079,R5,i1,R6,s14,arbace/core.aev11,arbace.core9,load-libsm12,R17,TR0,L1,V2,R14,R15,R2,s87,Loads libs, interpreting libspecs, prefix lists, and flags for\n  forwarding to load-libR4,i6126,R5,i1,R6,s14,arbace/core.aev11,arbace.core23,check-cyclic-dependencym12,R17,TR0,L1,V1,R47,R2,s277,Detects and rejects non-trivial cyclic load dependencies. The\n  exception message shows the dependency chain with the cycle\n  highlighted. Ignores the trivial case of a file attempting to load\n  itself because that can occur when a gen-class'd class loads its\n  implementation.R4,i6149,R5,i1,R6,s14,arbace/core.aev11,arbace.core7,requirem12,R0,L1,V2,R14,R15,R2,s2979,Loads libs, skipping any that are already loaded. Each argument is\n  either a libspec that identifies a lib, a prefix list that identifies\n  multiple libs whose names share a common prefix, or a flag that modifies\n  how all the identified libs are loaded. Use :require in the ns macro\n  in preference to calling this directly.\n\n  Libs\n\n  A 'lib' is a named set of resources in classpath whose contents define a\n  library of Clojure code. Lib names are symbols and each lib is associated\n  with a Clojure namespace and a Java package that share its name. A lib's\n  name also locates its root directory within classpath using Java's\n  package name to classpath-relative path mapping. All resources in a lib\n  should be contained in the directory structure under its root directory.\n  All definitions a lib makes should be in its associated namespace.\n\n  'require loads a lib by loading its root resource. The root resource path\n  is derived from the lib name in the following manner:\n  Consider a lib named by the symbol 'x.y.z; it has the root directory\n  <classpath>/x/y/, and its root resource is <classpath>/x/y/z.ae, or\n  <classpath>/x/y/z.clj if <classpath>/x/y/z.ae does not exist, or\n  <classpath>/x/y/z.cljc if neither exists. The\n  root resource should contain code to create the lib's\n  namespace (usually by using the ns macro) and load any additional\n  lib resources.\n\n  Libspecs\n\n  A libspec is a lib name or a vector containing a lib name followed by\n  options expressed as sequential keywords and arguments.\n\n  Recognized options:\n  :as takes a symbol as its argument and makes that symbol an alias to the\n    lib's namespace in the current namespace.\n  :as-alias takes a symbol as its argument and aliases like :as, however\n    the lib will not be loaded. If the lib has not been loaded, a new\n    empty namespace will be created (as with create-ns).\n  :refer takes a list of symbols to refer from the namespace or the :all\n    keyword to bring in all public vars.\n\n  Prefix Lists\n\n  It's common for Clojure code to depend on several libs whose names have\n  the same prefix. When specifying libs, prefix lists can be used to reduce\n  repetition. A prefix list contains the shared prefix followed by libspecs\n  with the shared prefix removed from the lib names. After removing the\n  prefix, the names that remain must not contain any periods.\n\n  Flags\n\n  A flag is a keyword.\n  Recognized flags: :reload, :reload-all, :verbose\n  :reload forces loading of all the identified libs even if they are\n    already loaded (has no effect on libspecs using :as-alias)\n  :reload-all implies :reload and also forces loading of all libs that the\n    identified libs directly or indirectly load via require or use\n    (has no effect on libspecs using :as-alias)\n  :verbose triggers printing information about each load, alias, and refer\n\n  Example:\n\n  The following would load the libraries arbace.zip and arbace.set\n  abbreviated as 's'.\n\n  (require '(clojure zip [set :as s]))R3,s3,1.0R4,i6164,R5,i1,R6,s14,arbace/core.aev11,arbace.core18,serialized-requirem14,R17,TR0,L1,V2,R14,R15,R2,s157,Like 'require', but serializes loading.\n  Interim function preferred over 'require' for known asynchronous loads.\n  Future changes may make these equivalent.R3,s4,1.10R4,i6235,R5,i1,R6,s14,arbace/core.aev11,arbace.core17,requiring-resolvem12,R0,L1,V1,R48,R2,s122,Resolves namespace-qualified sym per 'resolve'. If initial resolve\nfails, attempts to require sym's namespace and retries.R3,s4,1.10R4,i6244,R5,i1,R6,s14,arbace/core.aev11,arbace.core3,usem12,R0,L1,V2,R14,R15,R2,s343,Like 'require, but also refers to each lib's namespace using\n  arbace.core/refer. Use :use in the ns macro in preference to calling\n  this directly.\n\n  'use accepts additional options in libspecs: :exclude, :only, :rename.\n  The arguments and semantics for :exclude, :only, and :rename are the same\n  as those documented for arbace.core/refer.R3,s3,1.0R4,i6255,R5,i1,R6,s14,arbace/core.aev11,arbace.core11,loaded-libsm12,R0,L1,V0,R2,s64,Returns a sorted set of symbols naming the currently loaded libsR3,s3,1.0R4,i6266,R5,i1,R6,s14,arbace/core.aem14,R0,L1,V2,R14,R49,R2,s192,Loads Clojure code from resources in classpath. A path is interpreted as\n  classpath-relative if it begins with a slash or relative to the root\n  directory for the current namespace otherwise.R42,TR3,s3,1.0R4,i6271,R5,i1,R6,s14,arbace/core.aev11,arbace.core7,compilem12,R0,L1,V1,R41,R2,s196,Loads the namespace named by the symbol lib with *compile-files*\n  bound to true. Clojure compiles it into a set of classfiles in\n  *compile-path*; Arbace has no bytecode back end and writes none.R3,s3,1.0R4,i6296,R5,i1,R6,s14,arbace/core.aev11,arbace.core6,get-inm14,R0,L2,V2,R50,R51,V3,R50,R51,R52,R2,s163,Returns the value in a nested associative structure,\n  where ks is a sequence of keys. Returns nil if the key\n  is not present, or the not-found value if supplied.R3,s3,1.2R10,TR4,i6308,R5,i1,R6,s14,arbace/core.aev11,arbace.core8,assoc-inm14,R0,L1,V3,R50,V3,R53,R14,R51,R54,R2,s202,Associates a value in a nested associative structure, where ks is a\n  sequence of keys and v is the new value and returns a new nested structure.\n  If any levels do not exist, hash-maps will be created.R3,s3,1.0R10,TR4,i6327,R5,i1,R6,s14,arbace/core.aev11,arbace.core9,update-inm14,R0,L1,V5,R50,R51,R13,R14,R15,R2,s280,'Updates' a value in a nested associative structure, where ks is a\n  sequence of keys and f is a function that will take the old value\n  and any supplied args and return the new value, and returns a new\n  nested structure.  If any levels do not exist, hash-maps will be\n  created.R3,s3,1.0R10,TR4,i6338,R5,i1,R6,s14,arbace/core.aev11,arbace.core6,updatem14,R0,L5,V3,R50,R53,R13,V4,R50,R53,R13,R7,V5,R50,R53,R13,R7,R25,V6,R50,R53,R13,R7,R25,R55,V8,R50,R53,R13,R7,R25,R55,R14,R26,R2,s255,'Updates' a value in an associative structure, where k is a\n  key and f is a function that will take the old value\n  and any supplied args and return the new value, and returns a new\n  structure.  If the key does not exist, nil is passed as the old value.R3,s3,1.7R10,TR4,i6354,R5,i1,R6,s14,arbace/core.aev11,arbace.core5,coll?m14,R0,L1,V1,R7,R2,s50,Returns true if x implements IPersistentCollectionR3,s3,1.0R10,TR4,i6372,R5,i1,R6,s14,arbace/core.aev11,arbace.core5,list?m14,R0,L1,V1,R7,R2,s44,Returns true if x implements IPersistentListR3,s3,1.0R10,TR4,i6378,R5,i1,R6,s14,arbace/core.aev11,arbace.core8,seqable?m12,R0,L1,V1,R7,R2,s50,Return true if the seq function is supported for xR3,s3,1.9R4,i6384,R5,i1,R6,s14,arbace/core.aev11,arbace.core4,ifn?m14,R0,L1,V1,R7,R2,s101,Returns true if x implements IFn. Note that many data structures\n  (e.g. sets and maps) implement IFnR3,s3,1.0R10,TR4,i6389,R5,i1,R6,s14,arbace/core.aev11,arbace.core3,fn?m14,R0,L1,V1,R7,R2,s66,Returns true if x implements Fn, i.e. is an object created via fn.R3,s3,1.0R10,TR4,i6396,R5,i1,R6,s14,arbace/core.aev11,arbace.core12,associative?m14,R0,L1,V1,R18,R2,s43,Returns true if coll implements AssociativeR3,s3,1.0R10,TR4,i6402,R5,i1,R6,s14,arbace/core.aev11,arbace.core11,sequential?m14,R0,L1,V1,R18,R2,s42,Returns true if coll implements SequentialR3,s3,1.0R10,TR4,i6408,R5,i1,R6,s14,arbace/core.aev11,arbace.core7,sorted?m14,R0,L1,V1,R18,R2,s38,Returns true if coll implements SortedR3,s3,1.0R10,TR4,i6414,R5,i1,R6,s14,arbace/core.aev11,arbace.core11,reversible?m14,R0,L1,V1,R18,R2,s42,Returns true if coll implements ReversibleR3,s3,1.0R10,TR4,i6420,R5,i1,R6,s14,arbace/core.aev11,arbace.core8,indexed?m12,R0,L1,V1,R18,R2,s76,Return true if coll implements Indexed, indicating efficient lookup by indexR3,s3,1.9R4,i6426,R5,i1,R6,s14,arbace/core.aev11,arbace.core2,*1m12,R2,s55,bound in a repl thread to the most recent value printedR3,s3,1.0R39,TR4,i6431,R5,i1,R6,s14,arbace/core.aev11,arbace.core2,*2m12,R2,s62,bound in a repl thread to the second most recent value printedR3,s3,1.0R39,TR4,i6436,R5,i1,R6,s14,arbace/core.aev11,arbace.core2,*3m12,R2,s61,bound in a repl thread to the third most recent value printedR3,s3,1.0R39,TR4,i6441,R5,i1,R6,s14,arbace/core.ae")

var Lit_1364 *jrt.String = jrt.Intern("arbace.core$eval1927001289$booleans__1927001290")

var Lit_1365 *jrt.String = jrt.Intern("arbace.core$bytes")

var Lit_1366 *jrt.String = jrt.Intern("arbace.core$eval1927001300$bytes__1927001301")

var Lit_1367 *jrt.String = jrt.Intern("arbace.core$chars")

var Lit_1368 *jrt.String = jrt.Intern("arbace.core$eval1927001311$chars__1927001312")

var Lit_1369 *jrt.String = jrt.Intern("arbace.core$shorts")

var Lit_1370 *jrt.String = jrt.Intern("arbace.core$eval1927001322$shorts__1927001323")

var Lit_1371 *jrt.String = jrt.Intern("arbace.core$floats")

var Lit_1372 *jrt.String = jrt.Intern("arbace.core$eval1927001333$floats__1927001334")

var Lit_1373 *jrt.String = jrt.Intern("arbace.core$ints")

var Lit_1374 *jrt.String = jrt.Intern("arbace.core$eval1927001344$ints__1927001345")

var Lit_1375 *jrt.String = jrt.Intern("arbace.core$doubles")

var Lit_1376 *jrt.String = jrt.Intern("arbace.core$eval1927001355$doubles__1927001356")

var Lit_1377 *jrt.String = jrt.Intern("arbace.core$longs")

var Lit_1378 *jrt.String = jrt.Intern("arbace.core$eval1927001366$longs__1927001367")

var Lit_1379 *jrt.String = jrt.Intern("arbace.core$bytes_QMARK_")

var Lit_1380 *jrt.String = jrt.Intern("java.util.concurrent.BlockingQueue")

var Lit_1381 *jrt.String = jrt.Intern("java.util.concurrent.LinkedBlockingQueue")

var Lit_1382 *jrt.String = jrt.Intern("arbace.core$seque")

var Lit_1383 *jrt.String = jrt.Intern("arbace.core$class_QMARK_")

var Lit_1384 *jrt.String = jrt.Intern("arbace.core$alter_var_root")

var Lit_1385 *jrt.String = jrt.Intern("arbace.core$bound_QMARK_")

var Lit_1386 *jrt.String = jrt.Intern("arbace.core$thread_bound_QMARK_")

var Lit_1387 *jrt.String = jrt.Intern("arbace.core$make_hierarchy")

var Lit_1388 *jrt.String = jrt.Intern("arbace.core$not_empty")

var Lit_1389 *jrt.String = jrt.Intern("arbace.core$bases")

var Lit_1390 *jrt.String = jrt.Intern("arbace.core$supers")

var Lit_1391 *jrt.String = jrt.Intern("arbace.core$isa_QMARK_")

var Lit_1392 *jrt.String = jrt.Intern("arbace.core$parents")

var Lit_1393 *jrt.String = jrt.Intern("arbace.core$ancestors")

var Lit_1394 *jrt.String = jrt.Intern("arbace.core$descendants")

var Lit_1395 *jrt.String = jrt.Intern("arbace.core$derive")

var Lit_1396 *jrt.String = jrt.Intern("arbace.core$underive")

var Lit_1397 *jrt.String = jrt.Intern("arbace.core$distinct_QMARK_")

var Lit_1398 *jrt.String = jrt.Intern("arbace.core$resultset_seq")

var Lit_1399 *jrt.String = jrt.Intern("arbace.core$iterator_seq")

var Lit_1400 *jrt.String = jrt.Intern("arbace.core$enumeration_seq")

var Lit_1401 *jrt.String = jrt.Intern("arbace.core$format")

var Lit_1402 *jrt.String = jrt.Intern("arbace.core$printf")

var Lit_1403 *jrt.String = jrt.Intern("arbace.core$with_loading_context")

var Lit_1404 *jrt.String = jrt.Intern("arbace.core$ns")

var Lit_1405 *jrt.String = jrt.Intern("arbace.core$refer_clojure")

var Lit_1406 *jrt.String = jrt.Intern("arbace.core$defonce")

var Lit_1407 *jrt.String = jrt.Intern("arbace.core$throw_if")

var Lit_1408 *jrt.String = jrt.Intern("arbace.core$libspec_QMARK_")

var Lit_1409 *jrt.String = jrt.Intern("arbace.core$prependss")

var Lit_1410 *jrt.String = jrt.Intern("arbace.core$root_resource")

var Lit_1411 *jrt.String = jrt.Intern("arbace.core$root_directory")

var Lit_1412 *jrt.String = jrt.Intern("arbace.core$load_one")

var Lit_1413 *jrt.String = jrt.Intern("arbace.core$load_all")

var Lit_1414 *jrt.String = jrt.Intern("arbace.core$load_lib")

var Lit_1415 *jrt.String = jrt.Intern("arbace.core$load_libs")

var Lit_1416 *jrt.String = jrt.Intern("arbace.core$check_cyclic_dependency")

var Lit_1417 *jrt.String = jrt.Intern("arbace.core$require")

var Lit_1418 *jrt.String = jrt.Intern("arbace.core$serialized_require")

var Lit_1419 *jrt.String = jrt.Intern("arbace.core$requiring_resolve")

var Lit_1420 *jrt.String = jrt.Intern("arbace.core$use")

var Lit_1421 *jrt.String = jrt.Intern("arbace.core$loaded_libs")

var Lit_1422 *jrt.String = jrt.Intern("arbace.core$load")

var Lit_1423 *jrt.String = jrt.Intern("arbace.core$compile")

var Lit_1424 *jrt.String = jrt.Intern("arbace.core$get_in")

var Lit_1425 *jrt.String = jrt.Intern("arbace.core$assoc_in")

var Lit_1426 *jrt.String = jrt.Intern("arbace.core$update_in")

var Lit_1427 *jrt.String = jrt.Intern("arbace.core$update")

var Lit_1428 *jrt.String = jrt.Intern("arbace.core$coll_QMARK_")

var Lit_1429 *jrt.String = jrt.Intern("arbace.core$list_QMARK_")

var Lit_1430 *jrt.String = jrt.Intern("arbace.core$seqable_QMARK_")

var Lit_1431 *jrt.String = jrt.Intern("arbace.core$ifn_QMARK_")

var Lit_1432 *jrt.String = jrt.Intern("arbace.core$fn_QMARK_")

var Lit_1433 *jrt.String = jrt.Intern("arbace.core$associative_QMARK_")

var Lit_1434 *jrt.String = jrt.Intern("arbace.core$sequential_QMARK_")

var Lit_1435 *jrt.String = jrt.Intern("arbace.core$sorted_QMARK_")

var Lit_1436 *jrt.String = jrt.Intern("arbace.core$reversible_QMARK_")

var Lit_1437 *jrt.String = jrt.Intern("arbace.core$indexed_QMARK_")

var Lit_1438 *jrt.String = jrt.Intern("kn3,dockn5,addedkn7,dynamickn4,linekn6,columnkn4,filekn8,arglistsyn1,fyn1,&yn4,argskn6,staticyn2,nskn3,tagyn18,arbace.lang.Symbolyn4,nameyn3,valyn4,testyn4,bodyyn4,predyn4,expryn7,clausesyn9,docstringyn4,metakn7,privateyn1,xyn27,java.util.concurrent.Futureyn7,fnspecskn5,formsyn5,letfnyn8,fnspecs*yn6,exprs*kn12,special-formkn3,urlyn1,yyn1,zyn5,shiftyn4,maskyn6,hashesyn6,case-fyn6,test-fyn5,testsyn5,thensyn4,intsyn8,expr-symyn7,defaultyn1,eyn11,arbace.coreyn27,java.util.stream.BaseStreamyn4,inityn5,xformyn2,toyn10,class-nameyn4,instkn2,onyn16,arbace.core.Instkn12,on-interfacekn4,sigskn8,inst-ms*kn4,namekn3,varkn10,method-mapkn15,method-builderskn8,protocolyn4,Instyn14,java.util.UUIDyn4,collkn9,kv-reduceyn2,cfyn4,fromyn2,c1yn2,c2yn2,c3yn5,collsyn3,mapyn6,keyseqyn4,mapsyn14,arbace.java.iokn2,asyn3,jioyn4,optsv11,arbace.core2,*em12,R0,s70,bound in a repl thread to the most recent exception caught by the replR1,s3,1.0R2,TR3,i6446,R4,i1,R5,s14,arbace/core.aev11,arbace.core6,*repl*m12,R0,s30,Bound to true in a repl threadR1,s4,1.12R2,TR3,i6451,R4,i1,R5,s14,arbace/core.aev11,arbace.core10,trampolinem14,R6,L2,V1,R7,V3,R7,R8,R9,R0,s426,trampoline can be used to convert algorithms requiring mutual\n  recursion without stack consumption. Calls f with supplied args, if\n  any. If f returns a fn, calls that fn with no arguments, and\n  continues to repeat, until the return value is not a fn, then\n  returns that non-fn value. Note that if you want to return a fn as a\n  final value, you must wrap it in some data structure and unpack it\n  after trampoline returns.R1,s3,1.0R10,TR3,i6456,R4,i1,R5,s14,arbace/core.aev11,arbace.core6,internm14,R6,L2,V2,R11,Myn4,namem2,R12,R13,V3,R11,R14,R15,R0,s256,Finds or creates a var named by the symbol name in the namespace\n  ns (which can be a symbol or a namespace), setting its root binding\n  to val if supplied. The namespace must exist. The var will adopt any\n  metadata from the name symbol.  Returns the var.R1,s3,1.0R10,TR3,i6474,R4,i1,R5,s14,arbace/core.aev11,arbace.core5,whilem12,R6,L1,V3,R16,R8,R17,R0,s132,Repeatedly executes body while test expression is true. Presumes\n  some side-effect will cause test to become false/nil. Returns nilR1,s3,1.0R3,i6490,R4,i1,R5,s14,arbace/core.aev11,arbace.core7,memoizem14,R6,L1,V1,R7,R0,s285,Returns a memoized version of a referentially transparent function. The\n  memoized version of the function keeps a cache of the mapping from arguments\n  to results and, when calls with the same arguments are repeated often, has\n  higher performance at the expense of higher memory use.R1,s3,1.0R10,TR3,i6500,R4,i1,R5,s14,arbace/core.aev11,arbace.core5,condpm12,R6,L1,V4,R18,R19,R8,R20,R0,s770,Takes a binary predicate, an expression, and a set of clauses.\n  Each clause can take the form of either:\n\n  test-expr result-expr\n\n  test-expr :>> result-fn\n\n  Note :>> is an ordinary keyword.\n\n  For each clause, (pred test-expr expr) is evaluated. If it returns\n  logical true, the clause is a match. If a binary clause matches, the\n  result-expr is returned, if a ternary clause matches, its result-fn,\n  which must be a unary function, is called with the result of the\n  predicate as its argument, the result of that call being the return\n  value of condp. A single default expression can follow the clauses,\n  and its value will be returned if no clause matches. If no default\n  expression is provided and no clause matches, an\n  IllegalArgumentException is thrown.R1,s3,1.0R3,i6516,R4,i1,R5,s14,arbace/core.aev11,arbace.core7,*agent*v11,arbace.core5,in-nsv11,arbace.core9,load-filev11,arbace.core16,add-doc-and-metam10,R6,L1,V3,R14,R21,R22,R23,TR3,i6563,R4,i1,R5,s14,arbace/core.aev11,arbace.core6,*file*m2,R1,s3,1.0v11,arbace.core19,*command-line-args*m2,R1,s3,1.0v11,arbace.core20,*warn-on-reflection*m2,R1,s3,1.0v11,arbace.core14,*compile-path*m2,R1,s3,1.0v11,arbace.core15,*compile-files*m2,R1,s3,1.0v11,arbace.core16,*unchecked-math*m2,R1,s3,1.3v11,arbace.core18,*compiler-options*m2,R1,s3,1.4v11,arbace.core4,*ns*m2,R1,s3,1.0v11,arbace.core4,*in*m2,R1,s3,1.0v11,arbace.core5,*out*m2,R1,s3,1.0v11,arbace.core5,*err*m2,R1,s3,1.0v11,arbace.core18,*flush-on-newline*m2,R1,s3,1.0v11,arbace.core12,*print-meta*m2,R1,s3,1.0v11,arbace.core11,*print-dup*m2,R1,s3,1.0v11,arbace.core16,*print-readably*m2,R1,s3,1.0v11,arbace.core11,*read-eval*m2,R1,s3,1.0v11,arbace.core8,*assert*m2,R1,s3,1.0v11,arbace.core7,future?m14,R6,L1,V1,R24,R0,s29,Returns true if x is a futureR1,s3,1.1R10,TR3,i6695,R4,i1,R5,s14,arbace/core.aev11,arbace.core12,future-done?m14,R6,L1,V1,Myn1,fm2,R12,R25,R0,s32,Returns true if future f is doneR1,s3,1.1R10,TR3,i6701,R4,i1,R5,s14,arbace/core.aev11,arbace.core5,letfnm18,R6,L1,V3,R26,R8,R17,R0,s273,fnspec ==> (fname [params*] exprs) or (fname ([params*] exprs)+)\n\n  Takes a vector of function specs and a body, and generates a set of\n  bindings of functions to their names. All of the names are available\n  in all of the definitions of the functions, as well as the body.R1,s3,1.0R27,V1,ML3,R28,V1,R29,R30,m4,R3,i6713,R4,i27,R31,TR32,nR3,i6707,R4,i1,R5,s14,arbace/core.aev11,arbace.core4,fnilm14,R6,L3,V2,R7,R24,V3,R7,R24,R33,V4,R7,R24,R33,R34,R0,s311,Takes a function f, and returns a function that calls f, replacing\n  a nil first argument to f with the supplied value x. Higher arity\n  versions can replace arguments in the second and third\n  positions (y, z). Note that the function f can take any number of\n  arguments, not just the one(s) being nil-patched.R1,s3,1.2R10,TR3,i6720,R4,i1,R5,s14,arbace/core.aev11,arbace.core10,shift-maskm10,R23,TR6,L1,V3,R35,R36,R24,R3,i6746,R4,i1,R5,s14,arbace/core.aev11,arbace.core13,max-mask-bitsl13,m8,R23,TR3,i6749,R4,i1,R5,s14,arbace/core.aev11,arbace.core21,max-switch-table-sizem8,R23,TR3,i6750,R4,i1,R5,s14,arbace/core.aev11,arbace.core14,maybe-min-hashm12,R23,TR6,L1,V1,R37,R0,s74,takes a collection of hashes and returns [shift mask] or nil if none foundR3,i6752,R4,i1,R5,s14,arbace/core.aev11,arbace.core8,case-mapm12,R23,TR6,L1,V4,R38,R39,R40,R41,R0,s205,Transforms a sequence of test constants and a corresponding sequence of then\n  expressions into a sorted map to be consumed by case*. The form of the map\n  entries are {(case-f test) [(test-f test) then]}.R3,i6762,R4,i1,R5,s14,arbace/core.aev11,arbace.core11,fits-table?m12,R23,TR6,L1,V1,R42,R0,s99,Returns true if the collection of ints can fit within the\n  max-table-switch-size, false otherwise.R3,i6773,R4,i1,R5,s14,arbace/core.aev11,arbace.core9,prep-intsm12,R23,TR6,L1,V2,R40,R41,R0,s266,Takes a sequence of int-sized test constants and a corresponding sequence of\n  then expressions. Returns a tuple of [shift mask case-map switch-type] where\n  case-map is a map of int case values to [test then] tuples, and switch-type\n  is either :sparse or :compact.R3,i6779,R4,i1,R5,s14,arbace/core.aev11,arbace.core21,merge-hash-collisionsm12,R23,TR6,L1,V4,R43,R44,R40,R41,R0,s590,Takes a case expression, default expression, and a sequence of test constants\n  and a corresponding sequence of then expressions. Returns a tuple of\n  [tests thens skip-check-set] where no tests have the same hash. Each set of\n  input test constants with the same hash is replaced with a single test\n  constant (the case int), and their respective thens are combined into:\n  (condp = expr\n    test-1 then-1\n    ...\n    test-n then-n\n    default).\n  The skip-check is a set of case ints for which post-switch equivalence\n  checking must not be done (the cases holding the above condp thens).R3,i6795,R4,i1,R5,s14,arbace/core.aev11,arbace.core11,prep-hashesm12,R23,TR6,L1,V4,R43,R44,R40,R41,R0,s395,Takes a sequence of test constants and a corresponding sequence of then\n  expressions. Returns a tuple of [shift mask case-map switch-type skip-check]\n  where case-map is a map of int case values to [test then] tuples, switch-type\n  is either :sparse or :compact, and skip-check is a set of case ints for which\n  post-switch equivalence checking must not be done (occurs with hash\n  collisions).R3,i6831,R4,i1,R5,s14,arbace/core.aev11,arbace.core4,casem12,R6,L1,V3,R45,R8,R20,R0,s1026,Takes an expression, and a set of clauses.\n\n  Each clause can take the form of either:\n\n  test-constant result-expr\n\n  (test-constant1 ... test-constantN)  result-expr\n\n  The test-constants are not evaluated. They must be compile-time\n  literals, and need not be quoted.  If the expression is equal to a\n  test-constant, the corresponding result-expr is returned. A single\n  default expression can follow the clauses, and its value will be\n  returned if no clause matches. If no default expression is provided\n  and no clause matches, an IllegalArgumentException is thrown.\n\n  Unlike cond and condp, case does a constant-time dispatch, the\n  clauses are not considered sequentially.  All manner of constant\n  expressions are acceptable in case, including numbers, strings,\n  symbols, keywords, and (Clojure) composites thereof. Note that since\n  lists are used to group multiple constants that map to the same\n  expression, a vector can be used to match a list if needed. The\n  test-constants need not be all of the same type.R1,s3,1.2R3,i6859,R4,i1,R5,s14,arbace/core.aeR46,v11,arbace.core14,stream-reduce!m12,R6,L2,V2,R7,Myn1,sm2,R12,R47,V3,R7,R48,Myn1,sm2,R12,R47,R0,s130,Works like reduce but takes a java.util.stream.BaseStream as its source.\n  Honors 'reduced', is a terminal operation on the streamR1,s4,1.12R3,i6932,R4,i1,R5,s14,arbace/core.aev11,arbace.core11,stream-seq!m12,R6,L1,V1,Myn6,streamm2,R12,R47,R0,s127,Takes a java.util.stream.BaseStream instance s and returns a seq of its\n  contents. This is a terminal operation on the stream.R1,s4,1.12R3,i6941,R4,i1,R5,s14,arbace/core.aev11,arbace.core17,stream-transduce!m12,R6,L2,V3,R49,R7,Myn6,streamm2,R12,R47,V4,R49,R7,R48,Myn6,streamm2,R12,R47,R0,s121,Works like transduce but takes a java.util.stream.BaseStream as its source.\n  This is a terminal operation on the stream.R1,s4,1.12R3,i6948,R4,i1,R5,s14,arbace/core.aev11,arbace.core12,stream-into!m12,R6,L2,V2,R50,Myn6,streamm2,R12,R47,V3,R50,R49,Myn6,streamm2,R12,R47,R0,s130,Returns a new coll consisting of coll with all of the items of the\n  stream conjoined. This is a terminal operation on the stream.R1,s4,1.12R3,i6958,R4,i1,R5,s14,arbace/core.aev11,arbace.core10,when-classm10,R23,TR6,L1,V3,R51,R8,R17,R3,i6971,R4,i1,R5,s14,arbace/core.aev11,arbace.core4,Instm6,R3,i6981,R4,i1,R5,s14,arbace/core.aem6,R3,i6981,R4,i1,R5,s14,arbace/core.aeC16,arbace.core.Instv11,arbace.core20,assert-same-protocolL1,Myn8,inst-ms*m4,R0,nR6,L1,V1,R52,m4,R53,R54,R55,C16,arbace.core.InstR56,m2,R57,m8,R12,nR58,Myn8,inst-ms*m4,R0,nR6,L1,V1,R52,R6,L1,V1,R52,R0,nR59,R60,m2,R57,R57,R61,Myn8,inst-ms*m4,R0,nR6,L1,V1,R52,m8,R12,nR58,Myn8,inst-ms*m4,R0,nR6,L1,V1,R52,R6,L1,V1,R52,R0,nR62,v11,arbace.core14,-reset-methodsR63,v11,arbace.core6,extendC14,java.util.DateR57,v11,arbace.core7,inst-msm12,R6,L1,V1,R52,R0,s69,Return the number of milliseconds since January 1, 1970, 00:00:00 GMTR1,s3,1.9R3,i6988,R4,i1,R5,s14,arbace/core.aev11,arbace.core5,inst?m12,R6,L1,V1,R24,R0,s31,Return true if x satisfies InstR1,s3,1.9R3,i6994,R4,i1,R5,s14,arbace/core.aeC17,java.time.Instantv11,arbace.core5,uuid?m12,R6,L1,V1,R24,R0,s36,Return true if x is a java.util.UUIDR1,s3,1.9R3,i7006,R4,i1,R5,s14,arbace/core.aev11,arbace.core11,random-uuidm12,R6,L1,MV0,m2,R12,R64,R0,s157,Returns a pseudo-randomly generated java.util.UUID instance (i.e. type 4).\n\n  See: https://docs.oracle.com/javase/8/docs/api/java/util/UUID.html#randomUUID--R1,s4,1.11R3,i7011,R4,i1,R5,s14,arbace/core.aev11,arbace.core6,reducem12,R6,L2,V2,R7,R65,V3,R7,R15,R65,R0,s585,f should be a function of 2 arguments. If val is not supplied,\n  returns the result of applying f to the first 2 items in coll, then\n  applying f to that result and the 3rd item, etc. If coll contains no\n  items, f must accept no arguments as well, and reduce returns the\n  result of calling f with no arguments.  If coll has only 1 item, it\n  is returned and f is not called.  If val is supplied, returns the\n  result of applying f to val and the first item in coll, then\n  applying f to that result and the 2nd item, etc. If coll contains no\n  items, returns val and f is not called.R1,s3,1.0R3,i7019,R4,i1,R5,s14,arbace/core.aev21,arbace.core.protocols9,IKVReduceR66,C16,java.lang.ObjectC21,arbace.lang.IKVReducem12,R6,L1,V3,R7,R48,R65,R0,s376,Reduces an associative collection. f should be a function of 3\n  arguments. Returns the result of applying f to init, the first key\n  and the first value in coll, then applying f to that result and the\n  2nd key and value, etc. If coll contains no entries, returns init\n  and f is not called. Note that reduce-kv is supported on vectors,\n  where the keys will be the ordinals.R1,s3,1.4R3,i7063,R4,i1,R5,s14,arbace/core.aev11,arbace.core10,completingm12,R6,L2,V1,R7,V2,R7,R67,R0,s171,Takes a reducing function f of 2 args and returns a fn suitable for\n  transduce by adding an arity-1 signature that calls cf (default -\n  identity) on the result argument.R1,s3,1.7R3,i7076,R4,i1,R5,s14,arbace/core.aev11,arbace.core9,transducem12,R6,L2,V3,R49,R7,R65,V4,R49,R7,R48,R65,R0,s509,reduce with a transformation of f (xf). If init is not\n  supplied, (f) will be called to produce it. f should be a reducing\n  step function that accepts both 1 and 2 arguments, if it accepts\n  only 2 you can add the arity-1 with 'completing'. Returns the result\n  of applying (the transformed) xf to init and the first item in coll,\n  then applying xf to that result and the 2nd item, etc. If coll\n  contains no items, returns init and f is not called. Note that\n  certain transforms may inject or skip items.R1,s3,1.7R3,i7088,R4,i1,R5,s14,arbace/core.aev11,arbace.core4,intom14,R6,L4,V0,V1,R50,V2,R50,R68,V3,R50,R49,R68,R0,s149,Returns a new coll consisting of to with all of the items of\n  from conjoined. A transducer may be supplied.\n  (into x) returns x. (into) returns [].R1,s3,1.0R10,TR3,i7105,R4,i1,R5,s14,arbace/core.aev11,arbace.core4,mapvm14,R6,L4,V2,R7,R65,V3,R7,R69,R70,V4,R7,R69,R70,R71,V6,R7,R69,R70,R71,R8,R72,R0,s309,Returns a vector consisting of the result of applying f to the\n  set of first items of each coll, followed by applying f to the set\n  of second items in each coll, until any one of the colls is\n  exhausted.  Any remaining items in other colls are ignored. Function\n  f should accept number-of-colls arguments.R1,s3,1.4R10,TR3,i7133,R4,i1,R5,s14,arbace/core.aev11,arbace.core7,filtervm14,R6,L1,V2,R18,R65,R0,s118,Returns a vector of the items in coll for which\n  (pred item) returns logical true. pred must be free of side-effects.R1,s3,1.4R10,TR3,i7151,R4,i1,R5,s14,arbace/core.aem12,R6,ML1,V2,R73,R74,m4,R3,i7163,R4,i15,R0,s73,Returns a map containing only those entries in map whose key is in keyseqR1,s3,1.0R3,i7162,R4,i1,R5,s14,arbace/core.aev11,arbace.core10,merge-deepm12,R6,L1,V2,R8,R75,R0,s235,Returns a map that consists of the rest of the maps conj-ed onto\n  the first. For each pairwise merge, when a key occurs in both maps,\n  if both values are maps, then recursively merge-deep, else use the\n  latter (left-to-right) value.R1,s4,1.13R3,i7178,R4,i1,R5,s14,arbace/core.aev11,arbace.core15,merge-deep-withm12,R6,L1,V3,R7,R8,R75,R0,s252,Returns a map that consists of the rest of the maps conj-ed onto\n  the first. For each pairwise merge, when a key occurs in both maps,\n  if both values are maps, then recursively merge-deep-with, else use\n  the result of (f val-in-prior val-in-latter).R1,s4,1.13R3,i7192,R4,i1,R5,s14,arbace/core.aeV3,R76,R77,R78,v11,arbace.core20,normalize-slurp-optsm10,R23,TR6,L1,V1,R79,R3,i7208,R4,i1,R5,s14,arbace/core.aev11,arbace.core5,slurpm14,R6,L1,V3,R7,R8,R79,R0,s139,Opens a reader on f and reads all its contents, returning a string.\n  See arbace.java.io/reader for a complete list of supported arguments.R1,s3,1.0R12,C16,java.lang.StringR3,i7216,R4,i1,R5,s14,arbace/core.ae")

var Lit_1439 *jrt.String = jrt.Intern("arbace.core$trampoline")

var Lit_1440 *jrt.String = jrt.Intern("arbace.core$intern")

var Lit_1441 *jrt.String = jrt.Intern("arbace.core$while")

var Lit_1442 *jrt.String = jrt.Intern("arbace.core$memoize")

var Lit_1443 *jrt.String = jrt.Intern("arbace.core$condp")

var Lit_1444 *jrt.String = jrt.Intern("arbace.core$add_doc_and_meta")

var Lit_1445 *jrt.String = jrt.Intern("The path of the file being evaluated, as a String.\n\n  When there is no file, e.g. in the REPL, the value is not defined.")

var Lit_1446 *jrt.String = jrt.Intern("A sequence of the supplied command line arguments, or nil if\n  none were supplied")

var Lit_1447 *jrt.String = jrt.Intern("When set to true, the compiler will emit warnings when reflection is\n  needed to resolve Java method calls or field accesses.\n\n  Defaults to false.")

var Lit_1448 *jrt.String = jrt.Intern("Specifies the directory where 'compile' will write out .class\n  files. This directory must be in the classpath for 'compile' to\n  work.\n\n  Defaults to \"classes\"")

var Lit_1449 *jrt.String = jrt.Intern("Set to true when compiling files, false otherwise.")

var Lit_1450 *jrt.String = jrt.Intern("While bound to true, compilations of +, -, *, inc, dec and the\n  coercions will be done without overflow checks. While bound\n  to :warn-on-boxed, same behavior as true, and a warning is emitted\n  when compilation uses boxed math. Default: false.")

var Lit_1451 *jrt.String = jrt.Intern("A map of keys to options.\n  Note, when binding dynamically make sure to merge with previous value.\n  Supported options:\n  :elide-meta - a collection of metadata keys to elide during compilation.\n  :disable-locals-clearing - set to true to disable clearing, useful for using a debugger\n  :direct-linking - set to true to use direct static invocation of functions, rather than vars\n    Note that call sites compiled with direct linking will not be affected by var redefinition.\n    Use ^:redef (or ^:dynamic) on a var to prevent direct linking and allow redefinition.\n  See https://clojure.org/reference/compilation for more information.")

var Lit_1452 *jrt.String = jrt.Intern("A arbace.lang.Namespace object representing the current namespace.")

var Lit_1453 *jrt.String = jrt.Intern("A java.io.Reader object representing standard input for read operations.\n\n  Defaults to System/in, wrapped in a LineNumberingPushbackReader")

var Lit_1454 *jrt.String = jrt.Intern("A java.io.Writer object representing standard output for print operations.\n\n  Defaults to System/out, wrapped in an OutputStreamWriter")

var Lit_1455 *jrt.String = jrt.Intern("A java.io.Writer object representing standard error for print operations.\n\n  Defaults to System/err, wrapped in a PrintWriter")

var Lit_1456 *jrt.String = jrt.Intern("When set to true, output will be flushed whenever a newline is printed.\n\n  Defaults to true.")

var Lit_1457 *jrt.String = jrt.Intern("If set to logical true, when printing an object, its metadata will also\n  be printed in a form that can be read back by the reader.\n\n  Defaults to false.")

var Lit_1458 *jrt.String = jrt.Intern("When set to logical true, objects will be printed in a way that preserves\n  their type when read in later.\n\n  Defaults to false.")

var Lit_1459 *jrt.String = jrt.Intern("When set to logical false, strings and characters will be printed with\n  non-alphanumeric characters converted to the appropriate escape sequences.\n\n  Defaults to true")

var Lit_1460 *jrt.String = jrt.Intern("Defaults to true (or value specified by system property, see below)\n  ***This setting implies that the full power of the reader is in play,\n  including syntax that can cause code to execute. It should never be\n  used with untrusted sources. See also: arbace.edn/read.***\n\n  When set to logical false in the thread-local binding,\n  the eval reader (#=) and record/type literal syntax are disabled in read/load.\n  Example (will fail): (binding [*read-eval* false] (read-string \"#=(* 2 21)\"))\n\n  The default binding can be controlled by the system property\n  'arbace.read.eval' System properties can be set on the command line\n  like this:\n\n  java -Darbace.read.eval=false ...\n\n  The system property can also be set to 'unknown' via\n  -Darbace.read.eval=unknown, in which case the default binding\n  is :unknown and all reads will fail in contexts where *read-eval*\n  has not been explicitly bound to either true or false. This setting\n  can be a useful diagnostic tool to ensure that all of your reads\n  occur in considered contexts. You can also accomplish this in a\n  particular scope by binding *read-eval* to :unknown\n  ")

var Lit_1461 *jrt.String = jrt.Intern("When set to logical false, 'assert' will omit assertion checks in\n  compiled code. Defaults to true.")

var Lit_1462 *jrt.String = jrt.Intern("arbace.core$future_QMARK_")

var Lit_1463 *jrt.String = jrt.Intern("arbace.core$future_done_QMARK_")

var Lit_1464 *jrt.String = jrt.Intern("arbace.core$letfn")

var Lit_1465 *jrt.String = jrt.Intern("arbace.core$fnil")

var Lit_1466 *jrt.String = jrt.Intern("arbace.core$shift_mask")

var Lit_1467 *jrt.String = jrt.Intern("arbace.core$maybe_min_hash")

var Lit_1468 *jrt.String = jrt.Intern("arbace.core$case_map")

var Lit_1469 *jrt.String = jrt.Intern("arbace.core$fits_table_QMARK_")

var Lit_1470 *jrt.String = jrt.Intern("arbace.core$prep_ints")

var Lit_1471 *jrt.String = jrt.Intern("arbace.core$merge_hash_collisions")

var Lit_1472 *jrt.String = jrt.Intern("arbace.core$prep_hashes")

var Lit_1473 *jrt.String = jrt.Intern("arbace.core$case")

var Lit_1474 *jrt.String = jrt.Intern("Fundamental library of the Clojure language")

var Lit_1475 *jrt.String = jrt.Intern("core_proxy")

var Lit_1476 *jrt.String = jrt.Intern("core_bean")

var Lit_1477 *jrt.String = jrt.Intern("core_print")

var Lit_1478 *jrt.String = jrt.Intern("genclass")

var Lit_1479 *jrt.String = jrt.Intern("core_deftype")

var Lit_1480 *jrt.String = jrt.Intern("core/protocols")

var Lit_1481 *jrt.String = jrt.Intern("gvec")

var Lit_1482 *jrt.String = jrt.Intern("arbace.core$stream_reduce_BANG_")

var Lit_1483 *jrt.String = jrt.Intern("arbace.core$stream_seq_BANG_")

var Lit_1484 *jrt.String = jrt.Intern("arbace.core$stream_transduce_BANG_")

var Lit_1485 *jrt.String = jrt.Intern("arbace.core$stream_into_BANG_")

var Lit_1486 *jrt.String = jrt.Intern("arbace.core$when_class")

var Lit_1487 *jrt.String = jrt.Intern("instant")

var Lit_1488 *jrt.String = jrt.Intern("arbace.core$eval1927001833$fn__1927001834")

var Lit_1489 *jrt.String = jrt.Intern("arbace.core$eval1927001847$fn__1927001848")

var Lit_1490 *jrt.String = jrt.Intern("arbace.core$inst_ms")

var Lit_1491 *jrt.String = jrt.Intern("arbace.core$inst_QMARK_")

var Lit_1492 *jrt.String = jrt.Intern("arbace.core$eval1927001853$fn__1927001854")

var Lit_1493 *jrt.String = jrt.Intern("uuid")

var Lit_1494 *jrt.String = jrt.Intern("arbace.core$uuid_QMARK_")

var Lit_1495 *jrt.String = jrt.Intern("arbace.core$random_uuid")

var Lit_1496 *jrt.String = jrt.Intern("arbace.core$reduce")

var Lit_1497 *jrt.String = jrt.Intern("arbace.core$eval1927001862$fn__1927001863")

var Lit_1498 *jrt.String = jrt.Intern("arbace.core$eval1927001866$fn__1927001867")

var Lit_1499 *jrt.String = jrt.Intern("arbace.core$eval1927001870$fn__1927001871")

var Lit_1500 *jrt.String = jrt.Intern("arbace.core$eval1927001876$fn__1927001877")

var Lit_1501 *jrt.String = jrt.Intern("arbace.core$reduce_kv")

var Lit_1502 *jrt.String = jrt.Intern("arbace.core$completing")

var Lit_1503 *jrt.String = jrt.Intern("arbace.core$transduce")

var Lit_1504 *jrt.String = jrt.Intern("arbace.core$into")

var Lit_1505 *jrt.String = jrt.Intern("arbace.core$eval1927001888$fn__1927001889")

var Lit_1506 *jrt.String = jrt.Intern("arbace.core$mapv")

var Lit_1507 *jrt.String = jrt.Intern("arbace.core$filterv")

var Lit_1508 *jrt.String = jrt.Intern("arbace.core$select_keys")

var Lit_1509 *jrt.String = jrt.Intern("arbace.core$merge_deep")

var Lit_1510 *jrt.String = jrt.Intern("arbace.core$merge_deep_with")

var Lit_1511 *jrt.String = jrt.Intern("arbace.core$normalize_slurp_opts")

var Lit_1512 *jrt.String = jrt.Intern("arbace.core$slurp")

var Lit_1513 *jrt.String = jrt.Intern("kn8,arglistsyn1,fyn7,contentyn1,&yn7,optionskn3,dockn5,addedkn4,linekn6,columnkn4,filekn6,staticyn4,bodykn3,tagyn27,java.util.concurrent.Futureyn4,collyn5,collsyn3,fnsyn5,exprskn5,majorkn5,minorkn11,incrementalkn9,qualifierkn7,interimkn7,dynamicyn7,promiseyn3,valyn1,xyn4,inityn4,longyn1,nyn4,stepyn3,padyn20,java.util.Collectionyn1,pyn2,p1yn2,p2yn2,p3yn2,pskn7,privateyn5,fdeclyn11,binding-mapyn4,funcyn8,bindingsyn20,arbace.lang.IPendingyn4,expryn7,clausesyn4,nameyn5,formsyn2,rfyn4,predyn4,retfyn4,probyn5,xformyn6,xform*yn4,prockn4,keysyn5,somefyn2,vfyn2,kfyn5,initkkn2,oryn8,identityyn5,some?yn5,valueyn18,arbace.lang.Symbolyn4,formyn7,Booleanyn4,uuidyn4,instyn3,symyn8,mappingsyn12,java.net.URLyn1,myn16,java.lang.Stringyn6,Stringyn14,java.lang.Longyn16,java.lang.Doubleyn14,java.util.UUIDyn6,doublev11,arbace.core4,spitm12,R0,L1,V4,R1,R2,R3,R4,R5,s114,Opposite of slurp.  Opens f with writer, writes content, then\n  closes f. Options passed to arbace.java.io/writer.R6,s3,1.2R7,i7228,R8,i1,R9,s14,arbace/core.aev11,arbace.core11,future-callm14,R0,L1,V1,R1,R5,s329,Takes a function of no args and yields a future object that will\n  invoke the function in another thread, and will cache the result and\n  return it on all subsequent calls to deref/@. If the computation has\n  not yet finished, calls to deref/@ will block, unless the variant\n  of deref with timeout is used. See also - realized?.R6,s3,1.1R10,TR7,i7237,R8,i1,R9,s14,arbace/core.aev11,arbace.core6,futurem12,R0,L1,V2,R3,R11,R5,s325,Takes a body of expressions and yields a future object that will\n  invoke the body in another thread, and will cache the result and\n  return it on all subsequent calls to deref/@. If the computation has\n  not yet finished, calls to deref/@ will block, unless the variant of\n  deref with timeout is used. See also - realized?.R6,s3,1.1R7,i7264,R8,i1,R9,s14,arbace/core.aev11,arbace.core13,future-cancelm14,R0,L1,V1,Myn1,fm2,R12,R13,R5,s32,Cancels the future, if possible.R6,s3,1.1R10,TR7,i7273,R8,i1,R9,s14,arbace/core.aev11,arbace.core17,future-cancelled?m14,R0,L1,V1,Myn1,fm2,R12,R13,R5,s37,Returns true if future f is cancelledR6,s3,1.1R10,TR7,i7279,R8,i1,R9,s14,arbace/core.aev11,arbace.core4,pmapm14,R0,L2,V2,R1,R14,V4,R1,R14,R3,R15,R5,s289,Like map, except f is applied in parallel. Semi-lazy in that the\n  parallel computation stays ahead of the consumption, but doesn't\n  realize the entire result unless required. Only useful for\n  computationally intensive functions where the time of f dominates\n  the coordination overhead.R6,s3,1.0R10,TR7,i7285,R8,i1,R9,s14,arbace/core.aev11,arbace.core6,pcallsm14,R0,L1,V2,R3,R16,R5,s80,Executes the no-arg fns in parallel, returning a lazy sequence of\n  their valuesR6,s3,1.0R10,TR7,i7310,R8,i1,R9,s14,arbace/core.aev11,arbace.core7,pvaluesm14,R0,L1,V2,R3,R17,R5,s85,Returns a lazy sequence of the values of the exprs, which are\n  evaluated in parallelR6,s3,1.0R10,TR7,i7317,R8,i1,R9,s14,arbace/core.aep56,(\\d+)\\.(\\d+)\\.(\\d+)(?:-([a-zA-Z0-9_]+))?(?:-(SNAPSHOT))?R18,R19,R20,R21,v11,arbace.core17,*clojure-version*R22,m8,R23,TR7,i7336,R8,i3,R9,s14,arbace/core.aem2,R6,s3,1.0v11,arbace.core15,clojure-versionm12,R0,L1,V0,R5,s46,Returns clojure version as a printable string.R6,s3,1.0R7,i7348,R8,i1,R9,s14,arbace/core.aev11,arbace.core16,*arbace-version*m8,R23,TR7,i7370,R8,i1,R9,s14,arbace/core.aem2,R6,s6,arbacev11,arbace.core14,arbace-versionm12,R0,L1,V0,R5,s131,Returns Arbace's version as a printable string: the git describe of the commit it was built\n  from (:describe of *arbace-version*).R6,s6,arbaceR7,i7393,R8,i1,R9,s14,arbace/core.aev11,arbace.core7,promisem14,R0,L1,V0,R5,s293,Returns a promise object that can be read with deref/@, and set,\n  once only, with deliver. Calls to deref/@ prior to delivery will\n  block, unless the variant of deref with timeout is used. All\n  subsequent derefs will return the same delivered value without\n  blocking. See also - realized?.R6,s3,1.1R10,TR7,i7401,R8,i1,R9,s14,arbace/core.aev11,arbace.core7,deliverm14,R0,L1,V2,R24,R25,R5,s138,Delivers the supplied value to the promise, releasing any pending\n  derefs. A subsequent call to deliver on a promise will have no effect.R6,s3,1.1R10,TR7,i7432,R8,i1,R9,s14,arbace/core.aem14,R0,L1,V1,R26,R5,s177,Takes any nested combination of sequential things (lists, vectors,\n  etc.) and returns their contents as a single, flat lazy sequence.\n  (flatten nil) returns an empty sequence.R6,s3,1.2R10,TR7,i7439,R8,i1,R9,s14,arbace/core.aev11,arbace.core8,group-bym14,R0,L1,V2,R1,R14,R5,s189,Returns a map of the elements of coll keyed by the result of\n  f on each element. The value at each key will be a vector of the\n  corresponding elements, in the order they appeared in coll.R6,s3,1.2R10,TR7,i7449,R8,i1,R9,s14,arbace/core.aev11,arbace.core12,partition-bym14,R0,L2,V1,R1,V2,R1,R14,R5,s182,Applies f to each value in coll, splitting it each time f returns a\n   new value.  Returns a lazy seq of partitions.  Returns a stateful\n   transducer when no collection is provided.R6,s3,1.2R10,TR7,i7463,R8,i1,R9,s14,arbace/core.aev11,arbace.core11,frequenciesm14,R0,L1,V1,R14,R5,s79,Returns a map from distinct items in coll to the number of times\n  they appear.R6,s3,1.2R10,TR7,i7506,R8,i1,R9,s14,arbace/core.aev11,arbace.core10,reductionsm12,R0,L2,V2,R1,R14,V3,R1,R27,R14,R5,s114,Returns a lazy seq of the intermediate values of the reduction (as\n  per reduce) of coll by f, starting with init.R6,s3,1.2R7,i7517,R8,i1,R9,s14,arbace/core.aev11,arbace.core8,rand-nthm14,R0,L1,V1,R14,R5,s139,Return a random element of the (sequential) collection. Will have\n  the same performance characteristics as nth for the given\n  collection.R6,s3,1.2R10,TR7,i7534,R8,i1,R9,s14,arbace/core.aev11,arbace.core13,partition-allm14,R0,L3,V1,Myn1,nm2,R12,R28,V2,R29,R14,V3,R29,R30,R14,R5,s178,Returns a lazy sequence of lists like partition, but may include\n  partitions with fewer than n items at the end.  Returns a stateful\n  transducer when no collection is provided.R6,s3,1.2R10,TR7,i7543,R8,i1,R9,s14,arbace/core.aev11,arbace.core9,splitv-atm12,R0,L1,V2,R29,R14,R5,s59,Returns a vector of [(into [] (take n) coll) (drop n coll)]R6,s4,1.12R7,i7577,R8,i1,R9,s14,arbace/core.aev11,arbace.core10,partitionvm12,R0,L3,V2,R29,R14,V3,R29,R30,R14,V4,R29,R30,R31,R14,R5,s352,Returns a lazy sequence of vectors of n items each, at offsets step\n  apart. If step is not supplied, defaults to n, i.e. the partitions\n  do not overlap. If a pad collection is supplied, use its elements as\n  necessary to complete last partition upto n items. In case there are\n  not enough padding elements, return a partition with less than n items.R6,s4,1.12R7,i7583,R8,i1,R9,s14,arbace/core.aev11,arbace.core14,partitionv-allm12,R0,L3,V1,R29,V2,R29,R14,V3,R29,R30,R14,R5,s174,Returns a lazy sequence of vector partitions, but may include\n  partitions with fewer than n items at the end.\n  Returns a stateful transducer when no collection is provided.R6,s4,1.12R7,i7606,R8,i1,R9,s14,arbace/core.aev11,arbace.core7,shufflem14,R0,L1,V1,Myn4,collm2,R12,R32,R5,s35,Return a random permutation of collR6,s3,1.2R10,TR7,i7621,R8,i1,R9,s14,arbace/core.aev11,arbace.core11,map-indexedm14,R0,L2,V1,R1,V2,R1,R14,R5,s311,Returns a lazy sequence consisting of the result of applying f to 0\n  and the first item of coll, followed by applying f to 1 and the second\n  item in coll, etc, until coll is exhausted. Thus function f should\n  accept 2 arguments, index and item. Returns a stateful transducer when\n  no collection is provided.R6,s3,1.2R10,TR7,i7630,R8,i1,R9,s14,arbace/core.aev11,arbace.core4,keepm14,R0,L2,V1,R1,V2,R1,R14,R5,s205,Returns a lazy sequence of the non-nil results of (f item). Note,\n  this means false return values will be included.  f must be free of\n  side-effects.  Returns a transducer when no collection is provided.R6,s3,1.2R10,TR7,i7660,R8,i1,R9,s14,arbace/core.aev11,arbace.core12,keep-indexedm14,R0,L2,V1,R1,V2,R1,R14,R5,s222,Returns a lazy sequence of the non-nil results of (f index item). Note,\n  this means false return values will be included.  f must be free of\n  side-effects.  Returns a stateful transducer when no collection is\n  provided.R6,s3,1.2R10,TR7,i7693,R8,i1,R9,s14,arbace/core.aev11,arbace.core13,bounded-countm12,R0,L1,V2,R29,R14,R5,s107,If coll is counted? returns its count, else will count at most the first n\n  elements of coll using its seqR6,s3,1.9R7,i7731,R8,i1,R9,s14,arbace/core.aev11,arbace.core10,every-predm12,R0,L4,V1,R33,V2,R34,R35,V3,R34,R35,R36,V5,R34,R35,R36,R3,R37,R5,s345,Takes a set of predicates and returns a function f that returns true if all of its\n  composing predicates return a logical true value against all of its arguments, else it returns\n  false. Note that f is short-circuiting in that it will stop execution on the first\n  argument that triggers a logical false result against the original predicates.R6,s3,1.3R7,i7743,R8,i1,R9,s14,arbace/core.aev11,arbace.core7,some-fnm12,R0,L4,V1,R33,V2,R34,R35,V3,R34,R35,R36,V5,R34,R35,R36,R3,R37,R5,s357,Takes a set of predicates and returns a function f that returns the first logical true value\n  returned by one of its composing predicates against any of its arguments, else it returns\n  logical false. Note that f is short-circuiting in that it will stop execution on the first\n  argument that triggers a logical true result against the original predicates.R6,s3,1.3R7,i7783,R8,i1,R9,s14,arbace/core.aem14,R23,TR38,TR0,L1,V1,R39,R5,s69,A good fdecl looks like (([a] ...) ([a b] ...)) near the end of defn.R7,i7823,R8,i1,R9,s14,arbace/core.aev11,arbace.core14,with-redefs-fnm12,R0,L1,V2,R40,R41,R5,s357,Temporarily redefines Vars during a call to func.  Each val of\n  binding-map will replace the root value of its key which must be\n  a Var.  After func is called with no args, the root values of all\n  the Vars will be set back to their old values.  These temporary\n  changes will be visible in all threads.  Useful for mocking out\n  functions during testing.R6,s3,1.3R7,i7845,R8,i1,R9,s14,arbace/core.aev11,arbace.core11,with-redefsm12,R0,L1,V3,R42,R3,R11,R5,s425,binding => var-symbol temp-value-expr\n\n  Temporarily redefines Vars while executing the body.  The\n  temp-value-exprs will be evaluated and each resulting value will\n  replace in parallel the root value of its Var.  After the body is\n  executed, the root values of all the Vars will be set back to their\n  old values.  These temporary changes will be visible in all threads.\n  Useful for mocking out functions during testing.R6,s3,1.3R7,i7865,R8,i1,R9,s14,arbace/core.aev11,arbace.core9,realized?m12,R0,L1,V1,Myn1,xm2,R12,R43,R5,s88,Returns true if a value has been produced for a promise, delay, future or lazy sequence.R6,s3,1.3R7,i7880,R8,i1,R9,s14,arbace/core.aev11,arbace.core6,cond->m12,R0,L1,V3,R44,R3,R45,R5,s260,Takes an expression and a set of test/form pairs. Threads expr (via ->)\n  through each form for which the corresponding test\n  expression is true. Note that, unlike cond branching, cond-> threading does\n  not short circuit after the first true test expression.R6,s3,1.5R7,i7885,R8,i1,R9,s14,arbace/core.aev11,arbace.core7,cond->>m12,R0,L1,V3,R44,R3,R45,R5,s263,Takes an expression and a set of test/form pairs. Threads expr (via ->>)\n  through each form for which the corresponding test expression\n  is true.  Note that, unlike cond branching, cond->> threading does not short circuit\n  after the first true test expression.R6,s3,1.5R7,i7902,R8,i1,R9,s14,arbace/core.aev11,arbace.core4,as->m12,R0,L1,V4,R44,R46,R3,R47,R5,s195,Binds name to expr, evaluates the first form in the lexical context\n  of that binding, then binds name to that result, repeating for each\n  successive form, returning the result of the last form.R6,s3,1.5R7,i7919,R8,i1,R9,s14,arbace/core.aev11,arbace.core6,some->m12,R0,L1,V3,R44,R3,R47,R5,s118,When expr is not nil, threads it into the first form (via ->),\n  and when that result is not nil, through the next etcR6,s3,1.5R7,i7931,R8,i1,R9,s14,arbace/core.aev11,arbace.core7,some->>m12,R0,L1,V3,R44,R3,R47,R5,s119,When expr is not nil, threads it into the first form (via ->>),\n  and when that result is not nil, through the next etcR6,s3,1.5R7,i7945,R8,i1,R9,s14,arbace/core.aev11,arbace.core18,preserving-reducedm10,R38,TR0,L1,V1,R48,R7,i7959,R8,i1,R9,s14,arbace/core.aem12,R0,L1,V1,R48,R5,s109,A transducer which concatenates the contents of each input, which must be a\n  collection, into the reduction.R6,s3,1.7R7,i7966,R8,i1,R9,s14,arbace/core.aev11,arbace.core9,halt-whenm12,R0,L2,V1,R49,V2,R49,R50,R5,s492,Returns a transducer that ends transduction when pred returns true\n  for an input. When retf is supplied it must be a fn of 2 arguments -\n  it will be passed the (completed) result so far and the input that\n  triggered the predicate, and its return value (if it does not throw\n  an exception) will be the return value of the transducer. If retf\n  is not supplied, the input that triggered the predicate will be\n  returned. If the predicate never returns true the transduction is\n  unaffected.R6,s3,1.9R7,i7978,R8,i1,R9,s14,arbace/core.aev11,arbace.core6,dedupem12,R0,L2,V0,V1,R14,R5,s119,Returns a lazy sequence removing consecutive duplicates in coll.\n  Returns a transducer when no collection is provided.R6,s3,1.7R7,i8002,R8,i1,R9,s14,arbace/core.aev11,arbace.core13,random-samplem12,R0,L2,V1,R51,V2,R51,R14,R5,s124,Returns items from coll with random probability of prob (0.0 -\n  1.0).  Returns a transducer when no collection is provided.R6,s3,1.7R7,i8020,R8,i1,R9,s14,arbace/core.aeC20,arbace.core.Eductionv11,arbace.core10,->Eductionm10,R0,L1,V2,R52,R14,R5,s59,Positional factory function for class arbace.core.Eduction.R7,i8029,R8,i1,R9,s14,arbace/core.aev11,arbace.core8,eductionm12,R0,ML1,V2,R53,R14,m4,R7,i8046,R8,i15,R5,s231,Returns a reducible/iterable application of the transducers\n  to the items in coll. Transducers are applied in order as if\n  combined with comp. Note that these applications will be\n  performed every time reduce/iterator is called.R6,s3,1.7R7,i8041,R8,i1,R9,s14,arbace/core.aev11,arbace.core4,run!m12,R0,L1,V2,R54,R14,R5,s124,Runs the supplied procedure (via reduce), for purposes of side\n  effects, on successive items in the collection. Returns nilR6,s3,1.7R7,i8057,R8,i1,R9,s14,arbace/core.aev11,arbace.core9,iterationm12,R0,L1,V3,R30,R3,m4,R55,V4,R56,R57,R58,R59,R60,m8,R57,R61,R58,R61,R56,R62,R59,nR5,s979,Creates a seqable/reducible via repeated calls to step,\n  a function of some (continuation token) 'k'. The first call to step\n  will be passed initk, returning 'ret'. Iff (somef ret) is true,\n  (vf ret) will be included in the iteration, else iteration will\n  terminate and vf/kf will not be called. If (kf ret) is non-nil it\n  will be passed to the next step call, else iteration will terminate.\n\n  This can be used e.g. to consume APIs that return paginated or batched data.\n\n   step - (possibly impure) fn of 'k' -> 'ret'\n\n   :somef - fn of 'ret' -> logical true/false, default 'some?'\n   :vf - fn of 'ret' -> 'v', a value produced by the iteration, default 'identity'\n   :kf - fn of 'ret' -> 'next-k' or nil (signaling 'do not continue'), default 'identity'\n   :initk - the first value passed to step, default 'nil'\n\n  It is presumed that step with non-initk is unreproducible/non-idempotent.\n  If step with initk is unreproducible it is on the consumer to not consume twice.R6,s4,1.11R7,i8065,R8,i1,R9,s14,arbace/core.aev11,arbace.core15,tagged-literal?m12,R0,L1,V1,R63,R5,s71,Return true if the value is the data representation of a tagged literalR6,s3,1.7R7,i8112,R8,i1,R9,s14,arbace/core.aev11,arbace.core14,tagged-literalm12,R0,L1,V2,Myn3,tagm2,R12,R64,R65,R5,s83,Construct a data representation of a tagged literal from a\n  tag symbol and a form.R6,s3,1.7R7,i8118,R8,i1,R9,s14,arbace/core.aev11,arbace.core19,reader-conditional?m12,R0,L1,V1,R63,R5,s75,Return true if the value is the data representation of a reader conditionalR6,s3,1.7R7,i8125,R8,i1,R9,s14,arbace/core.aev11,arbace.core18,reader-conditionalm12,R0,L1,V2,R65,Myn9,splicing?m2,R12,R66,R5,s107,Construct a data representation of a reader conditional.\n  If true, splicing? indicates read-cond-splicing.R6,s3,1.7R7,i8131,R8,i1,R9,s14,arbace/core.aev11,arbace.core20,default-data-readersR67,v11,arbace.uuid19,default-uuid-readerR68,v14,arbace.instant17,read-instant-datem10,R6,s3,1.4R7,i8140,R8,i1,R9,s14,arbace/core.aeR5,s104,Default map of data reader functions provided by Clojure. May be\n  overridden by binding *data-readers*.v11,arbace.core14,*data-readers*m12,R6,s3,1.4R23,TR7,i8147,R8,i1,R9,s14,arbace/core.aeR5,s1187,Map from reader tag symbols to data reader Vars.\n\n  When Arbace starts, it searches for files named 'data_readers.ae',\n  'data_readers.clj' and 'data_readers.cljc' (in that order, as a\n  namespace's sources are looked for) at the root of the classpath.\n  Each such file\n  must contain a literal map of symbols, like this:\n\n      {foo/bar my.project.foo/bar\n       foo/baz my.project/baz}\n\n  The first symbol in each pair is a tag that will be recognized by\n  the Clojure reader. The second symbol in the pair is the\n  fully-qualified name of a Var which will be invoked by the reader to\n  parse the form following the tag. For example, given the\n  data_readers.clj file above, the Clojure reader would parse this\n  form:\n\n      #foo/bar [1 2 3]\n\n  by invoking the Var #'my.project.foo/bar on the vector [1 2 3]. The\n  data reader function is invoked on the form AFTER it has been read\n  as a normal Clojure data structure by the reader.\n\n  Reader tags without namespace qualifiers are reserved for\n  Clojure. Default reader tags are defined in\n  arbace.core/default-data-readers but may be overridden in\n  data_readers.ae, data_readers.clj, data_readers.cljc, or by rebinding\n  this Var.v11,arbace.core24,*default-data-reader-fn*m12,R6,s3,1.5R23,TR7,i8179,R8,i1,R9,s14,arbace/core.aeR5,s246,When no data reader is found for a tag and *default-data-reader-fn*\n  is non-nil, it will be called with two arguments,\n  the tag and the value.  If *default-data-reader-fn* is nil (the\n  default), an exception will be thrown for the unknown tag.v11,arbace.core16,data-reader-urlsm10,R38,TR0,L1,V0,R7,i8186,R8,i1,R9,s14,arbace/core.aev11,arbace.core15,data-reader-varm10,R38,TR0,L1,V1,R69,R7,i8193,R8,i1,R9,s14,arbace/core.aev11,arbace.core21,load-data-reader-filem10,R38,TR0,L1,V2,R70,Myn3,urlm2,R12,R71,R7,i8197,R8,i1,R9,s14,arbace/core.aev11,arbace.core17,load-data-readersm10,R38,TR0,L1,V0,R7,i8226,R8,i1,R9,s14,arbace/core.aev11,arbace.core4,uri?m12,R0,L1,V1,R26,R5,s34,Return true if x is a java.net.URIR6,s3,1.9R7,i8238,R8,i1,R9,s14,arbace/core.aev11,arbace.core6,tapsetm8,R38,TR7,i8243,R8,i1,R9,s14,arbace/core.aem8,R38,TR7,i8243,R8,i1,R9,s14,arbace/core.aev11,arbace.core4,tapqm10,R12,C39,java.util.concurrent.ArrayBlockingQueueR38,TR7,i8244,R8,i1,R9,s14,arbace/core.aem10,R12,C39,java.util.concurrent.ArrayBlockingQueueR38,TR7,i8244,R8,i1,R9,s14,arbace/core.aev11,arbace.core8,tap-loopm8,R38,TR7,i8246,R8,i1,R9,s14,arbace/core.aem8,R38,TR7,i8246,R8,i1,R9,s14,arbace/core.aev11,arbace.core7,add-tapm12,R0,L1,V1,R1,R5,s296,adds f, a fn of one argument, to the tap set. This function will be called with anything sent via tap>.\n  This function may (briefly) block (e.g. for streams), and will never impede calls to tap>,\n  but blocking indefinitely may cause tap values to be dropped.\n  Remember f in order to remove-tapR6,s4,1.10R7,i8261,R8,i1,R9,s14,arbace/core.aev11,arbace.core10,remove-tapm12,R0,L1,V1,R1,R5,s26,Remove f from the tap set.R6,s4,1.10R7,i8272,R8,i1,R9,s14,arbace/core.aev11,arbace.core4,tap>m12,R0,L1,V1,R26,R5,s107,sends x to any taps. Will not block. Returns true if there was room in the queue,\n  false if not (dropped).R6,s4,1.10R7,i8279,R8,i1,R9,s14,arbace/core.aev11,arbace.core5,tap->m12,R0,L1,V1,R26,R5,s59,Sends x to any taps, drops if tap queue is full, returns x.R6,s4,1.13R7,i8287,R8,i1,R9,s14,arbace/core.aev11,arbace.core11,update-valsm12,R0,L1,V2,R72,R1,R5,s178,m f => {k (f v) ...}\n\n  Given a map m and a function f of 1-argument, returns a new map where the keys of m\n  are mapped to result of applying f to the corresponding values of m.R6,s4,1.11R7,i8293,R8,i1,R9,s14,arbace/core.aev11,arbace.core11,update-keysm12,R0,L1,V2,R72,R1,R5,s270,m f => {(f k) v ...}\n\n  Given a map m and a function f of 1-argument, returns a new map whose\n  keys are the result of applying f to the keys of m, mapped to the\n  corresponding values of m.\n  f must return a unique key for each key of m, else the behavior is undefined.R6,s4,1.11R7,i8308,R8,i1,R9,s14,arbace/core.aev11,arbace.core11,parsing-errm12,R38,TR0,L1,MV1,R25,m2,R12,R73,R5,s58,Construct message for parsing for non-string parsing errorR7,i8323,R8,i1,R9,s14,arbace/core.aev11,arbace.core10,parse-longm12,R0,L1,MV1,Myn1,sm2,R12,R74,m2,R12,R75,R5,s105,Parse string of decimal digits with optional leading -/+ and return a\n  Long value, or nil if parse failsR6,s4,1.11R7,i8328,R8,i1,R9,s14,arbace/core.aev11,arbace.core12,parse-doublem12,R0,L1,MV1,Myn1,sm2,R12,R74,m2,R12,R76,R5,s197,Parse string with floating point components and return a Double value,\n  or nil if parse fails.\n\n  Grammar: https://docs.oracle.com/javase/8/docs/api/java/lang/Double.html#valueOf-java.lang.String-R6,s4,1.11R7,i8339,R8,i1,R9,s14,arbace/core.aev11,arbace.core10,parse-uuidm12,R0,L1,MV1,Myn1,sm2,R12,R74,m2,R12,R77,R5,s182,Parse a string representing a UUID and return a java.util.UUID instance,\n  or nil if parse fails.\n\n  Grammar: https://docs.oracle.com/javase/8/docs/api/java/util/UUID.html#toString--R6,s4,1.11R7,i8352,R8,i1,R9,s14,arbace/core.aev11,arbace.core13,parse-booleanm12,R0,L1,V1,Myn1,sm2,R12,R74,R5,s71,Parse strings \"true\" or \"false\" and return a boolean, or nil if invalidR6,s4,1.11R7,i8363,R8,i1,R9,s14,arbace/core.aev11,arbace.core4,NaN?L1,V1,Myn3,numm2,R12,R78,S1,l1,i8374,v11,arbace.core9,infinite?L1,V1,Myn3,numm2,R12,R78,S1,l1,i8383,v11,arbace.core13,selector-implm10,R38,TR0,L1,V1,R72,R7,i8391,R8,i1,R9,s14,arbace/core.aev11,arbace.core8,selectorm12,R0,L1,V1,R72,R5,s728,Builds a selecting-fn from m, a map destructuring form that must\n  include one or more of the :select, :all, :missing, and :excess\n  directives. The return function takes a collection, destructures it\n  per m, and returns a map of the result(s).\n\n  If m has exactly one directive, the result is the value that\n  directive would yield. If m has more than one directive, then it\n  returns a map of directives to values.\n\n  As in destructuring, :missing controls whether missing required keys\n  throw or are collected.\n\n  While a map destructuring form may and sometimes must include\n  bindings, selector doesn't produce bindings, thus ignoring the\n  associated directive names.\n\n  Throws an exception if the argument is not a map.R6,s4,1.13R7,i8404,R8,i1,R9,s14,arbace/core.ae")

var Lit_1514 *jrt.String = jrt.Intern("arbace.core$spit")

var Lit_1515 *jrt.String = jrt.Intern("arbace.core$future_call")

var Lit_1516 *jrt.String = jrt.Intern("arbace.core$future")

var Lit_1517 *jrt.String = jrt.Intern("arbace.core$future_cancel")

var Lit_1518 *jrt.String = jrt.Intern("arbace.core$future_cancelled_QMARK_")

var Lit_1519 *jrt.String = jrt.Intern("arbace.core$pmap")

var Lit_1520 *jrt.String = jrt.Intern("arbace.core$pcalls")

var Lit_1521 *jrt.String = jrt.Intern("arbace.core$pvalues")

var Lit_1522 *jrt.String = jrt.Intern("1.13.0-master-SNAPSHOT")

var Lit_1523 *jrt.String = jrt.Intern("SNAPSHOT")

var Lit_1524 *jrt.String = jrt.Intern("The version info for Clojure core, as a map containing :major :minor\n  :incremental and :qualifier keys. Feature releases may increment\n  :minor and/or :major, bugfix releases will increment :incremental.\n  Possible values of :qualifier include \"GA\", \"SNAPSHOT\", \"RC-x\" \"BETA-x\"")

var Lit_1525 *jrt.String = jrt.Intern("arbace.core$clojure_version")

var Lit_1526 *jrt.String = jrt.Intern("arbace.core$fn__1927001963")

var Lit_1527 *jrt.String = jrt.Intern("The version of Arbace: the commit it was built from, as a map:\n  :describe  git describe --tags --always --dirty of the build's checkout (in a tarball,\n             the describe git archive wrote into VERSION), \"unknown\" when neither\n  :commit    the commit's full hash, a string (nil when unknown)\n  :dirty     true when tracked files of the checkout differed from the commit, false in a\n             tarball (nil when unknown)\n  *clojure-version* stays the version of Clojure Arbace derives from, for libraries.")

var Lit_1528 *jrt.String = jrt.Intern("arbace.core$arbace_version")

var Lit_1529 *jrt.String = jrt.Intern("arbace.core$promise")

var Lit_1530 *jrt.String = jrt.Intern("arbace.core$deliver")

var Lit_1531 *jrt.String = jrt.Intern("arbace.core$flatten")

var Lit_1532 *jrt.String = jrt.Intern("arbace.core$group_by")

var Lit_1533 *jrt.String = jrt.Intern("arbace.core$partition_by")

var Lit_1534 *jrt.String = jrt.Intern("arbace.core$frequencies")

var Lit_1535 *jrt.String = jrt.Intern("arbace.core$reductions")

var Lit_1536 *jrt.String = jrt.Intern("arbace.core$rand_nth")

var Lit_1537 *jrt.String = jrt.Intern("arbace.core$partition_all")

var Lit_1538 *jrt.String = jrt.Intern("arbace.core$splitv_at")

var Lit_1539 *jrt.String = jrt.Intern("arbace.core$partitionv")

var Lit_1540 *jrt.String = jrt.Intern("arbace.core$partitionv_all")

var Lit_1541 *jrt.String = jrt.Intern("arbace.core$shuffle")

var Lit_1542 *jrt.String = jrt.Intern("arbace.core$map_indexed")

var Lit_1543 *jrt.String = jrt.Intern("arbace.core$keep")

var Lit_1544 *jrt.String = jrt.Intern("arbace.core$keep_indexed")

var Lit_1545 *jrt.String = jrt.Intern("arbace.core$bounded_count")

var Lit_1546 *jrt.String = jrt.Intern("arbace.core$every_pred")

var Lit_1547 *jrt.String = jrt.Intern("arbace.core$some_fn")

var Lit_1548 *jrt.String = jrt.Intern("arbace.core$assert_valid_fdecl__1")

var Lit_1549 *jrt.String = jrt.Intern("arbace.core$with_redefs_fn")

var Lit_1550 *jrt.String = jrt.Intern("arbace.core$with_redefs")

var Lit_1551 *jrt.String = jrt.Intern("arbace.core$realized_QMARK_")

var Lit_1552 *jrt.String = jrt.Intern("arbace.core$cond__GT_")

var Lit_1553 *jrt.String = jrt.Intern("arbace.core$cond__GT__GT_")

var Lit_1554 *jrt.String = jrt.Intern("arbace.core$as__GT_")

var Lit_1555 *jrt.String = jrt.Intern("arbace.core$some__GT_")

var Lit_1556 *jrt.String = jrt.Intern("arbace.core$some__GT__GT_")

var Lit_1557 *jrt.String = jrt.Intern("arbace.core$preserving_reduced")

var Lit_1558 *jrt.String = jrt.Intern("arbace.core$cat")

var Lit_1559 *jrt.String = jrt.Intern("arbace.core$halt_when")

var Lit_1560 *jrt.String = jrt.Intern("arbace.core$dedupe")

var Lit_1561 *jrt.String = jrt.Intern("arbace.core$random_sample")

var Lit_1562 *jrt.String = jrt.Intern("arbace.core.Eduction")

var Lit_1563 *jrt.String = jrt.Intern("arbace.core$eval1927002196$__GT_Eduction__1927002198")

var Lit_1564 *jrt.String = jrt.Intern("arbace.core$eduction")

var Lit_1565 *jrt.String = jrt.Intern("arbace.core$eval1927002202$fn__1927002203")

var Lit_1566 *jrt.String = jrt.Intern("arbace.core$run_BANG_")

var Lit_1567 *jrt.String = jrt.Intern("arbace.core$iteration")

var Lit_1568 *jrt.String = jrt.Intern("arbace.core$tagged_literal_QMARK_")

var Lit_1569 *jrt.String = jrt.Intern("arbace.core$tagged_literal")

var Lit_1570 *jrt.String = jrt.Intern("arbace.core$reader_conditional_QMARK_")

var Lit_1571 *jrt.String = jrt.Intern("arbace.core$reader_conditional")

var Lit_1572 *jrt.String = jrt.Intern("arbace.core$data_reader_urls")

var Lit_1573 *jrt.String = jrt.Intern("arbace.core$data_reader_var")

var Lit_1574 *jrt.String = jrt.Intern("arbace.core$load_data_reader_file")

var Lit_1575 *jrt.String = jrt.Intern("arbace.core$load_data_readers")

var Lit_1576 *jrt.String = jrt.Intern("arbace.core$uri_QMARK_")

var Lit_1577 *jrt.String = jrt.Intern("arbace.core$eval1927002249$fn__1927002250")

var Lit_1578 *jrt.String = jrt.Intern("arbace.core$add_tap")

var Lit_1579 *jrt.String = jrt.Intern("arbace.core$remove_tap")

var Lit_1580 *jrt.String = jrt.Intern("arbace.core$tap_GT_")

var Lit_1581 *jrt.String = jrt.Intern("arbace.core$tap__GT_")

var Lit_1582 *jrt.String = jrt.Intern("arbace.core$update_vals")

var Lit_1583 *jrt.String = jrt.Intern("arbace.core$update_keys")

var Lit_1584 *jrt.String = jrt.Intern("arbace.core$parsing_err")

var Lit_1585 *jrt.String = jrt.Intern("arbace.core$parse_long")

var Lit_1586 *jrt.String = jrt.Intern("arbace.core$parse_double")

var Lit_1587 *jrt.String = jrt.Intern("arbace.core$parse_uuid")

var Lit_1588 *jrt.String = jrt.Intern("arbace.core$parse_boolean")

var Lit_1589 *jrt.String = jrt.Intern("arbace.core$NaN_QMARK_")

var Lit_1590 *jrt.String = jrt.Intern("Returns true if num is NaN, else false")

var Lit_1591 *jrt.String = jrt.Intern("arbace.core$NaN_QMARK___inliner__1927002281")

var Lit_1592 *jrt.String = jrt.Intern("arbace.core$infinite_QMARK_")

var Lit_1593 *jrt.String = jrt.Intern("Returns true if num is negative or positive infinity, else false")

var Lit_1594 *jrt.String = jrt.Intern("arbace.core$infinite_QMARK___inliner__1927002284")

var Lit_1595 *jrt.String = jrt.Intern("arbace.core$selector_impl")

var Lit_1596 *jrt.String = jrt.Intern("arbace.core$selector")

var Lit_1597 *jrt.String = jrt.Intern("core_classes")
