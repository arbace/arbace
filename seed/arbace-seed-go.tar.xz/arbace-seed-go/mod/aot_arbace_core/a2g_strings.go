//line a2g_strings.ae:1
package aot_arbace_core

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("cons")

var Lit_2 *jrt.String = jrt.Intern("let*")

var Lit_3 *jrt.String = jrt.Intern("loop*")

var Lit_4 *jrt.String = jrt.Intern("fn*")

var Lit_5 *jrt.String = jrt.Intern("first")

var Lit_6 *jrt.String = jrt.Intern("next")

var Lit_7 *jrt.String = jrt.Intern("second")

var Lit_8 *jrt.String = jrt.Intern("nnext")

var Lit_9 *jrt.String = jrt.Intern("list")

var Lit_10 *jrt.String = jrt.Intern("arbace.lang.RT")

var Lit_11 *jrt.String = jrt.Intern("meta")

var Lit_12 *jrt.String = jrt.Intern("&form")

var Lit_13 *jrt.String = jrt.Intern("map?")

var Lit_14 *jrt.String = jrt.Intern("with-meta")

var Lit_15 *jrt.String = jrt.Intern("conj")

var Lit_16 *jrt.String = jrt.Intern("tag")

var Lit_17 *jrt.String = jrt.Intern("assoc")

var Lit_18 *jrt.String = jrt.Intern("seq?")

var Lit_19 *jrt.String = jrt.Intern("seq")

var Lit_20 *jrt.String = jrt.Intern("assert-valid-fdecl")

var Lit_21 *jrt.String = jrt.Intern("string?")

var Lit_22 *jrt.String = jrt.Intern("doc")

var Lit_23 *jrt.String = jrt.Intern("vector?")

var Lit_24 *jrt.String = jrt.Intern("butlast")

var Lit_25 *jrt.String = jrt.Intern("inline")

var Lit_26 *jrt.String = jrt.Intern("fn")

var Lit_27 *jrt.String = jrt.Intern("last")

var Lit_28 *jrt.String = jrt.Intern("arglists")

var Lit_29 *jrt.String = jrt.Intern("quote")

var Lit_30 *jrt.String = jrt.Intern("sigs")

var Lit_31 *jrt.String = jrt.Intern("def")

var Lit_32 *jrt.String = jrt.Intern("rettag")

var Lit_33 *jrt.String = jrt.Intern("arbace.lang.Util")

var Lit_34 *jrt.String = jrt.Intern("identical")

var Lit_35 *jrt.String = jrt.Intern("vec")

var Lit_36 *jrt.String = jrt.Intern("&env")

var Lit_37 *jrt.String = jrt.Intern("do")

var Lit_38 *jrt.String = jrt.Intern("defn")

var Lit_39 *jrt.String = jrt.Intern(".")

var Lit_40 *jrt.String = jrt.Intern("setMacro")

var Lit_41 *jrt.String = jrt.Intern("line")

var Lit_42 *jrt.String = jrt.Intern("column")

var Lit_43 *jrt.String = jrt.Intern("var")

var Lit_44 *jrt.String = jrt.Intern("if")

var Lit_45 *jrt.String = jrt.Intern("not")

var Lit_46 *jrt.String = jrt.Intern("str")

var Lit_47 *jrt.String = jrt.Intern("cond")

var Lit_48 *jrt.String = jrt.Intern("symbol?")

var Lit_49 *jrt.String = jrt.Intern("else")

var Lit_50 *jrt.String = jrt.Intern("gensym")

var Lit_51 *jrt.String = jrt.Intern("keyword?")

var Lit_52 *jrt.String = jrt.Intern("spread")

var Lit_53 *jrt.String = jrt.Intern("list*")

var Lit_54 *jrt.String = jrt.Intern("apply")

var Lit_55 *jrt.String = jrt.Intern("new")

var Lit_56 *jrt.String = jrt.Intern("arbace.lang.LazySeq")

var Lit_57 *jrt.String = jrt.Intern("once")

var Lit_58 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_59 *jrt.String = jrt.Intern("chunk-cons")

var Lit_60 *jrt.String = jrt.Intern("chunk-first")

var Lit_61 *jrt.String = jrt.Intern("chunk-rest")

var Lit_62 *jrt.String = jrt.Intern("rest")

var Lit_63 *jrt.String = jrt.Intern("concat")

var Lit_64 *jrt.String = jrt.Intern("arbace.lang.Delay")

var Lit_65 *jrt.String = jrt.Intern("hash-map")

var Lit_66 *jrt.String = jrt.Intern("if-not")

var Lit_67 *jrt.String = jrt.Intern("equiv")

var Lit_68 *jrt.String = jrt.Intern("=")

var Lit_69 *jrt.String = jrt.Intern("compare")

var Lit_70 *jrt.String = jrt.Intern("let")

var Lit_71 *jrt.String = jrt.Intern("vector")

var Lit_72 *jrt.String = jrt.Intern("and__1927000168__auto__")

var Lit_73 *jrt.String = jrt.Intern("and")

var Lit_74 *jrt.String = jrt.Intern("or__1927000174__auto__")

var Lit_75 *jrt.String = jrt.Intern("or")

var Lit_76 *jrt.String = jrt.Intern("arbace.lang.Numbers")

var Lit_77 *jrt.String = jrt.Intern("isZero")

var Lit_78 *jrt.String = jrt.Intern("count")

var Lit_79 *jrt.String = jrt.Intern("*unchecked-math*")

var Lit_80 *jrt.String = jrt.Intern("uncheckedIntCast")

var Lit_81 *jrt.String = jrt.Intern("intCast")

var Lit_82 *jrt.String = jrt.Intern("nth")

var Lit_83 *jrt.String = jrt.Intern("<")

var Lit_84 *jrt.String = jrt.Intern("lt")

var Lit_85 *jrt.String = jrt.Intern("incP")

var Lit_86 *jrt.String = jrt.Intern("unchecked_inc")

var Lit_87 *jrt.String = jrt.Intern("inc")

var Lit_88 *jrt.String = jrt.Intern("chunk-next")

var Lit_89 *jrt.String = jrt.Intern("reduce0")

var Lit_90 *jrt.String = jrt.Intern("reduce1")

var Lit_91 *jrt.String = jrt.Intern("nary-inline")

var Lit_92 *jrt.String = jrt.Intern("+'")

var Lit_93 *jrt.String = jrt.Intern("cast")

var Lit_94 *jrt.String = jrt.Intern("java.lang.Number")

var Lit_95 *jrt.String = jrt.Intern("+")

var Lit_96 *jrt.String = jrt.Intern("*'")

var Lit_97 *jrt.String = jrt.Intern("*")

var Lit_98 *jrt.String = jrt.Intern("/")

var Lit_99 *jrt.String = jrt.Intern("-'")

var Lit_100 *jrt.String = jrt.Intern("-")

var Lit_101 *jrt.String = jrt.Intern("<=")

var Lit_102 *jrt.String = jrt.Intern("lte")

var Lit_103 *jrt.String = jrt.Intern(">")

var Lit_104 *jrt.String = jrt.Intern("gt")

var Lit_105 *jrt.String = jrt.Intern(">=")

var Lit_106 *jrt.String = jrt.Intern("gte")

var Lit_107 *jrt.String = jrt.Intern("==")

var Lit_108 *jrt.String = jrt.Intern("max")

var Lit_109 *jrt.String = jrt.Intern("min")

var Lit_110 *jrt.String = jrt.Intern("abs")

var Lit_111 *jrt.String = jrt.Intern("decP")

var Lit_112 *jrt.String = jrt.Intern("unchecked_dec")

var Lit_113 *jrt.String = jrt.Intern("dec")

var Lit_114 *jrt.String = jrt.Intern("unchecked_int_inc")

var Lit_115 *jrt.String = jrt.Intern("unchecked_int_dec")

var Lit_116 *jrt.String = jrt.Intern("unchecked_int_negate")

var Lit_117 *jrt.String = jrt.Intern("unchecked_minus")

var Lit_118 *jrt.String = jrt.Intern("unchecked_int_add")

var Lit_119 *jrt.String = jrt.Intern("unchecked_add")

var Lit_120 *jrt.String = jrt.Intern("unchecked_int_subtract")

var Lit_121 *jrt.String = jrt.Intern("unchecked_int_multiply")

var Lit_122 *jrt.String = jrt.Intern("unchecked_multiply")

var Lit_123 *jrt.String = jrt.Intern("unchecked_int_divide")

var Lit_124 *jrt.String = jrt.Intern("unchecked_int_remainder")

var Lit_125 *jrt.String = jrt.Intern("isPos")

var Lit_126 *jrt.String = jrt.Intern("isNeg")

var Lit_127 *jrt.String = jrt.Intern("quotient")

var Lit_128 *jrt.String = jrt.Intern("remainder")

var Lit_129 *jrt.String = jrt.Intern("bit-and")

var Lit_130 *jrt.String = jrt.Intern("bit-or")

var Lit_131 *jrt.String = jrt.Intern("bit-xor")

var Lit_132 *jrt.String = jrt.Intern("bit-and-not")

var Lit_133 *jrt.String = jrt.Intern("shiftLeft")

var Lit_134 *jrt.String = jrt.Intern("shiftRight")

var Lit_135 *jrt.String = jrt.Intern("unsignedShiftRight")

var Lit_136 *jrt.String = jrt.Intern("integer?")

var Lit_137 *jrt.String = jrt.Intern("even?")

var Lit_138 *jrt.String = jrt.Intern("int?")

var Lit_139 *jrt.String = jrt.Intern("get")

var Lit_140 *jrt.String = jrt.Intern("req")

var Lit_141 *jrt.String = jrt.Intern("dissoc")

var Lit_142 *jrt.String = jrt.Intern("disj")

var Lit_143 *jrt.String = jrt.Intern("booleanCast")

var Lit_144 *jrt.String = jrt.Intern("ident?")

var Lit_145 *jrt.String = jrt.Intern("namespace")

var Lit_146 *jrt.String = jrt.Intern("lockee__1927000360__auto__")

var Lit_147 *jrt.String = jrt.Intern("try")

var Lit_148 *jrt.String = jrt.Intern("locklocal__1927000361__auto__")

var Lit_149 *jrt.String = jrt.Intern("monitor-enter")

var Lit_150 *jrt.String = jrt.Intern("finally")

var Lit_151 *jrt.String = jrt.Intern("monitor-exit")

var Lit_152 *jrt.String = jrt.Intern("..")

var Lit_153 *jrt.String = jrt.Intern("java.lang.IllegalArgumentException")

var Lit_154 *jrt.String = jrt.Intern("hash-set")

var Lit_155 *jrt.String = jrt.Intern("keys")

var Lit_156 *jrt.String = jrt.Intern("map")

var Lit_157 *jrt.String = jrt.Intern("default")

var Lit_158 *jrt.String = jrt.Intern("hierarchy")

var Lit_159 *jrt.String = jrt.Intern("global-hierarchy")

var Lit_160 *jrt.String = jrt.Intern("check-valid-options")

var Lit_161 *jrt.String = jrt.Intern("v__1927000386__auto__")

var Lit_162 *jrt.String = jrt.Intern("when-not")

var Lit_163 *jrt.String = jrt.Intern(".hasRoot")

var Lit_164 *jrt.String = jrt.Intern("instance?")

var Lit_165 *jrt.String = jrt.Intern("arbace.lang.MultiFn")

var Lit_166 *jrt.String = jrt.Intern("deref")

var Lit_167 *jrt.String = jrt.Intern("name")

var Lit_168 *jrt.String = jrt.Intern("addMethod")

var Lit_169 *jrt.String = jrt.Intern("throw")

var Lit_170 *jrt.String = jrt.Intern("java.lang.IllegalArgumentException.")

var Lit_171 *jrt.String = jrt.Intern("*ns*")

var Lit_172 *jrt.String = jrt.Intern("assert-args")

var Lit_173 *jrt.String = jrt.Intern("temp__1927000408__auto__")

var Lit_174 *jrt.String = jrt.Intern("if-let")

var Lit_175 *jrt.String = jrt.Intern("temp__1927000414__auto__")

var Lit_176 *jrt.String = jrt.Intern("when")

var Lit_177 *jrt.String = jrt.Intern("temp__1927000420__auto__")

var Lit_178 *jrt.String = jrt.Intern("nil?")

var Lit_179 *jrt.String = jrt.Intern("if-some")

var Lit_180 *jrt.String = jrt.Intern("temp__1927000426__auto__")

var Lit_181 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_182 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_183 *jrt.String = jrt.Intern("with-bindings*")

var Lit_184 *jrt.String = jrt.Intern("get-thread-bindings")

var Lit_185 *jrt.String = jrt.Intern("bound-fn*")

var Lit_186 *jrt.String = jrt.Intern("validator")

var Lit_187 *jrt.String = jrt.Intern("setup-reference")

var Lit_188 *jrt.String = jrt.Intern("error-handler")

var Lit_189 *jrt.String = jrt.Intern("error-mode")

var Lit_190 *jrt.String = jrt.Intern("continue")

var Lit_191 *jrt.String = jrt.Intern("fail")

var Lit_192 *jrt.String = jrt.Intern("binding-conveyor-fn")

var Lit_193 *jrt.String = jrt.Intern("*agent*")

var Lit_194 *jrt.String = jrt.Intern("send-via")

var Lit_195 *jrt.String = jrt.Intern("clear-actions")

var Lit_196 *jrt.String = jrt.Intern("agent-error")

var Lit_197 *jrt.String = jrt.Intern("restart-agent")

var Lit_198 *jrt.String = jrt.Intern("ref")

var Lit_199 *jrt.String = jrt.Intern("max-history")

var Lit_200 *jrt.String = jrt.Intern("min-history")

var Lit_201 *jrt.String = jrt.Intern("deref-future")

var Lit_202 *jrt.String = jrt.Intern("atom")

var Lit_203 *jrt.String = jrt.Intern("arbace.lang.LockingTransaction")

var Lit_204 *jrt.String = jrt.Intern("runInTransaction")

var Lit_205 *jrt.String = jrt.Intern("isRunning")

var Lit_206 *jrt.String = jrt.Intern("java.lang.IllegalStateException")

var Lit_207 *jrt.String = jrt.Intern("arbace.lang.Volatile")

var Lit_208 *jrt.String = jrt.Intern(".reset")

var Lit_209 *jrt.String = jrt.Intern(".deref")

var Lit_210 *jrt.String = jrt.Intern("comp")

var Lit_211 *jrt.String = jrt.Intern("identity")

var Lit_212 *jrt.String = jrt.Intern("n__1927000566__auto__")

var Lit_213 *jrt.String = jrt.Intern("longCast")

var Lit_214 *jrt.String = jrt.Intern("loop")

var Lit_215 *jrt.String = jrt.Intern("recur")

var Lit_216 *jrt.String = jrt.Intern("unchecked-inc")

var Lit_217 *jrt.String = jrt.Intern("every?")

var Lit_218 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_219 *jrt.String = jrt.Intern("chunk-append")

var Lit_220 *jrt.String = jrt.Intern("chunk")

var Lit_221 *jrt.String = jrt.Intern("vary-meta")

var Lit_222 *jrt.String = jrt.Intern("declared")

var Lit_223 *jrt.String = jrt.Intern("cat")

var Lit_224 *jrt.String = jrt.Intern("filter")

var Lit_225 *jrt.String = jrt.Intern("complement")

var Lit_226 *jrt.String = jrt.Intern("isReduced")

var Lit_227 *jrt.String = jrt.Intern("reduced")

var Lit_228 *jrt.String = jrt.Intern("take")

var Lit_229 *jrt.String = jrt.Intern("volatile!")

var Lit_230 *jrt.String = jrt.Intern("ensure-reduced")

var Lit_231 *jrt.String = jrt.Intern("take-while")

var Lit_232 *jrt.String = jrt.Intern("drop")

var Lit_233 *jrt.String = jrt.Intern("drop-last")

var Lit_234 *jrt.String = jrt.Intern("vreset!")

var Lit_235 *jrt.String = jrt.Intern("drop-while")

var Lit_236 *jrt.String = jrt.Intern("repeat")

var Lit_237 *jrt.String = jrt.Intern("iterate")

var Lit_238 *jrt.String = jrt.Intern("inc'")

var Lit_239 *jrt.String = jrt.Intern("line-seq")

var Lit_240 *jrt.String = jrt.Intern("to-array")

var Lit_241 *jrt.String = jrt.Intern("sort")

var Lit_242 *jrt.String = jrt.Intern("sort-by")

var Lit_243 *jrt.String = jrt.Intern("dorun")

var Lit_244 *jrt.String = jrt.Intern("doall")

var Lit_245 *jrt.String = jrt.Intern("partition")

var Lit_246 *jrt.String = jrt.Intern("nthrest")

var Lit_247 *jrt.String = jrt.Intern("while")

var Lit_248 *jrt.String = jrt.Intern("arbace.lang.IChunk")

var Lit_249 *jrt.String = jrt.Intern(".nth")

var Lit_250 *jrt.String = jrt.Intern("when-let")

var Lit_251 *jrt.String = jrt.Intern("c__1927000678__auto__")

var Lit_252 *jrt.String = jrt.Intern("int")

var Lit_253 *jrt.String = jrt.Intern("send")

var Lit_254 *jrt.String = jrt.Intern("await")

var Lit_255 *jrt.String = jrt.Intern("n__1927000701__auto__")

var Lit_256 *jrt.String = jrt.Intern("long")

var Lit_257 *jrt.String = jrt.Intern("transient")

var Lit_258 *jrt.String = jrt.Intern("merge-with")

var Lit_259 *jrt.String = jrt.Intern("assoc!")

var Lit_260 *jrt.String = jrt.Intern("persistent!")

var Lit_261 *jrt.String = jrt.Intern("key")

var Lit_262 *jrt.String = jrt.Intern("val")

var Lit_263 *jrt.String = jrt.Intern("conj!")

var Lit_264 *jrt.String = jrt.Intern("merge")

var Lit_265 *jrt.String = jrt.Intern("into1")

var Lit_266 *jrt.String = jrt.Intern("import*")

var Lit_267 *jrt.String = jrt.Intern("into-array")

var Lit_268 *jrt.String = jrt.Intern("type")

var Lit_269 *jrt.String = jrt.Intern("class")

var Lit_270 *jrt.String = jrt.Intern("num")

var Lit_271 *jrt.String = jrt.Intern("uncheckedFloatCast")

var Lit_272 *jrt.String = jrt.Intern("floatCast")

var Lit_273 *jrt.String = jrt.Intern("doubleCast")

var Lit_274 *jrt.String = jrt.Intern("uncheckedShortCast")

var Lit_275 *jrt.String = jrt.Intern("shortCast")

var Lit_276 *jrt.String = jrt.Intern("uncheckedByteCast")

var Lit_277 *jrt.String = jrt.Intern("byteCast")

var Lit_278 *jrt.String = jrt.Intern("uncheckedCharCast")

var Lit_279 *jrt.String = jrt.Intern("charCast")

var Lit_280 *jrt.String = jrt.Intern("uncheckedLongCast")

var Lit_281 *jrt.String = jrt.Intern("uncheckedDoubleCast")

var Lit_282 *jrt.String = jrt.Intern("ratio?")

var Lit_283 *jrt.String = jrt.Intern("decimal?")

var Lit_284 *jrt.String = jrt.Intern("bigint")

var Lit_285 *jrt.String = jrt.Intern("float?")

var Lit_286 *jrt.String = jrt.Intern("number?")

var Lit_287 *jrt.String = jrt.Intern("java.math.BigInteger")

var Lit_288 *jrt.String = jrt.Intern("java.math.BigDecimal")

var Lit_289 *jrt.String = jrt.Intern("*print-dup*")

var Lit_290 *jrt.String = jrt.Intern("print-dup")

var Lit_291 *jrt.String = jrt.Intern("print-method")

var Lit_292 *jrt.String = jrt.Intern("pr")

var Lit_293 *jrt.String = jrt.Intern("*out*")

var Lit_294 *jrt.String = jrt.Intern("pr-on")

var Lit_295 *jrt.String = jrt.Intern("system-newline")

var Lit_296 *jrt.String = jrt.Intern("*flush-on-newline*")

var Lit_297 *jrt.String = jrt.Intern("flush")

var Lit_298 *jrt.String = jrt.Intern("newline")

var Lit_299 *jrt.String = jrt.Intern("*print-readably*")

var Lit_300 *jrt.String = jrt.Intern("prn")

var Lit_301 *jrt.String = jrt.Intern("read")

var Lit_302 *jrt.String = jrt.Intern("*in*")

var Lit_303 *jrt.String = jrt.Intern("read+string")

var Lit_304 *jrt.String = jrt.Intern("subvec")

var Lit_305 *jrt.String = jrt.Intern("with-open")

var Lit_306 *jrt.String = jrt.Intern("close")

var Lit_307 *jrt.String = jrt.Intern("start__1927000835__auto__")

var Lit_308 *jrt.String = jrt.Intern("java.lang.System")

var Lit_309 *jrt.String = jrt.Intern("nanoTime")

var Lit_310 *jrt.String = jrt.Intern("ret__1927000836__auto__")

var Lit_311 *jrt.String = jrt.Intern("double")

var Lit_312 *jrt.String = jrt.Intern("alength")

var Lit_313 *jrt.String = jrt.Intern("aclone")

var Lit_314 *jrt.String = jrt.Intern("aget")

var Lit_315 *jrt.String = jrt.Intern("aset")

var Lit_316 *jrt.String = jrt.Intern("array")

var Lit_317 *jrt.String = jrt.Intern("idx")

var Lit_318 *jrt.String = jrt.Intern("idx2")

var Lit_319 *jrt.String = jrt.Intern("&")

var Lit_320 *jrt.String = jrt.Intern("idxv")

var Lit_321 *jrt.String = jrt.Intern("array__1927000856__auto__")

var Lit_322 *jrt.String = jrt.Intern("idx__1927000857__auto__")

var Lit_323 *jrt.String = jrt.Intern("val__1927000858__auto__")

var Lit_324 *jrt.String = jrt.Intern("java.lang.reflect.Array")

var Lit_325 *jrt.String = jrt.Intern("idx2__1927000859__auto__")

var Lit_326 *jrt.String = jrt.Intern("idxv__1927000860__auto__")

var Lit_327 *jrt.String = jrt.Intern("aset-int")

var Lit_328 *jrt.String = jrt.Intern("aset-long")

var Lit_329 *jrt.String = jrt.Intern("aset-boolean")

var Lit_330 *jrt.String = jrt.Intern("aset-float")

var Lit_331 *jrt.String = jrt.Intern("aset-double")

var Lit_332 *jrt.String = jrt.Intern("aset-short")

var Lit_333 *jrt.String = jrt.Intern("aset-byte")

var Lit_334 *jrt.String = jrt.Intern("aset-char")

var Lit_335 *jrt.String = jrt.Intern("make-array")

var Lit_336 *jrt.String = jrt.Intern("macroexpand-1")

var Lit_337 *jrt.String = jrt.Intern("macroexpand")

var Lit_338 *jrt.String = jrt.Intern("create-struct")

var Lit_339 *jrt.String = jrt.Intern("load-reader")

var Lit_340 *jrt.String = jrt.Intern("set?")

var Lit_341 *jrt.String = jrt.Intern("find-ns")

var Lit_342 *jrt.String = jrt.Intern("the-ns")

var Lit_343 *jrt.String = jrt.Intern("filter-key")

var Lit_344 *jrt.String = jrt.Intern("ns-map")

var Lit_345 *jrt.String = jrt.Intern("partial")

var Lit_346 *jrt.String = jrt.Intern("java.lang.Class")

var Lit_347 *jrt.String = jrt.Intern("ns-publics")

var Lit_348 *jrt.String = jrt.Intern("rename")

var Lit_349 *jrt.String = jrt.Intern("set")

var Lit_350 *jrt.String = jrt.Intern("all")

var Lit_351 *jrt.String = jrt.Intern("refer")

var Lit_352 *jrt.String = jrt.Intern("only")

var Lit_353 *jrt.String = jrt.Intern("exclude")

var Lit_354 *jrt.String = jrt.Intern("ns-interns")

var Lit_355 *jrt.String = jrt.Intern("not=")

var Lit_356 *jrt.String = jrt.Intern("take-nth")

var Lit_357 *jrt.String = jrt.Intern("interleave")

var Lit_358 *jrt.String = jrt.Intern("arbace.lang.Var")

var Lit_359 *jrt.String = jrt.Intern("create")

var Lit_360 *jrt.String = jrt.Intern("setDynamic")

var Lit_361 *jrt.String = jrt.Intern("pushThreadBindings")

var Lit_362 *jrt.String = jrt.Intern("popThreadBindings")

var Lit_363 *jrt.String = jrt.Intern("contains?")

var Lit_364 *jrt.String = jrt.Intern("ns-resolve")

var Lit_365 *jrt.String = jrt.Intern("odd?")

var Lit_366 *jrt.String = jrt.Intern("repeatedly")

var Lit_367 *jrt.String = jrt.Intern("counted?")

var Lit_368 *jrt.String = jrt.Intern("reduce-kv")

var Lit_369 *jrt.String = jrt.Intern("some?")

var Lit_370 *jrt.String = jrt.Intern("some")

var Lit_371 *jrt.String = jrt.Intern("as")

var Lit_372 *jrt.String = jrt.Intern("zipmap")

var Lit_373 *jrt.String = jrt.Intern("select")

var Lit_374 *jrt.String = jrt.Intern("excess")

var Lit_375 *jrt.String = jrt.Intern("missing")

var Lit_376 *jrt.String = jrt.Intern("keyword")

var Lit_377 *jrt.String = jrt.Intern("symbol")

var Lit_378 *jrt.String = jrt.Intern("req!")

var Lit_379 *jrt.String = jrt.Intern("identical?")

var Lit_380 *jrt.String = jrt.Intern("ret")

var Lit_381 *jrt.String = jrt.Intern("sel")

var Lit_382 *jrt.String = jrt.Intern("b->k")

var Lit_383 *jrt.String = jrt.Intern("subs")

var Lit_384 *jrt.String = jrt.Intern("suba")

var Lit_385 *jrt.String = jrt.Intern("subexcess")

var Lit_386 *jrt.String = jrt.Intern("submissing")

var Lit_387 *jrt.String = jrt.Intern("empty?")

var Lit_388 *jrt.String = jrt.Intern("arbace.lang.ISeq")

var Lit_389 *jrt.String = jrt.Intern("defaults")

var Lit_390 *jrt.String = jrt.Intern("arbace.lang.PersistentArrayMap")

var Lit_391 *jrt.String = jrt.Intern("createAsIfByAssoc")

var Lit_392 *jrt.String = jrt.Intern("EMPTY")

var Lit_393 *jrt.String = jrt.Intern("Object")

var Lit_394 *jrt.String = jrt.Intern("vals")

var Lit_395 *jrt.String = jrt.Intern("select-keys")

var Lit_396 *jrt.String = jrt.Intern("mm__1927000956__auto__")

var Lit_397 *jrt.String = jrt.Intern("some-vals")

var Lit_398 *jrt.String = jrt.Intern("not-empty")

var Lit_399 *jrt.String = jrt.Intern("destvec*")

var Lit_400 *jrt.String = jrt.Intern("destmap*")

var Lit_401 *jrt.String = jrt.Intern("destructure")

var Lit_402 *jrt.String = jrt.Intern("pre")

var Lit_403 *jrt.String = jrt.Intern("post")

var Lit_404 *jrt.String = jrt.Intern("maybe-destructured")

var Lit_405 *jrt.String = jrt.Intern("%")

var Lit_406 *jrt.String = jrt.Intern("assert")

var Lit_407 *jrt.String = jrt.Intern("xs__1927001018__auto__")

var Lit_408 *jrt.String = jrt.Intern("lazy-seq")

var Lit_409 *jrt.String = jrt.Intern("pop")

var Lit_410 *jrt.String = jrt.Intern("peek")

var Lit_411 *jrt.String = jrt.Intern("iterys__1927001035__auto__")

var Lit_412 *jrt.String = jrt.Intern("fs__1927001036__auto__")

var Lit_413 *jrt.String = jrt.Intern("when-first")

var Lit_414 *jrt.String = jrt.Intern("c__1927001037__auto__")

var Lit_415 *jrt.String = jrt.Intern("size__1927001038__auto__")

var Lit_416 *jrt.String = jrt.Intern("iter__1927001039__auto__")

var Lit_417 *jrt.String = jrt.Intern("s__1927001093__auto__")

var Lit_418 *jrt.String = jrt.Intern("java.io.StringWriter")

var Lit_419 *jrt.String = jrt.Intern("binding")

var Lit_420 *jrt.String = jrt.Intern("s__1927001099__auto__")

var Lit_421 *jrt.String = jrt.Intern("->")

var Lit_422 *jrt.String = jrt.Intern("java.io.StringReader.")

var Lit_423 *jrt.String = jrt.Intern("arbace.lang.LineNumberingPushbackReader.")

var Lit_424 *jrt.String = jrt.Intern("print")

var Lit_425 *jrt.String = jrt.Intern("println")

var Lit_426 *jrt.String = jrt.Intern("java.lang.StackTraceElement")

var Lit_427 *jrt.String = jrt.Intern("elide-top-frames")

var Lit_428 *jrt.String = jrt.Intern("*assert*")

var Lit_429 *jrt.String = jrt.Intern("java.lang.AssertionError")

var Lit_430 *jrt.String = jrt.Intern("pr-str")

var Lit_431 *jrt.String = jrt.Intern("test")

var Lit_432 *jrt.String = jrt.Intern("ok")

var Lit_433 *jrt.String = jrt.Intern("no-test")

var Lit_434 *jrt.String = jrt.Intern("re-matcher")

var Lit_435 *jrt.String = jrt.Intern("re-groups")

var Lit_436 *jrt.String = jrt.Intern("re-find")

var Lit_437 *jrt.String = jrt.Intern("rand")

var Lit_438 *jrt.String = jrt.Intern("private")

var Lit_439 *jrt.String = jrt.Intern("mapcat")

var Lit_440 *jrt.String = jrt.Intern("tree-seq")

var Lit_441 *jrt.String = jrt.Intern("content")

var Lit_442 *jrt.String = jrt.Intern("find")

var Lit_443 *jrt.String = jrt.Intern("range")

var Lit_444 *jrt.String = jrt.Intern("sync")

var Lit_445 *jrt.String = jrt.Intern("rounding")

var Lit_446 *jrt.String = jrt.Intern("java.math.RoundingMode")

var Lit_447 *jrt.String = jrt.Intern("*math-context*")

var Lit_448 *jrt.String = jrt.Intern("java.math.MathContext.")

var Lit_449 *jrt.String = jrt.Intern("mk-bound-fn")

var Lit_450 *jrt.String = jrt.Intern("split-with")

var Lit_451 *jrt.String = jrt.Intern("eval")

var Lit_452 *jrt.String = jrt.Intern("alter-meta!")

var Lit_453 *jrt.String = jrt.Intern("a__1927001243__auto__")

var Lit_454 *jrt.String = jrt.Intern("l__1927001244__auto__")

var Lit_455 *jrt.String = jrt.Intern("a__1927001250__auto__")

var Lit_456 *jrt.String = jrt.Intern("l__1927001251__auto__")

var Lit_457 *jrt.String = jrt.Intern("unchecked-inc-int")

var Lit_458 *jrt.String = jrt.Intern("float_array")

var Lit_459 *jrt.String = jrt.Intern("boolean_array")

var Lit_460 *jrt.String = jrt.Intern("byte_array")

var Lit_461 *jrt.String = jrt.Intern("char_array")

var Lit_462 *jrt.String = jrt.Intern("short_array")

var Lit_463 *jrt.String = jrt.Intern("double_array")

var Lit_464 *jrt.String = jrt.Intern("object_array")

var Lit_465 *jrt.String = jrt.Intern("int_array")

var Lit_466 *jrt.String = jrt.Intern("long_array")

var Lit_467 *jrt.String = jrt.Intern("booleans")

var Lit_468 *jrt.String = jrt.Intern("bytes")

var Lit_469 *jrt.String = jrt.Intern("chars")

var Lit_470 *jrt.String = jrt.Intern("shorts")

var Lit_471 *jrt.String = jrt.Intern("floats")

var Lit_472 *jrt.String = jrt.Intern("ints")

var Lit_473 *jrt.String = jrt.Intern("doubles")

var Lit_474 *jrt.String = jrt.Intern("longs")

var Lit_475 *jrt.String = jrt.Intern("agent")

var Lit_476 *jrt.String = jrt.Intern("send-off")

var Lit_477 *jrt.String = jrt.Intern("release-pending-sends")

var Lit_478 *jrt.String = jrt.Intern("seque")

var Lit_479 *jrt.String = jrt.Intern("parents")

var Lit_480 *jrt.String = jrt.Intern("descendants")

var Lit_481 *jrt.String = jrt.Intern("ancestors")

var Lit_482 *jrt.String = jrt.Intern("bases")

var Lit_483 *jrt.String = jrt.Intern("into0")

var Lit_484 *jrt.String = jrt.Intern("class?")

var Lit_485 *jrt.String = jrt.Intern("supers")

var Lit_486 *jrt.String = jrt.Intern("isa?")

var Lit_487 *jrt.String = jrt.Intern("parent")

var Lit_488 *jrt.String = jrt.Intern("arbace.lang.Named")

var Lit_489 *jrt.String = jrt.Intern("print-str")

var Lit_490 *jrt.String = jrt.Intern("alter-var-root")

var Lit_491 *jrt.String = jrt.Intern("derive")

var Lit_492 *jrt.String = jrt.Intern("flatten")

var Lit_493 *jrt.String = jrt.Intern("interpose")

var Lit_494 *jrt.String = jrt.Intern("make-hierarchy")

var Lit_495 *jrt.String = jrt.Intern("underive")

var Lit_496 *jrt.String = jrt.Intern("struct")

var Lit_497 *jrt.String = jrt.Intern("distinct?")

var Lit_498 *jrt.String = jrt.Intern("java.lang.String")

var Lit_499 *jrt.String = jrt.Intern("format")

var Lit_500 *jrt.String = jrt.Intern("loading__1927001464__auto__")

var Lit_501 *jrt.String = jrt.Intern("arbace.lang.Compiler")

var Lit_502 *jrt.String = jrt.Intern("LOADER")

var Lit_503 *jrt.String = jrt.Intern(".getClassLoader")

var Lit_504 *jrt.String = jrt.Intern(".getClass")

var Lit_505 *jrt.String = jrt.Intern("java.lang.Object")

var Lit_506 *jrt.String = jrt.Intern("remove")

var Lit_507 *jrt.String = jrt.Intern("gen-class")

var Lit_508 *jrt.String = jrt.Intern("impl-ns")

var Lit_509 *jrt.String = jrt.Intern("main")

var Lit_510 *jrt.String = jrt.Intern("in-ns")

var Lit_511 *jrt.String = jrt.Intern(".resetMeta")

var Lit_512 *jrt.String = jrt.Intern("arbace.lang.Namespace")

var Lit_513 *jrt.String = jrt.Intern("not-any?")

var Lit_514 *jrt.String = jrt.Intern("with-loading-context")

var Lit_515 *jrt.String = jrt.Intern("refer-clojure")

var Lit_516 *jrt.String = jrt.Intern(".equals")

var Lit_517 *jrt.String = jrt.Intern("dosync")

var Lit_518 *jrt.String = jrt.Intern("commute")

var Lit_519 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_520 *jrt.String = jrt.Intern("v__1927001498__auto__")

var Lit_521 *jrt.String = jrt.Intern("*file*")

var Lit_522 *jrt.String = jrt.Intern("root-resource")

var Lit_523 *jrt.String = jrt.Intern("load")

var Lit_524 *jrt.String = jrt.Intern("throw-if")

var Lit_525 *jrt.String = jrt.Intern("load-one")

var Lit_526 *jrt.String = jrt.Intern("sorted-set")

var Lit_527 *jrt.String = jrt.Intern("reload")

var Lit_528 *jrt.String = jrt.Intern("reload-all")

var Lit_529 *jrt.String = jrt.Intern("require")

var Lit_530 *jrt.String = jrt.Intern("use")

var Lit_531 *jrt.String = jrt.Intern("verbose")

var Lit_532 *jrt.String = jrt.Intern("as-alias")

var Lit_533 *jrt.String = jrt.Intern("load-all")

var Lit_534 *jrt.String = jrt.Intern("create-ns")

var Lit_535 *jrt.String = jrt.Intern("*loading-verbosely*")

var Lit_536 *jrt.String = jrt.Intern("remove-ns")

var Lit_537 *jrt.String = jrt.Intern("printf")

var Lit_538 *jrt.String = jrt.Intern("alias")

var Lit_539 *jrt.String = jrt.Intern("ns-name")

var Lit_540 *jrt.String = jrt.Intern("libspec?")

var Lit_541 *jrt.String = jrt.Intern("load-lib")

var Lit_542 *jrt.String = jrt.Intern("prependss")

var Lit_543 *jrt.String = jrt.Intern("*pending-paths*")

var Lit_544 *jrt.String = jrt.Intern("load-libs")

var Lit_545 *jrt.String = jrt.Intern("qualified-symbol?")

var Lit_546 *jrt.String = jrt.Intern("resolve")

var Lit_547 *jrt.String = jrt.Intern("serialized-require")

var Lit_548 *jrt.String = jrt.Intern("root-directory")

var Lit_549 *jrt.String = jrt.Intern("check-cyclic-dependency")

var Lit_550 *jrt.String = jrt.Intern("*compile-files*")

var Lit_551 *jrt.String = jrt.Intern("assoc-in")

var Lit_552 *jrt.String = jrt.Intern("trampoline")

var Lit_553 *jrt.String = jrt.Intern("fn?")

var Lit_554 *jrt.String = jrt.Intern("swap!")

var Lit_555 *jrt.String = jrt.Intern("split-at")

var Lit_556 *jrt.String = jrt.Intern(">>")

var Lit_557 *jrt.String = jrt.Intern("p__1927001616__auto__")

var Lit_558 *jrt.String = jrt.Intern("letfn*")

var Lit_559 *jrt.String = jrt.Intern("shift-mask")

var Lit_560 *jrt.String = jrt.Intern("max-mask-bits")

var Lit_561 *jrt.String = jrt.Intern("sorted-map")

var Lit_562 *jrt.String = jrt.Intern("max-switch-table-size")

var Lit_563 *jrt.String = jrt.Intern("fits-table?")

var Lit_564 *jrt.String = jrt.Intern("maybe-min-hash")

var Lit_565 *jrt.String = jrt.Intern("case-map")

var Lit_566 *jrt.String = jrt.Intern("compact")

var Lit_567 *jrt.String = jrt.Intern("sparse")

var Lit_568 *jrt.String = jrt.Intern("update")

var Lit_569 *jrt.String = jrt.Intern("fnil")

var Lit_570 *jrt.String = jrt.Intern("condp")

var Lit_571 *jrt.String = jrt.Intern("ffirst")

var Lit_572 *jrt.String = jrt.Intern("merge-hash-collisions")

var Lit_573 *jrt.String = jrt.Intern("prep-hashes")

var Lit_574 *jrt.String = jrt.Intern("hashes")

var Lit_575 *jrt.String = jrt.Intern("prep-ints")

var Lit_576 *jrt.String = jrt.Intern("case*")

var Lit_577 *jrt.String = jrt.Intern("hash-equiv")

var Lit_578 *jrt.String = jrt.Intern("hash-identity")

var Lit_579 *jrt.String = jrt.Intern("arbace.core.protocols")

var Lit_580 *jrt.String = jrt.Intern("iterator-reduce!")

var Lit_581 *jrt.String = jrt.Intern("iterator-seq")

var Lit_582 *jrt.String = jrt.Intern("stream-reduce!")

var Lit_583 *jrt.String = jrt.Intern("stream-transduce!")

var Lit_584 *jrt.String = jrt.Intern("forName")

var Lit_585 *jrt.String = jrt.Intern("catch")

var Lit_586 *jrt.String = jrt.Intern("java.lang.ClassNotFoundException")

var Lit_587 *jrt.String = jrt.Intern("___1927001817__auto__")

var Lit_588 *jrt.String = jrt.Intern("-cache-protocol-fn")

var Lit_589 *jrt.String = jrt.Intern("arbace.core.Inst")

var Lit_590 *jrt.String = jrt.Intern("inst-ms*")

var Lit_591 *jrt.String = jrt.Intern("satisfies?")

var Lit_592 *jrt.String = jrt.Intern("Inst")

var Lit_593 *jrt.String = jrt.Intern("coll-reduce")

var Lit_594 *jrt.String = jrt.Intern("reduce")

var Lit_595 *jrt.String = jrt.Intern("kv-reduce")

var Lit_596 *jrt.String = jrt.Intern("completing")

var Lit_597 *jrt.String = jrt.Intern("transduce")

var Lit_598 *jrt.String = jrt.Intern("into")

var Lit_599 *jrt.String = jrt.Intern("merge-deep")

var Lit_600 *jrt.String = jrt.Intern("merge-deep-with")

var Lit_601 *jrt.String = jrt.Intern("encoding")

var Lit_602 *jrt.String = jrt.Intern("normalize-slurp-opts")

var Lit_603 *jrt.String = jrt.Intern("arbace.java.io")

var Lit_604 *jrt.String = jrt.Intern("reader")

var Lit_605 *jrt.String = jrt.Intern("copy")

var Lit_606 *jrt.String = jrt.Intern("writer")

var Lit_607 *jrt.String = jrt.Intern("future-call")

var Lit_608 *jrt.String = jrt.Intern("pmap")

var Lit_609 *jrt.String = jrt.Intern("pcalls")

var Lit_610 *jrt.String = jrt.Intern("major")

var Lit_611 *jrt.String = jrt.Intern("*clojure-version*")

var Lit_612 *jrt.String = jrt.Intern("minor")

var Lit_613 *jrt.String = jrt.Intern("incremental")

var Lit_614 *jrt.String = jrt.Intern("qualifier")

var Lit_615 *jrt.String = jrt.Intern("interim")

var Lit_616 *jrt.String = jrt.Intern("read-string")

var Lit_617 *jrt.String = jrt.Intern("*read-eval*")

var Lit_618 *jrt.String = jrt.Intern("java.lang.ClassLoader")

var Lit_619 *jrt.String = jrt.Intern("describe")

var Lit_620 *jrt.String = jrt.Intern("unknown")

var Lit_621 *jrt.String = jrt.Intern("commit")

var Lit_622 *jrt.String = jrt.Intern("dirty")

var Lit_623 *jrt.String = jrt.Intern("*arbace-version*")

var Lit_624 *jrt.String = jrt.Intern("compare-and-set!")

var Lit_625 *jrt.String = jrt.Intern("sequential?")

var Lit_626 *jrt.String = jrt.Intern("partition-by")

var Lit_627 *jrt.String = jrt.Intern("none")

var Lit_628 *jrt.String = jrt.Intern("unreduced")

var Lit_629 *jrt.String = jrt.Intern("reductions")

var Lit_630 *jrt.String = jrt.Intern("rand-int")

var Lit_631 *jrt.String = jrt.Intern("partition-all")

var Lit_632 *jrt.String = jrt.Intern("partitionv")

var Lit_633 *jrt.String = jrt.Intern("partitionv-all")

var Lit_634 *jrt.String = jrt.Intern("keep")

var Lit_635 *jrt.String = jrt.Intern("with-redefs-fn")

var Lit_636 *jrt.String = jrt.Intern("clauses")

var Lit_637 *jrt.String = jrt.Intern("->>")

var Lit_638 *jrt.String = jrt.Intern("preserving-reduced")

var Lit_639 *jrt.String = jrt.Intern("halt")

var Lit_640 *jrt.String = jrt.Intern("halt-when")

var Lit_641 *jrt.String = jrt.Intern("sequence")

var Lit_642 *jrt.String = jrt.Intern("dedupe")

var Lit_643 *jrt.String = jrt.Intern("print-sequential")

var Lit_644 *jrt.String = jrt.Intern("print-object")

var Lit_645 *jrt.String = jrt.Intern("somef")

var Lit_646 *jrt.String = jrt.Intern("vf")

var Lit_647 *jrt.String = jrt.Intern("kf")

var Lit_648 *jrt.String = jrt.Intern("initk")

var Lit_649 *jrt.String = jrt.Intern("java.lang.Thread")

var Lit_650 *jrt.String = jrt.Intern("enumeration-seq")

var Lit_651 *jrt.String = jrt.Intern("intern")

var Lit_652 *jrt.String = jrt.Intern("eof")

var Lit_653 *jrt.String = jrt.Intern("read-cond")

var Lit_654 *jrt.String = jrt.Intern("allow")

var Lit_655 *jrt.String = jrt.Intern("ex-info")

var Lit_656 *jrt.String = jrt.Intern("url")

var Lit_657 *jrt.String = jrt.Intern("data-reader-var")

var Lit_658 *jrt.String = jrt.Intern("form")

var Lit_659 *jrt.String = jrt.Intern("conflict")

var Lit_660 *jrt.String = jrt.Intern("mappings")

var Lit_661 *jrt.String = jrt.Intern("*data-readers*")

var Lit_662 *jrt.String = jrt.Intern("load-data-reader-file")

var Lit_663 *jrt.String = jrt.Intern("data-reader-urls")

var Lit_664 *jrt.String = jrt.Intern("tapq")

var Lit_665 *jrt.String = jrt.Intern("tap-nil")

var Lit_666 *jrt.String = jrt.Intern("tapset")

var Lit_667 *jrt.String = jrt.Intern("force")

var Lit_668 *jrt.String = jrt.Intern("tap-loop")

var Lit_669 *jrt.String = jrt.Intern("tap>")

var Lit_670 *jrt.String = jrt.Intern("parsing-err")

var Lit_671 *jrt.String = jrt.Intern("java.lang.Double")

var Lit_672 *jrt.String = jrt.Intern("isNaN")

var Lit_673 *jrt.String = jrt.Intern("isInfinite")

var Lit_674 *jrt.String = jrt.Intern("map__1927002287__auto__")

var Lit_675 *jrt.String = jrt.Intern("selector-impl")

var Lit_676 *jrt.String = jrt.Intern("hash")

var Lit_677 *jrt.String = jrt.Intern("method-sig")

var Lit_678 *jrt.String = jrt.Intern("group-by-sig")

var Lit_679 *jrt.String = jrt.Intern("super")

var Lit_680 *jrt.String = jrt.Intern("ifaces")

var Lit_681 *jrt.String = jrt.Intern("bridges")

var Lit_682 *jrt.String = jrt.Intern("most-specific")

var Lit_683 *jrt.String = jrt.Intern("toString")

var Lit_684 *jrt.String = jrt.Intern("hashCode")

var Lit_685 *jrt.String = jrt.Intern("equals")

var Lit_686 *jrt.String = jrt.Intern("proxy-super-marker")

var Lit_687 *jrt.String = jrt.Intern("proxy-methods")

var Lit_688 *jrt.String = jrt.Intern("arbace.lang.IProxy")

var Lit_689 *jrt.String = jrt.Intern("arbace.lang.IPersistentMap")

var Lit_690 *jrt.String = jrt.Intern("proxy-method-fn")

var Lit_691 *jrt.String = jrt.Intern("set-proxy-method")

var Lit_692 *jrt.String = jrt.Intern("get-super-and-interfaces")

var Lit_693 *jrt.String = jrt.Intern("proxy-name")

var Lit_694 *jrt.String = jrt.Intern("define-proxy")

var Lit_695 *jrt.String = jrt.Intern("get-proxy-class")

var Lit_696 *jrt.String = jrt.Intern("java.lang.UnsupportedOperationException.")

var Lit_697 *jrt.String = jrt.Intern("p__840000142__auto__")

var Lit_698 *jrt.String = jrt.Intern("init-proxy")

var Lit_699 *jrt.String = jrt.Intern("this")

var Lit_700 *jrt.String = jrt.Intern("proxy-mappings")

var Lit_701 *jrt.String = jrt.Intern("update-proxy")

var Lit_702 *jrt.String = jrt.Intern("proxy-call-with-super")

var Lit_703 *jrt.String = jrt.Intern("bean-accessible-method")

var Lit_704 *jrt.String = jrt.Intern("bean-exported?")

var Lit_705 *jrt.String = jrt.Intern("java.lang.Cloneable")

var Lit_706 *jrt.String = jrt.Intern("java.lang.Comparable")

var Lit_707 *jrt.String = jrt.Intern("java.lang.AutoCloseable")

var Lit_708 *jrt.String = jrt.Intern("java.io.Closeable")

var Lit_709 *jrt.String = jrt.Intern("bean-class-methods")

var Lit_710 *jrt.String = jrt.Intern("bean-decapitalize")

var Lit_711 *jrt.String = jrt.Intern("bean-class-reads")

var Lit_712 *jrt.String = jrt.Intern("reverse")

var Lit_713 *jrt.String = jrt.Intern("bean-properties")

var Lit_714 *jrt.String = jrt.Intern("*print-level*")

var Lit_715 *jrt.String = jrt.Intern("*print-length*")

var Lit_716 *jrt.String = jrt.Intern("*print-meta*")

var Lit_717 *jrt.String = jrt.Intern("print-meta")

var Lit_718 *jrt.String = jrt.Intern("print-simple")

var Lit_719 *jrt.String = jrt.Intern("print-tagged-object")

var Lit_720 *jrt.String = jrt.Intern("print-ctor")

var Lit_721 *jrt.String = jrt.Intern("char-escape-string")

var Lit_722 *jrt.String = jrt.Intern("print-prefix-map")

var Lit_723 *jrt.String = jrt.Intern("*print-namespace-maps*")

var Lit_724 *jrt.String = jrt.Intern("qualified-ident?")

var Lit_725 *jrt.String = jrt.Intern("strip-ns")

var Lit_726 *jrt.String = jrt.Intern("lift-ns")

var Lit_727 *jrt.String = jrt.Intern("print-map")

var Lit_728 *jrt.String = jrt.Intern("*verbose-defrecords*")

var Lit_729 *jrt.String = jrt.Intern("char-name-string")

var Lit_730 *jrt.String = jrt.Intern("primitives-classnames")

var Lit_731 *jrt.String = jrt.Intern("status")

var Lit_732 *jrt.String = jrt.Intern("failed")

var Lit_733 *jrt.String = jrt.Intern("pending")

var Lit_734 *jrt.String = jrt.Intern("ready")

var Lit_735 *jrt.String = jrt.Intern("deref-as-map")

var Lit_736 *jrt.String = jrt.Intern("message")

var Lit_737 *jrt.String = jrt.Intern("ex-data")

var Lit_738 *jrt.String = jrt.Intern("data")

var Lit_739 *jrt.String = jrt.Intern("at")

var Lit_740 *jrt.String = jrt.Intern("StackTraceElement->vec")

var Lit_741 *jrt.String = jrt.Intern("via")

var Lit_742 *jrt.String = jrt.Intern("trace")

var Lit_743 *jrt.String = jrt.Intern("cause")

var Lit_744 *jrt.String = jrt.Intern("arbace.error")

var Lit_745 *jrt.String = jrt.Intern("phase")

var Lit_746 *jrt.String = jrt.Intern("Throwable->map")

var Lit_747 *jrt.String = jrt.Intern("print-throwable")

var Lit_748 *jrt.String = jrt.Intern("splicing?")

var Lit_749 *jrt.String = jrt.Intern("PrintWriter-on")

var Lit_750 *jrt.String = jrt.Intern("prim->class")

var Lit_751 *jrt.String = jrt.Intern("the-array-class")

var Lit_752 *jrt.String = jrt.Intern("extends")

var Lit_753 *jrt.String = jrt.Intern("methods")

var Lit_754 *jrt.String = jrt.Intern("the-class")

var Lit_755 *jrt.String = jrt.Intern("objects")

var Lit_756 *jrt.String = jrt.Intern("resolve-unqualified-class-tag")

var Lit_757 *jrt.String = jrt.Intern("namespace-munge")

var Lit_758 *jrt.String = jrt.Intern("gen-interface")

var Lit_759 *jrt.String = jrt.Intern("import")

var Lit_760 *jrt.String = jrt.Intern("parse-opts")

var Lit_761 *jrt.String = jrt.Intern("parse-impls")

var Lit_762 *jrt.String = jrt.Intern("var?")

var Lit_763 *jrt.String = jrt.Intern("on")

var Lit_764 *jrt.String = jrt.Intern("load-ns")

var Lit_765 *jrt.String = jrt.Intern("no-print")

var Lit_766 *jrt.String = jrt.Intern("parse-opts+specs")

var Lit_767 *jrt.String = jrt.Intern("reify*")

var Lit_768 *jrt.String = jrt.Intern("map-entry?")

var Lit_769 *jrt.String = jrt.Intern("arbace.lang.IRecord")

var Lit_770 *jrt.String = jrt.Intern("arbace.lang.IHashEq")

var Lit_771 *jrt.String = jrt.Intern("hasheq")

var Lit_772 *jrt.String = jrt.Intern("this__231000057__auto__")

var Lit_773 *jrt.String = jrt.Intern("hq__231000058__auto__")

var Lit_774 *jrt.String = jrt.Intern("__hasheq")

var Lit_775 *jrt.String = jrt.Intern("zero?")

var Lit_776 *jrt.String = jrt.Intern("h__231000059__auto__")

var Lit_777 *jrt.String = jrt.Intern("arbace.lang.APersistentMap")

var Lit_778 *jrt.String = jrt.Intern("mapHasheq")

var Lit_779 *jrt.String = jrt.Intern("set!")

var Lit_780 *jrt.String = jrt.Intern("this__231000060__auto__")

var Lit_781 *jrt.String = jrt.Intern("hash__231000061__auto__")

var Lit_782 *jrt.String = jrt.Intern("__hash")

var Lit_783 *jrt.String = jrt.Intern("h__231000062__auto__")

var Lit_784 *jrt.String = jrt.Intern("mapHash")

var Lit_785 *jrt.String = jrt.Intern("this__231000063__auto__")

var Lit_786 *jrt.String = jrt.Intern("mapEquals")

var Lit_787 *jrt.String = jrt.Intern("arbace.lang.IObj")

var Lit_788 *jrt.String = jrt.Intern("this__231000064__auto__")

var Lit_789 *jrt.String = jrt.Intern("__meta")

var Lit_790 *jrt.String = jrt.Intern("withMeta")

var Lit_791 *jrt.String = jrt.Intern("this__231000065__auto__")

var Lit_792 *jrt.String = jrt.Intern("replace")

var Lit_793 *jrt.String = jrt.Intern("arbace.lang.ILookup")

var Lit_794 *jrt.String = jrt.Intern("arbace.lang.IKeywordLookup")

var Lit_795 *jrt.String = jrt.Intern("valAt")

var Lit_796 *jrt.String = jrt.Intern("this__231000066__auto__")

var Lit_797 *jrt.String = jrt.Intern("k__231000067__auto__")

var Lit_798 *jrt.String = jrt.Intern(".valAt")

var Lit_799 *jrt.String = jrt.Intern("this__231000068__auto__")

var Lit_800 *jrt.String = jrt.Intern("k__231000069__auto__")

var Lit_801 *jrt.String = jrt.Intern("else__231000070__auto__")

var Lit_802 *jrt.String = jrt.Intern("case")

var Lit_803 *jrt.String = jrt.Intern("__extmap")

var Lit_804 *jrt.String = jrt.Intern("getLookupThunk")

var Lit_805 *jrt.String = jrt.Intern("this__231000071__auto__")

var Lit_806 *jrt.String = jrt.Intern("k__231000072__auto__")

var Lit_807 *jrt.String = jrt.Intern("gclass")

var Lit_808 *jrt.String = jrt.Intern("gtarget")

var Lit_809 *jrt.String = jrt.Intern("reify")

var Lit_810 *jrt.String = jrt.Intern("arbace.lang.ILookupThunk")

var Lit_811 *jrt.String = jrt.Intern("thunk")

var Lit_812 *jrt.String = jrt.Intern("this__231000073__auto__")

var Lit_813 *jrt.String = jrt.Intern("empty")

var Lit_814 *jrt.String = jrt.Intern("this__231000074__auto__")

var Lit_815 *jrt.String = jrt.Intern("this__231000075__auto__")

var Lit_816 *jrt.String = jrt.Intern("e__231000076__auto__")

var Lit_817 *jrt.String = jrt.Intern("imap-cons")

var Lit_818 *jrt.String = jrt.Intern("this__231000077__auto__")

var Lit_819 *jrt.String = jrt.Intern("boolean")

var Lit_820 *jrt.String = jrt.Intern("containsKey")

var Lit_821 *jrt.String = jrt.Intern("this__231000078__auto__")

var Lit_822 *jrt.String = jrt.Intern("k__231000079__auto__")

var Lit_823 *jrt.String = jrt.Intern("entryAt")

var Lit_824 *jrt.String = jrt.Intern("this__231000080__auto__")

var Lit_825 *jrt.String = jrt.Intern("k__231000081__auto__")

var Lit_826 *jrt.String = jrt.Intern("v__231000082__auto__")

var Lit_827 *jrt.String = jrt.Intern("arbace.lang.MapEntry")

var Lit_828 *jrt.String = jrt.Intern("this__231000084__auto__")

var Lit_829 *jrt.String = jrt.Intern("iterator")

var Lit_830 *jrt.String = jrt.Intern("arbace.lang.RecordIterator.")

var Lit_831 *jrt.String = jrt.Intern("iter")

var Lit_832 *jrt.String = jrt.Intern("this__231000085__auto__")

var Lit_833 *jrt.String = jrt.Intern("k__231000086__auto__")

var Lit_834 *jrt.String = jrt.Intern("without")

var Lit_835 *jrt.String = jrt.Intern("this__231000087__auto__")

var Lit_836 *jrt.String = jrt.Intern("k__231000088__auto__")

var Lit_837 *jrt.String = jrt.Intern("java.util.Map")

var Lit_838 *jrt.String = jrt.Intern("java.io.Serializable")

var Lit_839 *jrt.String = jrt.Intern("size")

var Lit_840 *jrt.String = jrt.Intern("this__231000089__auto__")

var Lit_841 *jrt.String = jrt.Intern(".count")

var Lit_842 *jrt.String = jrt.Intern("isEmpty")

var Lit_843 *jrt.String = jrt.Intern("this__231000090__auto__")

var Lit_844 *jrt.String = jrt.Intern("containsValue")

var Lit_845 *jrt.String = jrt.Intern("this__231000091__auto__")

var Lit_846 *jrt.String = jrt.Intern("v__231000092__auto__")

var Lit_847 *jrt.String = jrt.Intern("this__231000093__auto__")

var Lit_848 *jrt.String = jrt.Intern("k__231000094__auto__")

var Lit_849 *jrt.String = jrt.Intern("put")

var Lit_850 *jrt.String = jrt.Intern("this__231000095__auto__")

var Lit_851 *jrt.String = jrt.Intern("k__231000096__auto__")

var Lit_852 *jrt.String = jrt.Intern("v__231000097__auto__")

var Lit_853 *jrt.String = jrt.Intern("this__231000098__auto__")

var Lit_854 *jrt.String = jrt.Intern("k__231000099__auto__")

var Lit_855 *jrt.String = jrt.Intern("putAll")

var Lit_856 *jrt.String = jrt.Intern("this__231000100__auto__")

var Lit_857 *jrt.String = jrt.Intern("m__231000101__auto__")

var Lit_858 *jrt.String = jrt.Intern("clear")

var Lit_859 *jrt.String = jrt.Intern("this__231000102__auto__")

var Lit_860 *jrt.String = jrt.Intern("keySet")

var Lit_861 *jrt.String = jrt.Intern("this__231000103__auto__")

var Lit_862 *jrt.String = jrt.Intern("values")

var Lit_863 *jrt.String = jrt.Intern("this__231000104__auto__")

var Lit_864 *jrt.String = jrt.Intern("entrySet")

var Lit_865 *jrt.String = jrt.Intern("this__231000105__auto__")

var Lit_866 *jrt.String = jrt.Intern("unsynchronized-mutable")

var Lit_867 *jrt.String = jrt.Intern("volatile-mutable")

var Lit_868 *jrt.String = jrt.Intern("deftype*")

var Lit_869 *jrt.String = jrt.Intern("implements")

var Lit_870 *jrt.String = jrt.Intern("overage")

var Lit_871 *jrt.String = jrt.Intern("arbace.lang.ArityException.")

var Lit_872 *jrt.String = jrt.Intern("validate-fields")

var Lit_873 *jrt.String = jrt.Intern("declare")

var Lit_874 *jrt.String = jrt.Intern("map->")

var Lit_875 *jrt.String = jrt.Intern("emit-defrecord")

var Lit_876 *jrt.String = jrt.Intern("build-positional-factory")

var Lit_877 *jrt.String = jrt.Intern("m__231000174__auto__")

var Lit_878 *jrt.String = jrt.Intern("arbace.lang.MapEquivalence")

var Lit_879 *jrt.String = jrt.Intern("arbace.lang.IType")

var Lit_880 *jrt.String = jrt.Intern("emit-deftype*")

var Lit_881 *jrt.String = jrt.Intern("super-chain")

var Lit_882 *jrt.String = jrt.Intern("impls")

var Lit_883 *jrt.String = jrt.Intern("on-interface")

var Lit_884 *jrt.String = jrt.Intern("pref")

var Lit_885 *jrt.String = jrt.Intern("find-protocol-impl")

var Lit_886 *jrt.String = jrt.Intern("implements?")

var Lit_887 *jrt.String = jrt.Intern("find-protocol-method")

var Lit_888 *jrt.String = jrt.Intern("expand-method-impl-cache")

var Lit_889 *jrt.String = jrt.Intern("arbace.lang.AFunction")

var Lit_890 *jrt.String = jrt.Intern("cache__231000238__auto__")

var Lit_891 *jrt.String = jrt.Intern("f__231000239__auto__")

var Lit_892 *jrt.String = jrt.Intern("cache__231000232__auto__")

var Lit_893 *jrt.String = jrt.Intern(".__methodImplCache")

var Lit_894 *jrt.String = jrt.Intern("f__231000233__auto__")

var Lit_895 *jrt.String = jrt.Intern(".fnFor")

var Lit_896 *jrt.String = jrt.Intern("classOf")

var Lit_897 *jrt.String = jrt.Intern("meta__231000234__auto__")

var Lit_898 *jrt.String = jrt.Intern("m__231000235__auto__")

var Lit_899 *jrt.String = jrt.Intern(".sym")

var Lit_900 *jrt.String = jrt.Intern("cache__231000236__auto__")

var Lit_901 *jrt.String = jrt.Intern("f__231000237__auto__")

var Lit_902 *jrt.String = jrt.Intern("method-builders")

var Lit_903 *jrt.String = jrt.Intern("protocol")

var Lit_904 *jrt.String = jrt.Intern("bound?")

var Lit_905 *jrt.String = jrt.Intern("*err*")

var Lit_906 *jrt.String = jrt.Intern("munge")

var Lit_907 *jrt.String = jrt.Intern("char")

var Lit_908 *jrt.String = jrt.Intern("short")

var Lit_909 *jrt.String = jrt.Intern("float")

var Lit_910 *jrt.String = jrt.Intern("void")

var Lit_911 *jrt.String = jrt.Intern("byte")

var Lit_912 *jrt.String = jrt.Intern("update-in")

var Lit_913 *jrt.String = jrt.Intern("defonce")

var Lit_914 *jrt.String = jrt.Intern("assert-same-protocol")

var Lit_915 *jrt.String = jrt.Intern("method-map")

var Lit_916 *jrt.String = jrt.Intern("emit-method-builder")

var Lit_917 *jrt.String = jrt.Intern("extend-via-metadata")

var Lit_918 *jrt.String = jrt.Intern("-reset-methods")

var Lit_919 *jrt.String = jrt.Intern("emit-protocol")

var Lit_920 *jrt.String = jrt.Intern("protocol?")

var Lit_921 *jrt.String = jrt.Intern("extend")

var Lit_922 *jrt.String = jrt.Intern("emit-hinted-impl")

var Lit_923 *jrt.String = jrt.Intern("emit-extend-type")

var Lit_924 *jrt.String = jrt.Intern("extend-type")

var Lit_925 *jrt.String = jrt.Intern("emit-extend-protocol")

var Lit_926 *jrt.String = jrt.Intern("arbace.lang.IPersistentVector")

var Lit_927 *jrt.String = jrt.Intern("arbace.core.ArrayManager")

var Lit_928 *jrt.String = jrt.Intern("_")

var Lit_929 *jrt.String = jrt.Intern("size__57000061__auto__")

var Lit_930 *jrt.String = jrt.Intern("i__57000062__auto__")

var Lit_931 *jrt.String = jrt.Intern("val__57000063__auto__")

var Lit_932 *jrt.String = jrt.Intern("am__57000093__auto__")

var Lit_933 *jrt.String = jrt.Intern("ams")

var Lit_934 *jrt.String = jrt.Intern("vector-of")

var Lit_935 *jrt.String = jrt.Intern("EMPTY-NODE")

var Lit_936 *jrt.String = jrt.Intern("class*")

var Lit_937 *jrt.String = jrt.Intern("top")

var Lit_938 *jrt.String = jrt.Intern("tops")

var Lit_939 *jrt.String = jrt.Intern("anon")

var Lit_940 *jrt.String = jrt.Intern("local")

var Lit_941 *jrt.String = jrt.Intern("label*")

var Lit_942 *jrt.String = jrt.Intern("break*")

var Lit_943 *jrt.String = jrt.Intern("continue*")

var Lit_944 *jrt.String = jrt.Intern("return*")

var Lit_945 *jrt.String = jrt.Intern("switch*")

var Lit_946 *jrt.String = jrt.Intern("lambda*")

var Lit_947 *jrt.String = jrt.Intern("method-ref*")

var Lit_948 *jrt.String = jrt.Intern("java-str*")

var Lit_949 *jrt.String = jrt.Intern("java-assert*")

var Lit_950 *jrt.String = jrt.Intern("for-each*")

var Lit_951 *jrt.String = jrt.Intern("with-resources*")

var Lit_952 *jrt.String = jrt.Intern("if-instance*")

var Lit_953 *jrt.String = jrt.Intern("added")

var Lit_954 *jrt.String = jrt.Intern("inline-arities")

var Lit_955 *jrt.String = jrt.Intern("andInt")

var Lit_956 *jrt.String = jrt.Intern("orInt")

var Lit_957 *jrt.String = jrt.Intern("xorInt")

var Lit_958 *jrt.String = jrt.Intern("notInt")

var Lit_959 *jrt.String = jrt.Intern("shiftLeftInt")

var Lit_960 *jrt.String = jrt.Intern("shiftRightInt")

var Lit_961 *jrt.String = jrt.Intern("unsignedShiftRightInt")

var Lit_962 *jrt.String = jrt.Intern("unchecked_divide")

var Lit_963 *jrt.String = jrt.Intern("unchecked_remainder")

var Lit_964 *jrt.String = jrt.Intern("unchecked_float_add")

var Lit_965 *jrt.String = jrt.Intern("unchecked_float_subtract")

var Lit_966 *jrt.String = jrt.Intern("unchecked_float_multiply")

var Lit_967 *jrt.String = jrt.Intern("unchecked_float_divide")

var Lit_968 *jrt.String = jrt.Intern("unchecked_float_remainder")

var Lit_969 *jrt.String = jrt.Intern("unchecked_float_negate")

var Lit_970 *jrt.String = jrt.Intern("arbace.core$NaN_QMARK_")

var Lit_971 *jrt.String = jrt.Intern("arbace.core$NaN_QMARK___inliner__1927002281")

var Lit_972 *jrt.String = jrt.Intern("arbace.core$PrintWriter_on")

var Lit_973 *jrt.String = jrt.Intern("arbace.core.proxy$java.io.Writer$ff19274a")

var Lit_974 *jrt.String = jrt.Intern("write")

var Lit_975 *jrt.String = jrt.Intern("arbace.core$PrintWriter_on$fn__1769000390")

var Lit_976 *jrt.String = jrt.Intern("arbace.core$PrintWriter_on$fn__1769000392")

var Lit_977 *jrt.String = jrt.Intern("arbace.core$PrintWriter_on$fn__1769000394")

var Lit_978 *jrt.String = jrt.Intern("arbace.core$StackTraceElement__GT_vec")

var Lit_979 *jrt.String = jrt.Intern("arbace.core$Throwable__GT_map")

var Lit_980 *jrt.String = jrt.Intern("arbace.core$Throwable__GT_map$base__1769000355")

var Lit_981 *jrt.String = jrt.Intern("arbace.core$Throwable__GT_map$fn__1769000357")

var Lit_982 *jrt.String = jrt.Intern("arbace.core$_")

var Lit_983 *jrt.String = jrt.Intern("arbace.core$_DOT__DOT_")

var Lit_984 *jrt.String = jrt.Intern("arbace.core$_EQ_")

var Lit_985 *jrt.String = jrt.Intern("arbace.core$_EQ__EQ_")

var Lit_986 *jrt.String = jrt.Intern("arbace.core$_EQ__EQ___inliner__1927000226")

var Lit_987 *jrt.String = jrt.Intern("arbace.core$_EQ___inliner__1927000161")

var Lit_988 *jrt.String = jrt.Intern("arbace.core$_GT_")

var Lit_989 *jrt.String = jrt.Intern("arbace.core$_GT_0_QMARK_")

var Lit_990 *jrt.String = jrt.Intern("arbace.core$_GT_1_QMARK_")

var Lit_991 *jrt.String = jrt.Intern("arbace.core$_GT__EQ_")

var Lit_992 *jrt.String = jrt.Intern("arbace.core$_GT__EQ___inliner__1927000223")

var Lit_993 *jrt.String = jrt.Intern("arbace.core$_GT___inliner__1927000220")

var Lit_994 *jrt.String = jrt.Intern("arbace.core$_LT_")

var Lit_995 *jrt.String = jrt.Intern("arbace.core$_LT__EQ_")

var Lit_996 *jrt.String = jrt.Intern("arbace.core$_LT__EQ___inliner__1927000217")

var Lit_997 *jrt.String = jrt.Intern("arbace.core$_LT___inliner__1927000192")

var Lit_998 *jrt.String = jrt.Intern("arbace.core$_PLUS_")

var Lit_999 *jrt.String = jrt.Intern("arbace.core$_PLUS__SINGLEQUOTE_")

var Lit_1000 *jrt.String = jrt.Intern("arbace.core$_SLASH_")

var Lit_1001 *jrt.String = jrt.Intern("arbace.core$_STAR_")

var Lit_1002 *jrt.String = jrt.Intern("arbace.core$_STAR__SINGLEQUOTE_")

var Lit_1003 *jrt.String = jrt.Intern("arbace.core$__GT_")

var Lit_1004 *jrt.String = jrt.Intern("arbace.core$__GT__GT_")

var Lit_1005 *jrt.String = jrt.Intern("arbace.core$__SINGLEQUOTE_")

var Lit_1006 *jrt.String = jrt.Intern("arbace.core$_cache_protocol_fn")

var Lit_1007 *jrt.String = jrt.Intern("No implementation of method: ")

var Lit_1008 *jrt.String = jrt.Intern(" of protocol: ")

var Lit_1009 *jrt.String = jrt.Intern(" found for class: ")

var Lit_1010 *jrt.String = jrt.Intern("nil")

var Lit_1011 *jrt.String = jrt.Intern("arbace.core$_reset_methods")

var Lit_1012 *jrt.String = jrt.Intern("arbace.core$abs")

var Lit_1013 *jrt.String = jrt.Intern("arbace.core$abs__inliner__1927000231")

var Lit_1014 *jrt.String = jrt.Intern("arbace.core$accessor")

var Lit_1015 *jrt.String = jrt.Intern("arbace.core$aclone")

var Lit_1016 *jrt.String = jrt.Intern("arbace.core$aclone__inliner__1927000847")

var Lit_1017 *jrt.String = jrt.Intern("arbace.core$add_classpath")

var Lit_1018 *jrt.String = jrt.Intern("WARNING: add-classpath is deprecated")

var Lit_1019 *jrt.String = jrt.Intern("arbace.core$add_doc_and_meta")

var Lit_1020 *jrt.String = jrt.Intern("arbace.core$add_tap")

var Lit_1021 *jrt.String = jrt.Intern("arbace.core$add_watch")

var Lit_1022 *jrt.String = jrt.Intern("arbace.core$agent")

var Lit_1023 *jrt.String = jrt.Intern("arbace.core$agent_error")

var Lit_1024 *jrt.String = jrt.Intern("arbace.core$agent_errors")

var Lit_1025 *jrt.String = jrt.Intern("arbace.core$aget")

var Lit_1026 *jrt.String = jrt.Intern("arbace.core$aget__inliner__1927000850")

var Lit_1027 *jrt.String = jrt.Intern("arbace.core$alength")

var Lit_1028 *jrt.String = jrt.Intern("arbace.core$alength__inliner__1927000844")

var Lit_1029 *jrt.String = jrt.Intern("arbace.core$alias")

var Lit_1030 *jrt.String = jrt.Intern("arbace.core$all_ns")

var Lit_1031 *jrt.String = jrt.Intern("arbace.core$alter")

var Lit_1032 *jrt.String = jrt.Intern("arbace.core$alter_meta_BANG_")

var Lit_1033 *jrt.String = jrt.Intern("arbace.core$alter_var_root")

var Lit_1034 *jrt.String = jrt.Intern("arbace.core$amap")

var Lit_1035 *jrt.String = jrt.Intern("arbace.core$ams_check")

var Lit_1036 *jrt.String = jrt.Intern("Unrecognized type ")

var Lit_1037 *jrt.String = jrt.Intern("arbace.core$ancestors")

var Lit_1038 *jrt.String = jrt.Intern("arbace.core$ancestors$fn__1927001418")

var Lit_1039 *jrt.String = jrt.Intern("arbace.core$and")

var Lit_1040 *jrt.String = jrt.Intern("arbace.core$anon")

var Lit_1041 *jrt.String = jrt.Intern("arbace.core$any_QMARK_")

var Lit_1042 *jrt.String = jrt.Intern("arbace.core$apply")

var Lit_1043 *jrt.String = jrt.Intern("arbace.core$arbace_version")

var Lit_1044 *jrt.String = jrt.Intern("arbace.core$areduce")

var Lit_1045 *jrt.String = jrt.Intern("arbace.core$array")

var Lit_1046 *jrt.String = jrt.Intern("arbace.core$array_map")

var Lit_1047 *jrt.String = jrt.Intern("No value supplied for key: ")

var Lit_1048 *jrt.String = jrt.Intern("arbace.core$as__GT_")

var Lit_1049 *jrt.String = jrt.Intern("arbace.core$aset")

var Lit_1050 *jrt.String = jrt.Intern("arbace.core$aset__inliner__1927000853")

var Lit_1051 *jrt.String = jrt.Intern("arbace.core$aset_boolean")

var Lit_1052 *jrt.String = jrt.Intern("arbace.core$aset_byte")

var Lit_1053 *jrt.String = jrt.Intern("arbace.core$aset_char")

var Lit_1054 *jrt.String = jrt.Intern("arbace.core$aset_double")

var Lit_1055 *jrt.String = jrt.Intern("arbace.core$aset_float")

var Lit_1056 *jrt.String = jrt.Intern("arbace.core$aset_int")

var Lit_1057 *jrt.String = jrt.Intern("arbace.core$aset_long")

var Lit_1058 *jrt.String = jrt.Intern("arbace.core$aset_short")

var Lit_1059 *jrt.String = jrt.Intern("arbace.core$assert")

var Lit_1060 *jrt.String = jrt.Intern("Assert failed: ")

var Lit_1061 *jrt.String = jrt.Intern("\n")

var Lit_1062 *jrt.String = jrt.Intern("arbace.core$assert_args")

var Lit_1063 *jrt.String = jrt.Intern(" requires ")

var Lit_1064 *jrt.String = jrt.Intern(" in ")

var Lit_1065 *jrt.String = jrt.Intern(":")

var Lit_1066 *jrt.String = jrt.Intern("arbace.core$assert_same_protocol")

var Lit_1067 *jrt.String = jrt.Intern("arbace.core$assert_same_protocol$fn__231000264")

var Lit_1068 *jrt.String = jrt.Intern("Warning: protocol")

var Lit_1069 *jrt.String = jrt.Intern("is overwriting")

var Lit_1070 *jrt.String = jrt.Intern("method ")

var Lit_1071 *jrt.String = jrt.Intern(" of protocol ")

var Lit_1072 *jrt.String = jrt.Intern("sym")

var Lit_1073 *jrt.String = jrt.Intern("function ")

var Lit_1074 *jrt.String = jrt.Intern("arbace.core$assert_same_protocol$fn__231000266")

var Lit_1075 *jrt.String = jrt.Intern("arbace.core$assert_valid_fdecl")

var Lit_1076 *jrt.String = jrt.Intern("arbace.core$assert_valid_fdecl$fn__1927002102")

var Lit_1077 *jrt.String = jrt.Intern("Invalid signature \"")

var Lit_1078 *jrt.String = jrt.Intern("\" should be a list")

var Lit_1079 *jrt.String = jrt.Intern("Parameter declaration \"")

var Lit_1080 *jrt.String = jrt.Intern("\" should be a vector")

var Lit_1081 *jrt.String = jrt.Intern("arbace.core$assert_valid_fdecl$fn__1927002104")

var Lit_1082 *jrt.String = jrt.Intern("arbace.core$assert_valid_fdecl__1")

var Lit_1083 *jrt.String = jrt.Intern("Parameter declaration missing")

var Lit_1084 *jrt.String = jrt.Intern("arbace.core$assoc_BANG_")

var Lit_1085 *jrt.String = jrt.Intern("arbace.core$assoc__1927000040")

var Lit_1086 *jrt.String = jrt.Intern("assoc expects even number of arguments after map/vector, found odd number")

var Lit_1087 *jrt.String = jrt.Intern("arbace.core$assoc_in")

var Lit_1088 *jrt.String = jrt.Intern("arbace.core$associative_QMARK_")

var Lit_1089 *jrt.String = jrt.Intern("arbace.core$atom")

var Lit_1090 *jrt.String = jrt.Intern("arbace.core$await")

var Lit_1091 *jrt.String = jrt.Intern("await in transaction")

var Lit_1092 *jrt.String = jrt.Intern("Can't await in agent action")

var Lit_1093 *jrt.String = jrt.Intern("arbace.core$await$count_down__1927000686")

var Lit_1094 *jrt.String = jrt.Intern("arbace.core$await1")

var Lit_1095 *jrt.String = jrt.Intern("arbace.core$await_for")

var Lit_1096 *jrt.String = jrt.Intern("await-for in transaction")

var Lit_1097 *jrt.String = jrt.Intern("arbace.core$await_for$count_down__1927000694")

var Lit_1098 *jrt.String = jrt.Intern("arbace.core$bases")

var Lit_1099 *jrt.String = jrt.Intern("arbace.core$bean")

var Lit_1100 *jrt.String = jrt.Intern("arbace.core.proxy$arbace.lang.APersistentMap$ff19274a")

var Lit_1101 *jrt.String = jrt.Intern("arbace.core$bean$fn__1968000063")

var Lit_1102 *jrt.String = jrt.Intern("arbace.core$bean$fn__1968000063$fn__1968000067")

var Lit_1103 *jrt.String = jrt.Intern("arbace.core$bean$fn__1968000080")

var Lit_1104 *jrt.String = jrt.Intern("arbace.core$bean$fn__1968000082")

var Lit_1105 *jrt.String = jrt.Intern("arbace.core$bean$fn__1968000084")

var Lit_1106 *jrt.String = jrt.Intern("arbace.core$bean$fn__1968000086")

var Lit_1107 *jrt.String = jrt.Intern("arbace.core$bean$fn__1968000088")

var Lit_1108 *jrt.String = jrt.Intern("arbace.core$bean$fn__1968000090")

var Lit_1109 *jrt.String = jrt.Intern("arbace.core$bean$fn__1968000092")

var Lit_1110 *jrt.String = jrt.Intern("arbace.core$bean$fn__1968000094")

var Lit_1111 *jrt.String = jrt.Intern("arbace.core$bean$fn__1968000096")

var Lit_1112 *jrt.String = jrt.Intern("arbace.core$bean$snapshot__1968000072")

var Lit_1113 *jrt.String = jrt.Intern("arbace.core$bean$snapshot__1968000072$fn__1968000073")

var Lit_1114 *jrt.String = jrt.Intern("arbace.core$bean$thisfn__1968000076")

var Lit_1115 *jrt.String = jrt.Intern("arbace.core$bean$thisfn__1968000076$fn__1968000077")

var Lit_1116 *jrt.String = jrt.Intern("arbace.core$bean$v__1968000070")

var Lit_1117 *jrt.String = jrt.Intern("arbace.core$bean_accessible_method")

var Lit_1118 *jrt.String = jrt.Intern("arbace.core$bean_accessible_method$in__1968000006")

var Lit_1119 *jrt.String = jrt.Intern("arbace.core$bean_accessible_method$in__1968000006$fn__1968000007")

var Lit_1120 *jrt.String = jrt.Intern("arbace.core$bean_class_methods")

var Lit_1121 *jrt.String = jrt.Intern("arbace.core$bean_class_methods$fn__1968000013")

var Lit_1122 *jrt.String = jrt.Intern("arbace.core$bean_class_methods$fn__1968000015")

var Lit_1123 *jrt.String = jrt.Intern("arbace.core$bean_class_methods$fn__1968000015$fn__1968000016")

var Lit_1124 *jrt.String = jrt.Intern("arbace.core$bean_class_methods$fn__1968000019")

var Lit_1125 *jrt.String = jrt.Intern("arbace.core$bean_class_methods$no_params_QMARK___1968000011")

var Lit_1126 *jrt.String = jrt.Intern("arbace.core$bean_class_reads")

var Lit_1127 *jrt.String = jrt.Intern("arbace.core$bean_class_reads$fn__1968000028")

var Lit_1128 *jrt.String = jrt.Intern("is")

var Lit_1129 *jrt.String = jrt.Intern("arbace.core$bean_class_reads$fn__1968000038")

var Lit_1130 *jrt.String = jrt.Intern("arbace.core$bean_class_reads$fn__1968000044")

var Lit_1131 *jrt.String = jrt.Intern("arbace.core$bean_class_reads$pick__1968000033")

var Lit_1132 *jrt.String = jrt.Intern("arbace.core$bean_class_reads$pick__1968000033$fn__1968000034")

var Lit_1133 *jrt.String = jrt.Intern("arbace.core$bean_class_reads$prefixed__1968000025")

var Lit_1134 *jrt.String = jrt.Intern("arbace.core$bean_decapitalize")

var Lit_1135 *jrt.String = jrt.Intern("arbace.core$bean_exported_QMARK_")

var Lit_1136 *jrt.String = jrt.Intern("arbace.core$bean_properties")

var Lit_1137 *jrt.String = jrt.Intern("arbace.core$bean_properties$fn__1968000051")

var Lit_1138 *jrt.String = jrt.Intern("arbace.core$bean_properties$fn__1968000051$fn__1968000053")

var Lit_1139 *jrt.String = jrt.Intern("arbace.core$bean_properties$fn__1968000059")

var Lit_1140 *jrt.String = jrt.Intern("arbace.core$bigdec")

var Lit_1141 *jrt.String = jrt.Intern("arbace.core$bigint")

var Lit_1142 *jrt.String = jrt.Intern("arbace.core$biginteger")

var Lit_1143 *jrt.String = jrt.Intern("arbace.core$binding")

var Lit_1144 *jrt.String = jrt.Intern("arbace.core$binding$var_ize__1927000435")

var Lit_1145 *jrt.String = jrt.Intern("arbace.core$binding_conveyor_fn")

var Lit_1146 *jrt.String = jrt.Intern("arbace.core$binding_conveyor_fn$fn__1927000457")

var Lit_1147 *jrt.String = jrt.Intern("arbace.core$bit_and")

var Lit_1148 *jrt.String = jrt.Intern("arbace.core$bit_and_int")

var Lit_1149 *jrt.String = jrt.Intern("arbace.core$bit_and_not")

var Lit_1150 *jrt.String = jrt.Intern("arbace.core$bit_clear")

var Lit_1151 *jrt.String = jrt.Intern("arbace.core$bit_flip")

var Lit_1152 *jrt.String = jrt.Intern("arbace.core$bit_not")

var Lit_1153 *jrt.String = jrt.Intern("arbace.core$bit_not__inliner__1927000295")

var Lit_1154 *jrt.String = jrt.Intern("arbace.core$bit_not_int")

var Lit_1155 *jrt.String = jrt.Intern("arbace.core$bit_or")

var Lit_1156 *jrt.String = jrt.Intern("arbace.core$bit_or_int")

var Lit_1157 *jrt.String = jrt.Intern("arbace.core$bit_set")

var Lit_1158 *jrt.String = jrt.Intern("arbace.core$bit_shift_left")

var Lit_1159 *jrt.String = jrt.Intern("arbace.core$bit_shift_left__inliner__1927000306")

var Lit_1160 *jrt.String = jrt.Intern("arbace.core$bit_shift_left_int")

var Lit_1161 *jrt.String = jrt.Intern("arbace.core$bit_shift_right")

var Lit_1162 *jrt.String = jrt.Intern("arbace.core$bit_shift_right__inliner__1927000309")

var Lit_1163 *jrt.String = jrt.Intern("arbace.core$bit_shift_right_int")

var Lit_1164 *jrt.String = jrt.Intern("arbace.core$bit_test")

var Lit_1165 *jrt.String = jrt.Intern("arbace.core$bit_xor")

var Lit_1166 *jrt.String = jrt.Intern("arbace.core$bit_xor_int")

var Lit_1167 *jrt.String = jrt.Intern("arbace.core$boolean")

var Lit_1168 *jrt.String = jrt.Intern("arbace.core$boolean_QMARK_")

var Lit_1169 *jrt.String = jrt.Intern("arbace.core$boolean__inliner__1927000350")

var Lit_1170 *jrt.String = jrt.Intern("arbace.core$boolean_array")

var Lit_1171 *jrt.String = jrt.Intern("arbace.core$boolean_array__inliner__1927001260")

var Lit_1172 *jrt.String = jrt.Intern("arbace.core$booleans")

var Lit_1173 *jrt.String = jrt.Intern("arbace.core$bound_QMARK_")

var Lit_1174 *jrt.String = jrt.Intern("arbace.core$bound_QMARK_$fn__1927001401")

var Lit_1175 *jrt.String = jrt.Intern("arbace.core$bound_fn")

var Lit_1176 *jrt.String = jrt.Intern("arbace.core$bound_fn_STAR_")

var Lit_1177 *jrt.String = jrt.Intern("arbace.core$bound_fn_STAR_$fn__1927000448")

var Lit_1178 *jrt.String = jrt.Intern("arbace.core$bounded_count")

var Lit_1179 *jrt.String = jrt.Intern("arbace.core$break")

var Lit_1180 *jrt.String = jrt.Intern("arbace.core$build_positional_factory")

var Lit_1181 *jrt.String = jrt.Intern("Positional factory function for class ")

var Lit_1182 *jrt.String = jrt.Intern("arbace.core$build_positional_factory$iter__231000161__231000165")

var Lit_1183 *jrt.String = jrt.Intern("arbace.core$build_positional_factory$iter__231000161__231000165$fn__231000166")

var Lit_1184 *jrt.String = jrt.Intern("arbace.core$build_positional_factory$iter__231000161__231000165$fn__231000166$fn__231000167")

var Lit_1185 *jrt.String = jrt.Intern("arbace.core$butlast__1927000056")

var Lit_1186 *jrt.String = jrt.Intern("arbace.core$byte")

var Lit_1187 *jrt.String = jrt.Intern("arbace.core$byte__inliner__1927000760")

var Lit_1188 *jrt.String = jrt.Intern("arbace.core$byte_array")

var Lit_1189 *jrt.String = jrt.Intern("arbace.core$byte_array__inliner__1927001263")

var Lit_1190 *jrt.String = jrt.Intern("arbace.core$bytes")

var Lit_1191 *jrt.String = jrt.Intern("arbace.core$bytes_QMARK_")

var Lit_1192 *jrt.String = jrt.Intern("arbace.core$case")

var Lit_1193 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_1194 *jrt.String = jrt.Intern("arbace.core$case$assoc_test__1927001769")

var Lit_1195 *jrt.String = jrt.Intern("Duplicate case test constant: ")

var Lit_1196 *jrt.String = jrt.Intern("arbace.core$case$fn__1927001772")

var Lit_1197 *jrt.String = jrt.Intern("arbace.core$case$fn__1927001772$fn__1927001776")

var Lit_1198 *jrt.String = jrt.Intern("arbace.core$case$fn__1927001779")

var Lit_1199 *jrt.String = jrt.Intern("arbace.core$case_map")

var Lit_1200 *jrt.String = jrt.Intern("arbace.core$cast")

var Lit_1201 *jrt.String = jrt.Intern("arbace.core$cat")

var Lit_1202 *jrt.String = jrt.Intern("arbace.core$cat$fn__1927002178")

var Lit_1203 *jrt.String = jrt.Intern("arbace.core$char")

var Lit_1204 *jrt.String = jrt.Intern("arbace.core$char_QMARK___1927000032")

var Lit_1205 *jrt.String = jrt.Intern("arbace.core$char__inliner__1927000763")

var Lit_1206 *jrt.String = jrt.Intern("arbace.core$char_array")

var Lit_1207 *jrt.String = jrt.Intern("arbace.core$char_array__inliner__1927001266")

var Lit_1208 *jrt.String = jrt.Intern("arbace.core$chars")

var Lit_1209 *jrt.String = jrt.Intern("arbace.core$check_cyclic_dependency")

var Lit_1210 *jrt.String = jrt.Intern("Cyclic load dependency: %s")

var Lit_1211 *jrt.String = jrt.Intern("arbace.core$check_cyclic_dependency$fn__1927001561")

var Lit_1212 *jrt.String = jrt.Intern("[ ")

var Lit_1213 *jrt.String = jrt.Intern(" ]")

var Lit_1214 *jrt.String = jrt.Intern("arbace.core$check_valid_options")

var Lit_1215 *jrt.String = jrt.Intern("Only these options are valid: ")

var Lit_1216 *jrt.String = jrt.Intern("arbace.core$check_valid_options$fn__1927000383")

var Lit_1217 *jrt.String = jrt.Intern(", ")

var Lit_1218 *jrt.String = jrt.Intern("arbace.core$chunk")

var Lit_1219 *jrt.String = jrt.Intern("arbace.core$chunk_append")

var Lit_1220 *jrt.String = jrt.Intern("arbace.core$chunk_buffer")

var Lit_1221 *jrt.String = jrt.Intern("arbace.core$chunk_cons")

var Lit_1222 *jrt.String = jrt.Intern("arbace.core$chunk_first")

var Lit_1223 *jrt.String = jrt.Intern("arbace.core$chunk_next")

var Lit_1224 *jrt.String = jrt.Intern("arbace.core$chunk_rest")

var Lit_1225 *jrt.String = jrt.Intern("arbace.core$chunked_seq_QMARK_")

var Lit_1226 *jrt.String = jrt.Intern("arbace.core$class")

var Lit_1227 *jrt.String = jrt.Intern("arbace.core$class_QMARK_")

var Lit_1228 *jrt.String = jrt.Intern("arbace.core$clear_agent_errors")

var Lit_1229 *jrt.String = jrt.Intern("arbace.core$clojure_version")

var Lit_1230 *jrt.String = jrt.Intern("-SNAPSHOT")

var Lit_1231 *jrt.String = jrt.Intern("arbace.core$coll_QMARK_")

var Lit_1232 *jrt.String = jrt.Intern("arbace.core$comment")

var Lit_1233 *jrt.String = jrt.Intern("arbace.core$commute")

var Lit_1234 *jrt.String = jrt.Intern("arbace.core$comp")

var Lit_1235 *jrt.String = jrt.Intern("arbace.core$comp$fn__1927000519")

var Lit_1236 *jrt.String = jrt.Intern("arbace.core$comparator")

var Lit_1237 *jrt.String = jrt.Intern("arbace.core$comparator$fn__1927000659")

var Lit_1238 *jrt.String = jrt.Intern("arbace.core$compare")

var Lit_1239 *jrt.String = jrt.Intern("arbace.core$compare__inliner__1927000165")

var Lit_1240 *jrt.String = jrt.Intern("arbace.core$compare_and_set_BANG_")

var Lit_1241 *jrt.String = jrt.Intern("arbace.core$compile")

var Lit_1242 *jrt.String = jrt.Intern("arbace.core$compile$fn__1927001578")

var Lit_1243 *jrt.String = jrt.Intern("arbace.core$complement")

var Lit_1244 *jrt.String = jrt.Intern("arbace.core$complement$fn__1927000323")

var Lit_1245 *jrt.String = jrt.Intern("arbace.core$completing")

var Lit_1246 *jrt.String = jrt.Intern("arbace.core$completing$fn__1927001881")

var Lit_1247 *jrt.String = jrt.Intern("arbace.core$concat")

var Lit_1248 *jrt.String = jrt.Intern("arbace.core$concat$cat__1927000141")

var Lit_1249 *jrt.String = jrt.Intern("arbace.core$concat$cat__1927000141$fn__1927000142")

var Lit_1250 *jrt.String = jrt.Intern("arbace.core$concat$fn__1927000135")

var Lit_1251 *jrt.String = jrt.Intern("arbace.core$concat$fn__1927000137")

var Lit_1252 *jrt.String = jrt.Intern("arbace.core$concat$fn__1927000139")

var Lit_1253 *jrt.String = jrt.Intern("arbace.core$cond")

var Lit_1254 *jrt.String = jrt.Intern("cond requires an even number of forms")

var Lit_1255 *jrt.String = jrt.Intern("arbace.core$cond__GT_")

var Lit_1256 *jrt.String = jrt.Intern("arbace.core$cond__GT_$fn__1927002133")

var Lit_1257 *jrt.String = jrt.Intern("arbace.core$cond__GT__GT_")

var Lit_1258 *jrt.String = jrt.Intern("arbace.core$cond__GT__GT_$fn__1927002144")

var Lit_1259 *jrt.String = jrt.Intern("arbace.core$condp")

var Lit_1260 *jrt.String = jrt.Intern("pred__")

var Lit_1261 *jrt.String = jrt.Intern("expr__")

var Lit_1262 *jrt.String = jrt.Intern("arbace.core$condp$emit__1927001617")

var Lit_1263 *jrt.String = jrt.Intern("arbace.core$conj_BANG_")

var Lit_1264 *jrt.String = jrt.Intern("arbace.core$conj__1927000014")

var Lit_1265 *jrt.String = jrt.Intern("arbace.core$cons__1927000000")

var Lit_1266 *jrt.String = jrt.Intern("arbace.core$constantly")

var Lit_1267 *jrt.String = jrt.Intern("arbace.core$constantly$fn__1927000326")

var Lit_1268 *jrt.String = jrt.Intern("arbace.core$construct_proxy")

var Lit_1269 *jrt.String = jrt.Intern("arbace.core$contains_QMARK_")

var Lit_1270 *jrt.String = jrt.Intern("arbace.core$continue")

var Lit_1271 *jrt.String = jrt.Intern("arbace.core$count")

var Lit_1272 *jrt.String = jrt.Intern("arbace.core$count__inliner__1927000183")

var Lit_1273 *jrt.String = jrt.Intern("arbace.core$counted_QMARK_")

var Lit_1274 *jrt.String = jrt.Intern("arbace.core$create_ns")

var Lit_1275 *jrt.String = jrt.Intern("arbace.core$create_struct")

var Lit_1276 *jrt.String = jrt.Intern("arbace.core$cycle")

var Lit_1277 *jrt.String = jrt.Intern("arbace.core$data_reader_urls")

var Lit_1278 *jrt.String = jrt.Intern("getContextClassLoader")

var Lit_1279 *jrt.String = jrt.Intern("getResources")

var Lit_1280 *jrt.String = jrt.Intern("data_readers.ae")

var Lit_1281 *jrt.String = jrt.Intern("data_readers.clj")

var Lit_1282 *jrt.String = jrt.Intern("data_readers.cljc")

var Lit_1283 *jrt.String = jrt.Intern("arbace.core$data_reader_var")

var Lit_1284 *jrt.String = jrt.Intern("arbace.core$dec")

var Lit_1285 *jrt.String = jrt.Intern("arbace.core$dec_SINGLEQUOTE_")

var Lit_1286 *jrt.String = jrt.Intern("arbace.core$dec_SINGLEQUOTE___inliner__1927000234")

var Lit_1287 *jrt.String = jrt.Intern("arbace.core$dec__inliner__1927000237")

var Lit_1288 *jrt.String = jrt.Intern("arbace.core$decimal_QMARK_")

var Lit_1289 *jrt.String = jrt.Intern("arbace.core$declare")

var Lit_1290 *jrt.String = jrt.Intern("arbace.core$declare$fn__1927000591")

var Lit_1291 *jrt.String = jrt.Intern("arbace.core$dedupe")

var Lit_1292 *jrt.String = jrt.Intern("arbace.core$dedupe$fn__1927002186")

var Lit_1293 *jrt.String = jrt.Intern("arbace.core$dedupe$fn__1927002186$fn__1927002187")

var Lit_1294 *jrt.String = jrt.Intern("arbace.core$def_aset")

var Lit_1295 *jrt.String = jrt.Intern("arbace.core$defclass")

var Lit_1296 *jrt.String = jrt.Intern("arbace.core$defclasses")

var Lit_1297 *jrt.String = jrt.Intern("defclass")

var Lit_1298 *jrt.String = jrt.Intern("defclasses takes defclass forms: ")

var Lit_1299 *jrt.String = jrt.Intern("arbace.core$define_proxy")

var Lit_1300 *jrt.String = jrt.Intern("proxy")

var Lit_1301 *jrt.String = jrt.Intern("__initArbaceFnMappings")

var Lit_1302 *jrt.String = jrt.Intern("__updateArbaceFnMappings")

var Lit_1303 *jrt.String = jrt.Intern("__getArbaceFnMappings")

var Lit_1304 *jrt.String = jrt.Intern("arbace.core$define_proxy$fn__840000097")

var Lit_1305 *jrt.String = jrt.Intern("arbace.core$define_proxy$fn__840000099")

var Lit_1306 *jrt.String = jrt.Intern("arbace.core$define_proxy$fn__840000101")

var Lit_1307 *jrt.String = jrt.Intern("arbace.core$define_proxy$fn__840000111")

var Lit_1308 *jrt.String = jrt.Intern("arbace.core$definline")

var Lit_1309 *jrt.String = jrt.Intern("arbace.core$definterface")

var Lit_1310 *jrt.String = jrt.Intern("arbace.core$definterface$psig__231000007")

var Lit_1311 *jrt.String = jrt.Intern("arbace.core$definterface$tag__231000004")

var Lit_1312 *jrt.String = jrt.Intern("arbace.core$defmacro")

var Lit_1313 *jrt.String = jrt.Intern("arbace.core$defmacro$add_args__1927000081")

var Lit_1314 *jrt.String = jrt.Intern("arbace.core$defmacro$add_implicit_args__1927000079")

var Lit_1315 *jrt.String = jrt.Intern("arbace.core$defmacro$fn__1927000075")

var Lit_1316 *jrt.String = jrt.Intern("arbace.core$defmacro$fn__1927000077")

var Lit_1317 *jrt.String = jrt.Intern("arbace.core$defmacro$fn__1927000083")

var Lit_1318 *jrt.String = jrt.Intern("arbace.core$defmethod")

var Lit_1319 *jrt.String = jrt.Intern("arbace.core$defmodule")

var Lit_1320 *jrt.String = jrt.Intern("arbace.core$defmulti")

var Lit_1321 *jrt.String = jrt.Intern("The syntax for defmulti has changed. Example: (defmulti name dispatch-fn :default dispatch-value)")

var Lit_1322 *jrt.String = jrt.Intern("arbace.core$defn_")

var Lit_1323 *jrt.String = jrt.Intern("arbace.core$defn__1927000058")

var Lit_1324 *jrt.String = jrt.Intern("First argument to defn must be a symbol")

var Lit_1325 *jrt.String = jrt.Intern("__inliner")

var Lit_1326 *jrt.String = jrt.Intern("arbace.core$defonce")

var Lit_1327 *jrt.String = jrt.Intern("arbace.core$defop")

var Lit_1328 *jrt.String = jrt.Intern("arbace")

var Lit_1329 *jrt.String = jrt.Intern("arbace.core$defpackage")

var Lit_1330 *jrt.String = jrt.Intern("arbace.core$defprotocol")

var Lit_1331 *jrt.String = jrt.Intern("arbace.core$defrecord")

var Lit_1332 *jrt.String = jrt.Intern("Factory function for class ")

var Lit_1333 *jrt.String = jrt.Intern(", taking a map of keywords to field values.")

var Lit_1334 *jrt.String = jrt.Intern("/create")

var Lit_1335 *jrt.String = jrt.Intern("arbace.core$defrecord$fn__231000178")

var Lit_1336 *jrt.String = jrt.Intern("arbace.core$defstruct")

var Lit_1337 *jrt.String = jrt.Intern("arbace.core$deftype")

var Lit_1338 *jrt.String = jrt.Intern("arbace.core$deftype$fn__231000194")

var Lit_1339 *jrt.String = jrt.Intern("arbace.core$delay")

var Lit_1340 *jrt.String = jrt.Intern("arbace.core$delay_QMARK_")

var Lit_1341 *jrt.String = jrt.Intern("arbace.core$deliver")

var Lit_1342 *jrt.String = jrt.Intern("arbace.core$denominator")

var Lit_1343 *jrt.String = jrt.Intern("arbace.core$deref")

var Lit_1344 *jrt.String = jrt.Intern("arbace.core$deref_as_map")

var Lit_1345 *jrt.String = jrt.Intern("arbace.core$deref_as_map$fn__1769000343")

var Lit_1346 *jrt.String = jrt.Intern("arbace.core$deref_future")

var Lit_1347 *jrt.String = jrt.Intern("arbace.core$derive")

var Lit_1348 *jrt.String = jrt.Intern("already has")

var Lit_1349 *jrt.String = jrt.Intern("as ancestor")

var Lit_1350 *jrt.String = jrt.Intern("Cyclic derivation:")

var Lit_1351 *jrt.String = jrt.Intern("has")

var Lit_1352 *jrt.String = jrt.Intern("arbace.core$derive$tf__1927001422")

var Lit_1353 *jrt.String = jrt.Intern("arbace.core$derive$tf__1927001422$fn__1927001423")

var Lit_1354 *jrt.String = jrt.Intern("arbace.core$descendants")

var Lit_1355 *jrt.String = jrt.Intern("Can't get descendants of classes")

var Lit_1356 *jrt.String = jrt.Intern("arbace.core$destmap_STAR_")

var Lit_1357 *jrt.String = jrt.Intern("map__")

var Lit_1358 *jrt.String = jrt.Intern("temp__")

var Lit_1359 *jrt.String = jrt.Intern("notfound__")

var Lit_1360 *jrt.String = jrt.Intern("notfound?__")

var Lit_1361 *jrt.String = jrt.Intern("keys ")

var Lit_1362 *jrt.String = jrt.Intern(" appear only in :or")

var Lit_1363 *jrt.String = jrt.Intern("arbace.core$destmap_STAR_$bk__1927000977")

var Lit_1364 *jrt.String = jrt.Intern("symbol ")

var Lit_1365 *jrt.String = jrt.Intern(" in :or does not refer to a binding")

var Lit_1366 *jrt.String = jrt.Intern("arbace.core$destmap_STAR_$fn__1927000957")

var Lit_1367 *jrt.String = jrt.Intern("default__")

var Lit_1368 *jrt.String = jrt.Intern("arbace.core$destmap_STAR_$fn__1927000965")

var Lit_1369 *jrt.String = jrt.Intern("arbace.core$destmap_STAR_$fn__1927000967")

var Lit_1370 *jrt.String = jrt.Intern("arbace.core$destmap_STAR_$fn__1927000973")

var Lit_1371 *jrt.String = jrt.Intern("!")

var Lit_1372 *jrt.String = jrt.Intern("select__")

var Lit_1373 *jrt.String = jrt.Intern("all__")

var Lit_1374 *jrt.String = jrt.Intern("excess__")

var Lit_1375 *jrt.String = jrt.Intern("missing__")

var Lit_1376 *jrt.String = jrt.Intern("arbace.core$destmap_STAR_$fn__1927000973$fn__1927000974")

var Lit_1377 *jrt.String = jrt.Intern("& can only appear once in ")

var Lit_1378 *jrt.String = jrt.Intern("'")

var Lit_1379 *jrt.String = jrt.Intern("' - binding symbols can only appear before '&', use keys after")

var Lit_1380 *jrt.String = jrt.Intern("arbace.core$destmap_STAR_$localize__1927000969")

var Lit_1381 *jrt.String = jrt.Intern("arbace.core$destmap_STAR_$push1__1927000971")

var Lit_1382 *jrt.String = jrt.Intern("Multiple :or defaults for same key: ")

var Lit_1383 *jrt.String = jrt.Intern(" '")

var Lit_1384 *jrt.String = jrt.Intern("Can't supply default value for required key: ")

var Lit_1385 *jrt.String = jrt.Intern("arbace.core$destmap_STAR_$xf__1927000959")

var Lit_1386 *jrt.String = jrt.Intern("syms")

var Lit_1387 *jrt.String = jrt.Intern("strs")

var Lit_1388 *jrt.String = jrt.Intern("Unsupported map directive: ")

var Lit_1389 *jrt.String = jrt.Intern("arbace.core$destmap_STAR_$xf__1927000959$fn__1927000960")

var Lit_1390 *jrt.String = jrt.Intern("arbace.core$destmap_STAR_$xf__1927000959$fn__1927000962")

var Lit_1391 *jrt.String = jrt.Intern("arbace.core$destructure")

var Lit_1392 *jrt.String = jrt.Intern("arbace.core$destructure$pb__1927000980")

var Lit_1393 *jrt.String = jrt.Intern("Unsupported binding form: ")

var Lit_1394 *jrt.String = jrt.Intern("arbace.core$destructure$process_entry__1927000982")

var Lit_1395 *jrt.String = jrt.Intern("arbace.core$destvec_STAR_")

var Lit_1396 *jrt.String = jrt.Intern("vec__")

var Lit_1397 *jrt.String = jrt.Intern("seq__")

var Lit_1398 *jrt.String = jrt.Intern("first__")

var Lit_1399 *jrt.String = jrt.Intern("Unsupported binding form, only :as can follow & parameter")

var Lit_1400 *jrt.String = jrt.Intern("arbace.core$disj")

var Lit_1401 *jrt.String = jrt.Intern("arbace.core$disj_BANG_")

var Lit_1402 *jrt.String = jrt.Intern("arbace.core$dissoc")

var Lit_1403 *jrt.String = jrt.Intern("arbace.core$dissoc_BANG_")

var Lit_1404 *jrt.String = jrt.Intern("arbace.core$distinct")

var Lit_1405 *jrt.String = jrt.Intern("arbace.core$distinct$fn__1927001167")

var Lit_1406 *jrt.String = jrt.Intern("arbace.core$distinct$fn__1927001167$fn__1927001168")

var Lit_1407 *jrt.String = jrt.Intern("arbace.core$distinct$step__1927001171")

var Lit_1408 *jrt.String = jrt.Intern("arbace.core$distinct$step__1927001171$fn__1927001172")

var Lit_1409 *jrt.String = jrt.Intern("arbace.core$distinct$step__1927001171$fn__1927001172$fn__1927001174")

var Lit_1410 *jrt.String = jrt.Intern("arbace.core$distinct_QMARK_")

var Lit_1411 *jrt.String = jrt.Intern("arbace.core$doall")

var Lit_1412 *jrt.String = jrt.Intern("arbace.core$dorun")

var Lit_1413 *jrt.String = jrt.Intern("arbace.core$doseq")

var Lit_1414 *jrt.String = jrt.Intern("arbace.core$doseq$step__1927000679")

var Lit_1415 *jrt.String = jrt.Intern("seq_")

var Lit_1416 *jrt.String = jrt.Intern("chunk_")

var Lit_1417 *jrt.String = jrt.Intern("count_")

var Lit_1418 *jrt.String = jrt.Intern("i_")

var Lit_1419 *jrt.String = jrt.Intern("arbace.core$dosync")

var Lit_1420 *jrt.String = jrt.Intern("arbace.core$dotimes")

var Lit_1421 *jrt.String = jrt.Intern("arbace.core$dotimes__1")

var Lit_1422 *jrt.String = jrt.Intern("arbace.core$doto")

var Lit_1423 *jrt.String = jrt.Intern("arbace.core$doto$fn__1927000823")

var Lit_1424 *jrt.String = jrt.Intern("arbace.core$double")

var Lit_1425 *jrt.String = jrt.Intern("arbace.core$double_QMARK_")

var Lit_1426 *jrt.String = jrt.Intern("arbace.core$double__inliner__1927000754")

var Lit_1427 *jrt.String = jrt.Intern("arbace.core$double_array")

var Lit_1428 *jrt.String = jrt.Intern("arbace.core$double_array__inliner__1927001272")

var Lit_1429 *jrt.String = jrt.Intern("arbace.core$doubles")

var Lit_1430 *jrt.String = jrt.Intern("arbace.core$drop")

var Lit_1431 *jrt.String = jrt.Intern("arbace.core$drop$fn__1927000627")

var Lit_1432 *jrt.String = jrt.Intern("arbace.core$drop$fn__1927000627$fn__1927000628")

var Lit_1433 *jrt.String = jrt.Intern("arbace.core$drop$fn__1927000633")

var Lit_1434 *jrt.String = jrt.Intern("arbace.core$drop$step__1927000631")

var Lit_1435 *jrt.String = jrt.Intern("arbace.core$drop_last")

var Lit_1436 *jrt.String = jrt.Intern("arbace.core$drop_last$fn__1927000636")

var Lit_1437 *jrt.String = jrt.Intern("arbace.core$drop_while")

var Lit_1438 *jrt.String = jrt.Intern("arbace.core$drop_while$fn__1927000640")

var Lit_1439 *jrt.String = jrt.Intern("arbace.core$drop_while$fn__1927000640$fn__1927000641")

var Lit_1440 *jrt.String = jrt.Intern("arbace.core$drop_while$fn__1927000646")

var Lit_1441 *jrt.String = jrt.Intern("arbace.core$drop_while$step__1927000644")

var Lit_1442 *jrt.String = jrt.Intern("arbace.core$eduction")

var Lit_1443 *jrt.String = jrt.Intern("arbace.core$elide_top_frames")

var Lit_1444 *jrt.String = jrt.Intern("arbace.core$elide_top_frames$fn__1927001115")

var Lit_1445 *jrt.String = jrt.Intern("arbace.core$emit_defrecord")

var Lit_1446 *jrt.String = jrt.Intern(":volatile-mutable or :unsynchronized-mutable not supported for record fields")

var Lit_1447 *jrt.String = jrt.Intern("arbace.core$emit_defrecord$eqhash__231000115")

var Lit_1448 *jrt.String = jrt.Intern("arbace.core$emit_defrecord$fn__231000106")

var Lit_1449 *jrt.String = jrt.Intern("arbace.core$emit_defrecord$ijavamap__231000149")

var Lit_1450 *jrt.String = jrt.Intern("arbace.core$emit_defrecord$ilookup__231000127")

var Lit_1451 *jrt.String = jrt.Intern("arbace.core$emit_defrecord$ilookup__231000127$fn__231000131")

var Lit_1452 *jrt.String = jrt.Intern("arbace.core$emit_defrecord$ilookup__231000127$fn__231000133")

var Lit_1453 *jrt.String = jrt.Intern("arbace.core$emit_defrecord$imap__231000137")

var Lit_1454 *jrt.String = jrt.Intern("Can't create empty: ")

var Lit_1455 *jrt.String = jrt.Intern("arbace.core$emit_defrecord$imap__231000137$fn__231000141")

var Lit_1456 *jrt.String = jrt.Intern("arbace.core$emit_defrecord$imap__231000137$fn__231000143")

var Lit_1457 *jrt.String = jrt.Intern("arbace.core$emit_defrecord$imap__231000137$fn__231000145")

var Lit_1458 *jrt.String = jrt.Intern("arbace.core$emit_defrecord$iobj__231000121")

var Lit_1459 *jrt.String = jrt.Intern("arbace.core$emit_defrecord$irecord__231000109")

var Lit_1460 *jrt.String = jrt.Intern("arbace.core$emit_deftype_STAR_")

var Lit_1461 *jrt.String = jrt.Intern("arbace.core$emit_extend_protocol")

var Lit_1462 *jrt.String = jrt.Intern("arbace.core$emit_extend_protocol$fn__231000355")

var Lit_1463 *jrt.String = jrt.Intern("arbace.core$emit_extend_type")

var Lit_1464 *jrt.String = jrt.Intern("arbace.core$emit_hinted_impl")

var Lit_1465 *jrt.String = jrt.Intern("arbace.core$emit_hinted_impl$fn__231000343")

var Lit_1466 *jrt.String = jrt.Intern("arbace.core$emit_hinted_impl$fn__231000345")

var Lit_1467 *jrt.String = jrt.Intern("arbace.core$emit_hinted_impl$hint__231000332")

var Lit_1468 *jrt.String = jrt.Intern("arbace.core$emit_hinted_impl$hint__231000332$fn__231000334")

var Lit_1469 *jrt.String = jrt.Intern("arbace.core$emit_impl")

var Lit_1470 *jrt.String = jrt.Intern("arbace.core$emit_impl$fn__231000321")

var Lit_1471 *jrt.String = jrt.Intern("arbace.core$emit_impl$fn__231000323")

var Lit_1472 *jrt.String = jrt.Intern("arbace.core$emit_method_builder")

var Lit_1473 *jrt.String = jrt.Intern("arbace.core$emit_method_builder$fn__231000240")

var Lit_1474 *jrt.String = jrt.Intern("arbace.core$emit_method_builder$fn__231000240$fn__231000241")

var Lit_1475 *jrt.String = jrt.Intern("gf__")

var Lit_1476 *jrt.String = jrt.Intern("__")

var Lit_1477 *jrt.String = jrt.Intern("arbace.core$emit_method_builder$fn__231000244")

var Lit_1478 *jrt.String = jrt.Intern("arbace.core$emit_method_builder$fn__231000244$fn__231000245")

var Lit_1479 *jrt.String = jrt.Intern("arbace.core$emit_protocol")

var Lit_1480 *jrt.String = jrt.Intern("arbace.core$emit_protocol$fn__231000275")

var Lit_1481 *jrt.String = jrt.Intern("arbace.core$emit_protocol$fn__231000275$pred__231000276__231000278")

var Lit_1482 *jrt.String = jrt.Intern("arbace.core$emit_protocol$fn__231000281")

var Lit_1483 *jrt.String = jrt.Intern("Definition of function ")

var Lit_1484 *jrt.String = jrt.Intern(" in protocol ")

var Lit_1485 *jrt.String = jrt.Intern(" must take at least one arg.")

var Lit_1486 *jrt.String = jrt.Intern("Function ")

var Lit_1487 *jrt.String = jrt.Intern(" was redefined. Specify all arities in single definition.")

var Lit_1488 *jrt.String = jrt.Intern("arbace.core$emit_protocol$fn__231000281$fn__231000287")

var Lit_1489 *jrt.String = jrt.Intern("arbace.core$emit_protocol$fn__231000281$resolve_class_symbol__231000285")

var Lit_1490 *jrt.String = jrt.Intern("arbace.core$emit_protocol$fn__231000290")

var Lit_1491 *jrt.String = jrt.Intern("arbace.core$emit_protocol$fn__231000290$fn__231000291")

var Lit_1492 *jrt.String = jrt.Intern("arbace.core$emit_protocol$fn__231000294")

var Lit_1493 *jrt.String = jrt.Intern("arbace.core$emit_protocol$fn__231000296")

var Lit_1494 *jrt.String = jrt.Intern("arbace.core$empty")

var Lit_1495 *jrt.String = jrt.Intern("arbace.core$empty_QMARK_")

var Lit_1496 *jrt.String = jrt.Intern("arbace.core$ensure")

var Lit_1497 *jrt.String = jrt.Intern("arbace.core$ensure_reduced")

var Lit_1498 *jrt.String = jrt.Intern("arbace.core$enumeration_seq")

var Lit_1499 *jrt.String = jrt.Intern("arbace.core$error_handler")

var Lit_1500 *jrt.String = jrt.Intern("arbace.core$error_mode")

var Lit_1501 *jrt.String = jrt.Intern("arbace.core$eval")

var Lit_1502 *jrt.String = jrt.Intern("arbace.core$eval1769000030$fn__1769000031")

var Lit_1503 *jrt.String = jrt.Intern("arbace.core$eval1769000030$fn__1769000031$fn__1769000032")

var Lit_1504 *jrt.String = jrt.Intern("arbace.core$eval1769000036$fn__1769000037")

var Lit_1505 *jrt.String = jrt.Intern("arbace.core$eval1769000040$fn__1769000041")

var Lit_1506 *jrt.String = jrt.Intern("arbace.core$eval1769000047$fn__1769000048")

var Lit_1507 *jrt.String = jrt.Intern("arbace.core$eval1769000051$fn__1769000052")

var Lit_1508 *jrt.String = jrt.Intern("arbace.core$eval1769000055$fn__1769000056")

var Lit_1509 *jrt.String = jrt.Intern("arbace.core$eval1769000059$fn__1769000060")

var Lit_1510 *jrt.String = jrt.Intern("arbace.core$eval1769000063$fn__1769000064")

var Lit_1511 *jrt.String = jrt.Intern("##Inf")

var Lit_1512 *jrt.String = jrt.Intern("##-Inf")

var Lit_1513 *jrt.String = jrt.Intern("##NaN")

var Lit_1514 *jrt.String = jrt.Intern("arbace.core$eval1769000067$fn__1769000068")

var Lit_1515 *jrt.String = jrt.Intern("arbace.core$eval1769000071$fn__1769000072")

var Lit_1516 *jrt.String = jrt.Intern("arbace.core$eval1769000071$fn__1769000072$fn__1769000073")

var Lit_1517 *jrt.String = jrt.Intern("arbace.core$eval1769000077$fn__1769000078")

var Lit_1518 *jrt.String = jrt.Intern("arbace.core$eval1769000077$fn__1769000078$fn__1769000079")

var Lit_1519 *jrt.String = jrt.Intern("arbace.core$eval1769000089$fn__1769000090")

var Lit_1520 *jrt.String = jrt.Intern("arbace.core$eval1769000093$fn__1769000094")

var Lit_1521 *jrt.String = jrt.Intern("arbace.core$eval1769000097$fn__1769000098")

var Lit_1522 *jrt.String = jrt.Intern("arbace.core$eval1769000101$fn__1769000102")

var Lit_1523 *jrt.String = jrt.Intern("arbace.core$eval1769000105$fn__1769000106")

var Lit_1524 *jrt.String = jrt.Intern("arbace.core$eval1769000109$fn__1769000110")

var Lit_1525 *jrt.String = jrt.Intern("#=(var ")

var Lit_1526 *jrt.String = jrt.Intern(")")

var Lit_1527 *jrt.String = jrt.Intern("arbace.core$eval1769000113$fn__1769000114")

var Lit_1528 *jrt.String = jrt.Intern("(")

var Lit_1529 *jrt.String = jrt.Intern(" ")

var Lit_1530 *jrt.String = jrt.Intern("arbace.core$eval1769000117$fn__1769000118")

var Lit_1531 *jrt.String = jrt.Intern("arbace.core$eval1769000121$fn__1769000122")

var Lit_1532 *jrt.String = jrt.Intern("arbace.core$eval1769000135$fn__1769000136")

var Lit_1533 *jrt.String = jrt.Intern("arbace.core$eval1769000135$fn__1769000136$fn__1769000137")

var Lit_1534 *jrt.String = jrt.Intern("[")

var Lit_1535 *jrt.String = jrt.Intern("]")

var Lit_1536 *jrt.String = jrt.Intern("arbace.core$eval1769000141$fn__1769000142")

var Lit_1537 *jrt.String = jrt.Intern("#=(")

var Lit_1538 *jrt.String = jrt.Intern("/create ")

var Lit_1539 *jrt.String = jrt.Intern("arbace.core$eval1769000147$fn__1769000148")

var Lit_1540 *jrt.String = jrt.Intern("arbace.core$eval1769000151$fn__1769000152")

var Lit_1541 *jrt.String = jrt.Intern("arbace.core$eval1769000155$fn__1769000156")

var Lit_1542 *jrt.String = jrt.Intern("arbace.core$eval1769000188$fn__1769000189")

var Lit_1543 *jrt.String = jrt.Intern("#:")

var Lit_1544 *jrt.String = jrt.Intern("arbace.core$eval1769000197$fn__1769000198")

var Lit_1545 *jrt.String = jrt.Intern("arbace.core$eval1769000197$fn__1769000198$fn__1769000199")

var Lit_1546 *jrt.String = jrt.Intern("arbace.core$eval1769000203$fn__1769000204")

var Lit_1547 *jrt.String = jrt.Intern("arbace.core$eval1769000215$fn__1769000216")

var Lit_1548 *jrt.String = jrt.Intern("arbace.core$eval1769000219$fn__1769000220")

var Lit_1549 *jrt.String = jrt.Intern("arbace.core$eval1769000223$fn__1769000224")

var Lit_1550 *jrt.String = jrt.Intern("arbace.core$eval1769000227$fn__1769000228")

var Lit_1551 *jrt.String = jrt.Intern("#{")

var Lit_1552 *jrt.String = jrt.Intern("}")

var Lit_1553 *jrt.String = jrt.Intern("arbace.core$eval1769000231$fn__1769000232")

var Lit_1554 *jrt.String = jrt.Intern("#")

var Lit_1555 *jrt.String = jrt.Intern("arbace.core$eval1769000235$fn__1769000236")

var Lit_1556 *jrt.String = jrt.Intern("arbace.core$eval1769000251$fn__1769000252")

var Lit_1557 *jrt.String = jrt.Intern("arbace.core$eval1769000255$fn__1769000256")

var Lit_1558 *jrt.String = jrt.Intern("arbace.core$eval1769000259$fn__1769000260")

var Lit_1559 *jrt.String = jrt.Intern("arbace.core$eval1769000263$fn__1769000264")

var Lit_1560 *jrt.String = jrt.Intern("arbace.core$eval1769000267$fn__1769000268")

var Lit_1561 *jrt.String = jrt.Intern("arbace.core$eval1769000271$fn__1769000272")

var Lit_1562 *jrt.String = jrt.Intern("arbace.core$eval1769000275$fn__1769000276")

var Lit_1563 *jrt.String = jrt.Intern("arbace.core$eval1769000279$fn__1769000280")

var Lit_1564 *jrt.String = jrt.Intern("arbace.core$eval1769000283$fn__1769000284")

var Lit_1565 *jrt.String = jrt.Intern("arbace.core$eval1769000287$fn__1769000288")

var Lit_1566 *jrt.String = jrt.Intern("arbace.core$eval1769000291$fn__1769000292")

var Lit_1567 *jrt.String = jrt.Intern("arbace.core$eval1769000295$fn__1769000296")

var Lit_1568 *jrt.String = jrt.Intern("arbace.core$eval1769000299$fn__1769000300")

var Lit_1569 *jrt.String = jrt.Intern("arbace.core$eval1769000303$fn__1769000304")

var Lit_1570 *jrt.String = jrt.Intern("#=(identity ")

var Lit_1571 *jrt.String = jrt.Intern("#=(java.lang.Class/forName \"")

var Lit_1572 *jrt.String = jrt.Intern("\")")

var Lit_1573 *jrt.String = jrt.Intern("#=")

var Lit_1574 *jrt.String = jrt.Intern("arbace.core$eval1769000307$fn__1769000308")

var Lit_1575 *jrt.String = jrt.Intern("M")

var Lit_1576 *jrt.String = jrt.Intern("arbace.core$eval1769000311$fn__1769000312")

var Lit_1577 *jrt.String = jrt.Intern("N")

var Lit_1578 *jrt.String = jrt.Intern("arbace.core$eval1769000315$fn__1769000316")

var Lit_1579 *jrt.String = jrt.Intern("#\"")

var Lit_1580 *jrt.String = jrt.Intern("\\E\\\"\\Q")

var Lit_1581 *jrt.String = jrt.Intern("\\\"")

var Lit_1582 *jrt.String = jrt.Intern("arbace.core$eval1769000332$fn__1769000333")

var Lit_1583 *jrt.String = jrt.Intern("arbace.core$eval1769000336$fn__1769000337")

var Lit_1584 *jrt.String = jrt.Intern("#=(find-ns ")

var Lit_1585 *jrt.String = jrt.Intern("arbace.core$eval1769000346$fn__1769000347")

var Lit_1586 *jrt.String = jrt.Intern("arbace.core$eval1769000350$fn__1769000351")

var Lit_1587 *jrt.String = jrt.Intern("arbace.core$eval1769000374$fn__1769000375")

var Lit_1588 *jrt.String = jrt.Intern("arbace.core$eval1769000378$fn__1769000379")

var Lit_1589 *jrt.String = jrt.Intern("arbace.core$eval1769000382$fn__1769000383")

var Lit_1590 *jrt.String = jrt.Intern("arbace.core$eval1769000386$fn__1769000387")

var Lit_1591 *jrt.String = jrt.Intern("#?")

var Lit_1592 *jrt.String = jrt.Intern("@")

var Lit_1593 *jrt.String = jrt.Intern("arbace.core$eval1927000798$fn__1927000799")

var Lit_1594 *jrt.String = jrt.Intern("arbace.core$eval1927000802$fn__1927000803")

var Lit_1595 *jrt.String = jrt.Intern("arbace.core$eval1927001289$booleans__1927001290")

var Lit_1596 *jrt.String = jrt.Intern("arbace.core$eval1927001300$bytes__1927001301")

var Lit_1597 *jrt.String = jrt.Intern("arbace.core$eval1927001311$chars__1927001312")

var Lit_1598 *jrt.String = jrt.Intern("arbace.core$eval1927001322$shorts__1927001323")

var Lit_1599 *jrt.String = jrt.Intern("arbace.core$eval1927001333$floats__1927001334")

var Lit_1600 *jrt.String = jrt.Intern("arbace.core$eval1927001344$ints__1927001345")

var Lit_1601 *jrt.String = jrt.Intern("arbace.core$eval1927001355$doubles__1927001356")

var Lit_1602 *jrt.String = jrt.Intern("arbace.core$eval1927001366$longs__1927001367")

var Lit_1603 *jrt.String = jrt.Intern("arbace.core$eval1927001833$fn__1927001834")

var Lit_1604 *jrt.String = jrt.Intern("arbace.core$eval1927001833$fn__1927001834$G__1927001825__1927001839")

var Lit_1605 *jrt.String = jrt.Intern("arbace.core$eval1927001833$fn__1927001834$G__1927001826__1927001836")

var Lit_1606 *jrt.String = jrt.Intern("inst_ms_STAR_")

var Lit_1607 *jrt.String = jrt.Intern("arbace.core$eval1927001847$fn__1927001848")

var Lit_1608 *jrt.String = jrt.Intern("arbace.core$eval1927001853$fn__1927001854")

var Lit_1609 *jrt.String = jrt.Intern("arbace.core$eval1927001862$fn__1927001863")

var Lit_1610 *jrt.String = jrt.Intern("arbace.core$eval1927001866$fn__1927001867")

var Lit_1611 *jrt.String = jrt.Intern("arbace.core$eval1927001870$fn__1927001871")

var Lit_1612 *jrt.String = jrt.Intern("arbace.core$eval1927001870$fn__1927001871$fn__1927001872")

var Lit_1613 *jrt.String = jrt.Intern("arbace.core$eval1927001876$fn__1927001877")

var Lit_1614 *jrt.String = jrt.Intern("arbace.core$eval1927001888$fn__1927001889")

var Lit_1615 *jrt.String = jrt.Intern("arbace.core$eval1927002196$__GT_Eduction__1927002198")

var Lit_1616 *jrt.String = jrt.Intern("arbace.core$eval1927002202$fn__1927002203")

var Lit_1617 *jrt.String = jrt.Intern("arbace.core$eval1927002249$fn__1927002250")

var Lit_1618 *jrt.String = jrt.Intern("arbace.core/tap-loop")

var Lit_1619 *jrt.String = jrt.Intern("arbace.core$eval1927002249$fn__1927002250$fn__1927002252")

var Lit_1620 *jrt.String = jrt.Intern("arbace.core$eval1927002249$fn__1927002250$fn__1927002252$fn__1927002257")

var Lit_1621 *jrt.String = jrt.Intern("arbace.core$eval1927002249$fn__1927002250$fn__1927002252$fn__1927002259")

var Lit_1622 *jrt.String = jrt.Intern("arbace.core$eval57000016$__GT_VecNode__57000018")

var Lit_1623 *jrt.String = jrt.Intern("arbace.core$eval57000025$__GT_ArrayChunk__57000027")

var Lit_1624 *jrt.String = jrt.Intern("arbace.core$eval57000030$__GT_VecSeq__57000034")

var Lit_1625 *jrt.String = jrt.Intern("arbace.core$eval57000037$fn__57000038")

var Lit_1626 *jrt.String = jrt.Intern("arbace.core$eval57000043$__GT_Vec__57000054")

var Lit_1627 *jrt.String = jrt.Intern("arbace.core$eval57000057$fn__57000058")

var Lit_1628 *jrt.String = jrt.Intern("arbace.core$even_QMARK_")

var Lit_1629 *jrt.String = jrt.Intern("Argument must be an integer: ")

var Lit_1630 *jrt.String = jrt.Intern("arbace.core$every_QMARK_")

var Lit_1631 *jrt.String = jrt.Intern("arbace.core$every_pred")

var Lit_1632 *jrt.String = jrt.Intern("arbace.core$every_pred$ep1__1927002052")

var Lit_1633 *jrt.String = jrt.Intern("arbace.core$every_pred$ep2__1927002054")

var Lit_1634 *jrt.String = jrt.Intern("arbace.core$every_pred$ep2__1927002054$fn__1927002055")

var Lit_1635 *jrt.String = jrt.Intern("arbace.core$every_pred$ep3__1927002058")

var Lit_1636 *jrt.String = jrt.Intern("arbace.core$every_pred$ep3__1927002058$fn__1927002059")

var Lit_1637 *jrt.String = jrt.Intern("arbace.core$every_pred$epn__1927002062")

var Lit_1638 *jrt.String = jrt.Intern("arbace.core$every_pred$epn__1927002062$fn__1927002063")

var Lit_1639 *jrt.String = jrt.Intern("arbace.core$every_pred$epn__1927002062$fn__1927002065")

var Lit_1640 *jrt.String = jrt.Intern("arbace.core$every_pred$epn__1927002062$fn__1927002067")

var Lit_1641 *jrt.String = jrt.Intern("arbace.core$every_pred$epn__1927002062$fn__1927002069")

var Lit_1642 *jrt.String = jrt.Intern("arbace.core$ex_cause")

var Lit_1643 *jrt.String = jrt.Intern("arbace.core$ex_data")

var Lit_1644 *jrt.String = jrt.Intern("arbace.core$ex_info")

var Lit_1645 *jrt.String = jrt.Intern("arbace.core$ex_message")

var Lit_1646 *jrt.String = jrt.Intern("arbace.core$expand_method_impl_cache")

var Lit_1647 *jrt.String = jrt.Intern("arbace.core$expand_method_impl_cache$fn__231000202")

var Lit_1648 *jrt.String = jrt.Intern("arbace.core$expand_method_impl_cache$fn__231000211")

var Lit_1649 *jrt.String = jrt.Intern("arbace.core$extend")

var Lit_1650 *jrt.String = jrt.Intern(" is not a protocol")

var Lit_1651 *jrt.String = jrt.Intern(" already directly implements ")

var Lit_1652 *jrt.String = jrt.Intern(" for protocol:")

var Lit_1653 *jrt.String = jrt.Intern("arbace.core$extend_protocol")

var Lit_1654 *jrt.String = jrt.Intern("arbace.core$extend_type")

var Lit_1655 *jrt.String = jrt.Intern("arbace.core$extenders")

var Lit_1656 *jrt.String = jrt.Intern("arbace.core$extends_QMARK_")

var Lit_1657 *jrt.String = jrt.Intern("arbace.core$false_QMARK_")

var Lit_1658 *jrt.String = jrt.Intern("arbace.core$ffirst__1927000018")

var Lit_1659 *jrt.String = jrt.Intern("arbace.core$file_seq")

var Lit_1660 *jrt.String = jrt.Intern("arbace.core$file_seq$fn__1927001150")

var Lit_1661 *jrt.String = jrt.Intern("arbace.core$file_seq$fn__1927001152")

var Lit_1662 *jrt.String = jrt.Intern("arbace.core$filter")

var Lit_1663 *jrt.String = jrt.Intern("arbace.core$filter$fn__1927000599")

var Lit_1664 *jrt.String = jrt.Intern("arbace.core$filter$fn__1927000599$fn__1927000600")

var Lit_1665 *jrt.String = jrt.Intern("arbace.core$filter$fn__1927000603")

var Lit_1666 *jrt.String = jrt.Intern("arbace.core$filter_key")

var Lit_1667 *jrt.String = jrt.Intern("arbace.core$filterv")

var Lit_1668 *jrt.String = jrt.Intern("arbace.core$filterv$fn__1927001895")

var Lit_1669 *jrt.String = jrt.Intern("arbace.core$find")

var Lit_1670 *jrt.String = jrt.Intern("arbace.core$find_keyword")

var Lit_1671 *jrt.String = jrt.Intern("arbace.core$find_ns")

var Lit_1672 *jrt.String = jrt.Intern("arbace.core$find_protocol_impl")

var Lit_1673 *jrt.String = jrt.Intern("arbace.core$find_protocol_impl$impl__231000220")

var Lit_1674 *jrt.String = jrt.Intern("arbace.core$find_protocol_method")

var Lit_1675 *jrt.String = jrt.Intern("arbace.core$find_var")

var Lit_1676 *jrt.String = jrt.Intern("arbace.core$first__1927000008")

var Lit_1677 *jrt.String = jrt.Intern("arbace.core$fits_table_QMARK_")

var Lit_1678 *jrt.String = jrt.Intern("arbace.core$flatten")

var Lit_1679 *jrt.String = jrt.Intern("arbace.core$float")

var Lit_1680 *jrt.String = jrt.Intern("arbace.core$float_QMARK_")

var Lit_1681 *jrt.String = jrt.Intern("arbace.core$float__inliner__1927000751")

var Lit_1682 *jrt.String = jrt.Intern("arbace.core$float_array")

var Lit_1683 *jrt.String = jrt.Intern("arbace.core$float_array__inliner__1927001257")

var Lit_1684 *jrt.String = jrt.Intern("arbace.core$floats")

var Lit_1685 *jrt.String = jrt.Intern("arbace.core$flush")

var Lit_1686 *jrt.String = jrt.Intern("arbace.core$fn")

var Lit_1687 *jrt.String = jrt.Intern("Parameter declaration ")

var Lit_1688 *jrt.String = jrt.Intern(" should be a vector")

var Lit_1689 *jrt.String = jrt.Intern("arbace.core$fn$psig__1927000991")

var Lit_1690 *jrt.String = jrt.Intern("Invalid signature ")

var Lit_1691 *jrt.String = jrt.Intern(" should be a list")

var Lit_1692 *jrt.String = jrt.Intern("arbace.core$fn$psig__1927000991$fn__1927000995")

var Lit_1693 *jrt.String = jrt.Intern("arbace.core$fn$psig__1927000991$fn__1927000997")

var Lit_1694 *jrt.String = jrt.Intern("arbace.core$fn_QMARK_")

var Lit_1695 *jrt.String = jrt.Intern("arbace.core$fn__1056000106")

var Lit_1696 *jrt.String = jrt.Intern("arbace.core$fn__1056000109")

var Lit_1697 *jrt.String = jrt.Intern("arbace.core$fn__1056000112")

var Lit_1698 *jrt.String = jrt.Intern("arbace.core$fn__1056000115")

var Lit_1699 *jrt.String = jrt.Intern("arbace.core$fn__1056000118")

var Lit_1700 *jrt.String = jrt.Intern("arbace.core$fn__1056000121")

var Lit_1701 *jrt.String = jrt.Intern("arbace.core$fn__1056000124")

var Lit_1702 *jrt.String = jrt.Intern("arbace.core$fn__1056000127")

var Lit_1703 *jrt.String = jrt.Intern("arbace.core$fn__1056000130")

var Lit_1704 *jrt.String = jrt.Intern("arbace.core$fn__1056000133")

var Lit_1705 *jrt.String = jrt.Intern("arbace.core$fn__1056000136")

var Lit_1706 *jrt.String = jrt.Intern("arbace.core$fn__1056000139")

var Lit_1707 *jrt.String = jrt.Intern("arbace.core$fn__1056000142")

var Lit_1708 *jrt.String = jrt.Intern("arbace.core$fn__1056000145")

var Lit_1709 *jrt.String = jrt.Intern("arbace.core$fn__1056000148")

var Lit_1710 *jrt.String = jrt.Intern("arbace.core$fn__1927000006")

var Lit_1711 *jrt.String = jrt.Intern("arbace.core$fn__1927000042")

var Lit_1712 *jrt.String = jrt.Intern("arbace.core$fn__1927001963")

var Lit_1713 *jrt.String = jrt.Intern("arbace.version")

var Lit_1714 *jrt.String = jrt.Intern("getResourceAsStream")

var Lit_1715 *jrt.String = jrt.Intern("arbace/version.edn")

var Lit_1716 *jrt.String = jrt.Intern("arbace.core$fn__1927001963$fn__1927001968")

var Lit_1717 *jrt.String = jrt.Intern("UTF-8")

var Lit_1718 *jrt.String = jrt.Intern("arbace.core$fn__1927001963$parse__1927001964")

var Lit_1719 *jrt.String = jrt.Intern("arbace.core$fn__1927001963$parse__1927001964$fn__1927001965")

var Lit_1720 *jrt.String = jrt.Intern("arbace.core$fnext__1927000022")

var Lit_1721 *jrt.String = jrt.Intern("arbace.core$fnil")

var Lit_1722 *jrt.String = jrt.Intern("arbace.core$fnil$fn__1927001685")

var Lit_1723 *jrt.String = jrt.Intern("arbace.core$fnil$fn__1927001687")

var Lit_1724 *jrt.String = jrt.Intern("arbace.core$fnil$fn__1927001689")

var Lit_1725 *jrt.String = jrt.Intern("arbace.core$for")

var Lit_1726 *jrt.String = jrt.Intern("arbace.core$for$emit_bind__1927001051")

var Lit_1727 *jrt.String = jrt.Intern("iter__")

var Lit_1728 *jrt.String = jrt.Intern("s__")

var Lit_1729 *jrt.String = jrt.Intern("i__")

var Lit_1730 *jrt.String = jrt.Intern("b__")

var Lit_1731 *jrt.String = jrt.Intern("arbace.core$for$emit_bind__1927001051$do_cmod__1927001074")

var Lit_1732 *jrt.String = jrt.Intern("Invalid 'for' keyword ")

var Lit_1733 *jrt.String = jrt.Intern("arbace.core$for$emit_bind__1927001051$do_mod__1927001065")

var Lit_1734 *jrt.String = jrt.Intern("arbace.core$for$err__1927001048")

var Lit_1735 *jrt.String = jrt.Intern("arbace.core$for$to_groups__1927001040")

var Lit_1736 *jrt.String = jrt.Intern("arbace.core$for$to_groups__1927001040$fn__1927001042")

var Lit_1737 *jrt.String = jrt.Intern("arbace.core$for_each")

var Lit_1738 *jrt.String = jrt.Intern("arbace.core$force")

var Lit_1739 *jrt.String = jrt.Intern("arbace.core$format")

var Lit_1740 *jrt.String = jrt.Intern("arbace.core$frequencies")

var Lit_1741 *jrt.String = jrt.Intern("arbace.core$frequencies$fn__1927001994")

var Lit_1742 *jrt.String = jrt.Intern("arbace.core$future")

var Lit_1743 *jrt.String = jrt.Intern("arbace.core$future_QMARK_")

var Lit_1744 *jrt.String = jrt.Intern("arbace.core$future_call")

var Lit_1745 *jrt.String = jrt.Intern("arbace.core$future_cancel")

var Lit_1746 *jrt.String = jrt.Intern("arbace.core$future_cancelled_QMARK_")

var Lit_1747 *jrt.String = jrt.Intern("arbace.core$future_done_QMARK_")

var Lit_1748 *jrt.String = jrt.Intern("arbace.core$gen_class")

var Lit_1749 *jrt.String = jrt.Intern("arbace.core$gen_interface")

var Lit_1750 *jrt.String = jrt.Intern("Interface methods must not contain '-'")

var Lit_1751 *jrt.String = jrt.Intern("arbace.core$gen_interface$fn__750000018")

var Lit_1752 *jrt.String = jrt.Intern("arbace.core$gensym")

var Lit_1753 *jrt.String = jrt.Intern("G__")

var Lit_1754 *jrt.String = jrt.Intern("arbace.core$get")

var Lit_1755 *jrt.String = jrt.Intern("arbace.core$get__inliner__1927000334")

var Lit_1756 *jrt.String = jrt.Intern("arbace.core$get_in")

var Lit_1757 *jrt.String = jrt.Intern("arbace.core$get_method")

var Lit_1758 *jrt.String = jrt.Intern("arbace.core$get_proxy_class")

var Lit_1759 *jrt.String = jrt.Intern("arbace.core$get_super_and_interfaces")

var Lit_1760 *jrt.String = jrt.Intern("arbace.core$get_thread_bindings")

var Lit_1761 *jrt.String = jrt.Intern("arbace.core$get_validator")

var Lit_1762 *jrt.String = jrt.Intern("arbace.core$group_by")

var Lit_1763 *jrt.String = jrt.Intern("arbace.core$group_by$fn__1927001979")

var Lit_1764 *jrt.String = jrt.Intern("arbace.core$group_by_sig")

var Lit_1765 *jrt.String = jrt.Intern("arbace.core$group_by_sig$fn__840000030")

var Lit_1766 *jrt.String = jrt.Intern("arbace.core$halt_when")

var Lit_1767 *jrt.String = jrt.Intern("arbace.core$halt_when$fn__1927002181")

var Lit_1768 *jrt.String = jrt.Intern("arbace.core$halt_when$fn__1927002181$fn__1927002182")

var Lit_1769 *jrt.String = jrt.Intern("arbace.core$hash")

var Lit_1770 *jrt.String = jrt.Intern("arbace.core$hash_combine")

var Lit_1771 *jrt.String = jrt.Intern("arbace.core$hash_map")

var Lit_1772 *jrt.String = jrt.Intern("arbace.core$hash_ordered_coll")

var Lit_1773 *jrt.String = jrt.Intern("arbace.core$hash_set")

var Lit_1774 *jrt.String = jrt.Intern("arbace.core$hash_unordered_coll")

var Lit_1775 *jrt.String = jrt.Intern("arbace.core$ident_QMARK_")

var Lit_1776 *jrt.String = jrt.Intern("arbace.core$identical_QMARK_")

var Lit_1777 *jrt.String = jrt.Intern("arbace.core$identical_QMARK___inliner__1927000158")

var Lit_1778 *jrt.String = jrt.Intern("arbace.core$identity")

var Lit_1779 *jrt.String = jrt.Intern("arbace.core$if_instance")

var Lit_1780 *jrt.String = jrt.Intern("arbace.core$if_let")

var Lit_1781 *jrt.String = jrt.Intern("arbace.core$if_not")

var Lit_1782 *jrt.String = jrt.Intern("arbace.core$if_some")

var Lit_1783 *jrt.String = jrt.Intern("arbace.core$ifn_QMARK_")

var Lit_1784 *jrt.String = jrt.Intern("arbace.core$imap_cons")

var Lit_1785 *jrt.String = jrt.Intern("arbace.core$implements_QMARK_")

var Lit_1786 *jrt.String = jrt.Intern("arbace.core$import")

var Lit_1787 *jrt.String = jrt.Intern("arbace.core$import$fn__1927000728")

var Lit_1788 *jrt.String = jrt.Intern("arbace.core$import$fn__1927000730")

var Lit_1789 *jrt.String = jrt.Intern("arbace.core$import$fn__1927000732")

var Lit_1790 *jrt.String = jrt.Intern("arbace.core$import$fn__1927000732$fn__1927000733")

var Lit_1791 *jrt.String = jrt.Intern("arbace.core$inc")

var Lit_1792 *jrt.String = jrt.Intern("arbace.core$inc_SINGLEQUOTE_")

var Lit_1793 *jrt.String = jrt.Intern("arbace.core$inc_SINGLEQUOTE___inliner__1927000195")

var Lit_1794 *jrt.String = jrt.Intern("arbace.core$inc__inliner__1927000198")

var Lit_1795 *jrt.String = jrt.Intern("arbace.core$indexed_QMARK_")

var Lit_1796 *jrt.String = jrt.Intern("arbace.core$infinite_QMARK_")

var Lit_1797 *jrt.String = jrt.Intern("arbace.core$infinite_QMARK___inliner__1927002284")

var Lit_1798 *jrt.String = jrt.Intern("arbace.core$init_proxy")

var Lit_1799 *jrt.String = jrt.Intern("arbace.core$inst_QMARK_")

var Lit_1800 *jrt.String = jrt.Intern("arbace.core$inst_ms")

var Lit_1801 *jrt.String = jrt.Intern("arbace.core$instance_QMARK___1927000028")

var Lit_1802 *jrt.String = jrt.Intern("arbace.core$int")

var Lit_1803 *jrt.String = jrt.Intern("arbace.core$int_QMARK_")

var Lit_1804 *jrt.String = jrt.Intern("arbace.core$int__inliner__1927000186")

var Lit_1805 *jrt.String = jrt.Intern("arbace.core$int_array")

var Lit_1806 *jrt.String = jrt.Intern("arbace.core$int_array__inliner__1927001278")

var Lit_1807 *jrt.String = jrt.Intern("arbace.core$integer_QMARK_")

var Lit_1808 *jrt.String = jrt.Intern("arbace.core$interleave")

var Lit_1809 *jrt.String = jrt.Intern("arbace.core$interleave$fn__1927000925")

var Lit_1810 *jrt.String = jrt.Intern("arbace.core$interleave$fn__1927000927")

var Lit_1811 *jrt.String = jrt.Intern("arbace.core$interleave$fn__1927000929")

var Lit_1812 *jrt.String = jrt.Intern("arbace.core$intern")

var Lit_1813 *jrt.String = jrt.Intern("arbace.core$interpose")

var Lit_1814 *jrt.String = jrt.Intern("arbace.core$interpose$fn__1927001226")

var Lit_1815 *jrt.String = jrt.Intern("arbace.core$interpose$fn__1927001226$fn__1927001227")

var Lit_1816 *jrt.String = jrt.Intern("arbace.core$into")

var Lit_1817 *jrt.String = jrt.Intern("arbace.core$into$rf__1927001885")

var Lit_1818 *jrt.String = jrt.Intern("arbace.core$into0")

var Lit_1819 *jrt.String = jrt.Intern("arbace.core$into_array")

var Lit_1820 *jrt.String = jrt.Intern("arbace.core$ints")

var Lit_1821 *jrt.String = jrt.Intern("arbace.core$io_BANG_")

var Lit_1822 *jrt.String = jrt.Intern("I/O in transaction")

var Lit_1823 *jrt.String = jrt.Intern("arbace.core$isa_QMARK_")

var Lit_1824 *jrt.String = jrt.Intern("arbace.core$isa_QMARK_$fn__1927001413")

var Lit_1825 *jrt.String = jrt.Intern("arbace.core$iterate")

var Lit_1826 *jrt.String = jrt.Intern("arbace.core$iteration")

var Lit_1827 *jrt.String = jrt.Intern("arbace.core$iteration$reify__1927002219$next__1927002220")

var Lit_1828 *jrt.String = jrt.Intern("arbace.core$iteration$reify__1927002219$next__1927002220$fn__1927002221")

var Lit_1829 *jrt.String = jrt.Intern("arbace.core$iterator_seq")

var Lit_1830 *jrt.String = jrt.Intern("arbace.core$java_assert")

var Lit_1831 *jrt.String = jrt.Intern("arbace.core$java_str")

var Lit_1832 *jrt.String = jrt.Intern("arbace.core$juxt")

var Lit_1833 *jrt.String = jrt.Intern("arbace.core$juxt$fn__1927000532")

var Lit_1834 *jrt.String = jrt.Intern("arbace.core$juxt$fn__1927000534")

var Lit_1835 *jrt.String = jrt.Intern("arbace.core$juxt$fn__1927000536")

var Lit_1836 *jrt.String = jrt.Intern("arbace.core$juxt$fn__1927000538")

var Lit_1837 *jrt.String = jrt.Intern("arbace.core$juxt$fn__1927000538$fn__1927000539")

var Lit_1838 *jrt.String = jrt.Intern("arbace.core$juxt$fn__1927000538$fn__1927000541")

var Lit_1839 *jrt.String = jrt.Intern("arbace.core$juxt$fn__1927000538$fn__1927000543")

var Lit_1840 *jrt.String = jrt.Intern("arbace.core$juxt$fn__1927000538$fn__1927000545")

var Lit_1841 *jrt.String = jrt.Intern("arbace.core$juxt$fn__1927000538$fn__1927000547")

var Lit_1842 *jrt.String = jrt.Intern("arbace.core$keep")

var Lit_1843 *jrt.String = jrt.Intern("arbace.core$keep$fn__1927002029")

var Lit_1844 *jrt.String = jrt.Intern("arbace.core$keep$fn__1927002029$fn__1927002030")

var Lit_1845 *jrt.String = jrt.Intern("arbace.core$keep$fn__1927002033")

var Lit_1846 *jrt.String = jrt.Intern("arbace.core$keep_indexed")

var Lit_1847 *jrt.String = jrt.Intern("arbace.core$keep_indexed$fn__1927002036")

var Lit_1848 *jrt.String = jrt.Intern("arbace.core$keep_indexed$fn__1927002036$fn__1927002037")

var Lit_1849 *jrt.String = jrt.Intern("arbace.core$keep_indexed$keepi__1927002040")

var Lit_1850 *jrt.String = jrt.Intern("arbace.core$keep_indexed$keepi__1927002040$fn__1927002041")

var Lit_1851 *jrt.String = jrt.Intern("arbace.core$key")

var Lit_1852 *jrt.String = jrt.Intern("arbace.core$keys")

var Lit_1853 *jrt.String = jrt.Intern("arbace.core$keyword")

var Lit_1854 *jrt.String = jrt.Intern("arbace.core$keyword_QMARK_")

var Lit_1855 *jrt.String = jrt.Intern("arbace.core$label")

var Lit_1856 *jrt.String = jrt.Intern("arbace.core$lambda")

var Lit_1857 *jrt.String = jrt.Intern("arbace.core$last__1927000054")

var Lit_1858 *jrt.String = jrt.Intern("arbace.core$lazy_cat")

var Lit_1859 *jrt.String = jrt.Intern("arbace.core$lazy_cat$fn__1927001028")

var Lit_1860 *jrt.String = jrt.Intern("arbace.core$lazy_seq")

var Lit_1861 *jrt.String = jrt.Intern("arbace.core$let")

var Lit_1862 *jrt.String = jrt.Intern("arbace.core$let__1927000002")

var Lit_1863 *jrt.String = jrt.Intern("arbace.core$letclass")

var Lit_1864 *jrt.String = jrt.Intern("arbace.core$letfn")

var Lit_1865 *jrt.String = jrt.Intern("arbace.core$letfn$fn__1927001678")

var Lit_1866 *jrt.String = jrt.Intern("arbace.core$libspec_QMARK_")

var Lit_1867 *jrt.String = jrt.Intern("arbace.core$lift_ns")

var Lit_1868 *jrt.String = jrt.Intern("arbace.core$line_seq")

var Lit_1869 *jrt.String = jrt.Intern("arbace.core$line_seq$fn__1927000656")

var Lit_1870 *jrt.String = jrt.Intern("arbace.core$list_QMARK_")

var Lit_1871 *jrt.String = jrt.Intern("arbace.core$list_STAR_")

var Lit_1872 *jrt.String = jrt.Intern("arbace.core$load")

var Lit_1873 *jrt.String = jrt.Intern("(arbace.core/load \"%s\")\n")

var Lit_1874 *jrt.String = jrt.Intern("arbace.core$load$fn__1927001573")

var Lit_1875 *jrt.String = jrt.Intern("arbace.core$load$fn__1927001575")

var Lit_1876 *jrt.String = jrt.Intern("arbace.core$load_all")

var Lit_1877 *jrt.String = jrt.Intern("arbace.core$load_all$fn__1927001523")

var Lit_1878 *jrt.String = jrt.Intern("arbace.core$load_all$fn__1927001523$fn__1927001524")

var Lit_1879 *jrt.String = jrt.Intern("arbace.core$load_all$fn__1927001523$fn__1927001526")

var Lit_1880 *jrt.String = jrt.Intern("arbace.core$load_data_reader_file")

var Lit_1881 *jrt.String = jrt.Intern("cljc")

var Lit_1882 *jrt.String = jrt.Intern("Not a valid data-reader map")

var Lit_1883 *jrt.String = jrt.Intern("arbace.core$load_data_reader_file$fn__1927002233")

var Lit_1884 *jrt.String = jrt.Intern("Invalid form in data-reader file")

var Lit_1885 *jrt.String = jrt.Intern("Conflicting data-reader mapping")

var Lit_1886 *jrt.String = jrt.Intern("arbace.core$load_data_readers")

var Lit_1887 *jrt.String = jrt.Intern("arbace.core$load_data_readers$fn__1927002239")

var Lit_1888 *jrt.String = jrt.Intern("arbace.core$load_lib")

var Lit_1889 *jrt.String = jrt.Intern("Found lib name '%s' containing period with prefix '%s'.  lib names inside prefix lists must not contain periods")

var Lit_1890 *jrt.String = jrt.Intern("namespace '%s' not found")

var Lit_1891 *jrt.String = jrt.Intern("(arbace.core/in-ns '%s)\n")

var Lit_1892 *jrt.String = jrt.Intern("(arbace.core/alias '%s '%s)\n")

var Lit_1893 *jrt.String = jrt.Intern("(arbace.core/refer '%s")

var Lit_1894 *jrt.String = jrt.Intern(" %s '%s")

var Lit_1895 *jrt.String = jrt.Intern(")\n")

var Lit_1896 *jrt.String = jrt.Intern("arbace.core$load_lib$fn__1927001532")

var Lit_1897 *jrt.String = jrt.Intern("arbace.core$load_lib$fn__1927001534")

var Lit_1898 *jrt.String = jrt.Intern("arbace.core$load_libs")

var Lit_1899 *jrt.String = jrt.Intern("Unsupported option(s) supplied: ")

var Lit_1900 *jrt.String = jrt.Intern("Nothing specified to load")

var Lit_1901 *jrt.String = jrt.Intern("prefix cannot be nil")

var Lit_1902 *jrt.String = jrt.Intern("arbace.core$load_one")

var Lit_1903 *jrt.String = jrt.Intern("namespace '%s' not found after loading '%s'")

var Lit_1904 *jrt.String = jrt.Intern("arbace.core$load_one$fn__1927001518")

var Lit_1905 *jrt.String = jrt.Intern("arbace.core$load_reader")

var Lit_1906 *jrt.String = jrt.Intern("arbace.core$load_string")

var Lit_1907 *jrt.String = jrt.Intern("arbace.core$loaded_libs")

var Lit_1908 *jrt.String = jrt.Intern("arbace.core$locking")

var Lit_1909 *jrt.String = jrt.Intern("arbace.core$long")

var Lit_1910 *jrt.String = jrt.Intern("arbace.core$long__inliner__1927000748")

var Lit_1911 *jrt.String = jrt.Intern("arbace.core$long_array")

var Lit_1912 *jrt.String = jrt.Intern("arbace.core$long_array__inliner__1927001281")

var Lit_1913 *jrt.String = jrt.Intern("arbace.core$longs")

var Lit_1914 *jrt.String = jrt.Intern("arbace.core$loop")

var Lit_1915 *jrt.String = jrt.Intern("arbace.core$loop$fn__1927001005")

var Lit_1916 *jrt.String = jrt.Intern("arbace.core$loop$fn__1927001008")

var Lit_1917 *jrt.String = jrt.Intern("arbace.core$loop__1927000004")

var Lit_1918 *jrt.String = jrt.Intern("arbace.core$macroexpand")

var Lit_1919 *jrt.String = jrt.Intern("arbace.core$macroexpand_1")

var Lit_1920 *jrt.String = jrt.Intern("arbace.core$make_array")

var Lit_1921 *jrt.String = jrt.Intern("arbace.core$make_hierarchy")

var Lit_1922 *jrt.String = jrt.Intern("arbace.core$map")

var Lit_1923 *jrt.String = jrt.Intern("arbace.core$map$fn__1927000573")

var Lit_1924 *jrt.String = jrt.Intern("arbace.core$map$fn__1927000573$fn__1927000574")

var Lit_1925 *jrt.String = jrt.Intern("arbace.core$map$fn__1927000577")

var Lit_1926 *jrt.String = jrt.Intern("arbace.core$map$fn__1927000579")

var Lit_1927 *jrt.String = jrt.Intern("arbace.core$map$fn__1927000581")

var Lit_1928 *jrt.String = jrt.Intern("arbace.core$map$fn__1927000587")

var Lit_1929 *jrt.String = jrt.Intern("arbace.core$map$step__1927000583")

var Lit_1930 *jrt.String = jrt.Intern("arbace.core$map$step__1927000583$fn__1927000584")

var Lit_1931 *jrt.String = jrt.Intern("arbace.core$map_QMARK___1927000036")

var Lit_1932 *jrt.String = jrt.Intern("arbace.core$map_entry_QMARK_")

var Lit_1933 *jrt.String = jrt.Intern("arbace.core$map_indexed")

var Lit_1934 *jrt.String = jrt.Intern("arbace.core$map_indexed$fn__1927002020")

var Lit_1935 *jrt.String = jrt.Intern("arbace.core$map_indexed$fn__1927002020$fn__1927002021")

var Lit_1936 *jrt.String = jrt.Intern("arbace.core$map_indexed$mapi__1927002024")

var Lit_1937 *jrt.String = jrt.Intern("arbace.core$map_indexed$mapi__1927002024$fn__1927002025")

var Lit_1938 *jrt.String = jrt.Intern("arbace.core$mapcat")

var Lit_1939 *jrt.String = jrt.Intern("arbace.core$mapv")

var Lit_1940 *jrt.String = jrt.Intern("arbace.core$mapv$fn__1927001892")

var Lit_1941 *jrt.String = jrt.Intern("arbace.core$max")

var Lit_1942 *jrt.String = jrt.Intern("arbace.core$max_key")

var Lit_1943 *jrt.String = jrt.Intern("arbace.core$maybe_destructured")

var Lit_1944 *jrt.String = jrt.Intern("p__")

var Lit_1945 *jrt.String = jrt.Intern("arbace.core$maybe_min_hash")

var Lit_1946 *jrt.String = jrt.Intern("arbace.core$maybe_min_hash$fn__1927001696")

var Lit_1947 *jrt.String = jrt.Intern("arbace.core$maybe_min_hash$fn__1927001696$fn__1927001700")

var Lit_1948 *jrt.String = jrt.Intern("arbace.core$maybe_min_hash$fn__1927001719")

var Lit_1949 *jrt.String = jrt.Intern("arbace.core$maybe_min_hash$iter__1927001703__1927001709")

var Lit_1950 *jrt.String = jrt.Intern("arbace.core$maybe_min_hash$iter__1927001703__1927001709$fn__1927001710")

var Lit_1951 *jrt.String = jrt.Intern("arbace.core$maybe_min_hash$iter__1927001703__1927001709$fn__1927001710$iter__1927001705__1927001711")

var Lit_1952 *jrt.String = jrt.Intern("arbace.core$maybe_min_hash$iter__1927001703__1927001709$fn__1927001710$iter__1927001705__1927001711$fn__1927001712")

var Lit_1953 *jrt.String = jrt.Intern("arbace.core$maybe_min_hash$iter__1927001703__1927001709$fn__1927001710$iter__1927001705__1927001711$fn__1927001712$fn__1927001713")

var Lit_1954 *jrt.String = jrt.Intern("arbace.core$memfn")

var Lit_1955 *jrt.String = jrt.Intern("target")

var Lit_1956 *jrt.String = jrt.Intern("arbace.core$memoize")

var Lit_1957 *jrt.String = jrt.Intern("arbace.core$memoize$fn__1927001613")

var Lit_1958 *jrt.String = jrt.Intern("arbace.core$merge")

var Lit_1959 *jrt.String = jrt.Intern("arbace.core$merge_deep")

var Lit_1960 *jrt.String = jrt.Intern("arbace.core$merge_deep$fn__1927001901")

var Lit_1961 *jrt.String = jrt.Intern("arbace.core$merge_deep_with")

var Lit_1962 *jrt.String = jrt.Intern("arbace.core$merge_deep_with$fn__1927001904")

var Lit_1963 *jrt.String = jrt.Intern("arbace.core$merge_hash_collisions")

var Lit_1964 *jrt.String = jrt.Intern("arbace.core$merge_hash_collisions$assoc_multi__1927001734")

var Lit_1965 *jrt.String = jrt.Intern("arbace.core$merge_hash_collisions$assoc_multi__1927001734$fn__1927001735")

var Lit_1966 *jrt.String = jrt.Intern("arbace.core$merge_hash_collisions$fn__1927001732")

var Lit_1967 *jrt.String = jrt.Intern("arbace.core$merge_hash_collisions$fn__1927001739")

var Lit_1968 *jrt.String = jrt.Intern("arbace.core$merge_hash_collisions$fn__1927001744")

var Lit_1969 *jrt.String = jrt.Intern("arbace.core$merge_with")

var Lit_1970 *jrt.String = jrt.Intern("arbace.core$merge_with$fn__1927000718")

var Lit_1971 *jrt.String = jrt.Intern("arbace.core$merge_with$merge2__1927000720")

var Lit_1972 *jrt.String = jrt.Intern("arbace.core$merge_with$this__1927000714")

var Lit_1973 *jrt.String = jrt.Intern("arbace.core$merge_with$this__1927000716")

var Lit_1974 *jrt.String = jrt.Intern("arbace.core$meta__1927000044")

var Lit_1975 *jrt.String = jrt.Intern("arbace.core$method_ref")

var Lit_1976 *jrt.String = jrt.Intern("arbace.core$method_sig")

var Lit_1977 *jrt.String = jrt.Intern("arbace.core$methods")

var Lit_1978 *jrt.String = jrt.Intern("arbace.core$min")

var Lit_1979 *jrt.String = jrt.Intern("arbace.core$min_key")

var Lit_1980 *jrt.String = jrt.Intern("arbace.core$mix_collection_hash")

var Lit_1981 *jrt.String = jrt.Intern("arbace.core$mk_am")

var Lit_1982 *jrt.String = jrt.Intern("s")

var Lit_1983 *jrt.String = jrt.Intern("-array")

var Lit_1984 *jrt.String = jrt.Intern("arbace.core$mk_bound_fn")

var Lit_1985 *jrt.String = jrt.Intern("arbace.core$mk_bound_fn$fn__1927001204")

var Lit_1986 *jrt.String = jrt.Intern("arbace.core$mod")

var Lit_1987 *jrt.String = jrt.Intern("arbace.core$most_specific")

var Lit_1988 *jrt.String = jrt.Intern("Incompatible return types")

var Lit_1989 *jrt.String = jrt.Intern("arbace.core$most_specific$fn__840000024")

var Lit_1990 *jrt.String = jrt.Intern("arbace.core$most_specific$fn__840000024$fn__840000025")

var Lit_1991 *jrt.String = jrt.Intern("arbace.core$munge")

var Lit_1992 *jrt.String = jrt.Intern("arbace.core$name")

var Lit_1993 *jrt.String = jrt.Intern("arbace.core$namespace")

var Lit_1994 *jrt.String = jrt.Intern("arbace.core$namespace_munge")

var Lit_1995 *jrt.String = jrt.Intern("arbace.core$nary_inline")

var Lit_1996 *jrt.String = jrt.Intern("arbace.core$nary_inline$fn__1927000203")

var Lit_1997 *jrt.String = jrt.Intern("arbace.core$nary_inline$fn__1927000203$fn__1927000204")

var Lit_1998 *jrt.String = jrt.Intern("arbace.core$nat_int_QMARK_")

var Lit_1999 *jrt.String = jrt.Intern("arbace.core$neg_QMARK_")

var Lit_2000 *jrt.String = jrt.Intern("arbace.core$neg_QMARK___inliner__1927000285")

var Lit_2001 *jrt.String = jrt.Intern("arbace.core$neg_int_QMARK_")

var Lit_2002 *jrt.String = jrt.Intern("arbace.core$newline")

var Lit_2003 *jrt.String = jrt.Intern("arbace.core$next__1927000010")

var Lit_2004 *jrt.String = jrt.Intern("arbace.core$nfirst__1927000020")

var Lit_2005 *jrt.String = jrt.Intern("arbace.core$nil_QMARK_")

var Lit_2006 *jrt.String = jrt.Intern("arbace.core$nil_QMARK___inliner__1927000072")

var Lit_2007 *jrt.String = jrt.Intern("arbace.core$nnext__1927000024")

var Lit_2008 *jrt.String = jrt.Intern("arbace.core$normalize_slurp_opts")

var Lit_2009 *jrt.String = jrt.Intern("WARNING: (slurp f enc) is deprecated, use (slurp f :encoding enc).")

var Lit_2010 *jrt.String = jrt.Intern("arbace.core$not")

var Lit_2011 *jrt.String = jrt.Intern("arbace.core$not_EQ_")

var Lit_2012 *jrt.String = jrt.Intern("arbace.core$not_empty")

var Lit_2013 *jrt.String = jrt.Intern("arbace.core$ns")

var Lit_2014 *jrt.String = jrt.Intern("arbace.core$ns$fn__1927001482")

var Lit_2015 *jrt.String = jrt.Intern("arbace.core$ns$fn__1927001484")

var Lit_2016 *jrt.String = jrt.Intern("arbace.core$ns$fn__1927001486")

var Lit_2017 *jrt.String = jrt.Intern("arbace.core$ns$process_reference__1927001475")

var Lit_2018 *jrt.String = jrt.Intern("arbace.core$ns$process_reference__1927001475$fn__1927001479")

var Lit_2019 *jrt.String = jrt.Intern("arbace.core$ns_aliases")

var Lit_2020 *jrt.String = jrt.Intern("arbace.core$ns_imports")

var Lit_2021 *jrt.String = jrt.Intern("arbace.core$ns_interns")

var Lit_2022 *jrt.String = jrt.Intern("arbace.core$ns_interns$fn__1927000904")

var Lit_2023 *jrt.String = jrt.Intern("arbace.core$ns_map")

var Lit_2024 *jrt.String = jrt.Intern("arbace.core$ns_name")

var Lit_2025 *jrt.String = jrt.Intern("arbace.core$ns_publics")

var Lit_2026 *jrt.String = jrt.Intern("arbace.core$ns_publics$fn__1927000900")

var Lit_2027 *jrt.String = jrt.Intern("arbace.core$ns_refers")

var Lit_2028 *jrt.String = jrt.Intern("arbace.core$ns_refers$fn__1927000912")

var Lit_2029 *jrt.String = jrt.Intern("arbace.core$ns_resolve")

var Lit_2030 *jrt.String = jrt.Intern("arbace.core$ns_unalias")

var Lit_2031 *jrt.String = jrt.Intern("arbace.core$ns_unmap")

var Lit_2032 *jrt.String = jrt.Intern("arbace.core$nth")

var Lit_2033 *jrt.String = jrt.Intern("arbace.core$nth__inliner__1927000189")

var Lit_2034 *jrt.String = jrt.Intern("arbace.core$nthnext")

var Lit_2035 *jrt.String = jrt.Intern("arbace.core$nthrest")

var Lit_2036 *jrt.String = jrt.Intern("arbace.core$nthrest$fn__1927000669")

var Lit_2037 *jrt.String = jrt.Intern("arbace.core$num")

var Lit_2038 *jrt.String = jrt.Intern("arbace.core$num__inliner__1927000745")

var Lit_2039 *jrt.String = jrt.Intern("arbace.core$number_QMARK_")

var Lit_2040 *jrt.String = jrt.Intern("arbace.core$numerator")

var Lit_2041 *jrt.String = jrt.Intern("arbace.core$object_array")

var Lit_2042 *jrt.String = jrt.Intern("arbace.core$object_array__inliner__1927001275")

var Lit_2043 *jrt.String = jrt.Intern("arbace.core$odd_QMARK_")

var Lit_2044 *jrt.String = jrt.Intern("arbace.core$or")

var Lit_2045 *jrt.String = jrt.Intern("arbace.core$parents")

var Lit_2046 *jrt.String = jrt.Intern("arbace.core$parse_boolean")

var Lit_2047 *jrt.String = jrt.Intern("true")

var Lit_2048 *jrt.String = jrt.Intern("false")

var Lit_2049 *jrt.String = jrt.Intern("arbace.core$parse_double")

var Lit_2050 *jrt.String = jrt.Intern("arbace.core$parse_impls")

var Lit_2051 *jrt.String = jrt.Intern("arbace.core$parse_long")

var Lit_2052 *jrt.String = jrt.Intern("arbace.core$parse_opts")

var Lit_2053 *jrt.String = jrt.Intern("arbace.core$parse_opts_PLUS_specs")

var Lit_2054 *jrt.String = jrt.Intern("Unsupported option(s) -")

var Lit_2055 *jrt.String = jrt.Intern("arbace.core$parse_opts_PLUS_specs$fn__231000036")

var Lit_2056 *jrt.String = jrt.Intern("arbace.core$parse_opts_PLUS_specs$fn__231000039")

var Lit_2057 *jrt.String = jrt.Intern("arbace.core$parse_uuid")

var Lit_2058 *jrt.String = jrt.Intern("arbace.core$parsing_err")

var Lit_2059 *jrt.String = jrt.Intern("Expected string, got ")

var Lit_2060 *jrt.String = jrt.Intern("arbace.core$partial")

var Lit_2061 *jrt.String = jrt.Intern("arbace.core$partial$fn__1927000551")

var Lit_2062 *jrt.String = jrt.Intern("arbace.core$partial$fn__1927000553")

var Lit_2063 *jrt.String = jrt.Intern("arbace.core$partial$fn__1927000555")

var Lit_2064 *jrt.String = jrt.Intern("arbace.core$partial$fn__1927000557")

var Lit_2065 *jrt.String = jrt.Intern("arbace.core$partition")

var Lit_2066 *jrt.String = jrt.Intern("arbace.core$partition$fn__1927000672")

var Lit_2067 *jrt.String = jrt.Intern("arbace.core$partition$fn__1927000674")

var Lit_2068 *jrt.String = jrt.Intern("arbace.core$partition_all")

var Lit_2069 *jrt.String = jrt.Intern("arbace.core$partition_all$fn__1927002003")

var Lit_2070 *jrt.String = jrt.Intern("arbace.core$partition_all$fn__1927002003$fn__1927002004")

var Lit_2071 *jrt.String = jrt.Intern("arbace.core$partition_all$fn__1927002007")

var Lit_2072 *jrt.String = jrt.Intern("arbace.core$partition_by")

var Lit_2073 *jrt.String = jrt.Intern("arbace.core$partition_by$fn__1927001983")

var Lit_2074 *jrt.String = jrt.Intern("arbace.core$partition_by$fn__1927001983$fn__1927001984")

var Lit_2075 *jrt.String = jrt.Intern("arbace.core$partition_by$fn__1927001987")

var Lit_2076 *jrt.String = jrt.Intern("arbace.core$partition_by$fn__1927001987$fn__1927001988")

var Lit_2077 *jrt.String = jrt.Intern("arbace.core$partition_by$fn__1927001987$fn__1927001990")

var Lit_2078 *jrt.String = jrt.Intern("arbace.core$partitionv")

var Lit_2079 *jrt.String = jrt.Intern("arbace.core$partitionv$fn__1927002011")

var Lit_2080 *jrt.String = jrt.Intern("arbace.core$partitionv$fn__1927002013")

var Lit_2081 *jrt.String = jrt.Intern("arbace.core$partitionv_all")

var Lit_2082 *jrt.String = jrt.Intern("arbace.core$partitionv_all$fn__1927002016")

var Lit_2083 *jrt.String = jrt.Intern("arbace.core$pcalls")

var Lit_2084 *jrt.String = jrt.Intern("arbace.core$pcalls$fn__1927001944")

var Lit_2085 *jrt.String = jrt.Intern("arbace.core$peek")

var Lit_2086 *jrt.String = jrt.Intern("arbace.core$persistent_BANG_")

var Lit_2087 *jrt.String = jrt.Intern("arbace.core$pmap")

var Lit_2088 *jrt.String = jrt.Intern("arbace.core$pmap$fn__1927001924")

var Lit_2089 *jrt.String = jrt.Intern("arbace.core$pmap$fn__1927001924$fn__1927001925")

var Lit_2090 *jrt.String = jrt.Intern("arbace.core$pmap$fn__1927001940")

var Lit_2091 *jrt.String = jrt.Intern("arbace.core$pmap$step__1927001929")

var Lit_2092 *jrt.String = jrt.Intern("arbace.core$pmap$step__1927001929$fn__1927001933")

var Lit_2093 *jrt.String = jrt.Intern("arbace.core$pmap$step__1927001936")

var Lit_2094 *jrt.String = jrt.Intern("arbace.core$pmap$step__1927001936$fn__1927001937")

var Lit_2095 *jrt.String = jrt.Intern("arbace.core$pop")

var Lit_2096 *jrt.String = jrt.Intern("arbace.core$pop_BANG_")

var Lit_2097 *jrt.String = jrt.Intern("arbace.core$pop_thread_bindings")

var Lit_2098 *jrt.String = jrt.Intern("arbace.core$pos_QMARK_")

var Lit_2099 *jrt.String = jrt.Intern("arbace.core$pos_QMARK___inliner__1927000282")

var Lit_2100 *jrt.String = jrt.Intern("arbace.core$pos_int_QMARK_")

var Lit_2101 *jrt.String = jrt.Intern("arbace.core$pr")

var Lit_2102 *jrt.String = jrt.Intern("arbace.core$pr_on")

var Lit_2103 *jrt.String = jrt.Intern("arbace.core$pr_str")

var Lit_2104 *jrt.String = jrt.Intern("arbace.core$pref")

var Lit_2105 *jrt.String = jrt.Intern("arbace.core$prefer_method")

var Lit_2106 *jrt.String = jrt.Intern("arbace.core$prefers")

var Lit_2107 *jrt.String = jrt.Intern("arbace.core$prep_hashes")

var Lit_2108 *jrt.String = jrt.Intern("arbace.core$prep_hashes$fn__1927001755")

var Lit_2109 *jrt.String = jrt.Intern("arbace.core$prep_hashes$fn__1927001763")

var Lit_2110 *jrt.String = jrt.Intern("arbace.core$prep_hashes$hashcode__1927001750")

var Lit_2111 *jrt.String = jrt.Intern("arbace.core$prep_ints")

var Lit_2112 *jrt.String = jrt.Intern("arbace.core$prep_ints$fn__1927001728")

var Lit_2113 *jrt.String = jrt.Intern("arbace.core$prependss")

var Lit_2114 *jrt.String = jrt.Intern("arbace.core$preserving_reduced")

var Lit_2115 *jrt.String = jrt.Intern("arbace.core$preserving_reduced$fn__1927002175")

var Lit_2116 *jrt.String = jrt.Intern("arbace.core$print")

var Lit_2117 *jrt.String = jrt.Intern("arbace.core$print_ctor")

var Lit_2118 *jrt.String = jrt.Intern(". ")

var Lit_2119 *jrt.String = jrt.Intern("arbace.core$print_map")

var Lit_2120 *jrt.String = jrt.Intern("arbace.core$print_meta")

var Lit_2121 *jrt.String = jrt.Intern("^")

var Lit_2122 *jrt.String = jrt.Intern("arbace.core$print_object")

var Lit_2123 *jrt.String = jrt.Intern("arbace.core$print_prefix_map")

var Lit_2124 *jrt.String = jrt.Intern("{")

var Lit_2125 *jrt.String = jrt.Intern("arbace.core$print_prefix_map$fn__1769000160")

var Lit_2126 *jrt.String = jrt.Intern("arbace.core$print_sequential")

var Lit_2127 *jrt.String = jrt.Intern("...")

var Lit_2128 *jrt.String = jrt.Intern("arbace.core$print_simple")

var Lit_2129 *jrt.String = jrt.Intern("arbace.core$print_str")

var Lit_2130 *jrt.String = jrt.Intern("arbace.core$print_tagged_object")

var Lit_2131 *jrt.String = jrt.Intern("#object[")

var Lit_2132 *jrt.String = jrt.Intern("0x%x ")

var Lit_2133 *jrt.String = jrt.Intern("arbace.core$print_throwable")

var Lit_2134 *jrt.String = jrt.Intern("#error {\n :cause ")

var Lit_2135 *jrt.String = jrt.Intern("\n :data ")

var Lit_2136 *jrt.String = jrt.Intern("\n :via\n [")

var Lit_2137 *jrt.String = jrt.Intern("\n  ")

var Lit_2138 *jrt.String = jrt.Intern("\n :trace\n [")

var Lit_2139 *jrt.String = jrt.Intern("arbace.core$print_throwable$print_via__1769000363")

var Lit_2140 *jrt.String = jrt.Intern("{:type ")

var Lit_2141 *jrt.String = jrt.Intern("\n   :message ")

var Lit_2142 *jrt.String = jrt.Intern("\n   :data ")

var Lit_2143 *jrt.String = jrt.Intern("\n   :at ")

var Lit_2144 *jrt.String = jrt.Intern("arbace.core$printf")

var Lit_2145 *jrt.String = jrt.Intern("arbace.core$println")

var Lit_2146 *jrt.String = jrt.Intern("arbace.core$println_str")

var Lit_2147 *jrt.String = jrt.Intern("arbace.core$prn")

var Lit_2148 *jrt.String = jrt.Intern("arbace.core$prn_str")

var Lit_2149 *jrt.String = jrt.Intern("arbace.core$promise")

var Lit_2150 *jrt.String = jrt.Intern("arbace.core$protocol_QMARK_")

var Lit_2151 *jrt.String = jrt.Intern("arbace.core$proxy")

var Lit_2152 *jrt.String = jrt.Intern("arbace.core$proxy$fn__840000146")

var Lit_2153 *jrt.String = jrt.Intern("Can't resolve: ")

var Lit_2154 *jrt.String = jrt.Intern("arbace.core$proxy$fn__840000148")

var Lit_2155 *jrt.String = jrt.Intern("arbace.core$proxy$fn__840000150")

var Lit_2156 *jrt.String = jrt.Intern("Method '")

var Lit_2157 *jrt.String = jrt.Intern("' redefined")

var Lit_2158 *jrt.String = jrt.Intern("arbace.core$proxy$fn__840000150$fn__840000155")

var Lit_2159 *jrt.String = jrt.Intern("arbace.core$proxy_call_with_super")

var Lit_2160 *jrt.String = jrt.Intern("arbace.core$proxy_mappings")

var Lit_2161 *jrt.String = jrt.Intern("arbace.core$proxy_method_fn")

var Lit_2162 *jrt.String = jrt.Intern("arbace.core$proxy_method_fn$fn__840000089")

var Lit_2163 *jrt.String = jrt.Intern("arbace.core$proxy_method_fn$fn__840000091")

var Lit_2164 *jrt.String = jrt.Intern("arbace.core$proxy_methods")

var Lit_2165 *jrt.String = jrt.Intern("arbace.core$proxy_methods$abstract_QMARK___840000077")

var Lit_2166 *jrt.String = jrt.Intern("arbace.core$proxy_methods$fn__840000053")

var Lit_2167 *jrt.String = jrt.Intern("arbace.core$proxy_methods$fn__840000053$fn__840000057")

var Lit_2168 *jrt.String = jrt.Intern("finalize")

var Lit_2169 *jrt.String = jrt.Intern("arbace.core$proxy_methods$fn__840000082")

var Lit_2170 *jrt.String = jrt.Intern("arbace.core$proxy_methods$fn__840000084")

var Lit_2171 *jrt.String = jrt.Intern("arbace.core$proxy_methods$fn__840000086")

var Lit_2172 *jrt.String = jrt.Intern("arbace.core$proxy_methods$iter__840000060__840000066")

var Lit_2173 *jrt.String = jrt.Intern("arbace.core$proxy_methods$iter__840000060__840000066$fn__840000067")

var Lit_2174 *jrt.String = jrt.Intern("arbace.core$proxy_methods$iter__840000060__840000066$fn__840000067$iter__840000062__840000068")

var Lit_2175 *jrt.String = jrt.Intern("arbace.core$proxy_methods$iter__840000060__840000066$fn__840000067$iter__840000062__840000068$fn__840000069")

var Lit_2176 *jrt.String = jrt.Intern("arbace.core$proxy_methods$iter__840000060__840000066$fn__840000067$iter__840000062__840000068$fn__840000069$fn__840000070")

var Lit_2177 *jrt.String = jrt.Intern("arbace.core$proxy_name")

var Lit_2178 *jrt.String = jrt.Intern(".proxy")

var Lit_2179 *jrt.String = jrt.Intern("$")

var Lit_2180 *jrt.String = jrt.Intern("arbace.core$proxy_name$fn__840000038")

var Lit_2181 *jrt.String = jrt.Intern("arbace.core$proxy_name$fn__840000040")

var Lit_2182 *jrt.String = jrt.Intern("arbace.core$proxy_super")

var Lit_2183 *jrt.String = jrt.Intern("arbace.core$push_thread_bindings")

var Lit_2184 *jrt.String = jrt.Intern("arbace.core$pvalues")

var Lit_2185 *jrt.String = jrt.Intern("arbace.core$pvalues$fn__1927001948")

var Lit_2186 *jrt.String = jrt.Intern("arbace.core$qualified_ident_QMARK_")

var Lit_2187 *jrt.String = jrt.Intern("arbace.core$qualified_keyword_QMARK_")

var Lit_2188 *jrt.String = jrt.Intern("arbace.core$qualified_symbol_QMARK_")

var Lit_2189 *jrt.String = jrt.Intern("arbace.core$quot")

var Lit_2190 *jrt.String = jrt.Intern("arbace.core$quot__inliner__1927000288")

var Lit_2191 *jrt.String = jrt.Intern("arbace.core$rand")

var Lit_2192 *jrt.String = jrt.Intern("arbace.core$rand_int")

var Lit_2193 *jrt.String = jrt.Intern("arbace.core$rand_nth")

var Lit_2194 *jrt.String = jrt.Intern("arbace.core$random_sample")

var Lit_2195 *jrt.String = jrt.Intern("arbace.core$random_sample$fn__1927002191")

var Lit_2196 *jrt.String = jrt.Intern("arbace.core$random_sample$fn__1927002193")

var Lit_2197 *jrt.String = jrt.Intern("arbace.core$random_uuid")

var Lit_2198 *jrt.String = jrt.Intern("arbace.core$range")

var Lit_2199 *jrt.String = jrt.Intern("arbace.core$ratio_QMARK_")

var Lit_2200 *jrt.String = jrt.Intern("arbace.core$rational_QMARK_")

var Lit_2201 *jrt.String = jrt.Intern("arbace.core$rationalize")

var Lit_2202 *jrt.String = jrt.Intern("arbace.core$re_find")

var Lit_2203 *jrt.String = jrt.Intern("arbace.core$re_groups")

var Lit_2204 *jrt.String = jrt.Intern("arbace.core$re_matcher")

var Lit_2205 *jrt.String = jrt.Intern("arbace.core$re_matches")

var Lit_2206 *jrt.String = jrt.Intern("arbace.core$re_pattern")

var Lit_2207 *jrt.String = jrt.Intern("arbace.core$re_seq")

var Lit_2208 *jrt.String = jrt.Intern("arbace.core$re_seq$step__1927001131")

var Lit_2209 *jrt.String = jrt.Intern("arbace.core$re_seq$step__1927001131$fn__1927001132")

var Lit_2210 *jrt.String = jrt.Intern("arbace.core$read")

var Lit_2211 *jrt.String = jrt.Intern("arbace.core$read_PLUS_string")

var Lit_2212 *jrt.String = jrt.Intern("arbace.core$read_line")

var Lit_2213 *jrt.String = jrt.Intern("arbace.core$read_string")

var Lit_2214 *jrt.String = jrt.Intern("arbace.core$reader_conditional")

var Lit_2215 *jrt.String = jrt.Intern("arbace.core$reader_conditional_QMARK_")

var Lit_2216 *jrt.String = jrt.Intern("arbace.core$realized_QMARK_")

var Lit_2217 *jrt.String = jrt.Intern("arbace.core$record_QMARK_")

var Lit_2218 *jrt.String = jrt.Intern("arbace.core$reduce")

var Lit_2219 *jrt.String = jrt.Intern("arbace.core$reduce0")

var Lit_2220 *jrt.String = jrt.Intern("arbace.core$reduce_kv")

var Lit_2221 *jrt.String = jrt.Intern("arbace.core$reduced")

var Lit_2222 *jrt.String = jrt.Intern("arbace.core$reduced_QMARK_")

var Lit_2223 *jrt.String = jrt.Intern("arbace.core$reduced_QMARK___inliner__1927000608")

var Lit_2224 *jrt.String = jrt.Intern("arbace.core$reductions")

var Lit_2225 *jrt.String = jrt.Intern("arbace.core$reductions$fn__1927001997")

var Lit_2226 *jrt.String = jrt.Intern("arbace.core$reductions$fn__1927001999")

var Lit_2227 *jrt.String = jrt.Intern("arbace.core$ref")

var Lit_2228 *jrt.String = jrt.Intern("arbace.core$ref_history_count")

var Lit_2229 *jrt.String = jrt.Intern("arbace.core$ref_max_history")

var Lit_2230 *jrt.String = jrt.Intern("arbace.core$ref_min_history")

var Lit_2231 *jrt.String = jrt.Intern("arbace.core$ref_set")

var Lit_2232 *jrt.String = jrt.Intern("arbace.core$refer")

var Lit_2233 *jrt.String = jrt.Intern("No namespace: ")

var Lit_2234 *jrt.String = jrt.Intern(":only/:refer value must be a sequential collection of symbols")

var Lit_2235 *jrt.String = jrt.Intern(" is not public")

var Lit_2236 *jrt.String = jrt.Intern(" does not exist")

var Lit_2237 *jrt.String = jrt.Intern("arbace.core$refer_clojure")

var Lit_2238 *jrt.String = jrt.Intern("arbace.core$reify")

var Lit_2239 *jrt.String = jrt.Intern("arbace.core$release_pending_sends")

var Lit_2240 *jrt.String = jrt.Intern("arbace.core$rem")

var Lit_2241 *jrt.String = jrt.Intern("arbace.core$rem__inliner__1927000291")

var Lit_2242 *jrt.String = jrt.Intern("arbace.core$remove")

var Lit_2243 *jrt.String = jrt.Intern("arbace.core$remove_all_methods")

var Lit_2244 *jrt.String = jrt.Intern("arbace.core$remove_method")

var Lit_2245 *jrt.String = jrt.Intern("arbace.core$remove_ns")

var Lit_2246 *jrt.String = jrt.Intern("arbace.core$remove_tap")

var Lit_2247 *jrt.String = jrt.Intern("arbace.core$remove_watch")

var Lit_2248 *jrt.String = jrt.Intern("arbace.core$repeat")

var Lit_2249 *jrt.String = jrt.Intern("arbace.core$repeatedly")

var Lit_2250 *jrt.String = jrt.Intern("arbace.core$repeatedly$fn__1927000943")

var Lit_2251 *jrt.String = jrt.Intern("arbace.core$replace")

var Lit_2252 *jrt.String = jrt.Intern("arbace.core$replace$fn__1927001184")

var Lit_2253 *jrt.String = jrt.Intern("arbace.core$replace$fn__1927001186")

var Lit_2254 *jrt.String = jrt.Intern("arbace.core$replace$fn__1927001188")

var Lit_2255 *jrt.String = jrt.Intern("arbace.core$replicate")

var Lit_2256 *jrt.String = jrt.Intern("arbace.core$req_BANG_")

var Lit_2257 *jrt.String = jrt.Intern("arbace.core$req_BANG___inliner__1927000337")

var Lit_2258 *jrt.String = jrt.Intern("arbace.core$require")

var Lit_2259 *jrt.String = jrt.Intern("arbace.core$requiring_resolve")

var Lit_2260 *jrt.String = jrt.Intern("Not a qualified symbol: ")

var Lit_2261 *jrt.String = jrt.Intern("arbace.core$reset_BANG_")

var Lit_2262 *jrt.String = jrt.Intern("arbace.core$reset_meta_BANG_")

var Lit_2263 *jrt.String = jrt.Intern("arbace.core$reset_vals_BANG_")

var Lit_2264 *jrt.String = jrt.Intern("arbace.core$resolve")

var Lit_2265 *jrt.String = jrt.Intern("arbace.core$resolve_unqualified_class_tag")

var Lit_2266 *jrt.String = jrt.Intern("arbace.core$rest__1927000012")

var Lit_2267 *jrt.String = jrt.Intern("arbace.core$restart_agent")

var Lit_2268 *jrt.String = jrt.Intern("arbace.core$resultset_seq")

var Lit_2269 *jrt.String = jrt.Intern("java.sql.ResultSet")

var Lit_2270 *jrt.String = jrt.Intern("getMetaData")

var Lit_2271 *jrt.String = jrt.Intern("java.sql.ResultSetMetaData")

var Lit_2272 *jrt.String = jrt.Intern("getColumnCount")

var Lit_2273 *jrt.String = jrt.Intern("ResultSet must have unique column labels")

var Lit_2274 *jrt.String = jrt.Intern("arbace.core$resultset_seq$fn__1927001447")

var Lit_2275 *jrt.String = jrt.Intern("arbace.core$resultset_seq$fn__1927001449")

var Lit_2276 *jrt.String = jrt.Intern("getColumnLabel")

var Lit_2277 *jrt.String = jrt.Intern("arbace.core$resultset_seq$row_values__1927001451")

var Lit_2278 *jrt.String = jrt.Intern("arbace.core$resultset_seq$row_values__1927001451$fn__1927001452")

var Lit_2279 *jrt.String = jrt.Intern("getObject")

var Lit_2280 *jrt.String = jrt.Intern("arbace.core$resultset_seq$thisfn__1927001455")

var Lit_2281 *jrt.String = jrt.Intern("arbace.core$resultset_seq$thisfn__1927001455$fn__1927001456")

var Lit_2282 *jrt.String = jrt.Intern("arbace.core$return")

var Lit_2283 *jrt.String = jrt.Intern("arbace.core$reverse")

var Lit_2284 *jrt.String = jrt.Intern("arbace.core$reversible_QMARK_")

var Lit_2285 *jrt.String = jrt.Intern("arbace.core$root_directory")

var Lit_2286 *jrt.String = jrt.Intern("arbace.core$root_resource")

var Lit_2287 *jrt.String = jrt.Intern("arbace.core$rseq")

var Lit_2288 *jrt.String = jrt.Intern("arbace.core$rsubseq")

var Lit_2289 *jrt.String = jrt.Intern("arbace.core$run_BANG_")

var Lit_2290 *jrt.String = jrt.Intern("arbace.core$run_BANG_$fn__1927002208")

var Lit_2291 *jrt.String = jrt.Intern("arbace.core$satisfies_QMARK_")

var Lit_2292 *jrt.String = jrt.Intern("arbace.core$second__1927000016")

var Lit_2293 *jrt.String = jrt.Intern("arbace.core$select_keys")

var Lit_2294 *jrt.String = jrt.Intern("arbace.core$select_keys$this__1927001898")

var Lit_2295 *jrt.String = jrt.Intern("arbace.core$selector")

var Lit_2296 *jrt.String = jrt.Intern("expected a map")

var Lit_2297 *jrt.String = jrt.Intern("arbace.core$selector_impl")

var Lit_2298 *jrt.String = jrt.Intern("form must contain at least one of :select :excess :missing :all")

var Lit_2299 *jrt.String = jrt.Intern("selector")

var Lit_2300 *jrt.String = jrt.Intern("arbace.core$send")

var Lit_2301 *jrt.String = jrt.Intern("arbace.core$send_off")

var Lit_2302 *jrt.String = jrt.Intern("arbace.core$send_via")

var Lit_2303 *jrt.String = jrt.Intern("arbace.core$send_via$fn__1927000464")

var Lit_2304 *jrt.String = jrt.Intern("arbace.core$seq_QMARK___1927000030")

var Lit_2305 *jrt.String = jrt.Intern("arbace.core$seq__1927000026")

var Lit_2306 *jrt.String = jrt.Intern("arbace.core$seq_to_map_for_destructuring")

var Lit_2307 *jrt.String = jrt.Intern("arbace.core$seqable_QMARK_")

var Lit_2308 *jrt.String = jrt.Intern("arbace.core$seque")

var Lit_2309 *jrt.String = jrt.Intern("arbace.core$seque$drain__1927001393")

var Lit_2310 *jrt.String = jrt.Intern("arbace.core$seque$drain__1927001393$fn__1927001394")

var Lit_2311 *jrt.String = jrt.Intern("arbace.core$seque$fill__1927001381")

var Lit_2312 *jrt.String = jrt.Intern("arbace.core$seque$fn__1927001377")

var Lit_2313 *jrt.String = jrt.Intern("arbace.core$seque$log_error__1927001379")

var Lit_2314 *jrt.String = jrt.Intern("offer")

var Lit_2315 *jrt.String = jrt.Intern("arbace.core$sequence")

var Lit_2316 *jrt.String = jrt.Intern("arbace.core$sequence$fn__1927000561")

var Lit_2317 *jrt.String = jrt.Intern("arbace.core$sequential_QMARK_")

var Lit_2318 *jrt.String = jrt.Intern("arbace.core$serialized_require")

var Lit_2319 *jrt.String = jrt.Intern("arbace.core$set")

var Lit_2320 *jrt.String = jrt.Intern("arbace.core$set_QMARK_")

var Lit_2321 *jrt.String = jrt.Intern("arbace.core$set_agent_send_executor_BANG_")

var Lit_2322 *jrt.String = jrt.Intern("arbace.core$set_agent_send_off_executor_BANG_")

var Lit_2323 *jrt.String = jrt.Intern("arbace.core$set_error_handler_BANG_")

var Lit_2324 *jrt.String = jrt.Intern("arbace.core$set_error_mode_BANG_")

var Lit_2325 *jrt.String = jrt.Intern("arbace.core$set_proxy_method")

var Lit_2326 *jrt.String = jrt.Intern("arbace.core$set_validator_BANG_")

var Lit_2327 *jrt.String = jrt.Intern("arbace.core$setup_reference")

var Lit_2328 *jrt.String = jrt.Intern("arbace.core$shift_mask")

var Lit_2329 *jrt.String = jrt.Intern("arbace.core$short")

var Lit_2330 *jrt.String = jrt.Intern("arbace.core$short__inliner__1927000757")

var Lit_2331 *jrt.String = jrt.Intern("arbace.core$short_array")

var Lit_2332 *jrt.String = jrt.Intern("arbace.core$short_array__inliner__1927001269")

var Lit_2333 *jrt.String = jrt.Intern("arbace.core$shorts")

var Lit_2334 *jrt.String = jrt.Intern("arbace.core$shuffle")

var Lit_2335 *jrt.String = jrt.Intern("arbace.core$shutdown_agents")

var Lit_2336 *jrt.String = jrt.Intern("arbace.core$sigs")

var Lit_2337 *jrt.String = jrt.Intern("arbace.core$sigs$asig__1927000049")

var Lit_2338 *jrt.String = jrt.Intern("arbace.core$sigs$resolve_tag__1927000051")

var Lit_2339 *jrt.String = jrt.Intern("arbace.core$simple_ident_QMARK_")

var Lit_2340 *jrt.String = jrt.Intern("arbace.core$simple_keyword_QMARK_")

var Lit_2341 *jrt.String = jrt.Intern("arbace.core$simple_symbol_QMARK_")

var Lit_2342 *jrt.String = jrt.Intern("arbace.core$slurp")

var Lit_2343 *jrt.String = jrt.Intern("arbace.core$some")

var Lit_2344 *jrt.String = jrt.Intern("arbace.core$some_QMARK_")

var Lit_2345 *jrt.String = jrt.Intern("arbace.core$some__GT_")

var Lit_2346 *jrt.String = jrt.Intern("arbace.core$some__GT_$fn__1927002159")

var Lit_2347 *jrt.String = jrt.Intern("arbace.core$some__GT__GT_")

var Lit_2348 *jrt.String = jrt.Intern("arbace.core$some__GT__GT_$fn__1927002166")

var Lit_2349 *jrt.String = jrt.Intern("arbace.core$some_fn")

var Lit_2350 *jrt.String = jrt.Intern("arbace.core$some_fn$sp1__1927002079")

var Lit_2351 *jrt.String = jrt.Intern("arbace.core$some_fn$sp2__1927002081")

var Lit_2352 *jrt.String = jrt.Intern("arbace.core$some_fn$sp2__1927002081$fn__1927002082")

var Lit_2353 *jrt.String = jrt.Intern("arbace.core$some_fn$sp3__1927002085")

var Lit_2354 *jrt.String = jrt.Intern("arbace.core$some_fn$sp3__1927002085$fn__1927002086")

var Lit_2355 *jrt.String = jrt.Intern("arbace.core$some_fn$spn__1927002089")

var Lit_2356 *jrt.String = jrt.Intern("arbace.core$some_fn$spn__1927002089$fn__1927002090")

var Lit_2357 *jrt.String = jrt.Intern("arbace.core$some_fn$spn__1927002089$fn__1927002092")

var Lit_2358 *jrt.String = jrt.Intern("arbace.core$some_fn$spn__1927002089$fn__1927002094")

var Lit_2359 *jrt.String = jrt.Intern("arbace.core$some_fn$spn__1927002089$fn__1927002096")

var Lit_2360 *jrt.String = jrt.Intern("arbace.core$some_vals")

var Lit_2361 *jrt.String = jrt.Intern("arbace.core$some_vals$fn__1927000948")

var Lit_2362 *jrt.String = jrt.Intern("arbace.core$sort")

var Lit_2363 *jrt.String = jrt.Intern("arbace.core$sort_by")

var Lit_2364 *jrt.String = jrt.Intern("arbace.core$sort_by$fn__1927000663")

var Lit_2365 *jrt.String = jrt.Intern("arbace.core$sorted_QMARK_")

var Lit_2366 *jrt.String = jrt.Intern("arbace.core$sorted_map")

var Lit_2367 *jrt.String = jrt.Intern("arbace.core$sorted_map_by")

var Lit_2368 *jrt.String = jrt.Intern("arbace.core$sorted_set")

var Lit_2369 *jrt.String = jrt.Intern("arbace.core$sorted_set_by")

var Lit_2370 *jrt.String = jrt.Intern("arbace.core$special_symbol_QMARK_")

var Lit_2371 *jrt.String = jrt.Intern("arbace.core$spit")

var Lit_2372 *jrt.String = jrt.Intern("arbace.core$split_at")

var Lit_2373 *jrt.String = jrt.Intern("arbace.core$split_with")

var Lit_2374 *jrt.String = jrt.Intern("arbace.core$splitv_at")

var Lit_2375 *jrt.String = jrt.Intern("arbace.core$spread")

var Lit_2376 *jrt.String = jrt.Intern("arbace.core$str")

var Lit_2377 *jrt.String = jrt.Intern("")

var Lit_2378 *jrt.String = jrt.Intern("arbace.core$str$fn__1927000104")

var Lit_2379 *jrt.String = jrt.Intern("arbace.core$stream_into_BANG_")

var Lit_2380 *jrt.String = jrt.Intern("arbace.core$stream_reduce_BANG_")

var Lit_2381 *jrt.String = jrt.Intern("arbace.core$stream_seq_BANG_")

var Lit_2382 *jrt.String = jrt.Intern("arbace.core$stream_transduce_BANG_")

var Lit_2383 *jrt.String = jrt.Intern("arbace.core$string_QMARK___1927000034")

var Lit_2384 *jrt.String = jrt.Intern("arbace.core$strip_ns")

var Lit_2385 *jrt.String = jrt.Intern("arbace.core$struct")

var Lit_2386 *jrt.String = jrt.Intern("arbace.core$struct_map")

var Lit_2387 *jrt.String = jrt.Intern("arbace.core$subs")

var Lit_2388 *jrt.String = jrt.Intern("arbace.core$subseq")

var Lit_2389 *jrt.String = jrt.Intern("arbace.core$subvec")

var Lit_2390 *jrt.String = jrt.Intern("arbace.core$super_chain")

var Lit_2391 *jrt.String = jrt.Intern("arbace.core$supers")

var Lit_2392 *jrt.String = jrt.Intern("arbace.core$swap_BANG_")

var Lit_2393 *jrt.String = jrt.Intern("arbace.core$swap_vals_BANG_")

var Lit_2394 *jrt.String = jrt.Intern("arbace.core$switch")

var Lit_2395 *jrt.String = jrt.Intern("arbace.core$symbol")

var Lit_2396 *jrt.String = jrt.Intern("no conversion to symbol")

var Lit_2397 *jrt.String = jrt.Intern("arbace.core$symbol_QMARK_")

var Lit_2398 *jrt.String = jrt.Intern("arbace.core$sync")

var Lit_2399 *jrt.String = jrt.Intern("arbace.core$tagged_literal")

var Lit_2400 *jrt.String = jrt.Intern("arbace.core$tagged_literal_QMARK_")

var Lit_2401 *jrt.String = jrt.Intern("arbace.core$take")

var Lit_2402 *jrt.String = jrt.Intern("arbace.core$take$fn__1927000613")

var Lit_2403 *jrt.String = jrt.Intern("arbace.core$take$fn__1927000613$fn__1927000614")

var Lit_2404 *jrt.String = jrt.Intern("arbace.core$take$fn__1927000617")

var Lit_2405 *jrt.String = jrt.Intern("arbace.core$take_last")

var Lit_2406 *jrt.String = jrt.Intern("arbace.core$take_nth")

var Lit_2407 *jrt.String = jrt.Intern("arbace.core$take_nth$fn__1927000918")

var Lit_2408 *jrt.String = jrt.Intern("arbace.core$take_nth$fn__1927000918$fn__1927000919")

var Lit_2409 *jrt.String = jrt.Intern("arbace.core$take_nth$fn__1927000922")

var Lit_2410 *jrt.String = jrt.Intern("arbace.core$take_while")

var Lit_2411 *jrt.String = jrt.Intern("arbace.core$take_while$fn__1927000620")

var Lit_2412 *jrt.String = jrt.Intern("arbace.core$take_while$fn__1927000620$fn__1927000621")

var Lit_2413 *jrt.String = jrt.Intern("arbace.core$take_while$fn__1927000624")

var Lit_2414 *jrt.String = jrt.Intern("arbace.core$tap_GT_")

var Lit_2415 *jrt.String = jrt.Intern("arbace.core$tap__GT_")

var Lit_2416 *jrt.String = jrt.Intern("arbace.core$test")

var Lit_2417 *jrt.String = jrt.Intern("arbace.core$the_array_class")

var Lit_2418 *jrt.String = jrt.Intern("java.lang.")

var Lit_2419 *jrt.String = jrt.Intern("arbace.core$the_class")

var Lit_2420 *jrt.String = jrt.Intern("arbace.core$the_ns")

var Lit_2421 *jrt.String = jrt.Intern(" found")

var Lit_2422 *jrt.String = jrt.Intern("arbace.core$thread_bound_QMARK_")

var Lit_2423 *jrt.String = jrt.Intern("arbace.core$thread_bound_QMARK_$fn__1927001405")

var Lit_2424 *jrt.String = jrt.Intern("arbace.core$throw_if")

var Lit_2425 *jrt.String = jrt.Intern("arbace.core$throw_if$boring_QMARK___1927001511")

var Lit_2426 *jrt.String = jrt.Intern("doInvoke")

var Lit_2427 *jrt.String = jrt.Intern("arbace.core$time")

var Lit_2428 *jrt.String = jrt.Intern("Elapsed time: ")

var Lit_2429 *jrt.String = jrt.Intern(" msecs")

var Lit_2430 *jrt.String = jrt.Intern("arbace.core$to_array")

var Lit_2431 *jrt.String = jrt.Intern("arbace.core$to_array_2d")

var Lit_2432 *jrt.String = jrt.Intern("[Ljava.lang.Object;")

var Lit_2433 *jrt.String = jrt.Intern("arbace.core$trampoline")

var Lit_2434 *jrt.String = jrt.Intern("arbace.core$trampoline$fn__1927001604")

var Lit_2435 *jrt.String = jrt.Intern("arbace.core$transduce")

var Lit_2436 *jrt.String = jrt.Intern("arbace.core$transient")

var Lit_2437 *jrt.String = jrt.Intern("arbace.core$tree_seq")

var Lit_2438 *jrt.String = jrt.Intern("arbace.core$tree_seq$walk__1927001145")

var Lit_2439 *jrt.String = jrt.Intern("arbace.core$tree_seq$walk__1927001145$fn__1927001146")

var Lit_2440 *jrt.String = jrt.Intern("arbace.core$true_QMARK_")

var Lit_2441 *jrt.String = jrt.Intern("arbace.core$type")

var Lit_2442 *jrt.String = jrt.Intern("arbace.core$unchecked_add")

var Lit_2443 *jrt.String = jrt.Intern("arbace.core$unchecked_add__inliner__1927000261")

var Lit_2444 *jrt.String = jrt.Intern("arbace.core$unchecked_add_float")

var Lit_2445 *jrt.String = jrt.Intern("arbace.core$unchecked_add_int")

var Lit_2446 *jrt.String = jrt.Intern("arbace.core$unchecked_add_int__inliner__1927000258")

var Lit_2447 *jrt.String = jrt.Intern("arbace.core$unchecked_byte")

var Lit_2448 *jrt.String = jrt.Intern("arbace.core$unchecked_byte__inliner__1927000766")

var Lit_2449 *jrt.String = jrt.Intern("arbace.core$unchecked_char")

var Lit_2450 *jrt.String = jrt.Intern("arbace.core$unchecked_char__inliner__1927000772")

var Lit_2451 *jrt.String = jrt.Intern("arbace.core$unchecked_dec")

var Lit_2452 *jrt.String = jrt.Intern("arbace.core$unchecked_dec__inliner__1927000249")

var Lit_2453 *jrt.String = jrt.Intern("arbace.core$unchecked_dec_int")

var Lit_2454 *jrt.String = jrt.Intern("arbace.core$unchecked_dec_int__inliner__1927000246")

var Lit_2455 *jrt.String = jrt.Intern("arbace.core$unchecked_divide")

var Lit_2456 *jrt.String = jrt.Intern("arbace.core$unchecked_divide_float")

var Lit_2457 *jrt.String = jrt.Intern("arbace.core$unchecked_divide_int")

var Lit_2458 *jrt.String = jrt.Intern("arbace.core$unchecked_divide_int__inliner__1927000276")

var Lit_2459 *jrt.String = jrt.Intern("arbace.core$unchecked_double")

var Lit_2460 *jrt.String = jrt.Intern("arbace.core$unchecked_double__inliner__1927000784")

var Lit_2461 *jrt.String = jrt.Intern("arbace.core$unchecked_float")

var Lit_2462 *jrt.String = jrt.Intern("arbace.core$unchecked_float__inliner__1927000781")

var Lit_2463 *jrt.String = jrt.Intern("arbace.core$unchecked_inc")

var Lit_2464 *jrt.String = jrt.Intern("arbace.core$unchecked_inc__inliner__1927000243")

var Lit_2465 *jrt.String = jrt.Intern("arbace.core$unchecked_inc_int")

var Lit_2466 *jrt.String = jrt.Intern("arbace.core$unchecked_inc_int__inliner__1927000240")

var Lit_2467 *jrt.String = jrt.Intern("arbace.core$unchecked_int")

var Lit_2468 *jrt.String = jrt.Intern("arbace.core$unchecked_int__inliner__1927000775")

var Lit_2469 *jrt.String = jrt.Intern("arbace.core$unchecked_long")

var Lit_2470 *jrt.String = jrt.Intern("arbace.core$unchecked_long__inliner__1927000778")

var Lit_2471 *jrt.String = jrt.Intern("arbace.core$unchecked_multiply")

var Lit_2472 *jrt.String = jrt.Intern("arbace.core$unchecked_multiply__inliner__1927000273")

var Lit_2473 *jrt.String = jrt.Intern("arbace.core$unchecked_multiply_float")

var Lit_2474 *jrt.String = jrt.Intern("arbace.core$unchecked_multiply_int")

var Lit_2475 *jrt.String = jrt.Intern("arbace.core$unchecked_multiply_int__inliner__1927000270")

var Lit_2476 *jrt.String = jrt.Intern("arbace.core$unchecked_negate")

var Lit_2477 *jrt.String = jrt.Intern("arbace.core$unchecked_negate__inliner__1927000255")

var Lit_2478 *jrt.String = jrt.Intern("arbace.core$unchecked_negate_float")

var Lit_2479 *jrt.String = jrt.Intern("arbace.core$unchecked_negate_int")

var Lit_2480 *jrt.String = jrt.Intern("arbace.core$unchecked_negate_int__inliner__1927000252")

var Lit_2481 *jrt.String = jrt.Intern("arbace.core$unchecked_remainder")

var Lit_2482 *jrt.String = jrt.Intern("arbace.core$unchecked_remainder_float")

var Lit_2483 *jrt.String = jrt.Intern("arbace.core$unchecked_remainder_int")

var Lit_2484 *jrt.String = jrt.Intern("arbace.core$unchecked_remainder_int__inliner__1927000279")

var Lit_2485 *jrt.String = jrt.Intern("arbace.core$unchecked_short")

var Lit_2486 *jrt.String = jrt.Intern("arbace.core$unchecked_short__inliner__1927000769")

var Lit_2487 *jrt.String = jrt.Intern("arbace.core$unchecked_subtract")

var Lit_2488 *jrt.String = jrt.Intern("arbace.core$unchecked_subtract__inliner__1927000267")

var Lit_2489 *jrt.String = jrt.Intern("arbace.core$unchecked_subtract_float")

var Lit_2490 *jrt.String = jrt.Intern("arbace.core$unchecked_subtract_int")

var Lit_2491 *jrt.String = jrt.Intern("arbace.core$unchecked_subtract_int__inliner__1927000264")

var Lit_2492 *jrt.String = jrt.Intern("arbace.core$underive")

var Lit_2493 *jrt.String = jrt.Intern("arbace.core$underive$fn__1927001430")

var Lit_2494 *jrt.String = jrt.Intern("arbace.core$underive$fn__1927001432")

var Lit_2495 *jrt.String = jrt.Intern("arbace.core$unreduced")

var Lit_2496 *jrt.String = jrt.Intern("arbace.core$unsigned_bit_shift_right")

var Lit_2497 *jrt.String = jrt.Intern("arbace.core$unsigned_bit_shift_right__inliner__1927000312")

var Lit_2498 *jrt.String = jrt.Intern("arbace.core$unsigned_bit_shift_right_int")

var Lit_2499 *jrt.String = jrt.Intern("arbace.core$update")

var Lit_2500 *jrt.String = jrt.Intern("arbace.core$update_in")

var Lit_2501 *jrt.String = jrt.Intern("arbace.core$update_in$up__1927001587")

var Lit_2502 *jrt.String = jrt.Intern("arbace.core$update_keys")

var Lit_2503 *jrt.String = jrt.Intern("arbace.core$update_keys$fn__1927002272")

var Lit_2504 *jrt.String = jrt.Intern("arbace.core$update_proxy")

var Lit_2505 *jrt.String = jrt.Intern("arbace.core$update_vals")

var Lit_2506 *jrt.String = jrt.Intern("arbace.core$update_vals$fn__1927002269")

var Lit_2507 *jrt.String = jrt.Intern("arbace.core$uri_QMARK_")

var Lit_2508 *jrt.String = jrt.Intern("arbace.core$use")

var Lit_2509 *jrt.String = jrt.Intern("arbace.core$uuid_QMARK_")

var Lit_2510 *jrt.String = jrt.Intern("arbace.core$val")

var Lit_2511 *jrt.String = jrt.Intern("arbace.core$validate_fields")

var Lit_2512 *jrt.String = jrt.Intern("No fields vector given.")

var Lit_2513 *jrt.String = jrt.Intern("The names in ")

var Lit_2514 *jrt.String = jrt.Intern(" cannot be used as field names for types or records.")

var Lit_2515 *jrt.String = jrt.Intern("defrecord and deftype fields must be symbols, ")

var Lit_2516 *jrt.String = jrt.Intern(" had: ")

var Lit_2517 *jrt.String = jrt.Intern("arbace.core$vals")

var Lit_2518 *jrt.String = jrt.Intern("arbace.core$var_QMARK_")

var Lit_2519 *jrt.String = jrt.Intern("arbace.core$var_get")

var Lit_2520 *jrt.String = jrt.Intern("arbace.core$var_set")

var Lit_2521 *jrt.String = jrt.Intern("arbace.core$vary_meta")

var Lit_2522 *jrt.String = jrt.Intern("arbace.core$vec")

var Lit_2523 *jrt.String = jrt.Intern("arbace.core$vector")

var Lit_2524 *jrt.String = jrt.Intern("arbace.core$vector_QMARK___1927000038")

var Lit_2525 *jrt.String = jrt.Intern("arbace.core$vector_of")

var Lit_2526 *jrt.String = jrt.Intern("arbace.core$volatile_BANG_")

var Lit_2527 *jrt.String = jrt.Intern("arbace.core$volatile_QMARK_")

var Lit_2528 *jrt.String = jrt.Intern("arbace.core$vreset_BANG_")

var Lit_2529 *jrt.String = jrt.Intern("arbace.core$vswap_BANG_")

var Lit_2530 *jrt.String = jrt.Intern("arbace.core$when")

var Lit_2531 *jrt.String = jrt.Intern("arbace.core$when_class")

var Lit_2532 *jrt.String = jrt.Intern("arbace.core$when_first")

var Lit_2533 *jrt.String = jrt.Intern("arbace.core$when_instance")

var Lit_2534 *jrt.String = jrt.Intern("arbace.core$when_let")

var Lit_2535 *jrt.String = jrt.Intern("arbace.core$when_not")

var Lit_2536 *jrt.String = jrt.Intern("arbace.core$when_some")

var Lit_2537 *jrt.String = jrt.Intern("arbace.core$while")

var Lit_2538 *jrt.String = jrt.Intern("arbace.core$with_bindings")

var Lit_2539 *jrt.String = jrt.Intern("arbace.core$with_bindings_STAR_")

var Lit_2540 *jrt.String = jrt.Intern("arbace.core$with_in_str")

var Lit_2541 *jrt.String = jrt.Intern("arbace.core$with_loading_context")

var Lit_2542 *jrt.String = jrt.Intern("arbace.core$with_local_vars")

var Lit_2543 *jrt.String = jrt.Intern("arbace.core$with_meta__1927000046")

var Lit_2544 *jrt.String = jrt.Intern("arbace.core$with_open")

var Lit_2545 *jrt.String = jrt.Intern("with-open only allows Symbols in bindings")

var Lit_2546 *jrt.String = jrt.Intern("arbace.core$with_out_str")

var Lit_2547 *jrt.String = jrt.Intern("arbace.core$with_precision")

var Lit_2548 *jrt.String = jrt.Intern("arbace.core$with_redefs")

var Lit_2549 *jrt.String = jrt.Intern("arbace.core$with_redefs$fn__1927002124")

var Lit_2550 *jrt.String = jrt.Intern("arbace.core$with_redefs_fn")

var Lit_2551 *jrt.String = jrt.Intern("arbace.core$with_redefs_fn$fn__1927002120")

var Lit_2552 *jrt.String = jrt.Intern("arbace.core$with_redefs_fn$root_bind__1927002108")

var Lit_2553 *jrt.String = jrt.Intern("arbace.core$with_resources")

var Lit_2554 *jrt.String = jrt.Intern("arbace.core$xml_seq")

var Lit_2555 *jrt.String = jrt.Intern("arbace.core$zero_QMARK_")

var Lit_2556 *jrt.String = jrt.Intern("arbace.core$zero_QMARK___inliner__1927000180")

var Lit_2557 *jrt.String = jrt.Intern("arbace.core$zipmap")

var Lit_2558 *jrt.String = jrt.Intern("am")

var Lit_2559 *jrt.String = jrt.Intern("arr")

var Lit_2560 *jrt.String = jrt.Intern("off")

var Lit_2561 *jrt.String = jrt.Intern("end")

var Lit_2562 *jrt.String = jrt.Intern("dropFirst of empty chunk")

var Lit_2563 *jrt.String = jrt.Intern("xform")

var Lit_2564 *jrt.String = jrt.Intern("coll")

var Lit_2565 *jrt.String = jrt.Intern("cnt")

var Lit_2566 *jrt.String = jrt.Intern("shift")

var Lit_2567 *jrt.String = jrt.Intern("root")

var Lit_2568 *jrt.String = jrt.Intern("arbace.core.VecNode")

var Lit_2569 *jrt.String = jrt.Intern("tail")

var Lit_2570 *jrt.String = jrt.Intern("_meta")

var Lit_2571 *jrt.String = jrt.Intern("tailoff")

var Lit_2572 *jrt.String = jrt.Intern("doAssoc")

var Lit_2573 *jrt.String = jrt.Intern("arrayFor")

var Lit_2574 *jrt.String = jrt.Intern("Key must be integer")

var Lit_2575 *jrt.String = jrt.Intern("newPath")

var Lit_2576 *jrt.String = jrt.Intern("pushTail")

var Lit_2577 *jrt.String = jrt.Intern("popTail")

var Lit_2578 *jrt.String = jrt.Intern("Can't pop empty vector")

var Lit_2579 *jrt.String = jrt.Intern("arbace.core.Vec$fn__57000044")

var Lit_2580 *jrt.String = jrt.Intern("arbace.core.Vec$fn__57000046")

var Lit_2581 *jrt.String = jrt.Intern("edit")

var Lit_2582 *jrt.String = jrt.Intern("arbace.core.IVecImpl")

var Lit_2583 *jrt.String = jrt.Intern("anode")

var Lit_2584 *jrt.String = jrt.Intern("i")

var Lit_2585 *jrt.String = jrt.Intern("offset")

var Lit_2586 *jrt.String = jrt.Intern("arbace.core.VecSeq$fn__57000031")

var Lit_2587 *jrt.String = jrt.Intern("The core Clojure language.")

var Lit_2588 *jrt.String = jrt.Intern("author")

var Lit_2589 *jrt.String = jrt.Intern("Rich Hickey")

var Lit_2590 *jrt.String = jrt.Intern("unquote")

var Lit_2591 *jrt.String = jrt.Intern("file")

var Lit_2592 *jrt.String = jrt.Intern("arbace/core.ae")

var Lit_2593 *jrt.String = jrt.Intern("unquote-splicing")

var Lit_2594 *jrt.String = jrt.Intern("items")

var Lit_2595 *jrt.String = jrt.Intern("Creates a new list containing the items.")

var Lit_2596 *jrt.String = jrt.Intern("1.0")

var Lit_2597 *jrt.String = jrt.Intern("x")

var Lit_2598 *jrt.String = jrt.Intern("Returns a new seq where x is the first element and seq is\n    the rest.")

var Lit_2599 *jrt.String = jrt.Intern("static")

var Lit_2600 *jrt.String = jrt.Intern("macro")

var Lit_2601 *jrt.String = jrt.Intern("Returns the first item in the collection. Calls seq on its\n    argument. If coll is nil, returns nil.")

var Lit_2602 *jrt.String = jrt.Intern("Returns a seq of the items after the first. Calls seq on its\n  argument.  If there are no more items, returns nil.")

var Lit_2603 *jrt.String = jrt.Intern("Returns a possibly empty seq of the items after the first. Calls seq on its\n  argument.")

var Lit_2604 *jrt.String = jrt.Intern("xs")

var Lit_2605 *jrt.String = jrt.Intern("conj[oin]. Returns a new collection with the xs\n    'added'. (conj nil item) returns (item).\n    (conj coll) returns coll. (conj) returns [].\n    The 'addition' may happen at different 'places' depending\n    on the concrete type.")

var Lit_2606 *jrt.String = jrt.Intern("Same as (first (next x))")

var Lit_2607 *jrt.String = jrt.Intern("Same as (first (first x))")

var Lit_2608 *jrt.String = jrt.Intern("nfirst")

var Lit_2609 *jrt.String = jrt.Intern("Same as (next (first x))")

var Lit_2610 *jrt.String = jrt.Intern("fnext")

var Lit_2611 *jrt.String = jrt.Intern("Same as (next (next x))")

var Lit_2612 *jrt.String = jrt.Intern("Returns a seq on the collection. If the collection is\n    empty, returns nil.  (seq nil) returns nil. seq also works on\n    Strings, native Java arrays (of reference types) and any objects\n    that implement Iterable. Note that seqs cache values, thus seq\n    should not be used on any Iterable whose iterator repeatedly\n    returns the same mutable object.")

var Lit_2613 *jrt.String = jrt.Intern("c")

var Lit_2614 *jrt.String = jrt.Intern("Class")

var Lit_2615 *jrt.String = jrt.Intern("Evaluates x and tests if it is an instance of the class\n    c. Returns true or false")

var Lit_2616 *jrt.String = jrt.Intern("Return true if x implements ISeq")

var Lit_2617 *jrt.String = jrt.Intern("char?")

var Lit_2618 *jrt.String = jrt.Intern("Return true if x is a Character")

var Lit_2619 *jrt.String = jrt.Intern("Return true if x is a String")

var Lit_2620 *jrt.String = jrt.Intern("Return true if x implements IPersistentMap")

var Lit_2621 *jrt.String = jrt.Intern("Return true if x implements IPersistentVector")

var Lit_2622 *jrt.String = jrt.Intern("kvs")

var Lit_2623 *jrt.String = jrt.Intern("assoc[iate]. When applied to a map, returns a new map of the\n    same (hashed/sorted) type, that contains the mapping of key(s) to\n    val(s). When applied to a vector, returns a new vector that\n    contains val at index. Note - index must be <= (count vector).")

var Lit_2624 *jrt.String = jrt.Intern("obj")

var Lit_2625 *jrt.String = jrt.Intern("m")

var Lit_2626 *jrt.String = jrt.Intern("Returns an object of the same type and value as obj, with\n    map m as its metadata.")

var Lit_2627 *jrt.String = jrt.Intern("dynamic")

var Lit_2628 *jrt.String = jrt.Intern("Return the last item in coll, in linear time")

var Lit_2629 *jrt.String = jrt.Intern("Return a seq of all but the last item in coll, in linear time")

var Lit_2630 *jrt.String = jrt.Intern("Same as (def name (fn [params* ] exprs*)) or (def\n    name (fn ([params* ] exprs*)+)) with any doc-string or attrs added\n    to the var metadata. prepost-map defines a map with optional keys\n    :pre and :post that contain collections of pre or post conditions.")

var Lit_2631 *jrt.String = jrt.Intern("doc-string?")

var Lit_2632 *jrt.String = jrt.Intern("attr-map?")

var Lit_2633 *jrt.String = jrt.Intern("params*")

var Lit_2634 *jrt.String = jrt.Intern("prepost-map?")

var Lit_2635 *jrt.String = jrt.Intern("body")

var Lit_2636 *jrt.String = jrt.Intern("Returns an array of Objects containing the contents of coll, which\n  can be any Collection.  Maps to java.util.Collection.toArray().")

var Lit_2637 *jrt.String = jrt.Intern("Throws a ClassCastException if x is not a c, else returns x.")

var Lit_2638 *jrt.String = jrt.Intern("a")

var Lit_2639 *jrt.String = jrt.Intern("b")

var Lit_2640 *jrt.String = jrt.Intern("d")

var Lit_2641 *jrt.String = jrt.Intern("e")

var Lit_2642 *jrt.String = jrt.Intern("f")

var Lit_2643 *jrt.String = jrt.Intern("args")

var Lit_2644 *jrt.String = jrt.Intern("Creates a new vector containing the args.")

var Lit_2645 *jrt.String = jrt.Intern("Creates a new vector containing the contents of coll. Java arrays\n  will be aliased and should not be modified.")

var Lit_2646 *jrt.String = jrt.Intern("keyvals")

var Lit_2647 *jrt.String = jrt.Intern("keyval => key val\n  Returns a new hash map with supplied mappings.  If any keys are\n  equal, they are handled as if by repeated uses of assoc.")

var Lit_2648 *jrt.String = jrt.Intern("Returns a new hash set with supplied keys.  Any equal keys are\n  handled as if by repeated uses of conj.")

var Lit_2649 *jrt.String = jrt.Intern("keyval => key val\n  Returns a new sorted map with supplied mappings.  If any keys are\n  equal, they are handled as if by repeated uses of assoc.")

var Lit_2650 *jrt.String = jrt.Intern("sorted-map-by")

var Lit_2651 *jrt.String = jrt.Intern("comparator")

var Lit_2652 *jrt.String = jrt.Intern("keyval => key val\n  Returns a new sorted map with supplied mappings, using the supplied\n  comparator.  If any keys are equal, they are handled as if by\n  repeated uses of assoc.")

var Lit_2653 *jrt.String = jrt.Intern("Returns a new sorted set with supplied keys.  Any equal keys are\n  handled as if by repeated uses of conj.")

var Lit_2654 *jrt.String = jrt.Intern("sorted-set-by")

var Lit_2655 *jrt.String = jrt.Intern("Returns a new sorted set with supplied keys, using the supplied\n  comparator.  Any equal keys are handled as if by repeated uses of\n  conj.")

var Lit_2656 *jrt.String = jrt.Intern("1.1")

var Lit_2657 *jrt.String = jrt.Intern("java.lang.Boolean")

var Lit_2658 *jrt.String = jrt.Intern("defmacro")

var Lit_2659 *jrt.String = jrt.Intern("Like defn, but the resulting function name is declared as a\n  macro and will be used as a macro by the compiler when it is\n  called.")

var Lit_2660 *jrt.String = jrt.Intern("Evaluates test. If logical true, evaluates body in an implicit do.")

var Lit_2661 *jrt.String = jrt.Intern("Evaluates test. If logical false, evaluates body in an implicit do.")

var Lit_2662 *jrt.String = jrt.Intern("false?")

var Lit_2663 *jrt.String = jrt.Intern("Returns true if x is the value false, false otherwise.")

var Lit_2664 *jrt.String = jrt.Intern("true?")

var Lit_2665 *jrt.String = jrt.Intern("Returns true if x is the value true, false otherwise.")

var Lit_2666 *jrt.String = jrt.Intern("boolean?")

var Lit_2667 *jrt.String = jrt.Intern("Return true if x is a Boolean")

var Lit_2668 *jrt.String = jrt.Intern("1.9")

var Lit_2669 *jrt.String = jrt.Intern("Returns true if x is logical false, false otherwise.")

var Lit_2670 *jrt.String = jrt.Intern("Returns true if x is not nil, false otherwise.")

var Lit_2671 *jrt.String = jrt.Intern("1.6")

var Lit_2672 *jrt.String = jrt.Intern("any?")

var Lit_2673 *jrt.String = jrt.Intern("Returns true given any argument.")

var Lit_2674 *jrt.String = jrt.Intern("ys")

var Lit_2675 *jrt.String = jrt.Intern("With no args, returns the empty string. With one arg x, returns\n  x.toString().  (str nil) returns the empty string. With more than\n  one arg, returns the concatenation of the str values of the args.")

var Lit_2676 *jrt.String = jrt.Intern("Return true if x is a Symbol")

var Lit_2677 *jrt.String = jrt.Intern("Return true if x is a Keyword")

var Lit_2678 *jrt.String = jrt.Intern("Takes a set of test/expr pairs. It evaluates each test one at a\n  time.  If a test returns logical true, cond evaluates and returns\n  the value of the corresponding expr and doesn't evaluate any of the\n  other tests or exprs. (cond) returns nil.")

var Lit_2679 *jrt.String = jrt.Intern("ns")

var Lit_2680 *jrt.String = jrt.Intern("Returns a Symbol with the given namespace and name. Arity-1 works\n  on strings, keywords, and vars.")

var Lit_2681 *jrt.String = jrt.Intern("arbace.lang.Symbol")

var Lit_2682 *jrt.String = jrt.Intern("prefix-string")

var Lit_2683 *jrt.String = jrt.Intern("Returns a new symbol with a unique name. If a prefix string is\n  supplied, the name is prefix# where # is some unique number. If\n  prefix is not supplied, the prefix is 'G__'.")

var Lit_2684 *jrt.String = jrt.Intern("Returns a Keyword with the given namespace and name.  Do not use :\n  in the keyword strings, it will be added automatically.")

var Lit_2685 *jrt.String = jrt.Intern("arbace.lang.Keyword")

var Lit_2686 *jrt.String = jrt.Intern("find-keyword")

var Lit_2687 *jrt.String = jrt.Intern("Returns a Keyword with the given namespace and name if one already\n  exists.  This function will not intern a new keyword. If the keyword\n  has not already been interned, it will return nil.  Do not use :\n  in the keyword strings, it will be added automatically.")

var Lit_2688 *jrt.String = jrt.Intern("1.3")

var Lit_2689 *jrt.String = jrt.Intern("arglist")

var Lit_2690 *jrt.String = jrt.Intern("more")

var Lit_2691 *jrt.String = jrt.Intern("Creates a new seq containing the items prepended to the rest, the\n  last of which will be treated as a sequence.")

var Lit_2692 *jrt.String = jrt.Intern("arbace.lang.IFn")

var Lit_2693 *jrt.String = jrt.Intern("y")

var Lit_2694 *jrt.String = jrt.Intern("z")

var Lit_2695 *jrt.String = jrt.Intern("Applies fn f to the argument list formed by prepending intervening arguments to args.")

var Lit_2696 *jrt.String = jrt.Intern("Returns an object of the same type and value as obj, with\n  (apply f (meta obj) args) as its metadata.")

var Lit_2697 *jrt.String = jrt.Intern("Takes a body of expressions that returns an ISeq or nil, and yields\n  a Seqable object that will invoke the body only the first time seq\n  is called, and will cache the result and return it on all subsequent\n  seq calls. See also - realized?")

var Lit_2698 *jrt.String = jrt.Intern("arbace.lang.ChunkBuffer")

var Lit_2699 *jrt.String = jrt.Intern("capacity")

var Lit_2700 *jrt.String = jrt.Intern("arbace.lang.IChunkedSeq")

var Lit_2701 *jrt.String = jrt.Intern("zs")

var Lit_2702 *jrt.String = jrt.Intern("Returns a lazy seq representing the concatenation of the elements in the supplied colls.")

var Lit_2703 *jrt.String = jrt.Intern("delay")

var Lit_2704 *jrt.String = jrt.Intern("Takes a body of expressions and yields a Delay object that will\n  invoke the body only the first time it is forced (with force or deref/@), and\n  will cache the result and return it on all subsequent force\n  calls. See also - realized?")

var Lit_2705 *jrt.String = jrt.Intern("delay?")

var Lit_2706 *jrt.String = jrt.Intern("returns true if x is a Delay created with delay")

var Lit_2707 *jrt.String = jrt.Intern("If x is a Delay, returns the (possibly cached) value of its expression, else returns x")

var Lit_2708 *jrt.String = jrt.Intern("then")

var Lit_2709 *jrt.String = jrt.Intern("Evaluates test. If logical false, evaluates and returns then expr,\n  otherwise else expr, if supplied, else nil.")

var Lit_2710 *jrt.String = jrt.Intern("Same as (not (= obj1 obj2))")

var Lit_2711 *jrt.String = jrt.Intern("Evaluates exprs one at a time, from left to right. If a form\n  returns logical false (nil or false), and returns that value and\n  doesn't evaluate any of the other expressions, otherwise it returns\n  the value of the last expr. (and) returns true.")

var Lit_2712 *jrt.String = jrt.Intern("Evaluates exprs one at a time, from left to right. If a form\n  returns a logical true value, or returns that value and doesn't\n  evaluate any of the other expressions, otherwise it returns the\n  value of the last expression. (or) returns nil.")

var Lit_2713 *jrt.String = jrt.Intern("index")

var Lit_2714 *jrt.String = jrt.Intern("not-found")

var Lit_2715 *jrt.String = jrt.Intern("redef")

var Lit_2716 *jrt.String = jrt.Intern("Returns a seq of the items in coll in reverse order. Not lazy.")

var Lit_2717 *jrt.String = jrt.Intern("op")

var Lit_2718 *jrt.String = jrt.Intern("unchecked-op")

var Lit_2719 *jrt.String = jrt.Intern(">1?")

var Lit_2720 *jrt.String = jrt.Intern("n")

var Lit_2721 *jrt.String = jrt.Intern(">0?")

var Lit_2722 *jrt.String = jrt.Intern("addP")

var Lit_2723 *jrt.String = jrt.Intern("add")

var Lit_2724 *jrt.String = jrt.Intern("multiplyP")

var Lit_2725 *jrt.String = jrt.Intern("multiply")

var Lit_2726 *jrt.String = jrt.Intern("divide")

var Lit_2727 *jrt.String = jrt.Intern("minusP")

var Lit_2728 *jrt.String = jrt.Intern("minus")

var Lit_2729 *jrt.String = jrt.Intern("dec'")

var Lit_2730 *jrt.String = jrt.Intern("unchecked-dec-int")

var Lit_2731 *jrt.String = jrt.Intern("unchecked-dec")

var Lit_2732 *jrt.String = jrt.Intern("unchecked-negate-int")

var Lit_2733 *jrt.String = jrt.Intern("unchecked-negate")

var Lit_2734 *jrt.String = jrt.Intern("unchecked-add-int")

var Lit_2735 *jrt.String = jrt.Intern("unchecked-add")

var Lit_2736 *jrt.String = jrt.Intern("unchecked-subtract-int")

var Lit_2737 *jrt.String = jrt.Intern("unchecked-subtract")

var Lit_2738 *jrt.String = jrt.Intern("unchecked-multiply-int")

var Lit_2739 *jrt.String = jrt.Intern("unchecked-multiply")

var Lit_2740 *jrt.String = jrt.Intern("unchecked-divide-int")

var Lit_2741 *jrt.String = jrt.Intern("unchecked-remainder-int")

var Lit_2742 *jrt.String = jrt.Intern("pos?")

var Lit_2743 *jrt.String = jrt.Intern("neg?")

var Lit_2744 *jrt.String = jrt.Intern("quot")

var Lit_2745 *jrt.String = jrt.Intern("div")

var Lit_2746 *jrt.String = jrt.Intern("rem")

var Lit_2747 *jrt.String = jrt.Intern("rationalize")

var Lit_2748 *jrt.String = jrt.Intern("returns the rational value of num")

var Lit_2749 *jrt.String = jrt.Intern("bit-not")

var Lit_2750 *jrt.String = jrt.Intern("xor")

var Lit_2751 *jrt.String = jrt.Intern("andNot")

var Lit_2752 *jrt.String = jrt.Intern("bit-clear")

var Lit_2753 *jrt.String = jrt.Intern("Clear bit at index n")

var Lit_2754 *jrt.String = jrt.Intern("bit-set")

var Lit_2755 *jrt.String = jrt.Intern("Set bit at index n")

var Lit_2756 *jrt.String = jrt.Intern("bit-flip")

var Lit_2757 *jrt.String = jrt.Intern("Flip bit at index n")

var Lit_2758 *jrt.String = jrt.Intern("bit-test")

var Lit_2759 *jrt.String = jrt.Intern("Test bit at index n")

var Lit_2760 *jrt.String = jrt.Intern("bit-shift-left")

var Lit_2761 *jrt.String = jrt.Intern("bit-shift-right")

var Lit_2762 *jrt.String = jrt.Intern("unsigned-bit-shift-right")

var Lit_2763 *jrt.String = jrt.Intern("Returns true if n is an integer")

var Lit_2764 *jrt.String = jrt.Intern("Returns true if n is even, throws an exception if n is not an integer")

var Lit_2765 *jrt.String = jrt.Intern("Returns true if n is odd, throws an exception if n is not an integer")

var Lit_2766 *jrt.String = jrt.Intern("Return true if x is a fixed precision integer")

var Lit_2767 *jrt.String = jrt.Intern("pos-int?")

var Lit_2768 *jrt.String = jrt.Intern("Return true if x is a positive fixed precision integer")

var Lit_2769 *jrt.String = jrt.Intern("neg-int?")

var Lit_2770 *jrt.String = jrt.Intern("Return true if x is a negative fixed precision integer")

var Lit_2771 *jrt.String = jrt.Intern("nat-int?")

var Lit_2772 *jrt.String = jrt.Intern("Return true if x is a non-negative fixed precision integer")

var Lit_2773 *jrt.String = jrt.Intern("double?")

var Lit_2774 *jrt.String = jrt.Intern("Return true if x is a Double")

var Lit_2775 *jrt.String = jrt.Intern("Takes a fn f and returns a fn that takes the same arguments as f,\n  has the same effects, if any, and returns the opposite truth value.")

var Lit_2776 *jrt.String = jrt.Intern("constantly")

var Lit_2777 *jrt.String = jrt.Intern("Returns a function that takes any number of arguments and returns x.")

var Lit_2778 *jrt.String = jrt.Intern("Returns its argument.")

var Lit_2779 *jrt.String = jrt.Intern("For a list or queue, same as first, for a vector, same as, but much\n  more efficient than, last. If the collection is empty, returns nil.")

var Lit_2780 *jrt.String = jrt.Intern("For a list or queue, returns a new list/queue without the first\n  item, for a vector, returns a new vector without the last item. If\n  the collection is empty, throws an exception.  Note - not the same\n  as next/butlast.")

var Lit_2781 *jrt.String = jrt.Intern("Return true if x is a map entry")

var Lit_2782 *jrt.String = jrt.Intern("1.8")

var Lit_2783 *jrt.String = jrt.Intern("Returns true if key is present in the given collection, otherwise\n  returns false.  Note that for numerically indexed collections like\n  vectors and Java arrays, this tests if the numeric key is within the\n  range of indexes. 'contains?' operates constant or logarithmic time;\n  it will not perform a linear search for a value.  See also 'some'.")

var Lit_2784 *jrt.String = jrt.Intern("k")

var Lit_2785 *jrt.String = jrt.Intern("ks")

var Lit_2786 *jrt.String = jrt.Intern("dissoc[iate]. Returns a new map of the same (hashed/sorted) type,\n  that does not contain a mapping for key(s).")

var Lit_2787 *jrt.String = jrt.Intern("arbace.lang.IPersistentSet")

var Lit_2788 *jrt.String = jrt.Intern("disj[oin]. Returns a new set of the same (hashed/sorted) type, that\n  does not contain key(s).")

var Lit_2789 *jrt.String = jrt.Intern("Returns the map entry for key, or nil if key not present.")

var Lit_2790 *jrt.String = jrt.Intern("Returns a sequence of the map's keys, in the same order as (seq map).")

var Lit_2791 *jrt.String = jrt.Intern("Returns a sequence of the map's values, in the same order as (seq map).")

var Lit_2792 *jrt.String = jrt.Intern("java.util.Map$Entry")

var Lit_2793 *jrt.String = jrt.Intern("Returns the key of the map entry.")

var Lit_2794 *jrt.String = jrt.Intern("Returns the value in the map entry.")

var Lit_2795 *jrt.String = jrt.Intern("rseq")

var Lit_2796 *jrt.String = jrt.Intern("rev")

var Lit_2797 *jrt.String = jrt.Intern("arbace.lang.Reversible")

var Lit_2798 *jrt.String = jrt.Intern("Returns, in constant time, a seq of the items in rev (which\n  can be a vector or sorted-map), in reverse order. If rev is empty returns nil")

var Lit_2799 *jrt.String = jrt.Intern("Returns the name String of a string, symbol or keyword.")

var Lit_2800 *jrt.String = jrt.Intern("Returns the namespace String of a symbol or keyword, or nil if not present.")

var Lit_2801 *jrt.String = jrt.Intern("Return true if x is a symbol or keyword")

var Lit_2802 *jrt.String = jrt.Intern("simple-ident?")

var Lit_2803 *jrt.String = jrt.Intern("Return true if x is a symbol or keyword without a namespace")

var Lit_2804 *jrt.String = jrt.Intern("Return true if x is a symbol or keyword with a namespace")

var Lit_2805 *jrt.String = jrt.Intern("simple-symbol?")

var Lit_2806 *jrt.String = jrt.Intern("Return true if x is a symbol without a namespace")

var Lit_2807 *jrt.String = jrt.Intern("Return true if x is a symbol with a namespace")

var Lit_2808 *jrt.String = jrt.Intern("simple-keyword?")

var Lit_2809 *jrt.String = jrt.Intern("Return true if x is a keyword without a namespace")

var Lit_2810 *jrt.String = jrt.Intern("qualified-keyword?")

var Lit_2811 *jrt.String = jrt.Intern("Return true if x is a keyword with a namespace")

var Lit_2812 *jrt.String = jrt.Intern("locking")

var Lit_2813 *jrt.String = jrt.Intern("Executes exprs in an implicit do, while holding the monitor of x.\n  Will release the monitor of x in all circumstances.")

var Lit_2814 *jrt.String = jrt.Intern("form => fieldName-symbol or (instanceMethodName-symbol args*)\n\n  Expands into a member access (.) of the first member on the first\n  argument, followed by the next member on the result, etc. For\n  instance:\n\n  (.. System (getProperties) (get \"os.name\"))\n\n  expands to:\n\n  (. (. System (getProperties)) (get \"os.name\"))\n\n  but is easier to write, read, and understand.")

var Lit_2815 *jrt.String = jrt.Intern("forms")

var Lit_2816 *jrt.String = jrt.Intern("Threads the expr through the forms. Inserts x as the\n  second item in the first form, making a list of it if it is not a\n  list already. If there are more forms, inserts the first form as the\n  second item in second form, etc.")

var Lit_2817 *jrt.String = jrt.Intern("Threads the expr through the forms. Inserts x as the\n  last item in the first form, making a list of it if it is not a\n  list already. If there are more forms, inserts the first form as the\n  last item in second form, etc.")

var Lit_2818 *jrt.String = jrt.Intern("options")

var Lit_2819 *jrt.String = jrt.Intern("valid-keys")

var Lit_2820 *jrt.String = jrt.Intern("Throws an exception if the given option map contains keys not listed\n  as valid, else returns nil.")

var Lit_2821 *jrt.String = jrt.Intern("defmulti")

var Lit_2822 *jrt.String = jrt.Intern("docstring?")

var Lit_2823 *jrt.String = jrt.Intern("dispatch-fn")

var Lit_2824 *jrt.String = jrt.Intern("Creates a new multimethod with the associated dispatch function.\n  The docstring and attr-map are optional.\n\n  Options are key-value pairs and may be one of:\n\n  :default\n\n  The default dispatch value, defaults to :default\n\n  :hierarchy\n\n  The value used for hierarchical dispatch (e.g. ::square is-a ::shape)\n\n  Hierarchies are type-like relationships that do not depend upon type\n  inheritance. By default Clojure's multimethods dispatch off of a\n  global hierarchy map.  However, a hierarchy relationship can be\n  created with the derive function used to augment the root ancestor\n  created with make-hierarchy.\n\n  Multimethods expect the value of the hierarchy option to be supplied as\n  a reference type e.g. a var (i.e. via the Var-quote dispatch macro #'\n  or the var special form).")

var Lit_2825 *jrt.String = jrt.Intern("defmethod")

var Lit_2826 *jrt.String = jrt.Intern("multifn")

var Lit_2827 *jrt.String = jrt.Intern("dispatch-val")

var Lit_2828 *jrt.String = jrt.Intern("fn-tail")

var Lit_2829 *jrt.String = jrt.Intern("Creates and installs a new method of multimethod associated with dispatch-value. ")

var Lit_2830 *jrt.String = jrt.Intern("remove-all-methods")

var Lit_2831 *jrt.String = jrt.Intern("Removes all of the methods of multimethod.")

var Lit_2832 *jrt.String = jrt.Intern("1.2")

var Lit_2833 *jrt.String = jrt.Intern("remove-method")

var Lit_2834 *jrt.String = jrt.Intern("Removes the method of multimethod associated with dispatch-value.")

var Lit_2835 *jrt.String = jrt.Intern("prefer-method")

var Lit_2836 *jrt.String = jrt.Intern("dispatch-val-x")

var Lit_2837 *jrt.String = jrt.Intern("dispatch-val-y")

var Lit_2838 *jrt.String = jrt.Intern("Causes the multimethod to prefer matches of dispatch-val-x over dispatch-val-y\n   when there is a conflict")

var Lit_2839 *jrt.String = jrt.Intern("Given a multimethod, returns a map of dispatch values -> dispatch fns")

var Lit_2840 *jrt.String = jrt.Intern("get-method")

var Lit_2841 *jrt.String = jrt.Intern("Given a multimethod and a dispatch value, returns the dispatch fn\n  that would apply to that value, or nil if none apply and no default")

var Lit_2842 *jrt.String = jrt.Intern("prefers")

var Lit_2843 *jrt.String = jrt.Intern("Given a multimethod, returns a map of preferred value -> set of other values")

var Lit_2844 *jrt.String = jrt.Intern("pairs")

var Lit_2845 *jrt.String = jrt.Intern("bindings")

var Lit_2846 *jrt.String = jrt.Intern("oldform")

var Lit_2847 *jrt.String = jrt.Intern("bindings => binding-form test\n\n  If test is true, evaluates then with binding-form bound to the value of\n  test, if not, yields else")

var Lit_2848 *jrt.String = jrt.Intern("bindings => binding-form test\n\n  When test is true, evaluates body with binding-form bound to the value of test")

var Lit_2849 *jrt.String = jrt.Intern("bindings => binding-form test\n\n   If test is not nil, evaluates then with binding-form bound to the\n   value of test, if not, yields else")

var Lit_2850 *jrt.String = jrt.Intern("when-some")

var Lit_2851 *jrt.String = jrt.Intern("bindings => binding-form test\n\n   When test is not nil, evaluates body with binding-form bound to the\n   value of test")

var Lit_2852 *jrt.String = jrt.Intern("WARNING: This is a low-level function. Prefer high-level macros like\n  binding where ever possible.\n\n  Takes a map of Var/value pairs. Binds each Var to the associated value for\n  the current thread. Each call *MUST* be accompanied by a matching call to\n  pop-thread-bindings wrapped in a try-finally!\n\n      (push-thread-bindings bindings)\n      (try\n        ...\n        (finally\n          (pop-thread-bindings)))")

var Lit_2853 *jrt.String = jrt.Intern("Pop one set of bindings pushed with push-binding before. It is an error to\n  pop bindings without pushing before.")

var Lit_2854 *jrt.String = jrt.Intern("Get a map with the Var/value pairs which is currently in effect for the\n  current thread.")

var Lit_2855 *jrt.String = jrt.Intern("binding => var-symbol init-expr\n\n  Creates new bindings for the (already-existing) vars, with the\n  supplied initial values, executes the exprs in an implicit do, then\n  re-establishes the bindings that existed before.  The new bindings\n  are made in parallel (unlike let); all init-exprs are evaluated\n  before the vars are bound to their new values.")

var Lit_2856 *jrt.String = jrt.Intern("binding-map")

var Lit_2857 *jrt.String = jrt.Intern("Takes a map of Var/value pairs. Installs for the given Vars the associated\n  values as thread-local bindings. Then calls f with the supplied arguments.\n  Pops the installed bindings after f returned. Returns whatever f returns.")

var Lit_2858 *jrt.String = jrt.Intern("with-bindings")

var Lit_2859 *jrt.String = jrt.Intern("Takes a map of Var/value pairs. Installs for the given Vars the associated\n  values as thread-local bindings. Then executes body. Pops the installed\n  bindings after body was evaluated. Returns the value of body.")

var Lit_2860 *jrt.String = jrt.Intern("Returns a function, which will install the same bindings in effect as in\n  the thread at the time bound-fn* was called and then call f with any given\n  arguments. This may be used to define a helper function which runs on a\n  different thread, but needs the same bindings in place.")

var Lit_2861 *jrt.String = jrt.Intern("bound-fn")

var Lit_2862 *jrt.String = jrt.Intern("fntail")

var Lit_2863 *jrt.String = jrt.Intern("Returns a function defined by the given fntail, which will install the\n  same bindings in effect as in the thread at the time bound-fn was called.\n  This may be used to define a helper function which runs on a different\n  thread, but needs the same bindings in place.")

var Lit_2864 *jrt.String = jrt.Intern("find-var")

var Lit_2865 *jrt.String = jrt.Intern("Returns the global var named by the namespace-qualified symbol, or\n  nil if no var with that name.")

var Lit_2866 *jrt.String = jrt.Intern("r")

var Lit_2867 *jrt.String = jrt.Intern("arbace.lang.ARef")

var Lit_2868 *jrt.String = jrt.Intern("state")

var Lit_2869 *jrt.String = jrt.Intern("Creates and returns an agent with an initial value of state and\n  zero or more options (in any order):\n\n  :meta metadata-map\n\n  :validator validate-fn\n\n  :error-handler handler-fn\n\n  :error-mode mode-keyword\n\n  If metadata-map is supplied, it will become the metadata on the\n  agent. validate-fn must be nil or a side-effect-free fn of one\n  argument, which will be passed the intended new state on any state\n  change. If the new state is unacceptable, the validate-fn should\n  return false or throw an exception.  handler-fn is called if an\n  action throws an exception or if validate-fn rejects a new state --\n  see set-error-handler! for details.  The mode-keyword may be either\n  :continue (the default if an error-handler is given) or :fail (the\n  default if no error-handler is given) -- see set-error-mode! for\n  details.")

var Lit_2870 *jrt.String = jrt.Intern("set-agent-send-executor!")

var Lit_2871 *jrt.String = jrt.Intern("executor")

var Lit_2872 *jrt.String = jrt.Intern("Sets the ExecutorService to be used by send")

var Lit_2873 *jrt.String = jrt.Intern("1.5")

var Lit_2874 *jrt.String = jrt.Intern("set-agent-send-off-executor!")

var Lit_2875 *jrt.String = jrt.Intern("Sets the ExecutorService to be used by send-off")

var Lit_2876 *jrt.String = jrt.Intern("arbace.lang.Agent")

var Lit_2877 *jrt.String = jrt.Intern("Dispatch an action to an agent. Returns the agent immediately.\n  Subsequently, in a thread supplied by executor, the state of the agent\n  will be set to the value of:\n\n  (apply action-fn state-of-agent args)")

var Lit_2878 *jrt.String = jrt.Intern("Dispatch an action to an agent. Returns the agent immediately.\n  Subsequently, in a thread from a thread pool, the state of the agent\n  will be set to the value of:\n\n  (apply action-fn state-of-agent args)")

var Lit_2879 *jrt.String = jrt.Intern("Dispatch a potentially blocking action to an agent. Returns the\n  agent immediately. Subsequently, in a separate thread, the state of\n  the agent will be set to the value of:\n\n  (apply action-fn state-of-agent args)")

var Lit_2880 *jrt.String = jrt.Intern("Normally, actions sent directly or indirectly during another action\n  are held until the action completes (changes the agent's\n  state). This function can be used to dispatch any pending sent\n  actions immediately. This has no impact on actions sent during a\n  transaction, which are still held until commit. If no action is\n  occurring, does nothing. Returns the number of actions dispatched.")

var Lit_2881 *jrt.String = jrt.Intern("add-watch")

var Lit_2882 *jrt.String = jrt.Intern("reference")

var Lit_2883 *jrt.String = jrt.Intern("arbace.lang.IRef")

var Lit_2884 *jrt.String = jrt.Intern("Adds a watch function to an agent/atom/var/ref reference. The watch\n  fn must be a fn of 4 args: a key, the reference, its old-state, its\n  new-state. Whenever the reference's state might have been changed,\n  any registered watches will have their functions called. The watch fn\n  will be called synchronously, on the agent's thread if an agent,\n  before any pending sends if agent or ref. Note that an atom's or\n  ref's state may have changed again prior to the fn call, so use\n  old/new-state rather than derefing the reference. Note also that watch\n  fns may be called from multiple threads simultaneously. Var watchers\n  are triggered only by root binding changes, not thread-local\n  set!s. Keys must be unique per reference, and can be used to remove\n  the watch with remove-watch, but are otherwise considered opaque by\n  the watch mechanism.")

var Lit_2885 *jrt.String = jrt.Intern("remove-watch")

var Lit_2886 *jrt.String = jrt.Intern("Removes a watch (set by add-watch) from a reference")

var Lit_2887 *jrt.String = jrt.Intern("Returns the exception thrown during an asynchronous action of the\n  agent if the agent is failed.  Returns nil if the agent is not\n  failed.")

var Lit_2888 *jrt.String = jrt.Intern("new-state")

var Lit_2889 *jrt.String = jrt.Intern("When an agent is failed, changes the agent state to new-state and\n  then un-fails the agent so that sends are allowed again.  If\n  a :clear-actions true option is given, any actions queued on the\n  agent that were being held while it was failed will be discarded,\n  otherwise those held actions will proceed.  The new-state must pass\n  the validator if any, or restart will throw an exception and the\n  agent will remain failed with its old state and error.  Watchers, if\n  any, will NOT be notified of the new state.  Throws an exception if\n  the agent is not failed.")

var Lit_2890 *jrt.String = jrt.Intern("set-error-handler!")

var Lit_2891 *jrt.String = jrt.Intern("handler-fn")

var Lit_2892 *jrt.String = jrt.Intern("Sets the error-handler of agent a to handler-fn.  If an action\n  being run by the agent throws an exception or doesn't pass the\n  validator fn, handler-fn will be called with two arguments: the\n  agent and the exception.")

var Lit_2893 *jrt.String = jrt.Intern("Returns the error-handler of agent a, or nil if there is none.\n  See set-error-handler!")

var Lit_2894 *jrt.String = jrt.Intern("set-error-mode!")

var Lit_2895 *jrt.String = jrt.Intern("mode-keyword")

var Lit_2896 *jrt.String = jrt.Intern("Sets the error-mode of agent a to mode-keyword, which must be\n  either :fail or :continue.  If an action being run by the agent\n  throws an exception or doesn't pass the validator fn, an\n  error-handler may be called (see set-error-handler!), after which,\n  if the mode is :continue, the agent will continue as if neither the\n  action that caused the error nor the error itself ever happened.\n\n  If the mode is :fail, the agent will become failed and will stop\n  accepting new 'send' and 'send-off' actions, and any previously\n  queued actions will be held until a 'restart-agent'.  Deref will\n  still work, returning the state of the agent before the error.")

var Lit_2897 *jrt.String = jrt.Intern("Returns the error-mode of agent a.  See set-error-mode!")

var Lit_2898 *jrt.String = jrt.Intern("agent-errors")

var Lit_2899 *jrt.String = jrt.Intern("DEPRECATED: Use 'agent-error' instead.\n  Returns a sequence of the exceptions thrown during asynchronous\n  actions of the agent.")

var Lit_2900 *jrt.String = jrt.Intern("deprecated")

var Lit_2901 *jrt.String = jrt.Intern("clear-agent-errors")

var Lit_2902 *jrt.String = jrt.Intern("DEPRECATED: Use 'restart-agent' instead.\n  Clears any exceptions thrown during asynchronous actions of the\n  agent, allowing subsequent actions to occur.")

var Lit_2903 *jrt.String = jrt.Intern("shutdown-agents")

var Lit_2904 *jrt.String = jrt.Intern("Initiates a shutdown of the thread pools that back the agent\n  system. Running actions will complete, but no new actions will be\n  accepted")

var Lit_2905 *jrt.String = jrt.Intern("Creates and returns a Ref with an initial value of x and zero or\n  more options (in any order):\n\n  :meta metadata-map\n\n  :validator validate-fn\n\n  :min-history (default 0)\n  :max-history (default 10)\n\n  If metadata-map is supplied, it will become the metadata on the\n  ref. validate-fn must be nil or a side-effect-free fn of one\n  argument, which will be passed the intended new state on any state\n  change. If the new state is unacceptable, the validate-fn should\n  return false or throw an exception. validate-fn will be called on\n  transaction commit, when all refs have their final values.\n\n  Normally refs accumulate history dynamically as needed to deal with\n  read demands. If you know in advance you will need history you can\n  set :min-history to ensure it will be available when first needed (instead\n  of after a read fault). History is limited, and the limit can be set\n  with :max-history.")

var Lit_2906 *jrt.String = jrt.Intern("fut")

var Lit_2907 *jrt.String = jrt.Intern("java.util.concurrent.Future")

var Lit_2908 *jrt.String = jrt.Intern("timeout-ms")

var Lit_2909 *jrt.String = jrt.Intern("timeout-val")

var Lit_2910 *jrt.String = jrt.Intern("Also reader macro: @ref/@agent/@var/@atom/@delay/@future/@promise. Within a transaction,\n  returns the in-transaction-value of ref, else returns the\n  most-recently-committed value of ref. When applied to a var, agent\n  or atom, returns its current state. When applied to a delay, forces\n  it if not already forced. When applied to a future, will block if\n  computation not complete. When applied to a promise, will block\n  until a value is delivered.  The variant taking a timeout can be\n  used for blocking references (futures and promises), and will return\n  timeout-val if the timeout (in milliseconds) is reached before a\n  value is available. See also - realized?.")

var Lit_2911 *jrt.String = jrt.Intern("Creates and returns an Atom with an initial value of x and zero or\n  more options (in any order):\n\n  :meta metadata-map\n\n  :validator validate-fn\n\n  If metadata-map is supplied, it will become the metadata on the\n  atom. validate-fn must be nil or a side-effect-free fn of one\n  argument, which will be passed the intended new state on any state\n  change. If the new state is unacceptable, the validate-fn should\n  return false or throw an exception.")

var Lit_2912 *jrt.String = jrt.Intern("arbace.lang.IAtom")

var Lit_2913 *jrt.String = jrt.Intern("Atomically swaps the value of atom to be:\n  (apply f current-value-of-atom args). Note that f may be called\n  multiple times, and thus should be free of side effects.  Returns\n  the value that was swapped in.")

var Lit_2914 *jrt.String = jrt.Intern("swap-vals!")

var Lit_2915 *jrt.String = jrt.Intern("arbace.lang.IAtom2")

var Lit_2916 *jrt.String = jrt.Intern("Atomically swaps the value of atom to be:\n  (apply f current-value-of-atom args). Note that f may be called\n  multiple times, and thus should be free of side effects.\n  Returns [old new], the value of the atom before and after the swap.")

var Lit_2917 *jrt.String = jrt.Intern("oldval")

var Lit_2918 *jrt.String = jrt.Intern("newval")

var Lit_2919 *jrt.String = jrt.Intern("Atomically sets the value of atom to newval if and only if the\n  current value of the atom is identical to oldval. Returns true if\n  set happened, else false")

var Lit_2920 *jrt.String = jrt.Intern("reset!")

var Lit_2921 *jrt.String = jrt.Intern("Sets the value of atom to newval without regard for the\n  current value. Returns newval.")

var Lit_2922 *jrt.String = jrt.Intern("reset-vals!")

var Lit_2923 *jrt.String = jrt.Intern("Sets the value of atom to newval. Returns [old new], the value of the\n   atom before and after the reset.")

var Lit_2924 *jrt.String = jrt.Intern("set-validator!")

var Lit_2925 *jrt.String = jrt.Intern("iref")

var Lit_2926 *jrt.String = jrt.Intern("validator-fn")

var Lit_2927 *jrt.String = jrt.Intern("Sets the validator-fn for a var/ref/agent/atom. validator-fn must be nil or a\n  side-effect-free fn of one argument, which will be passed the intended\n  new state on any state change. If the new state is unacceptable, the\n  validator-fn should return false or throw an exception. If the current state (root\n  value if var) is not acceptable to the new validator, an exception\n  will be thrown and the validator will not be changed.")

var Lit_2928 *jrt.String = jrt.Intern("get-validator")

var Lit_2929 *jrt.String = jrt.Intern("Gets the validator-fn for a var/ref/agent/atom.")

var Lit_2930 *jrt.String = jrt.Intern("arbace.lang.IReference")

var Lit_2931 *jrt.String = jrt.Intern("Atomically sets the metadata for a namespace/var/ref/agent/atom to be:\n\n  (apply f its-current-meta args)\n\n  f must be free of side-effects")

var Lit_2932 *jrt.String = jrt.Intern("reset-meta!")

var Lit_2933 *jrt.String = jrt.Intern("metadata-map")

var Lit_2934 *jrt.String = jrt.Intern("Atomically resets the metadata for a namespace/var/ref/agent/atom")

var Lit_2935 *jrt.String = jrt.Intern("arbace.lang.Ref")

var Lit_2936 *jrt.String = jrt.Intern("fun")

var Lit_2937 *jrt.String = jrt.Intern("Must be called in a transaction. Sets the in-transaction-value of\n  ref to:\n\n  (apply fun in-transaction-value-of-ref args)\n\n  and returns the in-transaction-value of ref.\n\n  At the commit point of the transaction, sets the value of ref to be:\n\n  (apply fun most-recently-committed-value-of-ref args)\n\n  Thus fun should be commutative, or, failing that, you must accept\n  last-one-in-wins behavior.  commute allows for more concurrency than\n  ref-set.")

var Lit_2938 *jrt.String = jrt.Intern("alter")

var Lit_2939 *jrt.String = jrt.Intern("Must be called in a transaction. Sets the in-transaction-value of\n  ref to:\n\n  (apply fun in-transaction-value-of-ref args)\n\n  and returns the in-transaction-value of ref.")

var Lit_2940 *jrt.String = jrt.Intern("ref-set")

var Lit_2941 *jrt.String = jrt.Intern("Must be called in a transaction. Sets the value of ref.\n  Returns val.")

var Lit_2942 *jrt.String = jrt.Intern("ref-history-count")

var Lit_2943 *jrt.String = jrt.Intern("Returns the history count of a ref")

var Lit_2944 *jrt.String = jrt.Intern("ref-min-history")

var Lit_2945 *jrt.String = jrt.Intern("Gets the min-history of a ref, or sets it and returns the ref")

var Lit_2946 *jrt.String = jrt.Intern("ref-max-history")

var Lit_2947 *jrt.String = jrt.Intern("Gets the max-history of a ref, or sets it and returns the ref")

var Lit_2948 *jrt.String = jrt.Intern("ensure")

var Lit_2949 *jrt.String = jrt.Intern("Must be called in a transaction. Protects the ref from modification\n  by other transactions.  Returns the in-transaction-value of\n  ref. Allows for more concurrency than (ref-set ref @ref)")

var Lit_2950 *jrt.String = jrt.Intern("flags-ignored-for-now")

var Lit_2951 *jrt.String = jrt.Intern("transaction-flags => TBD, pass nil for now\n\n  Runs the exprs (in an implicit do) in a transaction that encompasses\n  exprs and any nested calls.  Starts a transaction if none is already\n  running on this thread. Any uncaught exception will abort the\n  transaction and flow out of sync. The exprs may be run more than\n  once, but any effects on Refs will be atomic.")

var Lit_2952 *jrt.String = jrt.Intern("io!")

var Lit_2953 *jrt.String = jrt.Intern("If an io! block occurs in a transaction, throws an\n  IllegalStateException, else runs body in an implicit do. If the\n  first expression in body is a literal string, will use that as the\n  exception message.")

var Lit_2954 *jrt.String = jrt.Intern("Creates and returns a Volatile with an initial value of val.")

var Lit_2955 *jrt.String = jrt.Intern("1.7")

var Lit_2956 *jrt.String = jrt.Intern("vol")

var Lit_2957 *jrt.String = jrt.Intern("Sets the value of volatile to newval without regard for the\n   current value. Returns newval.")

var Lit_2958 *jrt.String = jrt.Intern("vswap!")

var Lit_2959 *jrt.String = jrt.Intern("Non-atomically swaps the value of the volatile as if:\n   (apply f current-value-of-vol args). Returns the value that\n   was swapped in.")

var Lit_2960 *jrt.String = jrt.Intern("volatile?")

var Lit_2961 *jrt.String = jrt.Intern("Returns true if x is a volatile.")

var Lit_2962 *jrt.String = jrt.Intern("g")

var Lit_2963 *jrt.String = jrt.Intern("fs")

var Lit_2964 *jrt.String = jrt.Intern("Takes a set of functions and returns a fn that is the composition\n  of those fns.  The returned fn takes a variable number of args,\n  applies the rightmost of fns to the args, the next\n  fn (right-to-left) to the result, etc.")

var Lit_2965 *jrt.String = jrt.Intern("juxt")

var Lit_2966 *jrt.String = jrt.Intern("h")

var Lit_2967 *jrt.String = jrt.Intern("Takes a set of functions and returns a fn that is the juxtaposition\n  of those fns.  The returned fn takes a variable number of args, and\n  returns a vector containing the result of applying each fn to the\n  args (left-to-right).\n  ((juxt a b c) x) => [(a x) (b x) (c x)]")

var Lit_2968 *jrt.String = jrt.Intern("arg1")

var Lit_2969 *jrt.String = jrt.Intern("arg2")

var Lit_2970 *jrt.String = jrt.Intern("arg3")

var Lit_2971 *jrt.String = jrt.Intern("Takes a function f and fewer than the normal arguments to f, and\n  returns a fn that takes a variable number of additional args. When\n  called, the returned function calls f with args + additional args.")

var Lit_2972 *jrt.String = jrt.Intern("colls")

var Lit_2973 *jrt.String = jrt.Intern("Coerces coll to a (possibly empty) sequence, if it is not already\n  one. Will not force a lazy seq. (sequence nil) yields (), When a\n  transducer is supplied, returns a lazy sequence of applications of\n  the transform to the items in coll(s), i.e. to the set of first\n  items of each coll, followed by the set of second\n  items in each coll, until any one of the colls is exhausted.  Any\n  remaining items in other colls are ignored. The transform should accept\n  number-of-colls arguments")

var Lit_2974 *jrt.String = jrt.Intern("pred")

var Lit_2975 *jrt.String = jrt.Intern("Returns true if (pred x) is logical true for every x in coll, else\n  false.")

var Lit_2976 *jrt.String = jrt.Intern("not-every?")

var Lit_2977 *jrt.String = jrt.Intern("Returns false if (pred x) is logical true for every x in\n  coll, else true.")

var Lit_2978 *jrt.String = jrt.Intern("Returns the first logical true value of (pred x) for any x in coll,\n  else nil.  One common idiom is to use a set as pred, for example\n  this will return :fred if :fred is in the sequence, otherwise nil:\n  (some #{:fred} coll)")

var Lit_2979 *jrt.String = jrt.Intern("Returns false if (pred x) is logical true for any x in coll,\n  else true.")

var Lit_2980 *jrt.String = jrt.Intern("dotimes")

var Lit_2981 *jrt.String = jrt.Intern("bindings => name n\n\n  Repeatedly executes body (presumably for side-effects) with name\n  bound to integers from 0 through n-1.")

var Lit_2982 *jrt.String = jrt.Intern("c1")

var Lit_2983 *jrt.String = jrt.Intern("c2")

var Lit_2984 *jrt.String = jrt.Intern("c3")

var Lit_2985 *jrt.String = jrt.Intern("Returns a lazy sequence consisting of the result of applying f to\n  the set of first items of each coll, followed by applying f to the\n  set of second items in each coll, until any one of the colls is\n  exhausted.  Any remaining items in other colls are ignored. Function\n  f should accept number-of-colls arguments. Returns a transducer when\n  no collection is provided.")

var Lit_2986 *jrt.String = jrt.Intern("names")

var Lit_2987 *jrt.String = jrt.Intern("defs the supplied var names with no bindings, useful for making forward declarations.")

var Lit_2988 *jrt.String = jrt.Intern("Returns the result of applying concat to the result of applying map\n  to f and colls.  Thus function f should return a collection. Returns\n  a transducer when no collections are provided")

var Lit_2989 *jrt.String = jrt.Intern("Returns a lazy sequence of the items in coll for which\n  (pred item) returns logical true. pred must be free of side-effects.\n  Returns a transducer when no collection is provided.")

var Lit_2990 *jrt.String = jrt.Intern("Returns a lazy sequence of the items in coll for which\n  (pred item) returns logical false. pred must be free of side-effects.\n  Returns a transducer when no collection is provided.")

var Lit_2991 *jrt.String = jrt.Intern("Wraps x in a way such that a reduce will terminate with the value x")

var Lit_2992 *jrt.String = jrt.Intern("reduced?")

var Lit_2993 *jrt.String = jrt.Intern("If x is already reduced?, returns it, else returns (reduced x)")

var Lit_2994 *jrt.String = jrt.Intern("If x is reduced?, returns (deref x), else returns x")

var Lit_2995 *jrt.String = jrt.Intern("Returns a lazy sequence of the first n items in coll, or all items if\n  there are fewer than n.  Returns a stateful transducer when\n  no collection is provided.")

var Lit_2996 *jrt.String = jrt.Intern("Returns a lazy sequence of successive items from coll while\n  (pred item) returns logical true. pred must be free of side-effects.\n  Returns a transducer when no collection is provided.")

var Lit_2997 *jrt.String = jrt.Intern("Returns a laziness-preserving sequence of all but the first n items in coll.\n  Returns a stateful transducer when no collection is provided.")

var Lit_2998 *jrt.String = jrt.Intern("Return a lazy sequence of all but the last n (default 1) items in coll")

var Lit_2999 *jrt.String = jrt.Intern("take-last")

var Lit_3000 *jrt.String = jrt.Intern("Returns a seq of the last n items in coll.  Depending on the type\n  of coll may be no better than linear time.  For vectors, see also subvec.")

var Lit_3001 *jrt.String = jrt.Intern("Returns a lazy sequence of the items in coll starting from the\n  first item for which (pred item) returns logical false.  Returns a\n  stateful transducer when no collection is provided.")

var Lit_3002 *jrt.String = jrt.Intern("cycle")

var Lit_3003 *jrt.String = jrt.Intern("Returns a lazy (infinite!) sequence of repetitions of the items in coll.")

var Lit_3004 *jrt.String = jrt.Intern("Returns a vector of [(take n coll) (drop n coll)]")

var Lit_3005 *jrt.String = jrt.Intern("Returns a vector of [(take-while pred coll) (drop-while pred coll)]")

var Lit_3006 *jrt.String = jrt.Intern("Returns a lazy (infinite!, or length n if supplied) sequence of xs.")

var Lit_3007 *jrt.String = jrt.Intern("replicate")

var Lit_3008 *jrt.String = jrt.Intern("DEPRECATED: Use 'repeat' instead.\n   Returns a lazy seq of n xs.")

var Lit_3009 *jrt.String = jrt.Intern("Returns a lazy (infinite!) sequence of x, (f x), (f (f x)) etc.\n  f must be free of side-effects")

var Lit_3010 *jrt.String = jrt.Intern("start")

var Lit_3011 *jrt.String = jrt.Intern("step")

var Lit_3012 *jrt.String = jrt.Intern("Returns a lazy seq of nums from start (inclusive) to end\n  (exclusive), by step, where start defaults to 0, step to 1, and end to\n  infinity. When step is equal to 0, returns an infinite sequence of\n  start. When start is equal to end, returns empty list.")

var Lit_3013 *jrt.String = jrt.Intern("rdr")

var Lit_3014 *jrt.String = jrt.Intern("java.io.BufferedReader")

var Lit_3015 *jrt.String = jrt.Intern("Returns the lines of text from rdr as a lazy sequence of strings.\n  rdr must implement java.io.BufferedReader.")

var Lit_3016 *jrt.String = jrt.Intern("Returns an implementation of java.util.Comparator based upon pred.")

var Lit_3017 *jrt.String = jrt.Intern("java.util.Comparator")

var Lit_3018 *jrt.String = jrt.Intern("Returns a sorted sequence of the items in coll. If no comparator is\n  supplied, uses compare.  comparator must implement\n  java.util.Comparator.  Guaranteed to be stable: equal elements will\n  not be reordered.  If coll is a Java array, it will be modified.  To\n  avoid this, sort a copy of the array.")

var Lit_3019 *jrt.String = jrt.Intern("keyfn")

var Lit_3020 *jrt.String = jrt.Intern("Returns a sorted sequence of the items in coll, where the sort\n  order is determined by comparing (keyfn item).  If no comparator is\n  supplied, uses compare.  comparator must implement\n  java.util.Comparator.  Guaranteed to be stable: equal elements will\n  not be reordered.  If coll is a Java array, it will be modified.  To\n  avoid this, sort a copy of the array.")

var Lit_3021 *jrt.String = jrt.Intern("When lazy sequences are produced via functions that have side\n  effects, any effects other than those needed to produce the first\n  element in the seq do not occur until the seq is consumed. dorun can\n  be used to force any effects. Walks through the successive nexts of\n  the seq, does not retain the head and returns nil.")

var Lit_3022 *jrt.String = jrt.Intern("When lazy sequences are produced via functions that have side\n  effects, any effects other than those needed to produce the first\n  element in the seq do not occur until the seq is consumed. doall can\n  be used to force any effects. Walks through the successive nexts of\n  the seq, retains the head and returns it, thus causing the entire\n  seq to reside in memory at one time.")

var Lit_3023 *jrt.String = jrt.Intern("nthnext")

var Lit_3024 *jrt.String = jrt.Intern("Returns the nth next of coll, (seq coll) when n is 0.")

var Lit_3025 *jrt.String = jrt.Intern("Returns the nth rest of coll, coll when n is 0.")

var Lit_3026 *jrt.String = jrt.Intern("pad")

var Lit_3027 *jrt.String = jrt.Intern("Returns a lazy sequence of lists of n items each, at offsets step\n  apart. If step is not supplied, defaults to n, i.e. the partitions\n  do not overlap. If a pad collection is supplied, use its elements as\n  necessary to complete last partition upto n items. In case there are\n  not enough padding elements, return a partition with less than n items.")

var Lit_3028 *jrt.String = jrt.Intern("Evaluates the form data structure (not text!) and returns the result.")

var Lit_3029 *jrt.String = jrt.Intern("doseq")

var Lit_3030 *jrt.String = jrt.Intern("seq-exprs")

var Lit_3031 *jrt.String = jrt.Intern("Repeatedly executes body (presumably for side-effects) with\n  bindings and filtering as provided by \"for\".  Does not retain\n  the head of the sequence. Returns nil.")

var Lit_3032 *jrt.String = jrt.Intern("agents")

var Lit_3033 *jrt.String = jrt.Intern("Blocks the current thread (indefinitely!) until all actions\n  dispatched thus far, from this thread or agent, to the agent(s) have\n  occurred.  Will block on failed agents.  Will never return if\n  a failed agent is restarted with :clear-actions true or shutdown-agents was called.")

var Lit_3034 *jrt.String = jrt.Intern("await1")

var Lit_3035 *jrt.String = jrt.Intern("await-for")

var Lit_3036 *jrt.String = jrt.Intern("Blocks the current thread until all actions dispatched thus\n  far (from this thread or agent) to the agents have occurred, or the\n  timeout (in milliseconds) has elapsed. Returns logical false if\n  returning due to timeout, logical true otherwise.")

var Lit_3037 *jrt.String = jrt.Intern("arbace.lang.IEditableCollection")

var Lit_3038 *jrt.String = jrt.Intern("Returns a new, transient version of the collection, in constant time.\n\n  Transients support a parallel set of 'changing' operations, with similar names\n  followed by ! - assoc!, conj! etc. These do the same things as their persistent\n  counterparts except the return values are themselves transient.\n\n  Note in particular that transients are not designed to be bashed in-place. You\n  must capture and use the return value in the next call. In this way, they support\n  the same code structure as the functional persistent code they replace.")

var Lit_3039 *jrt.String = jrt.Intern("arbace.lang.ITransientCollection")

var Lit_3040 *jrt.String = jrt.Intern("Returns a new, persistent version of the transient collection, in\n  constant time. The transient collection cannot be used after this\n  call, any such use will throw an exception.")

var Lit_3041 *jrt.String = jrt.Intern("Adds x to the transient collection, and return coll. The 'addition'\n  may happen at different 'places' depending on the concrete type.")

var Lit_3042 *jrt.String = jrt.Intern("arbace.lang.ITransientAssociative")

var Lit_3043 *jrt.String = jrt.Intern("When applied to a transient map, adds mapping of key(s) to\n  val(s). When applied to a transient vector, sets the val at index.\n  Note - index must be <= (count vector). Returns coll.")

var Lit_3044 *jrt.String = jrt.Intern("dissoc!")

var Lit_3045 *jrt.String = jrt.Intern("arbace.lang.ITransientMap")

var Lit_3046 *jrt.String = jrt.Intern("Returns a transient map that doesn't contain a mapping for key(s).")

var Lit_3047 *jrt.String = jrt.Intern("pop!")

var Lit_3048 *jrt.String = jrt.Intern("arbace.lang.ITransientVector")

var Lit_3049 *jrt.String = jrt.Intern("Removes the last item from a transient vector. If\n  the collection is empty, throws an exception. Returns coll")

var Lit_3050 *jrt.String = jrt.Intern("disj!")

var Lit_3051 *jrt.String = jrt.Intern("arbace.lang.ITransientSet")

var Lit_3052 *jrt.String = jrt.Intern("disj[oin]. Returns a transient set of the same (hashed/sorted) type, that\n  does not contain key(s).")

var Lit_3053 *jrt.String = jrt.Intern("maps")

var Lit_3054 *jrt.String = jrt.Intern("Returns a map that consists of the rest of the maps conj-ed onto\n  the first.  If a key occurs in more than one map, the mapping(s)\n  from the latter (left-to-right) will be combined with the mapping in\n  the result by calling (f val-in-result val-in-latter).")

var Lit_3055 *jrt.String = jrt.Intern("to")

var Lit_3056 *jrt.String = jrt.Intern("from")

var Lit_3057 *jrt.String = jrt.Intern("Returns a new coll consisting of to-coll with all of the items of\n  from-coll conjoined.")

var Lit_3058 *jrt.String = jrt.Intern("Returns a map that consists of the rest of the maps conj-ed onto\n  the first.  If a key occurs in more than one map, the mapping from\n  the latter (left-to-right) will be the mapping in the result.")

var Lit_3059 *jrt.String = jrt.Intern("import-symbols-or-lists")

var Lit_3060 *jrt.String = jrt.Intern("import-list => (package-symbol class-name-symbols*)\n\n  For each name in class-name-symbols, adds a mapping from name to the\n  class named by package.name to the current namespace. Use :import in the ns\n  macro in preference to calling this directly.")

var Lit_3061 *jrt.String = jrt.Intern("aseq")

var Lit_3062 *jrt.String = jrt.Intern("Returns an array with components set to the values in aseq. The array's\n  component type is type if provided, or the type of the first value in\n  aseq if present, or Object. All values in aseq must be compatible with\n  the component type. Class objects for the primitive types can be obtained\n  using, e.g., Integer/TYPE.")

var Lit_3063 *jrt.String = jrt.Intern("Returns the Class of x")

var Lit_3064 *jrt.String = jrt.Intern("Returns the :type metadata of x, or its Class if none")

var Lit_3065 *jrt.String = jrt.Intern("Number")

var Lit_3066 *jrt.String = jrt.Intern("unchecked-byte")

var Lit_3067 *jrt.String = jrt.Intern("unchecked-short")

var Lit_3068 *jrt.String = jrt.Intern("unchecked-char")

var Lit_3069 *jrt.String = jrt.Intern("unchecked-int")

var Lit_3070 *jrt.String = jrt.Intern("unchecked-long")

var Lit_3071 *jrt.String = jrt.Intern("unchecked-float")

var Lit_3072 *jrt.String = jrt.Intern("unchecked-double")

var Lit_3073 *jrt.String = jrt.Intern("Returns true if x is a Number")

var Lit_3074 *jrt.String = jrt.Intern("mod")

var Lit_3075 *jrt.String = jrt.Intern("Modulus of num and div. Truncates toward negative infinity.")

var Lit_3076 *jrt.String = jrt.Intern("Returns true if n is a Ratio")

var Lit_3077 *jrt.String = jrt.Intern("numerator")

var Lit_3078 *jrt.String = jrt.Intern("Returns the numerator part of a Ratio.")

var Lit_3079 *jrt.String = jrt.Intern("denominator")

var Lit_3080 *jrt.String = jrt.Intern("Returns the denominator part of a Ratio.")

var Lit_3081 *jrt.String = jrt.Intern("Returns true if n is a BigDecimal")

var Lit_3082 *jrt.String = jrt.Intern("Returns true if n is a floating point number")

var Lit_3083 *jrt.String = jrt.Intern("rational?")

var Lit_3084 *jrt.String = jrt.Intern("Returns true if n is a rational number")

var Lit_3085 *jrt.String = jrt.Intern("Coerce to BigInt")

var Lit_3086 *jrt.String = jrt.Intern("arbace.lang.BigInt")

var Lit_3087 *jrt.String = jrt.Intern("biginteger")

var Lit_3088 *jrt.String = jrt.Intern("Coerce to BigInteger")

var Lit_3089 *jrt.String = jrt.Intern("bigdec")

var Lit_3090 *jrt.String = jrt.Intern("Coerce to BigDecimal")

var Lit_3091 *jrt.String = jrt.Intern("print-initialized")

var Lit_3092 *jrt.String = jrt.Intern("w")

var Lit_3093 *jrt.String = jrt.Intern("Prints the object(s) to the output stream that is the current value\n  of *out*.  Prints the object(s), separated by spaces if there is\n  more than one.  By default, pr and prn print in a way that objects\n  can be read by the reader")

var Lit_3094 *jrt.String = jrt.Intern("Writes a platform-specific newline to *out*")

var Lit_3095 *jrt.String = jrt.Intern("Flushes the output stream that is the current value of\n  *out*")

var Lit_3096 *jrt.String = jrt.Intern("Same as pr followed by (newline). Observes *flush-on-newline*")

var Lit_3097 *jrt.String = jrt.Intern("Prints the object(s) to the output stream that is the current value\n  of *out*.  print and println produce output for human consumption.")

var Lit_3098 *jrt.String = jrt.Intern("Same as print followed by (newline)")

var Lit_3099 *jrt.String = jrt.Intern("stream")

var Lit_3100 *jrt.String = jrt.Intern("eof-error?")

var Lit_3101 *jrt.String = jrt.Intern("eof-value")

var Lit_3102 *jrt.String = jrt.Intern("recursive?")

var Lit_3103 *jrt.String = jrt.Intern("opts")

var Lit_3104 *jrt.String = jrt.Intern("Reads the next object from stream, which must be an instance of\n  java.io.PushbackReader or some derivee.  stream defaults to the\n  current value of *in*.\n\n  Opts is a persistent map with valid keys:\n    :read-cond - :allow to process reader conditionals, or\n                 :preserve to keep all branches\n    :features - persistent set of feature keywords for reader conditionals\n    :eof - on eof, return value unless :eofthrow, then throw.\n           if not specified, will throw\n\n  Note that read can execute code (controlled by *read-eval*),\n  and as such should be used only with trusted sources.\n\n  For data structure interop use arbace.edn/read")

var Lit_3105 *jrt.String = jrt.Intern("arbace.lang.LineNumberingPushbackReader")

var Lit_3106 *jrt.String = jrt.Intern("Like read, and taking the same args. stream must be a LineNumberingPushbackReader.\n  Returns a vector containing the object read and the (whitespace-trimmed) string read.")

var Lit_3107 *jrt.String = jrt.Intern("1.10")

var Lit_3108 *jrt.String = jrt.Intern("read-line")

var Lit_3109 *jrt.String = jrt.Intern("Reads the next line from stream that is the current value of *in* .")

var Lit_3110 *jrt.String = jrt.Intern("Reads one object from the string s. Optionally include reader\n  options, as specified in read.\n\n  Note that read-string can execute code (controlled by *read-eval*),\n  and as such should be used only with trusted sources.\n\n  For data structure interop use arbace.edn/read-string")

var Lit_3111 *jrt.String = jrt.Intern("v")

var Lit_3112 *jrt.String = jrt.Intern("Returns a persistent vector of the items in vector from\n  start (inclusive) to end (exclusive).  If end is not supplied,\n  defaults to (count vector). This operation is O(1) and very fast, as\n  the resulting vector shares structure with the original and no\n  trimming is done.")

var Lit_3113 *jrt.String = jrt.Intern("bindings => [name init ...]\n\n  Evaluates body in a try expression with names bound to the values\n  of the inits, and a finally clause that calls (.close name) on each\n  name in reverse order.")

var Lit_3114 *jrt.String = jrt.Intern("doto")

var Lit_3115 *jrt.String = jrt.Intern("Evaluates x then calls all of the methods and functions with the\n  value of x supplied at the front of the given arguments.  The forms\n  are evaluated in order.  Returns x.\n\n  (doto (new java.util.HashMap) (.put \"a\" 1) (.put \"b\" 2))")

var Lit_3116 *jrt.String = jrt.Intern("memfn")

var Lit_3117 *jrt.String = jrt.Intern("Expands into code that creates a fn that expects to be passed an\n  object and any args and calls the named instance method on the\n  object passing the args. Use when you want to treat a Java method as\n  a first-class fn. name may be type-hinted with the method receiver's\n  type in order to avoid reflective calls.")

var Lit_3118 *jrt.String = jrt.Intern("time")

var Lit_3119 *jrt.String = jrt.Intern("expr")

var Lit_3120 *jrt.String = jrt.Intern("Evaluates expr and prints the time it took.  Returns the value of\n expr.")

var Lit_3121 *jrt.String = jrt.Intern("idxs")

var Lit_3122 *jrt.String = jrt.Intern("def-aset")

var Lit_3123 *jrt.String = jrt.Intern("method")

var Lit_3124 *jrt.String = jrt.Intern("coerce")

var Lit_3125 *jrt.String = jrt.Intern("Sets the value at the index/indices. Works on arrays of int. Returns val.")

var Lit_3126 *jrt.String = jrt.Intern("Sets the value at the index/indices. Works on arrays of long. Returns val.")

var Lit_3127 *jrt.String = jrt.Intern("Sets the value at the index/indices. Works on arrays of boolean. Returns val.")

var Lit_3128 *jrt.String = jrt.Intern("Sets the value at the index/indices. Works on arrays of float. Returns val.")

var Lit_3129 *jrt.String = jrt.Intern("Sets the value at the index/indices. Works on arrays of double. Returns val.")

var Lit_3130 *jrt.String = jrt.Intern("Sets the value at the index/indices. Works on arrays of short. Returns val.")

var Lit_3131 *jrt.String = jrt.Intern("Sets the value at the index/indices. Works on arrays of byte. Returns val.")

var Lit_3132 *jrt.String = jrt.Intern("Sets the value at the index/indices. Works on arrays of char. Returns val.")

var Lit_3133 *jrt.String = jrt.Intern("len")

var Lit_3134 *jrt.String = jrt.Intern("dim")

var Lit_3135 *jrt.String = jrt.Intern("more-dims")

var Lit_3136 *jrt.String = jrt.Intern("Creates and returns an array of instances of the specified class of\n  the specified dimension(s).  Note that a class object is required.\n  Class objects can be obtained by using their imported or\n  fully-qualified name.  Class objects for the primitive types can be\n  obtained using, e.g., Integer/TYPE.")

var Lit_3137 *jrt.String = jrt.Intern("to-array-2d")

var Lit_3138 *jrt.String = jrt.Intern("java.util.Collection")

var Lit_3139 *jrt.String = jrt.Intern("Returns a (potentially-ragged) 2-dimensional array of Objects\n  containing the contents of coll, which can be any Collection of any\n  Collection.")

var Lit_3140 *jrt.String = jrt.Intern("[[Ljava.lang.Object;")

var Lit_3141 *jrt.String = jrt.Intern("If form represents a macro form, returns its expansion,\n  else returns form.")

var Lit_3142 *jrt.String = jrt.Intern("Repeatedly calls macroexpand-1 on form until it no longer\n  represents a macro form, then returns it.  Note neither\n  macroexpand-1 nor macroexpand expand macros in subforms.")

var Lit_3143 *jrt.String = jrt.Intern("Returns a structure basis object.")

var Lit_3144 *jrt.String = jrt.Intern("defstruct")

var Lit_3145 *jrt.String = jrt.Intern("Same as (def name (create-struct keys...))")

var Lit_3146 *jrt.String = jrt.Intern("struct-map")

var Lit_3147 *jrt.String = jrt.Intern("inits")

var Lit_3148 *jrt.String = jrt.Intern("Returns a new structmap instance with the keys of the\n  structure-basis. keyvals may contain all, some or none of the basis\n  keys - where values are not supplied they will default to nil.\n  keyvals can also contain keys not in the basis.")

var Lit_3149 *jrt.String = jrt.Intern("Returns a new structmap instance with the keys of the\n  structure-basis. vals must be supplied for basis keys in order -\n  where values are not supplied they will default to nil.")

var Lit_3150 *jrt.String = jrt.Intern("accessor")

var Lit_3151 *jrt.String = jrt.Intern("Returns a fn that, given an instance of a structmap with the basis,\n  returns the value at the key.  The key must be in the basis. The\n  returned function should be (slightly) more efficient than using\n  get, but such use of accessors should be limited to known\n  performance-critical areas.")

var Lit_3152 *jrt.String = jrt.Intern("Sequentially read and evaluate the set of forms contained in the\n  stream/file")

var Lit_3153 *jrt.String = jrt.Intern("load-string")

var Lit_3154 *jrt.String = jrt.Intern("Sequentially read and evaluate the set of forms contained in the\n  string")

var Lit_3155 *jrt.String = jrt.Intern("Returns true if x implements IPersistentSet")

var Lit_3156 *jrt.String = jrt.Intern("Returns a set of the distinct elements of coll.")

var Lit_3157 *jrt.String = jrt.Intern("amap")

var Lit_3158 *jrt.String = jrt.Intern("Returns the namespace named by the symbol or nil if it doesn't exist.")

var Lit_3159 *jrt.String = jrt.Intern("Create a new namespace named by the symbol if one doesn't already\n  exist, returns it or the already-existing namespace of the same\n  name.")

var Lit_3160 *jrt.String = jrt.Intern("Removes the namespace named by the symbol. Use with caution.\n  Cannot be used to remove the clojure namespace.")

var Lit_3161 *jrt.String = jrt.Intern("all-ns")

var Lit_3162 *jrt.String = jrt.Intern("Returns a sequence of all namespaces.")

var Lit_3163 *jrt.String = jrt.Intern("If passed a namespace, returns it. Else, when passed a symbol,\n  returns the namespace named by it, throwing an exception if not\n  found.")

var Lit_3164 *jrt.String = jrt.Intern("Returns the name of the namespace, a symbol.")

var Lit_3165 *jrt.String = jrt.Intern("Returns a map of all the mappings for the namespace.")

var Lit_3166 *jrt.String = jrt.Intern("ns-unmap")

var Lit_3167 *jrt.String = jrt.Intern("Removes the mappings for the symbol from the namespace.")

var Lit_3168 *jrt.String = jrt.Intern("Returns a map of the public intern mappings for the namespace.")

var Lit_3169 *jrt.String = jrt.Intern("ns-imports")

var Lit_3170 *jrt.String = jrt.Intern("Returns a map of the import mappings for the namespace.")

var Lit_3171 *jrt.String = jrt.Intern("Returns a map of the intern mappings for the namespace.")

var Lit_3172 *jrt.String = jrt.Intern("ns-sym")

var Lit_3173 *jrt.String = jrt.Intern("filters")

var Lit_3174 *jrt.String = jrt.Intern("refers to all public vars of ns, subject to filters.\n  filters can include at most one each of:\n\n  :exclude list-of-symbols\n  :only list-of-symbols\n  :rename map-of-fromsymbol-tosymbol\n\n  For each public interned var in the namespace named by the symbol,\n  adds a mapping from the name of the var to the var to the current\n  namespace.  Throws an exception if name is already mapped to\n  something else in the current namespace. Filters can be used to\n  select a subset, via inclusion or exclusion, or to provide a mapping\n  to a symbol different from the var's name, in order to prevent\n  clashes. Use :use in the ns macro in preference to calling this directly.")

var Lit_3175 *jrt.String = jrt.Intern("ns-refers")

var Lit_3176 *jrt.String = jrt.Intern("Returns a map of the refer mappings for the namespace.")

var Lit_3177 *jrt.String = jrt.Intern("namespace-sym")

var Lit_3178 *jrt.String = jrt.Intern("Add an alias in the current namespace to another\n  namespace. Arguments are two symbols: the alias to be used, and\n  the symbolic name of the target namespace. Use :as in the ns macro in preference\n  to calling this directly.")

var Lit_3179 *jrt.String = jrt.Intern("ns-aliases")

var Lit_3180 *jrt.String = jrt.Intern("Returns a map of the aliases for the namespace.")

var Lit_3181 *jrt.String = jrt.Intern("ns-unalias")

var Lit_3182 *jrt.String = jrt.Intern("Removes the alias for the symbol from the namespace.")

var Lit_3183 *jrt.String = jrt.Intern("Returns a lazy seq of every nth item in coll.  Returns a stateful\n  transducer when no collection is provided.")

var Lit_3184 *jrt.String = jrt.Intern("Returns a lazy seq of the first item in each coll, then the second etc.")

var Lit_3185 *jrt.String = jrt.Intern("var-get")

var Lit_3186 *jrt.String = jrt.Intern("Gets the value in the var object")

var Lit_3187 *jrt.String = jrt.Intern("var-set")

var Lit_3188 *jrt.String = jrt.Intern("Sets the value in the var object to val. The var must be\n thread-locally bound.")

var Lit_3189 *jrt.String = jrt.Intern("with-local-vars")

var Lit_3190 *jrt.String = jrt.Intern("name-vals-vec")

var Lit_3191 *jrt.String = jrt.Intern("varbinding=> symbol init-expr\n\n  Executes the exprs in a context in which the symbols are bound to\n  vars with per-thread bindings to the init-exprs.  The symbols refer\n  to the var objects themselves, and must be accessed with var-get and\n  var-set")

var Lit_3192 *jrt.String = jrt.Intern("env")

var Lit_3193 *jrt.String = jrt.Intern("Returns the var or Class to which a symbol will be resolved in the\n  namespace (unless found in the environment), else nil.  Note that\n  if the symbol is fully qualified, the var/Class to which it resolves\n  need not be present in the namespace.")

var Lit_3194 *jrt.String = jrt.Intern("same as (ns-resolve *ns* symbol) or (ns-resolve *ns* &env symbol)")

var Lit_3195 *jrt.String = jrt.Intern("array-map")

var Lit_3196 *jrt.String = jrt.Intern("Constructs an array-map. If any keys are equal, they are handled as\n  if by repeated uses of assoc.")

var Lit_3197 *jrt.String = jrt.Intern("Returns a map with the keys mapped to the corresponding vals.")

var Lit_3198 *jrt.String = jrt.Intern("Takes a function of no args, presumably with side effects, and\n  returns an infinite (or length n if supplied) lazy sequence of calls\n  to it")

var Lit_3199 *jrt.String = jrt.Intern("Returns true if coll implements count in constant time")

var Lit_3200 *jrt.String = jrt.Intern("Returns true if coll has no items. To check the emptiness of a seq,\n  please use the idiom (seq x) rather than (not (empty? x))")

var Lit_3201 *jrt.String = jrt.Intern("Returns a map with only the non-nil values of map m. Returns nil if\n  m has no non-nil vals.")

var Lit_3202 *jrt.String = jrt.Intern("1.13")

var Lit_3203 *jrt.String = jrt.Intern("seq-to-map-for-destructuring")

var Lit_3204 *jrt.String = jrt.Intern("Builds a map from a seq as described in\n  https://clojure.org/reference/special_forms#keyword-arguments")

var Lit_3205 *jrt.String = jrt.Intern("1.11")

var Lit_3206 *jrt.String = jrt.Intern("pb")

var Lit_3207 *jrt.String = jrt.Intern("bvec")

var Lit_3208 *jrt.String = jrt.Intern("binding => binding-form init-expr\n  binding-form => name, or destructuring-form\n  destructuring-form => map-destructure-form, or seq-destructure-form\n\n  Evaluates the exprs in a lexical context in which the symbols in\n  the binding-forms are bound to their respective init-exprs or parts\n  therein.\n\n  See https://clojure.org/reference/special_forms#binding-forms for\n  more information about destructuring.")

var Lit_3209 *jrt.String = jrt.Intern("special-form")

var Lit_3210 *jrt.String = jrt.Intern("bindings*")

var Lit_3211 *jrt.String = jrt.Intern("exprs*")

var Lit_3212 *jrt.String = jrt.Intern("params")

var Lit_3213 *jrt.String = jrt.Intern("params => positional-params*, or positional-params* & rest-param\n  positional-param => binding-form\n  rest-param => binding-form\n  binding-form => name, or destructuring-form\n\n  Defines a function.\n\n  See https://clojure.org/reference/special_forms#fn for more information")

var Lit_3214 *jrt.String = jrt.Intern("name?")

var Lit_3215 *jrt.String = jrt.Intern("Evaluates the exprs in a lexical context in which the symbols in\n  the binding-forms are bound to their respective init-exprs or parts\n  therein. Acts as a recur target.")

var Lit_3216 *jrt.String = jrt.Intern("bindings => x xs\n\n  Roughly the same as (when (seq xs) (let [x (first xs)] body)) but xs is evaluated only once")

var Lit_3217 *jrt.String = jrt.Intern("lazy-cat")

var Lit_3218 *jrt.String = jrt.Intern("Expands to code which yields a lazy sequence of the concatenation\n  of the supplied colls.  Each coll expr is not evaluated until it is\n  needed.\n\n  (lazy-cat xs ys zs) === (concat (lazy-seq xs) (lazy-seq ys) (lazy-seq zs))")

var Lit_3219 *jrt.String = jrt.Intern("for")

var Lit_3220 *jrt.String = jrt.Intern("body-expr")

var Lit_3221 *jrt.String = jrt.Intern("List comprehension. Takes a vector of one or more\n   binding-form/collection-expr pairs, each followed by zero or more\n   modifiers, and yields a lazy sequence of evaluations of expr.\n   Collections are iterated in a nested fashion, rightmost fastest,\n   and nested coll-exprs can refer to bindings created in prior\n   binding-forms.  Supported modifiers are: :let [binding-form expr ...],\n   :while test, :when test.\n\n  (take 100 (for [x (range 100000000) y (range 1000000) :while (< y x)] [x y]))")

var Lit_3222 *jrt.String = jrt.Intern("comment")

var Lit_3223 *jrt.String = jrt.Intern("Ignores body, yields nil")

var Lit_3224 *jrt.String = jrt.Intern("with-out-str")

var Lit_3225 *jrt.String = jrt.Intern("Evaluates exprs in a context in which *out* is bound to a fresh\n  StringWriter.  Returns the string created by any nested printing\n  calls.")

var Lit_3226 *jrt.String = jrt.Intern("with-in-str")

var Lit_3227 *jrt.String = jrt.Intern("Evaluates body in a context in which *in* is bound to a fresh\n  StringReader initialized with the string s.")

var Lit_3228 *jrt.String = jrt.Intern("pr to a string, returning it")

var Lit_3229 *jrt.String = jrt.Intern("prn-str")

var Lit_3230 *jrt.String = jrt.Intern("prn to a string, returning it")

var Lit_3231 *jrt.String = jrt.Intern("print to a string, returning it")

var Lit_3232 *jrt.String = jrt.Intern("println-str")

var Lit_3233 *jrt.String = jrt.Intern("println to a string, returning it")

var Lit_3234 *jrt.String = jrt.Intern("ex")

var Lit_3235 *jrt.String = jrt.Intern("Throwable")

var Lit_3236 *jrt.String = jrt.Intern("class-name")

var Lit_3237 *jrt.String = jrt.Intern("msg")

var Lit_3238 *jrt.String = jrt.Intern("Create an instance of ExceptionInfo, a RuntimeException subclass\n   that carries a map of additional data.")

var Lit_3239 *jrt.String = jrt.Intern("1.4")

var Lit_3240 *jrt.String = jrt.Intern("Returns exception data (a map) if ex is an IExceptionInfo.\n   Otherwise returns nil.")

var Lit_3241 *jrt.String = jrt.Intern("ex-message")

var Lit_3242 *jrt.String = jrt.Intern("Returns the message attached to ex if ex is a Throwable.\n  Otherwise returns nil.")

var Lit_3243 *jrt.String = jrt.Intern("ex-cause")

var Lit_3244 *jrt.String = jrt.Intern("Returns the cause of ex if ex is a Throwable.\n  Otherwise returns nil.")

var Lit_3245 *jrt.String = jrt.Intern("java.lang.Throwable")

var Lit_3246 *jrt.String = jrt.Intern("Evaluates expression x and throws an AssertionError with optional\n  message if x does not evaluate to logical true.\n\n  Assertion checks are omitted from compiled code if '*assert*' is\n  false.")

var Lit_3247 *jrt.String = jrt.Intern("test [v] finds fn at key :test in var metadata and calls it,\n  presuming failure will throw exception")

var Lit_3248 *jrt.String = jrt.Intern("re-pattern")

var Lit_3249 *jrt.String = jrt.Intern("Returns an instance of java.util.regex.Pattern, for use, e.g. in\n  re-matcher.")

var Lit_3250 *jrt.String = jrt.Intern("java.util.regex.Pattern")

var Lit_3251 *jrt.String = jrt.Intern("re")

var Lit_3252 *jrt.String = jrt.Intern("Returns an instance of java.util.regex.Matcher, for use, e.g. in\n  re-find.")

var Lit_3253 *jrt.String = jrt.Intern("java.util.regex.Matcher")

var Lit_3254 *jrt.String = jrt.Intern("Returns the groups from the most recent match/find. If there are no\n  nested groups, returns a string of the entire match. If there are\n  nested groups, returns a vector of the groups, the first element\n  being the entire match.")

var Lit_3255 *jrt.String = jrt.Intern("re-seq")

var Lit_3256 *jrt.String = jrt.Intern("Returns a lazy sequence of successive matches of pattern in string,\n  using java.util.regex.Matcher.find(), each such match processed with\n  re-groups.")

var Lit_3257 *jrt.String = jrt.Intern("re-matches")

var Lit_3258 *jrt.String = jrt.Intern("Returns the match, if any, of string to pattern, using\n  java.util.regex.Matcher.matches().  Uses re-groups to return the\n  groups.")

var Lit_3259 *jrt.String = jrt.Intern("Returns the next regex match, if any, of string to pattern, using\n  java.util.regex.Matcher.find().  Uses re-groups to return the\n  groups.")

var Lit_3260 *jrt.String = jrt.Intern("Returns a random floating point number between 0 (inclusive) and\n  n (default 1) (exclusive).")

var Lit_3261 *jrt.String = jrt.Intern("Returns a random integer between 0 (inclusive) and n (exclusive).")

var Lit_3262 *jrt.String = jrt.Intern("defn-")

var Lit_3263 *jrt.String = jrt.Intern("decls")

var Lit_3264 *jrt.String = jrt.Intern("same as defn, yielding non-public def")

var Lit_3265 *jrt.String = jrt.Intern("branch?")

var Lit_3266 *jrt.String = jrt.Intern("children")

var Lit_3267 *jrt.String = jrt.Intern("Returns a lazy sequence of the nodes in a tree, via a depth-first walk.\n   branch? must be a fn of one arg that returns true if passed a node\n   that can have children (but may not).  children must be a fn of one\n   arg that returns a sequence of the children. Will only be called on\n   nodes for which branch? returns true. Root is the root node of the\n  tree.")

var Lit_3268 *jrt.String = jrt.Intern("file-seq")

var Lit_3269 *jrt.String = jrt.Intern("dir")

var Lit_3270 *jrt.String = jrt.Intern("A tree seq on java.io.Files")

var Lit_3271 *jrt.String = jrt.Intern("xml-seq")

var Lit_3272 *jrt.String = jrt.Intern("A tree seq on the xml elements as per xml/parse")

var Lit_3273 *jrt.String = jrt.Intern("special-symbol?")

var Lit_3274 *jrt.String = jrt.Intern("Returns true if s names a special form")

var Lit_3275 *jrt.String = jrt.Intern("Returns true if v is of type arbace.lang.Var")

var Lit_3276 *jrt.String = jrt.Intern("String")

var Lit_3277 *jrt.String = jrt.Intern("Returns the substring of s beginning at start inclusive, and ending\n  at end (defaults to length of string), exclusive.")

var Lit_3278 *jrt.String = jrt.Intern("max-key")

var Lit_3279 *jrt.String = jrt.Intern("Returns the x for which (k x), a number, is greatest.\n\n  If there are multiple such xs, the last one is returned.")

var Lit_3280 *jrt.String = jrt.Intern("min-key")

var Lit_3281 *jrt.String = jrt.Intern("Returns the x for which (k x), a number, is least.\n\n  If there are multiple such xs, the last one is returned.")

var Lit_3282 *jrt.String = jrt.Intern("distinct")

var Lit_3283 *jrt.String = jrt.Intern("Returns a lazy sequence of the elements of coll with duplicates removed.\n  Returns a stateful transducer when no collection is provided.")

var Lit_3284 *jrt.String = jrt.Intern("smap")

var Lit_3285 *jrt.String = jrt.Intern("Given a map of replacement pairs and a vector/collection, returns a\n  vector/seq with any elements = a key in smap replaced with the\n  corresponding val in smap.  Returns a transducer when no collection\n  is provided.")

var Lit_3286 *jrt.String = jrt.Intern("exprs")

var Lit_3287 *jrt.String = jrt.Intern("Runs the exprs (in an implicit do) in a transaction that encompasses\n  exprs and any nested calls.  Starts a transaction if none is already\n  running on this thread. Any uncaught exception will abort the\n  transaction and flow out of dosync. The exprs may be run more than\n  once, but any effects on Refs will be atomic.")

var Lit_3288 *jrt.String = jrt.Intern("with-precision")

var Lit_3289 *jrt.String = jrt.Intern("precision")

var Lit_3290 *jrt.String = jrt.Intern("Sets the precision and rounding mode to be used for BigDecimal operations.\n\n  Usage: (with-precision 10 (/ 1M 3))\n  or:    (with-precision 10 :rounding HALF_DOWN (/ 1M 3))\n\n  The rounding mode is one of CEILING, FLOOR, HALF_UP, HALF_DOWN,\n  HALF_EVEN, UP, DOWN and UNNECESSARY; it defaults to HALF_UP.")

var Lit_3291 *jrt.String = jrt.Intern("sc")

var Lit_3292 *jrt.String = jrt.Intern("arbace.lang.Sorted")

var Lit_3293 *jrt.String = jrt.Intern("subseq")

var Lit_3294 *jrt.String = jrt.Intern("start-test")

var Lit_3295 *jrt.String = jrt.Intern("start-key")

var Lit_3296 *jrt.String = jrt.Intern("end-test")

var Lit_3297 *jrt.String = jrt.Intern("end-key")

var Lit_3298 *jrt.String = jrt.Intern("sc must be a sorted collection, test(s) one of <, <=, > or\n  >=. Returns a seq of those entries with keys ek for\n  which (test (.. sc comparator (compare ek key)) 0) is true")

var Lit_3299 *jrt.String = jrt.Intern("rsubseq")

var Lit_3300 *jrt.String = jrt.Intern("sc must be a sorted collection, test(s) one of <, <=, > or\n  >=. Returns a reverse seq of those entries with keys ek for\n  which (test (.. sc comparator (compare ek key)) 0) is true")

var Lit_3301 *jrt.String = jrt.Intern("add-classpath")

var Lit_3302 *jrt.String = jrt.Intern("DEPRECATED\n\n  Adds the url (String or URL object) to the classpath per\n  URLClassLoader.addURL")

var Lit_3303 *jrt.String = jrt.Intern("Returns the hash code of its argument. Note this is the hash code\n  consistent with =, and thus is different than .hashCode for Integer,\n  Short, Byte and Clojure collections.")

var Lit_3304 *jrt.String = jrt.Intern("mix-collection-hash")

var Lit_3305 *jrt.String = jrt.Intern("hash-basis")

var Lit_3306 *jrt.String = jrt.Intern("Mix final collection hash for ordered or unordered collections.\n   hash-basis is the combined collection hash, count is the number\n   of elements included in the basis. Note this is the hash code\n   consistent with =, different from .hashCode.\n   See http://clojure.org/data_structures#hash for full algorithms.")

var Lit_3307 *jrt.String = jrt.Intern("hash-ordered-coll")

var Lit_3308 *jrt.String = jrt.Intern("Returns the hash code, consistent with =, for an external ordered\n   collection implementing Iterable.\n   See http://clojure.org/data_structures#hash for full algorithms.")

var Lit_3309 *jrt.String = jrt.Intern("hash-unordered-coll")

var Lit_3310 *jrt.String = jrt.Intern("Returns the hash code, consistent with =, for an external unordered\n   collection implementing Iterable. For maps, the iterator should\n   return map entries whose hash is computed as\n     (hash-ordered-coll [k v]).\n   See http://clojure.org/data_structures#hash for full algorithms.")

var Lit_3311 *jrt.String = jrt.Intern("sep")

var Lit_3312 *jrt.String = jrt.Intern("Returns a lazy seq of the elements of coll separated by sep.\n  Returns a stateful transducer when no collection is provided.")

var Lit_3313 *jrt.String = jrt.Intern("definline")

var Lit_3314 *jrt.String = jrt.Intern("decl")

var Lit_3315 *jrt.String = jrt.Intern("Experimental - like defmacro, except defines a named function whose\n  body is the expansion, calls to which may be expanded inline as if\n  it were a macro. Cannot be used with variadic (&) args.")

var Lit_3316 *jrt.String = jrt.Intern("Returns an empty collection of the same category as coll, or nil")

var Lit_3317 *jrt.String = jrt.Intern("Maps an expression across an array a, using an index named idx, and\n  return value named ret, initialized to a clone of a, then setting\n  each element of ret to the evaluation of expr, returning the new\n  array ret.")

var Lit_3318 *jrt.String = jrt.Intern("areduce")

var Lit_3319 *jrt.String = jrt.Intern("init")

var Lit_3320 *jrt.String = jrt.Intern("Reduces an expression across an array a, using an index named idx,\n  and return value named ret, initialized to init, setting ret to the\n  evaluation of expr at each step, returning ret.")

var Lit_3321 *jrt.String = jrt.Intern("float-array")

var Lit_3322 *jrt.String = jrt.Intern("size-or-seq")

var Lit_3323 *jrt.String = jrt.Intern("init-val-or-seq")

var Lit_3324 *jrt.String = jrt.Intern("boolean-array")

var Lit_3325 *jrt.String = jrt.Intern("byte-array")

var Lit_3326 *jrt.String = jrt.Intern("char-array")

var Lit_3327 *jrt.String = jrt.Intern("short-array")

var Lit_3328 *jrt.String = jrt.Intern("double-array")

var Lit_3329 *jrt.String = jrt.Intern("object-array")

var Lit_3330 *jrt.String = jrt.Intern("int-array")

var Lit_3331 *jrt.String = jrt.Intern("long-array")

var Lit_3332 *jrt.String = jrt.Intern("Casts to boolean[]")

var Lit_3333 *jrt.String = jrt.Intern("Casts to byte[]")

var Lit_3334 *jrt.String = jrt.Intern("Casts to char[]")

var Lit_3335 *jrt.String = jrt.Intern("Casts to short[]")

var Lit_3336 *jrt.String = jrt.Intern("Casts to float[]")

var Lit_3337 *jrt.String = jrt.Intern("Casts to int[]")

var Lit_3338 *jrt.String = jrt.Intern("Casts to double[]")

var Lit_3339 *jrt.String = jrt.Intern("Casts to long[]")

var Lit_3340 *jrt.String = jrt.Intern("bytes?")

var Lit_3341 *jrt.String = jrt.Intern("Return true if x is a byte array")

var Lit_3342 *jrt.String = jrt.Intern("n-or-q")

var Lit_3343 *jrt.String = jrt.Intern("Creates a queued seq on another (presumably lazy) seq s. The queued\n  seq will produce a concrete seq in the background, and can get up to\n  n items ahead of the consumer. n-or-q can be an integer n buffer\n  size, or an instance of java.util.concurrent BlockingQueue. Note\n  that reading from a seque can block if the reader gets ahead of the\n  producer.")

var Lit_3344 *jrt.String = jrt.Intern("Returns true if x is an instance of Class")

var Lit_3345 *jrt.String = jrt.Intern("Atomically alters the root binding of var v by applying f to its\n  current value plus any args")

var Lit_3346 *jrt.String = jrt.Intern("vars")

var Lit_3347 *jrt.String = jrt.Intern("Returns true if all of the vars provided as arguments have any bound value, root or thread-local.\n   Implies that deref'ing the provided vars will succeed. Returns true if no vars are provided.")

var Lit_3348 *jrt.String = jrt.Intern("thread-bound?")

var Lit_3349 *jrt.String = jrt.Intern("Returns true if all of the vars provided as arguments have thread-local bindings.\n   Implies that set!'ing the provided vars will succeed.  Returns true if no vars are provided.")

var Lit_3350 *jrt.String = jrt.Intern("Creates a hierarchy object for use with derive, isa? etc.")

var Lit_3351 *jrt.String = jrt.Intern("If coll is empty, returns nil, else coll")

var Lit_3352 *jrt.String = jrt.Intern("Returns the immediate superclass and direct interfaces of c, if any")

var Lit_3353 *jrt.String = jrt.Intern("Returns the immediate and indirect superclasses and interfaces of c, if any")

var Lit_3354 *jrt.String = jrt.Intern("child")

var Lit_3355 *jrt.String = jrt.Intern("Returns true if (= child parent), or child is directly or indirectly derived from\n  parent, either via a Java type inheritance relationship or a\n  relationship established via derive. h must be a hierarchy obtained\n  from make-hierarchy, if not supplied defaults to the global\n  hierarchy")

var Lit_3356 *jrt.String = jrt.Intern("Returns the immediate parents of tag, either via a Java type\n  inheritance relationship or a relationship established via derive. h\n  must be a hierarchy obtained from make-hierarchy, if not supplied\n  defaults to the global hierarchy")

var Lit_3357 *jrt.String = jrt.Intern("Returns the immediate and indirect parents of tag, either via a Java type\n  inheritance relationship or a relationship established via derive. h\n  must be a hierarchy obtained from make-hierarchy, if not supplied\n  defaults to the global hierarchy")

var Lit_3358 *jrt.String = jrt.Intern("Returns the immediate and indirect children of tag, through a\n  relationship established via derive. h must be a hierarchy obtained\n  from make-hierarchy, if not supplied defaults to the global\n  hierarchy. Note: does not work on Java type inheritance\n  relationships.")

var Lit_3359 *jrt.String = jrt.Intern("Establishes a parent/child relationship between parent and\n  tag. Parent must be a namespace-qualified symbol or keyword and\n  child can be either a namespace-qualified symbol or keyword or a\n  class. h must be a hierarchy obtained from make-hierarchy, if not\n  supplied defaults to, and modifies, the global hierarchy.")

var Lit_3360 *jrt.String = jrt.Intern("Removes a parent/child relationship between parent and\n  tag. h must be a hierarchy obtained from make-hierarchy, if not\n  supplied defaults to, and modifies, the global hierarchy.")

var Lit_3361 *jrt.String = jrt.Intern("Returns true if no two of the arguments are =")

var Lit_3362 *jrt.String = jrt.Intern("resultset-seq")

var Lit_3363 *jrt.String = jrt.Intern("rs")

var Lit_3364 *jrt.String = jrt.Intern("Creates and returns a lazy sequence of structmaps corresponding to\n  the rows in the java.sql.ResultSet rs")

var Lit_3365 *jrt.String = jrt.Intern("Returns a seq on a java.util.Iterator. Note that most collections\n  providing iterators implement Iterable and thus support seq directly.\n  Seqs cache values, thus iterator-seq should not be used on any\n  iterator that repeatedly returns the same mutable object.")

var Lit_3366 *jrt.String = jrt.Intern("Returns a seq on a java.util.Enumeration")

var Lit_3367 *jrt.String = jrt.Intern("fmt")

var Lit_3368 *jrt.String = jrt.Intern("Formats a string using java.lang.String.format, see java.util.Formatter for format\n  string syntax")

var Lit_3369 *jrt.String = jrt.Intern("Prints formatted output, as per format")

var Lit_3370 *jrt.String = jrt.Intern("references*")

var Lit_3371 *jrt.String = jrt.Intern("Sets *ns* to the namespace named by name (unevaluated), creating it\n  if needed.  references can be zero or more of: (:refer-clojure ...)\n  (:require ...) (:use ...) (:import ...) (:load ...) (:gen-class)\n  with the syntax of refer-clojure/require/use/import/load/gen-class\n  respectively, except the arguments are unevaluated and need not be\n  quoted. (:gen-class ...), when supplied, defaults to :name\n  corresponding to the ns name, :main true, :impl-ns same as ns, and\n  :init-impl-ns true. All options of gen-class are\n  supported. The :gen-class directive is ignored when not\n  compiling. If :gen-class is not supplied, when compiled only an\n  nsname__init.class will be generated. If :refer-clojure is not used, a\n  default (refer 'arbace.core) is used.  Use of ns is preferred to\n  individual calls to in-ns/require/use/import:\n\n  (ns foo.bar\n    (:refer-clojure :exclude [ancestors printf])\n    (:require (clojure.contrib sql combinatorics))\n    (:use (my.lib this that))\n    (:import (java.util Date Timer Random)\n             (java.sql Connection Statement)))")

var Lit_3372 *jrt.String = jrt.Intern("Same as (refer 'arbace.core <filters>)")

var Lit_3373 *jrt.String = jrt.Intern("defs name to have the root value of the expr iff the named var has no root value,\n  else expr is unevaluated")

var Lit_3374 *jrt.String = jrt.Intern("A ref to a sorted set of symbols representing loaded libs")

var Lit_3375 *jrt.String = jrt.Intern("A stack of paths currently being loaded by this thread")

var Lit_3376 *jrt.String = jrt.Intern("True while a verbose load is pending")

var Lit_3377 *jrt.String = jrt.Intern("Throws a CompilerException with a message if pred is true")

var Lit_3378 *jrt.String = jrt.Intern("Returns true if x is a libspec")

var Lit_3379 *jrt.String = jrt.Intern("Prepends a symbol or a seq to coll")

var Lit_3380 *jrt.String = jrt.Intern("lib")

var Lit_3381 *jrt.String = jrt.Intern("Returns the root directory path for a lib")

var Lit_3382 *jrt.String = jrt.Intern("Returns the root resource path for a lib")

var Lit_3383 *jrt.String = jrt.Intern("need-ns")

var Lit_3384 *jrt.String = jrt.Intern("Loads a lib given its name. If need-ns, ensures that the associated\n  namespace exists after loading. If require, records the load so any\n  duplicate loads can be skipped.")

var Lit_3385 *jrt.String = jrt.Intern("Loads a lib given its name and forces a load of any libs it directly or\n  indirectly loads. If need-ns, ensures that the associated namespace\n  exists after loading. If require, records the load so any duplicate loads\n  can be skipped.")

var Lit_3386 *jrt.String = jrt.Intern("prefix")

var Lit_3387 *jrt.String = jrt.Intern("Loads a lib with options")

var Lit_3388 *jrt.String = jrt.Intern("Loads libs, interpreting libspecs, prefix lists, and flags for\n  forwarding to load-lib")

var Lit_3389 *jrt.String = jrt.Intern("path")

var Lit_3390 *jrt.String = jrt.Intern("Detects and rejects non-trivial cyclic load dependencies. The\n  exception message shows the dependency chain with the cycle\n  highlighted. Ignores the trivial case of a file attempting to load\n  itself because that can occur when a gen-class'd class loads its\n  implementation.")

var Lit_3391 *jrt.String = jrt.Intern("Loads libs, skipping any that are already loaded. Each argument is\n  either a libspec that identifies a lib, a prefix list that identifies\n  multiple libs whose names share a common prefix, or a flag that modifies\n  how all the identified libs are loaded. Use :require in the ns macro\n  in preference to calling this directly.\n\n  Libs\n\n  A 'lib' is a named set of resources in classpath whose contents define a\n  library of Clojure code. Lib names are symbols and each lib is associated\n  with a Clojure namespace and a Java package that share its name. A lib's\n  name also locates its root directory within classpath using Java's\n  package name to classpath-relative path mapping. All resources in a lib\n  should be contained in the directory structure under its root directory.\n  All definitions a lib makes should be in its associated namespace.\n\n  'require loads a lib by loading its root resource. The root resource path\n  is derived from the lib name in the following manner:\n  Consider a lib named by the symbol 'x.y.z; it has the root directory\n  <classpath>/x/y/, and its root resource is <classpath>/x/y/z.ae, or\n  <classpath>/x/y/z.clj if <classpath>/x/y/z.ae does not exist, or\n  <classpath>/x/y/z.cljc if neither exists. The\n  root resource should contain code to create the lib's\n  namespace (usually by using the ns macro) and load any additional\n  lib resources.\n\n  Libspecs\n\n  A libspec is a lib name or a vector containing a lib name followed by\n  options expressed as sequential keywords and arguments.\n\n  Recognized options:\n  :as takes a symbol as its argument and makes that symbol an alias to the\n    lib's namespace in the current namespace.\n  :as-alias takes a symbol as its argument and aliases like :as, however\n    the lib will not be loaded. If the lib has not been loaded, a new\n    empty namespace will be created (as with create-ns).\n  :refer takes a list of symbols to refer from the namespace or the :all\n    keyword to bring in all public vars.\n\n  Prefix Lists\n\n  It's common for Clojure code to depend on several libs whose names have\n  the same prefix. When specifying libs, prefix lists can be used to reduce\n  repetition. A prefix list contains the shared prefix followed by libspecs\n  with the shared prefix removed from the lib names. After removing the\n  prefix, the names that remain must not contain any periods.\n\n  Flags\n\n  A flag is a keyword.\n  Recognized flags: :reload, :reload-all, :verbose\n  :reload forces loading of all the identified libs even if they are\n    already loaded (has no effect on libspecs using :as-alias)\n  :reload-all implies :reload and also forces loading of all libs that the\n    identified libs directly or indirectly load via require or use\n    (has no effect on libspecs using :as-alias)\n  :verbose triggers printing information about each load, alias, and refer\n\n  Example:\n\n  The following would load the libraries arbace.zip and arbace.set\n  abbreviated as 's'.\n\n  (require '(clojure zip [set :as s]))")

var Lit_3392 *jrt.String = jrt.Intern("Like 'require', but serializes loading.\n  Interim function preferred over 'require' for known asynchronous loads.\n  Future changes may make these equivalent.")

var Lit_3393 *jrt.String = jrt.Intern("requiring-resolve")

var Lit_3394 *jrt.String = jrt.Intern("Resolves namespace-qualified sym per 'resolve'. If initial resolve\nfails, attempts to require sym's namespace and retries.")

var Lit_3395 *jrt.String = jrt.Intern("Like 'require, but also refers to each lib's namespace using\n  arbace.core/refer. Use :use in the ns macro in preference to calling\n  this directly.\n\n  'use accepts additional options in libspecs: :exclude, :only, :rename.\n  The arguments and semantics for :exclude, :only, and :rename are the same\n  as those documented for arbace.core/refer.")

var Lit_3396 *jrt.String = jrt.Intern("loaded-libs")

var Lit_3397 *jrt.String = jrt.Intern("Returns a sorted set of symbols naming the currently loaded libs")

var Lit_3398 *jrt.String = jrt.Intern("paths")

var Lit_3399 *jrt.String = jrt.Intern("Loads Clojure code from resources in classpath. A path is interpreted as\n  classpath-relative if it begins with a slash or relative to the root\n  directory for the current namespace otherwise.")

var Lit_3400 *jrt.String = jrt.Intern("compile")

var Lit_3401 *jrt.String = jrt.Intern("Loads the namespace named by the symbol lib with *compile-files*\n  bound to true. Clojure compiles it into a set of classfiles in\n  *compile-path*; Arbace has no bytecode back end and writes none.")

var Lit_3402 *jrt.String = jrt.Intern("get-in")

var Lit_3403 *jrt.String = jrt.Intern("Returns the value in a nested associative structure,\n  where ks is a sequence of keys. Returns nil if the key\n  is not present, or the not-found value if supplied.")

var Lit_3404 *jrt.String = jrt.Intern("Associates a value in a nested associative structure, where ks is a\n  sequence of keys and v is the new value and returns a new nested structure.\n  If any levels do not exist, hash-maps will be created.")

var Lit_3405 *jrt.String = jrt.Intern("'Updates' a value in a nested associative structure, where ks is a\n  sequence of keys and f is a function that will take the old value\n  and any supplied args and return the new value, and returns a new\n  nested structure.  If any levels do not exist, hash-maps will be\n  created.")

var Lit_3406 *jrt.String = jrt.Intern("'Updates' a value in an associative structure, where k is a\n  key and f is a function that will take the old value\n  and any supplied args and return the new value, and returns a new\n  structure.  If the key does not exist, nil is passed as the old value.")

var Lit_3407 *jrt.String = jrt.Intern("coll?")

var Lit_3408 *jrt.String = jrt.Intern("Returns true if x implements IPersistentCollection")

var Lit_3409 *jrt.String = jrt.Intern("list?")

var Lit_3410 *jrt.String = jrt.Intern("Returns true if x implements IPersistentList")

var Lit_3411 *jrt.String = jrt.Intern("seqable?")

var Lit_3412 *jrt.String = jrt.Intern("Return true if the seq function is supported for x")

var Lit_3413 *jrt.String = jrt.Intern("ifn?")

var Lit_3414 *jrt.String = jrt.Intern("Returns true if x implements IFn. Note that many data structures\n  (e.g. sets and maps) implement IFn")

var Lit_3415 *jrt.String = jrt.Intern("Returns true if x implements Fn, i.e. is an object created via fn.")

var Lit_3416 *jrt.String = jrt.Intern("associative?")

var Lit_3417 *jrt.String = jrt.Intern("Returns true if coll implements Associative")

var Lit_3418 *jrt.String = jrt.Intern("Returns true if coll implements Sequential")

var Lit_3419 *jrt.String = jrt.Intern("sorted?")

var Lit_3420 *jrt.String = jrt.Intern("Returns true if coll implements Sorted")

var Lit_3421 *jrt.String = jrt.Intern("reversible?")

var Lit_3422 *jrt.String = jrt.Intern("Returns true if coll implements Reversible")

var Lit_3423 *jrt.String = jrt.Intern("indexed?")

var Lit_3424 *jrt.String = jrt.Intern("Return true if coll implements Indexed, indicating efficient lookup by index")

var Lit_3425 *jrt.String = jrt.Intern("*1")

var Lit_3426 *jrt.String = jrt.Intern("bound in a repl thread to the most recent value printed")

var Lit_3427 *jrt.String = jrt.Intern("*2")

var Lit_3428 *jrt.String = jrt.Intern("bound in a repl thread to the second most recent value printed")

var Lit_3429 *jrt.String = jrt.Intern("*3")

var Lit_3430 *jrt.String = jrt.Intern("bound in a repl thread to the third most recent value printed")

var Lit_3431 *jrt.String = jrt.Intern("*e")

var Lit_3432 *jrt.String = jrt.Intern("bound in a repl thread to the most recent exception caught by the repl")

var Lit_3433 *jrt.String = jrt.Intern("*repl*")

var Lit_3434 *jrt.String = jrt.Intern("Bound to true in a repl thread")

var Lit_3435 *jrt.String = jrt.Intern("1.12")

var Lit_3436 *jrt.String = jrt.Intern("trampoline can be used to convert algorithms requiring mutual\n  recursion without stack consumption. Calls f with supplied args, if\n  any. If f returns a fn, calls that fn with no arguments, and\n  continues to repeat, until the return value is not a fn, then\n  returns that non-fn value. Note that if you want to return a fn as a\n  final value, you must wrap it in some data structure and unpack it\n  after trampoline returns.")

var Lit_3437 *jrt.String = jrt.Intern("Finds or creates a var named by the symbol name in the namespace\n  ns (which can be a symbol or a namespace), setting its root binding\n  to val if supplied. The namespace must exist. The var will adopt any\n  metadata from the name symbol.  Returns the var.")

var Lit_3438 *jrt.String = jrt.Intern("Repeatedly executes body while test expression is true. Presumes\n  some side-effect will cause test to become false/nil. Returns nil")

var Lit_3439 *jrt.String = jrt.Intern("memoize")

var Lit_3440 *jrt.String = jrt.Intern("Returns a memoized version of a referentially transparent function. The\n  memoized version of the function keeps a cache of the mapping from arguments\n  to results and, when calls with the same arguments are repeated often, has\n  higher performance at the expense of higher memory use.")

var Lit_3441 *jrt.String = jrt.Intern("Takes a binary predicate, an expression, and a set of clauses.\n  Each clause can take the form of either:\n\n  test-expr result-expr\n\n  test-expr :>> result-fn\n\n  Note :>> is an ordinary keyword.\n\n  For each clause, (pred test-expr expr) is evaluated. If it returns\n  logical true, the clause is a match. If a binary clause matches, the\n  result-expr is returned, if a ternary clause matches, its result-fn,\n  which must be a unary function, is called with the result of the\n  predicate as its argument, the result of that call being the return\n  value of condp. A single default expression can follow the clauses,\n  and its value will be returned if no clause matches. If no default\n  expression is provided and no clause matches, an\n  IllegalArgumentException is thrown.")

var Lit_3442 *jrt.String = jrt.Intern("load-file")

var Lit_3443 *jrt.String = jrt.Intern("add-doc-and-meta")

var Lit_3444 *jrt.String = jrt.Intern("docstring")

var Lit_3445 *jrt.String = jrt.Intern("*command-line-args*")

var Lit_3446 *jrt.String = jrt.Intern("*warn-on-reflection*")

var Lit_3447 *jrt.String = jrt.Intern("*compile-path*")

var Lit_3448 *jrt.String = jrt.Intern("*compiler-options*")

var Lit_3449 *jrt.String = jrt.Intern("future?")

var Lit_3450 *jrt.String = jrt.Intern("Returns true if x is a future")

var Lit_3451 *jrt.String = jrt.Intern("future-done?")

var Lit_3452 *jrt.String = jrt.Intern("Returns true if future f is done")

var Lit_3453 *jrt.String = jrt.Intern("letfn")

var Lit_3454 *jrt.String = jrt.Intern("fnspecs")

var Lit_3455 *jrt.String = jrt.Intern("fnspec ==> (fname [params*] exprs) or (fname ([params*] exprs)+)\n\n  Takes a vector of function specs and a body, and generates a set of\n  bindings of functions to their names. All of the names are available\n  in all of the definitions of the functions, as well as the body.")

var Lit_3456 *jrt.String = jrt.Intern("fnspecs*")

var Lit_3457 *jrt.String = jrt.Intern("Takes a function f, and returns a function that calls f, replacing\n  a nil first argument to f with the supplied value x. Higher arity\n  versions can replace arguments in the second and third\n  positions (y, z). Note that the function f can take any number of\n  arguments, not just the one(s) being nil-patched.")

var Lit_3458 *jrt.String = jrt.Intern("mask")

var Lit_3459 *jrt.String = jrt.Intern("takes a collection of hashes and returns [shift mask] or nil if none found")

var Lit_3460 *jrt.String = jrt.Intern("case-f")

var Lit_3461 *jrt.String = jrt.Intern("test-f")

var Lit_3462 *jrt.String = jrt.Intern("tests")

var Lit_3463 *jrt.String = jrt.Intern("thens")

var Lit_3464 *jrt.String = jrt.Intern("Transforms a sequence of test constants and a corresponding sequence of then\n  expressions into a sorted map to be consumed by case*. The form of the map\n  entries are {(case-f test) [(test-f test) then]}.")

var Lit_3465 *jrt.String = jrt.Intern("Returns true if the collection of ints can fit within the\n  max-table-switch-size, false otherwise.")

var Lit_3466 *jrt.String = jrt.Intern("Takes a sequence of int-sized test constants and a corresponding sequence of\n  then expressions. Returns a tuple of [shift mask case-map switch-type] where\n  case-map is a map of int case values to [test then] tuples, and switch-type\n  is either :sparse or :compact.")

var Lit_3467 *jrt.String = jrt.Intern("expr-sym")

var Lit_3468 *jrt.String = jrt.Intern("Takes a case expression, default expression, and a sequence of test constants\n  and a corresponding sequence of then expressions. Returns a tuple of\n  [tests thens skip-check-set] where no tests have the same hash. Each set of\n  input test constants with the same hash is replaced with a single test\n  constant (the case int), and their respective thens are combined into:\n  (condp = expr\n    test-1 then-1\n    ...\n    test-n then-n\n    default).\n  The skip-check is a set of case ints for which post-switch equivalence\n  checking must not be done (the cases holding the above condp thens).")

var Lit_3469 *jrt.String = jrt.Intern("Takes a sequence of test constants and a corresponding sequence of then\n  expressions. Returns a tuple of [shift mask case-map switch-type skip-check]\n  where case-map is a map of int case values to [test then] tuples, switch-type\n  is either :sparse or :compact, and skip-check is a set of case ints for which\n  post-switch equivalence checking must not be done (occurs with hash\n  collisions).")

var Lit_3470 *jrt.String = jrt.Intern("Takes an expression, and a set of clauses.\n\n  Each clause can take the form of either:\n\n  test-constant result-expr\n\n  (test-constant1 ... test-constantN)  result-expr\n\n  The test-constants are not evaluated. They must be compile-time\n  literals, and need not be quoted.  If the expression is equal to a\n  test-constant, the corresponding result-expr is returned. A single\n  default expression can follow the clauses, and its value will be\n  returned if no clause matches. If no default expression is provided\n  and no clause matches, an IllegalArgumentException is thrown.\n\n  Unlike cond and condp, case does a constant-time dispatch, the\n  clauses are not considered sequentially.  All manner of constant\n  expressions are acceptable in case, including numbers, strings,\n  symbols, keywords, and (Clojure) composites thereof. Note that since\n  lists are used to group multiple constants that map to the same\n  expression, a vector can be used to match a list if needed. The\n  test-constants need not be all of the same type.")

var Lit_3471 *jrt.String = jrt.Intern("java.util.stream.BaseStream")

var Lit_3472 *jrt.String = jrt.Intern("Works like reduce but takes a java.util.stream.BaseStream as its source.\n  Honors 'reduced', is a terminal operation on the stream")

var Lit_3473 *jrt.String = jrt.Intern("stream-seq!")

var Lit_3474 *jrt.String = jrt.Intern("Takes a java.util.stream.BaseStream instance s and returns a seq of its\n  contents. This is a terminal operation on the stream.")

var Lit_3475 *jrt.String = jrt.Intern("Works like transduce but takes a java.util.stream.BaseStream as its source.\n  This is a terminal operation on the stream.")

var Lit_3476 *jrt.String = jrt.Intern("stream-into!")

var Lit_3477 *jrt.String = jrt.Intern("Returns a new coll consisting of coll with all of the items of the\n  stream conjoined. This is a terminal operation on the stream.")

var Lit_3478 *jrt.String = jrt.Intern("when-class")

var Lit_3479 *jrt.String = jrt.Intern("inst")

var Lit_3480 *jrt.String = jrt.Intern("java.util.Date")

var Lit_3481 *jrt.String = jrt.Intern("inst-ms")

var Lit_3482 *jrt.String = jrt.Intern("Return the number of milliseconds since January 1, 1970, 00:00:00 GMT")

var Lit_3483 *jrt.String = jrt.Intern("inst?")

var Lit_3484 *jrt.String = jrt.Intern("Return true if x satisfies Inst")

var Lit_3485 *jrt.String = jrt.Intern("java.time.Instant")

var Lit_3486 *jrt.String = jrt.Intern("uuid?")

var Lit_3487 *jrt.String = jrt.Intern("Return true if x is a java.util.UUID")

var Lit_3488 *jrt.String = jrt.Intern("random-uuid")

var Lit_3489 *jrt.String = jrt.Intern("java.util.UUID")

var Lit_3490 *jrt.String = jrt.Intern("Returns a pseudo-randomly generated java.util.UUID instance (i.e. type 4).\n\n  See: https://docs.oracle.com/javase/8/docs/api/java/util/UUID.html#randomUUID--")

var Lit_3491 *jrt.String = jrt.Intern("f should be a function of 2 arguments. If val is not supplied,\n  returns the result of applying f to the first 2 items in coll, then\n  applying f to that result and the 3rd item, etc. If coll contains no\n  items, f must accept no arguments as well, and reduce returns the\n  result of calling f with no arguments.  If coll has only 1 item, it\n  is returned and f is not called.  If val is supplied, returns the\n  result of applying f to val and the first item in coll, then\n  applying f to that result and the 2nd item, etc. If coll contains no\n  items, returns val and f is not called.")

var Lit_3492 *jrt.String = jrt.Intern("IKVReduce")

var Lit_3493 *jrt.String = jrt.Intern("arbace.lang.IKVReduce")

var Lit_3494 *jrt.String = jrt.Intern("Reduces an associative collection. f should be a function of 3\n  arguments. Returns the result of applying f to init, the first key\n  and the first value in coll, then applying f to that result and the\n  2nd key and value, etc. If coll contains no entries, returns init\n  and f is not called. Note that reduce-kv is supported on vectors,\n  where the keys will be the ordinals.")

var Lit_3495 *jrt.String = jrt.Intern("cf")

var Lit_3496 *jrt.String = jrt.Intern("Takes a reducing function f of 2 args and returns a fn suitable for\n  transduce by adding an arity-1 signature that calls cf (default -\n  identity) on the result argument.")

var Lit_3497 *jrt.String = jrt.Intern("reduce with a transformation of f (xf). If init is not\n  supplied, (f) will be called to produce it. f should be a reducing\n  step function that accepts both 1 and 2 arguments, if it accepts\n  only 2 you can add the arity-1 with 'completing'. Returns the result\n  of applying (the transformed) xf to init and the first item in coll,\n  then applying xf to that result and the 2nd item, etc. If coll\n  contains no items, returns init and f is not called. Note that\n  certain transforms may inject or skip items.")

var Lit_3498 *jrt.String = jrt.Intern("Returns a new coll consisting of to with all of the items of\n  from conjoined. A transducer may be supplied.\n  (into x) returns x. (into) returns [].")

var Lit_3499 *jrt.String = jrt.Intern("mapv")

var Lit_3500 *jrt.String = jrt.Intern("Returns a vector consisting of the result of applying f to the\n  set of first items of each coll, followed by applying f to the set\n  of second items in each coll, until any one of the colls is\n  exhausted.  Any remaining items in other colls are ignored. Function\n  f should accept number-of-colls arguments.")

var Lit_3501 *jrt.String = jrt.Intern("filterv")

var Lit_3502 *jrt.String = jrt.Intern("Returns a vector of the items in coll for which\n  (pred item) returns logical true. pred must be free of side-effects.")

var Lit_3503 *jrt.String = jrt.Intern("keyseq")

var Lit_3504 *jrt.String = jrt.Intern("Returns a map containing only those entries in map whose key is in keyseq")

var Lit_3505 *jrt.String = jrt.Intern("Returns a map that consists of the rest of the maps conj-ed onto\n  the first. For each pairwise merge, when a key occurs in both maps,\n  if both values are maps, then recursively merge-deep, else use the\n  latter (left-to-right) value.")

var Lit_3506 *jrt.String = jrt.Intern("Returns a map that consists of the rest of the maps conj-ed onto\n  the first. For each pairwise merge, when a key occurs in both maps,\n  if both values are maps, then recursively merge-deep-with, else use\n  the result of (f val-in-prior val-in-latter).")

var Lit_3507 *jrt.String = jrt.Intern("jio")

var Lit_3508 *jrt.String = jrt.Intern("slurp")

var Lit_3509 *jrt.String = jrt.Intern("Opens a reader on f and reads all its contents, returning a string.\n  See arbace.java.io/reader for a complete list of supported arguments.")

var Lit_3510 *jrt.String = jrt.Intern("spit")

var Lit_3511 *jrt.String = jrt.Intern("Opposite of slurp.  Opens f with writer, writes content, then\n  closes f. Options passed to arbace.java.io/writer.")

var Lit_3512 *jrt.String = jrt.Intern("Takes a function of no args and yields a future object that will\n  invoke the function in another thread, and will cache the result and\n  return it on all subsequent calls to deref/@. If the computation has\n  not yet finished, calls to deref/@ will block, unless the variant\n  of deref with timeout is used. See also - realized?.")

var Lit_3513 *jrt.String = jrt.Intern("future")

var Lit_3514 *jrt.String = jrt.Intern("Takes a body of expressions and yields a future object that will\n  invoke the body in another thread, and will cache the result and\n  return it on all subsequent calls to deref/@. If the computation has\n  not yet finished, calls to deref/@ will block, unless the variant of\n  deref with timeout is used. See also - realized?.")

var Lit_3515 *jrt.String = jrt.Intern("future-cancel")

var Lit_3516 *jrt.String = jrt.Intern("Cancels the future, if possible.")

var Lit_3517 *jrt.String = jrt.Intern("future-cancelled?")

var Lit_3518 *jrt.String = jrt.Intern("Returns true if future f is cancelled")

var Lit_3519 *jrt.String = jrt.Intern("Like map, except f is applied in parallel. Semi-lazy in that the\n  parallel computation stays ahead of the consumption, but doesn't\n  realize the entire result unless required. Only useful for\n  computationally intensive functions where the time of f dominates\n  the coordination overhead.")

var Lit_3520 *jrt.String = jrt.Intern("fns")

var Lit_3521 *jrt.String = jrt.Intern("Executes the no-arg fns in parallel, returning a lazy sequence of\n  their values")

var Lit_3522 *jrt.String = jrt.Intern("pvalues")

var Lit_3523 *jrt.String = jrt.Intern("Returns a lazy sequence of the values of the exprs, which are\n  evaluated in parallel")

var Lit_3524 *jrt.String = jrt.Intern("(\\d+)\\.(\\d+)\\.(\\d+)(?:-([a-zA-Z0-9_]+))?(?:-(SNAPSHOT))?")

var Lit_3525 *jrt.String = jrt.Intern("clojure-version")

var Lit_3526 *jrt.String = jrt.Intern("Returns clojure version as a printable string.")

var Lit_3527 *jrt.String = jrt.Intern("arbace-version")

var Lit_3528 *jrt.String = jrt.Intern("Returns Arbace's version as a printable string: the git describe of the commit it was built\n  from (:describe of *arbace-version*).")

var Lit_3529 *jrt.String = jrt.Intern("promise")

var Lit_3530 *jrt.String = jrt.Intern("Returns a promise object that can be read with deref/@, and set,\n  once only, with deliver. Calls to deref/@ prior to delivery will\n  block, unless the variant of deref with timeout is used. All\n  subsequent derefs will return the same delivered value without\n  blocking. See also - realized?.")

var Lit_3531 *jrt.String = jrt.Intern("deliver")

var Lit_3532 *jrt.String = jrt.Intern("Delivers the supplied value to the promise, releasing any pending\n  derefs. A subsequent call to deliver on a promise will have no effect.")

var Lit_3533 *jrt.String = jrt.Intern("Takes any nested combination of sequential things (lists, vectors,\n  etc.) and returns their contents as a single, flat lazy sequence.\n  (flatten nil) returns an empty sequence.")

var Lit_3534 *jrt.String = jrt.Intern("group-by")

var Lit_3535 *jrt.String = jrt.Intern("Returns a map of the elements of coll keyed by the result of\n  f on each element. The value at each key will be a vector of the\n  corresponding elements, in the order they appeared in coll.")

var Lit_3536 *jrt.String = jrt.Intern("Applies f to each value in coll, splitting it each time f returns a\n   new value.  Returns a lazy seq of partitions.  Returns a stateful\n   transducer when no collection is provided.")

var Lit_3537 *jrt.String = jrt.Intern("frequencies")

var Lit_3538 *jrt.String = jrt.Intern("Returns a map from distinct items in coll to the number of times\n  they appear.")

var Lit_3539 *jrt.String = jrt.Intern("Returns a lazy seq of the intermediate values of the reduction (as\n  per reduce) of coll by f, starting with init.")

var Lit_3540 *jrt.String = jrt.Intern("rand-nth")

var Lit_3541 *jrt.String = jrt.Intern("Return a random element of the (sequential) collection. Will have\n  the same performance characteristics as nth for the given\n  collection.")

var Lit_3542 *jrt.String = jrt.Intern("Returns a lazy sequence of lists like partition, but may include\n  partitions with fewer than n items at the end.  Returns a stateful\n  transducer when no collection is provided.")

var Lit_3543 *jrt.String = jrt.Intern("splitv-at")

var Lit_3544 *jrt.String = jrt.Intern("Returns a vector of [(into [] (take n) coll) (drop n coll)]")

var Lit_3545 *jrt.String = jrt.Intern("Returns a lazy sequence of vectors of n items each, at offsets step\n  apart. If step is not supplied, defaults to n, i.e. the partitions\n  do not overlap. If a pad collection is supplied, use its elements as\n  necessary to complete last partition upto n items. In case there are\n  not enough padding elements, return a partition with less than n items.")

var Lit_3546 *jrt.String = jrt.Intern("Returns a lazy sequence of vector partitions, but may include\n  partitions with fewer than n items at the end.\n  Returns a stateful transducer when no collection is provided.")

var Lit_3547 *jrt.String = jrt.Intern("shuffle")

var Lit_3548 *jrt.String = jrt.Intern("Return a random permutation of coll")

var Lit_3549 *jrt.String = jrt.Intern("map-indexed")

var Lit_3550 *jrt.String = jrt.Intern("Returns a lazy sequence consisting of the result of applying f to 0\n  and the first item of coll, followed by applying f to 1 and the second\n  item in coll, etc, until coll is exhausted. Thus function f should\n  accept 2 arguments, index and item. Returns a stateful transducer when\n  no collection is provided.")

var Lit_3551 *jrt.String = jrt.Intern("Returns a lazy sequence of the non-nil results of (f item). Note,\n  this means false return values will be included.  f must be free of\n  side-effects.  Returns a transducer when no collection is provided.")

var Lit_3552 *jrt.String = jrt.Intern("keep-indexed")

var Lit_3553 *jrt.String = jrt.Intern("Returns a lazy sequence of the non-nil results of (f index item). Note,\n  this means false return values will be included.  f must be free of\n  side-effects.  Returns a stateful transducer when no collection is\n  provided.")

var Lit_3554 *jrt.String = jrt.Intern("bounded-count")

var Lit_3555 *jrt.String = jrt.Intern("If coll is counted? returns its count, else will count at most the first n\n  elements of coll using its seq")

var Lit_3556 *jrt.String = jrt.Intern("every-pred")

var Lit_3557 *jrt.String = jrt.Intern("p")

var Lit_3558 *jrt.String = jrt.Intern("p1")

var Lit_3559 *jrt.String = jrt.Intern("p2")

var Lit_3560 *jrt.String = jrt.Intern("p3")

var Lit_3561 *jrt.String = jrt.Intern("ps")

var Lit_3562 *jrt.String = jrt.Intern("Takes a set of predicates and returns a function f that returns true if all of its\n  composing predicates return a logical true value against all of its arguments, else it returns\n  false. Note that f is short-circuiting in that it will stop execution on the first\n  argument that triggers a logical false result against the original predicates.")

var Lit_3563 *jrt.String = jrt.Intern("some-fn")

var Lit_3564 *jrt.String = jrt.Intern("Takes a set of predicates and returns a function f that returns the first logical true value\n  returned by one of its composing predicates against any of its arguments, else it returns\n  logical false. Note that f is short-circuiting in that it will stop execution on the first\n  argument that triggers a logical true result against the original predicates.")

var Lit_3565 *jrt.String = jrt.Intern("fdecl")

var Lit_3566 *jrt.String = jrt.Intern("A good fdecl looks like (([a] ...) ([a b] ...)) near the end of defn.")

var Lit_3567 *jrt.String = jrt.Intern("func")

var Lit_3568 *jrt.String = jrt.Intern("Temporarily redefines Vars during a call to func.  Each val of\n  binding-map will replace the root value of its key which must be\n  a Var.  After func is called with no args, the root values of all\n  the Vars will be set back to their old values.  These temporary\n  changes will be visible in all threads.  Useful for mocking out\n  functions during testing.")

var Lit_3569 *jrt.String = jrt.Intern("with-redefs")

var Lit_3570 *jrt.String = jrt.Intern("binding => var-symbol temp-value-expr\n\n  Temporarily redefines Vars while executing the body.  The\n  temp-value-exprs will be evaluated and each resulting value will\n  replace in parallel the root value of its Var.  After the body is\n  executed, the root values of all the Vars will be set back to their\n  old values.  These temporary changes will be visible in all threads.\n  Useful for mocking out functions during testing.")

var Lit_3571 *jrt.String = jrt.Intern("realized?")

var Lit_3572 *jrt.String = jrt.Intern("arbace.lang.IPending")

var Lit_3573 *jrt.String = jrt.Intern("Returns true if a value has been produced for a promise, delay, future or lazy sequence.")

var Lit_3574 *jrt.String = jrt.Intern("cond->")

var Lit_3575 *jrt.String = jrt.Intern("Takes an expression and a set of test/form pairs. Threads expr (via ->)\n  through each form for which the corresponding test\n  expression is true. Note that, unlike cond branching, cond-> threading does\n  not short circuit after the first true test expression.")

var Lit_3576 *jrt.String = jrt.Intern("cond->>")

var Lit_3577 *jrt.String = jrt.Intern("Takes an expression and a set of test/form pairs. Threads expr (via ->>)\n  through each form for which the corresponding test expression\n  is true.  Note that, unlike cond branching, cond->> threading does not short circuit\n  after the first true test expression.")

var Lit_3578 *jrt.String = jrt.Intern("as->")

var Lit_3579 *jrt.String = jrt.Intern("Binds name to expr, evaluates the first form in the lexical context\n  of that binding, then binds name to that result, repeating for each\n  successive form, returning the result of the last form.")

var Lit_3580 *jrt.String = jrt.Intern("some->")

var Lit_3581 *jrt.String = jrt.Intern("When expr is not nil, threads it into the first form (via ->),\n  and when that result is not nil, through the next etc")

var Lit_3582 *jrt.String = jrt.Intern("some->>")

var Lit_3583 *jrt.String = jrt.Intern("When expr is not nil, threads it into the first form (via ->>),\n  and when that result is not nil, through the next etc")

var Lit_3584 *jrt.String = jrt.Intern("rf")

var Lit_3585 *jrt.String = jrt.Intern("A transducer which concatenates the contents of each input, which must be a\n  collection, into the reduction.")

var Lit_3586 *jrt.String = jrt.Intern("retf")

var Lit_3587 *jrt.String = jrt.Intern("Returns a transducer that ends transduction when pred returns true\n  for an input. When retf is supplied it must be a fn of 2 arguments -\n  it will be passed the (completed) result so far and the input that\n  triggered the predicate, and its return value (if it does not throw\n  an exception) will be the return value of the transducer. If retf\n  is not supplied, the input that triggered the predicate will be\n  returned. If the predicate never returns true the transduction is\n  unaffected.")

var Lit_3588 *jrt.String = jrt.Intern("Returns a lazy sequence removing consecutive duplicates in coll.\n  Returns a transducer when no collection is provided.")

var Lit_3589 *jrt.String = jrt.Intern("random-sample")

var Lit_3590 *jrt.String = jrt.Intern("prob")

var Lit_3591 *jrt.String = jrt.Intern("Returns items from coll with random probability of prob (0.0 -\n  1.0).  Returns a transducer when no collection is provided.")

var Lit_3592 *jrt.String = jrt.Intern("arbace.core.Eduction")

var Lit_3593 *jrt.String = jrt.Intern("->Eduction")

var Lit_3594 *jrt.String = jrt.Intern("Positional factory function for class arbace.core.Eduction.")

var Lit_3595 *jrt.String = jrt.Intern("eduction")

var Lit_3596 *jrt.String = jrt.Intern("xform*")

var Lit_3597 *jrt.String = jrt.Intern("Returns a reducible/iterable application of the transducers\n  to the items in coll. Transducers are applied in order as if\n  combined with comp. Note that these applications will be\n  performed every time reduce/iterator is called.")

var Lit_3598 *jrt.String = jrt.Intern("run!")

var Lit_3599 *jrt.String = jrt.Intern("proc")

var Lit_3600 *jrt.String = jrt.Intern("Runs the supplied procedure (via reduce), for purposes of side\n  effects, on successive items in the collection. Returns nil")

var Lit_3601 *jrt.String = jrt.Intern("iteration")

var Lit_3602 *jrt.String = jrt.Intern("Creates a seqable/reducible via repeated calls to step,\n  a function of some (continuation token) 'k'. The first call to step\n  will be passed initk, returning 'ret'. Iff (somef ret) is true,\n  (vf ret) will be included in the iteration, else iteration will\n  terminate and vf/kf will not be called. If (kf ret) is non-nil it\n  will be passed to the next step call, else iteration will terminate.\n\n  This can be used e.g. to consume APIs that return paginated or batched data.\n\n   step - (possibly impure) fn of 'k' -> 'ret'\n\n   :somef - fn of 'ret' -> logical true/false, default 'some?'\n   :vf - fn of 'ret' -> 'v', a value produced by the iteration, default 'identity'\n   :kf - fn of 'ret' -> 'next-k' or nil (signaling 'do not continue'), default 'identity'\n   :initk - the first value passed to step, default 'nil'\n\n  It is presumed that step with non-initk is unreproducible/non-idempotent.\n  If step with initk is unreproducible it is on the consumer to not consume twice.")

var Lit_3603 *jrt.String = jrt.Intern("tagged-literal?")

var Lit_3604 *jrt.String = jrt.Intern("value")

var Lit_3605 *jrt.String = jrt.Intern("Return true if the value is the data representation of a tagged literal")

var Lit_3606 *jrt.String = jrt.Intern("tagged-literal")

var Lit_3607 *jrt.String = jrt.Intern("Construct a data representation of a tagged literal from a\n  tag symbol and a form.")

var Lit_3608 *jrt.String = jrt.Intern("reader-conditional?")

var Lit_3609 *jrt.String = jrt.Intern("Return true if the value is the data representation of a reader conditional")

var Lit_3610 *jrt.String = jrt.Intern("reader-conditional")

var Lit_3611 *jrt.String = jrt.Intern("Boolean")

var Lit_3612 *jrt.String = jrt.Intern("Construct a data representation of a reader conditional.\n  If true, splicing? indicates read-cond-splicing.")

var Lit_3613 *jrt.String = jrt.Intern("default-data-readers")

var Lit_3614 *jrt.String = jrt.Intern("Default map of data reader functions provided by Clojure. May be\n  overridden by binding *data-readers*.")

var Lit_3615 *jrt.String = jrt.Intern("uuid")

var Lit_3616 *jrt.String = jrt.Intern("arbace.uuid")

var Lit_3617 *jrt.String = jrt.Intern("default-uuid-reader")

var Lit_3618 *jrt.String = jrt.Intern("arbace.instant")

var Lit_3619 *jrt.String = jrt.Intern("read-instant-date")

var Lit_3620 *jrt.String = jrt.Intern("Map from reader tag symbols to data reader Vars.\n\n  When Arbace starts, it searches for files named 'data_readers.ae',\n  'data_readers.clj' and 'data_readers.cljc' (in that order, as a\n  namespace's sources are looked for) at the root of the classpath.\n  Each such file\n  must contain a literal map of symbols, like this:\n\n      {foo/bar my.project.foo/bar\n       foo/baz my.project/baz}\n\n  The first symbol in each pair is a tag that will be recognized by\n  the Clojure reader. The second symbol in the pair is the\n  fully-qualified name of a Var which will be invoked by the reader to\n  parse the form following the tag. For example, given the\n  data_readers.clj file above, the Clojure reader would parse this\n  form:\n\n      #foo/bar [1 2 3]\n\n  by invoking the Var #'my.project.foo/bar on the vector [1 2 3]. The\n  data reader function is invoked on the form AFTER it has been read\n  as a normal Clojure data structure by the reader.\n\n  Reader tags without namespace qualifiers are reserved for\n  Clojure. Default reader tags are defined in\n  arbace.core/default-data-readers but may be overridden in\n  data_readers.ae, data_readers.clj, data_readers.cljc, or by rebinding\n  this Var.")

var Lit_3621 *jrt.String = jrt.Intern("*default-data-reader-fn*")

var Lit_3622 *jrt.String = jrt.Intern("When no data reader is found for a tag and *default-data-reader-fn*\n  is non-nil, it will be called with two arguments,\n  the tag and the value.  If *default-data-reader-fn* is nil (the\n  default), an exception will be thrown for the unknown tag.")

var Lit_3623 *jrt.String = jrt.Intern("java.net.URL")

var Lit_3624 *jrt.String = jrt.Intern("load-data-readers")

var Lit_3625 *jrt.String = jrt.Intern("uri?")

var Lit_3626 *jrt.String = jrt.Intern("Return true if x is a java.net.URI")

var Lit_3627 *jrt.String = jrt.Intern("java.util.concurrent.ArrayBlockingQueue")

var Lit_3628 *jrt.String = jrt.Intern("add-tap")

var Lit_3629 *jrt.String = jrt.Intern("adds f, a fn of one argument, to the tap set. This function will be called with anything sent via tap>.\n  This function may (briefly) block (e.g. for streams), and will never impede calls to tap>,\n  but blocking indefinitely may cause tap values to be dropped.\n  Remember f in order to remove-tap")

var Lit_3630 *jrt.String = jrt.Intern("remove-tap")

var Lit_3631 *jrt.String = jrt.Intern("Remove f from the tap set.")

var Lit_3632 *jrt.String = jrt.Intern("sends x to any taps. Will not block. Returns true if there was room in the queue,\n  false if not (dropped).")

var Lit_3633 *jrt.String = jrt.Intern("tap->")

var Lit_3634 *jrt.String = jrt.Intern("Sends x to any taps, drops if tap queue is full, returns x.")

var Lit_3635 *jrt.String = jrt.Intern("update-vals")

var Lit_3636 *jrt.String = jrt.Intern("m f => {k (f v) ...}\n\n  Given a map m and a function f of 1-argument, returns a new map where the keys of m\n  are mapped to result of applying f to the corresponding values of m.")

var Lit_3637 *jrt.String = jrt.Intern("update-keys")

var Lit_3638 *jrt.String = jrt.Intern("m f => {(f k) v ...}\n\n  Given a map m and a function f of 1-argument, returns a new map whose\n  keys are the result of applying f to the keys of m, mapped to the\n  corresponding values of m.\n  f must return a unique key for each key of m, else the behavior is undefined.")

var Lit_3639 *jrt.String = jrt.Intern("Construct message for parsing for non-string parsing error")

var Lit_3640 *jrt.String = jrt.Intern("parse-long")

var Lit_3641 *jrt.String = jrt.Intern("java.lang.Long")

var Lit_3642 *jrt.String = jrt.Intern("Parse string of decimal digits with optional leading -/+ and return a\n  Long value, or nil if parse fails")

var Lit_3643 *jrt.String = jrt.Intern("parse-double")

var Lit_3644 *jrt.String = jrt.Intern("Parse string with floating point components and return a Double value,\n  or nil if parse fails.\n\n  Grammar: https://docs.oracle.com/javase/8/docs/api/java/lang/Double.html#valueOf-java.lang.String-")

var Lit_3645 *jrt.String = jrt.Intern("parse-uuid")

var Lit_3646 *jrt.String = jrt.Intern("Parse a string representing a UUID and return a java.util.UUID instance,\n  or nil if parse fails.\n\n  Grammar: https://docs.oracle.com/javase/8/docs/api/java/util/UUID.html#toString--")

var Lit_3647 *jrt.String = jrt.Intern("parse-boolean")

var Lit_3648 *jrt.String = jrt.Intern("Parse strings \"true\" or \"false\" and return a boolean, or nil if invalid")

var Lit_3649 *jrt.String = jrt.Intern("NaN?")

var Lit_3650 *jrt.String = jrt.Intern("infinite?")

var Lit_3651 *jrt.String = jrt.Intern("Builds a selecting-fn from m, a map destructuring form that must\n  include one or more of the :select, :all, :missing, and :excess\n  directives. The return function takes a collection, destructures it\n  per m, and returns a map of the result(s).\n\n  If m has exactly one directive, the result is the value that\n  directive would yield. If m has more than one directive, then it\n  returns a map of directives to values.\n\n  As in destructuring, :missing controls whether missing required keys\n  throw or are collected.\n\n  While a map destructuring form may and sometimes must include\n  bindings, selector doesn't produce bindings, thus ignoring the\n  associated directive names.\n\n  Throws an exception if the argument is not a map.")

var Lit_3652 *jrt.String = jrt.Intern("Returns the metadata of obj, returns nil if there is no metadata.")

var Lit_3653 *jrt.String = jrt.Intern("Returns true if x is nil, false otherwise.")

var Lit_3654 *jrt.String = jrt.Intern("Tests if 2 arguments are the same object")

var Lit_3655 *jrt.String = jrt.Intern("Equality. Returns true if x equals y, false if not. Same as\n  Java x.equals(y) except it also works for nil, and compares\n  numbers and collections in a type-independent manner.  Clojure's immutable data\n  structures define equals() (and thus =) as a value, not an identity,\n  comparison.")

var Lit_3656 *jrt.String = jrt.Intern("Comparator. Returns a negative number, zero, or a positive number\n  when x is logically 'less than', 'equal to', or 'greater than'\n  y. Same as Java x.compareTo(y) except it also works for nil, and\n  compares numbers and collections in a type-independent manner. x\n  must implement Comparable")

var Lit_3657 *jrt.String = jrt.Intern("Returns true if num is zero, else false")

var Lit_3658 *jrt.String = jrt.Intern("Returns the number of items in the collection. (count nil) returns\n  0.  Also works on strings, arrays, and Java Collections and Maps")

var Lit_3659 *jrt.String = jrt.Intern("Coerce to int")

var Lit_3660 *jrt.String = jrt.Intern("Returns the value at the index. get returns nil if index out of\n  bounds, nth throws an exception unless not-found is supplied.  nth\n  also works for strings, Java arrays, regex Matchers and Lists, and,\n  in O(n) time, for sequences.")

var Lit_3661 *jrt.String = jrt.Intern("Returns non-nil if nums are in monotonically increasing order,\n  otherwise false.")

var Lit_3662 *jrt.String = jrt.Intern("Returns a number one greater than num. Supports arbitrary precision.\n  See also: inc")

var Lit_3663 *jrt.String = jrt.Intern("Returns a number one greater than num. Does not auto-promote\n  longs, will throw on overflow. See also: inc'")

var Lit_3664 *jrt.String = jrt.Intern("Returns the sum of nums. (+') returns 0. Supports arbitrary precision.\n  See also: +")

var Lit_3665 *jrt.String = jrt.Intern("Returns the sum of nums. (+) returns 0. Does not auto-promote\n  longs, will throw on overflow. See also: +'")

var Lit_3666 *jrt.String = jrt.Intern("Returns the product of nums. (*') returns 1. Supports arbitrary precision.\n  See also: *")

var Lit_3667 *jrt.String = jrt.Intern("Returns the product of nums. (*) returns 1. Does not auto-promote\n  longs, will throw on overflow. See also: *'")

var Lit_3668 *jrt.String = jrt.Intern("If no denominators are supplied, returns 1/numerator,\n  else returns numerator divided by all of the denominators.")

var Lit_3669 *jrt.String = jrt.Intern("If no ys are supplied, returns the negation of x, else subtracts\n  the ys from x and returns the result. Supports arbitrary precision.\n  See also: -")

var Lit_3670 *jrt.String = jrt.Intern("If no ys are supplied, returns the negation of x, else subtracts\n  the ys from x and returns the result. Does not auto-promote\n  longs, will throw on overflow. See also: -'")

var Lit_3671 *jrt.String = jrt.Intern("Returns non-nil if nums are in monotonically non-decreasing order,\n  otherwise false.")

var Lit_3672 *jrt.String = jrt.Intern("Returns non-nil if nums are in monotonically decreasing order,\n  otherwise false.")

var Lit_3673 *jrt.String = jrt.Intern("Returns non-nil if nums are in monotonically non-increasing order,\n  otherwise false.")

var Lit_3674 *jrt.String = jrt.Intern("Returns non-nil if nums all have the equivalent\n  value (type-independent), otherwise false")

var Lit_3675 *jrt.String = jrt.Intern("Returns the greatest of the nums.")

var Lit_3676 *jrt.String = jrt.Intern("Returns the least of the nums.")

var Lit_3677 *jrt.String = jrt.Intern("Returns the absolute value of a.\n  If a is Long/MIN_VALUE => Long/MIN_VALUE\n  If a is a double and zero => +0.0\n  If a is a double and ##Inf or ##-Inf => ##Inf\n  If a is a double and ##NaN => ##NaN")

var Lit_3678 *jrt.String = jrt.Intern("Returns a number one less than num. Supports arbitrary precision.\n  See also: dec")

var Lit_3679 *jrt.String = jrt.Intern("Returns a number one less than num. Does not auto-promote\n  longs, will throw on overflow. See also: dec'")

var Lit_3680 *jrt.String = jrt.Intern("Returns a number one greater than x, an int.\n  Note - uses a primitive operator subject to overflow.")

var Lit_3681 *jrt.String = jrt.Intern("Returns a number one greater than x, a long.\n  Note - uses a primitive operator subject to overflow.")

var Lit_3682 *jrt.String = jrt.Intern("Returns a number one less than x, an int.\n  Note - uses a primitive operator subject to overflow.")

var Lit_3683 *jrt.String = jrt.Intern("Returns a number one less than x, a long.\n  Note - uses a primitive operator subject to overflow.")

var Lit_3684 *jrt.String = jrt.Intern("Returns the negation of x, an int.\n  Note - uses a primitive operator subject to overflow.")

var Lit_3685 *jrt.String = jrt.Intern("Returns the negation of x, a long.\n  Note - uses a primitive operator subject to overflow.")

var Lit_3686 *jrt.String = jrt.Intern("Returns the sum of x and y, both int.\n  Note - uses a primitive operator subject to overflow.")

var Lit_3687 *jrt.String = jrt.Intern("Returns the sum of x and y, both long.\n  Note - uses a primitive operator subject to overflow.")

var Lit_3688 *jrt.String = jrt.Intern("Returns the difference of x and y, both int.\n  Note - uses a primitive operator subject to overflow.")

var Lit_3689 *jrt.String = jrt.Intern("Returns the difference of x and y, both long.\n  Note - uses a primitive operator subject to overflow.")

var Lit_3690 *jrt.String = jrt.Intern("Returns the product of x and y, both int.\n  Note - uses a primitive operator subject to overflow.")

var Lit_3691 *jrt.String = jrt.Intern("Returns the product of x and y, both long.\n  Note - uses a primitive operator subject to overflow.")

var Lit_3692 *jrt.String = jrt.Intern("Returns the division of x by y, both int.\n  Note - uses a primitive operator subject to truncation.")

var Lit_3693 *jrt.String = jrt.Intern("Returns the remainder of division of x by y, both int.\n  Note - uses a primitive operator subject to truncation.")

var Lit_3694 *jrt.String = jrt.Intern("Returns true if num is greater than zero, else false")

var Lit_3695 *jrt.String = jrt.Intern("Returns true if num is less than zero, else false")

var Lit_3696 *jrt.String = jrt.Intern("quot[ient] of dividing numerator by denominator.")

var Lit_3697 *jrt.String = jrt.Intern("remainder of dividing numerator by denominator.")

var Lit_3698 *jrt.String = jrt.Intern("Bitwise complement")

var Lit_3699 *jrt.String = jrt.Intern("Bitwise and")

var Lit_3700 *jrt.String = jrt.Intern("Bitwise or")

var Lit_3701 *jrt.String = jrt.Intern("Bitwise exclusive or")

var Lit_3702 *jrt.String = jrt.Intern("Bitwise and with complement")

var Lit_3703 *jrt.String = jrt.Intern("Bitwise shift left")

var Lit_3704 *jrt.String = jrt.Intern("Bitwise shift right")

var Lit_3705 *jrt.String = jrt.Intern("Bitwise shift right, without sign-extension.")

var Lit_3706 *jrt.String = jrt.Intern("Returns the value mapped to key, not-found or nil if key not present\n  in associative collection, set, string, array, or ILookup instance.")

var Lit_3707 *jrt.String = jrt.Intern("Like arity-2 'get', but throws if key not present.")

var Lit_3708 *jrt.String = jrt.Intern("Coerce to boolean")

var Lit_3709 *jrt.String = jrt.Intern("Returns true if x is the result of a call to reduced")

var Lit_3710 *jrt.String = jrt.Intern("Coerce to Number")

var Lit_3711 *jrt.String = jrt.Intern("Coerce to long")

var Lit_3712 *jrt.String = jrt.Intern("Coerce to float")

var Lit_3713 *jrt.String = jrt.Intern("Coerce to double")

var Lit_3714 *jrt.String = jrt.Intern("Coerce to short")

var Lit_3715 *jrt.String = jrt.Intern("Coerce to byte")

var Lit_3716 *jrt.String = jrt.Intern("Coerce to char")

var Lit_3717 *jrt.String = jrt.Intern("Coerce to byte. Subject to rounding or truncation.")

var Lit_3718 *jrt.String = jrt.Intern("Coerce to short. Subject to rounding or truncation.")

var Lit_3719 *jrt.String = jrt.Intern("Coerce to char. Subject to rounding or truncation.")

var Lit_3720 *jrt.String = jrt.Intern("Coerce to int. Subject to rounding or truncation.")

var Lit_3721 *jrt.String = jrt.Intern("Coerce to long. Subject to rounding or truncation.")

var Lit_3722 *jrt.String = jrt.Intern("Coerce to float. Subject to rounding.")

var Lit_3723 *jrt.String = jrt.Intern("Coerce to double. Subject to rounding.")

var Lit_3724 *jrt.String = jrt.Intern("line.separator")

var Lit_3725 *jrt.String = jrt.Intern("Returns the length of the Java array. Works on arrays of all\n  types.")

var Lit_3726 *jrt.String = jrt.Intern("Returns a clone of the Java array. Works on arrays of known\n  types.")

var Lit_3727 *jrt.String = jrt.Intern("Returns the value at the index/indices. Works on Java arrays of all\n  types.")

var Lit_3728 *jrt.String = jrt.Intern("Sets the value at the index/indices. Works on Java arrays of\n  reference types. Returns val.")

var Lit_3729 *jrt.String = jrt.Intern("arbace.lang.ExceptionInfo")

var Lit_3730 *jrt.String = jrt.Intern("arbace.lang.IExceptionInfo")

var Lit_3731 *jrt.String = jrt.Intern("Creates an array of floats")

var Lit_3732 *jrt.String = jrt.Intern("Creates an array of booleans")

var Lit_3733 *jrt.String = jrt.Intern("Creates an array of bytes")

var Lit_3734 *jrt.String = jrt.Intern("Creates an array of chars")

var Lit_3735 *jrt.String = jrt.Intern("Creates an array of shorts")

var Lit_3736 *jrt.String = jrt.Intern("Creates an array of doubles")

var Lit_3737 *jrt.String = jrt.Intern("Creates an array of objects")

var Lit_3738 *jrt.String = jrt.Intern("Creates an array of ints")

var Lit_3739 *jrt.String = jrt.Intern("Creates an array of longs")

var Lit_3740 *jrt.String = jrt.Intern("java.util.concurrent.BlockingQueue")

var Lit_3741 *jrt.String = jrt.Intern("java.util.concurrent.LinkedBlockingQueue")

var Lit_3742 *jrt.String = jrt.Intern("The path of the file being evaluated, as a String.\n\n  When there is no file, e.g. in the REPL, the value is not defined.")

var Lit_3743 *jrt.String = jrt.Intern("A sequence of the supplied command line arguments, or nil if\n  none were supplied")

var Lit_3744 *jrt.String = jrt.Intern("When set to true, the compiler will emit warnings when reflection is\n  needed to resolve Java method calls or field accesses.\n\n  Defaults to false.")

var Lit_3745 *jrt.String = jrt.Intern("Specifies the directory where 'compile' will write out .class\n  files. This directory must be in the classpath for 'compile' to\n  work.\n\n  Defaults to \"classes\"")

var Lit_3746 *jrt.String = jrt.Intern("Set to true when compiling files, false otherwise.")

var Lit_3747 *jrt.String = jrt.Intern("While bound to true, compilations of +, -, *, inc, dec and the\n  coercions will be done without overflow checks. While bound\n  to :warn-on-boxed, same behavior as true, and a warning is emitted\n  when compilation uses boxed math. Default: false.")

var Lit_3748 *jrt.String = jrt.Intern("A map of keys to options.\n  Note, when binding dynamically make sure to merge with previous value.\n  Supported options:\n  :elide-meta - a collection of metadata keys to elide during compilation.\n  :disable-locals-clearing - set to true to disable clearing, useful for using a debugger\n  :direct-linking - set to true to use direct static invocation of functions, rather than vars\n    Note that call sites compiled with direct linking will not be affected by var redefinition.\n    Use ^:redef (or ^:dynamic) on a var to prevent direct linking and allow redefinition.\n  See https://clojure.org/reference/compilation for more information.")

var Lit_3749 *jrt.String = jrt.Intern("A arbace.lang.Namespace object representing the current namespace.")

var Lit_3750 *jrt.String = jrt.Intern("A java.io.Reader object representing standard input for read operations.\n\n  Defaults to System/in, wrapped in a LineNumberingPushbackReader")

var Lit_3751 *jrt.String = jrt.Intern("A java.io.Writer object representing standard output for print operations.\n\n  Defaults to System/out, wrapped in an OutputStreamWriter")

var Lit_3752 *jrt.String = jrt.Intern("A java.io.Writer object representing standard error for print operations.\n\n  Defaults to System/err, wrapped in a PrintWriter")

var Lit_3753 *jrt.String = jrt.Intern("When set to true, output will be flushed whenever a newline is printed.\n\n  Defaults to true.")

var Lit_3754 *jrt.String = jrt.Intern("If set to logical true, when printing an object, its metadata will also\n  be printed in a form that can be read back by the reader.\n\n  Defaults to false.")

var Lit_3755 *jrt.String = jrt.Intern("When set to logical true, objects will be printed in a way that preserves\n  their type when read in later.\n\n  Defaults to false.")

var Lit_3756 *jrt.String = jrt.Intern("When set to logical false, strings and characters will be printed with\n  non-alphanumeric characters converted to the appropriate escape sequences.\n\n  Defaults to true")

var Lit_3757 *jrt.String = jrt.Intern("Defaults to true (or value specified by system property, see below)\n  ***This setting implies that the full power of the reader is in play,\n  including syntax that can cause code to execute. It should never be\n  used with untrusted sources. See also: arbace.edn/read.***\n\n  When set to logical false in the thread-local binding,\n  the eval reader (#=) and record/type literal syntax are disabled in read/load.\n  Example (will fail): (binding [*read-eval* false] (read-string \"#=(* 2 21)\"))\n\n  The default binding can be controlled by the system property\n  'arbace.read.eval' System properties can be set on the command line\n  like this:\n\n  java -Darbace.read.eval=false ...\n\n  The system property can also be set to 'unknown' via\n  -Darbace.read.eval=unknown, in which case the default binding\n  is :unknown and all reads will fail in contexts where *read-eval*\n  has not been explicitly bound to either true or false. This setting\n  can be a useful diagnostic tool to ensure that all of your reads\n  occur in considered contexts. You can also accomplish this in a\n  particular scope by binding *read-eval* to :unknown\n  ")

var Lit_3758 *jrt.String = jrt.Intern("When set to logical false, 'assert' will omit assertion checks in\n  compiled code. Defaults to true.")

var Lit_3759 *jrt.String = jrt.Intern("Fundamental library of the Clojure language")

var Lit_3760 *jrt.String = jrt.Intern("core_proxy")

var Lit_3761 *jrt.String = jrt.Intern("core_bean")

var Lit_3762 *jrt.String = jrt.Intern("core_print")

var Lit_3763 *jrt.String = jrt.Intern("genclass")

var Lit_3764 *jrt.String = jrt.Intern("core_deftype")

var Lit_3765 *jrt.String = jrt.Intern("core/protocols")

var Lit_3766 *jrt.String = jrt.Intern("gvec")

var Lit_3767 *jrt.String = jrt.Intern("instant")

var Lit_3768 *jrt.String = jrt.Intern("1.13.0-master-SNAPSHOT")

var Lit_3769 *jrt.String = jrt.Intern("SNAPSHOT")

var Lit_3770 *jrt.String = jrt.Intern("The version info for Clojure core, as a map containing :major :minor\n  :incremental and :qualifier keys. Feature releases may increment\n  :minor and/or :major, bugfix releases will increment :incremental.\n  Possible values of :qualifier include \"GA\", \"SNAPSHOT\", \"RC-x\" \"BETA-x\"")

var Lit_3771 *jrt.String = jrt.Intern("The version of Arbace: the commit it was built from, as a map:\n  :describe  git describe --tags --always --dirty of the build's checkout (in a tarball,\n             the describe git archive wrote into VERSION), \"unknown\" when neither\n  :commit    the commit's full hash, a string (nil when unknown)\n  :dirty     true when tracked files of the checkout differed from the commit, false in a\n             tarball (nil when unknown)\n  *clojure-version* stays the version of Clojure Arbace derives from, for libraries.")

var Lit_3772 *jrt.String = jrt.Intern("Returns true if num is NaN, else false")

var Lit_3773 *jrt.String = jrt.Intern("Returns true if num is negative or positive infinity, else false")

var Lit_3774 *jrt.String = jrt.Intern("core_classes")
