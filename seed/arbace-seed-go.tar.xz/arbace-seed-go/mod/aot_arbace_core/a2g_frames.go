//line a2g_frames.ae:1
package aot_arbace_core

import "arbace/jrt"


func init() { jrt.RegisterFrames([]jrt.FrameInfo{{"arbace/aot_arbace_core.A_arbace_core_Inst_A_Inst_ms_STAR___O", "arbace.core.Inst", "inst_ms_STAR_", 0}, {"arbace/aot_arbace_core.(*A_arbace_core_VecSeq_A).Internal_reduce_O_O__O", "arbace.core.VecSeq", "internal_reduce", 0}}) }
