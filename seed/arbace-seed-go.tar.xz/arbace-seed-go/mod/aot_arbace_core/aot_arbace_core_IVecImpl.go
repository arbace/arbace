//line aot_arbace_core_IVecImpl.ae:1
package aot_arbace_core

import "arbace/jrt"




type A_arbace_core_IVecImpl_A interface{ jrt.Object_I; Is_A_arbace_core_IVecImpl_A(); Tailoff__I() int32; ArrayFor_I__O(p0 int32) any; PushTail_I_A_arbace_core_VecNode_A_A_arbace_core_VecNode_A__O(p0 int32, p1, p2 *A_arbace_core_VecNode_A) any; PopTail_I_O__O(p0 int32, p1 any) any; NewPath_O_I_O__O(p0 any, p1 int32, p2 any) any; DoAssoc_I_O_I_O__O(p0 int32, p1 any, p2 int32, p3 any) any }

func A_arbace_core_IVecImpl_A_InstanceOf(x any) bool { _, ok := x.(A_arbace_core_IVecImpl_A); if !ok && x != nil && jrt.IsDynamic(x) { d, dyn := x.(jrt.Dynamic); if dyn { ok = d.DynImplements(A_arbace_core_IVecImpl_A_class) } }; return ok }

func A_arbace_core_IVecImpl_A_Cast(x any) A_arbace_core_IVecImpl_A { if x == nil { return nil }; v, ok := x.(A_arbace_core_IVecImpl_A); if ok && jrt.IsDynamic(x) { d, dyn := x.(jrt.Dynamic); if dyn { ok = d.DynImplements(A_arbace_core_IVecImpl_A_class) } }; if !ok { panic(jrt.ClassCast(x, A_arbace_core_IVecImpl_A_class)) }; return v }
