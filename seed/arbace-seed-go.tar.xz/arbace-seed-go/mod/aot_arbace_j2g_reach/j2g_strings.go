//line j2g_strings.ae:1
package aot_arbace_j2g_reach

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn20,arbace.classes.typesyn1,tyn18,arbace.classes.envyn3,envyn22,arbace.classes.analyzeyn1,ayn16,arbace.j2g.modelyn1,myn16,arbace.j2g.namesyn2,nmyn17,arbace.j2g.accessyn3,accyn14,arbace.j2g.jrtyn3,jrtyn22,arbace.classes.opcodesyn7,Opcodesyn11,arbace.corekn3,dockn2,opkn4,ctorkn4,tempkn7,restartkn5,framekn6,methodkn5,fieldkn3,samkn5,scopekn8,boundarykn3,varkn6,hiddenkn1,bkn11,sel-bindingkn4,elsekn8,accessorkn7,patternys11,arbace.core3,letyn20,h__685000056__auto__kn3,tagyn17,java.util.HashMapyn20,k__685000057__auto__yn20,v__685000058__auto__yn4,.getys11,arbace.core4,condys11,arbace.core10,identical?ys16,arbace.j2g.reach4,noneys11,arbace.core4,nil?yn4,.putyn2,ifyn20,h__685000064__auto__yn20,k__685000065__auto__yn20,l__685000066__auto__yn19,java.util.ArrayListyn4,.addyn20,java.util.ArrayList.yn20,v__685000072__auto__yn20,arbace.lang.Volatileyn5,.-curyn22,arbace.j2g.reach.Stateyn23,prev__685000073__auto__yn6,.derefyn6,.resetyn3,tryyn7,finallyyn21,mm__685000079__auto__ys11,arbace.core3,andys11,arbace.core5,zero?ys11,arbace.core7,bit-andys11,arbace.core4,longys11,arbace.core2,orkn5,flagsys16,arbace.j2g.reach19,acc-static-abstractys11,arbace.core3,notys22,arbace.classes.opcodes11,ACC_PRIVATEkn5,superkn7,methodskn4,namekn4,desckn3,jrtkn5,funcskn4,varskn6,constskn7,standinkn15,analysis-failedkn5,statekn10,interfaceskn5,outeryn21,st__685000143__auto__yn20,n__685000144__auto__yn9,.containsyn4,.-trkn4,linekn6,columnyn23,java.util.LinkedHashSetys16,arbace.j2g.reach8,use-slowyn21,st__685000150__auto__yn21,cs__685000151__auto__ys11,arbace.core4,whenyn20,l__685000152__auto__yn14,java.util.Listyn20,T__685000153__auto__ys11,arbace.core7,dotimesyn20,i__685000154__auto__yn5,.sizeyn20,c__685000155__auto__ys11,arbace.core8,when-notyn21,st__685000164__auto__yn20,k__685000165__auto__yn9,.-reachedys16,arbace.j2g.reach8,reach-styn21,st__685000184__auto__yn20,c__685000185__auto__yn8,.-initedyn17,java.util.HashSetys16,arbace.j2g.reach7,init-styn21,st__685000239__auto__yn20,d__685000240__auto__yn6,.-instys16,arbace.j2g.reach14,instantiate-styn21,st__685000255__auto__yn20,k__685000256__auto__yn8,.-vcallsys16,arbace.j2g.reach8,vcall-stkn6,statickn7,handleskn2,vhkn8,declarerkn5,ownerkn4,kindkn4,argskn9,class-litkn5,classkn6,targetkn10,get-statickn6,switchkn5,caseskn4,castkn9,new-arraykn4,typekn9,get-fieldkn9,ctor-callkn11,if-instancekn5,compskn8,java-strkn5,partskn4,nodekn4,nullkn8,for-eachkn5,arraykn9,instance?kn10,array-initkn12,null-checkedkn10,method-refkn5,boundkn3,newkn7,unboundkn2,fikn7,markerskn3,trykn7,catcheskn6,lambdakn7,classeskn9,set-fieldkn10,var-invokekn10,fi-adapterkn9,var-derefkn7,invokerkn12,invoker-desckn10,set-statickn6,invokekn11,array-clonekn9,interfacekn7,virtualkn7,specialkn6,assertkn8,msg-desckn6,labelsyn20,n__685000380__auto__ys16,arbace.j2g.reach10,use-quiet?yn2,doys16,arbace.j2g.reach6,use-styn21,cs__685000386__auto__yn20,l__685000387__auto__yn20,n__685000388__auto__ys11,arbace.core4,loopyn20,i__685000389__auto__yn20,f__685000390__auto__ys11,arbace.core1,<yn20,c__685000391__auto__yn5,recurys11,arbace.core3,incyn20,k__685000397__auto__yn20,c__685000403__auto__yn20,c__685000409__auto__yn20,k__685000415__auto__ys11,arbace.core9,volatile!ys11,arbace.core2,fnkn1,ukn2,gokn2,gskn2,gfkn1,rkn1,vkn1,pkn1,skn2,cckn1,nkn6,clinitkn6,bodieskn8,prologuekn4,callkn11,calls-superkn4,initkn4,bodykn11,uses-assertkn16,interface-assertkn7,derivedkn16,record-canonicalkn12,default-ctorkn6,bridgekn9,bridge-ofkn9,anon-ctorkn10,clj-constskn4,readkn20,record-object-methodkn10,componentskn5,rootskn11,instantiatekn6,slice?kn3,fiskn11,jrt-classeskn1,Tkn7,reachedkn4,instkn11,unavailablekn7,missingkn14,failed-classeskn6,vcallsv11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,V3,R5,R1,R6,V3,R7,R1,R8,V3,R9,R1,R10,V3,R11,R1,R12,V3,R13,R1,R14,V3,R15,R1,R16,V3,R17,R1,R18,v11,arbace.core5,referR19,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn16,arbace.j2g.reachm2,R20,s543,Reachability (JRT-SOURCES.md, the user's decision of 2026-10-08: translate the reached\n  methods, stub the rest): rapid type analysis over the analyzed Java forms from root methods.\n  It decides the translated classes T (classes reached code uses: a class jrt provides stays\n  jrt's, except stand-ins, which translated classes replace), the reached methods (translated;\n  every other method of T is a stub throwing UnsupportedOperationException), and the methods\n  whose code needs something the closed world lacks (stubbed too, and reported).v11,arbace.core4,map?v11,arbace.core9,contains?R21,v11,arbace.core3,seqv11,arbace.core3,notS13,R22,R23,R24,R25,R26,R27,R28,R29,R30,R31,R32,R33,R34,v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core5,firstS13,R22,R23,R24,R25,R26,R27,R28,R29,R30,R31,R32,R33,R34,v11,arbace.core10,chunk-restv11,arbace.core4,nextv16,arbace.j2g.reach5,node?v11,arbace.core11,sequential?R35,S5,R22,R25,R29,R36,R33,S5,R22,R25,R29,R36,R33,S1,R37,S1,R37,v11,arbace.core9,volatile!v11,arbace.core4,atomv16,arbace.j2g.reach6,new-cxv11,arbace.core6,concatv11,arbace.core4,listR38,v11,arbace.core5,applyv11,arbace.core6,vectorv11,arbace.core9,with-metaR39,v11,arbace.core8,hash-mapR40,R41,R42,R43,R44,R45,R46,R47,R48,R38,R49,R50,R48,R47,R38,R51,R41,R52,R53,R54,R44,R50,R55,R38,R56,R55,R49,R38,R57,R58,R59,m2,R40,R60,R61,R62,R63,R64,R65,R63,R38,R66,R67,R68,R69,R70,R71,R72,l0,R73,R74,R68,R69,R70,R71,R75,v16,arbace.j2g.reach4,nonev18,arbace.classes.env14,all-supertypesv18,arbace.classes.env10,interface?v18,arbace.classes.env9,subclass?R76,v18,arbace.classes.env4,infoR77,R78,R79,v11,arbace.core5,some?v16,arbace.j2g.reach14,find-method-ofv16,arbace.j2g.reach10,super-implv16,arbace.j2g.reach8,super-ofv11,arbace.core4,somev11,arbace.core4,not=v16,arbace.j2g.reach9,subclass?v16,arbace.j2g.reach10,all-supersv16,arbace.j2g.reach10,interface?v16,arbace.j2g.reach12,default-implv16,arbace.j2g.reach7,impl-ofv16,arbace.j2g.reach4,*st*v11,arbace.core5,swap!v11,arbace.core6,updatev11,arbace.core4,fnilv16,arbace.j2g.model7,go-namev16,arbace.j2g.names11,method-baseR80,v16,arbace.j2g.model3,*w*R81,v16,arbace.j2g.model11,j2g-static?R82,v16,arbace.j2g.names17,static-field-nameR83,v16,arbace.j2g.model9,jrt-classR84,v16,arbace.j2g.model13,translatable?v22,arbace.classes.analyze4,declR85,R86,v16,arbace.j2g.reach6,use-stv16,arbace.j2g.model22,reflectable-interface?v16,arbace.j2g.reach17,note-unavailable!R87,R88,v13,arbace.string7,replacev16,arbace.j2g.reach10,use-quiet?R38,R89,R60,R90,R50,R91,R92,R93,i326,R94,i21,R95,R96,R38,R97,R60,R98,R99,R38,R100,R101,R102,R95,R92,R103,R104,R105,R38,R106,R44,R107,R91,R96,v11,arbace.core7,string?v16,arbace.j2g.model12,desc-classesv16,arbace.j2g.reach12,desc-classesv16,arbace.j2g.reach8,use-slowR38,R108,R60,R109,R107,R91,R110,i363,i27,R95,R111,v16,arbace.j2g.reach8,reach-stv16,arbace.j2g.reach7,init-stv11,arbace.core3,vecv11,arbace.core6,subvecl1,v11,arbace.core4,intoS2,s6,<init>s8,<clinit>S2,s6,<init>s8,<clinit>R38,R112,R60,R113,R107,R91,R114,i400,R115,R116,v11,arbace.core12,chunk-bufferv16,arbace.j2g.model7,static?v16,arbace.j2g.model8,private?v11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core4,consv11,arbace.core4,restv16,arbace.j2g.reach17,own-external-keysv16,arbace.j2g.reach13,supertypes-ofv16,arbace.j2g.reach13,external-keysv16,arbace.j2g.model14,serialization?v16,arbace.j2g.reach10,supers-setv16,arbace.j2g.model12,serial-hook?v16,arbace.j2g.reach13,serial-reach!v16,arbace.j2g.reach12,reach-impls!R38,R117,R60,R118,R107,R91,R119,i493,R95,R120,v16,arbace.j2g.reach14,instantiate-stv11,arbace.core7,filtervR38,R121,R60,R122,R107,R91,R123,i527,R95,R124,v16,arbace.j2g.reach8,vcall-stv16,arbace.j2g.model14,all-supertypesv16,arbace.j2g.model10,interface?v16,arbace.j2g.model11,abstract-m?v16,arbace.j2g.reach9,lambda-stv16,arbace.j2g.model17,hw-method-exists?v16,arbace.j2g.model13,hand-written?v16,arbace.j2g.model22,throwable-print-helperR125,v16,arbace.j2g.reach14,hw-has-static?v16,arbace.j2g.reach17,hw-method-exists?v16,arbace.j2g.model9,in-world?R126,R127,R128,R129,v11,arbace.core8,to-arrayR130,S5,s9,fullFences13,loadLoadFences12,releaseFences15,storeStoreFences12,acquireFenceR131,R132,v20,arbace.classes.types11,class-desc?R133,v16,arbace.j2g.names6,pkg-ofv20,arbace.classes.types14,desc->internalv17,arbace.j2g.access8,unaccessR134,R135,v16,arbace.j2g.reach9,vh-const?R27,R136,R137,R138,v16,arbace.j2g.reach9,use-desc!R139,R140,R141,R142,R143,R144,R36,R37,R145,R146,R147,v22,arbace.classes.analyze10,value-typev20,arbace.classes.types4,ref?R148,R22,R149,R150,v20,arbace.classes.types6,array?R151,R152,R153,V3,s17,java/util/Objectss14,requireNonNulls38,(Ljava/lang/Object;)Ljava/lang/Object;R154,R155,v16,arbace.j2g.model11,find-methodR156,R157,v16,arbace.j2g.names8,new-nameR158,v16,arbace.j2g.reach10,markers-stR159,R160,R161,R162,R163,R164,R165,R166,v20,arbace.classes.types10,lang-classR167,v20,arbace.classes.types11,method-descv11,arbace.core6,repeatv16,arbace.j2g.reach10,walk-nodesR168,R169,R170,v16,arbace.j2g.reach13,hw-has-field?R171,R26,R172,v16,arbace.j2g.reach8,vh-call?v16,arbace.j2g.model19,method-desc-classesR173,v16,arbace.j2g.reach14,check-hw-call!R174,R175,R176,R177,R178,R38,R179,R45,R91,R180,R181,R182,R38,R183,R50,R38,R184,R101,R185,R105,R186,R187,R188,R50,R189,R38,R190,R44,R45,R91,R191,R192,R180,R191,R192,R181,R182,R191,R192,R38,R193,R50,R91,R110,i766,i32,R95,R181,R111,R38,R194,R50,R91,R114,i769,R115,R181,R116,R38,R195,R50,R91,R119,i772,R95,R181,R120,R38,R196,R50,R91,R123,i775,R95,R181,R124,v11,arbace.core10,repeatedlyv11,arbace.core6,gensymR38,R197,R198,m2,R40,R60,R107,R62,m2,R40,R58,R38,m2,R40,R95,R92,v11,arbace.core10,interleaveR99,R67,R63,m2,R40,R58,v16,arbace.j2g.reach8,internedR199,R200,v16,arbace.j2g.names13,go-class-nameR201,v16,arbace.j2g.reach10,scan-node!R202,R203,v16,arbace.j2g.reach9,hw-owner?R204,R205,R206,R207,R208,v11,arbace.core9,reduce-kvv16,arbace.j2g.reach11,scanned-opsv16,arbace.j2g.reach12,skipped-keysv11,arbace.core6,reducev16,arbace.j2g.reach18,skipped-plain-keysv11,arbace.core4,mapvv16,arbace.j2g.reach9,plan-nodev16,arbace.j2g.reach13,scanned-nodesv16,arbace.j2g.reach10,scan-code*R209,R210,R211,R212,R213,R214,R215,R216,R217,R218,R219,R220,R221,R222,R223,R224,R31,R225,v20,arbace.classes.types9,lang-descR226,R227,V3,s16,java/lang/Objects8,toStrings20,()Ljava/lang/String;V2,s8,toStrings20,()Ljava/lang/String;V3,s16,java/lang/Objects8,hashCodes3,()IV2,s8,hashCodes3,()IV3,s16,java/lang/Objects6,equalss21,(Ljava/lang/Object;)ZV2,s6,equalss21,(Ljava/lang/Object;)ZV3,s16,java/lang/Objects8,toStrings20,()Ljava/lang/String;V2,s8,toStrings20,()Ljava/lang/String;V3,s16,java/lang/Objects8,hashCodes3,()IV2,s8,hashCodes3,()IV3,s16,java/lang/Objects6,equalss21,(Ljava/lang/Object;)ZV2,s6,equalss21,(Ljava/lang/Object;)ZR228,R229,R230,R231,v11,arbace.core10,constantlyv18,arbace.classes.env13,*compile-set*v16,arbace.j2g.reach9,new-stateR232,R233,v16,arbace.j2g.reach12,snapshot-setR234,R235,R236,R237,R238,v11,arbace.core5,assocR239,v11,arbace.core7,ex-infov11,arbace.core19,pop-thread-bindingsv16,arbace.j2g.model8,par-mapvv16,arbace.j2g.model4,jobsv16,arbace.j2g.reach11,method-codeS2,s6,<init>s8,<clinit>S2,s6,<init>s8,<clinit>v16,arbace.j2g.reach9,plan-codev16,arbace.j2g.reach12,scan-method!v11,arbace.core20,push-thread-bindingsv16,arbace.j2g.reach8,*slice?*")

var Lit_1 *jrt.String = jrt.Intern("java/lang/Object")

var Lit_2 *jrt.String = jrt.Intern("arbace.j2g.reach$check_hw_call_BANG_$fn__685000296")

var Lit_3 *jrt.String = jrt.Intern("jrt lacks ")

var Lit_4 *jrt.String = jrt.Intern(".")

var Lit_5 *jrt.String = jrt.Intern("/")

var Lit_6 *jrt.String = jrt.Intern("arbace.j2g.reach$default_impl$fn__685000105")

var Lit_7 *jrt.String = jrt.Intern("arbace.j2g.reach$default_impl$fn__685000105$fn__685000106")

var Lit_8 *jrt.String = jrt.Intern("_")

var Lit_9 *jrt.String = jrt.Intern("arbace.j2g.reach$init_st$fn__685000177")

var Lit_10 *jrt.String = jrt.Intern("arbace.j2g.reach$init_st$fn__685000179")

var Lit_11 *jrt.String = jrt.Intern("<clinit>")

var Lit_12 *jrt.String = jrt.Intern("()V")

var Lit_13 *jrt.String = jrt.Intern("arbace.j2g.reach$init_st$fn__685000181")

var Lit_14 *jrt.String = jrt.Intern("<init>")

var Lit_15 *jrt.String = jrt.Intern("arbace.j2g.reach$own_external_keys$iter__685000192__685000196")

var Lit_16 *jrt.String = jrt.Intern("arbace.j2g.reach$own_external_keys$iter__685000192__685000196$fn__685000197")

var Lit_17 *jrt.String = jrt.Intern("arbace.j2g.reach$own_external_keys$iter__685000192__685000196$fn__685000197$fn__685000198")

var Lit_18 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_code$fn__685000646")

var Lit_19 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000428")

var Lit_20 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000436")

var Lit_21 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000438")

var Lit_22 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000440")

var Lit_23 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000446")

var Lit_24 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000454")

var Lit_25 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000462")

var Lit_26 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000471")

var Lit_27 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000479")

var Lit_28 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000487")

var Lit_29 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000495")

var Lit_30 *jrt.String = jrt.Intern("L")

var Lit_31 *jrt.String = jrt.Intern(";")

var Lit_32 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000504")

var Lit_33 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000518")

var Lit_34 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000520")

var Lit_35 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000534")

var Lit_36 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000536")

var Lit_37 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000550")

var Lit_38 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000564")

var Lit_39 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000566")

var Lit_40 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000580")

var Lit_41 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000582")

var Lit_42 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_43 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000597")

var Lit_44 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000606")

var Lit_45 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000613")

var Lit_46 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000615")

var Lit_47 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000619")

var Lit_48 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000621")

var Lit_49 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000623")

var Lit_50 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000629")

var Lit_51 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000428$fn__685000431")

var Lit_52 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000428$fn__685000431$fn__685000432")

var Lit_53 *jrt.String = jrt.Intern("jrt lacks static field ")

var Lit_54 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000440$fn__685000441")

var Lit_55 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000440$fn__685000441$fn__685000442")

var Lit_56 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000446$fn__685000449")

var Lit_57 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000446$fn__685000449$fn__685000450")

var Lit_58 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000454$fn__685000457")

var Lit_59 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000454$fn__685000457$fn__685000458")

var Lit_60 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000462$fn__685000466")

var Lit_61 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000462$fn__685000466$fn__685000467")

var Lit_62 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000471$fn__685000474")

var Lit_63 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000471$fn__685000474$fn__685000475")

var Lit_64 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000479$fn__685000482")

var Lit_65 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000479$fn__685000482$fn__685000483")

var Lit_66 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000487$fn__685000490")

var Lit_67 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000487$fn__685000490$fn__685000491")

var Lit_68 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000495$fn__685000498")

var Lit_69 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000495$fn__685000498$fn__685000499")

var Lit_70 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000504$fn__685000511")

var Lit_71 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000504$fn__685000511$fn__685000512")

var Lit_72 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000504$fn__685000511$fn__685000514")

var Lit_73 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000520$fn__685000527")

var Lit_74 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000520$fn__685000527$fn__685000528")

var Lit_75 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000520$fn__685000527$fn__685000530")

var Lit_76 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000536$fn__685000543")

var Lit_77 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000536$fn__685000543$fn__685000544")

var Lit_78 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000536$fn__685000543$fn__685000546")

var Lit_79 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000550$fn__685000557")

var Lit_80 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000550$fn__685000557$fn__685000558")

var Lit_81 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000550$fn__685000557$fn__685000560")

var Lit_82 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000566$fn__685000573")

var Lit_83 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000566$fn__685000573$fn__685000574")

var Lit_84 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000566$fn__685000573$fn__685000576")

var Lit_85 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000582$fn__685000590")

var Lit_86 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000582$fn__685000590$fn__685000591")

var Lit_87 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000582$fn__685000590$fn__685000593")

var Lit_88 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000597$fn__685000601")

var Lit_89 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000597$fn__685000601$fn__685000602")

var Lit_90 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000606$fn__685000610")

var Lit_91 *jrt.String = jrt.Intern("jrt lacks constructor ")

var Lit_92 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000615$fn__685000616")

var Lit_93 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000623$fn__685000624")

var Lit_94 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node$fn__685000623$fn__685000624$fn__685000625")

var Lit_95 *jrt.String = jrt.Intern("done")

var Lit_96 *jrt.String = jrt.Intern("arbace.j2g.reach$run$fn__685000713")

var Lit_97 *jrt.String = jrt.Intern("arbace.j2g.reach$run$fn__685000750")

var Lit_98 *jrt.String = jrt.Intern("arbace.j2g.reach$run$fn__685000713$fn__685000736")

var Lit_99 *jrt.String = jrt.Intern("arbace.j2g.reach$run$fn__685000713$fn__685000742")

var Lit_100 *jrt.String = jrt.Intern("j2g reach: the class environment changed during the run")

var Lit_101 *jrt.String = jrt.Intern("analysis failed: ")

var Lit_102 *jrt.String = jrt.Intern("RT")

var Lit_103 *jrt.String = jrt.Intern("var")

var Lit_104 *jrt.String = jrt.Intern("(Ljava/lang/String;Ljava/lang/String;)")

var Lit_105 *jrt.String = jrt.Intern("Var")

var Lit_106 *jrt.String = jrt.Intern("readString")

var Lit_107 *jrt.String = jrt.Intern("(Ljava/lang/String;)Ljava/lang/Object;")

var Lit_108 *jrt.String = jrt.Intern("arbace.j2g.reach$scan_node_BANG_$vcall__685000303")

var Lit_109 *jrt.String = jrt.Intern("Ljava/lang/String;")

var Lit_110 *jrt.String = jrt.Intern("toString")

var Lit_111 *jrt.String = jrt.Intern("()Ljava/lang/String;")

var Lit_112 *jrt.String = jrt.Intern("java/util/Iterator")

var Lit_113 *jrt.String = jrt.Intern("hasNext")

var Lit_114 *jrt.String = jrt.Intern("()Z")

var Lit_115 *jrt.String = jrt.Intern("next")

var Lit_116 *jrt.String = jrt.Intern("()Ljava/lang/Object;")

var Lit_117 *jrt.String = jrt.Intern("java/util/Objects")

var Lit_118 *jrt.String = jrt.Intern("deref")

var Lit_119 *jrt.String = jrt.Intern("getRawRoot")

var Lit_120 *jrt.String = jrt.Intern("IFn")

var Lit_121 *jrt.String = jrt.Intern("invoke")

var Lit_122 *jrt.String = jrt.Intern("Ljava/lang/Object;")

var Lit_123 *jrt.String = jrt.Intern("FnInvokers")

var Lit_124 *jrt.String = jrt.Intern("arbace.j2g.reach$scan_node_BANG_$fn__685000323")

var Lit_125 *jrt.String = jrt.Intern("java/lang/AssertionError")

var Lit_126 *jrt.String = jrt.Intern("(")

var Lit_127 *jrt.String = jrt.Intern(")V")

var Lit_128 *jrt.String = jrt.Intern("")

var Lit_129 *jrt.String = jrt.Intern("arbace.j2g.reach$scan_node_BANG_$pat__685000336")

var Lit_130 *jrt.String = jrt.Intern("arbace.j2g.reach$scan_node_BANG_$pat__685000354")

var Lit_131 *jrt.String = jrt.Intern("arbace.j2g.reach$scan_node_BANG_$pat__685000360")

var Lit_132 *jrt.String = jrt.Intern("arbace.j2g.reach$scan_node_BANG_$pat__685000366")

var Lit_133 *jrt.String = jrt.Intern("arbace.j2g.reach$scan_node_BANG_$pat__685000372")

var Lit_134 *jrt.String = jrt.Intern("arbace.j2g.reach$scanned_nodes$walk__685000632")

var Lit_135 *jrt.String = jrt.Intern("arbace.j2g.reach$scanned_nodes$walk_entry__685000634")

var Lit_136 *jrt.String = jrt.Intern("arbace.j2g.reach$scanned_nodes$walk_val__685000636")

var Lit_137 *jrt.String = jrt.Intern("arbace.j2g.reach$scanned_nodes$walk_elem__685000638")

var Lit_138 *jrt.String = jrt.Intern("arbace.j2g.reach$scanned_nodes$walk_plain__685000640")

var Lit_139 *jrt.String = jrt.Intern("arbace.j2g.reach$scanned_nodes$walk_plain_entry__685000642")

var Lit_140 *jrt.String = jrt.Intern("java/io/Serializable")

var Lit_141 *jrt.String = jrt.Intern("arbace.j2g.reach$serial_reach_BANG_$fn__685000231")

var Lit_142 *jrt.String = jrt.Intern("arbace.j2g.reach$supertypes_of$fn__685000217")

var Lit_143 *jrt.String = jrt.Intern("class ")

var Lit_144 *jrt.String = jrt.Intern(": ")

var Lit_145 *jrt.String = jrt.Intern(" failed analysis")

var Lit_146 *jrt.String = jrt.Intern("<class>")

var Lit_147 *jrt.String = jrt.Intern("arbace.j2g.reach$use_st$fn__685000119")

var Lit_148 *jrt.String = jrt.Intern("superclass ")

var Lit_149 *jrt.String = jrt.Intern(" unavailable")

var Lit_150 *jrt.String = jrt.Intern(": superclass ")

var Lit_151 *jrt.String = jrt.Intern("arbace.j2g.reach$use_st$fn__685000125")

var Lit_152 *jrt.String = jrt.Intern("arbace.j2g.reach$use_st$fn__685000127")

var Lit_153 *jrt.String = jrt.Intern("arbace.j2g.reach$use_st$fn__685000129")

var Lit_154 *jrt.String = jrt.Intern("arbace.j2g.reach$use_st$fn__685000135")

var Lit_155 *jrt.String = jrt.Intern("arbace.j2g.reach$use_st$fn__685000137")

var Lit_156 *jrt.String = jrt.Intern(" is not in the closed world")

var Lit_157 *jrt.String = jrt.Intern("arbace.j2g.reach$vcall_st$fn__685000248")

var Lit_158 *jrt.String = jrt.Intern("java/lang/invoke/VarHandle")

var Lit_159 *jrt.String = jrt.Intern("java/lang/invoke/MethodHandles")

var Lit_160 *jrt.String = jrt.Intern("lookup")

var Lit_161 *jrt.String = jrt.Intern("jdk/internal/jrt/Invokers")

var Lit_162 *jrt.String = jrt.Intern("arbace.j2g.reach$walk_nodes$walk__685000013")

var Lit_163 *jrt.String = jrt.Intern("arbace.j2g.reach$walk_nodes$walk_val__685000025")

var Lit_164 *jrt.String = jrt.Intern("arbace.j2g.reach$walk_nodes$walk_plain__685000031")

var Lit_165 *jrt.String = jrt.Intern("supers")

var Lit_166 *jrt.String = jrt.Intern("tag")

var Lit_167 *jrt.String = jrt.Intern("java.util.HashMap")

var Lit_168 *jrt.String = jrt.Intern("supersOf")

var Lit_169 *jrt.String = jrt.Intern("iface")

var Lit_170 *jrt.String = jrt.Intern("subcls")

var Lit_171 *jrt.String = jrt.Intern("superOf")

var Lit_172 *jrt.String = jrt.Intern("methods")

var Lit_173 *jrt.String = jrt.Intern("superImpl")

var Lit_174 *jrt.String = jrt.Intern("extKeys")

var Lit_175 *jrt.String = jrt.Intern("descClasses")

var Lit_176 *jrt.String = jrt.Intern("hwYes")

var Lit_177 *jrt.String = jrt.Intern("supersSet")

var Lit_178 *jrt.String = jrt.Intern("tr")

var Lit_179 *jrt.String = jrt.Intern("java.util.LinkedHashSet")

var Lit_180 *jrt.String = jrt.Intern("reached")

var Lit_181 *jrt.String = jrt.Intern("queue")

var Lit_182 *jrt.String = jrt.Intern("java.util.ArrayList")

var Lit_183 *jrt.String = jrt.Intern("inst")

var Lit_184 *jrt.String = jrt.Intern("vcalls")

var Lit_185 *jrt.String = jrt.Intern("vcallsBy")

var Lit_186 *jrt.String = jrt.Intern("instBy")

var Lit_187 *jrt.String = jrt.Intern("inited")

var Lit_188 *jrt.String = jrt.Intern("java.util.HashSet")

var Lit_189 *jrt.String = jrt.Intern("unavailable")

var Lit_190 *jrt.String = jrt.Intern("missing")

var Lit_191 *jrt.String = jrt.Intern("failed")

var Lit_192 *jrt.String = jrt.Intern("java.util.LinkedHashMap")

var Lit_193 *jrt.String = jrt.Intern("fis")

var Lit_194 *jrt.String = jrt.Intern("fisBy")

var Lit_195 *jrt.String = jrt.Intern("cx")

var Lit_196 *jrt.String = jrt.Intern("Cx")

var Lit_197 *jrt.String = jrt.Intern("cur")

var Lit_198 *jrt.String = jrt.Intern("arbace.lang.Volatile")

var Lit_199 *jrt.String = jrt.Intern("jc")

var Lit_200 *jrt.String = jrt.Intern("slice")

var Lit_201 *jrt.String = jrt.Intern("cs")

var Lit_202 *jrt.String = jrt.Intern("flat")

var Lit_203 *jrt.String = jrt.Intern("java.util.IdentityHashMap")

var Lit_204 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,arglistsyn1,xkn4,linekn6,columnkn4,fileyn1,fyn4,nodeyn6,supersyn8,supersOfyn5,ifaceyn6,subclsyn7,superOfyn7,methodsyn9,superImplyn7,extKeysyn11,descClassesyn5,hwYesyn9,supersSetkn7,privateyn2,tryn7,reachedyn5,queueyn4,instyn6,vcallsyn8,vcallsByyn6,instByyn6,initedyn11,unavailableyn7,missingyn6,failedyn3,fisyn5,fisByyn2,cxyn3,curyn2,jcyn5,sliceyn2,csyn4,flatyn2,stkn7,dynamicyn1,hyn1,kyn4,expryn1,&yn4,bodykn5,constyn2,mmkn3,tagyn2,Cxyn1,nyn1,ayn1,byn1,cyn1,syn4,nameyn4,desckn2,asyn5,Stateyn3,whyyn3,clsyn5,fnameyn7,static?yn1,dyn2,ndyn1,oyn2,fiyn7,markersyn5,owneryn4,kindkn9,var-derefkn10,array-initkn10,set-statickn10,method-refkn6,lambdakn3,newkn9,get-fieldkn4,castkn9,instance?kn9,class-litkn12,null-checkedkn6,assertkn10,fi-adapterkn9,set-fieldkn9,ctor-callkn11,if-instancekn9,new-arraykn10,get-statickn10,var-invokekn6,invokekn3,trykn8,java-strkn8,for-eachkn6,switchyn1,Tv11,arbace.core5,in-nsMyn16,arbace.j2g.reachm2,R0,s543,Reachability (JRT-SOURCES.md, the user's decision of 2026-10-08: translate the reached\n  methods, stub the rest): rapid type analysis over the analyzed Java forms from root methods.\n  It decides the translated classes T (classes reached code uses: a class jrt provides stays\n  jrt's, except stand-ins, which translated classes replace), the reached methods (translated;\n  every other method of T is a stub throwing UnsupportedOperationException), and the methods\n  whose code needs something the closed world lacks (stubbed too, and reported).m2,R0,s543,Reachability (JRT-SOURCES.md, the user's decision of 2026-10-08: translate the reached\n  methods, stub the rest): rapid type analysis over the analyzed Java forms from root methods.\n  It decides the translated classes T (classes reached code uses: a class jrt provides stays\n  jrt's, except stand-ins, which translated classes replace), the reached methods (translated;\n  every other method of T is a stub throwing UnsupportedOperationException), and the methods\n  whose code needs something the closed world lacks (stubbed too, and reported).R1,v16,arbace.j2g.reach5,node?m8,R2,L1,V1,R3,R4,i21,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach10,walk-nodesm10,R2,L1,V2,R7,R8,R0,s144,Calls (f node) on node and every node in it (operands, branches, bindings, cases, catches,\n  lambda bodies, patterns), each once, parents first.R4,i23,R5,i1,R6,s19,arbace/j2g/reach.aeC19,arbace.j2g.reach.Cxv16,arbace.j2g.reach4,->Cxm10,R2,L1,V11,R9,R10,R11,R12,R13,R14,R15,R16,R17,R18,R19,R0,s58,Positional factory function for class arbace.j2g.reach.Cx.R4,i49,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach6,new-cxm10,R20,TR2,L1,V0,R4,i60,R5,i1,R6,s19,arbace/j2g/reach.aeC22,arbace.j2g.reach.Statev16,arbace.j2g.reach7,->Statem10,R2,L1,V19,R21,R22,R23,R24,R25,R26,R27,R28,R29,R30,R31,R32,R33,R34,R35,R36,R37,R38,R39,R0,s61,Positional factory function for class arbace.j2g.reach.State.R4,i65,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach9,new-statem12,R20,TR2,L1,V4,R40,R36,R37,R38,R0,s168,The state of a run: a new one, or the previous run's st continued (its collections and\n  caches shared), with this run's jrt classes jc, slice and class environment cs.R4,i82,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach4,*st*m10,R41,TR4,i97,R5,i1,R6,s19,arbace/j2g/reach.aeR0,s84,The state of the run (a State), for use!, reach! ... and the ops scan-node! acts on.v16,arbace.j2g.reach8,*slice?*v11,arbace.core10,constantlym10,R41,TR4,i101,R5,i1,R6,s19,arbace/j2g/reach.aeR0,s122,Whether a class's code may be translated in this run (classes outside the slice exist as\n  declarations with stub bodies).v16,arbace.j2g.reach4,nonem10,R20,TR4,i106,R5,i1,R6,s19,arbace/j2g/reach.aeR0,s13,A cached nil.v16,arbace.j2g.reach4,memom12,R20,TR2,L1,V3,R42,R43,R44,R0,s80,The value of expr for key k in the cache h (a java.util.HashMap), computed once.R4,i110,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach7,add-to!m12,R20,TR2,L1,V3,R42,R43,R3,R0,s53,Appends x to the ArrayList of key k in the HashMap h.R4,i120,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach12,with-currentm12,R20,TR2,L1,V4,R40,R43,R45,R46,R0,s54,body with the method being scanned (the notes' key) k.R4,i130,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach19,acc-static-abstractm10,R47,TR20,TR4,i141,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach5,body?m12,R20,TR2,L1,V1,R48,R0,s66,Has method mm (a method or nil) a body (not static, not abstract)?R4,i143,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach8,private?m10,R20,TR2,L1,V1,R48,R4,i148,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach10,all-supersm12,R20,TR2,L1,V2,Myn2,cxm2,R49,R50,R51,R0,s27,env/all-supertypes, cached.R4,i151,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach10,interface?m10,R20,TR2,L1,V2,Myn2,cxm2,R49,R50,R51,R4,i156,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach9,subclass?m12,R20,TR2,L1,V3,Myn2,cxm2,R49,R50,R52,R53,R0,s22,env/subclass?, cached.R4,i158,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach8,super-ofm12,R20,TR2,L1,V2,Myn2,cxm2,R49,R50,R54,R0,s34,The superclass of class c, cached.R4,i168,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach14,find-method-ofm12,R20,TR2,L1,V3,Myn2,cxm2,R49,R50,R54,R43,R0,s182,The first method k ([name desc]) of class c, in env/info's order (each class's methods\n  indexed by [name desc] once: the class environment does not change once the world is loaded).R4,i173,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach10,super-implm12,R20,TR2,L1,V3,Myn2,cxm2,R49,R50,R55,R43,R0,s261,The implementation [c name desc] of method k ([name desc]) in the superclass chain from class\n  s: the first class c with a body of it that is not private, or nil (cached per class and key,\n  the vector too: the chains of many classes share their superclasses).R4,i187,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach12,default-implm12,R20,TR2,L1,V3,Myn2,cxm2,R49,R50,R51,R43,R0,s150,The first, in env/all-supertypes' order, of the most specific interfaces of class n with a\n  default method k ([name desc]), as [c name desc], or nil.R4,i205,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach7,impl-ofm12,R20,TR2,L1,V3,Myn2,cxm2,R49,R50,R51,R43,R0,s32,java-impl-of with the caches cx.R4,i217,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach12,java-impl-ofm10,R2,L1,V2,R51,V4,R56,R57,R58,R43,R0,s366,The [class name desc] implementing virtual method [name desc] for class n (a body in n or a\n  superclass, else an interface's default), by Java's rules on the class environment: the first\n  class of n's superclass chain with a body of it (private only in n itself), else the first,\n  in env/all-supertypes' order, of the most specific interfaces of n with a default.R4,i225,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach17,note-unavailable!m10,R20,TR2,L1,V2,Myn2,stm2,R49,R59,R60,R4,i236,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach14,hw-has-static?m10,R20,TR2,L1,V3,R61,R56,R57,R4,i240,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach13,hw-has-field?m10,R20,TR2,L1,V3,R61,R62,R63,R4,i247,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach6,use-stm12,R20,TR2,L1,V2,Myn2,stm2,R49,R59,R51,R0,s34,use! in the run whose state is st.R4,i255,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach4,use!m10,R2,L1,V1,R51,R0,s161,Makes class n exist in Go (translating it when it can and jrt does not provide it, or jrt\n  provides only a stand-in). Returns false, noting why, when it cannot.R4,i299,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach10,use-quiet?m12,R20,TR2,L1,V2,Myn2,stm2,R49,R59,R51,R0,s167,Is class n (not in T) one use! answers yes for without doing anything, now and from then\n  on: nil, Object, jrt's own class (not a stand-in; such a class never fails)?R4,i305,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach8,use-slowm12,R20,TR2,L1,V2,Myn2,stm2,R49,R59,R51,R0,s99,use* of a class n not in T: at once for nil, Object or jrt's own class (use-quiet?), else\n  use-st.R4,i314,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach4,use*m12,R20,TR2,L1,V2,R40,R51,R0,s114,use! in the run whose state is st: at once for a class already translated (inline: the hot\n  path), else use-slow.R4,i320,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach5,uses!m12,R20,TR2,L1,V2,R40,R38,R0,s53,use* of each class of cs (a vector or nil), in order.R4,i328,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach12,desc-classesm12,R20,TR2,L1,V2,Myn2,cxm2,R49,R50,R64,R0,s36,m/desc-classes, cached for a string.R4,i340,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach9,use-desc!m10,R20,TR2,L1,V2,Myn2,stm2,R49,R59,R64,R4,i345,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach8,reach-stm12,R20,TR2,L1,V2,Myn2,stm2,R49,R59,R43,R0,s36,reach! in the run whose state is st.R4,i348,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach6,reach*m12,R20,TR2,L1,V2,R40,R43,R0,s56,reach-st, at once (inline) for a method already reached.R4,i358,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach6,reach!m10,R2,L1,V1,R43,R0,s65,Marks method [c name desc] reached (its body will be translated).R4,i365,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach7,init-stm12,R20,TR2,L1,V2,Myn2,stm2,R49,R59,R54,R0,s35,init! in the run whose state is st.R4,i370,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach5,init*m12,R20,TR2,L1,V2,R40,R54,R0,s58,init-st, at once (inline) for a class already initialized.R4,i395,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach5,init!m10,R2,L1,V1,R54,R0,s81,Class c is initialized: its static initializer is reached (and its superclass's).R4,i402,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach17,own-external-keysm12,R20,TR2,L1,V2,Myn2,cxm2,R49,R50,R55,R0,s174,The virtual methods of type s that jrt's own code may call when s is Object, a hand-written\n  class or interface of jrt or a class jrt has a stand-in for, else none (cached).R4,i407,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach13,external-keysm12,R20,TR2,L1,V2,Myn2,cxm2,R49,R50,R64,R0,s230,The virtual methods of class d's supertypes that jrt's own code may call: those of Object,\n  of jrt's hand-written classes and interfaces and of the classes jrt has stand-ins for; each\n  once, in the order of its first occurrence.R4,i418,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach13,supertypes-ofm12,R20,TR2,L1,V2,Myn2,cxm2,R49,R50,R64,R0,s89,The types class d is a subtype of (env/subclass?): d, its supertypes and Object (cached).R4,i429,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach10,supers-setm12,R20,TR2,L1,V2,Myn2,cxm2,R49,R50,R64,R0,s187,The types class d is a subtype of (supertypes-of), as a set (cached): (env/subclass? d o) is\n  (contains? (supers-set d) o), env/subclass? walking the same supertypes all-supertypes does.R4,i436,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach12,reach-impls!m12,R20,TR2,L1,V2,Myn2,stm2,R49,R59,R64,R0,s264,Reaches the implementations for class d of the virtual calls whose receiver's static type is\n  a supertype of d (indexed by receiver type: the roots of --program are each a virtual call,\n  about 20,000), then of the methods jrt's own code may call (external-keys).R4,i442,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach13,serial-reach!m12,R20,TR2,L1,V2,Myn2,stm2,R49,R59,R64,R0,s728,JCS167 (doc/classes/JAVA-DEFERRED-TRIAGE.md, \"As built: JCS167 (write-ahead)\"): what\n  serialization calls by reflection on an object of instantiated class d, when serialization is in\n  the world (m/serialization?) and d is Serializable: the serialization hooks (m/serial-hook?:\n  writeObject, readObject, readObjectNoData, writeReplace, readResolve) each class of d's\n  superclass chain declares, and the no-argument constructor of d's first superclass that is not\n  Serializable, which jrt's allocation runs (m/serial-super); an Externalizable's public\n  no-argument constructor is a root of the REPL's world already, and its readExternal and\n  writeExternal virtual calls of ObjectInputStream's and ObjectOutputStream's code.R4,i457,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach14,instantiate-stm12,R20,TR2,L1,V2,Myn2,stm2,R49,R59,R64,R0,s42,instantiate! in the run whose state is st.R4,i477,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach12,instantiate*m12,R20,TR2,L1,V2,R40,R64,R0,s66,instantiate-st, at once (inline) for a class already instantiated.R4,i488,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach12,instantiate!m8,R2,L1,V1,R64,R4,i495,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach8,vcall-stm12,R20,TR2,L1,V3,Myn2,stm2,R49,R59,R43,R65,R0,s72,vcall! in the run whose state is st, of k [o name desc], nd [name desc].R4,i499,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach6,vcall*m12,R20,TR2,L1,V3,R40,R43,R65,R0,s51,vcall-st, at once (inline) for a call already seen.R4,i522,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach6,vcall!m10,R2,L1,V3,R66,R56,R57,R0,s61,A virtual call of [name desc] on a receiver of static type o.R4,i529,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach9,lambda-stm12,R20,TR2,L1,V2,Myn2,stm2,R49,R59,R67,R0,s37,lambda! in the run whose state is st.R4,i534,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach10,markers-stm12,R20,TR2,L1,V2,Myn2,stm2,R49,R59,R68,R0,s240,The marker interfaces of a lambda or method reference whose target is an intersection: used,\n  and their default methods (and their superinterfaces') reached, which its adapter implements\n  (out/adapter-forms; JCS118 (a), \"As built: JC4c\").R4,i541,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach7,lambda!m10,R2,L1,V1,R67,R0,s135,A lambda or method reference of functional interface fi: its adapter is an instance of fi,\n  whose default methods virtual calls reach.R4,i554,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach17,hw-method-exists?m12,R20,TR2,L1,V3,Myn2,stm2,R49,R59,R51,R48,R0,s181,m/hw-method-exists? of class n and method mm; its yes for a class not translated kept (jrt's\n  Go name of the class and its scan do not change, and what j2g adds only grows with T).R4,i560,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach14,check-hw-call!m12,R20,TR2,L1,V5,Myn2,stm2,R49,R59,R69,R56,R57,R70,R0,s65,A call of a method of jrt's hand-written class: jrt must have it.R4,i573,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach9,vh-const?m12,R20,TR2,L1,V1,R7,R0,s61,Is field f a constant VarHandle of the world (J2G-SPEC §8.5)?R4,i588,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach8,vh-call?m12,R20,TR2,L1,V1,R8,R0,s177,A VarHandle call j2g compiles statically (J2G-SPEC §8.5): a fence, MethodHandles.lookup(),\n  or an access mode on a constant handle; it names no class of java.lang.invoke in Go.R4,i593,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach10,scan-node!m10,R20,TR2,L1,V1,R8,R4,i610,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach11,scanned-opsS24,R71,R72,R73,R74,R75,R76,R77,R78,R79,R80,R81,R82,R83,R84,R85,R86,R87,R88,R89,R90,R91,R92,R93,R94,m10,R20,TR4,i730,R5,i1,R6,s19,arbace/j2g/reach.aeR0,s90,The ops scan-node! acts on (an accessor's call, an :invoke, may stand for a field access).v16,arbace.j2g.reach9,hw-owner?m12,R20,TR2,L1,V1,R54,R0,s74,Can a call of a method of class c need check-hw-call! (does jrt define c)?R4,i736,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach8,fast-usem12,R20,TR2,L1,V3,R40,R95,R51,R0,s69,use* of class n, true when it took the fast path (n in T: no effect).R4,i741,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach9,fast-usesm12,R20,TR2,L1,V3,R40,R95,R38,R0,s47,uses! of cs, true when each took the fast path.R4,i749,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach10,fast-reachm10,R20,TR2,L1,V2,R40,R43,R4,i765,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach9,fast-initm10,R20,TR2,L1,V2,R40,R54,R4,i768,R5,i1,R6,s19,arbace/j2g/reach.ae")

var Lit_205 *jrt.String = jrt.Intern("arbace.j2g.reach$eval685000004$loading__1927001464__auto____685000005")

var Lit_206 *jrt.String = jrt.Intern("arbace.j2g.reach$eval685000008$fn__685000009")

var Lit_207 *jrt.String = jrt.Intern("arbace.j2g.reach$node_QMARK_")

var Lit_208 *jrt.String = jrt.Intern("arbace.j2g.reach$walk_nodes")

var Lit_209 *jrt.String = jrt.Intern("arbace.j2g.reach.Cx")

var Lit_210 *jrt.String = jrt.Intern("arbace.j2g.reach$eval685000044$__GT_Cx__685000046")

var Lit_211 *jrt.String = jrt.Intern("arbace.j2g.reach$new_cx")

var Lit_212 *jrt.String = jrt.Intern("arbace.j2g.reach.State")

var Lit_213 *jrt.String = jrt.Intern("arbace.j2g.reach$eval685000050$__GT_State__685000052")

var Lit_214 *jrt.String = jrt.Intern("arbace.j2g.reach$new_state")

var Lit_215 *jrt.String = jrt.Intern("arbace.j2g.reach$memo")

var Lit_216 *jrt.String = jrt.Intern("arbace.j2g.reach$add_to_BANG_")

var Lit_217 *jrt.String = jrt.Intern("arbace.j2g.reach$with_current")

var Lit_218 *jrt.String = jrt.Intern("arbace.j2g.reach$body_QMARK_")

var Lit_219 *jrt.String = jrt.Intern("arbace.j2g.reach$private_QMARK_")

var Lit_220 *jrt.String = jrt.Intern("arbace.j2g.reach$all_supers")

var Lit_221 *jrt.String = jrt.Intern("arbace.j2g.reach$interface_QMARK_")

var Lit_222 *jrt.String = jrt.Intern("arbace.j2g.reach$subclass_QMARK_")

var Lit_223 *jrt.String = jrt.Intern("arbace.j2g.reach$super_of")

var Lit_224 *jrt.String = jrt.Intern("arbace.j2g.reach$find_method_of")

var Lit_225 *jrt.String = jrt.Intern("arbace.j2g.reach$super_impl")

var Lit_226 *jrt.String = jrt.Intern("arbace.j2g.reach$default_impl")

var Lit_227 *jrt.String = jrt.Intern("arbace.j2g.reach$impl_of")

var Lit_228 *jrt.String = jrt.Intern("arbace.j2g.reach$java_impl_of")

var Lit_229 *jrt.String = jrt.Intern("arbace.j2g.reach$note_unavailable_BANG_")

var Lit_230 *jrt.String = jrt.Intern("arbace.j2g.reach$hw_has_static_QMARK_")

var Lit_231 *jrt.String = jrt.Intern("arbace.j2g.reach$hw_has_field_QMARK_")

var Lit_232 *jrt.String = jrt.Intern("arbace.j2g.reach$use_st")

var Lit_233 *jrt.String = jrt.Intern("arbace.j2g.reach$use_BANG_")

var Lit_234 *jrt.String = jrt.Intern("arbace.j2g.reach$use_quiet_QMARK_")

var Lit_235 *jrt.String = jrt.Intern("arbace.j2g.reach$use_slow")

var Lit_236 *jrt.String = jrt.Intern("arbace.j2g.reach$use_STAR_")

var Lit_237 *jrt.String = jrt.Intern("arbace.j2g.reach$uses_BANG_")

var Lit_238 *jrt.String = jrt.Intern("arbace.j2g.reach$desc_classes")

var Lit_239 *jrt.String = jrt.Intern("arbace.j2g.reach$use_desc_BANG_")

var Lit_240 *jrt.String = jrt.Intern("arbace.j2g.reach$reach_st")

var Lit_241 *jrt.String = jrt.Intern("arbace.j2g.reach$reach_STAR_")

var Lit_242 *jrt.String = jrt.Intern("arbace.j2g.reach$reach_BANG_")

var Lit_243 *jrt.String = jrt.Intern("arbace.j2g.reach$init_st")

var Lit_244 *jrt.String = jrt.Intern("arbace.j2g.reach$init_STAR_")

var Lit_245 *jrt.String = jrt.Intern("arbace.j2g.reach$init_BANG_")

var Lit_246 *jrt.String = jrt.Intern("arbace.j2g.reach$own_external_keys")

var Lit_247 *jrt.String = jrt.Intern("arbace.j2g.reach$external_keys")

var Lit_248 *jrt.String = jrt.Intern("arbace.j2g.reach$supertypes_of")

var Lit_249 *jrt.String = jrt.Intern("arbace.j2g.reach$supers_set")

var Lit_250 *jrt.String = jrt.Intern("arbace.j2g.reach$reach_impls_BANG_")

var Lit_251 *jrt.String = jrt.Intern("arbace.j2g.reach$serial_reach_BANG_")

var Lit_252 *jrt.String = jrt.Intern("arbace.j2g.reach$instantiate_st")

var Lit_253 *jrt.String = jrt.Intern("arbace.j2g.reach$instantiate_STAR_")

var Lit_254 *jrt.String = jrt.Intern("arbace.j2g.reach$instantiate_BANG_")

var Lit_255 *jrt.String = jrt.Intern("arbace.j2g.reach$vcall_st")

var Lit_256 *jrt.String = jrt.Intern("arbace.j2g.reach$vcall_STAR_")

var Lit_257 *jrt.String = jrt.Intern("arbace.j2g.reach$vcall_BANG_")

var Lit_258 *jrt.String = jrt.Intern("arbace.j2g.reach$lambda_st")

var Lit_259 *jrt.String = jrt.Intern("arbace.j2g.reach$markers_st")

var Lit_260 *jrt.String = jrt.Intern("arbace.j2g.reach$lambda_BANG_")

var Lit_261 *jrt.String = jrt.Intern("arbace.j2g.reach$hw_method_exists_QMARK_")

var Lit_262 *jrt.String = jrt.Intern("arbace.j2g.reach$check_hw_call_BANG_")

var Lit_263 *jrt.String = jrt.Intern("arbace.j2g.reach$vh_const_QMARK_")

var Lit_264 *jrt.String = jrt.Intern("arbace.j2g.reach$vh_call_QMARK_")

var Lit_265 *jrt.String = jrt.Intern("arbace.j2g.reach$scan_node_BANG_")

var Lit_266 *jrt.String = jrt.Intern("arbace.j2g.reach$hw_owner_QMARK_")

var Lit_267 *jrt.String = jrt.Intern("arbace.j2g.reach$fast_use")

var Lit_268 *jrt.String = jrt.Intern("arbace.j2g.reach$fast_uses")

var Lit_269 *jrt.String = jrt.Intern("arbace.j2g.reach$fast_reach")

var Lit_270 *jrt.String = jrt.Intern("arbace.j2g.reach$fast_init")

var Lit_271 *jrt.String = jrt.Intern("kn7,privatekn8,arglistsyn2,styn1,ckn4,linekn6,columnkn4,fileyn1,kyn2,ndyn1,Tyn1,&yn6,checkskn3,dockn3,tagyn38,java.util.concurrent.ConcurrentHashMapyn3,keyyn2,mkyn2,ixyn3,preyn4,nodekn4,ctorkn4,tempkn7,restartkn5,framekn6,methodkn5,fieldkn3,samkn5,scopekn8,boundarykn3,varkn6,hiddenkn1,bkn11,sel-bindingkn8,accessoryn5,Stateyn4,nameyn4,desckn2,asyn4,codeyn1,skn4,keysyn5,rootsyn11,instantiateyn7,classesyn6,slice?yn3,fisyn5,statev16,arbace.j2g.reach9,fast-instm10,R0,TR1,L1,V2,R2,R3,R4,i771,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach10,fast-vcallm10,R0,TR1,L1,V3,R2,R7,R8,R4,i774,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach9,plan-oncem12,R0,TR1,L1,V4,R2,R9,R10,R11,R12,s334,A plan (fn [st]) running checks, each a form true when it took the fast path (no effect), in\n  order, all of them each time, until a run where all took it: the state only grows (a class\n  in T stays there once use! returns), so they would again, and the plan is skipped from then\n  on. st and T name the state and its T in the checks.R4,i777,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach8,internedm12,R0,TR1,L1,V3,Myn2,ixm2,R13,R14,R15,R16,R12,s118,The plan of key in ix (a ConcurrentHashMap: nodes of the same key, in any method, share it),\n  made by mk when absent.R4,i792,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach9,plan-nodem12,R0,TR1,L1,V3,R17,R18,R19,R12,s648,scan-node! of node as a function of the run's state st, its answers that depend only on the\n  class environment and the world (which do not change during the run) computed ahead: the\n  descriptors' classes, the keys, the accessor's node, whether jrt defines a member. Pure: the\n  plans of a batch are made in parallel (no cache of the run: st's are one thread's), then run\n  one after another, each doing what scan-node! does, in the same order. The common ops; the\n  others run scan-node! itself. A plan that cannot note anything (no jrt member to check) is\n  shared by the nodes of the same key (ix) and skipped once it had no effect (plan-once).R4,i800,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach12,skipped-keysS13,R20,R21,R22,R23,R24,R25,R26,R27,R28,R29,R30,R31,R32,m10,R0,TR4,i941,R5,i1,R6,s19,arbace/j2g/reach.aeR12,s49,The keys of a node walk-nodes does not walk into.v16,arbace.j2g.reach18,skipped-plain-keysS5,R20,R23,R27,R33,R31,m10,R0,TR4,i945,R5,i1,R6,s19,arbace/j2g/reach.aeR12,s93,The keys of a plain map in a node (a catch, a case, a pattern) walk-nodes does not walk into.v16,arbace.j2g.reach13,scanned-nodesm12,R0,TR1,L1,V1,R19,R12,s201,The nodes of node scan-node! acts on, in walk-nodes' order (its walk, with reduce-kv and\n  reduce rather than seqs of the maps' entries: a map's kv-reduce visits its entries in the\n  order of its seq).R4,i949,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach9,plan-codem12,R0,TR1,L1,V3,R17,R18,R19,R12,s90,The plans of the nodes of node scan-node! acts on, in walk-nodes' order (ix: plan-node's).R4,i980,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach10,scan-code*m12,R0,TR1,L1,V2,Myn2,stm2,R13,R34,R19,R12,s85,scan-code! in the run whose state is st: the plans of node (plan-code), run in order.R4,i985,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach10,scan-code!m8,R1,L1,V1,R19,R4,i992,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach11,method-codem10,R1,L1,V1,V3,R3,R35,R36,R12,s83,The analyzed code of method [c name desc] of a translated class: a vector of nodes.R4,i995,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach12,scan-method!m12,R0,TR1,L1,V3,Myn2,stm2,R13,R34,V5,R3,R35,R36,R37,R7,R38,R12,s49,Scans method k, whose code (method-code) is code.R4,i1007,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach12,snapshot-setm12,R0,TR1,L1,V1,R39,R12,s172,The persistent set of the elements of s, conj'ed in s's order (the order the run added them:\n  the same set, and the same seq, as the atoms of persistent sets gave before).R4,i1048,R5,i1,R6,s19,arbace/j2g/reach.aev16,arbace.j2g.reach3,runm10,R1,L1,V1,m2,R40,V6,R41,R42,R43,R44,R45,R46,R12,s478,Reachability from roots (method keys [class name desc]; classes to instantiate\n  :instantiate; functional interfaces with adapters :fis). Returns {:T #{} :reached #{} :inst #{} :unavailable {k #{why}} :missing {}\n  :state st}. With :state, a previous run's st, the run goes on from where that one ended:\n  reachability is monotone, so a run from more roots is the previous one continued from the\n  new ones (standalone S6: main's stand-in loop runs the closure once, not twice).R4,i1054,R5,i1,R6,s19,arbace/j2g/reach.ae")

var Lit_272 *jrt.String = jrt.Intern("arbace.j2g.reach$fast_inst")

var Lit_273 *jrt.String = jrt.Intern("arbace.j2g.reach$fast_vcall")

var Lit_274 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_once")

var Lit_275 *jrt.String = jrt.Intern("arbace.j2g.reach$interned")

var Lit_276 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_node")

var Lit_277 *jrt.String = jrt.Intern("arbace.j2g.reach$scanned_nodes")

var Lit_278 *jrt.String = jrt.Intern("arbace.j2g.reach$plan_code")

var Lit_279 *jrt.String = jrt.Intern("arbace.j2g.reach$scan_code_STAR_")

var Lit_280 *jrt.String = jrt.Intern("arbace.j2g.reach$scan_code_BANG_")

var Lit_281 *jrt.String = jrt.Intern("arbace.j2g.reach$method_code")

var Lit_282 *jrt.String = jrt.Intern("arbace.j2g.reach$scan_method_BANG_")

var Lit_283 *jrt.String = jrt.Intern("arbace.j2g.reach$snapshot_set")

var Lit_284 *jrt.String = jrt.Intern("arbace.j2g.reach$run")
