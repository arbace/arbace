//line aot_arbace_j2g_reach_State.ae:1
package aot_arbace_j2g_reach

import (
	"arbace/jrt"
	"arbace/lang"
)


























































func A_arbace_j2g_reach_State_A_New_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18 any) *A_arbace_j2g_reach_State_A { t := &A_arbace_j2g_reach_State_A{}; t.Ctor_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18); return t }
//line :65:1
func (t *A_arbace_j2g_reach_State_A) Ctor_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O(tr, reached, queue, inst, vcalls, vcallsBy, instBy, inited, unavailable, missing, failed, fis, fisBy, cx, cur, jc, slice, cs, flat any) { t.F_tr = tr; t.F_reached = reached; t.F_queue = queue; t.F_inst = inst; t.F_vcalls = vcalls; t.F_vcallsBy = vcallsBy; t.F_instBy = instBy; t.F_inited = inited; t.F_unavailable = unavailable; t.F_missing = missing; t.F_failed = failed; t.F_fis = fis; t.F_fisBy = fisBy; t.F_cx = cx; t.F_cur = cur; t.F_jc = jc; t.F_slice = slice; t.F_cs = cs; t.F_flat = flat }
//line :65:1
func A_arbace_j2g_reach_State_A_GetBasis__IPersistentVector() lang.IPersistentVector { return lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_171)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_159).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_172).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_173)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_159).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_172).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_174)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_159).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_175).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_176)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_159).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_172).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_177)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_159).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_172).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_178)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_159).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_160).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_179)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_159).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_160).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_180)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_159).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_181).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_182).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_183).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_184)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_159).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_185).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_186).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_187)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_159).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_160).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_188)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_159).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_189).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_190)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_159).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_191).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_192).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_193).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_194).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_195)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_159).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_196).Ref()))))) }







type A_arbace_j2g_reach_State_A struct{ jrt.Object; F_tr, F_reached, F_queue, F_inst, F_vcalls, F_vcallsBy, F_instBy, F_inited, F_unavailable, F_missing, F_failed, F_fis, F_fisBy, F_cx, F_cur, F_jc, F_slice, F_cs, F_flat any }

func (t *A_arbace_j2g_reach_State_A) Is_IType() {}

func (t *A_arbace_j2g_reach_State_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_reach_State_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_reach_State_A_class }

func (t *A_arbace_j2g_reach_State_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_reach_State_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_reach_State_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_reach_State_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_reach_State_A); return ok }

func A_arbace_j2g_reach_State_A_Cast(x any) *A_arbace_j2g_reach_State_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_reach_State_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_reach_State_A_class)) }; return v }
