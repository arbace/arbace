//line aot_arbace_j2g_reach__init.ae:1
package aot_arbace_j2g_reach

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_reach__init_part0_A_Unit0__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_j2g_reach__init_part0_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_reach__init_part0_A_const_1) }
//line :1:1
func A_arbace_j2g_reach__init_part0_A_Unit1__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_j2g_reach__init_part0_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_2)) }
//line :1:1
func A_arbace_j2g_reach__init_part0_A_Unit2__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_j2g_reach_eval685000004_loading__1927001464__auto____685000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_j2g_reach_eval685000004_loading__1927001464__auto____685000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_202, false, nil); A_arbace_j2g_reach_eval685000004_loading__1927001464__auto____685000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_j2g_reach__init_part0_A_Unit3__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_j2g_reach__init_part0_A_const_1)).Equals_O__Z(A_arbace_j2g_reach__init_part0_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_j2g_reach_eval685000008_fn__685000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_j2g_reach_eval685000008_fn__685000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_203, false, nil); A_arbace_j2g_reach_eval685000008_fn__685000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }
//line :1:1
func A_arbace_j2g_reach__init_part0_A_Init__O() any { A_arbace_j2g_reach__init_part0_A_Init(); return nil }
//line :1:1
func A_arbace_j2g_reach__init_part0_A_Load__O() any { A_arbace_j2g_reach__init_part0_A_Init(); A_arbace_j2g_reach__init_part0_A_Unit0__O(); A_arbace_j2g_reach__init_part0_A_Unit1__O(); A_arbace_j2g_reach__init_part0_A_Unit2__O(); A_arbace_j2g_reach__init_part0_A_Unit3__O(); A_arbace_j2g_reach__init_part0_A_Unit4__O(); A_arbace_j2g_reach__init_part0_A_Unit5__O(); A_arbace_j2g_reach__init_part0_A_Unit6__O(); A_arbace_j2g_reach__init_part0_A_Unit7__O(); A_arbace_j2g_reach__init_part0_A_Unit8__O(); A_arbace_j2g_reach__init_part0_A_Unit9__O(); A_arbace_j2g_reach__init_part0_A_Unit10__O(); A_arbace_j2g_reach__init_part0_A_Unit11__O(); A_arbace_j2g_reach__init_part0_A_Unit12__O(); A_arbace_j2g_reach__init_part0_A_Unit13__O(); A_arbace_j2g_reach__init_part0_A_Unit14__O(); A_arbace_j2g_reach__init_part0_A_Unit15__O(); A_arbace_j2g_reach__init_part0_A_Unit16__O(); A_arbace_j2g_reach__init_part0_A_Unit17__O(); A_arbace_j2g_reach__init_part0_A_Unit18__O(); A_arbace_j2g_reach__init_part0_A_Unit19__O(); A_arbace_j2g_reach__init_part0_A_Unit20__O(); A_arbace_j2g_reach__init_part0_A_Unit21__O(); A_arbace_j2g_reach__init_part0_A_Unit22__O(); A_arbace_j2g_reach__init_part0_A_Unit23__O(); A_arbace_j2g_reach__init_part0_A_Unit24__O(); A_arbace_j2g_reach__init_part0_A_Unit25__O(); A_arbace_j2g_reach__init_part0_A_Unit26__O(); A_arbace_j2g_reach__init_part0_A_Unit27__O(); A_arbace_j2g_reach__init_part0_A_Unit28__O(); A_arbace_j2g_reach__init_part0_A_Unit29__O(); A_arbace_j2g_reach__init_part0_A_Unit30__O(); A_arbace_j2g_reach__init_part0_A_Unit31__O(); A_arbace_j2g_reach__init_part0_A_Unit32__O(); A_arbace_j2g_reach__init_part0_A_Unit33__O(); A_arbace_j2g_reach__init_part0_A_Unit34__O(); A_arbace_j2g_reach__init_part0_A_Unit35__O(); A_arbace_j2g_reach__init_part0_A_Unit36__O(); A_arbace_j2g_reach__init_part0_A_Unit37__O(); A_arbace_j2g_reach__init_part0_A_Unit38__O(); A_arbace_j2g_reach__init_part0_A_Unit39__O(); A_arbace_j2g_reach__init_part0_A_Unit40__O(); A_arbace_j2g_reach__init_part0_A_Unit41__O(); A_arbace_j2g_reach__init_part0_A_Unit42__O(); A_arbace_j2g_reach__init_part0_A_Unit43__O(); A_arbace_j2g_reach__init_part0_A_Unit44__O(); A_arbace_j2g_reach__init_part0_A_Unit45__O(); A_arbace_j2g_reach__init_part0_A_Unit46__O(); A_arbace_j2g_reach__init_part0_A_Unit47__O(); A_arbace_j2g_reach__init_part0_A_Unit48__O(); A_arbace_j2g_reach__init_part0_A_Unit49__O(); A_arbace_j2g_reach__init_part0_A_Unit50__O(); A_arbace_j2g_reach__init_part0_A_Unit51__O(); A_arbace_j2g_reach__init_part0_A_Unit52__O(); A_arbace_j2g_reach__init_part0_A_Unit53__O(); A_arbace_j2g_reach__init_part0_A_Unit54__O(); A_arbace_j2g_reach__init_part0_A_Unit55__O(); A_arbace_j2g_reach__init_part0_A_Unit56__O(); A_arbace_j2g_reach__init_part0_A_Unit57__O(); A_arbace_j2g_reach__init_part0_A_Unit58__O(); A_arbace_j2g_reach__init_part0_A_Unit59__O(); A_arbace_j2g_reach__init_part0_A_Unit60__O(); A_arbace_j2g_reach__init_part0_A_Unit61__O(); A_arbace_j2g_reach__init_part0_A_Unit62__O(); A_arbace_j2g_reach__init_part0_A_Unit63__O(); A_arbace_j2g_reach__init_part0_A_Unit64__O(); A_arbace_j2g_reach__init_part0_A_Unit65__O(); A_arbace_j2g_reach__init_part0_A_Unit66__O(); A_arbace_j2g_reach__init_part0_A_Unit67__O(); A_arbace_j2g_reach__init_part0_A_Unit68__O(); A_arbace_j2g_reach__init_part0_A_Unit69__O(); A_arbace_j2g_reach__init_part0_A_Unit70__O(); A_arbace_j2g_reach__init_part0_A_Unit71__O(); A_arbace_j2g_reach__init_part0_A_Unit72__O(); A_arbace_j2g_reach__init_part0_A_Unit73__O(); A_arbace_j2g_reach__init_part0_A_Unit74__O(); A_arbace_j2g_reach__init_part0_A_Unit75__O(); A_arbace_j2g_reach__init_part0_A_Unit76__O(); A_arbace_j2g_reach__init_part0_A_Unit77__O(); A_arbace_j2g_reach__init_part0_A_Unit78__O(); A_arbace_j2g_reach__init_part0_A_Unit79__O(); A_arbace_j2g_reach__init_part0_A_Unit80__O(); A_arbace_j2g_reach__init_part0_A_Unit81__O(); A_arbace_j2g_reach__init_part0_A_Unit82__O(); A_arbace_j2g_reach__init_part0_A_Unit83__O(); A_arbace_j2g_reach__init_part0_A_Unit84__O(); A_arbace_j2g_reach__init_part0_A_Unit85__O(); A_arbace_j2g_reach__init_part0_A_Unit86__O(); A_arbace_j2g_reach__init_part0_A_Unit87__O(); A_arbace_j2g_reach__init_part0_A_Unit88__O(); A_arbace_j2g_reach__init_part0_A_Unit89__O(); A_arbace_j2g_reach__init_part0_A_Unit90__O(); A_arbace_j2g_reach__init_part0_A_Unit91__O(); A_arbace_j2g_reach__init_part0_A_Unit92__O(); A_arbace_j2g_reach__init_part0_A_Unit93__O(); A_arbace_j2g_reach__init_part0_A_Unit94__O(); A_arbace_j2g_reach__init_part0_A_Unit95__O(); A_arbace_j2g_reach__init_part0_A_Unit96__O(); A_arbace_j2g_reach__init_part0_A_Unit97__O(); A_arbace_j2g_reach__init_part0_A_Unit98__O(); A_arbace_j2g_reach__init_part0_A_Unit99__O(); return nil }



func A_arbace_j2g_reach__init_A_Load__O() any { jrt.StartCheck(); A_arbace_j2g_reach__init_part0_A_Init__O(); A_arbace_j2g_reach__init_part1_A_Init__O(); A_arbace_j2g_reach__init_part0_A_Load__O(); A_arbace_j2g_reach__init_part1_A_Load__O(); return nil }















func A_arbace_j2g_reach__init_part0_A_Unit4__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(21, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_4; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_j2g_reach_node_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_j2g_reach_node_QMARK__A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_204, false, nil); A_arbace_j2g_reach_node_QMARK__A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_5)); return A_arbace_j2g_reach__init_part0_A_const_4 }

func A_arbace_j2g_reach__init_part0_A_Unit5__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(23, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_j2g_reach_walk_nodes_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_j2g_reach_walk_nodes_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_205, false, nil); A_arbace_j2g_reach_walk_nodes_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_7)); return A_arbace_j2g_reach__init_part0_A_const_6 }

























func A_arbace_j2g_reach__init_part0_A_Unit6__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(49, 1); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_206)); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_9; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_10)); var tmp2 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_9; var tmp3 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_j2g_reach_eval685000044___GT_Cx__685000046_A_New(); var tmp4 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_j2g_reach_eval685000044___GT_Cx__685000046_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_207, false, nil); A_arbace_j2g_reach_eval685000044___GT_Cx__685000046_A_fn_class = fncls__9d; tmp4 = fncls__9d } else { tmp4 = fncls__9 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp4, nil); tmp2.BindRoot_O__V(tmp3.Ref()); return A_arbace_j2g_reach__init_part0_A_const_8 }










func A_arbace_j2g_reach__init_part0_A_Unit7__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(60, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_11; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_j2g_reach_new_cx_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_j2g_reach_new_cx_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_208, false, nil); A_arbace_j2g_reach_new_cx_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_12)); return A_arbace_j2g_reach__init_part0_A_const_11 }




func A_arbace_j2g_reach__init_part0_A_Unit8__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(65, 1); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_209)); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_14; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_15)); var tmp2 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_14; var tmp3 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_j2g_reach_eval685000050___GT_State__685000052_A_New(); var tmp4 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_j2g_reach_eval685000050___GT_State__685000052_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_210, false, nil); A_arbace_j2g_reach_eval685000050___GT_State__685000052_A_fn_class = fncls__13d; tmp4 = fncls__13d } else { tmp4 = fncls__13 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp4, nil); tmp2.BindRoot_O__V(tmp3.Ref()); return A_arbace_j2g_reach__init_part0_A_const_13 }
















func A_arbace_j2g_reach__init_part0_A_Unit9__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(82, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_16; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_j2g_reach_new_state_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_j2g_reach_new_state_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_211, false, nil); A_arbace_j2g_reach_new_state_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_17)); return A_arbace_j2g_reach__init_part0_A_const_16 }














func A_arbace_j2g_reach__init_part0_A_Unit10__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(97, 1); A_arbace_j2g_reach__init_part0_A_const_18.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_18; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_19)); return A_arbace_j2g_reach__init_part0_A_const_18.SetDynamic_Z__Var(true).Ref() }



func A_arbace_j2g_reach__init_part0_A_Unit11__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_20; var tmp2 any; var root_17 any = A_arbace_j2g_reach__init_part0_A_const_21.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_17, aot_arbace_core.A_arbace_core_constantly_A_fn_class); var ifn_19 lang.IFn; if


	linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any = jrt.Boolean_TRUE.Ref(); if linked_18 == nil { tmp2 = ifn_19.Invoke_O__O(arg_20) } else { tmp2 = linked_18.(*aot_arbace_core.A_arbace_core_constantly_A).Invoke_O_O__O(root_17, arg_20) }; /*line :101:1*/tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_20; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_22)); return A_arbace_j2g_reach__init_part0_A_const_20.SetDynamic_Z__Var(true).Ref() }




func A_arbace_j2g_reach__init_part0_A_Unit12__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(106, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_23; tmp1.BindRoot_O__V(jrt.Object_New()); var tmp2 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_23; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_24)); return A_arbace_j2g_reach__init_part0_A_const_23 }



func A_arbace_j2g_reach__init_part0_A_Unit13__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(110, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_25; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_j2g_reach_memo_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_j2g_reach_memo_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_212, false, nil); A_arbace_j2g_reach_memo_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_26)); return A_arbace_j2g_reach__init_part0_A_const_25 }
//line :110:1
func A_arbace_j2g_reach__init_part0_A_Unit14__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(110, 1); A_arbace_j2g_reach__init_part0_A_const_25.SetMacro__V(); return nil }
//line :110:1
func A_arbace_j2g_reach__init_part0_A_Unit15__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(110, 1); return A_arbace_j2g_reach__init_part0_A_const_25 }









func A_arbace_j2g_reach__init_part0_A_Unit16__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(120, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_27; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_j2g_reach_add_to_BANG__A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_j2g_reach_add_to_BANG__A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_213, false, nil); A_arbace_j2g_reach_add_to_BANG__A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_28)); return A_arbace_j2g_reach__init_part0_A_const_27 }
//line :120:1
func A_arbace_j2g_reach__init_part0_A_Unit17__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(120, 1); A_arbace_j2g_reach__init_part0_A_const_27.SetMacro__V(); return nil }
//line :120:1
func A_arbace_j2g_reach__init_part0_A_Unit18__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(120, 1); return A_arbace_j2g_reach__init_part0_A_const_27 }









func A_arbace_j2g_reach__init_part0_A_Unit19__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(130, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_29; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__26 any = A_arbace_j2g_reach_with_current_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_j2g_reach_with_current_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_214, true, nil); A_arbace_j2g_reach_with_current_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__26, tmp3, nil, 4); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_30)); return A_arbace_j2g_reach__init_part0_A_const_29 }
//line :130:1
func A_arbace_j2g_reach__init_part0_A_Unit20__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(130, 1); A_arbace_j2g_reach__init_part0_A_const_29.SetMacro__V(); return nil }
//line :130:1
func A_arbace_j2g_reach__init_part0_A_Unit21__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(130, 1); return A_arbace_j2g_reach__init_part0_A_const_29 }










func A_arbace_j2g_reach__init_part0_A_Unit22__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(141, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_31; tmp1.BindRoot_O__V(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Or_J_J__J_NoInit(8, 1024)).Ref()); var tmp2 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_31; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_32)); return A_arbace_j2g_reach__init_part0_A_const_31 }

func A_arbace_j2g_reach__init_part0_A_Unit23__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(143, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_33; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_j2g_reach_body_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_j2g_reach_body_QMARK__A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_215, false, nil); A_arbace_j2g_reach_body_QMARK__A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_33; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_34)); return A_arbace_j2g_reach__init_part0_A_const_33 }
//line :143:1
func A_arbace_j2g_reach__init_part0_A_Unit24__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(143, 1); A_arbace_j2g_reach__init_part0_A_const_33.SetMacro__V(); return nil }
//line :143:1
func A_arbace_j2g_reach__init_part0_A_Unit25__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(143, 1); return A_arbace_j2g_reach__init_part0_A_const_33 }




func A_arbace_j2g_reach__init_part0_A_Unit26__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(148, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_35; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_j2g_reach_private_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_j2g_reach_private_QMARK__A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_216, false, nil); A_arbace_j2g_reach_private_QMARK__A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_35; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_36)); return A_arbace_j2g_reach__init_part0_A_const_35 }
//line :148:1
func A_arbace_j2g_reach__init_part0_A_Unit27__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(148, 1); A_arbace_j2g_reach__init_part0_A_const_35.SetMacro__V(); return nil }
//line :148:1
func A_arbace_j2g_reach__init_part0_A_Unit28__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(148, 1); return A_arbace_j2g_reach__init_part0_A_const_35 }


func A_arbace_j2g_reach__init_part0_A_Unit29__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(151, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_37; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_j2g_reach_all_supers_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_j2g_reach_all_supers_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_217, false, nil); A_arbace_j2g_reach_all_supers_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_38)); return A_arbace_j2g_reach__init_part0_A_const_37 }




func A_arbace_j2g_reach__init_part0_A_Unit30__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(156, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_39; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_j2g_reach_interface_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_j2g_reach_interface_QMARK__A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_218, false, nil); A_arbace_j2g_reach_interface_QMARK__A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_40)); return A_arbace_j2g_reach__init_part0_A_const_39 }

func A_arbace_j2g_reach__init_part0_A_Unit31__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(158, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_41; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_j2g_reach_subclass_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_j2g_reach_subclass_QMARK__A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_219, false, nil); A_arbace_j2g_reach_subclass_QMARK__A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_42)); return A_arbace_j2g_reach__init_part0_A_const_41 }









func A_arbace_j2g_reach__init_part0_A_Unit32__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(168, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_43; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_j2g_reach_super_of_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_j2g_reach_super_of_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_220, false, nil); A_arbace_j2g_reach_super_of_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_44)); return A_arbace_j2g_reach__init_part0_A_const_43 }




func A_arbace_j2g_reach__init_part0_A_Unit33__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(173, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_45; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_j2g_reach_find_method_of_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_j2g_reach_find_method_of_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_221, false, nil); A_arbace_j2g_reach_find_method_of_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_46)); return A_arbace_j2g_reach__init_part0_A_const_45 }













func A_arbace_j2g_reach__init_part0_A_Unit34__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(187, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_47; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_j2g_reach_super_impl_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_j2g_reach_super_impl_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_222, false, nil); A_arbace_j2g_reach_super_impl_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_48)); return A_arbace_j2g_reach__init_part0_A_const_47 }

















func A_arbace_j2g_reach__init_part0_A_Unit35__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(205, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_49; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_j2g_reach_default_impl_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_j2g_reach_default_impl_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_223, false, nil); A_arbace_j2g_reach_default_impl_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_50)); return A_arbace_j2g_reach__init_part0_A_const_49 }











func A_arbace_j2g_reach__init_part0_A_Unit36__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(217, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_51; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_j2g_reach_impl_of_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_j2g_reach_impl_of_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_224, false, nil); A_arbace_j2g_reach_impl_of_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_52)); return A_arbace_j2g_reach__init_part0_A_const_51 }







func A_arbace_j2g_reach__init_part0_A_Unit37__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(225, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_53; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_j2g_reach_java_impl_of_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_j2g_reach_java_impl_of_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_225, false, nil); A_arbace_j2g_reach_java_impl_of_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_54)); return A_arbace_j2g_reach__init_part0_A_const_53 }










func A_arbace_j2g_reach__init_part0_A_Unit38__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(236, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_55; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_j2g_reach_note_unavailable_BANG__A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_j2g_reach_note_unavailable_BANG__A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_226, false, nil); A_arbace_j2g_reach_note_unavailable_BANG__A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_56)); return A_arbace_j2g_reach__init_part0_A_const_55 }



func A_arbace_j2g_reach__init_part0_A_Unit39__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(240, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_57; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_j2g_reach_hw_has_static_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_j2g_reach_hw_has_static_QMARK__A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_227, false, nil); A_arbace_j2g_reach_hw_has_static_QMARK__A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_58)); return A_arbace_j2g_reach__init_part0_A_const_57 }






func A_arbace_j2g_reach__init_part0_A_Unit40__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(247, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_59; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_j2g_reach_hw_has_field_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_j2g_reach_hw_has_field_QMARK__A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_228, false, nil); A_arbace_j2g_reach_hw_has_field_QMARK__A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_60)); return A_arbace_j2g_reach__init_part0_A_const_59 }







func A_arbace_j2g_reach__init_part0_A_Unit41__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(255, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_61; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_j2g_reach_use_st_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_j2g_reach_use_st_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_229, false, nil); A_arbace_j2g_reach_use_st_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_62)); return A_arbace_j2g_reach__init_part0_A_const_61 }











































func A_arbace_j2g_reach__init_part0_A_Unit42__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(299, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_63; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_j2g_reach_use_BANG__A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_j2g_reach_use_BANG__A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_230, false, nil); A_arbace_j2g_reach_use_BANG__A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_64)); return A_arbace_j2g_reach__init_part0_A_const_63 }





func A_arbace_j2g_reach__init_part0_A_Unit43__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(305, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_65; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_j2g_reach_use_quiet_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_j2g_reach_use_quiet_QMARK__A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_231, false, nil); A_arbace_j2g_reach_use_quiet_QMARK__A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_66)); return A_arbace_j2g_reach__init_part0_A_const_65 }








func A_arbace_j2g_reach__init_part0_A_Unit44__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(314, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_67; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_j2g_reach_use_slow_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_j2g_reach_use_slow_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_232, false, nil); A_arbace_j2g_reach_use_slow_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_68)); return A_arbace_j2g_reach__init_part0_A_const_67 }





func A_arbace_j2g_reach__init_part0_A_Unit45__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(320, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_69; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_j2g_reach_use_STAR__A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_j2g_reach_use_STAR__A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_233, false, nil); A_arbace_j2g_reach_use_STAR__A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_70)); return A_arbace_j2g_reach__init_part0_A_const_69 }
//line :320:1
func A_arbace_j2g_reach__init_part0_A_Unit46__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(320, 1); A_arbace_j2g_reach__init_part0_A_const_69.SetMacro__V(); return nil }
//line :320:1
func A_arbace_j2g_reach__init_part0_A_Unit47__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(320, 1); return A_arbace_j2g_reach__init_part0_A_const_69 }







func A_arbace_j2g_reach__init_part0_A_Unit48__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(328, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_71; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_j2g_reach_uses_BANG__A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_j2g_reach_uses_BANG__A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_234, false, nil); A_arbace_j2g_reach_uses_BANG__A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_72)); return A_arbace_j2g_reach__init_part0_A_const_71 }
//line :328:1
func A_arbace_j2g_reach__init_part0_A_Unit49__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(328, 1); A_arbace_j2g_reach__init_part0_A_const_71.SetMacro__V(); return nil }
//line :328:1
func A_arbace_j2g_reach__init_part0_A_Unit50__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(328, 1); return A_arbace_j2g_reach__init_part0_A_const_71 }











func A_arbace_j2g_reach__init_part0_A_Unit51__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(340, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_73; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_j2g_reach_desc_classes_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_j2g_reach_desc_classes_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_235, false, nil); A_arbace_j2g_reach_desc_classes_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_74)); return A_arbace_j2g_reach__init_part0_A_const_73 }




func A_arbace_j2g_reach__init_part0_A_Unit52__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(345, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_75; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_j2g_reach_use_desc_BANG__A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_j2g_reach_use_desc_BANG__A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_236, false, nil); A_arbace_j2g_reach_use_desc_BANG__A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_75; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_76)); return A_arbace_j2g_reach__init_part0_A_const_75 }


func A_arbace_j2g_reach__init_part0_A_Unit53__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(348, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_77; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_j2g_reach_reach_st_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_j2g_reach_reach_st_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_237, false, nil); A_arbace_j2g_reach_reach_st_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_77; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_78)); return A_arbace_j2g_reach__init_part0_A_const_77 }









func A_arbace_j2g_reach__init_part0_A_Unit54__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(358, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_79; var tmp2 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_j2g_reach_reach_STAR__A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_j2g_reach_reach_STAR__A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_238, false, nil); A_arbace_j2g_reach_reach_STAR__A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_79; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_80)); return A_arbace_j2g_reach__init_part0_A_const_79 }
//line :358:1
func A_arbace_j2g_reach__init_part0_A_Unit55__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(358, 1); A_arbace_j2g_reach__init_part0_A_const_79.SetMacro__V(); return nil }
//line :358:1
func A_arbace_j2g_reach__init_part0_A_Unit56__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(358, 1); return A_arbace_j2g_reach__init_part0_A_const_79 }






func A_arbace_j2g_reach__init_part0_A_Unit57__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(365, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_81; var tmp2 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_j2g_reach_reach_BANG__A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_j2g_reach_reach_BANG__A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_239, false, nil); A_arbace_j2g_reach_reach_BANG__A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_81; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_82)); return A_arbace_j2g_reach__init_part0_A_const_81 }




func A_arbace_j2g_reach__init_part0_A_Unit58__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(370, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_83; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_j2g_reach_init_st_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_j2g_reach_init_st_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_240, false, nil); A_arbace_j2g_reach_init_st_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_83; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_84)); return A_arbace_j2g_reach__init_part0_A_const_83 }
























func A_arbace_j2g_reach__init_part0_A_Unit59__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(395, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_85; var tmp2 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_j2g_reach_init_STAR__A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_j2g_reach_init_STAR__A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_241, false, nil); A_arbace_j2g_reach_init_STAR__A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_85; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_86)); return A_arbace_j2g_reach__init_part0_A_const_85 }
//line :395:1
func A_arbace_j2g_reach__init_part0_A_Unit60__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(395, 1); A_arbace_j2g_reach__init_part0_A_const_85.SetMacro__V(); return nil }
//line :395:1
func A_arbace_j2g_reach__init_part0_A_Unit61__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(395, 1); return A_arbace_j2g_reach__init_part0_A_const_85 }






func A_arbace_j2g_reach__init_part0_A_Unit62__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(402, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_87; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_j2g_reach_init_BANG__A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_j2g_reach_init_BANG__A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_242, false, nil); A_arbace_j2g_reach_init_BANG__A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_87; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_88)); return A_arbace_j2g_reach__init_part0_A_const_87 }




func A_arbace_j2g_reach__init_part0_A_Unit63__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(407, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_89; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_j2g_reach_own_external_keys_A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_j2g_reach_own_external_keys_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_243, false, nil); A_arbace_j2g_reach_own_external_keys_A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_89; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_90)); return A_arbace_j2g_reach__init_part0_A_const_89 }










func A_arbace_j2g_reach__init_part0_A_Unit64__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(418, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_91; var tmp2 *lang.Compiler_AOTFn; var fnbody__86 any = A_arbace_j2g_reach_external_keys_A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_j2g_reach_external_keys_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_244, false, nil); A_arbace_j2g_reach_external_keys_A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__86, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_91; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_92)); return A_arbace_j2g_reach__init_part0_A_const_91 }










func A_arbace_j2g_reach__init_part0_A_Unit65__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(429, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_93; var tmp2 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_j2g_reach_supertypes_of_A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_j2g_reach_supertypes_of_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_245, false, nil); A_arbace_j2g_reach_supertypes_of_A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_93; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_94)); return A_arbace_j2g_reach__init_part0_A_const_93 }






func A_arbace_j2g_reach__init_part0_A_Unit66__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(436, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_95; var tmp2 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_j2g_reach_supers_set_A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_j2g_reach_supers_set_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_246, false, nil); A_arbace_j2g_reach_supers_set_A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_95; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_96)); return A_arbace_j2g_reach__init_part0_A_const_95 }





func A_arbace_j2g_reach__init_part0_A_Unit67__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(442, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_97; var tmp2 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_j2g_reach_reach_impls_BANG__A_New(); var tmp3 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_j2g_reach_reach_impls_BANG__A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_247, false, nil); A_arbace_j2g_reach_reach_impls_BANG__A_fn_class = fncls__91d; tmp3 = fncls__91d } else { tmp3 = fncls__91 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_97; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_98)); return A_arbace_j2g_reach__init_part0_A_const_97 }














func A_arbace_j2g_reach__init_part0_A_Unit68__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(457, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_99; var tmp2 *lang.Compiler_AOTFn; var fnbody__94 any = A_arbace_j2g_reach_instantiate_st_A_New(); var tmp3 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_j2g_reach_instantiate_st_A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_248, false, nil); A_arbace_j2g_reach_instantiate_st_A_fn_class = fncls__93d; tmp3 = fncls__93d } else { tmp3 = fncls__93 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__94, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_99; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_100)); return A_arbace_j2g_reach__init_part0_A_const_99 }









func A_arbace_j2g_reach__init_part0_A_Unit69__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(467, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_101; var tmp2 *lang.Compiler_AOTFn; var fnbody__96 any = A_arbace_j2g_reach_instantiate_STAR__A_New(); var tmp3 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_j2g_reach_instantiate_STAR__A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_249, false, nil); A_arbace_j2g_reach_instantiate_STAR__A_fn_class = fncls__95d; tmp3 = fncls__95d } else { tmp3 = fncls__95 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_101; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_102)); return A_arbace_j2g_reach__init_part0_A_const_101 }
//line :467:1
func A_arbace_j2g_reach__init_part0_A_Unit70__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(467, 1); A_arbace_j2g_reach__init_part0_A_const_101.SetMacro__V(); return nil }
//line :467:1
func A_arbace_j2g_reach__init_part0_A_Unit71__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(467, 1); return A_arbace_j2g_reach__init_part0_A_const_101 }






func A_arbace_j2g_reach__init_part0_A_Unit72__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(474, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_103; var tmp2 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_j2g_reach_instantiate_BANG__A_New(); var tmp3 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_j2g_reach_instantiate_BANG__A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_250, false, nil); A_arbace_j2g_reach_instantiate_BANG__A_fn_class = fncls__97d; tmp3 = fncls__97d } else { tmp3 = fncls__97 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_103; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_104)); return A_arbace_j2g_reach__init_part0_A_const_103 }



func A_arbace_j2g_reach__init_part0_A_Unit73__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(478, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_105; var tmp2 *lang.Compiler_AOTFn; var fnbody__100 any = A_arbace_j2g_reach_vcall_st_A_New(); var tmp3 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_j2g_reach_vcall_st_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_251, false, nil); A_arbace_j2g_reach_vcall_st_A_fn_class = fncls__99d; tmp3 = fncls__99d } else { tmp3 = fncls__99 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_105; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_106)); return A_arbace_j2g_reach__init_part0_A_const_105 }






















func A_arbace_j2g_reach__init_part0_A_Unit74__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(501, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_107; var tmp2 *lang.Compiler_AOTFn; var fnbody__102 any = A_arbace_j2g_reach_vcall_STAR__A_New(); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_j2g_reach_vcall_STAR__A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_252, false, nil); A_arbace_j2g_reach_vcall_STAR__A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_107; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_108)); return A_arbace_j2g_reach__init_part0_A_const_107 }
//line :501:1
func A_arbace_j2g_reach__init_part0_A_Unit75__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(501, 1); A_arbace_j2g_reach__init_part0_A_const_107.SetMacro__V(); return nil }
//line :501:1
func A_arbace_j2g_reach__init_part0_A_Unit76__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(501, 1); return A_arbace_j2g_reach__init_part0_A_const_107 }






func A_arbace_j2g_reach__init_part0_A_Unit77__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(508, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_109; var tmp2 *lang.Compiler_AOTFn; var fnbody__104 any = A_arbace_j2g_reach_vcall_BANG__A_New(); var tmp3 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_j2g_reach_vcall_BANG__A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_253, false, nil); A_arbace_j2g_reach_vcall_BANG__A_fn_class = fncls__103d; tmp3 = fncls__103d } else { tmp3 = fncls__103 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__104, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_109; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_110)); return A_arbace_j2g_reach__init_part0_A_const_109 }




func A_arbace_j2g_reach__init_part0_A_Unit78__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(513, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_111; var tmp2 *lang.Compiler_AOTFn; var fnbody__106 any = A_arbace_j2g_reach_lambda_st_A_New(); var tmp3 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_j2g_reach_lambda_st_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_254, false, nil); A_arbace_j2g_reach_lambda_st_A_fn_class = fncls__105d; tmp3 = fncls__105d } else { tmp3 = fncls__105 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_111; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_112)); return A_arbace_j2g_reach__init_part0_A_const_111 }






func A_arbace_j2g_reach__init_part0_A_Unit79__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(520, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_113; var tmp2 *lang.Compiler_AOTFn; var fnbody__108 any = A_arbace_j2g_reach_markers_st_A_New(); var tmp3 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_j2g_reach_markers_st_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_255, false, nil); A_arbace_j2g_reach_markers_st_A_fn_class = fncls__107d; tmp3 = fncls__107d } else { tmp3 = fncls__107 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__108, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_113; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_114)); return A_arbace_j2g_reach__init_part0_A_const_113 }












func A_arbace_j2g_reach__init_part0_A_Unit80__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(533, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_115; var tmp2 *lang.Compiler_AOTFn; var fnbody__110 any = A_arbace_j2g_reach_lambda_BANG__A_New(); var tmp3 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_j2g_reach_lambda_BANG__A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_256, false, nil); A_arbace_j2g_reach_lambda_BANG__A_fn_class = fncls__109d; tmp3 = fncls__109d } else { tmp3 = fncls__109 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__110, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_115; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_116)); return A_arbace_j2g_reach__init_part0_A_const_115 }





func A_arbace_j2g_reach__init_part0_A_Unit81__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(539, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_117; var tmp2 *lang.Compiler_AOTFn; var fnbody__112 any = A_arbace_j2g_reach_hw_method_exists_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_j2g_reach_hw_method_exists_QMARK__A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_257, false, nil); A_arbace_j2g_reach_hw_method_exists_QMARK__A_fn_class = fncls__111d; tmp3 = fncls__111d } else { tmp3 = fncls__111 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__112, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_117; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_118)); return A_arbace_j2g_reach__init_part0_A_const_117 }












func A_arbace_j2g_reach__init_part0_A_Unit82__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(552, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_119; var tmp2 *lang.Compiler_AOTFn; var fnbody__114 any = A_arbace_j2g_reach_check_hw_call_BANG__A_New(); var tmp3 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_j2g_reach_check_hw_call_BANG__A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_258, false, nil); A_arbace_j2g_reach_check_hw_call_BANG__A_fn_class = fncls__113d; tmp3 = fncls__113d } else { tmp3 = fncls__113 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__114, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_119; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_120)); return A_arbace_j2g_reach__init_part0_A_const_119 }














func A_arbace_j2g_reach__init_part0_A_Unit83__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(567, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_121; var tmp2 *lang.Compiler_AOTFn; var fnbody__116 any = A_arbace_j2g_reach_vh_const_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_j2g_reach_vh_const_QMARK__A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_259, false, nil); A_arbace_j2g_reach_vh_const_QMARK__A_fn_class = fncls__115d; tmp3 = fncls__115d } else { tmp3 = fncls__115 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__116, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_121; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_122)); return A_arbace_j2g_reach__init_part0_A_const_121 }




func A_arbace_j2g_reach__init_part0_A_Unit84__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(572, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_123; var tmp2 *lang.Compiler_AOTFn; var fnbody__118 any = A_arbace_j2g_reach_vh_call_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_j2g_reach_vh_call_QMARK__A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_260, false, nil); A_arbace_j2g_reach_vh_call_QMARK__A_fn_class = fncls__117d; tmp3 = fncls__117d } else { tmp3 = fncls__117 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__118, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_123; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_124)); return A_arbace_j2g_reach__init_part0_A_const_123 }











func A_arbace_j2g_reach__init_part0_A_Unit85__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(584, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_125; var tmp2 *lang.Compiler_AOTFn; var fnbody__120 any = A_arbace_j2g_reach_scan_node_BANG__A_New(); var tmp3 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_j2g_reach_scan_node_BANG__A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_261, false, nil); A_arbace_j2g_reach_scan_node_BANG__A_fn_class = fncls__119d; tmp3 = fncls__119d } else { tmp3 = fncls__119 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__120, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_125; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_126)); return A_arbace_j2g_reach__init_part0_A_const_125 }























































































































func A_arbace_j2g_reach__init_part0_A_Unit86__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(704, 1); A_arbace_j2g_reach__init_part0_A_const_127.BindRoot_O__V(A_arbace_j2g_reach__init_part0_A_const_128); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_127; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_129)); return A_arbace_j2g_reach__init_part0_A_const_127 }





func A_arbace_j2g_reach__init_part0_A_Unit87__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(710, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_130; var tmp2 *lang.Compiler_AOTFn; var fnbody__122 any = A_arbace_j2g_reach_hw_owner_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_j2g_reach_hw_owner_QMARK__A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_262, false, nil); A_arbace_j2g_reach_hw_owner_QMARK__A_fn_class = fncls__121d; tmp3 = fncls__121d } else { tmp3 = fncls__121 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__122, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_130; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_131)); return A_arbace_j2g_reach__init_part0_A_const_130 }




func A_arbace_j2g_reach__init_part0_A_Unit88__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(715, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_132; var tmp2 *lang.Compiler_AOTFn; var fnbody__124 any = A_arbace_j2g_reach_fast_use_A_New(); var tmp3 *jrt.Class; var fncls__123 *jrt.Class = A_arbace_j2g_reach_fast_use_A_fn_class; if fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_263, false, nil); A_arbace_j2g_reach_fast_use_A_fn_class = fncls__123d; tmp3 = fncls__123d } else { tmp3 = fncls__123 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__124, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_132; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_133)); return A_arbace_j2g_reach__init_part0_A_const_132 }
//line :715:1
func A_arbace_j2g_reach__init_part0_A_Unit89__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(715, 1); A_arbace_j2g_reach__init_part0_A_const_132.SetMacro__V(); return nil }
//line :715:1
func A_arbace_j2g_reach__init_part0_A_Unit90__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(715, 1); return A_arbace_j2g_reach__init_part0_A_const_132 }







func A_arbace_j2g_reach__init_part0_A_Unit91__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(723, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_134; var tmp2 *lang.Compiler_AOTFn; var fnbody__126 any = A_arbace_j2g_reach_fast_uses_A_New(); var tmp3 *jrt.Class; var fncls__125 *jrt.Class = A_arbace_j2g_reach_fast_uses_A_fn_class; if fncls__125 == nil { var fncls__125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_264, false, nil); A_arbace_j2g_reach_fast_uses_A_fn_class = fncls__125d; tmp3 = fncls__125d } else { tmp3 = fncls__125 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__126, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_134; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_135)); return A_arbace_j2g_reach__init_part0_A_const_134 }
//line :723:1
func A_arbace_j2g_reach__init_part0_A_Unit92__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(723, 1); A_arbace_j2g_reach__init_part0_A_const_134.SetMacro__V(); return nil }
//line :723:1
func A_arbace_j2g_reach__init_part0_A_Unit93__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(723, 1); return A_arbace_j2g_reach__init_part0_A_const_134 }















func A_arbace_j2g_reach__init_part0_A_Unit94__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(739, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_136; var tmp2 *lang.Compiler_AOTFn; var fnbody__128 any = A_arbace_j2g_reach_fast_reach_A_New(); var tmp3 *jrt.Class; var fncls__127 *jrt.Class = A_arbace_j2g_reach_fast_reach_A_fn_class; if fncls__127 == nil { var fncls__127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_265, false, nil); A_arbace_j2g_reach_fast_reach_A_fn_class = fncls__127d; tmp3 = fncls__127d } else { tmp3 = fncls__127 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__128, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_136; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_137)); return A_arbace_j2g_reach__init_part0_A_const_136 }
//line :739:1
func A_arbace_j2g_reach__init_part0_A_Unit95__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(739, 1); A_arbace_j2g_reach__init_part0_A_const_136.SetMacro__V(); return nil }
//line :739:1
func A_arbace_j2g_reach__init_part0_A_Unit96__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(739, 1); return A_arbace_j2g_reach__init_part0_A_const_136 }


func A_arbace_j2g_reach__init_part0_A_Unit97__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(742, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_138; var tmp2 *lang.Compiler_AOTFn; var fnbody__130 any = A_arbace_j2g_reach_fast_init_A_New(); var tmp3 *jrt.Class; var fncls__129 *jrt.Class = A_arbace_j2g_reach_fast_init_A_fn_class; if fncls__129 == nil { var fncls__129d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_266, false, nil); A_arbace_j2g_reach_fast_init_A_fn_class = fncls__129d; tmp3 = fncls__129d } else { tmp3 = fncls__129 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__130, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part0_A_const_138; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part0_A_const_139)); return A_arbace_j2g_reach__init_part0_A_const_138 }
//line :742:1
func A_arbace_j2g_reach__init_part0_A_Unit98__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(742, 1); A_arbace_j2g_reach__init_part0_A_const_138.SetMacro__V(); return nil }
//line :742:1
func A_arbace_j2g_reach__init_part0_A_Unit99__O() any { A_arbace_j2g_reach__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(742, 1); return A_arbace_j2g_reach__init_part0_A_const_138 }


func A_arbace_j2g_reach__init_part1_A_Unit100__O() any { A_arbace_j2g_reach__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(745, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part1_A_const_0; var tmp2 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_j2g_reach_fast_inst_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_j2g_reach_fast_inst_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_268, false, nil); A_arbace_j2g_reach_fast_inst_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part1_A_const_0; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part1_A_const_1)); return A_arbace_j2g_reach__init_part1_A_const_0 }
//line :745:1
func A_arbace_j2g_reach__init_part1_A_Unit101__O() any { A_arbace_j2g_reach__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(745, 1); A_arbace_j2g_reach__init_part1_A_const_0.SetMacro__V(); return nil }
//line :745:1
func A_arbace_j2g_reach__init_part1_A_Unit102__O() any { A_arbace_j2g_reach__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(745, 1); return A_arbace_j2g_reach__init_part1_A_const_0 }
//line :745:1
func A_arbace_j2g_reach__init_part1_A_Init__O() any { A_arbace_j2g_reach__init_part1_A_Init(); return nil }
//line :745:1
func A_arbace_j2g_reach__init_part1_A_Load__O() any { A_arbace_j2g_reach__init_part1_A_Init(); A_arbace_j2g_reach__init_part1_A_Unit100__O(); A_arbace_j2g_reach__init_part1_A_Unit101__O(); A_arbace_j2g_reach__init_part1_A_Unit102__O(); A_arbace_j2g_reach__init_part1_A_Unit103__O(); A_arbace_j2g_reach__init_part1_A_Unit104__O(); A_arbace_j2g_reach__init_part1_A_Unit105__O(); A_arbace_j2g_reach__init_part1_A_Unit106__O(); A_arbace_j2g_reach__init_part1_A_Unit107__O(); A_arbace_j2g_reach__init_part1_A_Unit108__O(); A_arbace_j2g_reach__init_part1_A_Unit109__O(); A_arbace_j2g_reach__init_part1_A_Unit110__O(); A_arbace_j2g_reach__init_part1_A_Unit111__O(); A_arbace_j2g_reach__init_part1_A_Unit112__O(); A_arbace_j2g_reach__init_part1_A_Unit113__O(); A_arbace_j2g_reach__init_part1_A_Unit114__O(); A_arbace_j2g_reach__init_part1_A_Unit115__O(); A_arbace_j2g_reach__init_part1_A_Unit116__O(); A_arbace_j2g_reach__init_part1_A_Unit117__O(); A_arbace_j2g_reach__init_part1_A_Unit118__O(); A_arbace_j2g_reach__init_part1_A_Unit119__O(); A_arbace_j2g_reach__init_part1_A_Unit120__O(); return nil }


func A_arbace_j2g_reach__init_part1_A_Unit103__O() any { A_arbace_j2g_reach__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(748, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part1_A_const_2; var tmp2 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_j2g_reach_fast_vcall_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_j2g_reach_fast_vcall_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_269, false, nil); A_arbace_j2g_reach_fast_vcall_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part1_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part1_A_const_3)); return A_arbace_j2g_reach__init_part1_A_const_2 }
//line :748:1
func A_arbace_j2g_reach__init_part1_A_Unit104__O() any { A_arbace_j2g_reach__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(748, 1); A_arbace_j2g_reach__init_part1_A_const_2.SetMacro__V(); return nil }
//line :748:1
func A_arbace_j2g_reach__init_part1_A_Unit105__O() any { A_arbace_j2g_reach__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(748, 1); return A_arbace_j2g_reach__init_part1_A_const_2 }


func A_arbace_j2g_reach__init_part1_A_Unit106__O() any { A_arbace_j2g_reach__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(751, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part1_A_const_4; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__6 any = A_arbace_j2g_reach_plan_once_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_j2g_reach_plan_once_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_270, true, nil); A_arbace_j2g_reach_plan_once_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__6, tmp3, nil, 4); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part1_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part1_A_const_5)); return A_arbace_j2g_reach__init_part1_A_const_4 }
//line :751:1
func A_arbace_j2g_reach__init_part1_A_Unit107__O() any { A_arbace_j2g_reach__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(751, 1); A_arbace_j2g_reach__init_part1_A_const_4.SetMacro__V(); return nil }
//line :751:1
func A_arbace_j2g_reach__init_part1_A_Unit108__O() any { A_arbace_j2g_reach__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(751, 1); return A_arbace_j2g_reach__init_part1_A_const_4 }














func A_arbace_j2g_reach__init_part1_A_Unit109__O() any { A_arbace_j2g_reach__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(766, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part1_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_j2g_reach_interned_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_j2g_reach_interned_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_271, false, nil); A_arbace_j2g_reach_interned_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part1_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part1_A_const_7)); return A_arbace_j2g_reach__init_part1_A_const_6 }







func A_arbace_j2g_reach__init_part1_A_Unit110__O() any { A_arbace_j2g_reach__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(774, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part1_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_j2g_reach_plan_node_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_j2g_reach_plan_node_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_272, false, nil); A_arbace_j2g_reach_plan_node_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part1_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part1_A_const_9)); return A_arbace_j2g_reach__init_part1_A_const_8 }












































































































































func A_arbace_j2g_reach__init_part1_A_Unit111__O() any { A_arbace_j2g_reach__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(915, 1); A_arbace_j2g_reach__init_part1_A_const_10.BindRoot_O__V(A_arbace_j2g_reach__init_part1_A_const_11); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part1_A_const_10; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part1_A_const_12)); return A_arbace_j2g_reach__init_part1_A_const_10 }



func A_arbace_j2g_reach__init_part1_A_Unit112__O() any { A_arbace_j2g_reach__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(919, 1); A_arbace_j2g_reach__init_part1_A_const_13.BindRoot_O__V(A_arbace_j2g_reach__init_part1_A_const_14); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part1_A_const_13; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part1_A_const_15)); return A_arbace_j2g_reach__init_part1_A_const_13 }



func A_arbace_j2g_reach__init_part1_A_Unit113__O() any { A_arbace_j2g_reach__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(923, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part1_A_const_16; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_j2g_reach_scanned_nodes_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_j2g_reach_scanned_nodes_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_273, false, nil); A_arbace_j2g_reach_scanned_nodes_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part1_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part1_A_const_17)); return A_arbace_j2g_reach__init_part1_A_const_16 }






























func A_arbace_j2g_reach__init_part1_A_Unit114__O() any { A_arbace_j2g_reach__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(954, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part1_A_const_18; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_j2g_reach_plan_code_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_j2g_reach_plan_code_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_274, false, nil); A_arbace_j2g_reach_plan_code_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part1_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part1_A_const_19)); return A_arbace_j2g_reach__init_part1_A_const_18 }




func A_arbace_j2g_reach__init_part1_A_Unit115__O() any { A_arbace_j2g_reach__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(959, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part1_A_const_20; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_j2g_reach_scan_code_STAR__A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_j2g_reach_scan_code_STAR__A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_275, false, nil); A_arbace_j2g_reach_scan_code_STAR__A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part1_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part1_A_const_21)); return A_arbace_j2g_reach__init_part1_A_const_20 }






func A_arbace_j2g_reach__init_part1_A_Unit116__O() any { A_arbace_j2g_reach__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(966, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part1_A_const_22; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_j2g_reach_scan_code_BANG__A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_j2g_reach_scan_code_BANG__A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_276, false, nil); A_arbace_j2g_reach_scan_code_BANG__A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part1_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part1_A_const_23)); return A_arbace_j2g_reach__init_part1_A_const_22 }


func A_arbace_j2g_reach__init_part1_A_Unit117__O() any { A_arbace_j2g_reach__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(969, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part1_A_const_24; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_j2g_reach_method_code_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_j2g_reach_method_code_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_277, false, nil); A_arbace_j2g_reach_method_code_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part1_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part1_A_const_25)); return A_arbace_j2g_reach__init_part1_A_const_24 }











func A_arbace_j2g_reach__init_part1_A_Unit118__O() any { A_arbace_j2g_reach__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(981, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part1_A_const_26; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_j2g_reach_scan_method_BANG__A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_j2g_reach_scan_method_BANG__A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_278, false, nil); A_arbace_j2g_reach_scan_method_BANG__A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part1_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part1_A_const_27)); return A_arbace_j2g_reach__init_part1_A_const_26 }








































func A_arbace_j2g_reach__init_part1_A_Unit119__O() any { A_arbace_j2g_reach__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1022, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part1_A_const_28; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_j2g_reach_snapshot_set_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_j2g_reach_snapshot_set_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_279, false, nil); A_arbace_j2g_reach_snapshot_set_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part1_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part1_A_const_29)); return A_arbace_j2g_reach__init_part1_A_const_28 }





func A_arbace_j2g_reach__init_part1_A_Unit120__O() any { A_arbace_j2g_reach__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1028, 1); var tmp1 *lang.Var = A_arbace_j2g_reach__init_part1_A_const_30; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_j2g_reach_run_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_j2g_reach_run_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_280, false, nil); A_arbace_j2g_reach_run_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_reach__init_part1_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_reach__init_part1_A_const_31)); return A_arbace_j2g_reach__init_part1_A_const_30 }



type A_arbace_j2g_reach__init_A struct{ jrt.Object }

func A_arbace_j2g_reach__init_A_New() *A_arbace_j2g_reach__init_A { t := &A_arbace_j2g_reach__init_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_reach__init_A) Ctor() {}

func (t *A_arbace_j2g_reach__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_reach__init_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_reach__init_A_class }

func (t *A_arbace_j2g_reach__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_reach__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_reach__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_reach__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_reach__init_A); return ok }

func A_arbace_j2g_reach__init_A_Cast(x any) *A_arbace_j2g_reach__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_reach__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_reach__init_A_class)) }; return v }



type A_arbace_j2g_reach__init_part0_A struct{ jrt.Object }

var A_arbace_j2g_reach__init_part0_A_const_pool *jrt.RefArray

var A_arbace_j2g_reach__init_part0_A_const_0 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_1 any

var A_arbace_j2g_reach__init_part0_A_const_2 any

var A_arbace_j2g_reach__init_part0_A_const_3 any

var A_arbace_j2g_reach__init_part0_A_const_4 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_5 any

var A_arbace_j2g_reach__init_part0_A_const_6 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_7 any

var A_arbace_j2g_reach__init_part0_A_const_8 *jrt.Class

var A_arbace_j2g_reach__init_part0_A_const_9 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_10 any

var A_arbace_j2g_reach__init_part0_A_const_11 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_12 any

var A_arbace_j2g_reach__init_part0_A_const_13 *jrt.Class

var A_arbace_j2g_reach__init_part0_A_const_14 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_15 any

var A_arbace_j2g_reach__init_part0_A_const_16 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_17 any

var A_arbace_j2g_reach__init_part0_A_const_18 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_19 any

var A_arbace_j2g_reach__init_part0_A_const_20 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_21 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_22 any

var A_arbace_j2g_reach__init_part0_A_const_23 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_24 any

var A_arbace_j2g_reach__init_part0_A_const_25 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_26 any

var A_arbace_j2g_reach__init_part0_A_const_27 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_28 any

var A_arbace_j2g_reach__init_part0_A_const_29 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_30 any

var A_arbace_j2g_reach__init_part0_A_const_31 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_32 any

var A_arbace_j2g_reach__init_part0_A_const_33 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_34 any

var A_arbace_j2g_reach__init_part0_A_const_35 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_36 any

var A_arbace_j2g_reach__init_part0_A_const_37 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_38 any

var A_arbace_j2g_reach__init_part0_A_const_39 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_40 any

var A_arbace_j2g_reach__init_part0_A_const_41 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_42 any

var A_arbace_j2g_reach__init_part0_A_const_43 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_44 any

var A_arbace_j2g_reach__init_part0_A_const_45 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_46 any

var A_arbace_j2g_reach__init_part0_A_const_47 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_48 any

var A_arbace_j2g_reach__init_part0_A_const_49 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_50 any

var A_arbace_j2g_reach__init_part0_A_const_51 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_52 any

var A_arbace_j2g_reach__init_part0_A_const_53 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_54 any

var A_arbace_j2g_reach__init_part0_A_const_55 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_56 any

var A_arbace_j2g_reach__init_part0_A_const_57 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_58 any

var A_arbace_j2g_reach__init_part0_A_const_59 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_60 any

var A_arbace_j2g_reach__init_part0_A_const_61 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_62 any

var A_arbace_j2g_reach__init_part0_A_const_63 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_64 any

var A_arbace_j2g_reach__init_part0_A_const_65 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_66 any

var A_arbace_j2g_reach__init_part0_A_const_67 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_68 any

var A_arbace_j2g_reach__init_part0_A_const_69 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_70 any

var A_arbace_j2g_reach__init_part0_A_const_71 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_72 any

var A_arbace_j2g_reach__init_part0_A_const_73 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_74 any

var A_arbace_j2g_reach__init_part0_A_const_75 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_76 any

var A_arbace_j2g_reach__init_part0_A_const_77 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_78 any

var A_arbace_j2g_reach__init_part0_A_const_79 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_80 any

var A_arbace_j2g_reach__init_part0_A_const_81 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_82 any

var A_arbace_j2g_reach__init_part0_A_const_83 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_84 any

var A_arbace_j2g_reach__init_part0_A_const_85 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_86 any

var A_arbace_j2g_reach__init_part0_A_const_87 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_88 any

var A_arbace_j2g_reach__init_part0_A_const_89 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_90 any

var A_arbace_j2g_reach__init_part0_A_const_91 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_92 any

var A_arbace_j2g_reach__init_part0_A_const_93 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_94 any

var A_arbace_j2g_reach__init_part0_A_const_95 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_96 any

var A_arbace_j2g_reach__init_part0_A_const_97 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_98 any

var A_arbace_j2g_reach__init_part0_A_const_99 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_100 any

var A_arbace_j2g_reach__init_part0_A_const_101 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_102 any

var A_arbace_j2g_reach__init_part0_A_const_103 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_104 any

var A_arbace_j2g_reach__init_part0_A_const_105 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_106 any

var A_arbace_j2g_reach__init_part0_A_const_107 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_108 any

var A_arbace_j2g_reach__init_part0_A_const_109 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_110 any

var A_arbace_j2g_reach__init_part0_A_const_111 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_112 any

var A_arbace_j2g_reach__init_part0_A_const_113 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_114 any

var A_arbace_j2g_reach__init_part0_A_const_115 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_116 any

var A_arbace_j2g_reach__init_part0_A_const_117 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_118 any

var A_arbace_j2g_reach__init_part0_A_const_119 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_120 any

var A_arbace_j2g_reach__init_part0_A_const_121 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_122 any

var A_arbace_j2g_reach__init_part0_A_const_123 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_124 any

var A_arbace_j2g_reach__init_part0_A_const_125 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_126 any

var A_arbace_j2g_reach__init_part0_A_const_127 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_128 any

var A_arbace_j2g_reach__init_part0_A_const_129 any

var A_arbace_j2g_reach__init_part0_A_const_130 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_131 any

var A_arbace_j2g_reach__init_part0_A_const_132 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_133 any

var A_arbace_j2g_reach__init_part0_A_const_134 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_135 any

var A_arbace_j2g_reach__init_part0_A_const_136 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_137 any

var A_arbace_j2g_reach__init_part0_A_const_138 *lang.Var

var A_arbace_j2g_reach__init_part0_A_const_139 any

var A_arbace_j2g_reach__init_part0_A_init jrt.ClassInit

func A_arbace_j2g_reach__init_part0_A_Init() { if !A_arbace_j2g_reach__init_part0_A_init.Done() { A_arbace_j2g_reach__init_part0_A_init.Run(A_arbace_j2g_reach__init_part0_A_clinit) } }

func A_arbace_j2g_reach__init_part0_A_clinit() { A_arbace_j2g_reach__init_part0_A_clinit_p0(); A_arbace_j2g_reach__init_part0_A_clinit_p1(); A_arbace_j2g_reach__init_part0_A_clinit_p2(); A_arbace_j2g_reach__init_part0_A_clinit_p3(); A_arbace_j2g_reach__init_part0_A_clinit_p4(); A_arbace_j2g_reach__init_part0_A_clinit_p5(); A_arbace_j2g_reach__init_part0_A_clinit_p6(); A_arbace_j2g_reach__init_part0_A_clinit_p7(); A_arbace_j2g_reach__init_part0_A_clinit_p8(); A_arbace_j2g_reach__init_part0_A_clinit_p9(); A_arbace_j2g_reach__init_part0_A_clinit_p10() }

func A_arbace_j2g_reach__init_part0_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_reach__init_part0_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_201, 236); A_arbace_j2g_reach__init_part0_A_const_0 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[96]); A_arbace_j2g_reach__init_part0_A_const_1 = A_arbace_j2g_reach__init_part0_A_const_pool.A[97]; A_arbace_j2g_reach__init_part0_A_const_2 = A_arbace_j2g_reach__init_part0_A_const_pool.A[98]; A_arbace_j2g_reach__init_part0_A_const_3 = A_arbace_j2g_reach__init_part0_A_const_pool.A[99]; A_arbace_j2g_reach__init_part0_A_const_4 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[100]); A_arbace_j2g_reach__init_part0_A_const_5 = A_arbace_j2g_reach__init_part0_A_const_pool.A[101]; A_arbace_j2g_reach__init_part0_A_const_6 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[102]); A_arbace_j2g_reach__init_part0_A_const_7 = A_arbace_j2g_reach__init_part0_A_const_pool.A[103]; A_arbace_j2g_reach__init_part0_A_const_8 = jrt.Class_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[104]); A_arbace_j2g_reach__init_part0_A_const_9 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[105]); A_arbace_j2g_reach__init_part0_A_const_10 = A_arbace_j2g_reach__init_part0_A_const_pool.A[106]; A_arbace_j2g_reach__init_part0_A_const_11 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[107]); A_arbace_j2g_reach__init_part0_A_const_12 = A_arbace_j2g_reach__init_part0_A_const_pool.A[108] }

func A_arbace_j2g_reach__init_part0_A_clinit_p1() { A_arbace_j2g_reach__init_part0_A_const_13 = jrt.Class_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[109]); A_arbace_j2g_reach__init_part0_A_const_14 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[110]); A_arbace_j2g_reach__init_part0_A_const_15 = A_arbace_j2g_reach__init_part0_A_const_pool.A[111]; A_arbace_j2g_reach__init_part0_A_const_16 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[112]); A_arbace_j2g_reach__init_part0_A_const_17 = A_arbace_j2g_reach__init_part0_A_const_pool.A[113]; A_arbace_j2g_reach__init_part0_A_const_18 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[114]); A_arbace_j2g_reach__init_part0_A_const_19 = A_arbace_j2g_reach__init_part0_A_const_pool.A[115]; A_arbace_j2g_reach__init_part0_A_const_20 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[116]); A_arbace_j2g_reach__init_part0_A_const_21 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[117]); A_arbace_j2g_reach__init_part0_A_const_22 = A_arbace_j2g_reach__init_part0_A_const_pool.A[118]; A_arbace_j2g_reach__init_part0_A_const_23 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[119]); A_arbace_j2g_reach__init_part0_A_const_24 = A_arbace_j2g_reach__init_part0_A_const_pool.A[120]; A_arbace_j2g_reach__init_part0_A_const_25 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[121]) }

func A_arbace_j2g_reach__init_part0_A_clinit_p2() { A_arbace_j2g_reach__init_part0_A_const_26 = A_arbace_j2g_reach__init_part0_A_const_pool.A[122]; A_arbace_j2g_reach__init_part0_A_const_27 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[123]); A_arbace_j2g_reach__init_part0_A_const_28 = A_arbace_j2g_reach__init_part0_A_const_pool.A[124]; A_arbace_j2g_reach__init_part0_A_const_29 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[125]); A_arbace_j2g_reach__init_part0_A_const_30 = A_arbace_j2g_reach__init_part0_A_const_pool.A[126]; A_arbace_j2g_reach__init_part0_A_const_31 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[127]); A_arbace_j2g_reach__init_part0_A_const_32 = A_arbace_j2g_reach__init_part0_A_const_pool.A[128]; A_arbace_j2g_reach__init_part0_A_const_33 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[129]); A_arbace_j2g_reach__init_part0_A_const_34 = A_arbace_j2g_reach__init_part0_A_const_pool.A[130]; A_arbace_j2g_reach__init_part0_A_const_35 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[131]); A_arbace_j2g_reach__init_part0_A_const_36 = A_arbace_j2g_reach__init_part0_A_const_pool.A[132]; A_arbace_j2g_reach__init_part0_A_const_37 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[133]); A_arbace_j2g_reach__init_part0_A_const_38 = A_arbace_j2g_reach__init_part0_A_const_pool.A[134] }

func A_arbace_j2g_reach__init_part0_A_clinit_p3() { A_arbace_j2g_reach__init_part0_A_const_39 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[135]); A_arbace_j2g_reach__init_part0_A_const_40 = A_arbace_j2g_reach__init_part0_A_const_pool.A[136]; A_arbace_j2g_reach__init_part0_A_const_41 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[137]); A_arbace_j2g_reach__init_part0_A_const_42 = A_arbace_j2g_reach__init_part0_A_const_pool.A[138]; A_arbace_j2g_reach__init_part0_A_const_43 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[139]); A_arbace_j2g_reach__init_part0_A_const_44 = A_arbace_j2g_reach__init_part0_A_const_pool.A[140]; A_arbace_j2g_reach__init_part0_A_const_45 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[141]); A_arbace_j2g_reach__init_part0_A_const_46 = A_arbace_j2g_reach__init_part0_A_const_pool.A[142]; A_arbace_j2g_reach__init_part0_A_const_47 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[143]); A_arbace_j2g_reach__init_part0_A_const_48 = A_arbace_j2g_reach__init_part0_A_const_pool.A[144]; A_arbace_j2g_reach__init_part0_A_const_49 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[145]); A_arbace_j2g_reach__init_part0_A_const_50 = A_arbace_j2g_reach__init_part0_A_const_pool.A[146]; A_arbace_j2g_reach__init_part0_A_const_51 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[147]) }

func A_arbace_j2g_reach__init_part0_A_clinit_p4() { A_arbace_j2g_reach__init_part0_A_const_52 = A_arbace_j2g_reach__init_part0_A_const_pool.A[148]; A_arbace_j2g_reach__init_part0_A_const_53 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[149]); A_arbace_j2g_reach__init_part0_A_const_54 = A_arbace_j2g_reach__init_part0_A_const_pool.A[150]; A_arbace_j2g_reach__init_part0_A_const_55 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[151]); A_arbace_j2g_reach__init_part0_A_const_56 = A_arbace_j2g_reach__init_part0_A_const_pool.A[152]; A_arbace_j2g_reach__init_part0_A_const_57 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[153]); A_arbace_j2g_reach__init_part0_A_const_58 = A_arbace_j2g_reach__init_part0_A_const_pool.A[154]; A_arbace_j2g_reach__init_part0_A_const_59 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[155]); A_arbace_j2g_reach__init_part0_A_const_60 = A_arbace_j2g_reach__init_part0_A_const_pool.A[156]; A_arbace_j2g_reach__init_part0_A_const_61 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[157]); A_arbace_j2g_reach__init_part0_A_const_62 = A_arbace_j2g_reach__init_part0_A_const_pool.A[158]; A_arbace_j2g_reach__init_part0_A_const_63 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[159]); A_arbace_j2g_reach__init_part0_A_const_64 = A_arbace_j2g_reach__init_part0_A_const_pool.A[160] }

func A_arbace_j2g_reach__init_part0_A_clinit_p5() { A_arbace_j2g_reach__init_part0_A_const_65 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[161]); A_arbace_j2g_reach__init_part0_A_const_66 = A_arbace_j2g_reach__init_part0_A_const_pool.A[162]; A_arbace_j2g_reach__init_part0_A_const_67 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[163]); A_arbace_j2g_reach__init_part0_A_const_68 = A_arbace_j2g_reach__init_part0_A_const_pool.A[164]; A_arbace_j2g_reach__init_part0_A_const_69 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[165]); A_arbace_j2g_reach__init_part0_A_const_70 = A_arbace_j2g_reach__init_part0_A_const_pool.A[166]; A_arbace_j2g_reach__init_part0_A_const_71 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[167]); A_arbace_j2g_reach__init_part0_A_const_72 = A_arbace_j2g_reach__init_part0_A_const_pool.A[168]; A_arbace_j2g_reach__init_part0_A_const_73 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[169]); A_arbace_j2g_reach__init_part0_A_const_74 = A_arbace_j2g_reach__init_part0_A_const_pool.A[170]; A_arbace_j2g_reach__init_part0_A_const_75 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[171]); A_arbace_j2g_reach__init_part0_A_const_76 = A_arbace_j2g_reach__init_part0_A_const_pool.A[172]; A_arbace_j2g_reach__init_part0_A_const_77 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[173]) }

func A_arbace_j2g_reach__init_part0_A_clinit_p6() { A_arbace_j2g_reach__init_part0_A_const_78 = A_arbace_j2g_reach__init_part0_A_const_pool.A[174]; A_arbace_j2g_reach__init_part0_A_const_79 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[175]); A_arbace_j2g_reach__init_part0_A_const_80 = A_arbace_j2g_reach__init_part0_A_const_pool.A[176]; A_arbace_j2g_reach__init_part0_A_const_81 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[177]); A_arbace_j2g_reach__init_part0_A_const_82 = A_arbace_j2g_reach__init_part0_A_const_pool.A[178]; A_arbace_j2g_reach__init_part0_A_const_83 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[179]); A_arbace_j2g_reach__init_part0_A_const_84 = A_arbace_j2g_reach__init_part0_A_const_pool.A[180]; A_arbace_j2g_reach__init_part0_A_const_85 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[181]); A_arbace_j2g_reach__init_part0_A_const_86 = A_arbace_j2g_reach__init_part0_A_const_pool.A[182]; A_arbace_j2g_reach__init_part0_A_const_87 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[183]); A_arbace_j2g_reach__init_part0_A_const_88 = A_arbace_j2g_reach__init_part0_A_const_pool.A[184]; A_arbace_j2g_reach__init_part0_A_const_89 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[185]); A_arbace_j2g_reach__init_part0_A_const_90 = A_arbace_j2g_reach__init_part0_A_const_pool.A[186] }

func A_arbace_j2g_reach__init_part0_A_clinit_p7() { A_arbace_j2g_reach__init_part0_A_const_91 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[187]); A_arbace_j2g_reach__init_part0_A_const_92 = A_arbace_j2g_reach__init_part0_A_const_pool.A[188]; A_arbace_j2g_reach__init_part0_A_const_93 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[189]); A_arbace_j2g_reach__init_part0_A_const_94 = A_arbace_j2g_reach__init_part0_A_const_pool.A[190]; A_arbace_j2g_reach__init_part0_A_const_95 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[191]); A_arbace_j2g_reach__init_part0_A_const_96 = A_arbace_j2g_reach__init_part0_A_const_pool.A[192]; A_arbace_j2g_reach__init_part0_A_const_97 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[193]); A_arbace_j2g_reach__init_part0_A_const_98 = A_arbace_j2g_reach__init_part0_A_const_pool.A[194]; A_arbace_j2g_reach__init_part0_A_const_99 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[195]); A_arbace_j2g_reach__init_part0_A_const_100 = A_arbace_j2g_reach__init_part0_A_const_pool.A[196]; A_arbace_j2g_reach__init_part0_A_const_101 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[197]); A_arbace_j2g_reach__init_part0_A_const_102 = A_arbace_j2g_reach__init_part0_A_const_pool.A[198]; A_arbace_j2g_reach__init_part0_A_const_103 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[199]) }

func A_arbace_j2g_reach__init_part0_A_clinit_p8() { A_arbace_j2g_reach__init_part0_A_const_104 = A_arbace_j2g_reach__init_part0_A_const_pool.A[200]; A_arbace_j2g_reach__init_part0_A_const_105 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[201]); A_arbace_j2g_reach__init_part0_A_const_106 = A_arbace_j2g_reach__init_part0_A_const_pool.A[202]; A_arbace_j2g_reach__init_part0_A_const_107 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[203]); A_arbace_j2g_reach__init_part0_A_const_108 = A_arbace_j2g_reach__init_part0_A_const_pool.A[204]; A_arbace_j2g_reach__init_part0_A_const_109 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[205]); A_arbace_j2g_reach__init_part0_A_const_110 = A_arbace_j2g_reach__init_part0_A_const_pool.A[206]; A_arbace_j2g_reach__init_part0_A_const_111 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[207]); A_arbace_j2g_reach__init_part0_A_const_112 = A_arbace_j2g_reach__init_part0_A_const_pool.A[208]; A_arbace_j2g_reach__init_part0_A_const_113 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[209]); A_arbace_j2g_reach__init_part0_A_const_114 = A_arbace_j2g_reach__init_part0_A_const_pool.A[210]; A_arbace_j2g_reach__init_part0_A_const_115 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[211]); A_arbace_j2g_reach__init_part0_A_const_116 = A_arbace_j2g_reach__init_part0_A_const_pool.A[212] }

func A_arbace_j2g_reach__init_part0_A_clinit_p9() { A_arbace_j2g_reach__init_part0_A_const_117 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[213]); A_arbace_j2g_reach__init_part0_A_const_118 = A_arbace_j2g_reach__init_part0_A_const_pool.A[214]; A_arbace_j2g_reach__init_part0_A_const_119 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[215]); A_arbace_j2g_reach__init_part0_A_const_120 = A_arbace_j2g_reach__init_part0_A_const_pool.A[216]; A_arbace_j2g_reach__init_part0_A_const_121 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[217]); A_arbace_j2g_reach__init_part0_A_const_122 = A_arbace_j2g_reach__init_part0_A_const_pool.A[218]; A_arbace_j2g_reach__init_part0_A_const_123 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[219]); A_arbace_j2g_reach__init_part0_A_const_124 = A_arbace_j2g_reach__init_part0_A_const_pool.A[220]; A_arbace_j2g_reach__init_part0_A_const_125 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[221]); A_arbace_j2g_reach__init_part0_A_const_126 = A_arbace_j2g_reach__init_part0_A_const_pool.A[222]; A_arbace_j2g_reach__init_part0_A_const_127 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[223]); A_arbace_j2g_reach__init_part0_A_const_128 = A_arbace_j2g_reach__init_part0_A_const_pool.A[224]; A_arbace_j2g_reach__init_part0_A_const_129 = A_arbace_j2g_reach__init_part0_A_const_pool.A[225] }

func A_arbace_j2g_reach__init_part0_A_clinit_p10() { A_arbace_j2g_reach__init_part0_A_const_130 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[226]); A_arbace_j2g_reach__init_part0_A_const_131 = A_arbace_j2g_reach__init_part0_A_const_pool.A[227]; A_arbace_j2g_reach__init_part0_A_const_132 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[228]); A_arbace_j2g_reach__init_part0_A_const_133 = A_arbace_j2g_reach__init_part0_A_const_pool.A[229]; A_arbace_j2g_reach__init_part0_A_const_134 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[230]); A_arbace_j2g_reach__init_part0_A_const_135 = A_arbace_j2g_reach__init_part0_A_const_pool.A[231]; A_arbace_j2g_reach__init_part0_A_const_136 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[232]); A_arbace_j2g_reach__init_part0_A_const_137 = A_arbace_j2g_reach__init_part0_A_const_pool.A[233]; A_arbace_j2g_reach__init_part0_A_const_138 = lang.Var_Cast(A_arbace_j2g_reach__init_part0_A_const_pool.A[234]); A_arbace_j2g_reach__init_part0_A_const_139 = A_arbace_j2g_reach__init_part0_A_const_pool.A[235] }

func A_arbace_j2g_reach__init_part0_A_New() *A_arbace_j2g_reach__init_part0_A { A_arbace_j2g_reach__init_part0_A_Init(); t := &A_arbace_j2g_reach__init_part0_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_reach__init_part0_A) Ctor() {}

func (t *A_arbace_j2g_reach__init_part0_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_reach__init_part0_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_reach__init_part0_A_class }

func (t *A_arbace_j2g_reach__init_part0_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_reach__init_part0_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_reach__init_part0_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_reach__init_part0_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_reach__init_part0_A); return ok }

func A_arbace_j2g_reach__init_part0_A_Cast(x any) *A_arbace_j2g_reach__init_part0_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_reach__init_part0_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_reach__init_part0_A_class)) }; return v }



type A_arbace_j2g_reach__init_part1_A struct{ jrt.Object }

var A_arbace_j2g_reach__init_part1_A_const_pool *jrt.RefArray

var A_arbace_j2g_reach__init_part1_A_const_0 *lang.Var

var A_arbace_j2g_reach__init_part1_A_const_1 any

var A_arbace_j2g_reach__init_part1_A_const_2 *lang.Var

var A_arbace_j2g_reach__init_part1_A_const_3 any

var A_arbace_j2g_reach__init_part1_A_const_4 *lang.Var

var A_arbace_j2g_reach__init_part1_A_const_5 any

var A_arbace_j2g_reach__init_part1_A_const_6 *lang.Var

var A_arbace_j2g_reach__init_part1_A_const_7 any

var A_arbace_j2g_reach__init_part1_A_const_8 *lang.Var

var A_arbace_j2g_reach__init_part1_A_const_9 any

var A_arbace_j2g_reach__init_part1_A_const_10 *lang.Var

var A_arbace_j2g_reach__init_part1_A_const_11 any

var A_arbace_j2g_reach__init_part1_A_const_12 any

var A_arbace_j2g_reach__init_part1_A_const_13 *lang.Var

var A_arbace_j2g_reach__init_part1_A_const_14 any

var A_arbace_j2g_reach__init_part1_A_const_15 any

var A_arbace_j2g_reach__init_part1_A_const_16 *lang.Var

var A_arbace_j2g_reach__init_part1_A_const_17 any

var A_arbace_j2g_reach__init_part1_A_const_18 *lang.Var

var A_arbace_j2g_reach__init_part1_A_const_19 any

var A_arbace_j2g_reach__init_part1_A_const_20 *lang.Var

var A_arbace_j2g_reach__init_part1_A_const_21 any

var A_arbace_j2g_reach__init_part1_A_const_22 *lang.Var

var A_arbace_j2g_reach__init_part1_A_const_23 any

var A_arbace_j2g_reach__init_part1_A_const_24 *lang.Var

var A_arbace_j2g_reach__init_part1_A_const_25 any

var A_arbace_j2g_reach__init_part1_A_const_26 *lang.Var

var A_arbace_j2g_reach__init_part1_A_const_27 any

var A_arbace_j2g_reach__init_part1_A_const_28 *lang.Var

var A_arbace_j2g_reach__init_part1_A_const_29 any

var A_arbace_j2g_reach__init_part1_A_const_30 *lang.Var

var A_arbace_j2g_reach__init_part1_A_const_31 any

var A_arbace_j2g_reach__init_part1_A_init jrt.ClassInit

func A_arbace_j2g_reach__init_part1_A_Init() { if !A_arbace_j2g_reach__init_part1_A_init.Done() { A_arbace_j2g_reach__init_part1_A_init.Run(A_arbace_j2g_reach__init_part1_A_clinit) } }

func A_arbace_j2g_reach__init_part1_A_clinit() { A_arbace_j2g_reach__init_part1_A_clinit_p0(); A_arbace_j2g_reach__init_part1_A_clinit_p1(); A_arbace_j2g_reach__init_part1_A_clinit_p2() }

func A_arbace_j2g_reach__init_part1_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_reach__init_part1_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_267, 79); A_arbace_j2g_reach__init_part1_A_const_0 = lang.Var_Cast(A_arbace_j2g_reach__init_part1_A_const_pool.A[47]); A_arbace_j2g_reach__init_part1_A_const_1 = A_arbace_j2g_reach__init_part1_A_const_pool.A[48]; A_arbace_j2g_reach__init_part1_A_const_2 = lang.Var_Cast(A_arbace_j2g_reach__init_part1_A_const_pool.A[49]); A_arbace_j2g_reach__init_part1_A_const_3 = A_arbace_j2g_reach__init_part1_A_const_pool.A[50]; A_arbace_j2g_reach__init_part1_A_const_4 = lang.Var_Cast(A_arbace_j2g_reach__init_part1_A_const_pool.A[51]); A_arbace_j2g_reach__init_part1_A_const_5 = A_arbace_j2g_reach__init_part1_A_const_pool.A[52]; A_arbace_j2g_reach__init_part1_A_const_6 = lang.Var_Cast(A_arbace_j2g_reach__init_part1_A_const_pool.A[53]); A_arbace_j2g_reach__init_part1_A_const_7 = A_arbace_j2g_reach__init_part1_A_const_pool.A[54]; A_arbace_j2g_reach__init_part1_A_const_8 = lang.Var_Cast(A_arbace_j2g_reach__init_part1_A_const_pool.A[55]); A_arbace_j2g_reach__init_part1_A_const_9 = A_arbace_j2g_reach__init_part1_A_const_pool.A[56]; A_arbace_j2g_reach__init_part1_A_const_10 = lang.Var_Cast(A_arbace_j2g_reach__init_part1_A_const_pool.A[57]); A_arbace_j2g_reach__init_part1_A_const_11 = A_arbace_j2g_reach__init_part1_A_const_pool.A[58]; A_arbace_j2g_reach__init_part1_A_const_12 = A_arbace_j2g_reach__init_part1_A_const_pool.A[59] }

func A_arbace_j2g_reach__init_part1_A_clinit_p1() { A_arbace_j2g_reach__init_part1_A_const_13 = lang.Var_Cast(A_arbace_j2g_reach__init_part1_A_const_pool.A[60]); A_arbace_j2g_reach__init_part1_A_const_14 = A_arbace_j2g_reach__init_part1_A_const_pool.A[61]; A_arbace_j2g_reach__init_part1_A_const_15 = A_arbace_j2g_reach__init_part1_A_const_pool.A[62]; A_arbace_j2g_reach__init_part1_A_const_16 = lang.Var_Cast(A_arbace_j2g_reach__init_part1_A_const_pool.A[63]); A_arbace_j2g_reach__init_part1_A_const_17 = A_arbace_j2g_reach__init_part1_A_const_pool.A[64]; A_arbace_j2g_reach__init_part1_A_const_18 = lang.Var_Cast(A_arbace_j2g_reach__init_part1_A_const_pool.A[65]); A_arbace_j2g_reach__init_part1_A_const_19 = A_arbace_j2g_reach__init_part1_A_const_pool.A[66]; A_arbace_j2g_reach__init_part1_A_const_20 = lang.Var_Cast(A_arbace_j2g_reach__init_part1_A_const_pool.A[67]); A_arbace_j2g_reach__init_part1_A_const_21 = A_arbace_j2g_reach__init_part1_A_const_pool.A[68]; A_arbace_j2g_reach__init_part1_A_const_22 = lang.Var_Cast(A_arbace_j2g_reach__init_part1_A_const_pool.A[69]); A_arbace_j2g_reach__init_part1_A_const_23 = A_arbace_j2g_reach__init_part1_A_const_pool.A[70]; A_arbace_j2g_reach__init_part1_A_const_24 = lang.Var_Cast(A_arbace_j2g_reach__init_part1_A_const_pool.A[71]); A_arbace_j2g_reach__init_part1_A_const_25 = A_arbace_j2g_reach__init_part1_A_const_pool.A[72] }

func A_arbace_j2g_reach__init_part1_A_clinit_p2() { A_arbace_j2g_reach__init_part1_A_const_26 = lang.Var_Cast(A_arbace_j2g_reach__init_part1_A_const_pool.A[73]); A_arbace_j2g_reach__init_part1_A_const_27 = A_arbace_j2g_reach__init_part1_A_const_pool.A[74]; A_arbace_j2g_reach__init_part1_A_const_28 = lang.Var_Cast(A_arbace_j2g_reach__init_part1_A_const_pool.A[75]); A_arbace_j2g_reach__init_part1_A_const_29 = A_arbace_j2g_reach__init_part1_A_const_pool.A[76]; A_arbace_j2g_reach__init_part1_A_const_30 = lang.Var_Cast(A_arbace_j2g_reach__init_part1_A_const_pool.A[77]); A_arbace_j2g_reach__init_part1_A_const_31 = A_arbace_j2g_reach__init_part1_A_const_pool.A[78] }

func A_arbace_j2g_reach__init_part1_A_New() *A_arbace_j2g_reach__init_part1_A { A_arbace_j2g_reach__init_part1_A_Init(); t := &A_arbace_j2g_reach__init_part1_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_reach__init_part1_A) Ctor() {}

func (t *A_arbace_j2g_reach__init_part1_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_reach__init_part1_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_reach__init_part1_A_class }

func (t *A_arbace_j2g_reach__init_part1_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_reach__init_part1_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_reach__init_part1_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_reach__init_part1_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_reach__init_part1_A); return ok }

func A_arbace_j2g_reach__init_part1_A_Cast(x any) *A_arbace_j2g_reach__init_part1_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_reach__init_part1_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_reach__init_part1_A_class)) }; return v }
