//line aot_arbace_j2g_reach_Cx.ae:1
package aot_arbace_j2g_reach

import (
	"arbace/jrt"
	"arbace/lang"
)










































func A_arbace_j2g_reach_Cx_A_New_O_O_O_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10 any) *A_arbace_j2g_reach_Cx_A { t := &A_arbace_j2g_reach_Cx_A{}; t.Ctor_O_O_O_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10); return t }
//line :49:1
func (t *A_arbace_j2g_reach_Cx_A) Ctor_O_O_O_O_O_O_O_O_O_O_O(supers, supersOf, iface, subcls, superOf, methods, superImpl, extKeys, descClasses, hwYes, supersSet any) { t.F_supers = supers; t.F_supersOf = supersOf; t.F_iface = iface; t.F_subcls = subcls; t.F_superOf = superOf; t.F_methods = methods; t.F_superImpl = superImpl; t.F_extKeys = extKeys; t.F_descClasses = descClasses; t.F_hwYes = hwYes; t.F_supersSet = supersSet }
//line :49:1
func A_arbace_j2g_reach_Cx_A_GetBasis__IPersistentVector() lang.IPersistentVector { return lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_158)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_159).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_160).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_161)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_159).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_160).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_162)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_159).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_160).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_163)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_159).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_160).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_164)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_159).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_160).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_165)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_159).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_160).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_166)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_159).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_160).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_167)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_159).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_160).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_168)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_159).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_160).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_169)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_159).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_160).Ref()))), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_170)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword_NoInit(nil, Lit_159).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_160).Ref()))))) }







type A_arbace_j2g_reach_Cx_A struct{ jrt.Object; F_supers, F_supersOf, F_iface, F_subcls, F_superOf, F_methods, F_superImpl, F_extKeys, F_descClasses, F_hwYes, F_supersSet any }

func (t *A_arbace_j2g_reach_Cx_A) Is_IType() {}

func (t *A_arbace_j2g_reach_Cx_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_reach_Cx_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_reach_Cx_A_class }

func (t *A_arbace_j2g_reach_Cx_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_reach_Cx_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_reach_Cx_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_reach_Cx_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_reach_Cx_A); return ok }

func A_arbace_j2g_reach_Cx_A_Cast(x any) *A_arbace_j2g_reach_Cx_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_reach_Cx_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_reach_Cx_A_class)) }; return v }
