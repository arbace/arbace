//line a2g_classes.ae:1
package aot_arbace_c2a_main

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var a2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_c2a_main__main_A_class, Name: "arbace.c2a.main$_main", Modifiers: 25, Simple: "_main", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main__main_A", Source: "main.ae", Declaring: &A_arbace_c2a_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR0_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_main__main_fn__608000102_A_class, Name: "arbace.c2a.main$_main$fn__608000102", Modifiers: 25, Simple: "fn__608000102", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main__main_fn__608000102_A", Source: "main.ae", Declaring: &A_arbace_c2a_main__main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_main__main_fn__608000104_A_class, Name: "arbace.c2a.main$_main$fn__608000104", Modifiers: 25, Simple: "fn__608000104", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main__main_fn__608000104_A", Source: "main.ae", Declaring: &A_arbace_c2a_main__main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_main__main_fn__608000106_A_class, Name: "arbace.c2a.main$_main$fn__608000106", Modifiers: 25, Simple: "fn__608000106", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main__main_fn__608000106_A", Source: "main.ae", Declaring: &A_arbace_c2a_main__main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_main_base_A_class, Name: "arbace.c2a.main$base", Modifiers: 25, Simple: "base", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_base_A", Source: "main.ae", Declaring: &A_arbace_c2a_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_main_eval608000004_loading__1927001464__auto____608000005_A_class, Name: "arbace.c2a.main$eval608000004$loading__1927001464__auto____608000005", Modifiers: 25, Simple: "loading__1927001464__auto____608000005", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_eval608000004_loading__1927001464__auto____608000005_A", Source: "main.ae", Declaring: &A_arbace_c2a_main_eval608000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_main_eval608000008_fn__608000009_A_class, Name: "arbace.c2a.main$eval608000008$fn__608000009", Modifiers: 25, Simple: "fn__608000009", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_eval608000008_fn__608000009_A", Source: "main.ae", Declaring: &A_arbace_c2a_main_eval608000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_main_ext_A_class, Name: "arbace.c2a.main$ext", Modifiers: 25, Simple: "ext", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_ext_A", Source: "main.ae", Declaring: &A_arbace_c2a_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_main_files_A_class, Name: "arbace.c2a.main$files", Modifiers: 25, Simple: "files", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_files_A", Source: "main.ae", Declaring: &A_arbace_c2a_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_main_files_iter__608000022__608000026_A_class, Name: "arbace.c2a.main$files$iter__608000022__608000026", Modifiers: 25, Simple: "iter__608000022__608000026", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_files_iter__608000022__608000026_A", Source: "main.ae", Declaring: &A_arbace_c2a_main_files_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_A_class, Name: "arbace.c2a.main$files$iter__608000022__608000026$fn__608000027", Modifiers: 25, Simple: "fn__608000027", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_A", Source: "main.ae", Declaring: &A_arbace_c2a_main_files_iter__608000022__608000026_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_fn__608000028_A_class, Name: "arbace.c2a.main$files$iter__608000022__608000026$fn__608000027$fn__608000028", Modifiers: 25, Simple: "fn__608000028", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_fn__608000028_A", Source: "main.ae", Declaring: &A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_main_parse_args_A_class, Name: "arbace.c2a.main$parse_args", Modifiers: 25, Simple: "parse_args", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_parse_args_A", Source: "main.ae", Declaring: &A_arbace_c2a_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_main_plan_A_class, Name: "arbace.c2a.main$plan", Modifiers: 25, Simple: "plan", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_plan_A", Source: "main.ae", Declaring: &A_arbace_c2a_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_main_plan_fn__608000018_A_class, Name: "arbace.c2a.main$plan$fn__608000018", Modifiers: 25, Simple: "fn__608000018", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_plan_fn__608000018_A", Source: "main.ae", Declaring: &A_arbace_c2a_main_plan_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_main_print_rules_A_class, Name: "arbace.c2a.main$print_rules", Modifiers: 25, Simple: "print_rules", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_print_rules_A", Source: "main.ae", Declaring: &A_arbace_c2a_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_main_run_A_class, Name: "arbace.c2a.main$run", Modifiers: 25, Simple: "run", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_run_A", Source: "main.ae", Declaring: &A_arbace_c2a_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_main_run_fn__608000048_A_class, Name: "arbace.c2a.main$run$fn__608000048", Modifiers: 25, Simple: "fn__608000048", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_run_fn__608000048_A", Source: "main.ae", Declaring: &A_arbace_c2a_main_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_main_run_fn__608000050_A_class, Name: "arbace.c2a.main$run$fn__608000050", Modifiers: 25, Simple: "fn__608000050", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_run_fn__608000050_A", Source: "main.ae", Declaring: &A_arbace_c2a_main_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_main_run_fn__608000050_fn__608000051_A_class, Name: "arbace.c2a.main$run$fn__608000050$fn__608000051", Modifiers: 25, Simple: "fn__608000051", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_run_fn__608000050_fn__608000051_A", Source: "main.ae", Declaring: &A_arbace_c2a_main_run_fn__608000050_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_main_run_fn__608000057_A_class, Name: "arbace.c2a.main$run$fn__608000057", Modifiers: 25, Simple: "fn__608000057", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_run_fn__608000057_A", Source: "main.ae", Declaring: &A_arbace_c2a_main_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_main_run_fn__608000059_A_class, Name: "arbace.c2a.main$run$fn__608000059", Modifiers: 25, Simple: "fn__608000059", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_run_fn__608000059_A", Source: "main.ae", Declaring: &A_arbace_c2a_main_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_main_run_fn__608000059_fn__608000060_A_class, Name: "arbace.c2a.main$run$fn__608000059$fn__608000060", Modifiers: 25, Simple: "fn__608000060", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_run_fn__608000059_fn__608000060_A", Source: "main.ae", Declaring: &A_arbace_c2a_main_run_fn__608000059_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_main_run_fn__608000066_A_class, Name: "arbace.c2a.main$run$fn__608000066", Modifiers: 25, Simple: "fn__608000066", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_run_fn__608000066_A", Source: "main.ae", Declaring: &A_arbace_c2a_main_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_main_run_fn__608000068_A_class, Name: "arbace.c2a.main$run$fn__608000068", Modifiers: 25, Simple: "fn__608000068", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_run_fn__608000068_A", Source: "main.ae", Declaring: &A_arbace_c2a_main_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_main_run_fn__608000068_fn__608000069_A_class, Name: "arbace.c2a.main$run$fn__608000068$fn__608000069", Modifiers: 25, Simple: "fn__608000069", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_run_fn__608000068_fn__608000069_A", Source: "main.ae", Declaring: &A_arbace_c2a_main_run_fn__608000068_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_main_run_fn__608000075_A_class, Name: "arbace.c2a.main$run$fn__608000075", Modifiers: 25, Simple: "fn__608000075", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_run_fn__608000075_A", Source: "main.ae", Declaring: &A_arbace_c2a_main_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_main_run_fn__608000077_A_class, Name: "arbace.c2a.main$run$fn__608000077", Modifiers: 25, Simple: "fn__608000077", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_run_fn__608000077_A", Source: "main.ae", Declaring: &A_arbace_c2a_main_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_main_run_fn__608000077_fn__608000078_A_class, Name: "arbace.c2a.main$run$fn__608000077$fn__608000078", Modifiers: 25, Simple: "fn__608000078", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_run_fn__608000077_fn__608000078_A", Source: "main.ae", Declaring: &A_arbace_c2a_main_run_fn__608000077_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_main_translate_text_A_class, Name: "arbace.c2a.main$translate_text", Modifiers: 25, Simple: "translate_text", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_translate_text_A", Source: "main.ae", Declaring: &A_arbace_c2a_main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}}

var a2gCodeDefined bool = jrt.DefineCode(a2gCode)

func init() { jrt.LinkCode(a2gCode) }

func A_arbace_c2a_main_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main_A_New()}; return nil }

var A_arbace_c2a_main_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c2a_main_A_new}

var A_arbace_c2a_main_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_A"})

func init() { i := A_arbace_c2a_main_A_class.Info(); i.IsInstance = A_arbace_c2a_main_A_InstanceOf; i.Init = A_arbace_c2a_main_A_Init; i.Table = A_arbace_c2a_main_A_members }

var A_arbace_c2a_main__main_A_class *jrt.Class

var A_arbace_c2a_main__main_fn__608000102_A_class *jrt.Class

var A_arbace_c2a_main__main_fn__608000104_A_class *jrt.Class

var A_arbace_c2a_main__main_fn__608000106_A_class *jrt.Class

var A_arbace_c2a_main_base_A_class *jrt.Class

func A_arbace_c2a_main_eval608000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main_eval608000004_A_New()}; return nil }

var A_arbace_c2a_main_eval608000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c2a_main_eval608000004_A_new}

var A_arbace_c2a_main_eval608000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main$eval608000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_c2a_main_A_class, Simple: "eval608000004", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_eval608000004_A"})

func init() { i := A_arbace_c2a_main_eval608000004_A_class.Info(); i.IsInstance = A_arbace_c2a_main_eval608000004_A_InstanceOf; i.Table = A_arbace_c2a_main_eval608000004_A_members }

var A_arbace_c2a_main_eval608000004_loading__1927001464__auto____608000005_A_class *jrt.Class

func A_arbace_c2a_main_eval608000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main_eval608000008_A_New()}; return nil }

var A_arbace_c2a_main_eval608000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c2a_main_eval608000008_A_new}

var A_arbace_c2a_main_eval608000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main$eval608000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_c2a_main_A_class, Simple: "eval608000008", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_eval608000008_A"})

func init() { i := A_arbace_c2a_main_eval608000008_A_class.Info(); i.IsInstance = A_arbace_c2a_main_eval608000008_A_InstanceOf; i.Table = A_arbace_c2a_main_eval608000008_A_members }

var A_arbace_c2a_main_eval608000008_fn__608000009_A_class *jrt.Class

var A_arbace_c2a_main_ext_A_class *jrt.Class

var A_arbace_c2a_main_files_A_class *jrt.Class

var A_arbace_c2a_main_files_iter__608000022__608000026_A_class *jrt.Class

var A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_A_class *jrt.Class

var A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_fn__608000028_A_class *jrt.Class

var A_arbace_c2a_main_parse_args_A_class *jrt.Class

var A_arbace_c2a_main_plan_A_class *jrt.Class

var A_arbace_c2a_main_plan_fn__608000018_A_class *jrt.Class

var A_arbace_c2a_main_print_rules_A_class *jrt.Class

var A_arbace_c2a_main_run_A_class *jrt.Class

var A_arbace_c2a_main_run_fn__608000048_A_class *jrt.Class

var A_arbace_c2a_main_run_fn__608000050_A_class *jrt.Class

var A_arbace_c2a_main_run_fn__608000050_fn__608000051_A_class *jrt.Class

var A_arbace_c2a_main_run_fn__608000057_A_class *jrt.Class

var A_arbace_c2a_main_run_fn__608000059_A_class *jrt.Class

var A_arbace_c2a_main_run_fn__608000059_fn__608000060_A_class *jrt.Class

var A_arbace_c2a_main_run_fn__608000066_A_class *jrt.Class

var A_arbace_c2a_main_run_fn__608000068_A_class *jrt.Class

var A_arbace_c2a_main_run_fn__608000068_fn__608000069_A_class *jrt.Class

var A_arbace_c2a_main_run_fn__608000075_A_class *jrt.Class

var A_arbace_c2a_main_run_fn__608000077_A_class *jrt.Class

var A_arbace_c2a_main_run_fn__608000077_fn__608000078_A_class *jrt.Class

var A_arbace_c2a_main_translate_text_A_class *jrt.Class

func A_arbace_c2a_main__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_c2a_main__init_A_Load__O()}; return nil }

func A_arbace_c2a_main__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main__init_A_New()}; return nil }

var A_arbace_c2a_main__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_c2a_main__init_A_invoke, New: A_arbace_c2a_main__init_A_new}

var A_arbace_c2a_main__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main__init_A", Source: "main.ae"})

func init() { i := A_arbace_c2a_main__init_A_class.Info(); i.IsInstance = A_arbace_c2a_main__init_A_InstanceOf; i.Init = A_arbace_c2a_main__init_A_Init; i.Table = A_arbace_c2a_main__init_A_members }
