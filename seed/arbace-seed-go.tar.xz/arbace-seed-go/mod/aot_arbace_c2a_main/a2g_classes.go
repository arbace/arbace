//line a2g_classes.ae:1
package aot_arbace_c2a_main

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_c2a_main_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main_A_New()}; return nil }

var A_arbace_c2a_main_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c2a_main_A_new}

var A_arbace_c2a_main_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_A"})

func init() { i := A_arbace_c2a_main_A_class.Info(); i.IsInstance = A_arbace_c2a_main_A_InstanceOf; i.Init = A_arbace_c2a_main_A_Init; i.Table = A_arbace_c2a_main_A_members; jrt.RegisterGoType(A_arbace_c2a_main_A_class, reflect.TypeFor[A_arbace_c2a_main_A]()) }

func A_arbace_c2a_main__main_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_main__main_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_c2a_main__main_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main__main_A_New()}; return nil }

func A_arbace_c2a_main__main_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_main__main_A_fn_class)}; return nil }

var A_arbace_c2a_main__main_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_main__main_A_invoke, New: A_arbace_c2a_main__main_A_new, Get: A_arbace_c2a_main__main_A_get}

var A_arbace_c2a_main__main_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main$_main", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_c2a_main_A_class, Simple: "_main", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main__main_A", Source: "main.ae"})

func init() { i := A_arbace_c2a_main__main_A_class.Info(); i.IsInstance = A_arbace_c2a_main__main_A_InstanceOf; i.Init = A_arbace_c2a_main__main_A_Init; i.Table = A_arbace_c2a_main__main_A_members; jrt.RegisterGoType(A_arbace_c2a_main__main_A_class, reflect.TypeFor[A_arbace_c2a_main__main_A]()) }

func A_arbace_c2a_main__main_fn__608000102_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_main__main_fn__608000102_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_c2a_main__main_fn__608000102_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main__main_fn__608000102_A_New()}; return nil }

func A_arbace_c2a_main__main_fn__608000102_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_main__main_fn__608000102_A_fn_class)}; return nil }

var A_arbace_c2a_main__main_fn__608000102_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_main__main_fn__608000102_A_invoke, New: A_arbace_c2a_main__main_fn__608000102_A_new, Get: A_arbace_c2a_main__main_fn__608000102_A_get}

var A_arbace_c2a_main__main_fn__608000102_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main$_main$fn__608000102", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_c2a_main__main_A_class, Simple: "fn__608000102", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main__main_fn__608000102_A", Source: "main.ae"})

func init() { i := A_arbace_c2a_main__main_fn__608000102_A_class.Info(); i.IsInstance = A_arbace_c2a_main__main_fn__608000102_A_InstanceOf; i.Init = A_arbace_c2a_main__main_fn__608000102_A_Init; i.Table = A_arbace_c2a_main__main_fn__608000102_A_members; jrt.RegisterGoType(A_arbace_c2a_main__main_fn__608000102_A_class, reflect.TypeFor[A_arbace_c2a_main__main_fn__608000102_A]()) }

func A_arbace_c2a_main__main_fn__608000104_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_main__main_fn__608000104_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_c2a_main__main_fn__608000104_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main__main_fn__608000104_A_New()}; return nil }

func A_arbace_c2a_main__main_fn__608000104_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_main__main_fn__608000104_A_fn_class)}; return nil }

var A_arbace_c2a_main__main_fn__608000104_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_main__main_fn__608000104_A_invoke, New: A_arbace_c2a_main__main_fn__608000104_A_new, Get: A_arbace_c2a_main__main_fn__608000104_A_get}

var A_arbace_c2a_main__main_fn__608000104_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main$_main$fn__608000104", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_c2a_main__main_A_class, Simple: "fn__608000104", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main__main_fn__608000104_A", Source: "main.ae"})

func init() { i := A_arbace_c2a_main__main_fn__608000104_A_class.Info(); i.IsInstance = A_arbace_c2a_main__main_fn__608000104_A_InstanceOf; i.Init = A_arbace_c2a_main__main_fn__608000104_A_Init; i.Table = A_arbace_c2a_main__main_fn__608000104_A_members; jrt.RegisterGoType(A_arbace_c2a_main__main_fn__608000104_A_class, reflect.TypeFor[A_arbace_c2a_main__main_fn__608000104_A]()) }

func A_arbace_c2a_main__main_fn__608000106_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_main__main_fn__608000106_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_c2a_main__main_fn__608000106_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main__main_fn__608000106_A_New_O(args[0])}; return nil }

func A_arbace_c2a_main__main_fn__608000106_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_main__main_fn__608000106_A_fn_class)}; return nil }

var A_arbace_c2a_main__main_fn__608000106_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_main__main_fn__608000106_A_invoke, New: A_arbace_c2a_main__main_fn__608000106_A_new, Get: A_arbace_c2a_main__main_fn__608000106_A_get}

var A_arbace_c2a_main__main_fn__608000106_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main$_main$fn__608000106", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_c2a_main__main_A_class, Simple: "fn__608000106", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main__main_fn__608000106_A", Source: "main.ae"})

func init() { i := A_arbace_c2a_main__main_fn__608000106_A_class.Info(); i.IsInstance = A_arbace_c2a_main__main_fn__608000106_A_InstanceOf; i.Init = A_arbace_c2a_main__main_fn__608000106_A_Init; i.Table = A_arbace_c2a_main__main_fn__608000106_A_members; jrt.RegisterGoType(A_arbace_c2a_main__main_fn__608000106_A_class, reflect.TypeFor[A_arbace_c2a_main__main_fn__608000106_A]()) }

func A_arbace_c2a_main_base_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_main_base_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_c2a_main_base_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main_base_A_New()}; return nil }

func A_arbace_c2a_main_base_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_main_base_A_fn_class)}; return nil }

var A_arbace_c2a_main_base_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_main_base_A_invoke, New: A_arbace_c2a_main_base_A_new, Get: A_arbace_c2a_main_base_A_get}

var A_arbace_c2a_main_base_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main$base", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_c2a_main_A_class, Simple: "base", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_base_A", Source: "main.ae"})

func init() { i := A_arbace_c2a_main_base_A_class.Info(); i.IsInstance = A_arbace_c2a_main_base_A_InstanceOf; i.Init = A_arbace_c2a_main_base_A_Init; i.Table = A_arbace_c2a_main_base_A_members; jrt.RegisterGoType(A_arbace_c2a_main_base_A_class, reflect.TypeFor[A_arbace_c2a_main_base_A]()) }

func A_arbace_c2a_main_eval608000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main_eval608000004_A_New()}; return nil }

var A_arbace_c2a_main_eval608000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c2a_main_eval608000004_A_new}

var A_arbace_c2a_main_eval608000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main$eval608000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_c2a_main_A_class, Simple: "eval608000004", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_eval608000004_A"})

func init() { i := A_arbace_c2a_main_eval608000004_A_class.Info(); i.IsInstance = A_arbace_c2a_main_eval608000004_A_InstanceOf; i.Table = A_arbace_c2a_main_eval608000004_A_members; jrt.RegisterGoType(A_arbace_c2a_main_eval608000004_A_class, reflect.TypeFor[A_arbace_c2a_main_eval608000004_A]()) }

func A_arbace_c2a_main_eval608000004_loading__1927001464__auto____608000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_main_eval608000004_loading__1927001464__auto____608000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_c2a_main_eval608000004_loading__1927001464__auto____608000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main_eval608000004_loading__1927001464__auto____608000005_A_New()}; return nil }

func A_arbace_c2a_main_eval608000004_loading__1927001464__auto____608000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_main_eval608000004_loading__1927001464__auto____608000005_A_fn_class)}; return nil }

var A_arbace_c2a_main_eval608000004_loading__1927001464__auto____608000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_main_eval608000004_loading__1927001464__auto____608000005_A_invoke, New: A_arbace_c2a_main_eval608000004_loading__1927001464__auto____608000005_A_new, Get: A_arbace_c2a_main_eval608000004_loading__1927001464__auto____608000005_A_get}

var A_arbace_c2a_main_eval608000004_loading__1927001464__auto____608000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main$eval608000004$loading__1927001464__auto____608000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_c2a_main_eval608000004_A_class, Simple: "loading__1927001464__auto____608000005", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_eval608000004_loading__1927001464__auto____608000005_A", Source: "main.ae"})

func init() { i := A_arbace_c2a_main_eval608000004_loading__1927001464__auto____608000005_A_class.Info(); i.IsInstance = A_arbace_c2a_main_eval608000004_loading__1927001464__auto____608000005_A_InstanceOf; i.Init = A_arbace_c2a_main_eval608000004_loading__1927001464__auto____608000005_A_Init; i.Table = A_arbace_c2a_main_eval608000004_loading__1927001464__auto____608000005_A_members; jrt.RegisterGoType(A_arbace_c2a_main_eval608000004_loading__1927001464__auto____608000005_A_class, reflect.TypeFor[A_arbace_c2a_main_eval608000004_loading__1927001464__auto____608000005_A]()) }

func A_arbace_c2a_main_eval608000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main_eval608000008_A_New()}; return nil }

var A_arbace_c2a_main_eval608000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c2a_main_eval608000008_A_new}

var A_arbace_c2a_main_eval608000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main$eval608000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_c2a_main_A_class, Simple: "eval608000008", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_eval608000008_A"})

func init() { i := A_arbace_c2a_main_eval608000008_A_class.Info(); i.IsInstance = A_arbace_c2a_main_eval608000008_A_InstanceOf; i.Table = A_arbace_c2a_main_eval608000008_A_members; jrt.RegisterGoType(A_arbace_c2a_main_eval608000008_A_class, reflect.TypeFor[A_arbace_c2a_main_eval608000008_A]()) }

func A_arbace_c2a_main_eval608000008_fn__608000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_main_eval608000008_fn__608000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_c2a_main_eval608000008_fn__608000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main_eval608000008_fn__608000009_A_New()}; return nil }

func A_arbace_c2a_main_eval608000008_fn__608000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_main_eval608000008_fn__608000009_A_fn_class)}; return nil }

var A_arbace_c2a_main_eval608000008_fn__608000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_main_eval608000008_fn__608000009_A_invoke, New: A_arbace_c2a_main_eval608000008_fn__608000009_A_new, Get: A_arbace_c2a_main_eval608000008_fn__608000009_A_get}

var A_arbace_c2a_main_eval608000008_fn__608000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main$eval608000008$fn__608000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_c2a_main_eval608000008_A_class, Simple: "fn__608000009", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_eval608000008_fn__608000009_A", Source: "main.ae"})

func init() { i := A_arbace_c2a_main_eval608000008_fn__608000009_A_class.Info(); i.IsInstance = A_arbace_c2a_main_eval608000008_fn__608000009_A_InstanceOf; i.Init = A_arbace_c2a_main_eval608000008_fn__608000009_A_Init; i.Table = A_arbace_c2a_main_eval608000008_fn__608000009_A_members; jrt.RegisterGoType(A_arbace_c2a_main_eval608000008_fn__608000009_A_class, reflect.TypeFor[A_arbace_c2a_main_eval608000008_fn__608000009_A]()) }

func A_arbace_c2a_main_ext_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_main_ext_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_c2a_main_ext_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main_ext_A_New()}; return nil }

func A_arbace_c2a_main_ext_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_main_ext_A_fn_class)}; return nil }

var A_arbace_c2a_main_ext_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_main_ext_A_invoke, New: A_arbace_c2a_main_ext_A_new, Get: A_arbace_c2a_main_ext_A_get}

var A_arbace_c2a_main_ext_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main$ext", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_c2a_main_A_class, Simple: "ext", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_ext_A", Source: "main.ae"})

func init() { i := A_arbace_c2a_main_ext_A_class.Info(); i.IsInstance = A_arbace_c2a_main_ext_A_InstanceOf; i.Init = A_arbace_c2a_main_ext_A_Init; i.Table = A_arbace_c2a_main_ext_A_members; jrt.RegisterGoType(A_arbace_c2a_main_ext_A_class, reflect.TypeFor[A_arbace_c2a_main_ext_A]()) }

func A_arbace_c2a_main_files_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_main_files_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_c2a_main_files_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main_files_A_New()}; return nil }

func A_arbace_c2a_main_files_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_main_files_A_fn_class)}; return nil }

var A_arbace_c2a_main_files_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_main_files_A_invoke, New: A_arbace_c2a_main_files_A_new, Get: A_arbace_c2a_main_files_A_get}

var A_arbace_c2a_main_files_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main$files", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_c2a_main_A_class, Simple: "files", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_files_A", Source: "main.ae"})

func init() { i := A_arbace_c2a_main_files_A_class.Info(); i.IsInstance = A_arbace_c2a_main_files_A_InstanceOf; i.Init = A_arbace_c2a_main_files_A_Init; i.Table = A_arbace_c2a_main_files_A_members; jrt.RegisterGoType(A_arbace_c2a_main_files_A_class, reflect.TypeFor[A_arbace_c2a_main_files_A]()) }

func A_arbace_c2a_main_files_iter__608000022__608000026_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_main_files_iter__608000022__608000026_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_c2a_main_files_iter__608000022__608000026_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main_files_iter__608000022__608000026_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_c2a_main_files_iter__608000022__608000026_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_main_files_iter__608000022__608000026_A_fn_class)}; return nil }

var A_arbace_c2a_main_files_iter__608000022__608000026_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_main_files_iter__608000022__608000026_A_invoke, New: A_arbace_c2a_main_files_iter__608000022__608000026_A_new, Get: A_arbace_c2a_main_files_iter__608000022__608000026_A_get}

var A_arbace_c2a_main_files_iter__608000022__608000026_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main$files$iter__608000022__608000026", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_c2a_main_files_A_class, Simple: "iter__608000022__608000026", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_files_iter__608000022__608000026_A", Source: "main.ae"})

func init() { i := A_arbace_c2a_main_files_iter__608000022__608000026_A_class.Info(); i.IsInstance = A_arbace_c2a_main_files_iter__608000022__608000026_A_InstanceOf; i.Init = A_arbace_c2a_main_files_iter__608000022__608000026_A_Init; i.Table = A_arbace_c2a_main_files_iter__608000022__608000026_A_members; jrt.RegisterGoType(A_arbace_c2a_main_files_iter__608000022__608000026_A_class, reflect.TypeFor[A_arbace_c2a_main_files_iter__608000022__608000026_A]()) }

func A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_A_fn_class)}; return nil }

var A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_A_invoke, New: A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_A_new, Get: A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_A_get}

var A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main$files$iter__608000022__608000026$fn__608000027", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_c2a_main_files_iter__608000022__608000026_A_class, Simple: "fn__608000027", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_A", Source: "main.ae"})

func init() { i := A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_A_class.Info(); i.IsInstance = A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_A_InstanceOf; i.Init = A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_A_Init; i.Table = A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_A_members; jrt.RegisterGoType(A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_A_class, reflect.TypeFor[A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_A]()) }

func A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_fn__608000028_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_fn__608000028_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_fn__608000028_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_fn__608000028_A_New_O_O_O_I_O(args[0], args[1], args[2], args[3].(int32), args[4])}; return nil }

func A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_fn__608000028_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_fn__608000028_A_fn_class)}; return nil }

var A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_fn__608000028_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_fn__608000028_A_invoke, New: A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_fn__608000028_A_new, Get: A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_fn__608000028_A_get}

var A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_fn__608000028_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main$files$iter__608000022__608000026$fn__608000027$fn__608000028", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_A_class, Simple: "fn__608000028", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_fn__608000028_A", Source: "main.ae"})

func init() { i := A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_fn__608000028_A_class.Info(); i.IsInstance = A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_fn__608000028_A_InstanceOf; i.Init = A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_fn__608000028_A_Init; i.Table = A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_fn__608000028_A_members; jrt.RegisterGoType(A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_fn__608000028_A_class, reflect.TypeFor[A_arbace_c2a_main_files_iter__608000022__608000026_fn__608000027_fn__608000028_A]()) }

func A_arbace_c2a_main_parse_args_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_main_parse_args_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_c2a_main_parse_args_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main_parse_args_A_New()}; return nil }

func A_arbace_c2a_main_parse_args_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_main_parse_args_A_fn_class)}; return nil }

var A_arbace_c2a_main_parse_args_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_main_parse_args_A_invoke, New: A_arbace_c2a_main_parse_args_A_new, Get: A_arbace_c2a_main_parse_args_A_get}

var A_arbace_c2a_main_parse_args_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main$parse_args", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_c2a_main_A_class, Simple: "parse_args", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_parse_args_A", Source: "main.ae"})

func init() { i := A_arbace_c2a_main_parse_args_A_class.Info(); i.IsInstance = A_arbace_c2a_main_parse_args_A_InstanceOf; i.Init = A_arbace_c2a_main_parse_args_A_Init; i.Table = A_arbace_c2a_main_parse_args_A_members; jrt.RegisterGoType(A_arbace_c2a_main_parse_args_A_class, reflect.TypeFor[A_arbace_c2a_main_parse_args_A]()) }

func A_arbace_c2a_main_plan_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_main_plan_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_c2a_main_plan_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main_plan_A_New()}; return nil }

func A_arbace_c2a_main_plan_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_main_plan_A_fn_class)}; return nil }

var A_arbace_c2a_main_plan_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_main_plan_A_invoke, New: A_arbace_c2a_main_plan_A_new, Get: A_arbace_c2a_main_plan_A_get}

var A_arbace_c2a_main_plan_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main$plan", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_c2a_main_A_class, Simple: "plan", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_plan_A", Source: "main.ae"})

func init() { i := A_arbace_c2a_main_plan_A_class.Info(); i.IsInstance = A_arbace_c2a_main_plan_A_InstanceOf; i.Init = A_arbace_c2a_main_plan_A_Init; i.Table = A_arbace_c2a_main_plan_A_members; jrt.RegisterGoType(A_arbace_c2a_main_plan_A_class, reflect.TypeFor[A_arbace_c2a_main_plan_A]()) }

func A_arbace_c2a_main_plan_fn__608000018_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_main_plan_fn__608000018_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_c2a_main_plan_fn__608000018_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main_plan_fn__608000018_A_New_O(args[0])}; return nil }

func A_arbace_c2a_main_plan_fn__608000018_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_main_plan_fn__608000018_A_fn_class)}; return nil }

var A_arbace_c2a_main_plan_fn__608000018_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_main_plan_fn__608000018_A_invoke, New: A_arbace_c2a_main_plan_fn__608000018_A_new, Get: A_arbace_c2a_main_plan_fn__608000018_A_get}

var A_arbace_c2a_main_plan_fn__608000018_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main$plan$fn__608000018", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_c2a_main_plan_A_class, Simple: "fn__608000018", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_plan_fn__608000018_A", Source: "main.ae"})

func init() { i := A_arbace_c2a_main_plan_fn__608000018_A_class.Info(); i.IsInstance = A_arbace_c2a_main_plan_fn__608000018_A_InstanceOf; i.Init = A_arbace_c2a_main_plan_fn__608000018_A_Init; i.Table = A_arbace_c2a_main_plan_fn__608000018_A_members; jrt.RegisterGoType(A_arbace_c2a_main_plan_fn__608000018_A_class, reflect.TypeFor[A_arbace_c2a_main_plan_fn__608000018_A]()) }

func A_arbace_c2a_main_print_rules_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_main_print_rules_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_c2a_main_print_rules_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main_print_rules_A_New()}; return nil }

func A_arbace_c2a_main_print_rules_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_main_print_rules_A_fn_class)}; return nil }

var A_arbace_c2a_main_print_rules_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_main_print_rules_A_invoke, New: A_arbace_c2a_main_print_rules_A_new, Get: A_arbace_c2a_main_print_rules_A_get}

var A_arbace_c2a_main_print_rules_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main$print_rules", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_c2a_main_A_class, Simple: "print_rules", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_print_rules_A", Source: "main.ae"})

func init() { i := A_arbace_c2a_main_print_rules_A_class.Info(); i.IsInstance = A_arbace_c2a_main_print_rules_A_InstanceOf; i.Init = A_arbace_c2a_main_print_rules_A_Init; i.Table = A_arbace_c2a_main_print_rules_A_members; jrt.RegisterGoType(A_arbace_c2a_main_print_rules_A_class, reflect.TypeFor[A_arbace_c2a_main_print_rules_A]()) }

func A_arbace_c2a_main_run_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_main_run_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_c2a_main_run_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main_run_A_New()}; return nil }

func A_arbace_c2a_main_run_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_main_run_A_fn_class)}; return nil }

var A_arbace_c2a_main_run_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_main_run_A_invoke, New: A_arbace_c2a_main_run_A_new, Get: A_arbace_c2a_main_run_A_get}

var A_arbace_c2a_main_run_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main$run", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_c2a_main_A_class, Simple: "run", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_run_A", Source: "main.ae"})

func init() { i := A_arbace_c2a_main_run_A_class.Info(); i.IsInstance = A_arbace_c2a_main_run_A_InstanceOf; i.Init = A_arbace_c2a_main_run_A_Init; i.Table = A_arbace_c2a_main_run_A_members; jrt.RegisterGoType(A_arbace_c2a_main_run_A_class, reflect.TypeFor[A_arbace_c2a_main_run_A]()) }

func A_arbace_c2a_main_run_fn__608000048_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_main_run_fn__608000048_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_c2a_main_run_fn__608000048_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main_run_fn__608000048_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_c2a_main_run_fn__608000048_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_main_run_fn__608000048_A_fn_class)}; return nil }

var A_arbace_c2a_main_run_fn__608000048_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_main_run_fn__608000048_A_invoke, New: A_arbace_c2a_main_run_fn__608000048_A_new, Get: A_arbace_c2a_main_run_fn__608000048_A_get}

var A_arbace_c2a_main_run_fn__608000048_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main$run$fn__608000048", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_c2a_main_run_A_class, Simple: "fn__608000048", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_run_fn__608000048_A", Source: "main.ae"})

func init() { i := A_arbace_c2a_main_run_fn__608000048_A_class.Info(); i.IsInstance = A_arbace_c2a_main_run_fn__608000048_A_InstanceOf; i.Init = A_arbace_c2a_main_run_fn__608000048_A_Init; i.Table = A_arbace_c2a_main_run_fn__608000048_A_members; jrt.RegisterGoType(A_arbace_c2a_main_run_fn__608000048_A_class, reflect.TypeFor[A_arbace_c2a_main_run_fn__608000048_A]()) }

func A_arbace_c2a_main_run_fn__608000050_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_main_run_fn__608000050_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_c2a_main_run_fn__608000050_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main_run_fn__608000050_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_c2a_main_run_fn__608000050_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_main_run_fn__608000050_A_fn_class)}; return nil }

var A_arbace_c2a_main_run_fn__608000050_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_main_run_fn__608000050_A_invoke, New: A_arbace_c2a_main_run_fn__608000050_A_new, Get: A_arbace_c2a_main_run_fn__608000050_A_get}

var A_arbace_c2a_main_run_fn__608000050_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main$run$fn__608000050", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_c2a_main_run_A_class, Simple: "fn__608000050", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_run_fn__608000050_A", Source: "main.ae"})

func init() { i := A_arbace_c2a_main_run_fn__608000050_A_class.Info(); i.IsInstance = A_arbace_c2a_main_run_fn__608000050_A_InstanceOf; i.Init = A_arbace_c2a_main_run_fn__608000050_A_Init; i.Table = A_arbace_c2a_main_run_fn__608000050_A_members; jrt.RegisterGoType(A_arbace_c2a_main_run_fn__608000050_A_class, reflect.TypeFor[A_arbace_c2a_main_run_fn__608000050_A]()) }

func A_arbace_c2a_main_run_fn__608000050_fn__608000051_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_main_run_fn__608000050_fn__608000051_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_c2a_main_run_fn__608000050_fn__608000051_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main_run_fn__608000050_fn__608000051_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_c2a_main_run_fn__608000050_fn__608000051_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_main_run_fn__608000050_fn__608000051_A_fn_class)}; return nil }

var A_arbace_c2a_main_run_fn__608000050_fn__608000051_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_main_run_fn__608000050_fn__608000051_A_invoke, New: A_arbace_c2a_main_run_fn__608000050_fn__608000051_A_new, Get: A_arbace_c2a_main_run_fn__608000050_fn__608000051_A_get}

var A_arbace_c2a_main_run_fn__608000050_fn__608000051_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main$run$fn__608000050$fn__608000051", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_c2a_main_run_fn__608000050_A_class, Simple: "fn__608000051", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_run_fn__608000050_fn__608000051_A", Source: "main.ae"})

func init() { i := A_arbace_c2a_main_run_fn__608000050_fn__608000051_A_class.Info(); i.IsInstance = A_arbace_c2a_main_run_fn__608000050_fn__608000051_A_InstanceOf; i.Init = A_arbace_c2a_main_run_fn__608000050_fn__608000051_A_Init; i.Table = A_arbace_c2a_main_run_fn__608000050_fn__608000051_A_members; jrt.RegisterGoType(A_arbace_c2a_main_run_fn__608000050_fn__608000051_A_class, reflect.TypeFor[A_arbace_c2a_main_run_fn__608000050_fn__608000051_A]()) }

func A_arbace_c2a_main_run_fn__608000057_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_main_run_fn__608000057_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_c2a_main_run_fn__608000057_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main_run_fn__608000057_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_c2a_main_run_fn__608000057_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_main_run_fn__608000057_A_fn_class)}; return nil }

var A_arbace_c2a_main_run_fn__608000057_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_main_run_fn__608000057_A_invoke, New: A_arbace_c2a_main_run_fn__608000057_A_new, Get: A_arbace_c2a_main_run_fn__608000057_A_get}

var A_arbace_c2a_main_run_fn__608000057_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main$run$fn__608000057", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_c2a_main_run_A_class, Simple: "fn__608000057", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_run_fn__608000057_A", Source: "main.ae"})

func init() { i := A_arbace_c2a_main_run_fn__608000057_A_class.Info(); i.IsInstance = A_arbace_c2a_main_run_fn__608000057_A_InstanceOf; i.Init = A_arbace_c2a_main_run_fn__608000057_A_Init; i.Table = A_arbace_c2a_main_run_fn__608000057_A_members; jrt.RegisterGoType(A_arbace_c2a_main_run_fn__608000057_A_class, reflect.TypeFor[A_arbace_c2a_main_run_fn__608000057_A]()) }

func A_arbace_c2a_main_run_fn__608000059_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_main_run_fn__608000059_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_c2a_main_run_fn__608000059_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main_run_fn__608000059_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_c2a_main_run_fn__608000059_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_main_run_fn__608000059_A_fn_class)}; return nil }

var A_arbace_c2a_main_run_fn__608000059_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_main_run_fn__608000059_A_invoke, New: A_arbace_c2a_main_run_fn__608000059_A_new, Get: A_arbace_c2a_main_run_fn__608000059_A_get}

var A_arbace_c2a_main_run_fn__608000059_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main$run$fn__608000059", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_c2a_main_run_A_class, Simple: "fn__608000059", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_run_fn__608000059_A", Source: "main.ae"})

func init() { i := A_arbace_c2a_main_run_fn__608000059_A_class.Info(); i.IsInstance = A_arbace_c2a_main_run_fn__608000059_A_InstanceOf; i.Init = A_arbace_c2a_main_run_fn__608000059_A_Init; i.Table = A_arbace_c2a_main_run_fn__608000059_A_members; jrt.RegisterGoType(A_arbace_c2a_main_run_fn__608000059_A_class, reflect.TypeFor[A_arbace_c2a_main_run_fn__608000059_A]()) }

func A_arbace_c2a_main_run_fn__608000059_fn__608000060_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_main_run_fn__608000059_fn__608000060_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_c2a_main_run_fn__608000059_fn__608000060_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main_run_fn__608000059_fn__608000060_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_c2a_main_run_fn__608000059_fn__608000060_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_main_run_fn__608000059_fn__608000060_A_fn_class)}; return nil }

var A_arbace_c2a_main_run_fn__608000059_fn__608000060_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_main_run_fn__608000059_fn__608000060_A_invoke, New: A_arbace_c2a_main_run_fn__608000059_fn__608000060_A_new, Get: A_arbace_c2a_main_run_fn__608000059_fn__608000060_A_get}

var A_arbace_c2a_main_run_fn__608000059_fn__608000060_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main$run$fn__608000059$fn__608000060", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_c2a_main_run_fn__608000059_A_class, Simple: "fn__608000060", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_run_fn__608000059_fn__608000060_A", Source: "main.ae"})

func init() { i := A_arbace_c2a_main_run_fn__608000059_fn__608000060_A_class.Info(); i.IsInstance = A_arbace_c2a_main_run_fn__608000059_fn__608000060_A_InstanceOf; i.Init = A_arbace_c2a_main_run_fn__608000059_fn__608000060_A_Init; i.Table = A_arbace_c2a_main_run_fn__608000059_fn__608000060_A_members; jrt.RegisterGoType(A_arbace_c2a_main_run_fn__608000059_fn__608000060_A_class, reflect.TypeFor[A_arbace_c2a_main_run_fn__608000059_fn__608000060_A]()) }

func A_arbace_c2a_main_run_fn__608000066_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_main_run_fn__608000066_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_c2a_main_run_fn__608000066_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main_run_fn__608000066_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_c2a_main_run_fn__608000066_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_main_run_fn__608000066_A_fn_class)}; return nil }

var A_arbace_c2a_main_run_fn__608000066_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_main_run_fn__608000066_A_invoke, New: A_arbace_c2a_main_run_fn__608000066_A_new, Get: A_arbace_c2a_main_run_fn__608000066_A_get}

var A_arbace_c2a_main_run_fn__608000066_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main$run$fn__608000066", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_c2a_main_run_A_class, Simple: "fn__608000066", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_run_fn__608000066_A", Source: "main.ae"})

func init() { i := A_arbace_c2a_main_run_fn__608000066_A_class.Info(); i.IsInstance = A_arbace_c2a_main_run_fn__608000066_A_InstanceOf; i.Init = A_arbace_c2a_main_run_fn__608000066_A_Init; i.Table = A_arbace_c2a_main_run_fn__608000066_A_members; jrt.RegisterGoType(A_arbace_c2a_main_run_fn__608000066_A_class, reflect.TypeFor[A_arbace_c2a_main_run_fn__608000066_A]()) }

func A_arbace_c2a_main_run_fn__608000068_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_main_run_fn__608000068_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_c2a_main_run_fn__608000068_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main_run_fn__608000068_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_c2a_main_run_fn__608000068_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_main_run_fn__608000068_A_fn_class)}; return nil }

var A_arbace_c2a_main_run_fn__608000068_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_main_run_fn__608000068_A_invoke, New: A_arbace_c2a_main_run_fn__608000068_A_new, Get: A_arbace_c2a_main_run_fn__608000068_A_get}

var A_arbace_c2a_main_run_fn__608000068_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main$run$fn__608000068", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_c2a_main_run_A_class, Simple: "fn__608000068", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_run_fn__608000068_A", Source: "main.ae"})

func init() { i := A_arbace_c2a_main_run_fn__608000068_A_class.Info(); i.IsInstance = A_arbace_c2a_main_run_fn__608000068_A_InstanceOf; i.Init = A_arbace_c2a_main_run_fn__608000068_A_Init; i.Table = A_arbace_c2a_main_run_fn__608000068_A_members; jrt.RegisterGoType(A_arbace_c2a_main_run_fn__608000068_A_class, reflect.TypeFor[A_arbace_c2a_main_run_fn__608000068_A]()) }

func A_arbace_c2a_main_run_fn__608000068_fn__608000069_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_main_run_fn__608000068_fn__608000069_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_c2a_main_run_fn__608000068_fn__608000069_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main_run_fn__608000068_fn__608000069_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_c2a_main_run_fn__608000068_fn__608000069_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_main_run_fn__608000068_fn__608000069_A_fn_class)}; return nil }

var A_arbace_c2a_main_run_fn__608000068_fn__608000069_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_main_run_fn__608000068_fn__608000069_A_invoke, New: A_arbace_c2a_main_run_fn__608000068_fn__608000069_A_new, Get: A_arbace_c2a_main_run_fn__608000068_fn__608000069_A_get}

var A_arbace_c2a_main_run_fn__608000068_fn__608000069_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main$run$fn__608000068$fn__608000069", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_c2a_main_run_fn__608000068_A_class, Simple: "fn__608000069", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_run_fn__608000068_fn__608000069_A", Source: "main.ae"})

func init() { i := A_arbace_c2a_main_run_fn__608000068_fn__608000069_A_class.Info(); i.IsInstance = A_arbace_c2a_main_run_fn__608000068_fn__608000069_A_InstanceOf; i.Init = A_arbace_c2a_main_run_fn__608000068_fn__608000069_A_Init; i.Table = A_arbace_c2a_main_run_fn__608000068_fn__608000069_A_members; jrt.RegisterGoType(A_arbace_c2a_main_run_fn__608000068_fn__608000069_A_class, reflect.TypeFor[A_arbace_c2a_main_run_fn__608000068_fn__608000069_A]()) }

func A_arbace_c2a_main_run_fn__608000075_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_main_run_fn__608000075_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_c2a_main_run_fn__608000075_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main_run_fn__608000075_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_c2a_main_run_fn__608000075_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_main_run_fn__608000075_A_fn_class)}; return nil }

var A_arbace_c2a_main_run_fn__608000075_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_main_run_fn__608000075_A_invoke, New: A_arbace_c2a_main_run_fn__608000075_A_new, Get: A_arbace_c2a_main_run_fn__608000075_A_get}

var A_arbace_c2a_main_run_fn__608000075_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main$run$fn__608000075", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_c2a_main_run_A_class, Simple: "fn__608000075", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_run_fn__608000075_A", Source: "main.ae"})

func init() { i := A_arbace_c2a_main_run_fn__608000075_A_class.Info(); i.IsInstance = A_arbace_c2a_main_run_fn__608000075_A_InstanceOf; i.Init = A_arbace_c2a_main_run_fn__608000075_A_Init; i.Table = A_arbace_c2a_main_run_fn__608000075_A_members; jrt.RegisterGoType(A_arbace_c2a_main_run_fn__608000075_A_class, reflect.TypeFor[A_arbace_c2a_main_run_fn__608000075_A]()) }

func A_arbace_c2a_main_run_fn__608000077_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_main_run_fn__608000077_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_c2a_main_run_fn__608000077_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main_run_fn__608000077_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_c2a_main_run_fn__608000077_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_main_run_fn__608000077_A_fn_class)}; return nil }

var A_arbace_c2a_main_run_fn__608000077_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_main_run_fn__608000077_A_invoke, New: A_arbace_c2a_main_run_fn__608000077_A_new, Get: A_arbace_c2a_main_run_fn__608000077_A_get}

var A_arbace_c2a_main_run_fn__608000077_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main$run$fn__608000077", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_c2a_main_run_A_class, Simple: "fn__608000077", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_run_fn__608000077_A", Source: "main.ae"})

func init() { i := A_arbace_c2a_main_run_fn__608000077_A_class.Info(); i.IsInstance = A_arbace_c2a_main_run_fn__608000077_A_InstanceOf; i.Init = A_arbace_c2a_main_run_fn__608000077_A_Init; i.Table = A_arbace_c2a_main_run_fn__608000077_A_members; jrt.RegisterGoType(A_arbace_c2a_main_run_fn__608000077_A_class, reflect.TypeFor[A_arbace_c2a_main_run_fn__608000077_A]()) }

func A_arbace_c2a_main_run_fn__608000077_fn__608000078_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_main_run_fn__608000077_fn__608000078_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_c2a_main_run_fn__608000077_fn__608000078_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main_run_fn__608000077_fn__608000078_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_c2a_main_run_fn__608000077_fn__608000078_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_main_run_fn__608000077_fn__608000078_A_fn_class)}; return nil }

var A_arbace_c2a_main_run_fn__608000077_fn__608000078_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_main_run_fn__608000077_fn__608000078_A_invoke, New: A_arbace_c2a_main_run_fn__608000077_fn__608000078_A_new, Get: A_arbace_c2a_main_run_fn__608000077_fn__608000078_A_get}

var A_arbace_c2a_main_run_fn__608000077_fn__608000078_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main$run$fn__608000077$fn__608000078", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_c2a_main_run_fn__608000077_A_class, Simple: "fn__608000078", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_run_fn__608000077_fn__608000078_A", Source: "main.ae"})

func init() { i := A_arbace_c2a_main_run_fn__608000077_fn__608000078_A_class.Info(); i.IsInstance = A_arbace_c2a_main_run_fn__608000077_fn__608000078_A_InstanceOf; i.Init = A_arbace_c2a_main_run_fn__608000077_fn__608000078_A_Init; i.Table = A_arbace_c2a_main_run_fn__608000077_fn__608000078_A_members; jrt.RegisterGoType(A_arbace_c2a_main_run_fn__608000077_fn__608000078_A_class, reflect.TypeFor[A_arbace_c2a_main_run_fn__608000077_fn__608000078_A]()) }

func A_arbace_c2a_main_translate_text_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_main_translate_text_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_c2a_main_translate_text_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main_translate_text_A_New()}; return nil }

func A_arbace_c2a_main_translate_text_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_main_translate_text_A_fn_class)}; return nil }

var A_arbace_c2a_main_translate_text_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_main_translate_text_A_invoke, New: A_arbace_c2a_main_translate_text_A_new, Get: A_arbace_c2a_main_translate_text_A_get}

var A_arbace_c2a_main_translate_text_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main$translate_text", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_c2a_main_A_class, Simple: "translate_text", Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main_translate_text_A", Source: "main.ae"})

func init() { i := A_arbace_c2a_main_translate_text_A_class.Info(); i.IsInstance = A_arbace_c2a_main_translate_text_A_InstanceOf; i.Init = A_arbace_c2a_main_translate_text_A_Init; i.Table = A_arbace_c2a_main_translate_text_A_members; jrt.RegisterGoType(A_arbace_c2a_main_translate_text_A_class, reflect.TypeFor[A_arbace_c2a_main_translate_text_A]()) }

func A_arbace_c2a_main__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_c2a_main__init_A_Load__O(); case 1: return A_arbace_c2a_main__init_A_Unit0__O(); case 2: return A_arbace_c2a_main__init_A_Unit1__O(); case 3: return A_arbace_c2a_main__init_A_Unit10__O(); case 4: return A_arbace_c2a_main__init_A_Unit11__O(); case 5: return A_arbace_c2a_main__init_A_Unit12__O(); case 6: return A_arbace_c2a_main__init_A_Unit13__O(); case 7: return A_arbace_c2a_main__init_A_Unit2__O(); case 8: return A_arbace_c2a_main__init_A_Unit3__O(); case 9: return A_arbace_c2a_main__init_A_Unit4__O(); case 10: return A_arbace_c2a_main__init_A_Unit5__O(); case 11: return A_arbace_c2a_main__init_A_Unit6__O(); case 12: return A_arbace_c2a_main__init_A_Unit7__O(); case 13: return A_arbace_c2a_main__init_A_Unit8__O(); case 14: return A_arbace_c2a_main__init_A_Unit9__O()}; return nil }

func A_arbace_c2a_main__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_main__init_A_New()}; return nil }

var A_arbace_c2a_main__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_c2a_main__init_A_invoke, New: A_arbace_c2a_main__init_A_new}

var A_arbace_c2a_main__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.main__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_c2a_main.A_arbace_c2a_main__init_A", Source: "main.ae"})

func init() { i := A_arbace_c2a_main__init_A_class.Info(); i.IsInstance = A_arbace_c2a_main__init_A_InstanceOf; i.Init = A_arbace_c2a_main__init_A_Init; i.Table = A_arbace_c2a_main__init_A_members; jrt.RegisterGoType(A_arbace_c2a_main__init_A_class, reflect.TypeFor[A_arbace_c2a_main__init_A]()) }
