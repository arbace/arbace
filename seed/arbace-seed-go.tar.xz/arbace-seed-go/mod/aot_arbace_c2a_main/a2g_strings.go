//line a2g_strings.ae:1
package aot_arbace_c2a_main

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("require")

var Lit_3 *jrt.String = jrt.Intern("arbace.c2a.rules")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("rules")

var Lit_6 *jrt.String = jrt.Intern("arbace.java.io")

var Lit_7 *jrt.String = jrt.Intern("io")

var Lit_8 *jrt.String = jrt.Intern("arbace.string")

var Lit_9 *jrt.String = jrt.Intern("str")

var Lit_10 *jrt.String = jrt.Intern("commute")

var Lit_11 *jrt.String = jrt.Intern("deref")

var Lit_12 *jrt.String = jrt.Intern("conj")

var Lit_13 *jrt.String = jrt.Intern("arbace.c2a.main")

var Lit_14 *jrt.String = jrt.Intern("doc")

var Lit_15 *jrt.String = jrt.Intern("c2a, the Clojure -> Arbace translator (doc/C2A.md): Clojure source files or trees rewritten\n  by the rules of arbace.c2a.rules, their layout and comments kept. bin/c2a runs it.\n\n    c2a [OPTION...] -o OUT SRC...    translate files and trees into the directory OUT\n    c2a --in-place [OPTION...] SRC...  translate them where they are\n    c2a --stdin [--kind K] [--ae]    translate standard input to standard output\n    c2a --rules                      list the rules and the dialect divergences\n\n  A directory SRC is translated into OUT with its relative paths (its contents, not itself).\n  .clj and .cljc files become .ae files: a .cljc file's reader conditionals resolved for\n  Arbace's features (#{:clj}); a .clj and a .cljc of the same name give the .clj's .ae (the\n  reader prefers the .clj), and a .ae already there is kept as it is (the reader prefers it).\n  data_readers.clj/.cljc become data_readers.ae too (Arbace reads it first), but as Arbace reads\n  all three and merges them, one that would collide keeps its name: a data_readers.clj beside a\n  data_readers.ae, a data_readers.cljc beside either. project.clj keeps its name. .java files\n  are renamed as text and keep their names (j2a reads them). With -o, other files are copied\n  as they are, but class files (AOT output cannot be translated: their sources are); in place,\n  they stay.\n\n  Options:\n    --keep-ext       .clj and .cljc files keep their names (and so a .cljc its conditionals,\n                     which Arbace's reader resolves with the feature :clj), as bin/clojure-tests\n                     translates Clojure's test suite\n    --text EXT       files ending in EXT are renamed as text (rule :rename and the like) too,\n                     keeping their names (repeatable; e.g. --text .edn)\n    --skip ID,...    leave these rules out\n    --kind K         --stdin's kind: clj (default), cljc, java or text\n    --ae             --stdin: the text becomes a .ae file (a .cljc's conditionals resolved)\n    -q               quiet: no summary")

var Lit_16 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_17 *jrt.String = jrt.Intern("subs")

var Lit_18 *jrt.String = jrt.Intern("next")

var Lit_19 *jrt.String = jrt.Intern("to-array")

var Lit_20 *jrt.String = jrt.Intern("seq")

var Lit_21 *jrt.String = jrt.Intern("first")

var Lit_22 *jrt.String = jrt.Intern("keep-ext")

var Lit_23 *jrt.String = jrt.Intern("text")

var Lit_24 *jrt.String = jrt.Intern("ext")

var Lit_25 *jrt.String = jrt.Intern("contains?")

var Lit_26 *jrt.String = jrt.Intern("kind")

var Lit_27 *jrt.String = jrt.Intern("cljc")

var Lit_28 *jrt.String = jrt.Intern("clj")

var Lit_29 *jrt.String = jrt.Intern("to-ae")

var Lit_30 *jrt.String = jrt.Intern("out")

var Lit_31 *jrt.String = jrt.Intern(".cljc")

var Lit_32 *jrt.String = jrt.Intern(".clj")

var Lit_33 *jrt.String = jrt.Intern("keyword")

var Lit_34 *jrt.String = jrt.Intern("base")

var Lit_35 *jrt.String = jrt.Intern("skip")

var Lit_36 *jrt.String = jrt.Intern("else")

var Lit_37 *jrt.String = jrt.Intern("java")

var Lit_38 *jrt.String = jrt.Intern("some")

var Lit_39 *jrt.String = jrt.Intern("a class file (AOT output) cannot be translated")

var Lit_40 *jrt.String = jrt.Intern("copy")

var Lit_41 *jrt.String = jrt.Intern("keep-names")

var Lit_42 *jrt.String = jrt.Intern("ends-with?")

var Lit_43 *jrt.String = jrt.Intern("translate")

var Lit_44 *jrt.String = jrt.Intern("features")

var Lit_45 *jrt.String = jrt.Intern("path")

var Lit_46 *jrt.String = jrt.Intern("sort-by")

var Lit_47 *jrt.String = jrt.Intern("second")

var Lit_48 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_49 *jrt.String = jrt.Intern("chunk-first")

var Lit_50 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_51 *jrt.String = jrt.Intern("chunk-append")

var Lit_52 *jrt.String = jrt.Intern("chunk-cons")

var Lit_53 *jrt.String = jrt.Intern("cons")

var Lit_54 *jrt.String = jrt.Intern("chunk")

var Lit_55 *jrt.String = jrt.Intern("chunk-rest")

var Lit_56 *jrt.String = jrt.Intern("rest")

var Lit_57 *jrt.String = jrt.Intern("file-seq")

var Lit_58 *jrt.String = jrt.Intern("atom")

var Lit_59 *jrt.String = jrt.Intern("translated")

var Lit_60 *jrt.String = jrt.Intern("copied")

var Lit_61 *jrt.String = jrt.Intern("skipped")

var Lit_62 *jrt.String = jrt.Intern("unchanged")

var Lit_63 *jrt.String = jrt.Intern("errors")

var Lit_64 *jrt.String = jrt.Intern("file")

var Lit_65 *jrt.String = jrt.Intern("files")

var Lit_66 *jrt.String = jrt.Intern("set")

var Lit_67 *jrt.String = jrt.Intern("plan")

var Lit_68 *jrt.String = jrt.Intern("println")

var Lit_69 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_70 *jrt.String = jrt.Intern("swap!")

var Lit_71 *jrt.String = jrt.Intern("slurp")

var Lit_72 *jrt.String = jrt.Intern("translate-text")

var Lit_73 *jrt.String = jrt.Intern("ex-message")

var Lit_74 *jrt.String = jrt.Intern("update")

var Lit_75 *jrt.String = jrt.Intern("inc")

var Lit_76 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_77 *jrt.String = jrt.Intern("hash-map")

var Lit_78 *jrt.String = jrt.Intern("*out*")

var Lit_79 *jrt.String = jrt.Intern("*err*")

var Lit_80 *jrt.String = jrt.Intern("spit")

var Lit_81 *jrt.String = jrt.Intern("make-parents")

var Lit_82 *jrt.String = jrt.Intern("not=")

var Lit_83 *jrt.String = jrt.Intern("sources")

var Lit_84 *jrt.String = jrt.Intern("empty?")

var Lit_85 *jrt.String = jrt.Intern("starts-with?")

var Lit_86 *jrt.String = jrt.Intern("ex-info")

var Lit_87 *jrt.String = jrt.Intern("assoc")

var Lit_88 *jrt.String = jrt.Intern("in-place")

var Lit_89 *jrt.String = jrt.Intern("stdin")

var Lit_90 *jrt.String = jrt.Intern("ae")

var Lit_91 *jrt.String = jrt.Intern("quiet")

var Lit_92 *jrt.String = jrt.Intern("into")

var Lit_93 *jrt.String = jrt.Intern("map")

var Lit_94 *jrt.String = jrt.Intern("split")

var Lit_95 *jrt.String = jrt.Intern(",")

var Lit_96 *jrt.String = jrt.Intern("name")

var Lit_97 *jrt.String = jrt.Intern("replace")

var Lit_98 *jrt.String = jrt.Intern("id")

var Lit_99 *jrt.String = jrt.Intern("\\s+")

var Lit_100 *jrt.String = jrt.Intern("divergences")

var Lit_101 *jrt.String = jrt.Intern("divergence")

var Lit_102 *jrt.String = jrt.Intern("none")

var Lit_103 *jrt.String = jrt.Intern("rule")

var Lit_104 *jrt.String = jrt.Intern("why")

var Lit_105 *jrt.String = jrt.Intern("parse-args")

var Lit_106 *jrt.String = jrt.Intern("print-rules")

var Lit_107 *jrt.String = jrt.Intern("flush")

var Lit_108 *jrt.String = jrt.Intern("not")

var Lit_109 *jrt.String = jrt.Intern("run")

var Lit_110 *jrt.String = jrt.Intern("remove")

var Lit_111 *jrt.String = jrt.Intern("join")

var Lit_112 *jrt.String = jrt.Intern("print")

var Lit_113 *jrt.String = jrt.Intern("*in*")

var Lit_114 *jrt.String = jrt.Intern("the-ns")

var Lit_115 *jrt.String = jrt.Intern("format")

var Lit_116 *jrt.String = jrt.Intern("arbace.c2a.main$_main")

var Lit_117 *jrt.String = jrt.Intern("unknown rules: ")

var Lit_118 *jrt.String = jrt.Intern(", ")

var Lit_119 *jrt.String = jrt.Intern("<stdin>")

var Lit_120 *jrt.String = jrt.Intern("arbace.c2a.main$_main$fn__608000102")

var Lit_121 *jrt.String = jrt.Intern("arbace.c2a.main$_main$fn__608000104")

var Lit_122 *jrt.String = jrt.Intern("c2a: give -o OUT or --in-place")

var Lit_123 *jrt.String = jrt.Intern("arbace.c2a.main$_main$fn__608000106")

var Lit_124 *jrt.String = jrt.Intern("c2a: %d translated (%d to .ae), %d unchanged, %d copied, %d skipped, %d errors")

var Lit_125 *jrt.String = jrt.Intern("arbace.c2a.main$base")

var Lit_126 *jrt.String = jrt.Intern(".")

var Lit_127 *jrt.String = jrt.Intern("arbace.c2a.main$eval608000004$loading__1927001464__auto____608000005")

var Lit_128 *jrt.String = jrt.Intern("java.io.File")

var Lit_129 *jrt.String = jrt.Intern("arbace.c2a.main$eval608000008$fn__608000009")

var Lit_130 *jrt.String = jrt.Intern("arbace.c2a.main$ext")

var Lit_131 *jrt.String = jrt.Intern("")

var Lit_132 *jrt.String = jrt.Intern("arbace.c2a.main$files")

var Lit_133 *jrt.String = jrt.Intern("arbace.c2a.main$files$iter__608000022__608000026")

var Lit_134 *jrt.String = jrt.Intern("arbace.c2a.main$files$iter__608000022__608000026$fn__608000027")

var Lit_135 *jrt.String = jrt.Intern("arbace.c2a.main$files$iter__608000022__608000026$fn__608000027$fn__608000028")

var Lit_136 *jrt.String = jrt.Intern("arbace.c2a.main$parse_args")

var Lit_137 *jrt.String = jrt.Intern("-o")

var Lit_138 *jrt.String = jrt.Intern("--in-place")

var Lit_139 *jrt.String = jrt.Intern("--stdin")

var Lit_140 *jrt.String = jrt.Intern("--rules")

var Lit_141 *jrt.String = jrt.Intern("--keep-ext")

var Lit_142 *jrt.String = jrt.Intern("--ae")

var Lit_143 *jrt.String = jrt.Intern("-q")

var Lit_144 *jrt.String = jrt.Intern("--text")

var Lit_145 *jrt.String = jrt.Intern("--kind")

var Lit_146 *jrt.String = jrt.Intern("--skip")

var Lit_147 *jrt.String = jrt.Intern("-")

var Lit_148 *jrt.String = jrt.Intern("unknown option: ")

var Lit_149 *jrt.String = jrt.Intern("arbace.c2a.main$plan")

var Lit_150 *jrt.String = jrt.Intern("data_readers")

var Lit_151 *jrt.String = jrt.Intern("data_readers.ae")

var Lit_152 *jrt.String = jrt.Intern("data_readers.clj")

var Lit_153 *jrt.String = jrt.Intern(".ae")

var Lit_154 *jrt.String = jrt.Intern(".ae exists, which Arbace's reader prefers")

var Lit_155 *jrt.String = jrt.Intern(".clj is translated instead, as the reader prefers it")

var Lit_156 *jrt.String = jrt.Intern(".java")

var Lit_157 *jrt.String = jrt.Intern(".class")

var Lit_158 *jrt.String = jrt.Intern("arbace.c2a.main$plan$fn__608000018")

var Lit_159 *jrt.String = jrt.Intern("arbace.c2a.main$print_rules")

var Lit_160 *jrt.String = jrt.Intern("Rules, in the order they apply:")

var Lit_161 *jrt.String = jrt.Intern("  ")

var Lit_162 *jrt.String = jrt.Intern(": ")

var Lit_163 *jrt.String = jrt.Intern(" ")

var Lit_164 *jrt.String = jrt.Intern("Dialect divergences (doc/VENDOR-NOTES.md):")

var Lit_165 *jrt.String = jrt.Intern("no rule")

var Lit_166 *jrt.String = jrt.Intern(" - ")

var Lit_167 *jrt.String = jrt.Intern("arbace.c2a.main$run")

var Lit_168 *jrt.String = jrt.Intern("/")

var Lit_169 *jrt.String = jrt.Intern("arbace.c2a.main$run$fn__608000048")

var Lit_170 *jrt.String = jrt.Intern("c2a: skipped")

var Lit_171 *jrt.String = jrt.Intern("arbace.c2a.main$run$fn__608000050")

var Lit_172 *jrt.String = jrt.Intern("arbace.c2a.main$run$fn__608000050$fn__608000051")

var Lit_173 *jrt.String = jrt.Intern("c2a: error in")

var Lit_174 *jrt.String = jrt.Intern("arbace.c2a.main$run$fn__608000057")

var Lit_175 *jrt.String = jrt.Intern("arbace.c2a.main$run$fn__608000059")

var Lit_176 *jrt.String = jrt.Intern("arbace.c2a.main$run$fn__608000059$fn__608000060")

var Lit_177 *jrt.String = jrt.Intern("arbace.c2a.main$run$fn__608000066")

var Lit_178 *jrt.String = jrt.Intern("arbace.c2a.main$run$fn__608000068")

var Lit_179 *jrt.String = jrt.Intern("arbace.c2a.main$run$fn__608000068$fn__608000069")

var Lit_180 *jrt.String = jrt.Intern("arbace.c2a.main$run$fn__608000075")

var Lit_181 *jrt.String = jrt.Intern("arbace.c2a.main$run$fn__608000077")

var Lit_182 *jrt.String = jrt.Intern("arbace.c2a.main$run$fn__608000077$fn__608000078")

var Lit_183 *jrt.String = jrt.Intern("arbace.c2a.main$translate_text")

var Lit_184 *jrt.String = jrt.Intern("in-ns")

var Lit_185 *jrt.String = jrt.Intern("project.clj")

var Lit_186 *jrt.String = jrt.Intern("line")

var Lit_187 *jrt.String = jrt.Intern("column")

var Lit_188 *jrt.String = jrt.Intern("arbace/c2a/main.ae")

var Lit_189 *jrt.String = jrt.Intern("private")

var Lit_190 *jrt.String = jrt.Intern("arglists")

var Lit_191 *jrt.String = jrt.Intern("tag")

var Lit_192 *jrt.String = jrt.Intern("String")

var Lit_193 *jrt.String = jrt.Intern("siblings")

var Lit_194 *jrt.String = jrt.Intern("keys")

var Lit_195 *jrt.String = jrt.Intern("What becomes of the file named name, among its siblings (a set of names), with the options:\n  {:kind K :to-ae BOOL :out NAME} for a file translated, {:copy true} for one copied (or left\n  in place), {:skip REASON} for one left out.")

var Lit_196 *jrt.String = jrt.Intern("s")

var Lit_197 *jrt.String = jrt.Intern("p")

var Lit_198 *jrt.String = jrt.Intern("Text s translated as a file of the plan p.")

var Lit_199 *jrt.String = jrt.Intern("src")

var Lit_200 *jrt.String = jrt.Intern("File")

var Lit_201 *jrt.String = jrt.Intern("[root-dir relative-path] of every file under src (a file: its directory and its name).")

var Lit_202 *jrt.String = jrt.Intern("opts")

var Lit_203 *jrt.String = jrt.Intern("Translates the sources (paths) into out (a directory path), or in place when out is nil.\n  Returns the counts {:translated :to-ae :copied :skipped :unchanged} and prints what was\n  skipped, and errors, to *err*. Throws when a file cannot be read as source.")

var Lit_204 *jrt.String = jrt.Intern("args")

var Lit_205 *jrt.String = jrt.Intern("-main")

var Lit_206 *jrt.String = jrt.Intern("&")
