//line a2g_strings.ae:1
package aot_arbace_c2a_main

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn16,arbace.c2a.ruleskn2,asyn5,rulesyn14,arbace.java.ioyn2,ioyn13,arbace.stringyn3,strkn3,dockn8,keep-extkn4,textkn4,kindkn4,cljckn3,cljkn5,to-aekn3,outkn4,skipkn4,elsekn4,javakn4,copykn8,featureskn4,pathkn10,translatedkn6,copiedkn7,skippedkn9,unchangedkn6,errorskn7,sourceskn8,in-placekn5,stdinkn5,ruleskn2,aekn5,quietkn2,idkn10,divergencekn4,nonekn4,rulekn3,whyyn15,arbace.c2a.mainv11,arbace.core5,referv11,arbace.core7,requireR0,V3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn15,arbace.c2a.mainm2,R8,s2016,c2a, the Clojure -> Arbace translator (doc/C2A.md): Clojure source files or trees rewritten\n  by the rules of arbace.c2a.rules, their layout and comments kept. bin/c2a runs it.\n\n    c2a [OPTION...] -o OUT SRC...    translate files and trees into the directory OUT\n    c2a --in-place [OPTION...] SRC...  translate them where they are\n    c2a --stdin [--kind K] [--ae]    translate standard input to standard output\n    c2a --rules                      list the rules and the dialect divergences\n\n  A directory SRC is translated into OUT with its relative paths (its contents, not itself).\n  .clj and .cljc files become .ae files: a .cljc file's reader conditionals resolved for\n  Arbace's features (#{:clj}); a .clj and a .cljc of the same name give the .clj's .ae (the\n  reader prefers the .clj), and a .ae already there is kept as it is (the reader prefers it).\n  data_readers.clj/.cljc become data_readers.ae too (Arbace reads it first), but as Arbace reads\n  all three and merges them, one that would collide keeps its name: a data_readers.clj beside a\n  data_readers.ae, a data_readers.cljc beside either. project.clj keeps its name. .java files\n  are renamed as text and keep their names (j2a reads them). With -o, other files are copied\n  as they are, but class files (AOT output cannot be translated: their sources are); in place,\n  they stay.\n\n  Options:\n    --keep-ext       .clj and .cljc files keep their names (and so a .cljc its conditionals,\n                     which Arbace's reader resolves with the feature :clj), as bin/clojure-tests\n                     translates Clojure's test suite\n    --text EXT       files ending in EXT are renamed as text (rule :rename and the like) too,\n                     keeping their names (repeatable; e.g. --text .edn)\n    --skip ID,...    leave these rules out\n    --kind K         --stdin's kind: clj (default), cljc, java or text\n    --ae             --stdin: the text becomes a .ae file (a .cljc's conditionals resolved)\n    -q               quiet: no summaryv11,arbace.core13,*loaded-libs*v11,arbace.core4,subsl0,v11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core3,seqv11,arbace.core5,firstR9,R10,v15,arbace.c2a.main3,extv11,arbace.core9,contains?R11,R12,R13,R14,R15,S2,s5,.cljcs4,.cljv11,arbace.core7,keywordv15,arbace.c2a.main4,baseR16,R17,R18,v11,arbace.core4,somem2,R16,s46,a class file (AOT output) cannot be translatedm2,R19,Tv15,arbace.c2a.main10,keep-namesl1,v13,arbace.string10,ends-with?v16,arbace.c2a.rules9,translateR20,S1,R13,R21,v11,arbace.core7,sort-byv11,arbace.core6,secondv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core3,strv11,arbace.core10,chunk-consv11,arbace.core4,consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,restv11,arbace.core8,file-seqv11,arbace.core4,atomm12,R22,l0,R14,l0,R23,l0,R24,l0,R25,l0,R26,l0,v14,arbace.java.io4,filev15,arbace.c2a.main5,filesv11,arbace.core3,setv15,arbace.c2a.main4,planv11,arbace.core7,printlnv11,arbace.core19,pop-thread-bindingsR19,v11,arbace.core5,swap!v11,arbace.core5,slurpv15,arbace.c2a.main14,translate-textv11,arbace.core10,ex-messagev11,arbace.core6,updateR26,v11,arbace.core3,incv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core5,*out*v11,arbace.core5,*err*v11,arbace.core4,spitR24,v14,arbace.java.io4,copyv14,arbace.java.io12,make-parentsR23,R25,R22,v11,arbace.core4,not=R27,v11,arbace.core6,empty?v13,arbace.string12,starts-with?v11,arbace.core7,ex-infov11,arbace.core5,assocR28,R29,R30,R31,R32,v11,arbace.core4,intov11,arbace.core3,mapv13,arbace.string5,splitp1,,v16,arbace.c2a.rules5,rulesv11,arbace.core4,namev13,arbace.string7,replaceR33,R8,p3,\\s+v16,arbace.c2a.rules11,divergencesR34,R35,R36,R37,p3,\\s+v15,arbace.c2a.main10,parse-argsv15,arbace.c2a.main11,print-rulesv11,arbace.core5,flushv11,arbace.core3,notv15,arbace.c2a.main3,runv11,arbace.core6,removev13,arbace.string4,joinv11,arbace.core5,printv11,arbace.core4,*in*v11,arbace.core6,the-nsR38,v11,arbace.core6,format")

var Lit_1 *jrt.String = jrt.Intern("unknown rules: ")

var Lit_2 *jrt.String = jrt.Intern(", ")

var Lit_3 *jrt.String = jrt.Intern("<stdin>")

var Lit_4 *jrt.String = jrt.Intern("arbace.c2a.main$_main$fn__608000102")

var Lit_5 *jrt.String = jrt.Intern("arbace.c2a.main$_main$fn__608000104")

var Lit_6 *jrt.String = jrt.Intern("arbace.c2a.main$_main$fn__608000106")

var Lit_7 *jrt.String = jrt.Intern("c2a: give -o OUT or --in-place")

var Lit_8 *jrt.String = jrt.Intern("c2a: %d translated (%d to .ae), %d unchanged, %d copied, %d skipped, %d errors")

var Lit_9 *jrt.String = jrt.Intern(".")

var Lit_10 *jrt.String = jrt.Intern("java.io.File")

var Lit_11 *jrt.String = jrt.Intern("")

var Lit_12 *jrt.String = jrt.Intern("arbace.c2a.main$files$iter__608000022__608000026")

var Lit_13 *jrt.String = jrt.Intern("arbace.c2a.main$files$iter__608000022__608000026$fn__608000027")

var Lit_14 *jrt.String = jrt.Intern("arbace.c2a.main$files$iter__608000022__608000026$fn__608000027$fn__608000028")

var Lit_15 *jrt.String = jrt.Intern("-o")

var Lit_16 *jrt.String = jrt.Intern("--in-place")

var Lit_17 *jrt.String = jrt.Intern("--stdin")

var Lit_18 *jrt.String = jrt.Intern("--rules")

var Lit_19 *jrt.String = jrt.Intern("--keep-ext")

var Lit_20 *jrt.String = jrt.Intern("--ae")

var Lit_21 *jrt.String = jrt.Intern("-q")

var Lit_22 *jrt.String = jrt.Intern("--text")

var Lit_23 *jrt.String = jrt.Intern("--kind")

var Lit_24 *jrt.String = jrt.Intern("--skip")

var Lit_25 *jrt.String = jrt.Intern("-")

var Lit_26 *jrt.String = jrt.Intern("unknown option: ")

var Lit_27 *jrt.String = jrt.Intern(".cljc")

var Lit_28 *jrt.String = jrt.Intern("data_readers")

var Lit_29 *jrt.String = jrt.Intern("data_readers.ae")

var Lit_30 *jrt.String = jrt.Intern("data_readers.clj")

var Lit_31 *jrt.String = jrt.Intern(".ae")

var Lit_32 *jrt.String = jrt.Intern(".ae exists, which Arbace's reader prefers")

var Lit_33 *jrt.String = jrt.Intern(".clj")

var Lit_34 *jrt.String = jrt.Intern(".clj is translated instead, as the reader prefers it")

var Lit_35 *jrt.String = jrt.Intern(".java")

var Lit_36 *jrt.String = jrt.Intern("arbace.c2a.main$plan$fn__608000018")

var Lit_37 *jrt.String = jrt.Intern(".class")

var Lit_38 *jrt.String = jrt.Intern("Rules, in the order they apply:")

var Lit_39 *jrt.String = jrt.Intern("  ")

var Lit_40 *jrt.String = jrt.Intern(": ")

var Lit_41 *jrt.String = jrt.Intern(" ")

var Lit_42 *jrt.String = jrt.Intern("Dialect divergences (doc/VENDOR-NOTES.md):")

var Lit_43 *jrt.String = jrt.Intern("no rule")

var Lit_44 *jrt.String = jrt.Intern(" - ")

var Lit_45 *jrt.String = jrt.Intern("/")

var Lit_46 *jrt.String = jrt.Intern("arbace.c2a.main$run$fn__608000048")

var Lit_47 *jrt.String = jrt.Intern("arbace.c2a.main$run$fn__608000050")

var Lit_48 *jrt.String = jrt.Intern("arbace.c2a.main$run$fn__608000057")

var Lit_49 *jrt.String = jrt.Intern("arbace.c2a.main$run$fn__608000059")

var Lit_50 *jrt.String = jrt.Intern("arbace.c2a.main$run$fn__608000066")

var Lit_51 *jrt.String = jrt.Intern("arbace.c2a.main$run$fn__608000068")

var Lit_52 *jrt.String = jrt.Intern("arbace.c2a.main$run$fn__608000075")

var Lit_53 *jrt.String = jrt.Intern("arbace.c2a.main$run$fn__608000077")

var Lit_54 *jrt.String = jrt.Intern("c2a: skipped")

var Lit_55 *jrt.String = jrt.Intern("arbace.c2a.main$run$fn__608000050$fn__608000051")

var Lit_56 *jrt.String = jrt.Intern("c2a: error in")

var Lit_57 *jrt.String = jrt.Intern("arbace.c2a.main$run$fn__608000059$fn__608000060")

var Lit_58 *jrt.String = jrt.Intern("arbace.c2a.main$run$fn__608000068$fn__608000069")

var Lit_59 *jrt.String = jrt.Intern("arbace.c2a.main$run$fn__608000077$fn__608000078")

var Lit_60 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn4,linekn6,columnkn4,filekn7,privatekn8,arglistskn3,tagyn6,Stringyn8,siblingskn4,keysyn8,keep-extyn4,textyn1,syn1,pyn4,pathyn4,skipyn4,Fileyn7,sourcesyn3,outyn4,optsyn4,argsyn1,&v11,arbace.core5,in-nsMyn15,arbace.c2a.mainm2,R0,s2016,c2a, the Clojure -> Arbace translator (doc/C2A.md): Clojure source files or trees rewritten\n  by the rules of arbace.c2a.rules, their layout and comments kept. bin/c2a runs it.\n\n    c2a [OPTION...] -o OUT SRC...    translate files and trees into the directory OUT\n    c2a --in-place [OPTION...] SRC...  translate them where they are\n    c2a --stdin [--kind K] [--ae]    translate standard input to standard output\n    c2a --rules                      list the rules and the dialect divergences\n\n  A directory SRC is translated into OUT with its relative paths (its contents, not itself).\n  .clj and .cljc files become .ae files: a .cljc file's reader conditionals resolved for\n  Arbace's features (#{:clj}); a .clj and a .cljc of the same name give the .clj's .ae (the\n  reader prefers the .clj), and a .ae already there is kept as it is (the reader prefers it).\n  data_readers.clj/.cljc become data_readers.ae too (Arbace reads it first), but as Arbace reads\n  all three and merges them, one that would collide keeps its name: a data_readers.clj beside a\n  data_readers.ae, a data_readers.cljc beside either. project.clj keeps its name. .java files\n  are renamed as text and keep their names (j2a reads them). With -o, other files are copied\n  as they are, but class files (AOT output cannot be translated: their sources are); in place,\n  they stay.\n\n  Options:\n    --keep-ext       .clj and .cljc files keep their names (and so a .cljc its conditionals,\n                     which Arbace's reader resolves with the feature :clj), as bin/clojure-tests\n                     translates Clojure's test suite\n    --text EXT       files ending in EXT are renamed as text (rule :rename and the like) too,\n                     keeping their names (repeatable; e.g. --text .edn)\n    --skip ID,...    leave these rules out\n    --kind K         --stdin's kind: clj (default), cljc, java or text\n    --ae             --stdin: the text becomes a .ae file (a .cljc's conditionals resolved)\n    -q               quiet: no summarym2,R0,s2016,c2a, the Clojure -> Arbace translator (doc/C2A.md): Clojure source files or trees rewritten\n  by the rules of arbace.c2a.rules, their layout and comments kept. bin/c2a runs it.\n\n    c2a [OPTION...] -o OUT SRC...    translate files and trees into the directory OUT\n    c2a --in-place [OPTION...] SRC...  translate them where they are\n    c2a --stdin [--kind K] [--ae]    translate standard input to standard output\n    c2a --rules                      list the rules and the dialect divergences\n\n  A directory SRC is translated into OUT with its relative paths (its contents, not itself).\n  .clj and .cljc files become .ae files: a .cljc file's reader conditionals resolved for\n  Arbace's features (#{:clj}); a .clj and a .cljc of the same name give the .clj's .ae (the\n  reader prefers the .clj), and a .ae already there is kept as it is (the reader prefers it).\n  data_readers.clj/.cljc become data_readers.ae too (Arbace reads it first), but as Arbace reads\n  all three and merges them, one that would collide keeps its name: a data_readers.clj beside a\n  data_readers.ae, a data_readers.cljc beside either. project.clj keeps its name. .java files\n  are renamed as text and keep their names (j2a reads them). With -o, other files are copied\n  as they are, but class files (AOT output cannot be translated: their sources are); in place,\n  they stay.\n\n  Options:\n    --keep-ext       .clj and .cljc files keep their names (and so a .cljc its conditionals,\n                     which Arbace's reader resolves with the feature :clj), as bin/clojure-tests\n                     translates Clojure's test suite\n    --text EXT       files ending in EXT are renamed as text (rule :rename and the like) too,\n                     keeping their names (repeatable; e.g. --text .edn)\n    --skip ID,...    leave these rules out\n    --kind K         --stdin's kind: clj (default), cljc, java or text\n    --ae             --stdin: the text becomes a .ae file (a .cljc's conditionals resolved)\n    -q               quiet: no summaryR1,v15,arbace.c2a.main10,keep-namesS1,s11,project.cljm6,R2,i36,R3,i1,R4,s18,arbace/c2a/main.aev15,arbace.c2a.main3,extm10,R5,TR6,L1,V1,Myn4,namem2,R7,R8,R2,i38,R3,i1,R4,s18,arbace/c2a/main.aev15,arbace.c2a.main4,basem10,R5,TR6,L1,V1,Myn4,namem2,R7,R8,R2,i41,R3,i1,R4,s18,arbace/c2a/main.aev15,arbace.c2a.main4,planm10,R6,L1,V3,Myn4,namem2,R7,R8,R9,m2,R10,V2,R11,R12,R0,s231,What becomes of the file named name, among its siblings (a set of names), with the options:\n  {:kind K :to-ae BOOL :out NAME} for a file translated, {:copy true} for one copied (or left\n  in place), {:skip REASON} for one left out.R2,i44,R3,i1,R4,s18,arbace/c2a/main.aev15,arbace.c2a.main14,translate-textm10,R6,L1,V4,R13,R14,R15,R16,R0,s42,Text s translated as a file of the plan p.R2,i72,R3,i1,R4,s18,arbace/c2a/main.aev15,arbace.c2a.main5,filesm12,R5,TR6,L1,V1,Myn3,srcm2,R7,R17,R0,s86,[root-dir relative-path] of every file under src (a file: its directory and its name).R2,i77,R3,i1,R4,s18,arbace/c2a/main.aev15,arbace.c2a.main3,runm10,R6,L1,V3,R18,R19,R20,R0,s256,Translates the sources (paths) into out (a directory path), or in place when out is nil.\n  Returns the counts {:translated :to-ae :copied :skipped :unchanged} and prints what was\n  skipped, and errors, to *err*. Throws when a file cannot be read as source.R2,i87,R3,i1,R4,s18,arbace/c2a/main.aev15,arbace.c2a.main10,parse-argsm10,R5,TR6,L1,V1,R21,R2,i131,R3,i1,R4,s18,arbace/c2a/main.aev15,arbace.c2a.main11,print-rulesm10,R5,TR6,L1,V0,R2,i148,R3,i1,R4,s18,arbace/c2a/main.aev15,arbace.c2a.main5,-mainm8,R6,L1,V2,R22,R21,R2,i158,R3,i1,R4,s18,arbace/c2a/main.ae")

var Lit_61 *jrt.String = jrt.Intern("arbace.c2a.main$eval608000004$loading__1927001464__auto____608000005")

var Lit_62 *jrt.String = jrt.Intern("arbace.c2a.main$eval608000008$fn__608000009")

var Lit_63 *jrt.String = jrt.Intern("arbace.c2a.main$ext")

var Lit_64 *jrt.String = jrt.Intern("arbace.c2a.main$base")

var Lit_65 *jrt.String = jrt.Intern("arbace.c2a.main$plan")

var Lit_66 *jrt.String = jrt.Intern("arbace.c2a.main$translate_text")

var Lit_67 *jrt.String = jrt.Intern("arbace.c2a.main$files")

var Lit_68 *jrt.String = jrt.Intern("arbace.c2a.main$run")

var Lit_69 *jrt.String = jrt.Intern("arbace.c2a.main$parse_args")

var Lit_70 *jrt.String = jrt.Intern("arbace.c2a.main$print_rules")

var Lit_71 *jrt.String = jrt.Intern("arbace.c2a.main$_main")
