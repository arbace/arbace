//line aot_arbace_c2a_main__init.ae:1
package aot_arbace_c2a_main

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_c2a_main__init_A_Unit0__O() any { A_arbace_c2a_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(jrt.NN(A_arbace_c2a_main__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_c2a_main__init_A_const_1) }
//line :1:1
func A_arbace_c2a_main__init_A_Unit1__O() any { A_arbace_c2a_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_c2a_main__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_c2a_main__init_A_const_2)) }
//line :1:1
func A_arbace_c2a_main__init_A_Unit2__O() any { A_arbace_c2a_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_c2a_main_eval608000004_loading__1927001464__auto____608000005_A_New(); var tmp2 *jrt.Class; A_arbace_c2a_main_eval608000004_loading__1927001464__auto____608000005_A_Init(); tmp2 = A_arbace_c2a_main_eval608000004_loading__1927001464__auto____608000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_c2a_main__init_A_Unit3__O() any { A_arbace_c2a_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_c2a_main__init_A_const_1)).Equals_O__Z(A_arbace_c2a_main__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_c2a_main_eval608000008_fn__608000009_A_New(); var tmp2 *jrt.Class; A_arbace_c2a_main_eval608000008_fn__608000009_A_Init(); tmp2 = A_arbace_c2a_main_eval608000008_fn__608000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_c2a_main__init_A_Load__O() any { A_arbace_c2a_main__init_A_Init(); A_arbace_c2a_main__init_A_Unit0__O(); A_arbace_c2a_main__init_A_Unit1__O(); A_arbace_c2a_main__init_A_Unit2__O(); A_arbace_c2a_main__init_A_Unit3__O(); A_arbace_c2a_main__init_A_Unit4__O(); A_arbace_c2a_main__init_A_Unit5__O(); A_arbace_c2a_main__init_A_Unit6__O(); A_arbace_c2a_main__init_A_Unit7__O(); A_arbace_c2a_main__init_A_Unit8__O(); A_arbace_c2a_main__init_A_Unit9__O(); A_arbace_c2a_main__init_A_Unit10__O(); A_arbace_c2a_main__init_A_Unit11__O(); A_arbace_c2a_main__init_A_Unit12__O(); A_arbace_c2a_main__init_A_Unit13__O(); return nil }






























func A_arbace_c2a_main__init_A_Unit4__O() any { A_arbace_c2a_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(36, 1); jrt.NN(A_arbace_c2a_main__init_A_const_4).BindRoot_O__V(A_arbace_c2a_main__init_A_const_5); var tmp1 *lang.Var = A_arbace_c2a_main__init_A_const_4; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_main__init_A_const_6)); return A_arbace_c2a_main__init_A_const_4.Ref() }

func A_arbace_c2a_main__init_A_Unit5__O() any { A_arbace_c2a_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(38, 1); var tmp1 *lang.Var = A_arbace_c2a_main__init_A_const_7; var tmp2 any = A_arbace_c2a_main_ext_A_New(); var tmp3 *jrt.Class; A_arbace_c2a_main_ext_A_Init(); tmp3 = A_arbace_c2a_main_ext_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_main__init_A_const_7; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_main__init_A_const_8)); return A_arbace_c2a_main__init_A_const_7.Ref() }


func A_arbace_c2a_main__init_A_Unit6__O() any { A_arbace_c2a_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(41, 1); var tmp1 *lang.Var = A_arbace_c2a_main__init_A_const_9; var tmp2 any = A_arbace_c2a_main_base_A_New(); var tmp3 *jrt.Class; A_arbace_c2a_main_base_A_Init(); tmp3 = A_arbace_c2a_main_base_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_main__init_A_const_9; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_main__init_A_const_10)); return A_arbace_c2a_main__init_A_const_9.Ref() }


func A_arbace_c2a_main__init_A_Unit7__O() any { A_arbace_c2a_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(44, 1); var tmp1 *lang.Var = A_arbace_c2a_main__init_A_const_11; var tmp2 any = A_arbace_c2a_main_plan_A_New(); var tmp3 *jrt.Class; A_arbace_c2a_main_plan_A_Init(); tmp3 = A_arbace_c2a_main_plan_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_main__init_A_const_11; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_main__init_A_const_12)); return A_arbace_c2a_main__init_A_const_11.Ref() }



























func A_arbace_c2a_main__init_A_Unit8__O() any { A_arbace_c2a_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(72, 1); var tmp1 *lang.Var = A_arbace_c2a_main__init_A_const_13; var tmp2 any = A_arbace_c2a_main_translate_text_A_New(); var tmp3 *jrt.Class; A_arbace_c2a_main_translate_text_A_Init(); tmp3 = A_arbace_c2a_main_translate_text_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_main__init_A_const_13; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_main__init_A_const_14)); return A_arbace_c2a_main__init_A_const_13.Ref() }




func A_arbace_c2a_main__init_A_Unit9__O() any { A_arbace_c2a_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(77, 1); var tmp1 *lang.Var = A_arbace_c2a_main__init_A_const_15; var tmp2 any = A_arbace_c2a_main_files_A_New(); var tmp3 *jrt.Class; A_arbace_c2a_main_files_A_Init(); tmp3 = A_arbace_c2a_main_files_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_main__init_A_const_15; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_main__init_A_const_16)); return A_arbace_c2a_main__init_A_const_15.Ref() }









func A_arbace_c2a_main__init_A_Unit10__O() any { A_arbace_c2a_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(87, 1); var tmp1 *lang.Var = A_arbace_c2a_main__init_A_const_17; var tmp2 any = A_arbace_c2a_main_run_A_New(); var tmp3 *jrt.Class; A_arbace_c2a_main_run_A_Init(); tmp3 = A_arbace_c2a_main_run_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_main__init_A_const_17; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_main__init_A_const_18)); return A_arbace_c2a_main__init_A_const_17.Ref() }











































func A_arbace_c2a_main__init_A_Unit11__O() any { A_arbace_c2a_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(131, 1); var tmp1 *lang.Var = A_arbace_c2a_main__init_A_const_19; var tmp2 any = A_arbace_c2a_main_parse_args_A_New(); var tmp3 *jrt.Class; A_arbace_c2a_main_parse_args_A_Init(); tmp3 = A_arbace_c2a_main_parse_args_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_main__init_A_const_19; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_main__init_A_const_20)); return A_arbace_c2a_main__init_A_const_19.Ref() }
















func A_arbace_c2a_main__init_A_Unit12__O() any { A_arbace_c2a_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(148, 1); var tmp1 *lang.Var = A_arbace_c2a_main__init_A_const_21; var tmp2 any = A_arbace_c2a_main_print_rules_A_New(); var tmp3 *jrt.Class; A_arbace_c2a_main_print_rules_A_Init(); tmp3 = A_arbace_c2a_main_print_rules_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_main__init_A_const_21; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_main__init_A_const_22)); return A_arbace_c2a_main__init_A_const_21.Ref() }









func A_arbace_c2a_main__init_A_Unit13__O() any { A_arbace_c2a_main__init_A_Init(); lang.Compiler_AOT_At_I_I__V(158, 1); var tmp1 *lang.Var = A_arbace_c2a_main__init_A_const_23; var tmp2 any = A_arbace_c2a_main__main_A_New(); var tmp3 *jrt.Class; A_arbace_c2a_main__main_A_Init(); tmp3 = A_arbace_c2a_main__main_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_c2a_main__init_A_const_23; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_main__init_A_const_24)); return A_arbace_c2a_main__init_A_const_23.Ref() }



type A_arbace_c2a_main__init_A struct{ jrt.Object }

var A_arbace_c2a_main__init_A_const_0 *lang.Var

var A_arbace_c2a_main__init_A_const_1 any

var A_arbace_c2a_main__init_A_const_2 any

var A_arbace_c2a_main__init_A_const_3 any

var A_arbace_c2a_main__init_A_const_4 *lang.Var

var A_arbace_c2a_main__init_A_const_5 any

var A_arbace_c2a_main__init_A_const_6 any

var A_arbace_c2a_main__init_A_const_7 *lang.Var

var A_arbace_c2a_main__init_A_const_8 any

var A_arbace_c2a_main__init_A_const_9 *lang.Var

var A_arbace_c2a_main__init_A_const_10 any

var A_arbace_c2a_main__init_A_const_11 *lang.Var

var A_arbace_c2a_main__init_A_const_12 any

var A_arbace_c2a_main__init_A_const_13 *lang.Var

var A_arbace_c2a_main__init_A_const_14 any

var A_arbace_c2a_main__init_A_const_15 *lang.Var

var A_arbace_c2a_main__init_A_const_16 any

var A_arbace_c2a_main__init_A_const_17 *lang.Var

var A_arbace_c2a_main__init_A_const_18 any

var A_arbace_c2a_main__init_A_const_19 *lang.Var

var A_arbace_c2a_main__init_A_const_20 any

var A_arbace_c2a_main__init_A_const_21 *lang.Var

var A_arbace_c2a_main__init_A_const_22 any

var A_arbace_c2a_main__init_A_const_23 *lang.Var

var A_arbace_c2a_main__init_A_const_24 any

var A_arbace_c2a_main__init_A_init jrt.ClassInit

func A_arbace_c2a_main__init_A_Init() { if !A_arbace_c2a_main__init_A_init.Done() { A_arbace_c2a_main__init_A_init.Run(A_arbace_c2a_main__init_A_clinit) } }

func A_arbace_c2a_main__init_A_clinit() { A_arbace_c2a_main__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_184); A_arbace_c2a_main__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_13)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15))); A_arbace_c2a_main__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15)); A_arbace_c2a_main__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_c2a_main__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_13, Lit_41); A_arbace_c2a_main__init_A_const_5 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_185)).Ref(); A_arbace_c2a_main__init_A_const_6 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_186).Ref(), jrt.Integer_ValueOf_I__Integer(36).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_187).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_64).Ref(), Lit_188)); A_arbace_c2a_main__init_A_const_7 = lang.RT_Var_String_String__Var(Lit_13, Lit_24); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_189).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_c2a_main__init_A_const_8 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_190).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_96)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_191).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_192).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_186).Ref(), jrt.Integer_ValueOf_I__Integer(38).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_187).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_64).Ref(), Lit_188)); A_arbace_c2a_main__init_A_const_9 = lang.RT_Var_String_String__Var(Lit_13, Lit_34); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_189).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_c2a_main__init_A_const_10 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_190).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_96)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_191).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_192).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_186).Ref(), jrt.Integer_ValueOf_I__Integer(41).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_187).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_64).Ref(), Lit_188)); A_arbace_c2a_main__init_A_const_11 = lang.RT_Var_String_String__Var(Lit_13, Lit_67); A_arbace_c2a_main__init_A_const_12 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_190).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_96)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_191).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_192).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_193).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_194).Ref(), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_22).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_23).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_195, lang.RT_Keyword_String_String__Keyword(nil, Lit_186).Ref(), jrt.Integer_ValueOf_I__Integer(44).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_187).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_64).Ref(), Lit_188)); A_arbace_c2a_main__init_A_const_13 = lang.RT_Var_String_String__Var(Lit_13, Lit_72); A_arbace_c2a_main__init_A_const_14 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_190).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_196).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_197).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_45).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_35).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_198, lang.RT_Keyword_String_String__Keyword(nil, Lit_186).Ref(), jrt.Integer_ValueOf_I__Integer(72).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_187).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_64).Ref(), Lit_188)); A_arbace_c2a_main__init_A_const_15 = lang.RT_Var_String_String__Var(Lit_13, Lit_65); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_189).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_c2a_main__init_A_const_16 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_190).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_199)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_191).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_200).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_201, lang.RT_Keyword_String_String__Keyword(nil, Lit_186).Ref(), jrt.Integer_ValueOf_I__Integer(77).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_187).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_64).Ref(), Lit_188)); A_arbace_c2a_main__init_A_const_17 = lang.RT_Var_String_String__Var(Lit_13, Lit_109); A_arbace_c2a_main__init_A_const_18 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_190).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_30).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_202).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_203, lang.RT_Keyword_String_String__Keyword(nil, Lit_186).Ref(), jrt.Integer_ValueOf_I__Integer(87).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_187).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_64).Ref(), Lit_188)); A_arbace_c2a_main__init_A_const_19 = lang.RT_Var_String_String__Var(Lit_13, Lit_105); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_189).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_c2a_main__init_A_const_20 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_190).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_204).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_186).Ref(), jrt.Integer_ValueOf_I__Integer(131).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_187).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_64).Ref(), Lit_188)); A_arbace_c2a_main__init_A_const_21 = lang.RT_Var_String_String__Var(Lit_13, Lit_106); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_189).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_c2a_main__init_A_const_22 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_190).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_186).Ref(), jrt.Integer_ValueOf_I__Integer(148).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_187).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_64).Ref(), Lit_188)); A_arbace_c2a_main__init_A_const_23 = lang.RT_Var_String_String__Var(Lit_13, Lit_205); A_arbace_c2a_main__init_A_const_24 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_190).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_206).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_204).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_186).Ref(), jrt.Integer_ValueOf_I__Integer(158).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_187).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_64).Ref(), Lit_188)) }

func A_arbace_c2a_main__init_A_New() *A_arbace_c2a_main__init_A { A_arbace_c2a_main__init_A_Init(); t := &A_arbace_c2a_main__init_A{}; t.Ctor(); return t }

func (t *A_arbace_c2a_main__init_A) Ctor() {}

func (t *A_arbace_c2a_main__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_main__init_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_main__init_A_class }

func (t *A_arbace_c2a_main__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_main__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_main__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_main__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_main__init_A); return ok }

func A_arbace_c2a_main__init_A_Cast(x any) *A_arbace_c2a_main__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_main__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_main__init_A_class)) }; return v }
