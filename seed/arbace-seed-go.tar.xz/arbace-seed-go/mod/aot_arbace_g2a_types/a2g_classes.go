//line a2g_classes.ae:1
package aot_arbace_g2a_types

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_g2a_types_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_types_A_New()}; return nil }

var A_arbace_g2a_types_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_types_A_new}

var A_arbace_g2a_types_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.types", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_g2a_types.A_arbace_g2a_types_A"})

func init() { i := A_arbace_g2a_types_A_class.Info(); i.IsInstance = A_arbace_g2a_types_A_InstanceOf; i.Init = A_arbace_g2a_types_A_Init; i.Table = A_arbace_g2a_types_A_members; jrt.RegisterGoType(A_arbace_g2a_types_A_class, reflect.TypeFor[A_arbace_g2a_types_A]()) }

func A_arbace_g2a_types_const_kind_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_types_const_kind_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_types_const_kind_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_types_const_kind_A_New()}; return nil }

func A_arbace_g2a_types_const_kind_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_types_const_kind_A_fn_class)}; return nil }

var A_arbace_g2a_types_const_kind_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_types_const_kind_A_invoke, New: A_arbace_g2a_types_const_kind_A_new, Get: A_arbace_g2a_types_const_kind_A_get}

var A_arbace_g2a_types_const_kind_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.types$const_kind", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_types_A_class, Simple: "const_kind", Go: "arbace/aot_arbace_g2a_types.A_arbace_g2a_types_const_kind_A", Source: "types.ae"})

func init() { i := A_arbace_g2a_types_const_kind_A_class.Info(); i.IsInstance = A_arbace_g2a_types_const_kind_A_InstanceOf; i.Init = A_arbace_g2a_types_const_kind_A_Init; i.Table = A_arbace_g2a_types_const_kind_A_members; jrt.RegisterGoType(A_arbace_g2a_types_const_kind_A_class, reflect.TypeFor[A_arbace_g2a_types_const_kind_A]()) }

func A_arbace_g2a_types_entry_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_types_entry_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_types_entry_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_types_entry_A_New()}; return nil }

func A_arbace_g2a_types_entry_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_types_entry_A_fn_class)}; return nil }

var A_arbace_g2a_types_entry_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_types_entry_A_invoke, New: A_arbace_g2a_types_entry_A_new, Get: A_arbace_g2a_types_entry_A_get}

var A_arbace_g2a_types_entry_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.types$entry", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_types_A_class, Simple: "entry", Go: "arbace/aot_arbace_g2a_types.A_arbace_g2a_types_entry_A", Source: "types.ae"})

func init() { i := A_arbace_g2a_types_entry_A_class.Info(); i.IsInstance = A_arbace_g2a_types_entry_A_InstanceOf; i.Init = A_arbace_g2a_types_entry_A_Init; i.Table = A_arbace_g2a_types_entry_A_members; jrt.RegisterGoType(A_arbace_g2a_types_entry_A_class, reflect.TypeFor[A_arbace_g2a_types_entry_A]()) }

func A_arbace_g2a_types_eval1376000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_types_eval1376000004_A_New()}; return nil }

var A_arbace_g2a_types_eval1376000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_types_eval1376000004_A_new}

var A_arbace_g2a_types_eval1376000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.types$eval1376000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_types_A_class, Simple: "eval1376000004", Go: "arbace/aot_arbace_g2a_types.A_arbace_g2a_types_eval1376000004_A"})

func init() { i := A_arbace_g2a_types_eval1376000004_A_class.Info(); i.IsInstance = A_arbace_g2a_types_eval1376000004_A_InstanceOf; i.Table = A_arbace_g2a_types_eval1376000004_A_members; jrt.RegisterGoType(A_arbace_g2a_types_eval1376000004_A_class, reflect.TypeFor[A_arbace_g2a_types_eval1376000004_A]()) }

func A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A_New()}; return nil }

func A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A_fn_class)}; return nil }

var A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A_invoke, New: A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A_new, Get: A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A_get}

var A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.types$eval1376000004$loading__1927001464__auto____1376000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_types_eval1376000004_A_class, Simple: "loading__1927001464__auto____1376000005", Go: "arbace/aot_arbace_g2a_types.A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A", Source: "types.ae"})

func init() { i := A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A_class.Info(); i.IsInstance = A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A_InstanceOf; i.Init = A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A_Init; i.Table = A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A_members; jrt.RegisterGoType(A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A_class, reflect.TypeFor[A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A]()) }

func A_arbace_g2a_types_eval1376000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_types_eval1376000008_A_New()}; return nil }

var A_arbace_g2a_types_eval1376000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_g2a_types_eval1376000008_A_new}

var A_arbace_g2a_types_eval1376000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.types$eval1376000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_g2a_types_A_class, Simple: "eval1376000008", Go: "arbace/aot_arbace_g2a_types.A_arbace_g2a_types_eval1376000008_A"})

func init() { i := A_arbace_g2a_types_eval1376000008_A_class.Info(); i.IsInstance = A_arbace_g2a_types_eval1376000008_A_InstanceOf; i.Table = A_arbace_g2a_types_eval1376000008_A_members; jrt.RegisterGoType(A_arbace_g2a_types_eval1376000008_A_class, reflect.TypeFor[A_arbace_g2a_types_eval1376000008_A]()) }

func A_arbace_g2a_types_eval1376000008_fn__1376000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_types_eval1376000008_fn__1376000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_types_eval1376000008_fn__1376000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_types_eval1376000008_fn__1376000009_A_New()}; return nil }

func A_arbace_g2a_types_eval1376000008_fn__1376000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_types_eval1376000008_fn__1376000009_A_fn_class)}; return nil }

var A_arbace_g2a_types_eval1376000008_fn__1376000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_types_eval1376000008_fn__1376000009_A_invoke, New: A_arbace_g2a_types_eval1376000008_fn__1376000009_A_new, Get: A_arbace_g2a_types_eval1376000008_fn__1376000009_A_get}

var A_arbace_g2a_types_eval1376000008_fn__1376000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.types$eval1376000008$fn__1376000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_types_eval1376000008_A_class, Simple: "fn__1376000009", Go: "arbace/aot_arbace_g2a_types.A_arbace_g2a_types_eval1376000008_fn__1376000009_A", Source: "types.ae"})

func init() { i := A_arbace_g2a_types_eval1376000008_fn__1376000009_A_class.Info(); i.IsInstance = A_arbace_g2a_types_eval1376000008_fn__1376000009_A_InstanceOf; i.Init = A_arbace_g2a_types_eval1376000008_fn__1376000009_A_Init; i.Table = A_arbace_g2a_types_eval1376000008_fn__1376000009_A_members; jrt.RegisterGoType(A_arbace_g2a_types_eval1376000008_fn__1376000009_A_class, reflect.TypeFor[A_arbace_g2a_types_eval1376000008_fn__1376000009_A]()) }

func A_arbace_g2a_types_method_elem_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_types_method_elem_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_types_method_elem_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_types_method_elem_A_New()}; return nil }

func A_arbace_g2a_types_method_elem_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_types_method_elem_A_fn_class)}; return nil }

var A_arbace_g2a_types_method_elem_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_types_method_elem_A_invoke, New: A_arbace_g2a_types_method_elem_A_new, Get: A_arbace_g2a_types_method_elem_A_get}

var A_arbace_g2a_types_method_elem_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.types$method_elem", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_types_A_class, Simple: "method_elem", Go: "arbace/aot_arbace_g2a_types.A_arbace_g2a_types_method_elem_A", Source: "types.ae"})

func init() { i := A_arbace_g2a_types_method_elem_A_class.Info(); i.IsInstance = A_arbace_g2a_types_method_elem_A_InstanceOf; i.Init = A_arbace_g2a_types_method_elem_A_Init; i.Table = A_arbace_g2a_types_method_elem_A_members; jrt.RegisterGoType(A_arbace_g2a_types_method_elem_A_class, reflect.TypeFor[A_arbace_g2a_types_method_elem_A]()) }

func A_arbace_g2a_types_ns_name_of_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_types_ns_name_of_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_types_ns_name_of_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_types_ns_name_of_A_New()}; return nil }

func A_arbace_g2a_types_ns_name_of_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_types_ns_name_of_A_fn_class)}; return nil }

var A_arbace_g2a_types_ns_name_of_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_types_ns_name_of_A_invoke, New: A_arbace_g2a_types_ns_name_of_A_new, Get: A_arbace_g2a_types_ns_name_of_A_get}

var A_arbace_g2a_types_ns_name_of_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.types$ns_name_of", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_types_A_class, Simple: "ns_name_of", Go: "arbace/aot_arbace_g2a_types.A_arbace_g2a_types_ns_name_of_A", Source: "types.ae"})

func init() { i := A_arbace_g2a_types_ns_name_of_A_class.Info(); i.IsInstance = A_arbace_g2a_types_ns_name_of_A_InstanceOf; i.Init = A_arbace_g2a_types_ns_name_of_A_Init; i.Table = A_arbace_g2a_types_ns_name_of_A_members; jrt.RegisterGoType(A_arbace_g2a_types_ns_name_of_A_class, reflect.TypeFor[A_arbace_g2a_types_ns_name_of_A]()) }

func A_arbace_g2a_types_ns_name_of_fn__1376000014_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_types_ns_name_of_fn__1376000014_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_types_ns_name_of_fn__1376000014_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_types_ns_name_of_fn__1376000014_A_New()}; return nil }

func A_arbace_g2a_types_ns_name_of_fn__1376000014_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_types_ns_name_of_fn__1376000014_A_fn_class)}; return nil }

var A_arbace_g2a_types_ns_name_of_fn__1376000014_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_types_ns_name_of_fn__1376000014_A_invoke, New: A_arbace_g2a_types_ns_name_of_fn__1376000014_A_new, Get: A_arbace_g2a_types_ns_name_of_fn__1376000014_A_get}

var A_arbace_g2a_types_ns_name_of_fn__1376000014_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.types$ns_name_of$fn__1376000014", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_types_ns_name_of_A_class, Simple: "fn__1376000014", Go: "arbace/aot_arbace_g2a_types.A_arbace_g2a_types_ns_name_of_fn__1376000014_A", Source: "types.ae"})

func init() { i := A_arbace_g2a_types_ns_name_of_fn__1376000014_A_class.Info(); i.IsInstance = A_arbace_g2a_types_ns_name_of_fn__1376000014_A_InstanceOf; i.Init = A_arbace_g2a_types_ns_name_of_fn__1376000014_A_Init; i.Table = A_arbace_g2a_types_ns_name_of_fn__1376000014_A_members; jrt.RegisterGoType(A_arbace_g2a_types_ns_name_of_fn__1376000014_A_class, reflect.TypeFor[A_arbace_g2a_types_ns_name_of_fn__1376000014_A]()) }

func A_arbace_g2a_types_params_vec_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_types_params_vec_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_types_params_vec_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_types_params_vec_A_New()}; return nil }

func A_arbace_g2a_types_params_vec_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_types_params_vec_A_fn_class)}; return nil }

var A_arbace_g2a_types_params_vec_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_types_params_vec_A_invoke, New: A_arbace_g2a_types_params_vec_A_new, Get: A_arbace_g2a_types_params_vec_A_get}

var A_arbace_g2a_types_params_vec_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.types$params_vec", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_types_A_class, Simple: "params_vec", Go: "arbace/aot_arbace_g2a_types.A_arbace_g2a_types_params_vec_A", Source: "types.ae"})

func init() { i := A_arbace_g2a_types_params_vec_A_class.Info(); i.IsInstance = A_arbace_g2a_types_params_vec_A_InstanceOf; i.Init = A_arbace_g2a_types_params_vec_A_Init; i.Table = A_arbace_g2a_types_params_vec_A_members; jrt.RegisterGoType(A_arbace_g2a_types_params_vec_A_class, reflect.TypeFor[A_arbace_g2a_types_params_vec_A]()) }

func A_arbace_g2a_types_params_vec_fn__1376000018_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_types_params_vec_fn__1376000018_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_types_params_vec_fn__1376000018_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_types_params_vec_fn__1376000018_A_New_I_O(args[0].(int32), args[1])}; return nil }

func A_arbace_g2a_types_params_vec_fn__1376000018_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_types_params_vec_fn__1376000018_A_fn_class)}; return nil }

var A_arbace_g2a_types_params_vec_fn__1376000018_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_types_params_vec_fn__1376000018_A_invoke, New: A_arbace_g2a_types_params_vec_fn__1376000018_A_new, Get: A_arbace_g2a_types_params_vec_fn__1376000018_A_get}

var A_arbace_g2a_types_params_vec_fn__1376000018_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.types$params_vec$fn__1376000018", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_types_params_vec_A_class, Simple: "fn__1376000018", Go: "arbace/aot_arbace_g2a_types.A_arbace_g2a_types_params_vec_fn__1376000018_A", Source: "types.ae"})

func init() { i := A_arbace_g2a_types_params_vec_fn__1376000018_A_class.Info(); i.IsInstance = A_arbace_g2a_types_params_vec_fn__1376000018_A_InstanceOf; i.Init = A_arbace_g2a_types_params_vec_fn__1376000018_A_Init; i.Table = A_arbace_g2a_types_params_vec_fn__1376000018_A_members; jrt.RegisterGoType(A_arbace_g2a_types_params_vec_fn__1376000018_A_class, reflect.TypeFor[A_arbace_g2a_types_params_vec_fn__1376000018_A]()) }

func A_arbace_g2a_types_qualify_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_types_qualify_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_g2a_types_qualify_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_types_qualify_A_New()}; return nil }

func A_arbace_g2a_types_qualify_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_types_qualify_A_fn_class)}; return nil }

var A_arbace_g2a_types_qualify_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_types_qualify_A_invoke, New: A_arbace_g2a_types_qualify_A_new, Get: A_arbace_g2a_types_qualify_A_get}

var A_arbace_g2a_types_qualify_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.types$qualify", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_g2a_types_A_class, Simple: "qualify", Go: "arbace/aot_arbace_g2a_types.A_arbace_g2a_types_qualify_A", Source: "types.ae"})

func init() { i := A_arbace_g2a_types_qualify_A_class.Info(); i.IsInstance = A_arbace_g2a_types_qualify_A_InstanceOf; i.Init = A_arbace_g2a_types_qualify_A_Init; i.Table = A_arbace_g2a_types_qualify_A_members; jrt.RegisterGoType(A_arbace_g2a_types_qualify_A_class, reflect.TypeFor[A_arbace_g2a_types_qualify_A]()) }

func A_arbace_g2a_types_type_form_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_types_type_form_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_types_type_form_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_types_type_form_A_New()}; return nil }

func A_arbace_g2a_types_type_form_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_types_type_form_A_fn_class)}; return nil }

var A_arbace_g2a_types_type_form_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_types_type_form_A_invoke, New: A_arbace_g2a_types_type_form_A_new, Get: A_arbace_g2a_types_type_form_A_get}

var A_arbace_g2a_types_type_form_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.types$type_form", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_types_A_class, Simple: "type_form", Go: "arbace/aot_arbace_g2a_types.A_arbace_g2a_types_type_form_A", Source: "types.ae"})

func init() { i := A_arbace_g2a_types_type_form_A_class.Info(); i.IsInstance = A_arbace_g2a_types_type_form_A_InstanceOf; i.Init = A_arbace_g2a_types_type_form_A_Init; i.Table = A_arbace_g2a_types_type_form_A_members; jrt.RegisterGoType(A_arbace_g2a_types_type_form_A_class, reflect.TypeFor[A_arbace_g2a_types_type_form_A]()) }

func A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_New()}; return nil }

func A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_fn_class)}; return nil }

var A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_invoke, New: A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_new, Get: A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_get}

var A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.types$type_form$iter__1376000027__1376000031", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_types_type_form_A_class, Simple: "iter__1376000027__1376000031", Go: "arbace/aot_arbace_g2a_types.A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A", Source: "types.ae"})

func init() { i := A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_class.Info(); i.IsInstance = A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_InstanceOf; i.Init = A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_Init; i.Table = A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_members; jrt.RegisterGoType(A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_class, reflect.TypeFor[A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A]()) }

func A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_fn_class)}; return nil }

var A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_invoke, New: A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_new, Get: A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_get}

var A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.types$type_form$iter__1376000027__1376000031$fn__1376000032", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_class, Simple: "fn__1376000032", Go: "arbace/aot_arbace_g2a_types.A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A", Source: "types.ae"})

func init() { i := A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_class.Info(); i.IsInstance = A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_InstanceOf; i.Init = A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_Init; i.Table = A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_members; jrt.RegisterGoType(A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_class, reflect.TypeFor[A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A]()) }

func A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_fn_class)}; return nil }

var A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_invoke, New: A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_new, Get: A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_get}

var A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.types$type_form$iter__1376000027__1376000031$fn__1376000032$fn__1376000033", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_class, Simple: "fn__1376000033", Go: "arbace/aot_arbace_g2a_types.A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A", Source: "types.ae"})

func init() { i := A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_class.Info(); i.IsInstance = A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_InstanceOf; i.Init = A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_Init; i.Table = A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_members; jrt.RegisterGoType(A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_class, reflect.TypeFor[A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A]()) }

func A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_New()}; return nil }

func A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_fn_class)}; return nil }

var A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_invoke, New: A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_new, Get: A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_get}

var A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.types$type_form$iter__1376000037__1376000041", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_types_type_form_A_class, Simple: "iter__1376000037__1376000041", Go: "arbace/aot_arbace_g2a_types.A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A", Source: "types.ae"})

func init() { i := A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_class.Info(); i.IsInstance = A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_InstanceOf; i.Init = A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_Init; i.Table = A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_members; jrt.RegisterGoType(A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_class, reflect.TypeFor[A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A]()) }

func A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_fn_class)}; return nil }

var A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_invoke, New: A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_new, Get: A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_get}

var A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.types$type_form$iter__1376000037__1376000041$fn__1376000042", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_class, Simple: "fn__1376000042", Go: "arbace/aot_arbace_g2a_types.A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A", Source: "types.ae"})

func init() { i := A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_class.Info(); i.IsInstance = A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_InstanceOf; i.Init = A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_Init; i.Table = A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_members; jrt.RegisterGoType(A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_class, reflect.TypeFor[A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A]()) }

func A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_fn_class)}; return nil }

var A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_invoke, New: A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_new, Get: A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_get}

var A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.types$type_form$iter__1376000037__1376000041$fn__1376000042$fn__1376000043", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_class, Simple: "fn__1376000043", Go: "arbace/aot_arbace_g2a_types.A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A", Source: "types.ae"})

func init() { i := A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_class.Info(); i.IsInstance = A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_InstanceOf; i.Init = A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_Init; i.Table = A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_members; jrt.RegisterGoType(A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_class, reflect.TypeFor[A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A]()) }

func A_arbace_g2a_types_untyped_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_g2a_types_untyped_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_g2a_types_untyped_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_types_untyped_QMARK__A_New()}; return nil }

func A_arbace_g2a_types_untyped_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_g2a_types_untyped_QMARK__A_fn_class)}; return nil }

var A_arbace_g2a_types_untyped_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_g2a_types_untyped_QMARK__A_invoke, New: A_arbace_g2a_types_untyped_QMARK__A_new, Get: A_arbace_g2a_types_untyped_QMARK__A_get}

var A_arbace_g2a_types_untyped_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.types$untyped_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_g2a_types_A_class, Simple: "untyped_QMARK_", Go: "arbace/aot_arbace_g2a_types.A_arbace_g2a_types_untyped_QMARK__A", Source: "types.ae"})

func init() { i := A_arbace_g2a_types_untyped_QMARK__A_class.Info(); i.IsInstance = A_arbace_g2a_types_untyped_QMARK__A_InstanceOf; i.Init = A_arbace_g2a_types_untyped_QMARK__A_Init; i.Table = A_arbace_g2a_types_untyped_QMARK__A_members; jrt.RegisterGoType(A_arbace_g2a_types_untyped_QMARK__A_class, reflect.TypeFor[A_arbace_g2a_types_untyped_QMARK__A]()) }

func A_arbace_g2a_types__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_g2a_types__init_A_Load__O(); case 1: return A_arbace_g2a_types__init_A_Unit0__O(); case 2: return A_arbace_g2a_types__init_A_Unit1__O(); case 3: return A_arbace_g2a_types__init_A_Unit10__O(); case 4: return A_arbace_g2a_types__init_A_Unit11__O(); case 5: return A_arbace_g2a_types__init_A_Unit12__O(); case 6: return A_arbace_g2a_types__init_A_Unit13__O(); case 7: return A_arbace_g2a_types__init_A_Unit14__O(); case 8: return A_arbace_g2a_types__init_A_Unit15__O(); case 9: return A_arbace_g2a_types__init_A_Unit16__O(); case 10: return A_arbace_g2a_types__init_A_Unit17__O(); case 11: return A_arbace_g2a_types__init_A_Unit18__O(); case 12: return A_arbace_g2a_types__init_A_Unit2__O(); case 13: return A_arbace_g2a_types__init_A_Unit3__O(); case 14: return A_arbace_g2a_types__init_A_Unit4__O(); case 15: return A_arbace_g2a_types__init_A_Unit5__O(); case 16: return A_arbace_g2a_types__init_A_Unit6__O(); case 17: return A_arbace_g2a_types__init_A_Unit7__O(); case 18: return A_arbace_g2a_types__init_A_Unit8__O(); case 19: return A_arbace_g2a_types__init_A_Unit9__O()}; return nil }

func A_arbace_g2a_types__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_g2a_types__init_A_New()}; return nil }

var A_arbace_g2a_types__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_g2a_types__init_A_invoke, New: A_arbace_g2a_types__init_A_new}

var A_arbace_g2a_types__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.g2a.types__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_g2a_types.A_arbace_g2a_types__init_A", Source: "types.ae"})

func init() { i := A_arbace_g2a_types__init_A_class.Info(); i.IsInstance = A_arbace_g2a_types__init_A_InstanceOf; i.Init = A_arbace_g2a_types__init_A_Init; i.Table = A_arbace_g2a_types__init_A_members; jrt.RegisterGoType(A_arbace_g2a_types__init_A_class, reflect.TypeFor[A_arbace_g2a_types__init_A]()) }
