//line a2g_strings.ae:1
package aot_arbace_g2a_types

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("commute")

var Lit_3 *jrt.String = jrt.Intern("deref")

var Lit_4 *jrt.String = jrt.Intern("conj")

var Lit_5 *jrt.String = jrt.Intern("arbace.g2a.types")

var Lit_6 *jrt.String = jrt.Intern("doc")

var Lit_7 *jrt.String = jrt.Intern("Type forms (doc/go/SPEC.md §5) from the helper's type table (doc/go/HELPER-NOTES.md,\n  \"Types\"): for what the converter writes that the source did not spell, the type arguments\n  of :inst (§5.5) and the :tag of an expression (§8.3).\n\n  Named types, aliases and type parameters are written by name: unqualified in their own\n  package, by the file's import name when the file imports their package, and otherwise by\n  their package's namespace (§4.4).")

var Lit_8 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_9 *jrt.String = jrt.Intern("*table*")

var Lit_10 *jrt.String = jrt.Intern("symbol")

var Lit_11 *jrt.String = jrt.Intern("apply")

var Lit_12 *jrt.String = jrt.Intern("str")

var Lit_13 *jrt.String = jrt.Intern("interpose")

var Lit_14 *jrt.String = jrt.Intern("map")

var Lit_15 *jrt.String = jrt.Intern("java.lang.String")

var Lit_16 *jrt.String = jrt.Intern("*pkg*")

var Lit_17 *jrt.String = jrt.Intern("contains?")

var Lit_18 *jrt.String = jrt.Intern("else")

var Lit_19 *jrt.String = jrt.Intern("*imports*")

var Lit_20 *jrt.String = jrt.Intern("ns-name-of")

var Lit_21 *jrt.String = jrt.Intern("vec")

var Lit_22 *jrt.String = jrt.Intern("mapcat")

var Lit_23 *jrt.String = jrt.Intern("&")

var Lit_24 *jrt.String = jrt.Intern("type-form")

var Lit_25 *jrt.String = jrt.Intern("t")

var Lit_26 *jrt.String = jrt.Intern("range")

var Lit_27 *jrt.String = jrt.Intern("next")

var Lit_28 *jrt.String = jrt.Intern("to-array")

var Lit_29 *jrt.String = jrt.Intern("seq")

var Lit_30 *jrt.String = jrt.Intern("first")

var Lit_31 *jrt.String = jrt.Intern("name")

var Lit_32 *jrt.String = jrt.Intern("entry")

var Lit_33 *jrt.String = jrt.Intern("params-vec")

var Lit_34 *jrt.String = jrt.Intern("results")

var Lit_35 *jrt.String = jrt.Intern("empty?")

var Lit_36 *jrt.String = jrt.Intern("list")

var Lit_37 *jrt.String = jrt.Intern("params")

var Lit_38 *jrt.String = jrt.Intern("variadic")

var Lit_39 *jrt.String = jrt.Intern("with-meta")

var Lit_40 *jrt.String = jrt.Intern("tag")

var Lit_41 *jrt.String = jrt.Intern("mapv")

var Lit_42 *jrt.String = jrt.Intern("comp")

var Lit_43 *jrt.String = jrt.Intern("kind")

var Lit_44 *jrt.String = jrt.Intern("chan")

var Lit_45 *jrt.String = jrt.Intern("dir")

var Lit_46 *jrt.String = jrt.Intern("recv")

var Lit_47 *jrt.String = jrt.Intern("both")

var Lit_48 *jrt.String = jrt.Intern("send")

var Lit_49 *jrt.String = jrt.Intern("pointer")

var Lit_50 *jrt.String = jrt.Intern("union")

var Lit_51 *jrt.String = jrt.Intern("ex-info")

var Lit_52 *jrt.String = jrt.Intern("key")

var Lit_53 *jrt.String = jrt.Intern("elem")

var Lit_54 *jrt.String = jrt.Intern("*")

var Lit_55 *jrt.String = jrt.Intern("struct")

var Lit_56 *jrt.String = jrt.Intern("|")

var Lit_57 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_58 *jrt.String = jrt.Intern("chunk-first")

var Lit_59 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_60 *jrt.String = jrt.Intern("chunk-append")

var Lit_61 *jrt.String = jrt.Intern("tilde")

var Lit_62 *jrt.String = jrt.Intern("chunk-cons")

var Lit_63 *jrt.String = jrt.Intern("cons")

var Lit_64 *jrt.String = jrt.Intern("chunk")

var Lit_65 *jrt.String = jrt.Intern("chunk-rest")

var Lit_66 *jrt.String = jrt.Intern("rest")

var Lit_67 *jrt.String = jrt.Intern("terms")

var Lit_68 *jrt.String = jrt.Intern("type-param")

var Lit_69 *jrt.String = jrt.Intern("embedded")

var Lit_70 *jrt.String = jrt.Intern("vary-meta")

var Lit_71 *jrt.String = jrt.Intern("assoc")

var Lit_72 *jrt.String = jrt.Intern("go")

var Lit_73 *jrt.String = jrt.Intern("fields")

var Lit_74 *jrt.String = jrt.Intern("array")

var Lit_75 *jrt.String = jrt.Intern("basic")

var Lit_76 *jrt.String = jrt.Intern("pkg")

var Lit_77 *jrt.String = jrt.Intern("qualify")

var Lit_78 *jrt.String = jrt.Intern("len")

var Lit_79 *jrt.String = jrt.Intern("func")

var Lit_80 *jrt.String = jrt.Intern("interface")

var Lit_81 *jrt.String = jrt.Intern("tuple")

var Lit_82 *jrt.String = jrt.Intern("concat")

var Lit_83 *jrt.String = jrt.Intern("method-elem")

var Lit_84 *jrt.String = jrt.Intern("methods")

var Lit_85 *jrt.String = jrt.Intern("embeddeds")

var Lit_86 *jrt.String = jrt.Intern("alias")

var Lit_87 *jrt.String = jrt.Intern("origin")

var Lit_88 *jrt.String = jrt.Intern("namespace")

var Lit_89 *jrt.String = jrt.Intern("reserved-type-heads")

var Lit_90 *jrt.String = jrt.Intern("values")

var Lit_91 *jrt.String = jrt.Intern("vars")

var Lit_92 *jrt.String = jrt.Intern("slice")

var Lit_93 *jrt.String = jrt.Intern("inst")

var Lit_94 *jrt.String = jrt.Intern("args")

var Lit_95 *jrt.String = jrt.Intern("named")

var Lit_96 *jrt.String = jrt.Intern("pr-str")

var Lit_97 *jrt.String = jrt.Intern("id")

var Lit_98 *jrt.String = jrt.Intern("const-kind")

var Lit_99 *jrt.String = jrt.Intern("basic-kinds")

var Lit_100 *jrt.String = jrt.Intern("int")

var Lit_101 *jrt.String = jrt.Intern("*underlying*")

var Lit_102 *jrt.String = jrt.Intern("actual")

var Lit_103 *jrt.String = jrt.Intern("arbace.g2a.types$const_kind")

var Lit_104 *jrt.String = jrt.Intern("arbace.g2a.types$entry")

var Lit_105 *jrt.String = jrt.Intern("arbace.g2a.types$eval1376000004$loading__1927001464__auto____1376000005")

var Lit_106 *jrt.String = jrt.Intern("arbace.g2a.types$eval1376000008$fn__1376000009")

var Lit_107 *jrt.String = jrt.Intern("arbace.g2a.types$method_elem")

var Lit_108 *jrt.String = jrt.Intern("arbace.g2a.types$ns_name_of")

var Lit_109 *jrt.String = jrt.Intern("go.")

var Lit_110 *jrt.String = jrt.Intern(".")

var Lit_111 *jrt.String = jrt.Intern("split")

var Lit_112 *jrt.String = jrt.Intern("/")

var Lit_113 *jrt.String = jrt.Intern("arbace.g2a.types$ns_name_of$fn__1376000014")

var Lit_114 *jrt.String = jrt.Intern("replaceAll")

var Lit_115 *jrt.String = jrt.Intern("[.-]")

var Lit_116 *jrt.String = jrt.Intern("_")

var Lit_117 *jrt.String = jrt.Intern("arbace.g2a.types$params_vec")

var Lit_118 *jrt.String = jrt.Intern("arbace.g2a.types$params_vec$fn__1376000018")

var Lit_119 *jrt.String = jrt.Intern("arbace.g2a.types$qualify")

var Lit_120 *jrt.String = jrt.Intern("arbace.g2a.types$type_form")

var Lit_121 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_122 *jrt.String = jrt.Intern("type entry ")

var Lit_123 *jrt.String = jrt.Intern(": ")

var Lit_124 *jrt.String = jrt.Intern("arbace.g2a.types$type_form$iter__1376000027__1376000031")

var Lit_125 *jrt.String = jrt.Intern("arbace.g2a.types$type_form$iter__1376000027__1376000031$fn__1376000032")

var Lit_126 *jrt.String = jrt.Intern("arbace.g2a.types$type_form$iter__1376000027__1376000031$fn__1376000032$fn__1376000033")

var Lit_127 *jrt.String = jrt.Intern("arbace.g2a.types$type_form$iter__1376000037__1376000041")

var Lit_128 *jrt.String = jrt.Intern("arbace.g2a.types$type_form$iter__1376000037__1376000041$fn__1376000042")

var Lit_129 *jrt.String = jrt.Intern("arbace.g2a.types$type_form$iter__1376000037__1376000041$fn__1376000042$fn__1376000043")

var Lit_130 *jrt.String = jrt.Intern("arbace.g2a.types$untyped_QMARK_")

var Lit_131 *jrt.String = jrt.Intern("untyped")

var Lit_132 *jrt.String = jrt.Intern("in-ns")

var Lit_133 *jrt.String = jrt.Intern("dynamic")

var Lit_134 *jrt.String = jrt.Intern("line")

var Lit_135 *jrt.String = jrt.Intern("column")

var Lit_136 *jrt.String = jrt.Intern("file")

var Lit_137 *jrt.String = jrt.Intern("arbace/g2a/types.ae")

var Lit_138 *jrt.String = jrt.Intern("The dump's :type-table, a vector.")

var Lit_139 *jrt.String = jrt.Intern("The import path of the package converted.")

var Lit_140 *jrt.String = jrt.Intern("The file's imports: {path name} for the imports with a usable name (not _ or .).")

var Lit_141 *jrt.String = jrt.Intern("{type-id underlying-id} of the named types declared in the package (the dump's :types).")

var Lit_142 *jrt.String = jrt.Intern("arglists")

var Lit_143 *jrt.String = jrt.Intern("Type heads (§5.1): a generic type of one of these names is instantiated with inst.")

var Lit_144 *jrt.String = jrt.Intern("path")

var Lit_145 *jrt.String = jrt.Intern("The namespace of a Go import path (§4.1): go. plus the path, / as ., and . and - inside an\n  element as _.")

var Lit_146 *jrt.String = jrt.Intern("The symbol naming name of package path, from the file of the current package.")

var Lit_147 *jrt.String = jrt.Intern("declared")

var Lit_148 *jrt.String = jrt.Intern("private")

var Lit_149 *jrt.String = jrt.Intern("keys")

var Lit_150 *jrt.String = jrt.Intern("The type form of type id.")

var Lit_151 *jrt.String = jrt.Intern("untyped?")

var Lit_152 *jrt.String = jrt.Intern("Whether type id is an untyped basic type.")

var Lit_153 *jrt.String = jrt.Intern("string")

var Lit_154 *jrt.String = jrt.Intern("float32")

var Lit_155 *jrt.String = jrt.Intern("float")

var Lit_156 *jrt.String = jrt.Intern("float64")

var Lit_157 *jrt.String = jrt.Intern("untyped complex")

var Lit_158 *jrt.String = jrt.Intern("untyped-complex")

var Lit_159 *jrt.String = jrt.Intern("untyped rune")

var Lit_160 *jrt.String = jrt.Intern("rune")

var Lit_161 *jrt.String = jrt.Intern("complex128")

var Lit_162 *jrt.String = jrt.Intern("complex")

var Lit_163 *jrt.String = jrt.Intern("bool")

var Lit_164 *jrt.String = jrt.Intern("untyped int")

var Lit_165 *jrt.String = jrt.Intern("untyped string")

var Lit_166 *jrt.String = jrt.Intern("untyped bool")

var Lit_167 *jrt.String = jrt.Intern("untyped float")

var Lit_168 *jrt.String = jrt.Intern("untyped-float")

var Lit_169 *jrt.String = jrt.Intern("complex64")

var Lit_170 *jrt.String = jrt.Intern("The kind of constant values of type id (lit/const-form), or nil when it is not known (a\n  named type of another package, whose underlying type is in that package's dump).")
