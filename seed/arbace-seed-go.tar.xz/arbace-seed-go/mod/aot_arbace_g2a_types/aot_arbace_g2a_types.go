//line aot_arbace_g2a_types.ae:1
package aot_arbace_g2a_types

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A_New() *A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A { A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A_Init(); t := &A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_g2a_types_A_Init(); tmp4 = A_arbace_g2a_types_A_const_0; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_g2a_types_A_Init(); tmp6 = A_arbace_g2a_types_A_const_1; tmp3 = tmp5.Invoke_O__O(tmp6) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp7 != nil { panic(tmp7) }; return tmp3 }
//line :1:1
func A_arbace_g2a_types_eval1376000008_fn__1376000009_A_New() *A_arbace_g2a_types_eval1376000008_fn__1376000009_A { A_arbace_g2a_types_eval1376000008_fn__1376000009_A_Init(); t := &A_arbace_g2a_types_eval1376000008_fn__1376000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_g2a_types_eval1376000008_fn__1376000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_g2a_types_eval1376000008_fn__1376000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_g2a_types_A_Init(); tmp1 = A_arbace_g2a_types_A_const_2; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_g2a_types_A_Init(); tmp3 = A_arbace_g2a_types_A_const_3; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_g2a_types_A_Init(); tmp5 = A_arbace_g2a_types_A_const_6; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_g2a_types_A_Init(); tmp7 = A_arbace_g2a_types_A_const_4; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_g2a_types_A_Init(); tmp9 = A_arbace_g2a_types_A_const_5; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }
























func A_arbace_g2a_types_entry_A_New() *A_arbace_g2a_types_entry_A { A_arbace_g2a_types_entry_A_Init(); t := &A_arbace_g2a_types_entry_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_g2a_types_entry_A) Ctor() {}
//line :26:1
func (t *A_arbace_g2a_types_entry_A) Invoke_O_O__O(self, id__0 any) any { var tmp1 *lang.Var; A_arbace_g2a_types_A_Init(); tmp1 = A_arbace_g2a_types_A_const_7; return lang.RT_Nth_O_I__O(jrt.NN(tmp1).Get__O(), lang.RT_IntCast_O__I(id__0)) }





func A_arbace_g2a_types_ns_name_of_A_New() *A_arbace_g2a_types_ns_name_of_A { A_arbace_g2a_types_ns_name_of_A_Init(); t := &A_arbace_g2a_types_ns_name_of_A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_g2a_types_ns_name_of_A) Ctor() {}
//line :32:1
func (t *A_arbace_g2a_types_ns_name_of_A) Invoke_O_O__O(self, path__0 any) any {



	var tmp1 *lang.Var; A_arbace_g2a_types_A_Init(); tmp1 = A_arbace_g2a_types_A_const_8; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_g2a_types_A_Init(); tmp3 = A_arbace_g2a_types_A_const_9; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_g2a_types_A_Init(); tmp5 = A_arbace_g2a_types_A_const_10; var tmp6 any = jrt.NN(tmp5).GetRawRoot__O(); var tmp7 *lang.Var; A_arbace_g2a_types_A_Init(); tmp7 = A_arbace_g2a_types_A_const_11; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_g2a_types_A_Init(); tmp9 = A_arbace_g2a_types_A_const_12; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 any = A_arbace_g2a_types_ns_name_of_fn__1376000014_A_New(); var tmp12 *jrt.Class; A_arbace_g2a_types_ns_name_of_fn__1376000014_A_Init(); tmp12 = A_arbace_g2a_types_ns_name_of_fn__1376000014_A_fn_class; var tmp13 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var tmp14 *jrt.Class; A_arbace_g2a_types_A_Init(); tmp14 = A_arbace_g2a_types_A_const_13; var tmp15 *jrt.Class = tmp14; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp6, Lit_109, tmp8.Invoke_O_O__O(Lit_110, tmp10.Invoke_O_O__O(tmp13, lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(path__0, tmp15, Lit_111, jrt.RefArrayOf(jrt.Object_class, Lit_112)))))) }
//line :36:1
func A_arbace_g2a_types_ns_name_of_fn__1376000014_A_New() *A_arbace_g2a_types_ns_name_of_fn__1376000014_A { A_arbace_g2a_types_ns_name_of_fn__1376000014_A_Init(); t := &A_arbace_g2a_types_ns_name_of_fn__1376000014_A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_g2a_types_ns_name_of_fn__1376000014_A) Ctor() {}
//line :36:1
func (t *A_arbace_g2a_types_ns_name_of_fn__1376000014_A) Invoke_O_O__O(self, p1__1376000013_SHARP___1 any) any { var tmp1 *jrt.Class; A_arbace_g2a_types_A_Init(); tmp1 = A_arbace_g2a_types_A_const_13; var tmp2 *jrt.Class = tmp1; return lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(p1__1376000013_SHARP___1, tmp2, Lit_114, jrt.RefArrayOf(jrt.Object_class, Lit_115, Lit_116)) }


func A_arbace_g2a_types_qualify_A_New() *A_arbace_g2a_types_qualify_A { A_arbace_g2a_types_qualify_A_Init(); t := &A_arbace_g2a_types_qualify_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_g2a_types_qualify_A) Ctor() {}
//line :39:1
func (t *A_arbace_g2a_types_qualify_A) Invoke_O_O_O__O(self, path__0, name__1 any) any {


	var tmp1 bool; var or__1927000174__auto____3 bool = lang.Util_Identical_O_O__Z(path__0, nil)
	if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { var tmp2 *lang.Var; A_arbace_g2a_types_A_Init(); tmp2 = A_arbace_g2a_types_A_const_14; tmp1 = lang.Util_Equiv_O_O__Z(path__0, jrt.NN(tmp2).Get__O()) }
//line :42:1
	if tmp1 {
		var tmp3 *lang.Var; A_arbace_g2a_types_A_Init(); tmp3 = A_arbace_g2a_types_A_const_8; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(name__1) } else {
//line :42:1
			var tmp4 *lang.Var; A_arbace_g2a_types_A_Init(); tmp4 = A_arbace_g2a_types_A_const_15; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_g2a_types_A_Init(); tmp6 = A_arbace_g2a_types_A_const_17; if jrt.A2g_Truth(tmp5.Invoke_O_O__O(jrt.NN(tmp6).Get__O(), path__0)) {

				var tmp7 *lang.Var; A_arbace_g2a_types_A_Init(); tmp7 = A_arbace_g2a_types_A_const_8; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_g2a_types_A_Init(); tmp9 = A_arbace_g2a_types_A_const_17; return tmp8.Invoke_O_O__O(lang.RT_Get_O_O__O(jrt.NN(tmp9).Get__O(), path__0), name__1) } else {
//line :42:1
					var tmp10 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp10 = A_arbace_g2a_types_A_const_16; if tmp10 != nil {


						var tmp11 *lang.Var; A_arbace_g2a_types_A_Init(); tmp11 = A_arbace_g2a_types_A_const_8; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_g2a_types_A_Init(); tmp13 = A_arbace_g2a_types_A_const_10; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_g2a_types_A_Init(); tmp15 = A_arbace_g2a_types_A_const_18; return tmp12.Invoke_O_O__O(tmp14.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(path__0)), name__1) } else {
//line :42:1
							return nil
						}
				}
		}
}


func A_arbace_g2a_types_params_vec_A_New() *A_arbace_g2a_types_params_vec_A { A_arbace_g2a_types_params_vec_A_Init(); t := &A_arbace_g2a_types_params_vec_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_g2a_types_params_vec_A) Ctor() {}
//line :49:1
func (t *A_arbace_g2a_types_params_vec_A) Invoke_O_O_O__O(self, vars__0, variadic__1 any) any { var n__3 int32 = lang.RT_Count_O__I(vars__0); var tmp1 *lang.Var;

	A_arbace_g2a_types_A_Init(); tmp1 = A_arbace_g2a_types_A_const_19; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_g2a_types_A_Init(); tmp3 = A_arbace_g2a_types_A_const_20; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any = A_arbace_g2a_types_params_vec_fn__1376000018_A_New_I_O(n__3, variadic__1); var tmp6 *jrt.Class; A_arbace_g2a_types_params_vec_fn__1376000018_A_Init(); tmp6 = A_arbace_g2a_types_params_vec_fn__1376000018_A_fn_class; var tmp7 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp8 *lang.Var; A_arbace_g2a_types_A_Init(); tmp8 = A_arbace_g2a_types_A_const_24; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp7, lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke__O(), vars__0)) }
//line :51:1
func A_arbace_g2a_types_params_vec_fn__1376000018_A_New_I_O(p0 int32, p1 any) *A_arbace_g2a_types_params_vec_fn__1376000018_A { A_arbace_g2a_types_params_vec_fn__1376000018_A_Init(); t := &A_arbace_g2a_types_params_vec_fn__1376000018_A{}; t.Ctor_I_O(p0, p1); return t }
//line :51:1
func (t *A_arbace_g2a_types_params_vec_fn__1376000018_A) Ctor_I_O(c__n int32, c__variadic any) { t.F_n = c__n; t.F_variadic = c__variadic }
//line :51:1
func (t *A_arbace_g2a_types_params_vec_fn__1376000018_A) Invoke_O_O_O__O(self, i__1, v__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 any = t.F_variadic; if jrt.A2g_Truth(and__1927000168__auto____3) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_J__Z(i__1, lang.Numbers_Dec_J__J(int64(t.F_n)))).Ref() } else { tmp1 = and__1927000168__auto____3 }; if jrt.A2g_Truth(tmp1) { var tmp2 any; A_arbace_g2a_types_A_Init(); tmp2 = A_arbace_g2a_types_A_const_21; var tmp3 any = tmp2; var tmp4 *lang.Var; A_arbace_g2a_types_A_Init(); tmp4 = A_arbace_g2a_types_A_const_22; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp6 = A_arbace_g2a_types_A_const_23; return lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp5.Invoke_O__O(jrt.NN(tmp6).Invoke_O__O(v__2))) } else { var tmp7 *lang.Var; A_arbace_g2a_types_A_Init(); tmp7 = A_arbace_g2a_types_A_const_22; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp9 = A_arbace_g2a_types_A_const_23; return lang.Tuple_Create_O__IPersistentVector(tmp8.Invoke_O__O(jrt.NN(tmp9).Invoke_O__O(v__2)))
	}
}


func A_arbace_g2a_types_method_elem_A_New() *A_arbace_g2a_types_method_elem_A { A_arbace_g2a_types_method_elem_A_Init(); t := &A_arbace_g2a_types_method_elem_A{}; t.Ctor(); return t }
//line :57:1
func (t *A_arbace_g2a_types_method_elem_A) Ctor() {}
//line :57:1
func (t *A_arbace_g2a_types_method_elem_A) Invoke_O_O__O(self, p__1376000021__0 any) any { var map__1376000022__2 any = p__1376000021__0; var map__1376000022__3 any; if lang.ISeq_InstanceOf(map__1376000022__2) { var tmp1 *lang.Var; A_arbace_g2a_types_A_Init(); tmp1 = A_arbace_g2a_types_A_const_25; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(map__1376000022__2)) { var tmp2 *lang.Var; A_arbace_g2a_types_A_Init(); tmp2 = A_arbace_g2a_types_A_const_26; map__1376000022__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__1376000022__2), jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 *lang.Var; A_arbace_g2a_types_A_Init(); tmp3 = A_arbace_g2a_types_A_const_27; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__1376000022__2)) { var tmp4 *lang.Var; A_arbace_g2a_types_A_Init(); tmp4 = A_arbace_g2a_types_A_const_28; map__1376000022__3 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__1376000022__2) } else { lang.PersistentArrayMap_Init(); map__1376000022__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1376000022__3 = map__1376000022__2 }; var name__4 any; var tmp5 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp5 = A_arbace_g2a_types_A_const_29; name__4 = lang.RT_Get_O_O__O(map__1376000022__3, tmp5.Ref()); var t__5 any; var tmp6 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp6 = A_arbace_g2a_types_A_const_23; t__5 = lang.RT_Get_O_O__O(map__1376000022__3, tmp6.Ref()); var sig__6 any; var tmp7 *lang.Var;
												A_arbace_g2a_types_A_Init(); tmp7 = A_arbace_g2a_types_A_const_30; sig__6 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(t__5); var ps__7 any; var tmp8 /*line :57:1*/*lang.Var;

	A_arbace_g2a_types_A_Init(); tmp8 = A_arbace_g2a_types_A_const_31; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp10 = A_arbace_g2a_types_A_const_35; var tmp11 any = jrt.NN(tmp10).Invoke_O__O(sig__6); var tmp12 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp12 = A_arbace_g2a_types_A_const_36; ps__7 = tmp9.Invoke_O_O__O(tmp11, jrt.NN(tmp12).Invoke_O__O(sig__6)); var rs__8 any; var tmp13 /*line :57:1*/*lang.Keyword;


	A_arbace_g2a_types_A_Init(); tmp13 = A_arbace_g2a_types_A_const_32; rs__8 = jrt.NN(tmp13).Invoke_O__O(sig__6); var tmp14 /*line :61:1*/*lang.Var; A_arbace_g2a_types_A_Init(); tmp14 = A_arbace_g2a_types_A_const_33; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(rs__8)) {
		var tmp15 *lang.Var; A_arbace_g2a_types_A_Init(); tmp15 = A_arbace_g2a_types_A_const_34; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_g2a_types_A_Init(); tmp17 = A_arbace_g2a_types_A_const_8; return tmp16.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(name__4), ps__7) } else {
//line :61:1
			if lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(rs__8))) {

				var tmp18 *lang.Var; A_arbace_g2a_types_A_Init(); tmp18 = A_arbace_g2a_types_A_const_34; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Var; A_arbace_g2a_types_A_Init(); tmp20 = A_arbace_g2a_types_A_const_8; var tmp21 any = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(name__4); var tmp22 *lang.Var; A_arbace_g2a_types_A_Init(); tmp22 = A_arbace_g2a_types_A_const_37; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp24 = A_arbace_g2a_types_A_const_38; var tmp25 any = tmp24.Ref(); var tmp26 *lang.Var; A_arbace_g2a_types_A_Init(); tmp26 = A_arbace_g2a_types_A_const_22; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp28 = A_arbace_g2a_types_A_const_23; var tmp29 *lang.Keyword = tmp28; var tmp30 *lang.Var; A_arbace_g2a_types_A_Init(); tmp30 = A_arbace_g2a_types_A_const_28; return tmp19.Invoke_O_O__O(tmp21, tmp23.Invoke_O_O__O(ps__7, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25, tmp27.Invoke_O__O(jrt.NN(tmp29).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O__O(rs__8))))))) } else {
//line :61:1
					var tmp31 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp31 = A_arbace_g2a_types_A_const_16; if tmp31 != nil {


						var tmp32 *lang.Var; A_arbace_g2a_types_A_Init(); tmp32 = A_arbace_g2a_types_A_const_34; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 *lang.Var; A_arbace_g2a_types_A_Init(); tmp34 = A_arbace_g2a_types_A_const_8; var tmp35 any = lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()).Invoke_O__O(name__4); var tmp36 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp36 = A_arbace_g2a_types_A_const_32; var tmp37 any = tmp36.Ref(); var tmp38 *lang.Var; A_arbace_g2a_types_A_Init(); tmp38 = A_arbace_g2a_types_A_const_39; var tmp39 lang.IFn = lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()); var tmp40 *lang.Var; A_arbace_g2a_types_A_Init(); tmp40 = A_arbace_g2a_types_A_const_40; var tmp41 lang.IFn = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()); var tmp42 *lang.Var; A_arbace_g2a_types_A_Init(); tmp42 = A_arbace_g2a_types_A_const_22; var tmp43 any = jrt.NN(tmp42).GetRawRoot__O(); var tmp44 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp44 = A_arbace_g2a_types_A_const_23; return tmp33.Invoke_O_O_O_O__O(tmp35, ps__7, tmp37, tmp39.Invoke_O_O__O(tmp41.Invoke_O_O__O(tmp43, tmp44.Ref()), rs__8)) } else {
//line :61:1
							return nil } } } }




func A_arbace_g2a_types_type_form_A_New() *A_arbace_g2a_types_type_form_A { A_arbace_g2a_types_type_form_A_Init(); t := &A_arbace_g2a_types_type_form_A{}; t.Ctor(); return t }
//line :66:1
func (t *A_arbace_g2a_types_type_form_A) Ctor() {}
//line :66:1
func (t *A_arbace_g2a_types_type_form_A) Invoke_O_O__O(self, id__0 any) any { var e__2 any; var tmp1 *lang.Var;


	A_arbace_g2a_types_A_Init(); tmp1 = A_arbace_g2a_types_A_const_30; e__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(id__0); var G__1376000025__3_ any; var tmp2 /*line :66:1*/*lang.Keyword;



	A_arbace_g2a_types_A_Init(); tmp2 = A_arbace_g2a_types_A_const_41; G__1376000025__3_ = jrt.NN(tmp2).Invoke_O__O(e__2); switch lang.Util_Hash_O__I(G__1376000025__3_) >> 14 & 31 { case 0: var tmp3 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp3 = A_arbace_g2a_types_A_const_42; if any(G__1376000025__3_) == any(tmp3.Ref()) {




		var tmp4 *lang.Var; A_arbace_g2a_types_A_Init(); tmp4 = A_arbace_g2a_types_A_const_34; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_g2a_types_A_Init(); tmp6 = A_arbace_g2a_types_A_const_51; var tmp7 any = tmp6; var tmp8 *lang.Var; A_arbace_g2a_types_A_Init(); tmp8 = A_arbace_g2a_types_A_const_22; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp10 = A_arbace_g2a_types_A_const_52; var tmp11 any = tmp9.Invoke_O__O(jrt.NN(tmp10).Invoke_O__O(e__2)); var tmp12 *lang.Var; A_arbace_g2a_types_A_Init(); tmp12 = A_arbace_g2a_types_A_const_22; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp14 = A_arbace_g2a_types_A_const_53; return tmp5.Invoke_O_O_O__O(tmp7, tmp11, tmp13.Invoke_O__O(jrt.NN(tmp14).Invoke_O__O(e__2))) }
//line :70:1
	case 3: var tmp15 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp15 = A_arbace_g2a_types_A_const_43; if any(G__1376000025__3_) == any(tmp15.Ref()) { var G__1376000026__4_ any; var tmp16 *lang.Keyword





		A_arbace_g2a_types_A_Init(); tmp16 = A_arbace_g2a_types_A_const_44; G__1376000026__4_ = jrt.NN(tmp16).Invoke_O__O(e__2); switch lang.Util_Hash_O__I(G__1376000026__4_) >> 7 & 3 { case 0: var tmp17 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp17 = A_arbace_g2a_types_A_const_45; if any(G__1376000026__4_) == any(tmp17.Ref()) {


			var tmp18 *lang.Var; A_arbace_g2a_types_A_Init(); tmp18 = A_arbace_g2a_types_A_const_34; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 any; A_arbace_g2a_types_A_Init(); tmp20 = A_arbace_g2a_types_A_const_54; var tmp21 any = tmp20; var tmp22 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp22 = A_arbace_g2a_types_A_const_45; var tmp23 any = tmp22.Ref(); var tmp24 *lang.Var; A_arbace_g2a_types_A_Init(); tmp24 = A_arbace_g2a_types_A_const_22; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp26 = A_arbace_g2a_types_A_const_53; return tmp19.Invoke_O_O_O__O(tmp21, tmp23, tmp25.Invoke_O__O(jrt.NN(tmp26).Invoke_O__O(e__2))) }
//line :76:1
		case 2: var tmp27 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp27 = A_arbace_g2a_types_A_const_46; if any(G__1376000026__4_) == any(tmp27.Ref()) {
			var tmp28 *lang.Var; A_arbace_g2a_types_A_Init(); tmp28 = A_arbace_g2a_types_A_const_34; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 any; A_arbace_g2a_types_A_Init(); tmp30 = A_arbace_g2a_types_A_const_55; var tmp31 any = tmp30; var tmp32 *lang.Var; A_arbace_g2a_types_A_Init(); tmp32 = A_arbace_g2a_types_A_const_22; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp34 = A_arbace_g2a_types_A_const_53; return tmp29.Invoke_O_O__O(tmp31, tmp33.Invoke_O__O(jrt.NN(tmp34).Invoke_O__O(e__2))) }
//line :76:1
		case 3: var tmp35 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp35 = A_arbace_g2a_types_A_const_47; if any(G__1376000026__4_) == any(tmp35.Ref()) {

			var tmp36 *lang.Var; A_arbace_g2a_types_A_Init(); tmp36 = A_arbace_g2a_types_A_const_34; var tmp37 lang.IFn = lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()); var tmp38 any; A_arbace_g2a_types_A_Init(); tmp38 = A_arbace_g2a_types_A_const_56; var tmp39 any = tmp38; var tmp40 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp40 = A_arbace_g2a_types_A_const_47; var tmp41 any = tmp40.Ref(); var tmp42 *lang.Var; A_arbace_g2a_types_A_Init(); tmp42 = A_arbace_g2a_types_A_const_22; var tmp43 lang.IFn = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()); var tmp44 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp44 = A_arbace_g2a_types_A_const_53; return tmp37.Invoke_O_O_O__O(tmp39, tmp41, tmp43.Invoke_O__O(jrt.NN(tmp44).Invoke_O__O(e__2))) }
//line :76:1
		default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_121, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1376000026__4_))))) }
//line :70:1
	case 5: var tmp45 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp45 = A_arbace_g2a_types_A_const_48; if any(G__1376000025__3_) == any(tmp45.Ref()) {

		var tmp46 *lang.Var; A_arbace_g2a_types_A_Init(); tmp46 = A_arbace_g2a_types_A_const_34; var tmp47 lang.IFn = lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()); var tmp48 any; A_arbace_g2a_types_A_Init(); tmp48 = A_arbace_g2a_types_A_const_57; var tmp49 any = tmp48; var tmp50 *lang.Var; A_arbace_g2a_types_A_Init(); tmp50 = A_arbace_g2a_types_A_const_22; var tmp51 lang.IFn = lang.IFn_Cast(jrt.NN(tmp50).GetRawRoot__O()); var tmp52 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp52 = A_arbace_g2a_types_A_const_53; return tmp47.Invoke_O_O__O(tmp49, tmp51.Invoke_O__O(jrt.NN(tmp52).Invoke_O__O(e__2))) }
//line :70:1
	case 6: var tmp53 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp53 = A_arbace_g2a_types_A_const_49; if any(G__1376000025__3_) == any(tmp53.Ref()) {
























		var tmp54 *lang.Var; A_arbace_g2a_types_A_Init(); tmp54 = A_arbace_g2a_types_A_const_9; var tmp55 lang.IFn = lang.IFn_Cast(jrt.NN(tmp54).GetRawRoot__O()); var tmp56 *lang.Var; A_arbace_g2a_types_A_Init(); tmp56 = A_arbace_g2a_types_A_const_34; var tmp57 any = jrt.NN(tmp56).GetRawRoot__O(); var tmp58 any; A_arbace_g2a_types_A_Init(); tmp58 = A_arbace_g2a_types_A_const_59; var tmp59 any = tmp58; var tmp60 any; var iter__1927001039__auto____4 any; var tmp61 any = A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_New(); var tmp62 *jrt.Class
		A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_Init(); tmp62 = A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_fn_class; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp61, tmp62, nil); var tmp63 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____4); var tmp64 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp64 = A_arbace_g2a_types_A_const_71; tmp60 = tmp63.Invoke_O__O(jrt.NN(tmp64).Invoke_O__O(e__2))
//line :95:1
		return tmp55.Invoke_O_O_O__O(tmp57, tmp59, tmp60) }
//line :70:1
	case 7: var tmp65 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp65 = A_arbace_g2a_types_A_const_58; if any(G__1376000025__3_) == any(tmp65.Ref()) {













		var tmp66 *lang.Var; A_arbace_g2a_types_A_Init(); tmp66 = A_arbace_g2a_types_A_const_9; var tmp67 lang.IFn = lang.IFn_Cast(jrt.NN(tmp66).GetRawRoot__O()); var tmp68 *lang.Var; A_arbace_g2a_types_A_Init(); tmp68 = A_arbace_g2a_types_A_const_34; var tmp69 any = jrt.NN(tmp68).GetRawRoot__O(); var tmp70 any; A_arbace_g2a_types_A_Init(); tmp70 = A_arbace_g2a_types_A_const_73; var tmp71 any = tmp70; var tmp72 any; var iter__1927001039__auto____4_2 any; var tmp73 any = A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_New(); var tmp74 *jrt.Class
		A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_Init(); tmp74 = A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_fn_class; iter__1927001039__auto____4_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp73, tmp74, nil); var tmp75 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____4_2); var tmp76 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp76 = A_arbace_g2a_types_A_const_78; tmp72 = tmp75.Invoke_O__O(jrt.NN(tmp76).Invoke_O__O(e__2))
//line :84:1
		return tmp67.Invoke_O_O_O__O(tmp69, tmp71, tmp72) }
//line :70:1
	case 8: var tmp77 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp77 = A_arbace_g2a_types_A_const_72; if any(G__1376000025__3_) == any(tmp77.Ref()) {


































		var tmp78 *lang.Var; A_arbace_g2a_types_A_Init(); tmp78 = A_arbace_g2a_types_A_const_8; var tmp79 lang.IFn = lang.IFn_Cast(jrt.NN(tmp78).GetRawRoot__O()); var tmp80 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp80 = A_arbace_g2a_types_A_const_29; return tmp79.Invoke_O__O(jrt.NN(tmp80).Invoke_O__O(e__2)) }
//line :70:1
	case 11: var tmp81 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp81 = A_arbace_g2a_types_A_const_79; if any(G__1376000025__3_) == any(tmp81.Ref()) {



		var tmp82 *lang.Var; A_arbace_g2a_types_A_Init(); tmp82 = A_arbace_g2a_types_A_const_34; var tmp83 lang.IFn = lang.IFn_Cast(jrt.NN(tmp82).GetRawRoot__O()); var tmp84 any; A_arbace_g2a_types_A_Init(); tmp84 = A_arbace_g2a_types_A_const_83; var tmp85 any = tmp84; var tmp86 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp86 = A_arbace_g2a_types_A_const_84; var tmp87 any = jrt.NN(tmp86).Invoke_O__O(e__2); var tmp88 *lang.Var; A_arbace_g2a_types_A_Init(); tmp88 = A_arbace_g2a_types_A_const_22; var tmp89 lang.IFn = lang.IFn_Cast(jrt.NN(tmp88).GetRawRoot__O()); var tmp90 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp90 = A_arbace_g2a_types_A_const_53; return tmp83.Invoke_O_O_O__O(tmp85, tmp87, tmp89.Invoke_O__O(jrt.NN(tmp90).Invoke_O__O(e__2))) }
//line :70:1
	case 13: var tmp91 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp91 = A_arbace_g2a_types_A_const_80; if any(G__1376000025__3_) == any(tmp91.Ref()) {
		var tmp92 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp92 = A_arbace_g2a_types_A_const_81; if jrt.A2g_Truth(jrt.NN(tmp92).Invoke_O__O(e__2)) { var tmp93 *lang.Var; A_arbace_g2a_types_A_Init(); tmp93 = A_arbace_g2a_types_A_const_82; var tmp94 lang.IFn = lang.IFn_Cast(jrt.NN(tmp93).GetRawRoot__O()); var tmp95 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp95 = A_arbace_g2a_types_A_const_81; var tmp96 any = jrt.NN(tmp95).Invoke_O__O(e__2); var tmp97 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp97 = A_arbace_g2a_types_A_const_29; return tmp94.Invoke_O_O__O(tmp96, jrt.NN(tmp97).Invoke_O__O(e__2)) } else { var tmp98 *lang.Var; A_arbace_g2a_types_A_Init(); tmp98 = A_arbace_g2a_types_A_const_8; var tmp99 lang.IFn = lang.IFn_Cast(jrt.NN(tmp98).GetRawRoot__O()); var tmp100 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp100 = A_arbace_g2a_types_A_const_29; return tmp99.Invoke_O__O(jrt.NN(tmp100).Invoke_O__O(e__2)) } }
//line :70:1
	case 14: var tmp101 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp101 = A_arbace_g2a_types_A_const_85; if any(G__1376000025__3_) == any(tmp101.Ref()) { var ps__4 any; var tmp102 *lang.Var









		A_arbace_g2a_types_A_Init(); tmp102 = A_arbace_g2a_types_A_const_31; var tmp103 lang.IFn = lang.IFn_Cast(jrt.NN(tmp102).GetRawRoot__O()); var tmp104 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp104 = A_arbace_g2a_types_A_const_35; var tmp105 any = jrt.NN(tmp104).Invoke_O__O(e__2); var tmp106 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp106 = A_arbace_g2a_types_A_const_36; ps__4 = tmp103.Invoke_O_O__O(tmp105, jrt.NN(tmp106).Invoke_O__O(e__2))
		var tmp107 *lang.Var; A_arbace_g2a_types_A_Init(); tmp107 = A_arbace_g2a_types_A_const_27; var tmp108 lang.IFn = lang.IFn_Cast(jrt.NN(tmp107).GetRawRoot__O()); var tmp109 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp109 = A_arbace_g2a_types_A_const_32; if jrt.A2g_Truth(tmp108.Invoke_O__O(jrt.NN(tmp109).Invoke_O__O(e__2))) {
			var tmp110 *lang.Var; A_arbace_g2a_types_A_Init(); tmp110 = A_arbace_g2a_types_A_const_34; var tmp111 lang.IFn = lang.IFn_Cast(jrt.NN(tmp110).GetRawRoot__O()); var tmp112 any; A_arbace_g2a_types_A_Init(); tmp112 = A_arbace_g2a_types_A_const_87; var tmp113 any = tmp112; var tmp114 *lang.Var; A_arbace_g2a_types_A_Init(); tmp114 = A_arbace_g2a_types_A_const_39; var tmp115 lang.IFn = lang.IFn_Cast(jrt.NN(tmp114).GetRawRoot__O()); var tmp116 *lang.Var; A_arbace_g2a_types_A_Init(); tmp116 = A_arbace_g2a_types_A_const_40; var tmp117 lang.IFn = lang.IFn_Cast(jrt.NN(tmp116).GetRawRoot__O()); var tmp118 *lang.Var; A_arbace_g2a_types_A_Init(); tmp118 = A_arbace_g2a_types_A_const_22; var tmp119 any = jrt.NN(tmp118).GetRawRoot__O(); var tmp120 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp120 = A_arbace_g2a_types_A_const_23; var tmp121 any = tmp117.Invoke_O_O__O(tmp119, tmp120.Ref()); var tmp122 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp122 = A_arbace_g2a_types_A_const_32; return tmp111.Invoke_O_O_O__O(tmp113, ps__4, tmp115.Invoke_O_O__O(tmp121, jrt.NN(tmp122).Invoke_O__O(e__2))) } else {
				var tmp123 *lang.Var; A_arbace_g2a_types_A_Init(); tmp123 = A_arbace_g2a_types_A_const_34; var tmp124 lang.IFn = lang.IFn_Cast(jrt.NN(tmp123).GetRawRoot__O()); var tmp125 any; A_arbace_g2a_types_A_Init(); tmp125 = A_arbace_g2a_types_A_const_88; return tmp124.Invoke_O_O__O(tmp125, ps__4) } }
//line :70:1
	case 19: var tmp126 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp126 = A_arbace_g2a_types_A_const_86; if any(G__1376000025__3_) == any(tmp126.Ref()) {





















		var tmp127 *lang.Var; A_arbace_g2a_types_A_Init(); tmp127 = A_arbace_g2a_types_A_const_9; var tmp128 lang.IFn = lang.IFn_Cast(jrt.NN(tmp127).GetRawRoot__O()); var tmp129 *lang.Var; A_arbace_g2a_types_A_Init(); tmp129 = A_arbace_g2a_types_A_const_34; var tmp130 any = jrt.NN(tmp129).GetRawRoot__O(); var tmp131 any; A_arbace_g2a_types_A_Init(); tmp131 = A_arbace_g2a_types_A_const_90; var tmp132 any = tmp131; var tmp133 *lang.Var; A_arbace_g2a_types_A_Init(); tmp133 = A_arbace_g2a_types_A_const_91; var tmp134 lang.IFn = lang.IFn_Cast(jrt.NN(tmp133).GetRawRoot__O()); var tmp135 *lang.Var; A_arbace_g2a_types_A_Init(); tmp135 = A_arbace_g2a_types_A_const_12; var tmp136 lang.IFn = lang.IFn_Cast(jrt.NN(tmp135).GetRawRoot__O()); var tmp137 *lang.Var; A_arbace_g2a_types_A_Init(); tmp137 = A_arbace_g2a_types_A_const_92; var tmp138 any = jrt.NN(tmp137).GetRawRoot__O(); var tmp139 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp139 = A_arbace_g2a_types_A_const_93; var tmp140 any = tmp136.Invoke_O_O__O(tmp138, jrt.NN(tmp139).Invoke_O__O(e__2)); var tmp141 *lang.Var; A_arbace_g2a_types_A_Init(); tmp141 = A_arbace_g2a_types_A_const_12; var tmp142 lang.IFn = lang.IFn_Cast(jrt.NN(tmp141).GetRawRoot__O()); var tmp143 *lang.Var; A_arbace_g2a_types_A_Init(); tmp143 = A_arbace_g2a_types_A_const_22; var tmp144 any = jrt.NN(tmp143).GetRawRoot__O(); var tmp145 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp145 = A_arbace_g2a_types_A_const_94; return tmp128.Invoke_O_O_O__O(tmp130, tmp132, tmp134.Invoke_O_O__O(tmp140, tmp142.Invoke_O_O__O(tmp144, jrt.NN(tmp145).Invoke_O__O(e__2)))) }
//line :70:1
	case 23: var tmp146 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp146 = A_arbace_g2a_types_A_const_89; if any(G__1376000025__3_) == any(tmp146.Ref()) {



































		var tmp147 *lang.Var; A_arbace_g2a_types_A_Init(); tmp147 = A_arbace_g2a_types_A_const_9; var tmp148 lang.IFn = lang.IFn_Cast(jrt.NN(tmp147).GetRawRoot__O()); var tmp149 *lang.Var; A_arbace_g2a_types_A_Init(); tmp149 = A_arbace_g2a_types_A_const_34; var tmp150 any = jrt.NN(tmp149).GetRawRoot__O(); var tmp151 any; A_arbace_g2a_types_A_Init(); tmp151 = A_arbace_g2a_types_A_const_99; var tmp152 any = tmp151; var tmp153 *lang.Var; A_arbace_g2a_types_A_Init(); tmp153 = A_arbace_g2a_types_A_const_12; var tmp154 lang.IFn = lang.IFn_Cast(jrt.NN(tmp153).GetRawRoot__O()); var tmp155 *lang.Var; A_arbace_g2a_types_A_Init(); tmp155 = A_arbace_g2a_types_A_const_40; var tmp156 lang.IFn = lang.IFn_Cast(jrt.NN(tmp155).GetRawRoot__O()); var tmp157 *lang.Var; A_arbace_g2a_types_A_Init(); tmp157 = A_arbace_g2a_types_A_const_22; var tmp158 any = jrt.NN(tmp157).GetRawRoot__O(); var tmp159 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp159 = A_arbace_g2a_types_A_const_23; var tmp160 any = tmp156.Invoke_O_O__O(tmp158, tmp159.Ref()); var tmp161 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp161 = A_arbace_g2a_types_A_const_100; return tmp148.Invoke_O_O_O__O(tmp150, tmp152, tmp154.Invoke_O_O__O(tmp160, jrt.NN(tmp161).Invoke_O__O(e__2))) }
//line :70:1
	case 25: var tmp162 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp162 = A_arbace_g2a_types_A_const_95; if any(G__1376000025__3_) == any(tmp162.Ref()) { var base__4 any; var tmp163 *lang.Var




























		A_arbace_g2a_types_A_Init(); tmp163 = A_arbace_g2a_types_A_const_82; var tmp164 lang.IFn = lang.IFn_Cast(jrt.NN(tmp163).GetRawRoot__O()); var tmp165 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp165 = A_arbace_g2a_types_A_const_81; var tmp166 any = jrt.NN(tmp165).Invoke_O__O(e__2); var tmp167 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp167 = A_arbace_g2a_types_A_const_29; base__4 = tmp164.Invoke_O_O__O(tmp166, jrt.NN(tmp167).Invoke_O__O(e__2))
		var tmp168 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp168 = A_arbace_g2a_types_A_const_96; if jrt.A2g_Truth(jrt.NN(tmp168).Invoke_O__O(e__2)) {
			var tmp169 any; var and__1927000168__auto____5 bool; var tmp170 *lang.Var; A_arbace_g2a_types_A_Init(); tmp170 = A_arbace_g2a_types_A_const_97; and__1927000168__auto____5 = lang.Util_Identical_O_O__Z(lang.IFn_Cast(jrt.NN(tmp170).GetRawRoot__O()).Invoke_O__O(base__4), nil); if and__1927000168__auto____5 { var tmp171 *lang.Var; A_arbace_g2a_types_A_Init(); tmp171 = A_arbace_g2a_types_A_const_98; tmp169 = lang.IFn_Cast(jrt.NN(tmp171).GetRawRoot__O()).Invoke_O__O(base__4) } else { tmp169 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() }; if jrt.A2g_Truth(tmp169) {
				var tmp172 *lang.Var; A_arbace_g2a_types_A_Init(); tmp172 = A_arbace_g2a_types_A_const_9; var tmp173 lang.IFn = lang.IFn_Cast(jrt.NN(tmp172).GetRawRoot__O()); var tmp174 *lang.Var; A_arbace_g2a_types_A_Init(); tmp174 = A_arbace_g2a_types_A_const_34; var tmp175 any = jrt.NN(tmp174).GetRawRoot__O(); var tmp176 any; A_arbace_g2a_types_A_Init(); tmp176 = A_arbace_g2a_types_A_const_102; var tmp177 any = tmp176; var tmp178 *lang.Var; A_arbace_g2a_types_A_Init(); tmp178 = A_arbace_g2a_types_A_const_12; var tmp179 lang.IFn = lang.IFn_Cast(jrt.NN(tmp178).GetRawRoot__O()); var tmp180 *lang.Var; A_arbace_g2a_types_A_Init(); tmp180 = A_arbace_g2a_types_A_const_22; var tmp181 any = jrt.NN(tmp180).GetRawRoot__O(); var tmp182 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp182 = A_arbace_g2a_types_A_const_103; return tmp173.Invoke_O_O_O_O__O(tmp175, tmp177, base__4, tmp179.Invoke_O_O__O(tmp181, jrt.NN(tmp182).Invoke_O__O(e__2))) } else {
					var tmp183 *lang.Var; A_arbace_g2a_types_A_Init(); tmp183 = A_arbace_g2a_types_A_const_9; var tmp184 lang.IFn = lang.IFn_Cast(jrt.NN(tmp183).GetRawRoot__O()); var tmp185 *lang.Var; A_arbace_g2a_types_A_Init(); tmp185 = A_arbace_g2a_types_A_const_34; var tmp186 any = jrt.NN(tmp185).GetRawRoot__O(); var tmp187 *lang.Var; A_arbace_g2a_types_A_Init(); tmp187 = A_arbace_g2a_types_A_const_12; var tmp188 lang.IFn = lang.IFn_Cast(jrt.NN(tmp187).GetRawRoot__O()); var tmp189 *lang.Var; A_arbace_g2a_types_A_Init(); tmp189 = A_arbace_g2a_types_A_const_22; var tmp190 any = jrt.NN(tmp189).GetRawRoot__O(); var tmp191 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp191 = A_arbace_g2a_types_A_const_103; return tmp184.Invoke_O_O_O__O(tmp186, base__4, tmp188.Invoke_O_O__O(tmp190, jrt.NN(tmp191).Invoke_O__O(e__2))) } } else {
//line :100:1
						return base__4 } }
//line :70:1
	case 28: var tmp192 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp192 = A_arbace_g2a_types_A_const_101; if any(G__1376000025__3_) == any(tmp192.Ref()) {


		var tmp193 *lang.Var; A_arbace_g2a_types_A_Init(); tmp193 = A_arbace_g2a_types_A_const_34; var tmp194 lang.IFn = lang.IFn_Cast(jrt.NN(tmp193).GetRawRoot__O()); var tmp195 any; A_arbace_g2a_types_A_Init(); tmp195 = A_arbace_g2a_types_A_const_105; var tmp196 any = tmp195; var tmp197 *lang.Var; A_arbace_g2a_types_A_Init(); tmp197 = A_arbace_g2a_types_A_const_22; var tmp198 lang.IFn = lang.IFn_Cast(jrt.NN(tmp197).GetRawRoot__O()); var tmp199 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp199 = A_arbace_g2a_types_A_const_53; return tmp194.Invoke_O_O__O(tmp196, tmp198.Invoke_O__O(jrt.NN(tmp199).Invoke_O__O(e__2))) }
//line :70:1
	case 29: var tmp200 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp200 = A_arbace_g2a_types_A_const_104; if any(G__1376000025__3_) == any(tmp200.Ref()) { var base__4_2 any; var tmp201 *lang.Var




























		A_arbace_g2a_types_A_Init(); tmp201 = A_arbace_g2a_types_A_const_82; var tmp202 lang.IFn = lang.IFn_Cast(jrt.NN(tmp201).GetRawRoot__O()); var tmp203 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp203 = A_arbace_g2a_types_A_const_81; var tmp204 any = jrt.NN(tmp203).Invoke_O__O(e__2); var tmp205 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp205 = A_arbace_g2a_types_A_const_29; base__4_2 = tmp202.Invoke_O_O__O(tmp204, jrt.NN(tmp205).Invoke_O__O(e__2))
		var tmp206 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp206 = A_arbace_g2a_types_A_const_96; if jrt.A2g_Truth(jrt.NN(tmp206).Invoke_O__O(e__2)) {
			var tmp207 any; var and__1927000168__auto____5_2 bool; var tmp208 *lang.Var; A_arbace_g2a_types_A_Init(); tmp208 = A_arbace_g2a_types_A_const_97; and__1927000168__auto____5_2 = lang.Util_Identical_O_O__Z(lang.IFn_Cast(jrt.NN(tmp208).GetRawRoot__O()).Invoke_O__O(base__4_2), nil); if and__1927000168__auto____5_2 { var tmp209 *lang.Var; A_arbace_g2a_types_A_Init(); tmp209 = A_arbace_g2a_types_A_const_98; tmp207 = lang.IFn_Cast(jrt.NN(tmp209).GetRawRoot__O()).Invoke_O__O(base__4_2) } else { tmp207 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5_2).Ref() }; if jrt.A2g_Truth(tmp207) {
				var tmp210 *lang.Var; A_arbace_g2a_types_A_Init(); tmp210 = A_arbace_g2a_types_A_const_9; var tmp211 lang.IFn = lang.IFn_Cast(jrt.NN(tmp210).GetRawRoot__O()); var tmp212 *lang.Var; A_arbace_g2a_types_A_Init(); tmp212 = A_arbace_g2a_types_A_const_34; var tmp213 any = jrt.NN(tmp212).GetRawRoot__O(); var tmp214 any; A_arbace_g2a_types_A_Init(); tmp214 = A_arbace_g2a_types_A_const_102; var tmp215 any = tmp214; var tmp216 *lang.Var; A_arbace_g2a_types_A_Init(); tmp216 = A_arbace_g2a_types_A_const_12; var tmp217 lang.IFn = lang.IFn_Cast(jrt.NN(tmp216).GetRawRoot__O()); var tmp218 *lang.Var; A_arbace_g2a_types_A_Init(); tmp218 = A_arbace_g2a_types_A_const_22; var tmp219 any = jrt.NN(tmp218).GetRawRoot__O(); var tmp220 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp220 = A_arbace_g2a_types_A_const_103; return tmp211.Invoke_O_O_O_O__O(tmp213, tmp215, base__4_2, tmp217.Invoke_O_O__O(tmp219, jrt.NN(tmp220).Invoke_O__O(e__2))) } else {
					var tmp221 *lang.Var; A_arbace_g2a_types_A_Init(); tmp221 = A_arbace_g2a_types_A_const_9; var tmp222 lang.IFn = lang.IFn_Cast(jrt.NN(tmp221).GetRawRoot__O()); var tmp223 *lang.Var; A_arbace_g2a_types_A_Init(); tmp223 = A_arbace_g2a_types_A_const_34; var tmp224 any = jrt.NN(tmp223).GetRawRoot__O(); var tmp225 *lang.Var; A_arbace_g2a_types_A_Init(); tmp225 = A_arbace_g2a_types_A_const_12; var tmp226 lang.IFn = lang.IFn_Cast(jrt.NN(tmp225).GetRawRoot__O()); var tmp227 *lang.Var; A_arbace_g2a_types_A_Init(); tmp227 = A_arbace_g2a_types_A_const_22; var tmp228 any = jrt.NN(tmp227).GetRawRoot__O(); var tmp229 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp229 = A_arbace_g2a_types_A_const_103; return tmp222.Invoke_O_O_O__O(tmp224, base__4_2, tmp226.Invoke_O_O__O(tmp228, jrt.NN(tmp229).Invoke_O__O(e__2))) } } else {
//line :100:1
						return base__4_2 } }
//line :70:1
	default:}; var tmp230 *lang.Var; A_arbace_g2a_types_A_Init(); tmp230 = A_arbace_g2a_types_A_const_50; var tmp231 lang.IFn = lang.IFn_Cast(jrt.NN(tmp230).GetRawRoot__O()); var tmp232 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_122, nil, Lit_123, nil); var tmp233 *lang.Var; A_arbace_g2a_types_A_Init(); tmp233 = A_arbace_g2a_types_A_const_106; var tmp234 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp232, jrt.RefArrayOf(jrt.Object_class, nil, id__0, nil, lang.IFn_Cast(jrt.NN(tmp233).GetRawRoot__O()).Invoke_O__O(e__2))).Ref(); var tmp235 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp235 = A_arbace_g2a_types_A_const_107; panic(jrt.Thrown(jrt.Throwable_Cast(tmp231.Invoke_O_O__O(tmp234, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp235.Ref(), id__0)))))) }














func A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_New() *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A { A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_Init(); t := &A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A) Ctor() {}
//line :85:1
func (t *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A) Invoke_O_O__O(self, s__1376000038__1 any) any { var tmp1 any = A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_New_O_O(s__1376000038__1, self); var tmp2 *jrt.Class; A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_Init(); tmp2 = A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :85:1
func A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_New_O_O(p0, p1 any) *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A { A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_Init(); t := &A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A{}; t.Ctor_O_O(p0, p1); return t }
//line :85:1
func (t *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A) Ctor_O_O(c__s__1376000038, c__iter__1376000037 any) { t.F_s__1376000038 = c__s__1376000038; t.F_iter__1376000037 = c__iter__1376000037 }
//line :85:1
func (t *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A) Invoke_O__O(self any) any { { var s__1376000038__1 any; var t_ any = t.F_s__1376000038; t.F_s__1376000038 = nil; s__1376000038__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_g2a_types_A_Init(); tmp1 = A_arbace_g2a_types_A_const_27; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1376000038__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1376000038__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_g2a_types_A_Init(); tmp2 = A_arbace_g2a_types_A_const_60; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1376000038__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_g2a_types_A_Init(); tmp3 = A_arbace_g2a_types_A_const_61; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1376000038__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1376000040__6 any; var tmp4 *lang.Var; A_arbace_g2a_types_A_Init(); tmp4 = A_arbace_g2a_types_A_const_62; b__1376000040__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_New_O_I_O(b__1376000040__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_Init(); tmp6 = A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_g2a_types_A_Init(); tmp7 = A_arbace_g2a_types_A_const_66; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_g2a_types_A_Init(); tmp9 = A_arbace_g2a_types_A_const_68; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1376000040__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1376000037); var tmp12 *lang.Var; A_arbace_g2a_types_A_Init(); tmp12 = A_arbace_g2a_types_A_const_69; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1376000038__3))) } else { var tmp13 *lang.Var; A_arbace_g2a_types_A_Init(); tmp13 = A_arbace_g2a_types_A_const_66; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_g2a_types_A_Init(); tmp15 = A_arbace_g2a_types_A_const_68; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1376000040__6), nil) } } else { var f__4 any; var tmp16 *lang.Var; A_arbace_g2a_types_A_Init(); tmp16 = A_arbace_g2a_types_A_const_28; f__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1376000038__3); var tmp17 *lang.Var; A_arbace_g2a_types_A_Init(); tmp17 = A_arbace_g2a_types_A_const_67; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any; var tmp20 *lang.Keyword
														A_arbace_g2a_types_A_Init(); tmp20 = A_arbace_g2a_types_A_const_74; if jrt.A2g_Truth(jrt.NN(tmp20).Invoke_O__O(f__4)) { var t__5 any; var tmp21 *lang.Var
															A_arbace_g2a_types_A_Init(); tmp21 = A_arbace_g2a_types_A_const_22; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp23 = A_arbace_g2a_types_A_const_23; t__5 = tmp22.Invoke_O__O(jrt.NN(tmp23).Invoke_O__O(f__4))
															var tmp24 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp24 = A_arbace_g2a_types_A_const_38; if jrt.A2g_Truth(jrt.NN(tmp24).Invoke_O__O(f__4)) { var tmp25 *lang.Var; A_arbace_g2a_types_A_Init(); tmp25 = A_arbace_g2a_types_A_const_75; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Var; A_arbace_g2a_types_A_Init(); tmp27 = A_arbace_g2a_types_A_const_76; var tmp28 any = jrt.NN(tmp27).GetRawRoot__O(); var tmp29 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp29 = A_arbace_g2a_types_A_const_77; var tmp30 any = tmp29.Ref(); var tmp31 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp31 = A_arbace_g2a_types_A_const_38; tmp19 = tmp26.Invoke_O_O_O_O__O(t__5, tmp28, tmp30, jrt.NN(tmp31).Invoke_O__O(f__4)) } else { tmp19 = t__5 } } else {
																var tmp32 *lang.Var; A_arbace_g2a_types_A_Init(); tmp32 = A_arbace_g2a_types_A_const_37; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 *lang.Var; A_arbace_g2a_types_A_Init(); tmp34 = A_arbace_g2a_types_A_const_8; var tmp35 lang.IFn = lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()); var tmp36 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp36 = A_arbace_g2a_types_A_const_29; var tmp37 any = tmp35.Invoke_O__O(jrt.NN(tmp36).Invoke_O__O(f__4)); var tmp38 any; var G__1376000046__5_ any; var tmp39 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp39 = A_arbace_g2a_types_A_const_38; var tmp40 any = tmp39.Ref(); var tmp41 *lang.Var; A_arbace_g2a_types_A_Init(); tmp41 = A_arbace_g2a_types_A_const_22; var tmp42 lang.IFn = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()); var tmp43 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp43 = A_arbace_g2a_types_A_const_23; G__1376000046__5_ = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp40, tmp42.Invoke_O__O(jrt.NN(tmp43).Invoke_O__O(f__4))))
																var tmp44 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp44 = A_arbace_g2a_types_A_const_38; if jrt.A2g_Truth(jrt.NN(tmp44).Invoke_O__O(f__4)) {
																	var tmp45 *lang.Var; A_arbace_g2a_types_A_Init(); tmp45 = A_arbace_g2a_types_A_const_76; var tmp46 lang.IFn = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()); var tmp47 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp47 = A_arbace_g2a_types_A_const_77; var tmp48 any = tmp47.Ref(); var tmp49 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp49 = A_arbace_g2a_types_A_const_38; tmp38 = tmp46.Invoke_O_O_O__O(G__1376000046__5_, tmp48, jrt.NN(tmp49).Invoke_O__O(f__4)) } else {
//line :90:1
					tmp38 = G__1376000046__5_ }
//line :89:1
			tmp19 = tmp33.Invoke_O_O__O(tmp37, tmp38) }
//line :85:1
	var tmp50 any = tmp19; var tmp51 lang.IFn = lang.IFn_Cast(t.F_iter__1376000037); var tmp52 *lang.Var; A_arbace_g2a_types_A_Init(); tmp52 = A_arbace_g2a_types_A_const_70; return tmp18.Invoke_O_O__O(tmp50, tmp51.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()).Invoke_O__O(s__1376000038__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :85:1
func A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A { A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_Init(); t := &A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :85:1
func (t *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A) Ctor_O_I_O(c__b__1376000040 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1376000040 = c__b__1376000040; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :85:1
func (t *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A) Invoke_O__O(self any) any { { var i__1376000039__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1376000039__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1376000039__1)); var tmp2 *lang.Var; A_arbace_g2a_types_A_Init(); tmp2 = A_arbace_g2a_types_A_const_63; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__1376000040; var tmp5 any; var tmp6 *lang.Keyword
																A_arbace_g2a_types_A_Init(); tmp6 = A_arbace_g2a_types_A_const_74; if jrt.A2g_Truth(jrt.NN(tmp6).Invoke_O__O(f__2)) { var t__3 any; var tmp7 *lang.Var
																	A_arbace_g2a_types_A_Init(); tmp7 = A_arbace_g2a_types_A_const_22; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp9 = A_arbace_g2a_types_A_const_23; t__3 = tmp8.Invoke_O__O(jrt.NN(tmp9).Invoke_O__O(f__2))
																	var tmp10 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp10 = A_arbace_g2a_types_A_const_38; if jrt.A2g_Truth(jrt.NN(tmp10).Invoke_O__O(f__2)) { var tmp11 *lang.Var; A_arbace_g2a_types_A_Init(); tmp11 = A_arbace_g2a_types_A_const_75; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_g2a_types_A_Init(); tmp13 = A_arbace_g2a_types_A_const_76; var tmp14 any = jrt.NN(tmp13).GetRawRoot__O(); var tmp15 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp15 = A_arbace_g2a_types_A_const_77; var tmp16 any = tmp15.Ref(); var tmp17 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp17 = A_arbace_g2a_types_A_const_38; tmp5 = tmp12.Invoke_O_O_O_O__O(t__3, tmp14, tmp16, jrt.NN(tmp17).Invoke_O__O(f__2)) } else { tmp5 = t__3 } } else {
																		var tmp18 *lang.Var; A_arbace_g2a_types_A_Init(); tmp18 = A_arbace_g2a_types_A_const_37; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Var; A_arbace_g2a_types_A_Init(); tmp20 = A_arbace_g2a_types_A_const_8; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp22 = A_arbace_g2a_types_A_const_29; var tmp23 any = tmp21.Invoke_O__O(jrt.NN(tmp22).Invoke_O__O(f__2)); var tmp24 any; var G__1376000044__3_ any; var tmp25 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp25 = A_arbace_g2a_types_A_const_38; var tmp26 any = tmp25.Ref(); var tmp27 *lang.Var; A_arbace_g2a_types_A_Init(); tmp27 = A_arbace_g2a_types_A_const_22; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp29 = A_arbace_g2a_types_A_const_23; G__1376000044__3_ = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp26, tmp28.Invoke_O__O(jrt.NN(tmp29).Invoke_O__O(f__2))))
																		var tmp30 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp30 = A_arbace_g2a_types_A_const_38; if jrt.A2g_Truth(jrt.NN(tmp30).Invoke_O__O(f__2)) {
																			var tmp31 *lang.Var; A_arbace_g2a_types_A_Init(); tmp31 = A_arbace_g2a_types_A_const_76; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp33 = A_arbace_g2a_types_A_const_77; var tmp34 any = tmp33.Ref(); var tmp35 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp35 = A_arbace_g2a_types_A_const_38; tmp24 = tmp32.Invoke_O_O_O__O(G__1376000044__3_, tmp34, jrt.NN(tmp35).Invoke_O__O(f__2)) } else {
//line :90:1
					tmp24 = G__1376000044__3_ }
//line :89:1
			tmp5 = tmp19.Invoke_O_O__O(tmp23, tmp24) }
//line :85:1
	tmp3.Invoke_O_O__O(tmp4, tmp5); i__1376000039__1 = lang.Numbers_Unchecked_inc_J__J(i__1376000039__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }










func A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_New() *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A { A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_Init(); t := &A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A{}; t.Ctor(); return t }
//line :96:1
func (t *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A) Ctor() {}
//line :96:1
func (t *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A) Invoke_O_O__O(self, s__1376000028__1 any) any { var tmp1 any = A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_New_O_O(s__1376000028__1, self); var tmp2 *jrt.Class; A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_Init(); tmp2 = A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :96:1
func A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_New_O_O(p0, p1 any) *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A { A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_Init(); t := &A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A{}; t.Ctor_O_O(p0, p1); return t }
//line :96:1
func (t *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A) Ctor_O_O(c__s__1376000028, c__iter__1376000027 any) { t.F_s__1376000028 = c__s__1376000028; t.F_iter__1376000027 = c__iter__1376000027 }
//line :96:1
func (t *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A) Invoke_O__O(self any) any { { var s__1376000028__1 any; var t_ any = t.F_s__1376000028; t.F_s__1376000028 = nil; s__1376000028__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_g2a_types_A_Init(); tmp1 = A_arbace_g2a_types_A_const_27; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1376000028__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1376000028__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_g2a_types_A_Init(); tmp2 = A_arbace_g2a_types_A_const_60; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1376000028__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_g2a_types_A_Init(); tmp3 = A_arbace_g2a_types_A_const_61; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1376000028__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1376000030__6 any; var tmp4 *lang.Var; A_arbace_g2a_types_A_Init(); tmp4 = A_arbace_g2a_types_A_const_62; b__1376000030__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_New_O_I_O(b__1376000030__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_Init(); tmp6 = A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_g2a_types_A_Init(); tmp7 = A_arbace_g2a_types_A_const_66; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_g2a_types_A_Init(); tmp9 = A_arbace_g2a_types_A_const_68; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1376000030__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1376000027); var tmp12 *lang.Var; A_arbace_g2a_types_A_Init(); tmp12 = A_arbace_g2a_types_A_const_69; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1376000028__3))) } else { var tmp13 *lang.Var; A_arbace_g2a_types_A_Init(); tmp13 = A_arbace_g2a_types_A_const_66; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_g2a_types_A_Init(); tmp15 = A_arbace_g2a_types_A_const_68; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1376000030__6), nil) } } else { var t__4 any; var tmp16 *lang.Var; A_arbace_g2a_types_A_Init(); tmp16 = A_arbace_g2a_types_A_const_28; t__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1376000028__3); var tmp17 *lang.Var; A_arbace_g2a_types_A_Init(); tmp17 = A_arbace_g2a_types_A_const_67; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any; var tmp20 *lang.Keyword
														A_arbace_g2a_types_A_Init(); tmp20 = A_arbace_g2a_types_A_const_64; if jrt.A2g_Truth(jrt.NN(tmp20).Invoke_O__O(t__4)) { var tmp21 *lang.Var; A_arbace_g2a_types_A_Init(); tmp21 = A_arbace_g2a_types_A_const_34; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 any; A_arbace_g2a_types_A_Init(); tmp23 = A_arbace_g2a_types_A_const_65; var tmp24 any = tmp23; var tmp25 *lang.Var; A_arbace_g2a_types_A_Init(); tmp25 = A_arbace_g2a_types_A_const_22; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp27 = A_arbace_g2a_types_A_const_23; tmp19 = tmp22.Invoke_O_O__O(tmp24, tmp26.Invoke_O__O(jrt.NN(tmp27).Invoke_O__O(t__4))) } else { var tmp28 *lang.Var; A_arbace_g2a_types_A_Init(); tmp28 = A_arbace_g2a_types_A_const_22; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp30 = A_arbace_g2a_types_A_const_23; tmp19 = tmp29.Invoke_O__O(jrt.NN(tmp30).Invoke_O__O(t__4)) }
//line :96:1
	var tmp31 any = tmp19; var tmp32 lang.IFn = lang.IFn_Cast(t.F_iter__1376000027); var tmp33 *lang.Var; A_arbace_g2a_types_A_Init(); tmp33 = A_arbace_g2a_types_A_const_70; return tmp18.Invoke_O_O__O(tmp31, tmp32.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()).Invoke_O__O(s__1376000028__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :96:1
func A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A { A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_Init(); t := &A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :96:1
func (t *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A) Ctor_O_I_O(c__b__1376000030 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1376000030 = c__b__1376000030; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :96:1
func (t *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A) Invoke_O__O(self any) any { { var i__1376000029__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1376000029__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var t__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1376000029__1)); var tmp2 *lang.Var; A_arbace_g2a_types_A_Init(); tmp2 = A_arbace_g2a_types_A_const_63; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__1376000030; var tmp5 any; var tmp6 *lang.Keyword
																A_arbace_g2a_types_A_Init(); tmp6 = A_arbace_g2a_types_A_const_64; if jrt.A2g_Truth(jrt.NN(tmp6).Invoke_O__O(t__2)) { var tmp7 *lang.Var; A_arbace_g2a_types_A_Init(); tmp7 = A_arbace_g2a_types_A_const_34; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_g2a_types_A_Init(); tmp9 = A_arbace_g2a_types_A_const_65; var tmp10 any = tmp9; var tmp11 *lang.Var; A_arbace_g2a_types_A_Init(); tmp11 = A_arbace_g2a_types_A_const_22; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp13 = A_arbace_g2a_types_A_const_23; tmp5 = tmp8.Invoke_O_O__O(tmp10, tmp12.Invoke_O__O(jrt.NN(tmp13).Invoke_O__O(t__2))) } else { var tmp14 *lang.Var; A_arbace_g2a_types_A_Init(); tmp14 = A_arbace_g2a_types_A_const_22; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp16 = A_arbace_g2a_types_A_const_23; tmp5 = tmp15.Invoke_O__O(jrt.NN(tmp16).Invoke_O__O(t__2)) }
//line :96:1
	tmp3.Invoke_O_O__O(tmp4, tmp5); i__1376000029__1 = lang.Numbers_Unchecked_inc_J__J(i__1376000029__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }












func A_arbace_g2a_types_untyped_QMARK__A_New() *A_arbace_g2a_types_untyped_QMARK__A { A_arbace_g2a_types_untyped_QMARK__A_Init(); t := &A_arbace_g2a_types_untyped_QMARK__A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_g2a_types_untyped_QMARK__A) Ctor() {}
//line :109:1
func (t *A_arbace_g2a_types_untyped_QMARK__A) Invoke_O_O__O(self, id__0 any) any { var e__2 any; var tmp1 *lang.Var;


	A_arbace_g2a_types_A_Init(); tmp1 = A_arbace_g2a_types_A_const_30; e__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(id__0); var and__1927000168__auto____3 bool; var tmp2 /*line :109:1*/*lang.Keyword;



	A_arbace_g2a_types_A_Init(); tmp2 = A_arbace_g2a_types_A_const_80; var tmp3 any = tmp2.Ref(); var tmp4 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp4 = A_arbace_g2a_types_A_const_41; and__1927000168__auto____3 = lang.Util_Equiv_O_O__Z(tmp3, jrt.NN(tmp4).Invoke_O__O(e__2)); if and__1927000168__auto____3 { var tmp5 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp5 = A_arbace_g2a_types_A_const_29; return jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.String_Cast(jrt.NN(tmp5).Invoke_O__O(e__2))).StartsWith_String__Z(Lit_131)).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() } }








func A_arbace_g2a_types_const_kind_A_New() *A_arbace_g2a_types_const_kind_A { A_arbace_g2a_types_const_kind_A_Init(); t := &A_arbace_g2a_types_const_kind_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_g2a_types_const_kind_A) Ctor() {}
//line :122:1
func (t *A_arbace_g2a_types_const_kind_A) Invoke_O_O__O(self, id__0 any) any { var e__2 any; var tmp1 *lang.Var;



	A_arbace_g2a_types_A_Init(); tmp1 = A_arbace_g2a_types_A_const_30; e__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(id__0); var G__1376000051__3_ any; var tmp2 /*line :122:1*/*lang.Keyword;




	A_arbace_g2a_types_A_Init(); tmp2 = A_arbace_g2a_types_A_const_41; G__1376000051__3_ = jrt.NN(tmp2).Invoke_O__O(e__2); switch lang.Util_Hash_O__I(G__1376000051__3_) >> 4 & 3 { case 1: var tmp3 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp3 = A_arbace_g2a_types_A_const_95; if any(G__1376000051__3_) == any(tmp3.Ref()) {




		var tmp4 *lang.Var; A_arbace_g2a_types_A_Init(); tmp4 = A_arbace_g2a_types_A_const_108; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp6 = A_arbace_g2a_types_A_const_113; return tmp5.Invoke_O__O(jrt.NN(tmp6).Invoke_O__O(e__2)) }
//line :127:1
	case 2: var tmp7 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp7 = A_arbace_g2a_types_A_const_80; if any(G__1376000051__3_) == any(tmp7.Ref()) { var or__1927000174__auto____4 any; var tmp8 *lang.Var
		A_arbace_g2a_types_A_Init(); tmp8 = A_arbace_g2a_types_A_const_109; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp10 = A_arbace_g2a_types_A_const_29; or__1927000174__auto____4 = tmp9.Invoke_O__O(jrt.NN(tmp10).Invoke_O__O(e__2)); if jrt.A2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else {
			var tmp11 any; A_arbace_g2a_types_A_Init(); tmp11 = A_arbace_g2a_types_A_const_110; var tmp12 lang.IFn = lang.IFn_Cast(tmp11); var tmp13 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp13 = A_arbace_g2a_types_A_const_29; if jrt.A2g_Truth(tmp12.Invoke_O__O(jrt.NN(tmp13).Invoke_O__O(e__2))) { A_arbace_g2a_types_A_Init(); return A_arbace_g2a_types_A_const_111.Ref() } else { return nil } } }
//line :127:1
	case 3: var tmp14 *lang.Keyword; A_arbace_g2a_types_A_Init(); tmp14 = A_arbace_g2a_types_A_const_104; if any(G__1376000051__3_) == any(tmp14.Ref()) { var temp__1927000414__auto____4 any; var tmp15 *lang.Var





		A_arbace_g2a_types_A_Init(); tmp15 = A_arbace_g2a_types_A_const_112; temp__1927000414__auto____4 = lang.RT_Get_O_O__O(jrt.NN(tmp15).Get__O(), id__0); if jrt.A2g_Truth(temp__1927000414__auto____4) { var u__5 any = temp__1927000414__auto____4; var tmp16 *lang.Var; A_arbace_g2a_types_A_Init(); tmp16 = A_arbace_g2a_types_A_const_108; return lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(u__5) } else { return nil } }
//line :127:1
	default:}; return nil }







type A_arbace_g2a_types_A struct{ jrt.Object }

var A_arbace_g2a_types_A_const_0 *lang.Var

var A_arbace_g2a_types_A_const_1 any

var A_arbace_g2a_types_A_const_2 *lang.Var

var A_arbace_g2a_types_A_const_3 *lang.Var

var A_arbace_g2a_types_A_const_4 *lang.Var

var A_arbace_g2a_types_A_const_5 any

var A_arbace_g2a_types_A_const_6 *lang.Var

var A_arbace_g2a_types_A_const_7 *lang.Var

var A_arbace_g2a_types_A_const_8 *lang.Var

var A_arbace_g2a_types_A_const_9 *lang.Var

var A_arbace_g2a_types_A_const_10 *lang.Var

var A_arbace_g2a_types_A_const_11 *lang.Var

var A_arbace_g2a_types_A_const_12 *lang.Var

var A_arbace_g2a_types_A_const_13 *jrt.Class

var A_arbace_g2a_types_A_const_14 *lang.Var

var A_arbace_g2a_types_A_const_15 *lang.Var

var A_arbace_g2a_types_A_const_16 *lang.Keyword

var A_arbace_g2a_types_A_const_17 *lang.Var

var A_arbace_g2a_types_A_const_18 *lang.Var

var A_arbace_g2a_types_A_const_19 *lang.Var

var A_arbace_g2a_types_A_const_20 *lang.Var

var A_arbace_g2a_types_A_const_21 any

var A_arbace_g2a_types_A_const_22 *lang.Var

var A_arbace_g2a_types_A_const_23 *lang.Keyword

var A_arbace_g2a_types_A_const_24 *lang.Var

var A_arbace_g2a_types_A_const_25 *lang.Var

var A_arbace_g2a_types_A_const_26 *lang.Var

var A_arbace_g2a_types_A_const_27 *lang.Var

var A_arbace_g2a_types_A_const_28 *lang.Var

var A_arbace_g2a_types_A_const_29 *lang.Keyword

var A_arbace_g2a_types_A_const_30 *lang.Var

var A_arbace_g2a_types_A_const_31 *lang.Var

var A_arbace_g2a_types_A_const_32 *lang.Keyword

var A_arbace_g2a_types_A_const_33 *lang.Var

var A_arbace_g2a_types_A_const_34 *lang.Var

var A_arbace_g2a_types_A_const_35 *lang.Keyword

var A_arbace_g2a_types_A_const_36 *lang.Keyword

var A_arbace_g2a_types_A_const_37 *lang.Var

var A_arbace_g2a_types_A_const_38 *lang.Keyword

var A_arbace_g2a_types_A_const_39 *lang.Var

var A_arbace_g2a_types_A_const_40 *lang.Var

var A_arbace_g2a_types_A_const_41 *lang.Keyword

var A_arbace_g2a_types_A_const_42 *lang.Keyword

var A_arbace_g2a_types_A_const_43 *lang.Keyword

var A_arbace_g2a_types_A_const_44 *lang.Keyword

var A_arbace_g2a_types_A_const_45 *lang.Keyword

var A_arbace_g2a_types_A_const_46 *lang.Keyword

var A_arbace_g2a_types_A_const_47 *lang.Keyword

var A_arbace_g2a_types_A_const_48 *lang.Keyword

var A_arbace_g2a_types_A_const_49 *lang.Keyword

var A_arbace_g2a_types_A_const_50 *lang.Var

var A_arbace_g2a_types_A_const_51 any

var A_arbace_g2a_types_A_const_52 *lang.Keyword

var A_arbace_g2a_types_A_const_53 *lang.Keyword

var A_arbace_g2a_types_A_const_54 any

var A_arbace_g2a_types_A_const_55 any

var A_arbace_g2a_types_A_const_56 any

var A_arbace_g2a_types_A_const_57 any

var A_arbace_g2a_types_A_const_58 *lang.Keyword

var A_arbace_g2a_types_A_const_59 any

var A_arbace_g2a_types_A_const_60 *lang.Var

var A_arbace_g2a_types_A_const_61 *lang.Var

var A_arbace_g2a_types_A_const_62 *lang.Var

var A_arbace_g2a_types_A_const_63 *lang.Var

var A_arbace_g2a_types_A_const_64 *lang.Keyword

var A_arbace_g2a_types_A_const_65 any

var A_arbace_g2a_types_A_const_66 *lang.Var

var A_arbace_g2a_types_A_const_67 *lang.Var

var A_arbace_g2a_types_A_const_68 *lang.Var

var A_arbace_g2a_types_A_const_69 *lang.Var

var A_arbace_g2a_types_A_const_70 *lang.Var

var A_arbace_g2a_types_A_const_71 *lang.Keyword

var A_arbace_g2a_types_A_const_72 *lang.Keyword

var A_arbace_g2a_types_A_const_73 any

var A_arbace_g2a_types_A_const_74 *lang.Keyword

var A_arbace_g2a_types_A_const_75 *lang.Var

var A_arbace_g2a_types_A_const_76 *lang.Var

var A_arbace_g2a_types_A_const_77 *lang.Keyword

var A_arbace_g2a_types_A_const_78 *lang.Keyword

var A_arbace_g2a_types_A_const_79 *lang.Keyword

var A_arbace_g2a_types_A_const_80 *lang.Keyword

var A_arbace_g2a_types_A_const_81 *lang.Keyword

var A_arbace_g2a_types_A_const_82 *lang.Var

var A_arbace_g2a_types_A_const_83 any

var A_arbace_g2a_types_A_const_84 *lang.Keyword

var A_arbace_g2a_types_A_const_85 *lang.Keyword

var A_arbace_g2a_types_A_const_86 *lang.Keyword

var A_arbace_g2a_types_A_const_87 any

var A_arbace_g2a_types_A_const_88 any

var A_arbace_g2a_types_A_const_89 *lang.Keyword

var A_arbace_g2a_types_A_const_90 any

var A_arbace_g2a_types_A_const_91 *lang.Var

var A_arbace_g2a_types_A_const_92 *lang.Var

var A_arbace_g2a_types_A_const_93 *lang.Keyword

var A_arbace_g2a_types_A_const_94 *lang.Keyword

var A_arbace_g2a_types_A_const_95 *lang.Keyword

var A_arbace_g2a_types_A_const_96 *lang.Keyword

var A_arbace_g2a_types_A_const_97 *lang.Var

var A_arbace_g2a_types_A_const_98 *lang.Var

var A_arbace_g2a_types_A_const_99 any

var A_arbace_g2a_types_A_const_100 *lang.Keyword

var A_arbace_g2a_types_A_const_101 *lang.Keyword

var A_arbace_g2a_types_A_const_102 any

var A_arbace_g2a_types_A_const_103 *lang.Keyword

var A_arbace_g2a_types_A_const_104 *lang.Keyword

var A_arbace_g2a_types_A_const_105 any

var A_arbace_g2a_types_A_const_106 *lang.Var

var A_arbace_g2a_types_A_const_107 *lang.Keyword

var A_arbace_g2a_types_A_const_108 *lang.Var

var A_arbace_g2a_types_A_const_109 *lang.Var

var A_arbace_g2a_types_A_const_110 any

var A_arbace_g2a_types_A_const_111 *lang.Keyword

var A_arbace_g2a_types_A_const_112 *lang.Var

var A_arbace_g2a_types_A_const_113 *lang.Keyword

var A_arbace_g2a_types_A_init jrt.ClassInit

func A_arbace_g2a_types_A_Init() { if !A_arbace_g2a_types_A_init.Done() { A_arbace_g2a_types_A_init.Run(A_arbace_g2a_types_A_clinit) } }

func A_arbace_g2a_types_A_clinit() { A_arbace_g2a_types_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_g2a_types_A_const_1 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_g2a_types_A_const_2 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_g2a_types_A_const_3 = lang.RT_Var_String_String__Var(Lit_0, Lit_3); A_arbace_g2a_types_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_4); A_arbace_g2a_types_A_const_5 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_5)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7))); A_arbace_g2a_types_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_8); A_arbace_g2a_types_A_const_7 = lang.RT_Var_String_String__Var(Lit_5, Lit_9); A_arbace_g2a_types_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_10); A_arbace_g2a_types_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_11); A_arbace_g2a_types_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_12); A_arbace_g2a_types_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_13); A_arbace_g2a_types_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_14); A_arbace_g2a_types_A_const_13 = lang.RT_ClassForNameNonLoading_String__Class(Lit_15); A_arbace_g2a_types_A_const_14 = lang.RT_Var_String_String__Var(Lit_5, Lit_16); A_arbace_g2a_types_A_const_15 = lang.RT_Var_String_String__Var(Lit_0, Lit_17); A_arbace_g2a_types_A_const_16 = lang.RT_Keyword_String_String__Keyword(nil, Lit_18); A_arbace_g2a_types_A_const_17 = lang.RT_Var_String_String__Var(Lit_5, Lit_19); A_arbace_g2a_types_A_const_18 = lang.RT_Var_String_String__Var(Lit_5, Lit_20); A_arbace_g2a_types_A_const_19 = lang.RT_Var_String_String__Var(Lit_0, Lit_21); A_arbace_g2a_types_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_22); A_arbace_g2a_types_A_const_21 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_23).Ref(); A_arbace_g2a_types_A_const_22 = lang.RT_Var_String_String__Var(Lit_5, Lit_24); A_arbace_g2a_types_A_const_23 = lang.RT_Keyword_String_String__Keyword(nil, Lit_25); A_arbace_g2a_types_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_26); A_arbace_g2a_types_A_const_25 = lang.RT_Var_String_String__Var(Lit_0, Lit_27); A_arbace_g2a_types_A_const_26 = lang.RT_Var_String_String__Var(Lit_0, Lit_28); A_arbace_g2a_types_A_const_27 = lang.RT_Var_String_String__Var(Lit_0, Lit_29); A_arbace_g2a_types_A_const_28 = lang.RT_Var_String_String__Var(Lit_0, Lit_30); A_arbace_g2a_types_A_const_29 = lang.RT_Keyword_String_String__Keyword(nil, Lit_31); A_arbace_g2a_types_A_const_30 = lang.RT_Var_String_String__Var(Lit_5, Lit_32); A_arbace_g2a_types_A_const_31 = lang.RT_Var_String_String__Var(Lit_5, Lit_33); A_arbace_g2a_types_A_const_32 = lang.RT_Keyword_String_String__Keyword(nil, Lit_34); A_arbace_g2a_types_A_const_33 = lang.RT_Var_String_String__Var(Lit_0, Lit_35); A_arbace_g2a_types_A_const_34 = lang.RT_Var_String_String__Var(Lit_0, Lit_36); A_arbace_g2a_types_A_const_35 = lang.RT_Keyword_String_String__Keyword(nil, Lit_37); A_arbace_g2a_types_A_const_36 = lang.RT_Keyword_String_String__Keyword(nil, Lit_38); A_arbace_g2a_types_A_const_37 = lang.RT_Var_String_String__Var(Lit_0, Lit_39); A_arbace_g2a_types_A_const_38 = lang.RT_Keyword_String_String__Keyword(nil, Lit_40); A_arbace_g2a_types_A_const_39 = lang.RT_Var_String_String__Var(Lit_0, Lit_41); A_arbace_g2a_types_A_const_40 = lang.RT_Var_String_String__Var(Lit_0, Lit_42); A_arbace_g2a_types_A_const_41 = lang.RT_Keyword_String_String__Keyword(nil, Lit_43); A_arbace_g2a_types_A_const_42 = lang.RT_Keyword_String_String__Keyword(nil, Lit_14); A_arbace_g2a_types_A_const_43 = lang.RT_Keyword_String_String__Keyword(nil, Lit_44); A_arbace_g2a_types_A_const_44 = lang.RT_Keyword_String_String__Keyword(nil, Lit_45); A_arbace_g2a_types_A_const_45 = lang.RT_Keyword_String_String__Keyword(nil, Lit_46); A_arbace_g2a_types_A_const_46 = lang.RT_Keyword_String_String__Keyword(nil, Lit_47); A_arbace_g2a_types_A_const_47 = lang.RT_Keyword_String_String__Keyword(nil, Lit_48); A_arbace_g2a_types_A_const_48 = lang.RT_Keyword_String_String__Keyword(nil, Lit_49); A_arbace_g2a_types_A_const_49 = lang.RT_Keyword_String_String__Keyword(nil, Lit_50); A_arbace_g2a_types_A_const_50 = lang.RT_Var_String_String__Var(Lit_0, Lit_51); A_arbace_g2a_types_A_const_51 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_14).Ref(); A_arbace_g2a_types_A_const_52 = lang.RT_Keyword_String_String__Keyword(nil, Lit_52); A_arbace_g2a_types_A_const_53 = lang.RT_Keyword_String_String__Keyword(nil, Lit_53); A_arbace_g2a_types_A_const_54 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_44).Ref(); A_arbace_g2a_types_A_const_55 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_44).Ref(); A_arbace_g2a_types_A_const_56 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_44).Ref(); A_arbace_g2a_types_A_const_57 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_54).Ref(); A_arbace_g2a_types_A_const_58 = lang.RT_Keyword_String_String__Keyword(nil, Lit_55); A_arbace_g2a_types_A_const_59 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_56).Ref(); A_arbace_g2a_types_A_const_60 = lang.RT_Var_String_String__Var(Lit_0, Lit_57); A_arbace_g2a_types_A_const_61 = lang.RT_Var_String_String__Var(Lit_0, Lit_58); A_arbace_g2a_types_A_const_62 = lang.RT_Var_String_String__Var(Lit_0, Lit_59); A_arbace_g2a_types_A_const_63 = lang.RT_Var_String_String__Var(Lit_0, Lit_60); A_arbace_g2a_types_A_const_64 = lang.RT_Keyword_String_String__Keyword(nil, Lit_61); A_arbace_g2a_types_A_const_65 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_61).Ref(); A_arbace_g2a_types_A_const_66 = lang.RT_Var_String_String__Var(Lit_0, Lit_62); A_arbace_g2a_types_A_const_67 = lang.RT_Var_String_String__Var(Lit_0, Lit_63); A_arbace_g2a_types_A_const_68 = lang.RT_Var_String_String__Var(Lit_0, Lit_64); A_arbace_g2a_types_A_const_69 = lang.RT_Var_String_String__Var(Lit_0, Lit_65); A_arbace_g2a_types_A_const_70 = lang.RT_Var_String_String__Var(Lit_0, Lit_66); A_arbace_g2a_types_A_const_71 = lang.RT_Keyword_String_String__Keyword(nil, Lit_67); A_arbace_g2a_types_A_const_72 = lang.RT_Keyword_String_String__Keyword(nil, Lit_68); A_arbace_g2a_types_A_const_73 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_55).Ref(); A_arbace_g2a_types_A_const_74 = lang.RT_Keyword_String_String__Keyword(nil, Lit_69); A_arbace_g2a_types_A_const_75 = lang.RT_Var_String_String__Var(Lit_0, Lit_70); A_arbace_g2a_types_A_const_76 = lang.RT_Var_String_String__Var(Lit_0, Lit_71); A_arbace_g2a_types_A_const_77 = lang.RT_Keyword_String_String__Keyword(Lit_72, Lit_40); A_arbace_g2a_types_A_const_78 = lang.RT_Keyword_String_String__Keyword(nil, Lit_73); A_arbace_g2a_types_A_const_79 = lang.RT_Keyword_String_String__Keyword(nil, Lit_74); A_arbace_g2a_types_A_const_80 = lang.RT_Keyword_String_String__Keyword(nil, Lit_75); A_arbace_g2a_types_A_const_81 = lang.RT_Keyword_String_String__Keyword(nil, Lit_76); A_arbace_g2a_types_A_const_82 = lang.RT_Var_String_String__Var(Lit_5, Lit_77); A_arbace_g2a_types_A_const_83 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_74).Ref(); A_arbace_g2a_types_A_const_84 = lang.RT_Keyword_String_String__Keyword(nil, Lit_78); A_arbace_g2a_types_A_const_85 = lang.RT_Keyword_String_String__Keyword(nil, Lit_79); A_arbace_g2a_types_A_const_86 = lang.RT_Keyword_String_String__Keyword(nil, Lit_80); A_arbace_g2a_types_A_const_87 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_79).Ref(); A_arbace_g2a_types_A_const_88 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_79).Ref(); A_arbace_g2a_types_A_const_89 = lang.RT_Keyword_String_String__Keyword(nil, Lit_81); A_arbace_g2a_types_A_const_90 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_80).Ref(); A_arbace_g2a_types_A_const_91 = lang.RT_Var_String_String__Var(Lit_0, Lit_82); A_arbace_g2a_types_A_const_92 = lang.RT_Var_String_String__Var(Lit_5, Lit_83); A_arbace_g2a_types_A_const_93 = lang.RT_Keyword_String_String__Keyword(nil, Lit_84); A_arbace_g2a_types_A_const_94 = lang.RT_Keyword_String_String__Keyword(nil, Lit_85); A_arbace_g2a_types_A_const_95 = lang.RT_Keyword_String_String__Keyword(nil, Lit_86); A_arbace_g2a_types_A_const_96 = lang.RT_Keyword_String_String__Keyword(nil, Lit_87); A_arbace_g2a_types_A_const_97 = lang.RT_Var_String_String__Var(Lit_0, Lit_88); A_arbace_g2a_types_A_const_98 = lang.RT_Var_String_String__Var(Lit_5, Lit_89); A_arbace_g2a_types_A_const_99 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_90).Ref(); A_arbace_g2a_types_A_const_100 = lang.RT_Keyword_String_String__Keyword(nil, Lit_91); A_arbace_g2a_types_A_const_101 = lang.RT_Keyword_String_String__Keyword(nil, Lit_92); A_arbace_g2a_types_A_const_102 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_93).Ref(); A_arbace_g2a_types_A_const_103 = lang.RT_Keyword_String_String__Keyword(nil, Lit_94); A_arbace_g2a_types_A_const_104 = lang.RT_Keyword_String_String__Keyword(nil, Lit_95); A_arbace_g2a_types_A_const_105 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_92).Ref(); A_arbace_g2a_types_A_const_106 = lang.RT_Var_String_String__Var(Lit_0, Lit_96); A_arbace_g2a_types_A_const_107 = lang.RT_Keyword_String_String__Keyword(nil, Lit_97); A_arbace_g2a_types_A_const_108 = lang.RT_Var_String_String__Var(Lit_5, Lit_98); A_arbace_g2a_types_A_const_109 = lang.RT_Var_String_String__Var(Lit_5, Lit_99); A_arbace_g2a_types_A_const_110 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.ConstRefArray("[0,13,s5:int16s3:ints4:runes4:uints5:int32s6:uint16s7:uintptrs6:uint32s5:int64s6:uint64s5:uint8s4:int8s4:byte", []*jrt.Class{jrt.Object_class})).Ref(); A_arbace_g2a_types_A_const_111 = lang.RT_Keyword_String_String__Keyword(nil, Lit_100); A_arbace_g2a_types_A_const_112 = lang.RT_Var_String_String__Var(Lit_5, Lit_101); A_arbace_g2a_types_A_const_113 = lang.RT_Keyword_String_String__Keyword(nil, Lit_102) }

func A_arbace_g2a_types_A_New() *A_arbace_g2a_types_A { A_arbace_g2a_types_A_Init(); t := &A_arbace_g2a_types_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_types_A) Ctor() {}

func (t *A_arbace_g2a_types_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_types_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_types_A_class }

func (t *A_arbace_g2a_types_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_types_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_types_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_types_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_types_A); return ok }

func A_arbace_g2a_types_A_Cast(x any) *A_arbace_g2a_types_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_types_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_types_A_class)) }; return v }



type A_arbace_g2a_types_const_kind_A struct{ jrt.Object }

func (t *A_arbace_g2a_types_const_kind_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_types_const_kind_A_fn_class *jrt.Class

var A_arbace_g2a_types_const_kind_A_init jrt.ClassInit

func A_arbace_g2a_types_const_kind_A_Init() { if !A_arbace_g2a_types_const_kind_A_init.Done() { A_arbace_g2a_types_const_kind_A_init.Run(A_arbace_g2a_types_const_kind_A_clinit) } }

func A_arbace_g2a_types_const_kind_A_clinit() { A_arbace_g2a_types_const_kind_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_103, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_types_const_kind_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_types_const_kind_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_types_const_kind_A_class }

func (t *A_arbace_g2a_types_const_kind_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_types_const_kind_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_types_const_kind_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_types_const_kind_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_types_const_kind_A); return ok }

func A_arbace_g2a_types_const_kind_A_Cast(x any) *A_arbace_g2a_types_const_kind_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_types_const_kind_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_types_const_kind_A_class)) }; return v }



type A_arbace_g2a_types_entry_A struct{ jrt.Object }

func (t *A_arbace_g2a_types_entry_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_types_entry_A_fn_class *jrt.Class

var A_arbace_g2a_types_entry_A_init jrt.ClassInit

func A_arbace_g2a_types_entry_A_Init() { if !A_arbace_g2a_types_entry_A_init.Done() { A_arbace_g2a_types_entry_A_init.Run(A_arbace_g2a_types_entry_A_clinit) } }

func A_arbace_g2a_types_entry_A_clinit() { A_arbace_g2a_types_entry_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_104, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_types_entry_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_types_entry_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_types_entry_A_class }

func (t *A_arbace_g2a_types_entry_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_types_entry_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_types_entry_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_types_entry_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_types_entry_A); return ok }

func A_arbace_g2a_types_entry_A_Cast(x any) *A_arbace_g2a_types_entry_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_types_entry_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_types_entry_A_class)) }; return v }



type A_arbace_g2a_types_eval1376000004_A struct{ jrt.Object }

func A_arbace_g2a_types_eval1376000004_A_New() *A_arbace_g2a_types_eval1376000004_A { t := &A_arbace_g2a_types_eval1376000004_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_types_eval1376000004_A) Ctor() {}

func (t *A_arbace_g2a_types_eval1376000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_types_eval1376000004_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_types_eval1376000004_A_class }

func (t *A_arbace_g2a_types_eval1376000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_types_eval1376000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_types_eval1376000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_types_eval1376000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_types_eval1376000004_A); return ok }

func A_arbace_g2a_types_eval1376000004_A_Cast(x any) *A_arbace_g2a_types_eval1376000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_types_eval1376000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_types_eval1376000004_A_class)) }; return v }



type A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A struct{ jrt.Object }

func (t *A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A_fn_class *jrt.Class

var A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A_init jrt.ClassInit

func A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A_Init() { if !A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A_init.Done() { A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A_init.Run(A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A_clinit) } }

func A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A_clinit() { A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_105, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A_class }

func (t *A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A); return ok }

func A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A_Cast(x any) *A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A_class)) }; return v }



type A_arbace_g2a_types_eval1376000008_A struct{ jrt.Object }

func A_arbace_g2a_types_eval1376000008_A_New() *A_arbace_g2a_types_eval1376000008_A { t := &A_arbace_g2a_types_eval1376000008_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_types_eval1376000008_A) Ctor() {}

func (t *A_arbace_g2a_types_eval1376000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_types_eval1376000008_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_types_eval1376000008_A_class }

func (t *A_arbace_g2a_types_eval1376000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_types_eval1376000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_types_eval1376000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_types_eval1376000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_types_eval1376000008_A); return ok }

func A_arbace_g2a_types_eval1376000008_A_Cast(x any) *A_arbace_g2a_types_eval1376000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_types_eval1376000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_types_eval1376000008_A_class)) }; return v }



type A_arbace_g2a_types_eval1376000008_fn__1376000009_A struct{ jrt.Object }

func (t *A_arbace_g2a_types_eval1376000008_fn__1376000009_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_types_eval1376000008_fn__1376000009_A_fn_class *jrt.Class

var A_arbace_g2a_types_eval1376000008_fn__1376000009_A_init jrt.ClassInit

func A_arbace_g2a_types_eval1376000008_fn__1376000009_A_Init() { if !A_arbace_g2a_types_eval1376000008_fn__1376000009_A_init.Done() { A_arbace_g2a_types_eval1376000008_fn__1376000009_A_init.Run(A_arbace_g2a_types_eval1376000008_fn__1376000009_A_clinit) } }

func A_arbace_g2a_types_eval1376000008_fn__1376000009_A_clinit() { A_arbace_g2a_types_eval1376000008_fn__1376000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_106, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_types_eval1376000008_fn__1376000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_types_eval1376000008_fn__1376000009_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_types_eval1376000008_fn__1376000009_A_class }

func (t *A_arbace_g2a_types_eval1376000008_fn__1376000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_types_eval1376000008_fn__1376000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_types_eval1376000008_fn__1376000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_types_eval1376000008_fn__1376000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_types_eval1376000008_fn__1376000009_A); return ok }

func A_arbace_g2a_types_eval1376000008_fn__1376000009_A_Cast(x any) *A_arbace_g2a_types_eval1376000008_fn__1376000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_types_eval1376000008_fn__1376000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_types_eval1376000008_fn__1376000009_A_class)) }; return v }



type A_arbace_g2a_types_method_elem_A struct{ jrt.Object }

func (t *A_arbace_g2a_types_method_elem_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_types_method_elem_A_fn_class *jrt.Class

var A_arbace_g2a_types_method_elem_A_init jrt.ClassInit

func A_arbace_g2a_types_method_elem_A_Init() { if !A_arbace_g2a_types_method_elem_A_init.Done() { A_arbace_g2a_types_method_elem_A_init.Run(A_arbace_g2a_types_method_elem_A_clinit) } }

func A_arbace_g2a_types_method_elem_A_clinit() { A_arbace_g2a_types_method_elem_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_107, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_types_method_elem_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_types_method_elem_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_types_method_elem_A_class }

func (t *A_arbace_g2a_types_method_elem_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_types_method_elem_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_types_method_elem_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_types_method_elem_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_types_method_elem_A); return ok }

func A_arbace_g2a_types_method_elem_A_Cast(x any) *A_arbace_g2a_types_method_elem_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_types_method_elem_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_types_method_elem_A_class)) }; return v }



type A_arbace_g2a_types_ns_name_of_A struct{ jrt.Object }

func (t *A_arbace_g2a_types_ns_name_of_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_types_ns_name_of_A_fn_class *jrt.Class

var A_arbace_g2a_types_ns_name_of_A_init jrt.ClassInit

func A_arbace_g2a_types_ns_name_of_A_Init() { if !A_arbace_g2a_types_ns_name_of_A_init.Done() { A_arbace_g2a_types_ns_name_of_A_init.Run(A_arbace_g2a_types_ns_name_of_A_clinit) } }

func A_arbace_g2a_types_ns_name_of_A_clinit() { A_arbace_g2a_types_ns_name_of_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_108, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_types_ns_name_of_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_types_ns_name_of_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_types_ns_name_of_A_class }

func (t *A_arbace_g2a_types_ns_name_of_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_types_ns_name_of_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_types_ns_name_of_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_types_ns_name_of_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_types_ns_name_of_A); return ok }

func A_arbace_g2a_types_ns_name_of_A_Cast(x any) *A_arbace_g2a_types_ns_name_of_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_types_ns_name_of_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_types_ns_name_of_A_class)) }; return v }



type A_arbace_g2a_types_ns_name_of_fn__1376000014_A struct{ jrt.Object }

func (t *A_arbace_g2a_types_ns_name_of_fn__1376000014_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_types_ns_name_of_fn__1376000014_A_fn_class *jrt.Class

var A_arbace_g2a_types_ns_name_of_fn__1376000014_A_init jrt.ClassInit

func A_arbace_g2a_types_ns_name_of_fn__1376000014_A_Init() { if !A_arbace_g2a_types_ns_name_of_fn__1376000014_A_init.Done() { A_arbace_g2a_types_ns_name_of_fn__1376000014_A_init.Run(A_arbace_g2a_types_ns_name_of_fn__1376000014_A_clinit) } }

func A_arbace_g2a_types_ns_name_of_fn__1376000014_A_clinit() { A_arbace_g2a_types_ns_name_of_fn__1376000014_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_113, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_types_ns_name_of_fn__1376000014_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_types_ns_name_of_fn__1376000014_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_types_ns_name_of_fn__1376000014_A_class }

func (t *A_arbace_g2a_types_ns_name_of_fn__1376000014_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_types_ns_name_of_fn__1376000014_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_types_ns_name_of_fn__1376000014_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_types_ns_name_of_fn__1376000014_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_types_ns_name_of_fn__1376000014_A); return ok }

func A_arbace_g2a_types_ns_name_of_fn__1376000014_A_Cast(x any) *A_arbace_g2a_types_ns_name_of_fn__1376000014_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_types_ns_name_of_fn__1376000014_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_types_ns_name_of_fn__1376000014_A_class)) }; return v }



type A_arbace_g2a_types_params_vec_A struct{ jrt.Object }

func (t *A_arbace_g2a_types_params_vec_A) Is_Compiler_AOTF2() {}

var A_arbace_g2a_types_params_vec_A_fn_class *jrt.Class

var A_arbace_g2a_types_params_vec_A_init jrt.ClassInit

func A_arbace_g2a_types_params_vec_A_Init() { if !A_arbace_g2a_types_params_vec_A_init.Done() { A_arbace_g2a_types_params_vec_A_init.Run(A_arbace_g2a_types_params_vec_A_clinit) } }

func A_arbace_g2a_types_params_vec_A_clinit() { A_arbace_g2a_types_params_vec_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_117, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_types_params_vec_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_types_params_vec_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_types_params_vec_A_class }

func (t *A_arbace_g2a_types_params_vec_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_types_params_vec_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_types_params_vec_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_types_params_vec_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_types_params_vec_A); return ok }

func A_arbace_g2a_types_params_vec_A_Cast(x any) *A_arbace_g2a_types_params_vec_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_types_params_vec_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_types_params_vec_A_class)) }; return v }



type A_arbace_g2a_types_params_vec_fn__1376000018_A struct{ jrt.Object; F_n int32; F_variadic any }

func (t *A_arbace_g2a_types_params_vec_fn__1376000018_A) Is_Compiler_AOTF2() {}

var A_arbace_g2a_types_params_vec_fn__1376000018_A_fn_class *jrt.Class

var A_arbace_g2a_types_params_vec_fn__1376000018_A_init jrt.ClassInit

func A_arbace_g2a_types_params_vec_fn__1376000018_A_Init() { if !A_arbace_g2a_types_params_vec_fn__1376000018_A_init.Done() { A_arbace_g2a_types_params_vec_fn__1376000018_A_init.Run(A_arbace_g2a_types_params_vec_fn__1376000018_A_clinit) } }

func A_arbace_g2a_types_params_vec_fn__1376000018_A_clinit() { A_arbace_g2a_types_params_vec_fn__1376000018_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_118, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_types_params_vec_fn__1376000018_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_types_params_vec_fn__1376000018_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_types_params_vec_fn__1376000018_A_class }

func (t *A_arbace_g2a_types_params_vec_fn__1376000018_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_types_params_vec_fn__1376000018_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_types_params_vec_fn__1376000018_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_types_params_vec_fn__1376000018_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_types_params_vec_fn__1376000018_A); return ok }

func A_arbace_g2a_types_params_vec_fn__1376000018_A_Cast(x any) *A_arbace_g2a_types_params_vec_fn__1376000018_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_types_params_vec_fn__1376000018_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_types_params_vec_fn__1376000018_A_class)) }; return v }



type A_arbace_g2a_types_qualify_A struct{ jrt.Object }

func (t *A_arbace_g2a_types_qualify_A) Is_Compiler_AOTF2() {}

var A_arbace_g2a_types_qualify_A_fn_class *jrt.Class

var A_arbace_g2a_types_qualify_A_init jrt.ClassInit

func A_arbace_g2a_types_qualify_A_Init() { if !A_arbace_g2a_types_qualify_A_init.Done() { A_arbace_g2a_types_qualify_A_init.Run(A_arbace_g2a_types_qualify_A_clinit) } }

func A_arbace_g2a_types_qualify_A_clinit() { A_arbace_g2a_types_qualify_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_119, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_types_qualify_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_types_qualify_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_types_qualify_A_class }

func (t *A_arbace_g2a_types_qualify_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_types_qualify_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_types_qualify_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_types_qualify_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_types_qualify_A); return ok }

func A_arbace_g2a_types_qualify_A_Cast(x any) *A_arbace_g2a_types_qualify_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_types_qualify_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_types_qualify_A_class)) }; return v }



type A_arbace_g2a_types_type_form_A struct{ jrt.Object }

func (t *A_arbace_g2a_types_type_form_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_types_type_form_A_fn_class *jrt.Class

var A_arbace_g2a_types_type_form_A_init jrt.ClassInit

func A_arbace_g2a_types_type_form_A_Init() { if !A_arbace_g2a_types_type_form_A_init.Done() { A_arbace_g2a_types_type_form_A_init.Run(A_arbace_g2a_types_type_form_A_clinit) } }

func A_arbace_g2a_types_type_form_A_clinit() { A_arbace_g2a_types_type_form_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_120, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_types_type_form_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_types_type_form_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_types_type_form_A_class }

func (t *A_arbace_g2a_types_type_form_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_types_type_form_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_types_type_form_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_types_type_form_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_types_type_form_A); return ok }

func A_arbace_g2a_types_type_form_A_Cast(x any) *A_arbace_g2a_types_type_form_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_types_type_form_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_types_type_form_A_class)) }; return v }



type A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A struct{ jrt.Object }

func (t *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_fn_class *jrt.Class

var A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_init jrt.ClassInit

func A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_Init() { if !A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_init.Done() { A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_init.Run(A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_clinit) } }

func A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_clinit() { A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_124, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_class }

func (t *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A); return ok }

func A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_Cast(x any) *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_class)) }; return v }



type A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A struct{ jrt.Object; F_s__1376000028, F_iter__1376000027 any }

func (t *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_fn_class *jrt.Class

var A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_init jrt.ClassInit

func A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_Init() { if !A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_init.Done() { A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_init.Run(A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_clinit) } }

func A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_clinit() { A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_125, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_class }

func (t *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A); return ok }

func A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_Cast(x any) *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_class)) }; return v }



type A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A struct{ jrt.Object; F_b__1376000030 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_fn_class *jrt.Class

var A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_init jrt.ClassInit

func A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_Init() { if !A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_init.Done() { A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_init.Run(A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_clinit) } }

func A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_clinit() { A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_126, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_class }

func (t *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A); return ok }

func A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_Cast(x any) *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_class)) }; return v }



type A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A struct{ jrt.Object }

func (t *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_fn_class *jrt.Class

var A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_init jrt.ClassInit

func A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_Init() { if !A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_init.Done() { A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_init.Run(A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_clinit) } }

func A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_clinit() { A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_127, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_class }

func (t *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A); return ok }

func A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_Cast(x any) *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_class)) }; return v }



type A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A struct{ jrt.Object; F_s__1376000038, F_iter__1376000037 any }

func (t *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_fn_class *jrt.Class

var A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_init jrt.ClassInit

func A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_Init() { if !A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_init.Done() { A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_init.Run(A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_clinit) } }

func A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_clinit() { A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_128, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_class }

func (t *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A); return ok }

func A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_Cast(x any) *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_class)) }; return v }



type A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A struct{ jrt.Object; F_b__1376000040 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A) Is_Compiler_AOTF0() {}

var A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_fn_class *jrt.Class

var A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_init jrt.ClassInit

func A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_Init() { if !A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_init.Done() { A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_init.Run(A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_clinit) } }

func A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_clinit() { A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_129, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_class }

func (t *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A); return ok }

func A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_Cast(x any) *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_class)) }; return v }



type A_arbace_g2a_types_untyped_QMARK__A struct{ jrt.Object }

func (t *A_arbace_g2a_types_untyped_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_g2a_types_untyped_QMARK__A_fn_class *jrt.Class

var A_arbace_g2a_types_untyped_QMARK__A_init jrt.ClassInit

func A_arbace_g2a_types_untyped_QMARK__A_Init() { if !A_arbace_g2a_types_untyped_QMARK__A_init.Done() { A_arbace_g2a_types_untyped_QMARK__A_init.Run(A_arbace_g2a_types_untyped_QMARK__A_clinit) } }

func A_arbace_g2a_types_untyped_QMARK__A_clinit() { A_arbace_g2a_types_untyped_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_130, lang.Compiler_AOTFn_class) }

func (t *A_arbace_g2a_types_untyped_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_types_untyped_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_g2a_types_untyped_QMARK__A_class }

func (t *A_arbace_g2a_types_untyped_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_types_untyped_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_types_untyped_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_types_untyped_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_types_untyped_QMARK__A); return ok }

func A_arbace_g2a_types_untyped_QMARK__A_Cast(x any) *A_arbace_g2a_types_untyped_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_types_untyped_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_types_untyped_QMARK__A_class)) }; return v }
