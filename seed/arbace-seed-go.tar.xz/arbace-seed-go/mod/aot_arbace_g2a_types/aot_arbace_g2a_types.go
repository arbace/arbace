//line aot_arbace_g2a_types.ae:1
package aot_arbace_g2a_types

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A_New() *A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A { A_arbace_g2a_types_A_Init(); t := &A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp3 = lang.IFn_Cast(A_arbace_g2a_types_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_types_A_const_1); return nil }(); lang.Var_PopThreadBindings__V(); if tmp4 != nil { panic(tmp4) }; return tmp3 }
//line :1:1
func A_arbace_g2a_types_eval1376000008_fn__1376000009_A_New() *A_arbace_g2a_types_eval1376000008_fn__1376000009_A { A_arbace_g2a_types_A_Init(); t := &A_arbace_g2a_types_eval1376000008_fn__1376000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_g2a_types_eval1376000008_fn__1376000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_g2a_types_eval1376000008_fn__1376000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_g2a_types_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_g2a_types_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_types_A_const_6), A_arbace_g2a_types_A_const_4.GetRawRoot__O(), A_arbace_g2a_types_A_const_5) }
























func A_arbace_g2a_types_entry_A_New() *A_arbace_g2a_types_entry_A { A_arbace_g2a_types_A_Init(); t := &A_arbace_g2a_types_entry_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_g2a_types_entry_A) Ctor() {}
//line :26:1
func (t *A_arbace_g2a_types_entry_A) Invoke_O_O__O(self, id__0 any) any { return lang.RT_Nth_O_I__O(A_arbace_g2a_types_A_const_7.Get__O(), lang.RT_IntCast_O__I(id__0)) }





func A_arbace_g2a_types_ns_name_of_A_New() *A_arbace_g2a_types_ns_name_of_A { A_arbace_g2a_types_A_Init(); t := &A_arbace_g2a_types_ns_name_of_A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_g2a_types_ns_name_of_A) Ctor() {}
//line :32:1
func (t *A_arbace_g2a_types_ns_name_of_A) Invoke_O_O__O(self, path__0 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_types_A_const_8.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_types_A_const_9.GetRawRoot__O()); var tmp3 any = A_arbace_g2a_types_A_const_10.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_types_A_const_11.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_types_A_const_12.GetRawRoot__O()); var tmp6 any = A_arbace_g2a_types_ns_name_of_fn__1376000014_A_New(); var tmp7 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_g2a_types_ns_name_of_fn__1376000014_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_3, false); A_arbace_g2a_types_ns_name_of_fn__1376000014_A_fn_class = fncls__1d; tmp7 = fncls__1d } else { tmp7 = fncls__1 }; var tmp8 *jrt.Class = A_arbace_g2a_types_A_const_13; return tmp1.Invoke_O__O(tmp2.Invoke_O_O_O__O(tmp3, Lit_1, tmp4.Invoke_O_O__O(Lit_2, tmp5.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(path__0, tmp8, Lit_4, jrt.RefArrayOf(jrt.Object_class, Lit_5)))))) }
//line :36:1
func A_arbace_g2a_types_ns_name_of_fn__1376000014_A_New() *A_arbace_g2a_types_ns_name_of_fn__1376000014_A { A_arbace_g2a_types_A_Init(); t := &A_arbace_g2a_types_ns_name_of_fn__1376000014_A{}; t.Ctor(); return t }
//line :36:1
func (t *A_arbace_g2a_types_ns_name_of_fn__1376000014_A) Ctor() {}
//line :36:1
func (t *A_arbace_g2a_types_ns_name_of_fn__1376000014_A) Invoke_O_O__O(self, p1__1376000013_SHARP___1 any) any { var tmp1 *jrt.Class = A_arbace_g2a_types_A_const_13; return lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(p1__1376000013_SHARP___1, tmp1, Lit_6, jrt.RefArrayOf(jrt.Object_class, Lit_7, Lit_8)) }


func A_arbace_g2a_types_qualify_A_New() *A_arbace_g2a_types_qualify_A { A_arbace_g2a_types_A_Init(); t := &A_arbace_g2a_types_qualify_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_g2a_types_qualify_A) Ctor() {}
//line :39:1
func (t *A_arbace_g2a_types_qualify_A) Invoke_O_O_O__O(self, path__0, name__1 any) any {


	var tmp1 bool; var or__1927000174__auto____3 bool = lang.Util_Identical_O_O__Z(path__0, nil)
	if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { tmp1 = lang.Util_Equiv_O_O__Z(path__0, A_arbace_g2a_types_A_const_14.Get__O()) }
//line :42:1
	if tmp1 {
		return lang.IFn_Cast(A_arbace_g2a_types_A_const_8.GetRawRoot__O()).Invoke_O__O(name__1) } else {
//line :42:1
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_types_A_const_15.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_types_A_const_17.Get__O(), path__0)) {

				return lang.IFn_Cast(A_arbace_g2a_types_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Get_O_O__O(A_arbace_g2a_types_A_const_17.Get__O(), path__0), name__1) } else {
//line :42:1
					if A_arbace_g2a_types_A_const_16 != nil {


						return lang.IFn_Cast(A_arbace_g2a_types_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_types_A_const_10.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_types_A_const_18.GetRawRoot__O()).Invoke_O__O(path__0)), name__1) } else {
//line :42:1
							return nil
						}
				}
		}
}


func A_arbace_g2a_types_params_vec_A_New() *A_arbace_g2a_types_params_vec_A { A_arbace_g2a_types_A_Init(); t := &A_arbace_g2a_types_params_vec_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_g2a_types_params_vec_A) Ctor() {}
//line :49:1
func (t *A_arbace_g2a_types_params_vec_A) Invoke_O_O_O__O(self, vars__0, variadic__1 any) any { var n__3 int32 = lang.RT_Count_O__I(vars__0); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_types_A_const_19.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_types_A_const_20.GetRawRoot__O()); var tmp3 any = A_arbace_g2a_types_params_vec_fn__1376000018_A_New_I_O(n__3, variadic__1); var tmp4 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_g2a_types_params_vec_fn__1376000018_A_fn_class; if

	fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_9, false); A_arbace_g2a_types_params_vec_fn__1376000018_A_fn_class = fncls__2d; tmp4 = fncls__2d } else { tmp4 = fncls__2 }; return tmp1.Invoke_O__O(tmp2.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), lang.IFn_Cast(A_arbace_g2a_types_A_const_24.GetRawRoot__O()).Invoke__O(), vars__0)) }
//line :51:1
func A_arbace_g2a_types_params_vec_fn__1376000018_A_New_I_O(p0 int32, p1 any) *A_arbace_g2a_types_params_vec_fn__1376000018_A { A_arbace_g2a_types_A_Init(); t := &A_arbace_g2a_types_params_vec_fn__1376000018_A{}; t.Ctor_I_O(p0, p1); return t }
//line :51:1
func (t *A_arbace_g2a_types_params_vec_fn__1376000018_A) Ctor_I_O(c__n int32, c__variadic any) { t.F_n = c__n; t.F_variadic = c__variadic }
//line :51:1
func (t *A_arbace_g2a_types_params_vec_fn__1376000018_A) Invoke_O_O_O__O(self, i__1, v__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 any = t.F_variadic; if jrt.A2g_Truth(and__1927000168__auto____3) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_J__Z(i__1, lang.Numbers_Dec_J__J(int64(t.F_n)))).Ref() } else { tmp1 = and__1927000168__auto____3 }; if jrt.A2g_Truth(tmp1) { var tmp2 any = A_arbace_g2a_types_A_const_21; return lang.Tuple_Create_O_O__IPersistentVector(tmp2, lang.IFn_Cast(A_arbace_g2a_types_A_const_22.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_types_A_const_23.Invoke_O__O(v__2))) } else { return lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_g2a_types_A_const_22.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_types_A_const_23.Invoke_O__O(v__2)))
	}
}


func A_arbace_g2a_types_method_elem_A_New() *A_arbace_g2a_types_method_elem_A { A_arbace_g2a_types_A_Init(); t := &A_arbace_g2a_types_method_elem_A{}; t.Ctor(); return t }
//line :57:1
func (t *A_arbace_g2a_types_method_elem_A) Ctor() {}
//line :57:1
func (t *A_arbace_g2a_types_method_elem_A) Invoke_O_O__O(self, p__1376000021__0 any) any { var map__1376000022__2 any = p__1376000021__0; var map__1376000022__3 any; if lang.ISeq_InstanceOf(map__1376000022__2) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_types_A_const_25.GetRawRoot__O()).Invoke_O__O(map__1376000022__2)) { map__1376000022__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_g2a_types_A_const_26.GetRawRoot__O()).Invoke_O__O(map__1376000022__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_types_A_const_27.GetRawRoot__O()).Invoke_O__O(map__1376000022__2)) { map__1376000022__3 = lang.IFn_Cast(A_arbace_g2a_types_A_const_28.GetRawRoot__O()).Invoke_O__O(map__1376000022__2) } else { lang.PersistentArrayMap_Init(); map__1376000022__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1376000022__3 = map__1376000022__2 }; var name__4 any = lang.RT_Get_O_O__O(map__1376000022__3, A_arbace_g2a_types_A_const_29); var t__5 any = lang.RT_Get_O_O__O(map__1376000022__3, A_arbace_g2a_types_A_const_23); var sig__6 any = lang.IFn_Cast(A_arbace_g2a_types_A_const_30.GetRawRoot__O()).Invoke_O__O(t__5); var ps__7 any = lang.IFn_Cast(A_arbace_g2a_types_A_const_31.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_types_A_const_35.Invoke_O__O(sig__6), A_arbace_g2a_types_A_const_36.Invoke_O__O(sig__6)); var rs__8 any = A_arbace_g2a_types_A_const_32.Invoke_O__O(sig__6); if



	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_types_A_const_33.GetRawRoot__O()).Invoke_O__O(rs__8)) {
		return lang.IFn_Cast(A_arbace_g2a_types_A_const_34.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_types_A_const_8.GetRawRoot__O()).Invoke_O__O(name__4), ps__7) } else {
//line :61:1
			if lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(rs__8))) {

				var tmp1 any = A_arbace_g2a_types_A_const_38; var tmp2 *lang.Keyword = A_arbace_g2a_types_A_const_23; return lang.IFn_Cast(A_arbace_g2a_types_A_const_34.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_types_A_const_8.GetRawRoot__O()).Invoke_O__O(name__4), lang.IFn_Cast(A_arbace_g2a_types_A_const_37.GetRawRoot__O()).Invoke_O_O__O(ps__7, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, lang.IFn_Cast(A_arbace_g2a_types_A_const_22.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_types_A_const_28.GetRawRoot__O()).Invoke_O__O(rs__8))))))) } else {
//line :61:1
					if A_arbace_g2a_types_A_const_16 != nil {


						var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_types_A_const_34.GetRawRoot__O()); var tmp4 any = lang.IFn_Cast(A_arbace_g2a_types_A_const_8.GetRawRoot__O()).Invoke_O__O(name__4); var tmp5 any = A_arbace_g2a_types_A_const_32; return tmp3.Invoke_O_O_O_O__O(tmp4, ps__7, tmp5, lang.IFn_Cast(A_arbace_g2a_types_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_types_A_const_40.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_types_A_const_22.GetRawRoot__O(), A_arbace_g2a_types_A_const_23), rs__8)) } else {
//line :61:1
							return nil } } } }




func A_arbace_g2a_types_type_form_A_New() *A_arbace_g2a_types_type_form_A { A_arbace_g2a_types_A_Init(); t := &A_arbace_g2a_types_type_form_A{}; t.Ctor(); return t }
//line :66:1
func (t *A_arbace_g2a_types_type_form_A) Ctor() {}
//line :66:1
func (t *A_arbace_g2a_types_type_form_A) Invoke_O_O__O(self, id__0 any) any { var e__2 any = lang.IFn_Cast(A_arbace_g2a_types_A_const_30.GetRawRoot__O()).Invoke_O__O(id__0); var G__1376000025__3_ any = A_arbace_g2a_types_A_const_41.Invoke_O__O(e__2); switch



	lang.Util_Hash_O__I(G__1376000025__3_) >> 14 & 31 { case 0: if any(G__1376000025__3_) == any(A_arbace_g2a_types_A_const_42) {




		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_types_A_const_34.GetRawRoot__O()); var tmp2 any = A_arbace_g2a_types_A_const_51; return tmp1.Invoke_O_O_O__O(tmp2, lang.IFn_Cast(A_arbace_g2a_types_A_const_22.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_types_A_const_52.Invoke_O__O(e__2)), lang.IFn_Cast(A_arbace_g2a_types_A_const_22.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_types_A_const_53.Invoke_O__O(e__2))) }
//line :70:1
	case 3: if any(G__1376000025__3_) == any(A_arbace_g2a_types_A_const_43) { var G__1376000026__4_ any = A_arbace_g2a_types_A_const_44.Invoke_O__O(e__2)





		switch lang.Util_Hash_O__I(G__1376000026__4_) >> 7 & 3 { case 0: if any(G__1376000026__4_) == any(A_arbace_g2a_types_A_const_45) {


			var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_g2a_types_A_const_34.GetRawRoot__O()); var tmp4 any = A_arbace_g2a_types_A_const_54; var tmp5 any = A_arbace_g2a_types_A_const_45; return tmp3.Invoke_O_O_O__O(tmp4, tmp5, lang.IFn_Cast(A_arbace_g2a_types_A_const_22.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_types_A_const_53.Invoke_O__O(e__2))) }
//line :76:1
		case 2: if any(G__1376000026__4_) == any(A_arbace_g2a_types_A_const_46) {
			var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_types_A_const_34.GetRawRoot__O()); var tmp7 any = A_arbace_g2a_types_A_const_55; return tmp6.Invoke_O_O__O(tmp7, lang.IFn_Cast(A_arbace_g2a_types_A_const_22.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_types_A_const_53.Invoke_O__O(e__2))) }
//line :76:1
		case 3: if any(G__1376000026__4_) == any(A_arbace_g2a_types_A_const_47) {

			var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_types_A_const_34.GetRawRoot__O()); var tmp9 any = A_arbace_g2a_types_A_const_56; var tmp10 any = A_arbace_g2a_types_A_const_47; return tmp8.Invoke_O_O_O__O(tmp9, tmp10, lang.IFn_Cast(A_arbace_g2a_types_A_const_22.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_types_A_const_53.Invoke_O__O(e__2))) }
//line :76:1
		default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1376000026__4_))))) }
//line :70:1
	case 5: if any(G__1376000025__3_) == any(A_arbace_g2a_types_A_const_48) {

		var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_g2a_types_A_const_34.GetRawRoot__O()); var tmp12 any = A_arbace_g2a_types_A_const_57; return tmp11.Invoke_O_O__O(tmp12, lang.IFn_Cast(A_arbace_g2a_types_A_const_22.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_types_A_const_53.Invoke_O__O(e__2))) }
//line :70:1
	case 6: if any(G__1376000025__3_) == any(A_arbace_g2a_types_A_const_49) {
























		var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_g2a_types_A_const_9.GetRawRoot__O()); var tmp14 any = A_arbace_g2a_types_A_const_34.GetRawRoot__O(); var tmp15 any = A_arbace_g2a_types_A_const_59; var tmp16 any; var iter__1927001039__auto____4 any; var tmp17 any = A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_New(); var tmp18 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_fn_class
		if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_11, false); A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_fn_class = fncls__7d; tmp18 = fncls__7d } else { tmp18 = fncls__7 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); tmp16 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(A_arbace_g2a_types_A_const_71.Invoke_O__O(e__2))
//line :95:1
		return tmp13.Invoke_O_O_O__O(tmp14, tmp15, tmp16) }
//line :70:1
	case 7: if any(G__1376000025__3_) == any(A_arbace_g2a_types_A_const_58) {













		var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_g2a_types_A_const_9.GetRawRoot__O()); var tmp20 any = A_arbace_g2a_types_A_const_34.GetRawRoot__O(); var tmp21 any = A_arbace_g2a_types_A_const_73; var tmp22 any; var iter__1927001039__auto____4_2 any; var tmp23 any = A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_New(); var tmp24 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_fn_class
		if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_12, false); A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_fn_class = fncls__10d; tmp24 = fncls__10d } else { tmp24 = fncls__10 }; iter__1927001039__auto____4_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil); tmp22 = lang.IFn_Cast(iter__1927001039__auto____4_2).Invoke_O__O(A_arbace_g2a_types_A_const_78.Invoke_O__O(e__2))
//line :84:1
		return tmp19.Invoke_O_O_O__O(tmp20, tmp21, tmp22) }
//line :70:1
	case 8: if any(G__1376000025__3_) == any(A_arbace_g2a_types_A_const_72) {


































		return lang.IFn_Cast(A_arbace_g2a_types_A_const_8.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_types_A_const_29.Invoke_O__O(e__2)) }
//line :70:1
	case 11: if any(G__1376000025__3_) == any(A_arbace_g2a_types_A_const_79) {



		var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_g2a_types_A_const_34.GetRawRoot__O()); var tmp26 any = A_arbace_g2a_types_A_const_83; return tmp25.Invoke_O_O_O__O(tmp26, A_arbace_g2a_types_A_const_84.Invoke_O__O(e__2), lang.IFn_Cast(A_arbace_g2a_types_A_const_22.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_types_A_const_53.Invoke_O__O(e__2))) }
//line :70:1
	case 13: if any(G__1376000025__3_) == any(A_arbace_g2a_types_A_const_80) {
		if jrt.A2g_Truth(A_arbace_g2a_types_A_const_81.Invoke_O__O(e__2)) { return lang.IFn_Cast(A_arbace_g2a_types_A_const_82.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_types_A_const_81.Invoke_O__O(e__2), A_arbace_g2a_types_A_const_29.Invoke_O__O(e__2)) } else { return lang.IFn_Cast(A_arbace_g2a_types_A_const_8.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_types_A_const_29.Invoke_O__O(e__2)) } }
//line :70:1
	case 14: if any(G__1376000025__3_) == any(A_arbace_g2a_types_A_const_85) { var ps__4 any = lang.IFn_Cast(A_arbace_g2a_types_A_const_31.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_types_A_const_35.Invoke_O__O(e__2), A_arbace_g2a_types_A_const_36.Invoke_O__O(e__2))










		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_types_A_const_27.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_types_A_const_32.Invoke_O__O(e__2))) {
			var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_g2a_types_A_const_34.GetRawRoot__O()); var tmp28 any = A_arbace_g2a_types_A_const_87; return tmp27.Invoke_O_O_O__O(tmp28, ps__4, lang.IFn_Cast(A_arbace_g2a_types_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_types_A_const_40.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_types_A_const_22.GetRawRoot__O(), A_arbace_g2a_types_A_const_23), A_arbace_g2a_types_A_const_32.Invoke_O__O(e__2))) } else {
				return lang.IFn_Cast(A_arbace_g2a_types_A_const_34.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_types_A_const_88, ps__4) } }
//line :70:1
	case 19: if any(G__1376000025__3_) == any(A_arbace_g2a_types_A_const_86) {





















		var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_g2a_types_A_const_9.GetRawRoot__O()); var tmp30 any = A_arbace_g2a_types_A_const_34.GetRawRoot__O(); var tmp31 any = A_arbace_g2a_types_A_const_90; return tmp29.Invoke_O_O_O__O(tmp30, tmp31, lang.IFn_Cast(A_arbace_g2a_types_A_const_91.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_types_A_const_12.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_types_A_const_92.GetRawRoot__O(), A_arbace_g2a_types_A_const_93.Invoke_O__O(e__2)), lang.IFn_Cast(A_arbace_g2a_types_A_const_12.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_types_A_const_22.GetRawRoot__O(), A_arbace_g2a_types_A_const_94.Invoke_O__O(e__2)))) }
//line :70:1
	case 23: if any(G__1376000025__3_) == any(A_arbace_g2a_types_A_const_89) {



































		var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_g2a_types_A_const_9.GetRawRoot__O()); var tmp33 any = A_arbace_g2a_types_A_const_34.GetRawRoot__O(); var tmp34 any = A_arbace_g2a_types_A_const_99; return tmp32.Invoke_O_O_O__O(tmp33, tmp34, lang.IFn_Cast(A_arbace_g2a_types_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_types_A_const_40.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_types_A_const_22.GetRawRoot__O(), A_arbace_g2a_types_A_const_23), A_arbace_g2a_types_A_const_100.Invoke_O__O(e__2))) }
//line :70:1
	case 25: if any(G__1376000025__3_) == any(A_arbace_g2a_types_A_const_95) { var base__4 any = lang.IFn_Cast(A_arbace_g2a_types_A_const_82.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_types_A_const_81.Invoke_O__O(e__2), A_arbace_g2a_types_A_const_29.Invoke_O__O(e__2))





























		if jrt.A2g_Truth(A_arbace_g2a_types_A_const_96.Invoke_O__O(e__2)) {
			var tmp35 any; var and__1927000168__auto____5 bool = lang.Util_Identical_O_O__Z(lang.IFn_Cast(A_arbace_g2a_types_A_const_97.GetRawRoot__O()).Invoke_O__O(base__4), nil); if and__1927000168__auto____5 { tmp35 = lang.IFn_Cast(A_arbace_g2a_types_A_const_98.GetRawRoot__O()).Invoke_O__O(base__4) } else { tmp35 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() }; if jrt.A2g_Truth(tmp35) {
				var tmp36 lang.IFn = lang.IFn_Cast(A_arbace_g2a_types_A_const_9.GetRawRoot__O()); var tmp37 any = A_arbace_g2a_types_A_const_34.GetRawRoot__O(); var tmp38 any = A_arbace_g2a_types_A_const_102; return tmp36.Invoke_O_O_O_O__O(tmp37, tmp38, base__4, lang.IFn_Cast(A_arbace_g2a_types_A_const_12.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_types_A_const_22.GetRawRoot__O(), A_arbace_g2a_types_A_const_103.Invoke_O__O(e__2))) } else {
					return lang.IFn_Cast(A_arbace_g2a_types_A_const_9.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_g2a_types_A_const_34.GetRawRoot__O(), base__4, lang.IFn_Cast(A_arbace_g2a_types_A_const_12.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_types_A_const_22.GetRawRoot__O(), A_arbace_g2a_types_A_const_103.Invoke_O__O(e__2))) } } else {
//line :100:1
						return base__4 } }
//line :70:1
	case 28: if any(G__1376000025__3_) == any(A_arbace_g2a_types_A_const_101) {


		var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_g2a_types_A_const_34.GetRawRoot__O()); var tmp40 any = A_arbace_g2a_types_A_const_105; return tmp39.Invoke_O_O__O(tmp40, lang.IFn_Cast(A_arbace_g2a_types_A_const_22.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_types_A_const_53.Invoke_O__O(e__2))) }
//line :70:1
	case 29: if any(G__1376000025__3_) == any(A_arbace_g2a_types_A_const_104) { var base__4_2 any = lang.IFn_Cast(A_arbace_g2a_types_A_const_82.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_types_A_const_81.Invoke_O__O(e__2), A_arbace_g2a_types_A_const_29.Invoke_O__O(e__2))





























		if jrt.A2g_Truth(A_arbace_g2a_types_A_const_96.Invoke_O__O(e__2)) {
			var tmp41 any; var and__1927000168__auto____5_2 bool = lang.Util_Identical_O_O__Z(lang.IFn_Cast(A_arbace_g2a_types_A_const_97.GetRawRoot__O()).Invoke_O__O(base__4_2), nil); if and__1927000168__auto____5_2 { tmp41 = lang.IFn_Cast(A_arbace_g2a_types_A_const_98.GetRawRoot__O()).Invoke_O__O(base__4_2) } else { tmp41 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5_2).Ref() }; if jrt.A2g_Truth(tmp41) {
				var tmp42 lang.IFn = lang.IFn_Cast(A_arbace_g2a_types_A_const_9.GetRawRoot__O()); var tmp43 any = A_arbace_g2a_types_A_const_34.GetRawRoot__O(); var tmp44 any = A_arbace_g2a_types_A_const_102; return tmp42.Invoke_O_O_O_O__O(tmp43, tmp44, base__4_2, lang.IFn_Cast(A_arbace_g2a_types_A_const_12.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_types_A_const_22.GetRawRoot__O(), A_arbace_g2a_types_A_const_103.Invoke_O__O(e__2))) } else {
					return lang.IFn_Cast(A_arbace_g2a_types_A_const_9.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_g2a_types_A_const_34.GetRawRoot__O(), base__4_2, lang.IFn_Cast(A_arbace_g2a_types_A_const_12.GetRawRoot__O()).Invoke_O_O__O(A_arbace_g2a_types_A_const_22.GetRawRoot__O(), A_arbace_g2a_types_A_const_103.Invoke_O__O(e__2))) } } else {
//line :100:1
						return base__4_2 } }
//line :70:1
	default:}; panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_g2a_types_A_const_50.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_13, nil, Lit_14, nil), jrt.RefArrayOf(jrt.Object_class, nil, id__0, nil, lang.IFn_Cast(A_arbace_g2a_types_A_const_106.GetRawRoot__O()).Invoke_O__O(e__2))).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_g2a_types_A_const_107, id__0)))))) }














func A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_New() *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A { A_arbace_g2a_types_A_Init(); t := &A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A) Ctor() {}
//line :85:1
func (t *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A) Invoke_O_O__O(self, s__1376000038__1 any) any { var tmp1 any = A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_New_O_O(s__1376000038__1, self); var tmp2 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_17, false); A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_fn_class = fncls__9d; tmp2 = fncls__9d } else { tmp2 = fncls__9 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :85:1
func A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_New_O_O(p0, p1 any) *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A { A_arbace_g2a_types_A_Init(); t := &A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A{}; t.Ctor_O_O(p0, p1); return t }
//line :85:1
func (t *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A) Ctor_O_O(c__s__1376000038, c__iter__1376000037 any) { t.F_s__1376000038 = c__s__1376000038; t.F_iter__1376000037 = c__iter__1376000037 }
//line :85:1
func (t *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A) Invoke_O__O(self any) any { { var s__1376000038__1 any; var t_ any = t.F_s__1376000038; t.F_s__1376000038 = nil; s__1376000038__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_types_A_const_27.GetRawRoot__O()).Invoke_O__O(s__1376000038__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1376000038__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_types_A_const_60.GetRawRoot__O()).Invoke_O__O(s__1376000038__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_g2a_types_A_const_61.GetRawRoot__O()).Invoke_O__O(s__1376000038__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1376000040__6 any = lang.IFn_Cast(A_arbace_g2a_types_A_const_62.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_New_O_I_O(b__1376000040__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_18, false); A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_fn_class = fncls__8d; tmp2 = fncls__8d } else { tmp2 = fncls__8 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1376000037); return lang.IFn_Cast(A_arbace_g2a_types_A_const_66.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_types_A_const_68.GetRawRoot__O()).Invoke_O__O(b__1376000040__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_types_A_const_69.GetRawRoot__O()).Invoke_O__O(s__1376000038__3))) } else { return lang.IFn_Cast(A_arbace_g2a_types_A_const_66.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_types_A_const_68.GetRawRoot__O()).Invoke_O__O(b__1376000040__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_g2a_types_A_const_28.GetRawRoot__O()).Invoke_O__O(s__1376000038__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_types_A_const_67.GetRawRoot__O()); var tmp5 any
														if jrt.A2g_Truth(A_arbace_g2a_types_A_const_74.Invoke_O__O(f__4)) { var t__5 any = lang.IFn_Cast(A_arbace_g2a_types_A_const_22.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_types_A_const_23.Invoke_O__O(f__4))

		if jrt.A2g_Truth(A_arbace_g2a_types_A_const_38.Invoke_O__O(f__4)) { var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_types_A_const_75.GetRawRoot__O()); var tmp7 any = A_arbace_g2a_types_A_const_76.GetRawRoot__O(); var tmp8 any = A_arbace_g2a_types_A_const_77; tmp5 = tmp6.Invoke_O_O_O_O__O(t__5, tmp7, tmp8, A_arbace_g2a_types_A_const_38.Invoke_O__O(f__4)) } else { tmp5 = t__5 } } else {
			var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_g2a_types_A_const_37.GetRawRoot__O()); var tmp10 any = lang.IFn_Cast(A_arbace_g2a_types_A_const_8.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_types_A_const_29.Invoke_O__O(f__4)); var tmp11 any; var tmp12 any = A_arbace_g2a_types_A_const_38; var G__1376000046__5_ any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp12, lang.IFn_Cast(A_arbace_g2a_types_A_const_22.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_types_A_const_23.Invoke_O__O(f__4))))
			if jrt.A2g_Truth(A_arbace_g2a_types_A_const_38.Invoke_O__O(f__4)) {
				var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_g2a_types_A_const_76.GetRawRoot__O()); var tmp14 any = A_arbace_g2a_types_A_const_77; tmp11 = tmp13.Invoke_O_O_O__O(G__1376000046__5_, tmp14, A_arbace_g2a_types_A_const_38.Invoke_O__O(f__4)) } else {
//line :90:1
					tmp11 = G__1376000046__5_ }
//line :89:1
			tmp5 = tmp9.Invoke_O_O__O(tmp10, tmp11) }
//line :85:1
	var tmp15 lang.IFn = lang.IFn_Cast(t.F_iter__1376000037); return tmp4.Invoke_O_O__O(tmp5, tmp15.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_types_A_const_70.GetRawRoot__O()).Invoke_O__O(s__1376000038__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :85:1
func A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A { A_arbace_g2a_types_A_Init(); t := &A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :85:1
func (t *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A) Ctor_O_I_O(c__b__1376000040 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1376000040 = c__b__1376000040; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :85:1
func (t *A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A) Invoke_O__O(self any) any { { var i__1376000039__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1376000039__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1376000039__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_types_A_const_63.GetRawRoot__O()); var tmp3 any = t.F_b__1376000040; var tmp4 any
																if jrt.A2g_Truth(A_arbace_g2a_types_A_const_74.Invoke_O__O(f__2)) { var t__3 any = lang.IFn_Cast(A_arbace_g2a_types_A_const_22.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_types_A_const_23.Invoke_O__O(f__2))

		if jrt.A2g_Truth(A_arbace_g2a_types_A_const_38.Invoke_O__O(f__2)) { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_types_A_const_75.GetRawRoot__O()); var tmp6 any = A_arbace_g2a_types_A_const_76.GetRawRoot__O(); var tmp7 any = A_arbace_g2a_types_A_const_77; tmp4 = tmp5.Invoke_O_O_O_O__O(t__3, tmp6, tmp7, A_arbace_g2a_types_A_const_38.Invoke_O__O(f__2)) } else { tmp4 = t__3 } } else {
			var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_g2a_types_A_const_37.GetRawRoot__O()); var tmp9 any = lang.IFn_Cast(A_arbace_g2a_types_A_const_8.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_types_A_const_29.Invoke_O__O(f__2)); var tmp10 any; var tmp11 any = A_arbace_g2a_types_A_const_38; var G__1376000044__3_ any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp11, lang.IFn_Cast(A_arbace_g2a_types_A_const_22.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_types_A_const_23.Invoke_O__O(f__2))))
			if jrt.A2g_Truth(A_arbace_g2a_types_A_const_38.Invoke_O__O(f__2)) {
				var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_g2a_types_A_const_76.GetRawRoot__O()); var tmp13 any = A_arbace_g2a_types_A_const_77; tmp10 = tmp12.Invoke_O_O_O__O(G__1376000044__3_, tmp13, A_arbace_g2a_types_A_const_38.Invoke_O__O(f__2)) } else {
//line :90:1
					tmp10 = G__1376000044__3_ }
//line :89:1
			tmp4 = tmp8.Invoke_O_O__O(tmp9, tmp10) }
//line :85:1
	tmp2.Invoke_O_O__O(tmp3, tmp4); i__1376000039__1 = lang.Numbers_Unchecked_inc_J__J(i__1376000039__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }










func A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_New() *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A { A_arbace_g2a_types_A_Init(); t := &A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A{}; t.Ctor(); return t }
//line :96:1
func (t *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A) Ctor() {}
//line :96:1
func (t *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A) Invoke_O_O__O(self, s__1376000028__1 any) any { var tmp1 any = A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_New_O_O(s__1376000028__1, self); var tmp2 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_15, false); A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_fn_class = fncls__6d; tmp2 = fncls__6d } else { tmp2 = fncls__6 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :96:1
func A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_New_O_O(p0, p1 any) *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A { A_arbace_g2a_types_A_Init(); t := &A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A{}; t.Ctor_O_O(p0, p1); return t }
//line :96:1
func (t *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A) Ctor_O_O(c__s__1376000028, c__iter__1376000027 any) { t.F_s__1376000028 = c__s__1376000028; t.F_iter__1376000027 = c__iter__1376000027 }
//line :96:1
func (t *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A) Invoke_O__O(self any) any { { var s__1376000028__1 any; var t_ any = t.F_s__1376000028; t.F_s__1376000028 = nil; s__1376000028__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_g2a_types_A_const_27.GetRawRoot__O()).Invoke_O__O(s__1376000028__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1376000028__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_g2a_types_A_const_60.GetRawRoot__O()).Invoke_O__O(s__1376000028__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_g2a_types_A_const_61.GetRawRoot__O()).Invoke_O__O(s__1376000028__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1376000030__6 any = lang.IFn_Cast(A_arbace_g2a_types_A_const_62.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_New_O_I_O(b__1376000030__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_16, false); A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_fn_class = fncls__5d; tmp2 = fncls__5d } else { tmp2 = fncls__5 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1376000027); return lang.IFn_Cast(A_arbace_g2a_types_A_const_66.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_types_A_const_68.GetRawRoot__O()).Invoke_O__O(b__1376000030__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_types_A_const_69.GetRawRoot__O()).Invoke_O__O(s__1376000028__3))) } else { return lang.IFn_Cast(A_arbace_g2a_types_A_const_66.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_g2a_types_A_const_68.GetRawRoot__O()).Invoke_O__O(b__1376000030__6), nil) } } else { var t__4 any = lang.IFn_Cast(A_arbace_g2a_types_A_const_28.GetRawRoot__O()).Invoke_O__O(s__1376000028__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_g2a_types_A_const_67.GetRawRoot__O()); var tmp5 any
														if jrt.A2g_Truth(A_arbace_g2a_types_A_const_64.Invoke_O__O(t__4)) { var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_g2a_types_A_const_34.GetRawRoot__O()); var tmp7 any = A_arbace_g2a_types_A_const_65; tmp5 = tmp6.Invoke_O_O__O(tmp7, lang.IFn_Cast(A_arbace_g2a_types_A_const_22.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_types_A_const_23.Invoke_O__O(t__4))) } else { tmp5 = lang.IFn_Cast(A_arbace_g2a_types_A_const_22.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_types_A_const_23.Invoke_O__O(t__4)) }
//line :96:1
	var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1376000027); return tmp4.Invoke_O_O__O(tmp5, tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_g2a_types_A_const_70.GetRawRoot__O()).Invoke_O__O(s__1376000028__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :96:1
func A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A { A_arbace_g2a_types_A_Init(); t := &A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :96:1
func (t *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A) Ctor_O_I_O(c__b__1376000030 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1376000030 = c__b__1376000030; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :96:1
func (t *A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A) Invoke_O__O(self any) any { { var i__1376000029__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1376000029__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var t__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1376000029__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_g2a_types_A_const_63.GetRawRoot__O()); var tmp3 any = t.F_b__1376000030; var tmp4 any
																if jrt.A2g_Truth(A_arbace_g2a_types_A_const_64.Invoke_O__O(t__2)) { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_g2a_types_A_const_34.GetRawRoot__O()); var tmp6 any = A_arbace_g2a_types_A_const_65; tmp4 = tmp5.Invoke_O_O__O(tmp6, lang.IFn_Cast(A_arbace_g2a_types_A_const_22.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_types_A_const_23.Invoke_O__O(t__2))) } else { tmp4 = lang.IFn_Cast(A_arbace_g2a_types_A_const_22.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_types_A_const_23.Invoke_O__O(t__2)) }
//line :96:1
	tmp2.Invoke_O_O__O(tmp3, tmp4); i__1376000029__1 = lang.Numbers_Unchecked_inc_J__J(i__1376000029__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }












func A_arbace_g2a_types_untyped_QMARK__A_New() *A_arbace_g2a_types_untyped_QMARK__A { A_arbace_g2a_types_A_Init(); t := &A_arbace_g2a_types_untyped_QMARK__A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_g2a_types_untyped_QMARK__A) Ctor() {}
//line :109:1
func (t *A_arbace_g2a_types_untyped_QMARK__A) Invoke_O_O__O(self, id__0 any) any { var e__2 any = lang.IFn_Cast(A_arbace_g2a_types_A_const_30.GetRawRoot__O()).Invoke_O__O(id__0); var tmp1 any = A_arbace_g2a_types_A_const_80; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z(tmp1, A_arbace_g2a_types_A_const_41.Invoke_O__O(e__2)); if and__1927000168__auto____3 {



	return jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.String_Cast(A_arbace_g2a_types_A_const_29.Invoke_O__O(e__2))).StartsWith_String__Z(Lit_19)).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() } }








func A_arbace_g2a_types_const_kind_A_New() *A_arbace_g2a_types_const_kind_A { A_arbace_g2a_types_A_Init(); t := &A_arbace_g2a_types_const_kind_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_g2a_types_const_kind_A) Ctor() {}
//line :122:1
func (t *A_arbace_g2a_types_const_kind_A) Invoke_O_O__O(self, id__0 any) any { var e__2 any = lang.IFn_Cast(A_arbace_g2a_types_A_const_30.GetRawRoot__O()).Invoke_O__O(id__0); var G__1376000051__3_ any = A_arbace_g2a_types_A_const_41.Invoke_O__O(e__2); switch




	lang.Util_Hash_O__I(G__1376000051__3_) >> 4 & 3 { case 1: if any(G__1376000051__3_) == any(A_arbace_g2a_types_A_const_95) {




		return lang.IFn_Cast(A_arbace_g2a_types_A_const_108.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_types_A_const_113.Invoke_O__O(e__2)) }
//line :127:1
	case 2: if any(G__1376000051__3_) == any(A_arbace_g2a_types_A_const_80) { var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_g2a_types_A_const_109.GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_types_A_const_29.Invoke_O__O(e__2))
		if jrt.A2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else {
			var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_g2a_types_A_const_110); if jrt.A2g_Truth(tmp1.Invoke_O__O(A_arbace_g2a_types_A_const_29.Invoke_O__O(e__2))) { return A_arbace_g2a_types_A_const_111 } else { return nil } } }
//line :127:1
	case 3: if any(G__1376000051__3_) == any(A_arbace_g2a_types_A_const_104) { var temp__1927000414__auto____4 any = lang.RT_Get_O_O__O(A_arbace_g2a_types_A_const_112.Get__O(), id__0)





		if jrt.A2g_Truth(temp__1927000414__auto____4) { var u__5 any = temp__1927000414__auto____4; return lang.IFn_Cast(A_arbace_g2a_types_A_const_108.GetRawRoot__O()).Invoke_O__O(u__5) } else { return nil } }
//line :127:1
	default:}; return nil }







type A_arbace_g2a_types_A struct{ jrt.Object }

var A_arbace_g2a_types_A_const_pool *jrt.RefArray

var A_arbace_g2a_types_A_const_0 *lang.Var

var A_arbace_g2a_types_A_const_1 any

var A_arbace_g2a_types_A_const_2 *lang.Var

var A_arbace_g2a_types_A_const_3 *lang.Var

var A_arbace_g2a_types_A_const_4 *lang.Var

var A_arbace_g2a_types_A_const_5 any

var A_arbace_g2a_types_A_const_6 *lang.Var

var A_arbace_g2a_types_A_const_7 *lang.Var

var A_arbace_g2a_types_A_const_8 *lang.Var

var A_arbace_g2a_types_A_const_9 *lang.Var

var A_arbace_g2a_types_A_const_10 *lang.Var

var A_arbace_g2a_types_A_const_11 *lang.Var

var A_arbace_g2a_types_A_const_12 *lang.Var

var A_arbace_g2a_types_A_const_13 *jrt.Class

var A_arbace_g2a_types_A_const_14 *lang.Var

var A_arbace_g2a_types_A_const_15 *lang.Var

var A_arbace_g2a_types_A_const_16 *lang.Keyword

var A_arbace_g2a_types_A_const_17 *lang.Var

var A_arbace_g2a_types_A_const_18 *lang.Var

var A_arbace_g2a_types_A_const_19 *lang.Var

var A_arbace_g2a_types_A_const_20 *lang.Var

var A_arbace_g2a_types_A_const_21 any

var A_arbace_g2a_types_A_const_22 *lang.Var

var A_arbace_g2a_types_A_const_23 *lang.Keyword

var A_arbace_g2a_types_A_const_24 *lang.Var

var A_arbace_g2a_types_A_const_25 *lang.Var

var A_arbace_g2a_types_A_const_26 *lang.Var

var A_arbace_g2a_types_A_const_27 *lang.Var

var A_arbace_g2a_types_A_const_28 *lang.Var

var A_arbace_g2a_types_A_const_29 *lang.Keyword

var A_arbace_g2a_types_A_const_30 *lang.Var

var A_arbace_g2a_types_A_const_31 *lang.Var

var A_arbace_g2a_types_A_const_32 *lang.Keyword

var A_arbace_g2a_types_A_const_33 *lang.Var

var A_arbace_g2a_types_A_const_34 *lang.Var

var A_arbace_g2a_types_A_const_35 *lang.Keyword

var A_arbace_g2a_types_A_const_36 *lang.Keyword

var A_arbace_g2a_types_A_const_37 *lang.Var

var A_arbace_g2a_types_A_const_38 *lang.Keyword

var A_arbace_g2a_types_A_const_39 *lang.Var

var A_arbace_g2a_types_A_const_40 *lang.Var

var A_arbace_g2a_types_A_const_41 *lang.Keyword

var A_arbace_g2a_types_A_const_42 *lang.Keyword

var A_arbace_g2a_types_A_const_43 *lang.Keyword

var A_arbace_g2a_types_A_const_44 *lang.Keyword

var A_arbace_g2a_types_A_const_45 *lang.Keyword

var A_arbace_g2a_types_A_const_46 *lang.Keyword

var A_arbace_g2a_types_A_const_47 *lang.Keyword

var A_arbace_g2a_types_A_const_48 *lang.Keyword

var A_arbace_g2a_types_A_const_49 *lang.Keyword

var A_arbace_g2a_types_A_const_50 *lang.Var

var A_arbace_g2a_types_A_const_51 any

var A_arbace_g2a_types_A_const_52 *lang.Keyword

var A_arbace_g2a_types_A_const_53 *lang.Keyword

var A_arbace_g2a_types_A_const_54 any

var A_arbace_g2a_types_A_const_55 any

var A_arbace_g2a_types_A_const_56 any

var A_arbace_g2a_types_A_const_57 any

var A_arbace_g2a_types_A_const_58 *lang.Keyword

var A_arbace_g2a_types_A_const_59 any

var A_arbace_g2a_types_A_const_60 *lang.Var

var A_arbace_g2a_types_A_const_61 *lang.Var

var A_arbace_g2a_types_A_const_62 *lang.Var

var A_arbace_g2a_types_A_const_63 *lang.Var

var A_arbace_g2a_types_A_const_64 *lang.Keyword

var A_arbace_g2a_types_A_const_65 any

var A_arbace_g2a_types_A_const_66 *lang.Var

var A_arbace_g2a_types_A_const_67 *lang.Var

var A_arbace_g2a_types_A_const_68 *lang.Var

var A_arbace_g2a_types_A_const_69 *lang.Var

var A_arbace_g2a_types_A_const_70 *lang.Var

var A_arbace_g2a_types_A_const_71 *lang.Keyword

var A_arbace_g2a_types_A_const_72 *lang.Keyword

var A_arbace_g2a_types_A_const_73 any

var A_arbace_g2a_types_A_const_74 *lang.Keyword

var A_arbace_g2a_types_A_const_75 *lang.Var

var A_arbace_g2a_types_A_const_76 *lang.Var

var A_arbace_g2a_types_A_const_77 *lang.Keyword

var A_arbace_g2a_types_A_const_78 *lang.Keyword

var A_arbace_g2a_types_A_const_79 *lang.Keyword

var A_arbace_g2a_types_A_const_80 *lang.Keyword

var A_arbace_g2a_types_A_const_81 *lang.Keyword

var A_arbace_g2a_types_A_const_82 *lang.Var

var A_arbace_g2a_types_A_const_83 any

var A_arbace_g2a_types_A_const_84 *lang.Keyword

var A_arbace_g2a_types_A_const_85 *lang.Keyword

var A_arbace_g2a_types_A_const_86 *lang.Keyword

var A_arbace_g2a_types_A_const_87 any

var A_arbace_g2a_types_A_const_88 any

var A_arbace_g2a_types_A_const_89 *lang.Keyword

var A_arbace_g2a_types_A_const_90 any

var A_arbace_g2a_types_A_const_91 *lang.Var

var A_arbace_g2a_types_A_const_92 *lang.Var

var A_arbace_g2a_types_A_const_93 *lang.Keyword

var A_arbace_g2a_types_A_const_94 *lang.Keyword

var A_arbace_g2a_types_A_const_95 *lang.Keyword

var A_arbace_g2a_types_A_const_96 *lang.Keyword

var A_arbace_g2a_types_A_const_97 *lang.Var

var A_arbace_g2a_types_A_const_98 *lang.Var

var A_arbace_g2a_types_A_const_99 any

var A_arbace_g2a_types_A_const_100 *lang.Keyword

var A_arbace_g2a_types_A_const_101 *lang.Keyword

var A_arbace_g2a_types_A_const_102 any

var A_arbace_g2a_types_A_const_103 *lang.Keyword

var A_arbace_g2a_types_A_const_104 *lang.Keyword

var A_arbace_g2a_types_A_const_105 any

var A_arbace_g2a_types_A_const_106 *lang.Var

var A_arbace_g2a_types_A_const_107 *lang.Keyword

var A_arbace_g2a_types_A_const_108 *lang.Var

var A_arbace_g2a_types_A_const_109 *lang.Var

var A_arbace_g2a_types_A_const_110 any

var A_arbace_g2a_types_A_const_111 *lang.Keyword

var A_arbace_g2a_types_A_const_112 *lang.Var

var A_arbace_g2a_types_A_const_113 *lang.Keyword

var A_arbace_g2a_types_A_init jrt.ClassInit

func A_arbace_g2a_types_A_Init() { if !A_arbace_g2a_types_A_init.Done() { A_arbace_g2a_types_A_init.Run(A_arbace_g2a_types_A_clinit) } }

func A_arbace_g2a_types_A_clinit() { A_arbace_g2a_types_A_clinit_p0(); A_arbace_g2a_types_A_clinit_p1(); A_arbace_g2a_types_A_clinit_p2(); A_arbace_g2a_types_A_clinit_p3(); A_arbace_g2a_types_A_clinit_p4(); A_arbace_g2a_types_A_clinit_p5(); A_arbace_g2a_types_A_clinit_p6(); A_arbace_g2a_types_A_clinit_p7(); A_arbace_g2a_types_A_clinit_p8(); A_arbace_g2a_types_A_clinit_p9() }

func A_arbace_g2a_types_A_clinit_p0() { A_arbace_g2a_types_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 172); A_arbace_g2a_types_A_const_0 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[58]); A_arbace_g2a_types_A_const_1 = A_arbace_g2a_types_A_const_pool.A[59]; A_arbace_g2a_types_A_const_2 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[60]); A_arbace_g2a_types_A_const_3 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[61]); A_arbace_g2a_types_A_const_4 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[62]); A_arbace_g2a_types_A_const_5 = A_arbace_g2a_types_A_const_pool.A[63]; A_arbace_g2a_types_A_const_6 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[64]); A_arbace_g2a_types_A_const_7 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[65]); A_arbace_g2a_types_A_const_8 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[66]); A_arbace_g2a_types_A_const_9 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[67]); A_arbace_g2a_types_A_const_10 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[68]); A_arbace_g2a_types_A_const_11 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[69]) }

func A_arbace_g2a_types_A_clinit_p1() { A_arbace_g2a_types_A_const_12 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[70]); A_arbace_g2a_types_A_const_13 = jrt.Class_Cast(A_arbace_g2a_types_A_const_pool.A[71]); A_arbace_g2a_types_A_const_14 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[72]); A_arbace_g2a_types_A_const_15 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[73]); A_arbace_g2a_types_A_const_16 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[74]); A_arbace_g2a_types_A_const_17 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[75]); A_arbace_g2a_types_A_const_18 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[76]); A_arbace_g2a_types_A_const_19 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[77]); A_arbace_g2a_types_A_const_20 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[78]); A_arbace_g2a_types_A_const_21 = A_arbace_g2a_types_A_const_pool.A[79]; A_arbace_g2a_types_A_const_22 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[80]); A_arbace_g2a_types_A_const_23 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[81]) }

func A_arbace_g2a_types_A_clinit_p2() { A_arbace_g2a_types_A_const_24 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[82]); A_arbace_g2a_types_A_const_25 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[83]); A_arbace_g2a_types_A_const_26 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[84]); A_arbace_g2a_types_A_const_27 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[85]); A_arbace_g2a_types_A_const_28 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[86]); A_arbace_g2a_types_A_const_29 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[87]); A_arbace_g2a_types_A_const_30 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[88]); A_arbace_g2a_types_A_const_31 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[89]); A_arbace_g2a_types_A_const_32 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[90]); A_arbace_g2a_types_A_const_33 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[91]); A_arbace_g2a_types_A_const_34 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[92]); A_arbace_g2a_types_A_const_35 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[93]) }

func A_arbace_g2a_types_A_clinit_p3() { A_arbace_g2a_types_A_const_36 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[94]); A_arbace_g2a_types_A_const_37 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[95]); A_arbace_g2a_types_A_const_38 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[96]); A_arbace_g2a_types_A_const_39 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[97]); A_arbace_g2a_types_A_const_40 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[98]); A_arbace_g2a_types_A_const_41 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[99]); A_arbace_g2a_types_A_const_42 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[100]); A_arbace_g2a_types_A_const_43 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[101]); A_arbace_g2a_types_A_const_44 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[102]); A_arbace_g2a_types_A_const_45 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[103]); A_arbace_g2a_types_A_const_46 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[104]); A_arbace_g2a_types_A_const_47 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[105]) }

func A_arbace_g2a_types_A_clinit_p4() { A_arbace_g2a_types_A_const_48 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[106]); A_arbace_g2a_types_A_const_49 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[107]); A_arbace_g2a_types_A_const_50 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[108]); A_arbace_g2a_types_A_const_51 = A_arbace_g2a_types_A_const_pool.A[109]; A_arbace_g2a_types_A_const_52 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[110]); A_arbace_g2a_types_A_const_53 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[111]); A_arbace_g2a_types_A_const_54 = A_arbace_g2a_types_A_const_pool.A[112]; A_arbace_g2a_types_A_const_55 = A_arbace_g2a_types_A_const_pool.A[113]; A_arbace_g2a_types_A_const_56 = A_arbace_g2a_types_A_const_pool.A[114]; A_arbace_g2a_types_A_const_57 = A_arbace_g2a_types_A_const_pool.A[115]; A_arbace_g2a_types_A_const_58 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[116]); A_arbace_g2a_types_A_const_59 = A_arbace_g2a_types_A_const_pool.A[117]; A_arbace_g2a_types_A_const_60 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[118]) }

func A_arbace_g2a_types_A_clinit_p5() { A_arbace_g2a_types_A_const_61 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[119]); A_arbace_g2a_types_A_const_62 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[120]); A_arbace_g2a_types_A_const_63 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[121]); A_arbace_g2a_types_A_const_64 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[122]); A_arbace_g2a_types_A_const_65 = A_arbace_g2a_types_A_const_pool.A[123]; A_arbace_g2a_types_A_const_66 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[124]); A_arbace_g2a_types_A_const_67 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[125]); A_arbace_g2a_types_A_const_68 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[126]); A_arbace_g2a_types_A_const_69 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[127]); A_arbace_g2a_types_A_const_70 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[128]); A_arbace_g2a_types_A_const_71 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[129]); A_arbace_g2a_types_A_const_72 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[130]) }

func A_arbace_g2a_types_A_clinit_p6() { A_arbace_g2a_types_A_const_73 = A_arbace_g2a_types_A_const_pool.A[131]; A_arbace_g2a_types_A_const_74 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[132]); A_arbace_g2a_types_A_const_75 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[133]); A_arbace_g2a_types_A_const_76 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[134]); A_arbace_g2a_types_A_const_77 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[135]); A_arbace_g2a_types_A_const_78 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[136]); A_arbace_g2a_types_A_const_79 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[137]); A_arbace_g2a_types_A_const_80 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[138]); A_arbace_g2a_types_A_const_81 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[139]); A_arbace_g2a_types_A_const_82 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[140]); A_arbace_g2a_types_A_const_83 = A_arbace_g2a_types_A_const_pool.A[141]; A_arbace_g2a_types_A_const_84 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[142]) }

func A_arbace_g2a_types_A_clinit_p7() { A_arbace_g2a_types_A_const_85 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[143]); A_arbace_g2a_types_A_const_86 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[144]); A_arbace_g2a_types_A_const_87 = A_arbace_g2a_types_A_const_pool.A[145]; A_arbace_g2a_types_A_const_88 = A_arbace_g2a_types_A_const_pool.A[146]; A_arbace_g2a_types_A_const_89 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[147]); A_arbace_g2a_types_A_const_90 = A_arbace_g2a_types_A_const_pool.A[148]; A_arbace_g2a_types_A_const_91 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[149]); A_arbace_g2a_types_A_const_92 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[150]); A_arbace_g2a_types_A_const_93 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[151]); A_arbace_g2a_types_A_const_94 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[152]); A_arbace_g2a_types_A_const_95 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[153]); A_arbace_g2a_types_A_const_96 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[154]) }

func A_arbace_g2a_types_A_clinit_p8() { A_arbace_g2a_types_A_const_97 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[155]); A_arbace_g2a_types_A_const_98 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[156]); A_arbace_g2a_types_A_const_99 = A_arbace_g2a_types_A_const_pool.A[157]; A_arbace_g2a_types_A_const_100 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[158]); A_arbace_g2a_types_A_const_101 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[159]); A_arbace_g2a_types_A_const_102 = A_arbace_g2a_types_A_const_pool.A[160]; A_arbace_g2a_types_A_const_103 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[161]); A_arbace_g2a_types_A_const_104 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[162]); A_arbace_g2a_types_A_const_105 = A_arbace_g2a_types_A_const_pool.A[163]; A_arbace_g2a_types_A_const_106 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[164]); A_arbace_g2a_types_A_const_107 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[165]); A_arbace_g2a_types_A_const_108 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[166]) }

func A_arbace_g2a_types_A_clinit_p9() { A_arbace_g2a_types_A_const_109 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[167]); A_arbace_g2a_types_A_const_110 = A_arbace_g2a_types_A_const_pool.A[168]; A_arbace_g2a_types_A_const_111 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[169]); A_arbace_g2a_types_A_const_112 = lang.Var_Cast(A_arbace_g2a_types_A_const_pool.A[170]); A_arbace_g2a_types_A_const_113 = lang.Keyword_Cast(A_arbace_g2a_types_A_const_pool.A[171]) }

func A_arbace_g2a_types_A_New() *A_arbace_g2a_types_A { A_arbace_g2a_types_A_Init(); t := &A_arbace_g2a_types_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_types_A) Ctor() {}

func (t *A_arbace_g2a_types_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_types_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_types_A_class }

func (t *A_arbace_g2a_types_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_types_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_types_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_types_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_types_A); return ok }

func A_arbace_g2a_types_A_Cast(x any) *A_arbace_g2a_types_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_types_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_types_A_class)) }; return v }



type A_arbace_g2a_types_const_kind_A struct{ a2g_header uint64 }

var A_arbace_g2a_types_const_kind_A_fn_class *jrt.Class



type A_arbace_g2a_types_entry_A struct{ a2g_header uint64 }

var A_arbace_g2a_types_entry_A_fn_class *jrt.Class



type A_arbace_g2a_types_eval1376000004_A struct{ jrt.Object }

func A_arbace_g2a_types_eval1376000004_A_New() *A_arbace_g2a_types_eval1376000004_A { t := &A_arbace_g2a_types_eval1376000004_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_types_eval1376000004_A) Ctor() {}

func (t *A_arbace_g2a_types_eval1376000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_types_eval1376000004_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_types_eval1376000004_A_class }

func (t *A_arbace_g2a_types_eval1376000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_types_eval1376000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_types_eval1376000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_types_eval1376000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_types_eval1376000004_A); return ok }

func A_arbace_g2a_types_eval1376000004_A_Cast(x any) *A_arbace_g2a_types_eval1376000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_types_eval1376000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_types_eval1376000004_A_class)) }; return v }



type A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A struct{ a2g_header uint64 }

var A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A_fn_class *jrt.Class



type A_arbace_g2a_types_eval1376000008_A struct{ jrt.Object }

func A_arbace_g2a_types_eval1376000008_A_New() *A_arbace_g2a_types_eval1376000008_A { t := &A_arbace_g2a_types_eval1376000008_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_types_eval1376000008_A) Ctor() {}

func (t *A_arbace_g2a_types_eval1376000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_types_eval1376000008_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_types_eval1376000008_A_class }

func (t *A_arbace_g2a_types_eval1376000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_types_eval1376000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_types_eval1376000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_types_eval1376000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_types_eval1376000008_A); return ok }

func A_arbace_g2a_types_eval1376000008_A_Cast(x any) *A_arbace_g2a_types_eval1376000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_types_eval1376000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_types_eval1376000008_A_class)) }; return v }



type A_arbace_g2a_types_eval1376000008_fn__1376000009_A struct{ a2g_header uint64 }

var A_arbace_g2a_types_eval1376000008_fn__1376000009_A_fn_class *jrt.Class



type A_arbace_g2a_types_method_elem_A struct{ a2g_header uint64 }

var A_arbace_g2a_types_method_elem_A_fn_class *jrt.Class



type A_arbace_g2a_types_ns_name_of_A struct{ a2g_header uint64 }

var A_arbace_g2a_types_ns_name_of_A_fn_class *jrt.Class



type A_arbace_g2a_types_ns_name_of_fn__1376000014_A struct{ a2g_header uint64 }

var A_arbace_g2a_types_ns_name_of_fn__1376000014_A_fn_class *jrt.Class



type A_arbace_g2a_types_params_vec_A struct{ a2g_header uint64 }

var A_arbace_g2a_types_params_vec_A_fn_class *jrt.Class



type A_arbace_g2a_types_params_vec_fn__1376000018_A struct{ a2g_header uint64; F_n int32; F_variadic any }

var A_arbace_g2a_types_params_vec_fn__1376000018_A_fn_class *jrt.Class



type A_arbace_g2a_types_qualify_A struct{ a2g_header uint64 }

var A_arbace_g2a_types_qualify_A_fn_class *jrt.Class



type A_arbace_g2a_types_type_form_A struct{ a2g_header uint64 }

var A_arbace_g2a_types_type_form_A_fn_class *jrt.Class



type A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A struct{ a2g_header uint64 }

var A_arbace_g2a_types_type_form_iter__1376000027__1376000031_A_fn_class *jrt.Class



type A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A struct{ a2g_header uint64; F_s__1376000028, F_iter__1376000027 any }

var A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_A_fn_class *jrt.Class



type A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A struct{ a2g_header uint64; F_b__1376000030 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_g2a_types_type_form_iter__1376000027__1376000031_fn__1376000032_fn__1376000033_A_fn_class *jrt.Class



type A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A struct{ a2g_header uint64 }

var A_arbace_g2a_types_type_form_iter__1376000037__1376000041_A_fn_class *jrt.Class



type A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A struct{ a2g_header uint64; F_s__1376000038, F_iter__1376000037 any }

var A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_A_fn_class *jrt.Class



type A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A struct{ a2g_header uint64; F_b__1376000040 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_g2a_types_type_form_iter__1376000037__1376000041_fn__1376000042_fn__1376000043_A_fn_class *jrt.Class



type A_arbace_g2a_types_untyped_QMARK__A struct{ a2g_header uint64 }

var A_arbace_g2a_types_untyped_QMARK__A_fn_class *jrt.Class
