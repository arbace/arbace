//line aot_arbace_g2a_types__init.ae:1
package aot_arbace_g2a_types

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_g2a_types__init_A_Unit0__O() any { A_arbace_g2a_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(jrt.NN(A_arbace_g2a_types__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_g2a_types__init_A_const_1) }
//line :1:1
func A_arbace_g2a_types__init_A_Unit1__O() any { A_arbace_g2a_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_g2a_types__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_g2a_types__init_A_const_2)) }
//line :1:1
func A_arbace_g2a_types__init_A_Unit2__O() any { A_arbace_g2a_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A_New(); var tmp2 *jrt.Class; A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A_Init(); tmp2 = A_arbace_g2a_types_eval1376000004_loading__1927001464__auto____1376000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_g2a_types__init_A_Unit3__O() any { A_arbace_g2a_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_g2a_types__init_A_const_1)).Equals_O__Z(A_arbace_g2a_types__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_g2a_types_eval1376000008_fn__1376000009_A_New(); var tmp2 *jrt.Class; A_arbace_g2a_types_eval1376000008_fn__1376000009_A_Init(); tmp2 = A_arbace_g2a_types_eval1376000008_fn__1376000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_g2a_types__init_A_Load__O() any { A_arbace_g2a_types__init_A_Init(); A_arbace_g2a_types__init_A_Unit0__O(); A_arbace_g2a_types__init_A_Unit1__O(); A_arbace_g2a_types__init_A_Unit2__O(); A_arbace_g2a_types__init_A_Unit3__O(); A_arbace_g2a_types__init_A_Unit4__O(); A_arbace_g2a_types__init_A_Unit5__O(); A_arbace_g2a_types__init_A_Unit6__O(); A_arbace_g2a_types__init_A_Unit7__O(); A_arbace_g2a_types__init_A_Unit8__O(); A_arbace_g2a_types__init_A_Unit9__O(); A_arbace_g2a_types__init_A_Unit10__O(); A_arbace_g2a_types__init_A_Unit11__O(); A_arbace_g2a_types__init_A_Unit12__O(); A_arbace_g2a_types__init_A_Unit13__O(); A_arbace_g2a_types__init_A_Unit14__O(); A_arbace_g2a_types__init_A_Unit15__O(); A_arbace_g2a_types__init_A_Unit16__O(); A_arbace_g2a_types__init_A_Unit17__O(); A_arbace_g2a_types__init_A_Unit18__O(); return nil }




func A_arbace_g2a_types__init_A_Unit4__O() any { A_arbace_g2a_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V(10, 1); jrt.NN(A_arbace_g2a_types__init_A_const_4).BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_g2a_types__init_A_const_4; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_types__init_A_const_5)); return jrt.NN(A_arbace_g2a_types__init_A_const_4).SetDynamic_Z__Var(true).Ref() }



func A_arbace_g2a_types__init_A_Unit5__O() any { A_arbace_g2a_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V(14, 1); jrt.NN(A_arbace_g2a_types__init_A_const_6).BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_g2a_types__init_A_const_6; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_types__init_A_const_7)); return jrt.NN(A_arbace_g2a_types__init_A_const_6).SetDynamic_Z__Var(true).Ref() }



func A_arbace_g2a_types__init_A_Unit6__O() any { A_arbace_g2a_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V(18, 1); var tmp1 *lang.Var = A_arbace_g2a_types__init_A_const_8; var tmp2 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY; jrt.NN(tmp1).BindRoot_O__V(tmp2.Ref()); var tmp3 *lang.Var = A_arbace_g2a_types__init_A_const_8; jrt.NN(tmp3).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_types__init_A_const_9)); return jrt.NN(A_arbace_g2a_types__init_A_const_8).SetDynamic_Z__Var(true).Ref() }



func A_arbace_g2a_types__init_A_Unit7__O() any { A_arbace_g2a_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V(22, 1); var tmp1 *lang.Var = A_arbace_g2a_types__init_A_const_10; var tmp2 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp2 = lang.PersistentArrayMap_EMPTY; jrt.NN(tmp1).BindRoot_O__V(tmp2.Ref()); var tmp3 *lang.Var = A_arbace_g2a_types__init_A_const_10; jrt.NN(tmp3).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_types__init_A_const_11)); return jrt.NN(A_arbace_g2a_types__init_A_const_10).SetDynamic_Z__Var(true).Ref() }



func A_arbace_g2a_types__init_A_Unit8__O() any { A_arbace_g2a_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V(26, 1); var tmp1 *lang.Var = A_arbace_g2a_types__init_A_const_12; var tmp2 any = A_arbace_g2a_types_entry_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_types_entry_A_Init(); tmp3 = A_arbace_g2a_types_entry_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_types__init_A_const_12; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_types__init_A_const_13)); return A_arbace_g2a_types__init_A_const_12.Ref() }

func A_arbace_g2a_types__init_A_Unit9__O() any { A_arbace_g2a_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V(28, 1); jrt.NN(A_arbace_g2a_types__init_A_const_14).BindRoot_O__V(A_arbace_g2a_types__init_A_const_15); var tmp1 *lang.Var = A_arbace_g2a_types__init_A_const_14; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_types__init_A_const_16)); return A_arbace_g2a_types__init_A_const_14.Ref() }



func A_arbace_g2a_types__init_A_Unit10__O() any { A_arbace_g2a_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V(32, 1); var tmp1 *lang.Var = A_arbace_g2a_types__init_A_const_17; var tmp2 any = A_arbace_g2a_types_ns_name_of_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_types_ns_name_of_A_Init(); tmp3 = A_arbace_g2a_types_ns_name_of_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_types__init_A_const_17; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_types__init_A_const_18)); return A_arbace_g2a_types__init_A_const_17.Ref() }






func A_arbace_g2a_types__init_A_Unit11__O() any { A_arbace_g2a_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V(39, 1); var tmp1 *lang.Var = A_arbace_g2a_types__init_A_const_19; var tmp2 any = A_arbace_g2a_types_qualify_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_types_qualify_A_Init(); tmp3 = A_arbace_g2a_types_qualify_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_types__init_A_const_19; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_types__init_A_const_20)); return A_arbace_g2a_types__init_A_const_19.Ref() }







func A_arbace_g2a_types__init_A_Unit12__O() any { A_arbace_g2a_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V(47, 1); var tmp1 *lang.Var = A_arbace_g2a_types__init_A_const_21; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_types__init_A_const_22)); return A_arbace_g2a_types__init_A_const_21.Ref() }

func A_arbace_g2a_types__init_A_Unit13__O() any { A_arbace_g2a_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V(49, 1); var tmp1 *lang.Var = A_arbace_g2a_types__init_A_const_23; var tmp2 any = A_arbace_g2a_types_params_vec_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_types_params_vec_A_Init(); tmp3 = A_arbace_g2a_types_params_vec_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_types__init_A_const_23; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_types__init_A_const_24)); return A_arbace_g2a_types__init_A_const_23.Ref() }







func A_arbace_g2a_types__init_A_Unit14__O() any { A_arbace_g2a_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V(57, 1); var tmp1 *lang.Var = A_arbace_g2a_types__init_A_const_25; var tmp2 any = A_arbace_g2a_types_method_elem_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_types_method_elem_A_Init(); tmp3 = A_arbace_g2a_types_method_elem_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_types__init_A_const_25; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_types__init_A_const_26)); return A_arbace_g2a_types__init_A_const_25.Ref() }








func A_arbace_g2a_types__init_A_Unit15__O() any { A_arbace_g2a_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V(66, 1); var tmp1 *lang.Var = A_arbace_g2a_types__init_A_const_21; var tmp2 any = A_arbace_g2a_types_type_form_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_types_type_form_A_Init(); tmp3 = A_arbace_g2a_types_type_form_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_types__init_A_const_21; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_types__init_A_const_27)); return A_arbace_g2a_types__init_A_const_21.Ref() }










































func A_arbace_g2a_types__init_A_Unit16__O() any { A_arbace_g2a_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V(109, 1); var tmp1 *lang.Var = A_arbace_g2a_types__init_A_const_28; var tmp2 any = A_arbace_g2a_types_untyped_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_g2a_types_untyped_QMARK__A_Init(); tmp3 = A_arbace_g2a_types_untyped_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_types__init_A_const_28; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_types__init_A_const_29)); return A_arbace_g2a_types__init_A_const_28.Ref() }





func A_arbace_g2a_types__init_A_Unit17__O() any { A_arbace_g2a_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V(115, 1); jrt.NN(A_arbace_g2a_types__init_A_const_30).BindRoot_O__V(A_arbace_g2a_types__init_A_const_31); var tmp1 *lang.Var = A_arbace_g2a_types__init_A_const_30; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_types__init_A_const_32)); return A_arbace_g2a_types__init_A_const_30.Ref() }






func A_arbace_g2a_types__init_A_Unit18__O() any { A_arbace_g2a_types__init_A_Init(); lang.Compiler_AOT_At_I_I__V(122, 1); var tmp1 *lang.Var = A_arbace_g2a_types__init_A_const_33; var tmp2 any = A_arbace_g2a_types_const_kind_A_New(); var tmp3 *jrt.Class; A_arbace_g2a_types_const_kind_A_Init(); tmp3 = A_arbace_g2a_types_const_kind_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_g2a_types__init_A_const_33; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_g2a_types__init_A_const_34)); return A_arbace_g2a_types__init_A_const_33.Ref() }



type A_arbace_g2a_types__init_A struct{ jrt.Object }

var A_arbace_g2a_types__init_A_const_0 *lang.Var

var A_arbace_g2a_types__init_A_const_1 any

var A_arbace_g2a_types__init_A_const_2 any

var A_arbace_g2a_types__init_A_const_3 any

var A_arbace_g2a_types__init_A_const_4 *lang.Var

var A_arbace_g2a_types__init_A_const_5 any

var A_arbace_g2a_types__init_A_const_6 *lang.Var

var A_arbace_g2a_types__init_A_const_7 any

var A_arbace_g2a_types__init_A_const_8 *lang.Var

var A_arbace_g2a_types__init_A_const_9 any

var A_arbace_g2a_types__init_A_const_10 *lang.Var

var A_arbace_g2a_types__init_A_const_11 any

var A_arbace_g2a_types__init_A_const_12 *lang.Var

var A_arbace_g2a_types__init_A_const_13 any

var A_arbace_g2a_types__init_A_const_14 *lang.Var

var A_arbace_g2a_types__init_A_const_15 any

var A_arbace_g2a_types__init_A_const_16 any

var A_arbace_g2a_types__init_A_const_17 *lang.Var

var A_arbace_g2a_types__init_A_const_18 any

var A_arbace_g2a_types__init_A_const_19 *lang.Var

var A_arbace_g2a_types__init_A_const_20 any

var A_arbace_g2a_types__init_A_const_21 *lang.Var

var A_arbace_g2a_types__init_A_const_22 any

var A_arbace_g2a_types__init_A_const_23 *lang.Var

var A_arbace_g2a_types__init_A_const_24 any

var A_arbace_g2a_types__init_A_const_25 *lang.Var

var A_arbace_g2a_types__init_A_const_26 any

var A_arbace_g2a_types__init_A_const_27 any

var A_arbace_g2a_types__init_A_const_28 *lang.Var

var A_arbace_g2a_types__init_A_const_29 any

var A_arbace_g2a_types__init_A_const_30 *lang.Var

var A_arbace_g2a_types__init_A_const_31 any

var A_arbace_g2a_types__init_A_const_32 any

var A_arbace_g2a_types__init_A_const_33 *lang.Var

var A_arbace_g2a_types__init_A_const_34 any

var A_arbace_g2a_types__init_A_init jrt.ClassInit

func A_arbace_g2a_types__init_A_Init() { if !A_arbace_g2a_types__init_A_init.Done() { A_arbace_g2a_types__init_A_init.Run(A_arbace_g2a_types__init_A_clinit) } }

func A_arbace_g2a_types__init_A_clinit() { A_arbace_g2a_types__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_132); A_arbace_g2a_types__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_5)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7))); A_arbace_g2a_types__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7)); A_arbace_g2a_types__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_g2a_types__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_5, Lit_9); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_133).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_g2a_types__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), jrt.Integer_ValueOf_I__Integer(10).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_135).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_136).Ref(), Lit_137, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_138)); A_arbace_g2a_types__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_5, Lit_16); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_133).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_g2a_types__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), jrt.Integer_ValueOf_I__Integer(14).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_135).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_136).Ref(), Lit_137, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_139)); A_arbace_g2a_types__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_5, Lit_19); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_133).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_g2a_types__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), jrt.Integer_ValueOf_I__Integer(18).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_135).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_136).Ref(), Lit_137, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_140)); A_arbace_g2a_types__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_5, Lit_101); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_133).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_g2a_types__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), jrt.Integer_ValueOf_I__Integer(22).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_135).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_136).Ref(), Lit_137, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_141)); A_arbace_g2a_types__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_5, Lit_32); A_arbace_g2a_types__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_97).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), jrt.Integer_ValueOf_I__Integer(26).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_135).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_136).Ref(), Lit_137)); A_arbace_g2a_types__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_5, Lit_89); A_arbace_g2a_types__init_A_const_15 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_55).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_14).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_44).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_54).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_80).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_93).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_79).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_56).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_61).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_74).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_92).Ref())).Ref(); A_arbace_g2a_types__init_A_const_16 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), jrt.Integer_ValueOf_I__Integer(28).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_135).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_136).Ref(), Lit_137, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_143)); A_arbace_g2a_types__init_A_const_17 = lang.RT_Var_String_String__Var(Lit_5, Lit_20); A_arbace_g2a_types__init_A_const_18 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_144).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_145, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), jrt.Integer_ValueOf_I__Integer(32).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_135).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_136).Ref(), Lit_137)); A_arbace_g2a_types__init_A_const_19 = lang.RT_Var_String_String__Var(Lit_5, Lit_77); A_arbace_g2a_types__init_A_const_20 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_144).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_31).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_146, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), jrt.Integer_ValueOf_I__Integer(39).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_135).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_136).Ref(), Lit_137)); A_arbace_g2a_types__init_A_const_21 = lang.RT_Var_String_String__Var(Lit_5, Lit_24); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_147).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_g2a_types__init_A_const_22 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), jrt.Integer_ValueOf_I__Integer(47).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_135).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_136).Ref(), Lit_137)); A_arbace_g2a_types__init_A_const_23 = lang.RT_Var_String_String__Var(Lit_5, Lit_33); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_g2a_types__init_A_const_24 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_91).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_38).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), jrt.Integer_ValueOf_I__Integer(49).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_135).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_136).Ref(), Lit_137)); A_arbace_g2a_types__init_A_const_25 = lang.RT_Var_String_String__Var(Lit_5, Lit_83); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_g2a_types__init_A_const_26 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_149).Ref(), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_31).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_25).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), jrt.Integer_ValueOf_I__Integer(57).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_135).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_136).Ref(), Lit_137)); A_arbace_g2a_types__init_A_const_27 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_97).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_150, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), jrt.Integer_ValueOf_I__Integer(66).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_135).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_136).Ref(), Lit_137)); A_arbace_g2a_types__init_A_const_28 = lang.RT_Var_String_String__Var(Lit_5, Lit_151); A_arbace_g2a_types__init_A_const_29 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_97).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_152, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), jrt.Integer_ValueOf_I__Integer(109).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_135).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_136).Ref(), Lit_137)); A_arbace_g2a_types__init_A_const_30 = lang.RT_Var_String_String__Var(Lit_5, Lit_99); A_arbace_g2a_types__init_A_const_31 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, Lit_153, lang.RT_Keyword_String_String__Keyword(nil, Lit_153).Ref(), Lit_154, lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), Lit_156, lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), Lit_157, lang.RT_Keyword_String_String__Keyword(nil, Lit_158).Ref(), Lit_159, lang.RT_Keyword_String_String__Keyword(nil, Lit_160).Ref(), Lit_161, lang.RT_Keyword_String_String__Keyword(nil, Lit_162).Ref(), Lit_163, lang.RT_Keyword_String_String__Keyword(nil, Lit_163).Ref(), Lit_164, lang.RT_Keyword_String_String__Keyword(nil, Lit_100).Ref(), Lit_165, lang.RT_Keyword_String_String__Keyword(nil, Lit_153).Ref(), Lit_166, lang.RT_Keyword_String_String__Keyword(nil, Lit_163).Ref(), Lit_167, lang.RT_Keyword_String_String__Keyword(nil, Lit_168).Ref(), Lit_169, lang.RT_Keyword_String_String__Keyword(nil, Lit_162).Ref())); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_148).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_g2a_types__init_A_const_32 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), jrt.Integer_ValueOf_I__Integer(115).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_135).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_136).Ref(), Lit_137)); A_arbace_g2a_types__init_A_const_33 = lang.RT_Var_String_String__Var(Lit_5, Lit_98); A_arbace_g2a_types__init_A_const_34 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_142).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_97).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_170, lang.RT_Keyword_String_String__Keyword(nil, Lit_134).Ref(), jrt.Integer_ValueOf_I__Integer(122).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_135).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_136).Ref(), Lit_137)) }

func A_arbace_g2a_types__init_A_New() *A_arbace_g2a_types__init_A { A_arbace_g2a_types__init_A_Init(); t := &A_arbace_g2a_types__init_A{}; t.Ctor(); return t }

func (t *A_arbace_g2a_types__init_A) Ctor() {}

func (t *A_arbace_g2a_types__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_g2a_types__init_A) GetClass__Class() *jrt.Class { return A_arbace_g2a_types__init_A_class }

func (t *A_arbace_g2a_types__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_g2a_types__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_g2a_types__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_g2a_types__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_g2a_types__init_A); return ok }

func A_arbace_g2a_types__init_A_Cast(x any) *A_arbace_g2a_types__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_g2a_types__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_g2a_types__init_A_class)) }; return v }
