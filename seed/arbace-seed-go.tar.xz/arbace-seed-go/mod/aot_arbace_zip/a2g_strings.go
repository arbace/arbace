//line a2g_strings.ae:1
package aot_arbace_zip

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.corekn7,excludeyn7,replaceyn6,removeyn4,nextkn4,linekn6,columnkn3,dockn6,authorks3,zip7,branch?ks3,zip8,childrenks3,zip9,make-nodekn7,contentkn6,pnodeskn1,lkn1,rkn5,ppathkn8,changed?kn3,endv11,arbace.core5,referR0,R1,ML3,R2,R3,R4,m4,R5,i16,R6,i28,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn10,arbace.zipm4,R7,s86,Functional hierarchical zipper, with navigation, editing,\n  and enumeration.  See HuetR8,s11,Rich Hickeyv11,arbace.core13,*loaded-libs*R9,R10,R11,v10,arbace.zip6,zipperv11,arbace.core4,seq?v11,arbace.core8,identityv11,arbace.core9,with-metav11,arbace.core7,vector?v11,arbace.core3,seqv11,arbace.core3,vecv11,arbace.core10,complementv11,arbace.core4,compv11,arbace.core5,assocR12,v11,arbace.core5,applyv11,arbace.core6,vectorv11,arbace.core7,string?l0,v10,arbace.zip4,nodev10,arbace.zip7,branch?R13,l1,R14,R15,v10,arbace.zip8,childrenv11,arbace.core5,firstv11,arbace.core4,nextR16,v11,arbace.core8,to-arrayR17,v11,arbace.core4,peekv10,arbace.zip9,make-nodev11,arbace.core6,concatv11,arbace.core4,consR18,v10,arbace.zip2,upv11,arbace.core4,lastv11,arbace.core7,butlastv11,arbace.core3,popv11,arbace.core4,restv10,arbace.zip7,replacev10,arbace.zip4,downv10,arbace.zip5,rightv10,arbace.zip4,leftv10,arbace.zip9,rightmost")

var Lit_1 *jrt.String = jrt.Intern("called children on a leaf node")

var Lit_2 *jrt.String = jrt.Intern("Insert at top")

var Lit_3 *jrt.String = jrt.Intern("Remove at top")

var Lit_4 *jrt.String = jrt.Intern("arbace.zip$seq_zip$fn__703000013")

var Lit_5 *jrt.String = jrt.Intern("arbace.zip$vector_zip$fn__703000016")

var Lit_6 *jrt.String = jrt.Intern("arbace.zip$xml_zip$fn__703000019")

var Lit_7 *jrt.String = jrt.Intern("kn3,dockn6,authoryn11,arbace.corekn8,arglistsyn7,branch?yn8,childrenyn9,make-nodeyn4,rootkn5,addedkn4,linekn6,columnkn4,fileyn3,locyn4,nodeyn4,itemyn1,fyn1,&yn4,argsv11,arbace.core5,in-nsMyn10,arbace.zipm4,R0,s86,Functional hierarchical zipper, with navigation, editing,\n  and enumeration.  See HuetR1,s11,Rich Hickeym4,R0,s86,Functional hierarchical zipper, with navigation, editing,\n  and enumeration.  See HuetR1,s11,Rich HickeyR2,v10,arbace.zip6,zipperm12,R3,L1,V4,R4,R5,R6,R7,R0,s374,Creates a new zipper structure.\n\n  branch? is a fn that, given a node, returns true if it can have\n  children, even if it currently doesn't.\n\n  children is a fn that, given a branch node, returns a seq of its\n  children.\n\n  make-node is a fn that, given an existing node and a seq of\n  children, returns a new branch node with the supplied children.\n  root is the root node.R8,s3,1.0R9,i18,R10,i1,R11,s13,arbace/zip.aev10,arbace.zip7,seq-zipm12,R3,L1,V1,R7,R0,s60,Returns a zipper for nested sequences, given a root sequenceR8,s3,1.0R9,i35,R10,i1,R11,s13,arbace/zip.aev10,arbace.zip10,vector-zipm12,R3,L1,V1,R7,R0,s56,Returns a zipper for nested vectors, given a root vectorR8,s3,1.0R9,i44,R10,i1,R11,s13,arbace/zip.aev10,arbace.zip7,xml-zipm12,R3,L1,V1,R7,R0,s77,Returns a zipper for xml elements (as from xml/parse),\n  given a root elementR8,s3,1.0R9,i53,R10,i1,R11,s13,arbace/zip.aev10,arbace.zip4,nodem12,R3,L1,V1,R12,R0,s23,Returns the node at locR8,s3,1.0R9,i64,R10,i1,R11,s13,arbace/zip.aev10,arbace.zip7,branch?m12,R3,L1,V1,R12,R0,s43,Returns true if the node at loc is a branchR8,s3,1.0R9,i69,R10,i1,R11,s13,arbace/zip.aev10,arbace.zip8,childrenm12,R3,L1,V1,R12,R0,s68,Returns a seq of the children of node at loc, which must be a branchR8,s3,1.0R9,i75,R10,i1,R11,s13,arbace/zip.aev10,arbace.zip9,make-nodem12,R3,L1,V3,R12,R13,R5,R0,s117,Returns a new branch node, given an existing node and new\n  children. The loc is only used to supply the constructor.R8,s3,1.0R9,i83,R10,i1,R11,s13,arbace/zip.aev10,arbace.zip4,pathm12,R3,L1,V1,R12,R0,s42,Returns a seq of nodes leading to this locR8,s3,1.0R9,i90,R10,i1,R11,s13,arbace/zip.aev10,arbace.zip5,leftsm12,R3,L1,V1,R12,R0,s46,Returns a seq of the left siblings of this locR8,s3,1.0R9,i96,R10,i1,R11,s13,arbace/zip.aev10,arbace.zip6,rightsm12,R3,L1,V1,R12,R0,s47,Returns a seq of the right siblings of this locR8,s3,1.0R9,i102,R10,i1,R11,s13,arbace/zip.aev10,arbace.zip4,downm12,R3,L1,V1,R12,R0,s86,Returns the loc of the leftmost child of the node at this loc, or\n  nil if no childrenR8,s3,1.0R9,i108,R10,i1,R11,s13,arbace/zip.aev10,arbace.zip2,upm12,R3,L1,V1,R12,R0,s77,Returns the loc of the parent of the node at this loc, or nil if at\n  the topR8,s3,1.0R9,i122,R10,i1,R11,s13,arbace/zip.aev10,arbace.zip4,rootm12,R3,L1,V1,R12,R0,s71,zips all the way up and returns the root node, reflecting any\n changes.R8,s3,1.0R9,i136,R10,i1,R11,s13,arbace/zip.aev10,arbace.zip5,rightm12,R3,L1,V1,R12,R0,s68,Returns the loc of the right sibling of the node at this loc, or nilR8,s3,1.0R9,i148,R10,i1,R11,s13,arbace/zip.aev10,arbace.zip9,rightmostm12,R3,L1,V1,R12,R0,s73,Returns the loc of the rightmost sibling of the node at this loc, or selfR8,s3,1.0R9,i156,R10,i1,R11,s13,arbace/zip.aev10,arbace.zip4,leftm12,R3,L1,V1,R12,R0,s67,Returns the loc of the left sibling of the node at this loc, or nilR8,s3,1.0R9,i165,R10,i1,R11,s13,arbace/zip.aev10,arbace.zip8,leftmostm12,R3,L1,V1,R12,R0,s72,Returns the loc of the leftmost sibling of the node at this loc, or selfR8,s3,1.0R9,i173,R10,i1,R11,s13,arbace/zip.aev10,arbace.zip11,insert-leftm12,R3,L1,V2,R12,R14,R0,s77,Inserts the item as the left sibling of the node at this loc,\n without movingR8,s3,1.0R9,i182,R10,i1,R11,s13,arbace/zip.aev10,arbace.zip12,insert-rightm12,R3,L1,V2,R12,R14,R0,s79,Inserts the item as the right sibling of the node at this loc,\n  without movingR8,s3,1.0R9,i192,R10,i1,R11,s13,arbace/zip.aev10,arbace.zip7,replacem12,R3,L1,V2,R12,R13,R0,s45,Replaces the node at this loc, without movingR8,s3,1.0R9,i202,R10,i1,R11,s13,arbace/zip.aev10,arbace.zip4,editm12,R3,L1,V4,R12,R15,R16,R17,R0,s61,Replaces the node at this loc with the value of (f node args)R8,s3,1.0R9,i209,R10,i1,R11,s13,arbace/zip.aev10,arbace.zip12,insert-childm12,R3,L1,V2,R12,R14,R0,s80,Inserts the item as the leftmost child of the node at this loc,\n  without movingR8,s3,1.0R9,i215,R10,i1,R11,s13,arbace/zip.aev10,arbace.zip12,append-childm12,R3,L1,V2,R12,R14,R0,s81,Inserts the item as the rightmost child of the node at this loc,\n  without movingR8,s3,1.0R9,i222,R10,i1,R11,s13,arbace/zip.aev10,arbace.zip4,nextm12,R3,L1,V1,R12,R0,s164,Moves to the next loc in the hierarchy, depth-first. When reaching\n  the end, returns a distinguished loc detectable via end?. If already\n  at the end, stays there.R8,s3,1.0R9,i229,R10,i1,R11,s13,arbace/zip.aev10,arbace.zip4,prevm12,R3,L1,V1,R12,R0,s95,Moves to the previous loc in the hierarchy, depth-first. If already\n  at the root, returns nil.R8,s3,1.0R9,i245,R10,i1,R11,s13,arbace/zip.aev10,arbace.zip4,end?m12,R3,L1,V1,R12,R0,s60,Returns true if loc represents the end of a depth-first walkR8,s3,1.0R9,i257,R10,i1,R11,s13,arbace/zip.aev10,arbace.zip6,removem12,R3,L1,V1,R12,R0,s95,Removes the node at loc, returning the loc that would have preceded\n  it in a depth-first walk.R8,s3,1.0R9,i263,R10,i1,R11,s13,arbace/zip.ae")

var Lit_8 *jrt.String = jrt.Intern("arbace.zip$eval703000004$loading__1927001464__auto____703000005")

var Lit_9 *jrt.String = jrt.Intern("arbace.zip$eval703000008$fn__703000009")

var Lit_10 *jrt.String = jrt.Intern("arbace.zip$zipper")

var Lit_11 *jrt.String = jrt.Intern("arbace.zip$seq_zip")

var Lit_12 *jrt.String = jrt.Intern("arbace.zip$vector_zip")

var Lit_13 *jrt.String = jrt.Intern("arbace.zip$xml_zip")

var Lit_14 *jrt.String = jrt.Intern("arbace.zip$node")

var Lit_15 *jrt.String = jrt.Intern("arbace.zip$branch_QMARK_")

var Lit_16 *jrt.String = jrt.Intern("arbace.zip$children")

var Lit_17 *jrt.String = jrt.Intern("arbace.zip$make_node")

var Lit_18 *jrt.String = jrt.Intern("arbace.zip$path")

var Lit_19 *jrt.String = jrt.Intern("arbace.zip$lefts")

var Lit_20 *jrt.String = jrt.Intern("arbace.zip$rights")

var Lit_21 *jrt.String = jrt.Intern("arbace.zip$down")

var Lit_22 *jrt.String = jrt.Intern("arbace.zip$up")

var Lit_23 *jrt.String = jrt.Intern("arbace.zip$root")

var Lit_24 *jrt.String = jrt.Intern("arbace.zip$right")

var Lit_25 *jrt.String = jrt.Intern("arbace.zip$rightmost")

var Lit_26 *jrt.String = jrt.Intern("arbace.zip$left")

var Lit_27 *jrt.String = jrt.Intern("arbace.zip$leftmost")

var Lit_28 *jrt.String = jrt.Intern("arbace.zip$insert_left")

var Lit_29 *jrt.String = jrt.Intern("arbace.zip$insert_right")

var Lit_30 *jrt.String = jrt.Intern("arbace.zip$replace")

var Lit_31 *jrt.String = jrt.Intern("arbace.zip$edit")

var Lit_32 *jrt.String = jrt.Intern("arbace.zip$insert_child")

var Lit_33 *jrt.String = jrt.Intern("arbace.zip$append_child")

var Lit_34 *jrt.String = jrt.Intern("arbace.zip$next")

var Lit_35 *jrt.String = jrt.Intern("arbace.zip$prev")

var Lit_36 *jrt.String = jrt.Intern("arbace.zip$end_QMARK_")

var Lit_37 *jrt.String = jrt.Intern("arbace.zip$remove")
