//line a2g_strings.ae:1
package aot_arbace_zip

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("exclude")

var Lit_3 *jrt.String = jrt.Intern("replace")

var Lit_4 *jrt.String = jrt.Intern("remove")

var Lit_5 *jrt.String = jrt.Intern("next")

var Lit_6 *jrt.String = jrt.Intern("line")

var Lit_7 *jrt.String = jrt.Intern("column")

var Lit_8 *jrt.String = jrt.Intern("commute")

var Lit_9 *jrt.String = jrt.Intern("deref")

var Lit_10 *jrt.String = jrt.Intern("conj")

var Lit_11 *jrt.String = jrt.Intern("arbace.zip")

var Lit_12 *jrt.String = jrt.Intern("doc")

var Lit_13 *jrt.String = jrt.Intern("Functional hierarchical zipper, with navigation, editing,\n  and enumeration.  See Huet")

var Lit_14 *jrt.String = jrt.Intern("author")

var Lit_15 *jrt.String = jrt.Intern("Rich Hickey")

var Lit_16 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_17 *jrt.String = jrt.Intern("zip")

var Lit_18 *jrt.String = jrt.Intern("branch?")

var Lit_19 *jrt.String = jrt.Intern("children")

var Lit_20 *jrt.String = jrt.Intern("make-node")

var Lit_21 *jrt.String = jrt.Intern("zipper")

var Lit_22 *jrt.String = jrt.Intern("seq?")

var Lit_23 *jrt.String = jrt.Intern("identity")

var Lit_24 *jrt.String = jrt.Intern("with-meta")

var Lit_25 *jrt.String = jrt.Intern("vector?")

var Lit_26 *jrt.String = jrt.Intern("seq")

var Lit_27 *jrt.String = jrt.Intern("vec")

var Lit_28 *jrt.String = jrt.Intern("complement")

var Lit_29 *jrt.String = jrt.Intern("comp")

var Lit_30 *jrt.String = jrt.Intern("assoc")

var Lit_31 *jrt.String = jrt.Intern("content")

var Lit_32 *jrt.String = jrt.Intern("apply")

var Lit_33 *jrt.String = jrt.Intern("vector")

var Lit_34 *jrt.String = jrt.Intern("string?")

var Lit_35 *jrt.String = jrt.Intern("node")

var Lit_36 *jrt.String = jrt.Intern("pnodes")

var Lit_37 *jrt.String = jrt.Intern("l")

var Lit_38 *jrt.String = jrt.Intern("r")

var Lit_39 *jrt.String = jrt.Intern("first")

var Lit_40 *jrt.String = jrt.Intern("ppath")

var Lit_41 *jrt.String = jrt.Intern("to-array")

var Lit_42 *jrt.String = jrt.Intern("changed?")

var Lit_43 *jrt.String = jrt.Intern("peek")

var Lit_44 *jrt.String = jrt.Intern("concat")

var Lit_45 *jrt.String = jrt.Intern("cons")

var Lit_46 *jrt.String = jrt.Intern("end")

var Lit_47 *jrt.String = jrt.Intern("up")

var Lit_48 *jrt.String = jrt.Intern("last")

var Lit_49 *jrt.String = jrt.Intern("butlast")

var Lit_50 *jrt.String = jrt.Intern("pop")

var Lit_51 *jrt.String = jrt.Intern("rest")

var Lit_52 *jrt.String = jrt.Intern("down")

var Lit_53 *jrt.String = jrt.Intern("right")

var Lit_54 *jrt.String = jrt.Intern("left")

var Lit_55 *jrt.String = jrt.Intern("rightmost")

var Lit_56 *jrt.String = jrt.Intern("arbace.zip$append_child")

var Lit_57 *jrt.String = jrt.Intern("arbace.zip$branch_QMARK_")

var Lit_58 *jrt.String = jrt.Intern("arbace.zip$children")

var Lit_59 *jrt.String = jrt.Intern("called children on a leaf node")

var Lit_60 *jrt.String = jrt.Intern("arbace.zip$down")

var Lit_61 *jrt.String = jrt.Intern("arbace.zip$edit")

var Lit_62 *jrt.String = jrt.Intern("arbace.zip$end_QMARK_")

var Lit_63 *jrt.String = jrt.Intern("arbace.zip$eval703000004$loading__1927001464__auto____703000005")

var Lit_64 *jrt.String = jrt.Intern("arbace.zip$eval703000008$fn__703000009")

var Lit_65 *jrt.String = jrt.Intern("arbace.zip$insert_child")

var Lit_66 *jrt.String = jrt.Intern("arbace.zip$insert_left")

var Lit_67 *jrt.String = jrt.Intern("Insert at top")

var Lit_68 *jrt.String = jrt.Intern("arbace.zip$insert_right")

var Lit_69 *jrt.String = jrt.Intern("arbace.zip$left")

var Lit_70 *jrt.String = jrt.Intern("arbace.zip$leftmost")

var Lit_71 *jrt.String = jrt.Intern("arbace.zip$lefts")

var Lit_72 *jrt.String = jrt.Intern("arbace.zip$make_node")

var Lit_73 *jrt.String = jrt.Intern("arbace.zip$next")

var Lit_74 *jrt.String = jrt.Intern("arbace.zip$node")

var Lit_75 *jrt.String = jrt.Intern("arbace.zip$path")

var Lit_76 *jrt.String = jrt.Intern("arbace.zip$prev")

var Lit_77 *jrt.String = jrt.Intern("arbace.zip$remove")

var Lit_78 *jrt.String = jrt.Intern("Remove at top")

var Lit_79 *jrt.String = jrt.Intern("arbace.zip$replace")

var Lit_80 *jrt.String = jrt.Intern("arbace.zip$right")

var Lit_81 *jrt.String = jrt.Intern("arbace.zip$rightmost")

var Lit_82 *jrt.String = jrt.Intern("arbace.zip$rights")

var Lit_83 *jrt.String = jrt.Intern("arbace.zip$root")

var Lit_84 *jrt.String = jrt.Intern("arbace.zip$seq_zip")

var Lit_85 *jrt.String = jrt.Intern("arbace.zip$seq_zip$fn__703000013")

var Lit_86 *jrt.String = jrt.Intern("arbace.zip$up")

var Lit_87 *jrt.String = jrt.Intern("arbace.zip$vector_zip")

var Lit_88 *jrt.String = jrt.Intern("arbace.zip$vector_zip$fn__703000016")

var Lit_89 *jrt.String = jrt.Intern("arbace.zip$xml_zip")

var Lit_90 *jrt.String = jrt.Intern("arbace.zip$xml_zip$fn__703000019")

var Lit_91 *jrt.String = jrt.Intern("arbace.zip$zipper")

var Lit_92 *jrt.String = jrt.Intern("in-ns")

var Lit_93 *jrt.String = jrt.Intern("arglists")

var Lit_94 *jrt.String = jrt.Intern("root")

var Lit_95 *jrt.String = jrt.Intern("Creates a new zipper structure.\n\n  branch? is a fn that, given a node, returns true if it can have\n  children, even if it currently doesn't.\n\n  children is a fn that, given a branch node, returns a seq of its\n  children.\n\n  make-node is a fn that, given an existing node and a seq of\n  children, returns a new branch node with the supplied children.\n  root is the root node.")

var Lit_96 *jrt.String = jrt.Intern("added")

var Lit_97 *jrt.String = jrt.Intern("1.0")

var Lit_98 *jrt.String = jrt.Intern("file")

var Lit_99 *jrt.String = jrt.Intern("arbace/zip.ae")

var Lit_100 *jrt.String = jrt.Intern("seq-zip")

var Lit_101 *jrt.String = jrt.Intern("Returns a zipper for nested sequences, given a root sequence")

var Lit_102 *jrt.String = jrt.Intern("vector-zip")

var Lit_103 *jrt.String = jrt.Intern("Returns a zipper for nested vectors, given a root vector")

var Lit_104 *jrt.String = jrt.Intern("xml-zip")

var Lit_105 *jrt.String = jrt.Intern("Returns a zipper for xml elements (as from xml/parse),\n  given a root element")

var Lit_106 *jrt.String = jrt.Intern("loc")

var Lit_107 *jrt.String = jrt.Intern("Returns the node at loc")

var Lit_108 *jrt.String = jrt.Intern("Returns true if the node at loc is a branch")

var Lit_109 *jrt.String = jrt.Intern("Returns a seq of the children of node at loc, which must be a branch")

var Lit_110 *jrt.String = jrt.Intern("Returns a new branch node, given an existing node and new\n  children. The loc is only used to supply the constructor.")

var Lit_111 *jrt.String = jrt.Intern("path")

var Lit_112 *jrt.String = jrt.Intern("Returns a seq of nodes leading to this loc")

var Lit_113 *jrt.String = jrt.Intern("lefts")

var Lit_114 *jrt.String = jrt.Intern("Returns a seq of the left siblings of this loc")

var Lit_115 *jrt.String = jrt.Intern("rights")

var Lit_116 *jrt.String = jrt.Intern("Returns a seq of the right siblings of this loc")

var Lit_117 *jrt.String = jrt.Intern("Returns the loc of the leftmost child of the node at this loc, or\n  nil if no children")

var Lit_118 *jrt.String = jrt.Intern("Returns the loc of the parent of the node at this loc, or nil if at\n  the top")

var Lit_119 *jrt.String = jrt.Intern("zips all the way up and returns the root node, reflecting any\n changes.")

var Lit_120 *jrt.String = jrt.Intern("Returns the loc of the right sibling of the node at this loc, or nil")

var Lit_121 *jrt.String = jrt.Intern("Returns the loc of the rightmost sibling of the node at this loc, or self")

var Lit_122 *jrt.String = jrt.Intern("Returns the loc of the left sibling of the node at this loc, or nil")

var Lit_123 *jrt.String = jrt.Intern("leftmost")

var Lit_124 *jrt.String = jrt.Intern("Returns the loc of the leftmost sibling of the node at this loc, or self")

var Lit_125 *jrt.String = jrt.Intern("insert-left")

var Lit_126 *jrt.String = jrt.Intern("item")

var Lit_127 *jrt.String = jrt.Intern("Inserts the item as the left sibling of the node at this loc,\n without moving")

var Lit_128 *jrt.String = jrt.Intern("insert-right")

var Lit_129 *jrt.String = jrt.Intern("Inserts the item as the right sibling of the node at this loc,\n  without moving")

var Lit_130 *jrt.String = jrt.Intern("Replaces the node at this loc, without moving")

var Lit_131 *jrt.String = jrt.Intern("edit")

var Lit_132 *jrt.String = jrt.Intern("f")

var Lit_133 *jrt.String = jrt.Intern("&")

var Lit_134 *jrt.String = jrt.Intern("args")

var Lit_135 *jrt.String = jrt.Intern("Replaces the node at this loc with the value of (f node args)")

var Lit_136 *jrt.String = jrt.Intern("insert-child")

var Lit_137 *jrt.String = jrt.Intern("Inserts the item as the leftmost child of the node at this loc,\n  without moving")

var Lit_138 *jrt.String = jrt.Intern("append-child")

var Lit_139 *jrt.String = jrt.Intern("Inserts the item as the rightmost child of the node at this loc,\n  without moving")

var Lit_140 *jrt.String = jrt.Intern("Moves to the next loc in the hierarchy, depth-first. When reaching\n  the end, returns a distinguished loc detectable via end?. If already\n  at the end, stays there.")

var Lit_141 *jrt.String = jrt.Intern("prev")

var Lit_142 *jrt.String = jrt.Intern("Moves to the previous loc in the hierarchy, depth-first. If already\n  at the root, returns nil.")

var Lit_143 *jrt.String = jrt.Intern("end?")

var Lit_144 *jrt.String = jrt.Intern("Returns true if loc represents the end of a depth-first walk")

var Lit_145 *jrt.String = jrt.Intern("Removes the node at loc, returning the loc that would have preceded\n  it in a depth-first walk.")
