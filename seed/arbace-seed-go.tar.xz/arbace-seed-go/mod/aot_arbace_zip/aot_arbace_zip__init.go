//line aot_arbace_zip__init.ae:1
package aot_arbace_zip

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_zip__init_A_Load__O() any { A_arbace_zip__init_A_Init(); A_arbace_zip__init_A_Unit0__O(); A_arbace_zip__init_A_Unit1__O(); A_arbace_zip__init_A_Unit2__O(); A_arbace_zip__init_A_Unit3__O(); A_arbace_zip__init_A_Unit4__O(); A_arbace_zip__init_A_Unit5__O(); A_arbace_zip__init_A_Unit6__O(); A_arbace_zip__init_A_Unit7__O(); A_arbace_zip__init_A_Unit8__O(); A_arbace_zip__init_A_Unit9__O(); A_arbace_zip__init_A_Unit10__O(); A_arbace_zip__init_A_Unit11__O(); A_arbace_zip__init_A_Unit12__O(); A_arbace_zip__init_A_Unit13__O(); A_arbace_zip__init_A_Unit14__O(); A_arbace_zip__init_A_Unit15__O(); A_arbace_zip__init_A_Unit16__O(); A_arbace_zip__init_A_Unit17__O(); A_arbace_zip__init_A_Unit18__O(); A_arbace_zip__init_A_Unit19__O(); A_arbace_zip__init_A_Unit20__O(); A_arbace_zip__init_A_Unit21__O(); A_arbace_zip__init_A_Unit22__O(); A_arbace_zip__init_A_Unit23__O(); A_arbace_zip__init_A_Unit24__O(); A_arbace_zip__init_A_Unit25__O(); A_arbace_zip__init_A_Unit26__O(); A_arbace_zip__init_A_Unit27__O(); A_arbace_zip__init_A_Unit28__O(); A_arbace_zip__init_A_Unit29__O(); A_arbace_zip__init_A_Unit30__O(); A_arbace_zip__init_A_Unit31__O(); A_arbace_zip__init_A_Unit32__O(); return nil }






func A_arbace_zip__init_A_Unit0__O() any { A_arbace_zip__init_A_Init(); lang.Compiler_AOT_At_I_I__V(12, 1); return lang.IFn_Cast(jrt.NN(A_arbace_zip__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_zip__init_A_const_1) }
//line :12:1
func A_arbace_zip__init_A_Unit1__O() any { A_arbace_zip__init_A_Init(); lang.Compiler_AOT_At_I_I__V(12, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_zip__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_zip__init_A_const_2)) }
//line :12:1
func A_arbace_zip__init_A_Unit2__O() any { A_arbace_zip__init_A_Init(); lang.Compiler_AOT_At_I_I__V(12, 1); var tmp1 any = A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_New(); var tmp2 *jrt.Class; A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_Init(); tmp2 = A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :12:1
func A_arbace_zip__init_A_Unit3__O() any { A_arbace_zip__init_A_Init(); lang.Compiler_AOT_At_I_I__V(12, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_zip__init_A_const_1)).Equals_O__Z(A_arbace_zip__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_zip_eval703000008_fn__703000009_A_New(); var tmp2 *jrt.Class; A_arbace_zip_eval703000008_fn__703000009_A_Init(); tmp2 = A_arbace_zip_eval703000008_fn__703000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }





func A_arbace_zip__init_A_Unit4__O() any { A_arbace_zip__init_A_Init(); lang.Compiler_AOT_At_I_I__V(18, 1); var tmp1 *lang.Var = A_arbace_zip__init_A_const_4; var tmp2 any = A_arbace_zip_zipper_A_New(); var tmp3 *jrt.Class; A_arbace_zip_zipper_A_Init(); tmp3 = A_arbace_zip_zipper_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_zip__init_A_const_4; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_zip__init_A_const_5)); return A_arbace_zip__init_A_const_4.Ref() }
















func A_arbace_zip__init_A_Unit5__O() any { A_arbace_zip__init_A_Init(); lang.Compiler_AOT_At_I_I__V(35, 1); var tmp1 *lang.Var = A_arbace_zip__init_A_const_6; var tmp2 any = A_arbace_zip_seq_zip_A_New(); var tmp3 *jrt.Class; A_arbace_zip_seq_zip_A_Init(); tmp3 = A_arbace_zip_seq_zip_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_zip__init_A_const_6; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_zip__init_A_const_7)); return A_arbace_zip__init_A_const_6.Ref() }








func A_arbace_zip__init_A_Unit6__O() any { A_arbace_zip__init_A_Init(); lang.Compiler_AOT_At_I_I__V(44, 1); var tmp1 *lang.Var = A_arbace_zip__init_A_const_8; var tmp2 any = A_arbace_zip_vector_zip_A_New(); var tmp3 *jrt.Class; A_arbace_zip_vector_zip_A_Init(); tmp3 = A_arbace_zip_vector_zip_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_zip__init_A_const_8; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_zip__init_A_const_9)); return A_arbace_zip__init_A_const_8.Ref() }








func A_arbace_zip__init_A_Unit7__O() any { A_arbace_zip__init_A_Init(); lang.Compiler_AOT_At_I_I__V(53, 1); var tmp1 *lang.Var = A_arbace_zip__init_A_const_10; var tmp2 any = A_arbace_zip_xml_zip_A_New(); var tmp3 *jrt.Class; A_arbace_zip_xml_zip_A_Init(); tmp3 = A_arbace_zip_xml_zip_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_zip__init_A_const_10; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_zip__init_A_const_11)); return A_arbace_zip__init_A_const_10.Ref() }










func A_arbace_zip__init_A_Unit8__O() any { A_arbace_zip__init_A_Init(); lang.Compiler_AOT_At_I_I__V(64, 1); var tmp1 *lang.Var = A_arbace_zip__init_A_const_12; var tmp2 any = A_arbace_zip_node_A_New(); var tmp3 *jrt.Class; A_arbace_zip_node_A_Init(); tmp3 = A_arbace_zip_node_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_zip__init_A_const_12; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_zip__init_A_const_13)); return A_arbace_zip__init_A_const_12.Ref() }




func A_arbace_zip__init_A_Unit9__O() any { A_arbace_zip__init_A_Init(); lang.Compiler_AOT_At_I_I__V(69, 1); var tmp1 *lang.Var = A_arbace_zip__init_A_const_14; var tmp2 any = A_arbace_zip_branch_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_zip_branch_QMARK__A_Init(); tmp3 = A_arbace_zip_branch_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_zip__init_A_const_14; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_zip__init_A_const_15)); return A_arbace_zip__init_A_const_14.Ref() }





func A_arbace_zip__init_A_Unit10__O() any { A_arbace_zip__init_A_Init(); lang.Compiler_AOT_At_I_I__V(75, 1); var tmp1 *lang.Var = A_arbace_zip__init_A_const_16; var tmp2 any = A_arbace_zip_children_A_New(); var tmp3 *jrt.Class; A_arbace_zip_children_A_Init(); tmp3 = A_arbace_zip_children_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_zip__init_A_const_16; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_zip__init_A_const_17)); return A_arbace_zip__init_A_const_16.Ref() }







func A_arbace_zip__init_A_Unit11__O() any { A_arbace_zip__init_A_Init(); lang.Compiler_AOT_At_I_I__V(83, 1); var tmp1 *lang.Var = A_arbace_zip__init_A_const_18; var tmp2 any = A_arbace_zip_make_node_A_New(); var tmp3 *jrt.Class; A_arbace_zip_make_node_A_Init(); tmp3 = A_arbace_zip_make_node_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_zip__init_A_const_18; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_zip__init_A_const_19)); return A_arbace_zip__init_A_const_18.Ref() }






func A_arbace_zip__init_A_Unit12__O() any { A_arbace_zip__init_A_Init(); lang.Compiler_AOT_At_I_I__V(90, 1); var tmp1 *lang.Var = A_arbace_zip__init_A_const_20; var tmp2 any = A_arbace_zip_path_A_New(); var tmp3 *jrt.Class; A_arbace_zip_path_A_Init(); tmp3 = A_arbace_zip_path_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_zip__init_A_const_20; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_zip__init_A_const_21)); return A_arbace_zip__init_A_const_20.Ref() }





func A_arbace_zip__init_A_Unit13__O() any { A_arbace_zip__init_A_Init(); lang.Compiler_AOT_At_I_I__V(96, 1); var tmp1 *lang.Var = A_arbace_zip__init_A_const_22; var tmp2 any = A_arbace_zip_lefts_A_New(); var tmp3 *jrt.Class; A_arbace_zip_lefts_A_Init(); tmp3 = A_arbace_zip_lefts_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_zip__init_A_const_22; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_zip__init_A_const_23)); return A_arbace_zip__init_A_const_22.Ref() }





func A_arbace_zip__init_A_Unit14__O() any { A_arbace_zip__init_A_Init(); lang.Compiler_AOT_At_I_I__V(102, 1); var tmp1 *lang.Var = A_arbace_zip__init_A_const_24; var tmp2 any = A_arbace_zip_rights_A_New(); var tmp3 *jrt.Class; A_arbace_zip_rights_A_Init(); tmp3 = A_arbace_zip_rights_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_zip__init_A_const_24; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_zip__init_A_const_25)); return A_arbace_zip__init_A_const_24.Ref() }





func A_arbace_zip__init_A_Unit15__O() any { A_arbace_zip__init_A_Init(); lang.Compiler_AOT_At_I_I__V(108, 1); var tmp1 *lang.Var = A_arbace_zip__init_A_const_26; var tmp2 any = A_arbace_zip_down_A_New(); var tmp3 *jrt.Class; A_arbace_zip_down_A_Init(); tmp3 = A_arbace_zip_down_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_zip__init_A_const_26; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_zip__init_A_const_27)); return A_arbace_zip__init_A_const_26.Ref() }













func A_arbace_zip__init_A_Unit16__O() any { A_arbace_zip__init_A_Init(); lang.Compiler_AOT_At_I_I__V(122, 1); var tmp1 *lang.Var = A_arbace_zip__init_A_const_28; var tmp2 any = A_arbace_zip_up_A_New(); var tmp3 *jrt.Class; A_arbace_zip_up_A_Init(); tmp3 = A_arbace_zip_up_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_zip__init_A_const_28; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_zip__init_A_const_29)); return A_arbace_zip__init_A_const_28.Ref() }













func A_arbace_zip__init_A_Unit17__O() any { A_arbace_zip__init_A_Init(); lang.Compiler_AOT_At_I_I__V(136, 1); var tmp1 *lang.Var = A_arbace_zip__init_A_const_30; var tmp2 any = A_arbace_zip_root_A_New(); var tmp3 *jrt.Class; A_arbace_zip_root_A_Init(); tmp3 = A_arbace_zip_root_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_zip__init_A_const_30; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_zip__init_A_const_31)); return A_arbace_zip__init_A_const_30.Ref() }











func A_arbace_zip__init_A_Unit18__O() any { A_arbace_zip__init_A_Init(); lang.Compiler_AOT_At_I_I__V(148, 1); var tmp1 *lang.Var = A_arbace_zip__init_A_const_32; var tmp2 any = A_arbace_zip_right_A_New(); var tmp3 *jrt.Class; A_arbace_zip_right_A_Init(); tmp3 = A_arbace_zip_right_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_zip__init_A_const_32; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_zip__init_A_const_33)); return A_arbace_zip__init_A_const_32.Ref() }







func A_arbace_zip__init_A_Unit19__O() any { A_arbace_zip__init_A_Init(); lang.Compiler_AOT_At_I_I__V(156, 1); var tmp1 *lang.Var = A_arbace_zip__init_A_const_34; var tmp2 any = A_arbace_zip_rightmost_A_New(); var tmp3 *jrt.Class; A_arbace_zip_rightmost_A_Init(); tmp3 = A_arbace_zip_rightmost_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_zip__init_A_const_34; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_zip__init_A_const_35)); return A_arbace_zip__init_A_const_34.Ref() }








func A_arbace_zip__init_A_Unit20__O() any { A_arbace_zip__init_A_Init(); lang.Compiler_AOT_At_I_I__V(165, 1); var tmp1 *lang.Var = A_arbace_zip__init_A_const_36; var tmp2 any = A_arbace_zip_left_A_New(); var tmp3 *jrt.Class; A_arbace_zip_left_A_Init(); tmp3 = A_arbace_zip_left_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_zip__init_A_const_36; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_zip__init_A_const_37)); return A_arbace_zip__init_A_const_36.Ref() }







func A_arbace_zip__init_A_Unit21__O() any { A_arbace_zip__init_A_Init(); lang.Compiler_AOT_At_I_I__V(173, 1); var tmp1 *lang.Var = A_arbace_zip__init_A_const_38; var tmp2 any = A_arbace_zip_leftmost_A_New(); var tmp3 *jrt.Class; A_arbace_zip_leftmost_A_Init(); tmp3 = A_arbace_zip_leftmost_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_zip__init_A_const_38; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_zip__init_A_const_39)); return A_arbace_zip__init_A_const_38.Ref() }








func A_arbace_zip__init_A_Unit22__O() any { A_arbace_zip__init_A_Init(); lang.Compiler_AOT_At_I_I__V(182, 1); var tmp1 *lang.Var = A_arbace_zip__init_A_const_40; var tmp2 any = A_arbace_zip_insert_left_A_New(); var tmp3 *jrt.Class; A_arbace_zip_insert_left_A_Init(); tmp3 = A_arbace_zip_insert_left_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_zip__init_A_const_40; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_zip__init_A_const_41)); return A_arbace_zip__init_A_const_40.Ref() }









func A_arbace_zip__init_A_Unit23__O() any { A_arbace_zip__init_A_Init(); lang.Compiler_AOT_At_I_I__V(192, 1); var tmp1 *lang.Var = A_arbace_zip__init_A_const_42; var tmp2 any = A_arbace_zip_insert_right_A_New(); var tmp3 *jrt.Class; A_arbace_zip_insert_right_A_Init(); tmp3 = A_arbace_zip_insert_right_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_zip__init_A_const_42; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_zip__init_A_const_43)); return A_arbace_zip__init_A_const_42.Ref() }









func A_arbace_zip__init_A_Unit24__O() any { A_arbace_zip__init_A_Init(); lang.Compiler_AOT_At_I_I__V(202, 1); var tmp1 *lang.Var = A_arbace_zip__init_A_const_44; var tmp2 any = A_arbace_zip_replace_A_New(); var tmp3 *jrt.Class; A_arbace_zip_replace_A_Init(); tmp3 = A_arbace_zip_replace_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_zip__init_A_const_44; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_zip__init_A_const_45)); return A_arbace_zip__init_A_const_44.Ref() }






func A_arbace_zip__init_A_Unit25__O() any { A_arbace_zip__init_A_Init(); lang.Compiler_AOT_At_I_I__V(209, 1); var tmp1 *lang.Var = A_arbace_zip__init_A_const_46; var tmp2 any = A_arbace_zip_edit_A_New(); var tmp3 *jrt.Class; A_arbace_zip_edit_A_Init(); tmp3 = A_arbace_zip_edit_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_zip__init_A_const_46; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_zip__init_A_const_47)); return A_arbace_zip__init_A_const_46.Ref() }





func A_arbace_zip__init_A_Unit26__O() any { A_arbace_zip__init_A_Init(); lang.Compiler_AOT_At_I_I__V(215, 1); var tmp1 *lang.Var = A_arbace_zip__init_A_const_48; var tmp2 any = A_arbace_zip_insert_child_A_New(); var tmp3 *jrt.Class; A_arbace_zip_insert_child_A_Init(); tmp3 = A_arbace_zip_insert_child_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_zip__init_A_const_48; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_zip__init_A_const_49)); return A_arbace_zip__init_A_const_48.Ref() }






func A_arbace_zip__init_A_Unit27__O() any { A_arbace_zip__init_A_Init(); lang.Compiler_AOT_At_I_I__V(222, 1); var tmp1 *lang.Var = A_arbace_zip__init_A_const_50; var tmp2 any = A_arbace_zip_append_child_A_New(); var tmp3 *jrt.Class; A_arbace_zip_append_child_A_Init(); tmp3 = A_arbace_zip_append_child_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_zip__init_A_const_50; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_zip__init_A_const_51)); return A_arbace_zip__init_A_const_50.Ref() }






func A_arbace_zip__init_A_Unit28__O() any { A_arbace_zip__init_A_Init(); lang.Compiler_AOT_At_I_I__V(229, 1); var tmp1 *lang.Var = A_arbace_zip__init_A_const_52; var tmp2 any = A_arbace_zip_next_A_New(); var tmp3 *jrt.Class; A_arbace_zip_next_A_Init(); tmp3 = A_arbace_zip_next_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_zip__init_A_const_52; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_zip__init_A_const_53)); return A_arbace_zip__init_A_const_52.Ref() }















func A_arbace_zip__init_A_Unit29__O() any { A_arbace_zip__init_A_Init(); lang.Compiler_AOT_At_I_I__V(245, 1); var tmp1 *lang.Var = A_arbace_zip__init_A_const_54; var tmp2 any = A_arbace_zip_prev_A_New(); var tmp3 *jrt.Class; A_arbace_zip_prev_A_Init(); tmp3 = A_arbace_zip_prev_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_zip__init_A_const_54; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_zip__init_A_const_55)); return A_arbace_zip__init_A_const_54.Ref() }











func A_arbace_zip__init_A_Unit30__O() any { A_arbace_zip__init_A_Init(); lang.Compiler_AOT_At_I_I__V(257, 1); var tmp1 *lang.Var = A_arbace_zip__init_A_const_56; var tmp2 any = A_arbace_zip_end_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_zip_end_QMARK__A_Init(); tmp3 = A_arbace_zip_end_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_zip__init_A_const_56; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_zip__init_A_const_57)); return A_arbace_zip__init_A_const_56.Ref() }





func A_arbace_zip__init_A_Unit31__O() any { A_arbace_zip__init_A_Init(); lang.Compiler_AOT_At_I_I__V(263, 1); var tmp1 *lang.Var = A_arbace_zip__init_A_const_58; var tmp2 any = A_arbace_zip_remove_A_New(); var tmp3 *jrt.Class; A_arbace_zip_remove_A_Init(); tmp3 = A_arbace_zip_remove_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_zip__init_A_const_58; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_zip__init_A_const_59)); return A_arbace_zip__init_A_const_58.Ref() }
















func A_arbace_zip__init_A_Unit32__O() any { A_arbace_zip__init_A_Init(); lang.Compiler_AOT_At_I_I__V(280, 1); return nil }



type A_arbace_zip__init_A struct{ jrt.Object }

var A_arbace_zip__init_A_const_0 *lang.Var

var A_arbace_zip__init_A_const_1 any

var A_arbace_zip__init_A_const_2 any

var A_arbace_zip__init_A_const_3 any

var A_arbace_zip__init_A_const_4 *lang.Var

var A_arbace_zip__init_A_const_5 any

var A_arbace_zip__init_A_const_6 *lang.Var

var A_arbace_zip__init_A_const_7 any

var A_arbace_zip__init_A_const_8 *lang.Var

var A_arbace_zip__init_A_const_9 any

var A_arbace_zip__init_A_const_10 *lang.Var

var A_arbace_zip__init_A_const_11 any

var A_arbace_zip__init_A_const_12 *lang.Var

var A_arbace_zip__init_A_const_13 any

var A_arbace_zip__init_A_const_14 *lang.Var

var A_arbace_zip__init_A_const_15 any

var A_arbace_zip__init_A_const_16 *lang.Var

var A_arbace_zip__init_A_const_17 any

var A_arbace_zip__init_A_const_18 *lang.Var

var A_arbace_zip__init_A_const_19 any

var A_arbace_zip__init_A_const_20 *lang.Var

var A_arbace_zip__init_A_const_21 any

var A_arbace_zip__init_A_const_22 *lang.Var

var A_arbace_zip__init_A_const_23 any

var A_arbace_zip__init_A_const_24 *lang.Var

var A_arbace_zip__init_A_const_25 any

var A_arbace_zip__init_A_const_26 *lang.Var

var A_arbace_zip__init_A_const_27 any

var A_arbace_zip__init_A_const_28 *lang.Var

var A_arbace_zip__init_A_const_29 any

var A_arbace_zip__init_A_const_30 *lang.Var

var A_arbace_zip__init_A_const_31 any

var A_arbace_zip__init_A_const_32 *lang.Var

var A_arbace_zip__init_A_const_33 any

var A_arbace_zip__init_A_const_34 *lang.Var

var A_arbace_zip__init_A_const_35 any

var A_arbace_zip__init_A_const_36 *lang.Var

var A_arbace_zip__init_A_const_37 any

var A_arbace_zip__init_A_const_38 *lang.Var

var A_arbace_zip__init_A_const_39 any

var A_arbace_zip__init_A_const_40 *lang.Var

var A_arbace_zip__init_A_const_41 any

var A_arbace_zip__init_A_const_42 *lang.Var

var A_arbace_zip__init_A_const_43 any

var A_arbace_zip__init_A_const_44 *lang.Var

var A_arbace_zip__init_A_const_45 any

var A_arbace_zip__init_A_const_46 *lang.Var

var A_arbace_zip__init_A_const_47 any

var A_arbace_zip__init_A_const_48 *lang.Var

var A_arbace_zip__init_A_const_49 any

var A_arbace_zip__init_A_const_50 *lang.Var

var A_arbace_zip__init_A_const_51 any

var A_arbace_zip__init_A_const_52 *lang.Var

var A_arbace_zip__init_A_const_53 any

var A_arbace_zip__init_A_const_54 *lang.Var

var A_arbace_zip__init_A_const_55 any

var A_arbace_zip__init_A_const_56 *lang.Var

var A_arbace_zip__init_A_const_57 any

var A_arbace_zip__init_A_const_58 *lang.Var

var A_arbace_zip__init_A_const_59 any

var A_arbace_zip__init_A_init jrt.ClassInit

func A_arbace_zip__init_A_Init() { if !A_arbace_zip__init_A_init.Done() { A_arbace_zip__init_A_init.Run(A_arbace_zip__init_A_clinit) } }

func A_arbace_zip__init_A_clinit() { A_arbace_zip__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_92); A_arbace_zip__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_11)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15))); A_arbace_zip__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15)); A_arbace_zip__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_zip__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_11, Lit_21); A_arbace_zip__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_18).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_19).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_20).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_94).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_95, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), Lit_97, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(18).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_zip__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_11, Lit_100); A_arbace_zip__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_94).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_101, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), Lit_97, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(35).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_zip__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_11, Lit_102); A_arbace_zip__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_94).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_103, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), Lit_97, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(44).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_zip__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_11, Lit_104); A_arbace_zip__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_94).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_105, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), Lit_97, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(53).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_zip__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_11, Lit_35); A_arbace_zip__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_106).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_107, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), Lit_97, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(64).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_zip__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_11, Lit_18); A_arbace_zip__init_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_106).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_108, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), Lit_97, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(69).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_zip__init_A_const_16 = lang.RT_Var_String_String__Var(Lit_11, Lit_19); A_arbace_zip__init_A_const_17 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_106).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_109, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), Lit_97, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(75).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_zip__init_A_const_18 = lang.RT_Var_String_String__Var(Lit_11, Lit_20); A_arbace_zip__init_A_const_19 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_106).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_35).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_19).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_110, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), Lit_97, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(83).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_zip__init_A_const_20 = lang.RT_Var_String_String__Var(Lit_11, Lit_111); A_arbace_zip__init_A_const_21 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_106).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_112, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), Lit_97, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(90).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_zip__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_11, Lit_113); A_arbace_zip__init_A_const_23 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_106).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_114, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), Lit_97, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(96).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_zip__init_A_const_24 = lang.RT_Var_String_String__Var(Lit_11, Lit_115); A_arbace_zip__init_A_const_25 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_106).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_116, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), Lit_97, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(102).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_zip__init_A_const_26 = lang.RT_Var_String_String__Var(Lit_11, Lit_52); A_arbace_zip__init_A_const_27 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_106).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_117, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), Lit_97, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(108).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_zip__init_A_const_28 = lang.RT_Var_String_String__Var(Lit_11, Lit_47); A_arbace_zip__init_A_const_29 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_106).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_118, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), Lit_97, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(122).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_zip__init_A_const_30 = lang.RT_Var_String_String__Var(Lit_11, Lit_94); A_arbace_zip__init_A_const_31 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_106).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_119, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), Lit_97, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(136).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_zip__init_A_const_32 = lang.RT_Var_String_String__Var(Lit_11, Lit_53); A_arbace_zip__init_A_const_33 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_106).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_120, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), Lit_97, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(148).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_zip__init_A_const_34 = lang.RT_Var_String_String__Var(Lit_11, Lit_55); A_arbace_zip__init_A_const_35 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_106).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_121, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), Lit_97, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(156).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_zip__init_A_const_36 = lang.RT_Var_String_String__Var(Lit_11, Lit_54); A_arbace_zip__init_A_const_37 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_106).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_122, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), Lit_97, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(165).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_zip__init_A_const_38 = lang.RT_Var_String_String__Var(Lit_11, Lit_123); A_arbace_zip__init_A_const_39 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_106).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_124, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), Lit_97, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(173).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_zip__init_A_const_40 = lang.RT_Var_String_String__Var(Lit_11, Lit_125); A_arbace_zip__init_A_const_41 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_106).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_126).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_127, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), Lit_97, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(182).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_zip__init_A_const_42 = lang.RT_Var_String_String__Var(Lit_11, Lit_128); A_arbace_zip__init_A_const_43 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_106).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_126).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_129, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), Lit_97, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(192).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_zip__init_A_const_44 = lang.RT_Var_String_String__Var(Lit_11, Lit_3); A_arbace_zip__init_A_const_45 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_106).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_35).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_130, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), Lit_97, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(202).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_zip__init_A_const_46 = lang.RT_Var_String_String__Var(Lit_11, Lit_131); A_arbace_zip__init_A_const_47 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_106).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_132).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_133).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_134).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_135, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), Lit_97, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(209).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_zip__init_A_const_48 = lang.RT_Var_String_String__Var(Lit_11, Lit_136); A_arbace_zip__init_A_const_49 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_106).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_126).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_137, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), Lit_97, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(215).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_zip__init_A_const_50 = lang.RT_Var_String_String__Var(Lit_11, Lit_138); A_arbace_zip__init_A_const_51 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_106).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_126).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_139, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), Lit_97, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(222).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_zip__init_A_const_52 = lang.RT_Var_String_String__Var(Lit_11, Lit_5); A_arbace_zip__init_A_const_53 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_106).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_140, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), Lit_97, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(229).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_zip__init_A_const_54 = lang.RT_Var_String_String__Var(Lit_11, Lit_141); A_arbace_zip__init_A_const_55 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_106).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_142, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), Lit_97, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(245).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_zip__init_A_const_56 = lang.RT_Var_String_String__Var(Lit_11, Lit_143); A_arbace_zip__init_A_const_57 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_106).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_144, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), Lit_97, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(257).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_zip__init_A_const_58 = lang.RT_Var_String_String__Var(Lit_11, Lit_4); A_arbace_zip__init_A_const_59 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_106).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_145, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), Lit_97, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(263).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)) }

func A_arbace_zip__init_A_New() *A_arbace_zip__init_A { A_arbace_zip__init_A_Init(); t := &A_arbace_zip__init_A{}; t.Ctor(); return t }

func (t *A_arbace_zip__init_A) Ctor() {}

func (t *A_arbace_zip__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip__init_A) GetClass__Class() *jrt.Class { return A_arbace_zip__init_A_class }

func (t *A_arbace_zip__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip__init_A); return ok }

func A_arbace_zip__init_A_Cast(x any) *A_arbace_zip__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip__init_A_class)) }; return v }
