//line aot_arbace_zip.ae:1
package aot_arbace_zip

import (
	"arbace/jrt"
	"arbace/lang"
)





func A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_New() *A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A { A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_Init(); t := &A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A{}; t.Ctor(); return t }
//line :12:1
func (t *A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A) Ctor() {}
//line :12:1
func (t *A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_zip_A_Init(); tmp4 = A_arbace_zip_A_const_0; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_zip_A_Init(); tmp6 = A_arbace_zip_A_const_1; var tmp7 any = tmp6; var tmp8 *lang.Keyword; A_arbace_zip_A_Init(); tmp8 = A_arbace_zip_A_const_2; var tmp9 any = tmp8.Ref(); var tmp10 any; A_arbace_zip_A_Init(); tmp10 = A_arbace_zip_A_const_3; tmp3 = tmp5.Invoke_O_O_O__O(tmp7, tmp9, tmp10) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp11 != nil { panic(tmp11) }; return tmp3 }
//line :12:1
func A_arbace_zip_eval703000008_fn__703000009_A_New() *A_arbace_zip_eval703000008_fn__703000009_A { A_arbace_zip_eval703000008_fn__703000009_A_Init(); t := &A_arbace_zip_eval703000008_fn__703000009_A{}; t.Ctor(); return t }
//line :12:1
func (t *A_arbace_zip_eval703000008_fn__703000009_A) Ctor() {}
//line :12:1
func (t *A_arbace_zip_eval703000008_fn__703000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_zip_A_Init(); tmp1 = A_arbace_zip_A_const_4; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_zip_A_Init(); tmp3 = A_arbace_zip_A_const_5; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_zip_A_Init(); tmp5 = A_arbace_zip_A_const_8; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_zip_A_Init(); tmp7 = A_arbace_zip_A_const_6; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_zip_A_Init(); tmp9 = A_arbace_zip_A_const_7; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }





func A_arbace_zip_zipper_A_New() *A_arbace_zip_zipper_A { A_arbace_zip_zipper_A_Init(); t := &A_arbace_zip_zipper_A{}; t.Ctor(); return t }
//line :18:1
func (t *A_arbace_zip_zipper_A) Ctor() {}
//line :18:1
func (t *A_arbace_zip_zipper_A) Invoke_O_O_O_O_O__O(self, branch_QMARK___0, children__1, make_node__2, root__3 any) any { var tmp1 lang.IObj = lang.IObj_Cast(lang.Tuple_Create_O_O__IPersistentVector(root__3, nil)); var tmp2 *lang.Keyword; A_arbace_zip_A_Init(); tmp2 = A_arbace_zip_A_const_9; var tmp3 any = tmp2.Ref(); var tmp4 *lang.Keyword; A_arbace_zip_A_Init(); tmp4 = A_arbace_zip_A_const_10; var tmp5 any = tmp4.Ref(); var tmp6 *lang.Keyword; A_arbace_zip_A_Init(); tmp6 = A_arbace_zip_A_const_11; return tmp1.WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3, branch_QMARK___0, tmp5, children__1, tmp6.Ref(), make_node__2))) }
















func A_arbace_zip_seq_zip_A_New() *A_arbace_zip_seq_zip_A { A_arbace_zip_seq_zip_A_Init(); t := &A_arbace_zip_seq_zip_A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_zip_seq_zip_A) Ctor() {}
//line :35:1
func (t *A_arbace_zip_seq_zip_A) Invoke_O_O__O(self, root__0 any) any {



	var tmp1 *lang.Var; A_arbace_zip_A_Init(); tmp1 = A_arbace_zip_A_const_12; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_zip_A_Init(); tmp3 = A_arbace_zip_A_const_13; var tmp4 any = jrt.NN(tmp3).GetRawRoot__O(); var tmp5 *lang.Var; A_arbace_zip_A_Init(); tmp5 = A_arbace_zip_A_const_14; var tmp6 any = jrt.NN(tmp5).GetRawRoot__O(); var tmp7 any = A_arbace_zip_seq_zip_fn__703000013_A_New(); var tmp8 *jrt.Class; A_arbace_zip_seq_zip_fn__703000013_A_Init(); tmp8 = A_arbace_zip_seq_zip_fn__703000013_A_fn_class; return tmp2.Invoke_O_O_O_O__O(tmp4, tmp6, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), root__0)
}
func A_arbace_zip_seq_zip_fn__703000013_A_New() *A_arbace_zip_seq_zip_fn__703000013_A { A_arbace_zip_seq_zip_fn__703000013_A_Init(); t := &A_arbace_zip_seq_zip_fn__703000013_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_zip_seq_zip_fn__703000013_A) Ctor() {}
//line :41:1
func (t *A_arbace_zip_seq_zip_fn__703000013_A) Invoke_O_O_O__O(self, node__1, children__2 any) any { var tmp1 *lang.Var; A_arbace_zip_A_Init(); tmp1 = A_arbace_zip_A_const_15; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(children__2, lang.RT_Meta_O__IPersistentMap(node__1)) }


func A_arbace_zip_vector_zip_A_New() *A_arbace_zip_vector_zip_A { A_arbace_zip_vector_zip_A_Init(); t := &A_arbace_zip_vector_zip_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_zip_vector_zip_A) Ctor() {}
//line :44:1
func (t *A_arbace_zip_vector_zip_A) Invoke_O_O__O(self, root__0 any) any {



	var tmp1 *lang.Var; A_arbace_zip_A_Init(); tmp1 = A_arbace_zip_A_const_12; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_zip_A_Init(); tmp3 = A_arbace_zip_A_const_16; var tmp4 any = jrt.NN(tmp3).GetRawRoot__O(); var tmp5 *lang.Var; A_arbace_zip_A_Init(); tmp5 = A_arbace_zip_A_const_17; var tmp6 any = jrt.NN(tmp5).GetRawRoot__O(); var tmp7 any = A_arbace_zip_vector_zip_fn__703000016_A_New(); var tmp8 *jrt.Class; A_arbace_zip_vector_zip_fn__703000016_A_Init(); tmp8 = A_arbace_zip_vector_zip_fn__703000016_A_fn_class; return tmp2.Invoke_O_O_O_O__O(tmp4, tmp6, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), root__0)
}
func A_arbace_zip_vector_zip_fn__703000016_A_New() *A_arbace_zip_vector_zip_fn__703000016_A { A_arbace_zip_vector_zip_fn__703000016_A_Init(); t := &A_arbace_zip_vector_zip_fn__703000016_A{}; t.Ctor(); return t }
//line :50:1
func (t *A_arbace_zip_vector_zip_fn__703000016_A) Ctor() {}
//line :50:1
func (t *A_arbace_zip_vector_zip_fn__703000016_A) Invoke_O_O_O__O(self, node__1, children__2 any) any { var tmp1 *lang.Var; A_arbace_zip_A_Init(); tmp1 = A_arbace_zip_A_const_15; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_zip_A_Init(); tmp3 = A_arbace_zip_A_const_18; return tmp2.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(children__2), lang.RT_Meta_O__IPersistentMap(node__1)) }


func A_arbace_zip_xml_zip_A_New() *A_arbace_zip_xml_zip_A { A_arbace_zip_xml_zip_A_Init(); t := &A_arbace_zip_xml_zip_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_zip_xml_zip_A) Ctor() {}
//line :53:1
func (t *A_arbace_zip_xml_zip_A) Invoke_O_O__O(self, root__0 any) any {




	var tmp1 *lang.Var; A_arbace_zip_A_Init(); tmp1 = A_arbace_zip_A_const_12; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_zip_A_Init(); tmp3 = A_arbace_zip_A_const_19; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_zip_A_Init(); tmp5 = A_arbace_zip_A_const_25; var tmp6 any = tmp4.Invoke_O__O(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_zip_A_Init(); tmp7 = A_arbace_zip_A_const_20; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_zip_A_Init(); tmp9 = A_arbace_zip_A_const_17; var tmp10 any = jrt.NN(tmp9).GetRawRoot__O(); var tmp11 *lang.Keyword; A_arbace_zip_A_Init(); tmp11 = A_arbace_zip_A_const_22; var tmp12 any = tmp8.Invoke_O_O__O(tmp10, tmp11.Ref()); var tmp13 any = A_arbace_zip_xml_zip_fn__703000019_A_New(); var tmp14 *jrt.Class; A_arbace_zip_xml_zip_fn__703000019_A_Init(); tmp14 = A_arbace_zip_xml_zip_fn__703000019_A_fn_class; return tmp2.Invoke_O_O_O_O__O(tmp6, tmp12, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil), root__0)
}
func A_arbace_zip_xml_zip_fn__703000019_A_New() *A_arbace_zip_xml_zip_fn__703000019_A { A_arbace_zip_xml_zip_fn__703000019_A_Init(); t := &A_arbace_zip_xml_zip_fn__703000019_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_zip_xml_zip_fn__703000019_A) Ctor() {}
//line :60:1
func (t *A_arbace_zip_xml_zip_fn__703000019_A) Invoke_O_O_O__O(self, node__1, children__2 any) any {
	var tmp1 *lang.Var; A_arbace_zip_A_Init(); tmp1 = A_arbace_zip_A_const_21; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_zip_A_Init(); tmp3 = A_arbace_zip_A_const_22; var tmp4 any = tmp3.Ref(); var tmp5 any; var and__1927000168__auto____3 any = children__2; if jrt.A2g_Truth(and__1927000168__auto____3) { var tmp6 *lang.Var; A_arbace_zip_A_Init(); tmp6 = A_arbace_zip_A_const_23; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_zip_A_Init(); tmp8 = A_arbace_zip_A_const_24; tmp5 = tmp7.Invoke_O_O__O(jrt.NN(tmp8).GetRawRoot__O(), children__2) } else { tmp5 = and__1927000168__auto____3 }; return tmp2.Invoke_O_O_O__O(node__1, tmp4, tmp5)
}

func A_arbace_zip_node_A_New() *A_arbace_zip_node_A { A_arbace_zip_node_A_Init(); t := &A_arbace_zip_node_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_zip_node_A) Ctor() {}
//line :64:1
func (t *A_arbace_zip_node_A) Invoke_O_O__O(self, loc__0 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(loc__0); var tmp2 any; A_arbace_zip_A_Init(); tmp2 = A_arbace_zip_A_const_26; return tmp1.Invoke_O__O(tmp2)
}
func A_arbace_zip_branch_QMARK__A_New() *A_arbace_zip_branch_QMARK__A { A_arbace_zip_branch_QMARK__A_Init(); t := &A_arbace_zip_branch_QMARK__A{}; t.Ctor(); return t }
//line :69:1
func (t *A_arbace_zip_branch_QMARK__A) Ctor() {}
//line :69:1
func (t *A_arbace_zip_branch_QMARK__A) Invoke_O_O__O(self, loc__0 any) any {



	var tmp1 *lang.Keyword; A_arbace_zip_A_Init(); tmp1 = A_arbace_zip_A_const_9; var tmp2 *lang.Keyword = tmp1; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(loc__0))); var tmp4 *lang.Var; A_arbace_zip_A_Init(); tmp4 = A_arbace_zip_A_const_27; return tmp3.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(loc__0))
}
func A_arbace_zip_children_A_New() *A_arbace_zip_children_A { A_arbace_zip_children_A_Init(); t := &A_arbace_zip_children_A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_zip_children_A) Ctor() {}
//line :75:1
func (t *A_arbace_zip_children_A) Invoke_O_O__O(self, loc__0 any) any {



	var tmp1 *lang.Var; A_arbace_zip_A_Init(); tmp1 = A_arbace_zip_A_const_28; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(loc__0)) {
		var tmp2 *lang.Keyword; A_arbace_zip_A_Init(); tmp2 = A_arbace_zip_A_const_10; var tmp3 *lang.Keyword = tmp2; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(loc__0))); var tmp5 *lang.Var; A_arbace_zip_A_Init(); tmp5 = A_arbace_zip_A_const_27; return tmp4.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(loc__0)) } else {
//line :79:1
			panic(jrt.Thrown(jrt.Exception_New_String(Lit_59)))
		}
}

func A_arbace_zip_make_node_A_New() *A_arbace_zip_make_node_A { A_arbace_zip_make_node_A_Init(); t := &A_arbace_zip_make_node_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_zip_make_node_A) Ctor() {}
//line :83:1
func (t *A_arbace_zip_make_node_A) Invoke_O_O_O_O__O(self, loc__0, node__1, children__2 any) any {




	var tmp1 *lang.Keyword; A_arbace_zip_A_Init(); tmp1 = A_arbace_zip_A_const_11; var tmp2 *lang.Keyword = tmp1; return lang.IFn_Cast(jrt.NN(tmp2).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(loc__0))).Invoke_O_O__O(node__1, children__2)
}
func A_arbace_zip_path_A_New() *A_arbace_zip_path_A { A_arbace_zip_path_A_Init(); t := &A_arbace_zip_path_A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_zip_path_A) Ctor() {}
//line :90:1
func (t *A_arbace_zip_path_A) Invoke_O_O__O(self, loc__0 any) any {



	var tmp1 *lang.Keyword; A_arbace_zip_A_Init(); tmp1 = A_arbace_zip_A_const_29; var tmp2 *lang.Keyword = tmp1; var tmp3 lang.IFn = lang.IFn_Cast(loc__0); var tmp4 any; A_arbace_zip_A_Init(); tmp4 = A_arbace_zip_A_const_30; return jrt.NN(tmp2).Invoke_O__O(tmp3.Invoke_O__O(tmp4))
}
func A_arbace_zip_lefts_A_New() *A_arbace_zip_lefts_A { A_arbace_zip_lefts_A_Init(); t := &A_arbace_zip_lefts_A{}; t.Ctor(); return t }
//line :96:1
func (t *A_arbace_zip_lefts_A) Ctor() {}
//line :96:1
func (t *A_arbace_zip_lefts_A) Invoke_O_O__O(self, loc__0 any) any {



	var tmp1 *lang.Var; A_arbace_zip_A_Init(); tmp1 = A_arbace_zip_A_const_17; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_zip_A_Init(); tmp3 = A_arbace_zip_A_const_31; var tmp4 *lang.Keyword = tmp3; var tmp5 lang.IFn = lang.IFn_Cast(loc__0); var tmp6 any; A_arbace_zip_A_Init(); tmp6 = A_arbace_zip_A_const_30; return tmp2.Invoke_O__O(jrt.NN(tmp4).Invoke_O__O(tmp5.Invoke_O__O(tmp6)))
}
func A_arbace_zip_rights_A_New() *A_arbace_zip_rights_A { A_arbace_zip_rights_A_Init(); t := &A_arbace_zip_rights_A{}; t.Ctor(); return t }
//line :102:1
func (t *A_arbace_zip_rights_A) Ctor() {}
//line :102:1
func (t *A_arbace_zip_rights_A) Invoke_O_O__O(self, loc__0 any) any {



	var tmp1 *lang.Keyword; A_arbace_zip_A_Init(); tmp1 = A_arbace_zip_A_const_32; var tmp2 *lang.Keyword = tmp1; var tmp3 lang.IFn = lang.IFn_Cast(loc__0); var tmp4 any; A_arbace_zip_A_Init(); tmp4 = A_arbace_zip_A_const_30; return jrt.NN(tmp2).Invoke_O__O(tmp3.Invoke_O__O(tmp4))
}
func A_arbace_zip_down_A_New() *A_arbace_zip_down_A { A_arbace_zip_down_A_Init(); t := &A_arbace_zip_down_A{}; t.Ctor(); return t }
//line :108:1
func (t *A_arbace_zip_down_A) Ctor() {}
//line :108:1
func (t *A_arbace_zip_down_A) Invoke_O_O__O(self, loc__0 any) any {




	var tmp1 *lang.Var; A_arbace_zip_A_Init(); tmp1 = A_arbace_zip_A_const_28; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(loc__0)) { var vec__703000029__2 any = loc__0; var node__3 any = lang.RT_Nth_O_I_O__O(vec__703000029__2, lang.RT_IntCast_J__I(0), nil); var path__4 any = lang.RT_Nth_O_I_O__O(vec__703000029__2, lang.RT_IntCast_J__I(1), nil); var vec__703000032__5 any; var tmp2 *lang.Var

		A_arbace_zip_A_Init(); tmp2 = A_arbace_zip_A_const_33; vec__703000032__5 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(loc__0)
//line :113:1
		var seq__703000033__6 any; var tmp3 *lang.Var
		A_arbace_zip_A_Init(); tmp3 = A_arbace_zip_A_const_17; seq__703000033__6 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(vec__703000032__5)
//line :113:1
		var first__703000034__7 any; var tmp4 *lang.Var
		A_arbace_zip_A_Init(); tmp4 = A_arbace_zip_A_const_34; first__703000034__7 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(seq__703000033__6)
//line :113:1
		var seq__703000033__8 any; var tmp5 *lang.Var
		A_arbace_zip_A_Init(); tmp5 = A_arbace_zip_A_const_35; seq__703000033__8 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(seq__703000033__6)
//line :113:1
		var c__9 any = first__703000034__7
		var cnext__10 any = seq__703000033__8
		var cs__11 any = vec__703000032__5
		if jrt.A2g_Truth(cs__11) {
			var tmp6 *lang.Var; A_arbace_zip_A_Init(); tmp6 = A_arbace_zip_A_const_15; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Keyword; A_arbace_zip_A_Init(); tmp8 = A_arbace_zip_A_const_31; var tmp9 any = tmp8.Ref(); var tmp10 *lang.PersistentVector; lang.PersistentVector_Init(); tmp10 = lang.PersistentVector_EMPTY; var tmp11 any = tmp10.Ref(); var tmp12 *lang.Keyword; A_arbace_zip_A_Init(); tmp12 = A_arbace_zip_A_const_29; var tmp13 any = tmp12.Ref(); var tmp14 any
			if jrt.A2g_Truth(path__4) { var tmp15 *lang.Var; A_arbace_zip_A_Init(); tmp15 = A_arbace_zip_A_const_6; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Keyword; A_arbace_zip_A_Init(); tmp17 = A_arbace_zip_A_const_29; tmp14 = tmp16.Invoke_O_O__O(jrt.NN(tmp17).Invoke_O__O(path__4), node__3) } else { tmp14 = lang.Tuple_Create_O__IPersistentVector(node__3) }
//line :117:1
			var tmp18 any = tmp14; var tmp19 *lang.Keyword; A_arbace_zip_A_Init(); tmp19 = A_arbace_zip_A_const_36; var tmp20 any = tmp19.Ref(); var tmp21 *lang.Keyword; A_arbace_zip_A_Init(); tmp21 = A_arbace_zip_A_const_32; return tmp7.Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(c__9, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp11, tmp13, tmp18, tmp20, path__4, tmp21.Ref(), cnext__10))), lang.RT_Meta_O__IPersistentMap(loc__0)) } else {
//line :116:1
				return nil } } else {
//line :113:1
					return nil
				}
}






func A_arbace_zip_up_A_New() *A_arbace_zip_up_A { A_arbace_zip_up_A_Init(); t := &A_arbace_zip_up_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_zip_up_A) Ctor() {}
//line :122:1
func (t *A_arbace_zip_up_A) Invoke_O_O__O(self, loc__0 any) any { var vec__703000036__2 any = loc__0; var node__3 any = lang.RT_Nth_O_I_O__O(vec__703000036__2, lang.RT_IntCast_J__I(0), nil); var map__703000039__4 any = lang.RT_Nth_O_I_O__O(vec__703000036__2, lang.RT_IntCast_J__I(1), nil); var map__703000039__5 any; if




	lang.ISeq_InstanceOf(map__703000039__4) { var tmp1 *lang.Var; A_arbace_zip_A_Init(); tmp1 = A_arbace_zip_A_const_35; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(map__703000039__4)) { var tmp2 *lang.Var; A_arbace_zip_A_Init(); tmp2 = A_arbace_zip_A_const_37; map__703000039__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__703000039__4), jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 *lang.Var; A_arbace_zip_A_Init(); tmp3 = A_arbace_zip_A_const_17; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__703000039__4)) { var tmp4 *lang.Var; A_arbace_zip_A_Init(); tmp4 = A_arbace_zip_A_const_34; map__703000039__5 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__703000039__4) } else { lang.PersistentArrayMap_Init(); map__703000039__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__703000039__5 = map__703000039__4 }; var path__6 any = map__703000039__5; var l__7 any; var tmp5 /*line :122:1*/*lang.Keyword; _ = path__6;




	A_arbace_zip_A_Init(); tmp5 = A_arbace_zip_A_const_31; l__7 = lang.RT_Get_O_O__O(map__703000039__5, tmp5.Ref()); var ppath__8 any; var tmp6 /*line :122:1*/*lang.Keyword;




	A_arbace_zip_A_Init(); tmp6 = A_arbace_zip_A_const_36; ppath__8 = lang.RT_Get_O_O__O(map__703000039__5, tmp6.Ref()); var pnodes__9 any; var tmp7 /*line :122:1*/*lang.Keyword;




	A_arbace_zip_A_Init(); tmp7 = A_arbace_zip_A_const_29; pnodes__9 = lang.RT_Get_O_O__O(map__703000039__5, tmp7.Ref()); var r__10 any; var tmp8 /*line :122:1*/*lang.Keyword;




	A_arbace_zip_A_Init(); tmp8 = A_arbace_zip_A_const_32; r__10 = lang.RT_Get_O_O__O(map__703000039__5, tmp8.Ref()); var changed_QMARK___11 any; var tmp9 /*line :122:1*/*lang.Keyword;




	A_arbace_zip_A_Init(); tmp9 = A_arbace_zip_A_const_38; changed_QMARK___11 = lang.RT_Get_O_O__O(map__703000039__5, tmp9.Ref()); if
	jrt.A2g_Truth(pnodes__9) { var pnode__12 any; var tmp10 *lang.Var
		A_arbace_zip_A_Init(); tmp10 = A_arbace_zip_A_const_39; pnode__12 = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(pnodes__9)
		var tmp11 *lang.Var; A_arbace_zip_A_Init(); tmp11 = A_arbace_zip_A_const_15; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 lang.IPersistentVector; if jrt.A2g_Truth(changed_QMARK___11) { var tmp14 *lang.Var; A_arbace_zip_A_Init(); tmp14 = A_arbace_zip_A_const_40; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Var; A_arbace_zip_A_Init(); tmp16 = A_arbace_zip_A_const_41; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Var; A_arbace_zip_A_Init(); tmp18 = A_arbace_zip_A_const_42; var tmp19 any = tmp15.Invoke_O_O_O__O(loc__0, pnode__12, tmp17.Invoke_O_O__O(l__7, lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O_O__O(node__3, r__10))); var tmp20 any
			var and__1927000168__auto____13 any = ppath__8
			if jrt.A2g_Truth(and__1927000168__auto____13) { var tmp21 *lang.Var; A_arbace_zip_A_Init(); tmp21 = A_arbace_zip_A_const_21; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Keyword; A_arbace_zip_A_Init(); tmp23 = A_arbace_zip_A_const_38; var tmp24 any = tmp23.Ref(); var tmp25 *jrt.Boolean; jrt.Boolean_Init(); tmp25 = jrt.Boolean_TRUE; tmp20 = tmp22.Invoke_O_O_O__O(ppath__8, tmp24, tmp25.Ref()) } else { tmp20 = and__1927000168__auto____13 }
//line :130:1
			tmp13 = lang.Tuple_Create_O_O__IPersistentVector(tmp19, tmp20) } else { tmp13 = lang.Tuple_Create_O_O__IPersistentVector(pnode__12, ppath__8) }; return tmp12.Invoke_O_O__O(tmp13, lang.RT_Meta_O__IPersistentMap(loc__0)) } else {
//line :128:1
				return nil } }







func A_arbace_zip_root_A_New() *A_arbace_zip_root_A { A_arbace_zip_root_A_Init(); t := &A_arbace_zip_root_A{}; t.Ctor(); return t }
//line :136:1
func (t *A_arbace_zip_root_A) Ctor() {}
//line :136:1
func (t *A_arbace_zip_root_A) Invoke_O_O__O(self, loc__0 any) any { { var loc__0_2 any = loc__0; L1: for {




	var tmp1 *lang.Keyword; A_arbace_zip_A_Init(); tmp1 = A_arbace_zip_A_const_43; var tmp2 any = tmp1.Ref(); var tmp3 lang.IFn = lang.IFn_Cast(loc__0_2); var tmp4 any; A_arbace_zip_A_Init(); tmp4 = A_arbace_zip_A_const_30; if lang.Util_Equiv_O_O__Z(tmp2, tmp3.Invoke_O__O(tmp4)) {
		var tmp5 *lang.Var; A_arbace_zip_A_Init(); tmp5 = A_arbace_zip_A_const_27; return lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(loc__0_2) } else {
//line :141:1
			var p__2 any; var tmp6 *lang.Var

			A_arbace_zip_A_Init(); tmp6 = A_arbace_zip_A_const_44; p__2 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(loc__0_2)
			if jrt.A2g_Truth(p__2) {
				loc__0_2 = p__2; continue L1 } else {
					var tmp7 *lang.Var; A_arbace_zip_A_Init(); tmp7 = A_arbace_zip_A_const_27; return lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(loc__0_2) } } } }; /*line :136:1*/panic("a2g: unreachable") }











func A_arbace_zip_right_A_New() *A_arbace_zip_right_A { A_arbace_zip_right_A_Init(); t := &A_arbace_zip_right_A{}; t.Ctor(); return t }
//line :148:1
func (t *A_arbace_zip_right_A) Ctor() {}
//line :148:1
func (t *A_arbace_zip_right_A) Invoke_O_O__O(self, loc__0 any) any { var vec__703000043__2 any = loc__0; var node__3 any = lang.RT_Nth_O_I_O__O(vec__703000043__2, lang.RT_IntCast_J__I(0), nil); var map__703000046__4 any = lang.RT_Nth_O_I_O__O(vec__703000043__2, lang.RT_IntCast_J__I(1), nil); var map__703000046__5 any; if



	lang.ISeq_InstanceOf(map__703000046__4) { var tmp1 *lang.Var; A_arbace_zip_A_Init(); tmp1 = A_arbace_zip_A_const_35; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(map__703000046__4)) { var tmp2 *lang.Var; A_arbace_zip_A_Init(); tmp2 = A_arbace_zip_A_const_37; map__703000046__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__703000046__4), jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 *lang.Var; A_arbace_zip_A_Init(); tmp3 = A_arbace_zip_A_const_17; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__703000046__4)) { var tmp4 *lang.Var; A_arbace_zip_A_Init(); tmp4 = A_arbace_zip_A_const_34; map__703000046__5 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__703000046__4) } else { lang.PersistentArrayMap_Init(); map__703000046__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__703000046__5 = map__703000046__4 }; var path__6 any = map__703000046__5; var l__7 any; var tmp5 /*line :148:1*/*lang.Keyword;



	A_arbace_zip_A_Init(); tmp5 = A_arbace_zip_A_const_31; l__7 = lang.RT_Get_O_O__O(map__703000046__5, tmp5.Ref()); var vec__703000048__8 any; var tmp6 /*line :148:1*/*lang.Keyword;



	A_arbace_zip_A_Init(); tmp6 = A_arbace_zip_A_const_32; vec__703000048__8 = lang.RT_Get_O_O__O(map__703000046__5, tmp6.Ref()); var seq__703000049__9 any; var tmp7 /*line :148:1*/*lang.Var;



	A_arbace_zip_A_Init(); tmp7 = A_arbace_zip_A_const_17; seq__703000049__9 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(vec__703000048__8); var first__703000050__10 any; var tmp8 /*line :148:1*/*lang.Var;



	A_arbace_zip_A_Init(); tmp8 = A_arbace_zip_A_const_34; first__703000050__10 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(seq__703000049__9); var seq__703000049__11 any; var tmp9 /*line :148:1*/*lang.Var;



	A_arbace_zip_A_Init(); tmp9 = A_arbace_zip_A_const_35; seq__703000049__11 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(seq__703000049__9); var r__12 any = first__703000050__10; var rnext__13 any = seq__703000049__11; var rs__14 any = vec__703000048__8; var tmp10 any; var and__1927000168__auto____15 any = path__6; if
	jrt.A2g_Truth(and__1927000168__auto____15) { tmp10 = rs__14 } else { tmp10 = and__1927000168__auto____15 }; if jrt.A2g_Truth(tmp10) {
		var tmp11 *lang.Var; A_arbace_zip_A_Init(); tmp11 = A_arbace_zip_A_const_15; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_zip_A_Init(); tmp13 = A_arbace_zip_A_const_21; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Keyword; A_arbace_zip_A_Init(); tmp15 = A_arbace_zip_A_const_31; var tmp16 any = tmp15.Ref(); var tmp17 *lang.Var; A_arbace_zip_A_Init(); tmp17 = A_arbace_zip_A_const_6; var tmp18 any = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O_O__O(l__7, node__3); var tmp19 *lang.Keyword; A_arbace_zip_A_Init(); tmp19 = A_arbace_zip_A_const_32; return tmp12.Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(r__12, tmp14.Invoke_O_O_O_O_O__O(path__6, tmp16, tmp18, tmp19.Ref(), rnext__13)), lang.RT_Meta_O__IPersistentMap(loc__0)) } else {
//line :153:1
			return nil } }


func A_arbace_zip_rightmost_A_New() *A_arbace_zip_rightmost_A { A_arbace_zip_rightmost_A_Init(); t := &A_arbace_zip_rightmost_A{}; t.Ctor(); return t }
//line :156:1
func (t *A_arbace_zip_rightmost_A) Ctor() {}
//line :156:1
func (t *A_arbace_zip_rightmost_A) Invoke_O_O__O(self, loc__0 any) any { var vec__703000052__2 any = loc__0; var node__3 any = lang.RT_Nth_O_I_O__O(vec__703000052__2, lang.RT_IntCast_J__I(0), nil); var map__703000055__4 any = lang.RT_Nth_O_I_O__O(vec__703000052__2, lang.RT_IntCast_J__I(1), nil); var map__703000055__5 any; if



	lang.ISeq_InstanceOf(map__703000055__4) { var tmp1 *lang.Var; A_arbace_zip_A_Init(); tmp1 = A_arbace_zip_A_const_35; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(map__703000055__4)) { var tmp2 *lang.Var; A_arbace_zip_A_Init(); tmp2 = A_arbace_zip_A_const_37; map__703000055__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__703000055__4), jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 *lang.Var; A_arbace_zip_A_Init(); tmp3 = A_arbace_zip_A_const_17; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__703000055__4)) { var tmp4 *lang.Var; A_arbace_zip_A_Init(); tmp4 = A_arbace_zip_A_const_34; map__703000055__5 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__703000055__4) } else { lang.PersistentArrayMap_Init(); map__703000055__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__703000055__5 = map__703000055__4 }; var path__6 any = map__703000055__5; var l__7 any; var tmp5 /*line :156:1*/*lang.Keyword;



	A_arbace_zip_A_Init(); tmp5 = A_arbace_zip_A_const_31; l__7 = lang.RT_Get_O_O__O(map__703000055__5, tmp5.Ref()); var r__8 any; var tmp6 /*line :156:1*/*lang.Keyword;



	A_arbace_zip_A_Init(); tmp6 = A_arbace_zip_A_const_32; r__8 = lang.RT_Get_O_O__O(map__703000055__5, tmp6.Ref()); var tmp7 any; var and__1927000168__auto____9 any = path__6; if
	jrt.A2g_Truth(and__1927000168__auto____9) { tmp7 = r__8 } else { tmp7 = and__1927000168__auto____9 }; if jrt.A2g_Truth(tmp7) {
		var tmp8 *lang.Var; A_arbace_zip_A_Init(); tmp8 = A_arbace_zip_A_const_15; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_zip_A_Init(); tmp10 = A_arbace_zip_A_const_45; var tmp11 any = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(r__8); var tmp12 *lang.Var; A_arbace_zip_A_Init(); tmp12 = A_arbace_zip_A_const_21; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Keyword; A_arbace_zip_A_Init(); tmp14 = A_arbace_zip_A_const_31; var tmp15 any = tmp14.Ref(); var tmp16 *lang.Var; A_arbace_zip_A_Init(); tmp16 = A_arbace_zip_A_const_23; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Var; A_arbace_zip_A_Init(); tmp18 = A_arbace_zip_A_const_6; var tmp19 any = jrt.NN(tmp18).GetRawRoot__O(); var tmp20 *lang.Var; A_arbace_zip_A_Init(); tmp20 = A_arbace_zip_A_const_46; var tmp21 any = tmp17.Invoke_O_O_O_O__O(tmp19, l__7, node__3, lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(r__8)); var tmp22 *lang.Keyword; A_arbace_zip_A_Init(); tmp22 = A_arbace_zip_A_const_32; return tmp9.Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(tmp11, tmp13.Invoke_O_O_O_O_O__O(path__6, tmp15, tmp21, tmp22.Ref(), nil)), lang.RT_Meta_O__IPersistentMap(loc__0)) } else {
//line :161:1
			return loc__0 } }



func A_arbace_zip_left_A_New() *A_arbace_zip_left_A { A_arbace_zip_left_A_Init(); t := &A_arbace_zip_left_A{}; t.Ctor(); return t }
//line :165:1
func (t *A_arbace_zip_left_A) Ctor() {}
//line :165:1
func (t *A_arbace_zip_left_A) Invoke_O_O__O(self, loc__0 any) any { var vec__703000058__2 any = loc__0; var node__3 any = lang.RT_Nth_O_I_O__O(vec__703000058__2, lang.RT_IntCast_J__I(0), nil); var map__703000061__4 any = lang.RT_Nth_O_I_O__O(vec__703000058__2, lang.RT_IntCast_J__I(1), nil); var map__703000061__5 any; if



	lang.ISeq_InstanceOf(map__703000061__4) { var tmp1 *lang.Var; A_arbace_zip_A_Init(); tmp1 = A_arbace_zip_A_const_35; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(map__703000061__4)) { var tmp2 *lang.Var; A_arbace_zip_A_Init(); tmp2 = A_arbace_zip_A_const_37; map__703000061__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__703000061__4), jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 *lang.Var; A_arbace_zip_A_Init(); tmp3 = A_arbace_zip_A_const_17; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__703000061__4)) { var tmp4 *lang.Var; A_arbace_zip_A_Init(); tmp4 = A_arbace_zip_A_const_34; map__703000061__5 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__703000061__4) } else { lang.PersistentArrayMap_Init(); map__703000061__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__703000061__5 = map__703000061__4 }; var path__6 any = map__703000061__5; var l__7 any; var tmp5 /*line :165:1*/*lang.Keyword;



	A_arbace_zip_A_Init(); tmp5 = A_arbace_zip_A_const_31; l__7 = lang.RT_Get_O_O__O(map__703000061__5, tmp5.Ref()); var r__8 any; var tmp6 /*line :165:1*/*lang.Keyword;



	A_arbace_zip_A_Init(); tmp6 = A_arbace_zip_A_const_32; r__8 = lang.RT_Get_O_O__O(map__703000061__5, tmp6.Ref()); var tmp7 any; var and__1927000168__auto____9 any = path__6; if
	jrt.A2g_Truth(and__1927000168__auto____9) { var tmp8 *lang.Var; A_arbace_zip_A_Init(); tmp8 = A_arbace_zip_A_const_17; tmp7 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(l__7) } else { tmp7 = and__1927000168__auto____9 }; if jrt.A2g_Truth(tmp7) {
		var tmp9 *lang.Var; A_arbace_zip_A_Init(); tmp9 = A_arbace_zip_A_const_15; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_zip_A_Init(); tmp11 = A_arbace_zip_A_const_39; var tmp12 any = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(l__7); var tmp13 *lang.Var; A_arbace_zip_A_Init(); tmp13 = A_arbace_zip_A_const_21; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Keyword; A_arbace_zip_A_Init(); tmp15 = A_arbace_zip_A_const_31; var tmp16 any = tmp15.Ref(); var tmp17 *lang.Var; A_arbace_zip_A_Init(); tmp17 = A_arbace_zip_A_const_47; var tmp18 any = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(l__7); var tmp19 *lang.Keyword; A_arbace_zip_A_Init(); tmp19 = A_arbace_zip_A_const_32; var tmp20 any = tmp19.Ref(); var tmp21 *lang.Var; A_arbace_zip_A_Init(); tmp21 = A_arbace_zip_A_const_42; return tmp10.Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(tmp12, tmp14.Invoke_O_O_O_O_O__O(path__6, tmp16, tmp18, tmp20, lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O_O__O(node__3, r__8))), lang.RT_Meta_O__IPersistentMap(loc__0)) } else {
//line :170:1
			return nil } }


func A_arbace_zip_leftmost_A_New() *A_arbace_zip_leftmost_A { A_arbace_zip_leftmost_A_Init(); t := &A_arbace_zip_leftmost_A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_zip_leftmost_A) Ctor() {}
//line :173:1
func (t *A_arbace_zip_leftmost_A) Invoke_O_O__O(self, loc__0 any) any { var vec__703000064__2 any = loc__0; var node__3 any = lang.RT_Nth_O_I_O__O(vec__703000064__2, lang.RT_IntCast_J__I(0), nil); var map__703000067__4 any = lang.RT_Nth_O_I_O__O(vec__703000064__2, lang.RT_IntCast_J__I(1), nil); var map__703000067__5 any; if



	lang.ISeq_InstanceOf(map__703000067__4) { var tmp1 *lang.Var; A_arbace_zip_A_Init(); tmp1 = A_arbace_zip_A_const_35; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(map__703000067__4)) { var tmp2 *lang.Var; A_arbace_zip_A_Init(); tmp2 = A_arbace_zip_A_const_37; map__703000067__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__703000067__4), jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 *lang.Var; A_arbace_zip_A_Init(); tmp3 = A_arbace_zip_A_const_17; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__703000067__4)) { var tmp4 *lang.Var; A_arbace_zip_A_Init(); tmp4 = A_arbace_zip_A_const_34; map__703000067__5 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__703000067__4) } else { lang.PersistentArrayMap_Init(); map__703000067__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__703000067__5 = map__703000067__4 }; var path__6 any = map__703000067__5; var l__7 any; var tmp5 /*line :173:1*/*lang.Keyword;



	A_arbace_zip_A_Init(); tmp5 = A_arbace_zip_A_const_31; l__7 = lang.RT_Get_O_O__O(map__703000067__5, tmp5.Ref()); var r__8 any; var tmp6 /*line :173:1*/*lang.Keyword;



	A_arbace_zip_A_Init(); tmp6 = A_arbace_zip_A_const_32; r__8 = lang.RT_Get_O_O__O(map__703000067__5, tmp6.Ref()); var tmp7 any; var and__1927000168__auto____9 any = path__6; if
	jrt.A2g_Truth(and__1927000168__auto____9) { var tmp8 *lang.Var; A_arbace_zip_A_Init(); tmp8 = A_arbace_zip_A_const_17; tmp7 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(l__7) } else { tmp7 = and__1927000168__auto____9 }; if jrt.A2g_Truth(tmp7) {
		var tmp9 *lang.Var; A_arbace_zip_A_Init(); tmp9 = A_arbace_zip_A_const_15; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_zip_A_Init(); tmp11 = A_arbace_zip_A_const_34; var tmp12 any = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(l__7); var tmp13 *lang.Var; A_arbace_zip_A_Init(); tmp13 = A_arbace_zip_A_const_21; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Keyword; A_arbace_zip_A_Init(); tmp15 = A_arbace_zip_A_const_31; var tmp16 any = tmp15.Ref(); var tmp17 *lang.PersistentVector; lang.PersistentVector_Init(); tmp17 = lang.PersistentVector_EMPTY; var tmp18 any = tmp17.Ref(); var tmp19 *lang.Keyword; A_arbace_zip_A_Init(); tmp19 = A_arbace_zip_A_const_32; var tmp20 any = tmp19.Ref(); var tmp21 *lang.Var; A_arbace_zip_A_Init(); tmp21 = A_arbace_zip_A_const_41; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_zip_A_Init(); tmp23 = A_arbace_zip_A_const_48; return tmp10.Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(tmp12, tmp14.Invoke_O_O_O_O_O__O(path__6, tmp16, tmp18, tmp20, tmp22.Invoke_O_O_O__O(lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(l__7), lang.Tuple_Create_O__IPersistentVector(node__3), r__8))), lang.RT_Meta_O__IPersistentMap(loc__0)) } else {
//line :178:1
			return loc__0 } }



func A_arbace_zip_insert_left_A_New() *A_arbace_zip_insert_left_A { A_arbace_zip_insert_left_A_Init(); t := &A_arbace_zip_insert_left_A{}; t.Ctor(); return t }
//line :182:1
func (t *A_arbace_zip_insert_left_A) Ctor() {}
//line :182:1
func (t *A_arbace_zip_insert_left_A) Invoke_O_O_O__O(self, loc__0, item__1 any) any { var vec__703000070__3 any = loc__0; var node__4 any = lang.RT_Nth_O_I_O__O(vec__703000070__3, lang.RT_IntCast_J__I(0), nil); var map__703000073__5 any = lang.RT_Nth_O_I_O__O(vec__703000070__3, lang.RT_IntCast_J__I(1), nil); var map__703000073__6 any; if




	lang.ISeq_InstanceOf(map__703000073__5) { var tmp1 *lang.Var; A_arbace_zip_A_Init(); tmp1 = A_arbace_zip_A_const_35; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(map__703000073__5)) { var tmp2 *lang.Var; A_arbace_zip_A_Init(); tmp2 = A_arbace_zip_A_const_37; map__703000073__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__703000073__5), jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 *lang.Var; A_arbace_zip_A_Init(); tmp3 = A_arbace_zip_A_const_17; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__703000073__5)) { var tmp4 *lang.Var; A_arbace_zip_A_Init(); tmp4 = A_arbace_zip_A_const_34; map__703000073__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__703000073__5) } else { lang.PersistentArrayMap_Init(); map__703000073__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__703000073__6 = map__703000073__5 }; var path__7 any = map__703000073__6; var l__8 any; var tmp5 /*line :182:1*/*lang.Keyword;




	A_arbace_zip_A_Init(); tmp5 = A_arbace_zip_A_const_31; l__8 = lang.RT_Get_O_O__O(map__703000073__6, tmp5.Ref()); if
	lang.Util_Identical_O_O__Z(path__7, nil) { panic(jrt.Thrown(jrt.Exception_New_String(Lit_67))) } else {

		var tmp6 *lang.Var; A_arbace_zip_A_Init(); tmp6 = A_arbace_zip_A_const_15; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_zip_A_Init(); tmp8 = A_arbace_zip_A_const_21; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Keyword; A_arbace_zip_A_Init(); tmp10 = A_arbace_zip_A_const_31; var tmp11 any = tmp10.Ref(); var tmp12 *lang.Var; A_arbace_zip_A_Init(); tmp12 = A_arbace_zip_A_const_6; var tmp13 any = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O_O__O(l__8, item__1); var tmp14 *lang.Keyword; A_arbace_zip_A_Init(); tmp14 = A_arbace_zip_A_const_38; var tmp15 any = tmp14.Ref(); var tmp16 *jrt.Boolean; jrt.Boolean_Init(); tmp16 = jrt.Boolean_TRUE; return tmp7.Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(node__4, tmp9.Invoke_O_O_O_O_O__O(path__7, tmp11, tmp13, tmp15, tmp16.Ref())), lang.RT_Meta_O__IPersistentMap(loc__0)) } }

func A_arbace_zip_insert_right_A_New() *A_arbace_zip_insert_right_A { A_arbace_zip_insert_right_A_Init(); t := &A_arbace_zip_insert_right_A{}; t.Ctor(); return t }
//line :192:1
func (t *A_arbace_zip_insert_right_A) Ctor() {}
//line :192:1
func (t *A_arbace_zip_insert_right_A) Invoke_O_O_O__O(self, loc__0, item__1 any) any { var vec__703000076__3 any = loc__0; var node__4 any = lang.RT_Nth_O_I_O__O(vec__703000076__3, lang.RT_IntCast_J__I(0), nil); var map__703000079__5 any = lang.RT_Nth_O_I_O__O(vec__703000076__3, lang.RT_IntCast_J__I(1), nil); var map__703000079__6 any; if




	lang.ISeq_InstanceOf(map__703000079__5) { var tmp1 *lang.Var; A_arbace_zip_A_Init(); tmp1 = A_arbace_zip_A_const_35; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(map__703000079__5)) { var tmp2 *lang.Var; A_arbace_zip_A_Init(); tmp2 = A_arbace_zip_A_const_37; map__703000079__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__703000079__5), jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 *lang.Var; A_arbace_zip_A_Init(); tmp3 = A_arbace_zip_A_const_17; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__703000079__5)) { var tmp4 *lang.Var; A_arbace_zip_A_Init(); tmp4 = A_arbace_zip_A_const_34; map__703000079__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__703000079__5) } else { lang.PersistentArrayMap_Init(); map__703000079__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__703000079__6 = map__703000079__5 }; var path__7 any = map__703000079__6; var r__8 any; var tmp5 /*line :192:1*/*lang.Keyword;




	A_arbace_zip_A_Init(); tmp5 = A_arbace_zip_A_const_32; r__8 = lang.RT_Get_O_O__O(map__703000079__6, tmp5.Ref()); if
	lang.Util_Identical_O_O__Z(path__7, nil) { panic(jrt.Thrown(jrt.Exception_New_String(Lit_67))) } else {

		var tmp6 *lang.Var; A_arbace_zip_A_Init(); tmp6 = A_arbace_zip_A_const_15; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_zip_A_Init(); tmp8 = A_arbace_zip_A_const_21; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Keyword; A_arbace_zip_A_Init(); tmp10 = A_arbace_zip_A_const_32; var tmp11 any = tmp10.Ref(); var tmp12 *lang.Var; A_arbace_zip_A_Init(); tmp12 = A_arbace_zip_A_const_42; var tmp13 any = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O_O__O(item__1, r__8); var tmp14 *lang.Keyword; A_arbace_zip_A_Init(); tmp14 = A_arbace_zip_A_const_38; var tmp15 any = tmp14.Ref(); var tmp16 *jrt.Boolean; jrt.Boolean_Init(); tmp16 = jrt.Boolean_TRUE; return tmp7.Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(node__4, tmp9.Invoke_O_O_O_O_O__O(path__7, tmp11, tmp13, tmp15, tmp16.Ref())), lang.RT_Meta_O__IPersistentMap(loc__0)) } }

func A_arbace_zip_replace_A_New() *A_arbace_zip_replace_A { A_arbace_zip_replace_A_Init(); t := &A_arbace_zip_replace_A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_zip_replace_A) Ctor() {}
//line :202:1
func (t *A_arbace_zip_replace_A) Invoke_O_O_O__O(self, loc__0, node__1 any) any { var vec__703000082__3 any = loc__0; var ___4 any = lang.RT_Nth_O_I_O__O(vec__703000082__3, lang.RT_IntCast_J__I(0), nil); var path__5 any = lang.RT_Nth_O_I_O__O(vec__703000082__3, lang.RT_IntCast_J__I(1), nil); var tmp1 *lang.Var; _ = ___4;




	A_arbace_zip_A_Init(); tmp1 = A_arbace_zip_A_const_15; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_zip_A_Init(); tmp3 = A_arbace_zip_A_const_21; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Keyword; A_arbace_zip_A_Init(); tmp5 = A_arbace_zip_A_const_38; var tmp6 any = tmp5.Ref(); var tmp7 *jrt.Boolean; jrt.Boolean_Init(); tmp7 = jrt.Boolean_TRUE; return tmp2.Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(node__1, tmp4.Invoke_O_O_O__O(path__5, tmp6, tmp7.Ref())), lang.RT_Meta_O__IPersistentMap(loc__0)) }

func A_arbace_zip_edit_A_New() *A_arbace_zip_edit_A { A_arbace_zip_edit_A_Init(); t := &A_arbace_zip_edit_A{}; t.Ctor(); return t }
//line :209:1
func (t *A_arbace_zip_edit_A) Ctor() {}
//line :209:1
func (t *A_arbace_zip_edit_A) DoInvoke_O_O_O_O__O(self, loc__0, f__1, args__2 any) any {



	var tmp1 *lang.Var; A_arbace_zip_A_Init(); tmp1 = A_arbace_zip_A_const_49; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_zip_A_Init(); tmp3 = A_arbace_zip_A_const_23; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_zip_A_Init(); tmp5 = A_arbace_zip_A_const_27; return tmp2.Invoke_O_O__O(loc__0, tmp4.Invoke_O_O_O__O(f__1, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(loc__0), args__2))
}
func A_arbace_zip_insert_child_A_New() *A_arbace_zip_insert_child_A { A_arbace_zip_insert_child_A_Init(); t := &A_arbace_zip_insert_child_A{}; t.Ctor(); return t }
//line :215:1
func (t *A_arbace_zip_insert_child_A) Ctor() {}
//line :215:1
func (t *A_arbace_zip_insert_child_A) Invoke_O_O_O__O(self, loc__0, item__1 any) any {




	var tmp1 *lang.Var; A_arbace_zip_A_Init(); tmp1 = A_arbace_zip_A_const_49; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_zip_A_Init(); tmp3 = A_arbace_zip_A_const_40; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_zip_A_Init(); tmp5 = A_arbace_zip_A_const_27; var tmp6 any = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(loc__0); var tmp7 *lang.Var; A_arbace_zip_A_Init(); tmp7 = A_arbace_zip_A_const_42; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_zip_A_Init(); tmp9 = A_arbace_zip_A_const_33; return tmp2.Invoke_O_O__O(loc__0, tmp4.Invoke_O_O_O__O(loc__0, tmp6, tmp8.Invoke_O_O__O(item__1, lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(loc__0))))
}
func A_arbace_zip_append_child_A_New() *A_arbace_zip_append_child_A { A_arbace_zip_append_child_A_Init(); t := &A_arbace_zip_append_child_A{}; t.Ctor(); return t }
//line :222:1
func (t *A_arbace_zip_append_child_A) Ctor() {}
//line :222:1
func (t *A_arbace_zip_append_child_A) Invoke_O_O_O__O(self, loc__0, item__1 any) any {




	var tmp1 *lang.Var; A_arbace_zip_A_Init(); tmp1 = A_arbace_zip_A_const_49; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_zip_A_Init(); tmp3 = A_arbace_zip_A_const_40; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_zip_A_Init(); tmp5 = A_arbace_zip_A_const_27; var tmp6 any = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(loc__0); var tmp7 *lang.Var; A_arbace_zip_A_Init(); tmp7 = A_arbace_zip_A_const_41; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_zip_A_Init(); tmp9 = A_arbace_zip_A_const_33; return tmp2.Invoke_O_O__O(loc__0, tmp4.Invoke_O_O_O__O(loc__0, tmp6, tmp8.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(loc__0), lang.Tuple_Create_O__IPersistentVector(item__1))))
}
func A_arbace_zip_next_A_New() *A_arbace_zip_next_A { A_arbace_zip_next_A_Init(); t := &A_arbace_zip_next_A{}; t.Ctor(); return t }
//line :229:1
func (t *A_arbace_zip_next_A) Ctor() {}
//line :229:1
func (t *A_arbace_zip_next_A) Invoke_O_O__O(self, loc__0 any) any {





	{ var tmp1 *lang.Keyword; A_arbace_zip_A_Init(); tmp1 = A_arbace_zip_A_const_43; var tmp2 any = tmp1.Ref(); var tmp3 lang.IFn = lang.IFn_Cast(loc__0); var tmp4 any; A_arbace_zip_A_Init(); tmp4 = A_arbace_zip_A_const_30; if lang.Util_Equiv_O_O__Z(tmp2, tmp3.Invoke_O__O(tmp4)) { return loc__0 } else { var or__1927000174__auto____2 any; var and__1927000168__auto____2 any; var tmp5 *lang.Var


		A_arbace_zip_A_Init(); tmp5 = A_arbace_zip_A_const_28; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(loc__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp6 *lang.Var; A_arbace_zip_A_Init(); tmp6 = A_arbace_zip_A_const_50; or__1927000174__auto____2 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(loc__0) } else { or__1927000174__auto____2 = and__1927000168__auto____2 }
//line :237:1
		if jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var tmp7 *lang.Var

			A_arbace_zip_A_Init(); tmp7 = A_arbace_zip_A_const_51; or__1927000174__auto____3 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(loc__0)
//line :237:1
			if jrt.A2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var p__4 any = loc__0; L1: for { var temp__1927000408__auto____5 any; var tmp8 *lang.Var



				A_arbace_zip_A_Init(); tmp8 = A_arbace_zip_A_const_44; temp__1927000408__auto____5 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(p__4); if jrt.A2g_Truth(temp__1927000408__auto____5) { var uloc__6 any = temp__1927000408__auto____5; var or__1927000174__auto____7 any; var tmp9 *lang.Var
					A_arbace_zip_A_Init(); tmp9 = A_arbace_zip_A_const_51; or__1927000174__auto____7 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(uloc__6); if jrt.A2g_Truth(or__1927000174__auto____7) { return or__1927000174__auto____7 } else { p__4 = uloc__6; continue L1 } } else {
//line :241:1
						var tmp10 *lang.Var; A_arbace_zip_A_Init(); tmp10 = A_arbace_zip_A_const_27; var tmp11 any = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(p__4); var tmp12 *lang.Keyword; A_arbace_zip_A_Init(); tmp12 = A_arbace_zip_A_const_43; return lang.Tuple_Create_O_O__IPersistentVector(tmp11, tmp12.Ref()) } } } } } }
//line :229:1
	panic("a2g: unreachable")
}














func A_arbace_zip_prev_A_New() *A_arbace_zip_prev_A { A_arbace_zip_prev_A_Init(); t := &A_arbace_zip_prev_A{}; t.Ctor(); return t }
//line :245:1
func (t *A_arbace_zip_prev_A) Ctor() {}
//line :245:1
func (t *A_arbace_zip_prev_A) Invoke_O_O__O(self, loc__0 any) any { { var temp__1927000408__auto____2 any; var tmp1 *lang.Var




	A_arbace_zip_A_Init(); tmp1 = A_arbace_zip_A_const_52; temp__1927000408__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(loc__0); if jrt.A2g_Truth(temp__1927000408__auto____2) { var lloc__3 any = temp__1927000408__auto____2; var loc__4 any = lloc__3; L1: for { var temp__1927000408__auto____5 any; var and__1927000168__auto____5 any; var tmp2 *lang.Var

		A_arbace_zip_A_Init(); tmp2 = A_arbace_zip_A_const_28; and__1927000168__auto____5 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(loc__4); if jrt.A2g_Truth(and__1927000168__auto____5) { var tmp3 *lang.Var; A_arbace_zip_A_Init(); tmp3 = A_arbace_zip_A_const_50; temp__1927000408__auto____5 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(loc__4) } else { temp__1927000408__auto____5 = and__1927000168__auto____5 }; if jrt.A2g_Truth(temp__1927000408__auto____5) { var child__6 any = temp__1927000408__auto____5; var tmp4 *lang.Var
			A_arbace_zip_A_Init(); tmp4 = A_arbace_zip_A_const_53; loc__4 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(child__6); continue L1 } else {
//line :252:1
				return loc__4 } } } else {


					var tmp5 *lang.Var; A_arbace_zip_A_Init(); tmp5 = A_arbace_zip_A_const_44; return lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(loc__0) } }; /*line :245:1*/panic("a2g: unreachable") }











func A_arbace_zip_end_QMARK__A_New() *A_arbace_zip_end_QMARK__A { A_arbace_zip_end_QMARK__A_Init(); t := &A_arbace_zip_end_QMARK__A{}; t.Ctor(); return t }
//line :257:1
func (t *A_arbace_zip_end_QMARK__A) Ctor() {}
//line :257:1
func (t *A_arbace_zip_end_QMARK__A) Invoke_O_O__O(self, loc__0 any) any {



	var tmp1 *lang.Keyword; A_arbace_zip_A_Init(); tmp1 = A_arbace_zip_A_const_43; var tmp2 any = tmp1.Ref(); var tmp3 lang.IFn = lang.IFn_Cast(loc__0); var tmp4 any; A_arbace_zip_A_Init(); tmp4 = A_arbace_zip_A_const_30; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp2, tmp3.Invoke_O__O(tmp4))).Ref()
}
func A_arbace_zip_remove_A_New() *A_arbace_zip_remove_A { A_arbace_zip_remove_A_Init(); t := &A_arbace_zip_remove_A{}; t.Ctor(); return t }
//line :263:1
func (t *A_arbace_zip_remove_A) Ctor() {}
//line :263:1
func (t *A_arbace_zip_remove_A) Invoke_O_O__O(self, loc__0 any) any { { var vec__703000092__2 any = loc__0; var node__3 any = lang.RT_Nth_O_I_O__O(vec__703000092__2, lang.RT_IntCast_J__I(0), nil); var map__703000095__4 any = lang.RT_Nth_O_I_O__O(vec__703000092__2, lang.RT_IntCast_J__I(1), nil); var map__703000095__5 any; _ = node__3




	if lang.ISeq_InstanceOf(map__703000095__4) { var tmp1 *lang.Var; A_arbace_zip_A_Init(); tmp1 = A_arbace_zip_A_const_35; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(map__703000095__4)) { var tmp2 *lang.Var; A_arbace_zip_A_Init(); tmp2 = A_arbace_zip_A_const_37; map__703000095__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__703000095__4), jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 *lang.Var; A_arbace_zip_A_Init(); tmp3 = A_arbace_zip_A_const_17; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__703000095__4)) { var tmp4 *lang.Var; A_arbace_zip_A_Init(); tmp4 = A_arbace_zip_A_const_34; map__703000095__5 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__703000095__4) } else { lang.PersistentArrayMap_Init(); map__703000095__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__703000095__5 = map__703000095__4 }
//line :263:1
	var path__6 any = map__703000095__5; var l__7 any; var tmp5 *lang.Keyword




	A_arbace_zip_A_Init(); tmp5 = A_arbace_zip_A_const_31; l__7 = lang.RT_Get_O_O__O(map__703000095__5, tmp5.Ref())
//line :263:1
	var ppath__8 any; var tmp6 *lang.Keyword




	A_arbace_zip_A_Init(); tmp6 = A_arbace_zip_A_const_36; ppath__8 = lang.RT_Get_O_O__O(map__703000095__5, tmp6.Ref())
//line :263:1
	var pnodes__9 any; var tmp7 *lang.Keyword




	A_arbace_zip_A_Init(); tmp7 = A_arbace_zip_A_const_29; pnodes__9 = lang.RT_Get_O_O__O(map__703000095__5, tmp7.Ref())
//line :263:1
	var rs__10 any; var tmp8 *lang.Keyword




	A_arbace_zip_A_Init(); tmp8 = A_arbace_zip_A_const_32; rs__10 = lang.RT_Get_O_O__O(map__703000095__5, tmp8.Ref())
	if lang.Util_Identical_O_O__Z(path__6, nil) { panic(jrt.Thrown(jrt.Exception_New_String(Lit_78))) } else {

		if lang.Numbers_IsPos_J__Z(int64(lang.RT_Count_O__I(l__7))) { var loc__11 any; var tmp9 *lang.Var
			A_arbace_zip_A_Init(); tmp9 = A_arbace_zip_A_const_15; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_zip_A_Init(); tmp11 = A_arbace_zip_A_const_39; var tmp12 any = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(l__7); var tmp13 *lang.Var; A_arbace_zip_A_Init(); tmp13 = A_arbace_zip_A_const_21; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Keyword; A_arbace_zip_A_Init(); tmp15 = A_arbace_zip_A_const_31; var tmp16 any = tmp15.Ref(); var tmp17 *lang.Var; A_arbace_zip_A_Init(); tmp17 = A_arbace_zip_A_const_47; var tmp18 any = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(l__7); var tmp19 *lang.Keyword; A_arbace_zip_A_Init(); tmp19 = A_arbace_zip_A_const_38; var tmp20 any = tmp19.Ref(); var tmp21 *jrt.Boolean; jrt.Boolean_Init(); tmp21 = jrt.Boolean_TRUE; loc__11 = tmp10.Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(tmp12, tmp14.Invoke_O_O_O_O_O__O(path__6, tmp16, tmp18, tmp20, tmp21.Ref())), lang.RT_Meta_O__IPersistentMap(loc__0))
//line :271:1
		L1: for { var temp__1927000408__auto____12 any; var and__1927000168__auto____12 any; var tmp22 *lang.Var

			A_arbace_zip_A_Init(); tmp22 = A_arbace_zip_A_const_28; and__1927000168__auto____12 = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(loc__11); if jrt.A2g_Truth(and__1927000168__auto____12) { var tmp23 *lang.Var; A_arbace_zip_A_Init(); tmp23 = A_arbace_zip_A_const_50; temp__1927000408__auto____12 = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(loc__11) } else { temp__1927000408__auto____12 = and__1927000168__auto____12 }; if jrt.A2g_Truth(temp__1927000408__auto____12) { var child__13 any = temp__1927000408__auto____12; var tmp24 *lang.Var
				A_arbace_zip_A_Init(); tmp24 = A_arbace_zip_A_const_53; loc__11 = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(child__13); continue L1 } else {
//line :273:1
					return loc__11 } } } else {


						var tmp25 *lang.Var; A_arbace_zip_A_Init(); tmp25 = A_arbace_zip_A_const_15; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Var; A_arbace_zip_A_Init(); tmp27 = A_arbace_zip_A_const_40; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Var; A_arbace_zip_A_Init(); tmp29 = A_arbace_zip_A_const_39; var tmp30 any = tmp28.Invoke_O_O_O__O(loc__0, lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(pnodes__9), rs__10); var tmp31 any; var and__1927000168__auto____11 any = ppath__8
						if jrt.A2g_Truth(and__1927000168__auto____11) { var tmp32 *lang.Var; A_arbace_zip_A_Init(); tmp32 = A_arbace_zip_A_const_21; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 *lang.Keyword; A_arbace_zip_A_Init(); tmp34 = A_arbace_zip_A_const_38; var tmp35 any = tmp34.Ref(); var tmp36 *jrt.Boolean; jrt.Boolean_Init(); tmp36 = jrt.Boolean_TRUE; tmp31 = tmp33.Invoke_O_O_O__O(ppath__8, tmp35, tmp36.Ref()) } else { tmp31 = and__1927000168__auto____11 }
//line :276:1
						return tmp26.Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(tmp30, tmp31), lang.RT_Meta_O__IPersistentMap(loc__0)) } } }; /*line :263:1*/panic("a2g: unreachable") }







type A_arbace_zip_A struct{ jrt.Object }

var A_arbace_zip_A_const_0 *lang.Var

var A_arbace_zip_A_const_1 any

var A_arbace_zip_A_const_2 *lang.Keyword

var A_arbace_zip_A_const_3 any

var A_arbace_zip_A_const_4 *lang.Var

var A_arbace_zip_A_const_5 *lang.Var

var A_arbace_zip_A_const_6 *lang.Var

var A_arbace_zip_A_const_7 any

var A_arbace_zip_A_const_8 *lang.Var

var A_arbace_zip_A_const_9 *lang.Keyword

var A_arbace_zip_A_const_10 *lang.Keyword

var A_arbace_zip_A_const_11 *lang.Keyword

var A_arbace_zip_A_const_12 *lang.Var

var A_arbace_zip_A_const_13 *lang.Var

var A_arbace_zip_A_const_14 *lang.Var

var A_arbace_zip_A_const_15 *lang.Var

var A_arbace_zip_A_const_16 *lang.Var

var A_arbace_zip_A_const_17 *lang.Var

var A_arbace_zip_A_const_18 *lang.Var

var A_arbace_zip_A_const_19 *lang.Var

var A_arbace_zip_A_const_20 *lang.Var

var A_arbace_zip_A_const_21 *lang.Var

var A_arbace_zip_A_const_22 *lang.Keyword

var A_arbace_zip_A_const_23 *lang.Var

var A_arbace_zip_A_const_24 *lang.Var

var A_arbace_zip_A_const_25 *lang.Var

var A_arbace_zip_A_const_26 any

var A_arbace_zip_A_const_27 *lang.Var

var A_arbace_zip_A_const_28 *lang.Var

var A_arbace_zip_A_const_29 *lang.Keyword

var A_arbace_zip_A_const_30 any

var A_arbace_zip_A_const_31 *lang.Keyword

var A_arbace_zip_A_const_32 *lang.Keyword

var A_arbace_zip_A_const_33 *lang.Var

var A_arbace_zip_A_const_34 *lang.Var

var A_arbace_zip_A_const_35 *lang.Var

var A_arbace_zip_A_const_36 *lang.Keyword

var A_arbace_zip_A_const_37 *lang.Var

var A_arbace_zip_A_const_38 *lang.Keyword

var A_arbace_zip_A_const_39 *lang.Var

var A_arbace_zip_A_const_40 *lang.Var

var A_arbace_zip_A_const_41 *lang.Var

var A_arbace_zip_A_const_42 *lang.Var

var A_arbace_zip_A_const_43 *lang.Keyword

var A_arbace_zip_A_const_44 *lang.Var

var A_arbace_zip_A_const_45 *lang.Var

var A_arbace_zip_A_const_46 *lang.Var

var A_arbace_zip_A_const_47 *lang.Var

var A_arbace_zip_A_const_48 *lang.Var

var A_arbace_zip_A_const_49 *lang.Var

var A_arbace_zip_A_const_50 *lang.Var

var A_arbace_zip_A_const_51 *lang.Var

var A_arbace_zip_A_const_52 *lang.Var

var A_arbace_zip_A_const_53 *lang.Var

var A_arbace_zip_A_init jrt.ClassInit

func A_arbace_zip_A_Init() { if !A_arbace_zip_A_init.Done() { A_arbace_zip_A_init.Run(A_arbace_zip_A_clinit) } }

func A_arbace_zip_A_clinit() { A_arbace_zip_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_zip_A_const_1 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_zip_A_const_2 = lang.RT_Keyword_String_String__Keyword(nil, Lit_2); A_arbace_zip_A_const_3 = lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), jrt.Integer_ValueOf_I__Integer(16).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(28).Ref()))); A_arbace_zip_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_8); A_arbace_zip_A_const_5 = lang.RT_Var_String_String__Var(Lit_0, Lit_9); A_arbace_zip_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_10); A_arbace_zip_A_const_7 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_11)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15))); A_arbace_zip_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_16); A_arbace_zip_A_const_9 = lang.RT_Keyword_String_String__Keyword(Lit_17, Lit_18); A_arbace_zip_A_const_10 = lang.RT_Keyword_String_String__Keyword(Lit_17, Lit_19); A_arbace_zip_A_const_11 = lang.RT_Keyword_String_String__Keyword(Lit_17, Lit_20); A_arbace_zip_A_const_12 = lang.RT_Var_String_String__Var(Lit_11, Lit_21); A_arbace_zip_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_22); A_arbace_zip_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_23); A_arbace_zip_A_const_15 = lang.RT_Var_String_String__Var(Lit_0, Lit_24); A_arbace_zip_A_const_16 = lang.RT_Var_String_String__Var(Lit_0, Lit_25); A_arbace_zip_A_const_17 = lang.RT_Var_String_String__Var(Lit_0, Lit_26); A_arbace_zip_A_const_18 = lang.RT_Var_String_String__Var(Lit_0, Lit_27); A_arbace_zip_A_const_19 = lang.RT_Var_String_String__Var(Lit_0, Lit_28); A_arbace_zip_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_29); A_arbace_zip_A_const_21 = lang.RT_Var_String_String__Var(Lit_0, Lit_30); A_arbace_zip_A_const_22 = lang.RT_Keyword_String_String__Keyword(nil, Lit_31); A_arbace_zip_A_const_23 = lang.RT_Var_String_String__Var(Lit_0, Lit_32); A_arbace_zip_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_33); A_arbace_zip_A_const_25 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_zip_A_const_26 = jrt.Long_ValueOf_J__Long(0).Ref(); A_arbace_zip_A_const_27 = lang.RT_Var_String_String__Var(Lit_11, Lit_35); A_arbace_zip_A_const_28 = lang.RT_Var_String_String__Var(Lit_11, Lit_18); A_arbace_zip_A_const_29 = lang.RT_Keyword_String_String__Keyword(nil, Lit_36); A_arbace_zip_A_const_30 = jrt.Long_ValueOf_J__Long(1).Ref(); A_arbace_zip_A_const_31 = lang.RT_Keyword_String_String__Keyword(nil, Lit_37); A_arbace_zip_A_const_32 = lang.RT_Keyword_String_String__Keyword(nil, Lit_38); A_arbace_zip_A_const_33 = lang.RT_Var_String_String__Var(Lit_11, Lit_19); A_arbace_zip_A_const_34 = lang.RT_Var_String_String__Var(Lit_0, Lit_39); A_arbace_zip_A_const_35 = lang.RT_Var_String_String__Var(Lit_0, Lit_5); A_arbace_zip_A_const_36 = lang.RT_Keyword_String_String__Keyword(nil, Lit_40); A_arbace_zip_A_const_37 = lang.RT_Var_String_String__Var(Lit_0, Lit_41); A_arbace_zip_A_const_38 = lang.RT_Keyword_String_String__Keyword(nil, Lit_42); A_arbace_zip_A_const_39 = lang.RT_Var_String_String__Var(Lit_0, Lit_43); A_arbace_zip_A_const_40 = lang.RT_Var_String_String__Var(Lit_11, Lit_20); A_arbace_zip_A_const_41 = lang.RT_Var_String_String__Var(Lit_0, Lit_44); A_arbace_zip_A_const_42 = lang.RT_Var_String_String__Var(Lit_0, Lit_45); A_arbace_zip_A_const_43 = lang.RT_Keyword_String_String__Keyword(nil, Lit_46); A_arbace_zip_A_const_44 = lang.RT_Var_String_String__Var(Lit_11, Lit_47); A_arbace_zip_A_const_45 = lang.RT_Var_String_String__Var(Lit_0, Lit_48); A_arbace_zip_A_const_46 = lang.RT_Var_String_String__Var(Lit_0, Lit_49); A_arbace_zip_A_const_47 = lang.RT_Var_String_String__Var(Lit_0, Lit_50); A_arbace_zip_A_const_48 = lang.RT_Var_String_String__Var(Lit_0, Lit_51); A_arbace_zip_A_const_49 = lang.RT_Var_String_String__Var(Lit_11, Lit_3); A_arbace_zip_A_const_50 = lang.RT_Var_String_String__Var(Lit_11, Lit_52); A_arbace_zip_A_const_51 = lang.RT_Var_String_String__Var(Lit_11, Lit_53); A_arbace_zip_A_const_52 = lang.RT_Var_String_String__Var(Lit_11, Lit_54); A_arbace_zip_A_const_53 = lang.RT_Var_String_String__Var(Lit_11, Lit_55) }

func A_arbace_zip_A_New() *A_arbace_zip_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_A{}; t.Ctor(); return t }

func (t *A_arbace_zip_A) Ctor() {}

func (t *A_arbace_zip_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_A) GetClass__Class() *jrt.Class { return A_arbace_zip_A_class }

func (t *A_arbace_zip_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_A); return ok }

func A_arbace_zip_A_Cast(x any) *A_arbace_zip_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_A_class)) }; return v }



type A_arbace_zip_append_child_A struct{ jrt.Object }

func (t *A_arbace_zip_append_child_A) Is_Compiler_AOTF2() {}

var A_arbace_zip_append_child_A_fn_class *jrt.Class

var A_arbace_zip_append_child_A_init jrt.ClassInit

func A_arbace_zip_append_child_A_Init() { if !A_arbace_zip_append_child_A_init.Done() { A_arbace_zip_append_child_A_init.Run(A_arbace_zip_append_child_A_clinit) } }

func A_arbace_zip_append_child_A_clinit() { A_arbace_zip_append_child_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_56, lang.Compiler_AOTFn_class) }

func (t *A_arbace_zip_append_child_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_append_child_A) GetClass__Class() *jrt.Class { return A_arbace_zip_append_child_A_class }

func (t *A_arbace_zip_append_child_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_append_child_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_append_child_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_append_child_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_append_child_A); return ok }

func A_arbace_zip_append_child_A_Cast(x any) *A_arbace_zip_append_child_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_append_child_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_append_child_A_class)) }; return v }



type A_arbace_zip_branch_QMARK__A struct{ jrt.Object }

func (t *A_arbace_zip_branch_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_zip_branch_QMARK__A_fn_class *jrt.Class

var A_arbace_zip_branch_QMARK__A_init jrt.ClassInit

func A_arbace_zip_branch_QMARK__A_Init() { if !A_arbace_zip_branch_QMARK__A_init.Done() { A_arbace_zip_branch_QMARK__A_init.Run(A_arbace_zip_branch_QMARK__A_clinit) } }

func A_arbace_zip_branch_QMARK__A_clinit() { A_arbace_zip_branch_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_57, lang.Compiler_AOTFn_class) }

func (t *A_arbace_zip_branch_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_branch_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_zip_branch_QMARK__A_class }

func (t *A_arbace_zip_branch_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_branch_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_branch_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_branch_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_branch_QMARK__A); return ok }

func A_arbace_zip_branch_QMARK__A_Cast(x any) *A_arbace_zip_branch_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_branch_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_branch_QMARK__A_class)) }; return v }



type A_arbace_zip_children_A struct{ jrt.Object }

func (t *A_arbace_zip_children_A) Is_Compiler_AOTF1() {}

var A_arbace_zip_children_A_fn_class *jrt.Class

var A_arbace_zip_children_A_init jrt.ClassInit

func A_arbace_zip_children_A_Init() { if !A_arbace_zip_children_A_init.Done() { A_arbace_zip_children_A_init.Run(A_arbace_zip_children_A_clinit) } }

func A_arbace_zip_children_A_clinit() { A_arbace_zip_children_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_58, lang.Compiler_AOTFn_class) }

func (t *A_arbace_zip_children_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_children_A) GetClass__Class() *jrt.Class { return A_arbace_zip_children_A_class }

func (t *A_arbace_zip_children_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_children_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_children_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_children_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_children_A); return ok }

func A_arbace_zip_children_A_Cast(x any) *A_arbace_zip_children_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_children_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_children_A_class)) }; return v }



type A_arbace_zip_down_A struct{ jrt.Object }

func (t *A_arbace_zip_down_A) Is_Compiler_AOTF1() {}

var A_arbace_zip_down_A_fn_class *jrt.Class

var A_arbace_zip_down_A_init jrt.ClassInit

func A_arbace_zip_down_A_Init() { if !A_arbace_zip_down_A_init.Done() { A_arbace_zip_down_A_init.Run(A_arbace_zip_down_A_clinit) } }

func A_arbace_zip_down_A_clinit() { A_arbace_zip_down_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_60, lang.Compiler_AOTFn_class) }

func (t *A_arbace_zip_down_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_down_A) GetClass__Class() *jrt.Class { return A_arbace_zip_down_A_class }

func (t *A_arbace_zip_down_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_down_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_down_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_down_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_down_A); return ok }

func A_arbace_zip_down_A_Cast(x any) *A_arbace_zip_down_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_down_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_down_A_class)) }; return v }



type A_arbace_zip_edit_A struct{ jrt.Object }

func (t *A_arbace_zip_edit_A) Is_Compiler_AOTR2() {}

var A_arbace_zip_edit_A_fn_class *jrt.Class

var A_arbace_zip_edit_A_init jrt.ClassInit

func A_arbace_zip_edit_A_Init() { if !A_arbace_zip_edit_A_init.Done() { A_arbace_zip_edit_A_init.Run(A_arbace_zip_edit_A_clinit) } }

func A_arbace_zip_edit_A_clinit() { A_arbace_zip_edit_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_61, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_zip_edit_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_edit_A) GetClass__Class() *jrt.Class { return A_arbace_zip_edit_A_class }

func (t *A_arbace_zip_edit_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_edit_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_edit_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_edit_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_edit_A); return ok }

func A_arbace_zip_edit_A_Cast(x any) *A_arbace_zip_edit_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_edit_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_edit_A_class)) }; return v }



type A_arbace_zip_end_QMARK__A struct{ jrt.Object }

func (t *A_arbace_zip_end_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_zip_end_QMARK__A_fn_class *jrt.Class

var A_arbace_zip_end_QMARK__A_init jrt.ClassInit

func A_arbace_zip_end_QMARK__A_Init() { if !A_arbace_zip_end_QMARK__A_init.Done() { A_arbace_zip_end_QMARK__A_init.Run(A_arbace_zip_end_QMARK__A_clinit) } }

func A_arbace_zip_end_QMARK__A_clinit() { A_arbace_zip_end_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_62, lang.Compiler_AOTFn_class) }

func (t *A_arbace_zip_end_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_end_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_zip_end_QMARK__A_class }

func (t *A_arbace_zip_end_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_end_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_end_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_end_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_end_QMARK__A); return ok }

func A_arbace_zip_end_QMARK__A_Cast(x any) *A_arbace_zip_end_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_end_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_end_QMARK__A_class)) }; return v }



type A_arbace_zip_eval703000004_A struct{ jrt.Object }

func A_arbace_zip_eval703000004_A_New() *A_arbace_zip_eval703000004_A { t := &A_arbace_zip_eval703000004_A{}; t.Ctor(); return t }

func (t *A_arbace_zip_eval703000004_A) Ctor() {}

func (t *A_arbace_zip_eval703000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_eval703000004_A) GetClass__Class() *jrt.Class { return A_arbace_zip_eval703000004_A_class }

func (t *A_arbace_zip_eval703000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_eval703000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_eval703000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_eval703000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_eval703000004_A); return ok }

func A_arbace_zip_eval703000004_A_Cast(x any) *A_arbace_zip_eval703000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_eval703000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_eval703000004_A_class)) }; return v }



type A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A struct{ jrt.Object }

func (t *A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A) Is_Compiler_AOTF0() {}

var A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_fn_class *jrt.Class

var A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_init jrt.ClassInit

func A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_Init() { if !A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_init.Done() { A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_init.Run(A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_clinit) } }

func A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_clinit() { A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_63, lang.Compiler_AOTFn_class) }

func (t *A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A) GetClass__Class() *jrt.Class { return A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_class }

func (t *A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A); return ok }

func A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_Cast(x any) *A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_class)) }; return v }



type A_arbace_zip_eval703000008_A struct{ jrt.Object }

func A_arbace_zip_eval703000008_A_New() *A_arbace_zip_eval703000008_A { t := &A_arbace_zip_eval703000008_A{}; t.Ctor(); return t }

func (t *A_arbace_zip_eval703000008_A) Ctor() {}

func (t *A_arbace_zip_eval703000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_eval703000008_A) GetClass__Class() *jrt.Class { return A_arbace_zip_eval703000008_A_class }

func (t *A_arbace_zip_eval703000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_eval703000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_eval703000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_eval703000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_eval703000008_A); return ok }

func A_arbace_zip_eval703000008_A_Cast(x any) *A_arbace_zip_eval703000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_eval703000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_eval703000008_A_class)) }; return v }



type A_arbace_zip_eval703000008_fn__703000009_A struct{ jrt.Object }

func (t *A_arbace_zip_eval703000008_fn__703000009_A) Is_Compiler_AOTF0() {}

var A_arbace_zip_eval703000008_fn__703000009_A_fn_class *jrt.Class

var A_arbace_zip_eval703000008_fn__703000009_A_init jrt.ClassInit

func A_arbace_zip_eval703000008_fn__703000009_A_Init() { if !A_arbace_zip_eval703000008_fn__703000009_A_init.Done() { A_arbace_zip_eval703000008_fn__703000009_A_init.Run(A_arbace_zip_eval703000008_fn__703000009_A_clinit) } }

func A_arbace_zip_eval703000008_fn__703000009_A_clinit() { A_arbace_zip_eval703000008_fn__703000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_64, lang.Compiler_AOTFn_class) }

func (t *A_arbace_zip_eval703000008_fn__703000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_eval703000008_fn__703000009_A) GetClass__Class() *jrt.Class { return A_arbace_zip_eval703000008_fn__703000009_A_class }

func (t *A_arbace_zip_eval703000008_fn__703000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_eval703000008_fn__703000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_eval703000008_fn__703000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_eval703000008_fn__703000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_eval703000008_fn__703000009_A); return ok }

func A_arbace_zip_eval703000008_fn__703000009_A_Cast(x any) *A_arbace_zip_eval703000008_fn__703000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_eval703000008_fn__703000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_eval703000008_fn__703000009_A_class)) }; return v }



type A_arbace_zip_insert_child_A struct{ jrt.Object }

func (t *A_arbace_zip_insert_child_A) Is_Compiler_AOTF2() {}

var A_arbace_zip_insert_child_A_fn_class *jrt.Class

var A_arbace_zip_insert_child_A_init jrt.ClassInit

func A_arbace_zip_insert_child_A_Init() { if !A_arbace_zip_insert_child_A_init.Done() { A_arbace_zip_insert_child_A_init.Run(A_arbace_zip_insert_child_A_clinit) } }

func A_arbace_zip_insert_child_A_clinit() { A_arbace_zip_insert_child_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_65, lang.Compiler_AOTFn_class) }

func (t *A_arbace_zip_insert_child_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_insert_child_A) GetClass__Class() *jrt.Class { return A_arbace_zip_insert_child_A_class }

func (t *A_arbace_zip_insert_child_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_insert_child_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_insert_child_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_insert_child_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_insert_child_A); return ok }

func A_arbace_zip_insert_child_A_Cast(x any) *A_arbace_zip_insert_child_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_insert_child_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_insert_child_A_class)) }; return v }



type A_arbace_zip_insert_left_A struct{ jrt.Object }

func (t *A_arbace_zip_insert_left_A) Is_Compiler_AOTF2() {}

var A_arbace_zip_insert_left_A_fn_class *jrt.Class

var A_arbace_zip_insert_left_A_init jrt.ClassInit

func A_arbace_zip_insert_left_A_Init() { if !A_arbace_zip_insert_left_A_init.Done() { A_arbace_zip_insert_left_A_init.Run(A_arbace_zip_insert_left_A_clinit) } }

func A_arbace_zip_insert_left_A_clinit() { A_arbace_zip_insert_left_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_66, lang.Compiler_AOTFn_class) }

func (t *A_arbace_zip_insert_left_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_insert_left_A) GetClass__Class() *jrt.Class { return A_arbace_zip_insert_left_A_class }

func (t *A_arbace_zip_insert_left_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_insert_left_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_insert_left_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_insert_left_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_insert_left_A); return ok }

func A_arbace_zip_insert_left_A_Cast(x any) *A_arbace_zip_insert_left_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_insert_left_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_insert_left_A_class)) }; return v }



type A_arbace_zip_insert_right_A struct{ jrt.Object }

func (t *A_arbace_zip_insert_right_A) Is_Compiler_AOTF2() {}

var A_arbace_zip_insert_right_A_fn_class *jrt.Class

var A_arbace_zip_insert_right_A_init jrt.ClassInit

func A_arbace_zip_insert_right_A_Init() { if !A_arbace_zip_insert_right_A_init.Done() { A_arbace_zip_insert_right_A_init.Run(A_arbace_zip_insert_right_A_clinit) } }

func A_arbace_zip_insert_right_A_clinit() { A_arbace_zip_insert_right_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_68, lang.Compiler_AOTFn_class) }

func (t *A_arbace_zip_insert_right_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_insert_right_A) GetClass__Class() *jrt.Class { return A_arbace_zip_insert_right_A_class }

func (t *A_arbace_zip_insert_right_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_insert_right_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_insert_right_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_insert_right_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_insert_right_A); return ok }

func A_arbace_zip_insert_right_A_Cast(x any) *A_arbace_zip_insert_right_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_insert_right_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_insert_right_A_class)) }; return v }



type A_arbace_zip_left_A struct{ jrt.Object }

func (t *A_arbace_zip_left_A) Is_Compiler_AOTF1() {}

var A_arbace_zip_left_A_fn_class *jrt.Class

var A_arbace_zip_left_A_init jrt.ClassInit

func A_arbace_zip_left_A_Init() { if !A_arbace_zip_left_A_init.Done() { A_arbace_zip_left_A_init.Run(A_arbace_zip_left_A_clinit) } }

func A_arbace_zip_left_A_clinit() { A_arbace_zip_left_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_69, lang.Compiler_AOTFn_class) }

func (t *A_arbace_zip_left_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_left_A) GetClass__Class() *jrt.Class { return A_arbace_zip_left_A_class }

func (t *A_arbace_zip_left_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_left_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_left_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_left_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_left_A); return ok }

func A_arbace_zip_left_A_Cast(x any) *A_arbace_zip_left_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_left_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_left_A_class)) }; return v }



type A_arbace_zip_leftmost_A struct{ jrt.Object }

func (t *A_arbace_zip_leftmost_A) Is_Compiler_AOTF1() {}

var A_arbace_zip_leftmost_A_fn_class *jrt.Class

var A_arbace_zip_leftmost_A_init jrt.ClassInit

func A_arbace_zip_leftmost_A_Init() { if !A_arbace_zip_leftmost_A_init.Done() { A_arbace_zip_leftmost_A_init.Run(A_arbace_zip_leftmost_A_clinit) } }

func A_arbace_zip_leftmost_A_clinit() { A_arbace_zip_leftmost_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_70, lang.Compiler_AOTFn_class) }

func (t *A_arbace_zip_leftmost_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_leftmost_A) GetClass__Class() *jrt.Class { return A_arbace_zip_leftmost_A_class }

func (t *A_arbace_zip_leftmost_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_leftmost_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_leftmost_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_leftmost_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_leftmost_A); return ok }

func A_arbace_zip_leftmost_A_Cast(x any) *A_arbace_zip_leftmost_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_leftmost_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_leftmost_A_class)) }; return v }



type A_arbace_zip_lefts_A struct{ jrt.Object }

func (t *A_arbace_zip_lefts_A) Is_Compiler_AOTF1() {}

var A_arbace_zip_lefts_A_fn_class *jrt.Class

var A_arbace_zip_lefts_A_init jrt.ClassInit

func A_arbace_zip_lefts_A_Init() { if !A_arbace_zip_lefts_A_init.Done() { A_arbace_zip_lefts_A_init.Run(A_arbace_zip_lefts_A_clinit) } }

func A_arbace_zip_lefts_A_clinit() { A_arbace_zip_lefts_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_71, lang.Compiler_AOTFn_class) }

func (t *A_arbace_zip_lefts_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_lefts_A) GetClass__Class() *jrt.Class { return A_arbace_zip_lefts_A_class }

func (t *A_arbace_zip_lefts_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_lefts_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_lefts_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_lefts_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_lefts_A); return ok }

func A_arbace_zip_lefts_A_Cast(x any) *A_arbace_zip_lefts_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_lefts_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_lefts_A_class)) }; return v }



type A_arbace_zip_make_node_A struct{ jrt.Object }

func (t *A_arbace_zip_make_node_A) Is_Compiler_AOTF3() {}

var A_arbace_zip_make_node_A_fn_class *jrt.Class

var A_arbace_zip_make_node_A_init jrt.ClassInit

func A_arbace_zip_make_node_A_Init() { if !A_arbace_zip_make_node_A_init.Done() { A_arbace_zip_make_node_A_init.Run(A_arbace_zip_make_node_A_clinit) } }

func A_arbace_zip_make_node_A_clinit() { A_arbace_zip_make_node_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_72, lang.Compiler_AOTFn_class) }

func (t *A_arbace_zip_make_node_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_make_node_A) GetClass__Class() *jrt.Class { return A_arbace_zip_make_node_A_class }

func (t *A_arbace_zip_make_node_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_make_node_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_make_node_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_make_node_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_make_node_A); return ok }

func A_arbace_zip_make_node_A_Cast(x any) *A_arbace_zip_make_node_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_make_node_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_make_node_A_class)) }; return v }



type A_arbace_zip_next_A struct{ jrt.Object }

func (t *A_arbace_zip_next_A) Is_Compiler_AOTF1() {}

var A_arbace_zip_next_A_fn_class *jrt.Class

var A_arbace_zip_next_A_init jrt.ClassInit

func A_arbace_zip_next_A_Init() { if !A_arbace_zip_next_A_init.Done() { A_arbace_zip_next_A_init.Run(A_arbace_zip_next_A_clinit) } }

func A_arbace_zip_next_A_clinit() { A_arbace_zip_next_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_73, lang.Compiler_AOTFn_class) }

func (t *A_arbace_zip_next_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_next_A) GetClass__Class() *jrt.Class { return A_arbace_zip_next_A_class }

func (t *A_arbace_zip_next_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_next_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_next_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_next_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_next_A); return ok }

func A_arbace_zip_next_A_Cast(x any) *A_arbace_zip_next_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_next_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_next_A_class)) }; return v }



type A_arbace_zip_node_A struct{ jrt.Object }

func (t *A_arbace_zip_node_A) Is_Compiler_AOTF1() {}

var A_arbace_zip_node_A_fn_class *jrt.Class

var A_arbace_zip_node_A_init jrt.ClassInit

func A_arbace_zip_node_A_Init() { if !A_arbace_zip_node_A_init.Done() { A_arbace_zip_node_A_init.Run(A_arbace_zip_node_A_clinit) } }

func A_arbace_zip_node_A_clinit() { A_arbace_zip_node_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_74, lang.Compiler_AOTFn_class) }

func (t *A_arbace_zip_node_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_node_A) GetClass__Class() *jrt.Class { return A_arbace_zip_node_A_class }

func (t *A_arbace_zip_node_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_node_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_node_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_node_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_node_A); return ok }

func A_arbace_zip_node_A_Cast(x any) *A_arbace_zip_node_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_node_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_node_A_class)) }; return v }



type A_arbace_zip_path_A struct{ jrt.Object }

func (t *A_arbace_zip_path_A) Is_Compiler_AOTF1() {}

var A_arbace_zip_path_A_fn_class *jrt.Class

var A_arbace_zip_path_A_init jrt.ClassInit

func A_arbace_zip_path_A_Init() { if !A_arbace_zip_path_A_init.Done() { A_arbace_zip_path_A_init.Run(A_arbace_zip_path_A_clinit) } }

func A_arbace_zip_path_A_clinit() { A_arbace_zip_path_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_75, lang.Compiler_AOTFn_class) }

func (t *A_arbace_zip_path_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_path_A) GetClass__Class() *jrt.Class { return A_arbace_zip_path_A_class }

func (t *A_arbace_zip_path_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_path_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_path_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_path_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_path_A); return ok }

func A_arbace_zip_path_A_Cast(x any) *A_arbace_zip_path_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_path_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_path_A_class)) }; return v }



type A_arbace_zip_prev_A struct{ jrt.Object }

func (t *A_arbace_zip_prev_A) Is_Compiler_AOTF1() {}

var A_arbace_zip_prev_A_fn_class *jrt.Class

var A_arbace_zip_prev_A_init jrt.ClassInit

func A_arbace_zip_prev_A_Init() { if !A_arbace_zip_prev_A_init.Done() { A_arbace_zip_prev_A_init.Run(A_arbace_zip_prev_A_clinit) } }

func A_arbace_zip_prev_A_clinit() { A_arbace_zip_prev_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_76, lang.Compiler_AOTFn_class) }

func (t *A_arbace_zip_prev_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_prev_A) GetClass__Class() *jrt.Class { return A_arbace_zip_prev_A_class }

func (t *A_arbace_zip_prev_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_prev_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_prev_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_prev_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_prev_A); return ok }

func A_arbace_zip_prev_A_Cast(x any) *A_arbace_zip_prev_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_prev_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_prev_A_class)) }; return v }



type A_arbace_zip_remove_A struct{ jrt.Object }

func (t *A_arbace_zip_remove_A) Is_Compiler_AOTF1() {}

var A_arbace_zip_remove_A_fn_class *jrt.Class

var A_arbace_zip_remove_A_init jrt.ClassInit

func A_arbace_zip_remove_A_Init() { if !A_arbace_zip_remove_A_init.Done() { A_arbace_zip_remove_A_init.Run(A_arbace_zip_remove_A_clinit) } }

func A_arbace_zip_remove_A_clinit() { A_arbace_zip_remove_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_77, lang.Compiler_AOTFn_class) }

func (t *A_arbace_zip_remove_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_remove_A) GetClass__Class() *jrt.Class { return A_arbace_zip_remove_A_class }

func (t *A_arbace_zip_remove_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_remove_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_remove_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_remove_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_remove_A); return ok }

func A_arbace_zip_remove_A_Cast(x any) *A_arbace_zip_remove_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_remove_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_remove_A_class)) }; return v }



type A_arbace_zip_replace_A struct{ jrt.Object }

func (t *A_arbace_zip_replace_A) Is_Compiler_AOTF2() {}

var A_arbace_zip_replace_A_fn_class *jrt.Class

var A_arbace_zip_replace_A_init jrt.ClassInit

func A_arbace_zip_replace_A_Init() { if !A_arbace_zip_replace_A_init.Done() { A_arbace_zip_replace_A_init.Run(A_arbace_zip_replace_A_clinit) } }

func A_arbace_zip_replace_A_clinit() { A_arbace_zip_replace_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_79, lang.Compiler_AOTFn_class) }

func (t *A_arbace_zip_replace_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_replace_A) GetClass__Class() *jrt.Class { return A_arbace_zip_replace_A_class }

func (t *A_arbace_zip_replace_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_replace_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_replace_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_replace_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_replace_A); return ok }

func A_arbace_zip_replace_A_Cast(x any) *A_arbace_zip_replace_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_replace_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_replace_A_class)) }; return v }



type A_arbace_zip_right_A struct{ jrt.Object }

func (t *A_arbace_zip_right_A) Is_Compiler_AOTF1() {}

var A_arbace_zip_right_A_fn_class *jrt.Class

var A_arbace_zip_right_A_init jrt.ClassInit

func A_arbace_zip_right_A_Init() { if !A_arbace_zip_right_A_init.Done() { A_arbace_zip_right_A_init.Run(A_arbace_zip_right_A_clinit) } }

func A_arbace_zip_right_A_clinit() { A_arbace_zip_right_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_80, lang.Compiler_AOTFn_class) }

func (t *A_arbace_zip_right_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_right_A) GetClass__Class() *jrt.Class { return A_arbace_zip_right_A_class }

func (t *A_arbace_zip_right_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_right_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_right_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_right_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_right_A); return ok }

func A_arbace_zip_right_A_Cast(x any) *A_arbace_zip_right_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_right_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_right_A_class)) }; return v }



type A_arbace_zip_rightmost_A struct{ jrt.Object }

func (t *A_arbace_zip_rightmost_A) Is_Compiler_AOTF1() {}

var A_arbace_zip_rightmost_A_fn_class *jrt.Class

var A_arbace_zip_rightmost_A_init jrt.ClassInit

func A_arbace_zip_rightmost_A_Init() { if !A_arbace_zip_rightmost_A_init.Done() { A_arbace_zip_rightmost_A_init.Run(A_arbace_zip_rightmost_A_clinit) } }

func A_arbace_zip_rightmost_A_clinit() { A_arbace_zip_rightmost_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_81, lang.Compiler_AOTFn_class) }

func (t *A_arbace_zip_rightmost_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_rightmost_A) GetClass__Class() *jrt.Class { return A_arbace_zip_rightmost_A_class }

func (t *A_arbace_zip_rightmost_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_rightmost_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_rightmost_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_rightmost_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_rightmost_A); return ok }

func A_arbace_zip_rightmost_A_Cast(x any) *A_arbace_zip_rightmost_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_rightmost_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_rightmost_A_class)) }; return v }



type A_arbace_zip_rights_A struct{ jrt.Object }

func (t *A_arbace_zip_rights_A) Is_Compiler_AOTF1() {}

var A_arbace_zip_rights_A_fn_class *jrt.Class

var A_arbace_zip_rights_A_init jrt.ClassInit

func A_arbace_zip_rights_A_Init() { if !A_arbace_zip_rights_A_init.Done() { A_arbace_zip_rights_A_init.Run(A_arbace_zip_rights_A_clinit) } }

func A_arbace_zip_rights_A_clinit() { A_arbace_zip_rights_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_82, lang.Compiler_AOTFn_class) }

func (t *A_arbace_zip_rights_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_rights_A) GetClass__Class() *jrt.Class { return A_arbace_zip_rights_A_class }

func (t *A_arbace_zip_rights_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_rights_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_rights_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_rights_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_rights_A); return ok }

func A_arbace_zip_rights_A_Cast(x any) *A_arbace_zip_rights_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_rights_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_rights_A_class)) }; return v }



type A_arbace_zip_root_A struct{ jrt.Object }

func (t *A_arbace_zip_root_A) Is_Compiler_AOTF1() {}

var A_arbace_zip_root_A_fn_class *jrt.Class

var A_arbace_zip_root_A_init jrt.ClassInit

func A_arbace_zip_root_A_Init() { if !A_arbace_zip_root_A_init.Done() { A_arbace_zip_root_A_init.Run(A_arbace_zip_root_A_clinit) } }

func A_arbace_zip_root_A_clinit() { A_arbace_zip_root_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_83, lang.Compiler_AOTFn_class) }

func (t *A_arbace_zip_root_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_root_A) GetClass__Class() *jrt.Class { return A_arbace_zip_root_A_class }

func (t *A_arbace_zip_root_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_root_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_root_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_root_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_root_A); return ok }

func A_arbace_zip_root_A_Cast(x any) *A_arbace_zip_root_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_root_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_root_A_class)) }; return v }



type A_arbace_zip_seq_zip_A struct{ jrt.Object }

func (t *A_arbace_zip_seq_zip_A) Is_Compiler_AOTF1() {}

var A_arbace_zip_seq_zip_A_fn_class *jrt.Class

var A_arbace_zip_seq_zip_A_init jrt.ClassInit

func A_arbace_zip_seq_zip_A_Init() { if !A_arbace_zip_seq_zip_A_init.Done() { A_arbace_zip_seq_zip_A_init.Run(A_arbace_zip_seq_zip_A_clinit) } }

func A_arbace_zip_seq_zip_A_clinit() { A_arbace_zip_seq_zip_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_84, lang.Compiler_AOTFn_class) }

func (t *A_arbace_zip_seq_zip_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_seq_zip_A) GetClass__Class() *jrt.Class { return A_arbace_zip_seq_zip_A_class }

func (t *A_arbace_zip_seq_zip_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_seq_zip_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_seq_zip_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_seq_zip_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_seq_zip_A); return ok }

func A_arbace_zip_seq_zip_A_Cast(x any) *A_arbace_zip_seq_zip_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_seq_zip_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_seq_zip_A_class)) }; return v }



type A_arbace_zip_seq_zip_fn__703000013_A struct{ jrt.Object }

func (t *A_arbace_zip_seq_zip_fn__703000013_A) Is_Compiler_AOTF2() {}

var A_arbace_zip_seq_zip_fn__703000013_A_fn_class *jrt.Class

var A_arbace_zip_seq_zip_fn__703000013_A_init jrt.ClassInit

func A_arbace_zip_seq_zip_fn__703000013_A_Init() { if !A_arbace_zip_seq_zip_fn__703000013_A_init.Done() { A_arbace_zip_seq_zip_fn__703000013_A_init.Run(A_arbace_zip_seq_zip_fn__703000013_A_clinit) } }

func A_arbace_zip_seq_zip_fn__703000013_A_clinit() { A_arbace_zip_seq_zip_fn__703000013_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_85, lang.Compiler_AOTFn_class) }

func (t *A_arbace_zip_seq_zip_fn__703000013_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_seq_zip_fn__703000013_A) GetClass__Class() *jrt.Class { return A_arbace_zip_seq_zip_fn__703000013_A_class }

func (t *A_arbace_zip_seq_zip_fn__703000013_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_seq_zip_fn__703000013_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_seq_zip_fn__703000013_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_seq_zip_fn__703000013_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_seq_zip_fn__703000013_A); return ok }

func A_arbace_zip_seq_zip_fn__703000013_A_Cast(x any) *A_arbace_zip_seq_zip_fn__703000013_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_seq_zip_fn__703000013_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_seq_zip_fn__703000013_A_class)) }; return v }



type A_arbace_zip_up_A struct{ jrt.Object }

func (t *A_arbace_zip_up_A) Is_Compiler_AOTF1() {}

var A_arbace_zip_up_A_fn_class *jrt.Class

var A_arbace_zip_up_A_init jrt.ClassInit

func A_arbace_zip_up_A_Init() { if !A_arbace_zip_up_A_init.Done() { A_arbace_zip_up_A_init.Run(A_arbace_zip_up_A_clinit) } }

func A_arbace_zip_up_A_clinit() { A_arbace_zip_up_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_86, lang.Compiler_AOTFn_class) }

func (t *A_arbace_zip_up_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_up_A) GetClass__Class() *jrt.Class { return A_arbace_zip_up_A_class }

func (t *A_arbace_zip_up_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_up_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_up_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_up_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_up_A); return ok }

func A_arbace_zip_up_A_Cast(x any) *A_arbace_zip_up_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_up_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_up_A_class)) }; return v }



type A_arbace_zip_vector_zip_A struct{ jrt.Object }

func (t *A_arbace_zip_vector_zip_A) Is_Compiler_AOTF1() {}

var A_arbace_zip_vector_zip_A_fn_class *jrt.Class

var A_arbace_zip_vector_zip_A_init jrt.ClassInit

func A_arbace_zip_vector_zip_A_Init() { if !A_arbace_zip_vector_zip_A_init.Done() { A_arbace_zip_vector_zip_A_init.Run(A_arbace_zip_vector_zip_A_clinit) } }

func A_arbace_zip_vector_zip_A_clinit() { A_arbace_zip_vector_zip_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_87, lang.Compiler_AOTFn_class) }

func (t *A_arbace_zip_vector_zip_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_vector_zip_A) GetClass__Class() *jrt.Class { return A_arbace_zip_vector_zip_A_class }

func (t *A_arbace_zip_vector_zip_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_vector_zip_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_vector_zip_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_vector_zip_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_vector_zip_A); return ok }

func A_arbace_zip_vector_zip_A_Cast(x any) *A_arbace_zip_vector_zip_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_vector_zip_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_vector_zip_A_class)) }; return v }



type A_arbace_zip_vector_zip_fn__703000016_A struct{ jrt.Object }

func (t *A_arbace_zip_vector_zip_fn__703000016_A) Is_Compiler_AOTF2() {}

var A_arbace_zip_vector_zip_fn__703000016_A_fn_class *jrt.Class

var A_arbace_zip_vector_zip_fn__703000016_A_init jrt.ClassInit

func A_arbace_zip_vector_zip_fn__703000016_A_Init() { if !A_arbace_zip_vector_zip_fn__703000016_A_init.Done() { A_arbace_zip_vector_zip_fn__703000016_A_init.Run(A_arbace_zip_vector_zip_fn__703000016_A_clinit) } }

func A_arbace_zip_vector_zip_fn__703000016_A_clinit() { A_arbace_zip_vector_zip_fn__703000016_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_88, lang.Compiler_AOTFn_class) }

func (t *A_arbace_zip_vector_zip_fn__703000016_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_vector_zip_fn__703000016_A) GetClass__Class() *jrt.Class { return A_arbace_zip_vector_zip_fn__703000016_A_class }

func (t *A_arbace_zip_vector_zip_fn__703000016_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_vector_zip_fn__703000016_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_vector_zip_fn__703000016_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_vector_zip_fn__703000016_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_vector_zip_fn__703000016_A); return ok }

func A_arbace_zip_vector_zip_fn__703000016_A_Cast(x any) *A_arbace_zip_vector_zip_fn__703000016_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_vector_zip_fn__703000016_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_vector_zip_fn__703000016_A_class)) }; return v }



type A_arbace_zip_xml_zip_A struct{ jrt.Object }

func (t *A_arbace_zip_xml_zip_A) Is_Compiler_AOTF1() {}

var A_arbace_zip_xml_zip_A_fn_class *jrt.Class

var A_arbace_zip_xml_zip_A_init jrt.ClassInit

func A_arbace_zip_xml_zip_A_Init() { if !A_arbace_zip_xml_zip_A_init.Done() { A_arbace_zip_xml_zip_A_init.Run(A_arbace_zip_xml_zip_A_clinit) } }

func A_arbace_zip_xml_zip_A_clinit() { A_arbace_zip_xml_zip_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_89, lang.Compiler_AOTFn_class) }

func (t *A_arbace_zip_xml_zip_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_xml_zip_A) GetClass__Class() *jrt.Class { return A_arbace_zip_xml_zip_A_class }

func (t *A_arbace_zip_xml_zip_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_xml_zip_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_xml_zip_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_xml_zip_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_xml_zip_A); return ok }

func A_arbace_zip_xml_zip_A_Cast(x any) *A_arbace_zip_xml_zip_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_xml_zip_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_xml_zip_A_class)) }; return v }



type A_arbace_zip_xml_zip_fn__703000019_A struct{ jrt.Object }

func (t *A_arbace_zip_xml_zip_fn__703000019_A) Is_Compiler_AOTF2() {}

var A_arbace_zip_xml_zip_fn__703000019_A_fn_class *jrt.Class

var A_arbace_zip_xml_zip_fn__703000019_A_init jrt.ClassInit

func A_arbace_zip_xml_zip_fn__703000019_A_Init() { if !A_arbace_zip_xml_zip_fn__703000019_A_init.Done() { A_arbace_zip_xml_zip_fn__703000019_A_init.Run(A_arbace_zip_xml_zip_fn__703000019_A_clinit) } }

func A_arbace_zip_xml_zip_fn__703000019_A_clinit() { A_arbace_zip_xml_zip_fn__703000019_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_90, lang.Compiler_AOTFn_class) }

func (t *A_arbace_zip_xml_zip_fn__703000019_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_xml_zip_fn__703000019_A) GetClass__Class() *jrt.Class { return A_arbace_zip_xml_zip_fn__703000019_A_class }

func (t *A_arbace_zip_xml_zip_fn__703000019_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_xml_zip_fn__703000019_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_xml_zip_fn__703000019_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_xml_zip_fn__703000019_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_xml_zip_fn__703000019_A); return ok }

func A_arbace_zip_xml_zip_fn__703000019_A_Cast(x any) *A_arbace_zip_xml_zip_fn__703000019_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_xml_zip_fn__703000019_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_xml_zip_fn__703000019_A_class)) }; return v }



type A_arbace_zip_zipper_A struct{ jrt.Object }

func (t *A_arbace_zip_zipper_A) Is_Compiler_AOTF4() {}

var A_arbace_zip_zipper_A_fn_class *jrt.Class

var A_arbace_zip_zipper_A_init jrt.ClassInit

func A_arbace_zip_zipper_A_Init() { if !A_arbace_zip_zipper_A_init.Done() { A_arbace_zip_zipper_A_init.Run(A_arbace_zip_zipper_A_clinit) } }

func A_arbace_zip_zipper_A_clinit() { A_arbace_zip_zipper_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_91, lang.Compiler_AOTFn_class) }

func (t *A_arbace_zip_zipper_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_zipper_A) GetClass__Class() *jrt.Class { return A_arbace_zip_zipper_A_class }

func (t *A_arbace_zip_zipper_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_zipper_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_zipper_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_zipper_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_zipper_A); return ok }

func A_arbace_zip_zipper_A_Cast(x any) *A_arbace_zip_zipper_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_zipper_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_zipper_A_class)) }; return v }
