//line aot_arbace_zip.ae:1
package aot_arbace_zip

import (
	"arbace/jrt"
	"arbace/lang"
)





func A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_New() *A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A{}; t.Ctor(); return t }
//line :12:1
func (t *A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A) Ctor() {}
//line :12:1
func (t *A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp3 = lang.IFn_Cast(A_arbace_zip_A_const_0.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_zip_A_const_1, A_arbace_zip_A_const_2, A_arbace_zip_A_const_3); return nil }(); lang.Var_PopThreadBindings__V(); if tmp4 != nil { panic(tmp4) }; return tmp3 }
//line :12:1
func A_arbace_zip_eval703000008_fn__703000009_A_New() *A_arbace_zip_eval703000008_fn__703000009_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_eval703000008_fn__703000009_A{}; t.Ctor(); return t }
//line :12:1
func (t *A_arbace_zip_eval703000008_fn__703000009_A) Ctor() {}
//line :12:1
func (t *A_arbace_zip_eval703000008_fn__703000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_zip_A_const_4.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_zip_A_const_5.GetRawRoot__O()).Invoke_O__O(A_arbace_zip_A_const_8), A_arbace_zip_A_const_6.GetRawRoot__O(), A_arbace_zip_A_const_7) }





func A_arbace_zip_zipper_A_New() *A_arbace_zip_zipper_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_zipper_A{}; t.Ctor(); return t }
//line :18:1
func (t *A_arbace_zip_zipper_A) Ctor() {}
//line :18:1
func (t *A_arbace_zip_zipper_A) Invoke_O_O_O_O_O__O(self, branch_QMARK___0, children__1, make_node__2, root__3 any) any { return lang.IObj_Cast(lang.Tuple_Create_O_O__IPersistentVector(root__3, nil)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_zip_A_const_9, branch_QMARK___0, A_arbace_zip_A_const_10, children__1, A_arbace_zip_A_const_11, make_node__2))) }
















func A_arbace_zip_seq_zip_A_New() *A_arbace_zip_seq_zip_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_seq_zip_A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_zip_seq_zip_A) Ctor() {}
//line :35:1
func (t *A_arbace_zip_seq_zip_A) Invoke_O_O__O(self, root__0 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_zip_A_const_12.GetRawRoot__O()); var tmp2 any = A_arbace_zip_A_const_13.GetRawRoot__O(); var tmp3 any = A_arbace_zip_A_const_14.GetRawRoot__O(); var tmp4 any = A_arbace_zip_seq_zip_fn__703000013_A_New(); var tmp5 *jrt.Class
	var fncls__1 /*line :39:1*/*jrt.Class = A_arbace_zip_seq_zip_fn__703000013_A_fn_class

	if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_4, false); A_arbace_zip_seq_zip_fn__703000013_A_fn_class = fncls__1d; tmp5 = fncls__1d } else { tmp5 = fncls__1 }
//line :39:1
	return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), root__0)
}
func A_arbace_zip_seq_zip_fn__703000013_A_New() *A_arbace_zip_seq_zip_fn__703000013_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_seq_zip_fn__703000013_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_zip_seq_zip_fn__703000013_A) Ctor() {}
//line :41:1
func (t *A_arbace_zip_seq_zip_fn__703000013_A) Invoke_O_O_O__O(self, node__1, children__2 any) any { return lang.IFn_Cast(A_arbace_zip_A_const_15.GetRawRoot__O()).Invoke_O_O__O(children__2, lang.RT_Meta_O__IPersistentMap(node__1)) }


func A_arbace_zip_vector_zip_A_New() *A_arbace_zip_vector_zip_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_vector_zip_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_zip_vector_zip_A) Ctor() {}
//line :44:1
func (t *A_arbace_zip_vector_zip_A) Invoke_O_O__O(self, root__0 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_zip_A_const_12.GetRawRoot__O()); var tmp2 any = A_arbace_zip_A_const_16.GetRawRoot__O(); var tmp3 any = A_arbace_zip_A_const_17.GetRawRoot__O(); var tmp4 any = A_arbace_zip_vector_zip_fn__703000016_A_New(); var tmp5 *jrt.Class
	var fncls__2 /*line :48:1*/*jrt.Class = A_arbace_zip_vector_zip_fn__703000016_A_fn_class

	if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_5, false); A_arbace_zip_vector_zip_fn__703000016_A_fn_class = fncls__2d; tmp5 = fncls__2d } else { tmp5 = fncls__2 }
//line :48:1
	return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), root__0)
}
func A_arbace_zip_vector_zip_fn__703000016_A_New() *A_arbace_zip_vector_zip_fn__703000016_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_vector_zip_fn__703000016_A{}; t.Ctor(); return t }
//line :50:1
func (t *A_arbace_zip_vector_zip_fn__703000016_A) Ctor() {}
//line :50:1
func (t *A_arbace_zip_vector_zip_fn__703000016_A) Invoke_O_O_O__O(self, node__1, children__2 any) any { return lang.IFn_Cast(A_arbace_zip_A_const_15.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_zip_A_const_18.GetRawRoot__O()).Invoke_O__O(children__2), lang.RT_Meta_O__IPersistentMap(node__1)) }


func A_arbace_zip_xml_zip_A_New() *A_arbace_zip_xml_zip_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_xml_zip_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_zip_xml_zip_A) Ctor() {}
//line :53:1
func (t *A_arbace_zip_xml_zip_A) Invoke_O_O__O(self, root__0 any) any {




	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_zip_A_const_12.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_zip_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_zip_A_const_25.GetRawRoot__O()); var tmp3 any = lang.IFn_Cast(A_arbace_zip_A_const_20.GetRawRoot__O()).Invoke_O_O__O(A_arbace_zip_A_const_17.GetRawRoot__O(), A_arbace_zip_A_const_22); var tmp4 any = A_arbace_zip_xml_zip_fn__703000019_A_New(); var tmp5 *jrt.Class
	var fncls__3 /*line :58:1*/*jrt.Class = A_arbace_zip_xml_zip_fn__703000019_A_fn_class

	if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_6, false); A_arbace_zip_xml_zip_fn__703000019_A_fn_class = fncls__3d; tmp5 = fncls__3d } else { tmp5 = fncls__3 }
//line :58:1
	return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), root__0)
}
func A_arbace_zip_xml_zip_fn__703000019_A_New() *A_arbace_zip_xml_zip_fn__703000019_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_xml_zip_fn__703000019_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_zip_xml_zip_fn__703000019_A) Ctor() {}
//line :60:1
func (t *A_arbace_zip_xml_zip_fn__703000019_A) Invoke_O_O_O__O(self, node__1, children__2 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_zip_A_const_21.GetRawRoot__O()); var tmp2 any = A_arbace_zip_A_const_22; var tmp3 any; var and__1927000168__auto____3 any = children__2; if jrt.A2g_Truth(and__1927000168__auto____3) { tmp3 = lang.IFn_Cast(A_arbace_zip_A_const_23.GetRawRoot__O()).Invoke_O_O__O(A_arbace_zip_A_const_24.GetRawRoot__O(), children__2) } else { tmp3 = and__1927000168__auto____3 }; return tmp1.Invoke_O_O_O__O(node__1, tmp2, tmp3)
}

func A_arbace_zip_node_A_New() *A_arbace_zip_node_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_node_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_zip_node_A) Ctor() {}
//line :64:1
func (t *A_arbace_zip_node_A) Invoke_O_O__O(self, loc__0 any) any {


	return lang.IFn_Cast(loc__0).Invoke_O__O(A_arbace_zip_A_const_26)
}
func A_arbace_zip_branch_QMARK__A_New() *A_arbace_zip_branch_QMARK__A { A_arbace_zip_A_Init(); t := &A_arbace_zip_branch_QMARK__A{}; t.Ctor(); return t }
//line :69:1
func (t *A_arbace_zip_branch_QMARK__A) Ctor() {}
//line :69:1
func (t *A_arbace_zip_branch_QMARK__A) Invoke_O_O__O(self, loc__0 any) any {



	var tmp1 *lang.Keyword = A_arbace_zip_A_const_9; return lang.IFn_Cast(tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(loc__0))).Invoke_O__O(lang.IFn_Cast(A_arbace_zip_A_const_27.GetRawRoot__O()).Invoke_O__O(loc__0))
}
func A_arbace_zip_children_A_New() *A_arbace_zip_children_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_children_A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_zip_children_A) Ctor() {}
//line :75:1
func (t *A_arbace_zip_children_A) Invoke_O_O__O(self, loc__0 any) any {



	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_zip_A_const_28.GetRawRoot__O()).Invoke_O__O(loc__0)) {
		var tmp1 *lang.Keyword = A_arbace_zip_A_const_10; return lang.IFn_Cast(tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(loc__0))).Invoke_O__O(lang.IFn_Cast(A_arbace_zip_A_const_27.GetRawRoot__O()).Invoke_O__O(loc__0)) } else {
//line :79:1
			panic(jrt.Thrown(jrt.Exception_New_String(Lit_1)))
		}
}

func A_arbace_zip_make_node_A_New() *A_arbace_zip_make_node_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_make_node_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_zip_make_node_A) Ctor() {}
//line :83:1
func (t *A_arbace_zip_make_node_A) Invoke_O_O_O_O__O(self, loc__0, node__1, children__2 any) any {




	var tmp1 *lang.Keyword = A_arbace_zip_A_const_11; return lang.IFn_Cast(tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(loc__0))).Invoke_O_O__O(node__1, children__2)
}
func A_arbace_zip_path_A_New() *A_arbace_zip_path_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_path_A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_zip_path_A) Ctor() {}
//line :90:1
func (t *A_arbace_zip_path_A) Invoke_O_O__O(self, loc__0 any) any {



	var tmp1 *lang.Keyword = A_arbace_zip_A_const_29; return tmp1.Invoke_O__O(lang.IFn_Cast(loc__0).Invoke_O__O(A_arbace_zip_A_const_30))
}
func A_arbace_zip_lefts_A_New() *A_arbace_zip_lefts_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_lefts_A{}; t.Ctor(); return t }
//line :96:1
func (t *A_arbace_zip_lefts_A) Ctor() {}
//line :96:1
func (t *A_arbace_zip_lefts_A) Invoke_O_O__O(self, loc__0 any) any {



	var tmp1 *lang.Keyword = A_arbace_zip_A_const_31; return lang.IFn_Cast(A_arbace_zip_A_const_17.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(loc__0).Invoke_O__O(A_arbace_zip_A_const_30)))
}
func A_arbace_zip_rights_A_New() *A_arbace_zip_rights_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_rights_A{}; t.Ctor(); return t }
//line :102:1
func (t *A_arbace_zip_rights_A) Ctor() {}
//line :102:1
func (t *A_arbace_zip_rights_A) Invoke_O_O__O(self, loc__0 any) any {



	var tmp1 *lang.Keyword = A_arbace_zip_A_const_32; return tmp1.Invoke_O__O(lang.IFn_Cast(loc__0).Invoke_O__O(A_arbace_zip_A_const_30))
}
func A_arbace_zip_down_A_New() *A_arbace_zip_down_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_down_A{}; t.Ctor(); return t }
//line :108:1
func (t *A_arbace_zip_down_A) Ctor() {}
//line :108:1
func (t *A_arbace_zip_down_A) Invoke_O_O__O(self, loc__0 any) any {




	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_zip_A_const_28.GetRawRoot__O()).Invoke_O__O(loc__0)) { var vec__703000029__2 any = loc__0; var node__3 any = lang.RT_Nth_O_I_O__O(vec__703000029__2, lang.RT_IntCast_J__I(0), nil); var path__4 any = lang.RT_Nth_O_I_O__O(vec__703000029__2, lang.RT_IntCast_J__I(1), nil); var vec__703000032__5 any = lang.IFn_Cast(A_arbace_zip_A_const_33.GetRawRoot__O()).Invoke_O__O(loc__0); var seq__703000033__6 any = lang.IFn_Cast(A_arbace_zip_A_const_17.GetRawRoot__O()).Invoke_O__O(vec__703000032__5); var first__703000034__7 any = lang.IFn_Cast(A_arbace_zip_A_const_34.GetRawRoot__O()).Invoke_O__O(seq__703000033__6); var seq__703000033__8 any = lang.IFn_Cast(A_arbace_zip_A_const_35.GetRawRoot__O()).Invoke_O__O(seq__703000033__6)
		var c__9 any = first__703000034__7
		var cnext__10 any = seq__703000033__8; var cs__11 any = vec__703000032__5
		if jrt.A2g_Truth(cs__11) {
			var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_zip_A_const_15.GetRawRoot__O()); var tmp2 any = A_arbace_zip_A_const_31; var tmp3 *lang.PersistentVector; lang.PersistentVector_Init(); tmp3 = lang.PersistentVector_EMPTY; var tmp4 any = tmp3.Ref(); var tmp5 any = A_arbace_zip_A_const_29; var tmp6 any
			if jrt.A2g_Truth(path__4) { tmp6 = lang.IFn_Cast(A_arbace_zip_A_const_6.GetRawRoot__O()).Invoke_O_O__O(A_arbace_zip_A_const_29.Invoke_O__O(path__4), node__3) } else { tmp6 = lang.Tuple_Create_O__IPersistentVector(node__3) }
//line :117:1
			return tmp1.Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(c__9, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp4, tmp5, tmp6, A_arbace_zip_A_const_36, path__4, A_arbace_zip_A_const_32, cnext__10))), lang.RT_Meta_O__IPersistentMap(loc__0)) } else {
//line :116:1
				return nil } } else {
//line :113:1
					return nil
				}
}






func A_arbace_zip_up_A_New() *A_arbace_zip_up_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_up_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_zip_up_A) Ctor() {}
//line :122:1
func (t *A_arbace_zip_up_A) Invoke_O_O__O(self, loc__0 any) any { var vec__703000036__2 any = loc__0; var node__3 any = lang.RT_Nth_O_I_O__O(vec__703000036__2, lang.RT_IntCast_J__I(0), nil); var map__703000039__4 any = lang.RT_Nth_O_I_O__O(vec__703000036__2, lang.RT_IntCast_J__I(1), nil); var map__703000039__5 any; if




	lang.ISeq_InstanceOf(map__703000039__4) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_zip_A_const_35.GetRawRoot__O()).Invoke_O__O(map__703000039__4)) { map__703000039__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_zip_A_const_37.GetRawRoot__O()).Invoke_O__O(map__703000039__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_zip_A_const_17.GetRawRoot__O()).Invoke_O__O(map__703000039__4)) { map__703000039__5 = lang.IFn_Cast(A_arbace_zip_A_const_34.GetRawRoot__O()).Invoke_O__O(map__703000039__4) } else { lang.PersistentArrayMap_Init(); map__703000039__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__703000039__5 = map__703000039__4 }; var path__6 any = map__703000039__5; var l__7 any = /*line :122:1*/lang.RT_Get_O_O__O(map__703000039__5, A_arbace_zip_A_const_31); var ppath__8 any = lang.RT_Get_O_O__O(map__703000039__5, A_arbace_zip_A_const_36); var pnodes__9 any = lang.RT_Get_O_O__O(map__703000039__5, A_arbace_zip_A_const_29); var r__10 any = lang.RT_Get_O_O__O(map__703000039__5, A_arbace_zip_A_const_32); var changed_QMARK___11 any = lang.RT_Get_O_O__O(map__703000039__5, A_arbace_zip_A_const_38); _ = path__6; if





	jrt.A2g_Truth(pnodes__9) { var pnode__12 any = lang.IFn_Cast(A_arbace_zip_A_const_39.GetRawRoot__O()).Invoke_O__O(pnodes__9); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_zip_A_const_15.GetRawRoot__O()); var tmp2 lang.IPersistentVector

		if jrt.A2g_Truth(changed_QMARK___11) { var tmp3 any = lang.IFn_Cast(A_arbace_zip_A_const_40.GetRawRoot__O()).Invoke_O_O_O__O(loc__0, pnode__12, lang.IFn_Cast(A_arbace_zip_A_const_41.GetRawRoot__O()).Invoke_O_O__O(l__7, lang.IFn_Cast(A_arbace_zip_A_const_42.GetRawRoot__O()).Invoke_O_O__O(node__3, r__10))); var tmp4 any
			var and__1927000168__auto____13 any = ppath__8
			if jrt.A2g_Truth(and__1927000168__auto____13) { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_zip_A_const_21.GetRawRoot__O()); var tmp6 any = A_arbace_zip_A_const_38; var tmp7 *jrt.Boolean; jrt.Boolean_Init(); tmp7 = jrt.Boolean_TRUE; tmp4 = tmp5.Invoke_O_O_O__O(ppath__8, tmp6, tmp7.Ref()) } else { tmp4 = and__1927000168__auto____13 }
//line :130:1
			tmp2 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) } else { tmp2 = lang.Tuple_Create_O_O__IPersistentVector(pnode__12, ppath__8) }; return tmp1.Invoke_O_O__O(tmp2, lang.RT_Meta_O__IPersistentMap(loc__0)) } else {
//line :128:1
				return nil } }







func A_arbace_zip_root_A_New() *A_arbace_zip_root_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_root_A{}; t.Ctor(); return t }
//line :136:1
func (t *A_arbace_zip_root_A) Ctor() {}
//line :136:1
func (t *A_arbace_zip_root_A) Invoke_O_O__O(self, loc__0 any) any { { var loc__0_2 any = loc__0; L1: for {




	var tmp1 any = A_arbace_zip_A_const_43; if lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(loc__0_2).Invoke_O__O(A_arbace_zip_A_const_30)) {
		return lang.IFn_Cast(A_arbace_zip_A_const_27.GetRawRoot__O()).Invoke_O__O(loc__0_2) } else {
//line :141:1
			var p__2 any = lang.IFn_Cast(A_arbace_zip_A_const_44.GetRawRoot__O()).Invoke_O__O(loc__0_2)


			if jrt.A2g_Truth(p__2) {
				loc__0_2 = p__2; continue L1 } else {
					return lang.IFn_Cast(A_arbace_zip_A_const_27.GetRawRoot__O()).Invoke_O__O(loc__0_2) } } } }; /*line :136:1*/panic("a2g: unreachable") }











func A_arbace_zip_right_A_New() *A_arbace_zip_right_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_right_A{}; t.Ctor(); return t }
//line :148:1
func (t *A_arbace_zip_right_A) Ctor() {}
//line :148:1
func (t *A_arbace_zip_right_A) Invoke_O_O__O(self, loc__0 any) any { var vec__703000043__2 any = loc__0; var node__3 any = lang.RT_Nth_O_I_O__O(vec__703000043__2, lang.RT_IntCast_J__I(0), nil); var map__703000046__4 any = lang.RT_Nth_O_I_O__O(vec__703000043__2, lang.RT_IntCast_J__I(1), nil); var map__703000046__5 any; if



	lang.ISeq_InstanceOf(map__703000046__4) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_zip_A_const_35.GetRawRoot__O()).Invoke_O__O(map__703000046__4)) { map__703000046__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_zip_A_const_37.GetRawRoot__O()).Invoke_O__O(map__703000046__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_zip_A_const_17.GetRawRoot__O()).Invoke_O__O(map__703000046__4)) { map__703000046__5 = lang.IFn_Cast(A_arbace_zip_A_const_34.GetRawRoot__O()).Invoke_O__O(map__703000046__4) } else { lang.PersistentArrayMap_Init(); map__703000046__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__703000046__5 = map__703000046__4 }; var path__6 any = map__703000046__5; var l__7 any = /*line :148:1*/lang.RT_Get_O_O__O(map__703000046__5, A_arbace_zip_A_const_31); var vec__703000048__8 any = lang.RT_Get_O_O__O(map__703000046__5, A_arbace_zip_A_const_32); var seq__703000049__9 any = lang.IFn_Cast(A_arbace_zip_A_const_17.GetRawRoot__O()).Invoke_O__O(vec__703000048__8); var first__703000050__10 any = lang.IFn_Cast(A_arbace_zip_A_const_34.GetRawRoot__O()).Invoke_O__O(seq__703000049__9); var seq__703000049__11 any = lang.IFn_Cast(A_arbace_zip_A_const_35.GetRawRoot__O()).Invoke_O__O(seq__703000049__9); var r__12 any = first__703000050__10; var rnext__13 any = seq__703000049__11; var rs__14 any = vec__703000048__8; var tmp1 any; var and__1927000168__auto____15 any = path__6; if




	jrt.A2g_Truth(and__1927000168__auto____15) { tmp1 = rs__14 } else { tmp1 = and__1927000168__auto____15 }; if jrt.A2g_Truth(tmp1) {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_zip_A_const_21.GetRawRoot__O()); var tmp3 any = A_arbace_zip_A_const_31; return lang.IFn_Cast(A_arbace_zip_A_const_15.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(r__12, tmp2.Invoke_O_O_O_O_O__O(path__6, tmp3, lang.IFn_Cast(A_arbace_zip_A_const_6.GetRawRoot__O()).Invoke_O_O__O(l__7, node__3), A_arbace_zip_A_const_32, rnext__13)), lang.RT_Meta_O__IPersistentMap(loc__0)) } else {
//line :153:1
			return nil } }


func A_arbace_zip_rightmost_A_New() *A_arbace_zip_rightmost_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_rightmost_A{}; t.Ctor(); return t }
//line :156:1
func (t *A_arbace_zip_rightmost_A) Ctor() {}
//line :156:1
func (t *A_arbace_zip_rightmost_A) Invoke_O_O__O(self, loc__0 any) any { var vec__703000052__2 any = loc__0; var node__3 any = lang.RT_Nth_O_I_O__O(vec__703000052__2, lang.RT_IntCast_J__I(0), nil); var map__703000055__4 any = lang.RT_Nth_O_I_O__O(vec__703000052__2, lang.RT_IntCast_J__I(1), nil); var map__703000055__5 any; if



	lang.ISeq_InstanceOf(map__703000055__4) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_zip_A_const_35.GetRawRoot__O()).Invoke_O__O(map__703000055__4)) { map__703000055__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_zip_A_const_37.GetRawRoot__O()).Invoke_O__O(map__703000055__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_zip_A_const_17.GetRawRoot__O()).Invoke_O__O(map__703000055__4)) { map__703000055__5 = lang.IFn_Cast(A_arbace_zip_A_const_34.GetRawRoot__O()).Invoke_O__O(map__703000055__4) } else { lang.PersistentArrayMap_Init(); map__703000055__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__703000055__5 = map__703000055__4 }; var path__6 any = map__703000055__5; var l__7 any = /*line :156:1*/lang.RT_Get_O_O__O(map__703000055__5, A_arbace_zip_A_const_31); var r__8 any = lang.RT_Get_O_O__O(map__703000055__5, A_arbace_zip_A_const_32); var tmp1 any; var and__1927000168__auto____9 any = path__6; if




	jrt.A2g_Truth(and__1927000168__auto____9) { tmp1 = r__8 } else { tmp1 = and__1927000168__auto____9 }; if jrt.A2g_Truth(tmp1) {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_zip_A_const_21.GetRawRoot__O()); var tmp3 any = A_arbace_zip_A_const_31; return lang.IFn_Cast(A_arbace_zip_A_const_15.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_zip_A_const_45.GetRawRoot__O()).Invoke_O__O(r__8), tmp2.Invoke_O_O_O_O_O__O(path__6, tmp3, lang.IFn_Cast(A_arbace_zip_A_const_23.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_zip_A_const_6.GetRawRoot__O(), l__7, node__3, lang.IFn_Cast(A_arbace_zip_A_const_46.GetRawRoot__O()).Invoke_O__O(r__8)), A_arbace_zip_A_const_32, nil)), lang.RT_Meta_O__IPersistentMap(loc__0)) } else {
//line :161:1
			return loc__0 } }



func A_arbace_zip_left_A_New() *A_arbace_zip_left_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_left_A{}; t.Ctor(); return t }
//line :165:1
func (t *A_arbace_zip_left_A) Ctor() {}
//line :165:1
func (t *A_arbace_zip_left_A) Invoke_O_O__O(self, loc__0 any) any { var vec__703000058__2 any = loc__0; var node__3 any = lang.RT_Nth_O_I_O__O(vec__703000058__2, lang.RT_IntCast_J__I(0), nil); var map__703000061__4 any = lang.RT_Nth_O_I_O__O(vec__703000058__2, lang.RT_IntCast_J__I(1), nil); var map__703000061__5 any; if



	lang.ISeq_InstanceOf(map__703000061__4) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_zip_A_const_35.GetRawRoot__O()).Invoke_O__O(map__703000061__4)) { map__703000061__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_zip_A_const_37.GetRawRoot__O()).Invoke_O__O(map__703000061__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_zip_A_const_17.GetRawRoot__O()).Invoke_O__O(map__703000061__4)) { map__703000061__5 = lang.IFn_Cast(A_arbace_zip_A_const_34.GetRawRoot__O()).Invoke_O__O(map__703000061__4) } else { lang.PersistentArrayMap_Init(); map__703000061__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__703000061__5 = map__703000061__4 }; var path__6 any = map__703000061__5; var l__7 any = /*line :165:1*/lang.RT_Get_O_O__O(map__703000061__5, A_arbace_zip_A_const_31); var r__8 any = lang.RT_Get_O_O__O(map__703000061__5, A_arbace_zip_A_const_32); var tmp1 any; var and__1927000168__auto____9 any = path__6; if




	jrt.A2g_Truth(and__1927000168__auto____9) { tmp1 = lang.IFn_Cast(A_arbace_zip_A_const_17.GetRawRoot__O()).Invoke_O__O(l__7) } else { tmp1 = and__1927000168__auto____9 }; if jrt.A2g_Truth(tmp1) {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_zip_A_const_21.GetRawRoot__O()); var tmp3 any = A_arbace_zip_A_const_31; var tmp4 any = lang.IFn_Cast(A_arbace_zip_A_const_47.GetRawRoot__O()).Invoke_O__O(l__7); var tmp5 any = A_arbace_zip_A_const_32; return lang.IFn_Cast(A_arbace_zip_A_const_15.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_zip_A_const_39.GetRawRoot__O()).Invoke_O__O(l__7), tmp2.Invoke_O_O_O_O_O__O(path__6, tmp3, tmp4, tmp5, lang.IFn_Cast(A_arbace_zip_A_const_42.GetRawRoot__O()).Invoke_O_O__O(node__3, r__8))), lang.RT_Meta_O__IPersistentMap(loc__0)) } else {
//line :170:1
			return nil } }


func A_arbace_zip_leftmost_A_New() *A_arbace_zip_leftmost_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_leftmost_A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_zip_leftmost_A) Ctor() {}
//line :173:1
func (t *A_arbace_zip_leftmost_A) Invoke_O_O__O(self, loc__0 any) any { var vec__703000064__2 any = loc__0; var node__3 any = lang.RT_Nth_O_I_O__O(vec__703000064__2, lang.RT_IntCast_J__I(0), nil); var map__703000067__4 any = lang.RT_Nth_O_I_O__O(vec__703000064__2, lang.RT_IntCast_J__I(1), nil); var map__703000067__5 any; if



	lang.ISeq_InstanceOf(map__703000067__4) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_zip_A_const_35.GetRawRoot__O()).Invoke_O__O(map__703000067__4)) { map__703000067__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_zip_A_const_37.GetRawRoot__O()).Invoke_O__O(map__703000067__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_zip_A_const_17.GetRawRoot__O()).Invoke_O__O(map__703000067__4)) { map__703000067__5 = lang.IFn_Cast(A_arbace_zip_A_const_34.GetRawRoot__O()).Invoke_O__O(map__703000067__4) } else { lang.PersistentArrayMap_Init(); map__703000067__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__703000067__5 = map__703000067__4 }; var path__6 any = map__703000067__5; var l__7 any = /*line :173:1*/lang.RT_Get_O_O__O(map__703000067__5, A_arbace_zip_A_const_31); var r__8 any = lang.RT_Get_O_O__O(map__703000067__5, A_arbace_zip_A_const_32); var tmp1 any; var and__1927000168__auto____9 any = path__6; if




	jrt.A2g_Truth(and__1927000168__auto____9) { tmp1 = lang.IFn_Cast(A_arbace_zip_A_const_17.GetRawRoot__O()).Invoke_O__O(l__7) } else { tmp1 = and__1927000168__auto____9 }; if jrt.A2g_Truth(tmp1) {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_zip_A_const_15.GetRawRoot__O()); var tmp3 any = lang.IFn_Cast(A_arbace_zip_A_const_34.GetRawRoot__O()).Invoke_O__O(l__7); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_zip_A_const_21.GetRawRoot__O()); var tmp5 any = A_arbace_zip_A_const_31; var tmp6 *lang.PersistentVector; lang.PersistentVector_Init(); tmp6 = lang.PersistentVector_EMPTY; var tmp7 any = tmp6.Ref(); var tmp8 any = A_arbace_zip_A_const_32; return tmp2.Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4.Invoke_O_O_O_O_O__O(path__6, tmp5, tmp7, tmp8, lang.IFn_Cast(A_arbace_zip_A_const_41.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_zip_A_const_48.GetRawRoot__O()).Invoke_O__O(l__7), lang.Tuple_Create_O__IPersistentVector(node__3), r__8))), lang.RT_Meta_O__IPersistentMap(loc__0)) } else {
//line :178:1
			return loc__0 } }



func A_arbace_zip_insert_left_A_New() *A_arbace_zip_insert_left_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_insert_left_A{}; t.Ctor(); return t }
//line :182:1
func (t *A_arbace_zip_insert_left_A) Ctor() {}
//line :182:1
func (t *A_arbace_zip_insert_left_A) Invoke_O_O_O__O(self, loc__0, item__1 any) any { var vec__703000070__3 any = loc__0; var node__4 any = lang.RT_Nth_O_I_O__O(vec__703000070__3, lang.RT_IntCast_J__I(0), nil); var map__703000073__5 any = lang.RT_Nth_O_I_O__O(vec__703000070__3, lang.RT_IntCast_J__I(1), nil); var map__703000073__6 any; if




	lang.ISeq_InstanceOf(map__703000073__5) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_zip_A_const_35.GetRawRoot__O()).Invoke_O__O(map__703000073__5)) { map__703000073__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_zip_A_const_37.GetRawRoot__O()).Invoke_O__O(map__703000073__5), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_zip_A_const_17.GetRawRoot__O()).Invoke_O__O(map__703000073__5)) { map__703000073__6 = lang.IFn_Cast(A_arbace_zip_A_const_34.GetRawRoot__O()).Invoke_O__O(map__703000073__5) } else { lang.PersistentArrayMap_Init(); map__703000073__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__703000073__6 = map__703000073__5 }; var path__7 any = map__703000073__6; var l__8 any = /*line :182:1*/lang.RT_Get_O_O__O(map__703000073__6, A_arbace_zip_A_const_31); if





	lang.Util_Identical_O_O__Z(path__7, nil) { panic(jrt.Thrown(jrt.Exception_New_String(Lit_2))) } else {

		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_zip_A_const_15.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_zip_A_const_21.GetRawRoot__O()); var tmp3 any = A_arbace_zip_A_const_31; var tmp4 any = lang.IFn_Cast(A_arbace_zip_A_const_6.GetRawRoot__O()).Invoke_O_O__O(l__8, item__1); var tmp5 any = A_arbace_zip_A_const_38; var tmp6 *jrt.Boolean; jrt.Boolean_Init(); tmp6 = jrt.Boolean_TRUE; return tmp1.Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(node__4, tmp2.Invoke_O_O_O_O_O__O(path__7, tmp3, tmp4, tmp5, tmp6.Ref())), lang.RT_Meta_O__IPersistentMap(loc__0)) } }

func A_arbace_zip_insert_right_A_New() *A_arbace_zip_insert_right_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_insert_right_A{}; t.Ctor(); return t }
//line :192:1
func (t *A_arbace_zip_insert_right_A) Ctor() {}
//line :192:1
func (t *A_arbace_zip_insert_right_A) Invoke_O_O_O__O(self, loc__0, item__1 any) any { var vec__703000076__3 any = loc__0; var node__4 any = lang.RT_Nth_O_I_O__O(vec__703000076__3, lang.RT_IntCast_J__I(0), nil); var map__703000079__5 any = lang.RT_Nth_O_I_O__O(vec__703000076__3, lang.RT_IntCast_J__I(1), nil); var map__703000079__6 any; if




	lang.ISeq_InstanceOf(map__703000079__5) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_zip_A_const_35.GetRawRoot__O()).Invoke_O__O(map__703000079__5)) { map__703000079__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_zip_A_const_37.GetRawRoot__O()).Invoke_O__O(map__703000079__5), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_zip_A_const_17.GetRawRoot__O()).Invoke_O__O(map__703000079__5)) { map__703000079__6 = lang.IFn_Cast(A_arbace_zip_A_const_34.GetRawRoot__O()).Invoke_O__O(map__703000079__5) } else { lang.PersistentArrayMap_Init(); map__703000079__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__703000079__6 = map__703000079__5 }; var path__7 any = map__703000079__6; var r__8 any = /*line :192:1*/lang.RT_Get_O_O__O(map__703000079__6, A_arbace_zip_A_const_32); if





	lang.Util_Identical_O_O__Z(path__7, nil) { panic(jrt.Thrown(jrt.Exception_New_String(Lit_2))) } else {

		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_zip_A_const_15.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_zip_A_const_21.GetRawRoot__O()); var tmp3 any = A_arbace_zip_A_const_32; var tmp4 any = lang.IFn_Cast(A_arbace_zip_A_const_42.GetRawRoot__O()).Invoke_O_O__O(item__1, r__8); var tmp5 any = A_arbace_zip_A_const_38; var tmp6 *jrt.Boolean; jrt.Boolean_Init(); tmp6 = jrt.Boolean_TRUE; return tmp1.Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(node__4, tmp2.Invoke_O_O_O_O_O__O(path__7, tmp3, tmp4, tmp5, tmp6.Ref())), lang.RT_Meta_O__IPersistentMap(loc__0)) } }

func A_arbace_zip_replace_A_New() *A_arbace_zip_replace_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_replace_A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_zip_replace_A) Ctor() {}
//line :202:1
func (t *A_arbace_zip_replace_A) Invoke_O_O_O__O(self, loc__0, node__1 any) any { var vec__703000082__3 any = loc__0; var ___4 any = lang.RT_Nth_O_I_O__O(vec__703000082__3, lang.RT_IntCast_J__I(0), nil); var path__5 any = lang.RT_Nth_O_I_O__O(vec__703000082__3, lang.RT_IntCast_J__I(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_zip_A_const_15.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_zip_A_const_21.GetRawRoot__O()); var tmp3 any = A_arbace_zip_A_const_38; var tmp4 *jrt.Boolean; _ = ___4;




	jrt.Boolean_Init(); tmp4 = jrt.Boolean_TRUE; return tmp1.Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(node__1, tmp2.Invoke_O_O_O__O(path__5, tmp3, tmp4.Ref())), lang.RT_Meta_O__IPersistentMap(loc__0)) }

func A_arbace_zip_edit_A_New() *A_arbace_zip_edit_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_edit_A{}; t.Ctor(); return t }
//line :209:1
func (t *A_arbace_zip_edit_A) Ctor() {}
//line :209:1
func (t *A_arbace_zip_edit_A) DoInvoke_O_O_O_O__O(self, loc__0, f__1, args__2 any) any {



	return lang.IFn_Cast(A_arbace_zip_A_const_49.GetRawRoot__O()).Invoke_O_O__O(loc__0, lang.IFn_Cast(A_arbace_zip_A_const_23.GetRawRoot__O()).Invoke_O_O_O__O(f__1, lang.IFn_Cast(A_arbace_zip_A_const_27.GetRawRoot__O()).Invoke_O__O(loc__0), args__2))
}
func A_arbace_zip_insert_child_A_New() *A_arbace_zip_insert_child_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_insert_child_A{}; t.Ctor(); return t }
//line :215:1
func (t *A_arbace_zip_insert_child_A) Ctor() {}
//line :215:1
func (t *A_arbace_zip_insert_child_A) Invoke_O_O_O__O(self, loc__0, item__1 any) any {




	return lang.IFn_Cast(A_arbace_zip_A_const_49.GetRawRoot__O()).Invoke_O_O__O(loc__0, lang.IFn_Cast(A_arbace_zip_A_const_40.GetRawRoot__O()).Invoke_O_O_O__O(loc__0, lang.IFn_Cast(A_arbace_zip_A_const_27.GetRawRoot__O()).Invoke_O__O(loc__0), lang.IFn_Cast(A_arbace_zip_A_const_42.GetRawRoot__O()).Invoke_O_O__O(item__1, lang.IFn_Cast(A_arbace_zip_A_const_33.GetRawRoot__O()).Invoke_O__O(loc__0))))
}
func A_arbace_zip_append_child_A_New() *A_arbace_zip_append_child_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_append_child_A{}; t.Ctor(); return t }
//line :222:1
func (t *A_arbace_zip_append_child_A) Ctor() {}
//line :222:1
func (t *A_arbace_zip_append_child_A) Invoke_O_O_O__O(self, loc__0, item__1 any) any {




	return lang.IFn_Cast(A_arbace_zip_A_const_49.GetRawRoot__O()).Invoke_O_O__O(loc__0, lang.IFn_Cast(A_arbace_zip_A_const_40.GetRawRoot__O()).Invoke_O_O_O__O(loc__0, lang.IFn_Cast(A_arbace_zip_A_const_27.GetRawRoot__O()).Invoke_O__O(loc__0), lang.IFn_Cast(A_arbace_zip_A_const_41.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_zip_A_const_33.GetRawRoot__O()).Invoke_O__O(loc__0), lang.Tuple_Create_O__IPersistentVector(item__1))))
}
func A_arbace_zip_next_A_New() *A_arbace_zip_next_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_next_A{}; t.Ctor(); return t }
//line :229:1
func (t *A_arbace_zip_next_A) Ctor() {}
//line :229:1
func (t *A_arbace_zip_next_A) Invoke_O_O__O(self, loc__0 any) any {





	{ var tmp1 any = A_arbace_zip_A_const_43; if lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(loc__0).Invoke_O__O(A_arbace_zip_A_const_30)) { return loc__0 } else { var or__1927000174__auto____2 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_zip_A_const_28.GetRawRoot__O()).Invoke_O__O(loc__0)


		if jrt.A2g_Truth(and__1927000168__auto____2) { or__1927000174__auto____2 = lang.IFn_Cast(A_arbace_zip_A_const_50.GetRawRoot__O()).Invoke_O__O(loc__0) } else { or__1927000174__auto____2 = and__1927000168__auto____2 }
//line :237:1
		if jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_zip_A_const_51.GetRawRoot__O()).Invoke_O__O(loc__0); if jrt.A2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var p__4 any = loc__0; L1: for { var temp__1927000408__auto____5 any = lang.IFn_Cast(A_arbace_zip_A_const_44.GetRawRoot__O()).Invoke_O__O(p__4)



			if jrt.A2g_Truth(temp__1927000408__auto____5) { var uloc__6 any = temp__1927000408__auto____5; var or__1927000174__auto____7 any = lang.IFn_Cast(A_arbace_zip_A_const_51.GetRawRoot__O()).Invoke_O__O(uloc__6)
				if jrt.A2g_Truth(or__1927000174__auto____7) { return or__1927000174__auto____7 } else { p__4 = uloc__6; continue L1 } } else {
//line :241:1
					return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_zip_A_const_27.GetRawRoot__O()).Invoke_O__O(p__4), A_arbace_zip_A_const_43) } } } } } }
//line :229:1
	panic("a2g: unreachable")
}














func A_arbace_zip_prev_A_New() *A_arbace_zip_prev_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_prev_A{}; t.Ctor(); return t }
//line :245:1
func (t *A_arbace_zip_prev_A) Ctor() {}
//line :245:1
func (t *A_arbace_zip_prev_A) Invoke_O_O__O(self, loc__0 any) any { { var temp__1927000408__auto____2 any = lang.IFn_Cast(A_arbace_zip_A_const_52.GetRawRoot__O()).Invoke_O__O(loc__0)




	if jrt.A2g_Truth(temp__1927000408__auto____2) { var lloc__3 any = temp__1927000408__auto____2; var loc__4 any = lloc__3; L1: for { var temp__1927000408__auto____5 any; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_zip_A_const_28.GetRawRoot__O()).Invoke_O__O(loc__4)

		if jrt.A2g_Truth(and__1927000168__auto____5) { temp__1927000408__auto____5 = lang.IFn_Cast(A_arbace_zip_A_const_50.GetRawRoot__O()).Invoke_O__O(loc__4) } else { temp__1927000408__auto____5 = and__1927000168__auto____5 }; if jrt.A2g_Truth(temp__1927000408__auto____5) { var child__6 any = temp__1927000408__auto____5
			loc__4 = lang.IFn_Cast(A_arbace_zip_A_const_53.GetRawRoot__O()).Invoke_O__O(child__6); continue L1 } else {
//line :252:1
				return loc__4 } } } else {


					return lang.IFn_Cast(A_arbace_zip_A_const_44.GetRawRoot__O()).Invoke_O__O(loc__0) } }; /*line :245:1*/panic("a2g: unreachable") }











func A_arbace_zip_end_QMARK__A_New() *A_arbace_zip_end_QMARK__A { A_arbace_zip_A_Init(); t := &A_arbace_zip_end_QMARK__A{}; t.Ctor(); return t }
//line :257:1
func (t *A_arbace_zip_end_QMARK__A) Ctor() {}
//line :257:1
func (t *A_arbace_zip_end_QMARK__A) Invoke_O_O__O(self, loc__0 any) any {



	var tmp1 any = A_arbace_zip_A_const_43; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(loc__0).Invoke_O__O(A_arbace_zip_A_const_30))).Ref()
}
func A_arbace_zip_remove_A_New() *A_arbace_zip_remove_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_remove_A{}; t.Ctor(); return t }
//line :263:1
func (t *A_arbace_zip_remove_A) Ctor() {}
//line :263:1
func (t *A_arbace_zip_remove_A) Invoke_O_O__O(self, loc__0 any) any { { var vec__703000092__2 any = loc__0; var node__3 any = lang.RT_Nth_O_I_O__O(vec__703000092__2, lang.RT_IntCast_J__I(0), nil); var map__703000095__4 any = lang.RT_Nth_O_I_O__O(vec__703000092__2, lang.RT_IntCast_J__I(1), nil); var map__703000095__5 any; _ = node__3




	if lang.ISeq_InstanceOf(map__703000095__4) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_zip_A_const_35.GetRawRoot__O()).Invoke_O__O(map__703000095__4)) { map__703000095__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_zip_A_const_37.GetRawRoot__O()).Invoke_O__O(map__703000095__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_zip_A_const_17.GetRawRoot__O()).Invoke_O__O(map__703000095__4)) { map__703000095__5 = lang.IFn_Cast(A_arbace_zip_A_const_34.GetRawRoot__O()).Invoke_O__O(map__703000095__4) } else { lang.PersistentArrayMap_Init(); map__703000095__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__703000095__5 = map__703000095__4 }
//line :263:1
	var path__6 any = map__703000095__5; var l__7 any = lang.RT_Get_O_O__O(map__703000095__5, A_arbace_zip_A_const_31); var ppath__8 any = lang.RT_Get_O_O__O(map__703000095__5, A_arbace_zip_A_const_36); var pnodes__9 any = lang.RT_Get_O_O__O(map__703000095__5, A_arbace_zip_A_const_29); var rs__10 any = lang.RT_Get_O_O__O(map__703000095__5, A_arbace_zip_A_const_32)





	if lang.Util_Identical_O_O__Z(path__6, nil) { panic(jrt.Thrown(jrt.Exception_New_String(Lit_3))) } else {

		if lang.Numbers_IsPos_J__Z(int64(lang.RT_Count_O__I(l__7))) { var loc__11 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_zip_A_const_15.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_zip_A_const_39.GetRawRoot__O()).Invoke_O__O(l__7); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_zip_A_const_21.GetRawRoot__O()); var tmp4 any = A_arbace_zip_A_const_31; var tmp5 any = lang.IFn_Cast(A_arbace_zip_A_const_47.GetRawRoot__O()).Invoke_O__O(l__7); var tmp6 any = A_arbace_zip_A_const_38; var tmp7 *jrt.Boolean
			jrt.Boolean_Init(); tmp7 = jrt.Boolean_TRUE; loc__11 = tmp1.Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3.Invoke_O_O_O_O_O__O(path__6, tmp4, tmp5, tmp6, tmp7.Ref())), lang.RT_Meta_O__IPersistentMap(loc__0))
//line :271:1
		L1: for { var temp__1927000408__auto____12 any; var and__1927000168__auto____12 any = lang.IFn_Cast(A_arbace_zip_A_const_28.GetRawRoot__O()).Invoke_O__O(loc__11)

			if jrt.A2g_Truth(and__1927000168__auto____12) { temp__1927000408__auto____12 = lang.IFn_Cast(A_arbace_zip_A_const_50.GetRawRoot__O()).Invoke_O__O(loc__11) } else { temp__1927000408__auto____12 = and__1927000168__auto____12 }; if jrt.A2g_Truth(temp__1927000408__auto____12) { var child__13 any = temp__1927000408__auto____12
				loc__11 = lang.IFn_Cast(A_arbace_zip_A_const_53.GetRawRoot__O()).Invoke_O__O(child__13); continue L1 } else {
//line :273:1
					return loc__11 } } } else {


						var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_zip_A_const_15.GetRawRoot__O()); var tmp9 any = lang.IFn_Cast(A_arbace_zip_A_const_40.GetRawRoot__O()).Invoke_O_O_O__O(loc__0, lang.IFn_Cast(A_arbace_zip_A_const_39.GetRawRoot__O()).Invoke_O__O(pnodes__9), rs__10); var tmp10 any; var and__1927000168__auto____11 any = ppath__8
						if jrt.A2g_Truth(and__1927000168__auto____11) { var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_zip_A_const_21.GetRawRoot__O()); var tmp12 any = A_arbace_zip_A_const_38; var tmp13 *jrt.Boolean; jrt.Boolean_Init(); tmp13 = jrt.Boolean_TRUE; tmp10 = tmp11.Invoke_O_O_O__O(ppath__8, tmp12, tmp13.Ref()) } else { tmp10 = and__1927000168__auto____11 }
//line :276:1
						return tmp8.Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(tmp9, tmp10), lang.RT_Meta_O__IPersistentMap(loc__0)) } } }; /*line :263:1*/panic("a2g: unreachable") }







type A_arbace_zip_A struct{ jrt.Object }

var A_arbace_zip_A_const_pool *jrt.RefArray

var A_arbace_zip_A_const_0 *lang.Var

var A_arbace_zip_A_const_1 any

var A_arbace_zip_A_const_2 *lang.Keyword

var A_arbace_zip_A_const_3 any

var A_arbace_zip_A_const_4 *lang.Var

var A_arbace_zip_A_const_5 *lang.Var

var A_arbace_zip_A_const_6 *lang.Var

var A_arbace_zip_A_const_7 any

var A_arbace_zip_A_const_8 *lang.Var

var A_arbace_zip_A_const_9 *lang.Keyword

var A_arbace_zip_A_const_10 *lang.Keyword

var A_arbace_zip_A_const_11 *lang.Keyword

var A_arbace_zip_A_const_12 *lang.Var

var A_arbace_zip_A_const_13 *lang.Var

var A_arbace_zip_A_const_14 *lang.Var

var A_arbace_zip_A_const_15 *lang.Var

var A_arbace_zip_A_const_16 *lang.Var

var A_arbace_zip_A_const_17 *lang.Var

var A_arbace_zip_A_const_18 *lang.Var

var A_arbace_zip_A_const_19 *lang.Var

var A_arbace_zip_A_const_20 *lang.Var

var A_arbace_zip_A_const_21 *lang.Var

var A_arbace_zip_A_const_22 *lang.Keyword

var A_arbace_zip_A_const_23 *lang.Var

var A_arbace_zip_A_const_24 *lang.Var

var A_arbace_zip_A_const_25 *lang.Var

var A_arbace_zip_A_const_26 any

var A_arbace_zip_A_const_27 *lang.Var

var A_arbace_zip_A_const_28 *lang.Var

var A_arbace_zip_A_const_29 *lang.Keyword

var A_arbace_zip_A_const_30 any

var A_arbace_zip_A_const_31 *lang.Keyword

var A_arbace_zip_A_const_32 *lang.Keyword

var A_arbace_zip_A_const_33 *lang.Var

var A_arbace_zip_A_const_34 *lang.Var

var A_arbace_zip_A_const_35 *lang.Var

var A_arbace_zip_A_const_36 *lang.Keyword

var A_arbace_zip_A_const_37 *lang.Var

var A_arbace_zip_A_const_38 *lang.Keyword

var A_arbace_zip_A_const_39 *lang.Var

var A_arbace_zip_A_const_40 *lang.Var

var A_arbace_zip_A_const_41 *lang.Var

var A_arbace_zip_A_const_42 *lang.Var

var A_arbace_zip_A_const_43 *lang.Keyword

var A_arbace_zip_A_const_44 *lang.Var

var A_arbace_zip_A_const_45 *lang.Var

var A_arbace_zip_A_const_46 *lang.Var

var A_arbace_zip_A_const_47 *lang.Var

var A_arbace_zip_A_const_48 *lang.Var

var A_arbace_zip_A_const_49 *lang.Var

var A_arbace_zip_A_const_50 *lang.Var

var A_arbace_zip_A_const_51 *lang.Var

var A_arbace_zip_A_const_52 *lang.Var

var A_arbace_zip_A_const_53 *lang.Var

var A_arbace_zip_A_init jrt.ClassInit

func A_arbace_zip_A_Init() { if !A_arbace_zip_A_init.Done() { A_arbace_zip_A_init.Run(A_arbace_zip_A_clinit) } }

func A_arbace_zip_A_clinit() { A_arbace_zip_A_clinit_p0(); A_arbace_zip_A_clinit_p1(); A_arbace_zip_A_clinit_p2(); A_arbace_zip_A_clinit_p3(); A_arbace_zip_A_clinit_p4() }

func A_arbace_zip_A_clinit_p0() { A_arbace_zip_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 73); A_arbace_zip_A_const_0 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[19]); A_arbace_zip_A_const_1 = A_arbace_zip_A_const_pool.A[20]; A_arbace_zip_A_const_2 = lang.Keyword_Cast(A_arbace_zip_A_const_pool.A[21]); A_arbace_zip_A_const_3 = A_arbace_zip_A_const_pool.A[22]; A_arbace_zip_A_const_4 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[23]); A_arbace_zip_A_const_5 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[24]); A_arbace_zip_A_const_6 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[25]); A_arbace_zip_A_const_7 = A_arbace_zip_A_const_pool.A[26]; A_arbace_zip_A_const_8 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[27]); A_arbace_zip_A_const_9 = lang.Keyword_Cast(A_arbace_zip_A_const_pool.A[28]); A_arbace_zip_A_const_10 = lang.Keyword_Cast(A_arbace_zip_A_const_pool.A[29]); A_arbace_zip_A_const_11 = lang.Keyword_Cast(A_arbace_zip_A_const_pool.A[30]) }

func A_arbace_zip_A_clinit_p1() { A_arbace_zip_A_const_12 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[31]); A_arbace_zip_A_const_13 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[32]); A_arbace_zip_A_const_14 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[33]); A_arbace_zip_A_const_15 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[34]); A_arbace_zip_A_const_16 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[35]); A_arbace_zip_A_const_17 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[36]); A_arbace_zip_A_const_18 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[37]); A_arbace_zip_A_const_19 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[38]); A_arbace_zip_A_const_20 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[39]); A_arbace_zip_A_const_21 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[40]); A_arbace_zip_A_const_22 = lang.Keyword_Cast(A_arbace_zip_A_const_pool.A[41]); A_arbace_zip_A_const_23 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[42]) }

func A_arbace_zip_A_clinit_p2() { A_arbace_zip_A_const_24 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[43]); A_arbace_zip_A_const_25 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[44]); A_arbace_zip_A_const_26 = A_arbace_zip_A_const_pool.A[45]; A_arbace_zip_A_const_27 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[46]); A_arbace_zip_A_const_28 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[47]); A_arbace_zip_A_const_29 = lang.Keyword_Cast(A_arbace_zip_A_const_pool.A[48]); A_arbace_zip_A_const_30 = A_arbace_zip_A_const_pool.A[49]; A_arbace_zip_A_const_31 = lang.Keyword_Cast(A_arbace_zip_A_const_pool.A[50]); A_arbace_zip_A_const_32 = lang.Keyword_Cast(A_arbace_zip_A_const_pool.A[51]); A_arbace_zip_A_const_33 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[52]); A_arbace_zip_A_const_34 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[53]); A_arbace_zip_A_const_35 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[54]) }

func A_arbace_zip_A_clinit_p3() { A_arbace_zip_A_const_36 = lang.Keyword_Cast(A_arbace_zip_A_const_pool.A[55]); A_arbace_zip_A_const_37 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[56]); A_arbace_zip_A_const_38 = lang.Keyword_Cast(A_arbace_zip_A_const_pool.A[57]); A_arbace_zip_A_const_39 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[58]); A_arbace_zip_A_const_40 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[59]); A_arbace_zip_A_const_41 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[60]); A_arbace_zip_A_const_42 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[61]); A_arbace_zip_A_const_43 = lang.Keyword_Cast(A_arbace_zip_A_const_pool.A[62]); A_arbace_zip_A_const_44 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[63]); A_arbace_zip_A_const_45 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[64]); A_arbace_zip_A_const_46 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[65]); A_arbace_zip_A_const_47 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[66]) }

func A_arbace_zip_A_clinit_p4() { A_arbace_zip_A_const_48 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[67]); A_arbace_zip_A_const_49 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[68]); A_arbace_zip_A_const_50 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[69]); A_arbace_zip_A_const_51 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[70]); A_arbace_zip_A_const_52 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[71]); A_arbace_zip_A_const_53 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[72]) }

func A_arbace_zip_A_New() *A_arbace_zip_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_A{}; t.Ctor(); return t }

func (t *A_arbace_zip_A) Ctor() {}

func (t *A_arbace_zip_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_A) GetClass__Class() *jrt.Class { return A_arbace_zip_A_class }

func (t *A_arbace_zip_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_A); return ok }

func A_arbace_zip_A_Cast(x any) *A_arbace_zip_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_A_class)) }; return v }



type A_arbace_zip_append_child_A struct{ a2g_header uint64 }

var A_arbace_zip_append_child_A_fn_class *jrt.Class



type A_arbace_zip_branch_QMARK__A struct{ a2g_header uint64 }

var A_arbace_zip_branch_QMARK__A_fn_class *jrt.Class



type A_arbace_zip_children_A struct{ a2g_header uint64 }

var A_arbace_zip_children_A_fn_class *jrt.Class



type A_arbace_zip_down_A struct{ a2g_header uint64 }

var A_arbace_zip_down_A_fn_class *jrt.Class



type A_arbace_zip_edit_A struct{ a2g_header uint64 }

var A_arbace_zip_edit_A_fn_class *jrt.Class



type A_arbace_zip_end_QMARK__A struct{ a2g_header uint64 }

var A_arbace_zip_end_QMARK__A_fn_class *jrt.Class



type A_arbace_zip_eval703000004_A struct{ jrt.Object }

func A_arbace_zip_eval703000004_A_New() *A_arbace_zip_eval703000004_A { t := &A_arbace_zip_eval703000004_A{}; t.Ctor(); return t }

func (t *A_arbace_zip_eval703000004_A) Ctor() {}

func (t *A_arbace_zip_eval703000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_eval703000004_A) GetClass__Class() *jrt.Class { return A_arbace_zip_eval703000004_A_class }

func (t *A_arbace_zip_eval703000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_eval703000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_eval703000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_eval703000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_eval703000004_A); return ok }

func A_arbace_zip_eval703000004_A_Cast(x any) *A_arbace_zip_eval703000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_eval703000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_eval703000004_A_class)) }; return v }



type A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A struct{ a2g_header uint64 }

var A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_fn_class *jrt.Class



type A_arbace_zip_eval703000008_A struct{ jrt.Object }

func A_arbace_zip_eval703000008_A_New() *A_arbace_zip_eval703000008_A { t := &A_arbace_zip_eval703000008_A{}; t.Ctor(); return t }

func (t *A_arbace_zip_eval703000008_A) Ctor() {}

func (t *A_arbace_zip_eval703000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_eval703000008_A) GetClass__Class() *jrt.Class { return A_arbace_zip_eval703000008_A_class }

func (t *A_arbace_zip_eval703000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_eval703000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_zip_eval703000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_eval703000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_eval703000008_A); return ok }

func A_arbace_zip_eval703000008_A_Cast(x any) *A_arbace_zip_eval703000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_eval703000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_eval703000008_A_class)) }; return v }



type A_arbace_zip_eval703000008_fn__703000009_A struct{ a2g_header uint64 }

var A_arbace_zip_eval703000008_fn__703000009_A_fn_class *jrt.Class



type A_arbace_zip_insert_child_A struct{ a2g_header uint64 }

var A_arbace_zip_insert_child_A_fn_class *jrt.Class



type A_arbace_zip_insert_left_A struct{ a2g_header uint64 }

var A_arbace_zip_insert_left_A_fn_class *jrt.Class



type A_arbace_zip_insert_right_A struct{ a2g_header uint64 }

var A_arbace_zip_insert_right_A_fn_class *jrt.Class



type A_arbace_zip_left_A struct{ a2g_header uint64 }

var A_arbace_zip_left_A_fn_class *jrt.Class



type A_arbace_zip_leftmost_A struct{ a2g_header uint64 }

var A_arbace_zip_leftmost_A_fn_class *jrt.Class



type A_arbace_zip_lefts_A struct{ a2g_header uint64 }

var A_arbace_zip_lefts_A_fn_class *jrt.Class



type A_arbace_zip_make_node_A struct{ a2g_header uint64 }

var A_arbace_zip_make_node_A_fn_class *jrt.Class



type A_arbace_zip_next_A struct{ a2g_header uint64 }

var A_arbace_zip_next_A_fn_class *jrt.Class



type A_arbace_zip_node_A struct{ a2g_header uint64 }

var A_arbace_zip_node_A_fn_class *jrt.Class



type A_arbace_zip_path_A struct{ a2g_header uint64 }

var A_arbace_zip_path_A_fn_class *jrt.Class



type A_arbace_zip_prev_A struct{ a2g_header uint64 }

var A_arbace_zip_prev_A_fn_class *jrt.Class



type A_arbace_zip_remove_A struct{ a2g_header uint64 }

var A_arbace_zip_remove_A_fn_class *jrt.Class



type A_arbace_zip_replace_A struct{ a2g_header uint64 }

var A_arbace_zip_replace_A_fn_class *jrt.Class



type A_arbace_zip_right_A struct{ a2g_header uint64 }

var A_arbace_zip_right_A_fn_class *jrt.Class



type A_arbace_zip_rightmost_A struct{ a2g_header uint64 }

var A_arbace_zip_rightmost_A_fn_class *jrt.Class



type A_arbace_zip_rights_A struct{ a2g_header uint64 }

var A_arbace_zip_rights_A_fn_class *jrt.Class



type A_arbace_zip_root_A struct{ a2g_header uint64 }

var A_arbace_zip_root_A_fn_class *jrt.Class



type A_arbace_zip_seq_zip_A struct{ a2g_header uint64 }

var A_arbace_zip_seq_zip_A_fn_class *jrt.Class



type A_arbace_zip_seq_zip_fn__703000013_A struct{ a2g_header uint64 }

var A_arbace_zip_seq_zip_fn__703000013_A_fn_class *jrt.Class



type A_arbace_zip_up_A struct{ a2g_header uint64 }

var A_arbace_zip_up_A_fn_class *jrt.Class



type A_arbace_zip_vector_zip_A struct{ a2g_header uint64 }

var A_arbace_zip_vector_zip_A_fn_class *jrt.Class



type A_arbace_zip_vector_zip_fn__703000016_A struct{ a2g_header uint64 }

var A_arbace_zip_vector_zip_fn__703000016_A_fn_class *jrt.Class



type A_arbace_zip_xml_zip_A struct{ a2g_header uint64 }

var A_arbace_zip_xml_zip_A_fn_class *jrt.Class



type A_arbace_zip_xml_zip_fn__703000019_A struct{ a2g_header uint64 }

var A_arbace_zip_xml_zip_fn__703000019_A_fn_class *jrt.Class



type A_arbace_zip_zipper_A struct{ a2g_header uint64 }

var A_arbace_zip_zipper_A_fn_class *jrt.Class
