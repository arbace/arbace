//line aot_arbace_zip.ae:1
package aot_arbace_zip

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)




func A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_New() *A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A{}; t.Ctor(); return t }
//line :12:1
func (t *A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A) Ctor() {}
//line :12:1
func (t *A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp2 = lang.IFn_Cast(A_arbace_zip_A_const_0.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_zip_A_const_1, A_arbace_zip_A_const_2, A_arbace_zip_A_const_3); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :12:1
func A_arbace_zip_eval703000008_fn__703000009_A_New() *A_arbace_zip_eval703000008_fn__703000009_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_eval703000008_fn__703000009_A{}; t.Ctor(); return t }
//line :12:1
func (t *A_arbace_zip_eval703000008_fn__703000009_A) Ctor() {}
//line :12:1
func (t *A_arbace_zip_eval703000008_fn__703000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_zip_A_const_4.GetRawRoot__O()); var tmp2 any; var root_7 any = A_arbace_zip_A_const_5.GetRawRoot__O(); var linked_8 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_7, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_9 lang.IFn; if linked_8 == nil { ifn_9 = lang.IFn_Cast(root_7) } else { ifn_9 = nil }; var arg_10 any = A_arbace_zip_A_const_6; if linked_8 == nil { tmp2 = ifn_9.Invoke_O__O(arg_10) } else { tmp2 = linked_8.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_7, arg_10) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_zip_A_const_7.GetRawRoot__O(), A_arbace_zip_A_const_8) }





func A_arbace_zip_zipper_A_New() *A_arbace_zip_zipper_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_zipper_A{}; t.Ctor(); return t }
//line :18:1
func (t *A_arbace_zip_zipper_A) Ctor() {}
//line :18:1
func (t *A_arbace_zip_zipper_A) Invoke_O_O_O_O_O__O(self, branch_QMARK___0, children__1, make_node__2, root__3 any) any { return lang.IObj_Cast(lang.Tuple_Create_O_O__IPersistentVector(root__3, nil)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_zip_A_const_9, branch_QMARK___0, A_arbace_zip_A_const_10, children__1, A_arbace_zip_A_const_11, make_node__2))) }
















func A_arbace_zip_seq_zip_A_New() *A_arbace_zip_seq_zip_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_seq_zip_A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_zip_seq_zip_A) Ctor() {}
//line :35:1
func (t *A_arbace_zip_seq_zip_A) Invoke_O_O__O(self, root__0 any) any {



	var root_23 any = A_arbace_zip_A_const_12.GetRawRoot__O(); var linked_24 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_23, A_arbace_zip_zipper_A_fn_class); var ifn_25 lang.IFn; if linked_24 == nil { ifn_25 = lang.IFn_Cast(root_23) } else { ifn_25 = nil }; var arg_26 any = A_arbace_zip_A_const_13.GetRawRoot__O(); var arg_27 any = A_arbace_zip_A_const_14.GetRawRoot__O(); var arg_28 any; var tmp1 any = A_arbace_zip_seq_zip_fn__703000013_A_New(); var tmp2 *jrt.Class
	var fncls__22 /*line :39:1*/*jrt.Class = A_arbace_zip_seq_zip_fn__703000013_A_fn_class

	if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_zip_seq_zip_fn__703000013_A_fn_class = fncls__22d; tmp2 = fncls__22d } else { tmp2 = fncls__22 }; arg_28 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :39:1
	var arg_29 any = root__0; if linked_24 == nil { return ifn_25.Invoke_O_O_O_O__O(arg_26, arg_27, arg_28, arg_29) } else { return linked_24.(*A_arbace_zip_zipper_A).Invoke_O_O_O_O_O__O(root_23, arg_26, arg_27, arg_28, arg_29)
	} }
func A_arbace_zip_seq_zip_fn__703000013_A_New() *A_arbace_zip_seq_zip_fn__703000013_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_seq_zip_fn__703000013_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_zip_seq_zip_fn__703000013_A) Ctor() {}
//line :41:1
func (t *A_arbace_zip_seq_zip_fn__703000013_A) Invoke_O_O_O__O(self, node__1, children__2 any) any { var root_17 any = A_arbace_zip_A_const_15.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_17, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_19 lang.IFn; if linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any = children__2; var arg_21 any = lang.RT_Meta_O__IPersistentMap_NoInit(node__1); if linked_18 == nil { return ifn_19.Invoke_O_O__O(arg_20, arg_21) } else { return linked_18.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_17, arg_20, arg_21) } }


func A_arbace_zip_vector_zip_A_New() *A_arbace_zip_vector_zip_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_vector_zip_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_zip_vector_zip_A) Ctor() {}
//line :44:1
func (t *A_arbace_zip_vector_zip_A) Invoke_O_O__O(self, root__0 any) any {



	var root_40 any = A_arbace_zip_A_const_12.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_40, A_arbace_zip_zipper_A_fn_class); var ifn_42 lang.IFn; if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any = A_arbace_zip_A_const_16.GetRawRoot__O(); var arg_44 any = A_arbace_zip_A_const_17.GetRawRoot__O(); var arg_45 any; var tmp1 any = A_arbace_zip_vector_zip_fn__703000016_A_New(); var tmp2 *jrt.Class
	var fncls__39 /*line :48:1*/*jrt.Class = A_arbace_zip_vector_zip_fn__703000016_A_fn_class

	if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_zip_vector_zip_fn__703000016_A_fn_class = fncls__39d; tmp2 = fncls__39d } else { tmp2 = fncls__39 }; arg_45 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :48:1
	var arg_46 any = root__0; if linked_41 == nil { return ifn_42.Invoke_O_O_O_O__O(arg_43, arg_44, arg_45, arg_46) } else { return linked_41.(*A_arbace_zip_zipper_A).Invoke_O_O_O_O_O__O(root_40, arg_43, arg_44, arg_45, arg_46)
	} }
func A_arbace_zip_vector_zip_fn__703000016_A_New() *A_arbace_zip_vector_zip_fn__703000016_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_vector_zip_fn__703000016_A{}; t.Ctor(); return t }
//line :50:1
func (t *A_arbace_zip_vector_zip_fn__703000016_A) Ctor() {}
//line :50:1
func (t *A_arbace_zip_vector_zip_fn__703000016_A) Invoke_O_O_O__O(self, node__1, children__2 any) any { var root_34 any = A_arbace_zip_A_const_15.GetRawRoot__O(); var linked_35 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_34, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_36 lang.IFn; if linked_35 == nil { ifn_36 = lang.IFn_Cast(root_34) } else { ifn_36 = nil }; var arg_37 any; var root_30 any = A_arbace_zip_A_const_18.GetRawRoot__O(); var linked_31 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_30, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_32 lang.IFn; if linked_31 == nil { ifn_32 = lang.IFn_Cast(root_30) } else { ifn_32 = nil }; var arg_33 any = children__2; if linked_31 == nil { arg_37 = ifn_32.Invoke_O__O(arg_33) } else { arg_37 = linked_31.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_30, arg_33) }; var arg_38 any = lang.RT_Meta_O__IPersistentMap_NoInit(node__1); if linked_35 == nil { return ifn_36.Invoke_O_O__O(arg_37, arg_38) } else { return linked_35.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_34, arg_37, arg_38) } }


func A_arbace_zip_xml_zip_A_New() *A_arbace_zip_xml_zip_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_xml_zip_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_zip_xml_zip_A) Ctor() {}
//line :53:1
func (t *A_arbace_zip_xml_zip_A) Invoke_O_O__O(self, root__0 any) any {




	var root_68 any = A_arbace_zip_A_const_12.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, A_arbace_zip_zipper_A_fn_class); var ifn_70 lang.IFn; if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any; var root_47 any = A_arbace_zip_A_const_19.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, aot_arbace_core.A_arbace_core_complement_A_fn_class); var ifn_49 lang.IFn; if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = A_arbace_zip_A_const_20.GetRawRoot__O(); if linked_48 == nil { arg_71 = ifn_49.Invoke_O__O(arg_50) } else { arg_71 = linked_48.(*aot_arbace_core.A_arbace_core_complement_A).Invoke_O_O__O(root_47, arg_50) }; var arg_72 any; var root_51 any = A_arbace_zip_A_const_21.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_51, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_53 lang.IFn
	if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = A_arbace_zip_A_const_17.GetRawRoot__O(); var arg_55 any = A_arbace_zip_A_const_22; if linked_52 == nil { arg_72 = ifn_53.Invoke_O_O__O(arg_54, arg_55) } else { arg_72 = linked_52.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_51, arg_54, arg_55) }
//line :58:1
	var arg_73 any; var tmp1 any = A_arbace_zip_xml_zip_fn__703000019_A_New(); var tmp2 *jrt.Class
	var fncls__67 /*line :58:1*/*jrt.Class = A_arbace_zip_xml_zip_fn__703000019_A_fn_class

	if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_zip_xml_zip_fn__703000019_A_fn_class = fncls__67d; tmp2 = fncls__67d } else { tmp2 = fncls__67 }; arg_73 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :58:1
	var arg_74 any = root__0; if linked_69 == nil { return ifn_70.Invoke_O_O_O_O__O(arg_71, arg_72, arg_73, arg_74) } else { return linked_69.(*A_arbace_zip_zipper_A).Invoke_O_O_O_O_O__O(root_68, arg_71, arg_72, arg_73, arg_74)
	} }
func A_arbace_zip_xml_zip_fn__703000019_A_New() *A_arbace_zip_xml_zip_fn__703000019_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_xml_zip_fn__703000019_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_zip_xml_zip_fn__703000019_A) Ctor() {}
//line :60:1
func (t *A_arbace_zip_xml_zip_fn__703000019_A) Invoke_O_O_O__O(self, node__1, children__2 any) any {
	var root_61 any = A_arbace_zip_A_const_23.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_61, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_63 lang.IFn; if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any = node__1; var arg_65 any = A_arbace_zip_A_const_22; var arg_66 any; var and__1927000168__auto____3 any = children__2; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_56 any = A_arbace_zip_A_const_24.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_56, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_58 lang.IFn; if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any = A_arbace_zip_A_const_25.GetRawRoot__O(); var arg_60 any = children__2; if linked_57 == nil { arg_66 = ifn_58.Invoke_O_O__O(arg_59, arg_60) } else { arg_66 = linked_57.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_56, arg_59, arg_60) } } else { arg_66 = and__1927000168__auto____3 }; if linked_62 == nil { return ifn_63.Invoke_O_O_O__O(arg_64, arg_65, arg_66) } else { return linked_62.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_61, arg_64, arg_65, arg_66)
	}
}
func A_arbace_zip_node_A_New() *A_arbace_zip_node_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_node_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_zip_node_A) Ctor() {}
//line :64:1
func (t *A_arbace_zip_node_A) Invoke_O_O__O(self, loc__0 any) any {


	return lang.IFn_Cast(loc__0).Invoke_O__O(A_arbace_zip_A_const_26)
}
func A_arbace_zip_branch_QMARK__A_New() *A_arbace_zip_branch_QMARK__A { A_arbace_zip_A_Init(); t := &A_arbace_zip_branch_QMARK__A{}; t.Ctor(); return t }
//line :69:1
func (t *A_arbace_zip_branch_QMARK__A) Ctor() {}
//line :69:1
func (t *A_arbace_zip_branch_QMARK__A) Invoke_O_O__O(self, loc__0 any) any {



	var tmp1 *lang.Keyword = A_arbace_zip_A_const_9; var tmp2 lang.IFn = lang.IFn_Cast(tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(loc__0))); var tmp3 any; var root_75 any = A_arbace_zip_A_const_27.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_75, A_arbace_zip_node_A_fn_class); var ifn_77 lang.IFn; if linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any = loc__0; if linked_76 == nil { tmp3 = ifn_77.Invoke_O__O(arg_78) } else { tmp3 = linked_76.(*A_arbace_zip_node_A).Invoke_O_O__O(root_75, arg_78) }; return tmp2.Invoke_O__O(tmp3)
}
func A_arbace_zip_children_A_New() *A_arbace_zip_children_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_children_A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_zip_children_A) Ctor() {}
//line :75:1
func (t *A_arbace_zip_children_A) Invoke_O_O__O(self, loc__0 any) any {



	var tmp1 any; var root_79 any = A_arbace_zip_A_const_28.GetRawRoot__O(); var linked_80 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_79, A_arbace_zip_branch_QMARK__A_fn_class); var ifn_81 lang.IFn; if linked_80 == nil { ifn_81 = lang.IFn_Cast(root_79) } else { ifn_81 = nil }; var arg_82 any = loc__0; if linked_80 == nil { tmp1 = ifn_81.Invoke_O__O(arg_82) } else { tmp1 = linked_80.(*A_arbace_zip_branch_QMARK__A).Invoke_O_O__O(root_79, arg_82) }; if jrt.J2g_Truth(tmp1) {
		var tmp2 *lang.Keyword = A_arbace_zip_A_const_10; var tmp3 lang.IFn = lang.IFn_Cast(tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(loc__0))); var tmp4 any; var root_83 any = A_arbace_zip_A_const_27.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_83, A_arbace_zip_node_A_fn_class); var ifn_85 lang.IFn; if linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any = loc__0; if linked_84 == nil { tmp4 = ifn_85.Invoke_O__O(arg_86) } else { tmp4 = linked_84.(*A_arbace_zip_node_A).Invoke_O_O__O(root_83, arg_86) }; return tmp3.Invoke_O__O(tmp4) } else {
//line :79:1
			panic(jrt.Thrown(jrt.Exception_New_String(Lit_1)))
		}
}

func A_arbace_zip_make_node_A_New() *A_arbace_zip_make_node_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_make_node_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_zip_make_node_A) Ctor() {}
//line :83:1
func (t *A_arbace_zip_make_node_A) Invoke_O_O_O_O__O(self, loc__0, node__1, children__2 any) any {




	var tmp1 *lang.Keyword = A_arbace_zip_A_const_11; return lang.IFn_Cast(tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(loc__0))).Invoke_O_O__O(node__1, children__2)
}
func A_arbace_zip_path_A_New() *A_arbace_zip_path_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_path_A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_zip_path_A) Ctor() {}
//line :90:1
func (t *A_arbace_zip_path_A) Invoke_O_O__O(self, loc__0 any) any {



	var tmp1 *lang.Keyword = A_arbace_zip_A_const_29; return tmp1.Invoke_O__O(lang.IFn_Cast(loc__0).Invoke_O__O(A_arbace_zip_A_const_30))
}
func A_arbace_zip_lefts_A_New() *A_arbace_zip_lefts_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_lefts_A{}; t.Ctor(); return t }
//line :96:1
func (t *A_arbace_zip_lefts_A) Ctor() {}
//line :96:1
func (t *A_arbace_zip_lefts_A) Invoke_O_O__O(self, loc__0 any) any {



	var root_87 any = A_arbace_zip_A_const_17.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_89 lang.IFn; if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var tmp1 *lang.Keyword = A_arbace_zip_A_const_31; var arg_90 any = tmp1.Invoke_O__O(lang.IFn_Cast(loc__0).Invoke_O__O(A_arbace_zip_A_const_30)); if linked_88 == nil { return ifn_89.Invoke_O__O(arg_90) } else { return linked_88.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_87, arg_90)
	} }
func A_arbace_zip_rights_A_New() *A_arbace_zip_rights_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_rights_A{}; t.Ctor(); return t }
//line :102:1
func (t *A_arbace_zip_rights_A) Ctor() {}
//line :102:1
func (t *A_arbace_zip_rights_A) Invoke_O_O__O(self, loc__0 any) any {



	var tmp1 *lang.Keyword = A_arbace_zip_A_const_32; return tmp1.Invoke_O__O(lang.IFn_Cast(loc__0).Invoke_O__O(A_arbace_zip_A_const_30))
}
func A_arbace_zip_down_A_New() *A_arbace_zip_down_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_down_A{}; t.Ctor(); return t }
//line :108:1
func (t *A_arbace_zip_down_A) Ctor() {}
//line :108:1
func (t *A_arbace_zip_down_A) Invoke_O_O__O(self, loc__0 any) any {




	var tmp1 any; var root_91 any = A_arbace_zip_A_const_28.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, A_arbace_zip_branch_QMARK__A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = loc__0; if linked_92 == nil { tmp1 = ifn_93.Invoke_O__O(arg_94) } else { tmp1 = linked_92.(*A_arbace_zip_branch_QMARK__A).Invoke_O_O__O(root_91, arg_94) }; if jrt.J2g_Truth(tmp1) { var vec__703000029__2 any = loc__0; var node__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__703000029__2, lang.RT_IntCast_J__I_NoInit(0), nil); var path__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__703000029__2, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__703000032__5 any; var root_95 any = A_arbace_zip_A_const_33.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, A_arbace_zip_children_A_fn_class); var ifn_97 lang.IFn

		if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any = loc__0; if linked_96 == nil { vec__703000032__5 = ifn_97.Invoke_O__O(arg_98) } else { vec__703000032__5 = linked_96.(*A_arbace_zip_children_A).Invoke_O_O__O(root_95, arg_98) }
//line :113:1
		var seq__703000033__6 any; var root_99 any = A_arbace_zip_A_const_17.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_101 lang.IFn
		if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any = vec__703000032__5; if linked_100 == nil { seq__703000033__6 = ifn_101.Invoke_O__O(arg_102) } else { seq__703000033__6 = linked_100.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_99, arg_102) }
//line :113:1
		var first__703000034__7 any; var root_103 any = A_arbace_zip_A_const_34.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_103, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_105 lang.IFn
		if linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any = seq__703000033__6; if linked_104 == nil { first__703000034__7 = ifn_105.Invoke_O__O(arg_106) } else { first__703000034__7 = linked_104.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_103, arg_106) }
//line :113:1
		var seq__703000033__8 any; var root_107 any = A_arbace_zip_A_const_35.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_109 lang.IFn
		if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = seq__703000033__6; if linked_108 == nil { seq__703000033__8 = ifn_109.Invoke_O__O(arg_110) } else { seq__703000033__8 = linked_108.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_107, arg_110) }
//line :113:1
		var c__9 any = first__703000034__7
		var cnext__10 any = seq__703000033__8
		var cs__11 any = vec__703000032__5
		if jrt.J2g_Truth(cs__11) {
			var root_116 any = A_arbace_zip_A_const_15.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_116, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_118 lang.IFn; if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any; var tmp2 any = A_arbace_zip_A_const_31; var tmp3 any = lang.PersistentVector_EMPTY.Ref(); var tmp4 any = A_arbace_zip_A_const_29; var tmp5 any
			if jrt.J2g_Truth(path__4) { var root_111 any = A_arbace_zip_A_const_7.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_113 lang.IFn; if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = A_arbace_zip_A_const_29.Invoke_O__O(path__4); var arg_115 any = node__3; if linked_112 == nil { tmp5 = ifn_113.Invoke_O_O__O(arg_114, arg_115) } else { tmp5 = linked_112.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_111, arg_114, arg_115) } } else { tmp5 = lang.Tuple_Create_O__IPersistentVector(node__3) }
//line :117:1
			arg_119 = lang.Tuple_Create_O_O__IPersistentVector(c__9, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, tmp5, A_arbace_zip_A_const_36, path__4, A_arbace_zip_A_const_32, cnext__10))); var arg_120 any = lang.RT_Meta_O__IPersistentMap_NoInit(loc__0); if linked_117 == nil { return ifn_118.Invoke_O_O__O(arg_119, arg_120) } else { return linked_117.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_116, arg_119, arg_120) } } else {
//line :116:1
				return nil } } else {
//line :113:1
					return nil
				}
}






func A_arbace_zip_up_A_New() *A_arbace_zip_up_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_up_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_zip_up_A) Ctor() {}
//line :122:1
func (t *A_arbace_zip_up_A) Invoke_O_O__O(self, loc__0 any) any { var vec__703000036__2 any = loc__0; var node__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__703000036__2, lang.RT_IntCast_J__I_NoInit(0), nil); var map__703000039__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__703000036__2, lang.RT_IntCast_J__I_NoInit(1), nil); var map__703000039__5 any; if




	lang.ISeq_InstanceOf(map__703000039__4) { var tmp1 any; var root_121 any = A_arbace_zip_A_const_35.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_123 lang.IFn; if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = map__703000039__4; if linked_122 == nil { tmp1 = ifn_123.Invoke_O__O(arg_124) } else { tmp1 = linked_122.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_121, arg_124) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_125 any = A_arbace_zip_A_const_37.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_125, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_127 lang.IFn; if linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; var arg_128 any = map__703000039__4; if linked_126 == nil { tmp2 = ifn_127.Invoke_O__O(arg_128) } else { tmp2 = linked_126.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_125, arg_128) }; map__703000039__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_129 any = A_arbace_zip_A_const_17.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_129, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any = map__703000039__4; if linked_130 == nil { tmp3 = ifn_131.Invoke_O__O(arg_132) } else { tmp3 = linked_130.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_129, arg_132) }; if jrt.J2g_Truth(tmp3) { var root_133 any = A_arbace_zip_A_const_34.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_133, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_135 lang.IFn; if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any = map__703000039__4; if linked_134 == nil { map__703000039__5 = ifn_135.Invoke_O__O(arg_136) } else { map__703000039__5 = linked_134.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_133, arg_136) } } else { map__703000039__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__703000039__5 = map__703000039__4 }; var path__6 any = map__703000039__5; var l__7 any = /*line :122:1*/lang.RT_Get_O_O__O_NoInit(map__703000039__5, A_arbace_zip_A_const_31); var ppath__8 any = lang.RT_Get_O_O__O_NoInit(map__703000039__5, A_arbace_zip_A_const_36); var pnodes__9 any = lang.RT_Get_O_O__O_NoInit(map__703000039__5, A_arbace_zip_A_const_29); var r__10 any = lang.RT_Get_O_O__O_NoInit(map__703000039__5, A_arbace_zip_A_const_32); var changed_QMARK___11 any = lang.RT_Get_O_O__O_NoInit(map__703000039__5, A_arbace_zip_A_const_38); _ = path__6; if





	jrt.J2g_Truth(pnodes__9) { var pnode__12 any; var root_137 any = A_arbace_zip_A_const_39.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_139 lang.IFn
		if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any = pnodes__9; if linked_138 == nil { pnode__12 = ifn_139.Invoke_O__O(arg_140) } else { pnode__12 = linked_138.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_137, arg_140) }
		var root_163 any = A_arbace_zip_A_const_15.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_165 lang.IFn; if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any; if jrt.J2g_Truth(changed_QMARK___11) { var tmp4 any; var root_151 any = A_arbace_zip_A_const_40.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, A_arbace_zip_make_node_A_fn_class); var ifn_153 lang.IFn
			if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = loc__0; var arg_155 any = pnode__12; var arg_156 any; var root_146 any = A_arbace_zip_A_const_41.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = l__7; var arg_150 any; var root_141 any = A_arbace_zip_A_const_42.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_141, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_143 lang.IFn; if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = node__3; var arg_145 any = r__10; if linked_142 == nil { arg_150 = ifn_143.Invoke_O_O__O(arg_144, arg_145) } else { arg_150 = linked_142.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_141, arg_144, arg_145) }; if linked_147 == nil { arg_156 = ifn_148.Invoke_O_O__O(arg_149, arg_150) } else { arg_156 = linked_147.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_146, arg_149, arg_150) }; if linked_152 == nil { tmp4 = ifn_153.Invoke_O_O_O__O(arg_154, arg_155, arg_156) } else { tmp4 = linked_152.(*A_arbace_zip_make_node_A).Invoke_O_O_O_O__O(root_151, arg_154, arg_155, arg_156) }
//line :130:1
			var tmp5 any = tmp4; var tmp6 any
			var and__1927000168__auto____13 any = ppath__8
			if jrt.J2g_Truth(and__1927000168__auto____13) { var root_157 any = A_arbace_zip_A_const_23.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_157, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_159 lang.IFn; if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any = ppath__8; var arg_161 any = A_arbace_zip_A_const_38; var arg_162 any = jrt.Boolean_TRUE.Ref(); if linked_158 == nil { tmp6 = ifn_159.Invoke_O_O_O__O(arg_160, arg_161, arg_162) } else { tmp6 = linked_158.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_157, arg_160, arg_161, arg_162) } } else { tmp6 = and__1927000168__auto____13 }
//line :130:1
			arg_166 = lang.Tuple_Create_O_O__IPersistentVector(tmp5, tmp6) } else { arg_166 = lang.Tuple_Create_O_O__IPersistentVector(pnode__12, ppath__8) }; var arg_167 any = lang.RT_Meta_O__IPersistentMap_NoInit(loc__0); if linked_164 == nil { return ifn_165.Invoke_O_O__O(arg_166, arg_167) } else { return linked_164.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_163, arg_166, arg_167) } } else {
//line :128:1
				return nil } }







func A_arbace_zip_root_A_New() *A_arbace_zip_root_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_root_A{}; t.Ctor(); return t }
//line :136:1
func (t *A_arbace_zip_root_A) Ctor() {}
//line :136:1
func (t *A_arbace_zip_root_A) Invoke_O_O__O(self, loc__0 any) any { { var loc__0_2 any = loc__0; L1: for {




	var tmp1 any = A_arbace_zip_A_const_43; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, lang.IFn_Cast(loc__0_2).Invoke_O__O(A_arbace_zip_A_const_30)) {
		var root_168 any = A_arbace_zip_A_const_27.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, A_arbace_zip_node_A_fn_class); var ifn_170 lang.IFn; if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = loc__0_2; if linked_169 == nil { return ifn_170.Invoke_O__O(arg_171) } else { return linked_169.(*A_arbace_zip_node_A).Invoke_O_O__O(root_168, arg_171) } } else {
//line :141:1
			var p__2 any; var root_172 any = A_arbace_zip_A_const_44.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, A_arbace_zip_up_A_fn_class); var ifn_174 lang.IFn

			if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = loc__0_2; if linked_173 == nil { p__2 = ifn_174.Invoke_O__O(arg_175) } else { p__2 = linked_173.(*A_arbace_zip_up_A).Invoke_O_O__O(root_172, arg_175) }
			if jrt.J2g_Truth(p__2) {
				loc__0_2 = p__2; continue L1 } else {
					var root_176 any = A_arbace_zip_A_const_27.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, A_arbace_zip_node_A_fn_class); var ifn_178 lang.IFn; if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any = loc__0_2; if linked_177 == nil { return ifn_178.Invoke_O__O(arg_179) } else { return linked_177.(*A_arbace_zip_node_A).Invoke_O_O__O(root_176, arg_179) } } } } }; /*line :136:1*/panic("j2g: unreachable") }











func A_arbace_zip_right_A_New() *A_arbace_zip_right_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_right_A{}; t.Ctor(); return t }
//line :148:1
func (t *A_arbace_zip_right_A) Ctor() {}
//line :148:1
func (t *A_arbace_zip_right_A) Invoke_O_O__O(self, loc__0 any) any { var vec__703000043__2 any = loc__0; var node__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__703000043__2, lang.RT_IntCast_J__I_NoInit(0), nil); var map__703000046__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__703000043__2, lang.RT_IntCast_J__I_NoInit(1), nil); var map__703000046__5 any; if



	lang.ISeq_InstanceOf(map__703000046__4) { var tmp1 any; var root_180 any = A_arbace_zip_A_const_35.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_182 lang.IFn; if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any = map__703000046__4; if linked_181 == nil { tmp1 = ifn_182.Invoke_O__O(arg_183) } else { tmp1 = linked_181.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_180, arg_183) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_184 any = A_arbace_zip_A_const_37.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_186 lang.IFn; if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any = map__703000046__4; if linked_185 == nil { tmp2 = ifn_186.Invoke_O__O(arg_187) } else { tmp2 = linked_185.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_184, arg_187) }; map__703000046__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_188 any = A_arbace_zip_A_const_17.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any = map__703000046__4; if linked_189 == nil { tmp3 = ifn_190.Invoke_O__O(arg_191) } else { tmp3 = linked_189.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_188, arg_191) }; if jrt.J2g_Truth(tmp3) { var root_192 any = A_arbace_zip_A_const_34.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_194 lang.IFn; if linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = map__703000046__4; if linked_193 == nil { map__703000046__5 = ifn_194.Invoke_O__O(arg_195) } else { map__703000046__5 = linked_193.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_192, arg_195) } } else { map__703000046__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__703000046__5 = map__703000046__4 }; var path__6 any = map__703000046__5; var l__7 any = /*line :148:1*/lang.RT_Get_O_O__O_NoInit(map__703000046__5, A_arbace_zip_A_const_31); var vec__703000048__8 any = lang.RT_Get_O_O__O_NoInit(map__703000046__5, A_arbace_zip_A_const_32); var seq__703000049__9 any; var root_196 any = A_arbace_zip_A_const_17.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_198 lang.IFn; if



	linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any = vec__703000048__8; if linked_197 == nil { seq__703000049__9 = ifn_198.Invoke_O__O(arg_199) } else { seq__703000049__9 = linked_197.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_196, arg_199) }; var first__703000050__10 any; var root_200 any = /*line :148:1*/A_arbace_zip_A_const_34.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_202 lang.IFn; if



	linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any = seq__703000049__9; if linked_201 == nil { first__703000050__10 = ifn_202.Invoke_O__O(arg_203) } else { first__703000050__10 = linked_201.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_200, arg_203) }; var seq__703000049__11 any; var root_204 any = /*line :148:1*/A_arbace_zip_A_const_35.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_206 lang.IFn; if



	linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = seq__703000049__9; if linked_205 == nil { seq__703000049__11 = ifn_206.Invoke_O__O(arg_207) } else { seq__703000049__11 = linked_205.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_204, arg_207) }; var r__12 any = first__703000050__10; var rnext__13 any = seq__703000049__11; var rs__14 any = vec__703000048__8; var tmp4 any; var and__1927000168__auto____15 any = path__6; if
	jrt.J2g_Truth(and__1927000168__auto____15) { tmp4 = rs__14 } else { tmp4 = and__1927000168__auto____15 }; if jrt.J2g_Truth(tmp4) {
		var root_221 any = A_arbace_zip_A_const_15.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_zip_A_const_23.GetRawRoot__O()); var tmp6 any = A_arbace_zip_A_const_31; var tmp7 any; var root_208 any = A_arbace_zip_A_const_7.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_208, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any = l__7; var arg_212 any = node__3; if linked_209 == nil { tmp7 = ifn_210.Invoke_O_O__O(arg_211, arg_212) } else { tmp7 = linked_209.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_208, arg_211, arg_212) }; arg_224 = lang.Tuple_Create_O_O__IPersistentVector(r__12, tmp5.Invoke_O_O_O_O_O__O(path__6, tmp6, tmp7, A_arbace_zip_A_const_32, rnext__13)); var arg_225 any = lang.RT_Meta_O__IPersistentMap_NoInit(loc__0); if linked_222 == nil { return ifn_223.Invoke_O_O__O(arg_224, arg_225) } else { return linked_222.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_221, arg_224, arg_225) } } else {
//line :153:1
			return nil } }


func A_arbace_zip_rightmost_A_New() *A_arbace_zip_rightmost_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_rightmost_A{}; t.Ctor(); return t }
//line :156:1
func (t *A_arbace_zip_rightmost_A) Ctor() {}
//line :156:1
func (t *A_arbace_zip_rightmost_A) Invoke_O_O__O(self, loc__0 any) any { var vec__703000052__2 any = loc__0; var node__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__703000052__2, lang.RT_IntCast_J__I_NoInit(0), nil); var map__703000055__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__703000052__2, lang.RT_IntCast_J__I_NoInit(1), nil); var map__703000055__5 any; if



	lang.ISeq_InstanceOf(map__703000055__4) { var tmp1 any; var root_226 any = A_arbace_zip_A_const_35.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_226, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_228 lang.IFn; if linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var arg_229 any = map__703000055__4; if linked_227 == nil { tmp1 = ifn_228.Invoke_O__O(arg_229) } else { tmp1 = linked_227.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_226, arg_229) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_230 any = A_arbace_zip_A_const_37.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_230, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_232 lang.IFn; if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = map__703000055__4; if linked_231 == nil { tmp2 = ifn_232.Invoke_O__O(arg_233) } else { tmp2 = linked_231.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_230, arg_233) }; map__703000055__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_234 any = A_arbace_zip_A_const_17.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_234, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = map__703000055__4; if linked_235 == nil { tmp3 = ifn_236.Invoke_O__O(arg_237) } else { tmp3 = linked_235.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_234, arg_237) }; if jrt.J2g_Truth(tmp3) { var root_238 any = A_arbace_zip_A_const_34.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_240 lang.IFn; if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any = map__703000055__4; if linked_239 == nil { map__703000055__5 = ifn_240.Invoke_O__O(arg_241) } else { map__703000055__5 = linked_239.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_238, arg_241) } } else { map__703000055__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__703000055__5 = map__703000055__4 }; var path__6 any = map__703000055__5; var l__7 any = /*line :156:1*/lang.RT_Get_O_O__O_NoInit(map__703000055__5, A_arbace_zip_A_const_31); var r__8 any = lang.RT_Get_O_O__O_NoInit(map__703000055__5, A_arbace_zip_A_const_32); var tmp4 any; var and__1927000168__auto____9 any = path__6; if




	jrt.J2g_Truth(and__1927000168__auto____9) { tmp4 = r__8 } else { tmp4 = and__1927000168__auto____9 }; if jrt.J2g_Truth(tmp4) {
		var root_265 any = A_arbace_zip_A_const_15.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_265, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_267 lang.IFn; if linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any; var tmp5 any; var root_242 any = A_arbace_zip_A_const_45.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = r__8; if linked_243 == nil { tmp5 = ifn_244.Invoke_O__O(arg_245) } else { tmp5 = linked_243.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_242, arg_245) }; var tmp6 any = tmp5; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_zip_A_const_23.GetRawRoot__O()); var tmp8 any = A_arbace_zip_A_const_31; var tmp9 any; var root_250 any = A_arbace_zip_A_const_24.GetRawRoot__O(); var linked_251 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_250, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_252 lang.IFn; if linked_251 == nil { ifn_252 = lang.IFn_Cast(root_250) } else { ifn_252 = nil }; var arg_253 any = A_arbace_zip_A_const_7.GetRawRoot__O(); var arg_254 any = l__7; var arg_255 any = node__3; var arg_256 any; var root_246 any = A_arbace_zip_A_const_46.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_core.A_arbace_core_butlast__1927000056_A_fn_class); var ifn_248 lang.IFn; if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = r__8; if linked_247 == nil { arg_256 = ifn_248.Invoke_O__O(arg_249) } else { arg_256 = linked_247.(*aot_arbace_core.A_arbace_core_butlast__1927000056_A).Invoke_O_O__O(root_246, arg_249) }; if linked_251 == nil { tmp9 = ifn_252.Invoke_O_O_O_O__O(arg_253, arg_254, arg_255, arg_256) } else { tmp9 = linked_251.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_250, arg_253, arg_254, arg_255, arg_256) }; arg_268 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7.Invoke_O_O_O_O_O__O(path__6, tmp8, tmp9, A_arbace_zip_A_const_32, nil)); var arg_269 any = lang.RT_Meta_O__IPersistentMap_NoInit(loc__0); if linked_266 == nil { return ifn_267.Invoke_O_O__O(arg_268, arg_269) } else { return linked_266.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_265, arg_268, arg_269) } } else {
//line :161:1
			return loc__0 } }



func A_arbace_zip_left_A_New() *A_arbace_zip_left_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_left_A{}; t.Ctor(); return t }
//line :165:1
func (t *A_arbace_zip_left_A) Ctor() {}
//line :165:1
func (t *A_arbace_zip_left_A) Invoke_O_O__O(self, loc__0 any) any { var vec__703000058__2 any = loc__0; var node__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__703000058__2, lang.RT_IntCast_J__I_NoInit(0), nil); var map__703000061__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__703000058__2, lang.RT_IntCast_J__I_NoInit(1), nil); var map__703000061__5 any; if



	lang.ISeq_InstanceOf(map__703000061__4) { var tmp1 any; var root_270 any = A_arbace_zip_A_const_35.GetRawRoot__O(); var linked_271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_270, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_272 lang.IFn; if linked_271 == nil { ifn_272 = lang.IFn_Cast(root_270) } else { ifn_272 = nil }; var arg_273 any = map__703000061__4; if linked_271 == nil { tmp1 = ifn_272.Invoke_O__O(arg_273) } else { tmp1 = linked_271.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_270, arg_273) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_274 any = A_arbace_zip_A_const_37.GetRawRoot__O(); var linked_275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_274, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_276 lang.IFn; if linked_275 == nil { ifn_276 = lang.IFn_Cast(root_274) } else { ifn_276 = nil }; var arg_277 any = map__703000061__4; if linked_275 == nil { tmp2 = ifn_276.Invoke_O__O(arg_277) } else { tmp2 = linked_275.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_274, arg_277) }; map__703000061__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_278 any = A_arbace_zip_A_const_17.GetRawRoot__O(); var linked_279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_278, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_280 lang.IFn; if linked_279 == nil { ifn_280 = lang.IFn_Cast(root_278) } else { ifn_280 = nil }; var arg_281 any = map__703000061__4; if linked_279 == nil { tmp3 = ifn_280.Invoke_O__O(arg_281) } else { tmp3 = linked_279.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_278, arg_281) }; if jrt.J2g_Truth(tmp3) { var root_282 any = A_arbace_zip_A_const_34.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_282, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_284 lang.IFn; if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any = map__703000061__4; if linked_283 == nil { map__703000061__5 = ifn_284.Invoke_O__O(arg_285) } else { map__703000061__5 = linked_283.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_282, arg_285) } } else { map__703000061__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__703000061__5 = map__703000061__4 }; var path__6 any = map__703000061__5; var l__7 any = /*line :165:1*/lang.RT_Get_O_O__O_NoInit(map__703000061__5, A_arbace_zip_A_const_31); var r__8 any = lang.RT_Get_O_O__O_NoInit(map__703000061__5, A_arbace_zip_A_const_32); var tmp4 any; var and__1927000168__auto____9 any = path__6; if




	jrt.J2g_Truth(and__1927000168__auto____9) { var root_286 any = A_arbace_zip_A_const_17.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_286, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_288 lang.IFn; if linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any = l__7; if linked_287 == nil { tmp4 = ifn_288.Invoke_O__O(arg_289) } else { tmp4 = linked_287.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_286, arg_289) } } else { tmp4 = and__1927000168__auto____9 }; if jrt.J2g_Truth(tmp4) {
		var root_311 any = A_arbace_zip_A_const_15.GetRawRoot__O(); var linked_312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_311, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_313 lang.IFn; if linked_312 == nil { ifn_313 = lang.IFn_Cast(root_311) } else { ifn_313 = nil }; var arg_314 any; var tmp5 any; var root_290 any = A_arbace_zip_A_const_39.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_290, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_292 lang.IFn; if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any = l__7; if linked_291 == nil { tmp5 = ifn_292.Invoke_O__O(arg_293) } else { tmp5 = linked_291.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_290, arg_293) }; var tmp6 any = tmp5; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_zip_A_const_23.GetRawRoot__O()); var tmp8 any = A_arbace_zip_A_const_31; var tmp9 any; var root_294 any = A_arbace_zip_A_const_47.GetRawRoot__O(); var linked_295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_294, aot_arbace_core.A_arbace_core_pop_A_fn_class); var ifn_296 lang.IFn; if linked_295 == nil { ifn_296 = lang.IFn_Cast(root_294) } else { ifn_296 = nil }; var arg_297 any = l__7; if linked_295 == nil { tmp9 = ifn_296.Invoke_O__O(arg_297) } else { tmp9 = linked_295.(*aot_arbace_core.A_arbace_core_pop_A).Invoke_O_O__O(root_294, arg_297) }; var tmp10 any = tmp9; var tmp11 any = A_arbace_zip_A_const_32; var tmp12 any; var root_298 any = A_arbace_zip_A_const_42.GetRawRoot__O(); var linked_299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_298, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_300 lang.IFn; if linked_299 == nil { ifn_300 = lang.IFn_Cast(root_298) } else { ifn_300 = nil }; var arg_301 any = node__3; var arg_302 any = r__8; if linked_299 == nil { tmp12 = ifn_300.Invoke_O_O__O(arg_301, arg_302) } else { tmp12 = linked_299.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_298, arg_301, arg_302) }; arg_314 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7.Invoke_O_O_O_O_O__O(path__6, tmp8, tmp10, tmp11, tmp12)); var arg_315 any = lang.RT_Meta_O__IPersistentMap_NoInit(loc__0); if linked_312 == nil { return ifn_313.Invoke_O_O__O(arg_314, arg_315) } else { return linked_312.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_311, arg_314, arg_315) } } else {
//line :170:1
			return nil } }


func A_arbace_zip_leftmost_A_New() *A_arbace_zip_leftmost_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_leftmost_A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_zip_leftmost_A) Ctor() {}
//line :173:1
func (t *A_arbace_zip_leftmost_A) Invoke_O_O__O(self, loc__0 any) any { var vec__703000064__2 any = loc__0; var node__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__703000064__2, lang.RT_IntCast_J__I_NoInit(0), nil); var map__703000067__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__703000064__2, lang.RT_IntCast_J__I_NoInit(1), nil); var map__703000067__5 any; if



	lang.ISeq_InstanceOf(map__703000067__4) { var tmp1 any; var root_316 any = A_arbace_zip_A_const_35.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = map__703000067__4; if linked_317 == nil { tmp1 = ifn_318.Invoke_O__O(arg_319) } else { tmp1 = linked_317.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_316, arg_319) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_320 any = A_arbace_zip_A_const_37.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_322 lang.IFn; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = map__703000067__4; if linked_321 == nil { tmp2 = ifn_322.Invoke_O__O(arg_323) } else { tmp2 = linked_321.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_320, arg_323) }; map__703000067__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_324 any = A_arbace_zip_A_const_17.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_326 lang.IFn; if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any = map__703000067__4; if linked_325 == nil { tmp3 = ifn_326.Invoke_O__O(arg_327) } else { tmp3 = linked_325.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_324, arg_327) }; if jrt.J2g_Truth(tmp3) { var root_328 any = A_arbace_zip_A_const_34.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_330 lang.IFn; if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any = map__703000067__4; if linked_329 == nil { map__703000067__5 = ifn_330.Invoke_O__O(arg_331) } else { map__703000067__5 = linked_329.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_328, arg_331) } } else { map__703000067__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__703000067__5 = map__703000067__4 }; var path__6 any = map__703000067__5; var l__7 any = /*line :173:1*/lang.RT_Get_O_O__O_NoInit(map__703000067__5, A_arbace_zip_A_const_31); var r__8 any = lang.RT_Get_O_O__O_NoInit(map__703000067__5, A_arbace_zip_A_const_32); var tmp4 any; var and__1927000168__auto____9 any = path__6; if




	jrt.J2g_Truth(and__1927000168__auto____9) { var root_332 any = A_arbace_zip_A_const_17.GetRawRoot__O(); var linked_333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_332, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_334 lang.IFn; if linked_333 == nil { ifn_334 = lang.IFn_Cast(root_332) } else { ifn_334 = nil }; var arg_335 any = l__7; if linked_333 == nil { tmp4 = ifn_334.Invoke_O__O(arg_335) } else { tmp4 = linked_333.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_332, arg_335) } } else { tmp4 = and__1927000168__auto____9 }; if jrt.J2g_Truth(tmp4) {
		var root_358 any = A_arbace_zip_A_const_15.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_360 lang.IFn; if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any; var tmp5 any; var root_336 any = A_arbace_zip_A_const_34.GetRawRoot__O(); var linked_337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_336, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_338 lang.IFn; if linked_337 == nil { ifn_338 = lang.IFn_Cast(root_336) } else { ifn_338 = nil }; var arg_339 any = l__7; if linked_337 == nil { tmp5 = ifn_338.Invoke_O__O(arg_339) } else { tmp5 = linked_337.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_336, arg_339) }; var tmp6 any = tmp5; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_zip_A_const_23.GetRawRoot__O()); var tmp8 any = A_arbace_zip_A_const_31; var tmp9 any = lang.PersistentVector_EMPTY.Ref(); var tmp10 any = A_arbace_zip_A_const_32; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_zip_A_const_41.GetRawRoot__O()); var tmp12 any; var root_340 any = A_arbace_zip_A_const_48.GetRawRoot__O(); var linked_341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_340, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_342 lang.IFn; if linked_341 == nil { ifn_342 = lang.IFn_Cast(root_340) } else { ifn_342 = nil }; var arg_343 any = l__7; if linked_341 == nil { tmp12 = ifn_342.Invoke_O__O(arg_343) } else { tmp12 = linked_341.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_340, arg_343) }; arg_361 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7.Invoke_O_O_O_O_O__O(path__6, tmp8, tmp9, tmp10, tmp11.Invoke_O_O_O__O(tmp12, lang.Tuple_Create_O__IPersistentVector(node__3), r__8))); var arg_362 any = lang.RT_Meta_O__IPersistentMap_NoInit(loc__0); if linked_359 == nil { return ifn_360.Invoke_O_O__O(arg_361, arg_362) } else { return linked_359.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_358, arg_361, arg_362) } } else {
//line :178:1
			return loc__0 } }



func A_arbace_zip_insert_left_A_New() *A_arbace_zip_insert_left_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_insert_left_A{}; t.Ctor(); return t }
//line :182:1
func (t *A_arbace_zip_insert_left_A) Ctor() {}
//line :182:1
func (t *A_arbace_zip_insert_left_A) Invoke_O_O_O__O(self, loc__0, item__1 any) any { var vec__703000070__3 any = loc__0; var node__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__703000070__3, lang.RT_IntCast_J__I_NoInit(0), nil); var map__703000073__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__703000070__3, lang.RT_IntCast_J__I_NoInit(1), nil); var map__703000073__6 any; if




	lang.ISeq_InstanceOf(map__703000073__5) { var tmp1 any; var root_363 any = A_arbace_zip_A_const_35.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_363, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_365 lang.IFn; if linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any = map__703000073__5; if linked_364 == nil { tmp1 = ifn_365.Invoke_O__O(arg_366) } else { tmp1 = linked_364.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_363, arg_366) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_367 any = A_arbace_zip_A_const_37.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_367, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_369 lang.IFn; if linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any = map__703000073__5; if linked_368 == nil { tmp2 = ifn_369.Invoke_O__O(arg_370) } else { tmp2 = linked_368.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_367, arg_370) }; map__703000073__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_371 any = A_arbace_zip_A_const_17.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_371, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_373 lang.IFn; if linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any = map__703000073__5; if linked_372 == nil { tmp3 = ifn_373.Invoke_O__O(arg_374) } else { tmp3 = linked_372.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_371, arg_374) }; if jrt.J2g_Truth(tmp3) { var root_375 any = A_arbace_zip_A_const_34.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_375, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_377 lang.IFn; if linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any = map__703000073__5; if linked_376 == nil { map__703000073__6 = ifn_377.Invoke_O__O(arg_378) } else { map__703000073__6 = linked_376.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_375, arg_378) } } else { map__703000073__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__703000073__6 = map__703000073__5 }; var path__7 any = map__703000073__6; var l__8 any = /*line :182:1*/lang.RT_Get_O_O__O_NoInit(map__703000073__6, A_arbace_zip_A_const_31); if





	lang.Util_Identical_O_O__Z_NoInit(path__7, nil) { panic(jrt.Thrown(jrt.Exception_New_String(Lit_2))) } else {

		var root_392 any = A_arbace_zip_A_const_15.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_392, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_394 lang.IFn; if linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_zip_A_const_23.GetRawRoot__O()); var tmp5 any = A_arbace_zip_A_const_31; var tmp6 any; var root_379 any = A_arbace_zip_A_const_7.GetRawRoot__O(); var linked_380 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_379, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_381 lang.IFn; if linked_380 == nil { ifn_381 = lang.IFn_Cast(root_379) } else { ifn_381 = nil }; var arg_382 any = l__8; var arg_383 any = item__1; if linked_380 == nil { tmp6 = ifn_381.Invoke_O_O__O(arg_382, arg_383) } else { tmp6 = linked_380.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_379, arg_382, arg_383) }; arg_395 = lang.Tuple_Create_O_O__IPersistentVector(node__4, tmp4.Invoke_O_O_O_O_O__O(path__7, tmp5, tmp6, A_arbace_zip_A_const_38, jrt.Boolean_TRUE.Ref())); var arg_396 any = lang.RT_Meta_O__IPersistentMap_NoInit(loc__0); if linked_393 == nil { return ifn_394.Invoke_O_O__O(arg_395, arg_396) } else { return linked_393.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_392, arg_395, arg_396) } } }

func A_arbace_zip_insert_right_A_New() *A_arbace_zip_insert_right_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_insert_right_A{}; t.Ctor(); return t }
//line :192:1
func (t *A_arbace_zip_insert_right_A) Ctor() {}
//line :192:1
func (t *A_arbace_zip_insert_right_A) Invoke_O_O_O__O(self, loc__0, item__1 any) any { var vec__703000076__3 any = loc__0; var node__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__703000076__3, lang.RT_IntCast_J__I_NoInit(0), nil); var map__703000079__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__703000076__3, lang.RT_IntCast_J__I_NoInit(1), nil); var map__703000079__6 any; if




	lang.ISeq_InstanceOf(map__703000079__5) { var tmp1 any; var root_397 any = A_arbace_zip_A_const_35.GetRawRoot__O(); var linked_398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_397, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_399 lang.IFn; if linked_398 == nil { ifn_399 = lang.IFn_Cast(root_397) } else { ifn_399 = nil }; var arg_400 any = map__703000079__5; if linked_398 == nil { tmp1 = ifn_399.Invoke_O__O(arg_400) } else { tmp1 = linked_398.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_397, arg_400) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_401 any = A_arbace_zip_A_const_37.GetRawRoot__O(); var linked_402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_401, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_403 lang.IFn; if linked_402 == nil { ifn_403 = lang.IFn_Cast(root_401) } else { ifn_403 = nil }; var arg_404 any = map__703000079__5; if linked_402 == nil { tmp2 = ifn_403.Invoke_O__O(arg_404) } else { tmp2 = linked_402.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_401, arg_404) }; map__703000079__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_405 any = A_arbace_zip_A_const_17.GetRawRoot__O(); var linked_406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_405, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_407 lang.IFn; if linked_406 == nil { ifn_407 = lang.IFn_Cast(root_405) } else { ifn_407 = nil }; var arg_408 any = map__703000079__5; if linked_406 == nil { tmp3 = ifn_407.Invoke_O__O(arg_408) } else { tmp3 = linked_406.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_405, arg_408) }; if jrt.J2g_Truth(tmp3) { var root_409 any = A_arbace_zip_A_const_34.GetRawRoot__O(); var linked_410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_409, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_411 lang.IFn; if linked_410 == nil { ifn_411 = lang.IFn_Cast(root_409) } else { ifn_411 = nil }; var arg_412 any = map__703000079__5; if linked_410 == nil { map__703000079__6 = ifn_411.Invoke_O__O(arg_412) } else { map__703000079__6 = linked_410.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_409, arg_412) } } else { map__703000079__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__703000079__6 = map__703000079__5 }; var path__7 any = map__703000079__6; var r__8 any = /*line :192:1*/lang.RT_Get_O_O__O_NoInit(map__703000079__6, A_arbace_zip_A_const_32); if





	lang.Util_Identical_O_O__Z_NoInit(path__7, nil) { panic(jrt.Thrown(jrt.Exception_New_String(Lit_2))) } else {

		var root_426 any = A_arbace_zip_A_const_15.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_426, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_428 lang.IFn; if linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_zip_A_const_23.GetRawRoot__O()); var tmp5 any = A_arbace_zip_A_const_32; var tmp6 any; var root_413 any = A_arbace_zip_A_const_42.GetRawRoot__O(); var linked_414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_413, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_415 lang.IFn; if linked_414 == nil { ifn_415 = lang.IFn_Cast(root_413) } else { ifn_415 = nil }; var arg_416 any = item__1; var arg_417 any = r__8; if linked_414 == nil { tmp6 = ifn_415.Invoke_O_O__O(arg_416, arg_417) } else { tmp6 = linked_414.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_413, arg_416, arg_417) }; arg_429 = lang.Tuple_Create_O_O__IPersistentVector(node__4, tmp4.Invoke_O_O_O_O_O__O(path__7, tmp5, tmp6, A_arbace_zip_A_const_38, jrt.Boolean_TRUE.Ref())); var arg_430 any = lang.RT_Meta_O__IPersistentMap_NoInit(loc__0); if linked_427 == nil { return ifn_428.Invoke_O_O__O(arg_429, arg_430) } else { return linked_427.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_426, arg_429, arg_430) } } }

func A_arbace_zip_replace_A_New() *A_arbace_zip_replace_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_replace_A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_zip_replace_A) Ctor() {}
//line :202:1
func (t *A_arbace_zip_replace_A) Invoke_O_O_O__O(self, loc__0, node__1 any) any { var vec__703000082__3 any = loc__0; var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__703000082__3, lang.RT_IntCast_J__I_NoInit(0), nil); var path__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__703000082__3, lang.RT_IntCast_J__I_NoInit(1), nil); var root_437 any = A_arbace_zip_A_const_15.GetRawRoot__O(); var linked_438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_437, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_439 lang.IFn; _ = ___4; if




	linked_438 == nil { ifn_439 = lang.IFn_Cast(root_437) } else { ifn_439 = nil }; var arg_440 any; var tmp1 any; var root_431 any = A_arbace_zip_A_const_23.GetRawRoot__O(); var linked_432 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_431, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_433 lang.IFn; if linked_432 == nil { ifn_433 = lang.IFn_Cast(root_431) } else { ifn_433 = nil }; var arg_434 any = path__5; var arg_435 any = A_arbace_zip_A_const_38; var arg_436 any = jrt.Boolean_TRUE.Ref(); if linked_432 == nil { tmp1 = ifn_433.Invoke_O_O_O__O(arg_434, arg_435, arg_436) } else { tmp1 = linked_432.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_431, arg_434, arg_435, arg_436) }; arg_440 = lang.Tuple_Create_O_O__IPersistentVector(node__1, tmp1); var arg_441 any = lang.RT_Meta_O__IPersistentMap_NoInit(loc__0); if linked_438 == nil { return ifn_439.Invoke_O_O__O(arg_440, arg_441) } else { return linked_438.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_437, arg_440, arg_441) } }

func A_arbace_zip_edit_A_New() *A_arbace_zip_edit_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_edit_A{}; t.Ctor(); return t }
//line :209:1
func (t *A_arbace_zip_edit_A) Ctor() {}
//line :209:1
func (t *A_arbace_zip_edit_A) DoInvoke_O_O_O_O__O(self, loc__0, f__1, args__2 any) any {



	var root_452 any = A_arbace_zip_A_const_49.GetRawRoot__O(); var linked_453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_452, A_arbace_zip_replace_A_fn_class); var ifn_454 lang.IFn; if linked_453 == nil { ifn_454 = lang.IFn_Cast(root_452) } else { ifn_454 = nil }; var arg_455 any = loc__0; var arg_456 any; var root_446 any = A_arbace_zip_A_const_24.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_446, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_448 lang.IFn; if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = f__1; var arg_450 any; var root_442 any = A_arbace_zip_A_const_27.GetRawRoot__O(); var linked_443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_442, A_arbace_zip_node_A_fn_class); var ifn_444 lang.IFn; if linked_443 == nil { ifn_444 = lang.IFn_Cast(root_442) } else { ifn_444 = nil }; var arg_445 any = loc__0; if linked_443 == nil { arg_450 = ifn_444.Invoke_O__O(arg_445) } else { arg_450 = linked_443.(*A_arbace_zip_node_A).Invoke_O_O__O(root_442, arg_445) }; var arg_451 any = args__2; if linked_447 == nil { arg_456 = ifn_448.Invoke_O_O_O__O(arg_449, arg_450, arg_451) } else { arg_456 = linked_447.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_446, arg_449, arg_450, arg_451) }; if linked_453 == nil { return ifn_454.Invoke_O_O__O(arg_455, arg_456) } else { return linked_453.(*A_arbace_zip_replace_A).Invoke_O_O_O__O(root_452, arg_455, arg_456)
	} }
func A_arbace_zip_insert_child_A_New() *A_arbace_zip_insert_child_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_insert_child_A{}; t.Ctor(); return t }
//line :215:1
func (t *A_arbace_zip_insert_child_A) Ctor() {}
//line :215:1
func (t *A_arbace_zip_insert_child_A) Invoke_O_O_O__O(self, loc__0, item__1 any) any {




	var root_476 any = A_arbace_zip_A_const_49.GetRawRoot__O(); var linked_477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_476, A_arbace_zip_replace_A_fn_class); var ifn_478 lang.IFn; if linked_477 == nil { ifn_478 = lang.IFn_Cast(root_476) } else { ifn_478 = nil }; var arg_479 any = loc__0; var arg_480 any; var root_470 any = A_arbace_zip_A_const_40.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, A_arbace_zip_make_node_A_fn_class); var ifn_472 lang.IFn; if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any = loc__0; var arg_474 any; var root_457 any = A_arbace_zip_A_const_27.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_457, A_arbace_zip_node_A_fn_class); var ifn_459 lang.IFn; if linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; var arg_460 any = loc__0; if linked_458 == nil { arg_474 = ifn_459.Invoke_O__O(arg_460) } else { arg_474 = linked_458.(*A_arbace_zip_node_A).Invoke_O_O__O(root_457, arg_460) }; var arg_475 any; var root_465 any = A_arbace_zip_A_const_42.GetRawRoot__O(); var linked_466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_465, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_467 lang.IFn; if linked_466 == nil { ifn_467 = lang.IFn_Cast(root_465) } else { ifn_467 = nil }; var arg_468 any = item__1; var arg_469 any; var root_461 any = A_arbace_zip_A_const_33.GetRawRoot__O(); var linked_462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_461, A_arbace_zip_children_A_fn_class); var ifn_463 lang.IFn; if linked_462 == nil { ifn_463 = lang.IFn_Cast(root_461) } else { ifn_463 = nil }; var arg_464 any = loc__0; if linked_462 == nil { arg_469 = ifn_463.Invoke_O__O(arg_464) } else { arg_469 = linked_462.(*A_arbace_zip_children_A).Invoke_O_O__O(root_461, arg_464) }; if linked_466 == nil { arg_475 = ifn_467.Invoke_O_O__O(arg_468, arg_469) } else { arg_475 = linked_466.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_465, arg_468, arg_469) }; if linked_471 == nil { arg_480 = ifn_472.Invoke_O_O_O__O(arg_473, arg_474, arg_475) } else { arg_480 = linked_471.(*A_arbace_zip_make_node_A).Invoke_O_O_O_O__O(root_470, arg_473, arg_474, arg_475) }; if linked_477 == nil { return ifn_478.Invoke_O_O__O(arg_479, arg_480) } else { return linked_477.(*A_arbace_zip_replace_A).Invoke_O_O_O__O(root_476, arg_479, arg_480)
	} }
func A_arbace_zip_append_child_A_New() *A_arbace_zip_append_child_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_append_child_A{}; t.Ctor(); return t }
//line :222:1
func (t *A_arbace_zip_append_child_A) Ctor() {}
//line :222:1
func (t *A_arbace_zip_append_child_A) Invoke_O_O_O__O(self, loc__0, item__1 any) any {




	var root_500 any = A_arbace_zip_A_const_49.GetRawRoot__O(); var linked_501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_500, A_arbace_zip_replace_A_fn_class); var ifn_502 lang.IFn; if linked_501 == nil { ifn_502 = lang.IFn_Cast(root_500) } else { ifn_502 = nil }; var arg_503 any = loc__0; var arg_504 any; var root_494 any = A_arbace_zip_A_const_40.GetRawRoot__O(); var linked_495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_494, A_arbace_zip_make_node_A_fn_class); var ifn_496 lang.IFn; if linked_495 == nil { ifn_496 = lang.IFn_Cast(root_494) } else { ifn_496 = nil }; var arg_497 any = loc__0; var arg_498 any; var root_481 any = A_arbace_zip_A_const_27.GetRawRoot__O(); var linked_482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_481, A_arbace_zip_node_A_fn_class); var ifn_483 lang.IFn; if linked_482 == nil { ifn_483 = lang.IFn_Cast(root_481) } else { ifn_483 = nil }; var arg_484 any = loc__0; if linked_482 == nil { arg_498 = ifn_483.Invoke_O__O(arg_484) } else { arg_498 = linked_482.(*A_arbace_zip_node_A).Invoke_O_O__O(root_481, arg_484) }; var arg_499 any; var root_489 any = A_arbace_zip_A_const_41.GetRawRoot__O(); var linked_490 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_489, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_491 lang.IFn; if linked_490 == nil { ifn_491 = lang.IFn_Cast(root_489) } else { ifn_491 = nil }; var arg_492 any; var root_485 any = A_arbace_zip_A_const_33.GetRawRoot__O(); var linked_486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_485, A_arbace_zip_children_A_fn_class); var ifn_487 lang.IFn; if linked_486 == nil { ifn_487 = lang.IFn_Cast(root_485) } else { ifn_487 = nil }; var arg_488 any = loc__0; if linked_486 == nil { arg_492 = ifn_487.Invoke_O__O(arg_488) } else { arg_492 = linked_486.(*A_arbace_zip_children_A).Invoke_O_O__O(root_485, arg_488) }; var arg_493 any = lang.Tuple_Create_O__IPersistentVector(item__1); if linked_490 == nil { arg_499 = ifn_491.Invoke_O_O__O(arg_492, arg_493) } else { arg_499 = linked_490.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_489, arg_492, arg_493) }; if linked_495 == nil { arg_504 = ifn_496.Invoke_O_O_O__O(arg_497, arg_498, arg_499) } else { arg_504 = linked_495.(*A_arbace_zip_make_node_A).Invoke_O_O_O_O__O(root_494, arg_497, arg_498, arg_499) }; if linked_501 == nil { return ifn_502.Invoke_O_O__O(arg_503, arg_504) } else { return linked_501.(*A_arbace_zip_replace_A).Invoke_O_O_O__O(root_500, arg_503, arg_504)
	} }
func A_arbace_zip_next_A_New() *A_arbace_zip_next_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_next_A{}; t.Ctor(); return t }
//line :229:1
func (t *A_arbace_zip_next_A) Ctor() {}
//line :229:1
func (t *A_arbace_zip_next_A) Invoke_O_O__O(self, loc__0 any) any {





	{ var tmp1 any = A_arbace_zip_A_const_43; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, lang.IFn_Cast(loc__0).Invoke_O__O(A_arbace_zip_A_const_30)) { return loc__0 } else { var or__1927000174__auto____2 any; var and__1927000168__auto____2 any; var root_505 any = A_arbace_zip_A_const_28.GetRawRoot__O(); var linked_506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_505, A_arbace_zip_branch_QMARK__A_fn_class); var ifn_507 lang.IFn


		if linked_506 == nil { ifn_507 = lang.IFn_Cast(root_505) } else { ifn_507 = nil }; var arg_508 any = loc__0; if linked_506 == nil { and__1927000168__auto____2 = ifn_507.Invoke_O__O(arg_508) } else { and__1927000168__auto____2 = linked_506.(*A_arbace_zip_branch_QMARK__A).Invoke_O_O__O(root_505, arg_508) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_509 any = A_arbace_zip_A_const_50.GetRawRoot__O(); var linked_510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_509, A_arbace_zip_down_A_fn_class); var ifn_511 lang.IFn; if linked_510 == nil { ifn_511 = lang.IFn_Cast(root_509) } else { ifn_511 = nil }; var arg_512 any = loc__0; if linked_510 == nil { or__1927000174__auto____2 = ifn_511.Invoke_O__O(arg_512) } else { or__1927000174__auto____2 = linked_510.(*A_arbace_zip_down_A).Invoke_O_O__O(root_509, arg_512) } } else { or__1927000174__auto____2 = and__1927000168__auto____2 }
//line :237:1
		if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var root_513 any = A_arbace_zip_A_const_51.GetRawRoot__O(); var linked_514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_513, A_arbace_zip_right_A_fn_class); var ifn_515 lang.IFn

			if linked_514 == nil { ifn_515 = lang.IFn_Cast(root_513) } else { ifn_515 = nil }; var arg_516 any = loc__0; if linked_514 == nil { or__1927000174__auto____3 = ifn_515.Invoke_O__O(arg_516) } else { or__1927000174__auto____3 = linked_514.(*A_arbace_zip_right_A).Invoke_O_O__O(root_513, arg_516) }
//line :237:1
			if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var p__4 any = loc__0; L1: for { var temp__1927000408__auto____5 any; var root_517 any = A_arbace_zip_A_const_44.GetRawRoot__O(); var linked_518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_517, A_arbace_zip_up_A_fn_class); var ifn_519 lang.IFn



				if linked_518 == nil { ifn_519 = lang.IFn_Cast(root_517) } else { ifn_519 = nil }; var arg_520 any = p__4; if linked_518 == nil { temp__1927000408__auto____5 = ifn_519.Invoke_O__O(arg_520) } else { temp__1927000408__auto____5 = linked_518.(*A_arbace_zip_up_A).Invoke_O_O__O(root_517, arg_520) }; if jrt.J2g_Truth(temp__1927000408__auto____5) { var uloc__6 any = temp__1927000408__auto____5; var or__1927000174__auto____7 any; var root_521 any = A_arbace_zip_A_const_51.GetRawRoot__O(); var linked_522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_521, A_arbace_zip_right_A_fn_class); var ifn_523 lang.IFn
					if linked_522 == nil { ifn_523 = lang.IFn_Cast(root_521) } else { ifn_523 = nil }; var arg_524 any = uloc__6; if linked_522 == nil { or__1927000174__auto____7 = ifn_523.Invoke_O__O(arg_524) } else { or__1927000174__auto____7 = linked_522.(*A_arbace_zip_right_A).Invoke_O_O__O(root_521, arg_524) }; if jrt.J2g_Truth(or__1927000174__auto____7) { return or__1927000174__auto____7 } else { p__4 = uloc__6; continue L1 } } else {
//line :241:1
						var tmp2 any; var root_525 any = A_arbace_zip_A_const_27.GetRawRoot__O(); var linked_526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_525, A_arbace_zip_node_A_fn_class); var ifn_527 lang.IFn

						if linked_526 == nil { ifn_527 = lang.IFn_Cast(root_525) } else { ifn_527 = nil }; var arg_528 any = p__4; if linked_526 == nil { tmp2 = ifn_527.Invoke_O__O(arg_528) } else { tmp2 = linked_526.(*A_arbace_zip_node_A).Invoke_O_O__O(root_525, arg_528) }
//line :241:1
						return lang.Tuple_Create_O_O__IPersistentVector(tmp2, A_arbace_zip_A_const_43) } } } } } }
//line :229:1
	panic("j2g: unreachable")
}














func A_arbace_zip_prev_A_New() *A_arbace_zip_prev_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_prev_A{}; t.Ctor(); return t }
//line :245:1
func (t *A_arbace_zip_prev_A) Ctor() {}
//line :245:1
func (t *A_arbace_zip_prev_A) Invoke_O_O__O(self, loc__0 any) any { { var temp__1927000408__auto____2 any; var root_529 any = A_arbace_zip_A_const_52.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_529, A_arbace_zip_left_A_fn_class); var ifn_531 lang.IFn




	if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any = loc__0; if linked_530 == nil { temp__1927000408__auto____2 = ifn_531.Invoke_O__O(arg_532) } else { temp__1927000408__auto____2 = linked_530.(*A_arbace_zip_left_A).Invoke_O_O__O(root_529, arg_532) }; if jrt.J2g_Truth(temp__1927000408__auto____2) { var lloc__3 any = temp__1927000408__auto____2; var loc__4 any = lloc__3; L1: for { var temp__1927000408__auto____5 any; var and__1927000168__auto____5 any; var root_533 any = A_arbace_zip_A_const_28.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_533, A_arbace_zip_branch_QMARK__A_fn_class); var ifn_535 lang.IFn

		if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any = loc__4; if linked_534 == nil { and__1927000168__auto____5 = ifn_535.Invoke_O__O(arg_536) } else { and__1927000168__auto____5 = linked_534.(*A_arbace_zip_branch_QMARK__A).Invoke_O_O__O(root_533, arg_536) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_537 any = A_arbace_zip_A_const_50.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_537, A_arbace_zip_down_A_fn_class); var ifn_539 lang.IFn; if linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any = loc__4; if linked_538 == nil { temp__1927000408__auto____5 = ifn_539.Invoke_O__O(arg_540) } else { temp__1927000408__auto____5 = linked_538.(*A_arbace_zip_down_A).Invoke_O_O__O(root_537, arg_540) } } else { temp__1927000408__auto____5 = and__1927000168__auto____5 }; if jrt.J2g_Truth(temp__1927000408__auto____5) { var child__6 any = temp__1927000408__auto____5; var tmp1 any; var root_545 any = A_arbace_zip_A_const_53.GetRawRoot__O(); var linked_546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_545, A_arbace_zip_rightmost_A_fn_class); var ifn_547 lang.IFn
			if linked_546 == nil { ifn_547 = lang.IFn_Cast(root_545) } else { ifn_547 = nil }; var arg_548 any = child__6; if linked_546 == nil { tmp1 = ifn_547.Invoke_O__O(arg_548) } else { tmp1 = linked_546.(*A_arbace_zip_rightmost_A).Invoke_O_O__O(root_545, arg_548) }; loc__4 = tmp1; continue L1 } else {
//line :252:1
				return loc__4 } } } else {


					var root_541 any = A_arbace_zip_A_const_44.GetRawRoot__O(); var linked_542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_541, A_arbace_zip_up_A_fn_class); var ifn_543 lang.IFn; if linked_542 == nil { ifn_543 = lang.IFn_Cast(root_541) } else { ifn_543 = nil }; var arg_544 any = loc__0; if linked_542 == nil { return ifn_543.Invoke_O__O(arg_544) } else { return linked_542.(*A_arbace_zip_up_A).Invoke_O_O__O(root_541, arg_544) } } }; /*line :245:1*/panic("j2g: unreachable") }











func A_arbace_zip_end_QMARK__A_New() *A_arbace_zip_end_QMARK__A { A_arbace_zip_A_Init(); t := &A_arbace_zip_end_QMARK__A{}; t.Ctor(); return t }
//line :257:1
func (t *A_arbace_zip_end_QMARK__A) Ctor() {}
//line :257:1
func (t *A_arbace_zip_end_QMARK__A) Invoke_O_O__O(self, loc__0 any) any {



	var tmp1 any = A_arbace_zip_A_const_43; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, lang.IFn_Cast(loc__0).Invoke_O__O(A_arbace_zip_A_const_30))).Ref()
}
func A_arbace_zip_remove_A_New() *A_arbace_zip_remove_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_remove_A{}; t.Ctor(); return t }
//line :263:1
func (t *A_arbace_zip_remove_A) Ctor() {}
//line :263:1
func (t *A_arbace_zip_remove_A) Invoke_O_O__O(self, loc__0 any) any { { var vec__703000092__2 any = loc__0; var node__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__703000092__2, lang.RT_IntCast_J__I_NoInit(0), nil); var map__703000095__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__703000092__2, lang.RT_IntCast_J__I_NoInit(1), nil); var map__703000095__5 any; _ = node__3




	if lang.ISeq_InstanceOf(map__703000095__4) { var tmp1 any; var root_549 any = A_arbace_zip_A_const_35.GetRawRoot__O(); var linked_550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_549, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_551 lang.IFn; if linked_550 == nil { ifn_551 = lang.IFn_Cast(root_549) } else { ifn_551 = nil }; var arg_552 any = map__703000095__4; if linked_550 == nil { tmp1 = ifn_551.Invoke_O__O(arg_552) } else { tmp1 = linked_550.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_549, arg_552) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_553 any = A_arbace_zip_A_const_37.GetRawRoot__O(); var linked_554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_553, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_555 lang.IFn; if linked_554 == nil { ifn_555 = lang.IFn_Cast(root_553) } else { ifn_555 = nil }; var arg_556 any = map__703000095__4; if linked_554 == nil { tmp2 = ifn_555.Invoke_O__O(arg_556) } else { tmp2 = linked_554.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_553, arg_556) }; map__703000095__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_557 any = A_arbace_zip_A_const_17.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_557, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_559 lang.IFn; if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any = map__703000095__4; if linked_558 == nil { tmp3 = ifn_559.Invoke_O__O(arg_560) } else { tmp3 = linked_558.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_557, arg_560) }; if jrt.J2g_Truth(tmp3) { var root_561 any = A_arbace_zip_A_const_34.GetRawRoot__O(); var linked_562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_561, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_563 lang.IFn; if linked_562 == nil { ifn_563 = lang.IFn_Cast(root_561) } else { ifn_563 = nil }; var arg_564 any = map__703000095__4; if linked_562 == nil { map__703000095__5 = ifn_563.Invoke_O__O(arg_564) } else { map__703000095__5 = linked_562.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_561, arg_564) } } else { map__703000095__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__703000095__5 = map__703000095__4 }
//line :263:1
	var path__6 any = map__703000095__5; var l__7 any = lang.RT_Get_O_O__O_NoInit(map__703000095__5, A_arbace_zip_A_const_31); var ppath__8 any = lang.RT_Get_O_O__O_NoInit(map__703000095__5, A_arbace_zip_A_const_36); var pnodes__9 any = lang.RT_Get_O_O__O_NoInit(map__703000095__5, A_arbace_zip_A_const_29); var rs__10 any = lang.RT_Get_O_O__O_NoInit(map__703000095__5, A_arbace_zip_A_const_32)





	if lang.Util_Identical_O_O__Z_NoInit(path__6, nil) { panic(jrt.Thrown(jrt.Exception_New_String(Lit_3))) } else {

		if lang.Numbers_IsPos_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(l__7))) { var loc__11 any; var root_581 any = A_arbace_zip_A_const_15.GetRawRoot__O(); var linked_582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_581, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_583 lang.IFn
			if linked_582 == nil { ifn_583 = lang.IFn_Cast(root_581) } else { ifn_583 = nil }; var arg_584 any; var tmp4 any; var root_565 any = A_arbace_zip_A_const_39.GetRawRoot__O(); var linked_566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_565, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_567 lang.IFn; if linked_566 == nil { ifn_567 = lang.IFn_Cast(root_565) } else { ifn_567 = nil }; var arg_568 any = l__7; if linked_566 == nil { tmp4 = ifn_567.Invoke_O__O(arg_568) } else { tmp4 = linked_566.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_565, arg_568) }; var tmp5 any = tmp4; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_zip_A_const_23.GetRawRoot__O()); var tmp7 any = A_arbace_zip_A_const_31; var tmp8 any; var root_569 any = A_arbace_zip_A_const_47.GetRawRoot__O(); var linked_570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_569, aot_arbace_core.A_arbace_core_pop_A_fn_class); var ifn_571 lang.IFn; if linked_570 == nil { ifn_571 = lang.IFn_Cast(root_569) } else { ifn_571 = nil }; var arg_572 any = l__7; if linked_570 == nil { tmp8 = ifn_571.Invoke_O__O(arg_572) } else { tmp8 = linked_570.(*aot_arbace_core.A_arbace_core_pop_A).Invoke_O_O__O(root_569, arg_572) }; arg_584 = lang.Tuple_Create_O_O__IPersistentVector(tmp5, tmp6.Invoke_O_O_O_O_O__O(path__6, tmp7, tmp8, A_arbace_zip_A_const_38, jrt.Boolean_TRUE.Ref())); var arg_585 any = lang.RT_Meta_O__IPersistentMap_NoInit(loc__0); if linked_582 == nil { loc__11 = ifn_583.Invoke_O_O__O(arg_584, arg_585) } else { loc__11 = linked_582.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_581, arg_584, arg_585) }
//line :271:1
		L1: for { var temp__1927000408__auto____12 any; var and__1927000168__auto____12 any; var root_586 any = A_arbace_zip_A_const_28.GetRawRoot__O(); var linked_587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_586, A_arbace_zip_branch_QMARK__A_fn_class); var ifn_588 lang.IFn

			if linked_587 == nil { ifn_588 = lang.IFn_Cast(root_586) } else { ifn_588 = nil }; var arg_589 any = loc__11; if linked_587 == nil { and__1927000168__auto____12 = ifn_588.Invoke_O__O(arg_589) } else { and__1927000168__auto____12 = linked_587.(*A_arbace_zip_branch_QMARK__A).Invoke_O_O__O(root_586, arg_589) }; if jrt.J2g_Truth(and__1927000168__auto____12) { var root_590 any = A_arbace_zip_A_const_50.GetRawRoot__O(); var linked_591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_590, A_arbace_zip_down_A_fn_class); var ifn_592 lang.IFn; if linked_591 == nil { ifn_592 = lang.IFn_Cast(root_590) } else { ifn_592 = nil }; var arg_593 any = loc__11; if linked_591 == nil { temp__1927000408__auto____12 = ifn_592.Invoke_O__O(arg_593) } else { temp__1927000408__auto____12 = linked_591.(*A_arbace_zip_down_A).Invoke_O_O__O(root_590, arg_593) } } else { temp__1927000408__auto____12 = and__1927000168__auto____12 }; if jrt.J2g_Truth(temp__1927000408__auto____12) { var child__13 any = temp__1927000408__auto____12; var tmp9 any; var root_615 any = A_arbace_zip_A_const_53.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_615, A_arbace_zip_rightmost_A_fn_class); var ifn_617 lang.IFn
				if linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any = child__13; if linked_616 == nil { tmp9 = ifn_617.Invoke_O__O(arg_618) } else { tmp9 = linked_616.(*A_arbace_zip_rightmost_A).Invoke_O_O__O(root_615, arg_618) }; loc__11 = tmp9; continue L1 } else {
//line :273:1
					return loc__11 } } } else {


						var root_610 any = A_arbace_zip_A_const_15.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_612 lang.IFn; if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any; var tmp10 any; var root_598 any = A_arbace_zip_A_const_40.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, A_arbace_zip_make_node_A_fn_class); var ifn_600 lang.IFn; if linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any = loc__0; var arg_602 any; var root_594 any = A_arbace_zip_A_const_39.GetRawRoot__O(); var linked_595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_594, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_596 lang.IFn; if linked_595 == nil { ifn_596 = lang.IFn_Cast(root_594) } else { ifn_596 = nil }; var arg_597 any = pnodes__9; if linked_595 == nil { arg_602 = ifn_596.Invoke_O__O(arg_597) } else { arg_602 = linked_595.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_594, arg_597) }; var arg_603 any = rs__10; if linked_599 == nil { tmp10 = ifn_600.Invoke_O_O_O__O(arg_601, arg_602, arg_603) } else { tmp10 = linked_599.(*A_arbace_zip_make_node_A).Invoke_O_O_O_O__O(root_598, arg_601, arg_602, arg_603) }; var tmp11 any = tmp10; var tmp12 any; var and__1927000168__auto____11 any = ppath__8
						if jrt.J2g_Truth(and__1927000168__auto____11) { var root_604 any = A_arbace_zip_A_const_23.GetRawRoot__O(); var linked_605 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_604, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_606 lang.IFn; if linked_605 == nil { ifn_606 = lang.IFn_Cast(root_604) } else { ifn_606 = nil }; var arg_607 any = ppath__8; var arg_608 any = A_arbace_zip_A_const_38; var arg_609 any = jrt.Boolean_TRUE.Ref(); if linked_605 == nil { tmp12 = ifn_606.Invoke_O_O_O__O(arg_607, arg_608, arg_609) } else { tmp12 = linked_605.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_604, arg_607, arg_608, arg_609) } } else { tmp12 = and__1927000168__auto____11 }
//line :276:1
						arg_613 = lang.Tuple_Create_O_O__IPersistentVector(tmp11, tmp12); var arg_614 any = lang.RT_Meta_O__IPersistentMap_NoInit(loc__0); if linked_611 == nil { return ifn_612.Invoke_O_O__O(arg_613, arg_614) } else { return linked_611.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_610, arg_613, arg_614) } } } }; /*line :263:1*/panic("j2g: unreachable") }







type A_arbace_zip_A struct{ jrt.Object }

var A_arbace_zip_A_const_pool *jrt.RefArray

var A_arbace_zip_A_const_0 *lang.Var

var A_arbace_zip_A_const_1 any

var A_arbace_zip_A_const_2 *lang.Keyword

var A_arbace_zip_A_const_3 any

var A_arbace_zip_A_const_4 *lang.Var

var A_arbace_zip_A_const_5 *lang.Var

var A_arbace_zip_A_const_6 *lang.Var

var A_arbace_zip_A_const_7 *lang.Var

var A_arbace_zip_A_const_8 any

var A_arbace_zip_A_const_9 *lang.Keyword

var A_arbace_zip_A_const_10 *lang.Keyword

var A_arbace_zip_A_const_11 *lang.Keyword

var A_arbace_zip_A_const_12 *lang.Var

var A_arbace_zip_A_const_13 *lang.Var

var A_arbace_zip_A_const_14 *lang.Var

var A_arbace_zip_A_const_15 *lang.Var

var A_arbace_zip_A_const_16 *lang.Var

var A_arbace_zip_A_const_17 *lang.Var

var A_arbace_zip_A_const_18 *lang.Var

var A_arbace_zip_A_const_19 *lang.Var

var A_arbace_zip_A_const_20 *lang.Var

var A_arbace_zip_A_const_21 *lang.Var

var A_arbace_zip_A_const_22 *lang.Keyword

var A_arbace_zip_A_const_23 *lang.Var

var A_arbace_zip_A_const_24 *lang.Var

var A_arbace_zip_A_const_25 *lang.Var

var A_arbace_zip_A_const_26 any

var A_arbace_zip_A_const_27 *lang.Var

var A_arbace_zip_A_const_28 *lang.Var

var A_arbace_zip_A_const_29 *lang.Keyword

var A_arbace_zip_A_const_30 any

var A_arbace_zip_A_const_31 *lang.Keyword

var A_arbace_zip_A_const_32 *lang.Keyword

var A_arbace_zip_A_const_33 *lang.Var

var A_arbace_zip_A_const_34 *lang.Var

var A_arbace_zip_A_const_35 *lang.Var

var A_arbace_zip_A_const_36 *lang.Keyword

var A_arbace_zip_A_const_37 *lang.Var

var A_arbace_zip_A_const_38 *lang.Keyword

var A_arbace_zip_A_const_39 *lang.Var

var A_arbace_zip_A_const_40 *lang.Var

var A_arbace_zip_A_const_41 *lang.Var

var A_arbace_zip_A_const_42 *lang.Var

var A_arbace_zip_A_const_43 *lang.Keyword

var A_arbace_zip_A_const_44 *lang.Var

var A_arbace_zip_A_const_45 *lang.Var

var A_arbace_zip_A_const_46 *lang.Var

var A_arbace_zip_A_const_47 *lang.Var

var A_arbace_zip_A_const_48 *lang.Var

var A_arbace_zip_A_const_49 *lang.Var

var A_arbace_zip_A_const_50 *lang.Var

var A_arbace_zip_A_const_51 *lang.Var

var A_arbace_zip_A_const_52 *lang.Var

var A_arbace_zip_A_const_53 *lang.Var

var A_arbace_zip_A_init jrt.ClassInit

func A_arbace_zip_A_Init() { if !A_arbace_zip_A_init.Done() { A_arbace_zip_A_init.Run(A_arbace_zip_A_clinit) } }

func A_arbace_zip_A_clinit() { A_arbace_zip_A_clinit_p0(); A_arbace_zip_A_clinit_p1(); A_arbace_zip_A_clinit_p2(); A_arbace_zip_A_clinit_p3(); A_arbace_zip_A_clinit_p4() }

func A_arbace_zip_A_clinit_p0() { jrt.StartCheck(); A_arbace_zip_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 73); A_arbace_zip_A_const_0 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[19]); A_arbace_zip_A_const_1 = A_arbace_zip_A_const_pool.A[20]; A_arbace_zip_A_const_2 = lang.Keyword_Cast(A_arbace_zip_A_const_pool.A[21]); A_arbace_zip_A_const_3 = A_arbace_zip_A_const_pool.A[22]; A_arbace_zip_A_const_4 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[23]); A_arbace_zip_A_const_5 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[24]); A_arbace_zip_A_const_6 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[25]); A_arbace_zip_A_const_7 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[26]); A_arbace_zip_A_const_8 = A_arbace_zip_A_const_pool.A[27]; A_arbace_zip_A_const_9 = lang.Keyword_Cast(A_arbace_zip_A_const_pool.A[28]); A_arbace_zip_A_const_10 = lang.Keyword_Cast(A_arbace_zip_A_const_pool.A[29]); A_arbace_zip_A_const_11 = lang.Keyword_Cast(A_arbace_zip_A_const_pool.A[30]) }

func A_arbace_zip_A_clinit_p1() { A_arbace_zip_A_const_12 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[31]); A_arbace_zip_A_const_13 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[32]); A_arbace_zip_A_const_14 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[33]); A_arbace_zip_A_const_15 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[34]); A_arbace_zip_A_const_16 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[35]); A_arbace_zip_A_const_17 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[36]); A_arbace_zip_A_const_18 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[37]); A_arbace_zip_A_const_19 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[38]); A_arbace_zip_A_const_20 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[39]); A_arbace_zip_A_const_21 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[40]); A_arbace_zip_A_const_22 = lang.Keyword_Cast(A_arbace_zip_A_const_pool.A[41]); A_arbace_zip_A_const_23 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[42]) }

func A_arbace_zip_A_clinit_p2() { A_arbace_zip_A_const_24 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[43]); A_arbace_zip_A_const_25 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[44]); A_arbace_zip_A_const_26 = A_arbace_zip_A_const_pool.A[45]; A_arbace_zip_A_const_27 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[46]); A_arbace_zip_A_const_28 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[47]); A_arbace_zip_A_const_29 = lang.Keyword_Cast(A_arbace_zip_A_const_pool.A[48]); A_arbace_zip_A_const_30 = A_arbace_zip_A_const_pool.A[49]; A_arbace_zip_A_const_31 = lang.Keyword_Cast(A_arbace_zip_A_const_pool.A[50]); A_arbace_zip_A_const_32 = lang.Keyword_Cast(A_arbace_zip_A_const_pool.A[51]); A_arbace_zip_A_const_33 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[52]); A_arbace_zip_A_const_34 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[53]); A_arbace_zip_A_const_35 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[54]) }

func A_arbace_zip_A_clinit_p3() { A_arbace_zip_A_const_36 = lang.Keyword_Cast(A_arbace_zip_A_const_pool.A[55]); A_arbace_zip_A_const_37 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[56]); A_arbace_zip_A_const_38 = lang.Keyword_Cast(A_arbace_zip_A_const_pool.A[57]); A_arbace_zip_A_const_39 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[58]); A_arbace_zip_A_const_40 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[59]); A_arbace_zip_A_const_41 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[60]); A_arbace_zip_A_const_42 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[61]); A_arbace_zip_A_const_43 = lang.Keyword_Cast(A_arbace_zip_A_const_pool.A[62]); A_arbace_zip_A_const_44 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[63]); A_arbace_zip_A_const_45 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[64]); A_arbace_zip_A_const_46 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[65]); A_arbace_zip_A_const_47 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[66]) }

func A_arbace_zip_A_clinit_p4() { A_arbace_zip_A_const_48 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[67]); A_arbace_zip_A_const_49 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[68]); A_arbace_zip_A_const_50 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[69]); A_arbace_zip_A_const_51 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[70]); A_arbace_zip_A_const_52 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[71]); A_arbace_zip_A_const_53 = lang.Var_Cast(A_arbace_zip_A_const_pool.A[72]) }

func A_arbace_zip_A_New() *A_arbace_zip_A { A_arbace_zip_A_Init(); t := &A_arbace_zip_A{}; t.Ctor(); return t }

func (t *A_arbace_zip_A) Ctor() {}

func (t *A_arbace_zip_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_A) GetClass__Class() *jrt.Class { return A_arbace_zip_A_class }

func (t *A_arbace_zip_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_zip_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_A); return ok }

func A_arbace_zip_A_Cast(x any) *A_arbace_zip_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_A_class)) }; return v }



type A_arbace_zip_append_child_A struct{ j2g_header uint64 }

var A_arbace_zip_append_child_A_fn_class *jrt.Class



type A_arbace_zip_branch_QMARK__A struct{ j2g_header uint64 }

var A_arbace_zip_branch_QMARK__A_fn_class *jrt.Class



type A_arbace_zip_children_A struct{ j2g_header uint64 }

var A_arbace_zip_children_A_fn_class *jrt.Class



type A_arbace_zip_down_A struct{ j2g_header uint64 }

var A_arbace_zip_down_A_fn_class *jrt.Class



type A_arbace_zip_edit_A struct{ j2g_header uint64 }

var A_arbace_zip_edit_A_fn_class *jrt.Class



type A_arbace_zip_end_QMARK__A struct{ j2g_header uint64 }

var A_arbace_zip_end_QMARK__A_fn_class *jrt.Class



type A_arbace_zip_eval703000004_A struct{ jrt.Object }

func A_arbace_zip_eval703000004_A_New() *A_arbace_zip_eval703000004_A { t := &A_arbace_zip_eval703000004_A{}; t.Ctor(); return t }

func (t *A_arbace_zip_eval703000004_A) Ctor() {}

func (t *A_arbace_zip_eval703000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_eval703000004_A) GetClass__Class() *jrt.Class { return A_arbace_zip_eval703000004_A_class }

func (t *A_arbace_zip_eval703000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_eval703000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_zip_eval703000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_eval703000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_eval703000004_A); return ok }

func A_arbace_zip_eval703000004_A_Cast(x any) *A_arbace_zip_eval703000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_eval703000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_eval703000004_A_class)) }; return v }



type A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A struct{ j2g_header uint64 }

var A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_fn_class *jrt.Class



type A_arbace_zip_eval703000008_A struct{ jrt.Object }

func A_arbace_zip_eval703000008_A_New() *A_arbace_zip_eval703000008_A { t := &A_arbace_zip_eval703000008_A{}; t.Ctor(); return t }

func (t *A_arbace_zip_eval703000008_A) Ctor() {}

func (t *A_arbace_zip_eval703000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_zip_eval703000008_A) GetClass__Class() *jrt.Class { return A_arbace_zip_eval703000008_A_class }

func (t *A_arbace_zip_eval703000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_zip_eval703000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_zip_eval703000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_zip_eval703000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_zip_eval703000008_A); return ok }

func A_arbace_zip_eval703000008_A_Cast(x any) *A_arbace_zip_eval703000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_zip_eval703000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_zip_eval703000008_A_class)) }; return v }



type A_arbace_zip_eval703000008_fn__703000009_A struct{ j2g_header uint64 }

var A_arbace_zip_eval703000008_fn__703000009_A_fn_class *jrt.Class



type A_arbace_zip_insert_child_A struct{ j2g_header uint64 }

var A_arbace_zip_insert_child_A_fn_class *jrt.Class



type A_arbace_zip_insert_left_A struct{ j2g_header uint64 }

var A_arbace_zip_insert_left_A_fn_class *jrt.Class



type A_arbace_zip_insert_right_A struct{ j2g_header uint64 }

var A_arbace_zip_insert_right_A_fn_class *jrt.Class



type A_arbace_zip_left_A struct{ j2g_header uint64 }

var A_arbace_zip_left_A_fn_class *jrt.Class



type A_arbace_zip_leftmost_A struct{ j2g_header uint64 }

var A_arbace_zip_leftmost_A_fn_class *jrt.Class



type A_arbace_zip_lefts_A struct{ j2g_header uint64 }

var A_arbace_zip_lefts_A_fn_class *jrt.Class



type A_arbace_zip_make_node_A struct{ j2g_header uint64 }

var A_arbace_zip_make_node_A_fn_class *jrt.Class



type A_arbace_zip_next_A struct{ j2g_header uint64 }

var A_arbace_zip_next_A_fn_class *jrt.Class



type A_arbace_zip_node_A struct{ j2g_header uint64 }

var A_arbace_zip_node_A_fn_class *jrt.Class



type A_arbace_zip_path_A struct{ j2g_header uint64 }

var A_arbace_zip_path_A_fn_class *jrt.Class



type A_arbace_zip_prev_A struct{ j2g_header uint64 }

var A_arbace_zip_prev_A_fn_class *jrt.Class



type A_arbace_zip_remove_A struct{ j2g_header uint64 }

var A_arbace_zip_remove_A_fn_class *jrt.Class



type A_arbace_zip_replace_A struct{ j2g_header uint64 }

var A_arbace_zip_replace_A_fn_class *jrt.Class



type A_arbace_zip_right_A struct{ j2g_header uint64 }

var A_arbace_zip_right_A_fn_class *jrt.Class



type A_arbace_zip_rightmost_A struct{ j2g_header uint64 }

var A_arbace_zip_rightmost_A_fn_class *jrt.Class



type A_arbace_zip_rights_A struct{ j2g_header uint64 }

var A_arbace_zip_rights_A_fn_class *jrt.Class



type A_arbace_zip_root_A struct{ j2g_header uint64 }

var A_arbace_zip_root_A_fn_class *jrt.Class



type A_arbace_zip_seq_zip_A struct{ j2g_header uint64 }

var A_arbace_zip_seq_zip_A_fn_class *jrt.Class



type A_arbace_zip_seq_zip_fn__703000013_A struct{ j2g_header uint64 }

var A_arbace_zip_seq_zip_fn__703000013_A_fn_class *jrt.Class



type A_arbace_zip_up_A struct{ j2g_header uint64 }

var A_arbace_zip_up_A_fn_class *jrt.Class



type A_arbace_zip_vector_zip_A struct{ j2g_header uint64 }

var A_arbace_zip_vector_zip_A_fn_class *jrt.Class



type A_arbace_zip_vector_zip_fn__703000016_A struct{ j2g_header uint64 }

var A_arbace_zip_vector_zip_fn__703000016_A_fn_class *jrt.Class



type A_arbace_zip_xml_zip_A struct{ j2g_header uint64 }

var A_arbace_zip_xml_zip_A_fn_class *jrt.Class



type A_arbace_zip_xml_zip_fn__703000019_A struct{ j2g_header uint64 }

var A_arbace_zip_xml_zip_fn__703000019_A_fn_class *jrt.Class



type A_arbace_zip_zipper_A struct{ j2g_header uint64 }

var A_arbace_zip_zipper_A_fn_class *jrt.Class
