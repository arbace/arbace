//line a2g_classes.ae:1
package aot_arbace_zip

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_zip_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_A_New()}; return nil }

var A_arbace_zip_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_zip_A_new}

var A_arbace_zip_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_zip.A_arbace_zip_A"})

func init() { i := A_arbace_zip_A_class.Info(); i.IsInstance = A_arbace_zip_A_InstanceOf; i.Init = A_arbace_zip_A_Init; i.Table = A_arbace_zip_A_members; jrt.RegisterGoType(A_arbace_zip_A_class, reflect.TypeFor[A_arbace_zip_A]()) }

func A_arbace_zip_append_child_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_zip_append_child_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_zip_append_child_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_append_child_A_New()}; return nil }

func A_arbace_zip_append_child_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_zip_append_child_A_fn_class)}; return nil }

var A_arbace_zip_append_child_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_zip_append_child_A_invoke, New: A_arbace_zip_append_child_A_new, Get: A_arbace_zip_append_child_A_get}

var A_arbace_zip_append_child_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$append_child", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_zip_A_class, Simple: "append_child", Go: "arbace/aot_arbace_zip.A_arbace_zip_append_child_A", Source: "zip.ae"})

func init() { i := A_arbace_zip_append_child_A_class.Info(); i.IsInstance = A_arbace_zip_append_child_A_InstanceOf; i.Init = A_arbace_zip_append_child_A_Init; i.Table = A_arbace_zip_append_child_A_members; jrt.RegisterGoType(A_arbace_zip_append_child_A_class, reflect.TypeFor[A_arbace_zip_append_child_A]()) }

func A_arbace_zip_branch_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_zip_branch_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_zip_branch_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_branch_QMARK__A_New()}; return nil }

func A_arbace_zip_branch_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_zip_branch_QMARK__A_fn_class)}; return nil }

var A_arbace_zip_branch_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_zip_branch_QMARK__A_invoke, New: A_arbace_zip_branch_QMARK__A_new, Get: A_arbace_zip_branch_QMARK__A_get}

var A_arbace_zip_branch_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$branch_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_zip_A_class, Simple: "branch_QMARK_", Go: "arbace/aot_arbace_zip.A_arbace_zip_branch_QMARK__A", Source: "zip.ae"})

func init() { i := A_arbace_zip_branch_QMARK__A_class.Info(); i.IsInstance = A_arbace_zip_branch_QMARK__A_InstanceOf; i.Init = A_arbace_zip_branch_QMARK__A_Init; i.Table = A_arbace_zip_branch_QMARK__A_members; jrt.RegisterGoType(A_arbace_zip_branch_QMARK__A_class, reflect.TypeFor[A_arbace_zip_branch_QMARK__A]()) }

func A_arbace_zip_children_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_zip_children_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_zip_children_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_children_A_New()}; return nil }

func A_arbace_zip_children_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_zip_children_A_fn_class)}; return nil }

var A_arbace_zip_children_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_zip_children_A_invoke, New: A_arbace_zip_children_A_new, Get: A_arbace_zip_children_A_get}

var A_arbace_zip_children_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$children", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_zip_A_class, Simple: "children", Go: "arbace/aot_arbace_zip.A_arbace_zip_children_A", Source: "zip.ae"})

func init() { i := A_arbace_zip_children_A_class.Info(); i.IsInstance = A_arbace_zip_children_A_InstanceOf; i.Init = A_arbace_zip_children_A_Init; i.Table = A_arbace_zip_children_A_members; jrt.RegisterGoType(A_arbace_zip_children_A_class, reflect.TypeFor[A_arbace_zip_children_A]()) }

func A_arbace_zip_down_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_zip_down_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_zip_down_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_down_A_New()}; return nil }

func A_arbace_zip_down_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_zip_down_A_fn_class)}; return nil }

var A_arbace_zip_down_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_zip_down_A_invoke, New: A_arbace_zip_down_A_new, Get: A_arbace_zip_down_A_get}

var A_arbace_zip_down_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$down", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_zip_A_class, Simple: "down", Go: "arbace/aot_arbace_zip.A_arbace_zip_down_A", Source: "zip.ae"})

func init() { i := A_arbace_zip_down_A_class.Info(); i.IsInstance = A_arbace_zip_down_A_InstanceOf; i.Init = A_arbace_zip_down_A_Init; i.Table = A_arbace_zip_down_A_members; jrt.RegisterGoType(A_arbace_zip_down_A_class, reflect.TypeFor[A_arbace_zip_down_A]()) }

func A_arbace_zip_edit_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_zip_edit_A).DoInvoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_zip_edit_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_edit_A_New()}; return nil }

func A_arbace_zip_edit_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_zip_edit_A_fn_class)}; return nil }

var A_arbace_zip_edit_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_zip_edit_A_invoke, New: A_arbace_zip_edit_A_new, Get: A_arbace_zip_edit_A_get}

var A_arbace_zip_edit_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$edit", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR2_class}, Declaring: A_arbace_zip_A_class, Simple: "edit", Go: "arbace/aot_arbace_zip.A_arbace_zip_edit_A", Source: "zip.ae"})

func init() { i := A_arbace_zip_edit_A_class.Info(); i.IsInstance = A_arbace_zip_edit_A_InstanceOf; i.Init = A_arbace_zip_edit_A_Init; i.Table = A_arbace_zip_edit_A_members; jrt.RegisterGoType(A_arbace_zip_edit_A_class, reflect.TypeFor[A_arbace_zip_edit_A]()) }

func A_arbace_zip_end_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_zip_end_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_zip_end_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_end_QMARK__A_New()}; return nil }

func A_arbace_zip_end_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_zip_end_QMARK__A_fn_class)}; return nil }

var A_arbace_zip_end_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_zip_end_QMARK__A_invoke, New: A_arbace_zip_end_QMARK__A_new, Get: A_arbace_zip_end_QMARK__A_get}

var A_arbace_zip_end_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$end_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_zip_A_class, Simple: "end_QMARK_", Go: "arbace/aot_arbace_zip.A_arbace_zip_end_QMARK__A", Source: "zip.ae"})

func init() { i := A_arbace_zip_end_QMARK__A_class.Info(); i.IsInstance = A_arbace_zip_end_QMARK__A_InstanceOf; i.Init = A_arbace_zip_end_QMARK__A_Init; i.Table = A_arbace_zip_end_QMARK__A_members; jrt.RegisterGoType(A_arbace_zip_end_QMARK__A_class, reflect.TypeFor[A_arbace_zip_end_QMARK__A]()) }

func A_arbace_zip_eval703000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_eval703000004_A_New()}; return nil }

var A_arbace_zip_eval703000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_zip_eval703000004_A_new}

var A_arbace_zip_eval703000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$eval703000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_zip_A_class, Simple: "eval703000004", Go: "arbace/aot_arbace_zip.A_arbace_zip_eval703000004_A"})

func init() { i := A_arbace_zip_eval703000004_A_class.Info(); i.IsInstance = A_arbace_zip_eval703000004_A_InstanceOf; i.Table = A_arbace_zip_eval703000004_A_members; jrt.RegisterGoType(A_arbace_zip_eval703000004_A_class, reflect.TypeFor[A_arbace_zip_eval703000004_A]()) }

func A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_New()}; return nil }

func A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_fn_class)}; return nil }

var A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_invoke, New: A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_new, Get: A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_get}

var A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$eval703000004$loading__1927001464__auto____703000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_zip_eval703000004_A_class, Simple: "loading__1927001464__auto____703000005", Go: "arbace/aot_arbace_zip.A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A", Source: "zip.ae"})

func init() { i := A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_class.Info(); i.IsInstance = A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_InstanceOf; i.Init = A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_Init; i.Table = A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_members; jrt.RegisterGoType(A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_class, reflect.TypeFor[A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A]()) }

func A_arbace_zip_eval703000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_eval703000008_A_New()}; return nil }

var A_arbace_zip_eval703000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_zip_eval703000008_A_new}

var A_arbace_zip_eval703000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$eval703000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_zip_A_class, Simple: "eval703000008", Go: "arbace/aot_arbace_zip.A_arbace_zip_eval703000008_A"})

func init() { i := A_arbace_zip_eval703000008_A_class.Info(); i.IsInstance = A_arbace_zip_eval703000008_A_InstanceOf; i.Table = A_arbace_zip_eval703000008_A_members; jrt.RegisterGoType(A_arbace_zip_eval703000008_A_class, reflect.TypeFor[A_arbace_zip_eval703000008_A]()) }

func A_arbace_zip_eval703000008_fn__703000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_zip_eval703000008_fn__703000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_zip_eval703000008_fn__703000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_eval703000008_fn__703000009_A_New()}; return nil }

func A_arbace_zip_eval703000008_fn__703000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_zip_eval703000008_fn__703000009_A_fn_class)}; return nil }

var A_arbace_zip_eval703000008_fn__703000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_zip_eval703000008_fn__703000009_A_invoke, New: A_arbace_zip_eval703000008_fn__703000009_A_new, Get: A_arbace_zip_eval703000008_fn__703000009_A_get}

var A_arbace_zip_eval703000008_fn__703000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$eval703000008$fn__703000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_zip_eval703000008_A_class, Simple: "fn__703000009", Go: "arbace/aot_arbace_zip.A_arbace_zip_eval703000008_fn__703000009_A", Source: "zip.ae"})

func init() { i := A_arbace_zip_eval703000008_fn__703000009_A_class.Info(); i.IsInstance = A_arbace_zip_eval703000008_fn__703000009_A_InstanceOf; i.Init = A_arbace_zip_eval703000008_fn__703000009_A_Init; i.Table = A_arbace_zip_eval703000008_fn__703000009_A_members; jrt.RegisterGoType(A_arbace_zip_eval703000008_fn__703000009_A_class, reflect.TypeFor[A_arbace_zip_eval703000008_fn__703000009_A]()) }

func A_arbace_zip_insert_child_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_zip_insert_child_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_zip_insert_child_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_insert_child_A_New()}; return nil }

func A_arbace_zip_insert_child_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_zip_insert_child_A_fn_class)}; return nil }

var A_arbace_zip_insert_child_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_zip_insert_child_A_invoke, New: A_arbace_zip_insert_child_A_new, Get: A_arbace_zip_insert_child_A_get}

var A_arbace_zip_insert_child_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$insert_child", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_zip_A_class, Simple: "insert_child", Go: "arbace/aot_arbace_zip.A_arbace_zip_insert_child_A", Source: "zip.ae"})

func init() { i := A_arbace_zip_insert_child_A_class.Info(); i.IsInstance = A_arbace_zip_insert_child_A_InstanceOf; i.Init = A_arbace_zip_insert_child_A_Init; i.Table = A_arbace_zip_insert_child_A_members; jrt.RegisterGoType(A_arbace_zip_insert_child_A_class, reflect.TypeFor[A_arbace_zip_insert_child_A]()) }

func A_arbace_zip_insert_left_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_zip_insert_left_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_zip_insert_left_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_insert_left_A_New()}; return nil }

func A_arbace_zip_insert_left_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_zip_insert_left_A_fn_class)}; return nil }

var A_arbace_zip_insert_left_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_zip_insert_left_A_invoke, New: A_arbace_zip_insert_left_A_new, Get: A_arbace_zip_insert_left_A_get}

var A_arbace_zip_insert_left_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$insert_left", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_zip_A_class, Simple: "insert_left", Go: "arbace/aot_arbace_zip.A_arbace_zip_insert_left_A", Source: "zip.ae"})

func init() { i := A_arbace_zip_insert_left_A_class.Info(); i.IsInstance = A_arbace_zip_insert_left_A_InstanceOf; i.Init = A_arbace_zip_insert_left_A_Init; i.Table = A_arbace_zip_insert_left_A_members; jrt.RegisterGoType(A_arbace_zip_insert_left_A_class, reflect.TypeFor[A_arbace_zip_insert_left_A]()) }

func A_arbace_zip_insert_right_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_zip_insert_right_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_zip_insert_right_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_insert_right_A_New()}; return nil }

func A_arbace_zip_insert_right_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_zip_insert_right_A_fn_class)}; return nil }

var A_arbace_zip_insert_right_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_zip_insert_right_A_invoke, New: A_arbace_zip_insert_right_A_new, Get: A_arbace_zip_insert_right_A_get}

var A_arbace_zip_insert_right_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$insert_right", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_zip_A_class, Simple: "insert_right", Go: "arbace/aot_arbace_zip.A_arbace_zip_insert_right_A", Source: "zip.ae"})

func init() { i := A_arbace_zip_insert_right_A_class.Info(); i.IsInstance = A_arbace_zip_insert_right_A_InstanceOf; i.Init = A_arbace_zip_insert_right_A_Init; i.Table = A_arbace_zip_insert_right_A_members; jrt.RegisterGoType(A_arbace_zip_insert_right_A_class, reflect.TypeFor[A_arbace_zip_insert_right_A]()) }

func A_arbace_zip_left_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_zip_left_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_zip_left_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_left_A_New()}; return nil }

func A_arbace_zip_left_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_zip_left_A_fn_class)}; return nil }

var A_arbace_zip_left_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_zip_left_A_invoke, New: A_arbace_zip_left_A_new, Get: A_arbace_zip_left_A_get}

var A_arbace_zip_left_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$left", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_zip_A_class, Simple: "left", Go: "arbace/aot_arbace_zip.A_arbace_zip_left_A", Source: "zip.ae"})

func init() { i := A_arbace_zip_left_A_class.Info(); i.IsInstance = A_arbace_zip_left_A_InstanceOf; i.Init = A_arbace_zip_left_A_Init; i.Table = A_arbace_zip_left_A_members; jrt.RegisterGoType(A_arbace_zip_left_A_class, reflect.TypeFor[A_arbace_zip_left_A]()) }

func A_arbace_zip_leftmost_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_zip_leftmost_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_zip_leftmost_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_leftmost_A_New()}; return nil }

func A_arbace_zip_leftmost_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_zip_leftmost_A_fn_class)}; return nil }

var A_arbace_zip_leftmost_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_zip_leftmost_A_invoke, New: A_arbace_zip_leftmost_A_new, Get: A_arbace_zip_leftmost_A_get}

var A_arbace_zip_leftmost_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$leftmost", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_zip_A_class, Simple: "leftmost", Go: "arbace/aot_arbace_zip.A_arbace_zip_leftmost_A", Source: "zip.ae"})

func init() { i := A_arbace_zip_leftmost_A_class.Info(); i.IsInstance = A_arbace_zip_leftmost_A_InstanceOf; i.Init = A_arbace_zip_leftmost_A_Init; i.Table = A_arbace_zip_leftmost_A_members; jrt.RegisterGoType(A_arbace_zip_leftmost_A_class, reflect.TypeFor[A_arbace_zip_leftmost_A]()) }

func A_arbace_zip_lefts_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_zip_lefts_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_zip_lefts_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_lefts_A_New()}; return nil }

func A_arbace_zip_lefts_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_zip_lefts_A_fn_class)}; return nil }

var A_arbace_zip_lefts_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_zip_lefts_A_invoke, New: A_arbace_zip_lefts_A_new, Get: A_arbace_zip_lefts_A_get}

var A_arbace_zip_lefts_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$lefts", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_zip_A_class, Simple: "lefts", Go: "arbace/aot_arbace_zip.A_arbace_zip_lefts_A", Source: "zip.ae"})

func init() { i := A_arbace_zip_lefts_A_class.Info(); i.IsInstance = A_arbace_zip_lefts_A_InstanceOf; i.Init = A_arbace_zip_lefts_A_Init; i.Table = A_arbace_zip_lefts_A_members; jrt.RegisterGoType(A_arbace_zip_lefts_A_class, reflect.TypeFor[A_arbace_zip_lefts_A]()) }

func A_arbace_zip_make_node_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_zip_make_node_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_zip_make_node_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_make_node_A_New()}; return nil }

func A_arbace_zip_make_node_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_zip_make_node_A_fn_class)}; return nil }

var A_arbace_zip_make_node_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_zip_make_node_A_invoke, New: A_arbace_zip_make_node_A_new, Get: A_arbace_zip_make_node_A_get}

var A_arbace_zip_make_node_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$make_node", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_zip_A_class, Simple: "make_node", Go: "arbace/aot_arbace_zip.A_arbace_zip_make_node_A", Source: "zip.ae"})

func init() { i := A_arbace_zip_make_node_A_class.Info(); i.IsInstance = A_arbace_zip_make_node_A_InstanceOf; i.Init = A_arbace_zip_make_node_A_Init; i.Table = A_arbace_zip_make_node_A_members; jrt.RegisterGoType(A_arbace_zip_make_node_A_class, reflect.TypeFor[A_arbace_zip_make_node_A]()) }

func A_arbace_zip_next_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_zip_next_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_zip_next_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_next_A_New()}; return nil }

func A_arbace_zip_next_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_zip_next_A_fn_class)}; return nil }

var A_arbace_zip_next_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_zip_next_A_invoke, New: A_arbace_zip_next_A_new, Get: A_arbace_zip_next_A_get}

var A_arbace_zip_next_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$next", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_zip_A_class, Simple: "next", Go: "arbace/aot_arbace_zip.A_arbace_zip_next_A", Source: "zip.ae"})

func init() { i := A_arbace_zip_next_A_class.Info(); i.IsInstance = A_arbace_zip_next_A_InstanceOf; i.Init = A_arbace_zip_next_A_Init; i.Table = A_arbace_zip_next_A_members; jrt.RegisterGoType(A_arbace_zip_next_A_class, reflect.TypeFor[A_arbace_zip_next_A]()) }

func A_arbace_zip_node_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_zip_node_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_zip_node_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_node_A_New()}; return nil }

func A_arbace_zip_node_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_zip_node_A_fn_class)}; return nil }

var A_arbace_zip_node_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_zip_node_A_invoke, New: A_arbace_zip_node_A_new, Get: A_arbace_zip_node_A_get}

var A_arbace_zip_node_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$node", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_zip_A_class, Simple: "node", Go: "arbace/aot_arbace_zip.A_arbace_zip_node_A", Source: "zip.ae"})

func init() { i := A_arbace_zip_node_A_class.Info(); i.IsInstance = A_arbace_zip_node_A_InstanceOf; i.Init = A_arbace_zip_node_A_Init; i.Table = A_arbace_zip_node_A_members; jrt.RegisterGoType(A_arbace_zip_node_A_class, reflect.TypeFor[A_arbace_zip_node_A]()) }

func A_arbace_zip_path_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_zip_path_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_zip_path_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_path_A_New()}; return nil }

func A_arbace_zip_path_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_zip_path_A_fn_class)}; return nil }

var A_arbace_zip_path_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_zip_path_A_invoke, New: A_arbace_zip_path_A_new, Get: A_arbace_zip_path_A_get}

var A_arbace_zip_path_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$path", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_zip_A_class, Simple: "path", Go: "arbace/aot_arbace_zip.A_arbace_zip_path_A", Source: "zip.ae"})

func init() { i := A_arbace_zip_path_A_class.Info(); i.IsInstance = A_arbace_zip_path_A_InstanceOf; i.Init = A_arbace_zip_path_A_Init; i.Table = A_arbace_zip_path_A_members; jrt.RegisterGoType(A_arbace_zip_path_A_class, reflect.TypeFor[A_arbace_zip_path_A]()) }

func A_arbace_zip_prev_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_zip_prev_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_zip_prev_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_prev_A_New()}; return nil }

func A_arbace_zip_prev_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_zip_prev_A_fn_class)}; return nil }

var A_arbace_zip_prev_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_zip_prev_A_invoke, New: A_arbace_zip_prev_A_new, Get: A_arbace_zip_prev_A_get}

var A_arbace_zip_prev_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$prev", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_zip_A_class, Simple: "prev", Go: "arbace/aot_arbace_zip.A_arbace_zip_prev_A", Source: "zip.ae"})

func init() { i := A_arbace_zip_prev_A_class.Info(); i.IsInstance = A_arbace_zip_prev_A_InstanceOf; i.Init = A_arbace_zip_prev_A_Init; i.Table = A_arbace_zip_prev_A_members; jrt.RegisterGoType(A_arbace_zip_prev_A_class, reflect.TypeFor[A_arbace_zip_prev_A]()) }

func A_arbace_zip_remove_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_zip_remove_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_zip_remove_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_remove_A_New()}; return nil }

func A_arbace_zip_remove_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_zip_remove_A_fn_class)}; return nil }

var A_arbace_zip_remove_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_zip_remove_A_invoke, New: A_arbace_zip_remove_A_new, Get: A_arbace_zip_remove_A_get}

var A_arbace_zip_remove_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$remove", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_zip_A_class, Simple: "remove", Go: "arbace/aot_arbace_zip.A_arbace_zip_remove_A", Source: "zip.ae"})

func init() { i := A_arbace_zip_remove_A_class.Info(); i.IsInstance = A_arbace_zip_remove_A_InstanceOf; i.Init = A_arbace_zip_remove_A_Init; i.Table = A_arbace_zip_remove_A_members; jrt.RegisterGoType(A_arbace_zip_remove_A_class, reflect.TypeFor[A_arbace_zip_remove_A]()) }

func A_arbace_zip_replace_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_zip_replace_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_zip_replace_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_replace_A_New()}; return nil }

func A_arbace_zip_replace_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_zip_replace_A_fn_class)}; return nil }

var A_arbace_zip_replace_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_zip_replace_A_invoke, New: A_arbace_zip_replace_A_new, Get: A_arbace_zip_replace_A_get}

var A_arbace_zip_replace_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$replace", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_zip_A_class, Simple: "replace", Go: "arbace/aot_arbace_zip.A_arbace_zip_replace_A", Source: "zip.ae"})

func init() { i := A_arbace_zip_replace_A_class.Info(); i.IsInstance = A_arbace_zip_replace_A_InstanceOf; i.Init = A_arbace_zip_replace_A_Init; i.Table = A_arbace_zip_replace_A_members; jrt.RegisterGoType(A_arbace_zip_replace_A_class, reflect.TypeFor[A_arbace_zip_replace_A]()) }

func A_arbace_zip_right_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_zip_right_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_zip_right_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_right_A_New()}; return nil }

func A_arbace_zip_right_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_zip_right_A_fn_class)}; return nil }

var A_arbace_zip_right_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_zip_right_A_invoke, New: A_arbace_zip_right_A_new, Get: A_arbace_zip_right_A_get}

var A_arbace_zip_right_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$right", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_zip_A_class, Simple: "right", Go: "arbace/aot_arbace_zip.A_arbace_zip_right_A", Source: "zip.ae"})

func init() { i := A_arbace_zip_right_A_class.Info(); i.IsInstance = A_arbace_zip_right_A_InstanceOf; i.Init = A_arbace_zip_right_A_Init; i.Table = A_arbace_zip_right_A_members; jrt.RegisterGoType(A_arbace_zip_right_A_class, reflect.TypeFor[A_arbace_zip_right_A]()) }

func A_arbace_zip_rightmost_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_zip_rightmost_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_zip_rightmost_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_rightmost_A_New()}; return nil }

func A_arbace_zip_rightmost_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_zip_rightmost_A_fn_class)}; return nil }

var A_arbace_zip_rightmost_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_zip_rightmost_A_invoke, New: A_arbace_zip_rightmost_A_new, Get: A_arbace_zip_rightmost_A_get}

var A_arbace_zip_rightmost_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$rightmost", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_zip_A_class, Simple: "rightmost", Go: "arbace/aot_arbace_zip.A_arbace_zip_rightmost_A", Source: "zip.ae"})

func init() { i := A_arbace_zip_rightmost_A_class.Info(); i.IsInstance = A_arbace_zip_rightmost_A_InstanceOf; i.Init = A_arbace_zip_rightmost_A_Init; i.Table = A_arbace_zip_rightmost_A_members; jrt.RegisterGoType(A_arbace_zip_rightmost_A_class, reflect.TypeFor[A_arbace_zip_rightmost_A]()) }

func A_arbace_zip_rights_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_zip_rights_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_zip_rights_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_rights_A_New()}; return nil }

func A_arbace_zip_rights_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_zip_rights_A_fn_class)}; return nil }

var A_arbace_zip_rights_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_zip_rights_A_invoke, New: A_arbace_zip_rights_A_new, Get: A_arbace_zip_rights_A_get}

var A_arbace_zip_rights_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$rights", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_zip_A_class, Simple: "rights", Go: "arbace/aot_arbace_zip.A_arbace_zip_rights_A", Source: "zip.ae"})

func init() { i := A_arbace_zip_rights_A_class.Info(); i.IsInstance = A_arbace_zip_rights_A_InstanceOf; i.Init = A_arbace_zip_rights_A_Init; i.Table = A_arbace_zip_rights_A_members; jrt.RegisterGoType(A_arbace_zip_rights_A_class, reflect.TypeFor[A_arbace_zip_rights_A]()) }

func A_arbace_zip_root_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_zip_root_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_zip_root_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_root_A_New()}; return nil }

func A_arbace_zip_root_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_zip_root_A_fn_class)}; return nil }

var A_arbace_zip_root_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_zip_root_A_invoke, New: A_arbace_zip_root_A_new, Get: A_arbace_zip_root_A_get}

var A_arbace_zip_root_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$root", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_zip_A_class, Simple: "root", Go: "arbace/aot_arbace_zip.A_arbace_zip_root_A", Source: "zip.ae"})

func init() { i := A_arbace_zip_root_A_class.Info(); i.IsInstance = A_arbace_zip_root_A_InstanceOf; i.Init = A_arbace_zip_root_A_Init; i.Table = A_arbace_zip_root_A_members; jrt.RegisterGoType(A_arbace_zip_root_A_class, reflect.TypeFor[A_arbace_zip_root_A]()) }

func A_arbace_zip_seq_zip_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_zip_seq_zip_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_zip_seq_zip_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_seq_zip_A_New()}; return nil }

func A_arbace_zip_seq_zip_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_zip_seq_zip_A_fn_class)}; return nil }

var A_arbace_zip_seq_zip_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_zip_seq_zip_A_invoke, New: A_arbace_zip_seq_zip_A_new, Get: A_arbace_zip_seq_zip_A_get}

var A_arbace_zip_seq_zip_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$seq_zip", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_zip_A_class, Simple: "seq_zip", Go: "arbace/aot_arbace_zip.A_arbace_zip_seq_zip_A", Source: "zip.ae"})

func init() { i := A_arbace_zip_seq_zip_A_class.Info(); i.IsInstance = A_arbace_zip_seq_zip_A_InstanceOf; i.Init = A_arbace_zip_seq_zip_A_Init; i.Table = A_arbace_zip_seq_zip_A_members; jrt.RegisterGoType(A_arbace_zip_seq_zip_A_class, reflect.TypeFor[A_arbace_zip_seq_zip_A]()) }

func A_arbace_zip_seq_zip_fn__703000013_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_zip_seq_zip_fn__703000013_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_zip_seq_zip_fn__703000013_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_seq_zip_fn__703000013_A_New()}; return nil }

func A_arbace_zip_seq_zip_fn__703000013_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_zip_seq_zip_fn__703000013_A_fn_class)}; return nil }

var A_arbace_zip_seq_zip_fn__703000013_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_zip_seq_zip_fn__703000013_A_invoke, New: A_arbace_zip_seq_zip_fn__703000013_A_new, Get: A_arbace_zip_seq_zip_fn__703000013_A_get}

var A_arbace_zip_seq_zip_fn__703000013_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$seq_zip$fn__703000013", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_zip_seq_zip_A_class, Simple: "fn__703000013", Go: "arbace/aot_arbace_zip.A_arbace_zip_seq_zip_fn__703000013_A", Source: "zip.ae"})

func init() { i := A_arbace_zip_seq_zip_fn__703000013_A_class.Info(); i.IsInstance = A_arbace_zip_seq_zip_fn__703000013_A_InstanceOf; i.Init = A_arbace_zip_seq_zip_fn__703000013_A_Init; i.Table = A_arbace_zip_seq_zip_fn__703000013_A_members; jrt.RegisterGoType(A_arbace_zip_seq_zip_fn__703000013_A_class, reflect.TypeFor[A_arbace_zip_seq_zip_fn__703000013_A]()) }

func A_arbace_zip_up_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_zip_up_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_zip_up_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_up_A_New()}; return nil }

func A_arbace_zip_up_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_zip_up_A_fn_class)}; return nil }

var A_arbace_zip_up_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_zip_up_A_invoke, New: A_arbace_zip_up_A_new, Get: A_arbace_zip_up_A_get}

var A_arbace_zip_up_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$up", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_zip_A_class, Simple: "up", Go: "arbace/aot_arbace_zip.A_arbace_zip_up_A", Source: "zip.ae"})

func init() { i := A_arbace_zip_up_A_class.Info(); i.IsInstance = A_arbace_zip_up_A_InstanceOf; i.Init = A_arbace_zip_up_A_Init; i.Table = A_arbace_zip_up_A_members; jrt.RegisterGoType(A_arbace_zip_up_A_class, reflect.TypeFor[A_arbace_zip_up_A]()) }

func A_arbace_zip_vector_zip_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_zip_vector_zip_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_zip_vector_zip_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_vector_zip_A_New()}; return nil }

func A_arbace_zip_vector_zip_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_zip_vector_zip_A_fn_class)}; return nil }

var A_arbace_zip_vector_zip_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_zip_vector_zip_A_invoke, New: A_arbace_zip_vector_zip_A_new, Get: A_arbace_zip_vector_zip_A_get}

var A_arbace_zip_vector_zip_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$vector_zip", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_zip_A_class, Simple: "vector_zip", Go: "arbace/aot_arbace_zip.A_arbace_zip_vector_zip_A", Source: "zip.ae"})

func init() { i := A_arbace_zip_vector_zip_A_class.Info(); i.IsInstance = A_arbace_zip_vector_zip_A_InstanceOf; i.Init = A_arbace_zip_vector_zip_A_Init; i.Table = A_arbace_zip_vector_zip_A_members; jrt.RegisterGoType(A_arbace_zip_vector_zip_A_class, reflect.TypeFor[A_arbace_zip_vector_zip_A]()) }

func A_arbace_zip_vector_zip_fn__703000016_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_zip_vector_zip_fn__703000016_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_zip_vector_zip_fn__703000016_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_vector_zip_fn__703000016_A_New()}; return nil }

func A_arbace_zip_vector_zip_fn__703000016_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_zip_vector_zip_fn__703000016_A_fn_class)}; return nil }

var A_arbace_zip_vector_zip_fn__703000016_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_zip_vector_zip_fn__703000016_A_invoke, New: A_arbace_zip_vector_zip_fn__703000016_A_new, Get: A_arbace_zip_vector_zip_fn__703000016_A_get}

var A_arbace_zip_vector_zip_fn__703000016_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$vector_zip$fn__703000016", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_zip_vector_zip_A_class, Simple: "fn__703000016", Go: "arbace/aot_arbace_zip.A_arbace_zip_vector_zip_fn__703000016_A", Source: "zip.ae"})

func init() { i := A_arbace_zip_vector_zip_fn__703000016_A_class.Info(); i.IsInstance = A_arbace_zip_vector_zip_fn__703000016_A_InstanceOf; i.Init = A_arbace_zip_vector_zip_fn__703000016_A_Init; i.Table = A_arbace_zip_vector_zip_fn__703000016_A_members; jrt.RegisterGoType(A_arbace_zip_vector_zip_fn__703000016_A_class, reflect.TypeFor[A_arbace_zip_vector_zip_fn__703000016_A]()) }

func A_arbace_zip_xml_zip_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_zip_xml_zip_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_zip_xml_zip_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_xml_zip_A_New()}; return nil }

func A_arbace_zip_xml_zip_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_zip_xml_zip_A_fn_class)}; return nil }

var A_arbace_zip_xml_zip_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_zip_xml_zip_A_invoke, New: A_arbace_zip_xml_zip_A_new, Get: A_arbace_zip_xml_zip_A_get}

var A_arbace_zip_xml_zip_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$xml_zip", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_zip_A_class, Simple: "xml_zip", Go: "arbace/aot_arbace_zip.A_arbace_zip_xml_zip_A", Source: "zip.ae"})

func init() { i := A_arbace_zip_xml_zip_A_class.Info(); i.IsInstance = A_arbace_zip_xml_zip_A_InstanceOf; i.Init = A_arbace_zip_xml_zip_A_Init; i.Table = A_arbace_zip_xml_zip_A_members; jrt.RegisterGoType(A_arbace_zip_xml_zip_A_class, reflect.TypeFor[A_arbace_zip_xml_zip_A]()) }

func A_arbace_zip_xml_zip_fn__703000019_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_zip_xml_zip_fn__703000019_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_zip_xml_zip_fn__703000019_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_xml_zip_fn__703000019_A_New()}; return nil }

func A_arbace_zip_xml_zip_fn__703000019_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_zip_xml_zip_fn__703000019_A_fn_class)}; return nil }

var A_arbace_zip_xml_zip_fn__703000019_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_zip_xml_zip_fn__703000019_A_invoke, New: A_arbace_zip_xml_zip_fn__703000019_A_new, Get: A_arbace_zip_xml_zip_fn__703000019_A_get}

var A_arbace_zip_xml_zip_fn__703000019_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$xml_zip$fn__703000019", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_zip_xml_zip_A_class, Simple: "fn__703000019", Go: "arbace/aot_arbace_zip.A_arbace_zip_xml_zip_fn__703000019_A", Source: "zip.ae"})

func init() { i := A_arbace_zip_xml_zip_fn__703000019_A_class.Info(); i.IsInstance = A_arbace_zip_xml_zip_fn__703000019_A_InstanceOf; i.Init = A_arbace_zip_xml_zip_fn__703000019_A_Init; i.Table = A_arbace_zip_xml_zip_fn__703000019_A_members; jrt.RegisterGoType(A_arbace_zip_xml_zip_fn__703000019_A_class, reflect.TypeFor[A_arbace_zip_xml_zip_fn__703000019_A]()) }

func A_arbace_zip_zipper_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_zip_zipper_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_zip_zipper_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_zipper_A_New()}; return nil }

func A_arbace_zip_zipper_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_zip_zipper_A_fn_class)}; return nil }

var A_arbace_zip_zipper_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_zip_zipper_A_invoke, New: A_arbace_zip_zipper_A_new, Get: A_arbace_zip_zipper_A_get}

var A_arbace_zip_zipper_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$zipper", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_zip_A_class, Simple: "zipper", Go: "arbace/aot_arbace_zip.A_arbace_zip_zipper_A", Source: "zip.ae"})

func init() { i := A_arbace_zip_zipper_A_class.Info(); i.IsInstance = A_arbace_zip_zipper_A_InstanceOf; i.Init = A_arbace_zip_zipper_A_Init; i.Table = A_arbace_zip_zipper_A_members; jrt.RegisterGoType(A_arbace_zip_zipper_A_class, reflect.TypeFor[A_arbace_zip_zipper_A]()) }

func A_arbace_zip__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_zip__init_A_Load__O(); case 1: return A_arbace_zip__init_A_Unit0__O(); case 2: return A_arbace_zip__init_A_Unit1__O(); case 3: return A_arbace_zip__init_A_Unit10__O(); case 4: return A_arbace_zip__init_A_Unit11__O(); case 5: return A_arbace_zip__init_A_Unit12__O(); case 6: return A_arbace_zip__init_A_Unit13__O(); case 7: return A_arbace_zip__init_A_Unit14__O(); case 8: return A_arbace_zip__init_A_Unit15__O(); case 9: return A_arbace_zip__init_A_Unit16__O(); case 10: return A_arbace_zip__init_A_Unit17__O(); case 11: return A_arbace_zip__init_A_Unit18__O(); case 12: return A_arbace_zip__init_A_Unit19__O(); case 13: return A_arbace_zip__init_A_Unit2__O(); case 14: return A_arbace_zip__init_A_Unit20__O(); case 15: return A_arbace_zip__init_A_Unit21__O(); case 16: return A_arbace_zip__init_A_Unit22__O(); case 17: return A_arbace_zip__init_A_Unit23__O(); case 18: return A_arbace_zip__init_A_Unit24__O(); case 19: return A_arbace_zip__init_A_Unit25__O(); case 20: return A_arbace_zip__init_A_Unit26__O(); case 21: return A_arbace_zip__init_A_Unit27__O(); case 22: return A_arbace_zip__init_A_Unit28__O(); case 23: return A_arbace_zip__init_A_Unit29__O(); case 24: return A_arbace_zip__init_A_Unit3__O(); case 25: return A_arbace_zip__init_A_Unit30__O(); case 26: return A_arbace_zip__init_A_Unit31__O(); case 27: return A_arbace_zip__init_A_Unit32__O(); case 28: return A_arbace_zip__init_A_Unit4__O(); case 29: return A_arbace_zip__init_A_Unit5__O(); case 30: return A_arbace_zip__init_A_Unit6__O(); case 31: return A_arbace_zip__init_A_Unit7__O(); case 32: return A_arbace_zip__init_A_Unit8__O(); case 33: return A_arbace_zip__init_A_Unit9__O()}; return nil }

func A_arbace_zip__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip__init_A_New()}; return nil }

var A_arbace_zip__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit28 ()Ljava.lang.Object;\nM9 unit29 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit30 ()Ljava.lang.Object;\nM9 unit31 ()Ljava.lang.Object;\nM9 unit32 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_zip__init_A_invoke, New: A_arbace_zip__init_A_new}

var A_arbace_zip__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_zip.A_arbace_zip__init_A", Source: "zip.ae"})

func init() { i := A_arbace_zip__init_A_class.Info(); i.IsInstance = A_arbace_zip__init_A_InstanceOf; i.Init = A_arbace_zip__init_A_Init; i.Table = A_arbace_zip__init_A_members; jrt.RegisterGoType(A_arbace_zip__init_A_class, reflect.TypeFor[A_arbace_zip__init_A]()) }
