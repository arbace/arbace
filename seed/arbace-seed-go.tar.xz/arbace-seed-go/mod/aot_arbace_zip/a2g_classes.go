//line a2g_classes.ae:1
package aot_arbace_zip

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var a2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_zip_append_child_A_class, Name: "arbace.zip$append_child", Modifiers: 25, Simple: "append_child", Go: "arbace/aot_arbace_zip.A_arbace_zip_append_child_A", Source: "zip.ae", Declaring: &A_arbace_zip_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_zip_branch_QMARK__A_class, Name: "arbace.zip$branch_QMARK_", Modifiers: 25, Simple: "branch_QMARK_", Go: "arbace/aot_arbace_zip.A_arbace_zip_branch_QMARK__A", Source: "zip.ae", Declaring: &A_arbace_zip_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_zip_children_A_class, Name: "arbace.zip$children", Modifiers: 25, Simple: "children", Go: "arbace/aot_arbace_zip.A_arbace_zip_children_A", Source: "zip.ae", Declaring: &A_arbace_zip_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_zip_down_A_class, Name: "arbace.zip$down", Modifiers: 25, Simple: "down", Go: "arbace/aot_arbace_zip.A_arbace_zip_down_A", Source: "zip.ae", Declaring: &A_arbace_zip_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_zip_edit_A_class, Name: "arbace.zip$edit", Modifiers: 25, Simple: "edit", Go: "arbace/aot_arbace_zip.A_arbace_zip_edit_A", Source: "zip.ae", Declaring: &A_arbace_zip_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}, jrt.CodeDecl{Out: &A_arbace_zip_end_QMARK__A_class, Name: "arbace.zip$end_QMARK_", Modifiers: 25, Simple: "end_QMARK_", Go: "arbace/aot_arbace_zip.A_arbace_zip_end_QMARK__A", Source: "zip.ae", Declaring: &A_arbace_zip_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_class, Name: "arbace.zip$eval703000004$loading__1927001464__auto____703000005", Modifiers: 25, Simple: "loading__1927001464__auto____703000005", Go: "arbace/aot_arbace_zip.A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A", Source: "zip.ae", Declaring: &A_arbace_zip_eval703000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_zip_eval703000008_fn__703000009_A_class, Name: "arbace.zip$eval703000008$fn__703000009", Modifiers: 25, Simple: "fn__703000009", Go: "arbace/aot_arbace_zip.A_arbace_zip_eval703000008_fn__703000009_A", Source: "zip.ae", Declaring: &A_arbace_zip_eval703000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_zip_insert_child_A_class, Name: "arbace.zip$insert_child", Modifiers: 25, Simple: "insert_child", Go: "arbace/aot_arbace_zip.A_arbace_zip_insert_child_A", Source: "zip.ae", Declaring: &A_arbace_zip_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_zip_insert_left_A_class, Name: "arbace.zip$insert_left", Modifiers: 25, Simple: "insert_left", Go: "arbace/aot_arbace_zip.A_arbace_zip_insert_left_A", Source: "zip.ae", Declaring: &A_arbace_zip_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_zip_insert_right_A_class, Name: "arbace.zip$insert_right", Modifiers: 25, Simple: "insert_right", Go: "arbace/aot_arbace_zip.A_arbace_zip_insert_right_A", Source: "zip.ae", Declaring: &A_arbace_zip_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_zip_left_A_class, Name: "arbace.zip$left", Modifiers: 25, Simple: "left", Go: "arbace/aot_arbace_zip.A_arbace_zip_left_A", Source: "zip.ae", Declaring: &A_arbace_zip_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_zip_leftmost_A_class, Name: "arbace.zip$leftmost", Modifiers: 25, Simple: "leftmost", Go: "arbace/aot_arbace_zip.A_arbace_zip_leftmost_A", Source: "zip.ae", Declaring: &A_arbace_zip_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_zip_lefts_A_class, Name: "arbace.zip$lefts", Modifiers: 25, Simple: "lefts", Go: "arbace/aot_arbace_zip.A_arbace_zip_lefts_A", Source: "zip.ae", Declaring: &A_arbace_zip_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_zip_make_node_A_class, Name: "arbace.zip$make_node", Modifiers: 25, Simple: "make_node", Go: "arbace/aot_arbace_zip.A_arbace_zip_make_node_A", Source: "zip.ae", Declaring: &A_arbace_zip_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_zip_next_A_class, Name: "arbace.zip$next", Modifiers: 25, Simple: "next", Go: "arbace/aot_arbace_zip.A_arbace_zip_next_A", Source: "zip.ae", Declaring: &A_arbace_zip_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_zip_node_A_class, Name: "arbace.zip$node", Modifiers: 25, Simple: "node", Go: "arbace/aot_arbace_zip.A_arbace_zip_node_A", Source: "zip.ae", Declaring: &A_arbace_zip_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_zip_path_A_class, Name: "arbace.zip$path", Modifiers: 25, Simple: "path", Go: "arbace/aot_arbace_zip.A_arbace_zip_path_A", Source: "zip.ae", Declaring: &A_arbace_zip_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_zip_prev_A_class, Name: "arbace.zip$prev", Modifiers: 25, Simple: "prev", Go: "arbace/aot_arbace_zip.A_arbace_zip_prev_A", Source: "zip.ae", Declaring: &A_arbace_zip_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_zip_remove_A_class, Name: "arbace.zip$remove", Modifiers: 25, Simple: "remove", Go: "arbace/aot_arbace_zip.A_arbace_zip_remove_A", Source: "zip.ae", Declaring: &A_arbace_zip_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_zip_replace_A_class, Name: "arbace.zip$replace", Modifiers: 25, Simple: "replace", Go: "arbace/aot_arbace_zip.A_arbace_zip_replace_A", Source: "zip.ae", Declaring: &A_arbace_zip_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_zip_right_A_class, Name: "arbace.zip$right", Modifiers: 25, Simple: "right", Go: "arbace/aot_arbace_zip.A_arbace_zip_right_A", Source: "zip.ae", Declaring: &A_arbace_zip_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_zip_rightmost_A_class, Name: "arbace.zip$rightmost", Modifiers: 25, Simple: "rightmost", Go: "arbace/aot_arbace_zip.A_arbace_zip_rightmost_A", Source: "zip.ae", Declaring: &A_arbace_zip_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_zip_rights_A_class, Name: "arbace.zip$rights", Modifiers: 25, Simple: "rights", Go: "arbace/aot_arbace_zip.A_arbace_zip_rights_A", Source: "zip.ae", Declaring: &A_arbace_zip_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_zip_root_A_class, Name: "arbace.zip$root", Modifiers: 25, Simple: "root", Go: "arbace/aot_arbace_zip.A_arbace_zip_root_A", Source: "zip.ae", Declaring: &A_arbace_zip_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_zip_seq_zip_A_class, Name: "arbace.zip$seq_zip", Modifiers: 25, Simple: "seq_zip", Go: "arbace/aot_arbace_zip.A_arbace_zip_seq_zip_A", Source: "zip.ae", Declaring: &A_arbace_zip_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_zip_seq_zip_fn__703000013_A_class, Name: "arbace.zip$seq_zip$fn__703000013", Modifiers: 25, Simple: "fn__703000013", Go: "arbace/aot_arbace_zip.A_arbace_zip_seq_zip_fn__703000013_A", Source: "zip.ae", Declaring: &A_arbace_zip_seq_zip_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_zip_up_A_class, Name: "arbace.zip$up", Modifiers: 25, Simple: "up", Go: "arbace/aot_arbace_zip.A_arbace_zip_up_A", Source: "zip.ae", Declaring: &A_arbace_zip_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_zip_vector_zip_A_class, Name: "arbace.zip$vector_zip", Modifiers: 25, Simple: "vector_zip", Go: "arbace/aot_arbace_zip.A_arbace_zip_vector_zip_A", Source: "zip.ae", Declaring: &A_arbace_zip_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_zip_vector_zip_fn__703000016_A_class, Name: "arbace.zip$vector_zip$fn__703000016", Modifiers: 25, Simple: "fn__703000016", Go: "arbace/aot_arbace_zip.A_arbace_zip_vector_zip_fn__703000016_A", Source: "zip.ae", Declaring: &A_arbace_zip_vector_zip_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_zip_xml_zip_A_class, Name: "arbace.zip$xml_zip", Modifiers: 25, Simple: "xml_zip", Go: "arbace/aot_arbace_zip.A_arbace_zip_xml_zip_A", Source: "zip.ae", Declaring: &A_arbace_zip_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_zip_xml_zip_fn__703000019_A_class, Name: "arbace.zip$xml_zip$fn__703000019", Modifiers: 25, Simple: "fn__703000019", Go: "arbace/aot_arbace_zip.A_arbace_zip_xml_zip_fn__703000019_A", Source: "zip.ae", Declaring: &A_arbace_zip_xml_zip_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_zip_zipper_A_class, Name: "arbace.zip$zipper", Modifiers: 25, Simple: "zipper", Go: "arbace/aot_arbace_zip.A_arbace_zip_zipper_A", Source: "zip.ae", Declaring: &A_arbace_zip_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}}

var a2gCodeDefined bool = jrt.DefineCode(a2gCode)

func init() { jrt.LinkCode(a2gCode) }

func A_arbace_zip_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_A_New()}; return nil }

var A_arbace_zip_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_zip_A_new}

var A_arbace_zip_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_zip.A_arbace_zip_A"})

func init() { i := A_arbace_zip_A_class.Info(); i.IsInstance = A_arbace_zip_A_InstanceOf; i.Init = A_arbace_zip_A_Init; i.Table = A_arbace_zip_A_members }

var A_arbace_zip_append_child_A_class *jrt.Class

var A_arbace_zip_branch_QMARK__A_class *jrt.Class

var A_arbace_zip_children_A_class *jrt.Class

var A_arbace_zip_down_A_class *jrt.Class

var A_arbace_zip_edit_A_class *jrt.Class

var A_arbace_zip_end_QMARK__A_class *jrt.Class

func A_arbace_zip_eval703000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_eval703000004_A_New()}; return nil }

var A_arbace_zip_eval703000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_zip_eval703000004_A_new}

var A_arbace_zip_eval703000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$eval703000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_zip_A_class, Simple: "eval703000004", Go: "arbace/aot_arbace_zip.A_arbace_zip_eval703000004_A"})

func init() { i := A_arbace_zip_eval703000004_A_class.Info(); i.IsInstance = A_arbace_zip_eval703000004_A_InstanceOf; i.Table = A_arbace_zip_eval703000004_A_members }

var A_arbace_zip_eval703000004_loading__1927001464__auto____703000005_A_class *jrt.Class

func A_arbace_zip_eval703000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip_eval703000008_A_New()}; return nil }

var A_arbace_zip_eval703000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_zip_eval703000008_A_new}

var A_arbace_zip_eval703000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip$eval703000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_zip_A_class, Simple: "eval703000008", Go: "arbace/aot_arbace_zip.A_arbace_zip_eval703000008_A"})

func init() { i := A_arbace_zip_eval703000008_A_class.Info(); i.IsInstance = A_arbace_zip_eval703000008_A_InstanceOf; i.Table = A_arbace_zip_eval703000008_A_members }

var A_arbace_zip_eval703000008_fn__703000009_A_class *jrt.Class

var A_arbace_zip_insert_child_A_class *jrt.Class

var A_arbace_zip_insert_left_A_class *jrt.Class

var A_arbace_zip_insert_right_A_class *jrt.Class

var A_arbace_zip_left_A_class *jrt.Class

var A_arbace_zip_leftmost_A_class *jrt.Class

var A_arbace_zip_lefts_A_class *jrt.Class

var A_arbace_zip_make_node_A_class *jrt.Class

var A_arbace_zip_next_A_class *jrt.Class

var A_arbace_zip_node_A_class *jrt.Class

var A_arbace_zip_path_A_class *jrt.Class

var A_arbace_zip_prev_A_class *jrt.Class

var A_arbace_zip_remove_A_class *jrt.Class

var A_arbace_zip_replace_A_class *jrt.Class

var A_arbace_zip_right_A_class *jrt.Class

var A_arbace_zip_rightmost_A_class *jrt.Class

var A_arbace_zip_rights_A_class *jrt.Class

var A_arbace_zip_root_A_class *jrt.Class

var A_arbace_zip_seq_zip_A_class *jrt.Class

var A_arbace_zip_seq_zip_fn__703000013_A_class *jrt.Class

var A_arbace_zip_up_A_class *jrt.Class

var A_arbace_zip_vector_zip_A_class *jrt.Class

var A_arbace_zip_vector_zip_fn__703000016_A_class *jrt.Class

var A_arbace_zip_xml_zip_A_class *jrt.Class

var A_arbace_zip_xml_zip_fn__703000019_A_class *jrt.Class

var A_arbace_zip_zipper_A_class *jrt.Class

func A_arbace_zip__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_zip__init_A_Load__O()}; return nil }

func A_arbace_zip__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_zip__init_A_New()}; return nil }

var A_arbace_zip__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_zip__init_A_invoke, New: A_arbace_zip__init_A_new}

var A_arbace_zip__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.zip__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_zip.A_arbace_zip__init_A", Source: "zip.ae"})

func init() { i := A_arbace_zip__init_A_class.Info(); i.IsInstance = A_arbace_zip__init_A_InstanceOf; i.Init = A_arbace_zip__init_A_Init; i.Table = A_arbace_zip__init_A_members }
