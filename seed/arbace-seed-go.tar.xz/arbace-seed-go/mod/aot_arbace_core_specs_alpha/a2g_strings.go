//line a2g_strings.ae:1
package aot_arbace_core_specs_alpha

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.spec.alpha")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("s")

var Lit_6 *jrt.String = jrt.Intern("commute")

var Lit_7 *jrt.String = jrt.Intern("deref")

var Lit_8 *jrt.String = jrt.Intern("conj")

var Lit_9 *jrt.String = jrt.Intern("arbace.core.specs.alpha")

var Lit_10 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_11 *jrt.String = jrt.Intern("not=")

var Lit_12 *jrt.String = jrt.Intern("&")

var Lit_13 *jrt.String = jrt.Intern("map?")

var Lit_14 *jrt.String = jrt.Intern("name")

var Lit_15 *jrt.String = jrt.Intern("even?")

var Lit_16 *jrt.String = jrt.Intern("coll?")

var Lit_17 *jrt.String = jrt.Intern("map-spec-impl")

var Lit_18 *jrt.String = jrt.Intern("with-gen")

var Lit_19 *jrt.String = jrt.Intern("req-un")

var Lit_20 *jrt.String = jrt.Intern("opt-un")

var Lit_21 *jrt.String = jrt.Intern("exclude")

var Lit_22 *jrt.String = jrt.Intern("only")

var Lit_23 *jrt.String = jrt.Intern("rename")

var Lit_24 *jrt.String = jrt.Intern("gfn")

var Lit_25 *jrt.String = jrt.Intern("pred-exprs")

var Lit_26 *jrt.String = jrt.Intern("keys-pred")

var Lit_27 *jrt.String = jrt.Intern("opt-keys")

var Lit_28 *jrt.String = jrt.Intern("req-specs")

var Lit_29 *jrt.String = jrt.Intern("req")

var Lit_30 *jrt.String = jrt.Intern("req-keys")

var Lit_31 *jrt.String = jrt.Intern("opt-specs")

var Lit_32 *jrt.String = jrt.Intern("pred-forms")

var Lit_33 *jrt.String = jrt.Intern("fn")

var Lit_34 *jrt.String = jrt.Intern("%")

var Lit_35 *jrt.String = jrt.Intern("opt")

var Lit_36 *jrt.String = jrt.Intern("amp-impl")

var Lit_37 *jrt.String = jrt.Intern("arbace.spec.gen.alpha")

var Lit_38 *jrt.String = jrt.Intern("fmap")

var Lit_39 *jrt.String = jrt.Intern("apply")

var Lit_40 *jrt.String = jrt.Intern("concat")

var Lit_41 *jrt.String = jrt.Intern("gen")

var Lit_42 *jrt.String = jrt.Intern("rep-impl")

var Lit_43 *jrt.String = jrt.Intern("*")

var Lit_44 *jrt.String = jrt.Intern("cat")

var Lit_45 *jrt.String = jrt.Intern("k")

var Lit_46 *jrt.String = jrt.Intern("keyword?")

var Lit_47 *jrt.String = jrt.Intern("v")

var Lit_48 *jrt.String = jrt.Intern("any?")

var Lit_49 *jrt.String = jrt.Intern("kvs->map")

var Lit_50 *jrt.String = jrt.Intern("mspec__1740000878__auto__")

var Lit_51 *jrt.String = jrt.Intern("cat-impl")

var Lit_52 *jrt.String = jrt.Intern("as-alias")

var Lit_53 *jrt.String = jrt.Intern("vector?")

var Lit_54 *jrt.String = jrt.Intern("extends")

var Lit_55 *jrt.String = jrt.Intern("implements")

var Lit_56 *jrt.String = jrt.Intern("init")

var Lit_57 *jrt.String = jrt.Intern("constructors")

var Lit_58 *jrt.String = jrt.Intern("post-init")

var Lit_59 *jrt.String = jrt.Intern("methods")

var Lit_60 *jrt.String = jrt.Intern("main")

var Lit_61 *jrt.String = jrt.Intern("factory")

var Lit_62 *jrt.String = jrt.Intern("state")

var Lit_63 *jrt.String = jrt.Intern("exposes")

var Lit_64 *jrt.String = jrt.Intern("prefix")

var Lit_65 *jrt.String = jrt.Intern("impl-ns")

var Lit_66 *jrt.String = jrt.Intern("load-impl-ns")

var Lit_67 *jrt.String = jrt.Intern("seq")

var Lit_68 *jrt.String = jrt.Intern("list")

var Lit_69 *jrt.String = jrt.Intern("or")

var Lit_70 *jrt.String = jrt.Intern("spec")

var Lit_71 *jrt.String = jrt.Intern("quoted-spec")

var Lit_72 *jrt.String = jrt.Intern("quote")

var Lit_73 *jrt.String = jrt.Intern("hash-set")

var Lit_74 *jrt.String = jrt.Intern("arbace.core.specs.alpha$eval1919000002$loading__1927001464__auto____1919000003")

var Lit_75 *jrt.String = jrt.Intern("arbace.core.specs.alpha$eval1919000006$fn__1919000007")

var Lit_76 *jrt.String = jrt.Intern("arbace.core.specs.alpha$even_number_of_forms_QMARK_")

var Lit_77 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000011")

var Lit_78 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000014")

var Lit_79 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000016")

var Lit_80 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000019")

var Lit_81 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000022")

var Lit_82 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000026")

var Lit_83 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000029")

var Lit_84 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000032")

var Lit_85 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000034")

var Lit_86 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000036")

var Lit_87 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000036$fn__1919000038")

var Lit_88 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000036$fn__1919000040")

var Lit_89 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000036$fn__1919000042")

var Lit_90 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000036$fn__1919000042$fn__1919000043")

var Lit_91 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000048")

var Lit_92 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000050")

var Lit_93 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000050$fn__1919000052")

var Lit_94 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000050$fn__1919000054")

var Lit_95 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000050$fn__1919000056")

var Lit_96 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000050$fn__1919000056$fn__1919000057")

var Lit_97 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000061")

var Lit_98 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000061$fn__1919000063")

var Lit_99 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000061$fn__1919000065")

var Lit_100 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000061$fn__1919000067")

var Lit_101 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000061$fn__1919000067$fn__1919000068")

var Lit_102 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000073")

var Lit_103 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000076")

var Lit_104 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000079")

var Lit_105 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000081")

var Lit_106 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000084")

var Lit_107 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000087")

var Lit_108 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000089")

var Lit_109 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000092")

var Lit_110 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000094")

var Lit_111 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000096")

var Lit_112 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000096$fn__1919000098")

var Lit_113 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000096$fn__1919000100")

var Lit_114 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000096$fn__1919000102")

var Lit_115 *jrt.String = jrt.Intern("arbace.core.specs.alpha$fn__1919000096$fn__1919000102$fn__1919000103")

var Lit_116 *jrt.String = jrt.Intern("arbace.core.specs.alpha$quotable")

var Lit_117 *jrt.String = jrt.Intern("in-ns")

var Lit_118 *jrt.String = jrt.Intern("def-impl")

var Lit_119 *jrt.String = jrt.Intern("local-name")

var Lit_120 *jrt.String = jrt.Intern("and")

var Lit_121 *jrt.String = jrt.Intern("simple-symbol?")

var Lit_122 *jrt.String = jrt.Intern("fn*")

var Lit_123 *jrt.String = jrt.Intern("p1__1919000010#")

var Lit_124 *jrt.String = jrt.Intern("line")

var Lit_125 *jrt.String = jrt.Intern("column")

var Lit_126 *jrt.String = jrt.Intern("and-spec-impl")

var Lit_127 *jrt.String = jrt.Intern("binding-form")

var Lit_128 *jrt.String = jrt.Intern("local-symbol")

var Lit_129 *jrt.String = jrt.Intern("seq-destructure")

var Lit_130 *jrt.String = jrt.Intern("seq-binding-form")

var Lit_131 *jrt.String = jrt.Intern("map-destructure")

var Lit_132 *jrt.String = jrt.Intern("map-binding-form")

var Lit_133 *jrt.String = jrt.Intern("or-spec-impl")

var Lit_134 *jrt.String = jrt.Intern("forms")

var Lit_135 *jrt.String = jrt.Intern("rest-forms")

var Lit_136 *jrt.String = jrt.Intern("?")

var Lit_137 *jrt.String = jrt.Intern("ampersand")

var Lit_138 *jrt.String = jrt.Intern("form")

var Lit_139 *jrt.String = jrt.Intern("as-form")

var Lit_140 *jrt.String = jrt.Intern("as-sym")

var Lit_141 *jrt.String = jrt.Intern("maybe-impl")

var Lit_142 *jrt.String = jrt.Intern("non-binding-elements")

var Lit_143 *jrt.String = jrt.Intern("non-binding-element")

var Lit_144 *jrt.String = jrt.Intern("+")

var Lit_145 *jrt.String = jrt.Intern("rep+impl")

var Lit_146 *jrt.String = jrt.Intern("keys-form")

var Lit_147 *jrt.String = jrt.Intern("bindings")

var Lit_148 *jrt.String = jrt.Intern("ident?")

var Lit_149 *jrt.String = jrt.Intern("nonbinding")

var Lit_150 *jrt.String = jrt.Intern("syms-form")

var Lit_151 *jrt.String = jrt.Intern("symbol?")

var Lit_152 *jrt.String = jrt.Intern("simple-syms-form")

var Lit_153 *jrt.String = jrt.Intern("keys")

var Lit_154 *jrt.String = jrt.Intern("syms")

var Lit_155 *jrt.String = jrt.Intern("strs")

var Lit_156 *jrt.String = jrt.Intern("keys!")

var Lit_157 *jrt.String = jrt.Intern("syms!")

var Lit_158 *jrt.String = jrt.Intern("strs!")

var Lit_159 *jrt.String = jrt.Intern("defaults")

var Lit_160 *jrt.String = jrt.Intern("select")

var Lit_161 *jrt.String = jrt.Intern("excess")

var Lit_162 *jrt.String = jrt.Intern("missing")

var Lit_163 *jrt.String = jrt.Intern("all")

var Lit_164 *jrt.String = jrt.Intern("map-special-binding")

var Lit_165 *jrt.String = jrt.Intern("map-binding")

var Lit_166 *jrt.String = jrt.Intern("tuple")

var Lit_167 *jrt.String = jrt.Intern("tuple-impl")

var Lit_168 *jrt.String = jrt.Intern("ns-keys")

var Lit_169 *jrt.String = jrt.Intern("qualified-keyword?")

var Lit_170 *jrt.String = jrt.Intern("p1__1919000018#")

var Lit_171 *jrt.String = jrt.Intern("->")

var Lit_172 *jrt.String = jrt.Intern("map-bindings")

var Lit_173 *jrt.String = jrt.Intern("every")

var Lit_174 *jrt.String = jrt.Intern("qualified-keys-or-syms")

var Lit_175 *jrt.String = jrt.Intern("special-binding")

var Lit_176 *jrt.String = jrt.Intern("kind")

var Lit_177 *jrt.String = jrt.Intern("every-impl")

var Lit_178 *jrt.String = jrt.Intern("kind-form")

var Lit_179 *jrt.String = jrt.Intern("describe")

var Lit_180 *jrt.String = jrt.Intern("cpred")

var Lit_181 *jrt.String = jrt.Intern("merge")

var Lit_182 *jrt.String = jrt.Intern("merge-spec-impl")

var Lit_183 *jrt.String = jrt.Intern("even-number-of-forms?")

var Lit_184 *jrt.String = jrt.Intern("arglists")

var Lit_185 *jrt.String = jrt.Intern("doc")

var Lit_186 *jrt.String = jrt.Intern("Returns true if there are an even number of forms in a binding vector")

var Lit_187 *jrt.String = jrt.Intern("file")

var Lit_188 *jrt.String = jrt.Intern("arbace/core/specs/alpha.ae")

var Lit_189 *jrt.String = jrt.Intern("binding")

var Lit_190 *jrt.String = jrt.Intern("init-expr")

var Lit_191 *jrt.String = jrt.Intern("let")

var Lit_192 *jrt.String = jrt.Intern("fspec")

var Lit_193 *jrt.String = jrt.Intern("args")

var Lit_194 *jrt.String = jrt.Intern("body")

var Lit_195 *jrt.String = jrt.Intern("fspec-impl")

var Lit_196 *jrt.String = jrt.Intern("spec-impl")

var Lit_197 *jrt.String = jrt.Intern("if-let")

var Lit_198 *jrt.String = jrt.Intern("then")

var Lit_199 *jrt.String = jrt.Intern("else")

var Lit_200 *jrt.String = jrt.Intern("when-let")

var Lit_201 *jrt.String = jrt.Intern("param-list")

var Lit_202 *jrt.String = jrt.Intern("params")

var Lit_203 *jrt.String = jrt.Intern("var-params")

var Lit_204 *jrt.String = jrt.Intern("var-form")

var Lit_205 *jrt.String = jrt.Intern("params+body")

var Lit_206 *jrt.String = jrt.Intern("alt")

var Lit_207 *jrt.String = jrt.Intern("prepost+body")

var Lit_208 *jrt.String = jrt.Intern("prepost")

var Lit_209 *jrt.String = jrt.Intern("alt-impl")

var Lit_210 *jrt.String = jrt.Intern("defn-args")

var Lit_211 *jrt.String = jrt.Intern("fn-name")

var Lit_212 *jrt.String = jrt.Intern("docstring")

var Lit_213 *jrt.String = jrt.Intern("string?")

var Lit_214 *jrt.String = jrt.Intern("meta")

var Lit_215 *jrt.String = jrt.Intern("fn-tail")

var Lit_216 *jrt.String = jrt.Intern("arity-1")

var Lit_217 *jrt.String = jrt.Intern("arity-n")

var Lit_218 *jrt.String = jrt.Intern("bodies")

var Lit_219 *jrt.String = jrt.Intern("attr-map")

var Lit_220 *jrt.String = jrt.Intern("defn")

var Lit_221 *jrt.String = jrt.Intern("ret")

var Lit_222 *jrt.String = jrt.Intern("defn-")

var Lit_223 *jrt.String = jrt.Intern("coll-of")

var Lit_224 *jrt.String = jrt.Intern("conform-all")

var Lit_225 *jrt.String = jrt.Intern("map-of")

var Lit_226 *jrt.String = jrt.Intern("kfn")

var Lit_227 *jrt.String = jrt.Intern("into")

var Lit_228 *jrt.String = jrt.Intern("filters")

var Lit_229 *jrt.String = jrt.Intern("keys*")

var Lit_230 *jrt.String = jrt.Intern("ns-refer-clojure")

var Lit_231 *jrt.String = jrt.Intern("clause")

var Lit_232 *jrt.String = jrt.Intern("refer-clojure")

var Lit_233 *jrt.String = jrt.Intern("refer-filters")

var Lit_234 *jrt.String = jrt.Intern("prefix-list")

var Lit_235 *jrt.String = jrt.Intern("libspecs")

var Lit_236 *jrt.String = jrt.Intern("libspec")

var Lit_237 *jrt.String = jrt.Intern("lib")

var Lit_238 *jrt.String = jrt.Intern("lib+opts")

var Lit_239 *jrt.String = jrt.Intern("options")

var Lit_240 *jrt.String = jrt.Intern("ns-require")

var Lit_241 *jrt.String = jrt.Intern("flag")

var Lit_242 *jrt.String = jrt.Intern("verbose")

var Lit_243 *jrt.String = jrt.Intern("reload")

var Lit_244 *jrt.String = jrt.Intern("reload-all")

var Lit_245 *jrt.String = jrt.Intern("package-list")

var Lit_246 *jrt.String = jrt.Intern("package")

var Lit_247 *jrt.String = jrt.Intern("classes")

var Lit_248 *jrt.String = jrt.Intern("import-list")

var Lit_249 *jrt.String = jrt.Intern("class")

var Lit_250 *jrt.String = jrt.Intern("ns-import")

var Lit_251 *jrt.String = jrt.Intern("import")

var Lit_252 *jrt.String = jrt.Intern("ns-refer")

var Lit_253 *jrt.String = jrt.Intern("use-prefix-list")

var Lit_254 *jrt.String = jrt.Intern("use-libspec")

var Lit_255 *jrt.String = jrt.Intern("ns-use")

var Lit_256 *jrt.String = jrt.Intern("use")

var Lit_257 *jrt.String = jrt.Intern("libs")

var Lit_258 *jrt.String = jrt.Intern("ns-load")

var Lit_259 *jrt.String = jrt.Intern("load")

var Lit_260 *jrt.String = jrt.Intern("class-ident")

var Lit_261 *jrt.String = jrt.Intern("class-name")

var Lit_262 *jrt.String = jrt.Intern("signature")

var Lit_263 *jrt.String = jrt.Intern("method")

var Lit_264 *jrt.String = jrt.Intern("method-name")

var Lit_265 *jrt.String = jrt.Intern("param-types")

var Lit_266 *jrt.String = jrt.Intern("return-type")

var Lit_267 *jrt.String = jrt.Intern("boolean?")

var Lit_268 *jrt.String = jrt.Intern("get")

var Lit_269 *jrt.String = jrt.Intern("set")

var Lit_270 *jrt.String = jrt.Intern("expose")

var Lit_271 *jrt.String = jrt.Intern("ns-gen-class")

var Lit_272 *jrt.String = jrt.Intern("gen-class")

var Lit_273 *jrt.String = jrt.Intern("ns-clauses")

var Lit_274 *jrt.String = jrt.Intern("ns-form")

var Lit_275 *jrt.String = jrt.Intern("ns-name")

var Lit_276 *jrt.String = jrt.Intern("ns")

var Lit_277 *jrt.String = jrt.Intern("quotable")

var Lit_278 *jrt.String = jrt.Intern("private")

var Lit_279 *jrt.String = jrt.Intern("Returns a spec that accepts both the spec and a (quote ...) form of the spec")

var Lit_280 *jrt.String = jrt.Intern("quotable-import-list")

var Lit_281 *jrt.String = jrt.Intern("op")

var Lit_282 *jrt.String = jrt.Intern("arg")
