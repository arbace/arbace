//line aot_arbace_core_specs_alpha.ae:1
package aot_arbace_core_specs_alpha

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A_New() *A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A { A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A_Init(); t := &A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A{}; t.Ctor(); return t }
//line :5:1
func (t *A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A) Ctor() {}
//line :5:1
func (t *A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp4 = A_arbace_core_specs_alpha_A_const_1; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_core_specs_alpha_A_Init(); tmp6 = A_arbace_core_specs_alpha_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp7 = A_arbace_core_specs_alpha_A_const_0; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_core_specs_alpha_A_Init(); tmp9 = A_arbace_core_specs_alpha_A_const_3; tmp3 = tmp8.Invoke_O__O(tmp9) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp10 != nil { panic(tmp10) }; return tmp3 }
//line :5:1
func A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A_New() *A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A { A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A_Init(); t := &A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A{}; t.Ctor(); return t }
//line :5:1
func (t *A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A) Ctor() {}
//line :5:1
func (t *A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_4; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp3 = A_arbace_core_specs_alpha_A_const_5; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp5 = A_arbace_core_specs_alpha_A_const_8; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp7 = A_arbace_core_specs_alpha_A_const_6; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_core_specs_alpha_A_Init(); tmp9 = A_arbace_core_specs_alpha_A_const_7; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }




func A_arbace_core_specs_alpha_fn__1919000011_A_New() *A_arbace_core_specs_alpha_fn__1919000011_A { A_arbace_core_specs_alpha_fn__1919000011_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000011_A{}; t.Ctor(); return t }
//line :10:1
func (t *A_arbace_core_specs_alpha_fn__1919000011_A) Ctor() {}
//line :10:1
func (t *A_arbace_core_specs_alpha_fn__1919000011_A) Invoke_O_O__O(self, p1__1919000010_SHARP___0 any) any { var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_9; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_core_specs_alpha_A_Init(); tmp3 = A_arbace_core_specs_alpha_A_const_10; return tmp2.Invoke_O_O__O(tmp3, p1__1919000010_SHARP___0) }




































func A_arbace_core_specs_alpha_fn__1919000014_A_New() *A_arbace_core_specs_alpha_fn__1919000014_A { A_arbace_core_specs_alpha_fn__1919000014_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000014_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_core_specs_alpha_fn__1919000014_A) Ctor() {}
//line :47:1
func (t *A_arbace_core_specs_alpha_fn__1919000014_A) Invoke_O_O__O(self, G__1919000013__0_ any) any { var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_11; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(G__1919000013__0_) }
//line :47:1
func A_arbace_core_specs_alpha_fn__1919000016_A_New() *A_arbace_core_specs_alpha_fn__1919000016_A { A_arbace_core_specs_alpha_fn__1919000016_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000016_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_core_specs_alpha_fn__1919000016_A) Ctor() {}
//line :47:1
func (t *A_arbace_core_specs_alpha_fn__1919000016_A) Invoke_O_O__O(self, G__1919000013__0_ any) any { var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_11; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(G__1919000013__0_) }





func A_arbace_core_specs_alpha_fn__1919000019_A_New() *A_arbace_core_specs_alpha_fn__1919000019_A { A_arbace_core_specs_alpha_fn__1919000019_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000019_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_core_specs_alpha_fn__1919000019_A) Ctor() {}
//line :53:1
func (t *A_arbace_core_specs_alpha_fn__1919000019_A) Invoke_O_O__O(self, p1__1919000018_SHARP___0 any) any { var tmp1 any; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_12; var tmp2 lang.IFn = lang.IFn_Cast(tmp1); var tmp3 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp3 = A_arbace_core_specs_alpha_A_const_13; return tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(p1__1919000018_SHARP___0)) }



func A_arbace_core_specs_alpha_fn__1919000022_A_New() *A_arbace_core_specs_alpha_fn__1919000022_A { A_arbace_core_specs_alpha_fn__1919000022_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000022_A{}; t.Ctor(); return t }
//line :57:1
func (t *A_arbace_core_specs_alpha_fn__1919000022_A) Ctor() {}
//line :57:1
func (t *A_arbace_core_specs_alpha_fn__1919000022_A) Invoke_O_O__O(self, G__1919000021__0_ any) any { var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_11; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(G__1919000021__0_) }








func A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A_New() *A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A { A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A_Init(); t := &A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A{}; t.Ctor(); return t }
//line :66:1
func (t *A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A) Ctor() {}
//line :66:1
func (t *A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A) Invoke_O_O__O(self, forms__0 any) any {


	var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_14; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(forms__0)).Ref())
}
























































func A_arbace_core_specs_alpha_fn__1919000026_A_New() *A_arbace_core_specs_alpha_fn__1919000026_A { A_arbace_core_specs_alpha_fn__1919000026_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000026_A{}; t.Ctor(); return t }
//line :127:1
func (t *A_arbace_core_specs_alpha_fn__1919000026_A) Ctor() {}
//line :127:1
func (t *A_arbace_core_specs_alpha_fn__1919000026_A) Invoke_O_O__O(self, G__1919000025__0_ any) any { var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_15; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(G__1919000025__0_) }
func A_arbace_core_specs_alpha_fn__1919000029_A_New() *A_arbace_core_specs_alpha_fn__1919000029_A { A_arbace_core_specs_alpha_fn__1919000029_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000029_A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_core_specs_alpha_fn__1919000029_A) Ctor() {}
//line :128:1
func (t *A_arbace_core_specs_alpha_fn__1919000029_A) Invoke_O_O__O(self, G__1919000028__0_ any) any { var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_15; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(G__1919000028__0_) }
func A_arbace_core_specs_alpha_fn__1919000032_A_New() *A_arbace_core_specs_alpha_fn__1919000032_A { A_arbace_core_specs_alpha_fn__1919000032_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000032_A{}; t.Ctor(); return t }
//line :129:1
func (t *A_arbace_core_specs_alpha_fn__1919000032_A) Ctor() {}
//line :129:1
func (t *A_arbace_core_specs_alpha_fn__1919000032_A) Invoke_O_O_O__O(self, i__1740000305__auto____0, v__1740000306__auto____1 any) any { return lang.RT_Nth_O_I__O(v__1740000306__auto____1, lang.RT_IntCast_J__I(0)) }
//line :129:1
func A_arbace_core_specs_alpha_fn__1919000034_A_New() *A_arbace_core_specs_alpha_fn__1919000034_A { A_arbace_core_specs_alpha_fn__1919000034_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000034_A{}; t.Ctor(); return t }
//line :129:1
func (t *A_arbace_core_specs_alpha_fn__1919000034_A) Ctor() {}
//line :129:1
func (t *A_arbace_core_specs_alpha_fn__1919000034_A) Invoke_O_O__O(self, G__1919000031__0_ any) any { var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_11; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(G__1919000031__0_) }
func A_arbace_core_specs_alpha_fn__1919000036_A_New() *A_arbace_core_specs_alpha_fn__1919000036_A { A_arbace_core_specs_alpha_fn__1919000036_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000036_A{}; t.Ctor(); return t }
//line :130:1
func (t *A_arbace_core_specs_alpha_fn__1919000036_A) Ctor() {}
//line :130:1
func (t *A_arbace_core_specs_alpha_fn__1919000036_A) Invoke_O__O(self any) any { var mspec__1740000878__auto____1 any; var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp3 = A_arbace_core_specs_alpha_A_const_18; var tmp4 any = tmp3.Ref(); var tmp5 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp5 = A_arbace_core_specs_alpha_A_const_19; var tmp6 any = tmp5.Ref(); var tmp7 any; A_arbace_core_specs_alpha_A_Init(); tmp7 = A_arbace_core_specs_alpha_A_const_20; var tmp8 any = tmp7; var tmp9 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp9 = A_arbace_core_specs_alpha_A_const_21; var tmp10 any = tmp9.Ref(); var tmp11 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp11 = A_arbace_core_specs_alpha_A_const_22; var tmp12 any = tmp11.Ref(); var tmp13 any = A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A_New(); var tmp14 *jrt.Class; A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A_Init(); tmp14 = A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A_fn_class; var tmp15 any = lang.Tuple_Create_O__IPersistentVector(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil)); var tmp16 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp16 = A_arbace_core_specs_alpha_A_const_23; var tmp17 any = tmp16.Ref(); var tmp18 any = A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A_New(); var tmp19 *jrt.Class; A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A_Init(); tmp19 = A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A_fn_class; var tmp20 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil); var tmp21 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp21 = A_arbace_core_specs_alpha_A_const_24; var tmp22 any = tmp21.Ref(); var tmp23 any; A_arbace_core_specs_alpha_A_Init(); tmp23 = A_arbace_core_specs_alpha_A_const_25; var tmp24 any = tmp23; var tmp25 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp25 = A_arbace_core_specs_alpha_A_const_26; var tmp26 any = tmp25.Ref(); var tmp27 *lang.PersistentVector; lang.PersistentVector_Init(); tmp27 = lang.PersistentVector_EMPTY; var tmp28 any = tmp27.Ref(); var tmp29 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp29 = A_arbace_core_specs_alpha_A_const_27; var tmp30 any = tmp29.Ref(); var tmp31 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp31 = A_arbace_core_specs_alpha_A_const_28; var tmp32 any = tmp31.Ref(); var tmp33 *lang.PersistentVector; lang.PersistentVector_Init(); tmp33 = lang.PersistentVector_EMPTY; var tmp34 any = tmp33.Ref(); var tmp35 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp35 = A_arbace_core_specs_alpha_A_const_29; var tmp36 any = tmp35.Ref(); var tmp37 any; A_arbace_core_specs_alpha_A_Init(); tmp37 = A_arbace_core_specs_alpha_A_const_30; var tmp38 any = tmp37; var tmp39 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp39 = A_arbace_core_specs_alpha_A_const_31; var tmp40 any = tmp39.Ref(); var tmp41 any; A_arbace_core_specs_alpha_A_Init(); tmp41 = A_arbace_core_specs_alpha_A_const_32; var tmp42 any = tmp41; var tmp43 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp43 = A_arbace_core_specs_alpha_A_const_33; mspec__1740000878__auto____1 = tmp2.Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, nil, tmp6, tmp8, tmp10, nil, tmp12, tmp15, tmp17, tmp20, tmp22, tmp24, tmp26, tmp28, tmp30, nil, tmp32, tmp34, tmp36, tmp38, tmp40, tmp42, tmp43.Ref(), nil))); var tmp44 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp44 = A_arbace_core_specs_alpha_A_const_17; var tmp45 lang.IFn = lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()); var tmp46 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp46 = A_arbace_core_specs_alpha_A_const_34; var tmp47 lang.IFn = lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()); var tmp48 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp48 = A_arbace_core_specs_alpha_A_const_39; var tmp49 lang.IFn = lang.IFn_Cast(jrt.NN(tmp48).GetRawRoot__O()); var tmp50 any; A_arbace_core_specs_alpha_A_Init(); tmp50 = A_arbace_core_specs_alpha_A_const_42; var tmp51 any = tmp50; var tmp52 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp52 = A_arbace_core_specs_alpha_A_const_43; var tmp53 lang.IFn = lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()); var tmp54 any; A_arbace_core_specs_alpha_A_Init(); tmp54 = A_arbace_core_specs_alpha_A_const_44; var tmp55 any = tmp54; var tmp56 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp56 = A_arbace_core_specs_alpha_A_const_46; var tmp57 any = jrt.NN(tmp56).GetRawRoot__O(); var tmp58 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp58 = A_arbace_core_specs_alpha_A_const_47; var tmp59 any = lang.Tuple_Create_O_O__IPersistentVector(tmp57, jrt.NN(tmp58).GetRawRoot__O()); var tmp60 any; A_arbace_core_specs_alpha_A_Init(); tmp60 = A_arbace_core_specs_alpha_A_const_45; var tmp61 any = tmp49.Invoke_O_O__O(tmp51, tmp53.Invoke_O_O_O__O(tmp55, tmp59, tmp60)); var tmp62 any; A_arbace_core_specs_alpha_A_Init(); tmp62 = A_arbace_core_specs_alpha_A_const_40; var tmp63 any = tmp62; var tmp64 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp64 = A_arbace_core_specs_alpha_A_const_48; var tmp65 any = lang.Tuple_Create_O_O__IPersistentVector(tmp64.Ref(), mspec__1740000878__auto____1); var tmp66 any; A_arbace_core_specs_alpha_A_Init(); tmp66 = A_arbace_core_specs_alpha_A_const_41; var tmp67 any = tmp47.Invoke_O_O_O_O__O(tmp61, tmp63, tmp65, tmp66); var tmp68 any = A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A_New_O(mspec__1740000878__auto____1); var tmp69 *jrt.Class; A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A_Init(); tmp69 = A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A_fn_class; return tmp45.Invoke_O_O__O(tmp67, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp68, tmp69, nil)) }
//line :130:1
func A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A_New() *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A { A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A{}; t.Ctor(); return t }
//line :130:1
func (t *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A) Ctor() {}
//line :130:1
func (t *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A) Invoke_O_O__O(self, G__1919000037__1_ any) any { var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_11; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(G__1919000037__1_) }
//line :130:1
func A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A_New() *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A { A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A{}; t.Ctor(); return t }
//line :130:1
func (t *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A) Ctor() {}
//line :130:1
func (t *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A) Invoke_O_O__O(self, G__1919000037__1_ any) any { var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_11; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(G__1919000037__1_) }
//line :130:1
func A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A_New_O(p0 any) *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A { A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A{}; t.Ctor_O(p0); return t }
//line :130:1
func (t *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A) Ctor_O(c__mspec__1740000878__auto__ any) { t.F_mspec__1740000878__auto__ = c__mspec__1740000878__auto__ }
//line :130:1
func (t *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_35; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A_New(); var tmp4 *jrt.Class; A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A_Init(); tmp4 = A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A_fn_class; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp6 = A_arbace_core_specs_alpha_A_const_38; return tmp2.Invoke_O_O__O(tmp5, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(t.F_mspec__1740000878__auto__)) }
//line :130:1
func A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A_New() *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A { A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A{}; t.Ctor(); return t }
//line :130:1
func (t *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A) Ctor() {}
//line :130:1
func (t *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A) Invoke_O_O__O(self, m__1740000879__auto____1 any) any { var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_36; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp3 = A_arbace_core_specs_alpha_A_const_37; return tmp2.Invoke_O_O__O(jrt.NN(tmp3).GetRawRoot__O(), m__1740000879__auto____1) }






func A_arbace_core_specs_alpha_fn__1919000048_A_New() *A_arbace_core_specs_alpha_fn__1919000048_A { A_arbace_core_specs_alpha_fn__1919000048_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000048_A{}; t.Ctor(); return t }
//line :137:1
func (t *A_arbace_core_specs_alpha_fn__1919000048_A) Ctor() {}
//line :137:1
func (t *A_arbace_core_specs_alpha_fn__1919000048_A) Invoke_O_O__O(self, G__1919000047__0_ any) any { var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_15; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(G__1919000047__0_) }











func A_arbace_core_specs_alpha_fn__1919000050_A_New() *A_arbace_core_specs_alpha_fn__1919000050_A { A_arbace_core_specs_alpha_fn__1919000050_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000050_A{}; t.Ctor(); return t }
//line :149:1
func (t *A_arbace_core_specs_alpha_fn__1919000050_A) Ctor() {}
//line :149:1
func (t *A_arbace_core_specs_alpha_fn__1919000050_A) Invoke_O__O(self any) any { var mspec__1740000878__auto____1 any; var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp3 = A_arbace_core_specs_alpha_A_const_18; var tmp4 any = tmp3.Ref(); var tmp5 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp5 = A_arbace_core_specs_alpha_A_const_19; var tmp6 any = tmp5.Ref(); var tmp7 any; A_arbace_core_specs_alpha_A_Init(); tmp7 = A_arbace_core_specs_alpha_A_const_49; var tmp8 any = tmp7; var tmp9 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp9 = A_arbace_core_specs_alpha_A_const_21; var tmp10 any = tmp9.Ref(); var tmp11 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp11 = A_arbace_core_specs_alpha_A_const_22; var tmp12 any = tmp11.Ref(); var tmp13 any = A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A_New(); var tmp14 *jrt.Class; A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A_Init(); tmp14 = A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A_fn_class; var tmp15 any = lang.Tuple_Create_O__IPersistentVector(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil)); var tmp16 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp16 = A_arbace_core_specs_alpha_A_const_23; var tmp17 any = tmp16.Ref(); var tmp18 any = A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A_New(); var tmp19 *jrt.Class; A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A_Init(); tmp19 = A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A_fn_class; var tmp20 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil); var tmp21 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp21 = A_arbace_core_specs_alpha_A_const_24; var tmp22 any = tmp21.Ref(); var tmp23 any; A_arbace_core_specs_alpha_A_Init(); tmp23 = A_arbace_core_specs_alpha_A_const_50; var tmp24 any = tmp23; var tmp25 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp25 = A_arbace_core_specs_alpha_A_const_26; var tmp26 any = tmp25.Ref(); var tmp27 *lang.PersistentVector; lang.PersistentVector_Init(); tmp27 = lang.PersistentVector_EMPTY; var tmp28 any = tmp27.Ref(); var tmp29 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp29 = A_arbace_core_specs_alpha_A_const_27; var tmp30 any = tmp29.Ref(); var tmp31 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp31 = A_arbace_core_specs_alpha_A_const_28; var tmp32 any = tmp31.Ref(); var tmp33 *lang.PersistentVector; lang.PersistentVector_Init(); tmp33 = lang.PersistentVector_EMPTY; var tmp34 any = tmp33.Ref(); var tmp35 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp35 = A_arbace_core_specs_alpha_A_const_29; var tmp36 any = tmp35.Ref(); var tmp37 any; A_arbace_core_specs_alpha_A_Init(); tmp37 = A_arbace_core_specs_alpha_A_const_51; var tmp38 any = tmp37; var tmp39 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp39 = A_arbace_core_specs_alpha_A_const_31; var tmp40 any = tmp39.Ref(); var tmp41 any; A_arbace_core_specs_alpha_A_Init(); tmp41 = A_arbace_core_specs_alpha_A_const_52; var tmp42 any = tmp41; var tmp43 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp43 = A_arbace_core_specs_alpha_A_const_33; mspec__1740000878__auto____1 = tmp2.Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, nil, tmp6, tmp8, tmp10, nil, tmp12, tmp15, tmp17, tmp20, tmp22, tmp24, tmp26, tmp28, tmp30, nil, tmp32, tmp34, tmp36, tmp38, tmp40, tmp42, tmp43.Ref(), nil))); var tmp44 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp44 = A_arbace_core_specs_alpha_A_const_17; var tmp45 lang.IFn = lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()); var tmp46 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp46 = A_arbace_core_specs_alpha_A_const_34; var tmp47 lang.IFn = lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()); var tmp48 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp48 = A_arbace_core_specs_alpha_A_const_39; var tmp49 lang.IFn = lang.IFn_Cast(jrt.NN(tmp48).GetRawRoot__O()); var tmp50 any; A_arbace_core_specs_alpha_A_Init(); tmp50 = A_arbace_core_specs_alpha_A_const_55; var tmp51 any = tmp50; var tmp52 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp52 = A_arbace_core_specs_alpha_A_const_43; var tmp53 lang.IFn = lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()); var tmp54 any; A_arbace_core_specs_alpha_A_Init(); tmp54 = A_arbace_core_specs_alpha_A_const_56; var tmp55 any = tmp54; var tmp56 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp56 = A_arbace_core_specs_alpha_A_const_46; var tmp57 any = jrt.NN(tmp56).GetRawRoot__O(); var tmp58 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp58 = A_arbace_core_specs_alpha_A_const_47; var tmp59 any = lang.Tuple_Create_O_O__IPersistentVector(tmp57, jrt.NN(tmp58).GetRawRoot__O()); var tmp60 any; A_arbace_core_specs_alpha_A_Init(); tmp60 = A_arbace_core_specs_alpha_A_const_57; var tmp61 any = tmp49.Invoke_O_O__O(tmp51, tmp53.Invoke_O_O_O__O(tmp55, tmp59, tmp60)); var tmp62 any; A_arbace_core_specs_alpha_A_Init(); tmp62 = A_arbace_core_specs_alpha_A_const_53; var tmp63 any = tmp62; var tmp64 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp64 = A_arbace_core_specs_alpha_A_const_48; var tmp65 any = lang.Tuple_Create_O_O__IPersistentVector(tmp64.Ref(), mspec__1740000878__auto____1); var tmp66 any; A_arbace_core_specs_alpha_A_Init(); tmp66 = A_arbace_core_specs_alpha_A_const_54; var tmp67 any = tmp47.Invoke_O_O_O_O__O(tmp61, tmp63, tmp65, tmp66); var tmp68 any = A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A_New_O(mspec__1740000878__auto____1); var tmp69 *jrt.Class; A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A_Init(); tmp69 = A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A_fn_class; return tmp45.Invoke_O_O__O(tmp67, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp68, tmp69, nil)) }
//line :149:1
func A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A_New() *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A { A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A{}; t.Ctor(); return t }
//line :149:1
func (t *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A) Ctor() {}
//line :149:1
func (t *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A) Invoke_O_O__O(self, G__1919000051__1_ any) any { var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_11; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(G__1919000051__1_) }
//line :149:1
func A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A_New() *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A { A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A{}; t.Ctor(); return t }
//line :149:1
func (t *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A) Ctor() {}
//line :149:1
func (t *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A) Invoke_O_O__O(self, G__1919000051__1_ any) any { var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_11; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(G__1919000051__1_) }
//line :149:1
func A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A_New_O(p0 any) *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A { A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A{}; t.Ctor_O(p0); return t }
//line :149:1
func (t *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A) Ctor_O(c__mspec__1740000878__auto__ any) { t.F_mspec__1740000878__auto__ = c__mspec__1740000878__auto__ }
//line :149:1
func (t *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_35; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A_New(); var tmp4 *jrt.Class; A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A_Init(); tmp4 = A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A_fn_class; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp6 = A_arbace_core_specs_alpha_A_const_38; return tmp2.Invoke_O_O__O(tmp5, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(t.F_mspec__1740000878__auto__)) }
//line :149:1
func A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A_New() *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A { A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A{}; t.Ctor(); return t }
//line :149:1
func (t *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A) Ctor() {}
//line :149:1
func (t *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A) Invoke_O_O__O(self, m__1740000879__auto____1 any) any { var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_36; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp3 = A_arbace_core_specs_alpha_A_const_37; return tmp2.Invoke_O_O__O(jrt.NN(tmp3).GetRawRoot__O(), m__1740000879__auto____1) }




































func A_arbace_core_specs_alpha_fn__1919000061_A_New() *A_arbace_core_specs_alpha_fn__1919000061_A { A_arbace_core_specs_alpha_fn__1919000061_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000061_A{}; t.Ctor(); return t }
//line :186:1
func (t *A_arbace_core_specs_alpha_fn__1919000061_A) Ctor() {}
//line :186:1
func (t *A_arbace_core_specs_alpha_fn__1919000061_A) Invoke_O__O(self any) any { var mspec__1740000878__auto____1 any; var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp3 = A_arbace_core_specs_alpha_A_const_18; var tmp4 any = tmp3.Ref(); var tmp5 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp5 = A_arbace_core_specs_alpha_A_const_19; var tmp6 any = tmp5.Ref(); var tmp7 any; A_arbace_core_specs_alpha_A_Init(); tmp7 = A_arbace_core_specs_alpha_A_const_58; var tmp8 any = tmp7; var tmp9 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp9 = A_arbace_core_specs_alpha_A_const_21; var tmp10 any = tmp9.Ref(); var tmp11 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp11 = A_arbace_core_specs_alpha_A_const_22; var tmp12 any = tmp11.Ref(); var tmp13 any = A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A_New(); var tmp14 *jrt.Class; A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A_Init(); tmp14 = A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A_fn_class; var tmp15 any = lang.Tuple_Create_O__IPersistentVector(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil)); var tmp16 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp16 = A_arbace_core_specs_alpha_A_const_23; var tmp17 any = tmp16.Ref(); var tmp18 any = A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A_New(); var tmp19 *jrt.Class; A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A_Init(); tmp19 = A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A_fn_class; var tmp20 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil); var tmp21 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp21 = A_arbace_core_specs_alpha_A_const_24; var tmp22 any = tmp21.Ref(); var tmp23 any; A_arbace_core_specs_alpha_A_Init(); tmp23 = A_arbace_core_specs_alpha_A_const_59; var tmp24 any = tmp23; var tmp25 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp25 = A_arbace_core_specs_alpha_A_const_26; var tmp26 any = tmp25.Ref(); var tmp27 *lang.PersistentVector; lang.PersistentVector_Init(); tmp27 = lang.PersistentVector_EMPTY; var tmp28 any = tmp27.Ref(); var tmp29 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp29 = A_arbace_core_specs_alpha_A_const_27; var tmp30 any = tmp29.Ref(); var tmp31 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp31 = A_arbace_core_specs_alpha_A_const_28; var tmp32 any = tmp31.Ref(); var tmp33 *lang.PersistentVector; lang.PersistentVector_Init(); tmp33 = lang.PersistentVector_EMPTY; var tmp34 any = tmp33.Ref(); var tmp35 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp35 = A_arbace_core_specs_alpha_A_const_29; var tmp36 any = tmp35.Ref(); var tmp37 any; A_arbace_core_specs_alpha_A_Init(); tmp37 = A_arbace_core_specs_alpha_A_const_60; var tmp38 any = tmp37; var tmp39 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp39 = A_arbace_core_specs_alpha_A_const_31; var tmp40 any = tmp39.Ref(); var tmp41 any; A_arbace_core_specs_alpha_A_Init(); tmp41 = A_arbace_core_specs_alpha_A_const_61; var tmp42 any = tmp41; var tmp43 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp43 = A_arbace_core_specs_alpha_A_const_33; mspec__1740000878__auto____1 = tmp2.Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, nil, tmp6, tmp8, tmp10, nil, tmp12, tmp15, tmp17, tmp20, tmp22, tmp24, tmp26, tmp28, tmp30, nil, tmp32, tmp34, tmp36, tmp38, tmp40, tmp42, tmp43.Ref(), nil))); var tmp44 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp44 = A_arbace_core_specs_alpha_A_const_17; var tmp45 lang.IFn = lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()); var tmp46 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp46 = A_arbace_core_specs_alpha_A_const_34; var tmp47 lang.IFn = lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()); var tmp48 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp48 = A_arbace_core_specs_alpha_A_const_39; var tmp49 lang.IFn = lang.IFn_Cast(jrt.NN(tmp48).GetRawRoot__O()); var tmp50 any; A_arbace_core_specs_alpha_A_Init(); tmp50 = A_arbace_core_specs_alpha_A_const_64; var tmp51 any = tmp50; var tmp52 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp52 = A_arbace_core_specs_alpha_A_const_43; var tmp53 lang.IFn = lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()); var tmp54 any; A_arbace_core_specs_alpha_A_Init(); tmp54 = A_arbace_core_specs_alpha_A_const_65; var tmp55 any = tmp54; var tmp56 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp56 = A_arbace_core_specs_alpha_A_const_46; var tmp57 any = jrt.NN(tmp56).GetRawRoot__O(); var tmp58 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp58 = A_arbace_core_specs_alpha_A_const_47; var tmp59 any = lang.Tuple_Create_O_O__IPersistentVector(tmp57, jrt.NN(tmp58).GetRawRoot__O()); var tmp60 any; A_arbace_core_specs_alpha_A_Init(); tmp60 = A_arbace_core_specs_alpha_A_const_66; var tmp61 any = tmp49.Invoke_O_O__O(tmp51, tmp53.Invoke_O_O_O__O(tmp55, tmp59, tmp60)); var tmp62 any; A_arbace_core_specs_alpha_A_Init(); tmp62 = A_arbace_core_specs_alpha_A_const_62; var tmp63 any = tmp62; var tmp64 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp64 = A_arbace_core_specs_alpha_A_const_48; var tmp65 any = lang.Tuple_Create_O_O__IPersistentVector(tmp64.Ref(), mspec__1740000878__auto____1); var tmp66 any; A_arbace_core_specs_alpha_A_Init(); tmp66 = A_arbace_core_specs_alpha_A_const_63; var tmp67 any = tmp47.Invoke_O_O_O_O__O(tmp61, tmp63, tmp65, tmp66); var tmp68 any = A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A_New_O(mspec__1740000878__auto____1); var tmp69 *jrt.Class; A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A_Init(); tmp69 = A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A_fn_class; return tmp45.Invoke_O_O__O(tmp67, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp68, tmp69, nil)) }
//line :186:1
func A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A_New() *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A { A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A{}; t.Ctor(); return t }
//line :186:1
func (t *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A) Ctor() {}
//line :186:1
func (t *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A) Invoke_O_O__O(self, G__1919000062__1_ any) any { var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_11; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(G__1919000062__1_) }
//line :186:1
func A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A_New() *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A { A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A{}; t.Ctor(); return t }
//line :186:1
func (t *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A) Ctor() {}
//line :186:1
func (t *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A) Invoke_O_O__O(self, G__1919000062__1_ any) any { var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_11; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(G__1919000062__1_) }
//line :186:1
func A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A_New_O(p0 any) *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A { A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A{}; t.Ctor_O(p0); return t }
//line :186:1
func (t *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A) Ctor_O(c__mspec__1740000878__auto__ any) { t.F_mspec__1740000878__auto__ = c__mspec__1740000878__auto__ }
//line :186:1
func (t *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_35; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A_New(); var tmp4 *jrt.Class; A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A_Init(); tmp4 = A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A_fn_class; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp6 = A_arbace_core_specs_alpha_A_const_38; return tmp2.Invoke_O_O__O(tmp5, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(t.F_mspec__1740000878__auto__)) }
//line :186:1
func A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A_New() *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A { A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A{}; t.Ctor(); return t }
//line :186:1
func (t *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A) Ctor() {}
//line :186:1
func (t *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A) Invoke_O_O__O(self, m__1740000879__auto____1 any) any { var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_36; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp3 = A_arbace_core_specs_alpha_A_const_37; return tmp2.Invoke_O_O__O(jrt.NN(tmp3).GetRawRoot__O(), m__1740000879__auto____1) }













func A_arbace_core_specs_alpha_fn__1919000073_A_New() *A_arbace_core_specs_alpha_fn__1919000073_A { A_arbace_core_specs_alpha_fn__1919000073_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000073_A{}; t.Ctor(); return t }
//line :200:1
func (t *A_arbace_core_specs_alpha_fn__1919000073_A) Ctor() {}
//line :200:1
func (t *A_arbace_core_specs_alpha_fn__1919000073_A) Invoke_O_O__O(self, G__1919000072__0_ any) any { var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_67; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(G__1919000072__0_) }


func A_arbace_core_specs_alpha_fn__1919000076_A_New() *A_arbace_core_specs_alpha_fn__1919000076_A { A_arbace_core_specs_alpha_fn__1919000076_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000076_A{}; t.Ctor(); return t }
//line :203:1
func (t *A_arbace_core_specs_alpha_fn__1919000076_A) Ctor() {}
//line :203:1
func (t *A_arbace_core_specs_alpha_fn__1919000076_A) Invoke_O_O__O(self, G__1919000075__0_ any) any { var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_67; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(G__1919000075__0_) }
func A_arbace_core_specs_alpha_fn__1919000079_A_New() *A_arbace_core_specs_alpha_fn__1919000079_A { A_arbace_core_specs_alpha_fn__1919000079_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000079_A{}; t.Ctor(); return t }
//line :204:1
func (t *A_arbace_core_specs_alpha_fn__1919000079_A) Ctor() {}
//line :204:1
func (t *A_arbace_core_specs_alpha_fn__1919000079_A) Invoke_O_O_O__O(self, i__1740000305__auto____0, v__1740000306__auto____1 any) any { return lang.RT_Nth_O_I__O(v__1740000306__auto____1, lang.RT_IntCast_J__I(0)) }
//line :204:1
func A_arbace_core_specs_alpha_fn__1919000081_A_New() *A_arbace_core_specs_alpha_fn__1919000081_A { A_arbace_core_specs_alpha_fn__1919000081_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000081_A{}; t.Ctor(); return t }
//line :204:1
func (t *A_arbace_core_specs_alpha_fn__1919000081_A) Ctor() {}
//line :204:1
func (t *A_arbace_core_specs_alpha_fn__1919000081_A) Invoke_O_O__O(self, G__1919000078__0_ any) any { var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_11; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(G__1919000078__0_) }





func A_arbace_core_specs_alpha_fn__1919000084_A_New() *A_arbace_core_specs_alpha_fn__1919000084_A { A_arbace_core_specs_alpha_fn__1919000084_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000084_A{}; t.Ctor(); return t }
//line :210:1
func (t *A_arbace_core_specs_alpha_fn__1919000084_A) Ctor() {}
//line :210:1
func (t *A_arbace_core_specs_alpha_fn__1919000084_A) Invoke_O_O__O(self, G__1919000083__0_ any) any { var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_67; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(G__1919000083__0_) }





func A_arbace_core_specs_alpha_fn__1919000087_A_New() *A_arbace_core_specs_alpha_fn__1919000087_A { A_arbace_core_specs_alpha_fn__1919000087_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000087_A{}; t.Ctor(); return t }
//line :216:1
func (t *A_arbace_core_specs_alpha_fn__1919000087_A) Ctor() {}
//line :216:1
func (t *A_arbace_core_specs_alpha_fn__1919000087_A) Invoke_O_O__O(self, G__1919000086__0_ any) any { var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_11; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(G__1919000086__0_) }
//line :216:1
func A_arbace_core_specs_alpha_fn__1919000089_A_New() *A_arbace_core_specs_alpha_fn__1919000089_A { A_arbace_core_specs_alpha_fn__1919000089_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000089_A{}; t.Ctor(); return t }
//line :216:1
func (t *A_arbace_core_specs_alpha_fn__1919000089_A) Ctor() {}
//line :216:1
func (t *A_arbace_core_specs_alpha_fn__1919000089_A) Invoke_O_O__O(self, G__1919000086__0_ any) any { var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_11; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(G__1919000086__0_) }
func A_arbace_core_specs_alpha_fn__1919000092_A_New() *A_arbace_core_specs_alpha_fn__1919000092_A { A_arbace_core_specs_alpha_fn__1919000092_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000092_A{}; t.Ctor(); return t }
//line :217:1
func (t *A_arbace_core_specs_alpha_fn__1919000092_A) Ctor() {}
//line :217:1
func (t *A_arbace_core_specs_alpha_fn__1919000092_A) Invoke_O_O_O__O(self, i__1740000305__auto____0, v__1740000306__auto____1 any) any { return lang.RT_Nth_O_I__O(v__1740000306__auto____1, lang.RT_IntCast_J__I(0)) }
//line :217:1
func A_arbace_core_specs_alpha_fn__1919000094_A_New() *A_arbace_core_specs_alpha_fn__1919000094_A { A_arbace_core_specs_alpha_fn__1919000094_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000094_A{}; t.Ctor(); return t }
//line :217:1
func (t *A_arbace_core_specs_alpha_fn__1919000094_A) Ctor() {}
//line :217:1
func (t *A_arbace_core_specs_alpha_fn__1919000094_A) Invoke_O_O__O(self, G__1919000091__0_ any) any { var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_11; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(G__1919000091__0_) }






func A_arbace_core_specs_alpha_fn__1919000096_A_New() *A_arbace_core_specs_alpha_fn__1919000096_A { A_arbace_core_specs_alpha_fn__1919000096_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000096_A{}; t.Ctor(); return t }
//line :224:1
func (t *A_arbace_core_specs_alpha_fn__1919000096_A) Ctor() {}
//line :224:1
func (t *A_arbace_core_specs_alpha_fn__1919000096_A) Invoke_O__O(self any) any { var mspec__1740000878__auto____1 any; var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp3 = A_arbace_core_specs_alpha_A_const_18; var tmp4 any = tmp3.Ref(); var tmp5 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp5 = A_arbace_core_specs_alpha_A_const_19; var tmp6 any = tmp5.Ref(); var tmp7 any; A_arbace_core_specs_alpha_A_Init(); tmp7 = A_arbace_core_specs_alpha_A_const_68; var tmp8 any = tmp7; var tmp9 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp9 = A_arbace_core_specs_alpha_A_const_21; var tmp10 any = tmp9.Ref(); var tmp11 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp11 = A_arbace_core_specs_alpha_A_const_22; var tmp12 any = tmp11.Ref(); var tmp13 any = A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A_New(); var tmp14 *jrt.Class; A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A_Init(); tmp14 = A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A_fn_class; var tmp15 any = lang.Tuple_Create_O__IPersistentVector(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil)); var tmp16 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp16 = A_arbace_core_specs_alpha_A_const_23; var tmp17 any = tmp16.Ref(); var tmp18 any = A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A_New(); var tmp19 *jrt.Class; A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A_Init(); tmp19 = A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A_fn_class; var tmp20 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil); var tmp21 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp21 = A_arbace_core_specs_alpha_A_const_24; var tmp22 any = tmp21.Ref(); var tmp23 any; A_arbace_core_specs_alpha_A_Init(); tmp23 = A_arbace_core_specs_alpha_A_const_69; var tmp24 any = tmp23; var tmp25 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp25 = A_arbace_core_specs_alpha_A_const_26; var tmp26 any = tmp25.Ref(); var tmp27 *lang.PersistentVector; lang.PersistentVector_Init(); tmp27 = lang.PersistentVector_EMPTY; var tmp28 any = tmp27.Ref(); var tmp29 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp29 = A_arbace_core_specs_alpha_A_const_27; var tmp30 any = tmp29.Ref(); var tmp31 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp31 = A_arbace_core_specs_alpha_A_const_28; var tmp32 any = tmp31.Ref(); var tmp33 *lang.PersistentVector; lang.PersistentVector_Init(); tmp33 = lang.PersistentVector_EMPTY; var tmp34 any = tmp33.Ref(); var tmp35 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp35 = A_arbace_core_specs_alpha_A_const_29; var tmp36 any = tmp35.Ref(); var tmp37 any; A_arbace_core_specs_alpha_A_Init(); tmp37 = A_arbace_core_specs_alpha_A_const_70; var tmp38 any = tmp37; var tmp39 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp39 = A_arbace_core_specs_alpha_A_const_31; var tmp40 any = tmp39.Ref(); var tmp41 any; A_arbace_core_specs_alpha_A_Init(); tmp41 = A_arbace_core_specs_alpha_A_const_71; var tmp42 any = tmp41; var tmp43 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp43 = A_arbace_core_specs_alpha_A_const_33; mspec__1740000878__auto____1 = tmp2.Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, nil, tmp6, tmp8, tmp10, nil, tmp12, tmp15, tmp17, tmp20, tmp22, tmp24, tmp26, tmp28, tmp30, nil, tmp32, tmp34, tmp36, tmp38, tmp40, tmp42, tmp43.Ref(), nil))); var tmp44 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp44 = A_arbace_core_specs_alpha_A_const_17; var tmp45 lang.IFn = lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()); var tmp46 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp46 = A_arbace_core_specs_alpha_A_const_34; var tmp47 lang.IFn = lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()); var tmp48 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp48 = A_arbace_core_specs_alpha_A_const_39; var tmp49 lang.IFn = lang.IFn_Cast(jrt.NN(tmp48).GetRawRoot__O()); var tmp50 any; A_arbace_core_specs_alpha_A_Init(); tmp50 = A_arbace_core_specs_alpha_A_const_74; var tmp51 any = tmp50; var tmp52 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp52 = A_arbace_core_specs_alpha_A_const_43; var tmp53 lang.IFn = lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()); var tmp54 any; A_arbace_core_specs_alpha_A_Init(); tmp54 = A_arbace_core_specs_alpha_A_const_75; var tmp55 any = tmp54; var tmp56 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp56 = A_arbace_core_specs_alpha_A_const_46; var tmp57 any = jrt.NN(tmp56).GetRawRoot__O(); var tmp58 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp58 = A_arbace_core_specs_alpha_A_const_47; var tmp59 any = lang.Tuple_Create_O_O__IPersistentVector(tmp57, jrt.NN(tmp58).GetRawRoot__O()); var tmp60 any; A_arbace_core_specs_alpha_A_Init(); tmp60 = A_arbace_core_specs_alpha_A_const_76; var tmp61 any = tmp49.Invoke_O_O__O(tmp51, tmp53.Invoke_O_O_O__O(tmp55, tmp59, tmp60)); var tmp62 any; A_arbace_core_specs_alpha_A_Init(); tmp62 = A_arbace_core_specs_alpha_A_const_72; var tmp63 any = tmp62; var tmp64 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp64 = A_arbace_core_specs_alpha_A_const_48; var tmp65 any = lang.Tuple_Create_O_O__IPersistentVector(tmp64.Ref(), mspec__1740000878__auto____1); var tmp66 any; A_arbace_core_specs_alpha_A_Init(); tmp66 = A_arbace_core_specs_alpha_A_const_73; var tmp67 any = tmp47.Invoke_O_O_O_O__O(tmp61, tmp63, tmp65, tmp66); var tmp68 any = A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A_New_O(mspec__1740000878__auto____1); var tmp69 *jrt.Class; A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A_Init(); tmp69 = A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A_fn_class; return tmp45.Invoke_O_O__O(tmp67, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp68, tmp69, nil)) }
//line :224:1
func A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A_New() *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A { A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A{}; t.Ctor(); return t }
//line :224:1
func (t *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A) Ctor() {}
//line :224:1
func (t *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A) Invoke_O_O__O(self, G__1919000097__1_ any) any { var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_11; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(G__1919000097__1_) }
//line :224:1
func A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A_New() *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A { A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A{}; t.Ctor(); return t }
//line :224:1
func (t *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A) Ctor() {}
//line :224:1
func (t *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A) Invoke_O_O__O(self, G__1919000097__1_ any) any { var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_11; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(G__1919000097__1_) }
//line :224:1
func A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A_New_O(p0 any) *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A { A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A{}; t.Ctor_O(p0); return t }
//line :224:1
func (t *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A) Ctor_O(c__mspec__1740000878__auto__ any) { t.F_mspec__1740000878__auto__ = c__mspec__1740000878__auto__ }
//line :224:1
func (t *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_35; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A_New(); var tmp4 *jrt.Class; A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A_Init(); tmp4 = A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A_fn_class; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp6 = A_arbace_core_specs_alpha_A_const_38; return tmp2.Invoke_O_O__O(tmp5, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(t.F_mspec__1740000878__auto__)) }
//line :224:1
func A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A_New() *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A { A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A_Init(); t := &A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A{}; t.Ctor(); return t }
//line :224:1
func (t *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A) Ctor() {}
//line :224:1
func (t *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A) Invoke_O_O__O(self, m__1740000879__auto____1 any) any { var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_36; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp3 = A_arbace_core_specs_alpha_A_const_37; return tmp2.Invoke_O_O__O(jrt.NN(tmp3).GetRawRoot__O(), m__1740000879__auto____1) }






















func A_arbace_core_specs_alpha_quotable_A_New() *A_arbace_core_specs_alpha_quotable_A { A_arbace_core_specs_alpha_quotable_A_Init(); t := &A_arbace_core_specs_alpha_quotable_A{}; t.Ctor(); return t }
//line :247:1
func (t *A_arbace_core_specs_alpha_quotable_A) Ctor() {}
//line :247:1
func (t *A_arbace_core_specs_alpha_quotable_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, spec__2 any) any { var tmp1 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp1 = A_arbace_core_specs_alpha_A_const_77; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp3 = A_arbace_core_specs_alpha_A_const_37; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp5 = A_arbace_core_specs_alpha_A_const_78; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_core_specs_alpha_A_Init(); tmp7 = A_arbace_core_specs_alpha_A_const_79; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp9 = A_arbace_core_specs_alpha_A_const_78; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp11 = A_arbace_core_specs_alpha_A_const_80; var tmp12 any = tmp10.Invoke_O__O(tmp11.Ref()); var tmp13 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp13 = A_arbace_core_specs_alpha_A_const_78; var tmp14 any = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(spec__2); var tmp15 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp15 = A_arbace_core_specs_alpha_A_const_78; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp17 = A_arbace_core_specs_alpha_A_const_81; var tmp18 any = tmp16.Invoke_O__O(tmp17.Ref()); var tmp19 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp19 = A_arbace_core_specs_alpha_A_const_78; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp21 = A_arbace_core_specs_alpha_A_const_77; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp23 = A_arbace_core_specs_alpha_A_const_37; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp25 = A_arbace_core_specs_alpha_A_const_78; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 any; A_arbace_core_specs_alpha_A_Init(); tmp27 = A_arbace_core_specs_alpha_A_const_82; var tmp28 any = tmp26.Invoke_O__O(tmp27); var tmp29 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp29 = A_arbace_core_specs_alpha_A_const_78; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp31 = A_arbace_core_specs_alpha_A_const_83; var tmp32 any = tmp30.Invoke_O__O(tmp31.Ref()); var tmp33 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp33 = A_arbace_core_specs_alpha_A_const_78; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp35 = A_arbace_core_specs_alpha_A_const_36; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp37 = A_arbace_core_specs_alpha_A_const_84; var tmp38 any = jrt.NN(tmp37).GetRawRoot__O(); var tmp39 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp39 = A_arbace_core_specs_alpha_A_const_77; var tmp40 lang.IFn = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()); var tmp41 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp41 = A_arbace_core_specs_alpha_A_const_37; var tmp42 lang.IFn = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()); var tmp43 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp43 = A_arbace_core_specs_alpha_A_const_78; var tmp44 lang.IFn = lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()); var tmp45 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp45 = A_arbace_core_specs_alpha_A_const_77; var tmp46 lang.IFn = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()); var tmp47 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp47 = A_arbace_core_specs_alpha_A_const_37; var tmp48 lang.IFn = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()); var tmp49 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp49 = A_arbace_core_specs_alpha_A_const_78; var tmp50 lang.IFn = lang.IFn_Cast(jrt.NN(tmp49).GetRawRoot__O()); var tmp51 any; A_arbace_core_specs_alpha_A_Init(); tmp51 = A_arbace_core_specs_alpha_A_const_85; var tmp52 any = tmp50.Invoke_O__O(tmp51); var tmp53 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp53 = A_arbace_core_specs_alpha_A_const_78; var tmp54 lang.IFn = lang.IFn_Cast(jrt.NN(tmp53).GetRawRoot__O()); var tmp55 any; A_arbace_core_specs_alpha_A_Init(); tmp55 = A_arbace_core_specs_alpha_A_const_86; var tmp56 any = tmp34.Invoke_O__O(tmp36.Invoke_O_O__O(tmp38, tmp40.Invoke_O__O(tmp42.Invoke_O__O(tmp44.Invoke_O__O(tmp46.Invoke_O__O(tmp48.Invoke_O_O__O(tmp52, tmp54.Invoke_O__O(tmp55)))))))); var tmp57 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp57 = A_arbace_core_specs_alpha_A_const_78; var tmp58 lang.IFn = lang.IFn_Cast(jrt.NN(tmp57).GetRawRoot__O()); var tmp59 *lang.Keyword; A_arbace_core_specs_alpha_A_Init(); tmp59 = A_arbace_core_specs_alpha_A_const_80; var tmp60 any = tmp58.Invoke_O__O(tmp59.Ref()); var tmp61 *lang.Var; A_arbace_core_specs_alpha_A_Init(); tmp61 = A_arbace_core_specs_alpha_A_const_78; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O_O_O__O(tmp8, tmp12, tmp14, tmp18, tmp20.Invoke_O__O(tmp22.Invoke_O__O(tmp24.Invoke_O_O_O_O_O__O(tmp28, tmp32, tmp56, tmp60, lang.IFn_Cast(jrt.NN(tmp61).GetRawRoot__O()).Invoke_O__O(spec__2)))))) }



























































































type A_arbace_core_specs_alpha_A struct{ jrt.Object }

var A_arbace_core_specs_alpha_A_const_0 *lang.Var

var A_arbace_core_specs_alpha_A_const_1 *lang.Var

var A_arbace_core_specs_alpha_A_const_2 any

var A_arbace_core_specs_alpha_A_const_3 any

var A_arbace_core_specs_alpha_A_const_4 *lang.Var

var A_arbace_core_specs_alpha_A_const_5 *lang.Var

var A_arbace_core_specs_alpha_A_const_6 *lang.Var

var A_arbace_core_specs_alpha_A_const_7 any

var A_arbace_core_specs_alpha_A_const_8 *lang.Var

var A_arbace_core_specs_alpha_A_const_9 *lang.Var

var A_arbace_core_specs_alpha_A_const_10 any

var A_arbace_core_specs_alpha_A_const_11 *lang.Var

var A_arbace_core_specs_alpha_A_const_12 any

var A_arbace_core_specs_alpha_A_const_13 *lang.Var

var A_arbace_core_specs_alpha_A_const_14 *lang.Var

var A_arbace_core_specs_alpha_A_const_15 *lang.Var

var A_arbace_core_specs_alpha_A_const_16 *lang.Var

var A_arbace_core_specs_alpha_A_const_17 *lang.Var

var A_arbace_core_specs_alpha_A_const_18 *lang.Keyword

var A_arbace_core_specs_alpha_A_const_19 *lang.Keyword

var A_arbace_core_specs_alpha_A_const_20 any

var A_arbace_core_specs_alpha_A_const_21 *lang.Keyword

var A_arbace_core_specs_alpha_A_const_22 *lang.Keyword

var A_arbace_core_specs_alpha_A_const_23 *lang.Keyword

var A_arbace_core_specs_alpha_A_const_24 *lang.Keyword

var A_arbace_core_specs_alpha_A_const_25 any

var A_arbace_core_specs_alpha_A_const_26 *lang.Keyword

var A_arbace_core_specs_alpha_A_const_27 *lang.Keyword

var A_arbace_core_specs_alpha_A_const_28 *lang.Keyword

var A_arbace_core_specs_alpha_A_const_29 *lang.Keyword

var A_arbace_core_specs_alpha_A_const_30 any

var A_arbace_core_specs_alpha_A_const_31 *lang.Keyword

var A_arbace_core_specs_alpha_A_const_32 any

var A_arbace_core_specs_alpha_A_const_33 *lang.Keyword

var A_arbace_core_specs_alpha_A_const_34 *lang.Var

var A_arbace_core_specs_alpha_A_const_35 *lang.Var

var A_arbace_core_specs_alpha_A_const_36 *lang.Var

var A_arbace_core_specs_alpha_A_const_37 *lang.Var

var A_arbace_core_specs_alpha_A_const_38 *lang.Var

var A_arbace_core_specs_alpha_A_const_39 *lang.Var

var A_arbace_core_specs_alpha_A_const_40 any

var A_arbace_core_specs_alpha_A_const_41 any

var A_arbace_core_specs_alpha_A_const_42 any

var A_arbace_core_specs_alpha_A_const_43 *lang.Var

var A_arbace_core_specs_alpha_A_const_44 any

var A_arbace_core_specs_alpha_A_const_45 any

var A_arbace_core_specs_alpha_A_const_46 *lang.Var

var A_arbace_core_specs_alpha_A_const_47 *lang.Var

var A_arbace_core_specs_alpha_A_const_48 *lang.Keyword

var A_arbace_core_specs_alpha_A_const_49 any

var A_arbace_core_specs_alpha_A_const_50 any

var A_arbace_core_specs_alpha_A_const_51 any

var A_arbace_core_specs_alpha_A_const_52 any

var A_arbace_core_specs_alpha_A_const_53 any

var A_arbace_core_specs_alpha_A_const_54 any

var A_arbace_core_specs_alpha_A_const_55 any

var A_arbace_core_specs_alpha_A_const_56 any

var A_arbace_core_specs_alpha_A_const_57 any

var A_arbace_core_specs_alpha_A_const_58 any

var A_arbace_core_specs_alpha_A_const_59 any

var A_arbace_core_specs_alpha_A_const_60 any

var A_arbace_core_specs_alpha_A_const_61 any

var A_arbace_core_specs_alpha_A_const_62 any

var A_arbace_core_specs_alpha_A_const_63 any

var A_arbace_core_specs_alpha_A_const_64 any

var A_arbace_core_specs_alpha_A_const_65 any

var A_arbace_core_specs_alpha_A_const_66 any

var A_arbace_core_specs_alpha_A_const_67 *lang.Var

var A_arbace_core_specs_alpha_A_const_68 any

var A_arbace_core_specs_alpha_A_const_69 any

var A_arbace_core_specs_alpha_A_const_70 any

var A_arbace_core_specs_alpha_A_const_71 any

var A_arbace_core_specs_alpha_A_const_72 any

var A_arbace_core_specs_alpha_A_const_73 any

var A_arbace_core_specs_alpha_A_const_74 any

var A_arbace_core_specs_alpha_A_const_75 any

var A_arbace_core_specs_alpha_A_const_76 any

var A_arbace_core_specs_alpha_A_const_77 *lang.Var

var A_arbace_core_specs_alpha_A_const_78 *lang.Var

var A_arbace_core_specs_alpha_A_const_79 any

var A_arbace_core_specs_alpha_A_const_80 *lang.Keyword

var A_arbace_core_specs_alpha_A_const_81 *lang.Keyword

var A_arbace_core_specs_alpha_A_const_82 any

var A_arbace_core_specs_alpha_A_const_83 *lang.Keyword

var A_arbace_core_specs_alpha_A_const_84 *lang.Var

var A_arbace_core_specs_alpha_A_const_85 any

var A_arbace_core_specs_alpha_A_const_86 any

var A_arbace_core_specs_alpha_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_A_Init() { if !A_arbace_core_specs_alpha_A_init.Done() { A_arbace_core_specs_alpha_A_init.Run(A_arbace_core_specs_alpha_A_clinit) } }

func A_arbace_core_specs_alpha_A_clinit() { A_arbace_core_specs_alpha_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_core_specs_alpha_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_core_specs_alpha_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_core_specs_alpha_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_core_specs_alpha_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_6); A_arbace_core_specs_alpha_A_const_5 = lang.RT_Var_String_String__Var(Lit_0, Lit_7); A_arbace_core_specs_alpha_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_8); A_arbace_core_specs_alpha_A_const_7 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_9).Ref(); A_arbace_core_specs_alpha_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_10); A_arbace_core_specs_alpha_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_11); A_arbace_core_specs_alpha_A_const_10 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_12).Ref(); A_arbace_core_specs_alpha_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_13); A_arbace_core_specs_alpha_A_const_12 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.ConstRefArray("[0,4,s4:symss4:keyss5:syms!s5:keys!", []*jrt.Class{jrt.Object_class})).Ref(); A_arbace_core_specs_alpha_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_14); A_arbace_core_specs_alpha_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_15); A_arbace_core_specs_alpha_A_const_15 = lang.RT_Var_String_String__Var(Lit_0, Lit_16); A_arbace_core_specs_alpha_A_const_16 = lang.RT_Var_String_String__Var(Lit_3, Lit_17); A_arbace_core_specs_alpha_A_const_17 = lang.RT_Var_String_String__Var(Lit_3, Lit_18); A_arbace_core_specs_alpha_A_const_18 = lang.RT_Keyword_String_String__Keyword(nil, Lit_19); A_arbace_core_specs_alpha_A_const_19 = lang.RT_Keyword_String_String__Keyword(nil, Lit_20); A_arbace_core_specs_alpha_A_const_20 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_21).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_22).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_23).Ref()); A_arbace_core_specs_alpha_A_const_21 = lang.RT_Keyword_String_String__Keyword(nil, Lit_24); A_arbace_core_specs_alpha_A_const_22 = lang.RT_Keyword_String_String__Keyword(nil, Lit_25); A_arbace_core_specs_alpha_A_const_23 = lang.RT_Keyword_String_String__Keyword(nil, Lit_26); A_arbace_core_specs_alpha_A_const_24 = lang.RT_Keyword_String_String__Keyword(nil, Lit_27); A_arbace_core_specs_alpha_A_const_25 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_23).Ref()); A_arbace_core_specs_alpha_A_const_26 = lang.RT_Keyword_String_String__Keyword(nil, Lit_28); A_arbace_core_specs_alpha_A_const_27 = lang.RT_Keyword_String_String__Keyword(nil, Lit_29); A_arbace_core_specs_alpha_A_const_28 = lang.RT_Keyword_String_String__Keyword(nil, Lit_30); A_arbace_core_specs_alpha_A_const_29 = lang.RT_Keyword_String_String__Keyword(nil, Lit_31); A_arbace_core_specs_alpha_A_const_30 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_21).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_22).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_23).Ref()); A_arbace_core_specs_alpha_A_const_31 = lang.RT_Keyword_String_String__Keyword(nil, Lit_32); A_arbace_core_specs_alpha_A_const_32 = lang.Tuple_Create_O__IPersistentVector(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_33).Ref(), lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_34).Ref()), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_13).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_34).Ref()))))))); A_arbace_core_specs_alpha_A_const_33 = lang.RT_Keyword_String_String__Keyword(nil, Lit_35); A_arbace_core_specs_alpha_A_const_34 = lang.RT_Var_String_String__Var(Lit_3, Lit_36); A_arbace_core_specs_alpha_A_const_35 = lang.RT_Var_String_String__Var(Lit_37, Lit_38); A_arbace_core_specs_alpha_A_const_36 = lang.RT_Var_String_String__Var(Lit_0, Lit_39); A_arbace_core_specs_alpha_A_const_37 = lang.RT_Var_String_String__Var(Lit_0, Lit_40); A_arbace_core_specs_alpha_A_const_38 = lang.RT_Var_String_String__Var(Lit_3, Lit_41); A_arbace_core_specs_alpha_A_const_39 = lang.RT_Var_String_String__Var(Lit_3, Lit_42); A_arbace_core_specs_alpha_A_const_40 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_3, Lit_43).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_3, Lit_44).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_3, Lit_45).Ref(), lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_46).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_3, Lit_47).Ref(), lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_48).Ref())))))); A_arbace_core_specs_alpha_A_const_41 = lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(Lit_3, Lit_49).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_50).Ref()); A_arbace_core_specs_alpha_A_const_42 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_3, Lit_44).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_3, Lit_45).Ref(), lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_46).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_3, Lit_47).Ref(), lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_48).Ref()))); A_arbace_core_specs_alpha_A_const_43 = lang.RT_Var_String_String__Var(Lit_3, Lit_51); A_arbace_core_specs_alpha_A_const_44 = lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(Lit_3, Lit_45).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_3, Lit_47).Ref()); A_arbace_core_specs_alpha_A_const_45 = lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_46).Ref(), lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_48).Ref()); A_arbace_core_specs_alpha_A_const_46 = lang.RT_Var_String_String__Var(Lit_0, Lit_46); A_arbace_core_specs_alpha_A_const_47 = lang.RT_Var_String_String__Var(Lit_0, Lit_48); A_arbace_core_specs_alpha_A_const_48 = lang.RT_Keyword_String_String__Keyword(Lit_3, Lit_49); A_arbace_core_specs_alpha_A_const_49 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_4).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_2).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_52).Ref()); A_arbace_core_specs_alpha_A_const_50 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_2).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_52).Ref()); A_arbace_core_specs_alpha_A_const_51 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_4).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_2).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_52).Ref()); A_arbace_core_specs_alpha_A_const_52 = lang.Tuple_Create_O__IPersistentVector(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_33).Ref(), lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_34).Ref()), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_13).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_34).Ref()))))))); A_arbace_core_specs_alpha_A_const_53 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_3, Lit_43).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_3, Lit_44).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_3, Lit_45).Ref(), lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_46).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_3, Lit_47).Ref(), lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_48).Ref())))))); A_arbace_core_specs_alpha_A_const_54 = lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(Lit_3, Lit_49).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_50).Ref()); A_arbace_core_specs_alpha_A_const_55 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_3, Lit_44).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_3, Lit_45).Ref(), lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_46).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_3, Lit_47).Ref(), lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_48).Ref()))); A_arbace_core_specs_alpha_A_const_56 = lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(Lit_3, Lit_45).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_3, Lit_47).Ref()); A_arbace_core_specs_alpha_A_const_57 = lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_46).Ref(), lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_48).Ref()); A_arbace_core_specs_alpha_A_const_58 = lang.Tuple_Create_O_O_O_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_4).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_2).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_21).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_22).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_23).Ref()); A_arbace_core_specs_alpha_A_const_59 = lang.Tuple_Create_O_O_O_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_2).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_23).Ref()); A_arbace_core_specs_alpha_A_const_60 = lang.Tuple_Create_O_O_O_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_4).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_2).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_21).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_22).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_23).Ref()); A_arbace_core_specs_alpha_A_const_61 = lang.Tuple_Create_O__IPersistentVector(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_33).Ref(), lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_34).Ref()), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_13).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_34).Ref()))))))); A_arbace_core_specs_alpha_A_const_62 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_3, Lit_43).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_3, Lit_44).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_3, Lit_45).Ref(), lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_46).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_3, Lit_47).Ref(), lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_48).Ref())))))); A_arbace_core_specs_alpha_A_const_63 = lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(Lit_3, Lit_49).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_50).Ref()); A_arbace_core_specs_alpha_A_const_64 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_3, Lit_44).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_3, Lit_45).Ref(), lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_46).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_3, Lit_47).Ref(), lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_48).Ref()))); A_arbace_core_specs_alpha_A_const_65 = lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(Lit_3, Lit_45).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_3, Lit_47).Ref()); A_arbace_core_specs_alpha_A_const_66 = lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_46).Ref(), lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_48).Ref()); A_arbace_core_specs_alpha_A_const_67 = lang.RT_Var_String_String__Var(Lit_0, Lit_53); A_arbace_core_specs_alpha_A_const_68 = lang.RT_Vector_O1__IPersistentVector(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_14).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_54).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_55).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_56).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_57).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_58).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_59).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_60).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_61).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_62).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_63).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_64).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_65).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_66).Ref())); A_arbace_core_specs_alpha_A_const_69 = lang.RT_Vector_O1__IPersistentVector(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_54).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_56).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_57).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_58).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_59).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_60).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_61).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_62).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_63).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_64).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_65).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_66).Ref())); A_arbace_core_specs_alpha_A_const_70 = lang.RT_Vector_O1__IPersistentVector(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_14).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_54).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_55).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_56).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_57).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_58).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_59).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_60).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_61).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_62).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_63).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_64).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_65).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_9, Lit_66).Ref())); A_arbace_core_specs_alpha_A_const_71 = lang.Tuple_Create_O__IPersistentVector(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_33).Ref(), lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_34).Ref()), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_13).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_34).Ref()))))))); A_arbace_core_specs_alpha_A_const_72 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_3, Lit_43).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_3, Lit_44).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_3, Lit_45).Ref(), lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_46).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_3, Lit_47).Ref(), lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_48).Ref())))))); A_arbace_core_specs_alpha_A_const_73 = lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(Lit_3, Lit_49).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_50).Ref()); A_arbace_core_specs_alpha_A_const_74 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_3, Lit_44).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_3, Lit_45).Ref(), lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_46).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_3, Lit_47).Ref(), lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_48).Ref()))); A_arbace_core_specs_alpha_A_const_75 = lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(Lit_3, Lit_45).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_3, Lit_47).Ref()); A_arbace_core_specs_alpha_A_const_76 = lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_46).Ref(), lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_48).Ref()); A_arbace_core_specs_alpha_A_const_77 = lang.RT_Var_String_String__Var(Lit_0, Lit_67); A_arbace_core_specs_alpha_A_const_78 = lang.RT_Var_String_String__Var(Lit_0, Lit_68); A_arbace_core_specs_alpha_A_const_79 = lang.Symbol_Intern_String_String__Symbol(Lit_3, Lit_69).Ref(); A_arbace_core_specs_alpha_A_const_80 = lang.RT_Keyword_String_String__Keyword(nil, Lit_70); A_arbace_core_specs_alpha_A_const_81 = lang.RT_Keyword_String_String__Keyword(nil, Lit_71); A_arbace_core_specs_alpha_A_const_82 = lang.Symbol_Intern_String_String__Symbol(Lit_3, Lit_44).Ref(); A_arbace_core_specs_alpha_A_const_83 = lang.RT_Keyword_String_String__Keyword(nil, Lit_72); A_arbace_core_specs_alpha_A_const_84 = lang.RT_Var_String_String__Var(Lit_0, Lit_73); A_arbace_core_specs_alpha_A_const_85 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_72).Ref(); A_arbace_core_specs_alpha_A_const_86 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_72).Ref() }

func A_arbace_core_specs_alpha_A_New() *A_arbace_core_specs_alpha_A { A_arbace_core_specs_alpha_A_Init(); t := &A_arbace_core_specs_alpha_A{}; t.Ctor(); return t }

func (t *A_arbace_core_specs_alpha_A) Ctor() {}

func (t *A_arbace_core_specs_alpha_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_A_class }

func (t *A_arbace_core_specs_alpha_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_A); return ok }

func A_arbace_core_specs_alpha_A_Cast(x any) *A_arbace_core_specs_alpha_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_A_class)) }; return v }



type A_arbace_core_specs_alpha_eval1919000002_A struct{ jrt.Object }

func A_arbace_core_specs_alpha_eval1919000002_A_New() *A_arbace_core_specs_alpha_eval1919000002_A { t := &A_arbace_core_specs_alpha_eval1919000002_A{}; t.Ctor(); return t }

func (t *A_arbace_core_specs_alpha_eval1919000002_A) Ctor() {}

func (t *A_arbace_core_specs_alpha_eval1919000002_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_eval1919000002_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_eval1919000002_A_class }

func (t *A_arbace_core_specs_alpha_eval1919000002_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_eval1919000002_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_eval1919000002_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_eval1919000002_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_eval1919000002_A); return ok }

func A_arbace_core_specs_alpha_eval1919000002_A_Cast(x any) *A_arbace_core_specs_alpha_eval1919000002_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_eval1919000002_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_eval1919000002_A_class)) }; return v }



type A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A) Is_Compiler_AOTF0() {}

var A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A_Init() { if !A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A_init.Done() { A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A_init.Run(A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A_clinit) } }

func A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A_clinit() { A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_74, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A_class }

func (t *A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A); return ok }

func A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A_Cast(x any) *A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A_class)) }; return v }



type A_arbace_core_specs_alpha_eval1919000006_A struct{ jrt.Object }

func A_arbace_core_specs_alpha_eval1919000006_A_New() *A_arbace_core_specs_alpha_eval1919000006_A { t := &A_arbace_core_specs_alpha_eval1919000006_A{}; t.Ctor(); return t }

func (t *A_arbace_core_specs_alpha_eval1919000006_A) Ctor() {}

func (t *A_arbace_core_specs_alpha_eval1919000006_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_eval1919000006_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_eval1919000006_A_class }

func (t *A_arbace_core_specs_alpha_eval1919000006_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_eval1919000006_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_eval1919000006_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_eval1919000006_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_eval1919000006_A); return ok }

func A_arbace_core_specs_alpha_eval1919000006_A_Cast(x any) *A_arbace_core_specs_alpha_eval1919000006_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_eval1919000006_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_eval1919000006_A_class)) }; return v }



type A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A) Is_Compiler_AOTF0() {}

var A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A_Init() { if !A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A_init.Done() { A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A_init.Run(A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A_clinit) } }

func A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A_clinit() { A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_75, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A_class }

func (t *A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A); return ok }

func A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A_Cast(x any) *A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A_class)) }; return v }



type A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A_init jrt.ClassInit

func A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A_Init() { if !A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A_init.Done() { A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A_init.Run(A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A_clinit) } }

func A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A_clinit() { A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_76, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A_class }

func (t *A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A); return ok }

func A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A_Cast(x any) *A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000011_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_fn__1919000011_A) Is_Compiler_AOTF1() {}

var A_arbace_core_specs_alpha_fn__1919000011_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000011_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000011_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000011_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000011_A_init.Run(A_arbace_core_specs_alpha_fn__1919000011_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000011_A_clinit() { A_arbace_core_specs_alpha_fn__1919000011_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_77, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000011_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000011_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000011_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000011_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000011_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000011_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000011_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000011_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000011_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000011_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000011_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000011_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000014_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_fn__1919000014_A) Is_Compiler_AOTF1() {}

var A_arbace_core_specs_alpha_fn__1919000014_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000014_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000014_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000014_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000014_A_init.Run(A_arbace_core_specs_alpha_fn__1919000014_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000014_A_clinit() { A_arbace_core_specs_alpha_fn__1919000014_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_78, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000014_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000014_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000014_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000014_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000014_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000014_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000014_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000014_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000014_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000014_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000014_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000014_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000016_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_fn__1919000016_A) Is_Compiler_AOTF1() {}

var A_arbace_core_specs_alpha_fn__1919000016_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000016_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000016_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000016_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000016_A_init.Run(A_arbace_core_specs_alpha_fn__1919000016_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000016_A_clinit() { A_arbace_core_specs_alpha_fn__1919000016_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_79, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000016_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000016_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000016_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000016_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000016_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000016_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000016_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000016_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000016_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000016_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000016_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000016_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000019_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_fn__1919000019_A) Is_Compiler_AOTF1() {}

var A_arbace_core_specs_alpha_fn__1919000019_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000019_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000019_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000019_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000019_A_init.Run(A_arbace_core_specs_alpha_fn__1919000019_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000019_A_clinit() { A_arbace_core_specs_alpha_fn__1919000019_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_80, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000019_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000019_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000019_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000019_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000019_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000019_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000019_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000019_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000019_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000019_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000019_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000019_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000022_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_fn__1919000022_A) Is_Compiler_AOTF1() {}

var A_arbace_core_specs_alpha_fn__1919000022_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000022_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000022_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000022_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000022_A_init.Run(A_arbace_core_specs_alpha_fn__1919000022_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000022_A_clinit() { A_arbace_core_specs_alpha_fn__1919000022_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_81, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000022_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000022_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000022_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000022_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000022_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000022_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000022_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000022_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000022_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000022_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000022_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000022_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000026_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_fn__1919000026_A) Is_Compiler_AOTF1() {}

var A_arbace_core_specs_alpha_fn__1919000026_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000026_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000026_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000026_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000026_A_init.Run(A_arbace_core_specs_alpha_fn__1919000026_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000026_A_clinit() { A_arbace_core_specs_alpha_fn__1919000026_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_82, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000026_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000026_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000026_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000026_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000026_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000026_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000026_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000026_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000026_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000026_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000026_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000026_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000029_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_fn__1919000029_A) Is_Compiler_AOTF1() {}

var A_arbace_core_specs_alpha_fn__1919000029_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000029_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000029_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000029_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000029_A_init.Run(A_arbace_core_specs_alpha_fn__1919000029_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000029_A_clinit() { A_arbace_core_specs_alpha_fn__1919000029_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_83, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000029_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000029_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000029_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000029_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000029_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000029_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000029_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000029_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000029_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000029_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000029_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000029_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000032_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_fn__1919000032_A) Is_Compiler_AOTF2() {}

var A_arbace_core_specs_alpha_fn__1919000032_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000032_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000032_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000032_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000032_A_init.Run(A_arbace_core_specs_alpha_fn__1919000032_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000032_A_clinit() { A_arbace_core_specs_alpha_fn__1919000032_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_84, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000032_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000032_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000032_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000032_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000032_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000032_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000032_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000032_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000032_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000032_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000032_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000032_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000034_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_fn__1919000034_A) Is_Compiler_AOTF1() {}

var A_arbace_core_specs_alpha_fn__1919000034_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000034_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000034_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000034_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000034_A_init.Run(A_arbace_core_specs_alpha_fn__1919000034_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000034_A_clinit() { A_arbace_core_specs_alpha_fn__1919000034_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_85, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000034_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000034_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000034_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000034_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000034_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000034_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000034_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000034_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000034_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000034_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000034_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000034_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000036_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_fn__1919000036_A) Is_Compiler_AOTF0() {}

var A_arbace_core_specs_alpha_fn__1919000036_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000036_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000036_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000036_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000036_A_init.Run(A_arbace_core_specs_alpha_fn__1919000036_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000036_A_clinit() { A_arbace_core_specs_alpha_fn__1919000036_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_86, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000036_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000036_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000036_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000036_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000036_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000036_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000036_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000036_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000036_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000036_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000036_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000036_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A) Is_Compiler_AOTF1() {}

var A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A_init.Run(A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A_clinit() { A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_87, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A) Is_Compiler_AOTF1() {}

var A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A_init.Run(A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A_clinit() { A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_88, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A struct{ jrt.Object; F_mspec__1740000878__auto__ any }

func (t *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A) Is_Compiler_AOTF0() {}

var A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A_init.Run(A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A_clinit() { A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_89, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A) Is_Compiler_AOTF1() {}

var A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A_init.Run(A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A_clinit() { A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_90, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000048_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_fn__1919000048_A) Is_Compiler_AOTF1() {}

var A_arbace_core_specs_alpha_fn__1919000048_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000048_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000048_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000048_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000048_A_init.Run(A_arbace_core_specs_alpha_fn__1919000048_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000048_A_clinit() { A_arbace_core_specs_alpha_fn__1919000048_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_91, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000048_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000048_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000048_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000048_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000048_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000048_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000048_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000048_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000048_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000048_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000048_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000048_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000050_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_fn__1919000050_A) Is_Compiler_AOTF0() {}

var A_arbace_core_specs_alpha_fn__1919000050_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000050_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000050_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000050_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000050_A_init.Run(A_arbace_core_specs_alpha_fn__1919000050_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000050_A_clinit() { A_arbace_core_specs_alpha_fn__1919000050_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_92, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000050_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000050_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000050_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000050_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000050_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000050_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000050_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000050_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000050_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000050_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000050_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000050_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A) Is_Compiler_AOTF1() {}

var A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A_init.Run(A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A_clinit() { A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_93, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A) Is_Compiler_AOTF1() {}

var A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A_init.Run(A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A_clinit() { A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_94, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A struct{ jrt.Object; F_mspec__1740000878__auto__ any }

func (t *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A) Is_Compiler_AOTF0() {}

var A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A_init.Run(A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A_clinit() { A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_95, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A) Is_Compiler_AOTF1() {}

var A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A_init.Run(A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A_clinit() { A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_96, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000061_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_fn__1919000061_A) Is_Compiler_AOTF0() {}

var A_arbace_core_specs_alpha_fn__1919000061_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000061_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000061_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000061_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000061_A_init.Run(A_arbace_core_specs_alpha_fn__1919000061_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000061_A_clinit() { A_arbace_core_specs_alpha_fn__1919000061_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_97, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000061_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000061_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000061_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000061_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000061_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000061_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000061_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000061_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000061_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000061_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000061_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000061_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A) Is_Compiler_AOTF1() {}

var A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A_init.Run(A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A_clinit() { A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_98, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A) Is_Compiler_AOTF1() {}

var A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A_init.Run(A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A_clinit() { A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_99, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A struct{ jrt.Object; F_mspec__1740000878__auto__ any }

func (t *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A) Is_Compiler_AOTF0() {}

var A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A_init.Run(A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A_clinit() { A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_100, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A) Is_Compiler_AOTF1() {}

var A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A_init.Run(A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A_clinit() { A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_101, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000073_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_fn__1919000073_A) Is_Compiler_AOTF1() {}

var A_arbace_core_specs_alpha_fn__1919000073_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000073_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000073_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000073_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000073_A_init.Run(A_arbace_core_specs_alpha_fn__1919000073_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000073_A_clinit() { A_arbace_core_specs_alpha_fn__1919000073_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_102, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000073_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000073_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000073_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000073_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000073_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000073_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000073_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000073_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000073_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000073_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000073_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000073_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000076_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_fn__1919000076_A) Is_Compiler_AOTF1() {}

var A_arbace_core_specs_alpha_fn__1919000076_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000076_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000076_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000076_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000076_A_init.Run(A_arbace_core_specs_alpha_fn__1919000076_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000076_A_clinit() { A_arbace_core_specs_alpha_fn__1919000076_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_103, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000076_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000076_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000076_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000076_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000076_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000076_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000076_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000076_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000076_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000076_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000076_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000076_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000079_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_fn__1919000079_A) Is_Compiler_AOTF2() {}

var A_arbace_core_specs_alpha_fn__1919000079_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000079_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000079_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000079_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000079_A_init.Run(A_arbace_core_specs_alpha_fn__1919000079_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000079_A_clinit() { A_arbace_core_specs_alpha_fn__1919000079_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_104, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000079_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000079_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000079_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000079_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000079_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000079_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000079_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000079_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000079_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000079_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000079_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000079_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000081_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_fn__1919000081_A) Is_Compiler_AOTF1() {}

var A_arbace_core_specs_alpha_fn__1919000081_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000081_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000081_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000081_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000081_A_init.Run(A_arbace_core_specs_alpha_fn__1919000081_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000081_A_clinit() { A_arbace_core_specs_alpha_fn__1919000081_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_105, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000081_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000081_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000081_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000081_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000081_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000081_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000081_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000081_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000081_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000081_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000081_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000081_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000084_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_fn__1919000084_A) Is_Compiler_AOTF1() {}

var A_arbace_core_specs_alpha_fn__1919000084_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000084_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000084_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000084_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000084_A_init.Run(A_arbace_core_specs_alpha_fn__1919000084_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000084_A_clinit() { A_arbace_core_specs_alpha_fn__1919000084_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_106, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000084_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000084_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000084_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000084_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000084_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000084_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000084_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000084_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000084_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000084_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000084_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000084_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000087_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_fn__1919000087_A) Is_Compiler_AOTF1() {}

var A_arbace_core_specs_alpha_fn__1919000087_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000087_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000087_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000087_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000087_A_init.Run(A_arbace_core_specs_alpha_fn__1919000087_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000087_A_clinit() { A_arbace_core_specs_alpha_fn__1919000087_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_107, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000087_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000087_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000087_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000087_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000087_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000087_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000087_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000087_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000087_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000087_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000087_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000087_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000089_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_fn__1919000089_A) Is_Compiler_AOTF1() {}

var A_arbace_core_specs_alpha_fn__1919000089_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000089_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000089_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000089_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000089_A_init.Run(A_arbace_core_specs_alpha_fn__1919000089_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000089_A_clinit() { A_arbace_core_specs_alpha_fn__1919000089_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_108, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000089_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000089_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000089_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000089_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000089_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000089_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000089_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000089_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000089_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000089_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000089_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000089_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000092_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_fn__1919000092_A) Is_Compiler_AOTF2() {}

var A_arbace_core_specs_alpha_fn__1919000092_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000092_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000092_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000092_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000092_A_init.Run(A_arbace_core_specs_alpha_fn__1919000092_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000092_A_clinit() { A_arbace_core_specs_alpha_fn__1919000092_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_109, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000092_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000092_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000092_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000092_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000092_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000092_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000092_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000092_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000092_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000092_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000092_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000092_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000094_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_fn__1919000094_A) Is_Compiler_AOTF1() {}

var A_arbace_core_specs_alpha_fn__1919000094_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000094_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000094_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000094_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000094_A_init.Run(A_arbace_core_specs_alpha_fn__1919000094_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000094_A_clinit() { A_arbace_core_specs_alpha_fn__1919000094_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_110, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000094_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000094_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000094_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000094_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000094_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000094_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000094_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000094_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000094_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000094_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000094_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000094_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000096_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_fn__1919000096_A) Is_Compiler_AOTF0() {}

var A_arbace_core_specs_alpha_fn__1919000096_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000096_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000096_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000096_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000096_A_init.Run(A_arbace_core_specs_alpha_fn__1919000096_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000096_A_clinit() { A_arbace_core_specs_alpha_fn__1919000096_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_111, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000096_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000096_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000096_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000096_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000096_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000096_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000096_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000096_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000096_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000096_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000096_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000096_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A) Is_Compiler_AOTF1() {}

var A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A_init.Run(A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A_clinit() { A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_112, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A) Is_Compiler_AOTF1() {}

var A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A_init.Run(A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A_clinit() { A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_113, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A struct{ jrt.Object; F_mspec__1740000878__auto__ any }

func (t *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A) Is_Compiler_AOTF0() {}

var A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A_init.Run(A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A_clinit() { A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_114, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A_class)) }; return v }



type A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A) Is_Compiler_AOTF1() {}

var A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A_Init() { if !A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A_init.Done() { A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A_init.Run(A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A_clinit) } }

func A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A_clinit() { A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_115, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A_class }

func (t *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A); return ok }

func A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A_Cast(x any) *A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A_class)) }; return v }



type A_arbace_core_specs_alpha_quotable_A struct{ jrt.Object }

func (t *A_arbace_core_specs_alpha_quotable_A) Is_Compiler_AOTF3() {}

var A_arbace_core_specs_alpha_quotable_A_fn_class *jrt.Class

var A_arbace_core_specs_alpha_quotable_A_init jrt.ClassInit

func A_arbace_core_specs_alpha_quotable_A_Init() { if !A_arbace_core_specs_alpha_quotable_A_init.Done() { A_arbace_core_specs_alpha_quotable_A_init.Run(A_arbace_core_specs_alpha_quotable_A_clinit) } }

func A_arbace_core_specs_alpha_quotable_A_clinit() { A_arbace_core_specs_alpha_quotable_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_116, lang.Compiler_AOTFn_class) }

func (t *A_arbace_core_specs_alpha_quotable_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_specs_alpha_quotable_A) GetClass__Class() *jrt.Class { return A_arbace_core_specs_alpha_quotable_A_class }

func (t *A_arbace_core_specs_alpha_quotable_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_specs_alpha_quotable_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_specs_alpha_quotable_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_specs_alpha_quotable_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_specs_alpha_quotable_A); return ok }

func A_arbace_core_specs_alpha_quotable_A_Cast(x any) *A_arbace_core_specs_alpha_quotable_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_specs_alpha_quotable_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_specs_alpha_quotable_A_class)) }; return v }
