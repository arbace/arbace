//line j2g_classes.ae:1
package aot_arbace_core_specs_alpha

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A_class, Name: "arbace.core.specs.alpha$eval1919000002$loading__1927001464__auto____1919000003", Modifiers: 25, Simple: "loading__1927001464__auto____1919000003", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_eval1919000002_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A_class, Name: "arbace.core.specs.alpha$eval1919000006$fn__1919000007", Modifiers: 25, Simple: "fn__1919000007", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_eval1919000006_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A_class, Name: "arbace.core.specs.alpha$even_number_of_forms_QMARK_", Modifiers: 25, Simple: "even_number_of_forms_QMARK_", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000011_A_class, Name: "arbace.core.specs.alpha$fn__1919000011", Modifiers: 25, Simple: "fn__1919000011", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000011_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000014_A_class, Name: "arbace.core.specs.alpha$fn__1919000014", Modifiers: 25, Simple: "fn__1919000014", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000014_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000016_A_class, Name: "arbace.core.specs.alpha$fn__1919000016", Modifiers: 25, Simple: "fn__1919000016", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000016_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000019_A_class, Name: "arbace.core.specs.alpha$fn__1919000019", Modifiers: 25, Simple: "fn__1919000019", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000019_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000022_A_class, Name: "arbace.core.specs.alpha$fn__1919000022", Modifiers: 25, Simple: "fn__1919000022", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000022_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000026_A_class, Name: "arbace.core.specs.alpha$fn__1919000026", Modifiers: 25, Simple: "fn__1919000026", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000026_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000029_A_class, Name: "arbace.core.specs.alpha$fn__1919000029", Modifiers: 25, Simple: "fn__1919000029", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000029_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000032_A_class, Name: "arbace.core.specs.alpha$fn__1919000032", Modifiers: 25, Simple: "fn__1919000032", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000032_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000034_A_class, Name: "arbace.core.specs.alpha$fn__1919000034", Modifiers: 25, Simple: "fn__1919000034", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000034_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000036_A_class, Name: "arbace.core.specs.alpha$fn__1919000036", Modifiers: 25, Simple: "fn__1919000036", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000036_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A_class, Name: "arbace.core.specs.alpha$fn__1919000036$fn__1919000038", Modifiers: 25, Simple: "fn__1919000038", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_fn__1919000036_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A_class, Name: "arbace.core.specs.alpha$fn__1919000036$fn__1919000040", Modifiers: 25, Simple: "fn__1919000040", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_fn__1919000036_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A_class, Name: "arbace.core.specs.alpha$fn__1919000036$fn__1919000042", Modifiers: 25, Simple: "fn__1919000042", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_fn__1919000036_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A_class, Name: "arbace.core.specs.alpha$fn__1919000036$fn__1919000042$fn__1919000043", Modifiers: 25, Simple: "fn__1919000043", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000048_A_class, Name: "arbace.core.specs.alpha$fn__1919000048", Modifiers: 25, Simple: "fn__1919000048", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000048_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000050_A_class, Name: "arbace.core.specs.alpha$fn__1919000050", Modifiers: 25, Simple: "fn__1919000050", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000050_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A_class, Name: "arbace.core.specs.alpha$fn__1919000050$fn__1919000052", Modifiers: 25, Simple: "fn__1919000052", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_fn__1919000050_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A_class, Name: "arbace.core.specs.alpha$fn__1919000050$fn__1919000054", Modifiers: 25, Simple: "fn__1919000054", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_fn__1919000050_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A_class, Name: "arbace.core.specs.alpha$fn__1919000050$fn__1919000056", Modifiers: 25, Simple: "fn__1919000056", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_fn__1919000050_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A_class, Name: "arbace.core.specs.alpha$fn__1919000050$fn__1919000056$fn__1919000057", Modifiers: 25, Simple: "fn__1919000057", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000061_A_class, Name: "arbace.core.specs.alpha$fn__1919000061", Modifiers: 25, Simple: "fn__1919000061", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000061_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A_class, Name: "arbace.core.specs.alpha$fn__1919000061$fn__1919000063", Modifiers: 25, Simple: "fn__1919000063", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_fn__1919000061_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A_class, Name: "arbace.core.specs.alpha$fn__1919000061$fn__1919000065", Modifiers: 25, Simple: "fn__1919000065", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_fn__1919000061_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A_class, Name: "arbace.core.specs.alpha$fn__1919000061$fn__1919000067", Modifiers: 25, Simple: "fn__1919000067", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_fn__1919000061_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A_class, Name: "arbace.core.specs.alpha$fn__1919000061$fn__1919000067$fn__1919000068", Modifiers: 25, Simple: "fn__1919000068", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000073_A_class, Name: "arbace.core.specs.alpha$fn__1919000073", Modifiers: 25, Simple: "fn__1919000073", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000073_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000076_A_class, Name: "arbace.core.specs.alpha$fn__1919000076", Modifiers: 25, Simple: "fn__1919000076", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000076_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000079_A_class, Name: "arbace.core.specs.alpha$fn__1919000079", Modifiers: 25, Simple: "fn__1919000079", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000079_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000081_A_class, Name: "arbace.core.specs.alpha$fn__1919000081", Modifiers: 25, Simple: "fn__1919000081", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000081_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000084_A_class, Name: "arbace.core.specs.alpha$fn__1919000084", Modifiers: 25, Simple: "fn__1919000084", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000084_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000087_A_class, Name: "arbace.core.specs.alpha$fn__1919000087", Modifiers: 25, Simple: "fn__1919000087", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000087_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000089_A_class, Name: "arbace.core.specs.alpha$fn__1919000089", Modifiers: 25, Simple: "fn__1919000089", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000089_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000092_A_class, Name: "arbace.core.specs.alpha$fn__1919000092", Modifiers: 25, Simple: "fn__1919000092", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000092_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000094_A_class, Name: "arbace.core.specs.alpha$fn__1919000094", Modifiers: 25, Simple: "fn__1919000094", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000094_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000096_A_class, Name: "arbace.core.specs.alpha$fn__1919000096", Modifiers: 25, Simple: "fn__1919000096", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000096_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A_class, Name: "arbace.core.specs.alpha$fn__1919000096$fn__1919000098", Modifiers: 25, Simple: "fn__1919000098", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_fn__1919000096_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A_class, Name: "arbace.core.specs.alpha$fn__1919000096$fn__1919000100", Modifiers: 25, Simple: "fn__1919000100", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_fn__1919000096_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A_class, Name: "arbace.core.specs.alpha$fn__1919000096$fn__1919000102", Modifiers: 25, Simple: "fn__1919000102", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_fn__1919000096_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A_class, Name: "arbace.core.specs.alpha$fn__1919000096$fn__1919000102$fn__1919000103", Modifiers: 25, Simple: "fn__1919000103", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_core_specs_alpha_quotable_A_class, Name: "arbace.core.specs.alpha$quotable", Modifiers: 25, Simple: "quotable", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_quotable_A", Source: "alpha.ae", Declaring: &A_arbace_core_specs_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_core_specs_alpha_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_A_New()}; return nil }

var A_arbace_core_specs_alpha_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_specs_alpha_A_new}

var A_arbace_core_specs_alpha_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_A"})

func init() { i := A_arbace_core_specs_alpha_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_A_Init; i.Table = A_arbace_core_specs_alpha_A_members }

func A_arbace_core_specs_alpha_eval1919000002_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_eval1919000002_A_New()}; return nil }

var A_arbace_core_specs_alpha_eval1919000002_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_specs_alpha_eval1919000002_A_new}

var A_arbace_core_specs_alpha_eval1919000002_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$eval1919000002", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_specs_alpha_A_class, Simple: "eval1919000002", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_eval1919000002_A"})

func init() { i := A_arbace_core_specs_alpha_eval1919000002_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_eval1919000002_A_InstanceOf; i.Table = A_arbace_core_specs_alpha_eval1919000002_A_members }

var A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A_class *jrt.Class

func A_arbace_core_specs_alpha_eval1919000006_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_eval1919000006_A_New()}; return nil }

var A_arbace_core_specs_alpha_eval1919000006_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_specs_alpha_eval1919000006_A_new}

var A_arbace_core_specs_alpha_eval1919000006_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$eval1919000006", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_specs_alpha_A_class, Simple: "eval1919000006", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_eval1919000006_A"})

func init() { i := A_arbace_core_specs_alpha_eval1919000006_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_eval1919000006_A_InstanceOf; i.Table = A_arbace_core_specs_alpha_eval1919000006_A_members }

var A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A_class *jrt.Class

var A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000011_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000014_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000016_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000019_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000022_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000026_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000029_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000032_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000034_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000036_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000048_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000050_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000061_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000073_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000076_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000079_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000081_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000084_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000087_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000089_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000092_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000094_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000096_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A_class *jrt.Class

var A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A_class *jrt.Class

var A_arbace_core_specs_alpha_quotable_A_class *jrt.Class

func A_arbace_core_specs_alpha__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha__init_A_Load__O()}; return nil }

func A_arbace_core_specs_alpha__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha__init_A_New()}; return nil }

var A_arbace_core_specs_alpha__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_core_specs_alpha__init_A_invoke, New: A_arbace_core_specs_alpha__init_A_new}

var A_arbace_core_specs_alpha__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha__init_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha__init_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha__init_A_InstanceOf; i.Init = A_arbace_core_specs_alpha__init_A_Init; i.Table = A_arbace_core_specs_alpha__init_A_members }
