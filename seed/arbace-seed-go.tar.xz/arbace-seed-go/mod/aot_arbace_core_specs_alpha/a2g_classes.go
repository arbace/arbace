//line a2g_classes.ae:1
package aot_arbace_core_specs_alpha

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_core_specs_alpha_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_A_New()}; return nil }

var A_arbace_core_specs_alpha_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_specs_alpha_A_new}

var A_arbace_core_specs_alpha_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_A"})

func init() { i := A_arbace_core_specs_alpha_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_A_Init; i.Table = A_arbace_core_specs_alpha_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_A]()) }

func A_arbace_core_specs_alpha_eval1919000002_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_eval1919000002_A_New()}; return nil }

var A_arbace_core_specs_alpha_eval1919000002_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_specs_alpha_eval1919000002_A_new}

var A_arbace_core_specs_alpha_eval1919000002_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$eval1919000002", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_specs_alpha_A_class, Simple: "eval1919000002", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_eval1919000002_A"})

func init() { i := A_arbace_core_specs_alpha_eval1919000002_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_eval1919000002_A_InstanceOf; i.Table = A_arbace_core_specs_alpha_eval1919000002_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_eval1919000002_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_eval1919000002_A]()) }

func A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A_New()}; return nil }

func A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A_invoke, New: A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A_new, Get: A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A_get}

var A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$eval1919000002$loading__1927001464__auto____1919000003", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_specs_alpha_eval1919000002_A_class, Simple: "loading__1927001464__auto____1919000003", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A_Init; i.Table = A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_eval1919000002_loading__1927001464__auto____1919000003_A]()) }

func A_arbace_core_specs_alpha_eval1919000006_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_eval1919000006_A_New()}; return nil }

var A_arbace_core_specs_alpha_eval1919000006_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_core_specs_alpha_eval1919000006_A_new}

var A_arbace_core_specs_alpha_eval1919000006_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$eval1919000006", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_core_specs_alpha_A_class, Simple: "eval1919000006", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_eval1919000006_A"})

func init() { i := A_arbace_core_specs_alpha_eval1919000006_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_eval1919000006_A_InstanceOf; i.Table = A_arbace_core_specs_alpha_eval1919000006_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_eval1919000006_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_eval1919000006_A]()) }

func A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A_New()}; return nil }

func A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A_invoke, New: A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A_new, Get: A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A_get}

var A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$eval1919000006$fn__1919000007", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_specs_alpha_eval1919000006_A_class, Simple: "fn__1919000007", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A_Init; i.Table = A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_eval1919000006_fn__1919000007_A]()) }

func A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A_New()}; return nil }

func A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A_invoke, New: A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A_new, Get: A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A_get}

var A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$even_number_of_forms_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_specs_alpha_A_class, Simple: "even_number_of_forms_QMARK_", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A_InstanceOf; i.Init = A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A_Init; i.Table = A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A_class, reflect.TypeFor[A_arbace_core_specs_alpha_even_number_of_forms_QMARK__A]()) }

func A_arbace_core_specs_alpha_fn__1919000011_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000011_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000011_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000011_A_New()}; return nil }

func A_arbace_core_specs_alpha_fn__1919000011_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000011_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000011_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000011_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000011_A_new, Get: A_arbace_core_specs_alpha_fn__1919000011_A_get}

var A_arbace_core_specs_alpha_fn__1919000011_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000011", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_specs_alpha_A_class, Simple: "fn__1919000011", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000011_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000011_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000011_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000011_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000011_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000011_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000011_A]()) }

func A_arbace_core_specs_alpha_fn__1919000014_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000014_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000014_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000014_A_New()}; return nil }

func A_arbace_core_specs_alpha_fn__1919000014_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000014_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000014_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000014_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000014_A_new, Get: A_arbace_core_specs_alpha_fn__1919000014_A_get}

var A_arbace_core_specs_alpha_fn__1919000014_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000014", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_specs_alpha_A_class, Simple: "fn__1919000014", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000014_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000014_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000014_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000014_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000014_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000014_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000014_A]()) }

func A_arbace_core_specs_alpha_fn__1919000016_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000016_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000016_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000016_A_New()}; return nil }

func A_arbace_core_specs_alpha_fn__1919000016_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000016_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000016_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000016_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000016_A_new, Get: A_arbace_core_specs_alpha_fn__1919000016_A_get}

var A_arbace_core_specs_alpha_fn__1919000016_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000016", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_specs_alpha_A_class, Simple: "fn__1919000016", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000016_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000016_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000016_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000016_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000016_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000016_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000016_A]()) }

func A_arbace_core_specs_alpha_fn__1919000019_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000019_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000019_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000019_A_New()}; return nil }

func A_arbace_core_specs_alpha_fn__1919000019_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000019_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000019_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000019_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000019_A_new, Get: A_arbace_core_specs_alpha_fn__1919000019_A_get}

var A_arbace_core_specs_alpha_fn__1919000019_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000019", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_specs_alpha_A_class, Simple: "fn__1919000019", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000019_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000019_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000019_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000019_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000019_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000019_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000019_A]()) }

func A_arbace_core_specs_alpha_fn__1919000022_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000022_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000022_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000022_A_New()}; return nil }

func A_arbace_core_specs_alpha_fn__1919000022_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000022_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000022_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000022_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000022_A_new, Get: A_arbace_core_specs_alpha_fn__1919000022_A_get}

var A_arbace_core_specs_alpha_fn__1919000022_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000022", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_specs_alpha_A_class, Simple: "fn__1919000022", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000022_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000022_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000022_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000022_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000022_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000022_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000022_A]()) }

func A_arbace_core_specs_alpha_fn__1919000026_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000026_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000026_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000026_A_New()}; return nil }

func A_arbace_core_specs_alpha_fn__1919000026_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000026_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000026_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000026_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000026_A_new, Get: A_arbace_core_specs_alpha_fn__1919000026_A_get}

var A_arbace_core_specs_alpha_fn__1919000026_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000026", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_specs_alpha_A_class, Simple: "fn__1919000026", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000026_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000026_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000026_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000026_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000026_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000026_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000026_A]()) }

func A_arbace_core_specs_alpha_fn__1919000029_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000029_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000029_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000029_A_New()}; return nil }

func A_arbace_core_specs_alpha_fn__1919000029_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000029_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000029_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000029_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000029_A_new, Get: A_arbace_core_specs_alpha_fn__1919000029_A_get}

var A_arbace_core_specs_alpha_fn__1919000029_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000029", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_specs_alpha_A_class, Simple: "fn__1919000029", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000029_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000029_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000029_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000029_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000029_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000029_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000029_A]()) }

func A_arbace_core_specs_alpha_fn__1919000032_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000032_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000032_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000032_A_New()}; return nil }

func A_arbace_core_specs_alpha_fn__1919000032_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000032_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000032_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000032_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000032_A_new, Get: A_arbace_core_specs_alpha_fn__1919000032_A_get}

var A_arbace_core_specs_alpha_fn__1919000032_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000032", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_core_specs_alpha_A_class, Simple: "fn__1919000032", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000032_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000032_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000032_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000032_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000032_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000032_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000032_A]()) }

func A_arbace_core_specs_alpha_fn__1919000034_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000034_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000034_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000034_A_New()}; return nil }

func A_arbace_core_specs_alpha_fn__1919000034_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000034_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000034_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000034_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000034_A_new, Get: A_arbace_core_specs_alpha_fn__1919000034_A_get}

var A_arbace_core_specs_alpha_fn__1919000034_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000034", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_specs_alpha_A_class, Simple: "fn__1919000034", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000034_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000034_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000034_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000034_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000034_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000034_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000034_A]()) }

func A_arbace_core_specs_alpha_fn__1919000036_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000036_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000036_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000036_A_New()}; return nil }

func A_arbace_core_specs_alpha_fn__1919000036_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000036_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000036_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000036_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000036_A_new, Get: A_arbace_core_specs_alpha_fn__1919000036_A_get}

var A_arbace_core_specs_alpha_fn__1919000036_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000036", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_specs_alpha_A_class, Simple: "fn__1919000036", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000036_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000036_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000036_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000036_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000036_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000036_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000036_A]()) }

func A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A_New()}; return nil }

func A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A_new, Get: A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A_get}

var A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000036$fn__1919000038", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_specs_alpha_fn__1919000036_A_class, Simple: "fn__1919000038", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000036_fn__1919000038_A]()) }

func A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A_New()}; return nil }

func A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A_new, Get: A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A_get}

var A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000036$fn__1919000040", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_specs_alpha_fn__1919000036_A_class, Simple: "fn__1919000040", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000036_fn__1919000040_A]()) }

func A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A_New_O(args[0])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A_new, Get: A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A_get}

var A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000036$fn__1919000042", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_specs_alpha_fn__1919000036_A_class, Simple: "fn__1919000042", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A]()) }

func A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A_New()}; return nil }

func A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A_new, Get: A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A_get}

var A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000036$fn__1919000042$fn__1919000043", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_A_class, Simple: "fn__1919000043", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000036_fn__1919000042_fn__1919000043_A]()) }

func A_arbace_core_specs_alpha_fn__1919000048_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000048_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000048_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000048_A_New()}; return nil }

func A_arbace_core_specs_alpha_fn__1919000048_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000048_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000048_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000048_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000048_A_new, Get: A_arbace_core_specs_alpha_fn__1919000048_A_get}

var A_arbace_core_specs_alpha_fn__1919000048_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000048", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_specs_alpha_A_class, Simple: "fn__1919000048", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000048_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000048_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000048_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000048_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000048_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000048_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000048_A]()) }

func A_arbace_core_specs_alpha_fn__1919000050_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000050_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000050_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000050_A_New()}; return nil }

func A_arbace_core_specs_alpha_fn__1919000050_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000050_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000050_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000050_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000050_A_new, Get: A_arbace_core_specs_alpha_fn__1919000050_A_get}

var A_arbace_core_specs_alpha_fn__1919000050_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000050", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_specs_alpha_A_class, Simple: "fn__1919000050", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000050_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000050_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000050_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000050_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000050_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000050_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000050_A]()) }

func A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A_New()}; return nil }

func A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A_new, Get: A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A_get}

var A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000050$fn__1919000052", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_specs_alpha_fn__1919000050_A_class, Simple: "fn__1919000052", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000050_fn__1919000052_A]()) }

func A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A_New()}; return nil }

func A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A_new, Get: A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A_get}

var A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000050$fn__1919000054", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_specs_alpha_fn__1919000050_A_class, Simple: "fn__1919000054", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000050_fn__1919000054_A]()) }

func A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A_New_O(args[0])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A_new, Get: A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A_get}

var A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000050$fn__1919000056", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_specs_alpha_fn__1919000050_A_class, Simple: "fn__1919000056", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A]()) }

func A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A_New()}; return nil }

func A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A_new, Get: A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A_get}

var A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000050$fn__1919000056$fn__1919000057", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_A_class, Simple: "fn__1919000057", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000050_fn__1919000056_fn__1919000057_A]()) }

func A_arbace_core_specs_alpha_fn__1919000061_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000061_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000061_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000061_A_New()}; return nil }

func A_arbace_core_specs_alpha_fn__1919000061_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000061_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000061_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000061_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000061_A_new, Get: A_arbace_core_specs_alpha_fn__1919000061_A_get}

var A_arbace_core_specs_alpha_fn__1919000061_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000061", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_specs_alpha_A_class, Simple: "fn__1919000061", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000061_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000061_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000061_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000061_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000061_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000061_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000061_A]()) }

func A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A_New()}; return nil }

func A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A_new, Get: A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A_get}

var A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000061$fn__1919000063", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_specs_alpha_fn__1919000061_A_class, Simple: "fn__1919000063", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000061_fn__1919000063_A]()) }

func A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A_New()}; return nil }

func A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A_new, Get: A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A_get}

var A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000061$fn__1919000065", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_specs_alpha_fn__1919000061_A_class, Simple: "fn__1919000065", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000061_fn__1919000065_A]()) }

func A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A_New_O(args[0])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A_new, Get: A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A_get}

var A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000061$fn__1919000067", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_specs_alpha_fn__1919000061_A_class, Simple: "fn__1919000067", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A]()) }

func A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A_New()}; return nil }

func A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A_new, Get: A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A_get}

var A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000061$fn__1919000067$fn__1919000068", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_A_class, Simple: "fn__1919000068", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000061_fn__1919000067_fn__1919000068_A]()) }

func A_arbace_core_specs_alpha_fn__1919000073_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000073_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000073_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000073_A_New()}; return nil }

func A_arbace_core_specs_alpha_fn__1919000073_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000073_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000073_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000073_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000073_A_new, Get: A_arbace_core_specs_alpha_fn__1919000073_A_get}

var A_arbace_core_specs_alpha_fn__1919000073_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000073", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_specs_alpha_A_class, Simple: "fn__1919000073", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000073_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000073_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000073_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000073_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000073_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000073_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000073_A]()) }

func A_arbace_core_specs_alpha_fn__1919000076_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000076_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000076_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000076_A_New()}; return nil }

func A_arbace_core_specs_alpha_fn__1919000076_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000076_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000076_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000076_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000076_A_new, Get: A_arbace_core_specs_alpha_fn__1919000076_A_get}

var A_arbace_core_specs_alpha_fn__1919000076_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000076", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_specs_alpha_A_class, Simple: "fn__1919000076", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000076_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000076_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000076_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000076_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000076_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000076_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000076_A]()) }

func A_arbace_core_specs_alpha_fn__1919000079_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000079_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000079_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000079_A_New()}; return nil }

func A_arbace_core_specs_alpha_fn__1919000079_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000079_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000079_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000079_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000079_A_new, Get: A_arbace_core_specs_alpha_fn__1919000079_A_get}

var A_arbace_core_specs_alpha_fn__1919000079_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000079", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_core_specs_alpha_A_class, Simple: "fn__1919000079", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000079_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000079_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000079_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000079_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000079_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000079_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000079_A]()) }

func A_arbace_core_specs_alpha_fn__1919000081_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000081_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000081_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000081_A_New()}; return nil }

func A_arbace_core_specs_alpha_fn__1919000081_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000081_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000081_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000081_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000081_A_new, Get: A_arbace_core_specs_alpha_fn__1919000081_A_get}

var A_arbace_core_specs_alpha_fn__1919000081_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000081", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_specs_alpha_A_class, Simple: "fn__1919000081", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000081_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000081_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000081_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000081_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000081_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000081_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000081_A]()) }

func A_arbace_core_specs_alpha_fn__1919000084_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000084_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000084_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000084_A_New()}; return nil }

func A_arbace_core_specs_alpha_fn__1919000084_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000084_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000084_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000084_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000084_A_new, Get: A_arbace_core_specs_alpha_fn__1919000084_A_get}

var A_arbace_core_specs_alpha_fn__1919000084_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000084", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_specs_alpha_A_class, Simple: "fn__1919000084", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000084_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000084_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000084_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000084_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000084_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000084_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000084_A]()) }

func A_arbace_core_specs_alpha_fn__1919000087_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000087_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000087_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000087_A_New()}; return nil }

func A_arbace_core_specs_alpha_fn__1919000087_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000087_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000087_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000087_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000087_A_new, Get: A_arbace_core_specs_alpha_fn__1919000087_A_get}

var A_arbace_core_specs_alpha_fn__1919000087_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000087", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_specs_alpha_A_class, Simple: "fn__1919000087", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000087_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000087_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000087_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000087_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000087_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000087_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000087_A]()) }

func A_arbace_core_specs_alpha_fn__1919000089_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000089_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000089_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000089_A_New()}; return nil }

func A_arbace_core_specs_alpha_fn__1919000089_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000089_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000089_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000089_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000089_A_new, Get: A_arbace_core_specs_alpha_fn__1919000089_A_get}

var A_arbace_core_specs_alpha_fn__1919000089_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000089", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_specs_alpha_A_class, Simple: "fn__1919000089", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000089_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000089_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000089_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000089_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000089_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000089_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000089_A]()) }

func A_arbace_core_specs_alpha_fn__1919000092_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000092_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000092_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000092_A_New()}; return nil }

func A_arbace_core_specs_alpha_fn__1919000092_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000092_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000092_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000092_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000092_A_new, Get: A_arbace_core_specs_alpha_fn__1919000092_A_get}

var A_arbace_core_specs_alpha_fn__1919000092_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000092", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_core_specs_alpha_A_class, Simple: "fn__1919000092", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000092_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000092_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000092_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000092_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000092_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000092_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000092_A]()) }

func A_arbace_core_specs_alpha_fn__1919000094_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000094_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000094_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000094_A_New()}; return nil }

func A_arbace_core_specs_alpha_fn__1919000094_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000094_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000094_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000094_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000094_A_new, Get: A_arbace_core_specs_alpha_fn__1919000094_A_get}

var A_arbace_core_specs_alpha_fn__1919000094_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000094", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_specs_alpha_A_class, Simple: "fn__1919000094", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000094_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000094_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000094_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000094_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000094_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000094_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000094_A]()) }

func A_arbace_core_specs_alpha_fn__1919000096_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000096_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000096_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000096_A_New()}; return nil }

func A_arbace_core_specs_alpha_fn__1919000096_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000096_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000096_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000096_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000096_A_new, Get: A_arbace_core_specs_alpha_fn__1919000096_A_get}

var A_arbace_core_specs_alpha_fn__1919000096_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000096", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_specs_alpha_A_class, Simple: "fn__1919000096", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000096_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000096_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000096_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000096_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000096_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000096_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000096_A]()) }

func A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A_New()}; return nil }

func A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A_new, Get: A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A_get}

var A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000096$fn__1919000098", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_specs_alpha_fn__1919000096_A_class, Simple: "fn__1919000098", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000096_fn__1919000098_A]()) }

func A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A_New()}; return nil }

func A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A_new, Get: A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A_get}

var A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000096$fn__1919000100", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_specs_alpha_fn__1919000096_A_class, Simple: "fn__1919000100", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000096_fn__1919000100_A]()) }

func A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A_New_O(args[0])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A_new, Get: A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A_get}

var A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000096$fn__1919000102", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_core_specs_alpha_fn__1919000096_A_class, Simple: "fn__1919000102", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A]()) }

func A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A_New()}; return nil }

func A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A_invoke, New: A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A_new, Get: A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A_get}

var A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$fn__1919000096$fn__1919000102$fn__1919000103", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_A_class, Simple: "fn__1919000103", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A_Init; i.Table = A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_fn__1919000096_fn__1919000102_fn__1919000103_A]()) }

func A_arbace_core_specs_alpha_quotable_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_core_specs_alpha_quotable_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_core_specs_alpha_quotable_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha_quotable_A_New()}; return nil }

func A_arbace_core_specs_alpha_quotable_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_core_specs_alpha_quotable_A_fn_class)}; return nil }

var A_arbace_core_specs_alpha_quotable_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_core_specs_alpha_quotable_A_invoke, New: A_arbace_core_specs_alpha_quotable_A_new, Get: A_arbace_core_specs_alpha_quotable_A_get}

var A_arbace_core_specs_alpha_quotable_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha$quotable", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_core_specs_alpha_A_class, Simple: "quotable", Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha_quotable_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha_quotable_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha_quotable_A_InstanceOf; i.Init = A_arbace_core_specs_alpha_quotable_A_Init; i.Table = A_arbace_core_specs_alpha_quotable_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha_quotable_A_class, reflect.TypeFor[A_arbace_core_specs_alpha_quotable_A]()) }

func A_arbace_core_specs_alpha__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha__init_A_Load__O(); case 1: return A_arbace_core_specs_alpha__init_A_Unit0__O(); case 2: return A_arbace_core_specs_alpha__init_A_Unit1__O(); case 3: return A_arbace_core_specs_alpha__init_A_Unit10__O(); case 4: return A_arbace_core_specs_alpha__init_A_Unit11__O(); case 5: return A_arbace_core_specs_alpha__init_A_Unit12__O(); case 6: return A_arbace_core_specs_alpha__init_A_Unit13__O(); case 7: return A_arbace_core_specs_alpha__init_A_Unit14__O(); case 8: return A_arbace_core_specs_alpha__init_A_Unit15__O(); case 9: return A_arbace_core_specs_alpha__init_A_Unit16__O(); case 10: return A_arbace_core_specs_alpha__init_A_Unit17__O(); case 11: return A_arbace_core_specs_alpha__init_A_Unit18__O(); case 12: return A_arbace_core_specs_alpha__init_A_Unit19__O(); case 13: return A_arbace_core_specs_alpha__init_A_Unit2__O(); case 14: return A_arbace_core_specs_alpha__init_A_Unit20__O(); case 15: return A_arbace_core_specs_alpha__init_A_Unit21__O(); case 16: return A_arbace_core_specs_alpha__init_A_Unit22__O(); case 17: return A_arbace_core_specs_alpha__init_A_Unit23__O(); case 18: return A_arbace_core_specs_alpha__init_A_Unit24__O(); case 19: return A_arbace_core_specs_alpha__init_A_Unit25__O(); case 20: return A_arbace_core_specs_alpha__init_A_Unit26__O(); case 21: return A_arbace_core_specs_alpha__init_A_Unit27__O(); case 22: return A_arbace_core_specs_alpha__init_A_Unit28__O(); case 23: return A_arbace_core_specs_alpha__init_A_Unit29__O(); case 24: return A_arbace_core_specs_alpha__init_A_Unit3__O(); case 25: return A_arbace_core_specs_alpha__init_A_Unit30__O(); case 26: return A_arbace_core_specs_alpha__init_A_Unit31__O(); case 27: return A_arbace_core_specs_alpha__init_A_Unit32__O(); case 28: return A_arbace_core_specs_alpha__init_A_Unit33__O(); case 29: return A_arbace_core_specs_alpha__init_A_Unit34__O(); case 30: return A_arbace_core_specs_alpha__init_A_Unit35__O(); case 31: return A_arbace_core_specs_alpha__init_A_Unit36__O(); case 32: return A_arbace_core_specs_alpha__init_A_Unit37__O(); case 33: return A_arbace_core_specs_alpha__init_A_Unit38__O(); case 34: return A_arbace_core_specs_alpha__init_A_Unit39__O(); case 35: return A_arbace_core_specs_alpha__init_A_Unit4__O(); case 36: return A_arbace_core_specs_alpha__init_A_Unit40__O(); case 37: return A_arbace_core_specs_alpha__init_A_Unit41__O(); case 38: return A_arbace_core_specs_alpha__init_A_Unit42__O(); case 39: return A_arbace_core_specs_alpha__init_A_Unit43__O(); case 40: return A_arbace_core_specs_alpha__init_A_Unit44__O(); case 41: return A_arbace_core_specs_alpha__init_A_Unit45__O(); case 42: return A_arbace_core_specs_alpha__init_A_Unit46__O(); case 43: return A_arbace_core_specs_alpha__init_A_Unit47__O(); case 44: return A_arbace_core_specs_alpha__init_A_Unit48__O(); case 45: return A_arbace_core_specs_alpha__init_A_Unit49__O(); case 46: return A_arbace_core_specs_alpha__init_A_Unit5__O(); case 47: return A_arbace_core_specs_alpha__init_A_Unit50__O(); case 48: return A_arbace_core_specs_alpha__init_A_Unit51__O(); case 49: return A_arbace_core_specs_alpha__init_A_Unit52__O(); case 50: return A_arbace_core_specs_alpha__init_A_Unit53__O(); case 51: return A_arbace_core_specs_alpha__init_A_Unit54__O(); case 52: return A_arbace_core_specs_alpha__init_A_Unit55__O(); case 53: return A_arbace_core_specs_alpha__init_A_Unit56__O(); case 54: return A_arbace_core_specs_alpha__init_A_Unit57__O(); case 55: return A_arbace_core_specs_alpha__init_A_Unit58__O(); case 56: return A_arbace_core_specs_alpha__init_A_Unit59__O(); case 57: return A_arbace_core_specs_alpha__init_A_Unit6__O(); case 58: return A_arbace_core_specs_alpha__init_A_Unit60__O(); case 59: return A_arbace_core_specs_alpha__init_A_Unit61__O(); case 60: return A_arbace_core_specs_alpha__init_A_Unit62__O(); case 61: return A_arbace_core_specs_alpha__init_A_Unit63__O(); case 62: return A_arbace_core_specs_alpha__init_A_Unit64__O(); case 63: return A_arbace_core_specs_alpha__init_A_Unit65__O(); case 64: return A_arbace_core_specs_alpha__init_A_Unit66__O(); case 65: return A_arbace_core_specs_alpha__init_A_Unit67__O(); case 66: return A_arbace_core_specs_alpha__init_A_Unit68__O(); case 67: return A_arbace_core_specs_alpha__init_A_Unit69__O(); case 68: return A_arbace_core_specs_alpha__init_A_Unit7__O(); case 69: return A_arbace_core_specs_alpha__init_A_Unit70__O(); case 70: return A_arbace_core_specs_alpha__init_A_Unit71__O(); case 71: return A_arbace_core_specs_alpha__init_A_Unit72__O(); case 72: return A_arbace_core_specs_alpha__init_A_Unit73__O(); case 73: return A_arbace_core_specs_alpha__init_A_Unit74__O(); case 74: return A_arbace_core_specs_alpha__init_A_Unit75__O(); case 75: return A_arbace_core_specs_alpha__init_A_Unit76__O(); case 76: return A_arbace_core_specs_alpha__init_A_Unit77__O(); case 77: return A_arbace_core_specs_alpha__init_A_Unit78__O(); case 78: return A_arbace_core_specs_alpha__init_A_Unit79__O(); case 79: return A_arbace_core_specs_alpha__init_A_Unit8__O(); case 80: return A_arbace_core_specs_alpha__init_A_Unit80__O(); case 81: return A_arbace_core_specs_alpha__init_A_Unit81__O(); case 82: return A_arbace_core_specs_alpha__init_A_Unit82__O(); case 83: return A_arbace_core_specs_alpha__init_A_Unit83__O(); case 84: return A_arbace_core_specs_alpha__init_A_Unit84__O(); case 85: return A_arbace_core_specs_alpha__init_A_Unit85__O(); case 86: return A_arbace_core_specs_alpha__init_A_Unit86__O(); case 87: return A_arbace_core_specs_alpha__init_A_Unit87__O(); case 88: return A_arbace_core_specs_alpha__init_A_Unit9__O()}; return nil }

func A_arbace_core_specs_alpha__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_core_specs_alpha__init_A_New()}; return nil }

var A_arbace_core_specs_alpha__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit28 ()Ljava.lang.Object;\nM9 unit29 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit30 ()Ljava.lang.Object;\nM9 unit31 ()Ljava.lang.Object;\nM9 unit32 ()Ljava.lang.Object;\nM9 unit33 ()Ljava.lang.Object;\nM9 unit34 ()Ljava.lang.Object;\nM9 unit35 ()Ljava.lang.Object;\nM9 unit36 ()Ljava.lang.Object;\nM9 unit37 ()Ljava.lang.Object;\nM9 unit38 ()Ljava.lang.Object;\nM9 unit39 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit40 ()Ljava.lang.Object;\nM9 unit41 ()Ljava.lang.Object;\nM9 unit42 ()Ljava.lang.Object;\nM9 unit43 ()Ljava.lang.Object;\nM9 unit44 ()Ljava.lang.Object;\nM9 unit45 ()Ljava.lang.Object;\nM9 unit46 ()Ljava.lang.Object;\nM9 unit47 ()Ljava.lang.Object;\nM9 unit48 ()Ljava.lang.Object;\nM9 unit49 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit50 ()Ljava.lang.Object;\nM9 unit51 ()Ljava.lang.Object;\nM9 unit52 ()Ljava.lang.Object;\nM9 unit53 ()Ljava.lang.Object;\nM9 unit54 ()Ljava.lang.Object;\nM9 unit55 ()Ljava.lang.Object;\nM9 unit56 ()Ljava.lang.Object;\nM9 unit57 ()Ljava.lang.Object;\nM9 unit58 ()Ljava.lang.Object;\nM9 unit59 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit60 ()Ljava.lang.Object;\nM9 unit61 ()Ljava.lang.Object;\nM9 unit62 ()Ljava.lang.Object;\nM9 unit63 ()Ljava.lang.Object;\nM9 unit64 ()Ljava.lang.Object;\nM9 unit65 ()Ljava.lang.Object;\nM9 unit66 ()Ljava.lang.Object;\nM9 unit67 ()Ljava.lang.Object;\nM9 unit68 ()Ljava.lang.Object;\nM9 unit69 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit70 ()Ljava.lang.Object;\nM9 unit71 ()Ljava.lang.Object;\nM9 unit72 ()Ljava.lang.Object;\nM9 unit73 ()Ljava.lang.Object;\nM9 unit74 ()Ljava.lang.Object;\nM9 unit75 ()Ljava.lang.Object;\nM9 unit76 ()Ljava.lang.Object;\nM9 unit77 ()Ljava.lang.Object;\nM9 unit78 ()Ljava.lang.Object;\nM9 unit79 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit80 ()Ljava.lang.Object;\nM9 unit81 ()Ljava.lang.Object;\nM9 unit82 ()Ljava.lang.Object;\nM9 unit83 ()Ljava.lang.Object;\nM9 unit84 ()Ljava.lang.Object;\nM9 unit85 ()Ljava.lang.Object;\nM9 unit86 ()Ljava.lang.Object;\nM9 unit87 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_core_specs_alpha__init_A_invoke, New: A_arbace_core_specs_alpha__init_A_new}

var A_arbace_core_specs_alpha__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.core.specs.alpha__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_core_specs_alpha.A_arbace_core_specs_alpha__init_A", Source: "alpha.ae"})

func init() { i := A_arbace_core_specs_alpha__init_A_class.Info(); i.IsInstance = A_arbace_core_specs_alpha__init_A_InstanceOf; i.Init = A_arbace_core_specs_alpha__init_A_Init; i.Table = A_arbace_core_specs_alpha__init_A_members; jrt.RegisterGoType(A_arbace_core_specs_alpha__init_A_class, reflect.TypeFor[A_arbace_core_specs_alpha__init_A]()) }
