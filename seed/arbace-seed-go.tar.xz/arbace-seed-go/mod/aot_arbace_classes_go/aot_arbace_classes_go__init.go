//line aot_arbace_classes_go__init.ae:1
package aot_arbace_classes_go

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_go__init_A_Unit0__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_classes_go__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_go__init_A_const_1) }
//line :1:1
func A_arbace_classes_go__init_A_Unit1__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_classes_go__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_2)) }
//line :1:1
func A_arbace_classes_go__init_A_Unit2__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 any = A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_classes_go__init_A_Unit3__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_classes_go__init_A_const_1)).Equals_O__Z(A_arbace_classes_go__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_classes_go_eval1797000008_fn__1797000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_classes_go_eval1797000008_fn__1797000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_classes_go_eval1797000008_fn__1797000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_classes_go__init_A_Load__O() any { A_arbace_classes_go__init_A_Init(); jrt.StartCheck(); A_arbace_classes_go__init_A_Unit0__O(); A_arbace_classes_go__init_A_Unit1__O(); A_arbace_classes_go__init_A_Unit2__O(); A_arbace_classes_go__init_A_Unit3__O(); A_arbace_classes_go__init_A_Unit4__O(); A_arbace_classes_go__init_A_Unit5__O(); A_arbace_classes_go__init_A_Unit6__O(); A_arbace_classes_go__init_A_Unit7__O(); A_arbace_classes_go__init_A_Unit8__O(); A_arbace_classes_go__init_A_Unit9__O(); A_arbace_classes_go__init_A_Unit10__O(); A_arbace_classes_go__init_A_Unit11__O(); A_arbace_classes_go__init_A_Unit12__O(); A_arbace_classes_go__init_A_Unit13__O(); A_arbace_classes_go__init_A_Unit14__O(); A_arbace_classes_go__init_A_Unit15__O(); A_arbace_classes_go__init_A_Unit16__O(); A_arbace_classes_go__init_A_Unit17__O(); A_arbace_classes_go__init_A_Unit18__O(); A_arbace_classes_go__init_A_Unit19__O(); A_arbace_classes_go__init_A_Unit20__O(); A_arbace_classes_go__init_A_Unit21__O(); A_arbace_classes_go__init_A_Unit22__O(); A_arbace_classes_go__init_A_Unit23__O(); A_arbace_classes_go__init_A_Unit24__O(); A_arbace_classes_go__init_A_Unit25__O(); A_arbace_classes_go__init_A_Unit26__O(); A_arbace_classes_go__init_A_Unit27__O(); A_arbace_classes_go__init_A_Unit28__O(); A_arbace_classes_go__init_A_Unit29__O(); A_arbace_classes_go__init_A_Unit30__O(); A_arbace_classes_go__init_A_Unit31__O(); A_arbace_classes_go__init_A_Unit32__O(); A_arbace_classes_go__init_A_Unit33__O(); A_arbace_classes_go__init_A_Unit34__O(); A_arbace_classes_go__init_A_Unit35__O(); A_arbace_classes_go__init_A_Unit36__O(); A_arbace_classes_go__init_A_Unit37__O(); A_arbace_classes_go__init_A_Unit38__O(); A_arbace_classes_go__init_A_Unit39__O(); return nil }






func A_arbace_classes_go__init_A_Unit4__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(12, 1); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_4; var tmp2 any = A_arbace_classes_go_tref_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_classes_go_tref_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_classes_go_tref_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_go__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_5)); return A_arbace_classes_go__init_A_const_4 }

func A_arbace_classes_go__init_A_Unit5__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(14, 1); A_arbace_classes_go__init_A_const_6.BindRoot_O__V(A_arbace_classes_go__init_A_const_7); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_6; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_8)); return A_arbace_classes_go__init_A_const_6 }
func A_arbace_classes_go__init_A_Unit6__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(15, 1); A_arbace_classes_go__init_A_const_9.BindRoot_O__V(A_arbace_classes_go__init_A_const_10); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_9; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_11)); return A_arbace_classes_go__init_A_const_9 }
func A_arbace_classes_go__init_A_Unit7__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); A_arbace_classes_go__init_A_const_12.BindRoot_O__V(A_arbace_classes_go__init_A_const_13); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_12; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_14)); return A_arbace_classes_go__init_A_const_12 }
func A_arbace_classes_go__init_A_Unit8__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(17, 1); A_arbace_classes_go__init_A_const_15.BindRoot_O__V(A_arbace_classes_go__init_A_const_16); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_15; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_17)); return A_arbace_classes_go__init_A_const_15 }
func A_arbace_classes_go__init_A_Unit9__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(18, 1); A_arbace_classes_go__init_A_const_18.BindRoot_O__V(A_arbace_classes_go__init_A_const_19); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_18; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_20)); return A_arbace_classes_go__init_A_const_18 }
func A_arbace_classes_go__init_A_Unit10__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(19, 1); A_arbace_classes_go__init_A_const_21.BindRoot_O__V(A_arbace_classes_go__init_A_const_22); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_21; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_23)); return A_arbace_classes_go__init_A_const_21 }
func A_arbace_classes_go__init_A_Unit11__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(20, 1); A_arbace_classes_go__init_A_const_24.BindRoot_O__V(A_arbace_classes_go__init_A_const_25); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_24; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_26)); return A_arbace_classes_go__init_A_const_24 }
func A_arbace_classes_go__init_A_Unit12__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(21, 1); A_arbace_classes_go__init_A_const_27.BindRoot_O__V(A_arbace_classes_go__init_A_const_28); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_27; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_29)); return A_arbace_classes_go__init_A_const_27 }
func A_arbace_classes_go__init_A_Unit13__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(22, 1); A_arbace_classes_go__init_A_const_30.BindRoot_O__V(A_arbace_classes_go__init_A_const_31); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_30; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_32)); return A_arbace_classes_go__init_A_const_30 }
func A_arbace_classes_go__init_A_Unit14__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(23, 1); A_arbace_classes_go__init_A_const_33.BindRoot_O__V(A_arbace_classes_go__init_A_const_34); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_33; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_35)); return A_arbace_classes_go__init_A_const_33 }
func A_arbace_classes_go__init_A_Unit15__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(24, 1); A_arbace_classes_go__init_A_const_36.BindRoot_O__V(A_arbace_classes_go__init_A_const_37); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_36; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_38)); return A_arbace_classes_go__init_A_const_36 }
func A_arbace_classes_go__init_A_Unit16__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(25, 1); A_arbace_classes_go__init_A_const_39.BindRoot_O__V(A_arbace_classes_go__init_A_const_40); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_39; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_41)); return A_arbace_classes_go__init_A_const_39 }
func A_arbace_classes_go__init_A_Unit17__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(26, 1); A_arbace_classes_go__init_A_const_42.BindRoot_O__V(A_arbace_classes_go__init_A_const_43); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_42; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_44)); return A_arbace_classes_go__init_A_const_42 }
func A_arbace_classes_go__init_A_Unit18__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(27, 1); A_arbace_classes_go__init_A_const_45.BindRoot_O__V(A_arbace_classes_go__init_A_const_46); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_45; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_47)); return A_arbace_classes_go__init_A_const_45 }
func A_arbace_classes_go__init_A_Unit19__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(28, 1); A_arbace_classes_go__init_A_const_48.BindRoot_O__V(A_arbace_classes_go__init_A_const_49); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_48; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_50)); return A_arbace_classes_go__init_A_const_48 }
func A_arbace_classes_go__init_A_Unit20__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(29, 1); A_arbace_classes_go__init_A_const_51.BindRoot_O__V(A_arbace_classes_go__init_A_const_52); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_51; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_53)); return A_arbace_classes_go__init_A_const_51 }
func A_arbace_classes_go__init_A_Unit21__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(30, 1); A_arbace_classes_go__init_A_const_54.BindRoot_O__V(A_arbace_classes_go__init_A_const_55); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_54; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_56)); return A_arbace_classes_go__init_A_const_54 }
func A_arbace_classes_go__init_A_Unit22__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(31, 1); A_arbace_classes_go__init_A_const_57.BindRoot_O__V(A_arbace_classes_go__init_A_const_58); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_57; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_59)); return A_arbace_classes_go__init_A_const_57 }
func A_arbace_classes_go__init_A_Unit23__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(32, 1); A_arbace_classes_go__init_A_const_60.BindRoot_O__V(A_arbace_classes_go__init_A_const_61); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_60; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_62)); return A_arbace_classes_go__init_A_const_60 }
func A_arbace_classes_go__init_A_Unit24__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(33, 1); A_arbace_classes_go__init_A_const_63.BindRoot_O__V(A_arbace_classes_go__init_A_const_64); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_63; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_65)); return A_arbace_classes_go__init_A_const_63 }
func A_arbace_classes_go__init_A_Unit25__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(34, 1); A_arbace_classes_go__init_A_const_66.BindRoot_O__V(A_arbace_classes_go__init_A_const_67); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_66; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_68)); return A_arbace_classes_go__init_A_const_66 }
func A_arbace_classes_go__init_A_Unit26__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(35, 1); A_arbace_classes_go__init_A_const_69.BindRoot_O__V(A_arbace_classes_go__init_A_const_70); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_69; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_71)); return A_arbace_classes_go__init_A_const_69 }

func A_arbace_classes_go__init_A_Unit27__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(37, 1); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_72; var tmp2 any = A_arbace_classes_go_newTypeReference_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_classes_go_newTypeReference_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_classes_go_newTypeReference_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_go__init_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_73)); return A_arbace_classes_go__init_A_const_72 }
func A_arbace_classes_go__init_A_Unit28__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_74; var tmp2 any = A_arbace_classes_go_newTypeParameterReference_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_classes_go_newTypeParameterReference_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_classes_go_newTypeParameterReference_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_go__init_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_75)); return A_arbace_classes_go__init_A_const_74 }

func A_arbace_classes_go__init_A_Unit29__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(40, 1); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_76; var tmp2 any = A_arbace_classes_go_newTypeParameterBoundReference_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_classes_go_newTypeParameterBoundReference_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_classes_go_newTypeParameterBoundReference_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_go__init_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_77)); return A_arbace_classes_go__init_A_const_76 }

func A_arbace_classes_go__init_A_Unit30__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(42, 1); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_78; var tmp2 any = A_arbace_classes_go_newSuperTypeReference_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_classes_go_newSuperTypeReference_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_classes_go_newSuperTypeReference_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_go__init_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_79)); return A_arbace_classes_go__init_A_const_78 }

func A_arbace_classes_go__init_A_Unit31__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(44, 1); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_80; var tmp2 any = A_arbace_classes_go_newFormalParameterReference_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_classes_go_newFormalParameterReference_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_classes_go_newFormalParameterReference_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_go__init_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_81)); return A_arbace_classes_go__init_A_const_80 }

func A_arbace_classes_go__init_A_Unit32__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(46, 1); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_82; var tmp2 any = A_arbace_classes_go_newExceptionReference_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_classes_go_newExceptionReference_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_classes_go_newExceptionReference_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_go__init_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_83)); return A_arbace_classes_go__init_A_const_82 }
func A_arbace_classes_go__init_A_Unit33__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_84; var tmp2 any = A_arbace_classes_go_newTryCatchReference_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_classes_go_newTryCatchReference_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_classes_go_newTryCatchReference_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_go__init_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_85)); return A_arbace_classes_go__init_A_const_84 }

func A_arbace_classes_go__init_A_Unit34__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(49, 1); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_86; var tmp2 any = A_arbace_classes_go_newTypeArgumentReference_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_classes_go_newTypeArgumentReference_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_classes_go_newTypeArgumentReference_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_go__init_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_87)); return A_arbace_classes_go__init_A_const_86 }





func A_arbace_classes_go__init_A_Unit35__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(55, 1); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_88; var tmp2 any = A_arbace_classes_go_fn__1797000023_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_classes_go_fn__1797000023_A_fn_class; if




	fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_classes_go_fn__1797000023_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; /*line :55:1*/tmp1.BindRoot_O__V(jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O())).Ref()); var tmp4 *lang.Var = A_arbace_classes_go__init_A_const_88; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_89)); return A_arbace_classes_go__init_A_const_88 }






func A_arbace_classes_go__init_A_Unit36__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(62, 1); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_90; var tmp2 any = A_arbace_classes_go_fn__1797000025_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_classes_go_fn__1797000025_A_fn_class; if
							fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_classes_go_fn__1797000025_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; /*line :62:1*/tmp1.BindRoot_O__V(lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil))); var tmp4 *lang.Var = A_arbace_classes_go__init_A_const_90; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_91)); return A_arbace_classes_go__init_A_const_90 }






func A_arbace_classes_go__init_A_Unit37__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(69, 1); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_92; var tmp2 any = A_arbace_classes_go_generics_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_classes_go_generics_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_classes_go_generics_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_go__init_A_const_92; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_93)); return A_arbace_classes_go__init_A_const_92 }





















func A_arbace_classes_go__init_A_Unit38__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(91, 1); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_94; var tmp2 any = A_arbace_classes_go_constructors_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_classes_go_constructors_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_classes_go_constructors_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_go__init_A_const_94; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_95)); return A_arbace_classes_go__init_A_const_94 }











func A_arbace_classes_go__init_A_Unit39__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(103, 1); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_96; var tmp2 any = A_arbace_classes_go_world_const_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_classes_go_world_const_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_classes_go_world_const_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_go__init_A_const_96; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_97)); return A_arbace_classes_go__init_A_const_96 }



type A_arbace_classes_go__init_A struct{ jrt.Object }

var A_arbace_classes_go__init_A_const_pool *jrt.RefArray

var A_arbace_classes_go__init_A_const_0 *lang.Var

var A_arbace_classes_go__init_A_const_1 any

var A_arbace_classes_go__init_A_const_2 any

var A_arbace_classes_go__init_A_const_3 any

var A_arbace_classes_go__init_A_const_4 *lang.Var

var A_arbace_classes_go__init_A_const_5 any

var A_arbace_classes_go__init_A_const_6 *lang.Var

var A_arbace_classes_go__init_A_const_7 any

var A_arbace_classes_go__init_A_const_8 any

var A_arbace_classes_go__init_A_const_9 *lang.Var

var A_arbace_classes_go__init_A_const_10 any

var A_arbace_classes_go__init_A_const_11 any

var A_arbace_classes_go__init_A_const_12 *lang.Var

var A_arbace_classes_go__init_A_const_13 any

var A_arbace_classes_go__init_A_const_14 any

var A_arbace_classes_go__init_A_const_15 *lang.Var

var A_arbace_classes_go__init_A_const_16 any

var A_arbace_classes_go__init_A_const_17 any

var A_arbace_classes_go__init_A_const_18 *lang.Var

var A_arbace_classes_go__init_A_const_19 any

var A_arbace_classes_go__init_A_const_20 any

var A_arbace_classes_go__init_A_const_21 *lang.Var

var A_arbace_classes_go__init_A_const_22 any

var A_arbace_classes_go__init_A_const_23 any

var A_arbace_classes_go__init_A_const_24 *lang.Var

var A_arbace_classes_go__init_A_const_25 any

var A_arbace_classes_go__init_A_const_26 any

var A_arbace_classes_go__init_A_const_27 *lang.Var

var A_arbace_classes_go__init_A_const_28 any

var A_arbace_classes_go__init_A_const_29 any

var A_arbace_classes_go__init_A_const_30 *lang.Var

var A_arbace_classes_go__init_A_const_31 any

var A_arbace_classes_go__init_A_const_32 any

var A_arbace_classes_go__init_A_const_33 *lang.Var

var A_arbace_classes_go__init_A_const_34 any

var A_arbace_classes_go__init_A_const_35 any

var A_arbace_classes_go__init_A_const_36 *lang.Var

var A_arbace_classes_go__init_A_const_37 any

var A_arbace_classes_go__init_A_const_38 any

var A_arbace_classes_go__init_A_const_39 *lang.Var

var A_arbace_classes_go__init_A_const_40 any

var A_arbace_classes_go__init_A_const_41 any

var A_arbace_classes_go__init_A_const_42 *lang.Var

var A_arbace_classes_go__init_A_const_43 any

var A_arbace_classes_go__init_A_const_44 any

var A_arbace_classes_go__init_A_const_45 *lang.Var

var A_arbace_classes_go__init_A_const_46 any

var A_arbace_classes_go__init_A_const_47 any

var A_arbace_classes_go__init_A_const_48 *lang.Var

var A_arbace_classes_go__init_A_const_49 any

var A_arbace_classes_go__init_A_const_50 any

var A_arbace_classes_go__init_A_const_51 *lang.Var

var A_arbace_classes_go__init_A_const_52 any

var A_arbace_classes_go__init_A_const_53 any

var A_arbace_classes_go__init_A_const_54 *lang.Var

var A_arbace_classes_go__init_A_const_55 any

var A_arbace_classes_go__init_A_const_56 any

var A_arbace_classes_go__init_A_const_57 *lang.Var

var A_arbace_classes_go__init_A_const_58 any

var A_arbace_classes_go__init_A_const_59 any

var A_arbace_classes_go__init_A_const_60 *lang.Var

var A_arbace_classes_go__init_A_const_61 any

var A_arbace_classes_go__init_A_const_62 any

var A_arbace_classes_go__init_A_const_63 *lang.Var

var A_arbace_classes_go__init_A_const_64 any

var A_arbace_classes_go__init_A_const_65 any

var A_arbace_classes_go__init_A_const_66 *lang.Var

var A_arbace_classes_go__init_A_const_67 any

var A_arbace_classes_go__init_A_const_68 any

var A_arbace_classes_go__init_A_const_69 *lang.Var

var A_arbace_classes_go__init_A_const_70 any

var A_arbace_classes_go__init_A_const_71 any

var A_arbace_classes_go__init_A_const_72 *lang.Var

var A_arbace_classes_go__init_A_const_73 any

var A_arbace_classes_go__init_A_const_74 *lang.Var

var A_arbace_classes_go__init_A_const_75 any

var A_arbace_classes_go__init_A_const_76 *lang.Var

var A_arbace_classes_go__init_A_const_77 any

var A_arbace_classes_go__init_A_const_78 *lang.Var

var A_arbace_classes_go__init_A_const_79 any

var A_arbace_classes_go__init_A_const_80 *lang.Var

var A_arbace_classes_go__init_A_const_81 any

var A_arbace_classes_go__init_A_const_82 *lang.Var

var A_arbace_classes_go__init_A_const_83 any

var A_arbace_classes_go__init_A_const_84 *lang.Var

var A_arbace_classes_go__init_A_const_85 any

var A_arbace_classes_go__init_A_const_86 *lang.Var

var A_arbace_classes_go__init_A_const_87 any

var A_arbace_classes_go__init_A_const_88 *lang.Var

var A_arbace_classes_go__init_A_const_89 any

var A_arbace_classes_go__init_A_const_90 *lang.Var

var A_arbace_classes_go__init_A_const_91 any

var A_arbace_classes_go__init_A_const_92 *lang.Var

var A_arbace_classes_go__init_A_const_93 any

var A_arbace_classes_go__init_A_const_94 *lang.Var

var A_arbace_classes_go__init_A_const_95 any

var A_arbace_classes_go__init_A_const_96 *lang.Var

var A_arbace_classes_go__init_A_const_97 any

var A_arbace_classes_go__init_A_init jrt.ClassInit

func A_arbace_classes_go__init_A_Init() { if !A_arbace_classes_go__init_A_init.Done() { A_arbace_classes_go__init_A_init.Run(A_arbace_classes_go__init_A_clinit) } }

func A_arbace_classes_go__init_A_clinit() { A_arbace_classes_go__init_A_clinit_p0(); A_arbace_classes_go__init_A_clinit_p1(); A_arbace_classes_go__init_A_clinit_p2(); A_arbace_classes_go__init_A_clinit_p3(); A_arbace_classes_go__init_A_clinit_p4(); A_arbace_classes_go__init_A_clinit_p5(); A_arbace_classes_go__init_A_clinit_p6(); A_arbace_classes_go__init_A_clinit_p7() }

func A_arbace_classes_go__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_classes_go__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_19, 115); A_arbace_classes_go__init_A_const_0 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[17]); A_arbace_classes_go__init_A_const_1 = A_arbace_classes_go__init_A_const_pool.A[18]; A_arbace_classes_go__init_A_const_2 = A_arbace_classes_go__init_A_const_pool.A[19]; A_arbace_classes_go__init_A_const_3 = A_arbace_classes_go__init_A_const_pool.A[20]; A_arbace_classes_go__init_A_const_4 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[21]); A_arbace_classes_go__init_A_const_5 = A_arbace_classes_go__init_A_const_pool.A[22]; A_arbace_classes_go__init_A_const_6 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[23]); A_arbace_classes_go__init_A_const_7 = A_arbace_classes_go__init_A_const_pool.A[24]; A_arbace_classes_go__init_A_const_8 = A_arbace_classes_go__init_A_const_pool.A[25]; A_arbace_classes_go__init_A_const_9 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[26]); A_arbace_classes_go__init_A_const_10 = A_arbace_classes_go__init_A_const_pool.A[27]; A_arbace_classes_go__init_A_const_11 = A_arbace_classes_go__init_A_const_pool.A[28]; A_arbace_classes_go__init_A_const_12 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[29]) }

func A_arbace_classes_go__init_A_clinit_p1() { A_arbace_classes_go__init_A_const_13 = A_arbace_classes_go__init_A_const_pool.A[30]; A_arbace_classes_go__init_A_const_14 = A_arbace_classes_go__init_A_const_pool.A[31]; A_arbace_classes_go__init_A_const_15 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[32]); A_arbace_classes_go__init_A_const_16 = A_arbace_classes_go__init_A_const_pool.A[33]; A_arbace_classes_go__init_A_const_17 = A_arbace_classes_go__init_A_const_pool.A[34]; A_arbace_classes_go__init_A_const_18 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[35]); A_arbace_classes_go__init_A_const_19 = A_arbace_classes_go__init_A_const_pool.A[36]; A_arbace_classes_go__init_A_const_20 = A_arbace_classes_go__init_A_const_pool.A[37]; A_arbace_classes_go__init_A_const_21 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[38]); A_arbace_classes_go__init_A_const_22 = A_arbace_classes_go__init_A_const_pool.A[39]; A_arbace_classes_go__init_A_const_23 = A_arbace_classes_go__init_A_const_pool.A[40]; A_arbace_classes_go__init_A_const_24 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[41]); A_arbace_classes_go__init_A_const_25 = A_arbace_classes_go__init_A_const_pool.A[42]; A_arbace_classes_go__init_A_const_26 = A_arbace_classes_go__init_A_const_pool.A[43] }

func A_arbace_classes_go__init_A_clinit_p2() { A_arbace_classes_go__init_A_const_27 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[44]); A_arbace_classes_go__init_A_const_28 = A_arbace_classes_go__init_A_const_pool.A[45]; A_arbace_classes_go__init_A_const_29 = A_arbace_classes_go__init_A_const_pool.A[46]; A_arbace_classes_go__init_A_const_30 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[47]); A_arbace_classes_go__init_A_const_31 = A_arbace_classes_go__init_A_const_pool.A[48]; A_arbace_classes_go__init_A_const_32 = A_arbace_classes_go__init_A_const_pool.A[49]; A_arbace_classes_go__init_A_const_33 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[50]); A_arbace_classes_go__init_A_const_34 = A_arbace_classes_go__init_A_const_pool.A[51]; A_arbace_classes_go__init_A_const_35 = A_arbace_classes_go__init_A_const_pool.A[52]; A_arbace_classes_go__init_A_const_36 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[53]); A_arbace_classes_go__init_A_const_37 = A_arbace_classes_go__init_A_const_pool.A[54]; A_arbace_classes_go__init_A_const_38 = A_arbace_classes_go__init_A_const_pool.A[55]; A_arbace_classes_go__init_A_const_39 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[56]); A_arbace_classes_go__init_A_const_40 = A_arbace_classes_go__init_A_const_pool.A[57] }

func A_arbace_classes_go__init_A_clinit_p3() { A_arbace_classes_go__init_A_const_41 = A_arbace_classes_go__init_A_const_pool.A[58]; A_arbace_classes_go__init_A_const_42 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[59]); A_arbace_classes_go__init_A_const_43 = A_arbace_classes_go__init_A_const_pool.A[60]; A_arbace_classes_go__init_A_const_44 = A_arbace_classes_go__init_A_const_pool.A[61]; A_arbace_classes_go__init_A_const_45 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[62]); A_arbace_classes_go__init_A_const_46 = A_arbace_classes_go__init_A_const_pool.A[63]; A_arbace_classes_go__init_A_const_47 = A_arbace_classes_go__init_A_const_pool.A[64]; A_arbace_classes_go__init_A_const_48 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[65]); A_arbace_classes_go__init_A_const_49 = A_arbace_classes_go__init_A_const_pool.A[66]; A_arbace_classes_go__init_A_const_50 = A_arbace_classes_go__init_A_const_pool.A[67]; A_arbace_classes_go__init_A_const_51 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[68]); A_arbace_classes_go__init_A_const_52 = A_arbace_classes_go__init_A_const_pool.A[69]; A_arbace_classes_go__init_A_const_53 = A_arbace_classes_go__init_A_const_pool.A[70]; A_arbace_classes_go__init_A_const_54 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[71]) }

func A_arbace_classes_go__init_A_clinit_p4() { A_arbace_classes_go__init_A_const_55 = A_arbace_classes_go__init_A_const_pool.A[72]; A_arbace_classes_go__init_A_const_56 = A_arbace_classes_go__init_A_const_pool.A[73]; A_arbace_classes_go__init_A_const_57 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[74]); A_arbace_classes_go__init_A_const_58 = A_arbace_classes_go__init_A_const_pool.A[75]; A_arbace_classes_go__init_A_const_59 = A_arbace_classes_go__init_A_const_pool.A[76]; A_arbace_classes_go__init_A_const_60 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[77]); A_arbace_classes_go__init_A_const_61 = A_arbace_classes_go__init_A_const_pool.A[78]; A_arbace_classes_go__init_A_const_62 = A_arbace_classes_go__init_A_const_pool.A[79]; A_arbace_classes_go__init_A_const_63 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[80]); A_arbace_classes_go__init_A_const_64 = A_arbace_classes_go__init_A_const_pool.A[81]; A_arbace_classes_go__init_A_const_65 = A_arbace_classes_go__init_A_const_pool.A[82]; A_arbace_classes_go__init_A_const_66 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[83]); A_arbace_classes_go__init_A_const_67 = A_arbace_classes_go__init_A_const_pool.A[84]; A_arbace_classes_go__init_A_const_68 = A_arbace_classes_go__init_A_const_pool.A[85] }

func A_arbace_classes_go__init_A_clinit_p5() { A_arbace_classes_go__init_A_const_69 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[86]); A_arbace_classes_go__init_A_const_70 = A_arbace_classes_go__init_A_const_pool.A[87]; A_arbace_classes_go__init_A_const_71 = A_arbace_classes_go__init_A_const_pool.A[88]; A_arbace_classes_go__init_A_const_72 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[89]); A_arbace_classes_go__init_A_const_73 = A_arbace_classes_go__init_A_const_pool.A[90]; A_arbace_classes_go__init_A_const_74 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[91]); A_arbace_classes_go__init_A_const_75 = A_arbace_classes_go__init_A_const_pool.A[92]; A_arbace_classes_go__init_A_const_76 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[93]); A_arbace_classes_go__init_A_const_77 = A_arbace_classes_go__init_A_const_pool.A[94]; A_arbace_classes_go__init_A_const_78 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[95]); A_arbace_classes_go__init_A_const_79 = A_arbace_classes_go__init_A_const_pool.A[96]; A_arbace_classes_go__init_A_const_80 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[97]); A_arbace_classes_go__init_A_const_81 = A_arbace_classes_go__init_A_const_pool.A[98] }

func A_arbace_classes_go__init_A_clinit_p6() { A_arbace_classes_go__init_A_const_82 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[99]); A_arbace_classes_go__init_A_const_83 = A_arbace_classes_go__init_A_const_pool.A[100]; A_arbace_classes_go__init_A_const_84 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[101]); A_arbace_classes_go__init_A_const_85 = A_arbace_classes_go__init_A_const_pool.A[102]; A_arbace_classes_go__init_A_const_86 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[103]); A_arbace_classes_go__init_A_const_87 = A_arbace_classes_go__init_A_const_pool.A[104]; A_arbace_classes_go__init_A_const_88 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[105]); A_arbace_classes_go__init_A_const_89 = A_arbace_classes_go__init_A_const_pool.A[106]; A_arbace_classes_go__init_A_const_90 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[107]); A_arbace_classes_go__init_A_const_91 = A_arbace_classes_go__init_A_const_pool.A[108]; A_arbace_classes_go__init_A_const_92 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[109]); A_arbace_classes_go__init_A_const_93 = A_arbace_classes_go__init_A_const_pool.A[110]; A_arbace_classes_go__init_A_const_94 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[111]) }

func A_arbace_classes_go__init_A_clinit_p7() { A_arbace_classes_go__init_A_const_95 = A_arbace_classes_go__init_A_const_pool.A[112]; A_arbace_classes_go__init_A_const_96 = lang.Var_Cast(A_arbace_classes_go__init_A_const_pool.A[113]); A_arbace_classes_go__init_A_const_97 = A_arbace_classes_go__init_A_const_pool.A[114] }

func A_arbace_classes_go__init_A_New() *A_arbace_classes_go__init_A { A_arbace_classes_go__init_A_Init(); t := &A_arbace_classes_go__init_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_go__init_A) Ctor() {}

func (t *A_arbace_classes_go__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go__init_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go__init_A_class }

func (t *A_arbace_classes_go__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_go__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go__init_A); return ok }

func A_arbace_classes_go__init_A_Cast(x any) *A_arbace_classes_go__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go__init_A_class)) }; return v }
