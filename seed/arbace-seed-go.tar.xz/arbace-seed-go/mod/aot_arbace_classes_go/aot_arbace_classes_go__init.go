//line aot_arbace_classes_go__init.ae:1
package aot_arbace_classes_go

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_go__init_A_Unit0__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(jrt.NN(A_arbace_classes_go__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_classes_go__init_A_const_1) }
//line :1:1
func A_arbace_classes_go__init_A_Unit1__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_classes_go__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_2)) }
//line :1:1
func A_arbace_classes_go__init_A_Unit2__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_New(); var tmp2 *jrt.Class; A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_Init(); tmp2 = A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_classes_go__init_A_Unit3__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_classes_go__init_A_const_1)).Equals_O__Z(A_arbace_classes_go__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_classes_go_eval1797000008_fn__1797000009_A_New(); var tmp2 *jrt.Class; A_arbace_classes_go_eval1797000008_fn__1797000009_A_Init(); tmp2 = A_arbace_classes_go_eval1797000008_fn__1797000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_classes_go__init_A_Load__O() any { A_arbace_classes_go__init_A_Init(); A_arbace_classes_go__init_A_Unit0__O(); A_arbace_classes_go__init_A_Unit1__O(); A_arbace_classes_go__init_A_Unit2__O(); A_arbace_classes_go__init_A_Unit3__O(); A_arbace_classes_go__init_A_Unit4__O(); A_arbace_classes_go__init_A_Unit5__O(); A_arbace_classes_go__init_A_Unit6__O(); A_arbace_classes_go__init_A_Unit7__O(); A_arbace_classes_go__init_A_Unit8__O(); A_arbace_classes_go__init_A_Unit9__O(); A_arbace_classes_go__init_A_Unit10__O(); A_arbace_classes_go__init_A_Unit11__O(); A_arbace_classes_go__init_A_Unit12__O(); A_arbace_classes_go__init_A_Unit13__O(); A_arbace_classes_go__init_A_Unit14__O(); A_arbace_classes_go__init_A_Unit15__O(); A_arbace_classes_go__init_A_Unit16__O(); A_arbace_classes_go__init_A_Unit17__O(); A_arbace_classes_go__init_A_Unit18__O(); A_arbace_classes_go__init_A_Unit19__O(); A_arbace_classes_go__init_A_Unit20__O(); A_arbace_classes_go__init_A_Unit21__O(); A_arbace_classes_go__init_A_Unit22__O(); A_arbace_classes_go__init_A_Unit23__O(); A_arbace_classes_go__init_A_Unit24__O(); A_arbace_classes_go__init_A_Unit25__O(); A_arbace_classes_go__init_A_Unit26__O(); A_arbace_classes_go__init_A_Unit27__O(); A_arbace_classes_go__init_A_Unit28__O(); A_arbace_classes_go__init_A_Unit29__O(); A_arbace_classes_go__init_A_Unit30__O(); A_arbace_classes_go__init_A_Unit31__O(); A_arbace_classes_go__init_A_Unit32__O(); A_arbace_classes_go__init_A_Unit33__O(); A_arbace_classes_go__init_A_Unit34__O(); A_arbace_classes_go__init_A_Unit35__O(); A_arbace_classes_go__init_A_Unit36__O(); A_arbace_classes_go__init_A_Unit37__O(); A_arbace_classes_go__init_A_Unit38__O(); return nil }






func A_arbace_classes_go__init_A_Unit4__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(12, 1); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_4; var tmp2 any = A_arbace_classes_go_tref_A_New(); var tmp3 *jrt.Class; A_arbace_classes_go_tref_A_Init(); tmp3 = A_arbace_classes_go_tref_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_go__init_A_const_4; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_5)); return A_arbace_classes_go__init_A_const_4.Ref() }

func A_arbace_classes_go__init_A_Unit5__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(14, 1); jrt.NN(A_arbace_classes_go__init_A_const_6).BindRoot_O__V(A_arbace_classes_go__init_A_const_7); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_6; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_8)); return A_arbace_classes_go__init_A_const_6.Ref() }
func A_arbace_classes_go__init_A_Unit6__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(15, 1); jrt.NN(A_arbace_classes_go__init_A_const_9).BindRoot_O__V(A_arbace_classes_go__init_A_const_10); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_9; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_11)); return A_arbace_classes_go__init_A_const_9.Ref() }
func A_arbace_classes_go__init_A_Unit7__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(16, 1); jrt.NN(A_arbace_classes_go__init_A_const_12).BindRoot_O__V(A_arbace_classes_go__init_A_const_13); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_12; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_14)); return A_arbace_classes_go__init_A_const_12.Ref() }
func A_arbace_classes_go__init_A_Unit8__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(17, 1); jrt.NN(A_arbace_classes_go__init_A_const_15).BindRoot_O__V(A_arbace_classes_go__init_A_const_16); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_15; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_17)); return A_arbace_classes_go__init_A_const_15.Ref() }
func A_arbace_classes_go__init_A_Unit9__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(18, 1); jrt.NN(A_arbace_classes_go__init_A_const_18).BindRoot_O__V(A_arbace_classes_go__init_A_const_19); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_18; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_20)); return A_arbace_classes_go__init_A_const_18.Ref() }
func A_arbace_classes_go__init_A_Unit10__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(19, 1); jrt.NN(A_arbace_classes_go__init_A_const_21).BindRoot_O__V(A_arbace_classes_go__init_A_const_22); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_21; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_23)); return A_arbace_classes_go__init_A_const_21.Ref() }
func A_arbace_classes_go__init_A_Unit11__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(20, 1); jrt.NN(A_arbace_classes_go__init_A_const_24).BindRoot_O__V(A_arbace_classes_go__init_A_const_25); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_24; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_26)); return A_arbace_classes_go__init_A_const_24.Ref() }
func A_arbace_classes_go__init_A_Unit12__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(21, 1); jrt.NN(A_arbace_classes_go__init_A_const_27).BindRoot_O__V(A_arbace_classes_go__init_A_const_28); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_27; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_29)); return A_arbace_classes_go__init_A_const_27.Ref() }
func A_arbace_classes_go__init_A_Unit13__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(22, 1); jrt.NN(A_arbace_classes_go__init_A_const_30).BindRoot_O__V(A_arbace_classes_go__init_A_const_31); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_30; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_32)); return A_arbace_classes_go__init_A_const_30.Ref() }
func A_arbace_classes_go__init_A_Unit14__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(23, 1); jrt.NN(A_arbace_classes_go__init_A_const_33).BindRoot_O__V(A_arbace_classes_go__init_A_const_34); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_33; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_35)); return A_arbace_classes_go__init_A_const_33.Ref() }
func A_arbace_classes_go__init_A_Unit15__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(24, 1); jrt.NN(A_arbace_classes_go__init_A_const_36).BindRoot_O__V(A_arbace_classes_go__init_A_const_37); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_36; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_38)); return A_arbace_classes_go__init_A_const_36.Ref() }
func A_arbace_classes_go__init_A_Unit16__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(25, 1); jrt.NN(A_arbace_classes_go__init_A_const_39).BindRoot_O__V(A_arbace_classes_go__init_A_const_40); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_39; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_41)); return A_arbace_classes_go__init_A_const_39.Ref() }
func A_arbace_classes_go__init_A_Unit17__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(26, 1); jrt.NN(A_arbace_classes_go__init_A_const_42).BindRoot_O__V(A_arbace_classes_go__init_A_const_43); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_42; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_44)); return A_arbace_classes_go__init_A_const_42.Ref() }
func A_arbace_classes_go__init_A_Unit18__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(27, 1); jrt.NN(A_arbace_classes_go__init_A_const_45).BindRoot_O__V(A_arbace_classes_go__init_A_const_46); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_45; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_47)); return A_arbace_classes_go__init_A_const_45.Ref() }
func A_arbace_classes_go__init_A_Unit19__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(28, 1); jrt.NN(A_arbace_classes_go__init_A_const_48).BindRoot_O__V(A_arbace_classes_go__init_A_const_49); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_48; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_50)); return A_arbace_classes_go__init_A_const_48.Ref() }
func A_arbace_classes_go__init_A_Unit20__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(29, 1); jrt.NN(A_arbace_classes_go__init_A_const_51).BindRoot_O__V(A_arbace_classes_go__init_A_const_52); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_51; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_53)); return A_arbace_classes_go__init_A_const_51.Ref() }
func A_arbace_classes_go__init_A_Unit21__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(30, 1); jrt.NN(A_arbace_classes_go__init_A_const_54).BindRoot_O__V(A_arbace_classes_go__init_A_const_55); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_54; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_56)); return A_arbace_classes_go__init_A_const_54.Ref() }
func A_arbace_classes_go__init_A_Unit22__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(31, 1); jrt.NN(A_arbace_classes_go__init_A_const_57).BindRoot_O__V(A_arbace_classes_go__init_A_const_58); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_57; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_59)); return A_arbace_classes_go__init_A_const_57.Ref() }
func A_arbace_classes_go__init_A_Unit23__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(32, 1); jrt.NN(A_arbace_classes_go__init_A_const_60).BindRoot_O__V(A_arbace_classes_go__init_A_const_61); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_60; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_62)); return A_arbace_classes_go__init_A_const_60.Ref() }
func A_arbace_classes_go__init_A_Unit24__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(33, 1); jrt.NN(A_arbace_classes_go__init_A_const_63).BindRoot_O__V(A_arbace_classes_go__init_A_const_64); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_63; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_65)); return A_arbace_classes_go__init_A_const_63.Ref() }
func A_arbace_classes_go__init_A_Unit25__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(34, 1); jrt.NN(A_arbace_classes_go__init_A_const_66).BindRoot_O__V(A_arbace_classes_go__init_A_const_67); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_66; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_68)); return A_arbace_classes_go__init_A_const_66.Ref() }
func A_arbace_classes_go__init_A_Unit26__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(35, 1); jrt.NN(A_arbace_classes_go__init_A_const_69).BindRoot_O__V(A_arbace_classes_go__init_A_const_70); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_69; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_71)); return A_arbace_classes_go__init_A_const_69.Ref() }

func A_arbace_classes_go__init_A_Unit27__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(37, 1); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_72; var tmp2 any = A_arbace_classes_go_newTypeReference_A_New(); var tmp3 *jrt.Class; A_arbace_classes_go_newTypeReference_A_Init(); tmp3 = A_arbace_classes_go_newTypeReference_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_go__init_A_const_72; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_73)); return A_arbace_classes_go__init_A_const_72.Ref() }
func A_arbace_classes_go__init_A_Unit28__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(38, 1); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_74; var tmp2 any = A_arbace_classes_go_newTypeParameterReference_A_New(); var tmp3 *jrt.Class; A_arbace_classes_go_newTypeParameterReference_A_Init(); tmp3 = A_arbace_classes_go_newTypeParameterReference_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_go__init_A_const_74; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_75)); return A_arbace_classes_go__init_A_const_74.Ref() }

func A_arbace_classes_go__init_A_Unit29__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(40, 1); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_76; var tmp2 any = A_arbace_classes_go_newTypeParameterBoundReference_A_New(); var tmp3 *jrt.Class; A_arbace_classes_go_newTypeParameterBoundReference_A_Init(); tmp3 = A_arbace_classes_go_newTypeParameterBoundReference_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_go__init_A_const_76; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_77)); return A_arbace_classes_go__init_A_const_76.Ref() }

func A_arbace_classes_go__init_A_Unit30__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(42, 1); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_78; var tmp2 any = A_arbace_classes_go_newSuperTypeReference_A_New(); var tmp3 *jrt.Class; A_arbace_classes_go_newSuperTypeReference_A_Init(); tmp3 = A_arbace_classes_go_newSuperTypeReference_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_go__init_A_const_78; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_79)); return A_arbace_classes_go__init_A_const_78.Ref() }

func A_arbace_classes_go__init_A_Unit31__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(44, 1); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_80; var tmp2 any = A_arbace_classes_go_newFormalParameterReference_A_New(); var tmp3 *jrt.Class; A_arbace_classes_go_newFormalParameterReference_A_Init(); tmp3 = A_arbace_classes_go_newFormalParameterReference_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_go__init_A_const_80; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_81)); return A_arbace_classes_go__init_A_const_80.Ref() }

func A_arbace_classes_go__init_A_Unit32__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(46, 1); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_82; var tmp2 any = A_arbace_classes_go_newExceptionReference_A_New(); var tmp3 *jrt.Class; A_arbace_classes_go_newExceptionReference_A_Init(); tmp3 = A_arbace_classes_go_newExceptionReference_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_go__init_A_const_82; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_83)); return A_arbace_classes_go__init_A_const_82.Ref() }
func A_arbace_classes_go__init_A_Unit33__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(47, 1); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_84; var tmp2 any = A_arbace_classes_go_newTryCatchReference_A_New(); var tmp3 *jrt.Class; A_arbace_classes_go_newTryCatchReference_A_Init(); tmp3 = A_arbace_classes_go_newTryCatchReference_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_go__init_A_const_84; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_85)); return A_arbace_classes_go__init_A_const_84.Ref() }

func A_arbace_classes_go__init_A_Unit34__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(49, 1); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_86; var tmp2 any = A_arbace_classes_go_newTypeArgumentReference_A_New(); var tmp3 *jrt.Class; A_arbace_classes_go_newTypeArgumentReference_A_Init(); tmp3 = A_arbace_classes_go_newTypeArgumentReference_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_go__init_A_const_86; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_87)); return A_arbace_classes_go__init_A_const_86.Ref() }





func A_arbace_classes_go__init_A_Unit35__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(55, 1); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_88; var tmp2 any = A_arbace_classes_go_fn__1797000023_A_New(); var tmp3 *jrt.Class; A_arbace_classes_go_fn__1797000023_A_Init(); tmp3 = A_arbace_classes_go_fn__1797000023_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O())).Ref()); var tmp4 *lang.Var = A_arbace_classes_go__init_A_const_88; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_89)); return A_arbace_classes_go__init_A_const_88.Ref() }






func A_arbace_classes_go__init_A_Unit36__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(62, 1); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_90; var tmp2 any = A_arbace_classes_go_fn__1797000025_A_New(); var tmp3 *jrt.Class; A_arbace_classes_go_fn__1797000025_A_Init(); tmp3 = A_arbace_classes_go_fn__1797000025_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil))); var tmp4 *lang.Var = A_arbace_classes_go__init_A_const_90; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_91)); return A_arbace_classes_go__init_A_const_90.Ref() }






func A_arbace_classes_go__init_A_Unit37__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(69, 1); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_92; var tmp2 any = A_arbace_classes_go_generics_A_New(); var tmp3 *jrt.Class; A_arbace_classes_go_generics_A_Init(); tmp3 = A_arbace_classes_go_generics_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_go__init_A_const_92; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_93)); return A_arbace_classes_go__init_A_const_92.Ref() }





















func A_arbace_classes_go__init_A_Unit38__O() any { A_arbace_classes_go__init_A_Init(); lang.Compiler_AOT_At_I_I__V(91, 1); var tmp1 *lang.Var = A_arbace_classes_go__init_A_const_94; var tmp2 any = A_arbace_classes_go_constructors_A_New(); var tmp3 *jrt.Class; A_arbace_classes_go_constructors_A_Init(); tmp3 = A_arbace_classes_go_constructors_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_go__init_A_const_94; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_go__init_A_const_95)); return A_arbace_classes_go__init_A_const_94.Ref() }



type A_arbace_classes_go__init_A struct{ jrt.Object }

var A_arbace_classes_go__init_A_const_0 *lang.Var

var A_arbace_classes_go__init_A_const_1 any

var A_arbace_classes_go__init_A_const_2 any

var A_arbace_classes_go__init_A_const_3 any

var A_arbace_classes_go__init_A_const_4 *lang.Var

var A_arbace_classes_go__init_A_const_5 any

var A_arbace_classes_go__init_A_const_6 *lang.Var

var A_arbace_classes_go__init_A_const_7 any

var A_arbace_classes_go__init_A_const_8 any

var A_arbace_classes_go__init_A_const_9 *lang.Var

var A_arbace_classes_go__init_A_const_10 any

var A_arbace_classes_go__init_A_const_11 any

var A_arbace_classes_go__init_A_const_12 *lang.Var

var A_arbace_classes_go__init_A_const_13 any

var A_arbace_classes_go__init_A_const_14 any

var A_arbace_classes_go__init_A_const_15 *lang.Var

var A_arbace_classes_go__init_A_const_16 any

var A_arbace_classes_go__init_A_const_17 any

var A_arbace_classes_go__init_A_const_18 *lang.Var

var A_arbace_classes_go__init_A_const_19 any

var A_arbace_classes_go__init_A_const_20 any

var A_arbace_classes_go__init_A_const_21 *lang.Var

var A_arbace_classes_go__init_A_const_22 any

var A_arbace_classes_go__init_A_const_23 any

var A_arbace_classes_go__init_A_const_24 *lang.Var

var A_arbace_classes_go__init_A_const_25 any

var A_arbace_classes_go__init_A_const_26 any

var A_arbace_classes_go__init_A_const_27 *lang.Var

var A_arbace_classes_go__init_A_const_28 any

var A_arbace_classes_go__init_A_const_29 any

var A_arbace_classes_go__init_A_const_30 *lang.Var

var A_arbace_classes_go__init_A_const_31 any

var A_arbace_classes_go__init_A_const_32 any

var A_arbace_classes_go__init_A_const_33 *lang.Var

var A_arbace_classes_go__init_A_const_34 any

var A_arbace_classes_go__init_A_const_35 any

var A_arbace_classes_go__init_A_const_36 *lang.Var

var A_arbace_classes_go__init_A_const_37 any

var A_arbace_classes_go__init_A_const_38 any

var A_arbace_classes_go__init_A_const_39 *lang.Var

var A_arbace_classes_go__init_A_const_40 any

var A_arbace_classes_go__init_A_const_41 any

var A_arbace_classes_go__init_A_const_42 *lang.Var

var A_arbace_classes_go__init_A_const_43 any

var A_arbace_classes_go__init_A_const_44 any

var A_arbace_classes_go__init_A_const_45 *lang.Var

var A_arbace_classes_go__init_A_const_46 any

var A_arbace_classes_go__init_A_const_47 any

var A_arbace_classes_go__init_A_const_48 *lang.Var

var A_arbace_classes_go__init_A_const_49 any

var A_arbace_classes_go__init_A_const_50 any

var A_arbace_classes_go__init_A_const_51 *lang.Var

var A_arbace_classes_go__init_A_const_52 any

var A_arbace_classes_go__init_A_const_53 any

var A_arbace_classes_go__init_A_const_54 *lang.Var

var A_arbace_classes_go__init_A_const_55 any

var A_arbace_classes_go__init_A_const_56 any

var A_arbace_classes_go__init_A_const_57 *lang.Var

var A_arbace_classes_go__init_A_const_58 any

var A_arbace_classes_go__init_A_const_59 any

var A_arbace_classes_go__init_A_const_60 *lang.Var

var A_arbace_classes_go__init_A_const_61 any

var A_arbace_classes_go__init_A_const_62 any

var A_arbace_classes_go__init_A_const_63 *lang.Var

var A_arbace_classes_go__init_A_const_64 any

var A_arbace_classes_go__init_A_const_65 any

var A_arbace_classes_go__init_A_const_66 *lang.Var

var A_arbace_classes_go__init_A_const_67 any

var A_arbace_classes_go__init_A_const_68 any

var A_arbace_classes_go__init_A_const_69 *lang.Var

var A_arbace_classes_go__init_A_const_70 any

var A_arbace_classes_go__init_A_const_71 any

var A_arbace_classes_go__init_A_const_72 *lang.Var

var A_arbace_classes_go__init_A_const_73 any

var A_arbace_classes_go__init_A_const_74 *lang.Var

var A_arbace_classes_go__init_A_const_75 any

var A_arbace_classes_go__init_A_const_76 *lang.Var

var A_arbace_classes_go__init_A_const_77 any

var A_arbace_classes_go__init_A_const_78 *lang.Var

var A_arbace_classes_go__init_A_const_79 any

var A_arbace_classes_go__init_A_const_80 *lang.Var

var A_arbace_classes_go__init_A_const_81 any

var A_arbace_classes_go__init_A_const_82 *lang.Var

var A_arbace_classes_go__init_A_const_83 any

var A_arbace_classes_go__init_A_const_84 *lang.Var

var A_arbace_classes_go__init_A_const_85 any

var A_arbace_classes_go__init_A_const_86 *lang.Var

var A_arbace_classes_go__init_A_const_87 any

var A_arbace_classes_go__init_A_const_88 *lang.Var

var A_arbace_classes_go__init_A_const_89 any

var A_arbace_classes_go__init_A_const_90 *lang.Var

var A_arbace_classes_go__init_A_const_91 any

var A_arbace_classes_go__init_A_const_92 *lang.Var

var A_arbace_classes_go__init_A_const_93 any

var A_arbace_classes_go__init_A_const_94 *lang.Var

var A_arbace_classes_go__init_A_const_95 any

var A_arbace_classes_go__init_A_init jrt.ClassInit

func A_arbace_classes_go__init_A_Init() { if !A_arbace_classes_go__init_A_init.Done() { A_arbace_classes_go__init_A_init.Run(A_arbace_classes_go__init_A_clinit) } }

func A_arbace_classes_go__init_A_clinit() { A_arbace_classes_go__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_90); A_arbace_classes_go__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_11)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13))); A_arbace_classes_go__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_classes_go__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_classes_go__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_11, Lit_15); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_classes_go__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_93)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_94).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_95).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), jrt.Integer_ValueOf_I__Integer(12).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_classes_go__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_11, Lit_100); A_arbace_classes_go__init_A_const_7 = jrt.Long_ValueOf_J__Long(0).Ref(); A_arbace_classes_go__init_A_const_8 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), jrt.Integer_ValueOf_I__Integer(14).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_classes_go__init_A_const_9 = lang.RT_Var_String_String__Var(Lit_11, Lit_101); A_arbace_classes_go__init_A_const_10 = jrt.Long_ValueOf_J__Long(1).Ref(); A_arbace_classes_go__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), jrt.Integer_ValueOf_I__Integer(15).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_classes_go__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_11, Lit_16); A_arbace_classes_go__init_A_const_13 = jrt.Long_ValueOf_J__Long(16).Ref(); A_arbace_classes_go__init_A_const_14 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), jrt.Integer_ValueOf_I__Integer(16).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_classes_go__init_A_const_15 = lang.RT_Var_String_String__Var(Lit_11, Lit_102); A_arbace_classes_go__init_A_const_16 = jrt.Long_ValueOf_J__Long(17).Ref(); A_arbace_classes_go__init_A_const_17 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), jrt.Integer_ValueOf_I__Integer(17).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_classes_go__init_A_const_18 = lang.RT_Var_String_String__Var(Lit_11, Lit_103); A_arbace_classes_go__init_A_const_19 = jrt.Long_ValueOf_J__Long(18).Ref(); A_arbace_classes_go__init_A_const_20 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), jrt.Integer_ValueOf_I__Integer(18).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_classes_go__init_A_const_21 = lang.RT_Var_String_String__Var(Lit_11, Lit_104); A_arbace_classes_go__init_A_const_22 = jrt.Long_ValueOf_J__Long(19).Ref(); A_arbace_classes_go__init_A_const_23 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), jrt.Integer_ValueOf_I__Integer(19).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_classes_go__init_A_const_24 = lang.RT_Var_String_String__Var(Lit_11, Lit_105); A_arbace_classes_go__init_A_const_25 = jrt.Long_ValueOf_J__Long(20).Ref(); A_arbace_classes_go__init_A_const_26 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), jrt.Integer_ValueOf_I__Integer(20).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_classes_go__init_A_const_27 = lang.RT_Var_String_String__Var(Lit_11, Lit_106); A_arbace_classes_go__init_A_const_28 = jrt.Long_ValueOf_J__Long(21).Ref(); A_arbace_classes_go__init_A_const_29 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), jrt.Integer_ValueOf_I__Integer(21).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_classes_go__init_A_const_30 = lang.RT_Var_String_String__Var(Lit_11, Lit_17); A_arbace_classes_go__init_A_const_31 = jrt.Long_ValueOf_J__Long(22).Ref(); A_arbace_classes_go__init_A_const_32 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), jrt.Integer_ValueOf_I__Integer(22).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_classes_go__init_A_const_33 = lang.RT_Var_String_String__Var(Lit_11, Lit_18); A_arbace_classes_go__init_A_const_34 = jrt.Long_ValueOf_J__Long(23).Ref(); A_arbace_classes_go__init_A_const_35 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), jrt.Integer_ValueOf_I__Integer(23).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_classes_go__init_A_const_36 = lang.RT_Var_String_String__Var(Lit_11, Lit_107); A_arbace_classes_go__init_A_const_37 = jrt.Long_ValueOf_J__Long(64).Ref(); A_arbace_classes_go__init_A_const_38 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), jrt.Integer_ValueOf_I__Integer(24).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_classes_go__init_A_const_39 = lang.RT_Var_String_String__Var(Lit_11, Lit_108); A_arbace_classes_go__init_A_const_40 = jrt.Long_ValueOf_J__Long(65).Ref(); A_arbace_classes_go__init_A_const_41 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), jrt.Integer_ValueOf_I__Integer(25).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_classes_go__init_A_const_42 = lang.RT_Var_String_String__Var(Lit_11, Lit_19); A_arbace_classes_go__init_A_const_43 = jrt.Long_ValueOf_J__Long(66).Ref(); A_arbace_classes_go__init_A_const_44 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), jrt.Integer_ValueOf_I__Integer(26).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_classes_go__init_A_const_45 = lang.RT_Var_String_String__Var(Lit_11, Lit_109); A_arbace_classes_go__init_A_const_46 = jrt.Long_ValueOf_J__Long(67).Ref(); A_arbace_classes_go__init_A_const_47 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), jrt.Integer_ValueOf_I__Integer(27).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_classes_go__init_A_const_48 = lang.RT_Var_String_String__Var(Lit_11, Lit_110); A_arbace_classes_go__init_A_const_49 = jrt.Long_ValueOf_J__Long(68).Ref(); A_arbace_classes_go__init_A_const_50 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), jrt.Integer_ValueOf_I__Integer(28).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_classes_go__init_A_const_51 = lang.RT_Var_String_String__Var(Lit_11, Lit_111); A_arbace_classes_go__init_A_const_52 = jrt.Long_ValueOf_J__Long(69).Ref(); A_arbace_classes_go__init_A_const_53 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), jrt.Integer_ValueOf_I__Integer(29).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_classes_go__init_A_const_54 = lang.RT_Var_String_String__Var(Lit_11, Lit_112); A_arbace_classes_go__init_A_const_55 = jrt.Long_ValueOf_J__Long(70).Ref(); A_arbace_classes_go__init_A_const_56 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), jrt.Integer_ValueOf_I__Integer(30).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_classes_go__init_A_const_57 = lang.RT_Var_String_String__Var(Lit_11, Lit_113); A_arbace_classes_go__init_A_const_58 = jrt.Long_ValueOf_J__Long(71).Ref(); A_arbace_classes_go__init_A_const_59 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), jrt.Integer_ValueOf_I__Integer(31).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_classes_go__init_A_const_60 = lang.RT_Var_String_String__Var(Lit_11, Lit_114); A_arbace_classes_go__init_A_const_61 = jrt.Long_ValueOf_J__Long(72).Ref(); A_arbace_classes_go__init_A_const_62 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), jrt.Integer_ValueOf_I__Integer(32).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_classes_go__init_A_const_63 = lang.RT_Var_String_String__Var(Lit_11, Lit_115); A_arbace_classes_go__init_A_const_64 = jrt.Long_ValueOf_J__Long(73).Ref(); A_arbace_classes_go__init_A_const_65 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), jrt.Integer_ValueOf_I__Integer(33).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_classes_go__init_A_const_66 = lang.RT_Var_String_String__Var(Lit_11, Lit_116); A_arbace_classes_go__init_A_const_67 = jrt.Long_ValueOf_J__Long(74).Ref(); A_arbace_classes_go__init_A_const_68 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), jrt.Integer_ValueOf_I__Integer(34).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_classes_go__init_A_const_69 = lang.RT_Var_String_String__Var(Lit_11, Lit_117); A_arbace_classes_go__init_A_const_70 = jrt.Long_ValueOf_J__Long(75).Ref(); A_arbace_classes_go__init_A_const_71 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), jrt.Integer_ValueOf_I__Integer(35).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_classes_go__init_A_const_72 = lang.RT_Var_String_String__Var(Lit_11, Lit_118); A_arbace_classes_go__init_A_const_73 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_119).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), jrt.Integer_ValueOf_I__Integer(37).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_classes_go__init_A_const_74 = lang.RT_Var_String_String__Var(Lit_11, Lit_120); A_arbace_classes_go__init_A_const_75 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_119).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_121).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), jrt.Integer_ValueOf_I__Integer(38).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_classes_go__init_A_const_76 = lang.RT_Var_String_String__Var(Lit_11, Lit_122); A_arbace_classes_go__init_A_const_77 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_119).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_123).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_124).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), jrt.Integer_ValueOf_I__Integer(40).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_classes_go__init_A_const_78 = lang.RT_Var_String_String__Var(Lit_11, Lit_125); A_arbace_classes_go__init_A_const_79 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_121).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), jrt.Integer_ValueOf_I__Integer(42).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_classes_go__init_A_const_80 = lang.RT_Var_String_String__Var(Lit_11, Lit_126); A_arbace_classes_go__init_A_const_81 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_121).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), jrt.Integer_ValueOf_I__Integer(44).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_classes_go__init_A_const_82 = lang.RT_Var_String_String__Var(Lit_11, Lit_127); A_arbace_classes_go__init_A_const_83 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_121).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), jrt.Integer_ValueOf_I__Integer(46).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_classes_go__init_A_const_84 = lang.RT_Var_String_String__Var(Lit_11, Lit_128); A_arbace_classes_go__init_A_const_85 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_121).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), jrt.Integer_ValueOf_I__Integer(47).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_classes_go__init_A_const_86 = lang.RT_Var_String_String__Var(Lit_11, Lit_129); A_arbace_classes_go__init_A_const_87 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_119).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_121).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), jrt.Integer_ValueOf_I__Integer(49).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_classes_go__init_A_const_88 = lang.RT_Var_String_String__Var(Lit_11, Lit_130); A_arbace_classes_go__init_A_const_89 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), jrt.Integer_ValueOf_I__Integer(55).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_131)); A_arbace_classes_go__init_A_const_90 = lang.RT_Var_String_String__Var(Lit_11, Lit_55); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_classes_go__init_A_const_91 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), jrt.Integer_ValueOf_I__Integer(62).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_classes_go__init_A_const_92 = lang.RT_Var_String_String__Var(Lit_11, Lit_132); A_arbace_classes_go__init_A_const_93 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_133).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_134)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_94).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_135).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_136, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), jrt.Integer_ValueOf_I__Integer(69).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_classes_go__init_A_const_94 = lang.RT_Var_String_String__Var(Lit_11, Lit_137); A_arbace_classes_go__init_A_const_95 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_92).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_133).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_138, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), jrt.Integer_ValueOf_I__Integer(91).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)) }

func A_arbace_classes_go__init_A_New() *A_arbace_classes_go__init_A { A_arbace_classes_go__init_A_Init(); t := &A_arbace_classes_go__init_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_go__init_A) Ctor() {}

func (t *A_arbace_classes_go__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go__init_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go__init_A_class }

func (t *A_arbace_classes_go__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_go__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go__init_A); return ok }

func A_arbace_classes_go__init_A_Cast(x any) *A_arbace_classes_go__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go__init_A_class)) }; return v }
