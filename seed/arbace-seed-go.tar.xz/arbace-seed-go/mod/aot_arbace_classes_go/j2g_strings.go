//line j2g_strings.ae:1
package aot_arbace_classes_go

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn20,arbace.classes.typeskn2,asyn1,tyn13,arbace.stringyn3,strkn3,dockn4,namekn4,desckn5,flagskn6,throwskn6,paramskn6,boundskn7,methodskn4,elsekn7,tparamskn6,superskn5,ctorsv11,arbace.core7,requirev11,arbace.core5,referR0,V3,R1,R2,R3,V3,R4,R2,R5,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn17,arbace.classes.gom2,R6,s582,What the Java forms' analysis (arbace.classes.analyze) took from ASM and, in the Go build,\n  from the JVM (doc/go/CLASSFORMS-REPL.md): ASM's TypeReference (ASM left main with the bytecode\n  back end, 2026-10-12), whose type reference values (sort << 24 | ...) it computes for type\n  annotations, as ASM does, each answering getValue; and, in the Go build, the generic\n  signatures of the classes of the world, which jrt's reflection does not have\n  (arbace/classes/generics.edn, written by j2g --program), for javac's bridges.\n  arbace.classes.analyze refers to it as TypeReference.v11,arbace.core13,*loaded-libs*v17,arbace.classes.go4,trefv17,arbace.classes.go13,CLASS_EXTENDSv17,arbace.classes.go23,METHOD_FORMAL_PARAMETERv17,arbace.classes.go6,THROWSv17,arbace.classes.go19,EXCEPTION_PARAMETERv11,arbace.core11,read-stringv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core11,*read-eval*v11,arbace.core5,slurpv11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendR7,R8,v20,arbace.classes.types11,method-descR9,R10,v11,arbace.core4,mapvR11,R12,v11,arbace.core3,mapv20,arbace.classes.types11,class->descv13,arbace.string7,replacev20,arbace.classes.types14,reflect->tnodev11,arbace.core10,chunk-consv11,arbace.core5,firstv11,arbace.core4,consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,restR13,v11,arbace.core5,assocR14,R15,R16,v11,arbace.core6,removev17,arbace.classes.go14,world-genericsv11,arbace.core4,nil?R17,m8,s14,java/lang/EnumV1,V2,s22,(Ljava/lang/String;I)Vl4,s24,java/lang/MatchExceptionV1,V2,s42,(Ljava/lang/String;Ljava/lang/Throwable;)Vl1,s16,java/lang/RecordV1,V2,s3,()Vl4,s16,java/lang/ObjectV1,V2,s3,()Vl1,")

var Lit_1 *jrt.String = jrt.Intern("arbace.lang.Compiler$CFGo")

var Lit_2 *jrt.String = jrt.Intern("arbace/classes/generics.edn")

var Lit_3 *jrt.String = jrt.Intern("arbace.classes.go$generics$raw__1797000028")

var Lit_4 *jrt.String = jrt.Intern("arbace.classes.go$generics$raw__1797000028$iter__1797000029__1797000033")

var Lit_5 *jrt.String = jrt.Intern("arbace.classes.go$generics$raw__1797000028$iter__1797000029__1797000033$fn__1797000034")

var Lit_6 *jrt.String = jrt.Intern("arbace.classes.go$generics$raw__1797000028$iter__1797000029__1797000033$fn__1797000034$fn__1797000035")

var Lit_7 *jrt.String = jrt.Intern("arbace.classes.go$generics$raw__1797000028$iter__1797000029__1797000033$fn__1797000034$fn__1797000039")

var Lit_8 *jrt.String = jrt.Intern("arbace.classes.go$generics$raw__1797000028$iter__1797000029__1797000033$fn__1797000034$fn__1797000035$fn__1797000036")

var Lit_9 *jrt.String = jrt.Intern(".")

var Lit_10 *jrt.String = jrt.Intern("/")

var Lit_11 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistskn3,tagyn4,longkn4,linekn6,columnkn4,fileyn4,sortyn1,iyn1,pyn1,byn1,nyn5,Classv11,arbace.core5,in-nsMyn17,arbace.classes.gom2,R0,s582,What the Java forms' analysis (arbace.classes.analyze) took from ASM and, in the Go build,\n  from the JVM (doc/go/CLASSFORMS-REPL.md): ASM's TypeReference (ASM left main with the bytecode\n  back end, 2026-10-12), whose type reference values (sort << 24 | ...) it computes for type\n  annotations, as ASM does, each answering getValue; and, in the Go build, the generic\n  signatures of the classes of the world, which jrt's reflection does not have\n  (arbace/classes/generics.edn, written by j2g --program), for javac's bridges.\n  arbace.classes.analyze refers to it as TypeReference.m2,R0,s582,What the Java forms' analysis (arbace.classes.analyze) took from ASM and, in the Go build,\n  from the JVM (doc/go/CLASSFORMS-REPL.md): ASM's TypeReference (ASM left main with the bytecode\n  back end, 2026-10-12), whose type reference values (sort << 24 | ...) it computes for type\n  annotations, as ASM does, each answering getValue; and, in the Go build, the generic\n  signatures of the classes of the world, which jrt's reflection does not have\n  (arbace/classes/generics.edn, written by j2g --program), for javac's bridges.\n  arbace.classes.analyze refers to it as TypeReference.R1,v17,arbace.classes.go4,trefm10,R2,TR3,L1,V1,Myn1,vm2,R4,R5,R6,i12,R7,i1,R8,s20,arbace/classes/go.aev17,arbace.classes.go20,CLASS_TYPE_PARAMETERl0,m6,R6,i14,R7,i1,R8,s20,arbace/classes/go.aev17,arbace.classes.go21,METHOD_TYPE_PARAMETERl1,m6,R6,i15,R7,i1,R8,s20,arbace/classes/go.aev17,arbace.classes.go13,CLASS_EXTENDSl16,m6,R6,i16,R7,i1,R8,s20,arbace/classes/go.aev17,arbace.classes.go26,CLASS_TYPE_PARAMETER_BOUNDl17,m6,R6,i17,R7,i1,R8,s20,arbace/classes/go.aev17,arbace.classes.go27,METHOD_TYPE_PARAMETER_BOUNDl18,m6,R6,i18,R7,i1,R8,s20,arbace/classes/go.aev17,arbace.classes.go5,FIELDl19,m6,R6,i19,R7,i1,R8,s20,arbace/classes/go.aev17,arbace.classes.go13,METHOD_RETURNl20,m6,R6,i20,R7,i1,R8,s20,arbace/classes/go.aev17,arbace.classes.go15,METHOD_RECEIVERl21,m6,R6,i21,R7,i1,R8,s20,arbace/classes/go.aev17,arbace.classes.go23,METHOD_FORMAL_PARAMETERl22,m6,R6,i22,R7,i1,R8,s20,arbace/classes/go.aev17,arbace.classes.go6,THROWSl23,m6,R6,i23,R7,i1,R8,s20,arbace/classes/go.aev17,arbace.classes.go14,LOCAL_VARIABLEl64,m6,R6,i24,R7,i1,R8,s20,arbace/classes/go.aev17,arbace.classes.go17,RESOURCE_VARIABLEl65,m6,R6,i25,R7,i1,R8,s20,arbace/classes/go.aev17,arbace.classes.go19,EXCEPTION_PARAMETERl66,m6,R6,i26,R7,i1,R8,s20,arbace/classes/go.aev17,arbace.classes.go10,INSTANCEOFl67,m6,R6,i27,R7,i1,R8,s20,arbace/classes/go.aev17,arbace.classes.go3,NEWl68,m6,R6,i28,R7,i1,R8,s20,arbace/classes/go.aev17,arbace.classes.go21,CONSTRUCTOR_REFERENCEl69,m6,R6,i29,R7,i1,R8,s20,arbace/classes/go.aev17,arbace.classes.go16,METHOD_REFERENCEl70,m6,R6,i30,R7,i1,R8,s20,arbace/classes/go.aev17,arbace.classes.go4,CASTl71,m6,R6,i31,R7,i1,R8,s20,arbace/classes/go.aev17,arbace.classes.go36,CONSTRUCTOR_INVOCATION_TYPE_ARGUMENTl72,m6,R6,i32,R7,i1,R8,s20,arbace/classes/go.aev17,arbace.classes.go31,METHOD_INVOCATION_TYPE_ARGUMENTl73,m6,R6,i33,R7,i1,R8,s20,arbace/classes/go.aev17,arbace.classes.go35,CONSTRUCTOR_REFERENCE_TYPE_ARGUMENTl74,m6,R6,i34,R7,i1,R8,s20,arbace/classes/go.aev17,arbace.classes.go30,METHOD_REFERENCE_TYPE_ARGUMENTl75,m6,R6,i35,R7,i1,R8,s20,arbace/classes/go.aev17,arbace.classes.go16,newTypeReferencem8,R3,L1,V1,R9,R6,i37,R7,i1,R8,s20,arbace/classes/go.aev17,arbace.classes.go25,newTypeParameterReferencem8,R3,L1,V2,R9,R10,R6,i38,R7,i1,R8,s20,arbace/classes/go.aev17,arbace.classes.go30,newTypeParameterBoundReferencem8,R3,L1,V3,R9,R11,R12,R6,i40,R7,i1,R8,s20,arbace/classes/go.aev17,arbace.classes.go21,newSuperTypeReferencem8,R3,L1,V1,R10,R6,i42,R7,i1,R8,s20,arbace/classes/go.aev17,arbace.classes.go27,newFormalParameterReferencem8,R3,L1,V1,R10,R6,i44,R7,i1,R8,s20,arbace/classes/go.aev17,arbace.classes.go21,newExceptionReferencem8,R3,L1,V1,R10,R6,i46,R7,i1,R8,s20,arbace/classes/go.aev17,arbace.classes.go20,newTryCatchReferencem8,R3,L1,V1,R10,R6,i47,R7,i1,R8,s20,arbace/classes/go.aev17,arbace.classes.go24,newTypeArgumentReferencem8,R3,L1,V2,R9,R10,R6,i49,R7,i1,R8,s20,arbace/classes/go.aev17,arbace.classes.go9,go-build?m8,R6,i55,R7,i1,R8,s20,arbace/classes/go.aeR0,s374,Is this the Go build? The front end runs there (the Java forms at the REPL, j2g on the\n  tools' host) and on the frozen JVM Arbace (repr/java, the edge's recording: doc/STANDALONE-NOTES.md,\n  \"S4: the JVM removed\"), which reflects on the JVM's classes where the Go build reads the\n  world's signatures. The Go build's Java forms host, arbace.lang.Compiler$CFGo, is its mark.v17,arbace.classes.go14,world-genericsm8,R2,TR6,i62,R7,i1,R8,s20,arbace/classes/go.aev17,arbace.classes.go8,genericsm10,R3,L1,V2,R13,Myn1,cm2,R4,R14,R0,s209,arbace.classes.analyze/class-generics of class n (Class c), which is not being compiled: from\n  the world's generic signatures when n is generic or has generic supertypes, else its erased\n  view by reflection.R6,i69,R7,i1,R8,s20,arbace/classes/go.aev17,arbace.classes.go12,constructorsm10,R3,L1,V1,R13,R0,s181,The constructors [[descriptor flags]] of class n (internal name), which jrt's reflection does\n  not list for abstract classes: from the world's signatures, else Enum's and Record's.R6,i91,R7,i1,R8,s20,arbace/classes/go.ae")

var Lit_12 *jrt.String = jrt.Intern("arbace.classes.go$eval1797000004$loading__1927001464__auto____1797000005")

var Lit_13 *jrt.String = jrt.Intern("arbace.classes.go$eval1797000008$fn__1797000009")

var Lit_14 *jrt.String = jrt.Intern("arbace.classes.go$tref")

var Lit_15 *jrt.String = jrt.Intern("arbace.classes.go$newTypeReference")

var Lit_16 *jrt.String = jrt.Intern("arbace.classes.go$newTypeParameterReference")

var Lit_17 *jrt.String = jrt.Intern("arbace.classes.go$newTypeParameterBoundReference")

var Lit_18 *jrt.String = jrt.Intern("arbace.classes.go$newSuperTypeReference")

var Lit_19 *jrt.String = jrt.Intern("arbace.classes.go$newFormalParameterReference")

var Lit_20 *jrt.String = jrt.Intern("arbace.classes.go$newExceptionReference")

var Lit_21 *jrt.String = jrt.Intern("arbace.classes.go$newTryCatchReference")

var Lit_22 *jrt.String = jrt.Intern("arbace.classes.go$newTypeArgumentReference")

var Lit_23 *jrt.String = jrt.Intern("arbace.classes.go$fn__1797000023")

var Lit_24 *jrt.String = jrt.Intern("arbace.classes.go$fn__1797000025")

var Lit_25 *jrt.String = jrt.Intern("arbace.classes.go$generics")

var Lit_26 *jrt.String = jrt.Intern("arbace.classes.go$constructors")
