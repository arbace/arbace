//line j2g_classes.ae:1
package aot_arbace_classes_go

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_classes_go_constructors_A_class, Name: "arbace.classes.go$constructors", Modifiers: 25, Simple: "constructors", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_constructors_A", Source: "go.ae", Declaring: &A_arbace_classes_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_class, Name: "arbace.classes.go$eval1797000004$loading__1927001464__auto____1797000005", Modifiers: 25, Simple: "loading__1927001464__auto____1797000005", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A", Source: "go.ae", Declaring: &A_arbace_classes_go_eval1797000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_go_eval1797000008_fn__1797000009_A_class, Name: "arbace.classes.go$eval1797000008$fn__1797000009", Modifiers: 25, Simple: "fn__1797000009", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_eval1797000008_fn__1797000009_A", Source: "go.ae", Declaring: &A_arbace_classes_go_eval1797000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_go_fn__1797000023_A_class, Name: "arbace.classes.go$fn__1797000023", Modifiers: 25, Simple: "fn__1797000023", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_fn__1797000023_A", Source: "go.ae", Declaring: &A_arbace_classes_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_go_fn__1797000025_A_class, Name: "arbace.classes.go$fn__1797000025", Modifiers: 25, Simple: "fn__1797000025", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_fn__1797000025_A", Source: "go.ae", Declaring: &A_arbace_classes_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_go_generics_A_class, Name: "arbace.classes.go$generics", Modifiers: 25, Simple: "generics", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_generics_A", Source: "go.ae", Declaring: &A_arbace_classes_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_classes_go_generics_raw__1797000028_A_class, Name: "arbace.classes.go$generics$raw__1797000028", Modifiers: 25, Simple: "raw__1797000028", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_generics_raw__1797000028_A", Source: "go.ae", Declaring: &A_arbace_classes_go_generics_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_class, Name: "arbace.classes.go$generics$raw__1797000028$iter__1797000029__1797000033", Modifiers: 25, Simple: "iter__1797000029__1797000033", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A", Source: "go.ae", Declaring: &A_arbace_classes_go_generics_raw__1797000028_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_class, Name: "arbace.classes.go$generics$raw__1797000028$iter__1797000029__1797000033$fn__1797000034", Modifiers: 25, Simple: "fn__1797000034", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A", Source: "go.ae", Declaring: &A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_class, Name: "arbace.classes.go$generics$raw__1797000028$iter__1797000029__1797000033$fn__1797000034$fn__1797000035", Modifiers: 25, Simple: "fn__1797000035", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A", Source: "go.ae", Declaring: &A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_class, Name: "arbace.classes.go$generics$raw__1797000028$iter__1797000029__1797000033$fn__1797000034$fn__1797000035$fn__1797000036", Modifiers: 25, Simple: "fn__1797000036", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A", Source: "go.ae", Declaring: &A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_class, Name: "arbace.classes.go$generics$raw__1797000028$iter__1797000029__1797000033$fn__1797000034$fn__1797000039", Modifiers: 25, Simple: "fn__1797000039", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A", Source: "go.ae", Declaring: &A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_go_newExceptionReference_A_class, Name: "arbace.classes.go$newExceptionReference", Modifiers: 25, Simple: "newExceptionReference", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_newExceptionReference_A", Source: "go.ae", Declaring: &A_arbace_classes_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_go_newFormalParameterReference_A_class, Name: "arbace.classes.go$newFormalParameterReference", Modifiers: 25, Simple: "newFormalParameterReference", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_newFormalParameterReference_A", Source: "go.ae", Declaring: &A_arbace_classes_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_go_newSuperTypeReference_A_class, Name: "arbace.classes.go$newSuperTypeReference", Modifiers: 25, Simple: "newSuperTypeReference", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_newSuperTypeReference_A", Source: "go.ae", Declaring: &A_arbace_classes_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_go_newTryCatchReference_A_class, Name: "arbace.classes.go$newTryCatchReference", Modifiers: 25, Simple: "newTryCatchReference", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_newTryCatchReference_A", Source: "go.ae", Declaring: &A_arbace_classes_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_go_newTypeArgumentReference_A_class, Name: "arbace.classes.go$newTypeArgumentReference", Modifiers: 25, Simple: "newTypeArgumentReference", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_newTypeArgumentReference_A", Source: "go.ae", Declaring: &A_arbace_classes_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_classes_go_newTypeParameterBoundReference_A_class, Name: "arbace.classes.go$newTypeParameterBoundReference", Modifiers: 25, Simple: "newTypeParameterBoundReference", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_newTypeParameterBoundReference_A", Source: "go.ae", Declaring: &A_arbace_classes_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_classes_go_newTypeParameterReference_A_class, Name: "arbace.classes.go$newTypeParameterReference", Modifiers: 25, Simple: "newTypeParameterReference", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_newTypeParameterReference_A", Source: "go.ae", Declaring: &A_arbace_classes_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_classes_go_newTypeReference_A_class, Name: "arbace.classes.go$newTypeReference", Modifiers: 25, Simple: "newTypeReference", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_newTypeReference_A", Source: "go.ae", Declaring: &A_arbace_classes_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_go_tref_A_class, Name: "arbace.classes.go$tref", Modifiers: 25, Simple: "tref", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_tref_A", Source: "go.ae", Declaring: &A_arbace_classes_go_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_classes_go_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_go_A_New()}; return nil }

var A_arbace_classes_go_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_go_A_new}

var A_arbace_classes_go_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.go", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_A"})

func init() { i := A_arbace_classes_go_A_class.Info(); i.IsInstance = A_arbace_classes_go_A_InstanceOf; i.Init = A_arbace_classes_go_A_Init; i.Table = A_arbace_classes_go_A_members }

var A_arbace_classes_go_constructors_A_class *jrt.Class

func A_arbace_classes_go_eval1797000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_go_eval1797000004_A_New()}; return nil }

var A_arbace_classes_go_eval1797000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_go_eval1797000004_A_new}

var A_arbace_classes_go_eval1797000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.go$eval1797000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_go_A_class, Simple: "eval1797000004", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_eval1797000004_A"})

func init() { i := A_arbace_classes_go_eval1797000004_A_class.Info(); i.IsInstance = A_arbace_classes_go_eval1797000004_A_InstanceOf; i.Table = A_arbace_classes_go_eval1797000004_A_members }

var A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_class *jrt.Class

func A_arbace_classes_go_eval1797000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_go_eval1797000008_A_New()}; return nil }

var A_arbace_classes_go_eval1797000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_go_eval1797000008_A_new}

var A_arbace_classes_go_eval1797000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.go$eval1797000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_go_A_class, Simple: "eval1797000008", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_eval1797000008_A"})

func init() { i := A_arbace_classes_go_eval1797000008_A_class.Info(); i.IsInstance = A_arbace_classes_go_eval1797000008_A_InstanceOf; i.Table = A_arbace_classes_go_eval1797000008_A_members }

var A_arbace_classes_go_eval1797000008_fn__1797000009_A_class *jrt.Class

var A_arbace_classes_go_fn__1797000023_A_class *jrt.Class

var A_arbace_classes_go_fn__1797000025_A_class *jrt.Class

var A_arbace_classes_go_generics_A_class *jrt.Class

var A_arbace_classes_go_generics_raw__1797000028_A_class *jrt.Class

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_class *jrt.Class

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_class *jrt.Class

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_class *jrt.Class

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_class *jrt.Class

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_class *jrt.Class

var A_arbace_classes_go_newExceptionReference_A_class *jrt.Class

var A_arbace_classes_go_newFormalParameterReference_A_class *jrt.Class

var A_arbace_classes_go_newSuperTypeReference_A_class *jrt.Class

var A_arbace_classes_go_newTryCatchReference_A_class *jrt.Class

var A_arbace_classes_go_newTypeArgumentReference_A_class *jrt.Class

var A_arbace_classes_go_newTypeParameterBoundReference_A_class *jrt.Class

var A_arbace_classes_go_newTypeParameterReference_A_class *jrt.Class

var A_arbace_classes_go_newTypeReference_A_class *jrt.Class

var A_arbace_classes_go_tref_A_class *jrt.Class

func A_arbace_classes_go_tref_reify__1797000012_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_go_tref_reify__1797000012_A).GetKey__O(); case 1: return this.(*A_arbace_classes_go_tref_reify__1797000012_A).GetValue__O(); case 2: return this.(*A_arbace_classes_go_tref_reify__1797000012_A).Meta__IPersistentMap(); case 3: return this.(*A_arbace_classes_go_tref_reify__1797000012_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0]))}; return nil }

func A_arbace_classes_go_tref_reify__1797000012_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_go_tref_reify__1797000012_A_New_IPersistentMap_J(jrt.As[lang.IPersistentMap](args[0]), args[1].(int64))}; return nil }

var A_arbace_classes_go_tref_reify__1797000012_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 getKey ()Ljava.lang.Object;\nM1 getValue ()Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nC1 (Larbace.lang.IPersistentMap;J)V", Invoke: A_arbace_classes_go_tref_reify__1797000012_A_invoke, New: A_arbace_classes_go_tref_reify__1797000012_A_new}

var A_arbace_classes_go_tref_reify__1797000012_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.go$tref$reify__1797000012", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{jrt.Map_Entry_class, lang.IObj_class}, Declaring: A_arbace_classes_go_tref_A_class, Simple: "reify__1797000012", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_tref_reify__1797000012_A", Source: "go.ae"})

func init() { i := A_arbace_classes_go_tref_reify__1797000012_A_class.Info(); i.IsInstance = A_arbace_classes_go_tref_reify__1797000012_A_InstanceOf; i.Table = A_arbace_classes_go_tref_reify__1797000012_A_members }

func A_arbace_classes_go__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_classes_go__init_A_Load__O()}; return nil }

func A_arbace_classes_go__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_go__init_A_New()}; return nil }

var A_arbace_classes_go__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_classes_go__init_A_invoke, New: A_arbace_classes_go__init_A_new}

var A_arbace_classes_go__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.go__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go__init_A", Source: "go.ae"})

func init() { i := A_arbace_classes_go__init_A_class.Info(); i.IsInstance = A_arbace_classes_go__init_A_InstanceOf; i.Init = A_arbace_classes_go__init_A_Init; i.Table = A_arbace_classes_go__init_A_members }
