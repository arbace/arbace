//line aot_arbace_classes_go.ae:1
package aot_arbace_classes_go

import (
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_New() *A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_classes_go_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_go_A_const_4); tmp2 = lang.IFn_Cast(A_arbace_classes_go_A_const_0.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_go_A_const_1, A_arbace_classes_go_A_const_2); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_classes_go_eval1797000008_fn__1797000009_A_New() *A_arbace_classes_go_eval1797000008_fn__1797000009_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_eval1797000008_fn__1797000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_go_eval1797000008_fn__1797000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_go_eval1797000008_fn__1797000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_go_A_const_5.GetRawRoot__O()); var tmp2 any; var root_16 any = A_arbace_classes_go_A_const_6.GetRawRoot__O(); var linked_17 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_16, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_18 lang.IFn; if linked_17 == nil { ifn_18 = lang.IFn_Cast(root_16) } else { ifn_18 = nil }; var arg_19 any = A_arbace_classes_go_A_const_7; if linked_17 == nil { tmp2 = ifn_18.Invoke_O__O(arg_19) } else { tmp2 = linked_17.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_16, arg_19) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_classes_go_A_const_8.GetRawRoot__O(), A_arbace_classes_go_A_const_9) }










func A_arbace_classes_go_tref_A_New() *A_arbace_classes_go_tref_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_tref_A{}; t.Ctor(); return t }
//line :12:1
func (t *A_arbace_classes_go_tref_A) Ctor() {}
//line :12:1
func (t *A_arbace_classes_go_tref_A) InvokePrim_O_J__O(self any, v__0 int64) any { return A_arbace_classes_go_tref_reify__1797000012_A_New_IPersistentMap_J(nil, v__0) }
//line :12:1
func (t *A_arbace_classes_go_tref_A) Invoke_O_O__O(self, p_v__0 any) any { return t.InvokePrim_O_J__O(self, lang.RT_LongCast_O__J_NoInit(p_v__0)) }
//line :12:1
func A_arbace_classes_go_tref_reify__1797000012_A_New_IPersistentMap_J(p0 lang.IPersistentMap, p1 int64) *A_arbace_classes_go_tref_reify__1797000012_A { t := &A_arbace_classes_go_tref_reify__1797000012_A{}; t.Ctor_IPersistentMap_J(p0, p1); return t }
//line :12:1
func (t *A_arbace_classes_go_tref_reify__1797000012_A) Ctor_IPersistentMap_J(meta__ lang.IPersistentMap, c__v int64) { t.F___meta = meta__; t.F_v = c__v }
//line :12:1
func (t *A_arbace_classes_go_tref_reify__1797000012_A) GetValue__O() any { return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_J__I_NoInit(t.F_v)).Ref() }
//line :12:1
func (t *A_arbace_classes_go_tref_reify__1797000012_A) GetKey__O() any { return nil }
//line :12:1
func (t *A_arbace_classes_go_tref_reify__1797000012_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :12:1
func (t *A_arbace_classes_go_tref_reify__1797000012_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_classes_go_tref_reify__1797000012_A_New_IPersistentMap_J(m, t.F_v) }
























func A_arbace_classes_go_newTypeReference_A_New() *A_arbace_classes_go_newTypeReference_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_newTypeReference_A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_classes_go_newTypeReference_A) Ctor() {}
//line :37:1
func (t *A_arbace_classes_go_newTypeReference_A) Invoke_O_O__O(self, sort__0 any) any { var root_20 any = A_arbace_classes_go_A_const_10.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_20, A_arbace_classes_go_tref_A_fn_class); var ifn_22 lang.IFn; if linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 int64 = lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(sort__0), 24); if linked_21 == nil { return ifn_22.Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_23).Ref()) } else { return linked_21.(*A_arbace_classes_go_tref_A).InvokePrim_O_J__O(root_20, arg_23) } }
func A_arbace_classes_go_newTypeParameterReference_A_New() *A_arbace_classes_go_newTypeParameterReference_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_newTypeParameterReference_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_classes_go_newTypeParameterReference_A) Ctor() {}
//line :38:1
func (t *A_arbace_classes_go_newTypeParameterReference_A) Invoke_O_O_O__O(self, sort__0, i__1 any) any {
	var root_24 any = A_arbace_classes_go_A_const_10.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_24, A_arbace_classes_go_tref_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 int64 = lang.Numbers_Or_J_J__J_NoInit(lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(sort__0), 24), lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(i__1), 16)); if linked_25 == nil { return ifn_26.Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_27).Ref()) } else { return linked_25.(*A_arbace_classes_go_tref_A).InvokePrim_O_J__O(root_24, arg_27) } }
func A_arbace_classes_go_newTypeParameterBoundReference_A_New() *A_arbace_classes_go_newTypeParameterBoundReference_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_newTypeParameterBoundReference_A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_classes_go_newTypeParameterBoundReference_A) Ctor() {}
//line :40:1
func (t *A_arbace_classes_go_newTypeParameterBoundReference_A) Invoke_O_O_O_O__O(self, sort__0, p__1, b__2 any) any {
	var root_28 any = A_arbace_classes_go_A_const_10.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_28, A_arbace_classes_go_tref_A_fn_class); var ifn_30 lang.IFn; if linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 int64 = lang.Numbers_Or_J_J__J_NoInit(lang.Numbers_Or_J_J__J_NoInit(lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(sort__0), 24), lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(p__1), 16)), lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(b__2), 8)); if linked_29 == nil { return ifn_30.Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_31).Ref()) } else { return linked_29.(*A_arbace_classes_go_tref_A).InvokePrim_O_J__O(root_28, arg_31) } }
func A_arbace_classes_go_newSuperTypeReference_A_New() *A_arbace_classes_go_newSuperTypeReference_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_newSuperTypeReference_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_classes_go_newSuperTypeReference_A) Ctor() {}
//line :42:1
func (t *A_arbace_classes_go_newSuperTypeReference_A) Invoke_O_O__O(self, i__0 any) any {
	var root_32 any = A_arbace_classes_go_A_const_10.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_32, A_arbace_classes_go_tref_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 int64; var tmp1 int64; var na_36 any = A_arbace_classes_go_A_const_11.GetRawRoot__O(); var na_37 int64 = 24; if jrt.Long_InstanceOf(na_36) { var n0_38 int64 = jrt.NN(jrt.Long_Cast(na_36)).LongValue__J(); var n1_39 int64 = na_37; tmp1 = n0_38 << (n1_39 & 63) } else { tmp1 = lang.Numbers_ShiftLeft_O_J__J_NoInit(na_36, na_37) }; arg_35 = lang.Numbers_Or_J_J__J_NoInit(tmp1, lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(i__0), 65535), 8)); if linked_33 == nil { return ifn_34.Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_35).Ref()) } else { return linked_33.(*A_arbace_classes_go_tref_A).InvokePrim_O_J__O(root_32, arg_35) } }
func A_arbace_classes_go_newFormalParameterReference_A_New() *A_arbace_classes_go_newFormalParameterReference_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_newFormalParameterReference_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_classes_go_newFormalParameterReference_A) Ctor() {}
//line :44:1
func (t *A_arbace_classes_go_newFormalParameterReference_A) Invoke_O_O__O(self, i__0 any) any {
	var root_41 any = A_arbace_classes_go_A_const_10.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_41, A_arbace_classes_go_tref_A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 int64; var tmp1 int64; var na_45 any = A_arbace_classes_go_A_const_12.GetRawRoot__O(); var na_46 int64 = 24; if jrt.Long_InstanceOf(na_45) { var n0_47 int64 = jrt.NN(jrt.Long_Cast(na_45)).LongValue__J(); var n1_48 int64 = na_46; tmp1 = n0_47 << (n1_48 & 63) } else { tmp1 = lang.Numbers_ShiftLeft_O_J__J_NoInit(na_45, na_46) }; arg_44 = lang.Numbers_Or_J_J__J_NoInit(tmp1, lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(i__0), 16)); if linked_42 == nil { return ifn_43.Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_44).Ref()) } else { return linked_42.(*A_arbace_classes_go_tref_A).InvokePrim_O_J__O(root_41, arg_44) } }
func A_arbace_classes_go_newExceptionReference_A_New() *A_arbace_classes_go_newExceptionReference_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_newExceptionReference_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_classes_go_newExceptionReference_A) Ctor() {}
//line :46:1
func (t *A_arbace_classes_go_newExceptionReference_A) Invoke_O_O__O(self, i__0 any) any { var root_50 any = A_arbace_classes_go_A_const_10.GetRawRoot__O(); var linked_51 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_50, A_arbace_classes_go_tref_A_fn_class); var ifn_52 lang.IFn; if linked_51 == nil { ifn_52 = lang.IFn_Cast(root_50) } else { ifn_52 = nil }; var arg_53 int64; var tmp1 int64; var na_54 any = A_arbace_classes_go_A_const_13.GetRawRoot__O(); var na_55 int64 = 24; if jrt.Long_InstanceOf(na_54) { var n0_56 int64 = jrt.NN(jrt.Long_Cast(na_54)).LongValue__J(); var n1_57 int64 = na_55; tmp1 = n0_56 << (n1_57 & 63) } else { tmp1 = lang.Numbers_ShiftLeft_O_J__J_NoInit(na_54, na_55) }; arg_53 = lang.Numbers_Or_J_J__J_NoInit(tmp1, lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(i__0), 8)); if linked_51 == nil { return ifn_52.Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_53).Ref()) } else { return linked_51.(*A_arbace_classes_go_tref_A).InvokePrim_O_J__O(root_50, arg_53) } }
func A_arbace_classes_go_newTryCatchReference_A_New() *A_arbace_classes_go_newTryCatchReference_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_newTryCatchReference_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_classes_go_newTryCatchReference_A) Ctor() {}
//line :47:1
func (t *A_arbace_classes_go_newTryCatchReference_A) Invoke_O_O__O(self, i__0 any) any {
	var root_59 any = A_arbace_classes_go_A_const_10.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_59, A_arbace_classes_go_tref_A_fn_class); var ifn_61 lang.IFn; if linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 int64; var tmp1 int64; var na_63 any = A_arbace_classes_go_A_const_14.GetRawRoot__O(); var na_64 int64 = 24; if jrt.Long_InstanceOf(na_63) { var n0_65 int64 = jrt.NN(jrt.Long_Cast(na_63)).LongValue__J(); var n1_66 int64 = na_64; tmp1 = n0_65 << (n1_66 & 63) } else { tmp1 = lang.Numbers_ShiftLeft_O_J__J_NoInit(na_63, na_64) }; arg_62 = lang.Numbers_Or_J_J__J_NoInit(tmp1, lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(i__0), 8)); if linked_60 == nil { return ifn_61.Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_62).Ref()) } else { return linked_60.(*A_arbace_classes_go_tref_A).InvokePrim_O_J__O(root_59, arg_62) } }
func A_arbace_classes_go_newTypeArgumentReference_A_New() *A_arbace_classes_go_newTypeArgumentReference_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_newTypeArgumentReference_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_classes_go_newTypeArgumentReference_A) Ctor() {}
//line :49:1
func (t *A_arbace_classes_go_newTypeArgumentReference_A) Invoke_O_O_O__O(self, sort__0, i__1 any) any {
	var root_68 any = A_arbace_classes_go_A_const_10.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_68, A_arbace_classes_go_tref_A_fn_class); var ifn_70 lang.IFn; if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 int64 = lang.Numbers_Or_J_J__J_NoInit(lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(sort__0), 24), lang.RT_LongCast_O__J_NoInit(i__1)); if linked_69 == nil { return ifn_70.Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_71).Ref()) } else { return linked_69.(*A_arbace_classes_go_tref_A).InvokePrim_O_J__O(root_68, arg_71)
	}
}







func A_arbace_classes_go_fn__1797000023_A_New() *A_arbace_classes_go_fn__1797000023_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_fn__1797000023_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_classes_go_fn__1797000023_A) Ctor() {}
//line :60:1
func (t *A_arbace_classes_go_fn__1797000023_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = jrt.Class_ForName_String__Class(Lit_1).Ref(); return nil }(); if tmp2 != nil { if true { var ___3 jrt.Throwable_I = tmp2; _ = ___3; tmp1 = nil } }; return tmp1 }


func A_arbace_classes_go_fn__1797000025_A_New() *A_arbace_classes_go_fn__1797000025_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_fn__1797000025_A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_classes_go_fn__1797000025_A) Ctor() {}
//line :63:1
func (t *A_arbace_classes_go_fn__1797000025_A) Invoke_O__O(self any) any { var temp__1927000408__auto____1 any = lang.RT_ResourceAsStream_ClassLoader_String__InputStream_NoInit(nil, Lit_2); if
										jrt.J2g_Truth(temp__1927000408__auto____1) { var in__2 any = temp__1927000408__auto____1; var root_83 any = A_arbace_classes_go_A_const_18.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_83, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_85 lang.IFn
											if linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any = lang.IFn_Cast(A_arbace_classes_go_A_const_19.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_go_A_const_20, jrt.Boolean_FALSE.Ref()); if linked_84 == nil { ifn_85.Invoke_O__O(arg_86) } else { linked_84.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_83, arg_86) }
//line :64:1
		var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

			{ var root_72 any = A_arbace_classes_go_A_const_15.GetRawRoot__O(); var linked_73 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_72, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_74 lang.IFn; if linked_73 == nil { ifn_74 = lang.IFn_Cast(root_72) } else { ifn_74 = nil }; var arg_75 any = lang.IFn_Cast(A_arbace_classes_go_A_const_16.GetRawRoot__O()).Invoke_O__O(in__2); if linked_73 == nil { tmp1 = ifn_74.Invoke_O__O(arg_75) } else { tmp1 = linked_73.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_72, arg_75) } }
//line :64:1
			return nil }(); var root_80 any = A_arbace_classes_go_A_const_17.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_82 lang.IFn
		if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; if linked_81 == nil { ifn_82.Invoke__O() } else { linked_81.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_80) }
//line :64:1
		if tmp2 != nil { panic(tmp2) }; return tmp1 } else { return lang.PersistentArrayMap_EMPTY.Ref() } }






func A_arbace_classes_go_generics_A_New() *A_arbace_classes_go_generics_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_generics_A{}; t.Ctor(); return t }
//line :71:1
func (t *A_arbace_classes_go_generics_A) Ctor() {}
//line :71:1
func (t *A_arbace_classes_go_generics_A) Invoke_O_O_O__O(self, n__0, c__1 any) any { var g__3 any; var tmp1 any; var root_92 any = A_arbace_classes_go_A_const_6.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_94 lang.IFn; if




	linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any = A_arbace_classes_go_A_const_21.GetRawRoot__O(); if linked_93 == nil { tmp1 = ifn_94.Invoke_O__O(arg_95) } else { tmp1 = linked_93.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_92, arg_95) }; g__3 = lang.RT_Get_O_O__O_NoInit(tmp1, n__0); var raw__4 any; var fnbody__223 any = /*line :71:1*/A_arbace_classes_go_generics_raw__1797000028_A_New_O(c__1); var tmp2 *jrt.Class; var fncls__222 *jrt.Class = A_arbace_classes_go_generics_raw__1797000028_A_fn_class; if





	fncls__222 == nil { var fncls__222d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, fnbody__223); A_arbace_classes_go_generics_raw__1797000028_A_fn_class = fncls__222d; tmp2 = fncls__222d } else { tmp2 = fncls__222 }; raw__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__223, tmp2, nil); var raw__5 any; var fnbody__344 any = /*line :71:1*/A_arbace_classes_go_generics_raw__1797000044_A_New_O_O(raw__4, n__0); var tmp3 *jrt.Class; var fncls__343 *jrt.Class = A_arbace_classes_go_generics_raw__1797000044_A_fn_class; if















	fncls__343 == nil { var fncls__343d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, fnbody__344); A_arbace_classes_go_generics_raw__1797000044_A_fn_class = fncls__343d; tmp3 = fncls__343d } else { tmp3 = fncls__343 }; raw__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__344, tmp3, nil); var tmp4 any; var and__1927000168__auto____6 any = g__3; if








	jrt.J2g_Truth(and__1927000168__auto____6) { tmp4 = A_arbace_classes_go_A_const_52.Invoke_O__O(g__3) } else { tmp4 = and__1927000168__auto____6 }; if /*line :95:1*/ jrt.J2g_Truth(tmp4) { return g__3 } else { if jrt.J2g_Truth(g__3) {

		var root_345 any = A_arbace_classes_go_A_const_54.GetRawRoot__O(); var linked_346 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_345, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_347 lang.IFn; if linked_346 == nil { ifn_347 = lang.IFn_Cast(root_345) } else { ifn_347 = nil }; var arg_348 any = g__3; var arg_349 any = A_arbace_classes_go_A_const_52; var arg_350 any = lang.IFn_Cast(raw__5).Invoke__O(); if linked_346 == nil { return ifn_347.Invoke_O_O_O__O(arg_348, arg_349, arg_350) } else { return linked_346.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_345, arg_348, arg_349, arg_350) } } else {
//line :95:1
			if A_arbace_classes_go_A_const_55 != nil { var tmp5 any = A_arbace_classes_go_A_const_56; var tmp6 any = lang.PersistentVector_EMPTY.Ref(); var tmp7 any = A_arbace_classes_go_A_const_57; var tmp8 any; var root_351 any = A_arbace_classes_go_A_const_58.GetRawRoot__O(); var linked_352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_351, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_353 lang.IFn



				if linked_352 == nil { ifn_353 = lang.IFn_Cast(root_351) } else { ifn_353 = nil }; var arg_354 any = A_arbace_classes_go_A_const_59.GetRawRoot__O(); var arg_355 any; var root_356 any = A_arbace_classes_go_A_const_43.GetRawRoot__O(); var linked_357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_356, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_358 lang.IFn; if linked_357 == nil { ifn_358 = lang.IFn_Cast(root_356) } else { ifn_358 = nil }; var arg_359 any; var G__1797000068__6_ any = jrt.NN(jrt.Class_Cast(c__1)).GetSuperclass__Class().Ref(); if lang.Util_Identical_O_O__Z_NoInit(G__1797000068__6_, nil) { arg_359 = nil } else { var root_361 any = A_arbace_classes_go_A_const_37.GetRawRoot__O(); var linked_362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_361, aot_arbace_classes_types.A_arbace_classes_types_reflect__GT_tnode_A_fn_class); var ifn_363 lang.IFn; if linked_362 == nil { ifn_363 = lang.IFn_Cast(root_361) } else { ifn_363 = nil }; var arg_364 any = G__1797000068__6_; if linked_362 == nil { arg_359 = ifn_363.Invoke_O__O(arg_364) } else { arg_359 = linked_362.(*aot_arbace_classes_types.A_arbace_classes_types_reflect__GT_tnode_A).Invoke_O_O__O(root_361, arg_364) } }; var arg_360 any; var root_365 any = A_arbace_classes_go_A_const_30.GetRawRoot__O(); var linked_366 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_365, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_367 lang.IFn
				if linked_366 == nil { ifn_367 = lang.IFn_Cast(root_365) } else { ifn_367 = nil }; var arg_368 any = A_arbace_classes_go_A_const_37.GetRawRoot__O(); var arg_369 any = jrt.NN(jrt.Class_Cast(c__1)).GetInterfaces__Class1().Ref(); if linked_366 == nil { arg_360 = ifn_367.Invoke_O_O__O(arg_368, arg_369) } else { arg_360 = linked_366.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_365, arg_368, arg_369) }
//line :99:1
				if linked_357 == nil { arg_355 = ifn_358.Invoke_O_O__O(arg_359, arg_360) } else { arg_355 = linked_357.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_356, arg_359, arg_360) }; if linked_352 == nil { tmp8 = ifn_353.Invoke_O_O__O(arg_354, arg_355) } else { tmp8 = linked_352.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_351, arg_354, arg_355) }
//line :95:1
				var tmp9 any = tmp8; var tmp10 any = A_arbace_classes_go_A_const_52; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, tmp9, tmp10, lang.IFn_Cast(raw__5).Invoke__O())) } else { return nil } } } }
//line :77:1
func A_arbace_classes_go_generics_raw__1797000028_A_New_O(p0 any) *A_arbace_classes_go_generics_raw__1797000028_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_generics_raw__1797000028_A{}; t.Ctor_O(p0); return t }
//line :77:1
func (t *A_arbace_classes_go_generics_raw__1797000028_A) Ctor_O(c__c any) { t.F_c = c__c }
//line :77:1
func (t *A_arbace_classes_go_generics_raw__1797000028_A) Invoke_O__O(self any) any { var iter__1927001039__auto____1 any; var fnbody__221 any = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_New(); var tmp1 *jrt.Class; var fncls__220 *jrt.Class = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_fn_class; if
											fncls__220 == nil { var fncls__220d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, nil); A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_fn_class = fncls__220d; tmp1 = fncls__220d } else { tmp1 = fncls__220 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__221, tmp1, nil); return lang.IFn_Cast(iter__1927001039__auto____1).Invoke_O__O(jrt.NN(jrt.Class_Cast(t.F_c)).GetDeclaredMethods__Method1().Ref()) }
//line :78:1
func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_New() *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A{}; t.Ctor(); return t }
//line :78:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A) Ctor() {}
//line :78:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A) Invoke_O_O__O(self, s__1797000030__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__219 any = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_New_O_O(self, s__1797000030__1); var tmp2 *jrt.Class; var fncls__218 *jrt.Class = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_fn_class; if fncls__218 == nil { var fncls__218d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, false, fnbody__219); A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_fn_class = fncls__218d; tmp2 = fncls__218d } else { tmp2 = fncls__218 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__219, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :78:1
func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_New_O_O(p0, p1 any) *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A{}; t.Ctor_O_O(p0, p1); return t }
//line :78:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A) Ctor_O_O(c__iter__1797000029, c__s__1797000030 any) { t.F_iter__1797000029 = c__iter__1797000029; t.F_s__1797000030 = c__s__1797000030 }
//line :78:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A) Invoke_O__O(self any) any { { var s__1797000030__1 any; var t_ any = t.F_s__1797000030; t.F_s__1797000030 = nil; s__1797000030__1 = t_; for { var temp__1927000414__auto____2 any; var root_96 any = A_arbace_classes_go_A_const_22.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_98 lang.IFn; if linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any = s__1797000030__1; if linked_97 == nil { temp__1927000414__auto____2 = ifn_98.Invoke_O__O(arg_99) } else { temp__1927000414__auto____2 = linked_97.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_96, arg_99) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1797000030__3 any = temp__1927000414__auto____2; var tmp1 any; var root_100 any = A_arbace_classes_go_A_const_23.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = s__1797000030__3; if linked_101 == nil { tmp1 = ifn_102.Invoke_O__O(arg_103) } else { tmp1 = linked_101.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_100, arg_103) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_104 any = A_arbace_classes_go_A_const_24.GetRawRoot__O(); var linked_105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_104, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_106 lang.IFn; if linked_105 == nil { ifn_106 = lang.IFn_Cast(root_104) } else { ifn_106 = nil }; var arg_107 any = s__1797000030__3; if linked_105 == nil { c__1927001037__auto____4 = ifn_106.Invoke_O__O(arg_107) } else { c__1927001037__auto____4 = linked_105.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_104, arg_107) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1797000032__6 any; var root_108 any = A_arbace_classes_go_A_const_25.GetRawRoot__O(); var linked_109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_108, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_110 lang.IFn; if linked_109 == nil { ifn_110 = lang.IFn_Cast(root_108) } else { ifn_110 = nil }; var arg_111 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_109 == nil { b__1797000032__6 = ifn_110.Invoke_O__O(arg_111) } else { b__1797000032__6 = linked_109.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_108, arg_111) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__150 any = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1797000032__6); var tmp3 *jrt.Class; var fncls__149 *jrt.Class = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_fn_class; if fncls__149 == nil { var fncls__149d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_7, false, fnbody__150); A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_fn_class = fncls__149d; tmp3 = fncls__149d } else { tmp3 = fncls__149 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__150, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_151 any = A_arbace_classes_go_A_const_39.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any; var root_156 any = A_arbace_classes_go_A_const_40.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_158 lang.IFn; if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = b__1797000032__6; if linked_157 == nil { arg_154 = ifn_158.Invoke_O__O(arg_159) } else { arg_154 = linked_157.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_156, arg_159) }; var arg_155 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1797000029); var tmp5 any; var root_160 any = A_arbace_classes_go_A_const_41.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any = s__1797000030__3; if linked_161 == nil { tmp5 = ifn_162.Invoke_O__O(arg_163) } else { tmp5 = linked_161.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_160, arg_163) }; arg_155 = tmp4.Invoke_O__O(tmp5); if linked_152 == nil { return ifn_153.Invoke_O_O__O(arg_154, arg_155) } else { return linked_152.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_151, arg_154, arg_155) } } else { var root_164 any = A_arbace_classes_go_A_const_39.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_166 lang.IFn; if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any; var root_169 any = A_arbace_classes_go_A_const_40.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = b__1797000032__6; if linked_170 == nil { arg_167 = ifn_171.Invoke_O__O(arg_172) } else { arg_167 = linked_170.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_169, arg_172) }; var arg_168 any; if linked_165 == nil { return ifn_166.Invoke_O_O__O(arg_167, arg_168) } else { return linked_165.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_164, arg_167, arg_168) } } } else { var m__4 any; var root_173 any = A_arbace_classes_go_A_const_42.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any = s__1797000030__3; if linked_174 == nil { m__4 = ifn_175.Invoke_O__O(arg_176) } else { m__4 = linked_174.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_173, arg_176) }; var root_177 any = A_arbace_classes_go_A_const_43.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any; var tmp6 any = A_arbace_classes_go_A_const_27; var tmp7 any = jrt.NN(jrt.Method_Cast(m__4)).GetName__String().Ref(); var tmp8 any = A_arbace_classes_go_A_const_28; var tmp9 any; var root_182 any = A_arbace_classes_go_A_const_29.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, aot_arbace_classes_types.A_arbace_classes_types_method_desc_A_fn_class); var ifn_184 lang.IFn

	if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any; var root_187 any = A_arbace_classes_go_A_const_30.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_187, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_189 lang.IFn; if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var arg_190 any = A_arbace_classes_go_A_const_31.GetRawRoot__O(); var arg_191 any = jrt.NN(jrt.Method_Cast(m__4)).GetParameterTypes__Class1().Ref(); if linked_188 == nil { arg_185 = ifn_189.Invoke_O_O__O(arg_190, arg_191) } else { arg_185 = linked_188.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_187, arg_190, arg_191) }; var arg_186 any; var root_192 any = A_arbace_classes_go_A_const_31.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A_fn_class); var ifn_194 lang.IFn; if linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = jrt.NN(jrt.Method_Cast(m__4)).GetReturnType__Class().Ref(); if linked_193 == nil { arg_186 = ifn_194.Invoke_O__O(arg_195) } else { arg_186 = linked_193.(*aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A).Invoke_O_O__O(root_192, arg_195) }; if linked_183 == nil { tmp9 = ifn_184.Invoke_O_O__O(arg_185, arg_186) } else { tmp9 = linked_183.(*aot_arbace_classes_types.A_arbace_classes_types_method_desc_A).Invoke_O_O_O__O(root_182, arg_185, arg_186) }
//line :78:1
	var tmp10 any = tmp9; var tmp11 any = A_arbace_classes_go_A_const_32; var tmp12 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Method_Cast(m__4)).GetModifiers__I()).Ref(); var tmp13 any = A_arbace_classes_go_A_const_33; var tmp14 any; var root_196 any = A_arbace_classes_go_A_const_34.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_196, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_198 lang.IFn



	if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any; var fnbody__208 any = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_New(); var tmp15 *jrt.Class; var fncls__207 *jrt.Class = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_fn_class; if fncls__207 == nil { var fncls__207d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, false, nil); A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_fn_class = fncls__207d; tmp15 = fncls__207d } else { tmp15 = fncls__207 }; arg_199 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__208, tmp15, nil); var arg_200 any = jrt.NN(jrt.Method_Cast(m__4)).GetExceptionTypes__Class1().Ref(); if linked_197 == nil { tmp14 = ifn_198.Invoke_O_O__O(arg_199, arg_200) } else { tmp14 = linked_197.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_196, arg_199, arg_200) }
//line :78:1
	var tmp16 any = tmp14; var tmp17 any = A_arbace_classes_go_A_const_36; var tmp18 any; var root_209 any = A_arbace_classes_go_A_const_34.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_209, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_211 lang.IFn




	if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any = A_arbace_classes_go_A_const_37.GetRawRoot__O(); var arg_213 any = jrt.NN(jrt.Method_Cast(m__4)).GetParameterTypes__Class1().Ref(); if linked_210 == nil { tmp18 = ifn_211.Invoke_O_O__O(arg_212, arg_213) } else { tmp18 = linked_210.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_209, arg_212, arg_213) }
//line :78:1
	arg_180 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7, tmp8, tmp10, tmp11, tmp12, tmp13, tmp16, tmp17, tmp18, A_arbace_classes_go_A_const_38, lang.PersistentArrayMap_EMPTY.Ref())); var arg_181 any; var tmp19 lang.IFn = lang.IFn_Cast(t.F_iter__1797000029); var tmp20 any; var root_214 any = A_arbace_classes_go_A_const_44.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_214, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_216 lang.IFn; if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = s__1797000030__3; if linked_215 == nil { tmp20 = ifn_216.Invoke_O__O(arg_217) } else { tmp20 = linked_215.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_214, arg_217) }; arg_181 = tmp19.Invoke_O__O(tmp20); if linked_178 == nil { return ifn_179.Invoke_O_O__O(arg_180, arg_181) } else { return linked_178.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_177, arg_180, arg_181) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :78:1
func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :78:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1797000032 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1797000032 = c__b__1797000032 }
//line :78:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A) Invoke_O__O(self any) any { { var i__1797000031__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1797000031__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1797000031__1)); var root_112 any = A_arbace_classes_go_A_const_26.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = t.F_b__1797000032; var arg_116 any; var tmp2 any = A_arbace_classes_go_A_const_27; var tmp3 any = jrt.NN(jrt.Method_Cast(m__2)).GetName__String().Ref(); var tmp4 any = A_arbace_classes_go_A_const_28; var tmp5 any; var root_117 any = A_arbace_classes_go_A_const_29.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_117, aot_arbace_classes_types.A_arbace_classes_types_method_desc_A_fn_class); var ifn_119 lang.IFn

	if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any; var root_122 any = A_arbace_classes_go_A_const_30.GetRawRoot__O(); var linked_123 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_122, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_124 lang.IFn; if linked_123 == nil { ifn_124 = lang.IFn_Cast(root_122) } else { ifn_124 = nil }; var arg_125 any = A_arbace_classes_go_A_const_31.GetRawRoot__O(); var arg_126 any = jrt.NN(jrt.Method_Cast(m__2)).GetParameterTypes__Class1().Ref(); if linked_123 == nil { arg_120 = ifn_124.Invoke_O_O__O(arg_125, arg_126) } else { arg_120 = linked_123.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_122, arg_125, arg_126) }; var arg_121 any; var root_127 any = A_arbace_classes_go_A_const_31.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A_fn_class); var ifn_129 lang.IFn; if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = jrt.NN(jrt.Method_Cast(m__2)).GetReturnType__Class().Ref(); if linked_128 == nil { arg_121 = ifn_129.Invoke_O__O(arg_130) } else { arg_121 = linked_128.(*aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A).Invoke_O_O__O(root_127, arg_130) }; if linked_118 == nil { tmp5 = ifn_119.Invoke_O_O__O(arg_120, arg_121) } else { tmp5 = linked_118.(*aot_arbace_classes_types.A_arbace_classes_types_method_desc_A).Invoke_O_O_O__O(root_117, arg_120, arg_121) }
//line :78:1
	var tmp6 any = tmp5; var tmp7 any = A_arbace_classes_go_A_const_32; var tmp8 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Method_Cast(m__2)).GetModifiers__I()).Ref(); var tmp9 any = A_arbace_classes_go_A_const_33; var tmp10 any; var root_131 any = A_arbace_classes_go_A_const_34.GetRawRoot__O(); var linked_132 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_131, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_133 lang.IFn



	if linked_132 == nil { ifn_133 = lang.IFn_Cast(root_131) } else { ifn_133 = nil }; var arg_134 any; var fnbody__143 any = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_New(); var tmp11 *jrt.Class; var fncls__142 *jrt.Class = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_fn_class; if fncls__142 == nil { var fncls__142d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_9, false, nil); A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_fn_class = fncls__142d; tmp11 = fncls__142d } else { tmp11 = fncls__142 }; arg_134 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__143, tmp11, nil); var arg_135 any = jrt.NN(jrt.Method_Cast(m__2)).GetExceptionTypes__Class1().Ref(); if linked_132 == nil { tmp10 = ifn_133.Invoke_O_O__O(arg_134, arg_135) } else { tmp10 = linked_132.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_131, arg_134, arg_135) }
//line :78:1
	var tmp12 any = tmp10; var tmp13 any = A_arbace_classes_go_A_const_36; var tmp14 any; var root_144 any = A_arbace_classes_go_A_const_34.GetRawRoot__O(); var linked_145 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_144, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_146 lang.IFn




	if linked_145 == nil { ifn_146 = lang.IFn_Cast(root_144) } else { ifn_146 = nil }; var arg_147 any = A_arbace_classes_go_A_const_37.GetRawRoot__O(); var arg_148 any = jrt.NN(jrt.Method_Cast(m__2)).GetParameterTypes__Class1().Ref(); if linked_145 == nil { tmp14 = ifn_146.Invoke_O_O__O(arg_147, arg_148) } else { tmp14 = linked_145.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_144, arg_147, arg_148) }
//line :78:1
	arg_116 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, tmp6, tmp7, tmp8, tmp9, tmp12, tmp13, tmp14, A_arbace_classes_go_A_const_38, lang.PersistentArrayMap_EMPTY.Ref())); if linked_113 == nil { ifn_114.Invoke_O_O__O(arg_115, arg_116) } else { linked_113.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_112, arg_115, arg_116) }; i__1797000031__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1797000031__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_New() *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A) Ctor() {}
//line :82:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A) Invoke_O_O__O(self, p1__1797000027_SHARP___1 any) any { var root_136 any = A_arbace_classes_go_A_const_35.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = jrt.NN(jrt.Class_Cast(p1__1797000027_SHARP___1)).GetName__String().Ref(); var arg_140 any = Lit_10; var arg_141 any = Lit_11; if linked_137 == nil { return ifn_138.Invoke_O_O_O__O(arg_139, arg_140, arg_141) } else { return linked_137.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_136, arg_139, arg_140, arg_141) } }
//line :82:1
func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_New() *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A) Ctor() {}
//line :82:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A) Invoke_O_O__O(self, p1__1797000027_SHARP___1 any) any { var root_201 any = A_arbace_classes_go_A_const_35.GetRawRoot__O(); var linked_202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_201, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_203 lang.IFn; if linked_202 == nil { ifn_203 = lang.IFn_Cast(root_201) } else { ifn_203 = nil }; var arg_204 any = jrt.NN(jrt.Class_Cast(p1__1797000027_SHARP___1)).GetName__String().Ref(); var arg_205 any = Lit_10; var arg_206 any = Lit_11; if linked_202 == nil { return ifn_203.Invoke_O_O_O__O(arg_204, arg_205, arg_206) } else { return linked_202.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_201, arg_204, arg_205, arg_206) } }




func A_arbace_classes_go_generics_raw__1797000044_A_New_O_O(p0, p1 any) *A_arbace_classes_go_generics_raw__1797000044_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_generics_raw__1797000044_A{}; t.Ctor_O_O(p0, p1); return t }
//line :87:1
func (t *A_arbace_classes_go_generics_raw__1797000044_A) Ctor_O_O(c__raw, c__n any) { t.F_raw = c__raw; t.F_n = c__n }
//line :87:1
func (t *A_arbace_classes_go_generics_raw__1797000044_A) Invoke_O__O(self any) any { var ms__1 any; var root_224 any = A_arbace_classes_go_A_const_45.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_226 lang.IFn; if
											linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = lang.IFn_Cast(t.F_raw).Invoke__O(); if linked_225 == nil { ms__1 = ifn_226.Invoke_O__O(arg_227) } else { ms__1 = linked_225.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_224, arg_227) }; var have__2 any; var root_228 any = /*line :87:1*/A_arbace_classes_go_A_const_46.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_228, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_230 lang.IFn; if

	linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any; var root_232 any = A_arbace_classes_go_A_const_30.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_232, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_234 lang.IFn; if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any; var root_237 any = A_arbace_classes_go_A_const_47.GetRawRoot__O(); var linked_238 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_237, aot_arbace_core.A_arbace_core_juxt_A_fn_class); var ifn_239 lang.IFn; if linked_238 == nil { ifn_239 = lang.IFn_Cast(root_237) } else { ifn_239 = nil }; var arg_240 any = A_arbace_classes_go_A_const_27; var arg_241 any = A_arbace_classes_go_A_const_28; if linked_238 == nil { arg_235 = ifn_239.Invoke_O_O__O(arg_240, arg_241) } else { arg_235 = linked_238.(*aot_arbace_core.A_arbace_core_juxt_A).Invoke_O_O_O__O(root_237, arg_240, arg_241) }; var arg_236 any = ms__1; if linked_233 == nil { arg_231 = ifn_234.Invoke_O_O__O(arg_235, arg_236) } else { arg_231 = linked_233.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_232, arg_235, arg_236) }; if linked_229 == nil { have__2 = ifn_230.Invoke_O__O(arg_231) } else { have__2 = linked_229.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_228, arg_231) }; var root_242 any =
	A_arbace_classes_go_A_const_48.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = ms__1; var arg_246 any; var iter__1927001039__auto____3 any; var fnbody__338 any = A_arbace_classes_go_generics_raw__1797000044_iter__1797000045__1797000049_A_New_O(have__2); var tmp1 *jrt.Class; var fncls__337 *jrt.Class = A_arbace_classes_go_generics_raw__1797000044_iter__1797000045__1797000049_A_fn_class; if fncls__337 == nil { var fncls__337d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, false, fnbody__338); A_arbace_classes_go_generics_raw__1797000044_iter__1797000045__1797000049_A_fn_class = fncls__337d; tmp1 = fncls__337d } else { tmp1 = fncls__337 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__338, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp3 *lang.Keyword = A_arbace_classes_go_A_const_52; var tmp4 any; var root_339 any = A_arbace_classes_go_A_const_53.GetRawRoot__O(); var linked_340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_339, A_arbace_classes_go_protected_members_A_fn_class); var ifn_341 lang.IFn; if linked_340 == nil { ifn_341 = lang.IFn_Cast(root_339) } else { ifn_341 = nil }; var arg_342 any = t.F_n; if linked_340 == nil { tmp4 = ifn_341.Invoke_O__O(arg_342) } else { tmp4 = linked_340.(*A_arbace_classes_go_protected_members_A).Invoke_O_O__O(root_339, arg_342) }; arg_246 = tmp2.Invoke_O__O(tmp3.Invoke_O__O(tmp4)); if linked_243 == nil { return ifn_244.Invoke_O_O__O(arg_245, arg_246) } else { return linked_243.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_242, arg_245, arg_246) } }
//line :90:1
func A_arbace_classes_go_generics_raw__1797000044_iter__1797000045__1797000049_A_New_O(p0 any) *A_arbace_classes_go_generics_raw__1797000044_iter__1797000045__1797000049_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_generics_raw__1797000044_iter__1797000045__1797000049_A{}; t.Ctor_O(p0); return t }
//line :90:1
func (t *A_arbace_classes_go_generics_raw__1797000044_iter__1797000045__1797000049_A) Ctor_O(c__have any) { t.F_have = c__have }
//line :90:1
func (t *A_arbace_classes_go_generics_raw__1797000044_iter__1797000045__1797000049_A) Invoke_O_O__O(self, s__1797000046__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__336 any = A_arbace_classes_go_generics_raw__1797000044_iter__1797000045__1797000049_fn__1797000050_A_New_O_O_O(t.F_have, s__1797000046__1, self); var tmp2 *jrt.Class; var fncls__335 *jrt.Class = A_arbace_classes_go_generics_raw__1797000044_iter__1797000045__1797000049_fn__1797000050_A_fn_class; if fncls__335 == nil { var fncls__335d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_13, false, fnbody__336); A_arbace_classes_go_generics_raw__1797000044_iter__1797000045__1797000049_fn__1797000050_A_fn_class = fncls__335d; tmp2 = fncls__335d } else { tmp2 = fncls__335 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__336, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :90:1
func A_arbace_classes_go_generics_raw__1797000044_iter__1797000045__1797000049_fn__1797000050_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_go_generics_raw__1797000044_iter__1797000045__1797000049_fn__1797000050_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_generics_raw__1797000044_iter__1797000045__1797000049_fn__1797000050_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :90:1
func (t *A_arbace_classes_go_generics_raw__1797000044_iter__1797000045__1797000049_fn__1797000050_A) Ctor_O_O_O(c__have, c__s__1797000046, c__iter__1797000045 any) { t.F_have = c__have; t.F_s__1797000046 = c__s__1797000046; t.F_iter__1797000045 = c__iter__1797000045 }
//line :90:1
func (t *A_arbace_classes_go_generics_raw__1797000044_iter__1797000045__1797000049_fn__1797000050_A) Invoke_O__O(self any) any { { var s__1797000046__1 any; var t_ any = t.F_s__1797000046; t.F_s__1797000046 = nil; s__1797000046__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_247 any = A_arbace_classes_go_A_const_22.GetRawRoot__O(); var linked_248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_247, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_249 lang.IFn; if linked_248 == nil { ifn_249 = lang.IFn_Cast(root_247) } else { ifn_249 = nil }; var arg_250 any = s__1797000046__1; if linked_248 == nil { temp__1927000414__auto____2 = ifn_249.Invoke_O__O(arg_250) } else { temp__1927000414__auto____2 = linked_248.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_247, arg_250) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1797000046__3 any = temp__1927000414__auto____2; var tmp1 any; var root_251 any = A_arbace_classes_go_A_const_23.GetRawRoot__O(); var linked_252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_251, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_253 lang.IFn; if linked_252 == nil { ifn_253 = lang.IFn_Cast(root_251) } else { ifn_253 = nil }; var arg_254 any = s__1797000046__3; if linked_252 == nil { tmp1 = ifn_253.Invoke_O__O(arg_254) } else { tmp1 = linked_252.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_251, arg_254) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_255 any = A_arbace_classes_go_A_const_24.GetRawRoot__O(); var linked_256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_255, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_257 lang.IFn; if linked_256 == nil { ifn_257 = lang.IFn_Cast(root_255) } else { ifn_257 = nil }; var arg_258 any = s__1797000046__3; if linked_256 == nil { c__1927001037__auto____4 = ifn_257.Invoke_O__O(arg_258) } else { c__1927001037__auto____4 = linked_256.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_255, arg_258) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1797000048__6 any; var root_259 any = A_arbace_classes_go_A_const_25.GetRawRoot__O(); var linked_260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_259, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_261 lang.IFn; if linked_260 == nil { ifn_261 = lang.IFn_Cast(root_259) } else { ifn_261 = nil }; var arg_262 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_260 == nil { b__1797000048__6 = ifn_261.Invoke_O__O(arg_262) } else { b__1797000048__6 = linked_260.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_259, arg_262) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__282 any = A_arbace_classes_go_generics_raw__1797000044_iter__1797000045__1797000049_fn__1797000050_fn__1797000051_A_New_O_O_I_O(b__1797000048__6, t.F_have, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__281 *jrt.Class = A_arbace_classes_go_generics_raw__1797000044_iter__1797000045__1797000049_fn__1797000050_fn__1797000051_A_fn_class; if fncls__281 == nil { var fncls__281d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_14, false, fnbody__282); A_arbace_classes_go_generics_raw__1797000044_iter__1797000045__1797000049_fn__1797000050_fn__1797000051_A_fn_class = fncls__281d; tmp3 = fncls__281d } else { tmp3 = fncls__281 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__282, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_283 any = A_arbace_classes_go_A_const_39.GetRawRoot__O(); var linked_284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_283, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_285 lang.IFn; if linked_284 == nil { ifn_285 = lang.IFn_Cast(root_283) } else { ifn_285 = nil }; var arg_286 any; var root_288 any = A_arbace_classes_go_A_const_40.GetRawRoot__O(); var linked_289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_288, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_290 lang.IFn; if linked_289 == nil { ifn_290 = lang.IFn_Cast(root_288) } else { ifn_290 = nil }; var arg_291 any = b__1797000048__6; if linked_289 == nil { arg_286 = ifn_290.Invoke_O__O(arg_291) } else { arg_286 = linked_289.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_288, arg_291) }; var arg_287 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1797000045); var tmp5 any; var root_292 any = A_arbace_classes_go_A_const_41.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_292, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_294 lang.IFn; if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any = s__1797000046__3; if linked_293 == nil { tmp5 = ifn_294.Invoke_O__O(arg_295) } else { tmp5 = linked_293.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_292, arg_295) }; arg_287 = tmp4.Invoke_O__O(tmp5); if linked_284 == nil { return ifn_285.Invoke_O_O__O(arg_286, arg_287) } else { return linked_284.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_283, arg_286, arg_287) } } else { var root_296 any = A_arbace_classes_go_A_const_39.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_298 lang.IFn; if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any; var root_301 any = A_arbace_classes_go_A_const_40.GetRawRoot__O(); var linked_302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_301, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_303 lang.IFn; if linked_302 == nil { ifn_303 = lang.IFn_Cast(root_301) } else { ifn_303 = nil }; var arg_304 any = b__1797000048__6; if linked_302 == nil { arg_299 = ifn_303.Invoke_O__O(arg_304) } else { arg_299 = linked_302.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_301, arg_304) }; var arg_300 any; if linked_297 == nil { return ifn_298.Invoke_O_O__O(arg_299, arg_300) } else { return linked_297.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_296, arg_299, arg_300) } } } else { var vec__1797000059__4 any; var root_305 any = A_arbace_classes_go_A_const_42.GetRawRoot__O(); var linked_306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_305, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_307 lang.IFn; if linked_306 == nil { ifn_307 = lang.IFn_Cast(root_305) } else { ifn_307 = nil }; var arg_308 any = s__1797000046__3; if linked_306 == nil { vec__1797000059__4 = ifn_307.Invoke_O__O(arg_308) } else { vec__1797000059__4 = linked_306.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_305, arg_308) }; var nm__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1797000059__4, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1797000059__4, lang.RT_IntCast_J__I_NoInit(1), nil); var flags__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1797000059__4, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp6 any; var root_309 any = A_arbace_classes_go_A_const_49.GetRawRoot__O(); var linked_310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_309, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_311 lang.IFn
																if linked_310 == nil { ifn_311 = lang.IFn_Cast(root_309) } else { ifn_311 = nil }; var tmp7 lang.IFn = lang.IFn_Cast(t.F_have); var arg_312 any = tmp7.Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(nm__5, desc__6)); if linked_310 == nil { tmp6 = ifn_311.Invoke_O__O(arg_312) } else { tmp6 = linked_310.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_309, arg_312) }
//line :90:1
	if jrt.J2g_Truth(tmp6) { var vec__1797000062__8 any; var root_313 any = A_arbace_classes_go_A_const_50.GetRawRoot__O(); var linked_314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_313, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_315 lang.IFn

		if linked_314 == nil { ifn_315 = lang.IFn_Cast(root_313) } else { ifn_315 = nil }; var arg_316 any = desc__6; if linked_314 == nil { vec__1797000062__8 = ifn_315.Invoke_O__O(arg_316) } else { vec__1797000062__8 = linked_314.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_313, arg_316) }
//line :90:1
		var ps__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1797000062__8, lang.RT_IntCast_J__I_NoInit(0), nil); var ___10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1797000062__8, lang.RT_IntCast_J__I_NoInit(1), nil); var root_317 any = A_arbace_classes_go_A_const_43.GetRawRoot__O(); var linked_318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_317, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_319 lang.IFn; _ = ___10; if linked_318 == nil { ifn_319 = lang.IFn_Cast(root_317) } else { ifn_319 = nil }; var arg_320 any; var tmp8 any = A_arbace_classes_go_A_const_27; var tmp9 any = A_arbace_classes_go_A_const_28; var tmp10 any = A_arbace_classes_go_A_const_32; var tmp11 any = A_arbace_classes_go_A_const_33; var tmp12 any = lang.PersistentVector_EMPTY.Ref(); var tmp13 any = A_arbace_classes_go_A_const_36; var tmp14 any; var root_322 any = A_arbace_classes_go_A_const_34.GetRawRoot__O(); var linked_323 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_322, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_324 lang.IFn



		if linked_323 == nil { ifn_324 = lang.IFn_Cast(root_322) } else { ifn_324 = nil }; var arg_325 any = A_arbace_classes_go_A_const_51.GetRawRoot__O(); var arg_326 any = ps__9; if linked_323 == nil { tmp14 = ifn_324.Invoke_O_O__O(arg_325, arg_326) } else { tmp14 = linked_323.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_322, arg_325, arg_326) }
//line :90:1
		arg_320 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, nm__5, tmp9, desc__6, tmp10, flags__7, tmp11, tmp12, tmp13, tmp14, A_arbace_classes_go_A_const_38, lang.PersistentArrayMap_EMPTY.Ref())); var arg_321 any; var tmp15 lang.IFn = lang.IFn_Cast(t.F_iter__1797000045); var tmp16 any; var root_327 any = A_arbace_classes_go_A_const_44.GetRawRoot__O(); var linked_328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_327, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_329 lang.IFn; if linked_328 == nil { ifn_329 = lang.IFn_Cast(root_327) } else { ifn_329 = nil }; var arg_330 any = s__1797000046__3; if linked_328 == nil { tmp16 = ifn_329.Invoke_O__O(arg_330) } else { tmp16 = linked_328.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_327, arg_330) }; arg_321 = tmp15.Invoke_O__O(tmp16); if linked_318 == nil { return ifn_319.Invoke_O_O__O(arg_320, arg_321) } else { return linked_318.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_317, arg_320, arg_321) } } else { var tmp17 any; var root_331 any = A_arbace_classes_go_A_const_44.GetRawRoot__O(); var linked_332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_331, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_333 lang.IFn; if linked_332 == nil { ifn_333 = lang.IFn_Cast(root_331) } else { ifn_333 = nil }; var arg_334 any = s__1797000046__3; if linked_332 == nil { tmp17 = ifn_333.Invoke_O__O(arg_334) } else { tmp17 = linked_332.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_331, arg_334) }; s__1797000046__1 = tmp17; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :90:1
func A_arbace_classes_go_generics_raw__1797000044_iter__1797000045__1797000049_fn__1797000050_fn__1797000051_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_go_generics_raw__1797000044_iter__1797000045__1797000049_fn__1797000050_fn__1797000051_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_generics_raw__1797000044_iter__1797000045__1797000049_fn__1797000050_fn__1797000051_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :90:1
func (t *A_arbace_classes_go_generics_raw__1797000044_iter__1797000045__1797000049_fn__1797000050_fn__1797000051_A) Ctor_O_O_I_O(c__b__1797000048, c__have any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1797000048 = c__b__1797000048; t.F_have = c__have; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :90:1
func (t *A_arbace_classes_go_generics_raw__1797000044_iter__1797000045__1797000049_fn__1797000050_fn__1797000051_A) Invoke_O__O(self any) any { { var i__1797000047__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1797000047__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1797000052__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1797000047__1)); var nm__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1797000052__2, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1797000052__2, lang.RT_IntCast_J__I_NoInit(1), nil); var flags__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1797000052__2, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp2 any; var root_263 any = A_arbace_classes_go_A_const_49.GetRawRoot__O(); var linked_264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_263, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_265 lang.IFn
																		if linked_264 == nil { ifn_265 = lang.IFn_Cast(root_263) } else { ifn_265 = nil }; var tmp3 lang.IFn = lang.IFn_Cast(t.F_have); var arg_266 any = tmp3.Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(nm__3, desc__4)); if linked_264 == nil { tmp2 = ifn_265.Invoke_O__O(arg_266) } else { tmp2 = linked_264.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_263, arg_266) }
//line :90:1
	if jrt.J2g_Truth(tmp2) { var vec__1797000055__6 any; var root_267 any = A_arbace_classes_go_A_const_50.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_267, aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A_fn_class); var ifn_269 lang.IFn

		if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any = desc__4; if linked_268 == nil { vec__1797000055__6 = ifn_269.Invoke_O__O(arg_270) } else { vec__1797000055__6 = linked_268.(*aot_arbace_classes_types.A_arbace_classes_types_parse_method_desc_A).Invoke_O_O__O(root_267, arg_270) }
//line :90:1
		var ps__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1797000055__6, lang.RT_IntCast_J__I_NoInit(0), nil); var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1797000055__6, lang.RT_IntCast_J__I_NoInit(1), nil); var root_271 any = A_arbace_classes_go_A_const_26.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_273 lang.IFn; _ = ___8; if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = t.F_b__1797000048; var arg_275 any; var tmp4 any = A_arbace_classes_go_A_const_27; var tmp5 any = A_arbace_classes_go_A_const_28; var tmp6 any = A_arbace_classes_go_A_const_32; var tmp7 any = A_arbace_classes_go_A_const_33; var tmp8 any = lang.PersistentVector_EMPTY.Ref(); var tmp9 any = A_arbace_classes_go_A_const_36; var tmp10 any; var root_276 any = A_arbace_classes_go_A_const_34.GetRawRoot__O(); var linked_277 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_276, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_278 lang.IFn



		if linked_277 == nil { ifn_278 = lang.IFn_Cast(root_276) } else { ifn_278 = nil }; var arg_279 any = A_arbace_classes_go_A_const_51.GetRawRoot__O(); var arg_280 any = ps__7; if linked_277 == nil { tmp10 = ifn_278.Invoke_O_O__O(arg_279, arg_280) } else { tmp10 = linked_277.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_276, arg_279, arg_280) }
//line :90:1
		arg_275 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, nm__3, tmp5, desc__4, tmp6, flags__5, tmp7, tmp8, tmp9, tmp10, A_arbace_classes_go_A_const_38, lang.PersistentArrayMap_EMPTY.Ref())); if linked_272 == nil { ifn_273.Invoke_O_O__O(arg_274, arg_275) } else { linked_272.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_271, arg_274, arg_275) }; i__1797000047__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1797000047__1); continue L1 } else { i__1797000047__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1797000047__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }












func A_arbace_classes_go_protected_members_A_New() *A_arbace_classes_go_protected_members_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_protected_members_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_classes_go_protected_members_A) Ctor() {}
//line :103:1
func (t *A_arbace_classes_go_protected_members_A) Invoke_O_O__O(self, n__0 any) any {




	var root_370 any = A_arbace_classes_go_A_const_60.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_370, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_372 lang.IFn; if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any; var root_375 any = A_arbace_classes_go_A_const_6.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_375, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_377 lang.IFn; if linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any = A_arbace_classes_go_A_const_21.GetRawRoot__O(); if linked_376 == nil { arg_373 = ifn_377.Invoke_O__O(arg_378) } else { arg_373 = linked_376.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_375, arg_378) }; var arg_374 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_classes_go_A_const_61, n__0); if linked_371 == nil { return ifn_372.Invoke_O_O__O(arg_373, arg_374) } else { return linked_371.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_370, arg_373, arg_374)
	} }
func A_arbace_classes_go_constructors_A_New() *A_arbace_classes_go_constructors_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_constructors_A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_classes_go_constructors_A) Ctor() {}
//line :110:1
func (t *A_arbace_classes_go_constructors_A) Invoke_O_O__O(self, n__0 any) any { var or__1927000174__auto____2 any; var tmp1 *lang.Keyword = A_arbace_classes_go_A_const_62; var tmp2 any; var root_379 any = A_arbace_classes_go_A_const_6.GetRawRoot__O(); var linked_380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_379, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_381 lang.IFn; if



	linked_380 == nil { ifn_381 = lang.IFn_Cast(root_379) } else { ifn_381 = nil }; var arg_382 any = A_arbace_classes_go_A_const_21.GetRawRoot__O(); if linked_380 == nil { tmp2 = ifn_381.Invoke_O__O(arg_382) } else { tmp2 = linked_380.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_379, arg_382) }; or__1927000174__auto____2 = tmp1.Invoke_O__O(lang.RT_Get_O_O__O_NoInit(tmp2, n__0)); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else {
		return lang.RT_Get_O_O__O_NoInit(A_arbace_classes_go_A_const_63, n__0) } }






func A_arbace_classes_go_world_const_A_New() *A_arbace_classes_go_world_const_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_world_const_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_classes_go_world_const_A) Ctor() {}
//line :122:1
func (t *A_arbace_classes_go_world_const_A) Invoke_O_O_O_O__O(self, n__0, fname__1, desc__2 any) any { var temp__1927000426__auto____4 any; var root_383 any = A_arbace_classes_go_A_const_60.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_383, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_385 lang.IFn; if



	linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any; var root_388 any = A_arbace_classes_go_A_const_6.GetRawRoot__O(); var linked_389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_388, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_390 lang.IFn; if linked_389 == nil { ifn_390 = lang.IFn_Cast(root_388) } else { ifn_390 = nil }; var arg_391 any = A_arbace_classes_go_A_const_21.GetRawRoot__O(); if linked_389 == nil { arg_386 = ifn_390.Invoke_O__O(arg_391) } else { arg_386 = linked_389.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_388, arg_391) }; var arg_387 any = lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_classes_go_A_const_64, n__0, fname__1); if linked_384 == nil { temp__1927000426__auto____4 = ifn_385.Invoke_O_O__O(arg_386, arg_387) } else { temp__1927000426__auto____4 = linked_384.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_383, arg_386, arg_387) }; if lang.Util_Identical_O_O__Z_NoInit(temp__1927000426__auto____4, nil) { return nil } else { var v__5 any = temp__1927000426__auto____4; var G__1797000072__6_ any = desc__2
		switch lang.Util_Hash_O__I_NoInit(G__1797000072__6_) { case 66: if lang.Util_Equiv_O_O__Z_NoInit(G__1797000072__6_, Lit_15) {


			return jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_ByteCast_O__B_NoInit(v__5)).Ref() }
//line :127:1
		case 67: if lang.Util_Equiv_O_O__Z_NoInit(G__1797000072__6_, Lit_16) {

			return jrt.Character_ValueOf_C__Character_NoInit(lang.RT_CharCast_I__C_NoInit(lang.RT_IntCast_O__I_NoInit(v__5))).Ref() }
//line :127:1
		case 68: if lang.Util_Equiv_O_O__Z_NoInit(G__1797000072__6_, Lit_17) {








			return jrt.Double_ValueOf_D__Double_NoInit(lang.RT_DoubleCast_O__D_NoInit(v__5)).Ref() }
//line :127:1
		case 70: if lang.Util_Equiv_O_O__Z_NoInit(G__1797000072__6_, Lit_18) {







			return jrt.Float_ValueOf_F__Float_NoInit(lang.RT_UncheckedFloatCast_O__F_NoInit(v__5)).Ref() }
//line :127:1
		case 73: if lang.Util_Equiv_O_O__Z_NoInit(G__1797000072__6_, Lit_19) {




			return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_O__I_NoInit(v__5)).Ref() }
//line :127:1
		case 74: if lang.Util_Equiv_O_O__Z_NoInit(G__1797000072__6_, Lit_20) {





			return jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(v__5)).Ref() }
//line :127:1
		case 83: if lang.Util_Equiv_O_O__Z_NoInit(G__1797000072__6_, Lit_21) {



			return jrt.Short_ValueOf_S__Short_NoInit(lang.RT_ShortCast_O__S_NoInit(v__5)).Ref() }
//line :127:1
		case 90: if lang.Util_Equiv_O_O__Z_NoInit(G__1797000072__6_, Lit_22) {
			var tmp1 any; var root_393 any = A_arbace_classes_go_A_const_65.GetRawRoot__O(); var linked_394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_393, aot_arbace_core.A_arbace_core_number_QMARK__A_fn_class); var ifn_395 lang.IFn; if linked_394 == nil { ifn_395 = lang.IFn_Cast(root_393) } else { ifn_395 = nil }; var arg_396 any = v__5; if linked_394 == nil { tmp1 = ifn_395.Invoke_O__O(arg_396) } else { tmp1 = linked_394.(*aot_arbace_core.A_arbace_core_number_QMARK__A).Invoke_O_O__O(root_393, arg_396) }; if jrt.J2g_Truth(tmp1) { var root_397 any = A_arbace_classes_go_A_const_49.GetRawRoot__O(); var linked_398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_397, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_399 lang.IFn; if linked_398 == nil { ifn_399 = lang.IFn_Cast(root_397) } else { ifn_399 = nil }; var arg_400 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(v__5))).Ref(); if linked_398 == nil { return ifn_399.Invoke_O__O(arg_400) } else { return linked_398.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_397, arg_400) } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(v__5)).Ref() } }
//line :127:1
		default:}; return v__5 } }























































type A_arbace_classes_go_A struct{ jrt.Object }

var A_arbace_classes_go_A_const_pool *jrt.RefArray

var A_arbace_classes_go_A_const_0 *lang.Var

var A_arbace_classes_go_A_const_1 any

var A_arbace_classes_go_A_const_2 any

var A_arbace_classes_go_A_const_3 *lang.Var

var A_arbace_classes_go_A_const_4 any

var A_arbace_classes_go_A_const_5 *lang.Var

var A_arbace_classes_go_A_const_6 *lang.Var

var A_arbace_classes_go_A_const_7 *lang.Var

var A_arbace_classes_go_A_const_8 *lang.Var

var A_arbace_classes_go_A_const_9 any

var A_arbace_classes_go_A_const_10 *lang.Var

var A_arbace_classes_go_A_const_11 *lang.Var

var A_arbace_classes_go_A_const_12 *lang.Var

var A_arbace_classes_go_A_const_13 *lang.Var

var A_arbace_classes_go_A_const_14 *lang.Var

var A_arbace_classes_go_A_const_15 *lang.Var

var A_arbace_classes_go_A_const_16 *lang.Var

var A_arbace_classes_go_A_const_17 *lang.Var

var A_arbace_classes_go_A_const_18 *lang.Var

var A_arbace_classes_go_A_const_19 *lang.Var

var A_arbace_classes_go_A_const_20 *lang.Var

var A_arbace_classes_go_A_const_21 *lang.Var

var A_arbace_classes_go_A_const_22 *lang.Var

var A_arbace_classes_go_A_const_23 *lang.Var

var A_arbace_classes_go_A_const_24 *lang.Var

var A_arbace_classes_go_A_const_25 *lang.Var

var A_arbace_classes_go_A_const_26 *lang.Var

var A_arbace_classes_go_A_const_27 *lang.Keyword

var A_arbace_classes_go_A_const_28 *lang.Keyword

var A_arbace_classes_go_A_const_29 *lang.Var

var A_arbace_classes_go_A_const_30 *lang.Var

var A_arbace_classes_go_A_const_31 *lang.Var

var A_arbace_classes_go_A_const_32 *lang.Keyword

var A_arbace_classes_go_A_const_33 *lang.Keyword

var A_arbace_classes_go_A_const_34 *lang.Var

var A_arbace_classes_go_A_const_35 *lang.Var

var A_arbace_classes_go_A_const_36 *lang.Keyword

var A_arbace_classes_go_A_const_37 *lang.Var

var A_arbace_classes_go_A_const_38 *lang.Keyword

var A_arbace_classes_go_A_const_39 *lang.Var

var A_arbace_classes_go_A_const_40 *lang.Var

var A_arbace_classes_go_A_const_41 *lang.Var

var A_arbace_classes_go_A_const_42 *lang.Var

var A_arbace_classes_go_A_const_43 *lang.Var

var A_arbace_classes_go_A_const_44 *lang.Var

var A_arbace_classes_go_A_const_45 *lang.Var

var A_arbace_classes_go_A_const_46 *lang.Var

var A_arbace_classes_go_A_const_47 *lang.Var

var A_arbace_classes_go_A_const_48 *lang.Var

var A_arbace_classes_go_A_const_49 *lang.Var

var A_arbace_classes_go_A_const_50 *lang.Var

var A_arbace_classes_go_A_const_51 *lang.Var

var A_arbace_classes_go_A_const_52 *lang.Keyword

var A_arbace_classes_go_A_const_53 *lang.Var

var A_arbace_classes_go_A_const_54 *lang.Var

var A_arbace_classes_go_A_const_55 *lang.Keyword

var A_arbace_classes_go_A_const_56 *lang.Keyword

var A_arbace_classes_go_A_const_57 *lang.Keyword

var A_arbace_classes_go_A_const_58 *lang.Var

var A_arbace_classes_go_A_const_59 *lang.Var

var A_arbace_classes_go_A_const_60 *lang.Var

var A_arbace_classes_go_A_const_61 *lang.Keyword

var A_arbace_classes_go_A_const_62 *lang.Keyword

var A_arbace_classes_go_A_const_63 any

var A_arbace_classes_go_A_const_64 *lang.Keyword

var A_arbace_classes_go_A_const_65 *lang.Var

var A_arbace_classes_go_A_init jrt.ClassInit

func A_arbace_classes_go_A_Init() { if !A_arbace_classes_go_A_init.Done() { A_arbace_classes_go_A_init.Run(A_arbace_classes_go_A_clinit) } }

func A_arbace_classes_go_A_clinit() { A_arbace_classes_go_A_clinit_p0(); A_arbace_classes_go_A_clinit_p1(); A_arbace_classes_go_A_clinit_p2(); A_arbace_classes_go_A_clinit_p3(); A_arbace_classes_go_A_clinit_p4(); A_arbace_classes_go_A_clinit_p5() }

func A_arbace_classes_go_A_clinit_p0() { jrt.StartCheck(); A_arbace_classes_go_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 86); A_arbace_classes_go_A_const_0 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[20]); A_arbace_classes_go_A_const_1 = A_arbace_classes_go_A_const_pool.A[21]; A_arbace_classes_go_A_const_2 = A_arbace_classes_go_A_const_pool.A[22]; A_arbace_classes_go_A_const_3 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[23]); A_arbace_classes_go_A_const_4 = A_arbace_classes_go_A_const_pool.A[24]; A_arbace_classes_go_A_const_5 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[25]); A_arbace_classes_go_A_const_6 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[26]); A_arbace_classes_go_A_const_7 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[27]); A_arbace_classes_go_A_const_8 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[28]); A_arbace_classes_go_A_const_9 = A_arbace_classes_go_A_const_pool.A[29]; A_arbace_classes_go_A_const_10 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[30]); A_arbace_classes_go_A_const_11 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[31]) }

func A_arbace_classes_go_A_clinit_p1() { A_arbace_classes_go_A_const_12 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[32]); A_arbace_classes_go_A_const_13 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[33]); A_arbace_classes_go_A_const_14 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[34]); A_arbace_classes_go_A_const_15 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[35]); A_arbace_classes_go_A_const_16 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[36]); A_arbace_classes_go_A_const_17 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[37]); A_arbace_classes_go_A_const_18 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[38]); A_arbace_classes_go_A_const_19 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[39]); A_arbace_classes_go_A_const_20 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[40]); A_arbace_classes_go_A_const_21 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[41]); A_arbace_classes_go_A_const_22 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[42]); A_arbace_classes_go_A_const_23 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[43]) }

func A_arbace_classes_go_A_clinit_p2() { A_arbace_classes_go_A_const_24 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[44]); A_arbace_classes_go_A_const_25 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[45]); A_arbace_classes_go_A_const_26 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[46]); A_arbace_classes_go_A_const_27 = lang.Keyword_Cast(A_arbace_classes_go_A_const_pool.A[47]); A_arbace_classes_go_A_const_28 = lang.Keyword_Cast(A_arbace_classes_go_A_const_pool.A[48]); A_arbace_classes_go_A_const_29 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[49]); A_arbace_classes_go_A_const_30 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[50]); A_arbace_classes_go_A_const_31 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[51]); A_arbace_classes_go_A_const_32 = lang.Keyword_Cast(A_arbace_classes_go_A_const_pool.A[52]); A_arbace_classes_go_A_const_33 = lang.Keyword_Cast(A_arbace_classes_go_A_const_pool.A[53]); A_arbace_classes_go_A_const_34 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[54]); A_arbace_classes_go_A_const_35 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[55]) }

func A_arbace_classes_go_A_clinit_p3() { A_arbace_classes_go_A_const_36 = lang.Keyword_Cast(A_arbace_classes_go_A_const_pool.A[56]); A_arbace_classes_go_A_const_37 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[57]); A_arbace_classes_go_A_const_38 = lang.Keyword_Cast(A_arbace_classes_go_A_const_pool.A[58]); A_arbace_classes_go_A_const_39 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[59]); A_arbace_classes_go_A_const_40 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[60]); A_arbace_classes_go_A_const_41 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[61]); A_arbace_classes_go_A_const_42 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[62]); A_arbace_classes_go_A_const_43 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[63]); A_arbace_classes_go_A_const_44 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[64]); A_arbace_classes_go_A_const_45 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[65]); A_arbace_classes_go_A_const_46 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[66]); A_arbace_classes_go_A_const_47 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[67]) }

func A_arbace_classes_go_A_clinit_p4() { A_arbace_classes_go_A_const_48 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[68]); A_arbace_classes_go_A_const_49 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[69]); A_arbace_classes_go_A_const_50 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[70]); A_arbace_classes_go_A_const_51 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[71]); A_arbace_classes_go_A_const_52 = lang.Keyword_Cast(A_arbace_classes_go_A_const_pool.A[72]); A_arbace_classes_go_A_const_53 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[73]); A_arbace_classes_go_A_const_54 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[74]); A_arbace_classes_go_A_const_55 = lang.Keyword_Cast(A_arbace_classes_go_A_const_pool.A[75]); A_arbace_classes_go_A_const_56 = lang.Keyword_Cast(A_arbace_classes_go_A_const_pool.A[76]); A_arbace_classes_go_A_const_57 = lang.Keyword_Cast(A_arbace_classes_go_A_const_pool.A[77]); A_arbace_classes_go_A_const_58 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[78]); A_arbace_classes_go_A_const_59 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[79]) }

func A_arbace_classes_go_A_clinit_p5() { A_arbace_classes_go_A_const_60 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[80]); A_arbace_classes_go_A_const_61 = lang.Keyword_Cast(A_arbace_classes_go_A_const_pool.A[81]); A_arbace_classes_go_A_const_62 = lang.Keyword_Cast(A_arbace_classes_go_A_const_pool.A[82]); A_arbace_classes_go_A_const_63 = A_arbace_classes_go_A_const_pool.A[83]; A_arbace_classes_go_A_const_64 = lang.Keyword_Cast(A_arbace_classes_go_A_const_pool.A[84]); A_arbace_classes_go_A_const_65 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[85]) }

func A_arbace_classes_go_A_New() *A_arbace_classes_go_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_go_A) Ctor() {}

func (t *A_arbace_classes_go_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_A_class }

func (t *A_arbace_classes_go_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_go_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_A); return ok }

func A_arbace_classes_go_A_Cast(x any) *A_arbace_classes_go_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_A_class)) }; return v }



type A_arbace_classes_go_constructors_A struct{ j2g_header uint64 }

var A_arbace_classes_go_constructors_A_fn_class *jrt.Class



type A_arbace_classes_go_eval1797000004_A struct{ jrt.Object }

func A_arbace_classes_go_eval1797000004_A_New() *A_arbace_classes_go_eval1797000004_A { t := &A_arbace_classes_go_eval1797000004_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_go_eval1797000004_A) Ctor() {}

func (t *A_arbace_classes_go_eval1797000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_eval1797000004_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_eval1797000004_A_class }

func (t *A_arbace_classes_go_eval1797000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_eval1797000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_go_eval1797000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_eval1797000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_eval1797000004_A); return ok }

func A_arbace_classes_go_eval1797000004_A_Cast(x any) *A_arbace_classes_go_eval1797000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_eval1797000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_eval1797000004_A_class)) }; return v }



type A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A struct{ j2g_header uint64 }

var A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_fn_class *jrt.Class



type A_arbace_classes_go_eval1797000008_A struct{ jrt.Object }

func A_arbace_classes_go_eval1797000008_A_New() *A_arbace_classes_go_eval1797000008_A { t := &A_arbace_classes_go_eval1797000008_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_go_eval1797000008_A) Ctor() {}

func (t *A_arbace_classes_go_eval1797000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_eval1797000008_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_eval1797000008_A_class }

func (t *A_arbace_classes_go_eval1797000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_eval1797000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_go_eval1797000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_eval1797000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_eval1797000008_A); return ok }

func A_arbace_classes_go_eval1797000008_A_Cast(x any) *A_arbace_classes_go_eval1797000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_eval1797000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_eval1797000008_A_class)) }; return v }



type A_arbace_classes_go_eval1797000008_fn__1797000009_A struct{ j2g_header uint64 }

var A_arbace_classes_go_eval1797000008_fn__1797000009_A_fn_class *jrt.Class



type A_arbace_classes_go_fn__1797000023_A struct{ j2g_header uint64 }

var A_arbace_classes_go_fn__1797000023_A_fn_class *jrt.Class



type A_arbace_classes_go_fn__1797000025_A struct{ j2g_header uint64 }

var A_arbace_classes_go_fn__1797000025_A_fn_class *jrt.Class



type A_arbace_classes_go_generics_A struct{ j2g_header uint64 }

var A_arbace_classes_go_generics_A_fn_class *jrt.Class



type A_arbace_classes_go_generics_raw__1797000028_A struct{ j2g_header uint64; F_c any }

var A_arbace_classes_go_generics_raw__1797000028_A_fn_class *jrt.Class



type A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A struct{ j2g_header uint64 }

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_fn_class *jrt.Class



type A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A struct{ j2g_header uint64; F_iter__1797000029, F_s__1797000030 any }

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_fn_class *jrt.Class



type A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1797000032 any }

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_fn_class *jrt.Class



type A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A struct{ j2g_header uint64 }

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_fn_class *jrt.Class



type A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A struct{ j2g_header uint64 }

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_fn_class *jrt.Class



type A_arbace_classes_go_generics_raw__1797000044_A struct{ j2g_header uint64; F_raw, F_n any }

var A_arbace_classes_go_generics_raw__1797000044_A_fn_class *jrt.Class



type A_arbace_classes_go_generics_raw__1797000044_iter__1797000045__1797000049_A struct{ j2g_header uint64; F_have any }

var A_arbace_classes_go_generics_raw__1797000044_iter__1797000045__1797000049_A_fn_class *jrt.Class



type A_arbace_classes_go_generics_raw__1797000044_iter__1797000045__1797000049_fn__1797000050_A struct{ j2g_header uint64; F_have, F_s__1797000046, F_iter__1797000045 any }

var A_arbace_classes_go_generics_raw__1797000044_iter__1797000045__1797000049_fn__1797000050_A_fn_class *jrt.Class



type A_arbace_classes_go_generics_raw__1797000044_iter__1797000045__1797000049_fn__1797000050_fn__1797000051_A struct{ j2g_header uint64; F_b__1797000048, F_have any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_go_generics_raw__1797000044_iter__1797000045__1797000049_fn__1797000050_fn__1797000051_A_fn_class *jrt.Class



type A_arbace_classes_go_newExceptionReference_A struct{ j2g_header uint64 }

var A_arbace_classes_go_newExceptionReference_A_fn_class *jrt.Class



type A_arbace_classes_go_newFormalParameterReference_A struct{ j2g_header uint64 }

var A_arbace_classes_go_newFormalParameterReference_A_fn_class *jrt.Class



type A_arbace_classes_go_newSuperTypeReference_A struct{ j2g_header uint64 }

var A_arbace_classes_go_newSuperTypeReference_A_fn_class *jrt.Class



type A_arbace_classes_go_newTryCatchReference_A struct{ j2g_header uint64 }

var A_arbace_classes_go_newTryCatchReference_A_fn_class *jrt.Class



type A_arbace_classes_go_newTypeArgumentReference_A struct{ j2g_header uint64 }

var A_arbace_classes_go_newTypeArgumentReference_A_fn_class *jrt.Class



type A_arbace_classes_go_newTypeParameterBoundReference_A struct{ j2g_header uint64 }

var A_arbace_classes_go_newTypeParameterBoundReference_A_fn_class *jrt.Class



type A_arbace_classes_go_newTypeParameterReference_A struct{ j2g_header uint64 }

var A_arbace_classes_go_newTypeParameterReference_A_fn_class *jrt.Class



type A_arbace_classes_go_newTypeReference_A struct{ j2g_header uint64 }

var A_arbace_classes_go_newTypeReference_A_fn_class *jrt.Class



type A_arbace_classes_go_protected_members_A struct{ j2g_header uint64 }

var A_arbace_classes_go_protected_members_A_fn_class *jrt.Class



type A_arbace_classes_go_tref_A struct{ j2g_header uint64 }

var A_arbace_classes_go_tref_A_fn_class *jrt.Class



type A_arbace_classes_go_tref_reify__1797000012_A struct{ jrt.Object; F_v int64; F___meta lang.IPersistentMap }

func (t *A_arbace_classes_go_tref_reify__1797000012_A) Is_Map_Entry() {}

func (t *A_arbace_classes_go_tref_reify__1797000012_A) Is_IObj() {}

func (t *A_arbace_classes_go_tref_reify__1797000012_A) Is_IMeta() {}

func (t *A_arbace_classes_go_tref_reify__1797000012_A) SetValue_O__O(p0 any) any { panic(jrt.AbstractMethodError_New_String(jrt.Str("Receiver class arbace.classes.go$tref$reify__1797000012 does not define or inherit an implementation of the resolved method 'abstract java.lang.Object setValue(java.lang.Object)' of interface java.util.Map$Entry."))) }

func (t *A_arbace_classes_go_tref_reify__1797000012_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_tref_reify__1797000012_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_tref_reify__1797000012_A_class }

func (t *A_arbace_classes_go_tref_reify__1797000012_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_tref_reify__1797000012_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_go_tref_reify__1797000012_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_tref_reify__1797000012_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_tref_reify__1797000012_A); return ok }

func A_arbace_classes_go_tref_reify__1797000012_A_Cast(x any) *A_arbace_classes_go_tref_reify__1797000012_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_tref_reify__1797000012_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_tref_reify__1797000012_A_class)) }; return v }



type A_arbace_classes_go_world_const_A struct{ j2g_header uint64 }

var A_arbace_classes_go_world_const_A_fn_class *jrt.Class
