//line aot_arbace_classes_go.ae:1
package aot_arbace_classes_go

import (
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_New() *A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_classes_go_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_go_A_const_4); tmp2 = lang.IFn_Cast(A_arbace_classes_go_A_const_0.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_go_A_const_1, A_arbace_classes_go_A_const_2); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_classes_go_eval1797000008_fn__1797000009_A_New() *A_arbace_classes_go_eval1797000008_fn__1797000009_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_eval1797000008_fn__1797000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_go_eval1797000008_fn__1797000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_go_eval1797000008_fn__1797000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_go_A_const_5.GetRawRoot__O()); var tmp2 any; var root_10 any = A_arbace_classes_go_A_const_6.GetRawRoot__O(); var linked_11 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_10, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_12 lang.IFn; if linked_11 == nil { ifn_12 = lang.IFn_Cast(root_10) } else { ifn_12 = nil }; var arg_13 any = A_arbace_classes_go_A_const_7; if linked_11 == nil { tmp2 = ifn_12.Invoke_O__O(arg_13) } else { tmp2 = linked_11.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_10, arg_13) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_classes_go_A_const_8.GetRawRoot__O(), A_arbace_classes_go_A_const_9) }










func A_arbace_classes_go_tref_A_New() *A_arbace_classes_go_tref_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_tref_A{}; t.Ctor(); return t }
//line :12:1
func (t *A_arbace_classes_go_tref_A) Ctor() {}
//line :12:1
func (t *A_arbace_classes_go_tref_A) Invoke_O_O__O(self, p_v__0 any) any { var v__0 int64 = lang.RT_LongCast_O__J_NoInit(p_v__0); return A_arbace_classes_go_tref_reify__1797000012_A_New_IPersistentMap_J(nil, v__0) }
//line :12:1
func A_arbace_classes_go_tref_reify__1797000012_A_New_IPersistentMap_J(p0 lang.IPersistentMap, p1 int64) *A_arbace_classes_go_tref_reify__1797000012_A { t := &A_arbace_classes_go_tref_reify__1797000012_A{}; t.Ctor_IPersistentMap_J(p0, p1); return t }
//line :12:1
func (t *A_arbace_classes_go_tref_reify__1797000012_A) Ctor_IPersistentMap_J(meta__ lang.IPersistentMap, c__v int64) { t.F___meta = meta__; t.F_v = c__v }
//line :12:1
func (t *A_arbace_classes_go_tref_reify__1797000012_A) GetValue__O() any { return jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_J__I_NoInit(t.F_v)).Ref() }
//line :12:1
func (t *A_arbace_classes_go_tref_reify__1797000012_A) GetKey__O() any { return nil }
//line :12:1
func (t *A_arbace_classes_go_tref_reify__1797000012_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :12:1
func (t *A_arbace_classes_go_tref_reify__1797000012_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_classes_go_tref_reify__1797000012_A_New_IPersistentMap_J(m, t.F_v) }
























func A_arbace_classes_go_newTypeReference_A_New() *A_arbace_classes_go_newTypeReference_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_newTypeReference_A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_classes_go_newTypeReference_A) Ctor() {}
//line :37:1
func (t *A_arbace_classes_go_newTypeReference_A) Invoke_O_O__O(self, sort__0 any) any { var root_20 any = A_arbace_classes_go_A_const_10.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_20, A_arbace_classes_go_tref_A_fn_class); var ifn_22 lang.IFn; if linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(sort__0), 24)).Ref(); if linked_21 == nil { return ifn_22.Invoke_O__O(arg_23) } else { return linked_21.(*A_arbace_classes_go_tref_A).Invoke_O_O__O(root_20, arg_23) } }
func A_arbace_classes_go_newTypeParameterReference_A_New() *A_arbace_classes_go_newTypeParameterReference_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_newTypeParameterReference_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_classes_go_newTypeParameterReference_A) Ctor() {}
//line :38:1
func (t *A_arbace_classes_go_newTypeParameterReference_A) Invoke_O_O_O__O(self, sort__0, i__1 any) any {
	var root_24 any = A_arbace_classes_go_A_const_10.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, A_arbace_classes_go_tref_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Or_J_J__J_NoInit(lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(sort__0), 24), lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(i__1), 16))).Ref(); if linked_25 == nil { return ifn_26.Invoke_O__O(arg_27) } else { return linked_25.(*A_arbace_classes_go_tref_A).Invoke_O_O__O(root_24, arg_27) } }
func A_arbace_classes_go_newTypeParameterBoundReference_A_New() *A_arbace_classes_go_newTypeParameterBoundReference_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_newTypeParameterBoundReference_A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_classes_go_newTypeParameterBoundReference_A) Ctor() {}
//line :40:1
func (t *A_arbace_classes_go_newTypeParameterBoundReference_A) Invoke_O_O_O_O__O(self, sort__0, p__1, b__2 any) any {
	var root_28 any = A_arbace_classes_go_A_const_10.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_28, A_arbace_classes_go_tref_A_fn_class); var ifn_30 lang.IFn; if linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Or_J_J__J_NoInit(lang.Numbers_Or_J_J__J_NoInit(lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(sort__0), 24), lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(p__1), 16)), lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(b__2), 8))).Ref(); if linked_29 == nil { return ifn_30.Invoke_O__O(arg_31) } else { return linked_29.(*A_arbace_classes_go_tref_A).Invoke_O_O__O(root_28, arg_31) } }
func A_arbace_classes_go_newSuperTypeReference_A_New() *A_arbace_classes_go_newSuperTypeReference_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_newSuperTypeReference_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_classes_go_newSuperTypeReference_A) Ctor() {}
//line :42:1
func (t *A_arbace_classes_go_newSuperTypeReference_A) Invoke_O_O__O(self, i__0 any) any {
	var root_37 any = A_arbace_classes_go_A_const_10.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_37, A_arbace_classes_go_tref_A_fn_class); var ifn_39 lang.IFn; if linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any; var tmp1 int64; var na_32 any = A_arbace_classes_go_A_const_11.GetRawRoot__O(); var na_33 int64 = 24; if jrt.Long_InstanceOf(na_32) { var n0_34 int64 = jrt.NN(jrt.Long_Cast(na_32)).LongValue__J(); var n1_35 int64 = na_33; tmp1 = n0_34 << (n1_35 & 63) } else { tmp1 = lang.Numbers_ShiftLeft_O_J__J_NoInit(na_32, na_33) }; arg_40 = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Or_J_J__J_NoInit(tmp1, lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.Numbers_And_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(i__0), 65535), 8))).Ref(); if linked_38 == nil { return ifn_39.Invoke_O__O(arg_40) } else { return linked_38.(*A_arbace_classes_go_tref_A).Invoke_O_O__O(root_37, arg_40) } }
func A_arbace_classes_go_newFormalParameterReference_A_New() *A_arbace_classes_go_newFormalParameterReference_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_newFormalParameterReference_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_classes_go_newFormalParameterReference_A) Ctor() {}
//line :44:1
func (t *A_arbace_classes_go_newFormalParameterReference_A) Invoke_O_O__O(self, i__0 any) any {
	var root_46 any = A_arbace_classes_go_A_const_10.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, A_arbace_classes_go_tref_A_fn_class); var ifn_48 lang.IFn; if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any; var tmp1 int64; var na_41 any = A_arbace_classes_go_A_const_12.GetRawRoot__O(); var na_42 int64 = 24; if jrt.Long_InstanceOf(na_41) { var n0_43 int64 = jrt.NN(jrt.Long_Cast(na_41)).LongValue__J(); var n1_44 int64 = na_42; tmp1 = n0_43 << (n1_44 & 63) } else { tmp1 = lang.Numbers_ShiftLeft_O_J__J_NoInit(na_41, na_42) }; arg_49 = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Or_J_J__J_NoInit(tmp1, lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(i__0), 16))).Ref(); if linked_47 == nil { return ifn_48.Invoke_O__O(arg_49) } else { return linked_47.(*A_arbace_classes_go_tref_A).Invoke_O_O__O(root_46, arg_49) } }
func A_arbace_classes_go_newExceptionReference_A_New() *A_arbace_classes_go_newExceptionReference_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_newExceptionReference_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_classes_go_newExceptionReference_A) Ctor() {}
//line :46:1
func (t *A_arbace_classes_go_newExceptionReference_A) Invoke_O_O__O(self, i__0 any) any { var root_55 any = A_arbace_classes_go_A_const_10.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, A_arbace_classes_go_tref_A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any; var tmp1 int64; var na_50 any = A_arbace_classes_go_A_const_13.GetRawRoot__O(); var na_51 int64 = 24; if jrt.Long_InstanceOf(na_50) { var n0_52 int64 = jrt.NN(jrt.Long_Cast(na_50)).LongValue__J(); var n1_53 int64 = na_51; tmp1 = n0_52 << (n1_53 & 63) } else { tmp1 = lang.Numbers_ShiftLeft_O_J__J_NoInit(na_50, na_51) }; arg_58 = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Or_J_J__J_NoInit(tmp1, lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(i__0), 8))).Ref(); if linked_56 == nil { return ifn_57.Invoke_O__O(arg_58) } else { return linked_56.(*A_arbace_classes_go_tref_A).Invoke_O_O__O(root_55, arg_58) } }
func A_arbace_classes_go_newTryCatchReference_A_New() *A_arbace_classes_go_newTryCatchReference_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_newTryCatchReference_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_classes_go_newTryCatchReference_A) Ctor() {}
//line :47:1
func (t *A_arbace_classes_go_newTryCatchReference_A) Invoke_O_O__O(self, i__0 any) any {
	var root_64 any = A_arbace_classes_go_A_const_10.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, A_arbace_classes_go_tref_A_fn_class); var ifn_66 lang.IFn; if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any; var tmp1 int64; var na_59 any = A_arbace_classes_go_A_const_14.GetRawRoot__O(); var na_60 int64 = 24; if jrt.Long_InstanceOf(na_59) { var n0_61 int64 = jrt.NN(jrt.Long_Cast(na_59)).LongValue__J(); var n1_62 int64 = na_60; tmp1 = n0_61 << (n1_62 & 63) } else { tmp1 = lang.Numbers_ShiftLeft_O_J__J_NoInit(na_59, na_60) }; arg_67 = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Or_J_J__J_NoInit(tmp1, lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(i__0), 8))).Ref(); if linked_65 == nil { return ifn_66.Invoke_O__O(arg_67) } else { return linked_65.(*A_arbace_classes_go_tref_A).Invoke_O_O__O(root_64, arg_67) } }
func A_arbace_classes_go_newTypeArgumentReference_A_New() *A_arbace_classes_go_newTypeArgumentReference_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_newTypeArgumentReference_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_classes_go_newTypeArgumentReference_A) Ctor() {}
//line :49:1
func (t *A_arbace_classes_go_newTypeArgumentReference_A) Invoke_O_O_O__O(self, sort__0, i__1 any) any {
	var root_68 any = A_arbace_classes_go_A_const_10.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, A_arbace_classes_go_tref_A_fn_class); var ifn_70 lang.IFn; if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Or_J_J__J_NoInit(lang.Numbers_ShiftLeft_J_J__J_NoInit(lang.RT_LongCast_O__J_NoInit(sort__0), 24), lang.RT_LongCast_O__J_NoInit(i__1))).Ref(); if linked_69 == nil { return ifn_70.Invoke_O__O(arg_71) } else { return linked_69.(*A_arbace_classes_go_tref_A).Invoke_O_O__O(root_68, arg_71)
	}
}







func A_arbace_classes_go_fn__1797000023_A_New() *A_arbace_classes_go_fn__1797000023_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_fn__1797000023_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_classes_go_fn__1797000023_A) Ctor() {}
//line :60:1
func (t *A_arbace_classes_go_fn__1797000023_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = jrt.Class_ForName_String__Class(Lit_1).Ref(); return nil }(); if tmp2 != nil { if true { var ___3 jrt.Throwable_I = tmp2; _ = ___3; tmp1 = nil } }; return tmp1 }


func A_arbace_classes_go_fn__1797000025_A_New() *A_arbace_classes_go_fn__1797000025_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_fn__1797000025_A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_classes_go_fn__1797000025_A) Ctor() {}
//line :63:1
func (t *A_arbace_classes_go_fn__1797000025_A) Invoke_O__O(self any) any { var temp__1927000408__auto____1 any = lang.RT_ResourceAsStream_ClassLoader_String__InputStream_NoInit(nil, Lit_2); if
										jrt.J2g_Truth(temp__1927000408__auto____1) { var in__2 any = temp__1927000408__auto____1; var root_88 any = A_arbace_classes_go_A_const_18.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_88, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_90 lang.IFn
											if linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; var arg_91 any = lang.IFn_Cast(A_arbace_classes_go_A_const_19.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_go_A_const_20, jrt.Boolean_FALSE.Ref()); if linked_89 == nil { ifn_90.Invoke_O__O(arg_91) } else { linked_89.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_88, arg_91) }
//line :64:1
		var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

			{ var root_76 any = A_arbace_classes_go_A_const_15.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var arg_79 any = lang.IFn_Cast(A_arbace_classes_go_A_const_16.GetRawRoot__O()).Invoke_O__O(in__2); if linked_77 == nil { tmp1 = ifn_78.Invoke_O__O(arg_79) } else { tmp1 = linked_77.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_76, arg_79) } }
//line :64:1
			return nil }(); var root_80 any = A_arbace_classes_go_A_const_17.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_82 lang.IFn
		if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; if linked_81 == nil { ifn_82.Invoke__O() } else { linked_81.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_80) }
//line :64:1
		if tmp2 != nil { panic(tmp2) }; return tmp1 } else { return lang.PersistentArrayMap_EMPTY.Ref() } }




func A_arbace_classes_go_generics_A_New() *A_arbace_classes_go_generics_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_generics_A{}; t.Ctor(); return t }
//line :69:1
func (t *A_arbace_classes_go_generics_A) Ctor() {}
//line :69:1
func (t *A_arbace_classes_go_generics_A) Invoke_O_O_O__O(self, n__0, c__1 any) any { var g__3 any; var tmp1 any; var root_92 any = A_arbace_classes_go_A_const_6.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_94 lang.IFn; if




	linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any = A_arbace_classes_go_A_const_21.GetRawRoot__O(); if linked_93 == nil { tmp1 = ifn_94.Invoke_O__O(arg_95) } else { tmp1 = linked_93.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_92, arg_95) }; g__3 = lang.RT_Get_O_O__O_NoInit(tmp1, n__0); var raw__4 any; var tmp2 any = /*line :69:1*/A_arbace_classes_go_generics_raw__1797000028_A_New_O(c__1); var tmp3 *jrt.Class; var fncls__217 *jrt.Class = A_arbace_classes_go_generics_raw__1797000028_A_fn_class; if





	fncls__217 == nil { var fncls__217d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_classes_go_generics_raw__1797000028_A_fn_class = fncls__217d; tmp3 = fncls__217d } else { tmp3 = fncls__217 }; raw__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp4 any; var and__1927000168__auto____5 any = g__3; if








	jrt.J2g_Truth(and__1927000168__auto____5) { tmp4 = A_arbace_classes_go_A_const_45.Invoke_O__O(g__3) } else { tmp4 = and__1927000168__auto____5 }; if /*line :83:1*/ jrt.J2g_Truth(tmp4) { return g__3 } else { if jrt.J2g_Truth(g__3) {

		var root_218 any = A_arbace_classes_go_A_const_46.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_218, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_220 lang.IFn; if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any = g__3; var arg_222 any = A_arbace_classes_go_A_const_45; var arg_223 any = lang.IFn_Cast(raw__4).Invoke__O(); if linked_219 == nil { return ifn_220.Invoke_O_O_O__O(arg_221, arg_222, arg_223) } else { return linked_219.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_218, arg_221, arg_222, arg_223) } } else {
//line :83:1
			if A_arbace_classes_go_A_const_47 != nil { var tmp5 any = A_arbace_classes_go_A_const_48; var tmp6 any = lang.PersistentVector_EMPTY.Ref(); var tmp7 any = A_arbace_classes_go_A_const_49; var tmp8 any; var root_238 any = A_arbace_classes_go_A_const_50.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_240 lang.IFn



				if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any = A_arbace_classes_go_A_const_51.GetRawRoot__O(); var arg_242 any; var root_233 any = A_arbace_classes_go_A_const_43.GetRawRoot__O(); var linked_234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_233, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_235 lang.IFn; if linked_234 == nil { ifn_235 = lang.IFn_Cast(root_233) } else { ifn_235 = nil }; var arg_236 any; var G__1797000044__5_ any = jrt.NN(jrt.Class_Cast(c__1)).GetSuperclass__Class().Ref(); if lang.Util_Identical_O_O__Z_NoInit(G__1797000044__5_, nil) { arg_236 = nil } else { var root_224 any = A_arbace_classes_go_A_const_37.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, aot_arbace_classes_types.A_arbace_classes_types_reflect__GT_tnode_A_fn_class); var ifn_226 lang.IFn; if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = G__1797000044__5_; if linked_225 == nil { arg_236 = ifn_226.Invoke_O__O(arg_227) } else { arg_236 = linked_225.(*aot_arbace_classes_types.A_arbace_classes_types_reflect__GT_tnode_A).Invoke_O_O__O(root_224, arg_227) } }; var arg_237 any; var root_228 any = A_arbace_classes_go_A_const_30.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_228, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_230 lang.IFn
				if linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any = A_arbace_classes_go_A_const_37.GetRawRoot__O(); var arg_232 any = jrt.NN(jrt.Class_Cast(c__1)).GetInterfaces__Class1().Ref(); if linked_229 == nil { arg_237 = ifn_230.Invoke_O_O__O(arg_231, arg_232) } else { arg_237 = linked_229.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_228, arg_231, arg_232) }
//line :87:1
				if linked_234 == nil { arg_242 = ifn_235.Invoke_O_O__O(arg_236, arg_237) } else { arg_242 = linked_234.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_233, arg_236, arg_237) }; if linked_239 == nil { tmp8 = ifn_240.Invoke_O_O__O(arg_241, arg_242) } else { tmp8 = linked_239.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_238, arg_241, arg_242) }
//line :83:1
				var tmp9 any = tmp8; var tmp10 any = A_arbace_classes_go_A_const_45; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, tmp9, tmp10, lang.IFn_Cast(raw__4).Invoke__O())) } else { return nil } } } }
//line :75:1
func A_arbace_classes_go_generics_raw__1797000028_A_New_O(p0 any) *A_arbace_classes_go_generics_raw__1797000028_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_generics_raw__1797000028_A{}; t.Ctor_O(p0); return t }
//line :75:1
func (t *A_arbace_classes_go_generics_raw__1797000028_A) Ctor_O(c__c any) { t.F_c = c__c }
//line :75:1
func (t *A_arbace_classes_go_generics_raw__1797000028_A) Invoke_O__O(self any) any { var iter__1927001039__auto____1 any; var tmp1 any = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_New(); var tmp2 *jrt.Class; var fncls__216 *jrt.Class = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_fn_class; if
											fncls__216 == nil { var fncls__216d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_fn_class = fncls__216d; tmp2 = fncls__216d } else { tmp2 = fncls__216 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return lang.IFn_Cast(iter__1927001039__auto____1).Invoke_O__O(jrt.NN(jrt.Class_Cast(t.F_c)).GetDeclaredMethods__Method1().Ref()) }
//line :76:1
func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_New() *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A{}; t.Ctor(); return t }
//line :76:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A) Ctor() {}
//line :76:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A) Invoke_O_O__O(self, s__1797000030__1 any) any { var tmp1 any = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_New_O_O(self, s__1797000030__1); var tmp2 *jrt.Class; var fncls__215 *jrt.Class = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_fn_class; if fncls__215 == nil { var fncls__215d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_fn_class = fncls__215d; tmp2 = fncls__215d } else { tmp2 = fncls__215 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :76:1
func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_New_O_O(p0, p1 any) *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A{}; t.Ctor_O_O(p0, p1); return t }
//line :76:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A) Ctor_O_O(c__iter__1797000029, c__s__1797000030 any) { t.F_iter__1797000029 = c__iter__1797000029; t.F_s__1797000030 = c__s__1797000030 }
//line :76:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A) Invoke_O__O(self any) any { { var s__1797000030__1 any; var t_ any = t.F_s__1797000030; t.F_s__1797000030 = nil; s__1797000030__1 = t_; for { var temp__1927000414__auto____2 any; var root_96 any = A_arbace_classes_go_A_const_22.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_98 lang.IFn; if linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any = s__1797000030__1; if linked_97 == nil { temp__1927000414__auto____2 = ifn_98.Invoke_O__O(arg_99) } else { temp__1927000414__auto____2 = linked_97.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_96, arg_99) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1797000030__3 any = temp__1927000414__auto____2; var tmp1 any; var root_100 any = A_arbace_classes_go_A_const_23.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = s__1797000030__3; if linked_101 == nil { tmp1 = ifn_102.Invoke_O__O(arg_103) } else { tmp1 = linked_101.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_100, arg_103) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_104 any = A_arbace_classes_go_A_const_24.GetRawRoot__O(); var linked_105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_104, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_106 lang.IFn; if linked_105 == nil { ifn_106 = lang.IFn_Cast(root_104) } else { ifn_106 = nil }; var arg_107 any = s__1797000030__3; if linked_105 == nil { c__1927001037__auto____4 = ifn_106.Invoke_O__O(arg_107) } else { c__1927001037__auto____4 = linked_105.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_104, arg_107) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1797000032__6 any; var root_108 any = A_arbace_classes_go_A_const_25.GetRawRoot__O(); var linked_109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_108, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_110 lang.IFn; if linked_109 == nil { ifn_110 = lang.IFn_Cast(root_108) } else { ifn_110 = nil }; var arg_111 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_109 == nil { b__1797000032__6 = ifn_110.Invoke_O__O(arg_111) } else { b__1797000032__6 = linked_109.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_108, arg_111) }; var tmp2 any = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1797000032__6); var tmp3 *jrt.Class; var fncls__148 *jrt.Class = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_fn_class; if fncls__148 == nil { var fncls__148d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_fn_class = fncls__148d; tmp3 = fncls__148d } else { tmp3 = fncls__148 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_157 any = A_arbace_classes_go_A_const_39.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_157, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_159 lang.IFn; if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any; var root_149 any = A_arbace_classes_go_A_const_40.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_149, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_151 lang.IFn; if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any = b__1797000032__6; if linked_150 == nil { arg_160 = ifn_151.Invoke_O__O(arg_152) } else { arg_160 = linked_150.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_149, arg_152) }; var arg_161 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1797000029); var tmp5 any; var root_153 any = A_arbace_classes_go_A_const_41.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_153, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_155 lang.IFn; if linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any = s__1797000030__3; if linked_154 == nil { tmp5 = ifn_155.Invoke_O__O(arg_156) } else { tmp5 = linked_154.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_153, arg_156) }; arg_161 = tmp4.Invoke_O__O(tmp5); if linked_158 == nil { return ifn_159.Invoke_O_O__O(arg_160, arg_161) } else { return linked_158.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_157, arg_160, arg_161) } } else { var root_166 any = A_arbace_classes_go_A_const_39.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_166, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_168 lang.IFn; if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any; var root_162 any = A_arbace_classes_go_A_const_40.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_162, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_164 lang.IFn; if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any = b__1797000032__6; if linked_163 == nil { arg_169 = ifn_164.Invoke_O__O(arg_165) } else { arg_169 = linked_163.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_162, arg_165) }; var arg_170 any; if linked_167 == nil { return ifn_168.Invoke_O_O__O(arg_169, arg_170) } else { return linked_167.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_166, arg_169, arg_170) } } } else { var m__4 any; var root_171 any = A_arbace_classes_go_A_const_42.GetRawRoot__O(); var linked_172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_171, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_173 lang.IFn; if linked_172 == nil { ifn_173 = lang.IFn_Cast(root_171) } else { ifn_173 = nil }; var arg_174 any = s__1797000030__3; if linked_172 == nil { m__4 = ifn_173.Invoke_O__O(arg_174) } else { m__4 = linked_172.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_171, arg_174) }; var root_210 any = A_arbace_classes_go_A_const_43.GetRawRoot__O(); var linked_211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_210, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_212 lang.IFn; if linked_211 == nil { ifn_212 = lang.IFn_Cast(root_210) } else { ifn_212 = nil }; var arg_213 any; var tmp6 any = A_arbace_classes_go_A_const_27; var tmp7 any = jrt.NN(jrt.Method_Cast(m__4)).GetName__String().Ref(); var tmp8 any = A_arbace_classes_go_A_const_28; var tmp9 any; var root_184 any = A_arbace_classes_go_A_const_29.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_classes_types.A_arbace_classes_types_method_desc_A_fn_class); var ifn_186 lang.IFn

	if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any; var root_175 any = A_arbace_classes_go_A_const_30.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_175, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_177 lang.IFn; if linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any = A_arbace_classes_go_A_const_31.GetRawRoot__O(); var arg_179 any = jrt.NN(jrt.Method_Cast(m__4)).GetParameterTypes__Class1().Ref(); if linked_176 == nil { arg_187 = ifn_177.Invoke_O_O__O(arg_178, arg_179) } else { arg_187 = linked_176.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_175, arg_178, arg_179) }; var arg_188 any; var root_180 any = A_arbace_classes_go_A_const_31.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A_fn_class); var ifn_182 lang.IFn; if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any = jrt.NN(jrt.Method_Cast(m__4)).GetReturnType__Class().Ref(); if linked_181 == nil { arg_188 = ifn_182.Invoke_O__O(arg_183) } else { arg_188 = linked_181.(*aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A).Invoke_O_O__O(root_180, arg_183) }; if linked_185 == nil { tmp9 = ifn_186.Invoke_O_O__O(arg_187, arg_188) } else { tmp9 = linked_185.(*aot_arbace_classes_types.A_arbace_classes_types_method_desc_A).Invoke_O_O_O__O(root_184, arg_187, arg_188) }
//line :76:1
	var tmp10 any = tmp9; var tmp11 any = A_arbace_classes_go_A_const_32; var tmp12 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Method_Cast(m__4)).GetModifiers__I()).Ref(); var tmp13 any = A_arbace_classes_go_A_const_33; var tmp14 any; var root_196 any = A_arbace_classes_go_A_const_34.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_196, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_198 lang.IFn



	if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any; var tmp15 any = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_New(); var tmp16 *jrt.Class; var fncls__195 *jrt.Class = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_fn_class; if fncls__195 == nil { var fncls__195d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_fn_class = fncls__195d; tmp16 = fncls__195d } else { tmp16 = fncls__195 }; arg_199 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); var arg_200 any = jrt.NN(jrt.Method_Cast(m__4)).GetExceptionTypes__Class1().Ref(); if linked_197 == nil { tmp14 = ifn_198.Invoke_O_O__O(arg_199, arg_200) } else { tmp14 = linked_197.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_196, arg_199, arg_200) }
//line :76:1
	var tmp17 any = tmp14; var tmp18 any = A_arbace_classes_go_A_const_36; var tmp19 any; var root_201 any = A_arbace_classes_go_A_const_34.GetRawRoot__O(); var linked_202 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_201, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_203 lang.IFn




	if linked_202 == nil { ifn_203 = lang.IFn_Cast(root_201) } else { ifn_203 = nil }; var arg_204 any = A_arbace_classes_go_A_const_37.GetRawRoot__O(); var arg_205 any = jrt.NN(jrt.Method_Cast(m__4)).GetParameterTypes__Class1().Ref(); if linked_202 == nil { tmp19 = ifn_203.Invoke_O_O__O(arg_204, arg_205) } else { tmp19 = linked_202.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_201, arg_204, arg_205) }
//line :76:1
	arg_213 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7, tmp8, tmp10, tmp11, tmp12, tmp13, tmp17, tmp18, tmp19, A_arbace_classes_go_A_const_38, lang.PersistentArrayMap_EMPTY.Ref())); var arg_214 any; var tmp20 lang.IFn = lang.IFn_Cast(t.F_iter__1797000029); var tmp21 any; var root_206 any = A_arbace_classes_go_A_const_44.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_208 lang.IFn; if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any = s__1797000030__3; if linked_207 == nil { tmp21 = ifn_208.Invoke_O__O(arg_209) } else { tmp21 = linked_207.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_206, arg_209) }; arg_214 = tmp20.Invoke_O__O(tmp21); if linked_211 == nil { return ifn_212.Invoke_O_O__O(arg_213, arg_214) } else { return linked_211.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_210, arg_213, arg_214) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :76:1
func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :76:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1797000032 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1797000032 = c__b__1797000032 }
//line :76:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A) Invoke_O__O(self any) any { { var i__1797000031__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1797000031__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1797000031__1)); var root_143 any = A_arbace_classes_go_A_const_26.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_143, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_145 lang.IFn; if linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any = t.F_b__1797000032; var arg_147 any; var tmp2 any = A_arbace_classes_go_A_const_27; var tmp3 any = jrt.NN(jrt.Method_Cast(m__2)).GetName__String().Ref(); var tmp4 any = A_arbace_classes_go_A_const_28; var tmp5 any; var root_121 any = A_arbace_classes_go_A_const_29.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, aot_arbace_classes_types.A_arbace_classes_types_method_desc_A_fn_class); var ifn_123 lang.IFn

	if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any; var root_112 any = A_arbace_classes_go_A_const_30.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_112, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = A_arbace_classes_go_A_const_31.GetRawRoot__O(); var arg_116 any = jrt.NN(jrt.Method_Cast(m__2)).GetParameterTypes__Class1().Ref(); if linked_113 == nil { arg_124 = ifn_114.Invoke_O_O__O(arg_115, arg_116) } else { arg_124 = linked_113.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_112, arg_115, arg_116) }; var arg_125 any; var root_117 any = A_arbace_classes_go_A_const_31.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_117, aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A_fn_class); var ifn_119 lang.IFn; if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = jrt.NN(jrt.Method_Cast(m__2)).GetReturnType__Class().Ref(); if linked_118 == nil { arg_125 = ifn_119.Invoke_O__O(arg_120) } else { arg_125 = linked_118.(*aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A).Invoke_O_O__O(root_117, arg_120) }; if linked_122 == nil { tmp5 = ifn_123.Invoke_O_O__O(arg_124, arg_125) } else { tmp5 = linked_122.(*aot_arbace_classes_types.A_arbace_classes_types_method_desc_A).Invoke_O_O_O__O(root_121, arg_124, arg_125) }
//line :76:1
	var tmp6 any = tmp5; var tmp7 any = A_arbace_classes_go_A_const_32; var tmp8 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Method_Cast(m__2)).GetModifiers__I()).Ref(); var tmp9 any = A_arbace_classes_go_A_const_33; var tmp10 any; var root_133 any = A_arbace_classes_go_A_const_34.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_133, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_135 lang.IFn



	if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any; var tmp11 any = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_New(); var tmp12 *jrt.Class; var fncls__132 *jrt.Class = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_fn_class; if fncls__132 == nil { var fncls__132d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_fn_class = fncls__132d; tmp12 = fncls__132d } else { tmp12 = fncls__132 }; arg_136 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var arg_137 any = jrt.NN(jrt.Method_Cast(m__2)).GetExceptionTypes__Class1().Ref(); if linked_134 == nil { tmp10 = ifn_135.Invoke_O_O__O(arg_136, arg_137) } else { tmp10 = linked_134.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_133, arg_136, arg_137) }
//line :76:1
	var tmp13 any = tmp10; var tmp14 any = A_arbace_classes_go_A_const_36; var tmp15 any; var root_138 any = A_arbace_classes_go_A_const_34.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_138, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_140 lang.IFn




	if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = A_arbace_classes_go_A_const_37.GetRawRoot__O(); var arg_142 any = jrt.NN(jrt.Method_Cast(m__2)).GetParameterTypes__Class1().Ref(); if linked_139 == nil { tmp15 = ifn_140.Invoke_O_O__O(arg_141, arg_142) } else { tmp15 = linked_139.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_138, arg_141, arg_142) }
//line :76:1
	arg_147 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, tmp6, tmp7, tmp8, tmp9, tmp13, tmp14, tmp15, A_arbace_classes_go_A_const_38, lang.PersistentArrayMap_EMPTY.Ref())); if linked_144 == nil { ifn_145.Invoke_O_O__O(arg_146, arg_147) } else { linked_144.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_143, arg_146, arg_147) }; i__1797000031__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1797000031__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_New() *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A) Ctor() {}
//line :80:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A) Invoke_O_O__O(self, p1__1797000027_SHARP___1 any) any { var root_126 any = A_arbace_classes_go_A_const_35.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_126, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_128 lang.IFn; if linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; var arg_129 any = jrt.NN(jrt.Class_Cast(p1__1797000027_SHARP___1)).GetName__String().Ref(); var arg_130 any = Lit_9; var arg_131 any = Lit_10; if linked_127 == nil { return ifn_128.Invoke_O_O_O__O(arg_129, arg_130, arg_131) } else { return linked_127.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_126, arg_129, arg_130, arg_131) } }
//line :80:1
func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_New() *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A) Ctor() {}
//line :80:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A) Invoke_O_O__O(self, p1__1797000027_SHARP___1 any) any { var root_189 any = A_arbace_classes_go_A_const_35.GetRawRoot__O(); var linked_190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_189, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_191 lang.IFn; if linked_190 == nil { ifn_191 = lang.IFn_Cast(root_189) } else { ifn_191 = nil }; var arg_192 any = jrt.NN(jrt.Class_Cast(p1__1797000027_SHARP___1)).GetName__String().Ref(); var arg_193 any = Lit_9; var arg_194 any = Lit_10; if linked_190 == nil { return ifn_191.Invoke_O_O_O__O(arg_192, arg_193, arg_194) } else { return linked_190.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_189, arg_192, arg_193, arg_194) } }










func A_arbace_classes_go_constructors_A_New() *A_arbace_classes_go_constructors_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_constructors_A{}; t.Ctor(); return t }
//line :91:1
func (t *A_arbace_classes_go_constructors_A) Ctor() {}
//line :91:1
func (t *A_arbace_classes_go_constructors_A) Invoke_O_O__O(self, n__0 any) any { var or__1927000174__auto____2 any; var tmp1 *lang.Keyword = A_arbace_classes_go_A_const_52; var tmp2 any; var root_243 any = A_arbace_classes_go_A_const_6.GetRawRoot__O(); var linked_244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_243, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_245 lang.IFn; if



	linked_244 == nil { ifn_245 = lang.IFn_Cast(root_243) } else { ifn_245 = nil }; var arg_246 any = A_arbace_classes_go_A_const_21.GetRawRoot__O(); if linked_244 == nil { tmp2 = ifn_245.Invoke_O__O(arg_246) } else { tmp2 = linked_244.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_243, arg_246) }; or__1927000174__auto____2 = tmp1.Invoke_O__O(lang.RT_Get_O_O__O_NoInit(tmp2, n__0)); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else {
		return lang.RT_Get_O_O__O_NoInit(A_arbace_classes_go_A_const_53, n__0) } }


















































type A_arbace_classes_go_A struct{ jrt.Object }

var A_arbace_classes_go_A_const_pool *jrt.RefArray

var A_arbace_classes_go_A_const_0 *lang.Var

var A_arbace_classes_go_A_const_1 any

var A_arbace_classes_go_A_const_2 any

var A_arbace_classes_go_A_const_3 *lang.Var

var A_arbace_classes_go_A_const_4 any

var A_arbace_classes_go_A_const_5 *lang.Var

var A_arbace_classes_go_A_const_6 *lang.Var

var A_arbace_classes_go_A_const_7 *lang.Var

var A_arbace_classes_go_A_const_8 *lang.Var

var A_arbace_classes_go_A_const_9 any

var A_arbace_classes_go_A_const_10 *lang.Var

var A_arbace_classes_go_A_const_11 *lang.Var

var A_arbace_classes_go_A_const_12 *lang.Var

var A_arbace_classes_go_A_const_13 *lang.Var

var A_arbace_classes_go_A_const_14 *lang.Var

var A_arbace_classes_go_A_const_15 *lang.Var

var A_arbace_classes_go_A_const_16 *lang.Var

var A_arbace_classes_go_A_const_17 *lang.Var

var A_arbace_classes_go_A_const_18 *lang.Var

var A_arbace_classes_go_A_const_19 *lang.Var

var A_arbace_classes_go_A_const_20 *lang.Var

var A_arbace_classes_go_A_const_21 *lang.Var

var A_arbace_classes_go_A_const_22 *lang.Var

var A_arbace_classes_go_A_const_23 *lang.Var

var A_arbace_classes_go_A_const_24 *lang.Var

var A_arbace_classes_go_A_const_25 *lang.Var

var A_arbace_classes_go_A_const_26 *lang.Var

var A_arbace_classes_go_A_const_27 *lang.Keyword

var A_arbace_classes_go_A_const_28 *lang.Keyword

var A_arbace_classes_go_A_const_29 *lang.Var

var A_arbace_classes_go_A_const_30 *lang.Var

var A_arbace_classes_go_A_const_31 *lang.Var

var A_arbace_classes_go_A_const_32 *lang.Keyword

var A_arbace_classes_go_A_const_33 *lang.Keyword

var A_arbace_classes_go_A_const_34 *lang.Var

var A_arbace_classes_go_A_const_35 *lang.Var

var A_arbace_classes_go_A_const_36 *lang.Keyword

var A_arbace_classes_go_A_const_37 *lang.Var

var A_arbace_classes_go_A_const_38 *lang.Keyword

var A_arbace_classes_go_A_const_39 *lang.Var

var A_arbace_classes_go_A_const_40 *lang.Var

var A_arbace_classes_go_A_const_41 *lang.Var

var A_arbace_classes_go_A_const_42 *lang.Var

var A_arbace_classes_go_A_const_43 *lang.Var

var A_arbace_classes_go_A_const_44 *lang.Var

var A_arbace_classes_go_A_const_45 *lang.Keyword

var A_arbace_classes_go_A_const_46 *lang.Var

var A_arbace_classes_go_A_const_47 *lang.Keyword

var A_arbace_classes_go_A_const_48 *lang.Keyword

var A_arbace_classes_go_A_const_49 *lang.Keyword

var A_arbace_classes_go_A_const_50 *lang.Var

var A_arbace_classes_go_A_const_51 *lang.Var

var A_arbace_classes_go_A_const_52 *lang.Keyword

var A_arbace_classes_go_A_const_53 any

var A_arbace_classes_go_A_init jrt.ClassInit

func A_arbace_classes_go_A_Init() { if !A_arbace_classes_go_A_init.Done() { A_arbace_classes_go_A_init.Run(A_arbace_classes_go_A_clinit) } }

func A_arbace_classes_go_A_clinit() { A_arbace_classes_go_A_clinit_p0(); A_arbace_classes_go_A_clinit_p1(); A_arbace_classes_go_A_clinit_p2(); A_arbace_classes_go_A_clinit_p3(); A_arbace_classes_go_A_clinit_p4() }

func A_arbace_classes_go_A_clinit_p0() { jrt.StartCheck(); A_arbace_classes_go_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 72); A_arbace_classes_go_A_const_0 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[18]); A_arbace_classes_go_A_const_1 = A_arbace_classes_go_A_const_pool.A[19]; A_arbace_classes_go_A_const_2 = A_arbace_classes_go_A_const_pool.A[20]; A_arbace_classes_go_A_const_3 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[21]); A_arbace_classes_go_A_const_4 = A_arbace_classes_go_A_const_pool.A[22]; A_arbace_classes_go_A_const_5 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[23]); A_arbace_classes_go_A_const_6 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[24]); A_arbace_classes_go_A_const_7 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[25]); A_arbace_classes_go_A_const_8 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[26]); A_arbace_classes_go_A_const_9 = A_arbace_classes_go_A_const_pool.A[27]; A_arbace_classes_go_A_const_10 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[28]); A_arbace_classes_go_A_const_11 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[29]) }

func A_arbace_classes_go_A_clinit_p1() { A_arbace_classes_go_A_const_12 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[30]); A_arbace_classes_go_A_const_13 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[31]); A_arbace_classes_go_A_const_14 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[32]); A_arbace_classes_go_A_const_15 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[33]); A_arbace_classes_go_A_const_16 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[34]); A_arbace_classes_go_A_const_17 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[35]); A_arbace_classes_go_A_const_18 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[36]); A_arbace_classes_go_A_const_19 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[37]); A_arbace_classes_go_A_const_20 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[38]); A_arbace_classes_go_A_const_21 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[39]); A_arbace_classes_go_A_const_22 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[40]); A_arbace_classes_go_A_const_23 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[41]) }

func A_arbace_classes_go_A_clinit_p2() { A_arbace_classes_go_A_const_24 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[42]); A_arbace_classes_go_A_const_25 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[43]); A_arbace_classes_go_A_const_26 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[44]); A_arbace_classes_go_A_const_27 = lang.Keyword_Cast(A_arbace_classes_go_A_const_pool.A[45]); A_arbace_classes_go_A_const_28 = lang.Keyword_Cast(A_arbace_classes_go_A_const_pool.A[46]); A_arbace_classes_go_A_const_29 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[47]); A_arbace_classes_go_A_const_30 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[48]); A_arbace_classes_go_A_const_31 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[49]); A_arbace_classes_go_A_const_32 = lang.Keyword_Cast(A_arbace_classes_go_A_const_pool.A[50]); A_arbace_classes_go_A_const_33 = lang.Keyword_Cast(A_arbace_classes_go_A_const_pool.A[51]); A_arbace_classes_go_A_const_34 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[52]); A_arbace_classes_go_A_const_35 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[53]) }

func A_arbace_classes_go_A_clinit_p3() { A_arbace_classes_go_A_const_36 = lang.Keyword_Cast(A_arbace_classes_go_A_const_pool.A[54]); A_arbace_classes_go_A_const_37 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[55]); A_arbace_classes_go_A_const_38 = lang.Keyword_Cast(A_arbace_classes_go_A_const_pool.A[56]); A_arbace_classes_go_A_const_39 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[57]); A_arbace_classes_go_A_const_40 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[58]); A_arbace_classes_go_A_const_41 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[59]); A_arbace_classes_go_A_const_42 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[60]); A_arbace_classes_go_A_const_43 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[61]); A_arbace_classes_go_A_const_44 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[62]); A_arbace_classes_go_A_const_45 = lang.Keyword_Cast(A_arbace_classes_go_A_const_pool.A[63]); A_arbace_classes_go_A_const_46 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[64]); A_arbace_classes_go_A_const_47 = lang.Keyword_Cast(A_arbace_classes_go_A_const_pool.A[65]) }

func A_arbace_classes_go_A_clinit_p4() { A_arbace_classes_go_A_const_48 = lang.Keyword_Cast(A_arbace_classes_go_A_const_pool.A[66]); A_arbace_classes_go_A_const_49 = lang.Keyword_Cast(A_arbace_classes_go_A_const_pool.A[67]); A_arbace_classes_go_A_const_50 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[68]); A_arbace_classes_go_A_const_51 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[69]); A_arbace_classes_go_A_const_52 = lang.Keyword_Cast(A_arbace_classes_go_A_const_pool.A[70]); A_arbace_classes_go_A_const_53 = A_arbace_classes_go_A_const_pool.A[71] }

func A_arbace_classes_go_A_New() *A_arbace_classes_go_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_go_A) Ctor() {}

func (t *A_arbace_classes_go_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_A_class }

func (t *A_arbace_classes_go_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_go_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_A); return ok }

func A_arbace_classes_go_A_Cast(x any) *A_arbace_classes_go_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_A_class)) }; return v }



type A_arbace_classes_go_constructors_A struct{ j2g_header uint64 }

var A_arbace_classes_go_constructors_A_fn_class *jrt.Class



type A_arbace_classes_go_eval1797000004_A struct{ jrt.Object }

func A_arbace_classes_go_eval1797000004_A_New() *A_arbace_classes_go_eval1797000004_A { t := &A_arbace_classes_go_eval1797000004_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_go_eval1797000004_A) Ctor() {}

func (t *A_arbace_classes_go_eval1797000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_eval1797000004_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_eval1797000004_A_class }

func (t *A_arbace_classes_go_eval1797000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_eval1797000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_go_eval1797000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_eval1797000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_eval1797000004_A); return ok }

func A_arbace_classes_go_eval1797000004_A_Cast(x any) *A_arbace_classes_go_eval1797000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_eval1797000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_eval1797000004_A_class)) }; return v }



type A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A struct{ j2g_header uint64 }

var A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_fn_class *jrt.Class



type A_arbace_classes_go_eval1797000008_A struct{ jrt.Object }

func A_arbace_classes_go_eval1797000008_A_New() *A_arbace_classes_go_eval1797000008_A { t := &A_arbace_classes_go_eval1797000008_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_go_eval1797000008_A) Ctor() {}

func (t *A_arbace_classes_go_eval1797000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_eval1797000008_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_eval1797000008_A_class }

func (t *A_arbace_classes_go_eval1797000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_eval1797000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_go_eval1797000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_eval1797000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_eval1797000008_A); return ok }

func A_arbace_classes_go_eval1797000008_A_Cast(x any) *A_arbace_classes_go_eval1797000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_eval1797000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_eval1797000008_A_class)) }; return v }



type A_arbace_classes_go_eval1797000008_fn__1797000009_A struct{ j2g_header uint64 }

var A_arbace_classes_go_eval1797000008_fn__1797000009_A_fn_class *jrt.Class



type A_arbace_classes_go_fn__1797000023_A struct{ j2g_header uint64 }

var A_arbace_classes_go_fn__1797000023_A_fn_class *jrt.Class



type A_arbace_classes_go_fn__1797000025_A struct{ j2g_header uint64 }

var A_arbace_classes_go_fn__1797000025_A_fn_class *jrt.Class



type A_arbace_classes_go_generics_A struct{ j2g_header uint64 }

var A_arbace_classes_go_generics_A_fn_class *jrt.Class



type A_arbace_classes_go_generics_raw__1797000028_A struct{ j2g_header uint64; F_c any }

var A_arbace_classes_go_generics_raw__1797000028_A_fn_class *jrt.Class



type A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A struct{ j2g_header uint64 }

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_fn_class *jrt.Class



type A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A struct{ j2g_header uint64; F_iter__1797000029, F_s__1797000030 any }

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_fn_class *jrt.Class



type A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1797000032 any }

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_fn_class *jrt.Class



type A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A struct{ j2g_header uint64 }

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_fn_class *jrt.Class



type A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A struct{ j2g_header uint64 }

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_fn_class *jrt.Class



type A_arbace_classes_go_newExceptionReference_A struct{ j2g_header uint64 }

var A_arbace_classes_go_newExceptionReference_A_fn_class *jrt.Class



type A_arbace_classes_go_newFormalParameterReference_A struct{ j2g_header uint64 }

var A_arbace_classes_go_newFormalParameterReference_A_fn_class *jrt.Class



type A_arbace_classes_go_newSuperTypeReference_A struct{ j2g_header uint64 }

var A_arbace_classes_go_newSuperTypeReference_A_fn_class *jrt.Class



type A_arbace_classes_go_newTryCatchReference_A struct{ j2g_header uint64 }

var A_arbace_classes_go_newTryCatchReference_A_fn_class *jrt.Class



type A_arbace_classes_go_newTypeArgumentReference_A struct{ j2g_header uint64 }

var A_arbace_classes_go_newTypeArgumentReference_A_fn_class *jrt.Class



type A_arbace_classes_go_newTypeParameterBoundReference_A struct{ j2g_header uint64 }

var A_arbace_classes_go_newTypeParameterBoundReference_A_fn_class *jrt.Class



type A_arbace_classes_go_newTypeParameterReference_A struct{ j2g_header uint64 }

var A_arbace_classes_go_newTypeParameterReference_A_fn_class *jrt.Class



type A_arbace_classes_go_newTypeReference_A struct{ j2g_header uint64 }

var A_arbace_classes_go_newTypeReference_A_fn_class *jrt.Class



type A_arbace_classes_go_tref_A struct{ j2g_header uint64 }

var A_arbace_classes_go_tref_A_fn_class *jrt.Class



type A_arbace_classes_go_tref_reify__1797000012_A struct{ jrt.Object; F_v int64; F___meta lang.IPersistentMap }

func (t *A_arbace_classes_go_tref_reify__1797000012_A) Is_Map_Entry() {}

func (t *A_arbace_classes_go_tref_reify__1797000012_A) Is_IObj() {}

func (t *A_arbace_classes_go_tref_reify__1797000012_A) Is_IMeta() {}

func (t *A_arbace_classes_go_tref_reify__1797000012_A) SetValue_O__O(p0 any) any { panic(jrt.AbstractMethodError_New_String(jrt.Str("Receiver class arbace.classes.go$tref$reify__1797000012 does not define or inherit an implementation of the resolved method 'abstract java.lang.Object setValue(java.lang.Object)' of interface java.util.Map$Entry."))) }

func (t *A_arbace_classes_go_tref_reify__1797000012_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_tref_reify__1797000012_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_tref_reify__1797000012_A_class }

func (t *A_arbace_classes_go_tref_reify__1797000012_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_tref_reify__1797000012_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_go_tref_reify__1797000012_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_tref_reify__1797000012_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_tref_reify__1797000012_A); return ok }

func A_arbace_classes_go_tref_reify__1797000012_A_Cast(x any) *A_arbace_classes_go_tref_reify__1797000012_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_tref_reify__1797000012_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_tref_reify__1797000012_A_class)) }; return v }
