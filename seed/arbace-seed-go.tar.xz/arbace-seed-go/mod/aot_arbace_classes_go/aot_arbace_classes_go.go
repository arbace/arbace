//line aot_arbace_classes_go.ae:1
package aot_arbace_classes_go

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_New() *A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_classes_go_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_go_A_const_2); tmp3 = lang.IFn_Cast(A_arbace_classes_go_A_const_0.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_go_A_const_3, A_arbace_classes_go_A_const_4); return nil }(); lang.Var_PopThreadBindings__V(); if tmp4 != nil { panic(tmp4) }; return tmp3 }
//line :1:1
func A_arbace_classes_go_eval1797000008_fn__1797000009_A_New() *A_arbace_classes_go_eval1797000008_fn__1797000009_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_eval1797000008_fn__1797000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_go_eval1797000008_fn__1797000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_go_eval1797000008_fn__1797000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_classes_go_A_const_5.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_classes_go_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_go_A_const_9), A_arbace_classes_go_A_const_7.GetRawRoot__O(), A_arbace_classes_go_A_const_8) }










func A_arbace_classes_go_tref_A_New() *A_arbace_classes_go_tref_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_tref_A{}; t.Ctor(); return t }
//line :12:1
func (t *A_arbace_classes_go_tref_A) Ctor() {}
//line :12:1
func (t *A_arbace_classes_go_tref_A) Invoke_O_O__O(self, p_v__0 any) any { var v__0 int64 = lang.RT_LongCast_O__J(p_v__0); return A_arbace_classes_go_tref_reify__1797000012_A_New_IPersistentMap_J(nil, v__0) }
//line :12:1
func A_arbace_classes_go_tref_reify__1797000012_A_New_IPersistentMap_J(p0 lang.IPersistentMap, p1 int64) *A_arbace_classes_go_tref_reify__1797000012_A { t := &A_arbace_classes_go_tref_reify__1797000012_A{}; t.Ctor_IPersistentMap_J(p0, p1); return t }
//line :12:1
func (t *A_arbace_classes_go_tref_reify__1797000012_A) Ctor_IPersistentMap_J(meta__ lang.IPersistentMap, c__v int64) { t.F___meta = meta__; t.F_v = c__v }
//line :12:1
func (t *A_arbace_classes_go_tref_reify__1797000012_A) GetValue__O() any { return jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(t.F_v)).Ref() }
//line :12:1
func (t *A_arbace_classes_go_tref_reify__1797000012_A) GetKey__O() any { return nil }
//line :12:1
func (t *A_arbace_classes_go_tref_reify__1797000012_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :12:1
func (t *A_arbace_classes_go_tref_reify__1797000012_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_classes_go_tref_reify__1797000012_A_New_IPersistentMap_J(m, t.F_v) }
























func A_arbace_classes_go_newTypeReference_A_New() *A_arbace_classes_go_newTypeReference_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_newTypeReference_A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_classes_go_newTypeReference_A) Ctor() {}
//line :37:1
func (t *A_arbace_classes_go_newTypeReference_A) Invoke_O_O__O(self, sort__0 any) any { return lang.IFn_Cast(A_arbace_classes_go_A_const_10.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_ShiftLeft_J_J__J(lang.RT_LongCast_O__J(sort__0), 24)).Ref()) }
func A_arbace_classes_go_newTypeParameterReference_A_New() *A_arbace_classes_go_newTypeParameterReference_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_newTypeParameterReference_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_classes_go_newTypeParameterReference_A) Ctor() {}
//line :38:1
func (t *A_arbace_classes_go_newTypeParameterReference_A) Invoke_O_O_O__O(self, sort__0, i__1 any) any {
	return lang.IFn_Cast(A_arbace_classes_go_A_const_10.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Or_J_J__J(lang.Numbers_ShiftLeft_J_J__J(lang.RT_LongCast_O__J(sort__0), 24), lang.Numbers_ShiftLeft_J_J__J(lang.RT_LongCast_O__J(i__1), 16))).Ref()) }
func A_arbace_classes_go_newTypeParameterBoundReference_A_New() *A_arbace_classes_go_newTypeParameterBoundReference_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_newTypeParameterBoundReference_A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_classes_go_newTypeParameterBoundReference_A) Ctor() {}
//line :40:1
func (t *A_arbace_classes_go_newTypeParameterBoundReference_A) Invoke_O_O_O_O__O(self, sort__0, p__1, b__2 any) any {
	return lang.IFn_Cast(A_arbace_classes_go_A_const_10.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Or_J_J__J(lang.Numbers_Or_J_J__J(lang.Numbers_ShiftLeft_J_J__J(lang.RT_LongCast_O__J(sort__0), 24), lang.Numbers_ShiftLeft_J_J__J(lang.RT_LongCast_O__J(p__1), 16)), lang.Numbers_ShiftLeft_J_J__J(lang.RT_LongCast_O__J(b__2), 8))).Ref()) }
func A_arbace_classes_go_newSuperTypeReference_A_New() *A_arbace_classes_go_newSuperTypeReference_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_newSuperTypeReference_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_classes_go_newSuperTypeReference_A) Ctor() {}
//line :42:1
func (t *A_arbace_classes_go_newSuperTypeReference_A) Invoke_O_O__O(self, i__0 any) any {
	return lang.IFn_Cast(A_arbace_classes_go_A_const_10.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Or_J_J__J(lang.Numbers_ShiftLeft_O_J__J(A_arbace_classes_go_A_const_11.GetRawRoot__O(), 24), lang.Numbers_ShiftLeft_J_J__J(lang.Numbers_And_J_J__J(lang.RT_LongCast_O__J(i__0), 65535), 8))).Ref()) }
func A_arbace_classes_go_newFormalParameterReference_A_New() *A_arbace_classes_go_newFormalParameterReference_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_newFormalParameterReference_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_classes_go_newFormalParameterReference_A) Ctor() {}
//line :44:1
func (t *A_arbace_classes_go_newFormalParameterReference_A) Invoke_O_O__O(self, i__0 any) any {
	return lang.IFn_Cast(A_arbace_classes_go_A_const_10.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Or_J_J__J(lang.Numbers_ShiftLeft_O_J__J(A_arbace_classes_go_A_const_12.GetRawRoot__O(), 24), lang.Numbers_ShiftLeft_J_J__J(lang.RT_LongCast_O__J(i__0), 16))).Ref()) }
func A_arbace_classes_go_newExceptionReference_A_New() *A_arbace_classes_go_newExceptionReference_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_newExceptionReference_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_classes_go_newExceptionReference_A) Ctor() {}
//line :46:1
func (t *A_arbace_classes_go_newExceptionReference_A) Invoke_O_O__O(self, i__0 any) any { return lang.IFn_Cast(A_arbace_classes_go_A_const_10.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Or_J_J__J(lang.Numbers_ShiftLeft_O_J__J(A_arbace_classes_go_A_const_13.GetRawRoot__O(), 24), lang.Numbers_ShiftLeft_J_J__J(lang.RT_LongCast_O__J(i__0), 8))).Ref()) }
func A_arbace_classes_go_newTryCatchReference_A_New() *A_arbace_classes_go_newTryCatchReference_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_newTryCatchReference_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_classes_go_newTryCatchReference_A) Ctor() {}
//line :47:1
func (t *A_arbace_classes_go_newTryCatchReference_A) Invoke_O_O__O(self, i__0 any) any {
	return lang.IFn_Cast(A_arbace_classes_go_A_const_10.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Or_J_J__J(lang.Numbers_ShiftLeft_O_J__J(A_arbace_classes_go_A_const_14.GetRawRoot__O(), 24), lang.Numbers_ShiftLeft_J_J__J(lang.RT_LongCast_O__J(i__0), 8))).Ref()) }
func A_arbace_classes_go_newTypeArgumentReference_A_New() *A_arbace_classes_go_newTypeArgumentReference_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_newTypeArgumentReference_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_classes_go_newTypeArgumentReference_A) Ctor() {}
//line :49:1
func (t *A_arbace_classes_go_newTypeArgumentReference_A) Invoke_O_O_O__O(self, sort__0, i__1 any) any {
	return lang.IFn_Cast(A_arbace_classes_go_A_const_10.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Or_J_J__J(lang.Numbers_ShiftLeft_J_J__J(lang.RT_LongCast_O__J(sort__0), 24), lang.RT_LongCast_O__J(i__1))).Ref())
}








func A_arbace_classes_go_fn__1797000023_A_New() *A_arbace_classes_go_fn__1797000023_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_fn__1797000023_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_classes_go_fn__1797000023_A) Ctor() {}
//line :60:1
func (t *A_arbace_classes_go_fn__1797000023_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = jrt.Class_ForName_String__Class(Lit_1).Ref(); return nil }(); if tmp2 != nil { if true { var ___3 jrt.Throwable_I = tmp2; _ = ___3; tmp1 = nil } }; return tmp1 }


func A_arbace_classes_go_fn__1797000025_A_New() *A_arbace_classes_go_fn__1797000025_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_fn__1797000025_A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_classes_go_fn__1797000025_A) Ctor() {}
//line :63:1
func (t *A_arbace_classes_go_fn__1797000025_A) Invoke_O__O(self any) any { var temp__1927000408__auto____1 any = lang.RT_ResourceAsStream_ClassLoader_String__InputStream(nil, Lit_2); if
										jrt.A2g_Truth(temp__1927000408__auto____1) { var in__2 any = temp__1927000408__auto____1; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_go_A_const_17.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_go_A_const_18.GetRawRoot__O()); var tmp3 any = A_arbace_classes_go_A_const_19; var tmp4 *jrt.Boolean
											jrt.Boolean_Init(); tmp4 = jrt.Boolean_FALSE; tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(tmp3, tmp4.Ref()))
//line :64:1
		var tmp5 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

			tmp5 = lang.IFn_Cast(A_arbace_classes_go_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_go_A_const_20.GetRawRoot__O()).Invoke_O__O(in__2))
//line :64:1
			return nil }()
		lang.IFn_Cast(A_arbace_classes_go_A_const_16.GetRawRoot__O()).Invoke__O()
//line :64:1
		if tmp6 != nil { panic(tmp6) }; return tmp5 } else { lang.PersistentArrayMap_Init(); return lang.PersistentArrayMap_EMPTY.Ref() } }




func A_arbace_classes_go_generics_A_New() *A_arbace_classes_go_generics_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_generics_A{}; t.Ctor(); return t }
//line :69:1
func (t *A_arbace_classes_go_generics_A) Ctor() {}
//line :69:1
func (t *A_arbace_classes_go_generics_A) Invoke_O_O_O__O(self, n__0, c__1 any) any { var g__3 any = lang.RT_Get_O_O__O(lang.IFn_Cast(A_arbace_classes_go_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_go_A_const_50.GetRawRoot__O()), n__0); var raw__4 any; var tmp1 any = A_arbace_classes_go_generics_raw__1797000028_A_New_O(c__1); var tmp2 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_classes_go_generics_raw__1797000028_A_fn_class; if





	fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_3, false); A_arbace_classes_go_generics_raw__1797000028_A_fn_class = fncls__6d; tmp2 = fncls__6d } else { tmp2 = fncls__6 }; raw__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 any; var and__1927000168__auto____5 any = g__3; if








	jrt.A2g_Truth(and__1927000168__auto____5) { tmp3 = A_arbace_classes_go_A_const_44.Invoke_O__O(g__3) } else { tmp3 = and__1927000168__auto____5 }; if /*line :83:1*/ jrt.A2g_Truth(tmp3) { return g__3 } else { if jrt.A2g_Truth(g__3) {

		var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_classes_go_A_const_45.GetRawRoot__O()); var tmp5 any = A_arbace_classes_go_A_const_44; return tmp4.Invoke_O_O_O__O(g__3, tmp5, lang.IFn_Cast(raw__4).Invoke__O()) } else {
//line :83:1
			if A_arbace_classes_go_A_const_46 != nil { var tmp6 any = A_arbace_classes_go_A_const_47; var tmp7 *lang.PersistentVector; lang.PersistentVector_Init(); tmp7 = lang.PersistentVector_EMPTY; var tmp8 any = tmp7.Ref(); var tmp9 any = A_arbace_classes_go_A_const_48; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_classes_go_A_const_49.GetRawRoot__O()); var tmp11 any = A_arbace_classes_go_A_const_51.GetRawRoot__O(); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_classes_go_A_const_40.GetRawRoot__O()); var tmp13 any; var G__1797000044__5_ any = jrt.NN(jrt.Class_Cast(c__1)).GetSuperclass__Class().Ref()



				if lang.Util_Identical_O_O__Z(G__1797000044__5_, nil) { tmp13 = nil } else { tmp13 = lang.IFn_Cast(A_arbace_classes_go_A_const_37.GetRawRoot__O()).Invoke_O__O(G__1797000044__5_) }
//line :83:1
				var tmp14 any = tmp10.Invoke_O_O__O(tmp11, tmp12.Invoke_O_O__O(tmp13, lang.IFn_Cast(A_arbace_classes_go_A_const_34.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_go_A_const_37.GetRawRoot__O(), jrt.NN(jrt.Class_Cast(c__1)).GetInterfaces__Class1().Ref()))); var tmp15 any = A_arbace_classes_go_A_const_44; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp8, tmp9, tmp14, tmp15, lang.IFn_Cast(raw__4).Invoke__O())) } else { return nil } } } }
//line :75:1
func A_arbace_classes_go_generics_raw__1797000028_A_New_O(p0 any) *A_arbace_classes_go_generics_raw__1797000028_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_generics_raw__1797000028_A{}; t.Ctor_O(p0); return t }
//line :75:1
func (t *A_arbace_classes_go_generics_raw__1797000028_A) Ctor_O(c__c any) { t.F_c = c__c }
//line :75:1
func (t *A_arbace_classes_go_generics_raw__1797000028_A) Invoke_O__O(self any) any { var iter__1927001039__auto____1 any; var tmp1 any = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_New(); var tmp2 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_fn_class; if
											fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_4, false); A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_fn_class = fncls__5d; tmp2 = fncls__5d } else { tmp2 = fncls__5 }; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return lang.IFn_Cast(iter__1927001039__auto____1).Invoke_O__O(jrt.NN(jrt.Class_Cast(t.F_c)).GetDeclaredMethods__Method1().Ref()) }
//line :76:1
func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_New() *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A{}; t.Ctor(); return t }
//line :76:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A) Ctor() {}
//line :76:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A) Invoke_O_O__O(self, s__1797000030__1 any) any { var tmp1 any = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_New_O_O(self, s__1797000030__1); var tmp2 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_5, false); A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_fn_class = fncls__4d; tmp2 = fncls__4d } else { tmp2 = fncls__4 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :76:1
func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_New_O_O(p0, p1 any) *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A{}; t.Ctor_O_O(p0, p1); return t }
//line :76:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A) Ctor_O_O(c__iter__1797000029, c__s__1797000030 any) { t.F_iter__1797000029 = c__iter__1797000029; t.F_s__1797000030 = c__s__1797000030 }
//line :76:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A) Invoke_O__O(self any) any { { var s__1797000030__1 any; var t_ any = t.F_s__1797000030; t.F_s__1797000030 = nil; s__1797000030__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_classes_go_A_const_21.GetRawRoot__O()).Invoke_O__O(s__1797000030__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1797000030__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_go_A_const_22.GetRawRoot__O()).Invoke_O__O(s__1797000030__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_classes_go_A_const_23.GetRawRoot__O()).Invoke_O__O(s__1797000030__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1797000032__6 any = lang.IFn_Cast(A_arbace_classes_go_A_const_24.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1797000032__6); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_6, false); A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1797000029); return lang.IFn_Cast(A_arbace_classes_go_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_go_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1797000032__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_classes_go_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1797000030__3))) } else { return lang.IFn_Cast(A_arbace_classes_go_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_go_A_const_41.GetRawRoot__O()).Invoke_O__O(b__1797000032__6), nil) } } else { var m__4 any = lang.IFn_Cast(A_arbace_classes_go_A_const_39.GetRawRoot__O()).Invoke_O__O(s__1797000030__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_classes_go_A_const_40.GetRawRoot__O()); var tmp5 any = A_arbace_classes_go_A_const_26; var tmp6 any = jrt.NN(jrt.Method_Cast(m__4)).GetName__String().Ref(); var tmp7 any = A_arbace_classes_go_A_const_27; var tmp8 any = lang.IFn_Cast(A_arbace_classes_go_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_go_A_const_34.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_go_A_const_35.GetRawRoot__O(), jrt.NN(jrt.Method_Cast(m__4)).GetParameterTypes__Class1().Ref()), lang.IFn_Cast(A_arbace_classes_go_A_const_35.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Method_Cast(m__4)).GetReturnType__Class().Ref())); var tmp9 any = A_arbace_classes_go_A_const_29; var tmp10 any = jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.Method_Cast(m__4)).GetModifiers__I()).Ref(); var tmp11 any = A_arbace_classes_go_A_const_30; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_classes_go_A_const_31.GetRawRoot__O()); var tmp13 any = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_New(); var tmp14 *jrt.Class
																var fncls__3 /*line :76:1*/*jrt.Class = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_fn_class



	if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_7, false); A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_fn_class = fncls__3d; tmp14 = fncls__3d } else { tmp14 = fncls__3 }
//line :76:1
	var tmp15 any = tmp12.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil), jrt.NN(jrt.Method_Cast(m__4)).GetExceptionTypes__Class1().Ref()); var tmp16 any = A_arbace_classes_go_A_const_32; var tmp17 any = lang.IFn_Cast(A_arbace_classes_go_A_const_31.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_go_A_const_37.GetRawRoot__O(), jrt.NN(jrt.Method_Cast(m__4)).GetParameterTypes__Class1().Ref()); var tmp18 any = A_arbace_classes_go_A_const_33; var tmp19 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp19 = lang.PersistentArrayMap_EMPTY; var tmp20 lang.IFn = lang.IFn_Cast(t.F_iter__1797000029); return tmp4.Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp15, tmp16, tmp17, tmp18, tmp19.Ref())), tmp20.Invoke_O__O(lang.IFn_Cast(A_arbace_classes_go_A_const_43.GetRawRoot__O()).Invoke_O__O(s__1797000030__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :76:1
func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :76:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1797000032 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1797000032 = c__b__1797000032 }
//line :76:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A) Invoke_O__O(self any) any { { var i__1797000031__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1797000031__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1797000031__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_go_A_const_25.GetRawRoot__O()); var tmp3 any = t.F_b__1797000032; var tmp4 any = A_arbace_classes_go_A_const_26; var tmp5 any = jrt.NN(jrt.Method_Cast(m__2)).GetName__String().Ref(); var tmp6 any = A_arbace_classes_go_A_const_27; var tmp7 any = lang.IFn_Cast(A_arbace_classes_go_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_go_A_const_34.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_go_A_const_35.GetRawRoot__O(), jrt.NN(jrt.Method_Cast(m__2)).GetParameterTypes__Class1().Ref()), lang.IFn_Cast(A_arbace_classes_go_A_const_35.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Method_Cast(m__2)).GetReturnType__Class().Ref())); var tmp8 any = A_arbace_classes_go_A_const_29; var tmp9 any = jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.Method_Cast(m__2)).GetModifiers__I()).Ref(); var tmp10 any = A_arbace_classes_go_A_const_30; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_classes_go_A_const_31.GetRawRoot__O()); var tmp12 any = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_New(); var tmp13 *jrt.Class
																		var fncls__1 /*line :76:1*/*jrt.Class = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_fn_class



	if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_8, false); A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_fn_class = fncls__1d; tmp13 = fncls__1d } else { tmp13 = fncls__1 }
//line :76:1
	var tmp14 any = tmp11.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), jrt.NN(jrt.Method_Cast(m__2)).GetExceptionTypes__Class1().Ref()); var tmp15 any = A_arbace_classes_go_A_const_32; var tmp16 any = lang.IFn_Cast(A_arbace_classes_go_A_const_31.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_go_A_const_37.GetRawRoot__O(), jrt.NN(jrt.Method_Cast(m__2)).GetParameterTypes__Class1().Ref()); var tmp17 any = A_arbace_classes_go_A_const_33; var tmp18 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp18 = lang.PersistentArrayMap_EMPTY; tmp2.Invoke_O_O__O(tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp14, tmp15, tmp16, tmp17, tmp18.Ref()))); i__1797000031__1 = lang.Numbers_Unchecked_inc_J__J(i__1797000031__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }



func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_New() *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A) Ctor() {}
//line :80:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A) Invoke_O_O__O(self, p1__1797000027_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_classes_go_A_const_36.GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(jrt.Class_Cast(p1__1797000027_SHARP___1)).GetName__String().Ref(), Lit_9, Lit_10) }
//line :80:1
func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_New() *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A) Ctor() {}
//line :80:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A) Invoke_O_O__O(self, p1__1797000027_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_classes_go_A_const_36.GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(jrt.Class_Cast(p1__1797000027_SHARP___1)).GetName__String().Ref(), Lit_9, Lit_10) }










func A_arbace_classes_go_constructors_A_New() *A_arbace_classes_go_constructors_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_constructors_A{}; t.Ctor(); return t }
//line :91:1
func (t *A_arbace_classes_go_constructors_A) Ctor() {}
//line :91:1
func (t *A_arbace_classes_go_constructors_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_classes_go_A_const_52; var or__1927000174__auto____2 any = tmp1.Invoke_O__O(lang.RT_Get_O_O__O(lang.IFn_Cast(A_arbace_classes_go_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_go_A_const_50.GetRawRoot__O()), n__0)); if



	jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else {
		return lang.RT_Get_O_O__O(A_arbace_classes_go_A_const_53, n__0) } }


















































type A_arbace_classes_go_A struct{ jrt.Object }

var A_arbace_classes_go_A_const_pool *jrt.RefArray

var A_arbace_classes_go_A_const_0 *lang.Var

var A_arbace_classes_go_A_const_1 *lang.Var

var A_arbace_classes_go_A_const_2 any

var A_arbace_classes_go_A_const_3 any

var A_arbace_classes_go_A_const_4 any

var A_arbace_classes_go_A_const_5 *lang.Var

var A_arbace_classes_go_A_const_6 *lang.Var

var A_arbace_classes_go_A_const_7 *lang.Var

var A_arbace_classes_go_A_const_8 any

var A_arbace_classes_go_A_const_9 *lang.Var

var A_arbace_classes_go_A_const_10 *lang.Var

var A_arbace_classes_go_A_const_11 *lang.Var

var A_arbace_classes_go_A_const_12 *lang.Var

var A_arbace_classes_go_A_const_13 *lang.Var

var A_arbace_classes_go_A_const_14 *lang.Var

var A_arbace_classes_go_A_const_15 *lang.Var

var A_arbace_classes_go_A_const_16 *lang.Var

var A_arbace_classes_go_A_const_17 *lang.Var

var A_arbace_classes_go_A_const_18 *lang.Var

var A_arbace_classes_go_A_const_19 *lang.Var

var A_arbace_classes_go_A_const_20 *lang.Var

var A_arbace_classes_go_A_const_21 *lang.Var

var A_arbace_classes_go_A_const_22 *lang.Var

var A_arbace_classes_go_A_const_23 *lang.Var

var A_arbace_classes_go_A_const_24 *lang.Var

var A_arbace_classes_go_A_const_25 *lang.Var

var A_arbace_classes_go_A_const_26 *lang.Keyword

var A_arbace_classes_go_A_const_27 *lang.Keyword

var A_arbace_classes_go_A_const_28 *lang.Var

var A_arbace_classes_go_A_const_29 *lang.Keyword

var A_arbace_classes_go_A_const_30 *lang.Keyword

var A_arbace_classes_go_A_const_31 *lang.Var

var A_arbace_classes_go_A_const_32 *lang.Keyword

var A_arbace_classes_go_A_const_33 *lang.Keyword

var A_arbace_classes_go_A_const_34 *lang.Var

var A_arbace_classes_go_A_const_35 *lang.Var

var A_arbace_classes_go_A_const_36 *lang.Var

var A_arbace_classes_go_A_const_37 *lang.Var

var A_arbace_classes_go_A_const_38 *lang.Var

var A_arbace_classes_go_A_const_39 *lang.Var

var A_arbace_classes_go_A_const_40 *lang.Var

var A_arbace_classes_go_A_const_41 *lang.Var

var A_arbace_classes_go_A_const_42 *lang.Var

var A_arbace_classes_go_A_const_43 *lang.Var

var A_arbace_classes_go_A_const_44 *lang.Keyword

var A_arbace_classes_go_A_const_45 *lang.Var

var A_arbace_classes_go_A_const_46 *lang.Keyword

var A_arbace_classes_go_A_const_47 *lang.Keyword

var A_arbace_classes_go_A_const_48 *lang.Keyword

var A_arbace_classes_go_A_const_49 *lang.Var

var A_arbace_classes_go_A_const_50 *lang.Var

var A_arbace_classes_go_A_const_51 *lang.Var

var A_arbace_classes_go_A_const_52 *lang.Keyword

var A_arbace_classes_go_A_const_53 any

var A_arbace_classes_go_A_init jrt.ClassInit

func A_arbace_classes_go_A_Init() { if !A_arbace_classes_go_A_init.Done() { A_arbace_classes_go_A_init.Run(A_arbace_classes_go_A_clinit) } }

func A_arbace_classes_go_A_clinit() { A_arbace_classes_go_A_clinit_p0(); A_arbace_classes_go_A_clinit_p1(); A_arbace_classes_go_A_clinit_p2(); A_arbace_classes_go_A_clinit_p3(); A_arbace_classes_go_A_clinit_p4() }

func A_arbace_classes_go_A_clinit_p0() { A_arbace_classes_go_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 72); A_arbace_classes_go_A_const_0 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[18]); A_arbace_classes_go_A_const_1 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[19]); A_arbace_classes_go_A_const_2 = A_arbace_classes_go_A_const_pool.A[20]; A_arbace_classes_go_A_const_3 = A_arbace_classes_go_A_const_pool.A[21]; A_arbace_classes_go_A_const_4 = A_arbace_classes_go_A_const_pool.A[22]; A_arbace_classes_go_A_const_5 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[23]); A_arbace_classes_go_A_const_6 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[24]); A_arbace_classes_go_A_const_7 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[25]); A_arbace_classes_go_A_const_8 = A_arbace_classes_go_A_const_pool.A[26]; A_arbace_classes_go_A_const_9 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[27]); A_arbace_classes_go_A_const_10 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[28]); A_arbace_classes_go_A_const_11 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[29]) }

func A_arbace_classes_go_A_clinit_p1() { A_arbace_classes_go_A_const_12 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[30]); A_arbace_classes_go_A_const_13 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[31]); A_arbace_classes_go_A_const_14 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[32]); A_arbace_classes_go_A_const_15 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[33]); A_arbace_classes_go_A_const_16 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[34]); A_arbace_classes_go_A_const_17 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[35]); A_arbace_classes_go_A_const_18 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[36]); A_arbace_classes_go_A_const_19 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[37]); A_arbace_classes_go_A_const_20 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[38]); A_arbace_classes_go_A_const_21 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[39]); A_arbace_classes_go_A_const_22 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[40]); A_arbace_classes_go_A_const_23 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[41]) }

func A_arbace_classes_go_A_clinit_p2() { A_arbace_classes_go_A_const_24 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[42]); A_arbace_classes_go_A_const_25 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[43]); A_arbace_classes_go_A_const_26 = lang.Keyword_Cast(A_arbace_classes_go_A_const_pool.A[44]); A_arbace_classes_go_A_const_27 = lang.Keyword_Cast(A_arbace_classes_go_A_const_pool.A[45]); A_arbace_classes_go_A_const_28 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[46]); A_arbace_classes_go_A_const_29 = lang.Keyword_Cast(A_arbace_classes_go_A_const_pool.A[47]); A_arbace_classes_go_A_const_30 = lang.Keyword_Cast(A_arbace_classes_go_A_const_pool.A[48]); A_arbace_classes_go_A_const_31 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[49]); A_arbace_classes_go_A_const_32 = lang.Keyword_Cast(A_arbace_classes_go_A_const_pool.A[50]); A_arbace_classes_go_A_const_33 = lang.Keyword_Cast(A_arbace_classes_go_A_const_pool.A[51]); A_arbace_classes_go_A_const_34 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[52]); A_arbace_classes_go_A_const_35 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[53]) }

func A_arbace_classes_go_A_clinit_p3() { A_arbace_classes_go_A_const_36 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[54]); A_arbace_classes_go_A_const_37 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[55]); A_arbace_classes_go_A_const_38 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[56]); A_arbace_classes_go_A_const_39 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[57]); A_arbace_classes_go_A_const_40 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[58]); A_arbace_classes_go_A_const_41 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[59]); A_arbace_classes_go_A_const_42 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[60]); A_arbace_classes_go_A_const_43 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[61]); A_arbace_classes_go_A_const_44 = lang.Keyword_Cast(A_arbace_classes_go_A_const_pool.A[62]); A_arbace_classes_go_A_const_45 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[63]); A_arbace_classes_go_A_const_46 = lang.Keyword_Cast(A_arbace_classes_go_A_const_pool.A[64]); A_arbace_classes_go_A_const_47 = lang.Keyword_Cast(A_arbace_classes_go_A_const_pool.A[65]) }

func A_arbace_classes_go_A_clinit_p4() { A_arbace_classes_go_A_const_48 = lang.Keyword_Cast(A_arbace_classes_go_A_const_pool.A[66]); A_arbace_classes_go_A_const_49 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[67]); A_arbace_classes_go_A_const_50 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[68]); A_arbace_classes_go_A_const_51 = lang.Var_Cast(A_arbace_classes_go_A_const_pool.A[69]); A_arbace_classes_go_A_const_52 = lang.Keyword_Cast(A_arbace_classes_go_A_const_pool.A[70]); A_arbace_classes_go_A_const_53 = A_arbace_classes_go_A_const_pool.A[71] }

func A_arbace_classes_go_A_New() *A_arbace_classes_go_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_go_A) Ctor() {}

func (t *A_arbace_classes_go_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_A_class }

func (t *A_arbace_classes_go_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_go_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_A); return ok }

func A_arbace_classes_go_A_Cast(x any) *A_arbace_classes_go_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_A_class)) }; return v }



type A_arbace_classes_go_constructors_A struct{ a2g_header uint64 }

var A_arbace_classes_go_constructors_A_fn_class *jrt.Class



type A_arbace_classes_go_eval1797000004_A struct{ jrt.Object }

func A_arbace_classes_go_eval1797000004_A_New() *A_arbace_classes_go_eval1797000004_A { t := &A_arbace_classes_go_eval1797000004_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_go_eval1797000004_A) Ctor() {}

func (t *A_arbace_classes_go_eval1797000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_eval1797000004_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_eval1797000004_A_class }

func (t *A_arbace_classes_go_eval1797000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_eval1797000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_go_eval1797000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_eval1797000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_eval1797000004_A); return ok }

func A_arbace_classes_go_eval1797000004_A_Cast(x any) *A_arbace_classes_go_eval1797000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_eval1797000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_eval1797000004_A_class)) }; return v }



type A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A struct{ a2g_header uint64 }

var A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_fn_class *jrt.Class



type A_arbace_classes_go_eval1797000008_A struct{ jrt.Object }

func A_arbace_classes_go_eval1797000008_A_New() *A_arbace_classes_go_eval1797000008_A { t := &A_arbace_classes_go_eval1797000008_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_go_eval1797000008_A) Ctor() {}

func (t *A_arbace_classes_go_eval1797000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_eval1797000008_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_eval1797000008_A_class }

func (t *A_arbace_classes_go_eval1797000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_eval1797000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_go_eval1797000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_eval1797000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_eval1797000008_A); return ok }

func A_arbace_classes_go_eval1797000008_A_Cast(x any) *A_arbace_classes_go_eval1797000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_eval1797000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_eval1797000008_A_class)) }; return v }



type A_arbace_classes_go_eval1797000008_fn__1797000009_A struct{ a2g_header uint64 }

var A_arbace_classes_go_eval1797000008_fn__1797000009_A_fn_class *jrt.Class



type A_arbace_classes_go_fn__1797000023_A struct{ a2g_header uint64 }

var A_arbace_classes_go_fn__1797000023_A_fn_class *jrt.Class



type A_arbace_classes_go_fn__1797000025_A struct{ a2g_header uint64 }

var A_arbace_classes_go_fn__1797000025_A_fn_class *jrt.Class



type A_arbace_classes_go_generics_A struct{ a2g_header uint64 }

var A_arbace_classes_go_generics_A_fn_class *jrt.Class



type A_arbace_classes_go_generics_raw__1797000028_A struct{ a2g_header uint64; F_c any }

var A_arbace_classes_go_generics_raw__1797000028_A_fn_class *jrt.Class



type A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A struct{ a2g_header uint64 }

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_fn_class *jrt.Class



type A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A struct{ a2g_header uint64; F_iter__1797000029, F_s__1797000030 any }

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_fn_class *jrt.Class



type A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A struct{ a2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1797000032 any }

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_fn_class *jrt.Class



type A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A struct{ a2g_header uint64 }

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_fn_class *jrt.Class



type A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A struct{ a2g_header uint64 }

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_fn_class *jrt.Class



type A_arbace_classes_go_newExceptionReference_A struct{ a2g_header uint64 }

var A_arbace_classes_go_newExceptionReference_A_fn_class *jrt.Class



type A_arbace_classes_go_newFormalParameterReference_A struct{ a2g_header uint64 }

var A_arbace_classes_go_newFormalParameterReference_A_fn_class *jrt.Class



type A_arbace_classes_go_newSuperTypeReference_A struct{ a2g_header uint64 }

var A_arbace_classes_go_newSuperTypeReference_A_fn_class *jrt.Class



type A_arbace_classes_go_newTryCatchReference_A struct{ a2g_header uint64 }

var A_arbace_classes_go_newTryCatchReference_A_fn_class *jrt.Class



type A_arbace_classes_go_newTypeArgumentReference_A struct{ a2g_header uint64 }

var A_arbace_classes_go_newTypeArgumentReference_A_fn_class *jrt.Class



type A_arbace_classes_go_newTypeParameterBoundReference_A struct{ a2g_header uint64 }

var A_arbace_classes_go_newTypeParameterBoundReference_A_fn_class *jrt.Class



type A_arbace_classes_go_newTypeParameterReference_A struct{ a2g_header uint64 }

var A_arbace_classes_go_newTypeParameterReference_A_fn_class *jrt.Class



type A_arbace_classes_go_newTypeReference_A struct{ a2g_header uint64 }

var A_arbace_classes_go_newTypeReference_A_fn_class *jrt.Class



type A_arbace_classes_go_tref_A struct{ a2g_header uint64 }

var A_arbace_classes_go_tref_A_fn_class *jrt.Class



type A_arbace_classes_go_tref_reify__1797000012_A struct{ jrt.Object; F_v int64; F___meta lang.IPersistentMap }

func (t *A_arbace_classes_go_tref_reify__1797000012_A) Is_Map_Entry() {}

func (t *A_arbace_classes_go_tref_reify__1797000012_A) Is_IObj() {}

func (t *A_arbace_classes_go_tref_reify__1797000012_A) Is_IMeta() {}

func (t *A_arbace_classes_go_tref_reify__1797000012_A) SetValue_O__O(p0 any) any { panic(jrt.A2g_NotTranslated("abstract arbace.classes.go$tref$reify__1797000012.setValue(Ljava/lang/Object;)Ljava/lang/Object;")) }

func (t *A_arbace_classes_go_tref_reify__1797000012_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_tref_reify__1797000012_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_tref_reify__1797000012_A_class }

func (t *A_arbace_classes_go_tref_reify__1797000012_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_tref_reify__1797000012_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_go_tref_reify__1797000012_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_tref_reify__1797000012_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_tref_reify__1797000012_A); return ok }

func A_arbace_classes_go_tref_reify__1797000012_A_Cast(x any) *A_arbace_classes_go_tref_reify__1797000012_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_tref_reify__1797000012_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_tref_reify__1797000012_A_class)) }; return v }
