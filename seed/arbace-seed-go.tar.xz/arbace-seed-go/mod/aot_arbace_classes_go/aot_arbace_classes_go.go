//line aot_arbace_classes_go.ae:1
package aot_arbace_classes_go

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_New() *A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A { A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_Init(); t := &A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_classes_go_A_Init(); tmp4 = A_arbace_classes_go_A_const_1; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_classes_go_A_Init(); tmp6 = A_arbace_classes_go_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_classes_go_A_Init(); tmp7 = A_arbace_classes_go_A_const_0; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_classes_go_A_Init(); tmp9 = A_arbace_classes_go_A_const_3; var tmp10 any = tmp9; var tmp11 any; A_arbace_classes_go_A_Init(); tmp11 = A_arbace_classes_go_A_const_4; tmp3 = tmp8.Invoke_O_O__O(tmp10, tmp11) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp12 != nil { panic(tmp12) }; return tmp3 }
//line :1:1
func A_arbace_classes_go_eval1797000008_fn__1797000009_A_New() *A_arbace_classes_go_eval1797000008_fn__1797000009_A { A_arbace_classes_go_eval1797000008_fn__1797000009_A_Init(); t := &A_arbace_classes_go_eval1797000008_fn__1797000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_go_eval1797000008_fn__1797000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_go_eval1797000008_fn__1797000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_classes_go_A_Init(); tmp1 = A_arbace_classes_go_A_const_5; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_classes_go_A_Init(); tmp3 = A_arbace_classes_go_A_const_6; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_classes_go_A_Init(); tmp5 = A_arbace_classes_go_A_const_9; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_classes_go_A_Init(); tmp7 = A_arbace_classes_go_A_const_7; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_classes_go_A_Init(); tmp9 = A_arbace_classes_go_A_const_8; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }










func A_arbace_classes_go_tref_A_New() *A_arbace_classes_go_tref_A { A_arbace_classes_go_tref_A_Init(); t := &A_arbace_classes_go_tref_A{}; t.Ctor(); return t }
//line :12:1
func (t *A_arbace_classes_go_tref_A) Ctor() {}
//line :12:1
func (t *A_arbace_classes_go_tref_A) Invoke_O_O__O(self, p_v__0 any) any { var v__0 int64 = lang.RT_LongCast_O__J(p_v__0); return A_arbace_classes_go_tref_reify__1797000012_A_New_IPersistentMap_J(nil, v__0) }
//line :12:1
func A_arbace_classes_go_tref_reify__1797000012_A_New_IPersistentMap_J(p0 lang.IPersistentMap, p1 int64) *A_arbace_classes_go_tref_reify__1797000012_A { t := &A_arbace_classes_go_tref_reify__1797000012_A{}; t.Ctor_IPersistentMap_J(p0, p1); return t }
//line :12:1
func (t *A_arbace_classes_go_tref_reify__1797000012_A) Ctor_IPersistentMap_J(meta__ lang.IPersistentMap, c__v int64) { t.F___meta = meta__; t.F_v = c__v }
//line :12:1
func (t *A_arbace_classes_go_tref_reify__1797000012_A) GetValue__O() any { return jrt.Integer_ValueOf_I__Integer(lang.RT_IntCast_J__I(t.F_v)).Ref() }
//line :12:1
func (t *A_arbace_classes_go_tref_reify__1797000012_A) GetKey__O() any { return nil }
//line :12:1
func (t *A_arbace_classes_go_tref_reify__1797000012_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :12:1
func (t *A_arbace_classes_go_tref_reify__1797000012_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_classes_go_tref_reify__1797000012_A_New_IPersistentMap_J(m, t.F_v) }
























func A_arbace_classes_go_newTypeReference_A_New() *A_arbace_classes_go_newTypeReference_A { A_arbace_classes_go_newTypeReference_A_Init(); t := &A_arbace_classes_go_newTypeReference_A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_classes_go_newTypeReference_A) Ctor() {}
//line :37:1
func (t *A_arbace_classes_go_newTypeReference_A) Invoke_O_O__O(self, sort__0 any) any { var tmp1 *lang.Var; A_arbace_classes_go_A_Init(); tmp1 = A_arbace_classes_go_A_const_10; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_ShiftLeft_J_J__J(lang.RT_LongCast_O__J(sort__0), 24)).Ref()) }
func A_arbace_classes_go_newTypeParameterReference_A_New() *A_arbace_classes_go_newTypeParameterReference_A { A_arbace_classes_go_newTypeParameterReference_A_Init(); t := &A_arbace_classes_go_newTypeParameterReference_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_classes_go_newTypeParameterReference_A) Ctor() {}
//line :38:1
func (t *A_arbace_classes_go_newTypeParameterReference_A) Invoke_O_O_O__O(self, sort__0, i__1 any) any {
	var tmp1 *lang.Var; A_arbace_classes_go_A_Init(); tmp1 = A_arbace_classes_go_A_const_10; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Or_J_J__J(lang.Numbers_ShiftLeft_J_J__J(lang.RT_LongCast_O__J(sort__0), 24), lang.Numbers_ShiftLeft_J_J__J(lang.RT_LongCast_O__J(i__1), 16))).Ref()) }
func A_arbace_classes_go_newTypeParameterBoundReference_A_New() *A_arbace_classes_go_newTypeParameterBoundReference_A { A_arbace_classes_go_newTypeParameterBoundReference_A_Init(); t := &A_arbace_classes_go_newTypeParameterBoundReference_A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_classes_go_newTypeParameterBoundReference_A) Ctor() {}
//line :40:1
func (t *A_arbace_classes_go_newTypeParameterBoundReference_A) Invoke_O_O_O_O__O(self, sort__0, p__1, b__2 any) any {
	var tmp1 *lang.Var; A_arbace_classes_go_A_Init(); tmp1 = A_arbace_classes_go_A_const_10; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Or_J_J__J(lang.Numbers_Or_J_J__J(lang.Numbers_ShiftLeft_J_J__J(lang.RT_LongCast_O__J(sort__0), 24), lang.Numbers_ShiftLeft_J_J__J(lang.RT_LongCast_O__J(p__1), 16)), lang.Numbers_ShiftLeft_J_J__J(lang.RT_LongCast_O__J(b__2), 8))).Ref()) }
func A_arbace_classes_go_newSuperTypeReference_A_New() *A_arbace_classes_go_newSuperTypeReference_A { A_arbace_classes_go_newSuperTypeReference_A_Init(); t := &A_arbace_classes_go_newSuperTypeReference_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_classes_go_newSuperTypeReference_A) Ctor() {}
//line :42:1
func (t *A_arbace_classes_go_newSuperTypeReference_A) Invoke_O_O__O(self, i__0 any) any {
	var tmp1 *lang.Var; A_arbace_classes_go_A_Init(); tmp1 = A_arbace_classes_go_A_const_10; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_classes_go_A_Init(); tmp3 = A_arbace_classes_go_A_const_11; return tmp2.Invoke_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Or_J_J__J(lang.Numbers_ShiftLeft_O_J__J(jrt.NN(tmp3).GetRawRoot__O(), 24), lang.Numbers_ShiftLeft_J_J__J(lang.Numbers_And_J_J__J(lang.RT_LongCast_O__J(i__0), 65535), 8))).Ref()) }
func A_arbace_classes_go_newFormalParameterReference_A_New() *A_arbace_classes_go_newFormalParameterReference_A { A_arbace_classes_go_newFormalParameterReference_A_Init(); t := &A_arbace_classes_go_newFormalParameterReference_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_classes_go_newFormalParameterReference_A) Ctor() {}
//line :44:1
func (t *A_arbace_classes_go_newFormalParameterReference_A) Invoke_O_O__O(self, i__0 any) any {
	var tmp1 *lang.Var; A_arbace_classes_go_A_Init(); tmp1 = A_arbace_classes_go_A_const_10; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_classes_go_A_Init(); tmp3 = A_arbace_classes_go_A_const_12; return tmp2.Invoke_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Or_J_J__J(lang.Numbers_ShiftLeft_O_J__J(jrt.NN(tmp3).GetRawRoot__O(), 24), lang.Numbers_ShiftLeft_J_J__J(lang.RT_LongCast_O__J(i__0), 16))).Ref()) }
func A_arbace_classes_go_newExceptionReference_A_New() *A_arbace_classes_go_newExceptionReference_A { A_arbace_classes_go_newExceptionReference_A_Init(); t := &A_arbace_classes_go_newExceptionReference_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_classes_go_newExceptionReference_A) Ctor() {}
//line :46:1
func (t *A_arbace_classes_go_newExceptionReference_A) Invoke_O_O__O(self, i__0 any) any { var tmp1 *lang.Var; A_arbace_classes_go_A_Init(); tmp1 = A_arbace_classes_go_A_const_10; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_classes_go_A_Init(); tmp3 = A_arbace_classes_go_A_const_13; return tmp2.Invoke_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Or_J_J__J(lang.Numbers_ShiftLeft_O_J__J(jrt.NN(tmp3).GetRawRoot__O(), 24), lang.Numbers_ShiftLeft_J_J__J(lang.RT_LongCast_O__J(i__0), 8))).Ref()) }
func A_arbace_classes_go_newTryCatchReference_A_New() *A_arbace_classes_go_newTryCatchReference_A { A_arbace_classes_go_newTryCatchReference_A_Init(); t := &A_arbace_classes_go_newTryCatchReference_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_classes_go_newTryCatchReference_A) Ctor() {}
//line :47:1
func (t *A_arbace_classes_go_newTryCatchReference_A) Invoke_O_O__O(self, i__0 any) any {
	var tmp1 *lang.Var; A_arbace_classes_go_A_Init(); tmp1 = A_arbace_classes_go_A_const_10; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_classes_go_A_Init(); tmp3 = A_arbace_classes_go_A_const_14; return tmp2.Invoke_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Or_J_J__J(lang.Numbers_ShiftLeft_O_J__J(jrt.NN(tmp3).GetRawRoot__O(), 24), lang.Numbers_ShiftLeft_J_J__J(lang.RT_LongCast_O__J(i__0), 8))).Ref()) }
func A_arbace_classes_go_newTypeArgumentReference_A_New() *A_arbace_classes_go_newTypeArgumentReference_A { A_arbace_classes_go_newTypeArgumentReference_A_Init(); t := &A_arbace_classes_go_newTypeArgumentReference_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_classes_go_newTypeArgumentReference_A) Ctor() {}
//line :49:1
func (t *A_arbace_classes_go_newTypeArgumentReference_A) Invoke_O_O_O__O(self, sort__0, i__1 any) any {
	var tmp1 *lang.Var; A_arbace_classes_go_A_Init(); tmp1 = A_arbace_classes_go_A_const_10; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long(lang.Numbers_Or_J_J__J(lang.Numbers_ShiftLeft_J_J__J(lang.RT_LongCast_O__J(sort__0), 24), lang.RT_LongCast_O__J(i__1))).Ref())
}








func A_arbace_classes_go_fn__1797000023_A_New() *A_arbace_classes_go_fn__1797000023_A { A_arbace_classes_go_fn__1797000023_A_Init(); t := &A_arbace_classes_go_fn__1797000023_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_classes_go_fn__1797000023_A) Ctor() {}
//line :60:1
func (t *A_arbace_classes_go_fn__1797000023_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = jrt.Class_ForName_String__Class(Lit_69).Ref(); return nil }(); if tmp2 != nil { if true { var ___3 jrt.Throwable_I = tmp2; _ = ___3; tmp1 = nil } }; return tmp1 }


func A_arbace_classes_go_fn__1797000025_A_New() *A_arbace_classes_go_fn__1797000025_A { A_arbace_classes_go_fn__1797000025_A_Init(); t := &A_arbace_classes_go_fn__1797000025_A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_classes_go_fn__1797000025_A) Ctor() {}
//line :63:1
func (t *A_arbace_classes_go_fn__1797000025_A) Invoke_O__O(self any) any { var temp__1927000408__auto____1 any = lang.RT_ResourceAsStream_ClassLoader_String__InputStream(nil, Lit_71); if
										jrt.A2g_Truth(temp__1927000408__auto____1) { var in__2 any = temp__1927000408__auto____1; var tmp1 *lang.Var
											A_arbace_classes_go_A_Init(); tmp1 = A_arbace_classes_go_A_const_17; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_classes_go_A_Init(); tmp3 = A_arbace_classes_go_A_const_18; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_classes_go_A_Init(); tmp5 = A_arbace_classes_go_A_const_19; var tmp6 any = tmp5.Ref(); var tmp7 *jrt.Boolean; jrt.Boolean_Init(); tmp7 = jrt.Boolean_FALSE; tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6, tmp7.Ref()))
//line :64:1
		var tmp8 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

			{ var tmp9 *lang.Var; A_arbace_classes_go_A_Init(); tmp9 = A_arbace_classes_go_A_const_15; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_classes_go_A_Init(); tmp11 = A_arbace_classes_go_A_const_20; tmp8 = tmp10.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(in__2)) }
//line :64:1
			return nil }(); var tmp13 *lang.Var
		A_arbace_classes_go_A_Init(); tmp13 = A_arbace_classes_go_A_const_16; lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke__O()
//line :64:1
		if tmp12 != nil { panic(tmp12) }; return tmp8 } else { lang.PersistentArrayMap_Init(); return lang.PersistentArrayMap_EMPTY.Ref() } }




func A_arbace_classes_go_generics_A_New() *A_arbace_classes_go_generics_A { A_arbace_classes_go_generics_A_Init(); t := &A_arbace_classes_go_generics_A{}; t.Ctor(); return t }
//line :69:1
func (t *A_arbace_classes_go_generics_A) Ctor() {}
//line :69:1
func (t *A_arbace_classes_go_generics_A) Invoke_O_O_O__O(self, n__0, c__1 any) any { var g__3 any; var tmp1 *lang.Var;




	A_arbace_classes_go_A_Init(); tmp1 = A_arbace_classes_go_A_const_6; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_classes_go_A_Init(); tmp3 = A_arbace_classes_go_A_const_50; g__3 = lang.RT_Get_O_O__O(tmp2.Invoke_O__O(jrt.NN(tmp3).GetRawRoot__O()), n__0); var raw__4 any; var tmp4 any = /*line :69:1*/A_arbace_classes_go_generics_raw__1797000028_A_New_O(c__1); var tmp5 *jrt.Class;





	A_arbace_classes_go_generics_raw__1797000028_A_Init(); tmp5 = A_arbace_classes_go_generics_raw__1797000028_A_fn_class; raw__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp6 any; var and__1927000168__auto____5 any = g__3; if








	jrt.A2g_Truth(and__1927000168__auto____5) { var tmp7 *lang.Keyword; A_arbace_classes_go_A_Init(); tmp7 = A_arbace_classes_go_A_const_44; tmp6 = jrt.NN(tmp7).Invoke_O__O(g__3) } else { tmp6 = and__1927000168__auto____5 }; if /*line :83:1*/ jrt.A2g_Truth(tmp6) { return g__3 } else { if jrt.A2g_Truth(g__3) {

		var tmp8 *lang.Var; A_arbace_classes_go_A_Init(); tmp8 = A_arbace_classes_go_A_const_45; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Keyword; A_arbace_classes_go_A_Init(); tmp10 = A_arbace_classes_go_A_const_44; var tmp11 any = tmp10.Ref(); return tmp9.Invoke_O_O_O__O(g__3, tmp11, lang.IFn_Cast(raw__4).Invoke__O()) } else {
//line :83:1
			var tmp12 *lang.Keyword; A_arbace_classes_go_A_Init(); tmp12 = A_arbace_classes_go_A_const_46; if tmp12 != nil { var tmp13 *lang.Keyword; A_arbace_classes_go_A_Init(); tmp13 = A_arbace_classes_go_A_const_47; var tmp14 any = tmp13.Ref(); var tmp15 *lang.PersistentVector; lang.PersistentVector_Init(); tmp15 = lang.PersistentVector_EMPTY; var tmp16 any = tmp15.Ref(); var tmp17 *lang.Keyword; A_arbace_classes_go_A_Init(); tmp17 = A_arbace_classes_go_A_const_48; var tmp18 any = tmp17.Ref(); var tmp19 *lang.Var; A_arbace_classes_go_A_Init(); tmp19 = A_arbace_classes_go_A_const_49; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_classes_go_A_Init(); tmp21 = A_arbace_classes_go_A_const_51; var tmp22 any = jrt.NN(tmp21).GetRawRoot__O(); var tmp23 *lang.Var; A_arbace_classes_go_A_Init(); tmp23 = A_arbace_classes_go_A_const_40; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 any; var G__1797000044__5_ any = jrt.NN(jrt.Class_Cast(c__1)).GetSuperclass__Class().Ref()



				if lang.Util_Identical_O_O__Z(G__1797000044__5_, nil) { tmp25 = nil } else { var tmp26 *lang.Var; A_arbace_classes_go_A_Init(); tmp26 = A_arbace_classes_go_A_const_37; tmp25 = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(G__1797000044__5_) }
//line :83:1
				var tmp27 any = tmp25; var tmp28 *lang.Var; A_arbace_classes_go_A_Init(); tmp28 = A_arbace_classes_go_A_const_34; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 *lang.Var; A_arbace_classes_go_A_Init(); tmp30 = A_arbace_classes_go_A_const_37; var tmp31 any = tmp20.Invoke_O_O__O(tmp22, tmp24.Invoke_O_O__O(tmp27, tmp29.Invoke_O_O__O(jrt.NN(tmp30).GetRawRoot__O(), jrt.NN(jrt.Class_Cast(c__1)).GetInterfaces__Class1().Ref()))); var tmp32 *lang.Keyword; A_arbace_classes_go_A_Init(); tmp32 = A_arbace_classes_go_A_const_44; var tmp33 any = tmp32.Ref(); return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp14, tmp16, tmp18, tmp31, tmp33, lang.IFn_Cast(raw__4).Invoke__O())) } else { return nil } } } }
//line :75:1
func A_arbace_classes_go_generics_raw__1797000028_A_New_O(p0 any) *A_arbace_classes_go_generics_raw__1797000028_A { A_arbace_classes_go_generics_raw__1797000028_A_Init(); t := &A_arbace_classes_go_generics_raw__1797000028_A{}; t.Ctor_O(p0); return t }
//line :75:1
func (t *A_arbace_classes_go_generics_raw__1797000028_A) Ctor_O(c__c any) { t.F_c = c__c }
//line :75:1
func (t *A_arbace_classes_go_generics_raw__1797000028_A) Invoke_O__O(self any) any { var iter__1927001039__auto____1 any; var tmp1 any = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_New(); var tmp2 *jrt.Class;
											A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_Init(); tmp2 = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_fn_class; iter__1927001039__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return lang.IFn_Cast(iter__1927001039__auto____1).Invoke_O__O(jrt.NN(jrt.Class_Cast(t.F_c)).GetDeclaredMethods__Method1().Ref()) }
//line :76:1
func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_New() *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A { A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_Init(); t := &A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A{}; t.Ctor(); return t }
//line :76:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A) Ctor() {}
//line :76:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A) Invoke_O_O__O(self, s__1797000030__1 any) any { var tmp1 any = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_New_O_O(self, s__1797000030__1); var tmp2 *jrt.Class; A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_Init(); tmp2 = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :76:1
func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_New_O_O(p0, p1 any) *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A { A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_Init(); t := &A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A{}; t.Ctor_O_O(p0, p1); return t }
//line :76:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A) Ctor_O_O(c__iter__1797000029, c__s__1797000030 any) { t.F_iter__1797000029 = c__iter__1797000029; t.F_s__1797000030 = c__s__1797000030 }
//line :76:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A) Invoke_O__O(self any) any { { var s__1797000030__1 any; var t_ any = t.F_s__1797000030; t.F_s__1797000030 = nil; s__1797000030__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_classes_go_A_Init(); tmp1 = A_arbace_classes_go_A_const_21; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__1797000030__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__1797000030__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_classes_go_A_Init(); tmp2 = A_arbace_classes_go_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__1797000030__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_classes_go_A_Init(); tmp3 = A_arbace_classes_go_A_const_23; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1797000030__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1797000032__6 any; var tmp4 *lang.Var; A_arbace_classes_go_A_Init(); tmp4 = A_arbace_classes_go_A_const_24; b__1797000032__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1797000032__6); var tmp6 *jrt.Class; A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_Init(); tmp6 = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_classes_go_A_Init(); tmp7 = A_arbace_classes_go_A_const_38; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_classes_go_A_Init(); tmp9 = A_arbace_classes_go_A_const_41; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__1797000032__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__1797000029); var tmp12 *lang.Var; A_arbace_classes_go_A_Init(); tmp12 = A_arbace_classes_go_A_const_42; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__1797000030__3))) } else { var tmp13 *lang.Var; A_arbace_classes_go_A_Init(); tmp13 = A_arbace_classes_go_A_const_38; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_classes_go_A_Init(); tmp15 = A_arbace_classes_go_A_const_41; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__1797000032__6), nil) } } else { var m__4 any; var tmp16 *lang.Var; A_arbace_classes_go_A_Init(); tmp16 = A_arbace_classes_go_A_const_39; m__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__1797000030__3); var tmp17 *lang.Var; A_arbace_classes_go_A_Init(); tmp17 = A_arbace_classes_go_A_const_40; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Keyword; A_arbace_classes_go_A_Init(); tmp19 = A_arbace_classes_go_A_const_26; var tmp20 any = tmp19.Ref(); var tmp21 any = jrt.NN(jrt.Method_Cast(m__4)).GetName__String().Ref(); var tmp22 *lang.Keyword; A_arbace_classes_go_A_Init(); tmp22 = A_arbace_classes_go_A_const_27; var tmp23 any = tmp22.Ref(); var tmp24 *lang.Var; A_arbace_classes_go_A_Init(); tmp24 = A_arbace_classes_go_A_const_28; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 *lang.Var; A_arbace_classes_go_A_Init(); tmp26 = A_arbace_classes_go_A_const_34; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Var; A_arbace_classes_go_A_Init(); tmp28 = A_arbace_classes_go_A_const_35; var tmp29 any = tmp27.Invoke_O_O__O(jrt.NN(tmp28).GetRawRoot__O(), jrt.NN(jrt.Method_Cast(m__4)).GetParameterTypes__Class1().Ref()); var tmp30 *lang.Var; A_arbace_classes_go_A_Init(); tmp30 = A_arbace_classes_go_A_const_35; var tmp31 any = tmp25.Invoke_O_O__O(tmp29, lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Method_Cast(m__4)).GetReturnType__Class().Ref())); var tmp32 *lang.Keyword; A_arbace_classes_go_A_Init(); tmp32 = A_arbace_classes_go_A_const_29; var tmp33 any = tmp32.Ref(); var tmp34 any = jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.Method_Cast(m__4)).GetModifiers__I()).Ref(); var tmp35 *lang.Keyword; A_arbace_classes_go_A_Init(); tmp35 = A_arbace_classes_go_A_const_30; var tmp36 any = tmp35.Ref(); var tmp37 *lang.Var; A_arbace_classes_go_A_Init(); tmp37 = A_arbace_classes_go_A_const_31; var tmp38 lang.IFn = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()); var tmp39 any = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_New(); var tmp40 *jrt.Class; A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_Init(); tmp40 = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_fn_class; var tmp41 any = tmp38.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp39, tmp40, nil), jrt.NN(jrt.Method_Cast(m__4)).GetExceptionTypes__Class1().Ref()); var tmp42 *lang.Keyword; A_arbace_classes_go_A_Init(); tmp42 = A_arbace_classes_go_A_const_32; var tmp43 any = tmp42.Ref(); var tmp44 *lang.Var; A_arbace_classes_go_A_Init(); tmp44 = A_arbace_classes_go_A_const_31; var tmp45 lang.IFn = lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()); var tmp46 *lang.Var; A_arbace_classes_go_A_Init(); tmp46 = A_arbace_classes_go_A_const_37; var tmp47 any = tmp45.Invoke_O_O__O(jrt.NN(tmp46).GetRawRoot__O(), jrt.NN(jrt.Method_Cast(m__4)).GetParameterTypes__Class1().Ref()); var tmp48 *lang.Keyword; A_arbace_classes_go_A_Init(); tmp48 = A_arbace_classes_go_A_const_33; var tmp49 any = tmp48.Ref(); var tmp50 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp50 = lang.PersistentArrayMap_EMPTY; var tmp51 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp20, tmp21, tmp23, tmp31, tmp33, tmp34, tmp36, tmp41, tmp43, tmp47, tmp49, tmp50.Ref())); var tmp52 lang.IFn = lang.IFn_Cast(t.F_iter__1797000029); var tmp53 *lang.Var; A_arbace_classes_go_A_Init(); tmp53 = A_arbace_classes_go_A_const_43; return tmp18.Invoke_O_O__O(tmp51, tmp52.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp53).GetRawRoot__O()).Invoke_O__O(s__1797000030__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :76:1
func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A { A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_Init(); t := &A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :76:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1797000032 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1797000032 = c__b__1797000032 }
//line :76:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A) Invoke_O__O(self any) any { { var i__1797000031__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1797000031__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1797000031__1)); var tmp2 *lang.Var; A_arbace_classes_go_A_Init(); tmp2 = A_arbace_classes_go_A_const_25; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__1797000032; var tmp5 *lang.Keyword; A_arbace_classes_go_A_Init(); tmp5 = A_arbace_classes_go_A_const_26; var tmp6 any = tmp5.Ref(); var tmp7 any = jrt.NN(jrt.Method_Cast(m__2)).GetName__String().Ref(); var tmp8 *lang.Keyword; A_arbace_classes_go_A_Init(); tmp8 = A_arbace_classes_go_A_const_27; var tmp9 any = tmp8.Ref(); var tmp10 *lang.Var; A_arbace_classes_go_A_Init(); tmp10 = A_arbace_classes_go_A_const_28; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Var; A_arbace_classes_go_A_Init(); tmp12 = A_arbace_classes_go_A_const_34; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_classes_go_A_Init(); tmp14 = A_arbace_classes_go_A_const_35; var tmp15 any = tmp13.Invoke_O_O__O(jrt.NN(tmp14).GetRawRoot__O(), jrt.NN(jrt.Method_Cast(m__2)).GetParameterTypes__Class1().Ref()); var tmp16 *lang.Var; A_arbace_classes_go_A_Init(); tmp16 = A_arbace_classes_go_A_const_35; var tmp17 any = tmp11.Invoke_O_O__O(tmp15, lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Method_Cast(m__2)).GetReturnType__Class().Ref())); var tmp18 *lang.Keyword; A_arbace_classes_go_A_Init(); tmp18 = A_arbace_classes_go_A_const_29; var tmp19 any = tmp18.Ref(); var tmp20 any = jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.Method_Cast(m__2)).GetModifiers__I()).Ref(); var tmp21 *lang.Keyword; A_arbace_classes_go_A_Init(); tmp21 = A_arbace_classes_go_A_const_30; var tmp22 any = tmp21.Ref(); var tmp23 *lang.Var; A_arbace_classes_go_A_Init(); tmp23 = A_arbace_classes_go_A_const_31; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 any = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_New(); var tmp26 *jrt.Class; A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_Init(); tmp26 = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_fn_class; var tmp27 any = tmp24.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil), jrt.NN(jrt.Method_Cast(m__2)).GetExceptionTypes__Class1().Ref()); var tmp28 *lang.Keyword; A_arbace_classes_go_A_Init(); tmp28 = A_arbace_classes_go_A_const_32; var tmp29 any = tmp28.Ref(); var tmp30 *lang.Var; A_arbace_classes_go_A_Init(); tmp30 = A_arbace_classes_go_A_const_31; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *lang.Var; A_arbace_classes_go_A_Init(); tmp32 = A_arbace_classes_go_A_const_37; var tmp33 any = tmp31.Invoke_O_O__O(jrt.NN(tmp32).GetRawRoot__O(), jrt.NN(jrt.Method_Cast(m__2)).GetParameterTypes__Class1().Ref()); var tmp34 *lang.Keyword; A_arbace_classes_go_A_Init(); tmp34 = A_arbace_classes_go_A_const_33; var tmp35 any = tmp34.Ref(); var tmp36 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp36 = lang.PersistentArrayMap_EMPTY; tmp3.Invoke_O_O__O(tmp4, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7, tmp9, tmp17, tmp19, tmp20, tmp22, tmp27, tmp29, tmp33, tmp35, tmp36.Ref()))); i__1797000031__1 = lang.Numbers_Unchecked_inc_J__J(i__1797000031__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }



func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_New() *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A { A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_Init(); t := &A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A) Ctor() {}
//line :80:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A) Invoke_O_O__O(self, p1__1797000027_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_classes_go_A_Init(); tmp1 = A_arbace_classes_go_A_const_36; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(jrt.Class_Cast(p1__1797000027_SHARP___1)).GetName__String().Ref(), Lit_78, Lit_79) }
//line :80:1
func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_New() *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A { A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_Init(); t := &A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A) Ctor() {}
//line :80:1
func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A) Invoke_O_O__O(self, p1__1797000027_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_classes_go_A_Init(); tmp1 = A_arbace_classes_go_A_const_36; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(jrt.Class_Cast(p1__1797000027_SHARP___1)).GetName__String().Ref(), Lit_78, Lit_79) }










func A_arbace_classes_go_constructors_A_New() *A_arbace_classes_go_constructors_A { A_arbace_classes_go_constructors_A_Init(); t := &A_arbace_classes_go_constructors_A{}; t.Ctor(); return t }
//line :91:1
func (t *A_arbace_classes_go_constructors_A) Ctor() {}
//line :91:1
func (t *A_arbace_classes_go_constructors_A) Invoke_O_O__O(self, n__0 any) any { var or__1927000174__auto____2 any; var tmp1 *lang.Keyword;



	A_arbace_classes_go_A_Init(); tmp1 = A_arbace_classes_go_A_const_52; var tmp2 *lang.Keyword = tmp1; var tmp3 *lang.Var; A_arbace_classes_go_A_Init(); tmp3 = A_arbace_classes_go_A_const_6; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_classes_go_A_Init(); tmp5 = A_arbace_classes_go_A_const_50; or__1927000174__auto____2 = jrt.NN(tmp2).Invoke_O__O(lang.RT_Get_O_O__O(tmp4.Invoke_O__O(jrt.NN(tmp5).GetRawRoot__O()), n__0)); if jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else {
		var tmp6 any; A_arbace_classes_go_A_Init(); tmp6 = A_arbace_classes_go_A_const_53; return lang.RT_Get_O_O__O(tmp6, n__0) } }


















































type A_arbace_classes_go_A struct{ jrt.Object }

var A_arbace_classes_go_A_const_0 *lang.Var

var A_arbace_classes_go_A_const_1 *lang.Var

var A_arbace_classes_go_A_const_2 any

var A_arbace_classes_go_A_const_3 any

var A_arbace_classes_go_A_const_4 any

var A_arbace_classes_go_A_const_5 *lang.Var

var A_arbace_classes_go_A_const_6 *lang.Var

var A_arbace_classes_go_A_const_7 *lang.Var

var A_arbace_classes_go_A_const_8 any

var A_arbace_classes_go_A_const_9 *lang.Var

var A_arbace_classes_go_A_const_10 *lang.Var

var A_arbace_classes_go_A_const_11 *lang.Var

var A_arbace_classes_go_A_const_12 *lang.Var

var A_arbace_classes_go_A_const_13 *lang.Var

var A_arbace_classes_go_A_const_14 *lang.Var

var A_arbace_classes_go_A_const_15 *lang.Var

var A_arbace_classes_go_A_const_16 *lang.Var

var A_arbace_classes_go_A_const_17 *lang.Var

var A_arbace_classes_go_A_const_18 *lang.Var

var A_arbace_classes_go_A_const_19 *lang.Var

var A_arbace_classes_go_A_const_20 *lang.Var

var A_arbace_classes_go_A_const_21 *lang.Var

var A_arbace_classes_go_A_const_22 *lang.Var

var A_arbace_classes_go_A_const_23 *lang.Var

var A_arbace_classes_go_A_const_24 *lang.Var

var A_arbace_classes_go_A_const_25 *lang.Var

var A_arbace_classes_go_A_const_26 *lang.Keyword

var A_arbace_classes_go_A_const_27 *lang.Keyword

var A_arbace_classes_go_A_const_28 *lang.Var

var A_arbace_classes_go_A_const_29 *lang.Keyword

var A_arbace_classes_go_A_const_30 *lang.Keyword

var A_arbace_classes_go_A_const_31 *lang.Var

var A_arbace_classes_go_A_const_32 *lang.Keyword

var A_arbace_classes_go_A_const_33 *lang.Keyword

var A_arbace_classes_go_A_const_34 *lang.Var

var A_arbace_classes_go_A_const_35 *lang.Var

var A_arbace_classes_go_A_const_36 *lang.Var

var A_arbace_classes_go_A_const_37 *lang.Var

var A_arbace_classes_go_A_const_38 *lang.Var

var A_arbace_classes_go_A_const_39 *lang.Var

var A_arbace_classes_go_A_const_40 *lang.Var

var A_arbace_classes_go_A_const_41 *lang.Var

var A_arbace_classes_go_A_const_42 *lang.Var

var A_arbace_classes_go_A_const_43 *lang.Var

var A_arbace_classes_go_A_const_44 *lang.Keyword

var A_arbace_classes_go_A_const_45 *lang.Var

var A_arbace_classes_go_A_const_46 *lang.Keyword

var A_arbace_classes_go_A_const_47 *lang.Keyword

var A_arbace_classes_go_A_const_48 *lang.Keyword

var A_arbace_classes_go_A_const_49 *lang.Var

var A_arbace_classes_go_A_const_50 *lang.Var

var A_arbace_classes_go_A_const_51 *lang.Var

var A_arbace_classes_go_A_const_52 *lang.Keyword

var A_arbace_classes_go_A_const_53 any

var A_arbace_classes_go_A_init jrt.ClassInit

func A_arbace_classes_go_A_Init() { if !A_arbace_classes_go_A_init.Done() { A_arbace_classes_go_A_init.Run(A_arbace_classes_go_A_clinit) } }

func A_arbace_classes_go_A_clinit() { A_arbace_classes_go_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_classes_go_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_classes_go_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_classes_go_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_classes_go_A_const_4 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref()); A_arbace_classes_go_A_const_5 = lang.RT_Var_String_String__Var(Lit_0, Lit_8); A_arbace_classes_go_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_9); A_arbace_classes_go_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_10); A_arbace_classes_go_A_const_8 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_11)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13))); A_arbace_classes_go_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_14); A_arbace_classes_go_A_const_10 = lang.RT_Var_String_String__Var(Lit_11, Lit_15); A_arbace_classes_go_A_const_11 = lang.RT_Var_String_String__Var(Lit_11, Lit_16); A_arbace_classes_go_A_const_12 = lang.RT_Var_String_String__Var(Lit_11, Lit_17); A_arbace_classes_go_A_const_13 = lang.RT_Var_String_String__Var(Lit_11, Lit_18); A_arbace_classes_go_A_const_14 = lang.RT_Var_String_String__Var(Lit_11, Lit_19); A_arbace_classes_go_A_const_15 = lang.RT_Var_String_String__Var(Lit_0, Lit_20); A_arbace_classes_go_A_const_16 = lang.RT_Var_String_String__Var(Lit_0, Lit_21); A_arbace_classes_go_A_const_17 = lang.RT_Var_String_String__Var(Lit_0, Lit_22); A_arbace_classes_go_A_const_18 = lang.RT_Var_String_String__Var(Lit_0, Lit_23); A_arbace_classes_go_A_const_19 = lang.RT_Var_String_String__Var(Lit_0, Lit_24); A_arbace_classes_go_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_25); A_arbace_classes_go_A_const_21 = lang.RT_Var_String_String__Var(Lit_0, Lit_26); A_arbace_classes_go_A_const_22 = lang.RT_Var_String_String__Var(Lit_0, Lit_27); A_arbace_classes_go_A_const_23 = lang.RT_Var_String_String__Var(Lit_0, Lit_28); A_arbace_classes_go_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_29); A_arbace_classes_go_A_const_25 = lang.RT_Var_String_String__Var(Lit_0, Lit_30); A_arbace_classes_go_A_const_26 = lang.RT_Keyword_String_String__Keyword(nil, Lit_31); A_arbace_classes_go_A_const_27 = lang.RT_Keyword_String_String__Keyword(nil, Lit_32); A_arbace_classes_go_A_const_28 = lang.RT_Var_String_String__Var(Lit_3, Lit_33); A_arbace_classes_go_A_const_29 = lang.RT_Keyword_String_String__Keyword(nil, Lit_34); A_arbace_classes_go_A_const_30 = lang.RT_Keyword_String_String__Keyword(nil, Lit_35); A_arbace_classes_go_A_const_31 = lang.RT_Var_String_String__Var(Lit_0, Lit_36); A_arbace_classes_go_A_const_32 = lang.RT_Keyword_String_String__Keyword(nil, Lit_37); A_arbace_classes_go_A_const_33 = lang.RT_Keyword_String_String__Keyword(nil, Lit_38); A_arbace_classes_go_A_const_34 = lang.RT_Var_String_String__Var(Lit_0, Lit_39); A_arbace_classes_go_A_const_35 = lang.RT_Var_String_String__Var(Lit_3, Lit_40); A_arbace_classes_go_A_const_36 = lang.RT_Var_String_String__Var(Lit_6, Lit_41); A_arbace_classes_go_A_const_37 = lang.RT_Var_String_String__Var(Lit_3, Lit_42); A_arbace_classes_go_A_const_38 = lang.RT_Var_String_String__Var(Lit_0, Lit_43); A_arbace_classes_go_A_const_39 = lang.RT_Var_String_String__Var(Lit_0, Lit_44); A_arbace_classes_go_A_const_40 = lang.RT_Var_String_String__Var(Lit_0, Lit_45); A_arbace_classes_go_A_const_41 = lang.RT_Var_String_String__Var(Lit_0, Lit_46); A_arbace_classes_go_A_const_42 = lang.RT_Var_String_String__Var(Lit_0, Lit_47); A_arbace_classes_go_A_const_43 = lang.RT_Var_String_String__Var(Lit_0, Lit_48); A_arbace_classes_go_A_const_44 = lang.RT_Keyword_String_String__Keyword(nil, Lit_49); A_arbace_classes_go_A_const_45 = lang.RT_Var_String_String__Var(Lit_0, Lit_50); A_arbace_classes_go_A_const_46 = lang.RT_Keyword_String_String__Keyword(nil, Lit_51); A_arbace_classes_go_A_const_47 = lang.RT_Keyword_String_String__Keyword(nil, Lit_52); A_arbace_classes_go_A_const_48 = lang.RT_Keyword_String_String__Keyword(nil, Lit_53); A_arbace_classes_go_A_const_49 = lang.RT_Var_String_String__Var(Lit_0, Lit_54); A_arbace_classes_go_A_const_50 = lang.RT_Var_String_String__Var(Lit_11, Lit_55); A_arbace_classes_go_A_const_51 = lang.RT_Var_String_String__Var(Lit_0, Lit_56); A_arbace_classes_go_A_const_52 = lang.RT_Keyword_String_String__Keyword(nil, Lit_57); A_arbace_classes_go_A_const_53 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, Lit_58, lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(Lit_59, jrt.Long_ValueOf_J__Long(4).Ref())), Lit_60, lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(Lit_61, jrt.Long_ValueOf_J__Long(1).Ref())), Lit_62, lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(Lit_63, jrt.Long_ValueOf_J__Long(4).Ref())), Lit_64, lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(Lit_63, jrt.Long_ValueOf_J__Long(1).Ref())))) }

func A_arbace_classes_go_A_New() *A_arbace_classes_go_A { A_arbace_classes_go_A_Init(); t := &A_arbace_classes_go_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_go_A) Ctor() {}

func (t *A_arbace_classes_go_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_A_class }

func (t *A_arbace_classes_go_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_go_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_A); return ok }

func A_arbace_classes_go_A_Cast(x any) *A_arbace_classes_go_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_A_class)) }; return v }



type A_arbace_classes_go_constructors_A struct{ jrt.Object }

func (t *A_arbace_classes_go_constructors_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_go_constructors_A_fn_class *jrt.Class

var A_arbace_classes_go_constructors_A_init jrt.ClassInit

func A_arbace_classes_go_constructors_A_Init() { if !A_arbace_classes_go_constructors_A_init.Done() { A_arbace_classes_go_constructors_A_init.Run(A_arbace_classes_go_constructors_A_clinit) } }

func A_arbace_classes_go_constructors_A_clinit() { A_arbace_classes_go_constructors_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_65, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_go_constructors_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_constructors_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_constructors_A_class }

func (t *A_arbace_classes_go_constructors_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_constructors_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_go_constructors_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_constructors_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_constructors_A); return ok }

func A_arbace_classes_go_constructors_A_Cast(x any) *A_arbace_classes_go_constructors_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_constructors_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_constructors_A_class)) }; return v }



type A_arbace_classes_go_eval1797000004_A struct{ jrt.Object }

func A_arbace_classes_go_eval1797000004_A_New() *A_arbace_classes_go_eval1797000004_A { t := &A_arbace_classes_go_eval1797000004_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_go_eval1797000004_A) Ctor() {}

func (t *A_arbace_classes_go_eval1797000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_eval1797000004_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_eval1797000004_A_class }

func (t *A_arbace_classes_go_eval1797000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_eval1797000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_go_eval1797000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_eval1797000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_eval1797000004_A); return ok }

func A_arbace_classes_go_eval1797000004_A_Cast(x any) *A_arbace_classes_go_eval1797000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_eval1797000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_eval1797000004_A_class)) }; return v }



type A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A struct{ jrt.Object }

func (t *A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_fn_class *jrt.Class

var A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_init jrt.ClassInit

func A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_Init() { if !A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_init.Done() { A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_init.Run(A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_clinit) } }

func A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_clinit() { A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_66, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_class }

func (t *A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A); return ok }

func A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_Cast(x any) *A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_class)) }; return v }



type A_arbace_classes_go_eval1797000008_A struct{ jrt.Object }

func A_arbace_classes_go_eval1797000008_A_New() *A_arbace_classes_go_eval1797000008_A { t := &A_arbace_classes_go_eval1797000008_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_go_eval1797000008_A) Ctor() {}

func (t *A_arbace_classes_go_eval1797000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_eval1797000008_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_eval1797000008_A_class }

func (t *A_arbace_classes_go_eval1797000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_eval1797000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_go_eval1797000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_eval1797000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_eval1797000008_A); return ok }

func A_arbace_classes_go_eval1797000008_A_Cast(x any) *A_arbace_classes_go_eval1797000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_eval1797000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_eval1797000008_A_class)) }; return v }



type A_arbace_classes_go_eval1797000008_fn__1797000009_A struct{ jrt.Object }

func (t *A_arbace_classes_go_eval1797000008_fn__1797000009_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_go_eval1797000008_fn__1797000009_A_fn_class *jrt.Class

var A_arbace_classes_go_eval1797000008_fn__1797000009_A_init jrt.ClassInit

func A_arbace_classes_go_eval1797000008_fn__1797000009_A_Init() { if !A_arbace_classes_go_eval1797000008_fn__1797000009_A_init.Done() { A_arbace_classes_go_eval1797000008_fn__1797000009_A_init.Run(A_arbace_classes_go_eval1797000008_fn__1797000009_A_clinit) } }

func A_arbace_classes_go_eval1797000008_fn__1797000009_A_clinit() { A_arbace_classes_go_eval1797000008_fn__1797000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_67, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_go_eval1797000008_fn__1797000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_eval1797000008_fn__1797000009_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_eval1797000008_fn__1797000009_A_class }

func (t *A_arbace_classes_go_eval1797000008_fn__1797000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_eval1797000008_fn__1797000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_go_eval1797000008_fn__1797000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_eval1797000008_fn__1797000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_eval1797000008_fn__1797000009_A); return ok }

func A_arbace_classes_go_eval1797000008_fn__1797000009_A_Cast(x any) *A_arbace_classes_go_eval1797000008_fn__1797000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_eval1797000008_fn__1797000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_eval1797000008_fn__1797000009_A_class)) }; return v }



type A_arbace_classes_go_fn__1797000023_A struct{ jrt.Object }

func (t *A_arbace_classes_go_fn__1797000023_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_go_fn__1797000023_A_fn_class *jrt.Class

var A_arbace_classes_go_fn__1797000023_A_init jrt.ClassInit

func A_arbace_classes_go_fn__1797000023_A_Init() { if !A_arbace_classes_go_fn__1797000023_A_init.Done() { A_arbace_classes_go_fn__1797000023_A_init.Run(A_arbace_classes_go_fn__1797000023_A_clinit) } }

func A_arbace_classes_go_fn__1797000023_A_clinit() { A_arbace_classes_go_fn__1797000023_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_68, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_go_fn__1797000023_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_fn__1797000023_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_fn__1797000023_A_class }

func (t *A_arbace_classes_go_fn__1797000023_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_fn__1797000023_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_go_fn__1797000023_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_fn__1797000023_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_fn__1797000023_A); return ok }

func A_arbace_classes_go_fn__1797000023_A_Cast(x any) *A_arbace_classes_go_fn__1797000023_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_fn__1797000023_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_fn__1797000023_A_class)) }; return v }



type A_arbace_classes_go_fn__1797000025_A struct{ jrt.Object }

func (t *A_arbace_classes_go_fn__1797000025_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_go_fn__1797000025_A_fn_class *jrt.Class

var A_arbace_classes_go_fn__1797000025_A_init jrt.ClassInit

func A_arbace_classes_go_fn__1797000025_A_Init() { if !A_arbace_classes_go_fn__1797000025_A_init.Done() { A_arbace_classes_go_fn__1797000025_A_init.Run(A_arbace_classes_go_fn__1797000025_A_clinit) } }

func A_arbace_classes_go_fn__1797000025_A_clinit() { A_arbace_classes_go_fn__1797000025_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_70, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_go_fn__1797000025_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_fn__1797000025_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_fn__1797000025_A_class }

func (t *A_arbace_classes_go_fn__1797000025_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_fn__1797000025_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_go_fn__1797000025_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_fn__1797000025_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_fn__1797000025_A); return ok }

func A_arbace_classes_go_fn__1797000025_A_Cast(x any) *A_arbace_classes_go_fn__1797000025_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_fn__1797000025_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_fn__1797000025_A_class)) }; return v }



type A_arbace_classes_go_generics_A struct{ jrt.Object }

func (t *A_arbace_classes_go_generics_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_go_generics_A_fn_class *jrt.Class

var A_arbace_classes_go_generics_A_init jrt.ClassInit

func A_arbace_classes_go_generics_A_Init() { if !A_arbace_classes_go_generics_A_init.Done() { A_arbace_classes_go_generics_A_init.Run(A_arbace_classes_go_generics_A_clinit) } }

func A_arbace_classes_go_generics_A_clinit() { A_arbace_classes_go_generics_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_72, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_go_generics_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_generics_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_generics_A_class }

func (t *A_arbace_classes_go_generics_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_generics_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_go_generics_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_generics_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_generics_A); return ok }

func A_arbace_classes_go_generics_A_Cast(x any) *A_arbace_classes_go_generics_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_generics_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_generics_A_class)) }; return v }



type A_arbace_classes_go_generics_raw__1797000028_A struct{ jrt.Object; F_c any }

func (t *A_arbace_classes_go_generics_raw__1797000028_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_go_generics_raw__1797000028_A_fn_class *jrt.Class

var A_arbace_classes_go_generics_raw__1797000028_A_init jrt.ClassInit

func A_arbace_classes_go_generics_raw__1797000028_A_Init() { if !A_arbace_classes_go_generics_raw__1797000028_A_init.Done() { A_arbace_classes_go_generics_raw__1797000028_A_init.Run(A_arbace_classes_go_generics_raw__1797000028_A_clinit) } }

func A_arbace_classes_go_generics_raw__1797000028_A_clinit() { A_arbace_classes_go_generics_raw__1797000028_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_73, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_go_generics_raw__1797000028_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_generics_raw__1797000028_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_generics_raw__1797000028_A_class }

func (t *A_arbace_classes_go_generics_raw__1797000028_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_generics_raw__1797000028_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_go_generics_raw__1797000028_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_generics_raw__1797000028_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_generics_raw__1797000028_A); return ok }

func A_arbace_classes_go_generics_raw__1797000028_A_Cast(x any) *A_arbace_classes_go_generics_raw__1797000028_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_generics_raw__1797000028_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_generics_raw__1797000028_A_class)) }; return v }



type A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A struct{ jrt.Object }

func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_fn_class *jrt.Class

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_init jrt.ClassInit

func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_Init() { if !A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_init.Done() { A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_init.Run(A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_clinit) } }

func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_clinit() { A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_74, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_class }

func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A); return ok }

func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_Cast(x any) *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_class)) }; return v }



type A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A struct{ jrt.Object; F_iter__1797000029, F_s__1797000030 any }

func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_fn_class *jrt.Class

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_init jrt.ClassInit

func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_Init() { if !A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_init.Done() { A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_init.Run(A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_clinit) } }

func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_clinit() { A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_75, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_class }

func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A); return ok }

func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_Cast(x any) *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_class)) }; return v }



type A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A struct{ jrt.Object; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1797000032 any }

func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_fn_class *jrt.Class

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_init jrt.ClassInit

func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_Init() { if !A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_init.Done() { A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_init.Run(A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_clinit) } }

func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_clinit() { A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_76, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_class }

func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A); return ok }

func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_Cast(x any) *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_class)) }; return v }



type A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A struct{ jrt.Object }

func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_fn_class *jrt.Class

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_init jrt.ClassInit

func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_Init() { if !A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_init.Done() { A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_init.Run(A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_clinit) } }

func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_clinit() { A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_77, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_class }

func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A); return ok }

func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_Cast(x any) *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_class)) }; return v }



type A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A struct{ jrt.Object }

func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_fn_class *jrt.Class

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_init jrt.ClassInit

func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_Init() { if !A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_init.Done() { A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_init.Run(A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_clinit) } }

func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_clinit() { A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_80, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_class }

func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A); return ok }

func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_Cast(x any) *A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_class)) }; return v }



type A_arbace_classes_go_newExceptionReference_A struct{ jrt.Object }

func (t *A_arbace_classes_go_newExceptionReference_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_go_newExceptionReference_A_fn_class *jrt.Class

var A_arbace_classes_go_newExceptionReference_A_init jrt.ClassInit

func A_arbace_classes_go_newExceptionReference_A_Init() { if !A_arbace_classes_go_newExceptionReference_A_init.Done() { A_arbace_classes_go_newExceptionReference_A_init.Run(A_arbace_classes_go_newExceptionReference_A_clinit) } }

func A_arbace_classes_go_newExceptionReference_A_clinit() { A_arbace_classes_go_newExceptionReference_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_81, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_go_newExceptionReference_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_newExceptionReference_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_newExceptionReference_A_class }

func (t *A_arbace_classes_go_newExceptionReference_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_newExceptionReference_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_go_newExceptionReference_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_newExceptionReference_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_newExceptionReference_A); return ok }

func A_arbace_classes_go_newExceptionReference_A_Cast(x any) *A_arbace_classes_go_newExceptionReference_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_newExceptionReference_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_newExceptionReference_A_class)) }; return v }



type A_arbace_classes_go_newFormalParameterReference_A struct{ jrt.Object }

func (t *A_arbace_classes_go_newFormalParameterReference_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_go_newFormalParameterReference_A_fn_class *jrt.Class

var A_arbace_classes_go_newFormalParameterReference_A_init jrt.ClassInit

func A_arbace_classes_go_newFormalParameterReference_A_Init() { if !A_arbace_classes_go_newFormalParameterReference_A_init.Done() { A_arbace_classes_go_newFormalParameterReference_A_init.Run(A_arbace_classes_go_newFormalParameterReference_A_clinit) } }

func A_arbace_classes_go_newFormalParameterReference_A_clinit() { A_arbace_classes_go_newFormalParameterReference_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_82, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_go_newFormalParameterReference_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_newFormalParameterReference_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_newFormalParameterReference_A_class }

func (t *A_arbace_classes_go_newFormalParameterReference_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_newFormalParameterReference_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_go_newFormalParameterReference_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_newFormalParameterReference_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_newFormalParameterReference_A); return ok }

func A_arbace_classes_go_newFormalParameterReference_A_Cast(x any) *A_arbace_classes_go_newFormalParameterReference_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_newFormalParameterReference_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_newFormalParameterReference_A_class)) }; return v }



type A_arbace_classes_go_newSuperTypeReference_A struct{ jrt.Object }

func (t *A_arbace_classes_go_newSuperTypeReference_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_go_newSuperTypeReference_A_fn_class *jrt.Class

var A_arbace_classes_go_newSuperTypeReference_A_init jrt.ClassInit

func A_arbace_classes_go_newSuperTypeReference_A_Init() { if !A_arbace_classes_go_newSuperTypeReference_A_init.Done() { A_arbace_classes_go_newSuperTypeReference_A_init.Run(A_arbace_classes_go_newSuperTypeReference_A_clinit) } }

func A_arbace_classes_go_newSuperTypeReference_A_clinit() { A_arbace_classes_go_newSuperTypeReference_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_83, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_go_newSuperTypeReference_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_newSuperTypeReference_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_newSuperTypeReference_A_class }

func (t *A_arbace_classes_go_newSuperTypeReference_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_newSuperTypeReference_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_go_newSuperTypeReference_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_newSuperTypeReference_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_newSuperTypeReference_A); return ok }

func A_arbace_classes_go_newSuperTypeReference_A_Cast(x any) *A_arbace_classes_go_newSuperTypeReference_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_newSuperTypeReference_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_newSuperTypeReference_A_class)) }; return v }



type A_arbace_classes_go_newTryCatchReference_A struct{ jrt.Object }

func (t *A_arbace_classes_go_newTryCatchReference_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_go_newTryCatchReference_A_fn_class *jrt.Class

var A_arbace_classes_go_newTryCatchReference_A_init jrt.ClassInit

func A_arbace_classes_go_newTryCatchReference_A_Init() { if !A_arbace_classes_go_newTryCatchReference_A_init.Done() { A_arbace_classes_go_newTryCatchReference_A_init.Run(A_arbace_classes_go_newTryCatchReference_A_clinit) } }

func A_arbace_classes_go_newTryCatchReference_A_clinit() { A_arbace_classes_go_newTryCatchReference_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_84, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_go_newTryCatchReference_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_newTryCatchReference_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_newTryCatchReference_A_class }

func (t *A_arbace_classes_go_newTryCatchReference_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_newTryCatchReference_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_go_newTryCatchReference_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_newTryCatchReference_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_newTryCatchReference_A); return ok }

func A_arbace_classes_go_newTryCatchReference_A_Cast(x any) *A_arbace_classes_go_newTryCatchReference_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_newTryCatchReference_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_newTryCatchReference_A_class)) }; return v }



type A_arbace_classes_go_newTypeArgumentReference_A struct{ jrt.Object }

func (t *A_arbace_classes_go_newTypeArgumentReference_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_go_newTypeArgumentReference_A_fn_class *jrt.Class

var A_arbace_classes_go_newTypeArgumentReference_A_init jrt.ClassInit

func A_arbace_classes_go_newTypeArgumentReference_A_Init() { if !A_arbace_classes_go_newTypeArgumentReference_A_init.Done() { A_arbace_classes_go_newTypeArgumentReference_A_init.Run(A_arbace_classes_go_newTypeArgumentReference_A_clinit) } }

func A_arbace_classes_go_newTypeArgumentReference_A_clinit() { A_arbace_classes_go_newTypeArgumentReference_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_85, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_go_newTypeArgumentReference_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_newTypeArgumentReference_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_newTypeArgumentReference_A_class }

func (t *A_arbace_classes_go_newTypeArgumentReference_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_newTypeArgumentReference_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_go_newTypeArgumentReference_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_newTypeArgumentReference_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_newTypeArgumentReference_A); return ok }

func A_arbace_classes_go_newTypeArgumentReference_A_Cast(x any) *A_arbace_classes_go_newTypeArgumentReference_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_newTypeArgumentReference_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_newTypeArgumentReference_A_class)) }; return v }



type A_arbace_classes_go_newTypeParameterBoundReference_A struct{ jrt.Object }

func (t *A_arbace_classes_go_newTypeParameterBoundReference_A) Is_Compiler_AOTF3() {}

var A_arbace_classes_go_newTypeParameterBoundReference_A_fn_class *jrt.Class

var A_arbace_classes_go_newTypeParameterBoundReference_A_init jrt.ClassInit

func A_arbace_classes_go_newTypeParameterBoundReference_A_Init() { if !A_arbace_classes_go_newTypeParameterBoundReference_A_init.Done() { A_arbace_classes_go_newTypeParameterBoundReference_A_init.Run(A_arbace_classes_go_newTypeParameterBoundReference_A_clinit) } }

func A_arbace_classes_go_newTypeParameterBoundReference_A_clinit() { A_arbace_classes_go_newTypeParameterBoundReference_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_86, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_go_newTypeParameterBoundReference_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_newTypeParameterBoundReference_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_newTypeParameterBoundReference_A_class }

func (t *A_arbace_classes_go_newTypeParameterBoundReference_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_newTypeParameterBoundReference_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_go_newTypeParameterBoundReference_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_newTypeParameterBoundReference_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_newTypeParameterBoundReference_A); return ok }

func A_arbace_classes_go_newTypeParameterBoundReference_A_Cast(x any) *A_arbace_classes_go_newTypeParameterBoundReference_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_newTypeParameterBoundReference_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_newTypeParameterBoundReference_A_class)) }; return v }



type A_arbace_classes_go_newTypeParameterReference_A struct{ jrt.Object }

func (t *A_arbace_classes_go_newTypeParameterReference_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_go_newTypeParameterReference_A_fn_class *jrt.Class

var A_arbace_classes_go_newTypeParameterReference_A_init jrt.ClassInit

func A_arbace_classes_go_newTypeParameterReference_A_Init() { if !A_arbace_classes_go_newTypeParameterReference_A_init.Done() { A_arbace_classes_go_newTypeParameterReference_A_init.Run(A_arbace_classes_go_newTypeParameterReference_A_clinit) } }

func A_arbace_classes_go_newTypeParameterReference_A_clinit() { A_arbace_classes_go_newTypeParameterReference_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_87, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_go_newTypeParameterReference_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_newTypeParameterReference_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_newTypeParameterReference_A_class }

func (t *A_arbace_classes_go_newTypeParameterReference_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_newTypeParameterReference_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_go_newTypeParameterReference_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_newTypeParameterReference_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_newTypeParameterReference_A); return ok }

func A_arbace_classes_go_newTypeParameterReference_A_Cast(x any) *A_arbace_classes_go_newTypeParameterReference_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_newTypeParameterReference_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_newTypeParameterReference_A_class)) }; return v }



type A_arbace_classes_go_newTypeReference_A struct{ jrt.Object }

func (t *A_arbace_classes_go_newTypeReference_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_go_newTypeReference_A_fn_class *jrt.Class

var A_arbace_classes_go_newTypeReference_A_init jrt.ClassInit

func A_arbace_classes_go_newTypeReference_A_Init() { if !A_arbace_classes_go_newTypeReference_A_init.Done() { A_arbace_classes_go_newTypeReference_A_init.Run(A_arbace_classes_go_newTypeReference_A_clinit) } }

func A_arbace_classes_go_newTypeReference_A_clinit() { A_arbace_classes_go_newTypeReference_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_88, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_go_newTypeReference_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_newTypeReference_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_newTypeReference_A_class }

func (t *A_arbace_classes_go_newTypeReference_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_newTypeReference_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_go_newTypeReference_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_newTypeReference_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_newTypeReference_A); return ok }

func A_arbace_classes_go_newTypeReference_A_Cast(x any) *A_arbace_classes_go_newTypeReference_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_newTypeReference_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_newTypeReference_A_class)) }; return v }



type A_arbace_classes_go_tref_A struct{ jrt.Object }

func (t *A_arbace_classes_go_tref_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_go_tref_A_fn_class *jrt.Class

var A_arbace_classes_go_tref_A_init jrt.ClassInit

func A_arbace_classes_go_tref_A_Init() { if !A_arbace_classes_go_tref_A_init.Done() { A_arbace_classes_go_tref_A_init.Run(A_arbace_classes_go_tref_A_clinit) } }

func A_arbace_classes_go_tref_A_clinit() { A_arbace_classes_go_tref_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_89, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_go_tref_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_tref_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_tref_A_class }

func (t *A_arbace_classes_go_tref_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_tref_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_go_tref_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_tref_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_tref_A); return ok }

func A_arbace_classes_go_tref_A_Cast(x any) *A_arbace_classes_go_tref_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_tref_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_tref_A_class)) }; return v }



type A_arbace_classes_go_tref_reify__1797000012_A struct{ jrt.Object; F_v int64; F___meta lang.IPersistentMap }

func (t *A_arbace_classes_go_tref_reify__1797000012_A) Is_Map_Entry() {}

func (t *A_arbace_classes_go_tref_reify__1797000012_A) Is_IObj() {}

func (t *A_arbace_classes_go_tref_reify__1797000012_A) Is_IMeta() {}

func (t *A_arbace_classes_go_tref_reify__1797000012_A) SetValue_O__O(p0 any) any { panic(jrt.A2g_NotTranslated("abstract arbace.classes.go$tref$reify__1797000012.setValue(Ljava/lang/Object;)Ljava/lang/Object;")) }

func (t *A_arbace_classes_go_tref_reify__1797000012_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_go_tref_reify__1797000012_A) GetClass__Class() *jrt.Class { return A_arbace_classes_go_tref_reify__1797000012_A_class }

func (t *A_arbace_classes_go_tref_reify__1797000012_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_go_tref_reify__1797000012_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_go_tref_reify__1797000012_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_go_tref_reify__1797000012_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_go_tref_reify__1797000012_A); return ok }

func A_arbace_classes_go_tref_reify__1797000012_A_Cast(x any) *A_arbace_classes_go_tref_reify__1797000012_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_go_tref_reify__1797000012_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_go_tref_reify__1797000012_A_class)) }; return v }
