//line a2g_strings.ae:1
package aot_arbace_classes_go

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.classes.types")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("t")

var Lit_6 *jrt.String = jrt.Intern("arbace.string")

var Lit_7 *jrt.String = jrt.Intern("str")

var Lit_8 *jrt.String = jrt.Intern("commute")

var Lit_9 *jrt.String = jrt.Intern("deref")

var Lit_10 *jrt.String = jrt.Intern("conj")

var Lit_11 *jrt.String = jrt.Intern("arbace.classes.go")

var Lit_12 *jrt.String = jrt.Intern("doc")

var Lit_13 *jrt.String = jrt.Intern("What the class forms' analysis (arbace.classes.analyze) took from ASM and, in the Go build,\n  from the JVM (doc/go/CLASSFORMS-REPL.md): ASM's TypeReference (ASM left main with the bytecode\n  back end, 2026-10-12), whose type reference values (sort << 24 | ...) it computes for type\n  annotations, as ASM does, each answering getValue; and, in the Go build, the generic\n  signatures of the classes of the world, which jrt's reflection does not have\n  (arbace/classes/generics.edn, written by a2g --program), for javac's bridges.\n  arbace.classes.analyze refers to it as TypeReference.")

var Lit_14 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_15 *jrt.String = jrt.Intern("tref")

var Lit_16 *jrt.String = jrt.Intern("CLASS_EXTENDS")

var Lit_17 *jrt.String = jrt.Intern("METHOD_FORMAL_PARAMETER")

var Lit_18 *jrt.String = jrt.Intern("THROWS")

var Lit_19 *jrt.String = jrt.Intern("EXCEPTION_PARAMETER")

var Lit_20 *jrt.String = jrt.Intern("read-string")

var Lit_21 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_22 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_23 *jrt.String = jrt.Intern("hash-map")

var Lit_24 *jrt.String = jrt.Intern("*read-eval*")

var Lit_25 *jrt.String = jrt.Intern("slurp")

var Lit_26 *jrt.String = jrt.Intern("seq")

var Lit_27 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_28 *jrt.String = jrt.Intern("chunk-first")

var Lit_29 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_30 *jrt.String = jrt.Intern("chunk-append")

var Lit_31 *jrt.String = jrt.Intern("name")

var Lit_32 *jrt.String = jrt.Intern("desc")

var Lit_33 *jrt.String = jrt.Intern("method-desc")

var Lit_34 *jrt.String = jrt.Intern("flags")

var Lit_35 *jrt.String = jrt.Intern("throws")

var Lit_36 *jrt.String = jrt.Intern("mapv")

var Lit_37 *jrt.String = jrt.Intern("params")

var Lit_38 *jrt.String = jrt.Intern("bounds")

var Lit_39 *jrt.String = jrt.Intern("map")

var Lit_40 *jrt.String = jrt.Intern("class->desc")

var Lit_41 *jrt.String = jrt.Intern("replace")

var Lit_42 *jrt.String = jrt.Intern("reflect->tnode")

var Lit_43 *jrt.String = jrt.Intern("chunk-cons")

var Lit_44 *jrt.String = jrt.Intern("first")

var Lit_45 *jrt.String = jrt.Intern("cons")

var Lit_46 *jrt.String = jrt.Intern("chunk")

var Lit_47 *jrt.String = jrt.Intern("chunk-rest")

var Lit_48 *jrt.String = jrt.Intern("rest")

var Lit_49 *jrt.String = jrt.Intern("methods")

var Lit_50 *jrt.String = jrt.Intern("assoc")

var Lit_51 *jrt.String = jrt.Intern("else")

var Lit_52 *jrt.String = jrt.Intern("tparams")

var Lit_53 *jrt.String = jrt.Intern("supers")

var Lit_54 *jrt.String = jrt.Intern("remove")

var Lit_55 *jrt.String = jrt.Intern("world-generics")

var Lit_56 *jrt.String = jrt.Intern("nil?")

var Lit_57 *jrt.String = jrt.Intern("ctors")

var Lit_58 *jrt.String = jrt.Intern("java/lang/Enum")

var Lit_59 *jrt.String = jrt.Intern("(Ljava/lang/String;I)V")

var Lit_60 *jrt.String = jrt.Intern("java/lang/MatchException")

var Lit_61 *jrt.String = jrt.Intern("(Ljava/lang/String;Ljava/lang/Throwable;)V")

var Lit_62 *jrt.String = jrt.Intern("java/lang/Record")

var Lit_63 *jrt.String = jrt.Intern("()V")

var Lit_64 *jrt.String = jrt.Intern("java/lang/Object")

var Lit_65 *jrt.String = jrt.Intern("arbace.classes.go$constructors")

var Lit_66 *jrt.String = jrt.Intern("arbace.classes.go$eval1797000004$loading__1927001464__auto____1797000005")

var Lit_67 *jrt.String = jrt.Intern("arbace.classes.go$eval1797000008$fn__1797000009")

var Lit_68 *jrt.String = jrt.Intern("arbace.classes.go$fn__1797000023")

var Lit_69 *jrt.String = jrt.Intern("arbace.lang.Compiler$CFGo")

var Lit_70 *jrt.String = jrt.Intern("arbace.classes.go$fn__1797000025")

var Lit_71 *jrt.String = jrt.Intern("arbace/classes/generics.edn")

var Lit_72 *jrt.String = jrt.Intern("arbace.classes.go$generics")

var Lit_73 *jrt.String = jrt.Intern("arbace.classes.go$generics$raw__1797000028")

var Lit_74 *jrt.String = jrt.Intern("arbace.classes.go$generics$raw__1797000028$iter__1797000029__1797000033")

var Lit_75 *jrt.String = jrt.Intern("arbace.classes.go$generics$raw__1797000028$iter__1797000029__1797000033$fn__1797000034")

var Lit_76 *jrt.String = jrt.Intern("arbace.classes.go$generics$raw__1797000028$iter__1797000029__1797000033$fn__1797000034$fn__1797000035")

var Lit_77 *jrt.String = jrt.Intern("arbace.classes.go$generics$raw__1797000028$iter__1797000029__1797000033$fn__1797000034$fn__1797000035$fn__1797000036")

var Lit_78 *jrt.String = jrt.Intern(".")

var Lit_79 *jrt.String = jrt.Intern("/")

var Lit_80 *jrt.String = jrt.Intern("arbace.classes.go$generics$raw__1797000028$iter__1797000029__1797000033$fn__1797000034$fn__1797000039")

var Lit_81 *jrt.String = jrt.Intern("arbace.classes.go$newExceptionReference")

var Lit_82 *jrt.String = jrt.Intern("arbace.classes.go$newFormalParameterReference")

var Lit_83 *jrt.String = jrt.Intern("arbace.classes.go$newSuperTypeReference")

var Lit_84 *jrt.String = jrt.Intern("arbace.classes.go$newTryCatchReference")

var Lit_85 *jrt.String = jrt.Intern("arbace.classes.go$newTypeArgumentReference")

var Lit_86 *jrt.String = jrt.Intern("arbace.classes.go$newTypeParameterBoundReference")

var Lit_87 *jrt.String = jrt.Intern("arbace.classes.go$newTypeParameterReference")

var Lit_88 *jrt.String = jrt.Intern("arbace.classes.go$newTypeReference")

var Lit_89 *jrt.String = jrt.Intern("arbace.classes.go$tref")

var Lit_90 *jrt.String = jrt.Intern("in-ns")

var Lit_91 *jrt.String = jrt.Intern("private")

var Lit_92 *jrt.String = jrt.Intern("arglists")

var Lit_93 *jrt.String = jrt.Intern("v")

var Lit_94 *jrt.String = jrt.Intern("tag")

var Lit_95 *jrt.String = jrt.Intern("long")

var Lit_96 *jrt.String = jrt.Intern("line")

var Lit_97 *jrt.String = jrt.Intern("column")

var Lit_98 *jrt.String = jrt.Intern("file")

var Lit_99 *jrt.String = jrt.Intern("arbace/classes/go.ae")

var Lit_100 *jrt.String = jrt.Intern("CLASS_TYPE_PARAMETER")

var Lit_101 *jrt.String = jrt.Intern("METHOD_TYPE_PARAMETER")

var Lit_102 *jrt.String = jrt.Intern("CLASS_TYPE_PARAMETER_BOUND")

var Lit_103 *jrt.String = jrt.Intern("METHOD_TYPE_PARAMETER_BOUND")

var Lit_104 *jrt.String = jrt.Intern("FIELD")

var Lit_105 *jrt.String = jrt.Intern("METHOD_RETURN")

var Lit_106 *jrt.String = jrt.Intern("METHOD_RECEIVER")

var Lit_107 *jrt.String = jrt.Intern("LOCAL_VARIABLE")

var Lit_108 *jrt.String = jrt.Intern("RESOURCE_VARIABLE")

var Lit_109 *jrt.String = jrt.Intern("INSTANCEOF")

var Lit_110 *jrt.String = jrt.Intern("NEW")

var Lit_111 *jrt.String = jrt.Intern("CONSTRUCTOR_REFERENCE")

var Lit_112 *jrt.String = jrt.Intern("METHOD_REFERENCE")

var Lit_113 *jrt.String = jrt.Intern("CAST")

var Lit_114 *jrt.String = jrt.Intern("CONSTRUCTOR_INVOCATION_TYPE_ARGUMENT")

var Lit_115 *jrt.String = jrt.Intern("METHOD_INVOCATION_TYPE_ARGUMENT")

var Lit_116 *jrt.String = jrt.Intern("CONSTRUCTOR_REFERENCE_TYPE_ARGUMENT")

var Lit_117 *jrt.String = jrt.Intern("METHOD_REFERENCE_TYPE_ARGUMENT")

var Lit_118 *jrt.String = jrt.Intern("newTypeReference")

var Lit_119 *jrt.String = jrt.Intern("sort")

var Lit_120 *jrt.String = jrt.Intern("newTypeParameterReference")

var Lit_121 *jrt.String = jrt.Intern("i")

var Lit_122 *jrt.String = jrt.Intern("newTypeParameterBoundReference")

var Lit_123 *jrt.String = jrt.Intern("p")

var Lit_124 *jrt.String = jrt.Intern("b")

var Lit_125 *jrt.String = jrt.Intern("newSuperTypeReference")

var Lit_126 *jrt.String = jrt.Intern("newFormalParameterReference")

var Lit_127 *jrt.String = jrt.Intern("newExceptionReference")

var Lit_128 *jrt.String = jrt.Intern("newTryCatchReference")

var Lit_129 *jrt.String = jrt.Intern("newTypeArgumentReference")

var Lit_130 *jrt.String = jrt.Intern("go-build?")

var Lit_131 *jrt.String = jrt.Intern("Is this the Go build? The front end runs there (the class forms at the REPL, a2g on the\n  tools' host) and on the frozen JVM Arbace (j2a, the edge's recording: doc/STANDALONE-NOTES.md,\n  \"S4: the JVM removed\"), which reflects on the JVM's classes where the Go build reads the\n  world's signatures. The Go build's class forms host, arbace.lang.Compiler$CFGo, is its mark.")

var Lit_132 *jrt.String = jrt.Intern("generics")

var Lit_133 *jrt.String = jrt.Intern("n")

var Lit_134 *jrt.String = jrt.Intern("c")

var Lit_135 *jrt.String = jrt.Intern("Class")

var Lit_136 *jrt.String = jrt.Intern("arbace.classes.analyze/class-generics of class n (Class c), which is not being compiled: from\n  the world's generic signatures when n is generic or has generic supertypes, else its erased\n  view by reflection.")

var Lit_137 *jrt.String = jrt.Intern("constructors")

var Lit_138 *jrt.String = jrt.Intern("The constructors [[descriptor flags]] of class n (internal name), which jrt's reflection does\n  not list for abstract classes: from the world's signatures, else Enum's and Record's.")
