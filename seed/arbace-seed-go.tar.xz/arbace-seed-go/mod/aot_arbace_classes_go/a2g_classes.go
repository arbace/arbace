//line a2g_classes.ae:1
package aot_arbace_classes_go

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_classes_go_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_go_A_New()}; return nil }

var A_arbace_classes_go_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_go_A_new}

var A_arbace_classes_go_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.go", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_A"})

func init() { i := A_arbace_classes_go_A_class.Info(); i.IsInstance = A_arbace_classes_go_A_InstanceOf; i.Init = A_arbace_classes_go_A_Init; i.Table = A_arbace_classes_go_A_members; jrt.RegisterGoType(A_arbace_classes_go_A_class, reflect.TypeFor[A_arbace_classes_go_A]()) }

func A_arbace_classes_go_constructors_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_go_constructors_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_go_constructors_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_go_constructors_A_New()}; return nil }

func A_arbace_classes_go_constructors_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_go_constructors_A_fn_class)}; return nil }

var A_arbace_classes_go_constructors_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_go_constructors_A_invoke, New: A_arbace_classes_go_constructors_A_new, Get: A_arbace_classes_go_constructors_A_get}

var A_arbace_classes_go_constructors_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.go$constructors", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_go_A_class, Simple: "constructors", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_constructors_A", Source: "go.ae"})

func init() { i := A_arbace_classes_go_constructors_A_class.Info(); i.IsInstance = A_arbace_classes_go_constructors_A_InstanceOf; i.Init = A_arbace_classes_go_constructors_A_Init; i.Table = A_arbace_classes_go_constructors_A_members; jrt.RegisterGoType(A_arbace_classes_go_constructors_A_class, reflect.TypeFor[A_arbace_classes_go_constructors_A]()) }

func A_arbace_classes_go_eval1797000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_go_eval1797000004_A_New()}; return nil }

var A_arbace_classes_go_eval1797000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_go_eval1797000004_A_new}

var A_arbace_classes_go_eval1797000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.go$eval1797000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_go_A_class, Simple: "eval1797000004", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_eval1797000004_A"})

func init() { i := A_arbace_classes_go_eval1797000004_A_class.Info(); i.IsInstance = A_arbace_classes_go_eval1797000004_A_InstanceOf; i.Table = A_arbace_classes_go_eval1797000004_A_members; jrt.RegisterGoType(A_arbace_classes_go_eval1797000004_A_class, reflect.TypeFor[A_arbace_classes_go_eval1797000004_A]()) }

func A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_New()}; return nil }

func A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_fn_class)}; return nil }

var A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_invoke, New: A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_new, Get: A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_get}

var A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.go$eval1797000004$loading__1927001464__auto____1797000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_go_eval1797000004_A_class, Simple: "loading__1927001464__auto____1797000005", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A", Source: "go.ae"})

func init() { i := A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_class.Info(); i.IsInstance = A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_InstanceOf; i.Init = A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_Init; i.Table = A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_members; jrt.RegisterGoType(A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A_class, reflect.TypeFor[A_arbace_classes_go_eval1797000004_loading__1927001464__auto____1797000005_A]()) }

func A_arbace_classes_go_eval1797000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_go_eval1797000008_A_New()}; return nil }

var A_arbace_classes_go_eval1797000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_go_eval1797000008_A_new}

var A_arbace_classes_go_eval1797000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.go$eval1797000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_go_A_class, Simple: "eval1797000008", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_eval1797000008_A"})

func init() { i := A_arbace_classes_go_eval1797000008_A_class.Info(); i.IsInstance = A_arbace_classes_go_eval1797000008_A_InstanceOf; i.Table = A_arbace_classes_go_eval1797000008_A_members; jrt.RegisterGoType(A_arbace_classes_go_eval1797000008_A_class, reflect.TypeFor[A_arbace_classes_go_eval1797000008_A]()) }

func A_arbace_classes_go_eval1797000008_fn__1797000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_go_eval1797000008_fn__1797000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_go_eval1797000008_fn__1797000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_go_eval1797000008_fn__1797000009_A_New()}; return nil }

func A_arbace_classes_go_eval1797000008_fn__1797000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_go_eval1797000008_fn__1797000009_A_fn_class)}; return nil }

var A_arbace_classes_go_eval1797000008_fn__1797000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_go_eval1797000008_fn__1797000009_A_invoke, New: A_arbace_classes_go_eval1797000008_fn__1797000009_A_new, Get: A_arbace_classes_go_eval1797000008_fn__1797000009_A_get}

var A_arbace_classes_go_eval1797000008_fn__1797000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.go$eval1797000008$fn__1797000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_go_eval1797000008_A_class, Simple: "fn__1797000009", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_eval1797000008_fn__1797000009_A", Source: "go.ae"})

func init() { i := A_arbace_classes_go_eval1797000008_fn__1797000009_A_class.Info(); i.IsInstance = A_arbace_classes_go_eval1797000008_fn__1797000009_A_InstanceOf; i.Init = A_arbace_classes_go_eval1797000008_fn__1797000009_A_Init; i.Table = A_arbace_classes_go_eval1797000008_fn__1797000009_A_members; jrt.RegisterGoType(A_arbace_classes_go_eval1797000008_fn__1797000009_A_class, reflect.TypeFor[A_arbace_classes_go_eval1797000008_fn__1797000009_A]()) }

func A_arbace_classes_go_fn__1797000023_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_go_fn__1797000023_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_go_fn__1797000023_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_go_fn__1797000023_A_New()}; return nil }

func A_arbace_classes_go_fn__1797000023_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_go_fn__1797000023_A_fn_class)}; return nil }

var A_arbace_classes_go_fn__1797000023_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_go_fn__1797000023_A_invoke, New: A_arbace_classes_go_fn__1797000023_A_new, Get: A_arbace_classes_go_fn__1797000023_A_get}

var A_arbace_classes_go_fn__1797000023_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.go$fn__1797000023", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_go_A_class, Simple: "fn__1797000023", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_fn__1797000023_A", Source: "go.ae"})

func init() { i := A_arbace_classes_go_fn__1797000023_A_class.Info(); i.IsInstance = A_arbace_classes_go_fn__1797000023_A_InstanceOf; i.Init = A_arbace_classes_go_fn__1797000023_A_Init; i.Table = A_arbace_classes_go_fn__1797000023_A_members; jrt.RegisterGoType(A_arbace_classes_go_fn__1797000023_A_class, reflect.TypeFor[A_arbace_classes_go_fn__1797000023_A]()) }

func A_arbace_classes_go_fn__1797000025_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_go_fn__1797000025_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_go_fn__1797000025_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_go_fn__1797000025_A_New()}; return nil }

func A_arbace_classes_go_fn__1797000025_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_go_fn__1797000025_A_fn_class)}; return nil }

var A_arbace_classes_go_fn__1797000025_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_go_fn__1797000025_A_invoke, New: A_arbace_classes_go_fn__1797000025_A_new, Get: A_arbace_classes_go_fn__1797000025_A_get}

var A_arbace_classes_go_fn__1797000025_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.go$fn__1797000025", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_go_A_class, Simple: "fn__1797000025", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_fn__1797000025_A", Source: "go.ae"})

func init() { i := A_arbace_classes_go_fn__1797000025_A_class.Info(); i.IsInstance = A_arbace_classes_go_fn__1797000025_A_InstanceOf; i.Init = A_arbace_classes_go_fn__1797000025_A_Init; i.Table = A_arbace_classes_go_fn__1797000025_A_members; jrt.RegisterGoType(A_arbace_classes_go_fn__1797000025_A_class, reflect.TypeFor[A_arbace_classes_go_fn__1797000025_A]()) }

func A_arbace_classes_go_generics_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_go_generics_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_go_generics_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_go_generics_A_New()}; return nil }

func A_arbace_classes_go_generics_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_go_generics_A_fn_class)}; return nil }

var A_arbace_classes_go_generics_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_go_generics_A_invoke, New: A_arbace_classes_go_generics_A_new, Get: A_arbace_classes_go_generics_A_get}

var A_arbace_classes_go_generics_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.go$generics", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_go_A_class, Simple: "generics", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_generics_A", Source: "go.ae"})

func init() { i := A_arbace_classes_go_generics_A_class.Info(); i.IsInstance = A_arbace_classes_go_generics_A_InstanceOf; i.Init = A_arbace_classes_go_generics_A_Init; i.Table = A_arbace_classes_go_generics_A_members; jrt.RegisterGoType(A_arbace_classes_go_generics_A_class, reflect.TypeFor[A_arbace_classes_go_generics_A]()) }

func A_arbace_classes_go_generics_raw__1797000028_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_go_generics_raw__1797000028_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_go_generics_raw__1797000028_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_go_generics_raw__1797000028_A_New_O(args[0])}; return nil }

func A_arbace_classes_go_generics_raw__1797000028_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_go_generics_raw__1797000028_A_fn_class)}; return nil }

var A_arbace_classes_go_generics_raw__1797000028_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_go_generics_raw__1797000028_A_invoke, New: A_arbace_classes_go_generics_raw__1797000028_A_new, Get: A_arbace_classes_go_generics_raw__1797000028_A_get}

var A_arbace_classes_go_generics_raw__1797000028_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.go$generics$raw__1797000028", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_go_generics_A_class, Simple: "raw__1797000028", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_generics_raw__1797000028_A", Source: "go.ae"})

func init() { i := A_arbace_classes_go_generics_raw__1797000028_A_class.Info(); i.IsInstance = A_arbace_classes_go_generics_raw__1797000028_A_InstanceOf; i.Init = A_arbace_classes_go_generics_raw__1797000028_A_Init; i.Table = A_arbace_classes_go_generics_raw__1797000028_A_members; jrt.RegisterGoType(A_arbace_classes_go_generics_raw__1797000028_A_class, reflect.TypeFor[A_arbace_classes_go_generics_raw__1797000028_A]()) }

func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_New()}; return nil }

func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_fn_class)}; return nil }

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_invoke, New: A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_new, Get: A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_get}

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.go$generics$raw__1797000028$iter__1797000029__1797000033", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_go_generics_raw__1797000028_A_class, Simple: "iter__1797000029__1797000033", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A", Source: "go.ae"})

func init() { i := A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_class.Info(); i.IsInstance = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_InstanceOf; i.Init = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_Init; i.Table = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_members; jrt.RegisterGoType(A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_class, reflect.TypeFor[A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A]()) }

func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_fn_class)}; return nil }

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_invoke, New: A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_new, Get: A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_get}

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.go$generics$raw__1797000028$iter__1797000029__1797000033$fn__1797000034", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_A_class, Simple: "fn__1797000034", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A", Source: "go.ae"})

func init() { i := A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_class.Info(); i.IsInstance = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_InstanceOf; i.Init = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_Init; i.Table = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_members; jrt.RegisterGoType(A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_class, reflect.TypeFor[A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A]()) }

func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_New_I_O_O(args[0].(int32), args[1], args[2])}; return nil }

func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_fn_class)}; return nil }

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_invoke, New: A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_new, Get: A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_get}

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.go$generics$raw__1797000028$iter__1797000029__1797000033$fn__1797000034$fn__1797000035", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_class, Simple: "fn__1797000035", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A", Source: "go.ae"})

func init() { i := A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_class.Info(); i.IsInstance = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_InstanceOf; i.Init = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_Init; i.Table = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_members; jrt.RegisterGoType(A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_class, reflect.TypeFor[A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A]()) }

func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_New()}; return nil }

func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_fn_class)}; return nil }

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_invoke, New: A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_new, Get: A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_get}

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.go$generics$raw__1797000028$iter__1797000029__1797000033$fn__1797000034$fn__1797000035$fn__1797000036", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_A_class, Simple: "fn__1797000036", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A", Source: "go.ae"})

func init() { i := A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_class.Info(); i.IsInstance = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_InstanceOf; i.Init = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_Init; i.Table = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_members; jrt.RegisterGoType(A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A_class, reflect.TypeFor[A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000035_fn__1797000036_A]()) }

func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_New()}; return nil }

func A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_fn_class)}; return nil }

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_invoke, New: A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_new, Get: A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_get}

var A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.go$generics$raw__1797000028$iter__1797000029__1797000033$fn__1797000034$fn__1797000039", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_A_class, Simple: "fn__1797000039", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A", Source: "go.ae"})

func init() { i := A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_class.Info(); i.IsInstance = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_InstanceOf; i.Init = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_Init; i.Table = A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_members; jrt.RegisterGoType(A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A_class, reflect.TypeFor[A_arbace_classes_go_generics_raw__1797000028_iter__1797000029__1797000033_fn__1797000034_fn__1797000039_A]()) }

func A_arbace_classes_go_newExceptionReference_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_go_newExceptionReference_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_go_newExceptionReference_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_go_newExceptionReference_A_New()}; return nil }

func A_arbace_classes_go_newExceptionReference_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_go_newExceptionReference_A_fn_class)}; return nil }

var A_arbace_classes_go_newExceptionReference_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_go_newExceptionReference_A_invoke, New: A_arbace_classes_go_newExceptionReference_A_new, Get: A_arbace_classes_go_newExceptionReference_A_get}

var A_arbace_classes_go_newExceptionReference_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.go$newExceptionReference", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_go_A_class, Simple: "newExceptionReference", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_newExceptionReference_A", Source: "go.ae"})

func init() { i := A_arbace_classes_go_newExceptionReference_A_class.Info(); i.IsInstance = A_arbace_classes_go_newExceptionReference_A_InstanceOf; i.Init = A_arbace_classes_go_newExceptionReference_A_Init; i.Table = A_arbace_classes_go_newExceptionReference_A_members; jrt.RegisterGoType(A_arbace_classes_go_newExceptionReference_A_class, reflect.TypeFor[A_arbace_classes_go_newExceptionReference_A]()) }

func A_arbace_classes_go_newFormalParameterReference_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_go_newFormalParameterReference_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_go_newFormalParameterReference_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_go_newFormalParameterReference_A_New()}; return nil }

func A_arbace_classes_go_newFormalParameterReference_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_go_newFormalParameterReference_A_fn_class)}; return nil }

var A_arbace_classes_go_newFormalParameterReference_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_go_newFormalParameterReference_A_invoke, New: A_arbace_classes_go_newFormalParameterReference_A_new, Get: A_arbace_classes_go_newFormalParameterReference_A_get}

var A_arbace_classes_go_newFormalParameterReference_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.go$newFormalParameterReference", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_go_A_class, Simple: "newFormalParameterReference", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_newFormalParameterReference_A", Source: "go.ae"})

func init() { i := A_arbace_classes_go_newFormalParameterReference_A_class.Info(); i.IsInstance = A_arbace_classes_go_newFormalParameterReference_A_InstanceOf; i.Init = A_arbace_classes_go_newFormalParameterReference_A_Init; i.Table = A_arbace_classes_go_newFormalParameterReference_A_members; jrt.RegisterGoType(A_arbace_classes_go_newFormalParameterReference_A_class, reflect.TypeFor[A_arbace_classes_go_newFormalParameterReference_A]()) }

func A_arbace_classes_go_newSuperTypeReference_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_go_newSuperTypeReference_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_go_newSuperTypeReference_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_go_newSuperTypeReference_A_New()}; return nil }

func A_arbace_classes_go_newSuperTypeReference_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_go_newSuperTypeReference_A_fn_class)}; return nil }

var A_arbace_classes_go_newSuperTypeReference_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_go_newSuperTypeReference_A_invoke, New: A_arbace_classes_go_newSuperTypeReference_A_new, Get: A_arbace_classes_go_newSuperTypeReference_A_get}

var A_arbace_classes_go_newSuperTypeReference_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.go$newSuperTypeReference", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_go_A_class, Simple: "newSuperTypeReference", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_newSuperTypeReference_A", Source: "go.ae"})

func init() { i := A_arbace_classes_go_newSuperTypeReference_A_class.Info(); i.IsInstance = A_arbace_classes_go_newSuperTypeReference_A_InstanceOf; i.Init = A_arbace_classes_go_newSuperTypeReference_A_Init; i.Table = A_arbace_classes_go_newSuperTypeReference_A_members; jrt.RegisterGoType(A_arbace_classes_go_newSuperTypeReference_A_class, reflect.TypeFor[A_arbace_classes_go_newSuperTypeReference_A]()) }

func A_arbace_classes_go_newTryCatchReference_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_go_newTryCatchReference_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_go_newTryCatchReference_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_go_newTryCatchReference_A_New()}; return nil }

func A_arbace_classes_go_newTryCatchReference_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_go_newTryCatchReference_A_fn_class)}; return nil }

var A_arbace_classes_go_newTryCatchReference_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_go_newTryCatchReference_A_invoke, New: A_arbace_classes_go_newTryCatchReference_A_new, Get: A_arbace_classes_go_newTryCatchReference_A_get}

var A_arbace_classes_go_newTryCatchReference_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.go$newTryCatchReference", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_go_A_class, Simple: "newTryCatchReference", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_newTryCatchReference_A", Source: "go.ae"})

func init() { i := A_arbace_classes_go_newTryCatchReference_A_class.Info(); i.IsInstance = A_arbace_classes_go_newTryCatchReference_A_InstanceOf; i.Init = A_arbace_classes_go_newTryCatchReference_A_Init; i.Table = A_arbace_classes_go_newTryCatchReference_A_members; jrt.RegisterGoType(A_arbace_classes_go_newTryCatchReference_A_class, reflect.TypeFor[A_arbace_classes_go_newTryCatchReference_A]()) }

func A_arbace_classes_go_newTypeArgumentReference_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_go_newTypeArgumentReference_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_go_newTypeArgumentReference_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_go_newTypeArgumentReference_A_New()}; return nil }

func A_arbace_classes_go_newTypeArgumentReference_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_go_newTypeArgumentReference_A_fn_class)}; return nil }

var A_arbace_classes_go_newTypeArgumentReference_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_go_newTypeArgumentReference_A_invoke, New: A_arbace_classes_go_newTypeArgumentReference_A_new, Get: A_arbace_classes_go_newTypeArgumentReference_A_get}

var A_arbace_classes_go_newTypeArgumentReference_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.go$newTypeArgumentReference", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_go_A_class, Simple: "newTypeArgumentReference", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_newTypeArgumentReference_A", Source: "go.ae"})

func init() { i := A_arbace_classes_go_newTypeArgumentReference_A_class.Info(); i.IsInstance = A_arbace_classes_go_newTypeArgumentReference_A_InstanceOf; i.Init = A_arbace_classes_go_newTypeArgumentReference_A_Init; i.Table = A_arbace_classes_go_newTypeArgumentReference_A_members; jrt.RegisterGoType(A_arbace_classes_go_newTypeArgumentReference_A_class, reflect.TypeFor[A_arbace_classes_go_newTypeArgumentReference_A]()) }

func A_arbace_classes_go_newTypeParameterBoundReference_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_go_newTypeParameterBoundReference_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_go_newTypeParameterBoundReference_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_go_newTypeParameterBoundReference_A_New()}; return nil }

func A_arbace_classes_go_newTypeParameterBoundReference_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_go_newTypeParameterBoundReference_A_fn_class)}; return nil }

var A_arbace_classes_go_newTypeParameterBoundReference_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_go_newTypeParameterBoundReference_A_invoke, New: A_arbace_classes_go_newTypeParameterBoundReference_A_new, Get: A_arbace_classes_go_newTypeParameterBoundReference_A_get}

var A_arbace_classes_go_newTypeParameterBoundReference_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.go$newTypeParameterBoundReference", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_classes_go_A_class, Simple: "newTypeParameterBoundReference", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_newTypeParameterBoundReference_A", Source: "go.ae"})

func init() { i := A_arbace_classes_go_newTypeParameterBoundReference_A_class.Info(); i.IsInstance = A_arbace_classes_go_newTypeParameterBoundReference_A_InstanceOf; i.Init = A_arbace_classes_go_newTypeParameterBoundReference_A_Init; i.Table = A_arbace_classes_go_newTypeParameterBoundReference_A_members; jrt.RegisterGoType(A_arbace_classes_go_newTypeParameterBoundReference_A_class, reflect.TypeFor[A_arbace_classes_go_newTypeParameterBoundReference_A]()) }

func A_arbace_classes_go_newTypeParameterReference_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_go_newTypeParameterReference_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_go_newTypeParameterReference_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_go_newTypeParameterReference_A_New()}; return nil }

func A_arbace_classes_go_newTypeParameterReference_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_go_newTypeParameterReference_A_fn_class)}; return nil }

var A_arbace_classes_go_newTypeParameterReference_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_go_newTypeParameterReference_A_invoke, New: A_arbace_classes_go_newTypeParameterReference_A_new, Get: A_arbace_classes_go_newTypeParameterReference_A_get}

var A_arbace_classes_go_newTypeParameterReference_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.go$newTypeParameterReference", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_go_A_class, Simple: "newTypeParameterReference", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_newTypeParameterReference_A", Source: "go.ae"})

func init() { i := A_arbace_classes_go_newTypeParameterReference_A_class.Info(); i.IsInstance = A_arbace_classes_go_newTypeParameterReference_A_InstanceOf; i.Init = A_arbace_classes_go_newTypeParameterReference_A_Init; i.Table = A_arbace_classes_go_newTypeParameterReference_A_members; jrt.RegisterGoType(A_arbace_classes_go_newTypeParameterReference_A_class, reflect.TypeFor[A_arbace_classes_go_newTypeParameterReference_A]()) }

func A_arbace_classes_go_newTypeReference_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_go_newTypeReference_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_go_newTypeReference_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_go_newTypeReference_A_New()}; return nil }

func A_arbace_classes_go_newTypeReference_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_go_newTypeReference_A_fn_class)}; return nil }

var A_arbace_classes_go_newTypeReference_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_go_newTypeReference_A_invoke, New: A_arbace_classes_go_newTypeReference_A_new, Get: A_arbace_classes_go_newTypeReference_A_get}

var A_arbace_classes_go_newTypeReference_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.go$newTypeReference", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_go_A_class, Simple: "newTypeReference", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_newTypeReference_A", Source: "go.ae"})

func init() { i := A_arbace_classes_go_newTypeReference_A_class.Info(); i.IsInstance = A_arbace_classes_go_newTypeReference_A_InstanceOf; i.Init = A_arbace_classes_go_newTypeReference_A_Init; i.Table = A_arbace_classes_go_newTypeReference_A_members; jrt.RegisterGoType(A_arbace_classes_go_newTypeReference_A_class, reflect.TypeFor[A_arbace_classes_go_newTypeReference_A]()) }

func A_arbace_classes_go_tref_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_go_tref_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_go_tref_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_go_tref_A_New()}; return nil }

func A_arbace_classes_go_tref_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_go_tref_A_fn_class)}; return nil }

var A_arbace_classes_go_tref_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_go_tref_A_invoke, New: A_arbace_classes_go_tref_A_new, Get: A_arbace_classes_go_tref_A_get}

var A_arbace_classes_go_tref_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.go$tref", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_go_A_class, Simple: "tref", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_tref_A", Source: "go.ae"})

func init() { i := A_arbace_classes_go_tref_A_class.Info(); i.IsInstance = A_arbace_classes_go_tref_A_InstanceOf; i.Init = A_arbace_classes_go_tref_A_Init; i.Table = A_arbace_classes_go_tref_A_members; jrt.RegisterGoType(A_arbace_classes_go_tref_A_class, reflect.TypeFor[A_arbace_classes_go_tref_A]()) }

func A_arbace_classes_go_tref_reify__1797000012_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_go_tref_reify__1797000012_A).GetKey__O(); case 1: return this.(*A_arbace_classes_go_tref_reify__1797000012_A).GetValue__O(); case 2: return this.(*A_arbace_classes_go_tref_reify__1797000012_A).Meta__IPersistentMap(); case 3: return this.(*A_arbace_classes_go_tref_reify__1797000012_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0]))}; return nil }

func A_arbace_classes_go_tref_reify__1797000012_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_go_tref_reify__1797000012_A_New_IPersistentMap_J(jrt.As[lang.IPersistentMap](args[0]), args[1].(int64))}; return nil }

var A_arbace_classes_go_tref_reify__1797000012_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 getKey ()Ljava.lang.Object;\nM1 getValue ()Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nC1 (Larbace.lang.IPersistentMap;J)V", Invoke: A_arbace_classes_go_tref_reify__1797000012_A_invoke, New: A_arbace_classes_go_tref_reify__1797000012_A_new}

var A_arbace_classes_go_tref_reify__1797000012_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.go$tref$reify__1797000012", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{jrt.Map_Entry_class, lang.IObj_class}, Declaring: A_arbace_classes_go_tref_A_class, Simple: "reify__1797000012", Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go_tref_reify__1797000012_A", Source: "go.ae"})

func init() { i := A_arbace_classes_go_tref_reify__1797000012_A_class.Info(); i.IsInstance = A_arbace_classes_go_tref_reify__1797000012_A_InstanceOf; i.Table = A_arbace_classes_go_tref_reify__1797000012_A_members; jrt.RegisterGoType(A_arbace_classes_go_tref_reify__1797000012_A_class, reflect.TypeFor[A_arbace_classes_go_tref_reify__1797000012_A]()) }

func A_arbace_classes_go__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_classes_go__init_A_Load__O(); case 1: return A_arbace_classes_go__init_A_Unit0__O(); case 2: return A_arbace_classes_go__init_A_Unit1__O(); case 3: return A_arbace_classes_go__init_A_Unit10__O(); case 4: return A_arbace_classes_go__init_A_Unit11__O(); case 5: return A_arbace_classes_go__init_A_Unit12__O(); case 6: return A_arbace_classes_go__init_A_Unit13__O(); case 7: return A_arbace_classes_go__init_A_Unit14__O(); case 8: return A_arbace_classes_go__init_A_Unit15__O(); case 9: return A_arbace_classes_go__init_A_Unit16__O(); case 10: return A_arbace_classes_go__init_A_Unit17__O(); case 11: return A_arbace_classes_go__init_A_Unit18__O(); case 12: return A_arbace_classes_go__init_A_Unit19__O(); case 13: return A_arbace_classes_go__init_A_Unit2__O(); case 14: return A_arbace_classes_go__init_A_Unit20__O(); case 15: return A_arbace_classes_go__init_A_Unit21__O(); case 16: return A_arbace_classes_go__init_A_Unit22__O(); case 17: return A_arbace_classes_go__init_A_Unit23__O(); case 18: return A_arbace_classes_go__init_A_Unit24__O(); case 19: return A_arbace_classes_go__init_A_Unit25__O(); case 20: return A_arbace_classes_go__init_A_Unit26__O(); case 21: return A_arbace_classes_go__init_A_Unit27__O(); case 22: return A_arbace_classes_go__init_A_Unit28__O(); case 23: return A_arbace_classes_go__init_A_Unit29__O(); case 24: return A_arbace_classes_go__init_A_Unit3__O(); case 25: return A_arbace_classes_go__init_A_Unit30__O(); case 26: return A_arbace_classes_go__init_A_Unit31__O(); case 27: return A_arbace_classes_go__init_A_Unit32__O(); case 28: return A_arbace_classes_go__init_A_Unit33__O(); case 29: return A_arbace_classes_go__init_A_Unit34__O(); case 30: return A_arbace_classes_go__init_A_Unit35__O(); case 31: return A_arbace_classes_go__init_A_Unit36__O(); case 32: return A_arbace_classes_go__init_A_Unit37__O(); case 33: return A_arbace_classes_go__init_A_Unit38__O(); case 34: return A_arbace_classes_go__init_A_Unit4__O(); case 35: return A_arbace_classes_go__init_A_Unit5__O(); case 36: return A_arbace_classes_go__init_A_Unit6__O(); case 37: return A_arbace_classes_go__init_A_Unit7__O(); case 38: return A_arbace_classes_go__init_A_Unit8__O(); case 39: return A_arbace_classes_go__init_A_Unit9__O()}; return nil }

func A_arbace_classes_go__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_go__init_A_New()}; return nil }

var A_arbace_classes_go__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit28 ()Ljava.lang.Object;\nM9 unit29 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit30 ()Ljava.lang.Object;\nM9 unit31 ()Ljava.lang.Object;\nM9 unit32 ()Ljava.lang.Object;\nM9 unit33 ()Ljava.lang.Object;\nM9 unit34 ()Ljava.lang.Object;\nM9 unit35 ()Ljava.lang.Object;\nM9 unit36 ()Ljava.lang.Object;\nM9 unit37 ()Ljava.lang.Object;\nM9 unit38 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_classes_go__init_A_invoke, New: A_arbace_classes_go__init_A_new}

var A_arbace_classes_go__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.go__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_classes_go.A_arbace_classes_go__init_A", Source: "go.ae"})

func init() { i := A_arbace_classes_go__init_A_class.Info(); i.IsInstance = A_arbace_classes_go__init_A_InstanceOf; i.Init = A_arbace_classes_go__init_A_Init; i.Table = A_arbace_classes_go__init_A_members; jrt.RegisterGoType(A_arbace_classes_go__init_A_class, reflect.TypeFor[A_arbace_classes_go__init_A]()) }
