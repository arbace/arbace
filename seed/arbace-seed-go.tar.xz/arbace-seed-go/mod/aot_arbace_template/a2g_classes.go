//line a2g_classes.ae:1
package aot_arbace_template

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_template_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_template_A_New()}; return nil }

var A_arbace_template_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_template_A_new}

var A_arbace_template_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.template", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_template.A_arbace_template_A"})

func init() { i := A_arbace_template_A_class.Info(); i.IsInstance = A_arbace_template_A_InstanceOf; i.Init = A_arbace_template_A_Init; i.Table = A_arbace_template_A_members; jrt.RegisterGoType(A_arbace_template_A_class, reflect.TypeFor[A_arbace_template_A]()) }

func A_arbace_template_apply_template_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_template_apply_template_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_template_apply_template_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_template_apply_template_A_New()}; return nil }

func A_arbace_template_apply_template_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_template_apply_template_A_fn_class)}; return nil }

var A_arbace_template_apply_template_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_template_apply_template_A_invoke, New: A_arbace_template_apply_template_A_new, Get: A_arbace_template_apply_template_A_get}

var A_arbace_template_apply_template_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.template$apply_template", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_template_A_class, Simple: "apply_template", Go: "arbace/aot_arbace_template.A_arbace_template_apply_template_A", Source: "template.ae"})

func init() { i := A_arbace_template_apply_template_A_class.Info(); i.IsInstance = A_arbace_template_apply_template_A_InstanceOf; i.Init = A_arbace_template_apply_template_A_Init; i.Table = A_arbace_template_apply_template_A_members; jrt.RegisterGoType(A_arbace_template_apply_template_A_class, reflect.TypeFor[A_arbace_template_apply_template_A]()) }

func A_arbace_template_do_template_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_template_do_template_A).DoInvoke_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_template_do_template_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_template_do_template_A_New()}; return nil }

func A_arbace_template_do_template_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_template_do_template_A_fn_class)}; return nil }

var A_arbace_template_do_template_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_template_do_template_A_invoke, New: A_arbace_template_do_template_A_new, Get: A_arbace_template_do_template_A_get}

var A_arbace_template_do_template_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.template$do_template", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR4_class}, Declaring: A_arbace_template_A_class, Simple: "do_template", Go: "arbace/aot_arbace_template.A_arbace_template_do_template_A", Source: "template.ae"})

func init() { i := A_arbace_template_do_template_A_class.Info(); i.IsInstance = A_arbace_template_do_template_A_InstanceOf; i.Init = A_arbace_template_do_template_A_Init; i.Table = A_arbace_template_do_template_A_members; jrt.RegisterGoType(A_arbace_template_do_template_A_class, reflect.TypeFor[A_arbace_template_do_template_A]()) }

func A_arbace_template_do_template_fn__348000013_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_template_do_template_fn__348000013_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_template_do_template_fn__348000013_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_template_do_template_fn__348000013_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_template_do_template_fn__348000013_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_template_do_template_fn__348000013_A_fn_class)}; return nil }

var A_arbace_template_do_template_fn__348000013_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_template_do_template_fn__348000013_A_invoke, New: A_arbace_template_do_template_fn__348000013_A_new, Get: A_arbace_template_do_template_fn__348000013_A_get}

var A_arbace_template_do_template_fn__348000013_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.template$do_template$fn__348000013", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_template_do_template_A_class, Simple: "fn__348000013", Go: "arbace/aot_arbace_template.A_arbace_template_do_template_fn__348000013_A", Source: "template.ae"})

func init() { i := A_arbace_template_do_template_fn__348000013_A_class.Info(); i.IsInstance = A_arbace_template_do_template_fn__348000013_A_InstanceOf; i.Init = A_arbace_template_do_template_fn__348000013_A_Init; i.Table = A_arbace_template_do_template_fn__348000013_A_members; jrt.RegisterGoType(A_arbace_template_do_template_fn__348000013_A_class, reflect.TypeFor[A_arbace_template_do_template_fn__348000013_A]()) }

func A_arbace_template_eval348000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_template_eval348000004_A_New()}; return nil }

var A_arbace_template_eval348000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_template_eval348000004_A_new}

var A_arbace_template_eval348000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.template$eval348000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_template_A_class, Simple: "eval348000004", Go: "arbace/aot_arbace_template.A_arbace_template_eval348000004_A"})

func init() { i := A_arbace_template_eval348000004_A_class.Info(); i.IsInstance = A_arbace_template_eval348000004_A_InstanceOf; i.Table = A_arbace_template_eval348000004_A_members; jrt.RegisterGoType(A_arbace_template_eval348000004_A_class, reflect.TypeFor[A_arbace_template_eval348000004_A]()) }

func A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_New()}; return nil }

func A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_fn_class)}; return nil }

var A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_invoke, New: A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_new, Get: A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_get}

var A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.template$eval348000004$loading__1927001464__auto____348000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_template_eval348000004_A_class, Simple: "loading__1927001464__auto____348000005", Go: "arbace/aot_arbace_template.A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A", Source: "template.ae"})

func init() { i := A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_class.Info(); i.IsInstance = A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_InstanceOf; i.Init = A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_Init; i.Table = A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_members; jrt.RegisterGoType(A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_class, reflect.TypeFor[A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A]()) }

func A_arbace_template_eval348000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_template_eval348000008_A_New()}; return nil }

var A_arbace_template_eval348000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_template_eval348000008_A_new}

var A_arbace_template_eval348000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.template$eval348000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_template_A_class, Simple: "eval348000008", Go: "arbace/aot_arbace_template.A_arbace_template_eval348000008_A"})

func init() { i := A_arbace_template_eval348000008_A_class.Info(); i.IsInstance = A_arbace_template_eval348000008_A_InstanceOf; i.Table = A_arbace_template_eval348000008_A_members; jrt.RegisterGoType(A_arbace_template_eval348000008_A_class, reflect.TypeFor[A_arbace_template_eval348000008_A]()) }

func A_arbace_template_eval348000008_fn__348000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_template_eval348000008_fn__348000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_template_eval348000008_fn__348000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_template_eval348000008_fn__348000009_A_New()}; return nil }

func A_arbace_template_eval348000008_fn__348000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_template_eval348000008_fn__348000009_A_fn_class)}; return nil }

var A_arbace_template_eval348000008_fn__348000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_template_eval348000008_fn__348000009_A_invoke, New: A_arbace_template_eval348000008_fn__348000009_A_new, Get: A_arbace_template_eval348000008_fn__348000009_A_get}

var A_arbace_template_eval348000008_fn__348000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.template$eval348000008$fn__348000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_template_eval348000008_A_class, Simple: "fn__348000009", Go: "arbace/aot_arbace_template.A_arbace_template_eval348000008_fn__348000009_A", Source: "template.ae"})

func init() { i := A_arbace_template_eval348000008_fn__348000009_A_class.Info(); i.IsInstance = A_arbace_template_eval348000008_fn__348000009_A_InstanceOf; i.Init = A_arbace_template_eval348000008_fn__348000009_A_Init; i.Table = A_arbace_template_eval348000008_fn__348000009_A_members; jrt.RegisterGoType(A_arbace_template_eval348000008_fn__348000009_A_class, reflect.TypeFor[A_arbace_template_eval348000008_fn__348000009_A]()) }

func A_arbace_template__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_template__init_A_Load__O(); case 1: return A_arbace_template__init_A_Unit0__O(); case 2: return A_arbace_template__init_A_Unit1__O(); case 3: return A_arbace_template__init_A_Unit2__O(); case 4: return A_arbace_template__init_A_Unit3__O(); case 5: return A_arbace_template__init_A_Unit4__O(); case 6: return A_arbace_template__init_A_Unit5__O(); case 7: return A_arbace_template__init_A_Unit6__O(); case 8: return A_arbace_template__init_A_Unit7__O()}; return nil }

func A_arbace_template__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_template__init_A_New()}; return nil }

var A_arbace_template__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_template__init_A_invoke, New: A_arbace_template__init_A_new}

var A_arbace_template__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.template__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_template.A_arbace_template__init_A", Source: "template.ae"})

func init() { i := A_arbace_template__init_A_class.Info(); i.IsInstance = A_arbace_template__init_A_InstanceOf; i.Init = A_arbace_template__init_A_Init; i.Table = A_arbace_template__init_A_members; jrt.RegisterGoType(A_arbace_template__init_A_class, reflect.TypeFor[A_arbace_template__init_A]()) }
