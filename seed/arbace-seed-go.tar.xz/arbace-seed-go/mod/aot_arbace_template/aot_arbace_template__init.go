//line aot_arbace_template__init.ae:1
package aot_arbace_template

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_template__init_A_Load__O() any { A_arbace_template__init_A_Init(); A_arbace_template__init_A_Unit0__O(); A_arbace_template__init_A_Unit1__O(); A_arbace_template__init_A_Unit2__O(); A_arbace_template__init_A_Unit3__O(); A_arbace_template__init_A_Unit4__O(); A_arbace_template__init_A_Unit5__O(); A_arbace_template__init_A_Unit6__O(); A_arbace_template__init_A_Unit7__O(); return nil }


















func A_arbace_template__init_A_Unit0__O() any { A_arbace_template__init_A_Init(); lang.Compiler_AOT_At_I_I__V(24, 1); return lang.IFn_Cast(jrt.NN(A_arbace_template__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_template__init_A_const_1) }
//line :24:1
func A_arbace_template__init_A_Unit1__O() any { A_arbace_template__init_A_Init(); lang.Compiler_AOT_At_I_I__V(24, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_template__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_template__init_A_const_2)) }
//line :24:1
func A_arbace_template__init_A_Unit2__O() any { A_arbace_template__init_A_Init(); lang.Compiler_AOT_At_I_I__V(24, 1); var tmp1 any = A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_New(); var tmp2 *jrt.Class; A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_Init(); tmp2 = A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :24:1
func A_arbace_template__init_A_Unit3__O() any { A_arbace_template__init_A_Init(); lang.Compiler_AOT_At_I_I__V(24, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_template__init_A_const_1)).Equals_O__Z(A_arbace_template__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_template_eval348000008_fn__348000009_A_New(); var tmp2 *jrt.Class; A_arbace_template_eval348000008_fn__348000009_A_Init(); tmp2 = A_arbace_template_eval348000008_fn__348000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }




func A_arbace_template__init_A_Unit4__O() any { A_arbace_template__init_A_Init(); lang.Compiler_AOT_At_I_I__V(29, 1); var tmp1 *lang.Var = A_arbace_template__init_A_const_4; var tmp2 any = A_arbace_template_apply_template_A_New(); var tmp3 *jrt.Class; A_arbace_template_apply_template_A_Init(); tmp3 = A_arbace_template_apply_template_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_template__init_A_const_4; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_template__init_A_const_5)); return A_arbace_template__init_A_const_4.Ref() }














func A_arbace_template__init_A_Unit5__O() any { A_arbace_template__init_A_Init(); lang.Compiler_AOT_At_I_I__V(44, 1); var tmp1 *lang.Var = A_arbace_template__init_A_const_6; var tmp2 any = A_arbace_template_do_template_A_New(); var tmp3 *jrt.Class; A_arbace_template_do_template_A_Init(); tmp3 = A_arbace_template_do_template_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 4)); var tmp4 *lang.Var = A_arbace_template__init_A_const_6; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_template__init_A_const_7)); return A_arbace_template__init_A_const_6.Ref() }
//line :44:1
func A_arbace_template__init_A_Unit6__O() any { A_arbace_template__init_A_Init(); lang.Compiler_AOT_At_I_I__V(44, 1); jrt.NN(A_arbace_template__init_A_const_6).SetMacro__V(); return nil }
//line :44:1
func A_arbace_template__init_A_Unit7__O() any { A_arbace_template__init_A_Init(); lang.Compiler_AOT_At_I_I__V(44, 1); return A_arbace_template__init_A_const_6.Ref() }







type A_arbace_template__init_A struct{ jrt.Object }

var A_arbace_template__init_A_const_0 *lang.Var

var A_arbace_template__init_A_const_1 any

var A_arbace_template__init_A_const_2 any

var A_arbace_template__init_A_const_3 any

var A_arbace_template__init_A_const_4 *lang.Var

var A_arbace_template__init_A_const_5 any

var A_arbace_template__init_A_const_6 *lang.Var

var A_arbace_template__init_A_const_7 any

var A_arbace_template__init_A_init jrt.ClassInit

func A_arbace_template__init_A_Init() { if !A_arbace_template__init_A_init.Done() { A_arbace_template__init_A_init.Run(A_arbace_template__init_A_clinit) } }

func A_arbace_template__init_A_clinit() { A_arbace_template__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_37); A_arbace_template__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_9)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_11, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13))); A_arbace_template__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_11, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_template__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_template__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_9, Lit_29); A_arbace_template__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_38).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_19).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_39).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_40).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_41, lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(), jrt.Integer_ValueOf_I__Integer(29).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_42).Ref(), Lit_43)); A_arbace_template__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_9, Lit_44); A_arbace_template__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_38).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_19).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_39).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_45).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_40).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_46, lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(), jrt.Integer_ValueOf_I__Integer(44).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_42).Ref(), Lit_43)) }

func A_arbace_template__init_A_New() *A_arbace_template__init_A { A_arbace_template__init_A_Init(); t := &A_arbace_template__init_A{}; t.Ctor(); return t }

func (t *A_arbace_template__init_A) Ctor() {}

func (t *A_arbace_template__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_template__init_A) GetClass__Class() *jrt.Class { return A_arbace_template__init_A_class }

func (t *A_arbace_template__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_template__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_template__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_template__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_template__init_A); return ok }

func A_arbace_template__init_A_Cast(x any) *A_arbace_template__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_template__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_template__init_A_class)) }; return v }
