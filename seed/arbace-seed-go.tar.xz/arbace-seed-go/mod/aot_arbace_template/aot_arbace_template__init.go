//line aot_arbace_template__init.ae:1
package aot_arbace_template

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_template__init_A_Load__O() any { A_arbace_template__init_A_Init(); A_arbace_template__init_A_Unit0__O(); A_arbace_template__init_A_Unit1__O(); A_arbace_template__init_A_Unit2__O(); A_arbace_template__init_A_Unit3__O(); A_arbace_template__init_A_Unit4__O(); A_arbace_template__init_A_Unit5__O(); A_arbace_template__init_A_Unit6__O(); A_arbace_template__init_A_Unit7__O(); return nil }


















func A_arbace_template__init_A_Unit0__O() any { A_arbace_template__init_A_Init(); lang.Compiler_AOT_At_I_I__V(24, 1); return lang.IFn_Cast(A_arbace_template__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_template__init_A_const_1) }
//line :24:1
func A_arbace_template__init_A_Unit1__O() any { A_arbace_template__init_A_Init(); lang.Compiler_AOT_At_I_I__V(24, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_template__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_template__init_A_const_2)) }
//line :24:1
func A_arbace_template__init_A_Unit2__O() any { A_arbace_template__init_A_Init(); lang.Compiler_AOT_At_I_I__V(24, 1); var tmp1 any = A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_4, false); A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :24:1
func A_arbace_template__init_A_Unit3__O() any { A_arbace_template__init_A_Init(); lang.Compiler_AOT_At_I_I__V(24, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_template__init_A_const_1)).Equals_O__Z(A_arbace_template__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_template_eval348000008_fn__348000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_template_eval348000008_fn__348000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_5, false); A_arbace_template_eval348000008_fn__348000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }




func A_arbace_template__init_A_Unit4__O() any { A_arbace_template__init_A_Init(); lang.Compiler_AOT_At_I_I__V(29, 1); var tmp1 *lang.Var = A_arbace_template__init_A_const_4; var tmp2 any = A_arbace_template_apply_template_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_template_apply_template_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_6, false); A_arbace_template_apply_template_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_template__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_template__init_A_const_5)); return A_arbace_template__init_A_const_4 }














func A_arbace_template__init_A_Unit5__O() any { A_arbace_template__init_A_Init(); lang.Compiler_AOT_At_I_I__V(44, 1); var tmp1 *lang.Var = A_arbace_template__init_A_const_6; var tmp2 any = A_arbace_template_do_template_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_template_do_template_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_7, true); A_arbace_template_do_template_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 4)); var tmp4 *lang.Var = A_arbace_template__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_template__init_A_const_7)); return A_arbace_template__init_A_const_6 }
//line :44:1
func A_arbace_template__init_A_Unit6__O() any { A_arbace_template__init_A_Init(); lang.Compiler_AOT_At_I_I__V(44, 1); A_arbace_template__init_A_const_6.SetMacro__V(); return nil }
//line :44:1
func A_arbace_template__init_A_Unit7__O() any { A_arbace_template__init_A_Init(); lang.Compiler_AOT_At_I_I__V(44, 1); return A_arbace_template__init_A_const_6 }







type A_arbace_template__init_A struct{ jrt.Object }

var A_arbace_template__init_A_const_pool *jrt.RefArray

var A_arbace_template__init_A_const_0 *lang.Var

var A_arbace_template__init_A_const_1 any

var A_arbace_template__init_A_const_2 any

var A_arbace_template__init_A_const_3 any

var A_arbace_template__init_A_const_4 *lang.Var

var A_arbace_template__init_A_const_5 any

var A_arbace_template__init_A_const_6 *lang.Var

var A_arbace_template__init_A_const_7 any

var A_arbace_template__init_A_init jrt.ClassInit

func A_arbace_template__init_A_Init() { if !A_arbace_template__init_A_init.Done() { A_arbace_template__init_A_init.Run(A_arbace_template__init_A_clinit) } }

func A_arbace_template__init_A_clinit() { A_arbace_template__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_3, 19); A_arbace_template__init_A_const_0 = lang.Var_Cast(A_arbace_template__init_A_const_pool.A[11]); A_arbace_template__init_A_const_1 = A_arbace_template__init_A_const_pool.A[12]; A_arbace_template__init_A_const_2 = A_arbace_template__init_A_const_pool.A[13]; A_arbace_template__init_A_const_3 = A_arbace_template__init_A_const_pool.A[14]; A_arbace_template__init_A_const_4 = lang.Var_Cast(A_arbace_template__init_A_const_pool.A[15]); A_arbace_template__init_A_const_5 = A_arbace_template__init_A_const_pool.A[16]; A_arbace_template__init_A_const_6 = lang.Var_Cast(A_arbace_template__init_A_const_pool.A[17]); A_arbace_template__init_A_const_7 = A_arbace_template__init_A_const_pool.A[18] }

func A_arbace_template__init_A_New() *A_arbace_template__init_A { A_arbace_template__init_A_Init(); t := &A_arbace_template__init_A{}; t.Ctor(); return t }

func (t *A_arbace_template__init_A) Ctor() {}

func (t *A_arbace_template__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_template__init_A) GetClass__Class() *jrt.Class { return A_arbace_template__init_A_class }

func (t *A_arbace_template__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_template__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_template__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_template__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_template__init_A); return ok }

func A_arbace_template__init_A_Cast(x any) *A_arbace_template__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_template__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_template__init_A_class)) }; return v }
