//line aot_arbace_template.ae:1
package aot_arbace_template

import (
	"arbace/jrt"
	"arbace/lang"
)

















func A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_New() *A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A { A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_Init(); t := &A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A) Ctor() {}
//line :24:1
func (t *A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_template_A_Init(); tmp4 = A_arbace_template_A_const_1; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_template_A_Init(); tmp6 = A_arbace_template_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_template_A_Init(); tmp7 = A_arbace_template_A_const_0; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_template_A_Init(); tmp9 = A_arbace_template_A_const_3; tmp3 = tmp8.Invoke_O__O(tmp9) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp10 != nil { panic(tmp10) }; return tmp3 }
//line :24:1
func A_arbace_template_eval348000008_fn__348000009_A_New() *A_arbace_template_eval348000008_fn__348000009_A { A_arbace_template_eval348000008_fn__348000009_A_Init(); t := &A_arbace_template_eval348000008_fn__348000009_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_template_eval348000008_fn__348000009_A) Ctor() {}
//line :24:1
func (t *A_arbace_template_eval348000008_fn__348000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_template_A_Init(); tmp1 = A_arbace_template_A_const_4; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_template_A_Init(); tmp3 = A_arbace_template_A_const_5; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_template_A_Init(); tmp5 = A_arbace_template_A_const_8; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_template_A_Init(); tmp7 = A_arbace_template_A_const_6; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_template_A_Init(); tmp9 = A_arbace_template_A_const_7; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }




func A_arbace_template_apply_template_A_New() *A_arbace_template_apply_template_A { A_arbace_template_apply_template_A_Init(); t := &A_arbace_template_apply_template_A{}; t.Ctor(); return t }
//line :29:1
func (t *A_arbace_template_apply_template_A) Ctor() {}
//line :29:1
func (t *A_arbace_template_apply_template_A) Invoke_O_O_O_O__O(self, argv__0, expr__1, values__2 any) any {










	var tmp1 *lang.Var; A_arbace_template_A_Init(); tmp1 = A_arbace_template_A_const_10; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(argv__0)) { } else { var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_32, nil); var tmp3 *lang.Var; A_arbace_template_A_Init(); tmp3 = A_arbace_template_A_const_11; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any; A_arbace_template_A_Init(); tmp5 = A_arbace_template_A_const_13; panic(jrt.Thrown(jrt.AssertionError_New_O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp4.Invoke_O__O(tmp5))).Ref()))) }
	var tmp6 *lang.Var; A_arbace_template_A_Init(); tmp6 = A_arbace_template_A_const_12; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_template_A_Init(); tmp8 = A_arbace_template_A_const_14; if jrt.A2g_Truth(tmp7.Invoke_O_O__O(jrt.NN(tmp8).GetRawRoot__O(), argv__0)) { } else { var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_32, nil); var tmp10 *lang.Var; A_arbace_template_A_Init(); tmp10 = A_arbace_template_A_const_11; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 any; A_arbace_template_A_Init(); tmp12 = A_arbace_template_A_const_15; panic(jrt.Thrown(jrt.AssertionError_New_O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp11.Invoke_O__O(tmp12))).Ref()))) }
	var tmp13 *lang.Var; A_arbace_template_A_Init(); tmp13 = A_arbace_template_A_const_9; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_template_A_Init(); tmp15 = A_arbace_template_A_const_16; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O_O__O(argv__0, values__2), expr__1)
}
func A_arbace_template_do_template_A_New() *A_arbace_template_do_template_A { A_arbace_template_do_template_A_Init(); t := &A_arbace_template_do_template_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_template_do_template_A) Ctor() {}
//line :44:1
func (t *A_arbace_template_do_template_A) DoInvoke_O_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, argv__2, expr__3, values__4 any) any { var c__6 int32 = lang.RT_Count_O__I(argv__2); var tmp1 *lang.Var;







	A_arbace_template_A_Init(); tmp1 = A_arbace_template_A_const_17; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_template_A_Init(); tmp3 = A_arbace_template_A_const_18; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_template_A_Init(); tmp5 = A_arbace_template_A_const_19; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_template_A_Init(); tmp7 = A_arbace_template_A_const_21; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_template_A_Init(); tmp9 = A_arbace_template_A_const_20; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 any = A_arbace_template_do_template_fn__348000013_A_New_O_O(expr__3, argv__2); var tmp12 *jrt.Class; A_arbace_template_do_template_fn__348000013_A_Init(); tmp12 = A_arbace_template_do_template_fn__348000013_A_fn_class; var tmp13 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var tmp14 *lang.Var; A_arbace_template_A_Init(); tmp14 = A_arbace_template_A_const_23; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O_O__O(tmp13, lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O_O__O(jrt.Integer_ValueOf_I__Integer(c__6).Ref(), values__4)))) }
func A_arbace_template_do_template_fn__348000013_A_New_O_O(p0, p1 any) *A_arbace_template_do_template_fn__348000013_A { A_arbace_template_do_template_fn__348000013_A_Init(); t := &A_arbace_template_do_template_fn__348000013_A{}; t.Ctor_O_O(p0, p1); return t }
//line :53:1
func (t *A_arbace_template_do_template_fn__348000013_A) Ctor_O_O(c__expr, c__argv any) { t.F_expr = c__expr; t.F_argv = c__argv }
//line :53:1
func (t *A_arbace_template_do_template_fn__348000013_A) Invoke_O_O__O(self, a__1 any) any { var tmp1 *lang.Var; A_arbace_template_A_Init(); tmp1 = A_arbace_template_A_const_22; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(t.F_argv, t.F_expr, a__1) }







type A_arbace_template_A struct{ jrt.Object }

var A_arbace_template_A_const_0 *lang.Var

var A_arbace_template_A_const_1 *lang.Var

var A_arbace_template_A_const_2 any

var A_arbace_template_A_const_3 any

var A_arbace_template_A_const_4 *lang.Var

var A_arbace_template_A_const_5 *lang.Var

var A_arbace_template_A_const_6 *lang.Var

var A_arbace_template_A_const_7 any

var A_arbace_template_A_const_8 *lang.Var

var A_arbace_template_A_const_9 *lang.Var

var A_arbace_template_A_const_10 *lang.Var

var A_arbace_template_A_const_11 *lang.Var

var A_arbace_template_A_const_12 *lang.Var

var A_arbace_template_A_const_13 any

var A_arbace_template_A_const_14 *lang.Var

var A_arbace_template_A_const_15 any

var A_arbace_template_A_const_16 *lang.Var

var A_arbace_template_A_const_17 *lang.Var

var A_arbace_template_A_const_18 *lang.Var

var A_arbace_template_A_const_19 *lang.Var

var A_arbace_template_A_const_20 *lang.Var

var A_arbace_template_A_const_21 any

var A_arbace_template_A_const_22 *lang.Var

var A_arbace_template_A_const_23 *lang.Var

var A_arbace_template_A_init jrt.ClassInit

func A_arbace_template_A_Init() { if !A_arbace_template_A_init.Done() { A_arbace_template_A_init.Run(A_arbace_template_A_clinit) } }

func A_arbace_template_A_clinit() { A_arbace_template_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_template_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_template_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_template_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_template_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_6); A_arbace_template_A_const_5 = lang.RT_Var_String_String__Var(Lit_0, Lit_7); A_arbace_template_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_8); A_arbace_template_A_const_7 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_9)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_11, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13))); A_arbace_template_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_14); A_arbace_template_A_const_9 = lang.RT_Var_String_String__Var(Lit_3, Lit_15); A_arbace_template_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_16); A_arbace_template_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_17); A_arbace_template_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_18); A_arbace_template_A_const_13 = lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_19).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(), jrt.Integer_ValueOf_I__Integer(40).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), jrt.Integer_ValueOf_I__Integer(11).Ref()))); A_arbace_template_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_22); A_arbace_template_A_const_15 = lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_18).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_22).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_19).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(), jrt.Integer_ValueOf_I__Integer(41).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref(), jrt.Integer_ValueOf_I__Integer(11).Ref()))); A_arbace_template_A_const_16 = lang.RT_Var_String_String__Var(Lit_0, Lit_23); A_arbace_template_A_const_17 = lang.RT_Var_String_String__Var(Lit_0, Lit_24); A_arbace_template_A_const_18 = lang.RT_Var_String_String__Var(Lit_0, Lit_25); A_arbace_template_A_const_19 = lang.RT_Var_String_String__Var(Lit_0, Lit_26); A_arbace_template_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_27); A_arbace_template_A_const_21 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_28).Ref(); A_arbace_template_A_const_22 = lang.RT_Var_String_String__Var(Lit_9, Lit_29); A_arbace_template_A_const_23 = lang.RT_Var_String_String__Var(Lit_0, Lit_30) }

func A_arbace_template_A_New() *A_arbace_template_A { A_arbace_template_A_Init(); t := &A_arbace_template_A{}; t.Ctor(); return t }

func (t *A_arbace_template_A) Ctor() {}

func (t *A_arbace_template_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_template_A) GetClass__Class() *jrt.Class { return A_arbace_template_A_class }

func (t *A_arbace_template_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_template_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_template_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_template_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_template_A); return ok }

func A_arbace_template_A_Cast(x any) *A_arbace_template_A { if x == nil { return nil }; v, ok := x.(*A_arbace_template_A); if !ok { panic(jrt.ClassCast(x, A_arbace_template_A_class)) }; return v }



type A_arbace_template_apply_template_A struct{ jrt.Object }

func (t *A_arbace_template_apply_template_A) Is_Compiler_AOTF3() {}

var A_arbace_template_apply_template_A_fn_class *jrt.Class

var A_arbace_template_apply_template_A_init jrt.ClassInit

func A_arbace_template_apply_template_A_Init() { if !A_arbace_template_apply_template_A_init.Done() { A_arbace_template_apply_template_A_init.Run(A_arbace_template_apply_template_A_clinit) } }

func A_arbace_template_apply_template_A_clinit() { A_arbace_template_apply_template_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_31, lang.Compiler_AOTFn_class) }

func (t *A_arbace_template_apply_template_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_template_apply_template_A) GetClass__Class() *jrt.Class { return A_arbace_template_apply_template_A_class }

func (t *A_arbace_template_apply_template_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_template_apply_template_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_template_apply_template_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_template_apply_template_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_template_apply_template_A); return ok }

func A_arbace_template_apply_template_A_Cast(x any) *A_arbace_template_apply_template_A { if x == nil { return nil }; v, ok := x.(*A_arbace_template_apply_template_A); if !ok { panic(jrt.ClassCast(x, A_arbace_template_apply_template_A_class)) }; return v }



type A_arbace_template_do_template_A struct{ jrt.Object }

func (t *A_arbace_template_do_template_A) Is_Compiler_AOTR4() {}

var A_arbace_template_do_template_A_fn_class *jrt.Class

var A_arbace_template_do_template_A_init jrt.ClassInit

func A_arbace_template_do_template_A_Init() { if !A_arbace_template_do_template_A_init.Done() { A_arbace_template_do_template_A_init.Run(A_arbace_template_do_template_A_clinit) } }

func A_arbace_template_do_template_A_clinit() { A_arbace_template_do_template_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_33, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_template_do_template_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_template_do_template_A) GetClass__Class() *jrt.Class { return A_arbace_template_do_template_A_class }

func (t *A_arbace_template_do_template_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_template_do_template_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_template_do_template_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_template_do_template_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_template_do_template_A); return ok }

func A_arbace_template_do_template_A_Cast(x any) *A_arbace_template_do_template_A { if x == nil { return nil }; v, ok := x.(*A_arbace_template_do_template_A); if !ok { panic(jrt.ClassCast(x, A_arbace_template_do_template_A_class)) }; return v }



type A_arbace_template_do_template_fn__348000013_A struct{ jrt.Object; F_expr, F_argv any }

func (t *A_arbace_template_do_template_fn__348000013_A) Is_Compiler_AOTF1() {}

var A_arbace_template_do_template_fn__348000013_A_fn_class *jrt.Class

var A_arbace_template_do_template_fn__348000013_A_init jrt.ClassInit

func A_arbace_template_do_template_fn__348000013_A_Init() { if !A_arbace_template_do_template_fn__348000013_A_init.Done() { A_arbace_template_do_template_fn__348000013_A_init.Run(A_arbace_template_do_template_fn__348000013_A_clinit) } }

func A_arbace_template_do_template_fn__348000013_A_clinit() { A_arbace_template_do_template_fn__348000013_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_34, lang.Compiler_AOTFn_class) }

func (t *A_arbace_template_do_template_fn__348000013_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_template_do_template_fn__348000013_A) GetClass__Class() *jrt.Class { return A_arbace_template_do_template_fn__348000013_A_class }

func (t *A_arbace_template_do_template_fn__348000013_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_template_do_template_fn__348000013_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_template_do_template_fn__348000013_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_template_do_template_fn__348000013_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_template_do_template_fn__348000013_A); return ok }

func A_arbace_template_do_template_fn__348000013_A_Cast(x any) *A_arbace_template_do_template_fn__348000013_A { if x == nil { return nil }; v, ok := x.(*A_arbace_template_do_template_fn__348000013_A); if !ok { panic(jrt.ClassCast(x, A_arbace_template_do_template_fn__348000013_A_class)) }; return v }



type A_arbace_template_eval348000004_A struct{ jrt.Object }

func A_arbace_template_eval348000004_A_New() *A_arbace_template_eval348000004_A { t := &A_arbace_template_eval348000004_A{}; t.Ctor(); return t }

func (t *A_arbace_template_eval348000004_A) Ctor() {}

func (t *A_arbace_template_eval348000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_template_eval348000004_A) GetClass__Class() *jrt.Class { return A_arbace_template_eval348000004_A_class }

func (t *A_arbace_template_eval348000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_template_eval348000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_template_eval348000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_template_eval348000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_template_eval348000004_A); return ok }

func A_arbace_template_eval348000004_A_Cast(x any) *A_arbace_template_eval348000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_template_eval348000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_template_eval348000004_A_class)) }; return v }



type A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A struct{ jrt.Object }

func (t *A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A) Is_Compiler_AOTF0() {}

var A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_fn_class *jrt.Class

var A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_init jrt.ClassInit

func A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_Init() { if !A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_init.Done() { A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_init.Run(A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_clinit) } }

func A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_clinit() { A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_35, lang.Compiler_AOTFn_class) }

func (t *A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A) GetClass__Class() *jrt.Class { return A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_class }

func (t *A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A); return ok }

func A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_Cast(x any) *A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_class)) }; return v }



type A_arbace_template_eval348000008_A struct{ jrt.Object }

func A_arbace_template_eval348000008_A_New() *A_arbace_template_eval348000008_A { t := &A_arbace_template_eval348000008_A{}; t.Ctor(); return t }

func (t *A_arbace_template_eval348000008_A) Ctor() {}

func (t *A_arbace_template_eval348000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_template_eval348000008_A) GetClass__Class() *jrt.Class { return A_arbace_template_eval348000008_A_class }

func (t *A_arbace_template_eval348000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_template_eval348000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_template_eval348000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_template_eval348000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_template_eval348000008_A); return ok }

func A_arbace_template_eval348000008_A_Cast(x any) *A_arbace_template_eval348000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_template_eval348000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_template_eval348000008_A_class)) }; return v }



type A_arbace_template_eval348000008_fn__348000009_A struct{ jrt.Object }

func (t *A_arbace_template_eval348000008_fn__348000009_A) Is_Compiler_AOTF0() {}

var A_arbace_template_eval348000008_fn__348000009_A_fn_class *jrt.Class

var A_arbace_template_eval348000008_fn__348000009_A_init jrt.ClassInit

func A_arbace_template_eval348000008_fn__348000009_A_Init() { if !A_arbace_template_eval348000008_fn__348000009_A_init.Done() { A_arbace_template_eval348000008_fn__348000009_A_init.Run(A_arbace_template_eval348000008_fn__348000009_A_clinit) } }

func A_arbace_template_eval348000008_fn__348000009_A_clinit() { A_arbace_template_eval348000008_fn__348000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_36, lang.Compiler_AOTFn_class) }

func (t *A_arbace_template_eval348000008_fn__348000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_template_eval348000008_fn__348000009_A) GetClass__Class() *jrt.Class { return A_arbace_template_eval348000008_fn__348000009_A_class }

func (t *A_arbace_template_eval348000008_fn__348000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_template_eval348000008_fn__348000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_template_eval348000008_fn__348000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_template_eval348000008_fn__348000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_template_eval348000008_fn__348000009_A); return ok }

func A_arbace_template_eval348000008_fn__348000009_A_Cast(x any) *A_arbace_template_eval348000008_fn__348000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_template_eval348000008_fn__348000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_template_eval348000008_fn__348000009_A_class)) }; return v }
