//line aot_arbace_template.ae:1
package aot_arbace_template

import (
	"arbace/jrt"
	"arbace/lang"
)

















func A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_New() *A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A { A_arbace_template_A_Init(); t := &A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A) Ctor() {}
//line :24:1
func (t *A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_template_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_template_A_const_2); tmp3 = lang.IFn_Cast(A_arbace_template_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_template_A_const_3); return nil }(); lang.Var_PopThreadBindings__V(); if tmp4 != nil { panic(tmp4) }; return tmp3 }
//line :24:1
func A_arbace_template_eval348000008_fn__348000009_A_New() *A_arbace_template_eval348000008_fn__348000009_A { A_arbace_template_A_Init(); t := &A_arbace_template_eval348000008_fn__348000009_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_template_eval348000008_fn__348000009_A) Ctor() {}
//line :24:1
func (t *A_arbace_template_eval348000008_fn__348000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_template_A_const_4.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_template_A_const_5.GetRawRoot__O()).Invoke_O__O(A_arbace_template_A_const_8), A_arbace_template_A_const_6.GetRawRoot__O(), A_arbace_template_A_const_7) }




func A_arbace_template_apply_template_A_New() *A_arbace_template_apply_template_A { A_arbace_template_A_Init(); t := &A_arbace_template_apply_template_A{}; t.Ctor(); return t }
//line :29:1
func (t *A_arbace_template_apply_template_A) Ctor() {}
//line :29:1
func (t *A_arbace_template_apply_template_A) Invoke_O_O_O_O__O(self, argv__0, expr__1, values__2 any) any {










	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_template_A_const_10.GetRawRoot__O()).Invoke_O__O(argv__0)) { } else { panic(jrt.Thrown(jrt.AssertionError_New_O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_1, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_template_A_const_11.GetRawRoot__O()).Invoke_O__O(A_arbace_template_A_const_13))).Ref()))) }
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_template_A_const_12.GetRawRoot__O()).Invoke_O_O__O(A_arbace_template_A_const_14.GetRawRoot__O(), argv__0)) { } else { panic(jrt.Thrown(jrt.AssertionError_New_O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_1, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_template_A_const_11.GetRawRoot__O()).Invoke_O__O(A_arbace_template_A_const_15))).Ref()))) }
	return lang.IFn_Cast(A_arbace_template_A_const_9.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_template_A_const_16.GetRawRoot__O()).Invoke_O_O__O(argv__0, values__2), expr__1)
}
func A_arbace_template_do_template_A_New() *A_arbace_template_do_template_A { A_arbace_template_A_Init(); t := &A_arbace_template_do_template_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_template_do_template_A) Ctor() {}
//line :44:1
func (t *A_arbace_template_do_template_A) DoInvoke_O_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, argv__2, expr__3, values__4 any) any { var c__6 int32 = lang.RT_Count_O__I(argv__2); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_template_A_const_17.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_template_A_const_18.GetRawRoot__O()); var tmp3 any = lang.IFn_Cast(A_arbace_template_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_template_A_const_21); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_template_A_const_20.GetRawRoot__O()); var tmp5 any = A_arbace_template_do_template_fn__348000013_A_New_O_O(expr__3, argv__2); var tmp6 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_template_do_template_fn__348000013_A_fn_class; if








	fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_2, false); A_arbace_template_do_template_fn__348000013_A_fn_class = fncls__1d; tmp6 = fncls__1d } else { tmp6 = fncls__1 }; return /*line :52:1*/ tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), lang.IFn_Cast(A_arbace_template_A_const_23.GetRawRoot__O()).Invoke_O_O__O(jrt.Integer_ValueOf_I__Integer(c__6).Ref(), values__4)))) }
func A_arbace_template_do_template_fn__348000013_A_New_O_O(p0, p1 any) *A_arbace_template_do_template_fn__348000013_A { A_arbace_template_A_Init(); t := &A_arbace_template_do_template_fn__348000013_A{}; t.Ctor_O_O(p0, p1); return t }
//line :53:1
func (t *A_arbace_template_do_template_fn__348000013_A) Ctor_O_O(c__expr, c__argv any) { t.F_expr = c__expr; t.F_argv = c__argv }
//line :53:1
func (t *A_arbace_template_do_template_fn__348000013_A) Invoke_O_O__O(self, a__1 any) any { return lang.IFn_Cast(A_arbace_template_A_const_22.GetRawRoot__O()).Invoke_O_O_O__O(t.F_argv, t.F_expr, a__1) }







type A_arbace_template_A struct{ jrt.Object }

var A_arbace_template_A_const_pool *jrt.RefArray

var A_arbace_template_A_const_0 *lang.Var

var A_arbace_template_A_const_1 *lang.Var

var A_arbace_template_A_const_2 any

var A_arbace_template_A_const_3 any

var A_arbace_template_A_const_4 *lang.Var

var A_arbace_template_A_const_5 *lang.Var

var A_arbace_template_A_const_6 *lang.Var

var A_arbace_template_A_const_7 any

var A_arbace_template_A_const_8 *lang.Var

var A_arbace_template_A_const_9 *lang.Var

var A_arbace_template_A_const_10 *lang.Var

var A_arbace_template_A_const_11 *lang.Var

var A_arbace_template_A_const_12 *lang.Var

var A_arbace_template_A_const_13 any

var A_arbace_template_A_const_14 *lang.Var

var A_arbace_template_A_const_15 any

var A_arbace_template_A_const_16 *lang.Var

var A_arbace_template_A_const_17 *lang.Var

var A_arbace_template_A_const_18 *lang.Var

var A_arbace_template_A_const_19 *lang.Var

var A_arbace_template_A_const_20 *lang.Var

var A_arbace_template_A_const_21 any

var A_arbace_template_A_const_22 *lang.Var

var A_arbace_template_A_const_23 *lang.Var

var A_arbace_template_A_init jrt.ClassInit

func A_arbace_template_A_Init() { if !A_arbace_template_A_init.Done() { A_arbace_template_A_init.Run(A_arbace_template_A_clinit) } }

func A_arbace_template_A_clinit() { A_arbace_template_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 37); A_arbace_template_A_const_0 = lang.Var_Cast(A_arbace_template_A_const_pool.A[13]); A_arbace_template_A_const_1 = lang.Var_Cast(A_arbace_template_A_const_pool.A[14]); A_arbace_template_A_const_2 = A_arbace_template_A_const_pool.A[15]; A_arbace_template_A_const_3 = A_arbace_template_A_const_pool.A[16]; A_arbace_template_A_const_4 = lang.Var_Cast(A_arbace_template_A_const_pool.A[17]); A_arbace_template_A_const_5 = lang.Var_Cast(A_arbace_template_A_const_pool.A[18]); A_arbace_template_A_const_6 = lang.Var_Cast(A_arbace_template_A_const_pool.A[19]); A_arbace_template_A_const_7 = A_arbace_template_A_const_pool.A[20]; A_arbace_template_A_const_8 = lang.Var_Cast(A_arbace_template_A_const_pool.A[21]); A_arbace_template_A_const_9 = lang.Var_Cast(A_arbace_template_A_const_pool.A[22]); A_arbace_template_A_const_10 = lang.Var_Cast(A_arbace_template_A_const_pool.A[23]); A_arbace_template_A_const_11 = lang.Var_Cast(A_arbace_template_A_const_pool.A[24]); A_arbace_template_A_const_12 = lang.Var_Cast(A_arbace_template_A_const_pool.A[25]); A_arbace_template_A_const_13 = A_arbace_template_A_const_pool.A[26]; A_arbace_template_A_const_14 = lang.Var_Cast(A_arbace_template_A_const_pool.A[27]); A_arbace_template_A_const_15 = A_arbace_template_A_const_pool.A[28]; A_arbace_template_A_const_16 = lang.Var_Cast(A_arbace_template_A_const_pool.A[29]); A_arbace_template_A_const_17 = lang.Var_Cast(A_arbace_template_A_const_pool.A[30]); A_arbace_template_A_const_18 = lang.Var_Cast(A_arbace_template_A_const_pool.A[31]); A_arbace_template_A_const_19 = lang.Var_Cast(A_arbace_template_A_const_pool.A[32]); A_arbace_template_A_const_20 = lang.Var_Cast(A_arbace_template_A_const_pool.A[33]); A_arbace_template_A_const_21 = A_arbace_template_A_const_pool.A[34]; A_arbace_template_A_const_22 = lang.Var_Cast(A_arbace_template_A_const_pool.A[35]); A_arbace_template_A_const_23 = lang.Var_Cast(A_arbace_template_A_const_pool.A[36]) }

func A_arbace_template_A_New() *A_arbace_template_A { A_arbace_template_A_Init(); t := &A_arbace_template_A{}; t.Ctor(); return t }

func (t *A_arbace_template_A) Ctor() {}

func (t *A_arbace_template_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_template_A) GetClass__Class() *jrt.Class { return A_arbace_template_A_class }

func (t *A_arbace_template_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_template_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_template_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_template_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_template_A); return ok }

func A_arbace_template_A_Cast(x any) *A_arbace_template_A { if x == nil { return nil }; v, ok := x.(*A_arbace_template_A); if !ok { panic(jrt.ClassCast(x, A_arbace_template_A_class)) }; return v }



type A_arbace_template_apply_template_A struct{ j2g_header uint64 }

var A_arbace_template_apply_template_A_fn_class *jrt.Class



type A_arbace_template_do_template_A struct{ j2g_header uint64 }

var A_arbace_template_do_template_A_fn_class *jrt.Class



type A_arbace_template_do_template_fn__348000013_A struct{ j2g_header uint64; F_expr, F_argv any }

var A_arbace_template_do_template_fn__348000013_A_fn_class *jrt.Class



type A_arbace_template_eval348000004_A struct{ jrt.Object }

func A_arbace_template_eval348000004_A_New() *A_arbace_template_eval348000004_A { t := &A_arbace_template_eval348000004_A{}; t.Ctor(); return t }

func (t *A_arbace_template_eval348000004_A) Ctor() {}

func (t *A_arbace_template_eval348000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_template_eval348000004_A) GetClass__Class() *jrt.Class { return A_arbace_template_eval348000004_A_class }

func (t *A_arbace_template_eval348000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_template_eval348000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_template_eval348000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_template_eval348000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_template_eval348000004_A); return ok }

func A_arbace_template_eval348000004_A_Cast(x any) *A_arbace_template_eval348000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_template_eval348000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_template_eval348000004_A_class)) }; return v }



type A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A struct{ j2g_header uint64 }

var A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_fn_class *jrt.Class



type A_arbace_template_eval348000008_A struct{ jrt.Object }

func A_arbace_template_eval348000008_A_New() *A_arbace_template_eval348000008_A { t := &A_arbace_template_eval348000008_A{}; t.Ctor(); return t }

func (t *A_arbace_template_eval348000008_A) Ctor() {}

func (t *A_arbace_template_eval348000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_template_eval348000008_A) GetClass__Class() *jrt.Class { return A_arbace_template_eval348000008_A_class }

func (t *A_arbace_template_eval348000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_template_eval348000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_template_eval348000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_template_eval348000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_template_eval348000008_A); return ok }

func A_arbace_template_eval348000008_A_Cast(x any) *A_arbace_template_eval348000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_template_eval348000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_template_eval348000008_A_class)) }; return v }



type A_arbace_template_eval348000008_fn__348000009_A struct{ j2g_header uint64 }

var A_arbace_template_eval348000008_fn__348000009_A_fn_class *jrt.Class
