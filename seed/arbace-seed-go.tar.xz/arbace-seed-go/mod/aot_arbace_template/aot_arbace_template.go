//line aot_arbace_template.ae:1
package aot_arbace_template

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_walk"
	"arbace/jrt"
	"arbace/lang"
)















func A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_New() *A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A { A_arbace_template_A_Init(); t := &A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A) Ctor() {}
//line :24:1
func (t *A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_template_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_template_A_const_3); tmp2 = lang.IFn_Cast(A_arbace_template_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_template_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :24:1
func A_arbace_template_eval348000008_fn__348000009_A_New() *A_arbace_template_eval348000008_fn__348000009_A { A_arbace_template_A_Init(); t := &A_arbace_template_eval348000008_fn__348000009_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_template_eval348000008_fn__348000009_A) Ctor() {}
//line :24:1
func (t *A_arbace_template_eval348000008_fn__348000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_template_A_const_4.GetRawRoot__O()); var tmp2 any; var root_9 any = A_arbace_template_A_const_5.GetRawRoot__O(); var linked_10 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_9, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_11 lang.IFn; if linked_10 == nil { ifn_11 = lang.IFn_Cast(root_9) } else { ifn_11 = nil }; var arg_12 any = A_arbace_template_A_const_6; if linked_10 == nil { tmp2 = ifn_11.Invoke_O__O(arg_12) } else { tmp2 = linked_10.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_9, arg_12) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_template_A_const_7.GetRawRoot__O(), A_arbace_template_A_const_8) }




func A_arbace_template_apply_template_A_New() *A_arbace_template_apply_template_A { A_arbace_template_A_Init(); t := &A_arbace_template_apply_template_A{}; t.Ctor(); return t }
//line :29:1
func (t *A_arbace_template_apply_template_A) Ctor() {}
//line :29:1
func (t *A_arbace_template_apply_template_A) Invoke_O_O_O_O__O(self, argv__0, expr__1, values__2 any) any {










	var tmp1 any; var root_29 any = A_arbace_template_A_const_11.GetRawRoot__O(); var linked_30 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_29, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_31 lang.IFn; if linked_30 == nil { ifn_31 = lang.IFn_Cast(root_29) } else { ifn_31 = nil }; var arg_32 any = argv__0; if linked_30 == nil { tmp1 = ifn_31.Invoke_O__O(arg_32) } else { tmp1 = linked_30.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_29, arg_32) }; if jrt.J2g_Truth(tmp1) { } else { panic(jrt.Thrown(jrt.AssertionError_New_O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_1, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_template_A_const_12.GetRawRoot__O()).Invoke_O__O(A_arbace_template_A_const_13))).Ref()))) }
	var tmp2 any; var root_37 any = A_arbace_template_A_const_14.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_37, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_39 lang.IFn; if linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any = A_arbace_template_A_const_15.GetRawRoot__O(); var arg_41 any = argv__0; if linked_38 == nil { tmp2 = ifn_39.Invoke_O_O__O(arg_40, arg_41) } else { tmp2 = linked_38.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_37, arg_40, arg_41) }; if jrt.J2g_Truth(tmp2) { } else { panic(jrt.Thrown(jrt.AssertionError_New_O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_1, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_template_A_const_12.GetRawRoot__O()).Invoke_O__O(A_arbace_template_A_const_16))).Ref()))) }
	var root_24 any = A_arbace_template_A_const_9.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, aot_arbace_walk.A_arbace_walk_postwalk_replace_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any; var root_19 any = A_arbace_template_A_const_10.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_zipmap_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = argv__0; var arg_23 any = values__2; if linked_20 == nil { arg_27 = ifn_21.Invoke_O_O__O(arg_22, arg_23) } else { arg_27 = linked_20.(*aot_arbace_core.A_arbace_core_zipmap_A).Invoke_O_O_O__O(root_19, arg_22, arg_23) }; var arg_28 any = expr__1; if linked_25 == nil { return ifn_26.Invoke_O_O__O(arg_27, arg_28) } else { return linked_25.(*aot_arbace_walk.A_arbace_walk_postwalk_replace_A).Invoke_O_O_O__O(root_24, arg_27, arg_28)
	} }
func A_arbace_template_do_template_A_New() *A_arbace_template_do_template_A { A_arbace_template_A_Init(); t := &A_arbace_template_do_template_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_template_do_template_A) Ctor() {}
//line :44:1
func (t *A_arbace_template_do_template_A) DoInvoke_O_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, argv__2, expr__3, values__4 any) any { var c__6 int32 = lang.RT_Count_O__I_NoInit(argv__2); var root_68 any = A_arbace_template_A_const_17.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_70 lang.IFn; if







	linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any; var root_63 any = A_arbace_template_A_const_18.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_63, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_65 lang.IFn; if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any = lang.IFn_Cast(A_arbace_template_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_template_A_const_20); var arg_67 any; var root_58 any = A_arbace_template_A_const_21.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_58, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_60 lang.IFn; if
	linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any; var tmp1 any = A_arbace_template_do_template_fn__348000013_A_New_O_O(expr__3, argv__2); var tmp2 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_template_do_template_fn__348000013_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_template_do_template_fn__348000013_A_fn_class = fncls__52d; tmp2 = fncls__52d } else { tmp2 = fncls__52 }; arg_61 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_62 any; var root_53 any = A_arbace_template_A_const_23.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_partition_A_fn_class); var ifn_55 lang.IFn; if
	linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = jrt.Integer_ValueOf_I__Integer_NoInit(c__6).Ref(); var arg_57 any = values__4; if linked_54 == nil { arg_62 = ifn_55.Invoke_O_O__O(arg_56, arg_57) } else { arg_62 = linked_54.(*aot_arbace_core.A_arbace_core_partition_A).Invoke_O_O_O__O(root_53, arg_56, arg_57) }; if /*line :53:1*/ linked_59 == nil { arg_67 = ifn_60.Invoke_O_O__O(arg_61, arg_62) } else { arg_67 = linked_59.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_58, arg_61, arg_62) }; if /*line :52:1*/ linked_64 == nil { arg_71 = ifn_65.Invoke_O_O__O(arg_66, arg_67) } else { arg_71 = linked_64.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_63, arg_66, arg_67) }; if linked_69 == nil { return ifn_70.Invoke_O__O(arg_71) } else { return linked_69.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_68, arg_71) } }
func A_arbace_template_do_template_fn__348000013_A_New_O_O(p0, p1 any) *A_arbace_template_do_template_fn__348000013_A { A_arbace_template_A_Init(); t := &A_arbace_template_do_template_fn__348000013_A{}; t.Ctor_O_O(p0, p1); return t }
//line :53:1
func (t *A_arbace_template_do_template_fn__348000013_A) Ctor_O_O(c__expr, c__argv any) { t.F_expr = c__expr; t.F_argv = c__argv }
//line :53:1
func (t *A_arbace_template_do_template_fn__348000013_A) Invoke_O_O__O(self, a__1 any) any { var root_46 any = A_arbace_template_A_const_22.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, A_arbace_template_apply_template_A_fn_class); var ifn_48 lang.IFn; if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = t.F_argv; var arg_50 any = t.F_expr; var arg_51 any = a__1; if linked_47 == nil { return ifn_48.Invoke_O_O_O__O(arg_49, arg_50, arg_51) } else { return linked_47.(*A_arbace_template_apply_template_A).Invoke_O_O_O_O__O(root_46, arg_49, arg_50, arg_51) } }







type A_arbace_template_A struct{ jrt.Object }

var A_arbace_template_A_const_pool *jrt.RefArray

var A_arbace_template_A_const_0 *lang.Var

var A_arbace_template_A_const_1 any

var A_arbace_template_A_const_2 *lang.Var

var A_arbace_template_A_const_3 any

var A_arbace_template_A_const_4 *lang.Var

var A_arbace_template_A_const_5 *lang.Var

var A_arbace_template_A_const_6 *lang.Var

var A_arbace_template_A_const_7 *lang.Var

var A_arbace_template_A_const_8 any

var A_arbace_template_A_const_9 *lang.Var

var A_arbace_template_A_const_10 *lang.Var

var A_arbace_template_A_const_11 *lang.Var

var A_arbace_template_A_const_12 *lang.Var

var A_arbace_template_A_const_13 any

var A_arbace_template_A_const_14 *lang.Var

var A_arbace_template_A_const_15 *lang.Var

var A_arbace_template_A_const_16 any

var A_arbace_template_A_const_17 *lang.Var

var A_arbace_template_A_const_18 *lang.Var

var A_arbace_template_A_const_19 *lang.Var

var A_arbace_template_A_const_20 any

var A_arbace_template_A_const_21 *lang.Var

var A_arbace_template_A_const_22 *lang.Var

var A_arbace_template_A_const_23 *lang.Var

var A_arbace_template_A_init jrt.ClassInit

func A_arbace_template_A_Init() { if !A_arbace_template_A_init.Done() { A_arbace_template_A_init.Run(A_arbace_template_A_clinit) } }

func A_arbace_template_A_clinit() { jrt.StartCheck(); A_arbace_template_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 37); A_arbace_template_A_const_0 = lang.Var_Cast(A_arbace_template_A_const_pool.A[13]); A_arbace_template_A_const_1 = A_arbace_template_A_const_pool.A[14]; A_arbace_template_A_const_2 = lang.Var_Cast(A_arbace_template_A_const_pool.A[15]); A_arbace_template_A_const_3 = A_arbace_template_A_const_pool.A[16]; A_arbace_template_A_const_4 = lang.Var_Cast(A_arbace_template_A_const_pool.A[17]); A_arbace_template_A_const_5 = lang.Var_Cast(A_arbace_template_A_const_pool.A[18]); A_arbace_template_A_const_6 = lang.Var_Cast(A_arbace_template_A_const_pool.A[19]); A_arbace_template_A_const_7 = lang.Var_Cast(A_arbace_template_A_const_pool.A[20]); A_arbace_template_A_const_8 = A_arbace_template_A_const_pool.A[21]; A_arbace_template_A_const_9 = lang.Var_Cast(A_arbace_template_A_const_pool.A[22]); A_arbace_template_A_const_10 = lang.Var_Cast(A_arbace_template_A_const_pool.A[23]); A_arbace_template_A_const_11 = lang.Var_Cast(A_arbace_template_A_const_pool.A[24]); A_arbace_template_A_const_12 = lang.Var_Cast(A_arbace_template_A_const_pool.A[25]); A_arbace_template_A_const_13 = A_arbace_template_A_const_pool.A[26]; A_arbace_template_A_const_14 = lang.Var_Cast(A_arbace_template_A_const_pool.A[27]); A_arbace_template_A_const_15 = lang.Var_Cast(A_arbace_template_A_const_pool.A[28]); A_arbace_template_A_const_16 = A_arbace_template_A_const_pool.A[29]; A_arbace_template_A_const_17 = lang.Var_Cast(A_arbace_template_A_const_pool.A[30]); A_arbace_template_A_const_18 = lang.Var_Cast(A_arbace_template_A_const_pool.A[31]); A_arbace_template_A_const_19 = lang.Var_Cast(A_arbace_template_A_const_pool.A[32]); A_arbace_template_A_const_20 = A_arbace_template_A_const_pool.A[33]; A_arbace_template_A_const_21 = lang.Var_Cast(A_arbace_template_A_const_pool.A[34]); A_arbace_template_A_const_22 = lang.Var_Cast(A_arbace_template_A_const_pool.A[35]); A_arbace_template_A_const_23 = lang.Var_Cast(A_arbace_template_A_const_pool.A[36]) }

func A_arbace_template_A_New() *A_arbace_template_A { A_arbace_template_A_Init(); t := &A_arbace_template_A{}; t.Ctor(); return t }

func (t *A_arbace_template_A) Ctor() {}

func (t *A_arbace_template_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_template_A) GetClass__Class() *jrt.Class { return A_arbace_template_A_class }

func (t *A_arbace_template_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_template_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_template_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_template_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_template_A); return ok }

func A_arbace_template_A_Cast(x any) *A_arbace_template_A { if x == nil { return nil }; v, ok := x.(*A_arbace_template_A); if !ok { panic(jrt.ClassCast(x, A_arbace_template_A_class)) }; return v }



type A_arbace_template_apply_template_A struct{ j2g_header uint64 }

var A_arbace_template_apply_template_A_fn_class *jrt.Class



type A_arbace_template_do_template_A struct{ j2g_header uint64 }

var A_arbace_template_do_template_A_fn_class *jrt.Class



type A_arbace_template_do_template_fn__348000013_A struct{ j2g_header uint64; F_expr, F_argv any }

var A_arbace_template_do_template_fn__348000013_A_fn_class *jrt.Class



type A_arbace_template_eval348000004_A struct{ jrt.Object }

func A_arbace_template_eval348000004_A_New() *A_arbace_template_eval348000004_A { t := &A_arbace_template_eval348000004_A{}; t.Ctor(); return t }

func (t *A_arbace_template_eval348000004_A) Ctor() {}

func (t *A_arbace_template_eval348000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_template_eval348000004_A) GetClass__Class() *jrt.Class { return A_arbace_template_eval348000004_A_class }

func (t *A_arbace_template_eval348000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_template_eval348000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_template_eval348000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_template_eval348000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_template_eval348000004_A); return ok }

func A_arbace_template_eval348000004_A_Cast(x any) *A_arbace_template_eval348000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_template_eval348000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_template_eval348000004_A_class)) }; return v }



type A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A struct{ j2g_header uint64 }

var A_arbace_template_eval348000004_loading__1927001464__auto____348000005_A_fn_class *jrt.Class



type A_arbace_template_eval348000008_A struct{ jrt.Object }

func A_arbace_template_eval348000008_A_New() *A_arbace_template_eval348000008_A { t := &A_arbace_template_eval348000008_A{}; t.Ctor(); return t }

func (t *A_arbace_template_eval348000008_A) Ctor() {}

func (t *A_arbace_template_eval348000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_template_eval348000008_A) GetClass__Class() *jrt.Class { return A_arbace_template_eval348000008_A_class }

func (t *A_arbace_template_eval348000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_template_eval348000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_template_eval348000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_template_eval348000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_template_eval348000008_A); return ok }

func A_arbace_template_eval348000008_A_Cast(x any) *A_arbace_template_eval348000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_template_eval348000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_template_eval348000008_A_class)) }; return v }



type A_arbace_template_eval348000008_fn__348000009_A struct{ j2g_header uint64 }

var A_arbace_template_eval348000008_fn__348000009_A_fn_class *jrt.Class
