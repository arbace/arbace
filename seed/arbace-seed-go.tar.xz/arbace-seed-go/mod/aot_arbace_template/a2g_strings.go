//line a2g_strings.ae:1
package aot_arbace_template

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn11,arbace.walkkn2,asyn4,walkkn3,dockn6,authoryn7,vector?yn4,argvkn4,linekn6,columnyn6,every?yn7,symbol?yn2,dov11,arbace.core7,requirev11,arbace.core5,referR0,V3,R1,R2,R3,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn15,arbace.templatem4,R4,s63,Macros that expand to repeated copies of a template expression.R5,s13,Stuart Sierrav11,arbace.core13,*loaded-libs*v11,arbace.walk16,postwalk-replacev11,arbace.core7,vector?v11,arbace.core6,pr-strv11,arbace.core6,every?ML2,R6,R7,m4,R8,i40,R9,i11,v11,arbace.core7,symbol?ML3,R10,R11,R7,m4,R8,i41,R9,i11,v11,arbace.core6,zipmapv11,arbace.core3,seqv11,arbace.core6,concatv11,arbace.core4,listv11,arbace.core3,mapR12,v15,arbace.template14,apply-templatev11,arbace.core9,partition")

var Lit_1 *jrt.String = jrt.Intern("Assert failed: ")

var Lit_2 *jrt.String = jrt.Intern("arbace.template$do_template$fn__348000013")

var Lit_3 *jrt.String = jrt.Intern("kn3,dockn6,authoryn11,arbace.corekn8,arglistsyn4,argvyn4,expryn6,valueskn4,linekn6,columnkn4,fileyn1,&v11,arbace.core5,in-nsMyn15,arbace.templatem4,R0,s63,Macros that expand to repeated copies of a template expression.R1,s13,Stuart Sierram4,R0,s63,Macros that expand to repeated copies of a template expression.R1,s13,Stuart SierraR2,v15,arbace.template14,apply-templatem10,R3,L1,V3,R4,R5,R6,R0,s380,For use in macros.  argv is an argument list, as in defn.  expr is\n  a quoted expression using the symbols in argv.  values is a sequence\n  of values to be used for the arguments.\n\n  apply-template will recursively replace argument symbols in expr\n  with their corresponding values, returning a modified expr.\n\n  Example: (apply-template '[x] '(+ x x) '[2])\n           ;=> (+ 2 2)R7,i29,R8,i1,R9,s18,arbace/template.aev15,arbace.template11,do-templatem10,R3,L1,V4,R4,R5,R10,R6,R0,s285,Repeatedly copies expr (in a do block) for each group of arguments\n  in values.  values are automatically partitioned by the number of\n  arguments in argv, an argument vector as in defn.\n\n  Example: (macroexpand '(do-template [x y] (+ y x) 2 4 3 5))\n           ;=> (do (+ 4 2) (+ 5 3))R7,i44,R8,i1,R9,s18,arbace/template.ae")

var Lit_4 *jrt.String = jrt.Intern("arbace.template$eval348000004$loading__1927001464__auto____348000005")

var Lit_5 *jrt.String = jrt.Intern("arbace.template$eval348000008$fn__348000009")

var Lit_6 *jrt.String = jrt.Intern("arbace.template$apply_template")

var Lit_7 *jrt.String = jrt.Intern("arbace.template$do_template")
