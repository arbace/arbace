//line a2g_strings.ae:1
package aot_arbace_template

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.walk")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("walk")

var Lit_6 *jrt.String = jrt.Intern("commute")

var Lit_7 *jrt.String = jrt.Intern("deref")

var Lit_8 *jrt.String = jrt.Intern("conj")

var Lit_9 *jrt.String = jrt.Intern("arbace.template")

var Lit_10 *jrt.String = jrt.Intern("doc")

var Lit_11 *jrt.String = jrt.Intern("Macros that expand to repeated copies of a template expression.")

var Lit_12 *jrt.String = jrt.Intern("author")

var Lit_13 *jrt.String = jrt.Intern("Stuart Sierra")

var Lit_14 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_15 *jrt.String = jrt.Intern("postwalk-replace")

var Lit_16 *jrt.String = jrt.Intern("vector?")

var Lit_17 *jrt.String = jrt.Intern("pr-str")

var Lit_18 *jrt.String = jrt.Intern("every?")

var Lit_19 *jrt.String = jrt.Intern("argv")

var Lit_20 *jrt.String = jrt.Intern("line")

var Lit_21 *jrt.String = jrt.Intern("column")

var Lit_22 *jrt.String = jrt.Intern("symbol?")

var Lit_23 *jrt.String = jrt.Intern("zipmap")

var Lit_24 *jrt.String = jrt.Intern("seq")

var Lit_25 *jrt.String = jrt.Intern("concat")

var Lit_26 *jrt.String = jrt.Intern("list")

var Lit_27 *jrt.String = jrt.Intern("map")

var Lit_28 *jrt.String = jrt.Intern("do")

var Lit_29 *jrt.String = jrt.Intern("apply-template")

var Lit_30 *jrt.String = jrt.Intern("partition")

var Lit_31 *jrt.String = jrt.Intern("arbace.template$apply_template")

var Lit_32 *jrt.String = jrt.Intern("Assert failed: ")

var Lit_33 *jrt.String = jrt.Intern("arbace.template$do_template")

var Lit_34 *jrt.String = jrt.Intern("arbace.template$do_template$fn__348000013")

var Lit_35 *jrt.String = jrt.Intern("arbace.template$eval348000004$loading__1927001464__auto____348000005")

var Lit_36 *jrt.String = jrt.Intern("arbace.template$eval348000008$fn__348000009")

var Lit_37 *jrt.String = jrt.Intern("in-ns")

var Lit_38 *jrt.String = jrt.Intern("arglists")

var Lit_39 *jrt.String = jrt.Intern("expr")

var Lit_40 *jrt.String = jrt.Intern("values")

var Lit_41 *jrt.String = jrt.Intern("For use in macros.  argv is an argument list, as in defn.  expr is\n  a quoted expression using the symbols in argv.  values is a sequence\n  of values to be used for the arguments.\n\n  apply-template will recursively replace argument symbols in expr\n  with their corresponding values, returning a modified expr.\n\n  Example: (apply-template '[x] '(+ x x) '[2])\n           ;=> (+ 2 2)")

var Lit_42 *jrt.String = jrt.Intern("file")

var Lit_43 *jrt.String = jrt.Intern("arbace/template.ae")

var Lit_44 *jrt.String = jrt.Intern("do-template")

var Lit_45 *jrt.String = jrt.Intern("&")

var Lit_46 *jrt.String = jrt.Intern("Repeatedly copies expr (in a do block) for each group of arguments\n  in values.  values are automatically partitioned by the number of\n  arguments in argv, an argument vector as in defn.\n\n  Example: (macroexpand '(do-template [x y] (+ y x) 2 4 3 5))\n           ;=> (do (+ 4 2) (+ 5 3))")
