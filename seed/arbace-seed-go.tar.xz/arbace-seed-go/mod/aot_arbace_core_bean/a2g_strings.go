//line a2g_strings.ae:1
package aot_arbace_core_bean

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("in-ns")

var Lit_2 *jrt.String = jrt.Intern("bean-decapitalize")

var Lit_3 *jrt.String = jrt.Intern("private")

var Lit_4 *jrt.String = jrt.Intern("arglists")

var Lit_5 *jrt.String = jrt.Intern("s")

var Lit_6 *jrt.String = jrt.Intern("tag")

var Lit_7 *jrt.String = jrt.Intern("String")

var Lit_8 *jrt.String = jrt.Intern("doc")

var Lit_9 *jrt.String = jrt.Intern("java.beans.Introspector/decapitalize.")

var Lit_10 *jrt.String = jrt.Intern("line")

var Lit_11 *jrt.String = jrt.Intern("column")

var Lit_12 *jrt.String = jrt.Intern("file")

var Lit_13 *jrt.String = jrt.Intern("arbace/core_bean.ae")

var Lit_14 *jrt.String = jrt.Intern("bean-exported?")

var Lit_15 *jrt.String = jrt.Intern("c")

var Lit_16 *jrt.String = jrt.Intern("Class")

var Lit_17 *jrt.String = jrt.Intern("Whether c's module exports its package (the Go build, which has no modules: always).")

var Lit_18 *jrt.String = jrt.Intern("bean-accessible-method")

var Lit_19 *jrt.String = jrt.Intern("m")

var Lit_20 *jrt.String = jrt.Intern("java.lang.reflect.Method")

var Lit_21 *jrt.String = jrt.Intern("The method of a public, exported class or interface that m (declared by a class that is not\n  public) implements, as com.sun.beans.finder.MethodFinder/findAccessibleMethod finds it for\n  a method without parameters, or nil.")

var Lit_22 *jrt.String = jrt.Intern("bean-class-methods")

var Lit_23 *jrt.String = jrt.Intern("The methods without parameters java.beans.Introspector takes from class c itself\n  (com.sun.beans.introspect.MethodInfo/get): the public ones c declares (for a class that is\n  not public, the public interface method each implements, ignored when it comes from a\n  superclass, or the method itself when there is none), then the default methods of its\n  interfaces, in MethodInfo's order (name, then return type name).")

var Lit_24 *jrt.String = jrt.Intern("bean-class-reads")

var Lit_25 *jrt.String = jrt.Intern("{name getter} for class c itself, as com.sun.beans.introspect.PropertyInfo/get chooses the\n  read methods: isX() returning boolean first, else among the getX() with a result the last\n  in order whose type is assignable to the one chosen so far (not a default method).")

var Lit_26 *jrt.String = jrt.Intern("bean-properties")

var Lit_27 *jrt.String = jrt.Intern("{name getter}: the readable JavaBean properties of class c with a getter without\n  parameters, as java.beans.Introspector/getBeanInfo finds them without an explicit BeanInfo:\n  each class from Object down to c contributes its own read methods, a later one replacing an\n  earlier one unless that one is an isX() of another name. Sorted by name, the Introspector's\n  order, which bean's map keeps.")

var Lit_28 *jrt.String = jrt.Intern("bean")

var Lit_29 *jrt.String = jrt.Intern("x")

var Lit_30 *jrt.String = jrt.Intern("Object")

var Lit_31 *jrt.String = jrt.Intern("Takes a Java object and returns a read-only implementation of the\n  map abstraction based upon its JavaBean properties.")

var Lit_32 *jrt.String = jrt.Intern("added")

var Lit_33 *jrt.String = jrt.Intern("1.0")

var Lit_34 *jrt.String = jrt.Intern("get-proxy-class")

var Lit_35 *jrt.String = jrt.Intern("arbace.lang.APersistentMap")

var Lit_36 *jrt.String = jrt.Intern("java.lang.reflect.Modifier")
