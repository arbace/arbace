//line aot_arbace_core_bean__init.ae:1
package aot_arbace_core_bean

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_core_bean__init_A_Load__O() any { A_arbace_core_bean__init_A_Init(); A_arbace_core_bean__init_A_Unit0__O(); A_arbace_core_bean__init_A_Unit1__O(); A_arbace_core_bean__init_A_Unit2__O(); A_arbace_core_bean__init_A_Unit3__O(); A_arbace_core_bean__init_A_Unit4__O(); A_arbace_core_bean__init_A_Unit5__O(); A_arbace_core_bean__init_A_Unit6__O(); A_arbace_core_bean__init_A_Unit7__O(); A_arbace_core_bean__init_A_Unit8__O(); return nil }









func A_arbace_core_bean__init_A_Unit0__O() any { A_arbace_core_bean__init_A_Init(); lang.Compiler_AOT_At_I_I__V(15, 1); return lang.IFn_Cast(jrt.NN(A_arbace_core_bean__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_core_bean__init_A_const_1) }

func A_arbace_core_bean__init_A_Unit1__O() any { A_arbace_core_bean__init_A_Init(); lang.Compiler_AOT_At_I_I__V(17, 1); var tmp1 *lang.Var; lang.RT_Init(); tmp1 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp1).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_36)); return nil }


func A_arbace_core_bean__init_A_Unit2__O() any { A_arbace_core_bean__init_A_Init(); lang.Compiler_AOT_At_I_I__V(20, 1); var tmp1 *lang.Var = A_arbace_core_bean__init_A_const_2; var tmp2 any = aot_arbace_core.A_arbace_core_bean_decapitalize_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_bean_decapitalize_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_bean_decapitalize_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_bean__init_A_const_2; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_bean__init_A_const_3)); return A_arbace_core_bean__init_A_const_2.Ref() }






func A_arbace_core_bean__init_A_Unit3__O() any { A_arbace_core_bean__init_A_Init(); lang.Compiler_AOT_At_I_I__V(27, 1); var tmp1 *lang.Var = A_arbace_core_bean__init_A_const_4; var tmp2 any = aot_arbace_core.A_arbace_core_bean_exported_QMARK__A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_bean_exported_QMARK__A_Init(); tmp3 = aot_arbace_core.A_arbace_core_bean_exported_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_bean__init_A_const_4; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_bean__init_A_const_5)); return A_arbace_core_bean__init_A_const_4.Ref() }




func A_arbace_core_bean__init_A_Unit4__O() any { A_arbace_core_bean__init_A_Init(); lang.Compiler_AOT_At_I_I__V(32, 1); var tmp1 *lang.Var = A_arbace_core_bean__init_A_const_6; var tmp2 any = aot_arbace_core.A_arbace_core_bean_accessible_method_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_bean_accessible_method_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_bean_accessible_method_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_bean__init_A_const_6; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_bean__init_A_const_7)); return A_arbace_core_bean__init_A_const_6.Ref() }

















func A_arbace_core_bean__init_A_Unit5__O() any { A_arbace_core_bean__init_A_Init(); lang.Compiler_AOT_At_I_I__V(50, 1); var tmp1 *lang.Var = A_arbace_core_bean__init_A_const_8; var tmp2 any = aot_arbace_core.A_arbace_core_bean_class_methods_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_bean_class_methods_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_bean_class_methods_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_bean__init_A_const_8; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_bean__init_A_const_9)); return A_arbace_core_bean__init_A_const_8.Ref() }































func A_arbace_core_bean__init_A_Unit6__O() any { A_arbace_core_bean__init_A_Init(); lang.Compiler_AOT_At_I_I__V(82, 1); var tmp1 *lang.Var = A_arbace_core_bean__init_A_const_10; var tmp2 any = aot_arbace_core.A_arbace_core_bean_class_reads_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_bean_class_reads_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_bean_class_reads_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_bean__init_A_const_10; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_bean__init_A_const_11)); return A_arbace_core_bean__init_A_const_10.Ref() }


























func A_arbace_core_bean__init_A_Unit7__O() any { A_arbace_core_bean__init_A_Init(); lang.Compiler_AOT_At_I_I__V(109, 1); var tmp1 *lang.Var = A_arbace_core_bean__init_A_const_12; var tmp2 any = aot_arbace_core.A_arbace_core_bean_properties_A_New(); var tmp3 *jrt.Class; aot_arbace_core.A_arbace_core_bean_properties_A_Init(); tmp3 = aot_arbace_core.A_arbace_core_bean_properties_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_core_bean__init_A_const_12; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_bean__init_A_const_13)); return A_arbace_core_bean__init_A_const_12.Ref() }















func A_arbace_core_bean__init_A_Unit8__O() any { A_arbace_core_bean__init_A_Init(); lang.Compiler_AOT_At_I_I__V(125, 1); var tmp1 any = A_arbace_core_bean__init_A_const_17.Ref(); lang.IFn_Cast(jrt.NN(A_arbace_core_bean__init_A_const_16).GetRawRoot__O()).ApplyTo_ISeq__O(lang.RT_Cons_O_O__ISeq(tmp1, lang.RT_Seq_O__ISeq(jrt.RefArrayOf(jrt.Object_class)))); var tmp2 *lang.Var = A_arbace_core_bean__init_A_const_14; var tmp3 any = aot_arbace_core.A_arbace_core_bean_A_New(); var tmp4 *jrt.Class; aot_arbace_core.A_arbace_core_bean_A_Init(); tmp4 = aot_arbace_core.A_arbace_core_bean_A_fn_class; jrt.NN(tmp2).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)); var tmp5 *lang.Var = A_arbace_core_bean__init_A_const_14; jrt.NN(tmp5).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_core_bean__init_A_const_15)); return A_arbace_core_bean__init_A_const_14.Ref() }



type A_arbace_core_bean__init_A struct{ jrt.Object }

var A_arbace_core_bean__init_A_const_0 *lang.Var

var A_arbace_core_bean__init_A_const_1 any

var A_arbace_core_bean__init_A_const_2 *lang.Var

var A_arbace_core_bean__init_A_const_3 any

var A_arbace_core_bean__init_A_const_4 *lang.Var

var A_arbace_core_bean__init_A_const_5 any

var A_arbace_core_bean__init_A_const_6 *lang.Var

var A_arbace_core_bean__init_A_const_7 any

var A_arbace_core_bean__init_A_const_8 *lang.Var

var A_arbace_core_bean__init_A_const_9 any

var A_arbace_core_bean__init_A_const_10 *lang.Var

var A_arbace_core_bean__init_A_const_11 any

var A_arbace_core_bean__init_A_const_12 *lang.Var

var A_arbace_core_bean__init_A_const_13 any

var A_arbace_core_bean__init_A_const_14 *lang.Var

var A_arbace_core_bean__init_A_const_15 any

var A_arbace_core_bean__init_A_const_16 *lang.Var

var A_arbace_core_bean__init_A_const_17 *jrt.Class

var A_arbace_core_bean__init_A_init jrt.ClassInit

func A_arbace_core_bean__init_A_Init() { if !A_arbace_core_bean__init_A_init.Done() { A_arbace_core_bean__init_A_init.Run(A_arbace_core_bean__init_A_clinit) } }

func A_arbace_core_bean__init_A_clinit() { A_arbace_core_bean__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_core_bean__init_A_const_1 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_core_bean__init_A_const_2 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_core_bean__init_A_const_3 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_5)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(20).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_core_bean__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_14); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_core_bean__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_15)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_17, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(27).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_core_bean__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_18); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_core_bean__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.IObj_Cast(lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_19)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_20).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_20).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_21, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(32).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_core_bean__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_22); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_core_bean__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_15)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_23, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(50).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_core_bean__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_24); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_core_bean__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_15)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_25, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(82).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_core_bean__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_26); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_3).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_core_bean__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_15)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_27, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(109).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_core_bean__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_28); A_arbace_core_bean__init_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_29)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_30).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_31, lang.RT_Keyword_String_String__Keyword(nil, Lit_32).Ref(), Lit_33, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), jrt.Integer_ValueOf_I__Integer(125).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_core_bean__init_A_const_16 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_core_bean__init_A_const_17 = lang.RT_ClassForNameNonLoading_String__Class(Lit_35) }

func A_arbace_core_bean__init_A_New() *A_arbace_core_bean__init_A { A_arbace_core_bean__init_A_Init(); t := &A_arbace_core_bean__init_A{}; t.Ctor(); return t }

func (t *A_arbace_core_bean__init_A) Ctor() {}

func (t *A_arbace_core_bean__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_core_bean__init_A) GetClass__Class() *jrt.Class { return A_arbace_core_bean__init_A_class }

func (t *A_arbace_core_bean__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_core_bean__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_core_bean__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_core_bean__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_core_bean__init_A); return ok }

func A_arbace_core_bean__init_A_Cast(x any) *A_arbace_core_bean__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_core_bean__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_core_bean__init_A_class)) }; return v }
