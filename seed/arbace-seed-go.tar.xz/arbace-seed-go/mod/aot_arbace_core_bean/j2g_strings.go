//line j2g_strings.ae:1
package aot_arbace_core_bean

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.corekn7,privatekn8,arglistskn3,tagyn6,Stringkn3,dockn4,linekn6,columnkn4,fileyn5,Classyn24,java.lang.reflect.Methodyn6,Objectkn5,addedv11,arbace.core5,in-nsR0,v11,arbace.core17,bean-decapitalizem12,R1,TR2,L1,V1,Myn1,sm2,R3,R4,R5,s37,java.beans.Introspector/decapitalize.R6,i20,R7,i1,R8,s19,arbace/core_bean.aev11,arbace.core14,bean-exported?m12,R1,TR2,L1,V1,Myn1,cm2,R3,R9,R5,s84,Whether c's module exports its package (the Go build, which has no modules: always).R6,i27,R7,i1,R8,s19,arbace/core_bean.aev11,arbace.core22,bean-accessible-methodm12,R1,TR2,L1,MV1,Myn1,mm2,R3,R10,m2,R3,R10,R5,s223,The method of a public, exported class or interface that m (declared by a class that is not\n  public) implements, as com.sun.beans.finder.MethodFinder/findAccessibleMethod finds it for\n  a method without parameters, or nil.R6,i32,R7,i1,R8,s19,arbace/core_bean.aev11,arbace.core18,bean-class-methodsm12,R1,TR2,L1,V1,Myn1,cm2,R3,R9,R5,s416,The methods without parameters java.beans.Introspector takes from class c itself\n  (com.sun.beans.introspect.MethodInfo/get): the public ones c declares (for a class that is\n  not public, the public interface method each implements, ignored when it comes from a\n  superclass, or the method itself when there is none), then the default methods of its\n  interfaces, in MethodInfo's order (name, then return type name).R6,i50,R7,i1,R8,s19,arbace/core_bean.aev11,arbace.core16,bean-class-readsm12,R1,TR2,L1,V1,Myn1,cm2,R3,R9,R5,s267,{name getter} for class c itself, as com.sun.beans.introspect.PropertyInfo/get chooses the\n  read methods: isX() returning boolean first, else among the getX() with a result the last\n  in order whose type is assignable to the one chosen so far (not a default method).R6,i82,R7,i1,R8,s19,arbace/core_bean.aev11,arbace.core15,bean-propertiesm12,R1,TR2,L1,V1,Myn1,cm2,R3,R9,R5,s395,{name getter}: the readable JavaBean properties of class c with a getter without\n  parameters, as java.beans.Introspector/getBeanInfo finds them without an explicit BeanInfo:\n  each class from Object down to c contributes its own read methods, a later one replacing an\n  earlier one unless that one is an isX() of another name. Sorted by name, the Introspector's\n  order, which bean's map keeps.R6,i109,R7,i1,R8,s19,arbace/core_bean.aev11,arbace.core4,beanm12,R2,L1,V1,Myn1,xm2,R3,R11,R5,s119,Takes a Java object and returns a read-only implementation of the\n  map abstraction based upon its JavaBean properties.R12,s3,1.0R6,i125,R7,i1,R8,s19,arbace/core_bean.aev11,arbace.core15,get-proxy-classC26,arbace.lang.APersistentMap")

var Lit_1 *jrt.String = jrt.Intern("java.lang.reflect.Modifier")

var Lit_2 *jrt.String = jrt.Intern("arbace.core$bean_decapitalize")

var Lit_3 *jrt.String = jrt.Intern("arbace.core$bean_exported_QMARK_")

var Lit_4 *jrt.String = jrt.Intern("arbace.core$bean_accessible_method")

var Lit_5 *jrt.String = jrt.Intern("arbace.core$bean_class_methods")

var Lit_6 *jrt.String = jrt.Intern("arbace.core$bean_class_reads")

var Lit_7 *jrt.String = jrt.Intern("arbace.core$bean_properties")

var Lit_8 *jrt.String = jrt.Intern("arbace.core$bean")
