//line aot_arbace_go_check_code_expr__init.ae:1
package aot_arbace_go_check_code_expr

import (
	"arbace/aot_arbace_go_check_code"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_code_expr__init_A_Unit0__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_go_check_code_expr__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_code_expr__init_A_const_1) }



func A_arbace_go_check_code_expr__init_A_Unit1__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(5, 1); A_arbace_go_check_code_expr__init_A_const_2.BindRoot_O__V(A_arbace_go_check_code_expr__init_A_const_3); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_2; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_4)); return A_arbace_go_check_code_expr__init_A_const_2 }
//line :5:1
func A_arbace_go_check_code_expr__init_A_Load__O() any { A_arbace_go_check_code_expr__init_A_Init(); jrt.StartCheck(); A_arbace_go_check_code_expr__init_A_Unit0__O(); A_arbace_go_check_code_expr__init_A_Unit1__O(); A_arbace_go_check_code_expr__init_A_Unit2__O(); A_arbace_go_check_code_expr__init_A_Unit3__O(); A_arbace_go_check_code_expr__init_A_Unit4__O(); A_arbace_go_check_code_expr__init_A_Unit5__O(); A_arbace_go_check_code_expr__init_A_Unit6__O(); A_arbace_go_check_code_expr__init_A_Unit7__O(); A_arbace_go_check_code_expr__init_A_Unit8__O(); A_arbace_go_check_code_expr__init_A_Unit9__O(); A_arbace_go_check_code_expr__init_A_Unit10__O(); A_arbace_go_check_code_expr__init_A_Unit11__O(); A_arbace_go_check_code_expr__init_A_Unit12__O(); A_arbace_go_check_code_expr__init_A_Unit13__O(); A_arbace_go_check_code_expr__init_A_Unit14__O(); A_arbace_go_check_code_expr__init_A_Unit15__O(); A_arbace_go_check_code_expr__init_A_Unit16__O(); A_arbace_go_check_code_expr__init_A_Unit17__O(); A_arbace_go_check_code_expr__init_A_Unit18__O(); A_arbace_go_check_code_expr__init_A_Unit19__O(); A_arbace_go_check_code_expr__init_A_Unit20__O(); A_arbace_go_check_code_expr__init_A_Unit21__O(); A_arbace_go_check_code_expr__init_A_Unit22__O(); A_arbace_go_check_code_expr__init_A_Unit23__O(); A_arbace_go_check_code_expr__init_A_Unit24__O(); A_arbace_go_check_code_expr__init_A_Unit25__O(); A_arbace_go_check_code_expr__init_A_Unit26__O(); A_arbace_go_check_code_expr__init_A_Unit27__O(); A_arbace_go_check_code_expr__init_A_Unit28__O(); A_arbace_go_check_code_expr__init_A_Unit29__O(); A_arbace_go_check_code_expr__init_A_Unit30__O(); A_arbace_go_check_code_expr__init_A_Unit31__O(); A_arbace_go_check_code_expr__init_A_Unit32__O(); A_arbace_go_check_code_expr__init_A_Unit33__O(); A_arbace_go_check_code_expr__init_A_Unit34__O(); A_arbace_go_check_code_expr__init_A_Unit35__O(); A_arbace_go_check_code_expr__init_A_Unit36__O(); A_arbace_go_check_code_expr__init_A_Unit37__O(); A_arbace_go_check_code_expr__init_A_Unit38__O(); A_arbace_go_check_code_expr__init_A_Unit39__O(); A_arbace_go_check_code_expr__init_A_Unit40__O(); A_arbace_go_check_code_expr__init_A_Unit41__O(); A_arbace_go_check_code_expr__init_A_Unit42__O(); A_arbace_go_check_code_expr__init_A_Unit43__O(); A_arbace_go_check_code_expr__init_A_Unit44__O(); A_arbace_go_check_code_expr__init_A_Unit45__O(); A_arbace_go_check_code_expr__init_A_Unit46__O(); A_arbace_go_check_code_expr__init_A_Unit47__O(); A_arbace_go_check_code_expr__init_A_Unit48__O(); A_arbace_go_check_code_expr__init_A_Unit49__O(); A_arbace_go_check_code_expr__init_A_Unit50__O(); A_arbace_go_check_code_expr__init_A_Unit51__O(); A_arbace_go_check_code_expr__init_A_Unit52__O(); A_arbace_go_check_code_expr__init_A_Unit53__O(); A_arbace_go_check_code_expr__init_A_Unit54__O(); A_arbace_go_check_code_expr__init_A_Unit55__O(); A_arbace_go_check_code_expr__init_A_Unit56__O(); A_arbace_go_check_code_expr__init_A_Unit57__O(); A_arbace_go_check_code_expr__init_A_Unit58__O(); A_arbace_go_check_code_expr__init_A_Unit59__O(); A_arbace_go_check_code_expr__init_A_Unit60__O(); A_arbace_go_check_code_expr__init_A_Unit61__O(); A_arbace_go_check_code_expr__init_A_Unit62__O(); A_arbace_go_check_code_expr__init_A_Unit63__O(); A_arbace_go_check_code_expr__init_A_Unit64__O(); A_arbace_go_check_code_expr__init_A_Unit65__O(); A_arbace_go_check_code_expr__init_A_Unit66__O(); A_arbace_go_check_code_expr__init_A_Unit67__O(); A_arbace_go_check_code_expr__init_A_Unit68__O(); A_arbace_go_check_code_expr__init_A_Unit69__O(); A_arbace_go_check_code_expr__init_A_Unit70__O(); A_arbace_go_check_code_expr__init_A_Unit71__O(); return nil }




func A_arbace_go_check_code_expr__init_A_Unit2__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(10, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_5; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_rune_quote_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_rune_quote_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); aot_arbace_go_check_code.A_arbace_go_check_code_rune_quote_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_5; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_6)); return A_arbace_go_check_code_expr__init_A_const_5 }













func A_arbace_go_check_code_expr__init_A_Unit3__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(24, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_7; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_lit_str_A_New(); var tmp3 *jrt.Class; var fncls__2 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_lit_str_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); aot_arbace_go_check_code.A_arbace_go_check_code_lit_str_A_fn_class = fncls__2d; tmp3 = fncls__2d } else { tmp3 = fncls__2 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_7; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_8)); return A_arbace_go_check_code_expr__init_A_const_7 }








func A_arbace_go_check_code_expr__init_A_Unit4__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(33, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_9; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); aot_arbace_go_check_code.A_arbace_go_check_code_expr_str_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_9; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_10)); return A_arbace_go_check_code_expr__init_A_const_9 }
































































func A_arbace_go_check_code_expr__init_A_Unit5__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(98, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_11; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_exact_decimal_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_exact_decimal_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); aot_arbace_go_check_code.A_arbace_go_check_code_exact_decimal_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_12)); return A_arbace_go_check_code_expr__init_A_const_11 }












func A_arbace_go_check_code_expr__init_A_Unit6__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(111, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_13; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_g_format_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_g_format_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); aot_arbace_go_check_code.A_arbace_go_check_code_g_format_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_14)); return A_arbace_go_check_code_expr__init_A_const_13 }















func A_arbace_go_check_code_expr__init_A_Unit7__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(127, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_15; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_digits_of_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_digits_of_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); aot_arbace_go_check_code.A_arbace_go_check_code_digits_of_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_16)); return A_arbace_go_check_code_expr__init_A_const_15 }






func A_arbace_go_check_code_expr__init_A_Unit8__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(134, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_17; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_float_str_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_float_str_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); aot_arbace_go_check_code.A_arbace_go_check_code_float_str_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_18)); return A_arbace_go_check_code_expr__init_A_const_17 }








































func A_arbace_go_check_code_expr__init_A_Unit9__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(175, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_19; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_val_str_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_val_str_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); aot_arbace_go_check_code.A_arbace_go_check_code_val_str_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_20)); return A_arbace_go_check_code_expr__init_A_const_19 }












func A_arbace_go_check_code_expr__init_A_Unit10__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(188, 1); A_arbace_go_check_code_expr__init_A_const_21.BindRoot_O__V(A_arbace_go_check_code_expr__init_A_const_22); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_21; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_23)); return A_arbace_go_check_code_expr__init_A_const_21 }




func A_arbace_go_check_code_expr__init_A_Unit11__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(193, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_24; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_composite_kind_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_composite_kind_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); aot_arbace_go_check_code.A_arbace_go_check_code_composite_kind_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_25)); return A_arbace_go_check_code_expr__init_A_const_24 }






func A_arbace_go_check_code_expr__init_A_Unit12__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(200, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_26; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_operand_str_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_operand_str_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); aot_arbace_go_check_code.A_arbace_go_check_code_operand_str_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_27)); return A_arbace_go_check_code_expr__init_A_const_26 }




























func A_arbace_go_check_code_expr__init_A_Unit13__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(229, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_28; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_type_summary_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_type_summary_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); aot_arbace_go_check_code.A_arbace_go_check_code_type_summary_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_29)); return A_arbace_go_check_code_expr__init_A_const_28 }










func A_arbace_go_check_code_expr__init_A_Unit14__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(240, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_30; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_invalid_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_invalid_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); aot_arbace_go_check_code.A_arbace_go_check_code_invalid_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_31)); return A_arbace_go_check_code_expr__init_A_const_30 }
func A_arbace_go_check_code_expr__init_A_Unit15__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(241, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_32; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_invalid_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_invalid_QMARK__A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); aot_arbace_go_check_code.A_arbace_go_check_code_invalid_QMARK__A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_33)); return A_arbace_go_check_code_expr__init_A_const_32 }

func A_arbace_go_check_code_expr__init_A_Unit16__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(243, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_34; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_const_node_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_const_node_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); aot_arbace_go_check_code.A_arbace_go_check_code_const_node_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_35)); return A_arbace_go_check_code_expr__init_A_const_34 }



func A_arbace_go_check_code_expr__init_A_Unit17__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(247, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_36; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_int_of_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_int_of_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); aot_arbace_go_check_code.A_arbace_go_check_code_int_of_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_37)); return A_arbace_go_check_code_expr__init_A_const_36 }









func A_arbace_go_check_code_expr__init_A_Unit18__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(257, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_38; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_float_of_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_float_of_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); aot_arbace_go_check_code.A_arbace_go_check_code_float_of_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_39)); return A_arbace_go_check_code_expr__init_A_const_38 }






func A_arbace_go_check_code_expr__init_A_Unit19__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(264, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_40; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_complex_of_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_complex_of_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); aot_arbace_go_check_code.A_arbace_go_check_code_complex_of_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_41)); return A_arbace_go_check_code_expr__init_A_const_40 }





func A_arbace_go_check_code_expr__init_A_Unit20__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(270, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_42; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_int_range_ok_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_int_range_ok_QMARK__A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); aot_arbace_go_check_code.A_arbace_go_check_code_int_range_ok_QMARK__A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_43)); return A_arbace_go_check_code_expr__init_A_const_42 }














func A_arbace_go_check_code_expr__init_A_Unit21__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(285, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_44; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_representation_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_representation_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); aot_arbace_go_check_code.A_arbace_go_check_code_representation_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_45)); return A_arbace_go_check_code_expr__init_A_const_44 }



































func A_arbace_go_check_code_expr__init_A_Unit22__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(321, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_46; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_cmul_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_cmul_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); aot_arbace_go_check_code.A_arbace_go_check_code_cmul_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_47)); return A_arbace_go_check_code_expr__init_A_const_46 }
func A_arbace_go_check_code_expr__init_A_Unit23__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(322, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_48; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_cquo_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_cquo_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); aot_arbace_go_check_code.A_arbace_go_check_code_cquo_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_49)); return A_arbace_go_check_code_expr__init_A_const_48 }




func A_arbace_go_check_code_expr__init_A_Unit24__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(327, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_50; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_const_binary_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_const_binary_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); aot_arbace_go_check_code.A_arbace_go_check_code_const_binary_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_51)); return A_arbace_go_check_code_expr__init_A_const_50 }

























func A_arbace_go_check_code_expr__init_A_Unit25__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(353, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_52; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_const_compare_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_const_compare_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); aot_arbace_go_check_code.A_arbace_go_check_code_const_compare_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_53)); return A_arbace_go_check_code_expr__init_A_const_52 }














func A_arbace_go_check_code_expr__init_A_Unit26__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(368, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_54; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_val_sign_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_val_sign_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); aot_arbace_go_check_code.A_arbace_go_check_code_val_sign_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_55)); return A_arbace_go_check_code_expr__init_A_const_54 }









func A_arbace_go_check_code_expr__init_A_Unit27__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(378, 1); A_arbace_go_check_code_expr__init_A_const_56.BindRoot_O__V(A_arbace_go_check_code_expr__init_A_const_57); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_56; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_58)); return A_arbace_go_check_code_expr__init_A_const_56 }
func A_arbace_go_check_code_expr__init_A_Unit28__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(379, 1); A_arbace_go_check_code_expr__init_A_const_59.BindRoot_O__V(A_arbace_go_check_code_expr__init_A_const_60); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_59; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_61)); return A_arbace_go_check_code_expr__init_A_const_59 }

func A_arbace_go_check_code_expr__init_A_Unit29__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(381, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_62; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_max_type_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_max_type_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); aot_arbace_go_check_code.A_arbace_go_check_code_max_type_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_63)); return A_arbace_go_check_code_expr__init_A_const_62 }







func A_arbace_go_check_code_expr__init_A_Unit30__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(389, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_64; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_implicit_type_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_implicit_type_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); aot_arbace_go_check_code.A_arbace_go_check_code_implicit_type_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_65)); return A_arbace_go_check_code_expr__init_A_const_64 }






































func A_arbace_go_check_code_expr__init_A_Unit31__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(428, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_66; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_67)); return A_arbace_go_check_code_expr__init_A_const_66 }

func A_arbace_go_check_code_expr__init_A_Unit32__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(430, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_68; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_update_type_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_update_type_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); aot_arbace_go_check_code.A_arbace_go_check_code_update_type_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_69)); return A_arbace_go_check_code_expr__init_A_const_68 }











func A_arbace_go_check_code_expr__init_A_Unit33__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(442, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_66; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_update_type_STAR__A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_update_type_STAR__A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); aot_arbace_go_check_code.A_arbace_go_check_code_update_type_STAR__A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_70)); return A_arbace_go_check_code_expr__init_A_const_66 }





























func A_arbace_go_check_code_expr__init_A_Unit34__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(472, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_71; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_invalid_conversion_BANG__A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_invalid_conversion_BANG__A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); aot_arbace_go_check_code.A_arbace_go_check_code_invalid_conversion_BANG__A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_72)); return A_arbace_go_check_code_expr__init_A_const_71 }










func A_arbace_go_check_code_expr__init_A_Unit35__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(483, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_73; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_convert_untyped_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_convert_untyped_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); aot_arbace_go_check_code.A_arbace_go_check_code_convert_untyped_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_74)); return A_arbace_go_check_code_expr__init_A_const_73 }
















func A_arbace_go_check_code_expr__init_A_Unit36__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(500, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_75; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_default_final_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_default_final_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); aot_arbace_go_check_code.A_arbace_go_check_code_default_final_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_75; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_76)); return A_arbace_go_check_code_expr__init_A_const_75 }








func A_arbace_go_check_code_expr__init_A_Unit37__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(509, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_77; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_single_value_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_single_value_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); aot_arbace_go_check_code.A_arbace_go_check_code_single_value_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_77; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_78)); return A_arbace_go_check_code_expr__init_A_const_77 }








func A_arbace_go_check_code_expr__init_A_Unit38__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(518, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_79; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_exclude_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_exclude_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); aot_arbace_go_check_code.A_arbace_go_check_code_exclude_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_79; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_80)); return A_arbace_go_check_code_expr__init_A_const_79 }










func A_arbace_go_check_code_expr__init_A_Unit39__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(529, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_81; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_82)); return A_arbace_go_check_code_expr__init_A_const_81 }

func A_arbace_go_check_code_expr__init_A_Unit40__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(531, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_83; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_expr_A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_expr_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); aot_arbace_go_check_code.A_arbace_go_check_code_expr_A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_83; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_84)); return A_arbace_go_check_code_expr__init_A_const_83 }








func A_arbace_go_check_code_expr__init_A_Unit41__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(540, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_85; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_expr_or_type_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_expr_or_type_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); aot_arbace_go_check_code.A_arbace_go_check_code_expr_or_type_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_85; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_86)); return A_arbace_go_check_code_expr__init_A_const_85 }







func A_arbace_go_check_code_expr__init_A_Unit42__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(548, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_87; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_multi_expr_A_New(); var tmp3 *jrt.Class; var fncls__36 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_multi_expr_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); aot_arbace_go_check_code.A_arbace_go_check_code_multi_expr_A_fn_class = fncls__36d; tmp3 = fncls__36d } else { tmp3 = fncls__36 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_87; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_88)); return A_arbace_go_check_code_expr__init_A_const_87 }















func A_arbace_go_check_code_expr__init_A_Unit43__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(564, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_89; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_const_expr_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_const_expr_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); aot_arbace_go_check_code.A_arbace_go_check_code_const_expr_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_89; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_90)); return A_arbace_go_check_code_expr__init_A_const_89 }






func A_arbace_go_check_code_expr__init_A_Unit44__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(571, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_91; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_92)); return A_arbace_go_check_code_expr__init_A_const_91 }

func A_arbace_go_check_code_expr__init_A_Unit45__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(573, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_93; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_tparam_terms_A_New(); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_tparam_terms_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); aot_arbace_go_check_code.A_arbace_go_check_code_tparam_terms_A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_93; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_94)); return A_arbace_go_check_code_expr__init_A_const_93 }




func A_arbace_go_check_code_expr__init_A_Unit46__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(578, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_95; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_assignable_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_assignable_QMARK__A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); aot_arbace_go_check_code.A_arbace_go_check_code_assignable_QMARK__A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_95; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_96)); return A_arbace_go_check_code_expr__init_A_const_95 }



































func A_arbace_go_check_code_expr__init_A_Unit47__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(614, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_97; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_missing_cause_A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_missing_cause_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); aot_arbace_go_check_code.A_arbace_go_check_code_missing_cause_A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_97; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_98)); return A_arbace_go_check_code_expr__init_A_const_97 }

















func A_arbace_go_check_code_expr__init_A_Unit48__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(632, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_91; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_implements_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_implements_QMARK__A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); aot_arbace_go_check_code.A_arbace_go_check_code_implements_QMARK__A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_91; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_99)); return A_arbace_go_check_code_expr__init_A_const_91 }

func A_arbace_go_check_code_expr__init_A_Unit49__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(634, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_100; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_wrap_iface_A_New(); var tmp3 *jrt.Class; var fncls__42 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_wrap_iface_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); aot_arbace_go_check_code.A_arbace_go_check_code_wrap_iface_A_fn_class = fncls__42d; tmp3 = fncls__42d } else { tmp3 = fncls__42 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_100; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_101)); return A_arbace_go_check_code_expr__init_A_const_100 }








func A_arbace_go_check_code_expr__init_A_Unit50__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(643, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_102; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_103)); return A_arbace_go_check_code_expr__init_A_const_102 }

func A_arbace_go_check_code_expr__init_A_Unit51__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(645, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_104; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_assign_cause_str_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_assign_cause_str_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); aot_arbace_go_check_code.A_arbace_go_check_code_assign_cause_str_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_104; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_105)); return A_arbace_go_check_code_expr__init_A_const_104 }










func A_arbace_go_check_code_expr__init_A_Unit52__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(656, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_106; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_assignment_A_New(); var tmp3 *jrt.Class; var fncls__44 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_assignment_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); aot_arbace_go_check_code.A_arbace_go_check_code_assignment_A_fn_class = fncls__44d; tmp3 = fncls__44d } else { tmp3 = fncls__44 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_106; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_107)); return A_arbace_go_check_code_expr__init_A_const_106 }















func A_arbace_go_check_code_expr__init_A_Unit53__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(672, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_102; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_assignment_STAR__A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_assignment_STAR__A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); aot_arbace_go_check_code.A_arbace_go_check_code_assignment_STAR__A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_102; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_108)); return A_arbace_go_check_code_expr__init_A_const_102 }









































func A_arbace_go_check_code_expr__init_A_Unit54__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(714, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_109; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_bytes_or_runes_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__46 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_bytes_or_runes_QMARK__A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); aot_arbace_go_check_code.A_arbace_go_check_code_bytes_or_runes_QMARK__A_fn_class = fncls__46d; tmp3 = fncls__46d } else { tmp3 = fncls__46 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_109; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_110)); return A_arbace_go_check_code_expr__init_A_const_109 }




func A_arbace_go_check_code_expr__init_A_Unit55__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(719, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_111; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_convertible_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_convertible_QMARK__A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); aot_arbace_go_check_code.A_arbace_go_check_code_convertible_QMARK__A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_111; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_112)); return A_arbace_go_check_code_expr__init_A_const_111 }






























func A_arbace_go_check_code_expr__init_A_Unit56__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(750, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_113; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_conversion_A_New(); var tmp3 *jrt.Class; var fncls__48 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_conversion_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); aot_arbace_go_check_code.A_arbace_go_check_code_conversion_A_fn_class = fncls__48d; tmp3 = fncls__48d } else { tmp3 = fncls__48 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_113; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_114)); return A_arbace_go_check_code_expr__init_A_const_113 }

























































func A_arbace_go_check_code_expr__init_A_Unit57__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(808, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_115; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_op_allowed_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_op_allowed_QMARK__A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); aot_arbace_go_check_code.A_arbace_go_check_code_op_allowed_QMARK__A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_115; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_116)); return A_arbace_go_check_code_expr__init_A_const_115 }















func A_arbace_go_check_code_expr__init_A_Unit58__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(824, 1); A_arbace_go_check_code_expr__init_A_const_117.BindRoot_O__V(A_arbace_go_check_code_expr__init_A_const_118); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_117; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_119)); return A_arbace_go_check_code_expr__init_A_const_117 }




func A_arbace_go_check_code_expr__init_A_Unit59__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(829, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_120; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_overflow_A_New(); var tmp3 *jrt.Class; var fncls__50 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_overflow_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); aot_arbace_go_check_code.A_arbace_go_check_code_overflow_A_fn_class = fncls__50d; tmp3 = fncls__50d } else { tmp3 = fncls__50 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_120; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_121)); return A_arbace_go_check_code_expr__init_A_const_120 }





















func A_arbace_go_check_code_expr__init_A_Unit60__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(851, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_122; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_unary_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_unary_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); aot_arbace_go_check_code.A_arbace_go_check_code_unary_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_122; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_123)); return A_arbace_go_check_code_expr__init_A_const_122 }























func A_arbace_go_check_code_expr__init_A_Unit61__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(875, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_124; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_may_convert_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_may_convert_QMARK__A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); aot_arbace_go_check_code.A_arbace_go_check_code_may_convert_QMARK__A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_124; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_125)); return A_arbace_go_check_code_expr__init_A_const_124 }












func A_arbace_go_check_code_expr__init_A_Unit62__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(888, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_126; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_match_types_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_match_types_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); aot_arbace_go_check_code.A_arbace_go_check_code_match_types_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_126; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_127)); return A_arbace_go_check_code_expr__init_A_const_126 }










func A_arbace_go_check_code_expr__init_A_Unit63__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(899, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_128; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_comparison_A_New(); var tmp3 *jrt.Class; var fncls__54 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_comparison_A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); aot_arbace_go_check_code.A_arbace_go_check_code_comparison_A_fn_class = fncls__54d; tmp3 = fncls__54d } else { tmp3 = fncls__54 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_128; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_129)); return A_arbace_go_check_code_expr__init_A_const_128 }






































func A_arbace_go_check_code_expr__init_A_Unit64__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(938, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_130; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_finish_comparison_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_finish_comparison_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); aot_arbace_go_check_code.A_arbace_go_check_code_finish_comparison_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_130; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_131)); return A_arbace_go_check_code_expr__init_A_const_130 }







func A_arbace_go_check_code_expr__init_A_Unit65__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(946, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_132; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_shift_A_New(); var tmp3 *jrt.Class; var fncls__56 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_shift_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); aot_arbace_go_check_code.A_arbace_go_check_code_shift_A_fn_class = fncls__56d; tmp3 = fncls__56d } else { tmp3 = fncls__56 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_132; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_133)); return A_arbace_go_check_code_expr__init_A_const_132 }
























































func A_arbace_go_check_code_expr__init_A_Unit66__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1003, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_134; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_binary_nodes_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_binary_nodes_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); aot_arbace_go_check_code.A_arbace_go_check_code_binary_nodes_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_134; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_135)); return A_arbace_go_check_code_expr__init_A_const_134 }


































func A_arbace_go_check_code_expr__init_A_Unit67__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1038, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_136; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_binary_A_New(); var tmp3 *jrt.Class; var fncls__58 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_binary_A_fn_class; if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); aot_arbace_go_check_code.A_arbace_go_check_code_binary_A_fn_class = fncls__58d; tmp3 = fncls__58d } else { tmp3 = fncls__58 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_136; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_137)); return A_arbace_go_check_code_expr__init_A_const_136 }














func A_arbace_go_check_code_expr__init_A_Unit68__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1053, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_138; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_val_float_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_val_float_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); aot_arbace_go_check_code.A_arbace_go_check_code_val_float_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_138; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_139)); return A_arbace_go_check_code_expr__init_A_const_138 }











func A_arbace_go_check_code_expr__init_A_Unit69__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1065, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_140; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_val_equal_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__60 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_val_equal_QMARK__A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); aot_arbace_go_check_code.A_arbace_go_check_code_val_equal_QMARK__A_fn_class = fncls__60d; tmp3 = fncls__60d } else { tmp3 = fncls__60 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_140; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_141)); return A_arbace_go_check_code_expr__init_A_const_140 }
























func A_arbace_go_check_code_expr__init_A_Unit70__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1090, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_142; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_val_const_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_val_const_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_61, false); aot_arbace_go_check_code.A_arbace_go_check_code_val_const_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_142; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_143)); return A_arbace_go_check_code_expr__init_A_const_142 }

























func A_arbace_go_check_code_expr__init_A_Unit71__O() any { A_arbace_go_check_code_expr__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1116, 1); var tmp1 *lang.Var = A_arbace_go_check_code_expr__init_A_const_144; var tmp2 any = aot_arbace_go_check_code.A_arbace_go_check_code_val_form_str_A_New(); var tmp3 *jrt.Class; var fncls__62 *jrt.Class = aot_arbace_go_check_code.A_arbace_go_check_code_val_form_str_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); aot_arbace_go_check_code.A_arbace_go_check_code_val_form_str_A_fn_class = fncls__62d; tmp3 = fncls__62d } else { tmp3 = fncls__62 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_go_check_code_expr__init_A_const_144; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_code_expr__init_A_const_145)); return A_arbace_go_check_code_expr__init_A_const_144 }



type A_arbace_go_check_code_expr__init_A struct{ jrt.Object }

var A_arbace_go_check_code_expr__init_A_const_pool *jrt.RefArray

var A_arbace_go_check_code_expr__init_A_const_0 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_1 any

var A_arbace_go_check_code_expr__init_A_const_2 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_3 any

var A_arbace_go_check_code_expr__init_A_const_4 any

var A_arbace_go_check_code_expr__init_A_const_5 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_6 any

var A_arbace_go_check_code_expr__init_A_const_7 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_8 any

var A_arbace_go_check_code_expr__init_A_const_9 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_10 any

var A_arbace_go_check_code_expr__init_A_const_11 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_12 any

var A_arbace_go_check_code_expr__init_A_const_13 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_14 any

var A_arbace_go_check_code_expr__init_A_const_15 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_16 any

var A_arbace_go_check_code_expr__init_A_const_17 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_18 any

var A_arbace_go_check_code_expr__init_A_const_19 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_20 any

var A_arbace_go_check_code_expr__init_A_const_21 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_22 any

var A_arbace_go_check_code_expr__init_A_const_23 any

var A_arbace_go_check_code_expr__init_A_const_24 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_25 any

var A_arbace_go_check_code_expr__init_A_const_26 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_27 any

var A_arbace_go_check_code_expr__init_A_const_28 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_29 any

var A_arbace_go_check_code_expr__init_A_const_30 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_31 any

var A_arbace_go_check_code_expr__init_A_const_32 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_33 any

var A_arbace_go_check_code_expr__init_A_const_34 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_35 any

var A_arbace_go_check_code_expr__init_A_const_36 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_37 any

var A_arbace_go_check_code_expr__init_A_const_38 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_39 any

var A_arbace_go_check_code_expr__init_A_const_40 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_41 any

var A_arbace_go_check_code_expr__init_A_const_42 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_43 any

var A_arbace_go_check_code_expr__init_A_const_44 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_45 any

var A_arbace_go_check_code_expr__init_A_const_46 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_47 any

var A_arbace_go_check_code_expr__init_A_const_48 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_49 any

var A_arbace_go_check_code_expr__init_A_const_50 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_51 any

var A_arbace_go_check_code_expr__init_A_const_52 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_53 any

var A_arbace_go_check_code_expr__init_A_const_54 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_55 any

var A_arbace_go_check_code_expr__init_A_const_56 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_57 any

var A_arbace_go_check_code_expr__init_A_const_58 any

var A_arbace_go_check_code_expr__init_A_const_59 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_60 any

var A_arbace_go_check_code_expr__init_A_const_61 any

var A_arbace_go_check_code_expr__init_A_const_62 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_63 any

var A_arbace_go_check_code_expr__init_A_const_64 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_65 any

var A_arbace_go_check_code_expr__init_A_const_66 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_67 any

var A_arbace_go_check_code_expr__init_A_const_68 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_69 any

var A_arbace_go_check_code_expr__init_A_const_70 any

var A_arbace_go_check_code_expr__init_A_const_71 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_72 any

var A_arbace_go_check_code_expr__init_A_const_73 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_74 any

var A_arbace_go_check_code_expr__init_A_const_75 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_76 any

var A_arbace_go_check_code_expr__init_A_const_77 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_78 any

var A_arbace_go_check_code_expr__init_A_const_79 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_80 any

var A_arbace_go_check_code_expr__init_A_const_81 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_82 any

var A_arbace_go_check_code_expr__init_A_const_83 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_84 any

var A_arbace_go_check_code_expr__init_A_const_85 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_86 any

var A_arbace_go_check_code_expr__init_A_const_87 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_88 any

var A_arbace_go_check_code_expr__init_A_const_89 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_90 any

var A_arbace_go_check_code_expr__init_A_const_91 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_92 any

var A_arbace_go_check_code_expr__init_A_const_93 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_94 any

var A_arbace_go_check_code_expr__init_A_const_95 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_96 any

var A_arbace_go_check_code_expr__init_A_const_97 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_98 any

var A_arbace_go_check_code_expr__init_A_const_99 any

var A_arbace_go_check_code_expr__init_A_const_100 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_101 any

var A_arbace_go_check_code_expr__init_A_const_102 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_103 any

var A_arbace_go_check_code_expr__init_A_const_104 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_105 any

var A_arbace_go_check_code_expr__init_A_const_106 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_107 any

var A_arbace_go_check_code_expr__init_A_const_108 any

var A_arbace_go_check_code_expr__init_A_const_109 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_110 any

var A_arbace_go_check_code_expr__init_A_const_111 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_112 any

var A_arbace_go_check_code_expr__init_A_const_113 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_114 any

var A_arbace_go_check_code_expr__init_A_const_115 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_116 any

var A_arbace_go_check_code_expr__init_A_const_117 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_118 any

var A_arbace_go_check_code_expr__init_A_const_119 any

var A_arbace_go_check_code_expr__init_A_const_120 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_121 any

var A_arbace_go_check_code_expr__init_A_const_122 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_123 any

var A_arbace_go_check_code_expr__init_A_const_124 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_125 any

var A_arbace_go_check_code_expr__init_A_const_126 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_127 any

var A_arbace_go_check_code_expr__init_A_const_128 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_129 any

var A_arbace_go_check_code_expr__init_A_const_130 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_131 any

var A_arbace_go_check_code_expr__init_A_const_132 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_133 any

var A_arbace_go_check_code_expr__init_A_const_134 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_135 any

var A_arbace_go_check_code_expr__init_A_const_136 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_137 any

var A_arbace_go_check_code_expr__init_A_const_138 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_139 any

var A_arbace_go_check_code_expr__init_A_const_140 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_141 any

var A_arbace_go_check_code_expr__init_A_const_142 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_143 any

var A_arbace_go_check_code_expr__init_A_const_144 *lang.Var

var A_arbace_go_check_code_expr__init_A_const_145 any

var A_arbace_go_check_code_expr__init_A_init jrt.ClassInit

func A_arbace_go_check_code_expr__init_A_Init() { if !A_arbace_go_check_code_expr__init_A_init.Done() { A_arbace_go_check_code_expr__init_A_init.Run(A_arbace_go_check_code_expr__init_A_clinit) } }

func A_arbace_go_check_code_expr__init_A_clinit() { A_arbace_go_check_code_expr__init_A_clinit_p0(); A_arbace_go_check_code_expr__init_A_clinit_p1(); A_arbace_go_check_code_expr__init_A_clinit_p2(); A_arbace_go_check_code_expr__init_A_clinit_p3(); A_arbace_go_check_code_expr__init_A_clinit_p4(); A_arbace_go_check_code_expr__init_A_clinit_p5(); A_arbace_go_check_code_expr__init_A_clinit_p6(); A_arbace_go_check_code_expr__init_A_clinit_p7(); A_arbace_go_check_code_expr__init_A_clinit_p8(); A_arbace_go_check_code_expr__init_A_clinit_p9(); A_arbace_go_check_code_expr__init_A_clinit_p10() }

func A_arbace_go_check_code_expr__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_code_expr__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 201); A_arbace_go_check_code_expr__init_A_const_0 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[55]); A_arbace_go_check_code_expr__init_A_const_1 = A_arbace_go_check_code_expr__init_A_const_pool.A[56]; A_arbace_go_check_code_expr__init_A_const_2 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[57]); A_arbace_go_check_code_expr__init_A_const_3 = A_arbace_go_check_code_expr__init_A_const_pool.A[58]; A_arbace_go_check_code_expr__init_A_const_4 = A_arbace_go_check_code_expr__init_A_const_pool.A[59]; A_arbace_go_check_code_expr__init_A_const_5 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[60]); A_arbace_go_check_code_expr__init_A_const_6 = A_arbace_go_check_code_expr__init_A_const_pool.A[61]; A_arbace_go_check_code_expr__init_A_const_7 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[62]); A_arbace_go_check_code_expr__init_A_const_8 = A_arbace_go_check_code_expr__init_A_const_pool.A[63]; A_arbace_go_check_code_expr__init_A_const_9 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[64]); A_arbace_go_check_code_expr__init_A_const_10 = A_arbace_go_check_code_expr__init_A_const_pool.A[65]; A_arbace_go_check_code_expr__init_A_const_11 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[66]); A_arbace_go_check_code_expr__init_A_const_12 = A_arbace_go_check_code_expr__init_A_const_pool.A[67] }

func A_arbace_go_check_code_expr__init_A_clinit_p1() { A_arbace_go_check_code_expr__init_A_const_13 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[68]); A_arbace_go_check_code_expr__init_A_const_14 = A_arbace_go_check_code_expr__init_A_const_pool.A[69]; A_arbace_go_check_code_expr__init_A_const_15 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[70]); A_arbace_go_check_code_expr__init_A_const_16 = A_arbace_go_check_code_expr__init_A_const_pool.A[71]; A_arbace_go_check_code_expr__init_A_const_17 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[72]); A_arbace_go_check_code_expr__init_A_const_18 = A_arbace_go_check_code_expr__init_A_const_pool.A[73]; A_arbace_go_check_code_expr__init_A_const_19 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[74]); A_arbace_go_check_code_expr__init_A_const_20 = A_arbace_go_check_code_expr__init_A_const_pool.A[75]; A_arbace_go_check_code_expr__init_A_const_21 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[76]); A_arbace_go_check_code_expr__init_A_const_22 = A_arbace_go_check_code_expr__init_A_const_pool.A[77]; A_arbace_go_check_code_expr__init_A_const_23 = A_arbace_go_check_code_expr__init_A_const_pool.A[78]; A_arbace_go_check_code_expr__init_A_const_24 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[79]); A_arbace_go_check_code_expr__init_A_const_25 = A_arbace_go_check_code_expr__init_A_const_pool.A[80] }

func A_arbace_go_check_code_expr__init_A_clinit_p2() { A_arbace_go_check_code_expr__init_A_const_26 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[81]); A_arbace_go_check_code_expr__init_A_const_27 = A_arbace_go_check_code_expr__init_A_const_pool.A[82]; A_arbace_go_check_code_expr__init_A_const_28 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[83]); A_arbace_go_check_code_expr__init_A_const_29 = A_arbace_go_check_code_expr__init_A_const_pool.A[84]; A_arbace_go_check_code_expr__init_A_const_30 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[85]); A_arbace_go_check_code_expr__init_A_const_31 = A_arbace_go_check_code_expr__init_A_const_pool.A[86]; A_arbace_go_check_code_expr__init_A_const_32 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[87]); A_arbace_go_check_code_expr__init_A_const_33 = A_arbace_go_check_code_expr__init_A_const_pool.A[88]; A_arbace_go_check_code_expr__init_A_const_34 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[89]); A_arbace_go_check_code_expr__init_A_const_35 = A_arbace_go_check_code_expr__init_A_const_pool.A[90]; A_arbace_go_check_code_expr__init_A_const_36 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[91]); A_arbace_go_check_code_expr__init_A_const_37 = A_arbace_go_check_code_expr__init_A_const_pool.A[92]; A_arbace_go_check_code_expr__init_A_const_38 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[93]) }

func A_arbace_go_check_code_expr__init_A_clinit_p3() { A_arbace_go_check_code_expr__init_A_const_39 = A_arbace_go_check_code_expr__init_A_const_pool.A[94]; A_arbace_go_check_code_expr__init_A_const_40 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[95]); A_arbace_go_check_code_expr__init_A_const_41 = A_arbace_go_check_code_expr__init_A_const_pool.A[96]; A_arbace_go_check_code_expr__init_A_const_42 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[97]); A_arbace_go_check_code_expr__init_A_const_43 = A_arbace_go_check_code_expr__init_A_const_pool.A[98]; A_arbace_go_check_code_expr__init_A_const_44 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[99]); A_arbace_go_check_code_expr__init_A_const_45 = A_arbace_go_check_code_expr__init_A_const_pool.A[100]; A_arbace_go_check_code_expr__init_A_const_46 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[101]); A_arbace_go_check_code_expr__init_A_const_47 = A_arbace_go_check_code_expr__init_A_const_pool.A[102]; A_arbace_go_check_code_expr__init_A_const_48 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[103]); A_arbace_go_check_code_expr__init_A_const_49 = A_arbace_go_check_code_expr__init_A_const_pool.A[104]; A_arbace_go_check_code_expr__init_A_const_50 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[105]); A_arbace_go_check_code_expr__init_A_const_51 = A_arbace_go_check_code_expr__init_A_const_pool.A[106] }

func A_arbace_go_check_code_expr__init_A_clinit_p4() { A_arbace_go_check_code_expr__init_A_const_52 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[107]); A_arbace_go_check_code_expr__init_A_const_53 = A_arbace_go_check_code_expr__init_A_const_pool.A[108]; A_arbace_go_check_code_expr__init_A_const_54 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[109]); A_arbace_go_check_code_expr__init_A_const_55 = A_arbace_go_check_code_expr__init_A_const_pool.A[110]; A_arbace_go_check_code_expr__init_A_const_56 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[111]); A_arbace_go_check_code_expr__init_A_const_57 = A_arbace_go_check_code_expr__init_A_const_pool.A[112]; A_arbace_go_check_code_expr__init_A_const_58 = A_arbace_go_check_code_expr__init_A_const_pool.A[113]; A_arbace_go_check_code_expr__init_A_const_59 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[114]); A_arbace_go_check_code_expr__init_A_const_60 = A_arbace_go_check_code_expr__init_A_const_pool.A[115]; A_arbace_go_check_code_expr__init_A_const_61 = A_arbace_go_check_code_expr__init_A_const_pool.A[116]; A_arbace_go_check_code_expr__init_A_const_62 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[117]); A_arbace_go_check_code_expr__init_A_const_63 = A_arbace_go_check_code_expr__init_A_const_pool.A[118]; A_arbace_go_check_code_expr__init_A_const_64 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[119]); A_arbace_go_check_code_expr__init_A_const_65 = A_arbace_go_check_code_expr__init_A_const_pool.A[120] }

func A_arbace_go_check_code_expr__init_A_clinit_p5() { A_arbace_go_check_code_expr__init_A_const_66 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[121]); A_arbace_go_check_code_expr__init_A_const_67 = A_arbace_go_check_code_expr__init_A_const_pool.A[122]; A_arbace_go_check_code_expr__init_A_const_68 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[123]); A_arbace_go_check_code_expr__init_A_const_69 = A_arbace_go_check_code_expr__init_A_const_pool.A[124]; A_arbace_go_check_code_expr__init_A_const_70 = A_arbace_go_check_code_expr__init_A_const_pool.A[125]; A_arbace_go_check_code_expr__init_A_const_71 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[126]); A_arbace_go_check_code_expr__init_A_const_72 = A_arbace_go_check_code_expr__init_A_const_pool.A[127]; A_arbace_go_check_code_expr__init_A_const_73 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[128]); A_arbace_go_check_code_expr__init_A_const_74 = A_arbace_go_check_code_expr__init_A_const_pool.A[129]; A_arbace_go_check_code_expr__init_A_const_75 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[130]); A_arbace_go_check_code_expr__init_A_const_76 = A_arbace_go_check_code_expr__init_A_const_pool.A[131]; A_arbace_go_check_code_expr__init_A_const_77 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[132]); A_arbace_go_check_code_expr__init_A_const_78 = A_arbace_go_check_code_expr__init_A_const_pool.A[133] }

func A_arbace_go_check_code_expr__init_A_clinit_p6() { A_arbace_go_check_code_expr__init_A_const_79 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[134]); A_arbace_go_check_code_expr__init_A_const_80 = A_arbace_go_check_code_expr__init_A_const_pool.A[135]; A_arbace_go_check_code_expr__init_A_const_81 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[136]); A_arbace_go_check_code_expr__init_A_const_82 = A_arbace_go_check_code_expr__init_A_const_pool.A[137]; A_arbace_go_check_code_expr__init_A_const_83 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[138]); A_arbace_go_check_code_expr__init_A_const_84 = A_arbace_go_check_code_expr__init_A_const_pool.A[139]; A_arbace_go_check_code_expr__init_A_const_85 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[140]); A_arbace_go_check_code_expr__init_A_const_86 = A_arbace_go_check_code_expr__init_A_const_pool.A[141]; A_arbace_go_check_code_expr__init_A_const_87 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[142]); A_arbace_go_check_code_expr__init_A_const_88 = A_arbace_go_check_code_expr__init_A_const_pool.A[143]; A_arbace_go_check_code_expr__init_A_const_89 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[144]); A_arbace_go_check_code_expr__init_A_const_90 = A_arbace_go_check_code_expr__init_A_const_pool.A[145]; A_arbace_go_check_code_expr__init_A_const_91 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[146]) }

func A_arbace_go_check_code_expr__init_A_clinit_p7() { A_arbace_go_check_code_expr__init_A_const_92 = A_arbace_go_check_code_expr__init_A_const_pool.A[147]; A_arbace_go_check_code_expr__init_A_const_93 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[148]); A_arbace_go_check_code_expr__init_A_const_94 = A_arbace_go_check_code_expr__init_A_const_pool.A[149]; A_arbace_go_check_code_expr__init_A_const_95 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[150]); A_arbace_go_check_code_expr__init_A_const_96 = A_arbace_go_check_code_expr__init_A_const_pool.A[151]; A_arbace_go_check_code_expr__init_A_const_97 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[152]); A_arbace_go_check_code_expr__init_A_const_98 = A_arbace_go_check_code_expr__init_A_const_pool.A[153]; A_arbace_go_check_code_expr__init_A_const_99 = A_arbace_go_check_code_expr__init_A_const_pool.A[154]; A_arbace_go_check_code_expr__init_A_const_100 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[155]); A_arbace_go_check_code_expr__init_A_const_101 = A_arbace_go_check_code_expr__init_A_const_pool.A[156]; A_arbace_go_check_code_expr__init_A_const_102 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[157]); A_arbace_go_check_code_expr__init_A_const_103 = A_arbace_go_check_code_expr__init_A_const_pool.A[158]; A_arbace_go_check_code_expr__init_A_const_104 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[159]); A_arbace_go_check_code_expr__init_A_const_105 = A_arbace_go_check_code_expr__init_A_const_pool.A[160] }

func A_arbace_go_check_code_expr__init_A_clinit_p8() { A_arbace_go_check_code_expr__init_A_const_106 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[161]); A_arbace_go_check_code_expr__init_A_const_107 = A_arbace_go_check_code_expr__init_A_const_pool.A[162]; A_arbace_go_check_code_expr__init_A_const_108 = A_arbace_go_check_code_expr__init_A_const_pool.A[163]; A_arbace_go_check_code_expr__init_A_const_109 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[164]); A_arbace_go_check_code_expr__init_A_const_110 = A_arbace_go_check_code_expr__init_A_const_pool.A[165]; A_arbace_go_check_code_expr__init_A_const_111 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[166]); A_arbace_go_check_code_expr__init_A_const_112 = A_arbace_go_check_code_expr__init_A_const_pool.A[167]; A_arbace_go_check_code_expr__init_A_const_113 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[168]); A_arbace_go_check_code_expr__init_A_const_114 = A_arbace_go_check_code_expr__init_A_const_pool.A[169]; A_arbace_go_check_code_expr__init_A_const_115 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[170]); A_arbace_go_check_code_expr__init_A_const_116 = A_arbace_go_check_code_expr__init_A_const_pool.A[171]; A_arbace_go_check_code_expr__init_A_const_117 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[172]); A_arbace_go_check_code_expr__init_A_const_118 = A_arbace_go_check_code_expr__init_A_const_pool.A[173]; A_arbace_go_check_code_expr__init_A_const_119 = A_arbace_go_check_code_expr__init_A_const_pool.A[174] }

func A_arbace_go_check_code_expr__init_A_clinit_p9() { A_arbace_go_check_code_expr__init_A_const_120 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[175]); A_arbace_go_check_code_expr__init_A_const_121 = A_arbace_go_check_code_expr__init_A_const_pool.A[176]; A_arbace_go_check_code_expr__init_A_const_122 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[177]); A_arbace_go_check_code_expr__init_A_const_123 = A_arbace_go_check_code_expr__init_A_const_pool.A[178]; A_arbace_go_check_code_expr__init_A_const_124 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[179]); A_arbace_go_check_code_expr__init_A_const_125 = A_arbace_go_check_code_expr__init_A_const_pool.A[180]; A_arbace_go_check_code_expr__init_A_const_126 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[181]); A_arbace_go_check_code_expr__init_A_const_127 = A_arbace_go_check_code_expr__init_A_const_pool.A[182]; A_arbace_go_check_code_expr__init_A_const_128 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[183]); A_arbace_go_check_code_expr__init_A_const_129 = A_arbace_go_check_code_expr__init_A_const_pool.A[184]; A_arbace_go_check_code_expr__init_A_const_130 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[185]); A_arbace_go_check_code_expr__init_A_const_131 = A_arbace_go_check_code_expr__init_A_const_pool.A[186]; A_arbace_go_check_code_expr__init_A_const_132 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[187]) }

func A_arbace_go_check_code_expr__init_A_clinit_p10() { A_arbace_go_check_code_expr__init_A_const_133 = A_arbace_go_check_code_expr__init_A_const_pool.A[188]; A_arbace_go_check_code_expr__init_A_const_134 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[189]); A_arbace_go_check_code_expr__init_A_const_135 = A_arbace_go_check_code_expr__init_A_const_pool.A[190]; A_arbace_go_check_code_expr__init_A_const_136 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[191]); A_arbace_go_check_code_expr__init_A_const_137 = A_arbace_go_check_code_expr__init_A_const_pool.A[192]; A_arbace_go_check_code_expr__init_A_const_138 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[193]); A_arbace_go_check_code_expr__init_A_const_139 = A_arbace_go_check_code_expr__init_A_const_pool.A[194]; A_arbace_go_check_code_expr__init_A_const_140 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[195]); A_arbace_go_check_code_expr__init_A_const_141 = A_arbace_go_check_code_expr__init_A_const_pool.A[196]; A_arbace_go_check_code_expr__init_A_const_142 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[197]); A_arbace_go_check_code_expr__init_A_const_143 = A_arbace_go_check_code_expr__init_A_const_pool.A[198]; A_arbace_go_check_code_expr__init_A_const_144 = lang.Var_Cast(A_arbace_go_check_code_expr__init_A_const_pool.A[199]); A_arbace_go_check_code_expr__init_A_const_145 = A_arbace_go_check_code_expr__init_A_const_pool.A[200] }

func A_arbace_go_check_code_expr__init_A_New() *A_arbace_go_check_code_expr__init_A { A_arbace_go_check_code_expr__init_A_Init(); t := &A_arbace_go_check_code_expr__init_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_code_expr__init_A) Ctor() {}

func (t *A_arbace_go_check_code_expr__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_code_expr__init_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_code_expr__init_A_class }

func (t *A_arbace_go_check_code_expr__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_code_expr__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_code_expr__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_code_expr__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_code_expr__init_A); return ok }

func A_arbace_go_check_code_expr__init_A_Cast(x any) *A_arbace_go_check_code_expr__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_code_expr__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_code_expr__init_A_class)) }; return v }
