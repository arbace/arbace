//line j2g_strings.ae:1
package aot_arbace_go_check_code_expr

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn20,arbace.go.check.codekn7,privatekn4,linekn6,columnkn4,filekn8,arglistsyn1,ckn3,docyn1,vkn8,declaredyn1,fkn3,tagyn20,java.math.BigDecimalyn3,negyn6,Stringyn2,dpyn2,tykn7,invalidkn7,novaluekn7,builtinkn7,typexprkn8,constantkn8,variablekn8,mapindexkn5,valuekn7,commaokkn3,nilyn1,nyn4,kindyn3,srcyn1,_yn1,ayn1,byn1,xyn1,yyn2,opyn6,targetyn5,finalyn4,codeyn5,modesyn2,cxyn4,hintyn14,allow-comma-okyn2,tpyn1,Tyn1,Vyn2,mmyn5,causeyn7,contextyn5,unaryyn6,x-formyn11,switch-caseyn4,argsyn5,typedyn3,sayv11,arbace.core5,in-nsR0,v20,arbace.go.check.code10,binop-textm38,s2,>>s2,>>s2,!=s2,!=s1,*s1,*s1,%s1,%s2,<=s2,<=s6,bit-ors1,|s1,/s1,/s1,-s1,-s7,bit-xors1,^s7,bit-ands1,&s11,bit-and-nots2,&^s2,ors2,||s2,>=s2,>=s3,ands2,&&s1,<s1,<s2,<<s2,<<s2,==s2,==s1,+s1,+s1,>s1,>m8,R1,TR2,i5,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code10,rune-quotem12,R1,TR5,L1,V1,R6,R7,s117,strconv.QuoteRune's text of rune c (a char), the spelling of a rune literal whose own the\n  forms do not keep (GR7c).R2,i10,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code7,lit-strm10,R1,TR5,L1,V1,R8,R2,i24,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code9,expr-str*m8,R9,TR2,i33,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code8,expr-strm10,R5,L1,V1,R10,R7,s123,Go's text of an expression form (abridged where long); a form's :go/parens (raw forms, mode\n  :full's parentheses) written.R2,i35,R3,i1,R4,s28,arbace/go/check/code_expr.aem10,R1,TR5,L1,V1,R10,R2,i44,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code13,exact-decimalm12,R1,TR5,L1,MV1,R8,m2,R11,R12,R7,s89,A float value (an integer, a ratio, a [:bf M E]) as a BigDecimal: exact, or to 40 digits.R2,i113,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code8,g-formatm12,R1,TR5,L1,V3,R13,Myn2,dsm2,R11,R14,R15,R7,s271,Go's %g of a non-zero decimal d rounded to its digits ds (a string of significant digits,\n  trailing zeros dropped) with decimal exponent dp (d = 0.ds × 10^dp): %e when the exponent is\n  below -4 or at least 6 (strconv's rule for %g, shortest or of precision 6), else %f.R2,i126,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code9,digits-ofm12,R1,TR5,L1,V1,Myn1,dm2,R11,R12,R7,s90,The significant digits and decimal exponent of a non-zero BigDecimal's magnitude: [ds dp].R2,i142,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code9,float-strm10,R5,L1,V1,R8,R7,s178,go/constant's String of a float value v: %.6g of the nearest float64 (%g when that hides a\n  fraction), or beyond float64's range a mantissa of six digits and a decimal exponent.R2,i149,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code7,val-strm10,R5,L1,V2,R8,R16,R7,s57,go/constant's String of a value at type t (for messages).R2,i190,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code10,mode-namesm20,R17,s15,invalid operandR18,s8,no valueR19,s8,built-inR20,s4,typeR21,s8,constantR22,s8,variableR23,s20,map index expressionR24,s5,valueR25,s20,comma, ok expressionR26,s3,nilm6,R2,i203,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code14,composite-kindm10,R1,TR5,L1,V1,R16,R2,i208,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code11,operand-strm10,R5,L1,V1,R27,R7,s34,go/types' operandString of a node.R2,i215,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code12,type-summarym10,R5,L1,V1,R16,R7,s116,types2's typesSummary of one argument's type: untyped numbers are \"number\", other untyped\n  kinds without \"untyped\".R2,i244,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code7,invalidm8,R5,L1,V1,R10,R2,i255,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code8,invalid?m8,R5,L1,V1,R27,R2,i256,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code10,const-nodem8,R5,L1,V3,R10,R16,R8,R2,i258,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code6,int-ofm12,R1,TR5,L1,V2,R8,R16,R7,s87,The integer value of a numeric constant value of type ty, or nil (go/constant's ToInt).R2,i262,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code8,float-ofm10,R1,TR5,L1,V2,R8,R16,R2,i272,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code10,complex-ofm10,R1,TR5,L1,V2,R8,R16,R2,i279,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code13,int-range-ok?m10,R1,TR5,L1,V2,R8,R28,R2,i285,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code14,representationm10,R5,L1,V3,R8,R29,R28,R7,s108,go/types' representation: [value nil] of constant value v (of type src) at basic type\n  kind, or [nil code].R2,i300,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code4,cmulm10,R1,TR5,L1,V2,V3,R30,R31,R32,V3,R30,R33,R34,R2,i336,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code4,cquom10,R1,TR5,L1,V2,V3,R30,R31,R32,V3,R30,R33,R34,R2,i337,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code12,const-binarym10,R5,L1,V4,R35,R33,R34,R16,R7,s72,x op y of constant values of type ty (one type: both converted already).R2,i342,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code13,const-comparem10,R5,L1,V4,R35,R33,R34,R16,R7,s37,x op y of constant values of type ty.R2,i368,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code8,val-signm10,R1,TR5,L1,V2,R8,R16,R2,i383,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code14,comparison-opsS6,s2,!=s2,<=s2,>=s1,<s2,==s1,>m6,R2,i393,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code9,shift-opsS2,s2,>>s2,<<m6,R2,i394,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code8,max-typem12,R1,TR5,L1,V2,R33,R34,R7,s55,go/types' maxType of two untyped numeric kinds, or nil.R2,i396,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code13,implicit-typem10,R5,L1,V2,R27,R36,R7,s116,go/types' implicitTypeAndValue: [type value nil] or [nil nil code] for untyped node n in a\n  context of type target.R2,i404,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code12,update-type*m8,R9,TR2,i443,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code11,update-typem10,R5,L1,V3,R27,R16,R37,R7,s276,Node n (untyped) with its type updated to ty, and its untyped operands with it (go/types'\n  updateExprType); constants checked representable at a final type. The resolve mode answers a\n  shift's final type (go/types records it then, whatever the expression around it becomes).R2,i445,R3,i1,R4,s28,arbace/go/check/code_expr.aem10,R1,TR5,L1,V3,R27,R16,R37,R2,i457,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code19,invalid-conversion!m8,R5,L1,V3,R38,R27,R36,R2,i487,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code15,convert-untypedm10,R5,L1,V2,R27,R36,R7,s82,go/types' convertUntyped: n converted to target's type when untyped, else invalid.R2,i498,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code13,default-finalm10,R5,L1,V1,R27,R7,s74,n with the default type of its untyped type, final (a value materialized).R2,i515,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code12,single-valuem10,R5,L1,V1,R27,R7,s47,An error for a tuple in a single-value context.R2,i524,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code7,excludem10,R5,L1,V2,R27,R39,R7,s57,n, or invalid with an error when its mode is among modes.R2,i533,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code13,expr-internalm8,R9,TR2,i544,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code4,exprm10,R5,L2,V2,R40,R10,V3,R40,R10,R41,R7,s44,A single-valued expression (go/types' expr).R2,i546,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code12,expr-or-typem10,R5,L1,V2,R40,R10,R7,s47,An expression or a type (go/types' exprOrType).R2,i555,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code10,multi-exprm10,R5,L1,V3,R40,R10,R42,R7,s121,The values of an expression: [nodes comma-ok?] (a call's results; a comma-ok expression\n  gives two values when allowed).R2,i563,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code10,const-exprm10,R5,L1,V2,R40,R10,R7,s43,A constant expression (array lengths, ...).R2,i579,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code11,implements?m8,R9,TR2,i586,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code12,tparam-termsm12,R1,TR5,L1,V1,R43,R7,s76,The specific types of type parameter tp's type set, or nil when it has none.R2,i588,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code11,assignable?m10,R5,L1,V2,R27,R44,R7,s60,go/types' assignableTo: [ok code cause] of node n to type T.R2,i593,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code13,missing-causem10,R5,L1,V3,R45,R44,R46,R7,s76,The text of a missing-method cause (go/types' missingMethodCause, abridged).R2,i629,R3,i1,R4,s28,arbace/go/check/code_expr.aem8,R5,L1,V2,R45,R44,R2,i647,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code10,wrap-ifacem10,R5,L1,V2,R27,R44,R7,s170,n converted implicitly to interface type T when its type is not an interface (§3.7): a type\n  parameter's value is converted (its instances' types may not be interfaces).R2,i649,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code11,assignment*m8,R9,TR2,i658,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code16,assign-cause-strm10,R5,L1,V3,R27,R44,R47,R7,s90,The cause of assignable?'s failure, as go/types' assignableTo words it (\": cause\"), or \"\".R2,i660,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code10,assignmentm10,R5,L1,V4,R40,R27,R44,R48,R7,s153,go/types' assignment: n assigned to a variable of type T (nil: the blank identifier) in\n  context (a string for messages); the converted node or invalid.R2,i671,R3,i1,R4,s28,arbace/go/check/code_expr.aem10,R1,TR5,L1,V4,R40,R27,R44,R48,R2,i687,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code15,bytes-or-runes?m8,R5,L1,V1,R16,R2,i729,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code12,convertible?m10,R5,L1,V3,R40,R27,R44,R7,s115,go/types' convertibleTo of node n to type T (non-constant rules; a type parameter's: each\n  of its specific types).R2,i734,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code10,conversionm10,R5,L1,V4,R40,R10,R27,R44,R7,s101,T(x): node n converted to type T (go/types' conversion; its errors at x, as go/types reports\n  them).R2,i765,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code11,op-allowed?m12,R1,TR5,L1,V3,R35,R16,R49,R7,s67,Whether operator op is defined on type ty (go/types' opPredicates).R2,i823,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code5,op-gom42,s2,>>s2,>>s2,!=s2,!=s1,*s1,*s1,%s1,%s2,<=s2,<=s6,bit-ors1,|s3,nots1,!s1,/s1,/s1,-s1,-s7,bit-xors1,^s7,bit-ands1,&s11,bit-and-nots2,&^s2,ors2,||s7,bit-nots1,^s2,>=s2,>=s3,ands2,&&s1,<s1,<s2,<<s2,<<s2,==s2,==s1,+s1,+s1,>s1,>m8,R1,TR2,i839,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code8,overflowm10,R5,L1,V2,R27,R35,R7,s106,go/types' overflow: a constant result checked (typed: representable; untyped integers at\n  most 512 bits).R2,i844,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code5,unarym10,R5,L1,V4,R40,R10,R35,R50,R7,s58,A unary operator op (- + bit-not not) on the operand form.R2,i868,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code12,may-convert?m10,R1,TR5,L1,V2,R33,R34,R2,i896,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code11,match-typesm10,R5,L1,V2,R33,R34,R7,s82,go/types' matchTypes: [x y] with untyped operands converted to each other's types.R2,i909,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code10,comparisonm10,R5,L1,V6,R40,R10,R35,R33,R34,R51,R7,s86,x op y, a comparison (expr.go comparison); switch-case: a switch case against its tag.R2,i920,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code17,finish-comparisonm8,R5,L1,V4,R10,R35,R33,R34,R2,i959,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code5,shiftm10,R5,L1,V5,R40,R10,R35,R33,R34,R7,s31,x << y, x >> y (expr.go shift).R2,i967,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code12,binary-nodesm10,R5,L1,V5,R40,R10,R35,R33,R34,R7,s44,x op y of checked operands (expr.go binary).R2,i1024,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code6,binarym10,R5,L1,V4,R40,R10,R35,R52,R7,s58,An operator form (op a b c ...): n-ary chains folded left.R2,i1062,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code9,val-floatm12,R1,TR5,L1,V2,R8,R53,R7,s139,The exact value a float part of :val denotes: typed floats' doubles are their binary\n  values, untyped ones' their shortest decimal text's.R2,i1077,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code10,val-equal?m10,R5,L1,V2,R54,R27,R7,s69,Whether a :val form denotes the value of constant node n at its type.R2,i1089,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code9,val-constm10,R5,L1,V2,R54,R16,R7,s173,The constant a :val form denotes at type ty (a digest's constant, which has no init: §6.5,\n  trusted), or nil when ty is nil and the form says no untyped kind: [type value].R2,i1114,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code12,val-form-strm10,R5,L1,V2,R8,R16,R7,s58,A constant value as the checker computes it, for messages.R2,i1140,R3,i1,R4,s28,arbace/go/check/code_expr.ae")

var Lit_1 *jrt.String = jrt.Intern("arbace.go.check.code$rune_quote")

var Lit_2 *jrt.String = jrt.Intern("arbace.go.check.code$lit_str")

var Lit_3 *jrt.String = jrt.Intern("arbace.go.check.code$expr_str")

var Lit_4 *jrt.String = jrt.Intern("arbace.go.check.code$expr_str_STAR_")

var Lit_5 *jrt.String = jrt.Intern("arbace.go.check.code$exact_decimal")

var Lit_6 *jrt.String = jrt.Intern("arbace.go.check.code$g_format")

var Lit_7 *jrt.String = jrt.Intern("arbace.go.check.code$digits_of")

var Lit_8 *jrt.String = jrt.Intern("arbace.go.check.code$float_str")

var Lit_9 *jrt.String = jrt.Intern("arbace.go.check.code$val_str")

var Lit_10 *jrt.String = jrt.Intern("arbace.go.check.code$composite_kind")

var Lit_11 *jrt.String = jrt.Intern("arbace.go.check.code$operand_str")

var Lit_12 *jrt.String = jrt.Intern("arbace.go.check.code$type_summary")

var Lit_13 *jrt.String = jrt.Intern("arbace.go.check.code$invalid")

var Lit_14 *jrt.String = jrt.Intern("arbace.go.check.code$invalid_QMARK_")

var Lit_15 *jrt.String = jrt.Intern("arbace.go.check.code$const_node")

var Lit_16 *jrt.String = jrt.Intern("arbace.go.check.code$int_of")

var Lit_17 *jrt.String = jrt.Intern("arbace.go.check.code$float_of")

var Lit_18 *jrt.String = jrt.Intern("arbace.go.check.code$complex_of")

var Lit_19 *jrt.String = jrt.Intern("arbace.go.check.code$int_range_ok_QMARK_")

var Lit_20 *jrt.String = jrt.Intern("arbace.go.check.code$representation")

var Lit_21 *jrt.String = jrt.Intern("arbace.go.check.code$cmul")

var Lit_22 *jrt.String = jrt.Intern("arbace.go.check.code$cquo")

var Lit_23 *jrt.String = jrt.Intern("arbace.go.check.code$const_binary")

var Lit_24 *jrt.String = jrt.Intern("arbace.go.check.code$const_compare")

var Lit_25 *jrt.String = jrt.Intern("arbace.go.check.code$val_sign")

var Lit_26 *jrt.String = jrt.Intern("arbace.go.check.code$max_type")

var Lit_27 *jrt.String = jrt.Intern("arbace.go.check.code$implicit_type")

var Lit_28 *jrt.String = jrt.Intern("arbace.go.check.code$update_type")

var Lit_29 *jrt.String = jrt.Intern("arbace.go.check.code$update_type_STAR_")

var Lit_30 *jrt.String = jrt.Intern("arbace.go.check.code$invalid_conversion_BANG_")

var Lit_31 *jrt.String = jrt.Intern("arbace.go.check.code$convert_untyped")

var Lit_32 *jrt.String = jrt.Intern("arbace.go.check.code$default_final")

var Lit_33 *jrt.String = jrt.Intern("arbace.go.check.code$single_value")

var Lit_34 *jrt.String = jrt.Intern("arbace.go.check.code$exclude")

var Lit_35 *jrt.String = jrt.Intern("arbace.go.check.code$expr")

var Lit_36 *jrt.String = jrt.Intern("arbace.go.check.code$expr_or_type")

var Lit_37 *jrt.String = jrt.Intern("arbace.go.check.code$multi_expr")

var Lit_38 *jrt.String = jrt.Intern("arbace.go.check.code$const_expr")

var Lit_39 *jrt.String = jrt.Intern("arbace.go.check.code$tparam_terms")

var Lit_40 *jrt.String = jrt.Intern("arbace.go.check.code$assignable_QMARK_")

var Lit_41 *jrt.String = jrt.Intern("arbace.go.check.code$missing_cause")

var Lit_42 *jrt.String = jrt.Intern("arbace.go.check.code$implements_QMARK_")

var Lit_43 *jrt.String = jrt.Intern("arbace.go.check.code$wrap_iface")

var Lit_44 *jrt.String = jrt.Intern("arbace.go.check.code$assign_cause_str")

var Lit_45 *jrt.String = jrt.Intern("arbace.go.check.code$assignment")

var Lit_46 *jrt.String = jrt.Intern("arbace.go.check.code$assignment_STAR_")

var Lit_47 *jrt.String = jrt.Intern("arbace.go.check.code$bytes_or_runes_QMARK_")

var Lit_48 *jrt.String = jrt.Intern("arbace.go.check.code$convertible_QMARK_")

var Lit_49 *jrt.String = jrt.Intern("arbace.go.check.code$conversion")

var Lit_50 *jrt.String = jrt.Intern("arbace.go.check.code$op_allowed_QMARK_")

var Lit_51 *jrt.String = jrt.Intern("arbace.go.check.code$overflow")

var Lit_52 *jrt.String = jrt.Intern("arbace.go.check.code$unary")

var Lit_53 *jrt.String = jrt.Intern("arbace.go.check.code$may_convert_QMARK_")

var Lit_54 *jrt.String = jrt.Intern("arbace.go.check.code$match_types")

var Lit_55 *jrt.String = jrt.Intern("arbace.go.check.code$comparison")

var Lit_56 *jrt.String = jrt.Intern("arbace.go.check.code$finish_comparison")

var Lit_57 *jrt.String = jrt.Intern("arbace.go.check.code$shift")

var Lit_58 *jrt.String = jrt.Intern("arbace.go.check.code$binary_nodes")

var Lit_59 *jrt.String = jrt.Intern("arbace.go.check.code$binary")

var Lit_60 *jrt.String = jrt.Intern("arbace.go.check.code$val_float")

var Lit_61 *jrt.String = jrt.Intern("arbace.go.check.code$val_equal_QMARK_")

var Lit_62 *jrt.String = jrt.Intern("arbace.go.check.code$val_const")

var Lit_63 *jrt.String = jrt.Intern("arbace.go.check.code$val_form_str")
