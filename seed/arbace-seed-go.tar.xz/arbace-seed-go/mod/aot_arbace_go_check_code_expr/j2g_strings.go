//line j2g_strings.ae:1
package aot_arbace_go_check_code_expr

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn20,arbace.go.check.codekn7,privatekn4,linekn6,columnkn4,filekn8,arglistsyn1,vyn1,fkn3,dockn3,tagyn20,java.math.BigDecimalyn3,negyn6,Stringyn2,dpyn2,tykn7,invalidkn7,novaluekn7,builtinkn7,typexprkn8,constantkn8,variablekn8,mapindexkn5,valuekn7,commaokkn3,nilyn1,nyn4,kindyn3,srcyn1,_yn1,ayn1,byn1,xyn1,yyn2,opyn6,targetyn5,finalyn4,codeyn5,modeskn8,declaredyn2,cxyn4,hintyn14,allow-comma-okyn2,tpyn1,Tyn1,Vyn2,mmyn7,contextyn5,unaryyn6,x-formyn11,switch-caseyn4,argsyn5,typedyn3,sayv11,arbace.core5,in-nsR0,v20,arbace.go.check.code10,binop-textm38,s2,>>s2,>>s2,!=s2,!=s1,*s1,*s1,%s1,%s2,<=s2,<=s6,bit-ors1,|s1,/s1,/s1,-s1,-s7,bit-xors1,^s7,bit-ands1,&s11,bit-and-nots2,&^s2,ors2,||s2,>=s2,>=s3,ands2,&&s1,<s1,<s2,<<s2,<<s2,==s2,==s1,+s1,+s1,>s1,>m8,R1,TR2,i5,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code7,lit-strm10,R1,TR5,L1,V1,R6,R2,i10,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code8,expr-strm10,R5,L1,V1,R7,R8,s54,Go's text of an expression form (abridged where long).R2,i19,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code13,exact-decimalm12,R1,TR5,L1,MV1,R6,m2,R9,R10,R8,s89,A float value (an integer, a ratio, a [:bf M E]) as a BigDecimal: exact, or to 40 digits.R2,i76,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code8,g-formatm12,R1,TR5,L1,V3,R11,Myn2,dsm2,R9,R12,R13,R8,s271,Go's %g of a non-zero decimal d rounded to its digits ds (a string of significant digits,\n  trailing zeros dropped) with decimal exponent dp (d = 0.ds × 10^dp): %e when the exponent is\n  below -4 or at least 6 (strconv's rule for %g, shortest or of precision 6), else %f.R2,i89,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code9,digits-ofm12,R1,TR5,L1,V1,Myn1,dm2,R9,R10,R8,s90,The significant digits and decimal exponent of a non-zero BigDecimal's magnitude: [ds dp].R2,i105,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code9,float-strm10,R5,L1,V1,R6,R8,s178,go/constant's String of a float value v: %.6g of the nearest float64 (%g when that hides a\n  fraction), or beyond float64's range a mantissa of six digits and a decimal exponent.R2,i112,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code7,val-strm10,R5,L1,V2,R6,R14,R8,s57,go/constant's String of a value at type t (for messages).R2,i153,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code10,mode-namesm20,R15,s15,invalid operandR16,s8,no valueR17,s8,built-inR18,s4,typeR19,s8,constantR20,s8,variableR21,s20,map index expressionR22,s5,valueR23,s20,comma, ok expressionR24,s3,nilm6,R2,i166,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code14,composite-kindm10,R1,TR5,L1,V1,R14,R2,i171,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code11,operand-strm10,R5,L1,V1,R25,R8,s34,go/types' operandString of a node.R2,i178,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code12,type-summarym10,R5,L1,V1,R14,R8,s116,types2's typesSummary of one argument's type: untyped numbers are \"number\", other untyped\n  kinds without \"untyped\".R2,i207,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code7,invalidm8,R5,L1,V1,R7,R2,i218,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code8,invalid?m8,R5,L1,V1,R25,R2,i219,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code10,const-nodem8,R5,L1,V3,R7,R14,R6,R2,i221,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code6,int-ofm12,R1,TR5,L1,V2,R6,R14,R8,s87,The integer value of a numeric constant value of type ty, or nil (go/constant's ToInt).R2,i225,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code8,float-ofm10,R1,TR5,L1,V2,R6,R14,R2,i235,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code10,complex-ofm10,R1,TR5,L1,V2,R6,R14,R2,i242,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code13,int-range-ok?m10,R1,TR5,L1,V2,R6,R26,R2,i248,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code14,representationm10,R5,L1,V3,R6,R27,R26,R8,s108,go/types' representation: [value nil] of constant value v (of type src) at basic type\n  kind, or [nil code].R2,i263,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code4,cmulm10,R1,TR5,L1,V2,V3,R28,R29,R30,V3,R28,R31,R32,R2,i299,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code4,cquom10,R1,TR5,L1,V2,V3,R28,R29,R30,V3,R28,R31,R32,R2,i300,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code12,const-binarym10,R5,L1,V4,R33,R31,R32,R14,R8,s72,x op y of constant values of type ty (one type: both converted already).R2,i305,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code13,const-comparem10,R5,L1,V4,R33,R31,R32,R14,R8,s37,x op y of constant values of type ty.R2,i331,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code8,val-signm10,R1,TR5,L1,V2,R6,R14,R2,i346,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code14,comparison-opsS6,s2,!=s2,<=s2,>=s1,<s2,==s1,>m6,R2,i356,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code9,shift-opsS2,s2,>>s2,<<m6,R2,i357,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code8,max-typem12,R1,TR5,L1,V2,R31,R32,R8,s55,go/types' maxType of two untyped numeric kinds, or nil.R2,i359,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code13,implicit-typem10,R5,L1,V2,R25,R34,R8,s116,go/types' implicitTypeAndValue: [type value nil] or [nil nil code] for untyped node n in a\n  context of type target.R2,i367,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code11,update-typem10,R5,L1,V3,R25,R14,R35,R8,s157,Node n (untyped) with its type updated to ty, and its untyped operands with it (go/types'\n  updateExprType); constants checked representable at a final type.R2,i406,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code19,invalid-conversion!m8,R5,L1,V3,R36,R25,R34,R2,i437,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code15,convert-untypedm10,R5,L1,V2,R25,R34,R8,s82,go/types' convertUntyped: n converted to target's type when untyped, else invalid.R2,i448,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code13,default-finalm10,R5,L1,V1,R25,R8,s74,n with the default type of its untyped type, final (a value materialized).R2,i465,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code12,single-valuem10,R5,L1,V1,R25,R8,s47,An error for a tuple in a single-value context.R2,i474,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code7,excludem10,R5,L1,V2,R25,R37,R8,s57,n, or invalid with an error when its mode is among modes.R2,i483,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code13,expr-internalm8,R38,TR2,i494,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code4,exprm10,R5,L2,V2,R39,R7,V3,R39,R7,R40,R8,s44,A single-valued expression (go/types' expr).R2,i496,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code12,expr-or-typem10,R5,L1,V2,R39,R7,R8,s47,An expression or a type (go/types' exprOrType).R2,i505,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code10,multi-exprm10,R5,L1,V3,R39,R7,R41,R8,s121,The values of an expression: [nodes comma-ok?] (a call's results; a comma-ok expression\n  gives two values when allowed).R2,i513,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code10,const-exprm10,R5,L1,V2,R39,R7,R8,s43,A constant expression (array lengths, ...).R2,i529,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code11,implements?m8,R38,TR2,i536,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code12,tparam-termsm12,R1,TR5,L1,V1,R42,R8,s76,The specific types of type parameter tp's type set, or nil when it has none.R2,i538,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code11,assignable?m10,R5,L1,V2,R25,R43,R8,s60,go/types' assignableTo: [ok code cause] of node n to type T.R2,i543,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code13,missing-causem10,R5,L1,V3,R44,R43,R45,R8,s76,The text of a missing-method cause (go/types' missingMethodCause, abridged).R2,i578,R3,i1,R4,s28,arbace/go/check/code_expr.aem8,R5,L1,V2,R44,R43,R2,i593,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code10,wrap-ifacem10,R5,L1,V2,R25,R43,R8,s170,n converted implicitly to interface type T when its type is not an interface (§3.7): a type\n  parameter's value is converted (its instances' types may not be interfaces).R2,i595,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code11,assignment*m8,R38,TR2,i604,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code10,assignmentm10,R5,L1,V4,R39,R25,R43,R46,R8,s153,go/types' assignment: n assigned to a variable of type T (nil: the blank identifier) in\n  context (a string for messages); the converted node or invalid.R2,i606,R3,i1,R4,s28,arbace/go/check/code_expr.aem10,R1,TR5,L1,V4,R39,R25,R43,R46,R2,i622,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code15,bytes-or-runes?m8,R5,L1,V1,R14,R2,i670,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code12,convertible?m10,R5,L1,V3,R39,R25,R43,R8,s115,go/types' convertibleTo of node n to type T (non-constant rules; a type parameter's: each\n  of its specific types).R2,i675,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code10,conversionm10,R5,L1,V4,R39,R7,R25,R43,R8,s101,T(x): node n converted to type T (go/types' conversion; its errors at x, as go/types reports\n  them).R2,i706,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code11,op-allowed?m12,R1,TR5,L1,V3,R33,R14,R47,R8,s67,Whether operator op is defined on type ty (go/types' opPredicates).R2,i766,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code5,op-gom42,s2,>>s2,>>s2,!=s2,!=s1,*s1,*s1,%s1,%s2,<=s2,<=s6,bit-ors1,|s3,nots1,!s1,/s1,/s1,-s1,-s7,bit-xors1,^s7,bit-ands1,&s11,bit-and-nots2,&^s2,ors2,||s7,bit-nots1,^s2,>=s2,>=s3,ands2,&&s1,<s1,<s2,<<s2,<<s2,==s2,==s1,+s1,+s1,>s1,>m8,R1,TR2,i782,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code8,overflowm10,R5,L1,V2,R25,R33,R8,s106,go/types' overflow: a constant result checked (typed: representable; untyped integers at\n  most 512 bits).R2,i787,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code5,unarym10,R5,L1,V4,R39,R7,R33,R48,R8,s58,A unary operator op (- + bit-not not) on the operand form.R2,i809,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code12,may-convert?m10,R1,TR5,L1,V2,R31,R32,R2,i833,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code11,match-typesm10,R5,L1,V2,R31,R32,R8,s82,go/types' matchTypes: [x y] with untyped operands converted to each other's types.R2,i846,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code10,comparisonm10,R5,L1,V6,R39,R7,R33,R31,R32,R49,R8,s86,x op y, a comparison (expr.go comparison); switch-case: a switch case against its tag.R2,i857,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code17,finish-comparisonm8,R5,L1,V4,R7,R33,R31,R32,R2,i896,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code5,shiftm10,R5,L1,V5,R39,R7,R33,R31,R32,R8,s31,x << y, x >> y (expr.go shift).R2,i904,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code12,binary-nodesm10,R5,L1,V5,R39,R7,R33,R31,R32,R8,s44,x op y of checked operands (expr.go binary).R2,i961,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code6,binarym10,R5,L1,V4,R39,R7,R33,R50,R8,s58,An operator form (op a b c ...): n-ary chains folded left.R2,i989,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code9,val-floatm12,R1,TR5,L1,V2,R6,R51,R8,s139,The exact value a float part of :val denotes: typed floats' doubles are their binary\n  values, untyped ones' their shortest decimal text's.R2,i1004,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code10,val-equal?m10,R5,L1,V2,R52,R25,R8,s69,Whether a :val form denotes the value of constant node n at its type.R2,i1016,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code9,val-constm10,R5,L1,V2,R52,R14,R8,s173,The constant a :val form denotes at type ty (a digest's constant, which has no init: §6.5,\n  trusted), or nil when ty is nil and the form says no untyped kind: [type value].R2,i1041,R3,i1,R4,s28,arbace/go/check/code_expr.aev20,arbace.go.check.code12,val-form-strm10,R5,L1,V2,R6,R14,R8,s58,A constant value as the checker computes it, for messages.R2,i1067,R3,i1,R4,s28,arbace/go/check/code_expr.ae")

var Lit_1 *jrt.String = jrt.Intern("arbace.go.check.code$lit_str")

var Lit_2 *jrt.String = jrt.Intern("arbace.go.check.code$expr_str")

var Lit_3 *jrt.String = jrt.Intern("arbace.go.check.code$exact_decimal")

var Lit_4 *jrt.String = jrt.Intern("arbace.go.check.code$g_format")

var Lit_5 *jrt.String = jrt.Intern("arbace.go.check.code$digits_of")

var Lit_6 *jrt.String = jrt.Intern("arbace.go.check.code$float_str")

var Lit_7 *jrt.String = jrt.Intern("arbace.go.check.code$val_str")

var Lit_8 *jrt.String = jrt.Intern("arbace.go.check.code$composite_kind")

var Lit_9 *jrt.String = jrt.Intern("arbace.go.check.code$operand_str")

var Lit_10 *jrt.String = jrt.Intern("arbace.go.check.code$type_summary")

var Lit_11 *jrt.String = jrt.Intern("arbace.go.check.code$invalid")

var Lit_12 *jrt.String = jrt.Intern("arbace.go.check.code$invalid_QMARK_")

var Lit_13 *jrt.String = jrt.Intern("arbace.go.check.code$const_node")

var Lit_14 *jrt.String = jrt.Intern("arbace.go.check.code$int_of")

var Lit_15 *jrt.String = jrt.Intern("arbace.go.check.code$float_of")

var Lit_16 *jrt.String = jrt.Intern("arbace.go.check.code$complex_of")

var Lit_17 *jrt.String = jrt.Intern("arbace.go.check.code$int_range_ok_QMARK_")

var Lit_18 *jrt.String = jrt.Intern("arbace.go.check.code$representation")

var Lit_19 *jrt.String = jrt.Intern("arbace.go.check.code$cmul")

var Lit_20 *jrt.String = jrt.Intern("arbace.go.check.code$cquo")

var Lit_21 *jrt.String = jrt.Intern("arbace.go.check.code$const_binary")

var Lit_22 *jrt.String = jrt.Intern("arbace.go.check.code$const_compare")

var Lit_23 *jrt.String = jrt.Intern("arbace.go.check.code$val_sign")

var Lit_24 *jrt.String = jrt.Intern("arbace.go.check.code$max_type")

var Lit_25 *jrt.String = jrt.Intern("arbace.go.check.code$implicit_type")

var Lit_26 *jrt.String = jrt.Intern("arbace.go.check.code$update_type")

var Lit_27 *jrt.String = jrt.Intern("arbace.go.check.code$invalid_conversion_BANG_")

var Lit_28 *jrt.String = jrt.Intern("arbace.go.check.code$convert_untyped")

var Lit_29 *jrt.String = jrt.Intern("arbace.go.check.code$default_final")

var Lit_30 *jrt.String = jrt.Intern("arbace.go.check.code$single_value")

var Lit_31 *jrt.String = jrt.Intern("arbace.go.check.code$exclude")

var Lit_32 *jrt.String = jrt.Intern("arbace.go.check.code$expr")

var Lit_33 *jrt.String = jrt.Intern("arbace.go.check.code$expr_or_type")

var Lit_34 *jrt.String = jrt.Intern("arbace.go.check.code$multi_expr")

var Lit_35 *jrt.String = jrt.Intern("arbace.go.check.code$const_expr")

var Lit_36 *jrt.String = jrt.Intern("arbace.go.check.code$tparam_terms")

var Lit_37 *jrt.String = jrt.Intern("arbace.go.check.code$assignable_QMARK_")

var Lit_38 *jrt.String = jrt.Intern("arbace.go.check.code$missing_cause")

var Lit_39 *jrt.String = jrt.Intern("arbace.go.check.code$implements_QMARK_")

var Lit_40 *jrt.String = jrt.Intern("arbace.go.check.code$wrap_iface")

var Lit_41 *jrt.String = jrt.Intern("arbace.go.check.code$assignment")

var Lit_42 *jrt.String = jrt.Intern("arbace.go.check.code$assignment_STAR_")

var Lit_43 *jrt.String = jrt.Intern("arbace.go.check.code$bytes_or_runes_QMARK_")

var Lit_44 *jrt.String = jrt.Intern("arbace.go.check.code$convertible_QMARK_")

var Lit_45 *jrt.String = jrt.Intern("arbace.go.check.code$conversion")

var Lit_46 *jrt.String = jrt.Intern("arbace.go.check.code$op_allowed_QMARK_")

var Lit_47 *jrt.String = jrt.Intern("arbace.go.check.code$overflow")

var Lit_48 *jrt.String = jrt.Intern("arbace.go.check.code$unary")

var Lit_49 *jrt.String = jrt.Intern("arbace.go.check.code$may_convert_QMARK_")

var Lit_50 *jrt.String = jrt.Intern("arbace.go.check.code$match_types")

var Lit_51 *jrt.String = jrt.Intern("arbace.go.check.code$comparison")

var Lit_52 *jrt.String = jrt.Intern("arbace.go.check.code$finish_comparison")

var Lit_53 *jrt.String = jrt.Intern("arbace.go.check.code$shift")

var Lit_54 *jrt.String = jrt.Intern("arbace.go.check.code$binary_nodes")

var Lit_55 *jrt.String = jrt.Intern("arbace.go.check.code$binary")

var Lit_56 *jrt.String = jrt.Intern("arbace.go.check.code$val_float")

var Lit_57 *jrt.String = jrt.Intern("arbace.go.check.code$val_equal_QMARK_")

var Lit_58 *jrt.String = jrt.Intern("arbace.go.check.code$val_const")

var Lit_59 *jrt.String = jrt.Intern("arbace.go.check.code$val_form_str")
