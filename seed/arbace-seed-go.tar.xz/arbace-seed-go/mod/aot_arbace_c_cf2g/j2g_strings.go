//line j2g_strings.ae:1
package aot_arbace_c_cf2g

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn11,arbace.walkyn4,walkyn20,arbace.repr.go.printyn2,gpyn11,arbace.corekn3,docks4,cf2g7,refusedkn4,elseyn2,>>yn2,<<yn4,convyn5,int64yn6,uint64ys2,ci4,Boolyn5,uint8yn6,uint32yn5,int32yn6,uint16yn5,int16yn4,int8yn6,.Load8yn1,Myn7,.Load64yn7,.Load32yn7,.Load16ys2,ci4,Loadyn7,.Store8yn8,.Store32yn8,.Store16yn8,.Store64kn8,aot-nodeyn4,agetyn1,Ryn1,Skn1,nkn4,varskn1,fyn7,float64kn1,ikn1,wys3,crt4,Widekn4,usedyn4,gotokn4,defsyn5,labelkn6,wtypesyn8,.LoadF32yn8,.LoadF64yn9,.LoadWideyn4,set!ys2,ci1,Byn2,!=yn4,whenyn3,notyn2,ifyn2,doys2,ci4,UDivys2,ci4,URemys2,ci4,SDivys2,ci4,SRemyn1,+yn4,uintyn7,bit-andyn1,-yn1,*yn7,bit-xoryn6,bit-oryn2,==yn2,>=yn1,>yn2,<=yn1,<yn7,float32ys4,math15,Float64frombitsyn4,addrys2,ci10,VlaAllocAtyn1,tys2,ci8,BitStoreyn3,.-Ikn3,tlsyn2,frys2,ci7,IStaticyn1,Pyn1,Gyn1,/yn5,.Fillyn3,vaayn4,basekn10,addr-takenyn3,lenyn7,.-VArgskn4,linekn6,columnys2,ci4,Trapyn7,.Uint64yn7,bit-notys2,ci7,BitLoadys2,ci7,F2IConvyn4,.Cmpyn5,.Moveyn7,.IsZeroys2,ci9,VlaMarkAtys2,ci7,VaArgAtyn4,.-SPys2,ci7,AllocaTyn3,andyn2,oryn3,.-Fyn9,.StoreF32yn9,.StoreF64yn8,.Float64kn7,wconstsyn5,.Normyn4,.Shlyn4,.Shryn10,.StoreWideyn4,.Subyn4,.Addyn3,.Oryn4,.Mulys2,ci4,WDivyn4,.Andys2,ci4,WRemyn4,.Xoryn3,.-Wyn5,.Convyn14,.StoreWideBitsys3,crt12,WFromFloat64yn13,.LoadWideBitsys3,crt11,WFromUint64ys3,crt10,WFromInt64yn4,.Negyn4,.Notyn3,lityn1,_kn1,Kkn1,Fkn1,Ikn4,Addrkn4,Sizekn1,Wyn5,sliceys2,ci3,Argkn6,directkn7,pre-fnskn8,compiledys2,ci4,Packyn5,.Callyn1,Fyn9,.CallAddryn2,eiyn4,retdkn3,brkkn4,contyn3,retyn6,switchyn4,casekn5,codesyn14,igoto-dispatchyn6,.SjSetys2,ci3,Ctlkn2,sjyn7,defaultkn8,aot-gotokn4,Sretyn5,enterys2,ci5,SjRunyn2,fnkn3,tagys2,ci1,Kyn4,zeroyn3,letys2,ci5,Paramkn4,Slotkn3,F32kn3,Offkn1,Tkn4,Widekn2,WTyn4,argskn4,Lretyn4,boolyn6,returnys2,ci5,Leaveyn2,spys2,go3,varys2,ci4,Codekn9,FrameSizekn8,Variadickn6,Paramsys2,go4,funcys2,ci6,Threadkn7,resultsyn6,valuesys2,ci5,Enteryn6,.-Baseyn4,.-VAys2,ci5,CNextys2,ci5,Frameyn3,.-Tkn5,itemskn8,pre-initkn4,initkn8,pre-codekn4,codekn4,datayn7,.-Initsyn1,pyn6,appendys2,ci4,Initkn1,Sys2,ci6,GoStmtyn12,.SetCompiledyn1,lyn8,.TopTextys3,crt5,WTypekn1,Nkn6,Signedys2,ci8,MustWideys4,math2,Piys3,crt4,Textys2,ci4,Progys3,crt3,Memys2,ci4,Funcyn2,nskn7,requireyn9,arbace.goyn2,goys2,go7,packagekn4,pathkn5,filesyn5,in-nsyn5,quoteys2,go4,filekn7,importsyn2,osyn4,mathyn2,ciyn3,crtkn5,bindsyn4,mainyn4,Mainyn8,subsliceys2,os4,Argsyn6,stringys2,ci7,AotMainys2,ci6,Loaderyn3,.-Myn7,.-Funcsyn9,.StaticsIkn9,functionskn6,layoutkn5,gofmtkn16,line-directives?kn6,fcandskn4,objskn4,selfkn3,fnskn4,itemkn4,textkn5,aliaskn1,kkn1,oyn4,Bindyn1,ryn1,skn5,initskn7,refusedkn6,statuskn2,okkn5,byteskn5,classkn7,messageys18,arbace.repr.c.host9,load-hostys16,arbace.c.runtime7,libraryys12,arbace.c.run9,read-unitys12,arbace.c.run17,uses-long-double?ys16,arbace.c.runtime11,link-tracedys15,arbace.c.aotlib11,program-preys14,arbace.c.build12,read-programks2,ci7,refusedys14,arbace.c.build12,program-textkn5,formskn2,rdyn12,arbace.c.runyn18,arbace.repr.c.hostyn13,arbace.c.muslyn16,arbace.c.runtimeyn14,arbace.c.buildyn15,arbace.c.aotlibys12,arbace.c.run6,resultys12,arbace.c.run21,subset-record-refusalkn2,idkn5,speedkn5,matchkn4,samekn6,differkn9,no-interpkn4,passkn4,failys12,arbace.c.run14,compare-recordys12,arbace.c.run13,report-recordys12,arbace.c.run16,controls-failingys12,arbace.c.run14,report-failingkn5,errorkn9,aot-errorv11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,V3,R5,R1,R6,v11,arbace.core5,referR7,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn13,arbace.c.cf2gm2,R8,s1271,cf2g, C's AOT (doc/C23-SURVEY.md §7, CS13 (a), CS17 (a); \"As built: C6 (write-ahead)\"): a C program's\n  node program (arbace.c.build's output, the lowered C forms ci's back end runs, CS120) translated into Go\n  forms over go/arbace/ci and go/arbace/crt, printed by repr/go and built by Go's compiler. Each function\n  of the program with code is a Go function of package-level name fID, the Native of its Func (ci.Enter's\n  frame in the C stack, its slots Go locals); its statements and expressions flattened into one block of\n  assignments, conditional gotos and labels, so that C's gotos into blocks, loops and switches (Duff's\n  device) and switch's cases are Go's gotos; expressions in temporaries wherever an operand's evaluation\n  has an effect, in ci's order (the builder's: gcc -O0's); setjmp's function body a closure under\n  ci.SjRun. The program's data (fn, native, static, data, at, alias, fnalias, start) stays node program\n  text, loaded by ci's Loader as on the interpreted path, so both lay out memory alike. A node or a jump\n  the translator cannot express is refused, with its reason (class aot-*).\n\n  translate gives the Go forms of one program's package; -main: `translate NODES OUTDIR [PKG]` and\n  `translate-list LIST THREADS` (bin/ci check --aot's).v11,arbace.core7,ex-infov11,arbace.core5,applyv11,arbace.core3,strR9,v11,arbace.core4,readv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core11,*read-eval*v11,arbace.core7,string?v11,arbace.core4,namev11,arbace.core10,bigintegerR10,v13,arbace.c.cf2g2,nmv11,arbace.core5,firstv11,arbace.core7,symbol?S2,c115,c117,v11,arbace.core3,notS4,s3,u16s3,u32s2,u8s3,u64v11,arbace.core6,every?v11,arbace.core4,subsl1,c115,v13,arbace.c.cf2g9,bit-widthv11,arbace.core9,contains?S6,s3,u16s1,ps3,u32s2,u8s1,bs3,u64l64,l8,l32,l16,v11,arbace.core4,listR11,R12,R13,R14,R11,R12,R13,R15,R16,R13,R14,R13,R17,R13,R14,R13,R18,R13,R14,R13,R19,R13,R14,R13,R20,R13,R14,R13,R21,R13,R14,R13,R22,S7,s3,u16s3,u32s2,u8s1,bs3,i16s2,i8s3,i32R13,R15,R13,R14,R23,R24,v13,arbace.c.cf2g2,uaR13,R14,R25,R24,R13,R14,R13,R19,R26,R24,R13,R14,R13,R21,R27,R24,R13,R14,R13,R22,R23,R24,R13,R14,R26,R24,R13,R14,R27,R24,R28,R24,R29,R24,R13,R17,R30,R24,R13,R18,R31,R24,R13,R20,R32,R24,R13,R15,c63,S2,c102,c115,l2,v13,arbace.c.cf2g11,placeholderv13,arbace.c.cf2g3,lngv13,arbace.c.cf2g7,*reloc*v13,arbace.c.cf2g6,refuseR33,R34,c102,R35,R36,R37,v11,arbace.core5,swap!v13,arbace.c.cf2g4,*fn*v11,arbace.core6,updatev11,arbace.core3,incv11,arbace.core6,symbolR38,R39,v13,arbace.c.cf2g6,fresh!R40,R41,R14,R42,R43,v11,arbace.core7,keywordv13,arbace.c.cf2g7,*scope*R44,R45,R46,R47,v13,arbace.c.cf2g5,*pkg*R48,v11,arbace.core5,assocv11,arbace.core10,re-matchesp10,[if][0-9]+v11,arbace.core7,number?v11,arbace.core5,char?v11,arbace.core8,keyword?v11,arbace.core8,boolean?v13,arbace.c.cf2g5,slot?v11,arbace.core4,seq?v13,arbace.c.cf2g10,pure-headsv13,arbace.c.cf2g7,stable?v11,arbace.core4,restS8,R23,R26,R49,R28,R50,R51,R25,R27,v13,arbace.string12,starts-with?v13,arbace.c.cf2g5,pure?v11,arbace.core3,vecv11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core4,somev11,arbace.core6,subvecv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv11,arbace.core5,rangev13,arbace.c.cf2g4,tmp!v11,arbace.core4,intoR52,R52,R53,v11,arbace.core6,secondR54,l0,R47,v13,arbace.c.cf2g10,has-label?v11,arbace.core6,empty?v13,arbace.c.cf2g6,label!R55,v13,arbace.c.cf2g5,goto!R56,v13,arbace.c.cf2g9,deflabel!R55,R55,R56,R57,R58,R58,v13,arbace.c.cf2g11,needs-norm?v13,arbace.c.cf2g5,widthv13,arbace.c.cf2g9,unsigned?v13,arbace.c.cf2g4,normr21,18446744073709551615NR59,R60,R61,R62,R63,R12,R13,R64,R65,R13,R14,R11,R65,R13,R15,R13,R15,R13,R64,R65,R11,R13,R64,R65,R66,R67,R65,R68,R69,R70,R71,R72,R73,R74,R54,R13,R40,R13,R75,R13,R40,R76,v11,arbace.core6,bigintr21,18446744073709551616Nv13,arbace.c.cf2g4,headv13,arbace.c.cf2g4,bindv13,arbace.c.cf2g2,ixl3,R77,R78,R79,v13,arbace.c.cf2g4,seqxR80,R24,l4,v11,arbace.core4,not=l5,v13,arbace.c.cf2g9,call-exprR81,v13,arbace.c.cf2g6,branchR70,R52,v11,arbace.core6,mapcatv13,arbace.c.cf2g6,effectv13,arbace.c.cf2g4,stmtv13,arbace.c.cf2g10,store-stmtv13,arbace.c.cf2g8,ref-exprR82,R83,R84,R85,R34,R86,R66,R87,R66,R88,R24,R89,R63,l4194304,R67,R63,R90,R53,R70,R91,v13,arbace.c.cf2g7,bin-intML3,R13,R14,ML2,R92,ML2,R93,R83,m4,R94,i268,R95,i37,m4,R94,i268,R95,i32,m4,R94,i268,R95,i20,v13,arbace.c.cf2g2,fxv13,arbace.c.cf2g3,cndR52,R52,R53,v13,arbace.c.cf2g6,cmp-opR96,R52,R52,v13,arbace.c.cf2g2,wxR13,R14,R97,v13,arbace.c.cf2g6,wtype!R13,R15,R98,R53,R99,R24,R100,R53,R101,R102,R24,v13,arbace.c.cf2g9,load-exprR53,R56,R103,R66,R104,R79,R77,R105,R24,R55,R54,R52,ML2,R106,R79,m4,R94,i338,R95,i64,R13,R15,R107,R79,R53,R108,R109,R52,R56,R52,R53,R63,R67,R53,R54,R110,v13,arbace.c.cf2g6,froundR52,R52,R111,R24,R13,R75,R112,R24,R52,R52,S2,s1,ps3,u64R13,R15,R13,R40,R13,R75,R13,R40,R66,R87,R63,R67,R13,R40,R49,R24,R50,R24,v13,arbace.c.cf2g6,fconstR66,R113,R114,R115,R116,R117,R13,R15,R118,R24,R51,R24,R119,R120,R121,R122,R123,R124,R125,R126,R127,R128,R129,R24,R130,v13,arbace.c.cf2g7,wconst!R131,R24,R132,R13,R15,R133,R134,R52,R52,R135,v11,arbace.core4,peekv11,arbace.core3,popv11,arbace.core4,rseqR136,R137,R138,R139,R136,R137,c105,R140,R136,R137,c109,R141,R142,R136,R137,c119,R143,v11,arbace.core3,mapv11,arbace.core6,vectorR136,R137,R63,R90,R136,ML2,R144,R145,m4,R94,i447,R95,i32,R146,R147,R148,R149,R83,R79,R150,R85,R79,R34,R151,R79,R79,R150,R85,R79,R34,R151,R152,R85,R79,R52,R137,R52,R153,R153,R32,R24,R13,R15,R89,R52,R153,v13,arbace.c.cf2g7,*in-sj*v13,arbace.c.cf2g6,*lret*R52,R154,v13,arbace.c.cf2g8,ret-jumpR155,v13,arbace.c.cf2g7,*jumps*R156,v13,arbace.c.cf2g10,code-labelR52,R157,R136,R145,R52,R157,R136,R145,R102,R24,R52,R157,R136,R145,R52,R157,R136,R145,v11,arbace.core4,mapvv11,arbace.core6,reducev11,arbace.core9,array-mapv11,arbace.core7,sort-byv11,arbace.core6,filterv11,arbace.core6,concatR158,R159,R55,R108,R71,R13,R15,R13,R15,R73,R13,R15,R13,R15,R108,R71,R73,v13,arbace.c.cf2g9,nil-node?R55,R56,v13,arbace.c.cf2g8,ret-stmtR160,v13,arbace.c.cf2g4,jumpv13,arbace.c.cf2g7,sj-bodyR52,R66,l6291456,R161,R52,R13,R14,R162,R83,R162,R83,R13,R163,v13,arbace.c.cf2g11,switch-stmtR164,v13,arbace.c.cf2g9,loop-stmtv11,arbace.core4,sortv11,arbace.core3,setR161,R158,R159,R165,v11,arbace.core6,removeR47,R166,v13,arbace.string4,joinv11,arbace.core4,atomR167,v13,arbace.c.cf2g12,finish-scopeR158,R168,R159,v13,arbace.c.cf2g9,new-scopeR169,R83,R170,v11,arbace.core9,with-metaR168,m2,R171,R163,R55,R154,S2,R11,R12,R172,v11,arbace.core4,dropv13,arbace.c.cf2g11,arith-headsR13,R13,v11,arbace.core4,takev11,arbace.core12,keep-indexedR172,v11,arbace.walk8,postwalkv13,arbace.c.cf2g7,unconstR52,v11,arbace.core7,vector?v11,arbace.core4,nextv13,arbace.c.cf2g5,readsR52,R52,R137,v11,arbace.core4,compR171,R173,R174,R14,R40,R136,R175,R176,R177,R136,R175,R136,R175,R178,R179,R136,R175,R180,R181,R55,R72,R92,R182,R52,R110,R34,R182,R110,R34,R182,R55,R72,R92,R182,R52,R81,R34,R182,v13,arbace.c.cf2g9,param-litv13,arbace.c.cf2g11,param-stmtsR183,v13,arbace.c.cf2g9,slot-varsV1,V2,R154,R184,v13,arbace.c.cf2g11,unconst-allv13,arbace.c.cf2g9,decls-letv11,arbace.core4,nil?ML2,R185,R157,m4,R94,i716,R95,i20,R186,R79,R83,R187,R52,R110,R157,R110,R157,R188,R77,R136,R189,R190,R191,R192,R136,ML2,R144,R175,m4,R94,i719,R95,i73,R193,R79,m2,R171,ML2,R67,R194,m4,R94,i720,R95,i64,R182,m2,R171,ML2,R144,R145,m4,R94,i720,R95,i104,R195,V1,R145,R174,ML3,R196,R83,R187,m4,R94,i722,R95,i35,R90,R89,R157,m2,R171,R145,ML2,R173,R145,m4,R94,i725,R95,i61,R197,R79,R182,R34,R151,R13,R14,R198,R83,R13,R14,R199,R83,ML3,R52,R137,R90,m4,R94,i726,R95,i23,ML3,R52,R137,R89,m4,R94,i726,R95,i38,V1,V2,R154,R184,V1,ML2,R185,R200,m4,R94,i738,R95,i60,R193,R83,m2,R171,ML2,R67,R201,m4,R94,i739,R95,i64,V1,R163,R174,R79,ML2,R202,R83,m4,R94,i740,R95,i37,R90,ML3,R13,R14,ML2,R198,R83,m4,R94,i741,R95,i46,m4,R94,i741,R95,i34,R89,ML3,R13,R14,ML2,R199,R83,m4,R94,i742,R95,i45,m4,R94,i742,R95,i33,R157,m2,R171,R145,ML2,R173,R145,m4,R94,i743,R95,i60,ML3,R52,R137,R79,m4,R94,i744,R95,i22,ML3,R52,R137,R90,m4,R94,i744,R95,i34,ML3,R52,R137,R89,m4,R94,i744,R95,i49,ML3,R52,R137,R157,m4,R94,i744,R95,i63,v11,arbace.core14,*print-length*v11,arbace.core13,*print-level*v11,arbace.core6,pr-strR203,R204,R205,R206,R207,R208,v11,arbace.core11,map-indexedv11,arbace.core9,volatile!l-1,v13,arbace.c.cf2g7,init-fnv13,arbace.c.cf2g7,code-fnv11,arbace.core4,keepR188,v13,arbace.c.cf2g7,text-ofv11,arbace.core7,vreset!R52,ML2,R209,R210,m4,R94,i790,R95,i58,R211,ML2,R209,R210,m4,R94,i790,R95,i85,R136,R212,R213,R13,R214,R52,ML2,R209,R210,m4,R94,i789,R95,i54,R211,ML2,R209,R210,m4,R94,i789,R95,i81,R136,R212,R13,R214,R215,R216,R217,R216,R215,R216,R210,R136,ML2,R144,R14,m4,R94,i793,R95,i74,R136,ML2,R144,R14,m4,R94,i793,R95,i109,ML2,R144,R14,m4,R94,i793,R95,i74,ML2,R144,R14,m4,R94,i793,R95,i109,R188,R136,R218,R219,R220,R188,R221,v13,arbace.string7,replaceML3,R188,R137,R222,m4,R94,i815,R95,i20,ML3,R188,R137,R223,m4,R94,i816,R95,i20,ML2,R188,Myn1,Pm2,R171,ML2,R67,R224,m4,R94,i817,R95,i35,m4,R94,i817,R95,i20,ML2,R188,Myn1,Mm2,R171,ML2,R67,R225,m4,R94,i818,R95,i35,m4,R94,i818,R95,i20,ML2,R188,Myn1,Fm2,R171,ML2,R144,ML2,R67,R226,m4,R94,i819,R95,i42,m4,R94,i819,R95,i35,m4,R94,i819,R95,i20,ML2,R188,Myn1,Gm2,R171,ML2,R144,R14,m4,R94,i820,R95,i35,m4,R94,i820,R95,i20,R227,ML2,R228,V3,R229,R1,R230,m4,R94,i808,R95,i37,R231,R232,R233,V1,s7,prog.goR234,R235,R236,R8,R237,V1,V2,R238,s2,osV3,V2,R239,s4,mathV2,R240,s9,arbace/ciV2,R241,s10,arbace/crtv11,arbace.core10,sorted-mapR242,R193,R243,R244,ML3,R245,R246,l1,m4,R94,i799,R95,i56,R193,R244,R182,m2,R171,ML2,R144,R247,m4,R94,i801,R95,i61,R248,R182,R170,R210,m2,R171,ML2,R67,R224,m4,R94,i803,R95,i65,R216,m2,R171,ML2,R67,R249,m4,R94,i803,R95,i100,ML3,R52,R85,R210,m4,R94,i804,R95,i35,ML3,R52,R24,ML2,R250,R210,m4,R94,i804,R95,i55,m4,R94,i804,R95,i47,V2,ML3,R52,R151,ML2,R251,R210,m4,R94,i805,R95,i58,m4,R94,i805,R95,i50,ML3,R52,R86,ML2,R252,R210,m4,R94,i805,R95,i80,m4,R94,i805,R95,i72,R253,v20,arbace.repr.go.print13,collect-formsv11,arbace.core3,valv20,arbace.repr.go.print11,print-formsm4,R254,R255,R256,FR257,R258,v11,arbace.core11,read-stringR259,R260,R261,R262,R263,R264,v11,arbace.core7,ex-dataR265,R188,R136,R218,R188,R221,ML3,R188,R137,R222,m4,R94,i884,R95,i22,ML3,R188,R137,R223,m4,R94,i885,R95,i22,ML2,R188,Myn1,Pm2,R171,ML2,R67,R224,m4,R94,i886,R95,i37,m4,R94,i886,R95,i22,ML2,R188,Myn1,Mm2,R171,ML2,R67,R225,m4,R94,i887,R95,i37,m4,R94,i887,R95,i22,ML2,R188,Myn1,Fm2,R171,ML2,R144,ML2,R67,R226,m4,R94,i888,R95,i44,m4,R94,i888,R95,i37,m4,R94,i888,R95,i22,ML2,R188,Myn1,Gm2,R171,ML2,R144,R14,m4,R94,i889,R95,i37,m4,R94,i889,R95,i22,ML2,R188,Myn1,Rm2,R171,ML2,R144,R14,m4,R94,i890,R95,i37,m4,R94,i890,R95,i22,ML2,R188,Myn1,Sm2,R171,ML2,R144,R14,m4,R94,i891,R95,i37,m4,R94,i891,R95,i22,R227,ML2,R228,V3,R229,R1,R230,m4,R94,i878,R95,i39,R231,V1,s7,unit.goR234,R235,R236,V3,V2,R239,s4,mathV2,R240,s9,arbace/ciV2,R241,s10,arbace/crtR193,R266,ML3,R52,R85,R210,m4,R94,i894,R95,i28,ML3,R52,R24,ML2,R250,R210,m4,R94,i894,R95,i48,m4,R94,i894,R95,i40,ML3,R52,R151,ML2,R251,R210,m4,R94,i894,R95,i66,m4,R94,i894,R95,i58,ML3,R52,R86,ML2,R252,R210,m4,R94,i894,R95,i88,m4,R94,i894,R95,i80,ML3,R52,R35,R267,m4,R94,i894,R95,i104,ML3,R52,R36,R268,m4,R94,i894,R95,i116,R210,m2,R171,ML2,R67,R224,m4,R94,i893,R95,i49,R267,m2,R171,ML2,R144,R14,m4,R94,i893,R95,i84,R268,m2,R171,ML2,R144,R14,m4,R94,i893,R95,i121,R269,R270,v13,arbace.c.cf2g9,translatev13,arbace.c.cf2g10,read-nodesv11,arbace.core5,slurpv13,arbace.c.cf2g7,go-textR271,R272,R273,v11,arbace.core4,spitR274,R275,v13,arbace.string5,splitp2,\\tv13,arbace.string6,blank?v13,arbace.string11,split-linesv11,arbace.core7,resolveR276,R277,R278,R279,R280,R281,R282,p8,[\\t\\n\\r]v11,arbace.core5,doallv11,arbace.core11,future-callp2,\\tp1, R283,R284,R285,R286,v11,arbace.core5,classR287,R288,R289,R290,R291,R292,v11,arbace.core4,valsv11,arbace.core15,shutdown-agentsR293,S1,s8,--recordS2,s0,s8,--recordR294,v11,arbace.core4,juxtR295,v11,arbace.core8,identityv13,arbace.c.cf2g8,read-allR296,v11,arbace.core7,re-findR297,R298,R299,R300,v13,arbace.c.cf2g3,tsvR301,R302,R303,R304,R305,R287,v11,arbace.core7,printlnv11,arbace.core5,*out*v11,arbace.core5,*err*v11,arbace.core11,frequenciesl40,v11,arbace.core6,formatv11,arbace.core1,-V2,TTV2,FFV2,TFV2,FTR306,v13,arbace.c.cf2g12,compile-listp8,[\\t\\n\\r]p2,\\tv13,arbace.c.cf2g14,translate-fileR307,R308,v13,arbace.c.cf2g5,judge")

var Lit_1 *jrt.String = jrt.Intern("compile-list")

var Lit_2 *jrt.String = jrt.Intern("translate-list")

var Lit_3 *jrt.String = jrt.Intern("arbace.c.cf2g$_main$clean__1650001227")

var Lit_4 *jrt.String = jrt.Intern("arbace.c.cf2g$_main$iter__1650001229__1650001233")

var Lit_5 *jrt.String = jrt.Intern("2")

var Lit_6 *jrt.String = jrt.Intern("translate")

var Lit_7 *jrt.String = jrt.Intern("main")

var Lit_8 *jrt.String = jrt.Intern("ciprog")

var Lit_9 *jrt.String = jrt.Intern("cf2g:")

var Lit_10 *jrt.String = jrt.Intern("functions,")

var Lit_11 *jrt.String = jrt.Intern("bytes")

var Lit_12 *jrt.String = jrt.Intern("arbace.c.cf2g$_main$fn__1650001264")

var Lit_13 *jrt.String = jrt.Intern("judge")

var Lit_14 *jrt.String = jrt.Intern("cf2g: translate NODES OUTDIR [PKG PATH] | translate-list LIST THREADS | compile-list HOST OUT LIST THREADS | judge ...")

var Lit_15 *jrt.String = jrt.Intern(" ")

var Lit_16 *jrt.String = jrt.Intern("refused (")

var Lit_17 *jrt.String = jrt.Intern("): ")

var Lit_18 *jrt.String = jrt.Intern("arbace.c.cf2g$_main$iter__1650001229__1650001233$fn__1650001234")

var Lit_19 *jrt.String = jrt.Intern("arbace.c.cf2g$_main$iter__1650001229__1650001233$fn__1650001234$fn__1650001235")

var Lit_20 *jrt.String = jrt.Intern("arbace.c.cf2g$_main$iter__1650001229__1650001233$fn__1650001234$fn__1650001244")

var Lit_21 *jrt.String = jrt.Intern("arbace.c.cf2g$_main$iter__1650001229__1650001233$fn__1650001234$fn__1650001235$fn__1650001236")

var Lit_22 *jrt.String = jrt.Intern("arbace.c.cf2g$_main$iter__1650001229__1650001233$fn__1650001234$fn__1650001235$fn__1650001236$fn__1650001240")

var Lit_23 *jrt.String = jrt.Intern("\t")

var Lit_24 *jrt.String = jrt.Intern("")

var Lit_25 *jrt.String = jrt.Intern(": ")

var Lit_26 *jrt.String = jrt.Intern("arbace.c.cf2g$_main$iter__1650001229__1650001233$fn__1650001234$fn__1650001244$fn__1650001248")

var Lit_27 *jrt.String = jrt.Intern("arbace.c.cf2g$bin_int$nr__1650000112")

var Lit_28 *jrt.String = jrt.Intern("div")

var Lit_29 *jrt.String = jrt.Intern("rem")

var Lit_30 *jrt.String = jrt.Intern("add")

var Lit_31 *jrt.String = jrt.Intern("shl")

var Lit_32 *jrt.String = jrt.Intern("shr")

var Lit_33 *jrt.String = jrt.Intern("sub")

var Lit_34 *jrt.String = jrt.Intern("mul")

var Lit_35 *jrt.String = jrt.Intern("and")

var Lit_36 *jrt.String = jrt.Intern("xor")

var Lit_37 *jrt.String = jrt.Intern("or")

var Lit_38 *jrt.String = jrt.Intern("no integer operator ")

var Lit_39 *jrt.String = jrt.Intern("arbace.c.cf2g$bit_width$fn__1650000021")

var Lit_40 *jrt.String = jrt.Intern("fnref")

var Lit_41 *jrt.String = jrt.Intern("apack")

var Lit_42 *jrt.String = jrt.Intern("arbace.c.cf2g$call_expr$iter__1650000410__1650000414")

var Lit_43 *jrt.String = jrt.Intern("arbace.c.cf2g$call_expr$iter__1650000422__1650000426")

var Lit_44 *jrt.String = jrt.Intern("cf")

var Lit_45 *jrt.String = jrt.Intern("arbace.c.cf2g$call_expr$iter__1650000410__1650000414$fn__1650000415")

var Lit_46 *jrt.String = jrt.Intern("arbace.c.cf2g$call_expr$iter__1650000410__1650000414$fn__1650000415$fn__1650000416")

var Lit_47 *jrt.String = jrt.Intern("af")

var Lit_48 *jrt.String = jrt.Intern("ai")

var Lit_49 *jrt.String = jrt.Intern("am")

var Lit_50 *jrt.String = jrt.Intern("aw")

var Lit_51 *jrt.String = jrt.Intern("no argument ")

var Lit_52 *jrt.String = jrt.Intern("arbace.c.cf2g$call_expr$iter__1650000422__1650000426$fn__1650000427")

var Lit_53 *jrt.String = jrt.Intern("arbace.c.cf2g$call_expr$iter__1650000422__1650000426$fn__1650000427$fn__1650000428")

var Lit_54 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_55 *jrt.String = jrt.Intern("eq")

var Lit_56 *jrt.String = jrt.Intern("ge")

var Lit_57 *jrt.String = jrt.Intern("gt")

var Lit_58 *jrt.String = jrt.Intern("le")

var Lit_59 *jrt.String = jrt.Intern("lt")

var Lit_60 *jrt.String = jrt.Intern("ne")

var Lit_61 *jrt.String = jrt.Intern("no comparison ")

var Lit_62 *jrt.String = jrt.Intern("CC")

var Lit_63 *jrt.String = jrt.Intern("L")

var Lit_64 *jrt.String = jrt.Intern("user.dir")

var Lit_65 *jrt.String = jrt.Intern("arbace.c.cf2g$compile_list$clean__1650001045")

var Lit_66 *jrt.String = jrt.Intern("arbace.c.cf2g$compile_list$iter__1650001047__1650001051")

var Lit_67 *jrt.String = jrt.Intern("3")

var Lit_68 *jrt.String = jrt.Intern("/nodes.tsv")

var Lit_69 *jrt.String = jrt.Intern("\n")

var Lit_70 *jrt.String = jrt.Intern("arbace.c.cf2g$compile_list$iter__1650001047__1650001051$fn__1650001052")

var Lit_71 *jrt.String = jrt.Intern("arbace.c.cf2g$compile_list$iter__1650001047__1650001051$fn__1650001052$fn__1650001053")

var Lit_72 *jrt.String = jrt.Intern("arbace.c.cf2g$compile_list$iter__1650001047__1650001051$fn__1650001052$fn__1650001069")

var Lit_73 *jrt.String = jrt.Intern("arbace.c.cf2g$compile_list$iter__1650001047__1650001051$fn__1650001052$fn__1650001053$fn__1650001054")

var Lit_74 *jrt.String = jrt.Intern("-std=")

var Lit_75 *jrt.String = jrt.Intern("arbace.c.cf2g$compile_list$iter__1650001047__1650001051$fn__1650001052$fn__1650001053$fn__1650001054$fn__1650001058")

var Lit_76 *jrt.String = jrt.Intern("long-double")

var Lit_77 *jrt.String = jrt.Intern("arbace.c.cf2g$compile_list$iter__1650001047__1650001051$fn__1650001052$fn__1650001053$fn__1650001054$fn__1650001058$fn__1650001059")

var Lit_78 *jrt.String = jrt.Intern("refused")

var Lit_79 *jrt.String = jrt.Intern("arbace.c.cf2g$compile_list$iter__1650001047__1650001051$fn__1650001052$fn__1650001053$fn__1650001054$fn__1650001058$fn__1650001061")

var Lit_80 *jrt.String = jrt.Intern("ok")

var Lit_81 *jrt.String = jrt.Intern("build-error")

var Lit_82 *jrt.String = jrt.Intern("arbace/progs/")

var Lit_83 *jrt.String = jrt.Intern("/progs/")

var Lit_84 *jrt.String = jrt.Intern("CI_AOT_NODES")

var Lit_85 *jrt.String = jrt.Intern("prog.nodes")

var Lit_86 *jrt.String = jrt.Intern("prog.go")

var Lit_87 *jrt.String = jrt.Intern("arbace.c.cf2g$compile_list$iter__1650001047__1650001051$fn__1650001052$fn__1650001069$fn__1650001073")

var Lit_88 *jrt.String = jrt.Intern("arbace.c.cf2g$compile_list$iter__1650001047__1650001051$fn__1650001052$fn__1650001069$fn__1650001073$fn__1650001074")

var Lit_89 *jrt.String = jrt.Intern("arbace.c.cf2g$compile_list$iter__1650001047__1650001051$fn__1650001052$fn__1650001069$fn__1650001073$fn__1650001076")

var Lit_90 *jrt.String = jrt.Intern("arbace.c.cf2g$decls_let$fn__1650000615")

var Lit_91 *jrt.String = jrt.Intern("arbace.c.cf2g$decls_let$fn__1650000617")

var Lit_92 *jrt.String = jrt.Intern("arbace.c.cf2g$decls_let$fn__1650000620")

var Lit_93 *jrt.String = jrt.Intern("arbace.c.cf2g$effect$drop_pure__1650000442")

var Lit_94 *jrt.String = jrt.Intern("ef")

var Lit_95 *jrt.String = jrt.Intern("fcall")

var Lit_96 *jrt.String = jrt.Intern("fs")

var Lit_97 *jrt.String = jrt.Intern("f")

var Lit_98 *jrt.String = jrt.Intern("ew")

var Lit_99 *jrt.String = jrt.Intern("wcall")

var Lit_100 *jrt.String = jrt.Intern("ecall")

var Lit_101 *jrt.String = jrt.Intern("ei")

var Lit_102 *jrt.String = jrt.Intern("st")

var Lit_103 *jrt.String = jrt.Intern("bst")

var Lit_104 *jrt.String = jrt.Intern("sx")

var Lit_105 *jrt.String = jrt.Intern("zero")

var Lit_106 *jrt.String = jrt.Intern("is")

var Lit_107 *jrt.String = jrt.Intern("i")

var Lit_108 *jrt.String = jrt.Intern("copy")

var Lit_109 *jrt.String = jrt.Intern("call")

var Lit_110 *jrt.String = jrt.Intern("seq")

var Lit_111 *jrt.String = jrt.Intern("vastart")

var Lit_112 *jrt.String = jrt.Intern("nop")

var Lit_113 *jrt.String = jrt.Intern("arbace.c.cf2g$finish_scope$targets__1650000565")

var Lit_114 *jrt.String = jrt.Intern("arbace.c.cf2g$finish_scope$fn__1650000567")

var Lit_115 *jrt.String = jrt.Intern("a jump to a label outside its function's block: ")

var Lit_116 *jrt.String = jrt.Intern("arbace.c.cf2g$finish_scope$fn__1650000579")

var Lit_117 *jrt.String = jrt.Intern("arbace.c.cf2g$finish_scope$fn__1650000567$iter__1650000568__1650000572")

var Lit_118 *jrt.String = jrt.Intern("arbace.c.cf2g$finish_scope$fn__1650000567$iter__1650000568__1650000572$fn__1650000573")

var Lit_119 *jrt.String = jrt.Intern("arbace.c.cf2g$finish_scope$fn__1650000567$iter__1650000568__1650000572$fn__1650000573$fn__1650000574")

var Lit_120 *jrt.String = jrt.Intern("fif")

var Lit_121 *jrt.String = jrt.Intern("fl")

var Lit_122 *jrt.String = jrt.Intern("fst")

var Lit_123 *jrt.String = jrt.Intern("f32")

var Lit_124 *jrt.String = jrt.Intern("fsx")

var Lit_125 *jrt.String = jrt.Intern("r32")

var Lit_126 *jrt.String = jrt.Intern("i2f")

var Lit_127 *jrt.String = jrt.Intern("fld")

var Lit_128 *jrt.String = jrt.Intern("fbin")

var Lit_129 *jrt.String = jrt.Intern("no floating operator ")

var Lit_130 *jrt.String = jrt.Intern("fneg")

var Lit_131 *jrt.String = jrt.Intern("w2f")

var Lit_132 *jrt.String = jrt.Intern("fseq")

var Lit_133 *jrt.String = jrt.Intern("no floating node ")

var Lit_134 *jrt.String = jrt.Intern("arbace.c.cf2g$has_label_QMARK_$fn__1650000108")

var Lit_135 *jrt.String = jrt.Intern("in")

var Lit_136 *jrt.String = jrt.Intern("elvis")

var Lit_137 *jrt.String = jrt.Intern("vlalloc")

var Lit_138 *jrt.String = jrt.Intern("arbace.c.cf2g$ix$sl__1650000131")

var Lit_139 *jrt.String = jrt.Intern("g")

var Lit_140 *jrt.String = jrt.Intern("cv")

var Lit_141 *jrt.String = jrt.Intern("pdiff")

var Lit_142 *jrt.String = jrt.Intern("va")

var Lit_143 *jrt.String = jrt.Intern("fa")

var Lit_144 *jrt.String = jrt.Intern("fp")

var Lit_145 *jrt.String = jrt.Intern("lnot")

var Lit_146 *jrt.String = jrt.Intern("labaddr")

var Lit_147 *jrt.String = jrt.Intern("bin")

var Lit_148 *jrt.String = jrt.Intern("vplen")

var Lit_149 *jrt.String = jrt.Intern("if")

var Lit_150 *jrt.String = jrt.Intern("fcmp")

var Lit_151 *jrt.String = jrt.Intern("il")

var Lit_152 *jrt.String = jrt.Intern("trap")

var Lit_153 *jrt.String = jrt.Intern("w2i")

var Lit_154 *jrt.String = jrt.Intern("bnot")

var Lit_155 *jrt.String = jrt.Intern("cmp")

var Lit_156 *jrt.String = jrt.Intern("arbace.c.cf2g$ix$w__1650000211")

var Lit_157 *jrt.String = jrt.Intern("bld")

var Lit_158 *jrt.String = jrt.Intern("f2i")

var Lit_159 *jrt.String = jrt.Intern("wcmp")

var Lit_160 *jrt.String = jrt.Intern("ld")

var Lit_161 *jrt.String = jrt.Intern("wtest")

var Lit_162 *jrt.String = jrt.Intern("neg")

var Lit_163 *jrt.String = jrt.Intern("vlamark")

var Lit_164 *jrt.String = jrt.Intern("vlarestore")

var Lit_165 *jrt.String = jrt.Intern("vaarg")

var Lit_166 *jrt.String = jrt.Intern("alloca")

var Lit_167 *jrt.String = jrt.Intern("adds")

var Lit_168 *jrt.String = jrt.Intern("ftest")

var Lit_169 *jrt.String = jrt.Intern("no integer node ")

var Lit_170 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$fn__1650001102")

var Lit_171 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$fn__1650001104")

var Lit_172 *jrt.String = jrt.Intern("test/c/check-known.edn")

var Lit_173 *jrt.String = jrt.Intern("test/c/check-aot-known.edn")

var Lit_174 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$klass__1650001107")

var Lit_175 *jrt.String = jrt.Intern("test/c/check-linux-amd64.edn")

var Lit_176 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$iter__1650001116__1650001122")

var Lit_177 *jrt.String = jrt.Intern("test/c/check-aot-linux-amd64.edn")

var Lit_178 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$fn__1650001150")

var Lit_179 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$ipass_QMARK___1650001152")

var Lit_180 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$fn__1650001154")

var Lit_181 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$fn__1650001157")

var Lit_182 *jrt.String = jrt.Intern("/results.edn")

var Lit_183 *jrt.String = jrt.Intern("[\n")

var Lit_184 *jrt.String = jrt.Intern("\n]\n")

var Lit_185 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$fn__1650001166")

var Lit_186 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$fn__1650001168")

var Lit_187 *jrt.String = jrt.Intern("%-24s %5d programs: %s")

var Lit_188 *jrt.String = jrt.Intern(", ")

var Lit_189 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$fn__1650001171")

var Lit_190 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$fn__1650001176")

var Lit_191 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$fn__1650001178")

var Lit_192 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$fn__1650001181")

var Lit_193 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$fn__1650001186")

var Lit_194 *jrt.String = jrt.Intern("compiled against interpreted (results):")

var Lit_195 *jrt.String = jrt.Intern("both pass,")

var Lit_196 *jrt.String = jrt.Intern("neither,")

var Lit_197 *jrt.String = jrt.Intern("compiled only,")

var Lit_198 *jrt.String = jrt.Intern("interpreted only")

var Lit_199 *jrt.String = jrt.Intern("compiled against interpreted (runs: status and stdout):")

var Lit_200 *jrt.String = jrt.Intern("the same,")

var Lit_201 *jrt.String = jrt.Intern("differ,")

var Lit_202 *jrt.String = jrt.Intern("with no interpreted run")

var Lit_203 *jrt.String = jrt.Intern("compiled against interpreted (runs): not compared (CI_AOT_NODES=1 runs the interpreter beside, CI_INTERP names its directory)")

var Lit_204 *jrt.String = jrt.Intern("  DIFFER")

var Lit_205 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$fn__1650001199")

var Lit_206 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$fn__1650001207")

var Lit_207 *jrt.String = jrt.Intern("recorded")

var Lit_208 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$fn__1650001212")

var Lit_209 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$fn__1650001214")

var Lit_210 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$fn__1650001217")

var Lit_211 *jrt.String = jrt.Intern("ci aot judge")

var Lit_212 *jrt.String = jrt.Intern("ci aot judge:")

var Lit_213 *jrt.String = jrt.Intern("/")

var Lit_214 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$fn__1650001199$fn__1650001203")

var Lit_215 *jrt.String = jrt.Intern("interpreted only: ")

var Lit_216 *jrt.String = jrt.Intern("differs from a passing interpreted run: ")

var Lit_217 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$iter__1650001116__1650001122$fn__1650001123")

var Lit_218 *jrt.String = jrt.Intern("/run.tsv")

var Lit_219 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$iter__1650001116__1650001122$fn__1650001123$iter__1650001118__1650001124")

var Lit_220 *jrt.String = jrt.Intern("/list.tsv")

var Lit_221 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$iter__1650001116__1650001122$fn__1650001123$iter__1650001118__1650001124$fn__1650001125")

var Lit_222 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$iter__1650001116__1650001122$fn__1650001123$iter__1650001118__1650001124$fn__1650001125$fn__1650001126")

var Lit_223 *jrt.String = jrt.Intern("torture-execute-mirror/")

var Lit_224 *jrt.String = jrt.Intern("torture-execute/")

var Lit_225 *jrt.String = jrt.Intern("internal: ")

var Lit_226 *jrt.String = jrt.Intern("known ")

var Lit_227 *jrt.String = jrt.Intern(" (")

var Lit_228 *jrt.String = jrt.Intern(")")

var Lit_229 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$klass__1650001107$fn__1650001111")

var Lit_230 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$klass__1650001107$fn__1650001111$fn__1650001112")

var Lit_231 *jrt.String = jrt.Intern("G")

var Lit_232 *jrt.String = jrt.Intern("b")

var Lit_233 *jrt.String = jrt.Intern("u8")

var Lit_234 *jrt.String = jrt.Intern("i64")

var Lit_235 *jrt.String = jrt.Intern("i32")

var Lit_236 *jrt.String = jrt.Intern("i16")

var Lit_237 *jrt.String = jrt.Intern("i8")

var Lit_238 *jrt.String = jrt.Intern("p")

var Lit_239 *jrt.String = jrt.Intern("u64")

var Lit_240 *jrt.String = jrt.Intern("u32")

var Lit_241 *jrt.String = jrt.Intern("u16")

var Lit_242 *jrt.String = jrt.Intern("arbace.c.cf2g$loop_stmt$cond_stmts__1650000549")

var Lit_243 *jrt.String = jrt.Intern("arbace.c.cf2g$loop_stmt$fn__1650000554")

var Lit_244 *jrt.String = jrt.Intern("nil")

var Lit_245 *jrt.String = jrt.Intern("pf")

var Lit_246 *jrt.String = jrt.Intern("pi")

var Lit_247 *jrt.String = jrt.Intern("pm")

var Lit_248 *jrt.String = jrt.Intern("pw")

var Lit_249 *jrt.String = jrt.Intern("no parameter ")

var Lit_250 *jrt.String = jrt.Intern("arbace.c.cf2g$param_stmts$fn__1650000649")

var Lit_251 *jrt.String = jrt.Intern("WT")

var Lit_252 *jrt.String = jrt.Intern("arbace.c.cf2g$reads$walk__1650000603")

var Lit_253 *jrt.String = jrt.Intern("an unresolved placeholder ")

var Lit_254 *jrt.String = jrt.Intern("retf")

var Lit_255 *jrt.String = jrt.Intern("reti")

var Lit_256 *jrt.String = jrt.Intern("retm")

var Lit_257 *jrt.String = jrt.Intern("retw")

var Lit_258 *jrt.String = jrt.Intern("no return ")

var Lit_259 *jrt.String = jrt.Intern("arbace.c.cf2g$seqx$iter__1650000066__1650000070")

var Lit_260 *jrt.String = jrt.Intern("arbace.c.cf2g$seqx$iter__1650000066__1650000070$fn__1650000071")

var Lit_261 *jrt.String = jrt.Intern("arbace.c.cf2g$seqx$iter__1650000066__1650000070$fn__1650000071$fn__1650000072")

var Lit_262 *jrt.String = jrt.Intern("arbace.c.cf2g$seqx$iter__1650000066__1650000070$fn__1650000071$fn__1650000084")

var Lit_263 *jrt.String = jrt.Intern("arbace.c.cf2g$seqx$iter__1650000066__1650000070$fn__1650000071$fn__1650000072$fn__1650000074")

var Lit_264 *jrt.String = jrt.Intern("a setjmp body inside another")

var Lit_265 *jrt.String = jrt.Intern("arbace.c.cf2g$sj_body$fn__1650000583")

var Lit_266 *jrt.String = jrt.Intern("arbace.c.cf2g$sj_body$fn__1650000583$iter__1650000584__1650000588")

var Lit_267 *jrt.String = jrt.Intern("arbace.c.cf2g$sj_body$fn__1650000583$iter__1650000584__1650000588$fn__1650000589")

var Lit_268 *jrt.String = jrt.Intern("arbace.c.cf2g$sj_body$fn__1650000583$iter__1650000584__1650000588$fn__1650000589$fn__1650000590")

var Lit_269 *jrt.String = jrt.Intern("arbace.c.cf2g$slot_vars$iter__1650000626__1650000630")

var Lit_270 *jrt.String = jrt.Intern("arbace.c.cf2g$slot_vars$iter__1650000636__1650000640")

var Lit_271 *jrt.String = jrt.Intern("arbace.c.cf2g$slot_vars$iter__1650000626__1650000630$fn__1650000631")

var Lit_272 *jrt.String = jrt.Intern("arbace.c.cf2g$slot_vars$iter__1650000626__1650000630$fn__1650000631$fn__1650000632")

var Lit_273 *jrt.String = jrt.Intern("arbace.c.cf2g$slot_vars$iter__1650000636__1650000640$fn__1650000641")

var Lit_274 *jrt.String = jrt.Intern("arbace.c.cf2g$slot_vars$iter__1650000636__1650000640$fn__1650000641$fn__1650000642")

var Lit_275 *jrt.String = jrt.Intern("x")

var Lit_276 *jrt.String = jrt.Intern("ret")

var Lit_277 *jrt.String = jrt.Intern("lab")

var Lit_278 *jrt.String = jrt.Intern("when")

var Lit_279 *jrt.String = jrt.Intern("jmp")

var Lit_280 *jrt.String = jrt.Intern("sjbody")

var Lit_281 *jrt.String = jrt.Intern("do")

var Lit_282 *jrt.String = jrt.Intern("igoto")

var Lit_283 *jrt.String = jrt.Intern("sj")

var Lit_284 *jrt.String = jrt.Intern("sw")

var Lit_285 *jrt.String = jrt.Intern("loop")

var Lit_286 *jrt.String = jrt.Intern("no statement ")

var Lit_287 *jrt.String = jrt.Intern("arbace.c.cf2g$switch_stmt$fn__1650000496")

var Lit_288 *jrt.String = jrt.Intern("arbace.c.cf2g$switch_stmt$fn__1650000499")

var Lit_289 *jrt.String = jrt.Intern("arbace.c.cf2g$switch_stmt$fn__1650000505")

var Lit_290 *jrt.String = jrt.Intern("arbace.c.cf2g$switch_stmt$iter__1650000510__1650000514")

var Lit_291 *jrt.String = jrt.Intern("arbace.c.cf2g$switch_stmt$iter__1650000526__1650000530")

var Lit_292 *jrt.String = jrt.Intern("arbace.c.cf2g$switch_stmt$fn__1650000542")

var Lit_293 *jrt.String = jrt.Intern("arbace.c.cf2g$switch_stmt$iter__1650000510__1650000514$fn__1650000515")

var Lit_294 *jrt.String = jrt.Intern("arbace.c.cf2g$switch_stmt$iter__1650000510__1650000514$fn__1650000515$fn__1650000516")

var Lit_295 *jrt.String = jrt.Intern("arbace.c.cf2g$switch_stmt$iter__1650000526__1650000530$fn__1650000531")

var Lit_296 *jrt.String = jrt.Intern("arbace.c.cf2g$switch_stmt$iter__1650000526__1650000530$fn__1650000531$fn__1650000532")

var Lit_297 *jrt.String = jrt.Intern("u")

var Lit_298 *jrt.String = jrt.Intern("t")

var Lit_299 *jrt.String = jrt.Intern("w")

var Lit_300 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$iter__1650000679__1650000683")

var Lit_301 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$iter__1650000689__1650000693")

var Lit_302 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$iter__1650000705__1650000709")

var Lit_303 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$fn__1650000722")

var Lit_304 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$fn__1650000729")

var Lit_305 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$fn__1650000736")

var Lit_306 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$fn__1650000742")

var Lit_307 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$iter__1650000751__1650000755")

var Lit_308 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$iter__1650000767__1650000771")

var Lit_309 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$iter__1650000789__1650000793")

var Lit_310 *jrt.String = jrt.Intern("go.")

var Lit_311 *jrt.String = jrt.Intern(".")

var Lit_312 *jrt.String = jrt.Intern("A C program compiled by cf2g (arbace.c.cf2g) from its node program.\n")

var Lit_313 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$iter__1650000805__1650000809")

var Lit_314 *jrt.String = jrt.Intern("init")

var Lit_315 *jrt.String = jrt.Intern("code")

var Lit_316 *jrt.String = jrt.Intern("D")

var Lit_317 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$iter__1650000679__1650000683$fn__1650000684")

var Lit_318 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$iter__1650000679__1650000683$fn__1650000684$fn__1650000685")

var Lit_319 *jrt.String = jrt.Intern("static")

var Lit_320 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$iter__1650000689__1650000693$fn__1650000694")

var Lit_321 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$iter__1650000689__1650000693$fn__1650000694$fn__1650000695")

var Lit_322 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$iter__1650000705__1650000709$fn__1650000710")

var Lit_323 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$iter__1650000705__1650000709$fn__1650000710$fn__1650000711")

var Lit_324 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$iter__1650000751__1650000755$fn__1650000756")

var Lit_325 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$iter__1650000751__1650000755$fn__1650000756$fn__1650000757")

var Lit_326 *jrt.String = jrt.Intern("Bind")

var Lit_327 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$iter__1650000767__1650000771$fn__1650000772")

var Lit_328 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$iter__1650000767__1650000771$fn__1650000772$fn__1650000773")

var Lit_329 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$iter__1650000789__1650000793$fn__1650000794")

var Lit_330 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$iter__1650000789__1650000793$fn__1650000794$fn__1650000795")

var Lit_331 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$iter__1650000805__1650000809$fn__1650000810")

var Lit_332 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$iter__1650000805__1650000809$fn__1650000810$fn__1650000811")

var Lit_333 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$read1__1650000826")

var Lit_334 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$fn__1650000829")

var Lit_335 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$iter__1650000834__1650000838")

var Lit_336 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$iter__1650000852__1650000856")

var Lit_337 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$pass__1650000868")

var Lit_338 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$iter__1650000934__1650000938")

var Lit_339 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$fn__1650000957")

var Lit_340 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$iter__1650000962__1650000966")

var Lit_341 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$iter__1650000984__1650000988")

var Lit_342 *jrt.String = jrt.Intern("unit.go")

var Lit_343 *jrt.String = jrt.Intern("A library unit's code compiled once by cf2g (arbace.c.cf2g/translate-unit) from its fragment.\n")

var Lit_344 *jrt.String = jrt.Intern("Bind sets the unit's program and its relocation tables (the program's link).\n")

var Lit_345 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$iter__1650001000__1650001004")

var Lit_346 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$iter__1650001016__1650001020")

var Lit_347 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$iter__1650000834__1650000838$fn__1650000839")

var Lit_348 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$iter__1650000834__1650000838$fn__1650000839$fn__1650000840")

var Lit_349 *jrt.String = jrt.Intern("(code ")

var Lit_350 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$iter__1650000852__1650000856$fn__1650000857")

var Lit_351 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$iter__1650000852__1650000856$fn__1650000857$fn__1650000858")

var Lit_352 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$iter__1650000934__1650000938$fn__1650000939")

var Lit_353 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$iter__1650000934__1650000938$fn__1650000939$fn__1650000940")

var Lit_354 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$iter__1650000962__1650000966$fn__1650000967")

var Lit_355 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$iter__1650000962__1650000966$fn__1650000967$fn__1650000968")

var Lit_356 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$iter__1650000984__1650000988$fn__1650000989")

var Lit_357 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$iter__1650000984__1650000988$fn__1650000989$fn__1650000990")

var Lit_358 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$iter__1650001000__1650001004$fn__1650001005")

var Lit_359 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$iter__1650001000__1650001004$fn__1650001005$fn__1650001006")

var Lit_360 *jrt.String = jrt.Intern("C")

var Lit_361 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$iter__1650001016__1650001020$fn__1650001021")

var Lit_362 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$iter__1650001016__1650001020$fn__1650001021$fn__1650001022")

var Lit_363 *jrt.String = jrt.Intern("I")

var Lit_364 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$pass__1650000868$try1__1650000869")

var Lit_365 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$pass__1650000868$iter__1650000871__1650000875")

var Lit_366 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$pass__1650000868$fn__1650000887")

var Lit_367 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$pass__1650000868$fn__1650000909")

var Lit_368 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$pass__1650000868$fn__1650000887$iter__1650000888__1650000892")

var Lit_369 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$pass__1650000868$fn__1650000887$iter__1650000888__1650000892$fn__1650000893")

var Lit_370 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$pass__1650000868$fn__1650000887$iter__1650000888__1650000892$fn__1650000893$fn__1650000894")

var Lit_371 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$pass__1650000868$fn__1650000887$iter__1650000888__1650000892$fn__1650000893$fn__1650000904")

var Lit_372 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$pass__1650000868$fn__1650000887$iter__1650000888__1650000892$fn__1650000893$fn__1650000894$fn__1650000898")

var Lit_373 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$pass__1650000868$fn__1650000909$iter__1650000910__1650000914")

var Lit_374 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$pass__1650000868$fn__1650000909$iter__1650000910__1650000914$fn__1650000915")

var Lit_375 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$pass__1650000868$fn__1650000909$iter__1650000910__1650000914$fn__1650000915$fn__1650000916")

var Lit_376 *jrt.String = jrt.Intern("(init ")

var Lit_377 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$pass__1650000868$fn__1650000909$iter__1650000910__1650000914$fn__1650000915$fn__1650000928")

var Lit_378 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$pass__1650000868$fn__1650000909$iter__1650000910__1650000914$fn__1650000915$fn__1650000916$fn__1650000921")

var Lit_379 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$pass__1650000868$iter__1650000871__1650000875$fn__1650000876")

var Lit_380 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit$pass__1650000868$iter__1650000871__1650000875$fn__1650000876$fn__1650000877")

var Lit_381 *jrt.String = jrt.Intern("arbace.c.cf2g$tsv$fn__1650001038")

var Lit_382 *jrt.String = jrt.Intern("arbace.c.cf2g$unconst$fn__1650000597")

var Lit_383 *jrt.String = jrt.Intern("arbace.c.cf2g$unconst$fn__1650000599")

var Lit_384 *jrt.String = jrt.Intern("WC")

var Lit_385 *jrt.String = jrt.Intern("wsh")

var Lit_386 *jrt.String = jrt.Intern("wst")

var Lit_387 *jrt.String = jrt.Intern("wld")

var Lit_388 *jrt.String = jrt.Intern("wbin")

var Lit_389 *jrt.String = jrt.Intern("no wide operator ")

var Lit_390 *jrt.String = jrt.Intern("w2w")

var Lit_391 *jrt.String = jrt.Intern("f2w")

var Lit_392 *jrt.String = jrt.Intern("wbst")

var Lit_393 *jrt.String = jrt.Intern("wbld")

var Lit_394 *jrt.String = jrt.Intern("wseq")

var Lit_395 *jrt.String = jrt.Intern("i2w")

var Lit_396 *jrt.String = jrt.Intern("wneg")

var Lit_397 *jrt.String = jrt.Intern("wif")

var Lit_398 *jrt.String = jrt.Intern("wnot")

var Lit_399 *jrt.String = jrt.Intern("no wide node ")

var Lit_400 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistsyn3,clsyn1,&yn3,msgkn4,linekn6,columnkn4,filekn3,tagyn6,Stringyn1,xyn16,java.lang.Stringyn4,longyn1,cyn1,tyn1,eyn1,akn7,dynamickn4,Lretyn6,prefixyn4,typeyn1,kyn2,kwyn4,agetys4,math15,Float64frombitsyn1,<yn7,bit-xoryn2,<=yn1,*ys2,ci4,Boolys2,ci1,Byn1,>yn1,-yn7,bit-andyn2,>>yn6,bit-oryn2,>=yn4,convyn1,+yn7,bit-notyn2,!=yn2,==yn2,<<yn5,partsyn1,syn5,stmtsyn4,thenyn4,elsekn8,declaredyn2,opyn1,byn3,f32yn4,bitsyn4,textyn4,codeyn1,_yn3,unsyn5,casesyn4,dfltyn4,bodyyn4,stepyn3,do?yn11,bit-and-notyn1,%yn1,/yn5,formsyn4,varsyn2,niyn2,nfyn1,qyn6,paramsyn2,idyn5,frameyn8,variadicyn6,retf32yn5,gnameyn1,nyn4,cmdsyn3,pkgyn4,pathyn3,preyn4,fragyn8,host-diryn3,outyn4,listyn7,threadsyn4,workyn4,reffyn4,divfyn4,divayn6,interpyn4,moreyn4,verbyn4,argsv11,arbace.core5,in-nsMyn13,arbace.c.cf2gm2,R0,s1271,cf2g, C's AOT (doc/C23-SURVEY.md §7, CS13 (a), CS17 (a); \"As built: C6 (write-ahead)\"): a C program's\n  node program (arbace.c.build's output, the lowered C forms ci's back end runs, CS120) translated into Go\n  forms over go/arbace/ci and go/arbace/crt, printed by repr/go and built by Go's compiler. Each function\n  of the program with code is a Go function of package-level name fID, the Native of its Func (ci.Enter's\n  frame in the C stack, its slots Go locals); its statements and expressions flattened into one block of\n  assignments, conditional gotos and labels, so that C's gotos into blocks, loops and switches (Duff's\n  device) and switch's cases are Go's gotos; expressions in temporaries wherever an operand's evaluation\n  has an effect, in ci's order (the builder's: gcc -O0's); setjmp's function body a closure under\n  ci.SjRun. The program's data (fn, native, static, data, at, alias, fnalias, start) stays node program\n  text, loaded by ci's Loader as on the interpreted path, so both lay out memory alike. A node or a jump\n  the translator cannot express is refused, with its reason (class aot-*).\n\n  translate gives the Go forms of one program's package; -main: `translate NODES OUTDIR [PKG]` and\n  `translate-list LIST THREADS` (bin/ci check --aot's).m2,R0,s1271,cf2g, C's AOT (doc/C23-SURVEY.md §7, CS13 (a), CS17 (a); \"As built: C6 (write-ahead)\"): a C program's\n  node program (arbace.c.build's output, the lowered C forms ci's back end runs, CS120) translated into Go\n  forms over go/arbace/ci and go/arbace/crt, printed by repr/go and built by Go's compiler. Each function\n  of the program with code is a Go function of package-level name fID, the Native of its Func (ci.Enter's\n  frame in the C stack, its slots Go locals); its statements and expressions flattened into one block of\n  assignments, conditional gotos and labels, so that C's gotos into blocks, loops and switches (Duff's\n  device) and switch's cases are Go's gotos; expressions in temporaries wherever an operand's evaluation\n  has an effect, in ci's order (the builder's: gcc -O0's); setjmp's function body a closure under\n  ci.SjRun. The program's data (fn, native, static, data, at, alias, fnalias, start) stays node program\n  text, loaded by ci's Loader as on the interpreted path, so both lay out memory alike. A node or a jump\n  the translator cannot express is refused, with its reason (class aot-*).\n\n  translate gives the Go forms of one program's package; -main: `translate NODES OUTDIR [PKG]` and\n  `translate-list LIST THREADS` (bin/ci check --aot's).R1,v11,arbace.core20,*warn-on-reflection*v13,arbace.c.cf2g6,refusem10,R2,TR3,L1,V3,R4,R5,R6,R7,i22,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g10,read-nodesm10,R3,L1,V1,Myn4,textm2,R10,R11,R0,s72,A node program's commands from its text (arbace.c.build/program-text's).R7,i28,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g2,nmm12,R2,TR3,L1,MV1,R12,m2,R10,R13,R0,s42,A word of a node: a string or a bare word.R7,i35,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g3,lngm12,R2,TR3,L1,MV1,R12,m2,R10,R14,R0,s66,An integer of a node: wrapped to 64 bits (the loader's ParseUint).R7,i36,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g4,headm10,R2,TR3,L1,V1,R15,R7,i40,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g9,nil-node?m10,R2,TR3,L1,V1,R12,R7,i41,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g9,bit-widthm12,R2,TR3,L1,V1,Myn1,tm2,R10,R11,R0,s88,[n signed] of a _BitInt type sN/uN (and gcc's wide bit-field types), nil for the others.R7,i46,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g9,unsigned?m10,R2,TR3,L1,V1,R16,R7,i53,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g5,widthm10,R2,TR3,L1,MV1,R16,m2,R10,R14,R7,i56,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g4,normm12,R2,TR3,L1,V2,R16,R17,R0,s52,e (an int64 expression) normalized to t, as ci.Norm.R7,i61,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g11,needs-norm?m10,R2,TR3,L1,V1,R16,R7,i80,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g2,uam10,R2,TR3,L1,V1,R18,R7,i83,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g9,load-exprm10,R2,TR3,L1,V2,R16,R18,R7,i85,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g10,store-stmtm10,R2,TR3,L1,V3,R16,R18,R12,R7,i96,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g5,*pkg*m8,R19,TR7,i109,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g4,*fn*m8,R19,TR7,i110,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g7,*scope*m8,R19,TR7,i111,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g7,*jumps*m8,R19,TR7,i112,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g6,*lret*R20,m8,R19,TR7,i113,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g7,*in-sj*m8,R19,TR7,i114,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g7,*reloc*m8,R19,TR7,i119,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g11,placeholderm12,R2,TR3,L1,V1,R12,R0,s89,[f L] or [s L] (the kind a char) of a fragment's placeholder symbol ?fL or ?sL, else nil.R7,i121,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g8,ref-exprm12,R2,TR3,L1,V1,R12,R0,s102,A function's id or a static's index of a node: its number, or in *reloc* the relocation table's entry.R7,i129,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g6,fresh!m10,R2,TR3,L1,V2,R21,R22,R7,i137,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g4,tmp!m10,R2,TR3,L1,V1,R23,R7,i143,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g6,label!m10,R2,TR3,L1,V0,R7,i144,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g5,goto!m10,R2,TR3,L1,V1,R24,R7,i145,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g9,deflabel!m10,R2,TR3,L1,V1,R24,R7,i146,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g10,code-labelm10,R2,TR3,L1,V1,R15,R7,i147,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g6,wtype!m12,R2,TR3,L1,V1,R12,R0,s66,The package variable holding the WType of a node's \"sN\"/\"uN\" word.R7,i149,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g5,slot?m10,R2,TR3,L1,V1,R17,R7,i156,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g10,pure-headsS20,R25,R26,R27,R28,R29,R30,R31,R32,R33,R34,R35,R36,R37,R38,R39,R40,R41,R42,R43,R44,m8,R2,TR7,i158,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g7,stable?m12,R2,TR3,L1,V1,R17,R0,s78,Whether e's value cannot change before it is used (no slot, no load, no call).R7,i161,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g5,pure?m12,R2,TR3,L1,V1,R17,R0,s85,Whether evaluating e has no effect but a load's possible fault (no call that writes).R7,i169,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g4,seqxm12,R2,TR3,L1,V1,R45,R0,s169,Children compiled as [kind [stmts expr]] in evaluation order: [stmts exprs], an expression bound to a\n  temporary when a later child has statements and it is not stable.R7,i178,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g4,bindm12,R2,TR3,L1,V2,R23,V2,R46,R17,R0,s56,[stmts temp] : e's value in a fresh temporary of kind k.R7,i193,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g3,cndm12,R2,TR3,L1,V1,R17,R0,s32,An int64 condition as a Go bool.R7,i198,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g10,has-label?m10,R2,TR3,L1,V1,R47,R7,i201,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g6,branchm12,R2,TR3,L1,V3,R15,R48,R49,R0,s85,if (c) then else, c a Go bool: a Go if when neither branch holds a label, else gotos.R7,i203,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g2,ixm8,R50,TR7,i221,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g2,fxm8,R50,TR7,i221,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g2,wxm8,R50,TR7,i221,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g4,stmtm8,R50,TR7,i221,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g6,effectm8,R50,TR7,i221,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g9,call-exprm8,R50,TR7,i221,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g7,bin-intm10,R2,TR3,L1,V4,R51,R16,R18,R52,R7,i223,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g6,cmp-opm10,R2,TR3,L1,V1,R51,R7,i247,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g6,froundm12,R2,TR3,L1,V2,R53,R17,R0,s82,float64 e, explicitly converted (no fusion, Go's spec), rounded to float when f32.R7,i250,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g6,fconstm10,R2,TR3,L1,V1,R54,R7,i253,R8,i1,R9,s16,arbace/c/cf2g.aem12,R2,TR3,L1,V1,R15,R0,s36,An integer node: [stmts int64-expr].R7,i256,R8,i1,R9,s16,arbace/c/cf2g.aem12,R2,TR3,L1,V1,R15,R0,s38,A floating node: [stmts float64-expr].R7,i344,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g7,wconst!m10,R2,TR3,L1,V2,R16,R55,R7,i377,R8,i1,R9,s16,arbace/c/cf2g.aem12,R2,TR3,L1,V1,R15,R0,s35,A wide node: [stmts crt.Wide-expr].R7,i382,R8,i1,R9,s16,arbace/c/cf2g.aem12,R2,TR3,L1,V1,R15,R0,s102,(KIND CALLEE [args] SRET SOFF): [stmts call-expr], the callee first, then the arguments right to left.R7,i418,R8,i1,R9,s16,arbace/c/cf2g.aem12,R2,TR3,L1,V1,R15,R0,s31,An effect node: its statements.R7,i459,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g8,ret-jumpm10,R2,TR3,L1,V0,R7,i490,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g4,jumpm10,R2,TR3,L1,V1,R56,R7,i492,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g8,ret-stmtm10,R2,TR3,L1,V1,R15,R7,i500,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g11,switch-stmtm10,R2,TR3,L1,V1,V6,R57,R17,R58,R59,R60,R61,R7,i515,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g9,loop-stmtm10,R2,TR3,L1,V1,V5,R57,R15,R62,R61,R63,R7,i537,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g7,sj-bodym8,R50,TR7,i552,R8,i1,R9,s16,arbace/c/cf2g.aem12,R2,TR3,L1,V1,R15,R0,s33,A statement node: its statements.R7,i554,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g12,finish-scopem12,R2,TR3,L1,V1,R47,R0,s133,The scope's statements with igoto's dispatches made, the labels no goto names dropped; a goto to a\n  label outside the scope refused.R7,i581,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g9,new-scopem10,R2,TR3,L1,V0,R7,i600,R8,i1,R9,s16,arbace/c/cf2g.aem12,R2,TR3,L1,V1,R61,R0,s95,A body that calls setjmp: a closure under ci.SjRun, entered again at a setjmp statement's code.R7,i602,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g11,arith-headsS13,R28,R30,R64,R65,R34,R35,R36,R66,R37,R39,R40,R41,R44,m8,R2,TR7,i621,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g7,unconstm12,R2,TR3,L1,V1,R12,R0,s171,An operation of constants alone made one of values (its first int64 constant as ci.K's): Go's exact\n  constant arithmetic would refuse what overflows; the machine's wraps.R7,i623,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g11,unconst-allm10,R2,TR3,L1,V1,R67,R7,i644,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g5,readsm12,R2,TR3,L1,V1,R67,R0,s66,The symbols the forms read (a set!'s target is written, not read).R7,i646,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g9,decls-letm12,R2,TR3,L1,V2,R68,R61,R0,s155,The function's variables declared around the body: those it reads (Go refuses a variable declared and\n  not used), the assignments of the others made to _.R7,i658,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g9,slot-varsm10,R2,TR3,L1,V2,R69,R70,R7,i676,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g9,param-litm10,R2,TR3,L1,V1,R71,R7,i680,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g11,param-stmtsm10,R2,TR3,L1,V1,R72,R7,i688,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g7,code-fnm12,R2,TR3,L1,V3,V9,R57,R73,R69,R70,R74,R75,R76,R72,R61,R5,V1,R77,R0,s167,(code ID NI NF FRAME VARIADIC RETF32 PARAMS BODY): the Go function cfID and its Code variable CCID (a library unit's\n  item: the names given, its id the relocation's).R7,i699,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g7,init-fnm12,R2,TR3,L1,V4,R78,R15,R5,V1,R77,R0,s130,(init STMT) or (init NI NF STMT): the Go function inN (or the name given: a library unit's), a ci.GoStmt of the\n  program's Inits.R7,i729,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g7,text-ofm10,R2,TR3,L1,V1,R79,R7,i747,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g9,translatem10,R3,L1,V5,R79,R80,R81,R5,V1,R82,R0,s538,The Go forms of the node program cmds as the package pkg (path PATH, a main package when pkg is main):\n  [forms {:functions n}]. Throws ex-info with :cf2g/refused for a node it cannot express. `pre` (arbace.c.aotlib's\n  program-pre): the commands that are a prebuilt library unit's items, {:items {INDEX GO-SYMBOL} :imports [[ALIAS PATH] ...]\n  :binds [[ALIAS R S] ...]}: such a code command's function is the unit package's (SetCompiled), such an init its GoStmt, and\n  each unit's relocation tables are bound once the program is loaded.R7,i751,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g7,go-textm10,R3,L1,MV1,R67,m2,R10,R13,R0,s71,The Go text of translate's forms (repr/go's printer, its gofmt layout).R7,i825,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g14,translate-unitm10,R3,L1,V3,R83,R80,R81,R0,s659,A library unit's fragment (arbace.c.build/unit-fragment's) translated once into the Go forms of its own package `pkg` (path\n  `path`), linked by programs instead of its code commands (doc/rust/RUST-EVAL-SURVEY.md, \"As built: RES34 (write-ahead)\"):\n  its Jth function candidate's code the function CJ, its Jth object's initializer the GoStmt IJ, each with its placeholders\n  through the relocation tables R and S that Bind sets (the program's link: arbace.c.build's *link-trace*). An item cf2g\n  refuses is left out, listed: the program translates its command itself. [forms {:fns {J NAME} :inits {J NAME} :refused\n  {[:f|:o J] [CLASS MESSAGE]} :functions n}].R7,i831,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g14,translate-filem10,R3,L1,V4,Myn10,nodes-pathm2,R10,R11,Myn7,out-dirm2,R10,R11,R80,R81,R0,s171,The node program at nodes-path translated into out-dir/prog.go as package pkg (path path): {:status :ok\n  :functions n :bytes b} or {:status :refused :class c :message m}.R7,i901,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g3,tsvm10,R2,TR3,L1,V1,Myn1,fm2,R10,R11,R7,i917,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g12,compile-listm12,R2,TR3,L1,V1,V4,R84,R85,R86,R87,R0,s409,compile-list HOST-DIR OUT LIST THREADS: each line of LIST (ID BASE STD ARGS READNAME PKG, tab-separated: a\n  program of one file) read, checked, linked with musl, built into its node program and translated into the\n  package OUT/progs/PKG (path arbace/progs/PKG); OUT/nodes.tsv lists ID STATUS [CLASS MESSAGE FLAGS], as\n  arbace.c.run's nodes-list does (a refusal of cf2g's the status refused with its class).R7,i921,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g8,read-allm10,R2,TR3,L1,V1,Myn1,fm2,R10,R11,R7,i982,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g5,judgem12,R2,TR3,L1,V1,V7,R88,R89,R90,R91,R92,R5,R93,R0,s381,judge WORK REF DIVERGENCES DIVERGENCES-AOT INTERP [--record] CORPUS...: each program's compiled run\n  against gcc's (arbace.c.run/result's rule), every non-pass in a class of the two files (the\n  interpreter's, then AOT's own); and against the interpreted run (INTERP: a directory of the\n  interpreted check's CORPUS/run.tsv), diffcheck's kind: the same status and standard output.R7,i985,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g5,-mainm10,R3,L1,V3,R94,R5,R95,R0,s280,translate NODES OUTDIR [PKG PATH]: one node program into OUTDIR/prog.go (default package main);\n  translate-list LIST THREADS: each line ID NODES OUTDIR PKG PATH (tab-separated) translated, a line\n  ID STATUS CLASS MESSAGE FUNCTIONS BYTES a program printed on the standard output.R7,i1071,R8,i1,R9,s16,arbace/c/cf2g.ae")

var Lit_401 *jrt.String = jrt.Intern("arbace.c.cf2g$eval1650000004$loading__1927001464__auto____1650000005")

var Lit_402 *jrt.String = jrt.Intern("arbace.c.cf2g$eval1650000008$fn__1650000009")

var Lit_403 *jrt.String = jrt.Intern("arbace.c.cf2g$refuse")

var Lit_404 *jrt.String = jrt.Intern("arbace.c.cf2g$read_nodes")

var Lit_405 *jrt.String = jrt.Intern("arbace.c.cf2g$nm")

var Lit_406 *jrt.String = jrt.Intern("arbace.c.cf2g$lng")

var Lit_407 *jrt.String = jrt.Intern("arbace.c.cf2g$head")

var Lit_408 *jrt.String = jrt.Intern("arbace.c.cf2g$nil_node_QMARK_")

var Lit_409 *jrt.String = jrt.Intern("arbace.c.cf2g$bit_width")

var Lit_410 *jrt.String = jrt.Intern("arbace.c.cf2g$unsigned_QMARK_")

var Lit_411 *jrt.String = jrt.Intern("arbace.c.cf2g$width")

var Lit_412 *jrt.String = jrt.Intern("arbace.c.cf2g$norm")

var Lit_413 *jrt.String = jrt.Intern("arbace.c.cf2g$needs_norm_QMARK_")

var Lit_414 *jrt.String = jrt.Intern("arbace.c.cf2g$ua")

var Lit_415 *jrt.String = jrt.Intern("arbace.c.cf2g$load_expr")

var Lit_416 *jrt.String = jrt.Intern("arbace.c.cf2g$store_stmt")

var Lit_417 *jrt.String = jrt.Intern("arbace.c.cf2g$placeholder")

var Lit_418 *jrt.String = jrt.Intern("arbace.c.cf2g$ref_expr")

var Lit_419 *jrt.String = jrt.Intern("arbace.c.cf2g$fresh_BANG_")

var Lit_420 *jrt.String = jrt.Intern("arbace.c.cf2g$tmp_BANG_")

var Lit_421 *jrt.String = jrt.Intern("arbace.c.cf2g$label_BANG_")

var Lit_422 *jrt.String = jrt.Intern("arbace.c.cf2g$goto_BANG_")

var Lit_423 *jrt.String = jrt.Intern("arbace.c.cf2g$deflabel_BANG_")

var Lit_424 *jrt.String = jrt.Intern("arbace.c.cf2g$code_label")

var Lit_425 *jrt.String = jrt.Intern("arbace.c.cf2g$wtype_BANG_")

var Lit_426 *jrt.String = jrt.Intern("arbace.c.cf2g$slot_QMARK_")

var Lit_427 *jrt.String = jrt.Intern("arbace.c.cf2g$stable_QMARK_")

var Lit_428 *jrt.String = jrt.Intern("arbace.c.cf2g$pure_QMARK_")

var Lit_429 *jrt.String = jrt.Intern("arbace.c.cf2g$seqx")

var Lit_430 *jrt.String = jrt.Intern("arbace.c.cf2g$bind")

var Lit_431 *jrt.String = jrt.Intern("arbace.c.cf2g$cnd")

var Lit_432 *jrt.String = jrt.Intern("arbace.c.cf2g$has_label_QMARK_")

var Lit_433 *jrt.String = jrt.Intern("arbace.c.cf2g$branch")

var Lit_434 *jrt.String = jrt.Intern("arbace.c.cf2g$bin_int")

var Lit_435 *jrt.String = jrt.Intern("arbace.c.cf2g$cmp_op")

var Lit_436 *jrt.String = jrt.Intern("arbace.c.cf2g$fround")

var Lit_437 *jrt.String = jrt.Intern("arbace.c.cf2g$fconst")

var Lit_438 *jrt.String = jrt.Intern("arbace.c.cf2g$ix")

var Lit_439 *jrt.String = jrt.Intern("arbace.c.cf2g$fx")

var Lit_440 *jrt.String = jrt.Intern("arbace.c.cf2g$wconst_BANG_")

var Lit_441 *jrt.String = jrt.Intern("arbace.c.cf2g$wx")

var Lit_442 *jrt.String = jrt.Intern("arbace.c.cf2g$call_expr")

var Lit_443 *jrt.String = jrt.Intern("arbace.c.cf2g$effect")

var Lit_444 *jrt.String = jrt.Intern("arbace.c.cf2g$ret_jump")

var Lit_445 *jrt.String = jrt.Intern("arbace.c.cf2g$jump")

var Lit_446 *jrt.String = jrt.Intern("arbace.c.cf2g$ret_stmt")

var Lit_447 *jrt.String = jrt.Intern("arbace.c.cf2g$switch_stmt")

var Lit_448 *jrt.String = jrt.Intern("arbace.c.cf2g$loop_stmt")

var Lit_449 *jrt.String = jrt.Intern("arbace.c.cf2g$stmt")

var Lit_450 *jrt.String = jrt.Intern("arbace.c.cf2g$finish_scope")

var Lit_451 *jrt.String = jrt.Intern("arbace.c.cf2g$new_scope")

var Lit_452 *jrt.String = jrt.Intern("arbace.c.cf2g$sj_body")

var Lit_453 *jrt.String = jrt.Intern("arbace.c.cf2g$unconst")

var Lit_454 *jrt.String = jrt.Intern("arbace.c.cf2g$unconst_all")

var Lit_455 *jrt.String = jrt.Intern("arbace.c.cf2g$reads")

var Lit_456 *jrt.String = jrt.Intern("arbace.c.cf2g$decls_let")

var Lit_457 *jrt.String = jrt.Intern("arbace.c.cf2g$slot_vars")

var Lit_458 *jrt.String = jrt.Intern("arbace.c.cf2g$param_lit")

var Lit_459 *jrt.String = jrt.Intern("arbace.c.cf2g$param_stmts")

var Lit_460 *jrt.String = jrt.Intern("arbace.c.cf2g$code_fn")

var Lit_461 *jrt.String = jrt.Intern("arbace.c.cf2g$init_fn")

var Lit_462 *jrt.String = jrt.Intern("arbace.c.cf2g$text_of")

var Lit_463 *jrt.String = jrt.Intern("arbace.c.cf2g$translate")

var Lit_464 *jrt.String = jrt.Intern("arbace.c.cf2g$go_text")

var Lit_465 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_unit")

var Lit_466 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_file")

var Lit_467 *jrt.String = jrt.Intern("arbace.c.cf2g$tsv")

var Lit_468 *jrt.String = jrt.Intern("arbace.c.cf2g$compile_list")

var Lit_469 *jrt.String = jrt.Intern("arbace.c.cf2g$read_all")

var Lit_470 *jrt.String = jrt.Intern("arbace.c.cf2g$judge")

var Lit_471 *jrt.String = jrt.Intern("arbace.c.cf2g$_main")
