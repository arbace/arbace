//line j2g_strings.ae:1
package aot_arbace_c_cf2g

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn11,arbace.walkyn4,walkyn20,arbace.repr.go.printyn2,gpyn11,arbace.corekn3,docks4,cf2g7,refusedkn4,elseyn2,>>yn2,<<yn4,convyn5,int64yn6,uint64ys2,ci4,Boolyn5,uint8yn6,uint32yn5,int32yn6,uint16yn5,int16yn4,int8yn6,.Load8yn1,Myn7,.Load64yn7,.Load32yn7,.Load16ys2,ci4,Loadyn7,.Store8yn8,.Store32yn8,.Store16yn8,.Store64kn1,nkn4,varskn1,fyn7,float64kn1,ikn1,wys3,crt4,Widekn4,usedyn4,gotokn4,defsyn5,labelkn6,wtypesyn8,.LoadF32yn8,.LoadF64yn9,.LoadWideyn4,set!ys2,ci1,Byn2,!=yn4,whenyn3,notyn2,ifyn2,dokn8,aot-nodeys2,ci4,UDivys2,ci4,URemys2,ci4,SDivys2,ci4,SRemyn1,+yn4,uintyn7,bit-andyn1,-yn1,*yn7,bit-xoryn6,bit-oryn2,==yn2,>=yn1,>yn2,<=yn1,<yn7,float32ys4,math15,Float64frombitsyn4,addrys2,ci10,VlaAllocAtyn1,tys2,ci8,BitStoreyn3,.-Iyn4,agetyn1,Gyn1,/yn5,.Fillyn3,vaayn4,basekn10,addr-takenys2,ci4,Trapyn7,.Uint64yn7,bit-notys2,ci7,BitLoadys2,ci7,F2IConvyn4,.Cmpyn5,.Moveyn7,.IsZeroys2,ci9,VlaMarkAtys2,ci7,VaArgAtyn4,.-SPkn4,linekn6,columnys2,ci7,AllocaTyn3,andyn2,oryn3,.-Fyn9,.StoreF32yn9,.StoreF64yn8,.Float64kn7,wconstsyn5,.Normyn4,.Shlyn4,.Shryn10,.StoreWideyn4,.Subyn4,.Addyn3,.Oryn4,.Mulys2,ci4,WDivyn4,.Andys2,ci4,WRemyn4,.Xoryn3,.-Wyn5,.Convys3,crt12,WFromFloat64ys3,crt11,WFromUint64ys3,crt10,WFromInt64yn4,.Negyn4,.Notyn3,lityn1,_kn1,Kkn1,Fkn1,Ikn4,Addrkn4,Sizekn1,Wyn5,sliceys2,ci3,Argkn8,compiledyn5,.Callyn1,Pyn1,Fyn9,.CallAddryn2,eiyn4,retdkn3,brkkn4,contyn3,retyn6,switchyn4,casekn5,codesyn14,igoto-dispatchyn6,.SjSetyn2,frys2,ci3,Ctlkn2,sjyn7,defaultkn8,aot-gotokn4,Sretyn5,enterys2,ci5,SjRunyn2,fnkn3,tagys2,ci1,Kyn4,zeroyn3,letys2,ci5,Paramkn4,Slotkn3,F32kn3,Offkn1,Tkn4,Widekn2,WTyn3,lenyn4,argskn4,Lretyn4,boolyn6,returnys2,ci5,Leaveyn2,spys2,go3,varys2,ci4,Codekn9,FrameSizekn8,Variadickn6,Paramsys2,go4,funcys2,ci6,Threadkn7,resultsyn6,valuesys2,ci5,Enteryn6,.-Baseyn4,.-VAys2,ci5,CNextys2,ci5,Frameyn3,.-Tkn4,initkn4,codekn4,datayn8,.TopTextyn1,lyn12,.SetCompiledyn7,.-Initsyn1,pyn6,appendys2,ci4,Initkn1,Sys2,ci6,GoStmtys3,crt5,WTypekn1,Nkn6,Signedys2,ci8,MustWideys4,math2,Piys3,crt4,Textys2,ci4,Progys3,crt3,Memys2,ci4,Funcyn2,nskn7,requireyn9,arbace.goyn2,goys2,go7,packagekn4,pathkn5,filesyn5,in-nsyn5,quoteys2,go4,filekn7,importsyn2,osyn4,mathyn2,ciyn3,crtyn4,mainyn4,Mainyn8,subsliceys2,os4,Argsyn6,stringys2,ci7,AotMainys2,ci6,Loaderyn3,.-Myn7,.-Funcsyn9,.StaticsIkn9,functionskn6,layoutkn5,gofmtkn16,line-directives?kn6,statuskn2,okkn5,byteskn7,refusedkn5,classkn7,messageys18,arbace.repr.c.host9,load-hostys13,arbace.c.musl7,libraryys12,arbace.c.run9,read-unitys12,arbace.c.run17,uses-long-double?ys13,arbace.c.musl12,build-linkedks2,ci7,refusedys14,arbace.c.build12,program-textkn5,formskn2,rdyn12,arbace.c.runyn18,arbace.repr.c.hostyn13,arbace.c.muslyn14,arbace.c.buildys12,arbace.c.run6,resultys12,arbace.c.run21,subset-record-refusalkn2,idkn5,speedkn5,matchkn4,samekn6,differkn9,no-interpkn4,passkn4,failys12,arbace.c.run14,compare-recordys12,arbace.c.run13,report-recordys12,arbace.c.run16,controls-failingkn5,errorkn9,aot-errorv11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,V3,R5,R1,R6,v11,arbace.core5,referR7,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn13,arbace.c.cf2gm2,R8,s1271,cf2g, C's AOT (doc/C23-SURVEY.md §7, CS13 (a), CS17 (a); \"As built: C6 (write-ahead)\"): a C program's\n  node program (arbace.c.build's output, the lowered C forms ci's back end runs, CS120) translated into Go\n  forms over go/arbace/ci and go/arbace/crt, printed by repr/go and built by Go's compiler. Each function\n  of the program with code is a Go function of package-level name fID, the Native of its Func (ci.Enter's\n  frame in the C stack, its slots Go locals); its statements and expressions flattened into one block of\n  assignments, conditional gotos and labels, so that C's gotos into blocks, loops and switches (Duff's\n  device) and switch's cases are Go's gotos; expressions in temporaries wherever an operand's evaluation\n  has an effect, in ci's order (the builder's: gcc -O0's); setjmp's function body a closure under\n  ci.SjRun. The program's data (fn, native, static, data, at, alias, fnalias, start) stays node program\n  text, loaded by ci's Loader as on the interpreted path, so both lay out memory alike. A node or a jump\n  the translator cannot express is refused, with its reason (class aot-*).\n\n  translate gives the Go forms of one program's package; -main: `translate NODES OUTDIR [PKG]` and\n  `translate-list LIST THREADS` (bin/ci check --aot's).v11,arbace.core7,ex-infov11,arbace.core5,applyv11,arbace.core3,strR9,v11,arbace.core4,readv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core11,*read-eval*v11,arbace.core7,string?v11,arbace.core4,namev11,arbace.core10,bigintegerR10,v13,arbace.c.cf2g2,nmv11,arbace.core5,firstv11,arbace.core7,symbol?S2,c115,c117,v11,arbace.core3,notS4,s3,u16s3,u32s2,u8s3,u64v11,arbace.core6,every?v11,arbace.core4,subsl1,c115,v13,arbace.c.cf2g9,bit-widthv11,arbace.core9,contains?S6,s3,u16s1,ps3,u32s2,u8s1,bs3,u64l64,l8,l32,l16,v11,arbace.core4,listR11,R12,R13,R14,R11,R12,R13,R15,R16,R13,R14,R13,R17,R13,R14,R13,R18,R13,R14,R13,R19,R13,R14,R13,R20,R13,R14,R13,R21,R13,R14,R13,R22,S7,s3,u16s3,u32s2,u8s1,bs3,i16s2,i8s3,i32R13,R15,R13,R14,R23,R24,v13,arbace.c.cf2g2,uaR13,R14,R25,R24,R13,R14,R13,R19,R26,R24,R13,R14,R13,R21,R27,R24,R13,R14,R13,R22,R23,R24,R13,R14,R26,R24,R13,R14,R27,R24,R28,R24,R29,R24,R13,R17,R30,R24,R13,R18,R31,R24,R13,R20,R32,R24,R13,R15,R33,v11,arbace.core5,swap!v13,arbace.c.cf2g4,*fn*v11,arbace.core6,updatev11,arbace.core3,incv11,arbace.core6,symbolR34,R35,v13,arbace.c.cf2g6,fresh!R36,R37,R14,R38,R39,v11,arbace.core7,keywordv13,arbace.c.cf2g7,*scope*R40,R41,R42,R43,v13,arbace.c.cf2g5,*pkg*R44,v11,arbace.core5,assocv11,arbace.core10,re-matchesp10,[if][0-9]+v11,arbace.core7,number?v11,arbace.core5,char?v11,arbace.core8,keyword?v11,arbace.core8,boolean?v13,arbace.c.cf2g5,slot?v11,arbace.core4,seq?v13,arbace.c.cf2g10,pure-headsv13,arbace.c.cf2g7,stable?v11,arbace.core4,restS8,R23,R26,R45,R28,R46,R47,R25,R27,v13,arbace.string12,starts-with?v13,arbace.c.cf2g5,pure?v11,arbace.core3,vecv11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core4,somev11,arbace.core6,subvecv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv11,arbace.core5,rangev13,arbace.c.cf2g4,tmp!v11,arbace.core4,intoR48,R48,R49,v11,arbace.core6,secondR50,l0,R43,v13,arbace.c.cf2g10,has-label?v11,arbace.core6,empty?v13,arbace.c.cf2g6,label!R51,v13,arbace.c.cf2g5,goto!R52,v13,arbace.c.cf2g9,deflabel!R51,R51,R52,R53,R54,R54,v13,arbace.c.cf2g11,needs-norm?v13,arbace.c.cf2g5,widthv13,arbace.c.cf2g9,unsigned?v13,arbace.c.cf2g4,normr21,18446744073709551615Nv13,arbace.c.cf2g6,refuseR55,R56,R57,R58,R59,R60,R12,R13,R61,R62,R13,R14,R11,R62,R13,R15,R13,R15,R13,R61,R62,R11,R13,R61,R62,R63,R64,R62,R65,R66,R67,R68,R69,R70,R71,R50,R13,R36,R13,R72,R13,R36,R73,v11,arbace.core6,bigintr21,18446744073709551616Nv13,arbace.c.cf2g4,headv13,arbace.c.cf2g4,bindv13,arbace.c.cf2g2,ixl3,R74,v13,arbace.c.cf2g3,lngR75,R76,l2,v13,arbace.c.cf2g4,seqxR77,R24,l4,v11,arbace.core4,not=l5,v13,arbace.c.cf2g9,call-exprR78,v13,arbace.c.cf2g6,branchR67,R48,v11,arbace.core6,mapcatv13,arbace.c.cf2g6,effectv13,arbace.c.cf2g4,stmtv13,arbace.c.cf2g10,store-stmtR79,R80,R63,R81,R63,R82,R24,R83,R60,R84,R49,R67,R85,v13,arbace.c.cf2g7,bin-intv13,arbace.c.cf2g2,fxv13,arbace.c.cf2g3,cndR48,R48,R49,v13,arbace.c.cf2g6,cmp-opR86,R48,R48,v13,arbace.c.cf2g2,wxR13,R14,R87,v13,arbace.c.cf2g6,wtype!R13,R15,R88,R49,R89,R24,R90,R49,R91,R92,R24,v13,arbace.c.cf2g9,load-exprR49,R52,R93,R63,R94,R76,R74,R95,R24,R51,R50,R48,ML2,R96,R76,m4,R97,i310,R98,i64,R13,R15,R99,R76,R49,R100,R101,R48,R52,R48,R49,R60,R64,R49,R50,R102,v13,arbace.c.cf2g6,froundR48,R48,R103,R24,R13,R72,R104,R24,R48,R48,S2,s1,ps3,u64R13,R15,R13,R36,R13,R72,R13,R36,R63,R81,R60,R64,R13,R36,R45,R24,R46,R24,v13,arbace.c.cf2g6,fconstR63,R105,R106,R107,R108,R109,R13,R15,R110,R24,R47,R24,R111,R112,R113,R114,R115,R116,R117,R118,R119,R120,R121,v13,arbace.c.cf2g7,wconst!R122,R13,R15,R123,R124,R48,R48,R125,v11,arbace.core4,rseqR126,R127,R128,c102,R129,R126,R127,c105,R130,R126,R127,c109,R131,R132,R126,R127,c119,R133,v11,arbace.core3,mapv11,arbace.core6,vectorR126,R127,R60,R84,R126,ML2,R134,R135,m4,R97,i411,R98,i32,R136,R76,R137,R138,R76,R79,R139,R140,R138,R76,R48,R127,R48,R141,R141,R32,R24,R13,R15,R83,R48,R141,v13,arbace.c.cf2g7,*in-sj*v13,arbace.c.cf2g6,*lret*R48,R142,v13,arbace.c.cf2g8,ret-jumpR143,v13,arbace.c.cf2g7,*jumps*R144,v13,arbace.c.cf2g10,code-labelR48,R145,R126,R135,R48,R145,R126,R135,R92,R24,R48,R145,R126,R135,R48,R145,R126,R135,v11,arbace.core4,mapvv11,arbace.core6,reducev11,arbace.core9,array-mapv11,arbace.core7,sort-byv11,arbace.core6,filterv11,arbace.core6,concatR146,R147,R51,R100,R68,R13,R15,R13,R15,R70,R13,R15,R13,R15,R100,R68,R70,v13,arbace.c.cf2g9,nil-node?R51,R52,v13,arbace.c.cf2g8,ret-stmtR148,v13,arbace.c.cf2g4,jumpv13,arbace.c.cf2g7,sj-bodyR48,R63,l6291456,R149,R48,R13,R14,R150,R151,R150,R151,R13,R152,v13,arbace.c.cf2g11,switch-stmtR153,v13,arbace.c.cf2g9,loop-stmtv11,arbace.core4,sortv11,arbace.core3,setR149,R146,R147,R154,v11,arbace.core6,removeR43,R155,v13,arbace.string4,joinv11,arbace.core4,atomR156,v13,arbace.c.cf2g12,finish-scopeR146,R157,R147,v13,arbace.c.cf2g9,new-scopeR158,R151,R159,v11,arbace.core9,with-metaR157,m2,R160,R152,R51,R142,S2,R11,R12,R161,v11,arbace.core4,dropv13,arbace.c.cf2g11,arith-headsR13,R13,v11,arbace.core4,takev11,arbace.core12,keep-indexedR161,v11,arbace.walk8,postwalkv13,arbace.c.cf2g7,unconstR48,v11,arbace.core7,vector?v11,arbace.core4,nextv13,arbace.c.cf2g5,readsR48,R48,R127,v11,arbace.core4,compR160,R162,R163,R14,R36,R126,R164,R165,R166,R126,R164,R126,R164,R167,R168,R126,R164,R169,R170,R51,R69,R171,R172,R48,R102,R79,R172,R102,R79,R172,R51,R69,R171,R172,R48,R78,R79,R172,v13,arbace.c.cf2g9,param-litv13,arbace.c.cf2g11,param-stmtsR173,v13,arbace.c.cf2g9,slot-varsV1,V2,R142,R174,v13,arbace.c.cf2g11,unconst-allv13,arbace.c.cf2g9,decls-letv11,arbace.core4,nil?ML2,R175,R145,m4,R97,i672,R98,i20,R176,R76,R151,R177,R48,R102,R145,R102,R145,R178,R74,R126,R179,R180,R181,R182,R126,ML2,R134,R164,m4,R97,i675,R98,i73,R183,R76,m2,R160,ML2,R64,R184,m4,R97,i676,R98,i64,R172,m2,R160,ML2,R134,R135,m4,R97,i676,R98,i104,R185,V1,R135,R163,ML3,R186,R151,R177,m4,R97,i678,R98,i35,R84,R83,R145,m2,R160,R135,ML2,R162,R135,m4,R97,i681,R98,i61,R187,R76,R172,R79,R139,R13,R14,R188,R151,R13,R14,R189,R151,ML3,R48,R127,R84,m4,R97,i682,R98,i23,ML3,R48,R127,R83,m4,R97,i682,R98,i38,V1,V2,R142,R174,V1,ML2,R175,R190,m4,R97,i693,R98,i60,R183,R151,m2,R160,ML2,R64,R191,m4,R97,i694,R98,i64,V1,R152,R163,R76,ML2,R192,R151,m4,R97,i695,R98,i37,R84,ML3,R13,R14,ML2,R188,R151,m4,R97,i696,R98,i46,m4,R97,i696,R98,i34,R83,ML3,R13,R14,ML2,R189,R151,m4,R97,i697,R98,i45,m4,R97,i697,R98,i33,R145,m2,R160,R135,ML2,R162,R135,m4,R97,i698,R98,i60,ML3,R48,R127,R76,m4,R97,i699,R98,i22,ML3,R48,R127,R84,m4,R97,i699,R98,i34,ML3,R48,R127,R83,m4,R97,i699,R98,i49,ML3,R48,R127,R145,m4,R97,i699,R98,i63,v11,arbace.core14,*print-length*v11,arbace.core13,*print-level*v11,arbace.core6,pr-strR193,R194,R195,v11,arbace.core4,peekv11,arbace.core3,popv11,arbace.core9,volatile!l-1,v13,arbace.c.cf2g7,code-fnv13,arbace.c.cf2g7,init-fnv11,arbace.core4,keepR178,v13,arbace.c.cf2g7,text-ofv11,arbace.core7,vreset!R196,R197,R198,R197,R48,ML2,R199,R200,m4,R97,i734,R98,i54,R201,ML2,R199,R200,m4,R97,i734,R98,i81,R126,R202,R203,R13,R204,R178,R126,R205,R206,R207,R178,R208,v13,arbace.string7,replaceML3,R178,R127,R209,m4,R97,i756,R98,i20,ML3,R178,R127,R210,m4,R97,i757,R98,i20,ML2,R178,Myn1,Pm2,R160,ML2,R64,R211,m4,R97,i758,R98,i35,m4,R97,i758,R98,i20,ML2,R178,Myn1,Mm2,R160,ML2,R64,R212,m4,R97,i759,R98,i35,m4,R97,i759,R98,i20,ML2,R178,Myn1,Fm2,R160,ML2,R134,ML2,R64,R213,m4,R97,i760,R98,i42,m4,R97,i760,R98,i35,m4,R97,i760,R98,i20,ML2,R178,Myn1,Gm2,R160,ML2,R134,R14,m4,R97,i761,R98,i35,m4,R97,i761,R98,i20,R214,ML2,R215,V3,R216,R1,R217,m4,R97,i750,R98,i37,R218,R219,R220,V1,s7,prog.goR221,R222,R223,R8,R224,V1,V2,R225,s2,osV3,V2,R226,s4,mathV2,R227,s9,arbace/ciV2,R228,s10,arbace/crtv11,arbace.core10,sorted-mapR183,R229,R230,ML3,R231,R232,l1,m4,R97,i741,R98,i56,R183,R230,R172,m2,R160,ML2,R134,R233,m4,R97,i743,R98,i61,R234,R172,R159,R200,m2,R160,ML2,R64,R211,m4,R97,i745,R98,i65,R197,m2,R160,ML2,R64,R235,m4,R97,i745,R98,i100,ML3,R48,R138,R200,m4,R97,i746,R98,i35,ML3,R48,R24,ML2,R236,R200,m4,R97,i746,R98,i55,m4,R97,i746,R98,i47,V2,ML3,R48,R139,ML2,R237,R200,m4,R97,i747,R98,i58,m4,R97,i747,R98,i50,ML3,R48,R80,ML2,R238,R200,m4,R97,i747,R98,i80,m4,R97,i747,R98,i72,R239,v20,arbace.repr.go.print13,collect-formsv11,arbace.core3,valv20,arbace.repr.go.print11,print-formsm4,R240,R241,R242,Fv13,arbace.c.cf2g9,translatev13,arbace.c.cf2g10,read-nodesv11,arbace.core5,slurpv13,arbace.c.cf2g7,go-textR243,R244,R245,v11,arbace.core4,spitv11,arbace.core7,ex-dataR246,R247,R248,v13,arbace.string5,splitp2,\\tv13,arbace.string6,blank?v13,arbace.string11,split-linesv11,arbace.core7,resolveR249,R250,R251,R252,R253,p8,[\\t\\n\\r]v11,arbace.core5,doallv11,arbace.core11,future-callp2,\\tp1, R254,v11,arbace.core4,map?R255,R256,R257,v11,arbace.core5,classR258,R259,R260,R261,v11,arbace.core4,valsv11,arbace.core15,shutdown-agentsR262,S1,s8,--recordS2,s0,s8,--recordR263,v11,arbace.core4,juxtR264,v11,arbace.core8,identityv13,arbace.c.cf2g8,read-allv11,arbace.core11,read-stringR265,v11,arbace.core7,re-findR266,R267,R268,R269,v13,arbace.c.cf2g3,tsvR270,R271,R272,R273,R274,R258,v11,arbace.core7,printlnv11,arbace.core5,*out*v11,arbace.core5,*err*v11,arbace.core11,frequenciesl40,v11,arbace.core6,formatv11,arbace.core1,-V2,TTV2,FFV2,TFV2,FTv13,arbace.c.cf2g12,compile-listp8,[\\t\\n\\r]p2,\\tv13,arbace.c.cf2g14,translate-fileR275,R276,v13,arbace.c.cf2g5,judge")

var Lit_1 *jrt.String = jrt.Intern("compile-list")

var Lit_2 *jrt.String = jrt.Intern("translate-list")

var Lit_3 *jrt.String = jrt.Intern("arbace.c.cf2g$_main$clean__1650000924")

var Lit_4 *jrt.String = jrt.Intern("arbace.c.cf2g$_main$iter__1650000926__1650000930")

var Lit_5 *jrt.String = jrt.Intern("2")

var Lit_6 *jrt.String = jrt.Intern("translate")

var Lit_7 *jrt.String = jrt.Intern("main")

var Lit_8 *jrt.String = jrt.Intern("ciprog")

var Lit_9 *jrt.String = jrt.Intern("cf2g:")

var Lit_10 *jrt.String = jrt.Intern("functions,")

var Lit_11 *jrt.String = jrt.Intern("bytes")

var Lit_12 *jrt.String = jrt.Intern("arbace.c.cf2g$_main$fn__1650000961")

var Lit_13 *jrt.String = jrt.Intern("judge")

var Lit_14 *jrt.String = jrt.Intern("cf2g: translate NODES OUTDIR [PKG PATH] | translate-list LIST THREADS | compile-list HOST OUT LIST THREADS | judge ...")

var Lit_15 *jrt.String = jrt.Intern(" ")

var Lit_16 *jrt.String = jrt.Intern("refused (")

var Lit_17 *jrt.String = jrt.Intern("): ")

var Lit_18 *jrt.String = jrt.Intern("arbace.c.cf2g$_main$iter__1650000926__1650000930$fn__1650000931")

var Lit_19 *jrt.String = jrt.Intern("arbace.c.cf2g$_main$iter__1650000926__1650000930$fn__1650000931$fn__1650000932")

var Lit_20 *jrt.String = jrt.Intern("arbace.c.cf2g$_main$iter__1650000926__1650000930$fn__1650000931$fn__1650000941")

var Lit_21 *jrt.String = jrt.Intern("arbace.c.cf2g$_main$iter__1650000926__1650000930$fn__1650000931$fn__1650000932$fn__1650000933")

var Lit_22 *jrt.String = jrt.Intern("arbace.c.cf2g$_main$iter__1650000926__1650000930$fn__1650000931$fn__1650000932$fn__1650000933$fn__1650000937")

var Lit_23 *jrt.String = jrt.Intern("\t")

var Lit_24 *jrt.String = jrt.Intern("")

var Lit_25 *jrt.String = jrt.Intern(": ")

var Lit_26 *jrt.String = jrt.Intern("arbace.c.cf2g$_main$iter__1650000926__1650000930$fn__1650000931$fn__1650000941$fn__1650000945")

var Lit_27 *jrt.String = jrt.Intern("arbace.c.cf2g$bin_int$nr__1650000107")

var Lit_28 *jrt.String = jrt.Intern("div")

var Lit_29 *jrt.String = jrt.Intern("rem")

var Lit_30 *jrt.String = jrt.Intern("add")

var Lit_31 *jrt.String = jrt.Intern("shl")

var Lit_32 *jrt.String = jrt.Intern("shr")

var Lit_33 *jrt.String = jrt.Intern("sub")

var Lit_34 *jrt.String = jrt.Intern("mul")

var Lit_35 *jrt.String = jrt.Intern("and")

var Lit_36 *jrt.String = jrt.Intern("xor")

var Lit_37 *jrt.String = jrt.Intern("or")

var Lit_38 *jrt.String = jrt.Intern("no integer operator ")

var Lit_39 *jrt.String = jrt.Intern("arbace.c.cf2g$bit_width$fn__1650000021")

var Lit_40 *jrt.String = jrt.Intern("fnref")

var Lit_41 *jrt.String = jrt.Intern("arbace.c.cf2g$call_expr$iter__1650000396__1650000400")

var Lit_42 *jrt.String = jrt.Intern("arbace.c.cf2g$call_expr$iter__1650000408__1650000412")

var Lit_43 *jrt.String = jrt.Intern("cf")

var Lit_44 *jrt.String = jrt.Intern("arbace.c.cf2g$call_expr$iter__1650000396__1650000400$fn__1650000401")

var Lit_45 *jrt.String = jrt.Intern("arbace.c.cf2g$call_expr$iter__1650000396__1650000400$fn__1650000401$fn__1650000402")

var Lit_46 *jrt.String = jrt.Intern("af")

var Lit_47 *jrt.String = jrt.Intern("ai")

var Lit_48 *jrt.String = jrt.Intern("am")

var Lit_49 *jrt.String = jrt.Intern("aw")

var Lit_50 *jrt.String = jrt.Intern("no argument ")

var Lit_51 *jrt.String = jrt.Intern("arbace.c.cf2g$call_expr$iter__1650000408__1650000412$fn__1650000413")

var Lit_52 *jrt.String = jrt.Intern("arbace.c.cf2g$call_expr$iter__1650000408__1650000412$fn__1650000413$fn__1650000414")

var Lit_53 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_54 *jrt.String = jrt.Intern("eq")

var Lit_55 *jrt.String = jrt.Intern("ge")

var Lit_56 *jrt.String = jrt.Intern("gt")

var Lit_57 *jrt.String = jrt.Intern("le")

var Lit_58 *jrt.String = jrt.Intern("lt")

var Lit_59 *jrt.String = jrt.Intern("ne")

var Lit_60 *jrt.String = jrt.Intern("no comparison ")

var Lit_61 *jrt.String = jrt.Intern("CC")

var Lit_62 *jrt.String = jrt.Intern("L")

var Lit_63 *jrt.String = jrt.Intern("user.dir")

var Lit_64 *jrt.String = jrt.Intern("arbace.c.cf2g$compile_list$clean__1650000738")

var Lit_65 *jrt.String = jrt.Intern("arbace.c.cf2g$compile_list$iter__1650000740__1650000744")

var Lit_66 *jrt.String = jrt.Intern("3")

var Lit_67 *jrt.String = jrt.Intern("/nodes.tsv")

var Lit_68 *jrt.String = jrt.Intern("\n")

var Lit_69 *jrt.String = jrt.Intern("arbace.c.cf2g$compile_list$iter__1650000740__1650000744$fn__1650000745")

var Lit_70 *jrt.String = jrt.Intern("arbace.c.cf2g$compile_list$iter__1650000740__1650000744$fn__1650000745$fn__1650000746")

var Lit_71 *jrt.String = jrt.Intern("arbace.c.cf2g$compile_list$iter__1650000740__1650000744$fn__1650000745$fn__1650000762")

var Lit_72 *jrt.String = jrt.Intern("arbace.c.cf2g$compile_list$iter__1650000740__1650000744$fn__1650000745$fn__1650000746$fn__1650000747")

var Lit_73 *jrt.String = jrt.Intern("-std=")

var Lit_74 *jrt.String = jrt.Intern("arbace.c.cf2g$compile_list$iter__1650000740__1650000744$fn__1650000745$fn__1650000746$fn__1650000747$fn__1650000751")

var Lit_75 *jrt.String = jrt.Intern("long-double")

var Lit_76 *jrt.String = jrt.Intern("arbace.c.cf2g$compile_list$iter__1650000740__1650000744$fn__1650000745$fn__1650000746$fn__1650000747$fn__1650000751$fn__1650000752")

var Lit_77 *jrt.String = jrt.Intern("refused")

var Lit_78 *jrt.String = jrt.Intern("arbace.c.cf2g$compile_list$iter__1650000740__1650000744$fn__1650000745$fn__1650000746$fn__1650000747$fn__1650000751$fn__1650000754")

var Lit_79 *jrt.String = jrt.Intern("ok")

var Lit_80 *jrt.String = jrt.Intern("build-error")

var Lit_81 *jrt.String = jrt.Intern("arbace/progs/")

var Lit_82 *jrt.String = jrt.Intern("/progs/")

var Lit_83 *jrt.String = jrt.Intern("CI_AOT_NODES")

var Lit_84 *jrt.String = jrt.Intern("prog.nodes")

var Lit_85 *jrt.String = jrt.Intern("prog.go")

var Lit_86 *jrt.String = jrt.Intern("arbace.c.cf2g$compile_list$iter__1650000740__1650000744$fn__1650000745$fn__1650000762$fn__1650000766")

var Lit_87 *jrt.String = jrt.Intern("arbace.c.cf2g$compile_list$iter__1650000740__1650000744$fn__1650000745$fn__1650000762$fn__1650000766$fn__1650000767")

var Lit_88 *jrt.String = jrt.Intern("arbace.c.cf2g$compile_list$iter__1650000740__1650000744$fn__1650000745$fn__1650000762$fn__1650000766$fn__1650000769")

var Lit_89 *jrt.String = jrt.Intern("arbace.c.cf2g$decls_let$fn__1650000601")

var Lit_90 *jrt.String = jrt.Intern("arbace.c.cf2g$decls_let$fn__1650000603")

var Lit_91 *jrt.String = jrt.Intern("arbace.c.cf2g$decls_let$fn__1650000606")

var Lit_92 *jrt.String = jrt.Intern("arbace.c.cf2g$effect$drop_pure__1650000428")

var Lit_93 *jrt.String = jrt.Intern("ef")

var Lit_94 *jrt.String = jrt.Intern("fcall")

var Lit_95 *jrt.String = jrt.Intern("fs")

var Lit_96 *jrt.String = jrt.Intern("f")

var Lit_97 *jrt.String = jrt.Intern("ew")

var Lit_98 *jrt.String = jrt.Intern("wcall")

var Lit_99 *jrt.String = jrt.Intern("ecall")

var Lit_100 *jrt.String = jrt.Intern("ei")

var Lit_101 *jrt.String = jrt.Intern("st")

var Lit_102 *jrt.String = jrt.Intern("bst")

var Lit_103 *jrt.String = jrt.Intern("sx")

var Lit_104 *jrt.String = jrt.Intern("zero")

var Lit_105 *jrt.String = jrt.Intern("is")

var Lit_106 *jrt.String = jrt.Intern("i")

var Lit_107 *jrt.String = jrt.Intern("copy")

var Lit_108 *jrt.String = jrt.Intern("call")

var Lit_109 *jrt.String = jrt.Intern("seq")

var Lit_110 *jrt.String = jrt.Intern("vastart")

var Lit_111 *jrt.String = jrt.Intern("nop")

var Lit_112 *jrt.String = jrt.Intern("arbace.c.cf2g$finish_scope$targets__1650000551")

var Lit_113 *jrt.String = jrt.Intern("arbace.c.cf2g$finish_scope$fn__1650000553")

var Lit_114 *jrt.String = jrt.Intern("a jump to a label outside its function's block: ")

var Lit_115 *jrt.String = jrt.Intern("arbace.c.cf2g$finish_scope$fn__1650000565")

var Lit_116 *jrt.String = jrt.Intern("arbace.c.cf2g$finish_scope$fn__1650000553$iter__1650000554__1650000558")

var Lit_117 *jrt.String = jrt.Intern("arbace.c.cf2g$finish_scope$fn__1650000553$iter__1650000554__1650000558$fn__1650000559")

var Lit_118 *jrt.String = jrt.Intern("arbace.c.cf2g$finish_scope$fn__1650000553$iter__1650000554__1650000558$fn__1650000559$fn__1650000560")

var Lit_119 *jrt.String = jrt.Intern("fif")

var Lit_120 *jrt.String = jrt.Intern("fl")

var Lit_121 *jrt.String = jrt.Intern("fst")

var Lit_122 *jrt.String = jrt.Intern("f32")

var Lit_123 *jrt.String = jrt.Intern("fsx")

var Lit_124 *jrt.String = jrt.Intern("r32")

var Lit_125 *jrt.String = jrt.Intern("i2f")

var Lit_126 *jrt.String = jrt.Intern("fld")

var Lit_127 *jrt.String = jrt.Intern("fbin")

var Lit_128 *jrt.String = jrt.Intern("no floating operator ")

var Lit_129 *jrt.String = jrt.Intern("fneg")

var Lit_130 *jrt.String = jrt.Intern("w2f")

var Lit_131 *jrt.String = jrt.Intern("fseq")

var Lit_132 *jrt.String = jrt.Intern("no floating node ")

var Lit_133 *jrt.String = jrt.Intern("arbace.c.cf2g$has_label_QMARK_$fn__1650000103")

var Lit_134 *jrt.String = jrt.Intern("in")

var Lit_135 *jrt.String = jrt.Intern("elvis")

var Lit_136 *jrt.String = jrt.Intern("vlalloc")

var Lit_137 *jrt.String = jrt.Intern("arbace.c.cf2g$ix$sl__1650000126")

var Lit_138 *jrt.String = jrt.Intern("g")

var Lit_139 *jrt.String = jrt.Intern("cv")

var Lit_140 *jrt.String = jrt.Intern("pdiff")

var Lit_141 *jrt.String = jrt.Intern("va")

var Lit_142 *jrt.String = jrt.Intern("fa")

var Lit_143 *jrt.String = jrt.Intern("fp")

var Lit_144 *jrt.String = jrt.Intern("lnot")

var Lit_145 *jrt.String = jrt.Intern("labaddr")

var Lit_146 *jrt.String = jrt.Intern("bin")

var Lit_147 *jrt.String = jrt.Intern("if")

var Lit_148 *jrt.String = jrt.Intern("fcmp")

var Lit_149 *jrt.String = jrt.Intern("il")

var Lit_150 *jrt.String = jrt.Intern("trap")

var Lit_151 *jrt.String = jrt.Intern("w2i")

var Lit_152 *jrt.String = jrt.Intern("bnot")

var Lit_153 *jrt.String = jrt.Intern("cmp")

var Lit_154 *jrt.String = jrt.Intern("arbace.c.cf2g$ix$w__1650000206")

var Lit_155 *jrt.String = jrt.Intern("bld")

var Lit_156 *jrt.String = jrt.Intern("f2i")

var Lit_157 *jrt.String = jrt.Intern("wcmp")

var Lit_158 *jrt.String = jrt.Intern("ld")

var Lit_159 *jrt.String = jrt.Intern("wtest")

var Lit_160 *jrt.String = jrt.Intern("neg")

var Lit_161 *jrt.String = jrt.Intern("vlamark")

var Lit_162 *jrt.String = jrt.Intern("vlarestore")

var Lit_163 *jrt.String = jrt.Intern("vaarg")

var Lit_164 *jrt.String = jrt.Intern("alloca")

var Lit_165 *jrt.String = jrt.Intern("adds")

var Lit_166 *jrt.String = jrt.Intern("ftest")

var Lit_167 *jrt.String = jrt.Intern("no integer node ")

var Lit_168 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$fn__1650000795")

var Lit_169 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$fn__1650000797")

var Lit_170 *jrt.String = jrt.Intern("test/c/check-known.edn")

var Lit_171 *jrt.String = jrt.Intern("test/c/check-aot-known.edn")

var Lit_172 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$klass__1650000800")

var Lit_173 *jrt.String = jrt.Intern("test/c/check-linux-amd64.edn")

var Lit_174 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$iter__1650000809__1650000815")

var Lit_175 *jrt.String = jrt.Intern("test/c/check-aot-linux-amd64.edn")

var Lit_176 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$fn__1650000843")

var Lit_177 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$ipass_QMARK___1650000845")

var Lit_178 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$fn__1650000847")

var Lit_179 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$fn__1650000850")

var Lit_180 *jrt.String = jrt.Intern("/results.edn")

var Lit_181 *jrt.String = jrt.Intern("[\n")

var Lit_182 *jrt.String = jrt.Intern("\n]\n")

var Lit_183 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$fn__1650000859")

var Lit_184 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$fn__1650000861")

var Lit_185 *jrt.String = jrt.Intern("%-24s %5d programs: %s")

var Lit_186 *jrt.String = jrt.Intern(", ")

var Lit_187 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$fn__1650000864")

var Lit_188 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$fn__1650000869")

var Lit_189 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$fn__1650000871")

var Lit_190 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$fn__1650000874")

var Lit_191 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$fn__1650000879")

var Lit_192 *jrt.String = jrt.Intern("compiled against interpreted (results):")

var Lit_193 *jrt.String = jrt.Intern("both pass,")

var Lit_194 *jrt.String = jrt.Intern("neither,")

var Lit_195 *jrt.String = jrt.Intern("compiled only,")

var Lit_196 *jrt.String = jrt.Intern("interpreted only")

var Lit_197 *jrt.String = jrt.Intern("compiled against interpreted (runs: status and stdout):")

var Lit_198 *jrt.String = jrt.Intern("the same,")

var Lit_199 *jrt.String = jrt.Intern("differ,")

var Lit_200 *jrt.String = jrt.Intern("with no interpreted run")

var Lit_201 *jrt.String = jrt.Intern("compiled against interpreted (runs): not compared (CI_AOT_NODES=1 runs the interpreter beside, CI_INTERP names its directory)")

var Lit_202 *jrt.String = jrt.Intern("  DIFFER")

var Lit_203 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$fn__1650000892")

var Lit_204 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$fn__1650000900")

var Lit_205 *jrt.String = jrt.Intern("recorded")

var Lit_206 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$fn__1650000905")

var Lit_207 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$fn__1650000907")

var Lit_208 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$fn__1650000910")

var Lit_209 *jrt.String = jrt.Intern("ci aot judge")

var Lit_210 *jrt.String = jrt.Intern("FAIL")

var Lit_211 *jrt.String = jrt.Intern("ci aot judge:")

var Lit_212 *jrt.String = jrt.Intern("/")

var Lit_213 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$fn__1650000892$fn__1650000896")

var Lit_214 *jrt.String = jrt.Intern("interpreted only: ")

var Lit_215 *jrt.String = jrt.Intern("differs from a passing interpreted run: ")

var Lit_216 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$iter__1650000809__1650000815$fn__1650000816")

var Lit_217 *jrt.String = jrt.Intern("/run.tsv")

var Lit_218 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$iter__1650000809__1650000815$fn__1650000816$iter__1650000811__1650000817")

var Lit_219 *jrt.String = jrt.Intern("/list.tsv")

var Lit_220 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$iter__1650000809__1650000815$fn__1650000816$iter__1650000811__1650000817$fn__1650000818")

var Lit_221 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$iter__1650000809__1650000815$fn__1650000816$iter__1650000811__1650000817$fn__1650000818$fn__1650000819")

var Lit_222 *jrt.String = jrt.Intern("torture-execute-mirror/")

var Lit_223 *jrt.String = jrt.Intern("torture-execute/")

var Lit_224 *jrt.String = jrt.Intern("internal: ")

var Lit_225 *jrt.String = jrt.Intern("known ")

var Lit_226 *jrt.String = jrt.Intern(" (")

var Lit_227 *jrt.String = jrt.Intern(")")

var Lit_228 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$klass__1650000800$fn__1650000804")

var Lit_229 *jrt.String = jrt.Intern("arbace.c.cf2g$judge$klass__1650000800$fn__1650000804$fn__1650000805")

var Lit_230 *jrt.String = jrt.Intern("G")

var Lit_231 *jrt.String = jrt.Intern("b")

var Lit_232 *jrt.String = jrt.Intern("u8")

var Lit_233 *jrt.String = jrt.Intern("i64")

var Lit_234 *jrt.String = jrt.Intern("i32")

var Lit_235 *jrt.String = jrt.Intern("i16")

var Lit_236 *jrt.String = jrt.Intern("i8")

var Lit_237 *jrt.String = jrt.Intern("p")

var Lit_238 *jrt.String = jrt.Intern("u64")

var Lit_239 *jrt.String = jrt.Intern("u32")

var Lit_240 *jrt.String = jrt.Intern("u16")

var Lit_241 *jrt.String = jrt.Intern("arbace.c.cf2g$loop_stmt$cond_stmts__1650000535")

var Lit_242 *jrt.String = jrt.Intern("arbace.c.cf2g$loop_stmt$fn__1650000540")

var Lit_243 *jrt.String = jrt.Intern("nil")

var Lit_244 *jrt.String = jrt.Intern("pf")

var Lit_245 *jrt.String = jrt.Intern("pi")

var Lit_246 *jrt.String = jrt.Intern("pm")

var Lit_247 *jrt.String = jrt.Intern("pw")

var Lit_248 *jrt.String = jrt.Intern("no parameter ")

var Lit_249 *jrt.String = jrt.Intern("arbace.c.cf2g$param_stmts$fn__1650000635")

var Lit_250 *jrt.String = jrt.Intern("WT")

var Lit_251 *jrt.String = jrt.Intern("arbace.c.cf2g$reads$walk__1650000589")

var Lit_252 *jrt.String = jrt.Intern("retf")

var Lit_253 *jrt.String = jrt.Intern("reti")

var Lit_254 *jrt.String = jrt.Intern("retm")

var Lit_255 *jrt.String = jrt.Intern("retw")

var Lit_256 *jrt.String = jrt.Intern("no return ")

var Lit_257 *jrt.String = jrt.Intern("arbace.c.cf2g$seqx$iter__1650000061__1650000065")

var Lit_258 *jrt.String = jrt.Intern("arbace.c.cf2g$seqx$iter__1650000061__1650000065$fn__1650000066")

var Lit_259 *jrt.String = jrt.Intern("arbace.c.cf2g$seqx$iter__1650000061__1650000065$fn__1650000066$fn__1650000067")

var Lit_260 *jrt.String = jrt.Intern("arbace.c.cf2g$seqx$iter__1650000061__1650000065$fn__1650000066$fn__1650000079")

var Lit_261 *jrt.String = jrt.Intern("arbace.c.cf2g$seqx$iter__1650000061__1650000065$fn__1650000066$fn__1650000067$fn__1650000069")

var Lit_262 *jrt.String = jrt.Intern("a setjmp body inside another")

var Lit_263 *jrt.String = jrt.Intern("arbace.c.cf2g$sj_body$fn__1650000569")

var Lit_264 *jrt.String = jrt.Intern("arbace.c.cf2g$sj_body$fn__1650000569$iter__1650000570__1650000574")

var Lit_265 *jrt.String = jrt.Intern("arbace.c.cf2g$sj_body$fn__1650000569$iter__1650000570__1650000574$fn__1650000575")

var Lit_266 *jrt.String = jrt.Intern("arbace.c.cf2g$sj_body$fn__1650000569$iter__1650000570__1650000574$fn__1650000575$fn__1650000576")

var Lit_267 *jrt.String = jrt.Intern("arbace.c.cf2g$slot_vars$iter__1650000612__1650000616")

var Lit_268 *jrt.String = jrt.Intern("arbace.c.cf2g$slot_vars$iter__1650000622__1650000626")

var Lit_269 *jrt.String = jrt.Intern("arbace.c.cf2g$slot_vars$iter__1650000612__1650000616$fn__1650000617")

var Lit_270 *jrt.String = jrt.Intern("arbace.c.cf2g$slot_vars$iter__1650000612__1650000616$fn__1650000617$fn__1650000618")

var Lit_271 *jrt.String = jrt.Intern("arbace.c.cf2g$slot_vars$iter__1650000622__1650000626$fn__1650000627")

var Lit_272 *jrt.String = jrt.Intern("arbace.c.cf2g$slot_vars$iter__1650000622__1650000626$fn__1650000627$fn__1650000628")

var Lit_273 *jrt.String = jrt.Intern("x")

var Lit_274 *jrt.String = jrt.Intern("ret")

var Lit_275 *jrt.String = jrt.Intern("lab")

var Lit_276 *jrt.String = jrt.Intern("when")

var Lit_277 *jrt.String = jrt.Intern("jmp")

var Lit_278 *jrt.String = jrt.Intern("sjbody")

var Lit_279 *jrt.String = jrt.Intern("do")

var Lit_280 *jrt.String = jrt.Intern("igoto")

var Lit_281 *jrt.String = jrt.Intern("sj")

var Lit_282 *jrt.String = jrt.Intern("sw")

var Lit_283 *jrt.String = jrt.Intern("loop")

var Lit_284 *jrt.String = jrt.Intern("no statement ")

var Lit_285 *jrt.String = jrt.Intern("arbace.c.cf2g$switch_stmt$fn__1650000482")

var Lit_286 *jrt.String = jrt.Intern("arbace.c.cf2g$switch_stmt$fn__1650000485")

var Lit_287 *jrt.String = jrt.Intern("arbace.c.cf2g$switch_stmt$fn__1650000491")

var Lit_288 *jrt.String = jrt.Intern("arbace.c.cf2g$switch_stmt$iter__1650000496__1650000500")

var Lit_289 *jrt.String = jrt.Intern("arbace.c.cf2g$switch_stmt$iter__1650000512__1650000516")

var Lit_290 *jrt.String = jrt.Intern("arbace.c.cf2g$switch_stmt$fn__1650000528")

var Lit_291 *jrt.String = jrt.Intern("arbace.c.cf2g$switch_stmt$iter__1650000496__1650000500$fn__1650000501")

var Lit_292 *jrt.String = jrt.Intern("arbace.c.cf2g$switch_stmt$iter__1650000496__1650000500$fn__1650000501$fn__1650000502")

var Lit_293 *jrt.String = jrt.Intern("arbace.c.cf2g$switch_stmt$iter__1650000512__1650000516$fn__1650000517")

var Lit_294 *jrt.String = jrt.Intern("arbace.c.cf2g$switch_stmt$iter__1650000512__1650000516$fn__1650000517$fn__1650000518")

var Lit_295 *jrt.String = jrt.Intern("u")

var Lit_296 *jrt.String = jrt.Intern("t")

var Lit_297 *jrt.String = jrt.Intern("w")

var Lit_298 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$iter__1650000653__1650000657")

var Lit_299 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$fn__1650000663")

var Lit_300 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$fn__1650000667")

var Lit_301 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$fn__1650000674")

var Lit_302 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$fn__1650000680")

var Lit_303 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$iter__1650000686__1650000690")

var Lit_304 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$iter__1650000708__1650000712")

var Lit_305 *jrt.String = jrt.Intern("go.")

var Lit_306 *jrt.String = jrt.Intern(".")

var Lit_307 *jrt.String = jrt.Intern("A C program compiled by cf2g (arbace.c.cf2g) from its node program.\n")

var Lit_308 *jrt.String = jrt.Intern("init")

var Lit_309 *jrt.String = jrt.Intern("code")

var Lit_310 *jrt.String = jrt.Intern("D")

var Lit_311 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$iter__1650000653__1650000657$fn__1650000658")

var Lit_312 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$iter__1650000653__1650000657$fn__1650000658$fn__1650000659")

var Lit_313 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$iter__1650000686__1650000690$fn__1650000691")

var Lit_314 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$iter__1650000686__1650000690$fn__1650000691$fn__1650000692")

var Lit_315 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$iter__1650000708__1650000712$fn__1650000713")

var Lit_316 *jrt.String = jrt.Intern("arbace.c.cf2g$translate$iter__1650000708__1650000712$fn__1650000713$fn__1650000714")

var Lit_317 *jrt.String = jrt.Intern("arbace.c.cf2g$tsv$fn__1650000731")

var Lit_318 *jrt.String = jrt.Intern("arbace.c.cf2g$unconst$fn__1650000583")

var Lit_319 *jrt.String = jrt.Intern("arbace.c.cf2g$unconst$fn__1650000585")

var Lit_320 *jrt.String = jrt.Intern("WC")

var Lit_321 *jrt.String = jrt.Intern("wsh")

var Lit_322 *jrt.String = jrt.Intern("wst")

var Lit_323 *jrt.String = jrt.Intern("wld")

var Lit_324 *jrt.String = jrt.Intern("wbin")

var Lit_325 *jrt.String = jrt.Intern("no wide operator ")

var Lit_326 *jrt.String = jrt.Intern("w2w")

var Lit_327 *jrt.String = jrt.Intern("f2w")

var Lit_328 *jrt.String = jrt.Intern("wseq")

var Lit_329 *jrt.String = jrt.Intern("i2w")

var Lit_330 *jrt.String = jrt.Intern("wneg")

var Lit_331 *jrt.String = jrt.Intern("wif")

var Lit_332 *jrt.String = jrt.Intern("wnot")

var Lit_333 *jrt.String = jrt.Intern("no wide node ")

var Lit_334 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistsyn3,clsyn1,&yn3,msgkn4,linekn6,columnkn4,filekn3,tagyn6,Stringyn1,xyn16,java.lang.Stringyn4,longyn1,cyn1,tyn1,eyn1,akn7,dynamickn4,Lretyn6,prefixyn4,typeyn1,kyn2,kwyn4,agetys4,math15,Float64frombitsyn1,<yn7,bit-xoryn2,<=yn1,*ys2,ci4,Boolys2,ci1,Byn1,>yn1,-yn7,bit-andyn2,>>yn6,bit-oryn2,>=yn4,convyn1,+yn7,bit-notyn2,!=yn2,==yn2,<<yn5,partsyn1,syn5,stmtsyn4,thenyn4,elsekn8,declaredyn2,opyn1,byn3,f32yn4,bitsyn4,textyn4,codeyn1,_yn3,unsyn5,casesyn4,dfltyn4,bodyyn4,stepyn3,do?yn11,bit-and-notyn1,%yn1,/yn5,formsyn4,varsyn2,niyn2,nfyn1,qyn6,paramsyn2,idyn5,frameyn8,variadicyn6,retf32yn1,nyn4,cmdsyn3,pkgyn4,pathyn8,host-diryn3,outyn4,listyn7,threadsyn4,workyn4,reffyn4,divfyn4,divayn6,interpyn4,moreyn4,verbyn4,argsv11,arbace.core5,in-nsMyn13,arbace.c.cf2gm2,R0,s1271,cf2g, C's AOT (doc/C23-SURVEY.md §7, CS13 (a), CS17 (a); \"As built: C6 (write-ahead)\"): a C program's\n  node program (arbace.c.build's output, the lowered C forms ci's back end runs, CS120) translated into Go\n  forms over go/arbace/ci and go/arbace/crt, printed by repr/go and built by Go's compiler. Each function\n  of the program with code is a Go function of package-level name fID, the Native of its Func (ci.Enter's\n  frame in the C stack, its slots Go locals); its statements and expressions flattened into one block of\n  assignments, conditional gotos and labels, so that C's gotos into blocks, loops and switches (Duff's\n  device) and switch's cases are Go's gotos; expressions in temporaries wherever an operand's evaluation\n  has an effect, in ci's order (the builder's: gcc -O0's); setjmp's function body a closure under\n  ci.SjRun. The program's data (fn, native, static, data, at, alias, fnalias, start) stays node program\n  text, loaded by ci's Loader as on the interpreted path, so both lay out memory alike. A node or a jump\n  the translator cannot express is refused, with its reason (class aot-*).\n\n  translate gives the Go forms of one program's package; -main: `translate NODES OUTDIR [PKG]` and\n  `translate-list LIST THREADS` (bin/ci check --aot's).m2,R0,s1271,cf2g, C's AOT (doc/C23-SURVEY.md §7, CS13 (a), CS17 (a); \"As built: C6 (write-ahead)\"): a C program's\n  node program (arbace.c.build's output, the lowered C forms ci's back end runs, CS120) translated into Go\n  forms over go/arbace/ci and go/arbace/crt, printed by repr/go and built by Go's compiler. Each function\n  of the program with code is a Go function of package-level name fID, the Native of its Func (ci.Enter's\n  frame in the C stack, its slots Go locals); its statements and expressions flattened into one block of\n  assignments, conditional gotos and labels, so that C's gotos into blocks, loops and switches (Duff's\n  device) and switch's cases are Go's gotos; expressions in temporaries wherever an operand's evaluation\n  has an effect, in ci's order (the builder's: gcc -O0's); setjmp's function body a closure under\n  ci.SjRun. The program's data (fn, native, static, data, at, alias, fnalias, start) stays node program\n  text, loaded by ci's Loader as on the interpreted path, so both lay out memory alike. A node or a jump\n  the translator cannot express is refused, with its reason (class aot-*).\n\n  translate gives the Go forms of one program's package; -main: `translate NODES OUTDIR [PKG]` and\n  `translate-list LIST THREADS` (bin/ci check --aot's).R1,v11,arbace.core20,*warn-on-reflection*v13,arbace.c.cf2g6,refusem10,R2,TR3,L1,V3,R4,R5,R6,R7,i22,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g10,read-nodesm10,R3,L1,V1,Myn4,textm2,R10,R11,R0,s72,A node program's commands from its text (arbace.c.build/program-text's).R7,i28,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g2,nmm12,R2,TR3,L1,MV1,R12,m2,R10,R13,R0,s42,A word of a node: a string or a bare word.R7,i35,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g3,lngm12,R2,TR3,L1,MV1,R12,m2,R10,R14,R0,s66,An integer of a node: wrapped to 64 bits (the loader's ParseUint).R7,i36,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g4,headm10,R2,TR3,L1,V1,R15,R7,i40,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g9,nil-node?m10,R2,TR3,L1,V1,R12,R7,i41,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g9,bit-widthm12,R2,TR3,L1,V1,Myn1,tm2,R10,R11,R0,s88,[n signed] of a _BitInt type sN/uN (and gcc's wide bit-field types), nil for the others.R7,i46,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g9,unsigned?m10,R2,TR3,L1,V1,R16,R7,i53,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g5,widthm10,R2,TR3,L1,MV1,R16,m2,R10,R14,R7,i56,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g4,normm12,R2,TR3,L1,V2,R16,R17,R0,s52,e (an int64 expression) normalized to t, as ci.Norm.R7,i61,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g11,needs-norm?m10,R2,TR3,L1,V1,R16,R7,i80,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g2,uam10,R2,TR3,L1,V1,R18,R7,i83,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g9,load-exprm10,R2,TR3,L1,V2,R16,R18,R7,i85,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g10,store-stmtm10,R2,TR3,L1,V3,R16,R18,R12,R7,i96,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g5,*pkg*m8,R19,TR7,i109,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g4,*fn*m8,R19,TR7,i110,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g7,*scope*m8,R19,TR7,i111,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g7,*jumps*m8,R19,TR7,i112,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g6,*lret*R20,m8,R19,TR7,i113,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g7,*in-sj*m8,R19,TR7,i114,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g6,fresh!m10,R2,TR3,L1,V2,R21,R22,R7,i116,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g4,tmp!m10,R2,TR3,L1,V1,R23,R7,i122,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g6,label!m10,R2,TR3,L1,V0,R7,i123,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g5,goto!m10,R2,TR3,L1,V1,R24,R7,i124,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g9,deflabel!m10,R2,TR3,L1,V1,R24,R7,i125,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g10,code-labelm10,R2,TR3,L1,V1,R15,R7,i126,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g6,wtype!m12,R2,TR3,L1,V1,R12,R0,s66,The package variable holding the WType of a node's \"sN\"/\"uN\" word.R7,i128,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g5,slot?m10,R2,TR3,L1,V1,R17,R7,i135,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g10,pure-headsS20,R25,R26,R27,R28,R29,R30,R31,R32,R33,R34,R35,R36,R37,R38,R39,R40,R41,R42,R43,R44,m8,R2,TR7,i137,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g7,stable?m12,R2,TR3,L1,V1,R17,R0,s78,Whether e's value cannot change before it is used (no slot, no load, no call).R7,i140,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g5,pure?m12,R2,TR3,L1,V1,R17,R0,s85,Whether evaluating e has no effect but a load's possible fault (no call that writes).R7,i148,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g4,seqxm12,R2,TR3,L1,V1,R45,R0,s169,Children compiled as [kind [stmts expr]] in evaluation order: [stmts exprs], an expression bound to a\n  temporary when a later child has statements and it is not stable.R7,i157,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g4,bindm12,R2,TR3,L1,V2,R23,V2,R46,R17,R0,s56,[stmts temp] : e's value in a fresh temporary of kind k.R7,i172,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g3,cndm12,R2,TR3,L1,V1,R17,R0,s32,An int64 condition as a Go bool.R7,i177,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g10,has-label?m10,R2,TR3,L1,V1,R47,R7,i180,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g6,branchm12,R2,TR3,L1,V3,R15,R48,R49,R0,s85,if (c) then else, c a Go bool: a Go if when neither branch holds a label, else gotos.R7,i182,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g2,ixm8,R50,TR7,i200,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g2,fxm8,R50,TR7,i200,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g2,wxm8,R50,TR7,i200,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g4,stmtm8,R50,TR7,i200,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g6,effectm8,R50,TR7,i200,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g9,call-exprm8,R50,TR7,i200,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g7,bin-intm10,R2,TR3,L1,V4,R51,R16,R18,R52,R7,i202,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g6,cmp-opm10,R2,TR3,L1,V1,R51,R7,i226,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g6,froundm12,R2,TR3,L1,V2,R53,R17,R0,s82,float64 e, explicitly converted (no fusion, Go's spec), rounded to float when f32.R7,i229,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g6,fconstm10,R2,TR3,L1,V1,R54,R7,i232,R8,i1,R9,s16,arbace/c/cf2g.aem12,R2,TR3,L1,V1,R15,R0,s36,An integer node: [stmts int64-expr].R7,i235,R8,i1,R9,s16,arbace/c/cf2g.aem12,R2,TR3,L1,V1,R15,R0,s38,A floating node: [stmts float64-expr].R7,i316,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g7,wconst!m10,R2,TR3,L1,V2,R16,R55,R7,i349,R8,i1,R9,s16,arbace/c/cf2g.aem12,R2,TR3,L1,V1,R15,R0,s35,A wide node: [stmts crt.Wide-expr].R7,i354,R8,i1,R9,s16,arbace/c/cf2g.aem12,R2,TR3,L1,V1,R15,R0,s102,(KIND CALLEE [args] SRET SOFF): [stmts call-expr], the callee first, then the arguments right to left.R7,i385,R8,i1,R9,s16,arbace/c/cf2g.aem12,R2,TR3,L1,V1,R15,R0,s31,An effect node: its statements.R7,i418,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g8,ret-jumpm10,R2,TR3,L1,V0,R7,i449,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g4,jumpm10,R2,TR3,L1,V1,R56,R7,i451,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g8,ret-stmtm10,R2,TR3,L1,V1,R15,R7,i459,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g11,switch-stmtm10,R2,TR3,L1,V1,V6,R57,R17,R58,R59,R60,R61,R7,i474,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g9,loop-stmtm10,R2,TR3,L1,V1,V5,R57,R15,R62,R61,R63,R7,i496,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g7,sj-bodym8,R50,TR7,i511,R8,i1,R9,s16,arbace/c/cf2g.aem12,R2,TR3,L1,V1,R15,R0,s33,A statement node: its statements.R7,i513,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g12,finish-scopem12,R2,TR3,L1,V1,R47,R0,s133,The scope's statements with igoto's dispatches made, the labels no goto names dropped; a goto to a\n  label outside the scope refused.R7,i540,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g9,new-scopem10,R2,TR3,L1,V0,R7,i559,R8,i1,R9,s16,arbace/c/cf2g.aem12,R2,TR3,L1,V1,R61,R0,s95,A body that calls setjmp: a closure under ci.SjRun, entered again at a setjmp statement's code.R7,i561,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g11,arith-headsS13,R28,R30,R64,R65,R34,R35,R36,R66,R37,R39,R40,R41,R44,m8,R2,TR7,i580,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g7,unconstm12,R2,TR3,L1,V1,R12,R0,s171,An operation of constants alone made one of values (its first int64 constant as ci.K's): Go's exact\n  constant arithmetic would refuse what overflows; the machine's wraps.R7,i582,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g11,unconst-allm10,R2,TR3,L1,V1,R67,R7,i603,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g5,readsm12,R2,TR3,L1,V1,R67,R0,s66,The symbols the forms read (a set!'s target is written, not read).R7,i605,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g9,decls-letm12,R2,TR3,L1,V2,R68,R61,R0,s155,The function's variables declared around the body: those it reads (Go refuses a variable declared and\n  not used), the assignments of the others made to _.R7,i617,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g9,slot-varsm10,R2,TR3,L1,V2,R69,R70,R7,i635,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g9,param-litm10,R2,TR3,L1,V1,R71,R7,i639,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g11,param-stmtsm10,R2,TR3,L1,V1,R72,R7,i647,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g7,code-fnm12,R2,TR3,L1,V1,V9,R57,R73,R69,R70,R74,R75,R76,R72,R61,R0,s97,(code ID NI NF FRAME VARIADIC RETF32 PARAMS BODY): the Go function fID and its Code variable CID.R7,i658,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g7,init-fnm12,R2,TR3,L1,V2,R77,R15,R0,s90,(init STMT) or (init NI NF STMT): the Go function inN, a ci.GoStmt of the program's Inits.R7,i685,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g7,text-ofm10,R2,TR3,L1,V1,R78,R7,i702,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g9,translatem10,R3,L1,V3,R78,R79,R80,R0,s192,The Go forms of the node program cmds as the package pkg (path PATH, a main package when pkg is main):\n  [forms {:functions n}]. Throws ex-info with :cf2g/refused for a node it cannot express.R7,i706,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g7,go-textm10,R3,L1,MV1,R67,m2,R10,R13,R0,s71,The Go text of translate's forms (repr/go's printer, its gofmt layout).R7,i766,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g14,translate-filem10,R3,L1,V4,Myn10,nodes-pathm2,R10,R11,Myn7,out-dirm2,R10,R11,R79,R80,R0,s171,The node program at nodes-path translated into out-dir/prog.go as package pkg (path path): {:status :ok\n  :functions n :bytes b} or {:status :refused :class c :message m}.R7,i772,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g3,tsvm10,R2,TR3,L1,V1,Myn1,fm2,R10,R11,R7,i788,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g12,compile-listm12,R2,TR3,L1,V1,V4,R81,R82,R83,R84,R0,s409,compile-list HOST-DIR OUT LIST THREADS: each line of LIST (ID BASE STD ARGS READNAME PKG, tab-separated: a\n  program of one file) read, checked, linked with musl, built into its node program and translated into the\n  package OUT/progs/PKG (path arbace/progs/PKG); OUT/nodes.tsv lists ID STATUS [CLASS MESSAGE FLAGS], as\n  arbace.c.run's nodes-list does (a refusal of cf2g's the status refused with its class).R7,i792,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g8,read-allm10,R2,TR3,L1,V1,Myn1,fm2,R10,R11,R7,i848,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g5,judgem12,R2,TR3,L1,V1,V7,R85,R86,R87,R88,R89,R5,R90,R0,s381,judge WORK REF DIVERGENCES DIVERGENCES-AOT INTERP [--record] CORPUS...: each program's compiled run\n  against gcc's (arbace.c.run/result's rule), every non-pass in a class of the two files (the\n  interpreter's, then AOT's own); and against the interpreted run (INTERP: a directory of the\n  interpreted check's CORPUS/run.tsv), diffcheck's kind: the same status and standard output.R7,i851,R8,i1,R9,s16,arbace/c/cf2g.aev13,arbace.c.cf2g5,-mainm10,R3,L1,V3,R91,R5,R92,R0,s280,translate NODES OUTDIR [PKG PATH]: one node program into OUTDIR/prog.go (default package main);\n  translate-list LIST THREADS: each line ID NODES OUTDIR PKG PATH (tab-separated) translated, a line\n  ID STATUS CLASS MESSAGE FUNCTIONS BYTES a program printed on the standard output.R7,i937,R8,i1,R9,s16,arbace/c/cf2g.ae")

var Lit_335 *jrt.String = jrt.Intern("arbace.c.cf2g$eval1650000004$loading__1927001464__auto____1650000005")

var Lit_336 *jrt.String = jrt.Intern("arbace.c.cf2g$eval1650000008$fn__1650000009")

var Lit_337 *jrt.String = jrt.Intern("arbace.c.cf2g$refuse")

var Lit_338 *jrt.String = jrt.Intern("arbace.c.cf2g$read_nodes")

var Lit_339 *jrt.String = jrt.Intern("arbace.c.cf2g$nm")

var Lit_340 *jrt.String = jrt.Intern("arbace.c.cf2g$lng")

var Lit_341 *jrt.String = jrt.Intern("arbace.c.cf2g$head")

var Lit_342 *jrt.String = jrt.Intern("arbace.c.cf2g$nil_node_QMARK_")

var Lit_343 *jrt.String = jrt.Intern("arbace.c.cf2g$bit_width")

var Lit_344 *jrt.String = jrt.Intern("arbace.c.cf2g$unsigned_QMARK_")

var Lit_345 *jrt.String = jrt.Intern("arbace.c.cf2g$width")

var Lit_346 *jrt.String = jrt.Intern("arbace.c.cf2g$norm")

var Lit_347 *jrt.String = jrt.Intern("arbace.c.cf2g$needs_norm_QMARK_")

var Lit_348 *jrt.String = jrt.Intern("arbace.c.cf2g$ua")

var Lit_349 *jrt.String = jrt.Intern("arbace.c.cf2g$load_expr")

var Lit_350 *jrt.String = jrt.Intern("arbace.c.cf2g$store_stmt")

var Lit_351 *jrt.String = jrt.Intern("arbace.c.cf2g$fresh_BANG_")

var Lit_352 *jrt.String = jrt.Intern("arbace.c.cf2g$tmp_BANG_")

var Lit_353 *jrt.String = jrt.Intern("arbace.c.cf2g$label_BANG_")

var Lit_354 *jrt.String = jrt.Intern("arbace.c.cf2g$goto_BANG_")

var Lit_355 *jrt.String = jrt.Intern("arbace.c.cf2g$deflabel_BANG_")

var Lit_356 *jrt.String = jrt.Intern("arbace.c.cf2g$code_label")

var Lit_357 *jrt.String = jrt.Intern("arbace.c.cf2g$wtype_BANG_")

var Lit_358 *jrt.String = jrt.Intern("arbace.c.cf2g$slot_QMARK_")

var Lit_359 *jrt.String = jrt.Intern("arbace.c.cf2g$stable_QMARK_")

var Lit_360 *jrt.String = jrt.Intern("arbace.c.cf2g$pure_QMARK_")

var Lit_361 *jrt.String = jrt.Intern("arbace.c.cf2g$seqx")

var Lit_362 *jrt.String = jrt.Intern("arbace.c.cf2g$bind")

var Lit_363 *jrt.String = jrt.Intern("arbace.c.cf2g$cnd")

var Lit_364 *jrt.String = jrt.Intern("arbace.c.cf2g$has_label_QMARK_")

var Lit_365 *jrt.String = jrt.Intern("arbace.c.cf2g$branch")

var Lit_366 *jrt.String = jrt.Intern("arbace.c.cf2g$bin_int")

var Lit_367 *jrt.String = jrt.Intern("arbace.c.cf2g$cmp_op")

var Lit_368 *jrt.String = jrt.Intern("arbace.c.cf2g$fround")

var Lit_369 *jrt.String = jrt.Intern("arbace.c.cf2g$fconst")

var Lit_370 *jrt.String = jrt.Intern("arbace.c.cf2g$ix")

var Lit_371 *jrt.String = jrt.Intern("arbace.c.cf2g$fx")

var Lit_372 *jrt.String = jrt.Intern("arbace.c.cf2g$wconst_BANG_")

var Lit_373 *jrt.String = jrt.Intern("arbace.c.cf2g$wx")

var Lit_374 *jrt.String = jrt.Intern("arbace.c.cf2g$call_expr")

var Lit_375 *jrt.String = jrt.Intern("arbace.c.cf2g$effect")

var Lit_376 *jrt.String = jrt.Intern("arbace.c.cf2g$ret_jump")

var Lit_377 *jrt.String = jrt.Intern("arbace.c.cf2g$jump")

var Lit_378 *jrt.String = jrt.Intern("arbace.c.cf2g$ret_stmt")

var Lit_379 *jrt.String = jrt.Intern("arbace.c.cf2g$switch_stmt")

var Lit_380 *jrt.String = jrt.Intern("arbace.c.cf2g$loop_stmt")

var Lit_381 *jrt.String = jrt.Intern("arbace.c.cf2g$stmt")

var Lit_382 *jrt.String = jrt.Intern("arbace.c.cf2g$finish_scope")

var Lit_383 *jrt.String = jrt.Intern("arbace.c.cf2g$new_scope")

var Lit_384 *jrt.String = jrt.Intern("arbace.c.cf2g$sj_body")

var Lit_385 *jrt.String = jrt.Intern("arbace.c.cf2g$unconst")

var Lit_386 *jrt.String = jrt.Intern("arbace.c.cf2g$unconst_all")

var Lit_387 *jrt.String = jrt.Intern("arbace.c.cf2g$reads")

var Lit_388 *jrt.String = jrt.Intern("arbace.c.cf2g$decls_let")

var Lit_389 *jrt.String = jrt.Intern("arbace.c.cf2g$slot_vars")

var Lit_390 *jrt.String = jrt.Intern("arbace.c.cf2g$param_lit")

var Lit_391 *jrt.String = jrt.Intern("arbace.c.cf2g$param_stmts")

var Lit_392 *jrt.String = jrt.Intern("arbace.c.cf2g$code_fn")

var Lit_393 *jrt.String = jrt.Intern("arbace.c.cf2g$init_fn")

var Lit_394 *jrt.String = jrt.Intern("arbace.c.cf2g$text_of")

var Lit_395 *jrt.String = jrt.Intern("arbace.c.cf2g$translate")

var Lit_396 *jrt.String = jrt.Intern("arbace.c.cf2g$go_text")

var Lit_397 *jrt.String = jrt.Intern("arbace.c.cf2g$translate_file")

var Lit_398 *jrt.String = jrt.Intern("arbace.c.cf2g$tsv")

var Lit_399 *jrt.String = jrt.Intern("arbace.c.cf2g$compile_list")

var Lit_400 *jrt.String = jrt.Intern("arbace.c.cf2g$read_all")

var Lit_401 *jrt.String = jrt.Intern("arbace.c.cf2g$judge")

var Lit_402 *jrt.String = jrt.Intern("arbace.c.cf2g$_main")
