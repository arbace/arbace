//line aot_arbace_c_cf2g__init.ae:1
package aot_arbace_c_cf2g

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_c_cf2g__init_A_Unit0__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_c_cf2g__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_c_cf2g__init_A_const_1) }
//line :1:1
func A_arbace_c_cf2g__init_A_Unit1__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_c_cf2g__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_2)) }
//line :1:1
func A_arbace_c_cf2g__init_A_Unit2__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_c_cf2g_eval1650000004_loading__1927001464__auto____1650000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_c_cf2g_eval1650000004_loading__1927001464__auto____1650000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_335, false, nil); A_arbace_c_cf2g_eval1650000004_loading__1927001464__auto____1650000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_c_cf2g__init_A_Unit3__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_c_cf2g__init_A_const_1)).Equals_O__Z(A_arbace_c_cf2g__init_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_c_cf2g_eval1650000008_fn__1650000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_c_cf2g_eval1650000008_fn__1650000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_336, false, nil); A_arbace_c_cf2g_eval1650000008_fn__1650000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }



func A_arbace_c_cf2g__init_A_Load__O() any { A_arbace_c_cf2g__init_A_Init(); jrt.StartCheck(); A_arbace_c_cf2g__init_A_Unit0__O(); A_arbace_c_cf2g__init_A_Unit1__O(); A_arbace_c_cf2g__init_A_Unit2__O(); A_arbace_c_cf2g__init_A_Unit3__O(); A_arbace_c_cf2g__init_A_Unit4__O(); A_arbace_c_cf2g__init_A_Unit5__O(); A_arbace_c_cf2g__init_A_Unit6__O(); A_arbace_c_cf2g__init_A_Unit7__O(); A_arbace_c_cf2g__init_A_Unit8__O(); A_arbace_c_cf2g__init_A_Unit9__O(); A_arbace_c_cf2g__init_A_Unit10__O(); A_arbace_c_cf2g__init_A_Unit11__O(); A_arbace_c_cf2g__init_A_Unit12__O(); A_arbace_c_cf2g__init_A_Unit13__O(); A_arbace_c_cf2g__init_A_Unit14__O(); A_arbace_c_cf2g__init_A_Unit15__O(); A_arbace_c_cf2g__init_A_Unit16__O(); A_arbace_c_cf2g__init_A_Unit17__O(); A_arbace_c_cf2g__init_A_Unit18__O(); A_arbace_c_cf2g__init_A_Unit19__O(); A_arbace_c_cf2g__init_A_Unit20__O(); A_arbace_c_cf2g__init_A_Unit21__O(); A_arbace_c_cf2g__init_A_Unit22__O(); A_arbace_c_cf2g__init_A_Unit23__O(); A_arbace_c_cf2g__init_A_Unit24__O(); A_arbace_c_cf2g__init_A_Unit25__O(); A_arbace_c_cf2g__init_A_Unit26__O(); A_arbace_c_cf2g__init_A_Unit27__O(); A_arbace_c_cf2g__init_A_Unit28__O(); A_arbace_c_cf2g__init_A_Unit29__O(); A_arbace_c_cf2g__init_A_Unit30__O(); A_arbace_c_cf2g__init_A_Unit31__O(); A_arbace_c_cf2g__init_A_Unit32__O(); A_arbace_c_cf2g__init_A_Unit33__O(); A_arbace_c_cf2g__init_A_Unit34__O(); A_arbace_c_cf2g__init_A_Unit35__O(); A_arbace_c_cf2g__init_A_Unit36__O(); A_arbace_c_cf2g__init_A_Unit37__O(); A_arbace_c_cf2g__init_A_Unit38__O(); A_arbace_c_cf2g__init_A_Unit39__O(); A_arbace_c_cf2g__init_A_Unit40__O(); A_arbace_c_cf2g__init_A_Unit41__O(); A_arbace_c_cf2g__init_A_Unit42__O(); A_arbace_c_cf2g__init_A_Unit43__O(); A_arbace_c_cf2g__init_A_Unit44__O(); A_arbace_c_cf2g__init_A_Unit45__O(); A_arbace_c_cf2g__init_A_Unit46__O(); A_arbace_c_cf2g__init_A_Unit47__O(); A_arbace_c_cf2g__init_A_Unit48__O(); A_arbace_c_cf2g__init_A_Unit49__O(); A_arbace_c_cf2g__init_A_Unit50__O(); A_arbace_c_cf2g__init_A_Unit51__O(); A_arbace_c_cf2g__init_A_Unit52__O(); A_arbace_c_cf2g__init_A_Unit53__O(); A_arbace_c_cf2g__init_A_Unit54__O(); A_arbace_c_cf2g__init_A_Unit55__O(); A_arbace_c_cf2g__init_A_Unit56__O(); A_arbace_c_cf2g__init_A_Unit57__O(); A_arbace_c_cf2g__init_A_Unit58__O(); A_arbace_c_cf2g__init_A_Unit59__O(); A_arbace_c_cf2g__init_A_Unit60__O(); A_arbace_c_cf2g__init_A_Unit61__O(); A_arbace_c_cf2g__init_A_Unit62__O(); A_arbace_c_cf2g__init_A_Unit63__O(); A_arbace_c_cf2g__init_A_Unit64__O(); A_arbace_c_cf2g__init_A_Unit65__O(); A_arbace_c_cf2g__init_A_Unit66__O(); A_arbace_c_cf2g__init_A_Unit67__O(); A_arbace_c_cf2g__init_A_Unit68__O(); A_arbace_c_cf2g__init_A_Unit69__O(); A_arbace_c_cf2g__init_A_Unit70__O(); A_arbace_c_cf2g__init_A_Unit71__O(); A_arbace_c_cf2g__init_A_Unit72__O(); A_arbace_c_cf2g__init_A_Unit73__O(); A_arbace_c_cf2g__init_A_Unit74__O(); A_arbace_c_cf2g__init_A_Unit75__O(); A_arbace_c_cf2g__init_A_Unit76__O(); A_arbace_c_cf2g__init_A_Unit77__O(); A_arbace_c_cf2g__init_A_Unit78__O(); A_arbace_c_cf2g__init_A_Unit79__O(); A_arbace_c_cf2g__init_A_Unit80__O(); A_arbace_c_cf2g__init_A_Unit81__O(); A_arbace_c_cf2g__init_A_Unit82__O(); A_arbace_c_cf2g__init_A_Unit83__O(); A_arbace_c_cf2g__init_A_Unit84__O(); A_arbace_c_cf2g__init_A_Unit85__O(); return nil }














func A_arbace_c_cf2g__init_A_Unit4__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(20, 1); return A_arbace_c_cf2g__init_A_const_4.Set_O__O(jrt.Boolean_TRUE.Ref()) }

func A_arbace_c_cf2g__init_A_Unit5__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(22, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_5; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__6 any = A_arbace_c_cf2g_refuse_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_c_cf2g_refuse_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_337, true, nil); A_arbace_c_cf2g_refuse_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__6, tmp3, nil, 1); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_5; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_6)); return A_arbace_c_cf2g__init_A_const_5 }





func A_arbace_c_cf2g__init_A_Unit6__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(28, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_7; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_c_cf2g_read_nodes_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_c_cf2g_read_nodes_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_338, false, nil); A_arbace_c_cf2g_read_nodes_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_7; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_8)); return A_arbace_c_cf2g__init_A_const_7 }






func A_arbace_c_cf2g__init_A_Unit7__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(35, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_9; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_c_cf2g_nm_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_c_cf2g_nm_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_339, false, nil); A_arbace_c_cf2g_nm_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_9; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_10)); return A_arbace_c_cf2g__init_A_const_9 }
func A_arbace_c_cf2g__init_A_Unit8__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(36, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_11; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_c_cf2g_lng_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_c_cf2g_lng_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_340, false, nil); A_arbace_c_cf2g_lng_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_12)); return A_arbace_c_cf2g__init_A_const_11 }



func A_arbace_c_cf2g__init_A_Unit9__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(40, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_13; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_c_cf2g_head_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_c_cf2g_head_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_341, false, nil); A_arbace_c_cf2g_head_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_14)); return A_arbace_c_cf2g__init_A_const_13 }
func A_arbace_c_cf2g__init_A_Unit10__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(41, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_15; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_c_cf2g_nil_node_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_c_cf2g_nil_node_QMARK__A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_342, false, nil); A_arbace_c_cf2g_nil_node_QMARK__A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_16)); return A_arbace_c_cf2g__init_A_const_15 }




func A_arbace_c_cf2g__init_A_Unit11__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(46, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_17; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_c_cf2g_bit_width_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_c_cf2g_bit_width_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_343, false, nil); A_arbace_c_cf2g_bit_width_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_18)); return A_arbace_c_cf2g__init_A_const_17 }






func A_arbace_c_cf2g__init_A_Unit12__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(53, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_19; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_c_cf2g_unsigned_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_c_cf2g_unsigned_QMARK__A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_344, false, nil); A_arbace_c_cf2g_unsigned_QMARK__A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_20)); return A_arbace_c_cf2g__init_A_const_19 }


func A_arbace_c_cf2g__init_A_Unit13__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(56, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_21; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_c_cf2g_width_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_c_cf2g_width_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_345, false, nil); A_arbace_c_cf2g_width_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_22)); return A_arbace_c_cf2g__init_A_const_21 }




func A_arbace_c_cf2g__init_A_Unit14__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(61, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_23; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_c_cf2g_norm_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_c_cf2g_norm_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_346, false, nil); A_arbace_c_cf2g_norm_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_24)); return A_arbace_c_cf2g__init_A_const_23 }


















func A_arbace_c_cf2g__init_A_Unit15__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(80, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_25; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_c_cf2g_needs_norm_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_c_cf2g_needs_norm_QMARK__A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_347, false, nil); A_arbace_c_cf2g_needs_norm_QMARK__A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_26)); return A_arbace_c_cf2g__init_A_const_25 }


func A_arbace_c_cf2g__init_A_Unit16__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(83, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_27; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_c_cf2g_ua_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_c_cf2g_ua_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_348, false, nil); A_arbace_c_cf2g_ua_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_28)); return A_arbace_c_cf2g__init_A_const_27 }

func A_arbace_c_cf2g__init_A_Unit17__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(85, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_29; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_c_cf2g_load_expr_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_c_cf2g_load_expr_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_349, false, nil); A_arbace_c_cf2g_load_expr_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_30)); return A_arbace_c_cf2g__init_A_const_29 }










func A_arbace_c_cf2g__init_A_Unit18__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(96, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_31; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_c_cf2g_store_stmt_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_c_cf2g_store_stmt_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_350, false, nil); A_arbace_c_cf2g_store_stmt_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_31; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_32)); return A_arbace_c_cf2g__init_A_const_31 }












func A_arbace_c_cf2g__init_A_Unit19__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(109, 1); A_arbace_c_cf2g__init_A_const_33.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_33; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_34)); return A_arbace_c_cf2g__init_A_const_33.SetDynamic_Z__Var(true).Ref() }
func A_arbace_c_cf2g__init_A_Unit20__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(110, 1); A_arbace_c_cf2g__init_A_const_35.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_35; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_36)); return A_arbace_c_cf2g__init_A_const_35.SetDynamic_Z__Var(true).Ref() }
func A_arbace_c_cf2g__init_A_Unit21__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(111, 1); A_arbace_c_cf2g__init_A_const_37.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_37; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_38)); return A_arbace_c_cf2g__init_A_const_37.SetDynamic_Z__Var(true).Ref() }
func A_arbace_c_cf2g__init_A_Unit22__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(112, 1); A_arbace_c_cf2g__init_A_const_39.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_39; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_40)); return A_arbace_c_cf2g__init_A_const_39.SetDynamic_Z__Var(true).Ref() }
func A_arbace_c_cf2g__init_A_Unit23__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(113, 1); A_arbace_c_cf2g__init_A_const_41.BindRoot_O__V(A_arbace_c_cf2g__init_A_const_42); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_41; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_43)); return A_arbace_c_cf2g__init_A_const_41.SetDynamic_Z__Var(true).Ref() }
func A_arbace_c_cf2g__init_A_Unit24__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(114, 1); A_arbace_c_cf2g__init_A_const_44.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_44; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_45)); return A_arbace_c_cf2g__init_A_const_44.SetDynamic_Z__Var(true).Ref() }

func A_arbace_c_cf2g__init_A_Unit25__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(116, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_46; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_c_cf2g_fresh_BANG__A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_c_cf2g_fresh_BANG__A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_351, false, nil); A_arbace_c_cf2g_fresh_BANG__A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_47)); return A_arbace_c_cf2g__init_A_const_46 }





func A_arbace_c_cf2g__init_A_Unit26__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(122, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_48; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_c_cf2g_tmp_BANG__A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_c_cf2g_tmp_BANG__A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_352, false, nil); A_arbace_c_cf2g_tmp_BANG__A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_49)); return A_arbace_c_cf2g__init_A_const_48 }
func A_arbace_c_cf2g__init_A_Unit27__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(123, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_50; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_c_cf2g_label_BANG__A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_c_cf2g_label_BANG__A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_353, false, nil); A_arbace_c_cf2g_label_BANG__A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_51)); return A_arbace_c_cf2g__init_A_const_50 }
func A_arbace_c_cf2g__init_A_Unit28__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_52; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_c_cf2g_goto_BANG__A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_c_cf2g_goto_BANG__A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_354, false, nil); A_arbace_c_cf2g_goto_BANG__A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_53)); return A_arbace_c_cf2g__init_A_const_52 }
func A_arbace_c_cf2g__init_A_Unit29__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(125, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_54; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_c_cf2g_deflabel_BANG__A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_c_cf2g_deflabel_BANG__A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_355, false, nil); A_arbace_c_cf2g_deflabel_BANG__A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_55)); return A_arbace_c_cf2g__init_A_const_54 }
func A_arbace_c_cf2g__init_A_Unit30__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(126, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_56; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_c_cf2g_code_label_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_c_cf2g_code_label_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_356, false, nil); A_arbace_c_cf2g_code_label_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_57)); return A_arbace_c_cf2g__init_A_const_56 }

func A_arbace_c_cf2g__init_A_Unit31__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(128, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_58; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_c_cf2g_wtype_BANG__A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_c_cf2g_wtype_BANG__A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_357, false, nil); A_arbace_c_cf2g_wtype_BANG__A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_59)); return A_arbace_c_cf2g__init_A_const_58 }






func A_arbace_c_cf2g__init_A_Unit32__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(135, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_60; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_c_cf2g_slot_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_c_cf2g_slot_QMARK__A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_358, false, nil); A_arbace_c_cf2g_slot_QMARK__A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_61)); return A_arbace_c_cf2g__init_A_const_60 }

func A_arbace_c_cf2g__init_A_Unit33__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(137, 1); A_arbace_c_cf2g__init_A_const_62.BindRoot_O__V(A_arbace_c_cf2g__init_A_const_63); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_62; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_64)); return A_arbace_c_cf2g__init_A_const_62 }


func A_arbace_c_cf2g__init_A_Unit34__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(140, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_65; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_c_cf2g_stable_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_c_cf2g_stable_QMARK__A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_359, false, nil); A_arbace_c_cf2g_stable_QMARK__A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_66)); return A_arbace_c_cf2g__init_A_const_65 }







func A_arbace_c_cf2g__init_A_Unit35__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(148, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_67; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_c_cf2g_pure_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_c_cf2g_pure_QMARK__A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_360, false, nil); A_arbace_c_cf2g_pure_QMARK__A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_68)); return A_arbace_c_cf2g__init_A_const_67 }








func A_arbace_c_cf2g__init_A_Unit36__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(157, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_69; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_c_cf2g_seqx_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_c_cf2g_seqx_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_361, false, nil); A_arbace_c_cf2g_seqx_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_70)); return A_arbace_c_cf2g__init_A_const_69 }














func A_arbace_c_cf2g__init_A_Unit37__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(172, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_71; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_c_cf2g_bind_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_c_cf2g_bind_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_362, false, nil); A_arbace_c_cf2g_bind_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_72)); return A_arbace_c_cf2g__init_A_const_71 }




func A_arbace_c_cf2g__init_A_Unit38__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(177, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_73; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_c_cf2g_cnd_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_c_cf2g_cnd_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_363, false, nil); A_arbace_c_cf2g_cnd_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_74)); return A_arbace_c_cf2g__init_A_const_73 }


func A_arbace_c_cf2g__init_A_Unit39__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(180, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_75; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_c_cf2g_has_label_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_c_cf2g_has_label_QMARK__A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_364, false, nil); A_arbace_c_cf2g_has_label_QMARK__A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_75; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_76)); return A_arbace_c_cf2g__init_A_const_75 }

func A_arbace_c_cf2g__init_A_Unit40__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(182, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_77; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_c_cf2g_branch_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_c_cf2g_branch_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_365, false, nil); A_arbace_c_cf2g_branch_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_77; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_78)); return A_arbace_c_cf2g__init_A_const_77 }

















func A_arbace_c_cf2g__init_A_Unit41__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(200, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_79; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_80)); return A_arbace_c_cf2g__init_A_const_79 }
//line :200:1
func A_arbace_c_cf2g__init_A_Unit42__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(200, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_81; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_82)); return A_arbace_c_cf2g__init_A_const_81 }
//line :200:1
func A_arbace_c_cf2g__init_A_Unit43__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(200, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_83; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_84)); return A_arbace_c_cf2g__init_A_const_83 }
//line :200:1
func A_arbace_c_cf2g__init_A_Unit44__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(200, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_85; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_86)); return A_arbace_c_cf2g__init_A_const_85 }
//line :200:1
func A_arbace_c_cf2g__init_A_Unit45__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(200, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_87; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_88)); return A_arbace_c_cf2g__init_A_const_87 }
//line :200:1
func A_arbace_c_cf2g__init_A_Unit46__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(200, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_89; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_90)); return A_arbace_c_cf2g__init_A_const_89 }

func A_arbace_c_cf2g__init_A_Unit47__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(202, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_91; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_c_cf2g_bin_int_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_c_cf2g_bin_int_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_366, false, nil); A_arbace_c_cf2g_bin_int_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_91; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_92)); return A_arbace_c_cf2g__init_A_const_91 }























func A_arbace_c_cf2g__init_A_Unit48__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(226, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_93; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_c_cf2g_cmp_op_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_c_cf2g_cmp_op_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_367, false, nil); A_arbace_c_cf2g_cmp_op_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_93; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_94)); return A_arbace_c_cf2g__init_A_const_93 }


func A_arbace_c_cf2g__init_A_Unit49__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(229, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_95; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_c_cf2g_fround_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_c_cf2g_fround_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_368, false, nil); A_arbace_c_cf2g_fround_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_95; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_96)); return A_arbace_c_cf2g__init_A_const_95 }


func A_arbace_c_cf2g__init_A_Unit50__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(232, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_97; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_c_cf2g_fconst_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_c_cf2g_fconst_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_369, false, nil); A_arbace_c_cf2g_fconst_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_97; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_98)); return A_arbace_c_cf2g__init_A_const_97 }


func A_arbace_c_cf2g__init_A_Unit51__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(235, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_79; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_c_cf2g_ix_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_c_cf2g_ix_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_370, false, nil); A_arbace_c_cf2g_ix_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_79; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_99)); return A_arbace_c_cf2g__init_A_const_79 }
















































































func A_arbace_c_cf2g__init_A_Unit52__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(316, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_81; var tmp2 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_c_cf2g_fx_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_c_cf2g_fx_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_371, false, nil); A_arbace_c_cf2g_fx_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_81; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_100)); return A_arbace_c_cf2g__init_A_const_81 }
































func A_arbace_c_cf2g__init_A_Unit53__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(349, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_101; var tmp2 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_c_cf2g_wconst_BANG__A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_c_cf2g_wconst_BANG__A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_372, false, nil); A_arbace_c_cf2g_wconst_BANG__A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_101; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_102)); return A_arbace_c_cf2g__init_A_const_101 }




func A_arbace_c_cf2g__init_A_Unit54__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(354, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_83; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_c_cf2g_wx_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_c_cf2g_wx_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_373, false, nil); A_arbace_c_cf2g_wx_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_83; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_103)); return A_arbace_c_cf2g__init_A_const_83 }






























func A_arbace_c_cf2g__init_A_Unit55__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(385, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_89; var tmp2 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_c_cf2g_call_expr_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_c_cf2g_call_expr_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_374, false, nil); A_arbace_c_cf2g_call_expr_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_89; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_104)); return A_arbace_c_cf2g__init_A_const_89 }
































func A_arbace_c_cf2g__init_A_Unit56__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(418, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_87; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_c_cf2g_effect_A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_c_cf2g_effect_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_375, false, nil); A_arbace_c_cf2g_effect_A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_87; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_105)); return A_arbace_c_cf2g__init_A_const_87 }






























func A_arbace_c_cf2g__init_A_Unit57__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(449, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_106; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_c_cf2g_ret_jump_A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_c_cf2g_ret_jump_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_376, false, nil); A_arbace_c_cf2g_ret_jump_A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_106; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_107)); return A_arbace_c_cf2g__init_A_const_106 }

func A_arbace_c_cf2g__init_A_Unit58__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(451, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_108; var tmp2 *lang.Compiler_AOTFn; var fnbody__86 any = A_arbace_c_cf2g_jump_A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_c_cf2g_jump_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_377, false, nil); A_arbace_c_cf2g_jump_A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__86, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_108; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_109)); return A_arbace_c_cf2g__init_A_const_108 }







func A_arbace_c_cf2g__init_A_Unit59__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(459, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_110; var tmp2 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_c_cf2g_ret_stmt_A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_c_cf2g_ret_stmt_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_378, false, nil); A_arbace_c_cf2g_ret_stmt_A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_110; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_111)); return A_arbace_c_cf2g__init_A_const_110 }














func A_arbace_c_cf2g__init_A_Unit60__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(474, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_112; var tmp2 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_c_cf2g_switch_stmt_A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_c_cf2g_switch_stmt_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_379, false, nil); A_arbace_c_cf2g_switch_stmt_A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_112; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_113)); return A_arbace_c_cf2g__init_A_const_112 }





















func A_arbace_c_cf2g__init_A_Unit61__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(496, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_114; var tmp2 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_c_cf2g_loop_stmt_A_New(); var tmp3 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_c_cf2g_loop_stmt_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_380, false, nil); A_arbace_c_cf2g_loop_stmt_A_fn_class = fncls__91d; tmp3 = fncls__91d } else { tmp3 = fncls__91 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_114; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_115)); return A_arbace_c_cf2g__init_A_const_114 }














func A_arbace_c_cf2g__init_A_Unit62__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(511, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_116; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_117)); return A_arbace_c_cf2g__init_A_const_116 }

func A_arbace_c_cf2g__init_A_Unit63__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(513, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_85; var tmp2 *lang.Compiler_AOTFn; var fnbody__94 any = A_arbace_c_cf2g_stmt_A_New(); var tmp3 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_c_cf2g_stmt_A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_381, false, nil); A_arbace_c_cf2g_stmt_A_fn_class = fncls__93d; tmp3 = fncls__93d } else { tmp3 = fncls__93 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__94, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_85; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_118)); return A_arbace_c_cf2g__init_A_const_85 }


























func A_arbace_c_cf2g__init_A_Unit64__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(540, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_119; var tmp2 *lang.Compiler_AOTFn; var fnbody__96 any = A_arbace_c_cf2g_finish_scope_A_New(); var tmp3 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_c_cf2g_finish_scope_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_382, false, nil); A_arbace_c_cf2g_finish_scope_A_fn_class = fncls__95d; tmp3 = fncls__95d } else { tmp3 = fncls__95 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_119; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_120)); return A_arbace_c_cf2g__init_A_const_119 }


















func A_arbace_c_cf2g__init_A_Unit65__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(559, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_121; var tmp2 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_c_cf2g_new_scope_A_New(); var tmp3 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_c_cf2g_new_scope_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_383, false, nil); A_arbace_c_cf2g_new_scope_A_fn_class = fncls__97d; tmp3 = fncls__97d } else { tmp3 = fncls__97 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_121; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_122)); return A_arbace_c_cf2g__init_A_const_121 }

func A_arbace_c_cf2g__init_A_Unit66__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(561, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_116; var tmp2 *lang.Compiler_AOTFn; var fnbody__100 any = A_arbace_c_cf2g_sj_body_A_New(); var tmp3 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_c_cf2g_sj_body_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_384, false, nil); A_arbace_c_cf2g_sj_body_A_fn_class = fncls__99d; tmp3 = fncls__99d } else { tmp3 = fncls__99 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_116; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_123)); return A_arbace_c_cf2g__init_A_const_116 }


















func A_arbace_c_cf2g__init_A_Unit67__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(580, 1); A_arbace_c_cf2g__init_A_const_124.BindRoot_O__V(A_arbace_c_cf2g__init_A_const_125); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_124; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_126)); return A_arbace_c_cf2g__init_A_const_124 }

func A_arbace_c_cf2g__init_A_Unit68__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(582, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_127; var tmp2 *lang.Compiler_AOTFn; var fnbody__102 any = A_arbace_c_cf2g_unconst_A_New(); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_c_cf2g_unconst_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_385, false, nil); A_arbace_c_cf2g_unconst_A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_127; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_128)); return A_arbace_c_cf2g__init_A_const_127 }




















func A_arbace_c_cf2g__init_A_Unit69__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(603, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_129; var tmp2 *lang.Compiler_AOTFn; var fnbody__104 any = A_arbace_c_cf2g_unconst_all_A_New(); var tmp3 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_c_cf2g_unconst_all_A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_386, false, nil); A_arbace_c_cf2g_unconst_all_A_fn_class = fncls__103d; tmp3 = fncls__103d } else { tmp3 = fncls__103 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__104, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_129; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_130)); return A_arbace_c_cf2g__init_A_const_129 }

func A_arbace_c_cf2g__init_A_Unit70__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(605, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_131; var tmp2 *lang.Compiler_AOTFn; var fnbody__106 any = A_arbace_c_cf2g_reads_A_New(); var tmp3 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_c_cf2g_reads_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_387, false, nil); A_arbace_c_cf2g_reads_A_fn_class = fncls__105d; tmp3 = fncls__105d } else { tmp3 = fncls__105 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_131; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_132)); return A_arbace_c_cf2g__init_A_const_131 }











func A_arbace_c_cf2g__init_A_Unit71__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(617, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_133; var tmp2 *lang.Compiler_AOTFn; var fnbody__108 any = A_arbace_c_cf2g_decls_let_A_New(); var tmp3 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_c_cf2g_decls_let_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_388, false, nil); A_arbace_c_cf2g_decls_let_A_fn_class = fncls__107d; tmp3 = fncls__107d } else { tmp3 = fncls__107 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__108, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_133; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_134)); return A_arbace_c_cf2g__init_A_const_133 }

















func A_arbace_c_cf2g__init_A_Unit72__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(635, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_135; var tmp2 *lang.Compiler_AOTFn; var fnbody__110 any = A_arbace_c_cf2g_slot_vars_A_New(); var tmp3 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_c_cf2g_slot_vars_A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_389, false, nil); A_arbace_c_cf2g_slot_vars_A_fn_class = fncls__109d; tmp3 = fncls__109d } else { tmp3 = fncls__109 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__110, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_135; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_136)); return A_arbace_c_cf2g__init_A_const_135 }



func A_arbace_c_cf2g__init_A_Unit73__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(639, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_137; var tmp2 *lang.Compiler_AOTFn; var fnbody__112 any = A_arbace_c_cf2g_param_lit_A_New(); var tmp3 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_c_cf2g_param_lit_A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_390, false, nil); A_arbace_c_cf2g_param_lit_A_fn_class = fncls__111d; tmp3 = fncls__111d } else { tmp3 = fncls__111 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__112, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_137; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_138)); return A_arbace_c_cf2g__init_A_const_137 }







func A_arbace_c_cf2g__init_A_Unit74__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(647, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_139; var tmp2 *lang.Compiler_AOTFn; var fnbody__114 any = A_arbace_c_cf2g_param_stmts_A_New(); var tmp3 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_c_cf2g_param_stmts_A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_391, false, nil); A_arbace_c_cf2g_param_stmts_A_fn_class = fncls__113d; tmp3 = fncls__113d } else { tmp3 = fncls__113 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__114, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_139; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_140)); return A_arbace_c_cf2g__init_A_const_139 }










func A_arbace_c_cf2g__init_A_Unit75__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(658, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_141; var tmp2 *lang.Compiler_AOTFn; var fnbody__116 any = A_arbace_c_cf2g_code_fn_A_New(); var tmp3 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_c_cf2g_code_fn_A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_392, false, nil); A_arbace_c_cf2g_code_fn_A_fn_class = fncls__115d; tmp3 = fncls__115d } else { tmp3 = fncls__115 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__116, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_141; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_142)); return A_arbace_c_cf2g__init_A_const_141 }


























func A_arbace_c_cf2g__init_A_Unit76__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(685, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_143; var tmp2 *lang.Compiler_AOTFn; var fnbody__118 any = A_arbace_c_cf2g_init_fn_A_New(); var tmp3 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_c_cf2g_init_fn_A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_393, false, nil); A_arbace_c_cf2g_init_fn_A_fn_class = fncls__117d; tmp3 = fncls__117d } else { tmp3 = fncls__117 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__118, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_143; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_144)); return A_arbace_c_cf2g__init_A_const_143 }
















func A_arbace_c_cf2g__init_A_Unit77__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(702, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_145; var tmp2 *lang.Compiler_AOTFn; var fnbody__120 any = A_arbace_c_cf2g_text_of_A_New(); var tmp3 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_c_cf2g_text_of_A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_394, false, nil); A_arbace_c_cf2g_text_of_A_fn_class = fncls__119d; tmp3 = fncls__119d } else { tmp3 = fncls__119 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__120, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_145; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_146)); return A_arbace_c_cf2g__init_A_const_145 }



func A_arbace_c_cf2g__init_A_Unit78__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(706, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_147; var tmp2 *lang.Compiler_AOTFn; var fnbody__122 any = A_arbace_c_cf2g_translate_A_New(); var tmp3 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_c_cf2g_translate_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_395, false, nil); A_arbace_c_cf2g_translate_A_fn_class = fncls__121d; tmp3 = fncls__121d } else { tmp3 = fncls__121 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__122, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_147; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_148)); return A_arbace_c_cf2g__init_A_const_147 }



























































func A_arbace_c_cf2g__init_A_Unit79__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(766, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_149; var tmp2 *lang.Compiler_AOTFn; var fnbody__124 any = A_arbace_c_cf2g_go_text_A_New(); var tmp3 *jrt.Class; var fncls__123 *jrt.Class = A_arbace_c_cf2g_go_text_A_fn_class; if fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_396, false, nil); A_arbace_c_cf2g_go_text_A_fn_class = fncls__123d; tmp3 = fncls__123d } else { tmp3 = fncls__123 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__124, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_149; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_150)); return A_arbace_c_cf2g__init_A_const_149 }





func A_arbace_c_cf2g__init_A_Unit80__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(772, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_151; var tmp2 *lang.Compiler_AOTFn; var fnbody__126 any = A_arbace_c_cf2g_translate_file_A_New(); var tmp3 *jrt.Class; var fncls__125 *jrt.Class = A_arbace_c_cf2g_translate_file_A_fn_class; if fncls__125 == nil { var fncls__125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_397, false, nil); A_arbace_c_cf2g_translate_file_A_fn_class = fncls__125d; tmp3 = fncls__125d } else { tmp3 = fncls__125 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__126, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_151; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_152)); return A_arbace_c_cf2g__init_A_const_151 }















func A_arbace_c_cf2g__init_A_Unit81__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(788, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_153; var tmp2 *lang.Compiler_AOTFn; var fnbody__128 any = A_arbace_c_cf2g_tsv_A_New(); var tmp3 *jrt.Class; var fncls__127 *jrt.Class = A_arbace_c_cf2g_tsv_A_fn_class; if fncls__127 == nil { var fncls__127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_398, false, nil); A_arbace_c_cf2g_tsv_A_fn_class = fncls__127d; tmp3 = fncls__127d } else { tmp3 = fncls__127 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__128, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_153; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_154)); return A_arbace_c_cf2g__init_A_const_153 }



func A_arbace_c_cf2g__init_A_Unit82__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(792, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_155; var tmp2 *lang.Compiler_AOTFn; var fnbody__130 any = A_arbace_c_cf2g_compile_list_A_New(); var tmp3 *jrt.Class; var fncls__129 *jrt.Class = A_arbace_c_cf2g_compile_list_A_fn_class; if fncls__129 == nil { var fncls__129d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_399, false, nil); A_arbace_c_cf2g_compile_list_A_fn_class = fncls__129d; tmp3 = fncls__129d } else { tmp3 = fncls__129 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__130, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_155; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_156)); return A_arbace_c_cf2g__init_A_const_155 }























































func A_arbace_c_cf2g__init_A_Unit83__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(848, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_157; var tmp2 *lang.Compiler_AOTFn; var fnbody__132 any = A_arbace_c_cf2g_read_all_A_New(); var tmp3 *jrt.Class; var fncls__131 *jrt.Class = A_arbace_c_cf2g_read_all_A_fn_class; if fncls__131 == nil { var fncls__131d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_400, false, nil); A_arbace_c_cf2g_read_all_A_fn_class = fncls__131d; tmp3 = fncls__131d } else { tmp3 = fncls__131 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__132, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_157; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_158)); return A_arbace_c_cf2g__init_A_const_157 }


func A_arbace_c_cf2g__init_A_Unit84__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(851, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_159; var tmp2 *lang.Compiler_AOTFn; var fnbody__134 any = A_arbace_c_cf2g_judge_A_New(); var tmp3 *jrt.Class; var fncls__133 *jrt.Class = A_arbace_c_cf2g_judge_A_fn_class; if fncls__133 == nil { var fncls__133d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_401, false, nil); A_arbace_c_cf2g_judge_A_fn_class = fncls__133d; tmp3 = fncls__133d } else { tmp3 = fncls__133 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__134, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_159; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_160)); return A_arbace_c_cf2g__init_A_const_159 }





















































































func A_arbace_c_cf2g__init_A_Unit85__O() any { A_arbace_c_cf2g__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(937, 1); var tmp1 *lang.Var = A_arbace_c_cf2g__init_A_const_161; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__136 any = A_arbace_c_cf2g__main_A_New(); var tmp3 *jrt.Class; var fncls__135 *jrt.Class = A_arbace_c_cf2g__main_A_fn_class; if fncls__135 == nil { var fncls__135d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_402, true, nil); A_arbace_c_cf2g__main_A_fn_class = fncls__135d; tmp3 = fncls__135d } else { tmp3 = fncls__135 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__136, tmp3, nil, 1); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c_cf2g__init_A_const_161; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c_cf2g__init_A_const_162)); return A_arbace_c_cf2g__init_A_const_161 }



type A_arbace_c_cf2g__init_A struct{ jrt.Object }

var A_arbace_c_cf2g__init_A_const_pool *jrt.RefArray

var A_arbace_c_cf2g__init_A_const_0 *lang.Var

var A_arbace_c_cf2g__init_A_const_1 any

var A_arbace_c_cf2g__init_A_const_2 any

var A_arbace_c_cf2g__init_A_const_3 any

var A_arbace_c_cf2g__init_A_const_4 *lang.Var

var A_arbace_c_cf2g__init_A_const_5 *lang.Var

var A_arbace_c_cf2g__init_A_const_6 any

var A_arbace_c_cf2g__init_A_const_7 *lang.Var

var A_arbace_c_cf2g__init_A_const_8 any

var A_arbace_c_cf2g__init_A_const_9 *lang.Var

var A_arbace_c_cf2g__init_A_const_10 any

var A_arbace_c_cf2g__init_A_const_11 *lang.Var

var A_arbace_c_cf2g__init_A_const_12 any

var A_arbace_c_cf2g__init_A_const_13 *lang.Var

var A_arbace_c_cf2g__init_A_const_14 any

var A_arbace_c_cf2g__init_A_const_15 *lang.Var

var A_arbace_c_cf2g__init_A_const_16 any

var A_arbace_c_cf2g__init_A_const_17 *lang.Var

var A_arbace_c_cf2g__init_A_const_18 any

var A_arbace_c_cf2g__init_A_const_19 *lang.Var

var A_arbace_c_cf2g__init_A_const_20 any

var A_arbace_c_cf2g__init_A_const_21 *lang.Var

var A_arbace_c_cf2g__init_A_const_22 any

var A_arbace_c_cf2g__init_A_const_23 *lang.Var

var A_arbace_c_cf2g__init_A_const_24 any

var A_arbace_c_cf2g__init_A_const_25 *lang.Var

var A_arbace_c_cf2g__init_A_const_26 any

var A_arbace_c_cf2g__init_A_const_27 *lang.Var

var A_arbace_c_cf2g__init_A_const_28 any

var A_arbace_c_cf2g__init_A_const_29 *lang.Var

var A_arbace_c_cf2g__init_A_const_30 any

var A_arbace_c_cf2g__init_A_const_31 *lang.Var

var A_arbace_c_cf2g__init_A_const_32 any

var A_arbace_c_cf2g__init_A_const_33 *lang.Var

var A_arbace_c_cf2g__init_A_const_34 any

var A_arbace_c_cf2g__init_A_const_35 *lang.Var

var A_arbace_c_cf2g__init_A_const_36 any

var A_arbace_c_cf2g__init_A_const_37 *lang.Var

var A_arbace_c_cf2g__init_A_const_38 any

var A_arbace_c_cf2g__init_A_const_39 *lang.Var

var A_arbace_c_cf2g__init_A_const_40 any

var A_arbace_c_cf2g__init_A_const_41 *lang.Var

var A_arbace_c_cf2g__init_A_const_42 *lang.Keyword

var A_arbace_c_cf2g__init_A_const_43 any

var A_arbace_c_cf2g__init_A_const_44 *lang.Var

var A_arbace_c_cf2g__init_A_const_45 any

var A_arbace_c_cf2g__init_A_const_46 *lang.Var

var A_arbace_c_cf2g__init_A_const_47 any

var A_arbace_c_cf2g__init_A_const_48 *lang.Var

var A_arbace_c_cf2g__init_A_const_49 any

var A_arbace_c_cf2g__init_A_const_50 *lang.Var

var A_arbace_c_cf2g__init_A_const_51 any

var A_arbace_c_cf2g__init_A_const_52 *lang.Var

var A_arbace_c_cf2g__init_A_const_53 any

var A_arbace_c_cf2g__init_A_const_54 *lang.Var

var A_arbace_c_cf2g__init_A_const_55 any

var A_arbace_c_cf2g__init_A_const_56 *lang.Var

var A_arbace_c_cf2g__init_A_const_57 any

var A_arbace_c_cf2g__init_A_const_58 *lang.Var

var A_arbace_c_cf2g__init_A_const_59 any

var A_arbace_c_cf2g__init_A_const_60 *lang.Var

var A_arbace_c_cf2g__init_A_const_61 any

var A_arbace_c_cf2g__init_A_const_62 *lang.Var

var A_arbace_c_cf2g__init_A_const_63 any

var A_arbace_c_cf2g__init_A_const_64 any

var A_arbace_c_cf2g__init_A_const_65 *lang.Var

var A_arbace_c_cf2g__init_A_const_66 any

var A_arbace_c_cf2g__init_A_const_67 *lang.Var

var A_arbace_c_cf2g__init_A_const_68 any

var A_arbace_c_cf2g__init_A_const_69 *lang.Var

var A_arbace_c_cf2g__init_A_const_70 any

var A_arbace_c_cf2g__init_A_const_71 *lang.Var

var A_arbace_c_cf2g__init_A_const_72 any

var A_arbace_c_cf2g__init_A_const_73 *lang.Var

var A_arbace_c_cf2g__init_A_const_74 any

var A_arbace_c_cf2g__init_A_const_75 *lang.Var

var A_arbace_c_cf2g__init_A_const_76 any

var A_arbace_c_cf2g__init_A_const_77 *lang.Var

var A_arbace_c_cf2g__init_A_const_78 any

var A_arbace_c_cf2g__init_A_const_79 *lang.Var

var A_arbace_c_cf2g__init_A_const_80 any

var A_arbace_c_cf2g__init_A_const_81 *lang.Var

var A_arbace_c_cf2g__init_A_const_82 any

var A_arbace_c_cf2g__init_A_const_83 *lang.Var

var A_arbace_c_cf2g__init_A_const_84 any

var A_arbace_c_cf2g__init_A_const_85 *lang.Var

var A_arbace_c_cf2g__init_A_const_86 any

var A_arbace_c_cf2g__init_A_const_87 *lang.Var

var A_arbace_c_cf2g__init_A_const_88 any

var A_arbace_c_cf2g__init_A_const_89 *lang.Var

var A_arbace_c_cf2g__init_A_const_90 any

var A_arbace_c_cf2g__init_A_const_91 *lang.Var

var A_arbace_c_cf2g__init_A_const_92 any

var A_arbace_c_cf2g__init_A_const_93 *lang.Var

var A_arbace_c_cf2g__init_A_const_94 any

var A_arbace_c_cf2g__init_A_const_95 *lang.Var

var A_arbace_c_cf2g__init_A_const_96 any

var A_arbace_c_cf2g__init_A_const_97 *lang.Var

var A_arbace_c_cf2g__init_A_const_98 any

var A_arbace_c_cf2g__init_A_const_99 any

var A_arbace_c_cf2g__init_A_const_100 any

var A_arbace_c_cf2g__init_A_const_101 *lang.Var

var A_arbace_c_cf2g__init_A_const_102 any

var A_arbace_c_cf2g__init_A_const_103 any

var A_arbace_c_cf2g__init_A_const_104 any

var A_arbace_c_cf2g__init_A_const_105 any

var A_arbace_c_cf2g__init_A_const_106 *lang.Var

var A_arbace_c_cf2g__init_A_const_107 any

var A_arbace_c_cf2g__init_A_const_108 *lang.Var

var A_arbace_c_cf2g__init_A_const_109 any

var A_arbace_c_cf2g__init_A_const_110 *lang.Var

var A_arbace_c_cf2g__init_A_const_111 any

var A_arbace_c_cf2g__init_A_const_112 *lang.Var

var A_arbace_c_cf2g__init_A_const_113 any

var A_arbace_c_cf2g__init_A_const_114 *lang.Var

var A_arbace_c_cf2g__init_A_const_115 any

var A_arbace_c_cf2g__init_A_const_116 *lang.Var

var A_arbace_c_cf2g__init_A_const_117 any

var A_arbace_c_cf2g__init_A_const_118 any

var A_arbace_c_cf2g__init_A_const_119 *lang.Var

var A_arbace_c_cf2g__init_A_const_120 any

var A_arbace_c_cf2g__init_A_const_121 *lang.Var

var A_arbace_c_cf2g__init_A_const_122 any

var A_arbace_c_cf2g__init_A_const_123 any

var A_arbace_c_cf2g__init_A_const_124 *lang.Var

var A_arbace_c_cf2g__init_A_const_125 any

var A_arbace_c_cf2g__init_A_const_126 any

var A_arbace_c_cf2g__init_A_const_127 *lang.Var

var A_arbace_c_cf2g__init_A_const_128 any

var A_arbace_c_cf2g__init_A_const_129 *lang.Var

var A_arbace_c_cf2g__init_A_const_130 any

var A_arbace_c_cf2g__init_A_const_131 *lang.Var

var A_arbace_c_cf2g__init_A_const_132 any

var A_arbace_c_cf2g__init_A_const_133 *lang.Var

var A_arbace_c_cf2g__init_A_const_134 any

var A_arbace_c_cf2g__init_A_const_135 *lang.Var

var A_arbace_c_cf2g__init_A_const_136 any

var A_arbace_c_cf2g__init_A_const_137 *lang.Var

var A_arbace_c_cf2g__init_A_const_138 any

var A_arbace_c_cf2g__init_A_const_139 *lang.Var

var A_arbace_c_cf2g__init_A_const_140 any

var A_arbace_c_cf2g__init_A_const_141 *lang.Var

var A_arbace_c_cf2g__init_A_const_142 any

var A_arbace_c_cf2g__init_A_const_143 *lang.Var

var A_arbace_c_cf2g__init_A_const_144 any

var A_arbace_c_cf2g__init_A_const_145 *lang.Var

var A_arbace_c_cf2g__init_A_const_146 any

var A_arbace_c_cf2g__init_A_const_147 *lang.Var

var A_arbace_c_cf2g__init_A_const_148 any

var A_arbace_c_cf2g__init_A_const_149 *lang.Var

var A_arbace_c_cf2g__init_A_const_150 any

var A_arbace_c_cf2g__init_A_const_151 *lang.Var

var A_arbace_c_cf2g__init_A_const_152 any

var A_arbace_c_cf2g__init_A_const_153 *lang.Var

var A_arbace_c_cf2g__init_A_const_154 any

var A_arbace_c_cf2g__init_A_const_155 *lang.Var

var A_arbace_c_cf2g__init_A_const_156 any

var A_arbace_c_cf2g__init_A_const_157 *lang.Var

var A_arbace_c_cf2g__init_A_const_158 any

var A_arbace_c_cf2g__init_A_const_159 *lang.Var

var A_arbace_c_cf2g__init_A_const_160 any

var A_arbace_c_cf2g__init_A_const_161 *lang.Var

var A_arbace_c_cf2g__init_A_const_162 any

var A_arbace_c_cf2g__init_A_init jrt.ClassInit

func A_arbace_c_cf2g__init_A_Init() { if !A_arbace_c_cf2g__init_A_init.Done() { A_arbace_c_cf2g__init_A_init.Run(A_arbace_c_cf2g__init_A_clinit) } }

func A_arbace_c_cf2g__init_A_clinit() { A_arbace_c_cf2g__init_A_clinit_p0(); A_arbace_c_cf2g__init_A_clinit_p1(); A_arbace_c_cf2g__init_A_clinit_p2(); A_arbace_c_cf2g__init_A_clinit_p3(); A_arbace_c_cf2g__init_A_clinit_p4(); A_arbace_c_cf2g__init_A_clinit_p5(); A_arbace_c_cf2g__init_A_clinit_p6(); A_arbace_c_cf2g__init_A_clinit_p7(); A_arbace_c_cf2g__init_A_clinit_p8(); A_arbace_c_cf2g__init_A_clinit_p9(); A_arbace_c_cf2g__init_A_clinit_p10(); A_arbace_c_cf2g__init_A_clinit_p11(); A_arbace_c_cf2g__init_A_clinit_p12() }

func A_arbace_c_cf2g__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_c_cf2g__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_334, 256); A_arbace_c_cf2g__init_A_const_0 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[93]); A_arbace_c_cf2g__init_A_const_1 = A_arbace_c_cf2g__init_A_const_pool.A[94]; A_arbace_c_cf2g__init_A_const_2 = A_arbace_c_cf2g__init_A_const_pool.A[95]; A_arbace_c_cf2g__init_A_const_3 = A_arbace_c_cf2g__init_A_const_pool.A[96]; A_arbace_c_cf2g__init_A_const_4 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[97]); A_arbace_c_cf2g__init_A_const_5 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[98]); A_arbace_c_cf2g__init_A_const_6 = A_arbace_c_cf2g__init_A_const_pool.A[99]; A_arbace_c_cf2g__init_A_const_7 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[100]); A_arbace_c_cf2g__init_A_const_8 = A_arbace_c_cf2g__init_A_const_pool.A[101]; A_arbace_c_cf2g__init_A_const_9 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[102]); A_arbace_c_cf2g__init_A_const_10 = A_arbace_c_cf2g__init_A_const_pool.A[103]; A_arbace_c_cf2g__init_A_const_11 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[104]); A_arbace_c_cf2g__init_A_const_12 = A_arbace_c_cf2g__init_A_const_pool.A[105] }

func A_arbace_c_cf2g__init_A_clinit_p1() { A_arbace_c_cf2g__init_A_const_13 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[106]); A_arbace_c_cf2g__init_A_const_14 = A_arbace_c_cf2g__init_A_const_pool.A[107]; A_arbace_c_cf2g__init_A_const_15 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[108]); A_arbace_c_cf2g__init_A_const_16 = A_arbace_c_cf2g__init_A_const_pool.A[109]; A_arbace_c_cf2g__init_A_const_17 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[110]); A_arbace_c_cf2g__init_A_const_18 = A_arbace_c_cf2g__init_A_const_pool.A[111]; A_arbace_c_cf2g__init_A_const_19 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[112]); A_arbace_c_cf2g__init_A_const_20 = A_arbace_c_cf2g__init_A_const_pool.A[113]; A_arbace_c_cf2g__init_A_const_21 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[114]); A_arbace_c_cf2g__init_A_const_22 = A_arbace_c_cf2g__init_A_const_pool.A[115]; A_arbace_c_cf2g__init_A_const_23 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[116]); A_arbace_c_cf2g__init_A_const_24 = A_arbace_c_cf2g__init_A_const_pool.A[117]; A_arbace_c_cf2g__init_A_const_25 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[118]) }

func A_arbace_c_cf2g__init_A_clinit_p2() { A_arbace_c_cf2g__init_A_const_26 = A_arbace_c_cf2g__init_A_const_pool.A[119]; A_arbace_c_cf2g__init_A_const_27 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[120]); A_arbace_c_cf2g__init_A_const_28 = A_arbace_c_cf2g__init_A_const_pool.A[121]; A_arbace_c_cf2g__init_A_const_29 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[122]); A_arbace_c_cf2g__init_A_const_30 = A_arbace_c_cf2g__init_A_const_pool.A[123]; A_arbace_c_cf2g__init_A_const_31 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[124]); A_arbace_c_cf2g__init_A_const_32 = A_arbace_c_cf2g__init_A_const_pool.A[125]; A_arbace_c_cf2g__init_A_const_33 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[126]); A_arbace_c_cf2g__init_A_const_34 = A_arbace_c_cf2g__init_A_const_pool.A[127]; A_arbace_c_cf2g__init_A_const_35 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[128]); A_arbace_c_cf2g__init_A_const_36 = A_arbace_c_cf2g__init_A_const_pool.A[129]; A_arbace_c_cf2g__init_A_const_37 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[130]); A_arbace_c_cf2g__init_A_const_38 = A_arbace_c_cf2g__init_A_const_pool.A[131] }

func A_arbace_c_cf2g__init_A_clinit_p3() { A_arbace_c_cf2g__init_A_const_39 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[132]); A_arbace_c_cf2g__init_A_const_40 = A_arbace_c_cf2g__init_A_const_pool.A[133]; A_arbace_c_cf2g__init_A_const_41 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[134]); A_arbace_c_cf2g__init_A_const_42 = lang.Keyword_Cast(A_arbace_c_cf2g__init_A_const_pool.A[135]); A_arbace_c_cf2g__init_A_const_43 = A_arbace_c_cf2g__init_A_const_pool.A[136]; A_arbace_c_cf2g__init_A_const_44 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[137]); A_arbace_c_cf2g__init_A_const_45 = A_arbace_c_cf2g__init_A_const_pool.A[138]; A_arbace_c_cf2g__init_A_const_46 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[139]); A_arbace_c_cf2g__init_A_const_47 = A_arbace_c_cf2g__init_A_const_pool.A[140]; A_arbace_c_cf2g__init_A_const_48 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[141]); A_arbace_c_cf2g__init_A_const_49 = A_arbace_c_cf2g__init_A_const_pool.A[142]; A_arbace_c_cf2g__init_A_const_50 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[143]); A_arbace_c_cf2g__init_A_const_51 = A_arbace_c_cf2g__init_A_const_pool.A[144] }

func A_arbace_c_cf2g__init_A_clinit_p4() { A_arbace_c_cf2g__init_A_const_52 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[145]); A_arbace_c_cf2g__init_A_const_53 = A_arbace_c_cf2g__init_A_const_pool.A[146]; A_arbace_c_cf2g__init_A_const_54 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[147]); A_arbace_c_cf2g__init_A_const_55 = A_arbace_c_cf2g__init_A_const_pool.A[148]; A_arbace_c_cf2g__init_A_const_56 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[149]); A_arbace_c_cf2g__init_A_const_57 = A_arbace_c_cf2g__init_A_const_pool.A[150]; A_arbace_c_cf2g__init_A_const_58 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[151]); A_arbace_c_cf2g__init_A_const_59 = A_arbace_c_cf2g__init_A_const_pool.A[152]; A_arbace_c_cf2g__init_A_const_60 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[153]); A_arbace_c_cf2g__init_A_const_61 = A_arbace_c_cf2g__init_A_const_pool.A[154]; A_arbace_c_cf2g__init_A_const_62 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[155]); A_arbace_c_cf2g__init_A_const_63 = A_arbace_c_cf2g__init_A_const_pool.A[156]; A_arbace_c_cf2g__init_A_const_64 = A_arbace_c_cf2g__init_A_const_pool.A[157] }

func A_arbace_c_cf2g__init_A_clinit_p5() { A_arbace_c_cf2g__init_A_const_65 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[158]); A_arbace_c_cf2g__init_A_const_66 = A_arbace_c_cf2g__init_A_const_pool.A[159]; A_arbace_c_cf2g__init_A_const_67 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[160]); A_arbace_c_cf2g__init_A_const_68 = A_arbace_c_cf2g__init_A_const_pool.A[161]; A_arbace_c_cf2g__init_A_const_69 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[162]); A_arbace_c_cf2g__init_A_const_70 = A_arbace_c_cf2g__init_A_const_pool.A[163]; A_arbace_c_cf2g__init_A_const_71 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[164]); A_arbace_c_cf2g__init_A_const_72 = A_arbace_c_cf2g__init_A_const_pool.A[165]; A_arbace_c_cf2g__init_A_const_73 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[166]); A_arbace_c_cf2g__init_A_const_74 = A_arbace_c_cf2g__init_A_const_pool.A[167]; A_arbace_c_cf2g__init_A_const_75 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[168]); A_arbace_c_cf2g__init_A_const_76 = A_arbace_c_cf2g__init_A_const_pool.A[169]; A_arbace_c_cf2g__init_A_const_77 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[170]) }

func A_arbace_c_cf2g__init_A_clinit_p6() { A_arbace_c_cf2g__init_A_const_78 = A_arbace_c_cf2g__init_A_const_pool.A[171]; A_arbace_c_cf2g__init_A_const_79 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[172]); A_arbace_c_cf2g__init_A_const_80 = A_arbace_c_cf2g__init_A_const_pool.A[173]; A_arbace_c_cf2g__init_A_const_81 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[174]); A_arbace_c_cf2g__init_A_const_82 = A_arbace_c_cf2g__init_A_const_pool.A[175]; A_arbace_c_cf2g__init_A_const_83 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[176]); A_arbace_c_cf2g__init_A_const_84 = A_arbace_c_cf2g__init_A_const_pool.A[177]; A_arbace_c_cf2g__init_A_const_85 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[178]); A_arbace_c_cf2g__init_A_const_86 = A_arbace_c_cf2g__init_A_const_pool.A[179]; A_arbace_c_cf2g__init_A_const_87 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[180]); A_arbace_c_cf2g__init_A_const_88 = A_arbace_c_cf2g__init_A_const_pool.A[181]; A_arbace_c_cf2g__init_A_const_89 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[182]); A_arbace_c_cf2g__init_A_const_90 = A_arbace_c_cf2g__init_A_const_pool.A[183] }

func A_arbace_c_cf2g__init_A_clinit_p7() { A_arbace_c_cf2g__init_A_const_91 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[184]); A_arbace_c_cf2g__init_A_const_92 = A_arbace_c_cf2g__init_A_const_pool.A[185]; A_arbace_c_cf2g__init_A_const_93 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[186]); A_arbace_c_cf2g__init_A_const_94 = A_arbace_c_cf2g__init_A_const_pool.A[187]; A_arbace_c_cf2g__init_A_const_95 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[188]); A_arbace_c_cf2g__init_A_const_96 = A_arbace_c_cf2g__init_A_const_pool.A[189]; A_arbace_c_cf2g__init_A_const_97 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[190]); A_arbace_c_cf2g__init_A_const_98 = A_arbace_c_cf2g__init_A_const_pool.A[191]; A_arbace_c_cf2g__init_A_const_99 = A_arbace_c_cf2g__init_A_const_pool.A[192]; A_arbace_c_cf2g__init_A_const_100 = A_arbace_c_cf2g__init_A_const_pool.A[193]; A_arbace_c_cf2g__init_A_const_101 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[194]); A_arbace_c_cf2g__init_A_const_102 = A_arbace_c_cf2g__init_A_const_pool.A[195]; A_arbace_c_cf2g__init_A_const_103 = A_arbace_c_cf2g__init_A_const_pool.A[196]; A_arbace_c_cf2g__init_A_const_104 = A_arbace_c_cf2g__init_A_const_pool.A[197] }

func A_arbace_c_cf2g__init_A_clinit_p8() { A_arbace_c_cf2g__init_A_const_105 = A_arbace_c_cf2g__init_A_const_pool.A[198]; A_arbace_c_cf2g__init_A_const_106 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[199]); A_arbace_c_cf2g__init_A_const_107 = A_arbace_c_cf2g__init_A_const_pool.A[200]; A_arbace_c_cf2g__init_A_const_108 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[201]); A_arbace_c_cf2g__init_A_const_109 = A_arbace_c_cf2g__init_A_const_pool.A[202]; A_arbace_c_cf2g__init_A_const_110 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[203]); A_arbace_c_cf2g__init_A_const_111 = A_arbace_c_cf2g__init_A_const_pool.A[204]; A_arbace_c_cf2g__init_A_const_112 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[205]); A_arbace_c_cf2g__init_A_const_113 = A_arbace_c_cf2g__init_A_const_pool.A[206]; A_arbace_c_cf2g__init_A_const_114 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[207]); A_arbace_c_cf2g__init_A_const_115 = A_arbace_c_cf2g__init_A_const_pool.A[208]; A_arbace_c_cf2g__init_A_const_116 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[209]); A_arbace_c_cf2g__init_A_const_117 = A_arbace_c_cf2g__init_A_const_pool.A[210]; A_arbace_c_cf2g__init_A_const_118 = A_arbace_c_cf2g__init_A_const_pool.A[211] }

func A_arbace_c_cf2g__init_A_clinit_p9() { A_arbace_c_cf2g__init_A_const_119 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[212]); A_arbace_c_cf2g__init_A_const_120 = A_arbace_c_cf2g__init_A_const_pool.A[213]; A_arbace_c_cf2g__init_A_const_121 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[214]); A_arbace_c_cf2g__init_A_const_122 = A_arbace_c_cf2g__init_A_const_pool.A[215]; A_arbace_c_cf2g__init_A_const_123 = A_arbace_c_cf2g__init_A_const_pool.A[216]; A_arbace_c_cf2g__init_A_const_124 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[217]); A_arbace_c_cf2g__init_A_const_125 = A_arbace_c_cf2g__init_A_const_pool.A[218]; A_arbace_c_cf2g__init_A_const_126 = A_arbace_c_cf2g__init_A_const_pool.A[219]; A_arbace_c_cf2g__init_A_const_127 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[220]); A_arbace_c_cf2g__init_A_const_128 = A_arbace_c_cf2g__init_A_const_pool.A[221]; A_arbace_c_cf2g__init_A_const_129 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[222]); A_arbace_c_cf2g__init_A_const_130 = A_arbace_c_cf2g__init_A_const_pool.A[223]; A_arbace_c_cf2g__init_A_const_131 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[224]); A_arbace_c_cf2g__init_A_const_132 = A_arbace_c_cf2g__init_A_const_pool.A[225] }

func A_arbace_c_cf2g__init_A_clinit_p10() { A_arbace_c_cf2g__init_A_const_133 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[226]); A_arbace_c_cf2g__init_A_const_134 = A_arbace_c_cf2g__init_A_const_pool.A[227]; A_arbace_c_cf2g__init_A_const_135 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[228]); A_arbace_c_cf2g__init_A_const_136 = A_arbace_c_cf2g__init_A_const_pool.A[229]; A_arbace_c_cf2g__init_A_const_137 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[230]); A_arbace_c_cf2g__init_A_const_138 = A_arbace_c_cf2g__init_A_const_pool.A[231]; A_arbace_c_cf2g__init_A_const_139 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[232]); A_arbace_c_cf2g__init_A_const_140 = A_arbace_c_cf2g__init_A_const_pool.A[233]; A_arbace_c_cf2g__init_A_const_141 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[234]); A_arbace_c_cf2g__init_A_const_142 = A_arbace_c_cf2g__init_A_const_pool.A[235]; A_arbace_c_cf2g__init_A_const_143 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[236]); A_arbace_c_cf2g__init_A_const_144 = A_arbace_c_cf2g__init_A_const_pool.A[237]; A_arbace_c_cf2g__init_A_const_145 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[238]) }

func A_arbace_c_cf2g__init_A_clinit_p11() { A_arbace_c_cf2g__init_A_const_146 = A_arbace_c_cf2g__init_A_const_pool.A[239]; A_arbace_c_cf2g__init_A_const_147 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[240]); A_arbace_c_cf2g__init_A_const_148 = A_arbace_c_cf2g__init_A_const_pool.A[241]; A_arbace_c_cf2g__init_A_const_149 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[242]); A_arbace_c_cf2g__init_A_const_150 = A_arbace_c_cf2g__init_A_const_pool.A[243]; A_arbace_c_cf2g__init_A_const_151 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[244]); A_arbace_c_cf2g__init_A_const_152 = A_arbace_c_cf2g__init_A_const_pool.A[245]; A_arbace_c_cf2g__init_A_const_153 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[246]); A_arbace_c_cf2g__init_A_const_154 = A_arbace_c_cf2g__init_A_const_pool.A[247]; A_arbace_c_cf2g__init_A_const_155 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[248]); A_arbace_c_cf2g__init_A_const_156 = A_arbace_c_cf2g__init_A_const_pool.A[249]; A_arbace_c_cf2g__init_A_const_157 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[250]); A_arbace_c_cf2g__init_A_const_158 = A_arbace_c_cf2g__init_A_const_pool.A[251] }

func A_arbace_c_cf2g__init_A_clinit_p12() { A_arbace_c_cf2g__init_A_const_159 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[252]); A_arbace_c_cf2g__init_A_const_160 = A_arbace_c_cf2g__init_A_const_pool.A[253]; A_arbace_c_cf2g__init_A_const_161 = lang.Var_Cast(A_arbace_c_cf2g__init_A_const_pool.A[254]); A_arbace_c_cf2g__init_A_const_162 = A_arbace_c_cf2g__init_A_const_pool.A[255] }

func A_arbace_c_cf2g__init_A_New() *A_arbace_c_cf2g__init_A { A_arbace_c_cf2g__init_A_Init(); t := &A_arbace_c_cf2g__init_A{}; t.Ctor(); return t }

func (t *A_arbace_c_cf2g__init_A) Ctor() {}

func (t *A_arbace_c_cf2g__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c_cf2g__init_A) GetClass__Class() *jrt.Class { return A_arbace_c_cf2g__init_A_class }

func (t *A_arbace_c_cf2g__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c_cf2g__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c_cf2g__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c_cf2g__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c_cf2g__init_A); return ok }

func A_arbace_c_cf2g__init_A_Cast(x any) *A_arbace_c_cf2g__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c_cf2g__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c_cf2g__init_A_class)) }; return v }
