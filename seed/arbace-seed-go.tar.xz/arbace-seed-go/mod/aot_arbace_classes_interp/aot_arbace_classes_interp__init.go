//line aot_arbace_classes_interp__init.ae:1
package aot_arbace_classes_interp

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_interp__init_part0_A_Unit0__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(A_arbace_classes_interp__init_part0_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_interp__init_part0_A_const_1) }
//line :1:1
func A_arbace_classes_interp__init_part0_A_Unit1__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_classes_interp__init_part0_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_2)) }
//line :1:1
func A_arbace_classes_interp__init_part0_A_Unit2__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_classes_interp_eval393000004_loading__1927001464__auto____393000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_classes_interp_eval393000004_loading__1927001464__auto____393000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_260, false); A_arbace_classes_interp_eval393000004_loading__1927001464__auto____393000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_classes_interp__init_part0_A_Unit3__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_classes_interp__init_part0_A_const_1)).Equals_O__Z(A_arbace_classes_interp__init_part0_A_const_3) { return nil } else { var tmp1 any = A_arbace_classes_interp_eval393000008_fn__393000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_classes_interp_eval393000008_fn__393000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_261, false); A_arbace_classes_interp_eval393000008_fn__393000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }
//line :1:1
func A_arbace_classes_interp__init_part0_A_Init__O() any { A_arbace_classes_interp__init_part0_A_Init(); return nil }
//line :1:1
func A_arbace_classes_interp__init_part0_A_Load__O() any { A_arbace_classes_interp__init_part0_A_Init(); A_arbace_classes_interp__init_part0_A_Unit0__O(); A_arbace_classes_interp__init_part0_A_Unit1__O(); A_arbace_classes_interp__init_part0_A_Unit2__O(); A_arbace_classes_interp__init_part0_A_Unit3__O(); A_arbace_classes_interp__init_part0_A_Unit4__O(); A_arbace_classes_interp__init_part0_A_Unit5__O(); A_arbace_classes_interp__init_part0_A_Unit6__O(); A_arbace_classes_interp__init_part0_A_Unit7__O(); A_arbace_classes_interp__init_part0_A_Unit8__O(); A_arbace_classes_interp__init_part0_A_Unit9__O(); A_arbace_classes_interp__init_part0_A_Unit10__O(); A_arbace_classes_interp__init_part0_A_Unit11__O(); A_arbace_classes_interp__init_part0_A_Unit12__O(); A_arbace_classes_interp__init_part0_A_Unit13__O(); A_arbace_classes_interp__init_part0_A_Unit14__O(); A_arbace_classes_interp__init_part0_A_Unit15__O(); A_arbace_classes_interp__init_part0_A_Unit16__O(); A_arbace_classes_interp__init_part0_A_Unit17__O(); A_arbace_classes_interp__init_part0_A_Unit18__O(); A_arbace_classes_interp__init_part0_A_Unit19__O(); A_arbace_classes_interp__init_part0_A_Unit20__O(); A_arbace_classes_interp__init_part0_A_Unit21__O(); A_arbace_classes_interp__init_part0_A_Unit22__O(); A_arbace_classes_interp__init_part0_A_Unit23__O(); A_arbace_classes_interp__init_part0_A_Unit24__O(); A_arbace_classes_interp__init_part0_A_Unit25__O(); A_arbace_classes_interp__init_part0_A_Unit26__O(); A_arbace_classes_interp__init_part0_A_Unit27__O(); A_arbace_classes_interp__init_part0_A_Unit28__O(); A_arbace_classes_interp__init_part0_A_Unit29__O(); A_arbace_classes_interp__init_part0_A_Unit30__O(); A_arbace_classes_interp__init_part0_A_Unit31__O(); A_arbace_classes_interp__init_part0_A_Unit32__O(); A_arbace_classes_interp__init_part0_A_Unit33__O(); A_arbace_classes_interp__init_part0_A_Unit34__O(); A_arbace_classes_interp__init_part0_A_Unit35__O(); A_arbace_classes_interp__init_part0_A_Unit36__O(); A_arbace_classes_interp__init_part0_A_Unit37__O(); A_arbace_classes_interp__init_part0_A_Unit38__O(); A_arbace_classes_interp__init_part0_A_Unit39__O(); A_arbace_classes_interp__init_part0_A_Unit40__O(); A_arbace_classes_interp__init_part0_A_Unit41__O(); A_arbace_classes_interp__init_part0_A_Unit42__O(); A_arbace_classes_interp__init_part0_A_Unit43__O(); A_arbace_classes_interp__init_part0_A_Unit44__O(); A_arbace_classes_interp__init_part0_A_Unit45__O(); A_arbace_classes_interp__init_part0_A_Unit46__O(); A_arbace_classes_interp__init_part0_A_Unit47__O(); A_arbace_classes_interp__init_part0_A_Unit48__O(); A_arbace_classes_interp__init_part0_A_Unit49__O(); A_arbace_classes_interp__init_part0_A_Unit50__O(); A_arbace_classes_interp__init_part0_A_Unit51__O(); A_arbace_classes_interp__init_part0_A_Unit52__O(); A_arbace_classes_interp__init_part0_A_Unit53__O(); A_arbace_classes_interp__init_part0_A_Unit54__O(); A_arbace_classes_interp__init_part0_A_Unit55__O(); A_arbace_classes_interp__init_part0_A_Unit56__O(); A_arbace_classes_interp__init_part0_A_Unit57__O(); A_arbace_classes_interp__init_part0_A_Unit58__O(); A_arbace_classes_interp__init_part0_A_Unit59__O(); A_arbace_classes_interp__init_part0_A_Unit60__O(); A_arbace_classes_interp__init_part0_A_Unit61__O(); A_arbace_classes_interp__init_part0_A_Unit62__O(); A_arbace_classes_interp__init_part0_A_Unit63__O(); A_arbace_classes_interp__init_part0_A_Unit64__O(); A_arbace_classes_interp__init_part0_A_Unit65__O(); A_arbace_classes_interp__init_part0_A_Unit66__O(); A_arbace_classes_interp__init_part0_A_Unit67__O(); A_arbace_classes_interp__init_part0_A_Unit68__O(); A_arbace_classes_interp__init_part0_A_Unit69__O(); A_arbace_classes_interp__init_part0_A_Unit70__O(); A_arbace_classes_interp__init_part0_A_Unit71__O(); A_arbace_classes_interp__init_part0_A_Unit72__O(); A_arbace_classes_interp__init_part0_A_Unit73__O(); A_arbace_classes_interp__init_part0_A_Unit74__O(); A_arbace_classes_interp__init_part0_A_Unit75__O(); A_arbace_classes_interp__init_part0_A_Unit76__O(); A_arbace_classes_interp__init_part0_A_Unit77__O(); A_arbace_classes_interp__init_part0_A_Unit78__O(); A_arbace_classes_interp__init_part0_A_Unit79__O(); A_arbace_classes_interp__init_part0_A_Unit80__O(); A_arbace_classes_interp__init_part0_A_Unit81__O(); A_arbace_classes_interp__init_part0_A_Unit82__O(); A_arbace_classes_interp__init_part0_A_Unit83__O(); A_arbace_classes_interp__init_part0_A_Unit84__O(); A_arbace_classes_interp__init_part0_A_Unit85__O(); A_arbace_classes_interp__init_part0_A_Unit86__O(); A_arbace_classes_interp__init_part0_A_Unit87__O(); A_arbace_classes_interp__init_part0_A_Unit88__O(); A_arbace_classes_interp__init_part0_A_Unit89__O(); A_arbace_classes_interp__init_part0_A_Unit90__O(); A_arbace_classes_interp__init_part0_A_Unit91__O(); A_arbace_classes_interp__init_part0_A_Unit92__O(); A_arbace_classes_interp__init_part0_A_Unit93__O(); A_arbace_classes_interp__init_part0_A_Unit94__O(); A_arbace_classes_interp__init_part0_A_Unit95__O(); A_arbace_classes_interp__init_part0_A_Unit96__O(); A_arbace_classes_interp__init_part0_A_Unit97__O(); A_arbace_classes_interp__init_part0_A_Unit98__O(); A_arbace_classes_interp__init_part0_A_Unit99__O(); return nil }



func A_arbace_classes_interp__init_A_Load__O() any { A_arbace_classes_interp__init_part0_A_Init__O(); A_arbace_classes_interp__init_part1_A_Init__O(); A_arbace_classes_interp__init_part0_A_Load__O(); A_arbace_classes_interp__init_part1_A_Load__O(); return nil }

































func A_arbace_classes_interp__init_part0_A_Unit4__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(39, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_5)); v__1927001498__auto____1 = A_arbace_classes_interp__init_part0_A_const_4; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_classes_interp__init_part0_A_const_4; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_7)); var tmp3 *lang.Var = A_arbace_classes_interp__init_part0_A_const_4; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_classes_interp__init_part0_A_const_6.GetRawRoot__O()); var tmp5 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp5 = lang.PersistentArrayMap_EMPTY; tmp3.BindRoot_O__V(tmp4.Invoke_O__O(tmp5.Ref())); return A_arbace_classes_interp__init_part0_A_const_4 } }


func A_arbace_classes_interp__init_part0_A_Unit5__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(42, 1); A_arbace_classes_interp__init_part0_A_const_8.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_8; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_9)); return A_arbace_classes_interp__init_part0_A_const_8.SetDynamic_Z__Var(true).Ref() }



func A_arbace_classes_interp__init_part0_A_Unit6__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(46, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_10; var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_FALSE; tmp1.BindRoot_O__V(tmp2.Ref()); var tmp3 *lang.Var = A_arbace_classes_interp__init_part0_A_const_10; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_11)); return A_arbace_classes_interp__init_part0_A_const_10.SetDynamic_Z__Var(true).Ref() }




func A_arbace_classes_interp__init_part0_A_Unit7__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(51, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_12; var tmp2 any = A_arbace_classes_interp_sibling_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_classes_interp_sibling_QMARK__A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_262, false); A_arbace_classes_interp_sibling_QMARK__A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_13)); return A_arbace_classes_interp__init_part0_A_const_12 }





func A_arbace_classes_interp__init_part0_A_Unit8__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(57, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_14; var tmp2 any = A_arbace_classes_interp_pending_BANG__A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_classes_interp_pending_BANG__A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_263, false); A_arbace_classes_interp_pending_BANG__A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_15)); return A_arbace_classes_interp__init_part0_A_const_14 }







func A_arbace_classes_interp__init_part0_A_Unit9__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(65, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_16; var tmp2 any = A_arbace_classes_interp_pending_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_classes_interp_pending_QMARK__A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_264, false); A_arbace_classes_interp_pending_QMARK__A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_17)); return A_arbace_classes_interp__init_part0_A_const_16 }

func A_arbace_classes_interp__init_part0_A_Unit10__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(67, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_18; var tmp2 any = A_arbace_classes_interp_klass_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_classes_interp_klass_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_265, false); A_arbace_classes_interp_klass_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_19)); return A_arbace_classes_interp__init_part0_A_const_18 }












func A_arbace_classes_interp__init_part0_A_Unit11__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(80, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_20; var tmp2 any = A_arbace_classes_interp_fail_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_classes_interp_fail_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_266, true); A_arbace_classes_interp_fail_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_21)); return A_arbace_classes_interp__init_part0_A_const_20 }




func A_arbace_classes_interp__init_part0_A_Unit12__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(85, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_22; var tmp2 any = A_arbace_classes_interp_tc_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_classes_interp_tc_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_267, false); A_arbace_classes_interp_tc_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_23)); return A_arbace_classes_interp__init_part0_A_const_22 }








func A_arbace_classes_interp__init_part0_A_Unit13__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(94, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_24; var tmp2 any = A_arbace_classes_interp_kind_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_classes_interp_kind_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_268, false); A_arbace_classes_interp_kind_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_25)); return A_arbace_classes_interp__init_part0_A_const_24 }

func A_arbace_classes_interp__init_part0_A_Unit14__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(96, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_26; var tmp2 *jrt.Class; jrt.Long_Init(); tmp2 = jrt.Long_TYPE; var tmp3 any = tmp2.Ref(); var tmp4 *jrt.Class; jrt.Short_Init(); tmp4 = jrt.Short_TYPE; var tmp5 any = tmp4.Ref(); var tmp6 *jrt.Class; jrt.Boolean_Init(); tmp6 = jrt.Boolean_TYPE; var tmp7 any = tmp6.Ref(); var tmp8 *jrt.Class; jrt.Character_Init(); tmp8 = jrt.Character_TYPE; var tmp9 any = tmp8.Ref(); var tmp10 *jrt.Class; jrt.Float_Init(); tmp10 = jrt.Float_TYPE; var tmp11 any = tmp10.Ref(); var tmp12 *jrt.Class; jrt.Byte_Init(); tmp12 = jrt.Byte_TYPE; var tmp13 any = tmp12.Ref(); var tmp14 *jrt.Class; jrt.Void_Init(); tmp14 = jrt.Void_TYPE; var tmp15 any = tmp14.Ref(); var tmp16 *jrt.Class; jrt.Integer_Init(); tmp16 = jrt.Integer_TYPE; var tmp17 any = tmp16.Ref(); var tmp18 *jrt.Class; jrt.Double_Init(); tmp18 = jrt.Double_TYPE; tmp1.BindRoot_O__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, Lit_269, tmp3, Lit_270, tmp5, Lit_6, tmp7, Lit_271, tmp9, Lit_272, tmp11, Lit_273, tmp13, Lit_9, tmp15, Lit_11, tmp17, Lit_274, tmp18.Ref()))); var tmp19 *lang.Var = A_arbace_classes_interp__init_part0_A_const_26; tmp19.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_27)); return A_arbace_classes_interp__init_part0_A_const_26 }



func A_arbace_classes_interp__init_part0_A_Unit15__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(100, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_28; var tmp2 any = A_arbace_classes_interp_desc__GT_class_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_classes_interp_desc__GT_class_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_275, false); A_arbace_classes_interp_desc__GT_class_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_29)); return A_arbace_classes_interp__init_part0_A_const_28 }


















func A_arbace_classes_interp__init_part0_A_Unit16__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(119, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_30; var tmp2 any = A_arbace_classes_interp_internal__GT_class_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_classes_interp_internal__GT_class_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_276, false); A_arbace_classes_interp_internal__GT_class_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_31)); return A_arbace_classes_interp__init_part0_A_const_30 }








func A_arbace_classes_interp__init_part0_A_Unit17__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(128, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_32; var tmp2 any = A_arbace_classes_interp_new_ctx_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_classes_interp_new_ctx_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_277, false); A_arbace_classes_interp_new_ctx_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_33)); return A_arbace_classes_interp__init_part0_A_const_32 }



func A_arbace_classes_interp__init_part0_A_Unit18__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(132, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_34; var tmp2 any = A_arbace_classes_interp_slot_BANG__A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_classes_interp_slot_BANG__A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_278, false); A_arbace_classes_interp_slot_BANG__A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_35)); return A_arbace_classes_interp__init_part0_A_const_34 }






func A_arbace_classes_interp__init_part0_A_Unit19__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(139, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_36; var tmp2 any = A_arbace_classes_interp_bind_BANG__A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_classes_interp_bind_BANG__A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_279, false); A_arbace_classes_interp_bind_BANG__A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_37)); return A_arbace_classes_interp__init_part0_A_const_36 }







func A_arbace_classes_interp__init_part0_A_Unit20__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(147, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_38; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_39)); return A_arbace_classes_interp__init_part0_A_const_38 }
//line :147:1
func A_arbace_classes_interp__init_part0_A_Unit21__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(147, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_40; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_41)); return A_arbace_classes_interp__init_part0_A_const_40 }

func A_arbace_classes_interp__init_part0_A_Unit22__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(149, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_42; var tmp2 any = A_arbace_classes_interp_konst_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_classes_interp_konst_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_280, false); A_arbace_classes_interp_konst_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_43)); return A_arbace_classes_interp__init_part0_A_const_42 }

func A_arbace_classes_interp__init_part0_A_Unit23__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(151, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_44; var tmp2 any = A_arbace_classes_interp_nodes_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_classes_interp_nodes_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_281, false); A_arbace_classes_interp_nodes_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_45)); return A_arbace_classes_interp__init_part0_A_const_44 }


func A_arbace_classes_interp__init_part0_A_Unit24__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(154, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_46; var tmp2 any = A_arbace_classes_interp_target_code_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_classes_interp_target_code_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_282, false); A_arbace_classes_interp_target_code_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_47)); return A_arbace_classes_interp__init_part0_A_const_46 }



func A_arbace_classes_interp__init_part0_A_Unit25__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(158, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_48; var tmp2 any = A_arbace_classes_interp_instance_fields_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_classes_interp_instance_fields_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_283, false); A_arbace_classes_interp_instance_fields_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_49)); return A_arbace_classes_interp__init_part0_A_const_48 }





func A_arbace_classes_interp__init_part0_A_Unit26__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(164, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_50; var tmp2 any = A_arbace_classes_interp_field_index_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_classes_interp_field_index_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_284, false); A_arbace_classes_interp_field_index_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_51)); return A_arbace_classes_interp__init_part0_A_const_50 }








func A_arbace_classes_interp__init_part0_A_Unit27__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(173, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_52; var tmp2 any = A_arbace_classes_interp_static_index_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_classes_interp_static_index_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_285, false); A_arbace_classes_interp_static_index_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_53)); return A_arbace_classes_interp__init_part0_A_const_52 }


func A_arbace_classes_interp__init_part0_A_Unit28__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(176, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_54; var tmp2 any = A_arbace_classes_interp_find_static_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_classes_interp_find_static_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_286, false); A_arbace_classes_interp_find_static_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_55)); return A_arbace_classes_interp__init_part0_A_const_54 }











func A_arbace_classes_interp__init_part0_A_Unit29__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(188, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_56; var tmp2 any = A_arbace_classes_interp_params_of_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_classes_interp_params_of_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_287, false); A_arbace_classes_interp_params_of_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_57)); return A_arbace_classes_interp__init_part0_A_const_56 }

func A_arbace_classes_interp__init_part0_A_Unit30__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(190, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_58; var tmp2 any = A_arbace_classes_interp_find_method_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_classes_interp_find_method_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_288, false); A_arbace_classes_interp_find_method_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_59)); return A_arbace_classes_interp__init_part0_A_const_58 }












func A_arbace_classes_interp__init_part0_A_Unit31__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(203, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_60; var tmp2 any = A_arbace_classes_interp_real_method_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_classes_interp_real_method_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_289, false); A_arbace_classes_interp_real_method_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_61)); return A_arbace_classes_interp__init_part0_A_const_60 }












func A_arbace_classes_interp__init_part0_A_Unit32__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(216, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_62; var tmp2 any = A_arbace_classes_interp_find_field_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_classes_interp_find_field_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_290, false); A_arbace_classes_interp_find_field_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_63)); return A_arbace_classes_interp__init_part0_A_const_62 }









func A_arbace_classes_interp__init_part0_A_Unit33__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(226, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_64; var tmp2 any = A_arbace_classes_interp_local_node_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_classes_interp_local_node_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_291, false); A_arbace_classes_interp_local_node_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_65)); return A_arbace_classes_interp__init_part0_A_const_64 }



















func A_arbace_classes_interp__init_part0_A_Unit34__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(246, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_66; var tmp2 any = A_arbace_classes_interp_convert_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_classes_interp_convert_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_292, false); A_arbace_classes_interp_convert_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_67)); return A_arbace_classes_interp__init_part0_A_const_66 }













func A_arbace_classes_interp__init_part0_A_Unit35__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(260, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_40; var tmp2 any = A_arbace_classes_interp_coerce_A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_classes_interp_coerce_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_293, false); A_arbace_classes_interp_coerce_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_68)); return A_arbace_classes_interp__init_part0_A_const_40 }






func A_arbace_classes_interp__init_part0_A_Unit36__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(267, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_69; var tmp2 any = A_arbace_classes_interp_value_convert_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_classes_interp_value_convert_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_294, false); A_arbace_classes_interp_value_convert_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_70)); return A_arbace_classes_interp__init_part0_A_const_69 }



















func A_arbace_classes_interp__init_part0_A_Unit37__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(287, 1); A_arbace_classes_interp__init_part0_A_const_71.BindRoot_O__V(A_arbace_classes_interp__init_part0_A_const_72); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_71; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_73)); return A_arbace_classes_interp__init_part0_A_const_71 }



func A_arbace_classes_interp__init_part0_A_Unit38__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(291, 1); A_arbace_classes_interp__init_part0_A_const_74.BindRoot_O__V(A_arbace_classes_interp__init_part0_A_const_75); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_74; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_76)); return A_arbace_classes_interp__init_part0_A_const_74 }

func A_arbace_classes_interp__init_part0_A_Unit39__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(293, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_77; var tmp2 any = A_arbace_classes_interp_vt_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_classes_interp_vt_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_295, false); A_arbace_classes_interp_vt_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_77; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_78)); return A_arbace_classes_interp__init_part0_A_const_77 }

func A_arbace_classes_interp__init_part0_A_Unit40__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(295, 1); var v__1927000386__auto____1 any; var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_79; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_80)); v__1927000386__auto____1 = A_arbace_classes_interp__init_part0_A_const_79; var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { tmp2 = lang.MultiFn_InstanceOf(lang.IFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()).Invoke_O__O(v__1927000386__auto____1)) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { var tmp3 *lang.Var = A_arbace_classes_interp__init_part0_A_const_79; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_84)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_79; var tmp5 *jrt.String = Lit_296; var tmp6 any = A_arbace_classes_interp_eval393000075_fn__393000076_A_New(); var tmp7 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_classes_interp_eval393000075_fn__393000076_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_297, false); A_arbace_classes_interp_eval393000075_fn__393000076_A_fn_class = fncls__31d; tmp7 = fncls__31d } else { tmp7 = fncls__31 }; var tmp8 lang.IFn = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp9 any = A_arbace_classes_interp__init_part0_A_const_82; tmp4.BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp5, tmp8, tmp9, A_arbace_classes_interp__init_part0_A_const_83)); return A_arbace_classes_interp__init_part0_A_const_79 } }

func A_arbace_classes_interp__init_part0_A_Unit41__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(297, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_38; var tmp2 any = A_arbace_classes_interp_node_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_classes_interp_node_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_298, false); A_arbace_classes_interp_node_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_85)); return A_arbace_classes_interp__init_part0_A_const_38 }




func A_arbace_classes_interp__init_part0_A_Unit42__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(302, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_82; var tmp3 any = A_arbace_classes_interp_eval393000080_fn__393000081_A_New(); var tmp4 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_classes_interp_eval393000080_fn__393000081_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_299, false); A_arbace_classes_interp_eval393000080_fn__393000081_A_fn_class = fncls__33d; tmp4 = fncls__33d } else { tmp4 = fncls__33 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_classes_interp__init_part0_A_Unit43__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(305, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_86; var tmp3 any = A_arbace_classes_interp_eval393000084_fn__393000085_A_New(); var tmp4 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_classes_interp_eval393000084_fn__393000085_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_300, false); A_arbace_classes_interp_eval393000084_fn__393000085_A_fn_class = fncls__34d; tmp4 = fncls__34d } else { tmp4 = fncls__34 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_classes_interp__init_part0_A_Unit44__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(309, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_87; var tmp3 any = A_arbace_classes_interp_eval393000088_fn__393000089_A_New(); var tmp4 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_classes_interp_eval393000088_fn__393000089_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_301, false); A_arbace_classes_interp_eval393000088_fn__393000089_A_fn_class = fncls__35d; tmp4 = fncls__35d } else { tmp4 = fncls__35 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_classes_interp__init_part0_A_Unit45__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(311, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_88; var tmp3 any = A_arbace_classes_interp_eval393000092_fn__393000093_A_New(); var tmp4 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_classes_interp_eval393000092_fn__393000093_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_302, false); A_arbace_classes_interp_eval393000092_fn__393000093_A_fn_class = fncls__36d; tmp4 = fncls__36d } else { tmp4 = fncls__36 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_classes_interp__init_part0_A_Unit46__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(313, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_89; var tmp3 any = A_arbace_classes_interp_eval393000096_fn__393000097_A_New(); var tmp4 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_classes_interp_eval393000096_fn__393000097_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_303, false); A_arbace_classes_interp_eval393000096_fn__393000097_A_fn_class = fncls__37d; tmp4 = fncls__37d } else { tmp4 = fncls__37 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }




func A_arbace_classes_interp__init_part0_A_Unit47__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(318, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_90; var tmp2 any = A_arbace_classes_interp_this0_index_A_New(); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_classes_interp_this0_index_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_304, false); A_arbace_classes_interp_this0_index_A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_90; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_91)); return A_arbace_classes_interp__init_part0_A_const_90 }






func A_arbace_classes_interp__init_part0_A_Unit48__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(325, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_92; var tmp3 any = A_arbace_classes_interp_eval393000104_fn__393000105_A_New(); var tmp4 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_classes_interp_eval393000104_fn__393000105_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_305, false); A_arbace_classes_interp_eval393000104_fn__393000105_A_fn_class = fncls__39d; tmp4 = fncls__39d } else { tmp4 = fncls__39 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_classes_interp__init_part0_A_Unit49__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(331, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_93; var tmp3 any = A_arbace_classes_interp_eval393000108_fn__393000109_A_New(); var tmp4 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_classes_interp_eval393000108_fn__393000109_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_306, false); A_arbace_classes_interp_eval393000108_fn__393000109_A_fn_class = fncls__40d; tmp4 = fncls__40d } else { tmp4 = fncls__40 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_classes_interp__init_part0_A_Unit50__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(334, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_94; var tmp3 any = A_arbace_classes_interp_eval393000112_fn__393000113_A_New(); var tmp4 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_classes_interp_eval393000112_fn__393000113_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_307, false); A_arbace_classes_interp_eval393000112_fn__393000113_A_fn_class = fncls__41d; tmp4 = fncls__41d } else { tmp4 = fncls__41 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_classes_interp__init_part0_A_Unit51__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(340, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_95; var tmp3 any = A_arbace_classes_interp_eval393000116_fn__393000117_A_New(); var tmp4 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_classes_interp_eval393000116_fn__393000117_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_308, false); A_arbace_classes_interp_eval393000116_fn__393000117_A_fn_class = fncls__42d; tmp4 = fncls__42d } else { tmp4 = fncls__42 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_classes_interp__init_part0_A_Unit52__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(343, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_96; var tmp3 any = A_arbace_classes_interp_eval393000120_fn__393000121_A_New(); var tmp4 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_classes_interp_eval393000120_fn__393000121_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_309, false); A_arbace_classes_interp_eval393000120_fn__393000121_A_fn_class = fncls__43d; tmp4 = fncls__43d } else { tmp4 = fncls__43 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_classes_interp__init_part0_A_Unit53__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(346, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_97; var tmp3 any = A_arbace_classes_interp_eval393000124_fn__393000125_A_New(); var tmp4 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_classes_interp_eval393000124_fn__393000125_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_310, false); A_arbace_classes_interp_eval393000124_fn__393000125_A_fn_class = fncls__44d; tmp4 = fncls__44d } else { tmp4 = fncls__44 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_classes_interp__init_part0_A_Unit54__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(353, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_98; var tmp3 any = A_arbace_classes_interp_eval393000128_fn__393000129_A_New(); var tmp4 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_classes_interp_eval393000128_fn__393000129_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_311, false); A_arbace_classes_interp_eval393000128_fn__393000129_A_fn_class = fncls__45d; tmp4 = fncls__45d } else { tmp4 = fncls__45 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }




func A_arbace_classes_interp__init_part0_A_Unit55__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(358, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_99; var tmp3 any = A_arbace_classes_interp_eval393000132_fn__393000133_A_New(); var tmp4 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_classes_interp_eval393000132_fn__393000133_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_312, false); A_arbace_classes_interp_eval393000132_fn__393000133_A_fn_class = fncls__46d; tmp4 = fncls__46d } else { tmp4 = fncls__46 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }











func A_arbace_classes_interp__init_part0_A_Unit56__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(370, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_100; var tmp3 any = A_arbace_classes_interp_eval393000142_fn__393000143_A_New(); var tmp4 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_classes_interp_eval393000142_fn__393000143_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_313, false); A_arbace_classes_interp_eval393000142_fn__393000143_A_fn_class = fncls__47d; tmp4 = fncls__47d } else { tmp4 = fncls__47 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }




func A_arbace_classes_interp__init_part0_A_Unit57__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(375, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_101; var tmp3 any = A_arbace_classes_interp_eval393000148_fn__393000149_A_New(); var tmp4 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_classes_interp_eval393000148_fn__393000149_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_314, false); A_arbace_classes_interp_eval393000148_fn__393000149_A_fn_class = fncls__48d; tmp4 = fncls__48d } else { tmp4 = fncls__48 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_classes_interp__init_part0_A_Unit58__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(376, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_102; var tmp3 any = A_arbace_classes_interp_eval393000152_fn__393000153_A_New(); var tmp4 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_classes_interp_eval393000152_fn__393000153_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_315, false); A_arbace_classes_interp_eval393000152_fn__393000153_A_fn_class = fncls__49d; tmp4 = fncls__49d } else { tmp4 = fncls__49 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_classes_interp__init_part0_A_Unit59__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(377, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_103; var tmp3 any = A_arbace_classes_interp_eval393000156_fn__393000157_A_New(); var tmp4 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_classes_interp_eval393000156_fn__393000157_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_316, false); A_arbace_classes_interp_eval393000156_fn__393000157_A_fn_class = fncls__50d; tmp4 = fncls__50d } else { tmp4 = fncls__50 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_classes_interp__init_part0_A_Unit60__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(379, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_104; var tmp3 any = A_arbace_classes_interp_eval393000160_fn__393000161_A_New(); var tmp4 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_classes_interp_eval393000160_fn__393000161_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_317, false); A_arbace_classes_interp_eval393000160_fn__393000161_A_fn_class = fncls__51d; tmp4 = fncls__51d } else { tmp4 = fncls__51 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_classes_interp__init_part0_A_Unit61__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(382, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_105; var tmp2 any = A_arbace_classes_interp_and_or_A_New(); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_classes_interp_and_or_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_318, false); A_arbace_classes_interp_and_or_A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_105; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_106)); return A_arbace_classes_interp__init_part0_A_const_105 }




func A_arbace_classes_interp__init_part0_A_Unit62__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(387, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_107; var tmp3 any = A_arbace_classes_interp_eval393000168_fn__393000169_A_New(); var tmp4 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_classes_interp_eval393000168_fn__393000169_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_319, false); A_arbace_classes_interp_eval393000168_fn__393000169_A_fn_class = fncls__53d; tmp4 = fncls__53d } else { tmp4 = fncls__53 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_classes_interp__init_part0_A_Unit63__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(388, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_108; var tmp3 any = A_arbace_classes_interp_eval393000172_fn__393000173_A_New(); var tmp4 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_classes_interp_eval393000172_fn__393000173_A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_320, false); A_arbace_classes_interp_eval393000172_fn__393000173_A_fn_class = fncls__54d; tmp4 = fncls__54d } else { tmp4 = fncls__54 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_classes_interp__init_part0_A_Unit64__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(390, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_109; var tmp3 any = A_arbace_classes_interp_eval393000176_fn__393000177_A_New(); var tmp4 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_classes_interp_eval393000176_fn__393000177_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_321, false); A_arbace_classes_interp_eval393000176_fn__393000177_A_fn_class = fncls__55d; tmp4 = fncls__55d } else { tmp4 = fncls__55 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }




func A_arbace_classes_interp__init_part0_A_Unit65__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(395, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_110; var tmp3 any = A_arbace_classes_interp_eval393000183_fn__393000184_A_New(); var tmp4 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_classes_interp_eval393000183_fn__393000184_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_322, false); A_arbace_classes_interp_eval393000183_fn__393000184_A_fn_class = fncls__56d; tmp4 = fncls__56d } else { tmp4 = fncls__56 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_classes_interp__init_part0_A_Unit66__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(398, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_111; var tmp2 any = A_arbace_classes_interp_let_node_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_classes_interp_let_node_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_323, false); A_arbace_classes_interp_let_node_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_111; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_112)); return A_arbace_classes_interp__init_part0_A_const_111 }

























func A_arbace_classes_interp__init_part0_A_Unit67__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(424, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_113; var tmp3 any = A_arbace_classes_interp_eval393000211_fn__393000212_A_New(); var tmp4 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_classes_interp_eval393000211_fn__393000212_A_fn_class; if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_324, false); A_arbace_classes_interp_eval393000211_fn__393000212_A_fn_class = fncls__58d; tmp4 = fncls__58d } else { tmp4 = fncls__58 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_classes_interp__init_part0_A_Unit68__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(425, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_114; var tmp3 any = A_arbace_classes_interp_eval393000215_fn__393000216_A_New(); var tmp4 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_classes_interp_eval393000215_fn__393000216_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_325, false); A_arbace_classes_interp_eval393000215_fn__393000216_A_fn_class = fncls__59d; tmp4 = fncls__59d } else { tmp4 = fncls__59 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_classes_interp__init_part0_A_Unit69__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(427, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_115; var tmp3 any = A_arbace_classes_interp_eval393000219_fn__393000220_A_New(); var tmp4 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_classes_interp_eval393000219_fn__393000220_A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_326, false); A_arbace_classes_interp_eval393000219_fn__393000220_A_fn_class = fncls__60d; tmp4 = fncls__60d } else { tmp4 = fncls__60 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_classes_interp__init_part0_A_Unit70__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(433, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_116; var tmp3 any = A_arbace_classes_interp_eval393000223_fn__393000224_A_New(); var tmp4 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_classes_interp_eval393000223_fn__393000224_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_327, false); A_arbace_classes_interp_eval393000223_fn__393000224_A_fn_class = fncls__61d; tmp4 = fncls__61d } else { tmp4 = fncls__61 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }








func A_arbace_classes_interp__init_part0_A_Unit71__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(442, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_117; var tmp3 any = A_arbace_classes_interp_eval393000227_fn__393000228_A_New(); var tmp4 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_classes_interp_eval393000227_fn__393000228_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_328, false); A_arbace_classes_interp_eval393000227_fn__393000228_A_fn_class = fncls__62d; tmp4 = fncls__62d } else { tmp4 = fncls__62 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_classes_interp__init_part0_A_Unit72__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(448, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_118; var tmp3 any = A_arbace_classes_interp_eval393000233_fn__393000234_A_New(); var tmp4 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_classes_interp_eval393000233_fn__393000234_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_329, false); A_arbace_classes_interp_eval393000233_fn__393000234_A_fn_class = fncls__63d; tmp4 = fncls__63d } else { tmp4 = fncls__63 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_classes_interp__init_part0_A_Unit73__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(455, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_119; var tmp3 any = A_arbace_classes_interp_eval393000237_fn__393000238_A_New(); var tmp4 *jrt.Class; var fncls__64 *jrt.Class = A_arbace_classes_interp_eval393000237_fn__393000238_A_fn_class; if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_330, false); A_arbace_classes_interp_eval393000237_fn__393000238_A_fn_class = fncls__64d; tmp4 = fncls__64d } else { tmp4 = fncls__64 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_classes_interp__init_part0_A_Unit74__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(457, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_120; var tmp3 any = A_arbace_classes_interp_eval393000241_fn__393000242_A_New(); var tmp4 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_classes_interp_eval393000241_fn__393000242_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_331, false); A_arbace_classes_interp_eval393000241_fn__393000242_A_fn_class = fncls__65d; tmp4 = fncls__65d } else { tmp4 = fncls__65 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


















func A_arbace_classes_interp__init_part0_A_Unit75__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(476, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_121; var tmp3 any = A_arbace_classes_interp_eval393000282_fn__393000283_A_New(); var tmp4 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_classes_interp_eval393000282_fn__393000283_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_332, false); A_arbace_classes_interp_eval393000282_fn__393000283_A_fn_class = fncls__66d; tmp4 = fncls__66d } else { tmp4 = fncls__66 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_classes_interp__init_part0_A_Unit76__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(480, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_122; var tmp3 any = A_arbace_classes_interp_eval393000286_fn__393000287_A_New(); var tmp4 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_classes_interp_eval393000286_fn__393000287_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_333, false); A_arbace_classes_interp_eval393000286_fn__393000287_A_fn_class = fncls__67d; tmp4 = fncls__67d } else { tmp4 = fncls__67 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_classes_interp__init_part0_A_Unit77__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(487, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_123; var tmp2 any = A_arbace_classes_interp_arg_nodes_A_New(); var tmp3 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_classes_interp_arg_nodes_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_334, false); A_arbace_classes_interp_arg_nodes_A_fn_class = fncls__68d; tmp3 = fncls__68d } else { tmp3 = fncls__68 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_123; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_124)); return A_arbace_classes_interp__init_part0_A_const_123 }


func A_arbace_classes_interp__init_part0_A_Unit78__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(490, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_125; var tmp2 any = A_arbace_classes_interp_ptypes_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_classes_interp_ptypes_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_335, false); A_arbace_classes_interp_ptypes_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_125; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_126)); return A_arbace_classes_interp__init_part0_A_const_125 }

func A_arbace_classes_interp__init_part0_A_Unit79__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(492, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_127; var tmp2 any = A_arbace_classes_interp_method_of_A_New(); var tmp3 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_classes_interp_method_of_A_fn_class; if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_336, false); A_arbace_classes_interp_method_of_A_fn_class = fncls__70d; tmp3 = fncls__70d } else { tmp3 = fncls__70 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_127; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_128)); return A_arbace_classes_interp__init_part0_A_const_127 }








func A_arbace_classes_interp__init_part0_A_Unit80__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(501, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_129; var tmp3 any = A_arbace_classes_interp_eval393000298_fn__393000299_A_New(); var tmp4 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_classes_interp_eval393000298_fn__393000299_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_337, false); A_arbace_classes_interp_eval393000298_fn__393000299_A_fn_class = fncls__71d; tmp4 = fncls__71d } else { tmp4 = fncls__71 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






































func A_arbace_classes_interp__init_part0_A_Unit81__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(540, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_130; var tmp2 any = A_arbace_classes_interp_ctor_meth_A_New(); var tmp3 *jrt.Class; var fncls__72 *jrt.Class = A_arbace_classes_interp_ctor_meth_A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_338, false); A_arbace_classes_interp_ctor_meth_A_fn_class = fncls__72d; tmp3 = fncls__72d } else { tmp3 = fncls__72 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_130; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_131)); return A_arbace_classes_interp__init_part0_A_const_130 }


func A_arbace_classes_interp__init_part0_A_Unit82__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(543, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_132; var tmp2 any = A_arbace_classes_interp_implicit_fields_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_classes_interp_implicit_fields_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_339, false); A_arbace_classes_interp_implicit_fields_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_132; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_133)); return A_arbace_classes_interp__init_part0_A_const_132 }












func A_arbace_classes_interp__init_part0_A_Unit83__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(556, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_134; var tmp2 any = A_arbace_classes_interp_super_outer_fields_A_New(); var tmp3 *jrt.Class; var fncls__74 *jrt.Class = A_arbace_classes_interp_super_outer_fields_A_fn_class; if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_340, false); A_arbace_classes_interp_super_outer_fields_A_fn_class = fncls__74d; tmp3 = fncls__74d } else { tmp3 = fncls__74 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_134; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_135)); return A_arbace_classes_interp__init_part0_A_const_134 }















func A_arbace_classes_interp__init_part0_A_Unit84__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(572, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_136; var tmp3 any = A_arbace_classes_interp_eval393000319_fn__393000320_A_New(); var tmp4 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_classes_interp_eval393000319_fn__393000320_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_341, false); A_arbace_classes_interp_eval393000319_fn__393000320_A_fn_class = fncls__75d; tmp4 = fncls__75d } else { tmp4 = fncls__75 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





























func A_arbace_classes_interp__init_part0_A_Unit85__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(602, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_137; var tmp2 any = A_arbace_classes_interp_clj_const_value_A_New(); var tmp3 *jrt.Class; var fncls__76 *jrt.Class = A_arbace_classes_interp_clj_const_value_A_fn_class; if fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_342, false); A_arbace_classes_interp_clj_const_value_A_fn_class = fncls__76d; tmp3 = fncls__76d } else { tmp3 = fncls__76 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_137; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_138)); return A_arbace_classes_interp__init_part0_A_const_137 }










func A_arbace_classes_interp__init_part0_A_Unit86__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(613, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_139; var tmp3 any = A_arbace_classes_interp_eval393000341_fn__393000342_A_New(); var tmp4 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_classes_interp_eval393000341_fn__393000342_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_343, false); A_arbace_classes_interp_eval393000341_fn__393000342_A_fn_class = fncls__77d; tmp4 = fncls__77d } else { tmp4 = fncls__77 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }















func A_arbace_classes_interp__init_part0_A_Unit87__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(629, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_140; var tmp3 any = A_arbace_classes_interp_eval393000348_fn__393000349_A_New(); var tmp4 *jrt.Class; var fncls__78 *jrt.Class = A_arbace_classes_interp_eval393000348_fn__393000349_A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_344, false); A_arbace_classes_interp_eval393000348_fn__393000349_A_fn_class = fncls__78d; tmp4 = fncls__78d } else { tmp4 = fncls__78 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }











func A_arbace_classes_interp__init_part0_A_Unit88__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(641, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_141; var tmp3 any = A_arbace_classes_interp_eval393000355_fn__393000356_A_New(); var tmp4 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_classes_interp_eval393000355_fn__393000356_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_345, false); A_arbace_classes_interp_eval393000355_fn__393000356_A_fn_class = fncls__79d; tmp4 = fncls__79d } else { tmp4 = fncls__79 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }











func A_arbace_classes_interp__init_part0_A_Unit89__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(653, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_142; var tmp3 any = A_arbace_classes_interp_eval393000359_fn__393000360_A_New(); var tmp4 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_classes_interp_eval393000359_fn__393000360_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_346, false); A_arbace_classes_interp_eval393000359_fn__393000360_A_fn_class = fncls__80d; tmp4 = fncls__80d } else { tmp4 = fncls__80 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }












func A_arbace_classes_interp__init_part0_A_Unit90__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(666, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_143; var tmp3 any = A_arbace_classes_interp_eval393000363_fn__393000364_A_New(); var tmp4 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_classes_interp_eval393000363_fn__393000364_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_347, false); A_arbace_classes_interp_eval393000363_fn__393000364_A_fn_class = fncls__81d; tmp4 = fncls__81d } else { tmp4 = fncls__81 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_classes_interp__init_part0_A_Unit91__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(673, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_144; var tmp3 any = A_arbace_classes_interp_eval393000368_fn__393000369_A_New(); var tmp4 *jrt.Class; var fncls__82 *jrt.Class = A_arbace_classes_interp_eval393000368_fn__393000369_A_fn_class; if fncls__82 == nil { var fncls__82d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_348, false); A_arbace_classes_interp_eval393000368_fn__393000369_A_fn_class = fncls__82d; tmp4 = fncls__82d } else { tmp4 = fncls__82 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }




func A_arbace_classes_interp__init_part0_A_Unit92__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(678, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_145; var tmp3 any = A_arbace_classes_interp_eval393000374_fn__393000375_A_New(); var tmp4 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_classes_interp_eval393000374_fn__393000375_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_349, false); A_arbace_classes_interp_eval393000374_fn__393000375_A_fn_class = fncls__83d; tmp4 = fncls__83d } else { tmp4 = fncls__83 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_classes_interp__init_part0_A_Unit93__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(684, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_146; var tmp3 any = A_arbace_classes_interp_eval393000379_fn__393000380_A_New(); var tmp4 *jrt.Class; var fncls__84 *jrt.Class = A_arbace_classes_interp_eval393000379_fn__393000380_A_fn_class; if fncls__84 == nil { var fncls__84d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_350, false); A_arbace_classes_interp_eval393000379_fn__393000380_A_fn_class = fncls__84d; tmp4 = fncls__84d } else { tmp4 = fncls__84 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_classes_interp__init_part0_A_Unit94__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(690, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_147; var tmp3 any = A_arbace_classes_interp_eval393000386_fn__393000387_A_New(); var tmp4 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_classes_interp_eval393000386_fn__393000387_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_351, false); A_arbace_classes_interp_eval393000386_fn__393000387_A_fn_class = fncls__85d; tmp4 = fncls__85d } else { tmp4 = fncls__85 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_classes_interp__init_part0_A_Unit95__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(694, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_148; var tmp3 any = A_arbace_classes_interp_eval393000392_fn__393000393_A_New(); var tmp4 *jrt.Class; var fncls__86 *jrt.Class = A_arbace_classes_interp_eval393000392_fn__393000393_A_fn_class; if fncls__86 == nil { var fncls__86d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_352, false); A_arbace_classes_interp_eval393000392_fn__393000393_A_fn_class = fncls__86d; tmp4 = fncls__86d } else { tmp4 = fncls__86 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_classes_interp__init_part0_A_Unit96__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(697, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_149; var tmp3 any = A_arbace_classes_interp_eval393000396_fn__393000397_A_New(); var tmp4 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_classes_interp_eval393000396_fn__393000397_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_353, false); A_arbace_classes_interp_eval393000396_fn__393000397_A_fn_class = fncls__87d; tmp4 = fncls__87d } else { tmp4 = fncls__87 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_classes_interp__init_part0_A_Unit97__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(701, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_150; var tmp3 any = A_arbace_classes_interp_eval393000400_fn__393000401_A_New(); var tmp4 *jrt.Class; var fncls__88 *jrt.Class = A_arbace_classes_interp_eval393000400_fn__393000401_A_fn_class; if fncls__88 == nil { var fncls__88d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_354, false); A_arbace_classes_interp_eval393000400_fn__393000401_A_fn_class = fncls__88d; tmp4 = fncls__88d } else { tmp4 = fncls__88 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_classes_interp__init_part0_A_Unit98__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(703, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_151; var tmp3 any = A_arbace_classes_interp_eval393000404_fn__393000405_A_New(); var tmp4 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_classes_interp_eval393000404_fn__393000405_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_355, false); A_arbace_classes_interp_eval393000404_fn__393000405_A_fn_class = fncls__89d; tmp4 = fncls__89d } else { tmp4 = fncls__89 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }









func A_arbace_classes_interp__init_part0_A_Unit99__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V(713, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_79.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_152; var tmp3 any = A_arbace_classes_interp_eval393000416_fn__393000417_A_New(); var tmp4 *jrt.Class; var fncls__90 *jrt.Class = A_arbace_classes_interp_eval393000416_fn__393000417_A_fn_class; if fncls__90 == nil { var fncls__90d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_356, false); A_arbace_classes_interp_eval393000416_fn__393000417_A_fn_class = fncls__90d; tmp4 = fncls__90d } else { tmp4 = fncls__90 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }




















func A_arbace_classes_interp__init_part1_A_Unit100__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(734, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_0; var tmp2 any = A_arbace_classes_interp_accessor_node_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_classes_interp_accessor_node_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_358, false); A_arbace_classes_interp_accessor_node_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_0; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_1)); return A_arbace_classes_interp__init_part1_A_const_0 }
//line :734:1
func A_arbace_classes_interp__init_part1_A_Init__O() any { A_arbace_classes_interp__init_part1_A_Init(); return nil }
//line :734:1
func A_arbace_classes_interp__init_part1_A_Load__O() any { A_arbace_classes_interp__init_part1_A_Init(); A_arbace_classes_interp__init_part1_A_Unit100__O(); A_arbace_classes_interp__init_part1_A_Unit101__O(); A_arbace_classes_interp__init_part1_A_Unit102__O(); A_arbace_classes_interp__init_part1_A_Unit103__O(); A_arbace_classes_interp__init_part1_A_Unit104__O(); A_arbace_classes_interp__init_part1_A_Unit105__O(); A_arbace_classes_interp__init_part1_A_Unit106__O(); A_arbace_classes_interp__init_part1_A_Unit107__O(); A_arbace_classes_interp__init_part1_A_Unit108__O(); A_arbace_classes_interp__init_part1_A_Unit109__O(); A_arbace_classes_interp__init_part1_A_Unit110__O(); A_arbace_classes_interp__init_part1_A_Unit111__O(); A_arbace_classes_interp__init_part1_A_Unit112__O(); A_arbace_classes_interp__init_part1_A_Unit113__O(); A_arbace_classes_interp__init_part1_A_Unit114__O(); A_arbace_classes_interp__init_part1_A_Unit115__O(); A_arbace_classes_interp__init_part1_A_Unit116__O(); A_arbace_classes_interp__init_part1_A_Unit117__O(); A_arbace_classes_interp__init_part1_A_Unit118__O(); A_arbace_classes_interp__init_part1_A_Unit119__O(); A_arbace_classes_interp__init_part1_A_Unit120__O(); A_arbace_classes_interp__init_part1_A_Unit121__O(); A_arbace_classes_interp__init_part1_A_Unit122__O(); A_arbace_classes_interp__init_part1_A_Unit123__O(); A_arbace_classes_interp__init_part1_A_Unit124__O(); A_arbace_classes_interp__init_part1_A_Unit125__O(); A_arbace_classes_interp__init_part1_A_Unit126__O(); A_arbace_classes_interp__init_part1_A_Unit127__O(); A_arbace_classes_interp__init_part1_A_Unit128__O(); A_arbace_classes_interp__init_part1_A_Unit129__O(); A_arbace_classes_interp__init_part1_A_Unit130__O(); A_arbace_classes_interp__init_part1_A_Unit131__O(); A_arbace_classes_interp__init_part1_A_Unit132__O(); A_arbace_classes_interp__init_part1_A_Unit133__O(); A_arbace_classes_interp__init_part1_A_Unit134__O(); A_arbace_classes_interp__init_part1_A_Unit135__O(); A_arbace_classes_interp__init_part1_A_Unit136__O(); A_arbace_classes_interp__init_part1_A_Unit137__O(); A_arbace_classes_interp__init_part1_A_Unit138__O(); A_arbace_classes_interp__init_part1_A_Unit139__O(); A_arbace_classes_interp__init_part1_A_Unit140__O(); A_arbace_classes_interp__init_part1_A_Unit141__O(); A_arbace_classes_interp__init_part1_A_Unit142__O(); A_arbace_classes_interp__init_part1_A_Unit143__O(); A_arbace_classes_interp__init_part1_A_Unit144__O(); A_arbace_classes_interp__init_part1_A_Unit145__O(); A_arbace_classes_interp__init_part1_A_Unit146__O(); A_arbace_classes_interp__init_part1_A_Unit147__O(); A_arbace_classes_interp__init_part1_A_Unit148__O(); A_arbace_classes_interp__init_part1_A_Unit149__O(); return nil }










func A_arbace_classes_interp__init_part1_A_Unit101__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(745, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_2; var tmp2 any = A_arbace_classes_interp_pattern_A_New(); var tmp3 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_classes_interp_pattern_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_359, false); A_arbace_classes_interp_pattern_A_fn_class = fncls__2d; tmp3 = fncls__2d } else { tmp3 = fncls__2 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_3)); return A_arbace_classes_interp__init_part1_A_const_2 }



















func A_arbace_classes_interp__init_part1_A_Unit102__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(765, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part1_A_const_4.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part1_A_const_5; var tmp3 any = A_arbace_classes_interp_eval393000429_fn__393000430_A_New(); var tmp4 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_classes_interp_eval393000429_fn__393000430_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_360, false); A_arbace_classes_interp_eval393000429_fn__393000430_A_fn_class = fncls__3d; tmp4 = fncls__3d } else { tmp4 = fncls__3 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_classes_interp__init_part1_A_Unit103__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(772, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part1_A_const_4.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part1_A_const_6; var tmp3 any = A_arbace_classes_interp_eval393000435_fn__393000436_A_New(); var tmp4 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_classes_interp_eval393000435_fn__393000436_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_361, false); A_arbace_classes_interp_eval393000435_fn__393000436_A_fn_class = fncls__4d; tmp4 = fncls__4d } else { tmp4 = fncls__4 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }




































func A_arbace_classes_interp__init_part1_A_Unit104__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(809, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_7; var tmp2 any = A_arbace_classes_interp_has_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_classes_interp_has_QMARK__A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_362, false); A_arbace_classes_interp_has_QMARK__A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_7; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_8)); return A_arbace_classes_interp__init_part1_A_const_7 }
func A_arbace_classes_interp__init_part1_A_Unit105__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(810, 1); A_arbace_classes_interp__init_part1_A_const_9.BindRoot_O__V(A_arbace_classes_interp__init_part1_A_const_10); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_9; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_11)); return A_arbace_classes_interp__init_part1_A_const_9 }
func A_arbace_classes_interp__init_part1_A_Unit106__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(811, 1); A_arbace_classes_interp__init_part1_A_const_12.BindRoot_O__V(A_arbace_classes_interp__init_part1_A_const_13); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_12; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_14)); return A_arbace_classes_interp__init_part1_A_const_12 }
func A_arbace_classes_interp__init_part1_A_Unit107__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(812, 1); A_arbace_classes_interp__init_part1_A_const_15.BindRoot_O__V(A_arbace_classes_interp__init_part1_A_const_16); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_15; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_17)); return A_arbace_classes_interp__init_part1_A_const_15 }
func A_arbace_classes_interp__init_part1_A_Unit108__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(813, 1); A_arbace_classes_interp__init_part1_A_const_18.BindRoot_O__V(A_arbace_classes_interp__init_part1_A_const_19); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_18; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_20)); return A_arbace_classes_interp__init_part1_A_const_18 }

func A_arbace_classes_interp__init_part1_A_Unit109__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(815, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_21; var tmp2 any = A_arbace_classes_interp_host_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_classes_interp_host_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_363, false); A_arbace_classes_interp_host_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_22)); return A_arbace_classes_interp__init_part1_A_const_21 }

func A_arbace_classes_interp__init_part1_A_Unit110__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(817, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_23; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_24)); return A_arbace_classes_interp__init_part1_A_const_23 }
//line :817:1
func A_arbace_classes_interp__init_part1_A_Unit111__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(817, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_25; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_26)); return A_arbace_classes_interp__init_part1_A_const_25 }

func A_arbace_classes_interp__init_part1_A_Unit112__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(819, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_27; var tmp2 any = A_arbace_classes_interp_meth_of_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_classes_interp_meth_of_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_364, false); A_arbace_classes_interp_meth_of_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_28)); return A_arbace_classes_interp__init_part1_A_const_27 }









func A_arbace_classes_interp__init_part1_A_Unit113__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(829, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_29; var tmp2 any = A_arbace_classes_interp_zero_of_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_classes_interp_zero_of_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_365, false); A_arbace_classes_interp_zero_of_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_30)); return A_arbace_classes_interp__init_part1_A_const_29 }

func A_arbace_classes_interp__init_part1_A_Unit114__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(831, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_31; var tmp2 any = A_arbace_classes_interp_make_klass_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_classes_interp_make_klass_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_366, false); A_arbace_classes_interp_make_klass_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_31; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_32)); return A_arbace_classes_interp__init_part1_A_const_31 }











func A_arbace_classes_interp__init_part1_A_Unit115__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(843, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_33; var tmp2 any = A_arbace_classes_interp_layout_BANG__A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_classes_interp_layout_BANG__A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_367, false); A_arbace_classes_interp_layout_BANG__A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_33; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_34)); return A_arbace_classes_interp__init_part1_A_const_33 }
























































func A_arbace_classes_interp__init_part1_A_Unit116__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(900, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_35; var tmp2 any = A_arbace_classes_interp_vtable_BANG__A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_classes_interp_vtable_BANG__A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_368, false); A_arbace_classes_interp_vtable_BANG__A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_35; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_36)); return A_arbace_classes_interp__init_part1_A_const_35 }

















func A_arbace_classes_interp__init_part1_A_Unit117__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(918, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_37; var tmp2 any = A_arbace_classes_interp_ctx_for_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_classes_interp_ctx_for_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_369, false); A_arbace_classes_interp_ctx_for_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_38)); return A_arbace_classes_interp__init_part1_A_const_37 }







func A_arbace_classes_interp__init_part1_A_Unit118__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(926, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_39; var tmp2 any = A_arbace_classes_interp_receiver_ctx_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_classes_interp_receiver_ctx_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_370, false); A_arbace_classes_interp_receiver_ctx_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_40)); return A_arbace_classes_interp__init_part1_A_const_39 }




func A_arbace_classes_interp__init_part1_A_Unit119__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(931, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_41; var tmp2 any = A_arbace_classes_interp_params_BANG__A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_classes_interp_params_BANG__A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_371, false); A_arbace_classes_interp_params_BANG__A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_42)); return A_arbace_classes_interp__init_part1_A_const_41 }




func A_arbace_classes_interp__init_part1_A_Unit120__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(936, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_43; var tmp2 any = A_arbace_classes_interp_finish_BANG__A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_classes_interp_finish_BANG__A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_372, false); A_arbace_classes_interp_finish_BANG__A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_44)); return A_arbace_classes_interp__init_part1_A_const_43 }





func A_arbace_classes_interp__init_part1_A_Unit121__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(942, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_45; var tmp2 any = A_arbace_classes_interp_record_op_node_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_classes_interp_record_op_node_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_373, false); A_arbace_classes_interp_record_op_node_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_46)); return A_arbace_classes_interp__init_part1_A_const_45 }








func A_arbace_classes_interp__init_part1_A_Unit122__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(951, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_47; var tmp2 any = A_arbace_classes_interp_derived_body_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_classes_interp_derived_body_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_374, false); A_arbace_classes_interp_derived_body_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_48)); return A_arbace_classes_interp__init_part1_A_const_47 }














































func A_arbace_classes_interp__init_part1_A_Unit123__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(998, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_49; var tmp2 any = A_arbace_classes_interp_init_nodes_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_classes_interp_init_nodes_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_375, false); A_arbace_classes_interp_init_nodes_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_50)); return A_arbace_classes_interp__init_part1_A_const_49 }




func A_arbace_classes_interp__init_part1_A_Unit124__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1003, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_51; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_52)); return A_arbace_classes_interp__init_part1_A_const_51 }

func A_arbace_classes_interp__init_part1_A_Unit125__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1005, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_53; var tmp2 any = A_arbace_classes_interp_trivial_super_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_classes_interp_trivial_super_QMARK__A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_376, false); A_arbace_classes_interp_trivial_super_QMARK__A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_54)); return A_arbace_classes_interp__init_part1_A_const_53 }






func A_arbace_classes_interp__init_part1_A_Unit126__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1012, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_55; var tmp2 any = A_arbace_classes_interp_ctor_call_node_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_classes_interp_ctor_call_node_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_377, false); A_arbace_classes_interp_ctor_call_node_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_56)); return A_arbace_classes_interp__init_part1_A_const_55 }












































func A_arbace_classes_interp__init_part1_A_Unit127__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1057, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_51; var tmp2 any = A_arbace_classes_interp_enum_arg_nodes_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_classes_interp_enum_arg_nodes_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_378, false); A_arbace_classes_interp_enum_arg_nodes_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_57)); return A_arbace_classes_interp__init_part1_A_const_51 }






func A_arbace_classes_interp__init_part1_A_Unit128__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1064, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part1_A_const_4.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part1_A_const_58; var tmp3 any = A_arbace_classes_interp_eval393000702_fn__393000703_A_New(); var tmp4 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_classes_interp_eval393000702_fn__393000703_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_379, false); A_arbace_classes_interp_eval393000702_fn__393000703_A_fn_class = fncls__22d; tmp4 = fncls__22d } else { tmp4 = fncls__22 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }




func A_arbace_classes_interp__init_part1_A_Unit129__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1069, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_23; var tmp2 any = A_arbace_classes_interp_build_method_BANG__A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_classes_interp_build_method_BANG__A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_380, false); A_arbace_classes_interp_build_method_BANG__A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_59)); return A_arbace_classes_interp__init_part1_A_const_23 }




































































func A_arbace_classes_interp__init_part1_A_Unit130__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1138, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_60; var tmp2 any = A_arbace_classes_interp_declare_siblings_BANG__A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_classes_interp_declare_siblings_BANG__A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_381, false); A_arbace_classes_interp_declare_siblings_BANG__A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_61)); return A_arbace_classes_interp__init_part1_A_const_60 }











func A_arbace_classes_interp__init_part1_A_Unit131__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1150, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_62; var tmp2 any = A_arbace_classes_interp_analyze_forms_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_classes_interp_analyze_forms_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_382, false); A_arbace_classes_interp_analyze_forms_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_63)); return A_arbace_classes_interp__init_part1_A_const_62 }















func A_arbace_classes_interp__init_part1_A_Unit132__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1166, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_64; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_65)); v__1927001498__auto____1 = A_arbace_classes_interp__init_part1_A_const_64; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_classes_interp__init_part1_A_const_64; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_67)); var tmp3 *lang.Var = A_arbace_classes_interp__init_part1_A_const_64; tmp3.BindRoot_O__V(lang.IFn_Cast(A_arbace_classes_interp__init_part1_A_const_66.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_interp__init_part1_A_const_68)); return A_arbace_classes_interp__init_part1_A_const_64 } }

func A_arbace_classes_interp__init_part1_A_Unit133__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1168, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_69; var tmp2 any = A_arbace_classes_interp_new_lambda_klass_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_classes_interp_new_lambda_klass_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_383, false); A_arbace_classes_interp_new_lambda_klass_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_70)); return A_arbace_classes_interp__init_part1_A_const_69 }















func A_arbace_classes_interp__init_part1_A_Unit134__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1184, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_71; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_72)); return A_arbace_classes_interp__init_part1_A_const_71 }
//line :1184:1
func A_arbace_classes_interp__init_part1_A_Unit135__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1184, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_73; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_74)); return A_arbace_classes_interp__init_part1_A_const_73 }

func A_arbace_classes_interp__init_part1_A_Unit136__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1186, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_75; var tmp2 any = A_arbace_classes_interp_lambda_done_BANG__A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_classes_interp_lambda_done_BANG__A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_384, false); A_arbace_classes_interp_lambda_done_BANG__A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_75; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_76)); return A_arbace_classes_interp__init_part1_A_const_75 }









func A_arbace_classes_interp__init_part1_A_Unit137__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1196, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part1_A_const_4.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part1_A_const_77; var tmp3 any = A_arbace_classes_interp_eval393000781_fn__393000782_A_New(); var tmp4 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_classes_interp_eval393000781_fn__393000782_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_385, false); A_arbace_classes_interp_eval393000781_fn__393000782_A_fn_class = fncls__28d; tmp4 = fncls__28d } else { tmp4 = fncls__28 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }




















func A_arbace_classes_interp__init_part1_A_Unit138__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1217, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part1_A_const_4.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part1_A_const_78; var tmp3 any = A_arbace_classes_interp_eval393000792_fn__393000793_A_New(); var tmp4 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_classes_interp_eval393000792_fn__393000793_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_386, false); A_arbace_classes_interp_eval393000792_fn__393000793_A_fn_class = fncls__29d; tmp4 = fncls__29d } else { tmp4 = fncls__29 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

















































func A_arbace_classes_interp__init_part1_A_Unit139__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1267, 1); A_arbace_classes_interp__init_part1_A_const_79.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_79; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_80)); return A_arbace_classes_interp__init_part1_A_const_79.SetDynamic_Z__Var(true).Ref() }




func A_arbace_classes_interp__init_part1_A_Unit140__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1272, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_81; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_interp__init_part1_A_const_66.GetRawRoot__O()); var tmp3 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp3 = lang.PersistentArrayMap_EMPTY; tmp1.BindRoot_O__V(tmp2.Invoke_O__O(tmp3.Ref())); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_81; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_82)); return A_arbace_classes_interp__init_part1_A_const_81 }




func A_arbace_classes_interp__init_part1_A_Unit141__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1277, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_83; var tmp2 any = A_arbace_classes_interp_sig_class_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_classes_interp_sig_class_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_387, false); A_arbace_classes_interp_sig_class_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_83; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_84)); return A_arbace_classes_interp__init_part1_A_const_83 }













func A_arbace_classes_interp__init_part1_A_Unit142__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1291, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_85; var tmp2 any = A_arbace_classes_interp_meth_classes_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_classes_interp_meth_classes_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_388, false); A_arbace_classes_interp_meth_classes_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_85; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_86)); return A_arbace_classes_interp__init_part1_A_const_85 }




func A_arbace_classes_interp__init_part1_A_Unit143__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1296, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_71; var tmp2 any = A_arbace_classes_interp_publish_BANG__A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_classes_interp_publish_BANG__A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_389, false); A_arbace_classes_interp_publish_BANG__A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_87)); return A_arbace_classes_interp__init_part1_A_const_71 }










func A_arbace_classes_interp__init_part1_A_Unit144__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1307, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_88; var tmp2 any = A_arbace_classes_interp_republish_BANG__A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_classes_interp_republish_BANG__A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_390, false); A_arbace_classes_interp_republish_BANG__A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_88; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_89)); return A_arbace_classes_interp__init_part1_A_const_88 }











func A_arbace_classes_interp__init_part1_A_Unit145__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1319, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_73; var tmp2 any = A_arbace_classes_interp_publish_members_BANG__A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_classes_interp_publish_members_BANG__A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_391, false); A_arbace_classes_interp_publish_members_BANG__A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_90)); return A_arbace_classes_interp__init_part1_A_const_73 }




















func A_arbace_classes_interp__init_part1_A_Unit146__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1340, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_91; var tmp2 any = A_arbace_classes_interp_clinit_BANG__A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_classes_interp_clinit_BANG__A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_392, false); A_arbace_classes_interp_clinit_BANG__A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_91; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_92)); return A_arbace_classes_interp__init_part1_A_const_91 }


























func A_arbace_classes_interp__init_part1_A_Unit147__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1367, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_93; var tmp2 any = A_arbace_classes_interp_define_BANG__A_New(); var tmp3 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_classes_interp_define_BANG__A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_393, false); A_arbace_classes_interp_define_BANG__A_fn_class = fncls__36d; tmp3 = fncls__36d } else { tmp3 = fncls__36 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_93; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_94)); return A_arbace_classes_interp__init_part1_A_const_93 }


























































func A_arbace_classes_interp__init_part1_A_Unit148__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1426, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_95; var tmp2 any = A_arbace_classes_interp_compile_and_load_BANG__A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_classes_interp_compile_and_load_BANG__A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_394, true); A_arbace_classes_interp_compile_and_load_BANG__A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_95; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_96)); return A_arbace_classes_interp__init_part1_A_const_95 }






func A_arbace_classes_interp__init_part1_A_Unit149__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V(1433, 1); var tmp1 lang.Compiler_CF_Host_I; lang.Compiler_CF_Rt_Init(); tmp1 = lang.Compiler_CF_Rt_HOST; if lang.Util_Identical_O_O__Z(tmp1, nil) { var temp__1927000414__auto____1 any; var tmp2 any = A_arbace_classes_interp_eval393001002_fn__393001003_A_New(); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_classes_interp_eval393001002_fn__393001003_A_fn_class
								if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_395, false); A_arbace_classes_interp_eval393001002_fn__393001003_A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; temp__1927000414__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O(); if jrt.A2g_Truth(temp__1927000414__auto____1) { var c__2 any = temp__1927000414__auto____1
									lang.Compiler_CF_Rt_SetHost_Compiler_CF_Host__V(lang.Compiler_CF_Host_Cast(jrt.NN(jrt.Class_Cast(c__2)).NewInstance__O())); return nil } else {
//line :1434:1
			return nil } } else {
//line :1433:1
				return nil } }





type A_arbace_classes_interp__init_A struct{ jrt.Object }

func A_arbace_classes_interp__init_A_New() *A_arbace_classes_interp__init_A { t := &A_arbace_classes_interp__init_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_interp__init_A) Ctor() {}

func (t *A_arbace_classes_interp__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_interp__init_A) GetClass__Class() *jrt.Class { return A_arbace_classes_interp__init_A_class }

func (t *A_arbace_classes_interp__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_interp__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_interp__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_interp__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_interp__init_A); return ok }

func A_arbace_classes_interp__init_A_Cast(x any) *A_arbace_classes_interp__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_interp__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_interp__init_A_class)) }; return v }



type A_arbace_classes_interp__init_part0_A struct{ jrt.Object }

var A_arbace_classes_interp__init_part0_A_const_pool *jrt.RefArray

var A_arbace_classes_interp__init_part0_A_const_0 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_1 any

var A_arbace_classes_interp__init_part0_A_const_2 any

var A_arbace_classes_interp__init_part0_A_const_3 any

var A_arbace_classes_interp__init_part0_A_const_4 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_5 any

var A_arbace_classes_interp__init_part0_A_const_6 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_7 any

var A_arbace_classes_interp__init_part0_A_const_8 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_9 any

var A_arbace_classes_interp__init_part0_A_const_10 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_11 any

var A_arbace_classes_interp__init_part0_A_const_12 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_13 any

var A_arbace_classes_interp__init_part0_A_const_14 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_15 any

var A_arbace_classes_interp__init_part0_A_const_16 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_17 any

var A_arbace_classes_interp__init_part0_A_const_18 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_19 any

var A_arbace_classes_interp__init_part0_A_const_20 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_21 any

var A_arbace_classes_interp__init_part0_A_const_22 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_23 any

var A_arbace_classes_interp__init_part0_A_const_24 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_25 any

var A_arbace_classes_interp__init_part0_A_const_26 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_27 any

var A_arbace_classes_interp__init_part0_A_const_28 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_29 any

var A_arbace_classes_interp__init_part0_A_const_30 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_31 any

var A_arbace_classes_interp__init_part0_A_const_32 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_33 any

var A_arbace_classes_interp__init_part0_A_const_34 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_35 any

var A_arbace_classes_interp__init_part0_A_const_36 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_37 any

var A_arbace_classes_interp__init_part0_A_const_38 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_39 any

var A_arbace_classes_interp__init_part0_A_const_40 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_41 any

var A_arbace_classes_interp__init_part0_A_const_42 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_43 any

var A_arbace_classes_interp__init_part0_A_const_44 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_45 any

var A_arbace_classes_interp__init_part0_A_const_46 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_47 any

var A_arbace_classes_interp__init_part0_A_const_48 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_49 any

var A_arbace_classes_interp__init_part0_A_const_50 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_51 any

var A_arbace_classes_interp__init_part0_A_const_52 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_53 any

var A_arbace_classes_interp__init_part0_A_const_54 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_55 any

var A_arbace_classes_interp__init_part0_A_const_56 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_57 any

var A_arbace_classes_interp__init_part0_A_const_58 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_59 any

var A_arbace_classes_interp__init_part0_A_const_60 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_61 any

var A_arbace_classes_interp__init_part0_A_const_62 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_63 any

var A_arbace_classes_interp__init_part0_A_const_64 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_65 any

var A_arbace_classes_interp__init_part0_A_const_66 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_67 any

var A_arbace_classes_interp__init_part0_A_const_68 any

var A_arbace_classes_interp__init_part0_A_const_69 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_70 any

var A_arbace_classes_interp__init_part0_A_const_71 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_72 any

var A_arbace_classes_interp__init_part0_A_const_73 any

var A_arbace_classes_interp__init_part0_A_const_74 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_75 any

var A_arbace_classes_interp__init_part0_A_const_76 any

var A_arbace_classes_interp__init_part0_A_const_77 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_78 any

var A_arbace_classes_interp__init_part0_A_const_79 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_80 any

var A_arbace_classes_interp__init_part0_A_const_81 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_82 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_83 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_84 any

var A_arbace_classes_interp__init_part0_A_const_85 any

var A_arbace_classes_interp__init_part0_A_const_86 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_87 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_88 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_89 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_90 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_91 any

var A_arbace_classes_interp__init_part0_A_const_92 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_93 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_94 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_95 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_96 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_97 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_98 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_99 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_100 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_101 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_102 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_103 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_104 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_105 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_106 any

var A_arbace_classes_interp__init_part0_A_const_107 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_108 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_109 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_110 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_111 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_112 any

var A_arbace_classes_interp__init_part0_A_const_113 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_114 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_115 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_116 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_117 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_118 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_119 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_120 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_121 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_122 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_123 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_124 any

var A_arbace_classes_interp__init_part0_A_const_125 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_126 any

var A_arbace_classes_interp__init_part0_A_const_127 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_128 any

var A_arbace_classes_interp__init_part0_A_const_129 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_130 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_131 any

var A_arbace_classes_interp__init_part0_A_const_132 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_133 any

var A_arbace_classes_interp__init_part0_A_const_134 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_135 any

var A_arbace_classes_interp__init_part0_A_const_136 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_137 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_138 any

var A_arbace_classes_interp__init_part0_A_const_139 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_140 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_141 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_142 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_143 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_144 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_145 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_146 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_147 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_148 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_149 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_150 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_151 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_152 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_init jrt.ClassInit

func A_arbace_classes_interp__init_part0_A_Init() { if !A_arbace_classes_interp__init_part0_A_init.Done() { A_arbace_classes_interp__init_part0_A_init.Run(A_arbace_classes_interp__init_part0_A_clinit) } }

func A_arbace_classes_interp__init_part0_A_clinit() { A_arbace_classes_interp__init_part0_A_clinit_p0(); A_arbace_classes_interp__init_part0_A_clinit_p1(); A_arbace_classes_interp__init_part0_A_clinit_p2(); A_arbace_classes_interp__init_part0_A_clinit_p3(); A_arbace_classes_interp__init_part0_A_clinit_p4(); A_arbace_classes_interp__init_part0_A_clinit_p5(); A_arbace_classes_interp__init_part0_A_clinit_p6(); A_arbace_classes_interp__init_part0_A_clinit_p7(); A_arbace_classes_interp__init_part0_A_clinit_p8(); A_arbace_classes_interp__init_part0_A_clinit_p9(); A_arbace_classes_interp__init_part0_A_clinit_p10(); A_arbace_classes_interp__init_part0_A_clinit_p11() }

func A_arbace_classes_interp__init_part0_A_clinit_p0() { A_arbace_classes_interp__init_part0_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_259, 266); A_arbace_classes_interp__init_part0_A_const_0 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[113]); A_arbace_classes_interp__init_part0_A_const_1 = A_arbace_classes_interp__init_part0_A_const_pool.A[114]; A_arbace_classes_interp__init_part0_A_const_2 = A_arbace_classes_interp__init_part0_A_const_pool.A[115]; A_arbace_classes_interp__init_part0_A_const_3 = A_arbace_classes_interp__init_part0_A_const_pool.A[116]; A_arbace_classes_interp__init_part0_A_const_4 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[117]); A_arbace_classes_interp__init_part0_A_const_5 = A_arbace_classes_interp__init_part0_A_const_pool.A[118]; A_arbace_classes_interp__init_part0_A_const_6 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[119]); A_arbace_classes_interp__init_part0_A_const_7 = A_arbace_classes_interp__init_part0_A_const_pool.A[120]; A_arbace_classes_interp__init_part0_A_const_8 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[121]); A_arbace_classes_interp__init_part0_A_const_9 = A_arbace_classes_interp__init_part0_A_const_pool.A[122]; A_arbace_classes_interp__init_part0_A_const_10 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[123]); A_arbace_classes_interp__init_part0_A_const_11 = A_arbace_classes_interp__init_part0_A_const_pool.A[124]; A_arbace_classes_interp__init_part0_A_const_12 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[125]) }

func A_arbace_classes_interp__init_part0_A_clinit_p1() { A_arbace_classes_interp__init_part0_A_const_13 = A_arbace_classes_interp__init_part0_A_const_pool.A[126]; A_arbace_classes_interp__init_part0_A_const_14 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[127]); A_arbace_classes_interp__init_part0_A_const_15 = A_arbace_classes_interp__init_part0_A_const_pool.A[128]; A_arbace_classes_interp__init_part0_A_const_16 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[129]); A_arbace_classes_interp__init_part0_A_const_17 = A_arbace_classes_interp__init_part0_A_const_pool.A[130]; A_arbace_classes_interp__init_part0_A_const_18 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[131]); A_arbace_classes_interp__init_part0_A_const_19 = A_arbace_classes_interp__init_part0_A_const_pool.A[132]; A_arbace_classes_interp__init_part0_A_const_20 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[133]); A_arbace_classes_interp__init_part0_A_const_21 = A_arbace_classes_interp__init_part0_A_const_pool.A[134]; A_arbace_classes_interp__init_part0_A_const_22 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[135]); A_arbace_classes_interp__init_part0_A_const_23 = A_arbace_classes_interp__init_part0_A_const_pool.A[136]; A_arbace_classes_interp__init_part0_A_const_24 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[137]); A_arbace_classes_interp__init_part0_A_const_25 = A_arbace_classes_interp__init_part0_A_const_pool.A[138] }

func A_arbace_classes_interp__init_part0_A_clinit_p2() { A_arbace_classes_interp__init_part0_A_const_26 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[139]); A_arbace_classes_interp__init_part0_A_const_27 = A_arbace_classes_interp__init_part0_A_const_pool.A[140]; A_arbace_classes_interp__init_part0_A_const_28 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[141]); A_arbace_classes_interp__init_part0_A_const_29 = A_arbace_classes_interp__init_part0_A_const_pool.A[142]; A_arbace_classes_interp__init_part0_A_const_30 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[143]); A_arbace_classes_interp__init_part0_A_const_31 = A_arbace_classes_interp__init_part0_A_const_pool.A[144]; A_arbace_classes_interp__init_part0_A_const_32 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[145]); A_arbace_classes_interp__init_part0_A_const_33 = A_arbace_classes_interp__init_part0_A_const_pool.A[146]; A_arbace_classes_interp__init_part0_A_const_34 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[147]); A_arbace_classes_interp__init_part0_A_const_35 = A_arbace_classes_interp__init_part0_A_const_pool.A[148]; A_arbace_classes_interp__init_part0_A_const_36 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[149]); A_arbace_classes_interp__init_part0_A_const_37 = A_arbace_classes_interp__init_part0_A_const_pool.A[150]; A_arbace_classes_interp__init_part0_A_const_38 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[151]) }

func A_arbace_classes_interp__init_part0_A_clinit_p3() { A_arbace_classes_interp__init_part0_A_const_39 = A_arbace_classes_interp__init_part0_A_const_pool.A[152]; A_arbace_classes_interp__init_part0_A_const_40 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[153]); A_arbace_classes_interp__init_part0_A_const_41 = A_arbace_classes_interp__init_part0_A_const_pool.A[154]; A_arbace_classes_interp__init_part0_A_const_42 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[155]); A_arbace_classes_interp__init_part0_A_const_43 = A_arbace_classes_interp__init_part0_A_const_pool.A[156]; A_arbace_classes_interp__init_part0_A_const_44 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[157]); A_arbace_classes_interp__init_part0_A_const_45 = A_arbace_classes_interp__init_part0_A_const_pool.A[158]; A_arbace_classes_interp__init_part0_A_const_46 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[159]); A_arbace_classes_interp__init_part0_A_const_47 = A_arbace_classes_interp__init_part0_A_const_pool.A[160]; A_arbace_classes_interp__init_part0_A_const_48 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[161]); A_arbace_classes_interp__init_part0_A_const_49 = A_arbace_classes_interp__init_part0_A_const_pool.A[162]; A_arbace_classes_interp__init_part0_A_const_50 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[163]); A_arbace_classes_interp__init_part0_A_const_51 = A_arbace_classes_interp__init_part0_A_const_pool.A[164] }

func A_arbace_classes_interp__init_part0_A_clinit_p4() { A_arbace_classes_interp__init_part0_A_const_52 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[165]); A_arbace_classes_interp__init_part0_A_const_53 = A_arbace_classes_interp__init_part0_A_const_pool.A[166]; A_arbace_classes_interp__init_part0_A_const_54 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[167]); A_arbace_classes_interp__init_part0_A_const_55 = A_arbace_classes_interp__init_part0_A_const_pool.A[168]; A_arbace_classes_interp__init_part0_A_const_56 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[169]); A_arbace_classes_interp__init_part0_A_const_57 = A_arbace_classes_interp__init_part0_A_const_pool.A[170]; A_arbace_classes_interp__init_part0_A_const_58 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[171]); A_arbace_classes_interp__init_part0_A_const_59 = A_arbace_classes_interp__init_part0_A_const_pool.A[172]; A_arbace_classes_interp__init_part0_A_const_60 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[173]); A_arbace_classes_interp__init_part0_A_const_61 = A_arbace_classes_interp__init_part0_A_const_pool.A[174]; A_arbace_classes_interp__init_part0_A_const_62 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[175]); A_arbace_classes_interp__init_part0_A_const_63 = A_arbace_classes_interp__init_part0_A_const_pool.A[176]; A_arbace_classes_interp__init_part0_A_const_64 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[177]) }

func A_arbace_classes_interp__init_part0_A_clinit_p5() { A_arbace_classes_interp__init_part0_A_const_65 = A_arbace_classes_interp__init_part0_A_const_pool.A[178]; A_arbace_classes_interp__init_part0_A_const_66 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[179]); A_arbace_classes_interp__init_part0_A_const_67 = A_arbace_classes_interp__init_part0_A_const_pool.A[180]; A_arbace_classes_interp__init_part0_A_const_68 = A_arbace_classes_interp__init_part0_A_const_pool.A[181]; A_arbace_classes_interp__init_part0_A_const_69 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[182]); A_arbace_classes_interp__init_part0_A_const_70 = A_arbace_classes_interp__init_part0_A_const_pool.A[183]; A_arbace_classes_interp__init_part0_A_const_71 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[184]); A_arbace_classes_interp__init_part0_A_const_72 = A_arbace_classes_interp__init_part0_A_const_pool.A[185]; A_arbace_classes_interp__init_part0_A_const_73 = A_arbace_classes_interp__init_part0_A_const_pool.A[186]; A_arbace_classes_interp__init_part0_A_const_74 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[187]); A_arbace_classes_interp__init_part0_A_const_75 = A_arbace_classes_interp__init_part0_A_const_pool.A[188]; A_arbace_classes_interp__init_part0_A_const_76 = A_arbace_classes_interp__init_part0_A_const_pool.A[189]; A_arbace_classes_interp__init_part0_A_const_77 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[190]); A_arbace_classes_interp__init_part0_A_const_78 = A_arbace_classes_interp__init_part0_A_const_pool.A[191] }

func A_arbace_classes_interp__init_part0_A_clinit_p6() { A_arbace_classes_interp__init_part0_A_const_79 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[192]); A_arbace_classes_interp__init_part0_A_const_80 = A_arbace_classes_interp__init_part0_A_const_pool.A[193]; A_arbace_classes_interp__init_part0_A_const_81 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[194]); A_arbace_classes_interp__init_part0_A_const_82 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[195]); A_arbace_classes_interp__init_part0_A_const_83 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[196]); A_arbace_classes_interp__init_part0_A_const_84 = A_arbace_classes_interp__init_part0_A_const_pool.A[197]; A_arbace_classes_interp__init_part0_A_const_85 = A_arbace_classes_interp__init_part0_A_const_pool.A[198]; A_arbace_classes_interp__init_part0_A_const_86 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[199]); A_arbace_classes_interp__init_part0_A_const_87 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[200]); A_arbace_classes_interp__init_part0_A_const_88 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[201]); A_arbace_classes_interp__init_part0_A_const_89 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[202]); A_arbace_classes_interp__init_part0_A_const_90 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[203]); A_arbace_classes_interp__init_part0_A_const_91 = A_arbace_classes_interp__init_part0_A_const_pool.A[204] }

func A_arbace_classes_interp__init_part0_A_clinit_p7() { A_arbace_classes_interp__init_part0_A_const_92 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[205]); A_arbace_classes_interp__init_part0_A_const_93 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[206]); A_arbace_classes_interp__init_part0_A_const_94 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[207]); A_arbace_classes_interp__init_part0_A_const_95 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[208]); A_arbace_classes_interp__init_part0_A_const_96 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[209]); A_arbace_classes_interp__init_part0_A_const_97 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[210]); A_arbace_classes_interp__init_part0_A_const_98 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[211]); A_arbace_classes_interp__init_part0_A_const_99 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[212]); A_arbace_classes_interp__init_part0_A_const_100 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[213]); A_arbace_classes_interp__init_part0_A_const_101 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[214]); A_arbace_classes_interp__init_part0_A_const_102 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[215]); A_arbace_classes_interp__init_part0_A_const_103 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[216]) }

func A_arbace_classes_interp__init_part0_A_clinit_p8() { A_arbace_classes_interp__init_part0_A_const_104 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[217]); A_arbace_classes_interp__init_part0_A_const_105 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[218]); A_arbace_classes_interp__init_part0_A_const_106 = A_arbace_classes_interp__init_part0_A_const_pool.A[219]; A_arbace_classes_interp__init_part0_A_const_107 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[220]); A_arbace_classes_interp__init_part0_A_const_108 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[221]); A_arbace_classes_interp__init_part0_A_const_109 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[222]); A_arbace_classes_interp__init_part0_A_const_110 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[223]); A_arbace_classes_interp__init_part0_A_const_111 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[224]); A_arbace_classes_interp__init_part0_A_const_112 = A_arbace_classes_interp__init_part0_A_const_pool.A[225]; A_arbace_classes_interp__init_part0_A_const_113 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[226]); A_arbace_classes_interp__init_part0_A_const_114 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[227]); A_arbace_classes_interp__init_part0_A_const_115 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[228]) }

func A_arbace_classes_interp__init_part0_A_clinit_p9() { A_arbace_classes_interp__init_part0_A_const_116 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[229]); A_arbace_classes_interp__init_part0_A_const_117 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[230]); A_arbace_classes_interp__init_part0_A_const_118 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[231]); A_arbace_classes_interp__init_part0_A_const_119 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[232]); A_arbace_classes_interp__init_part0_A_const_120 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[233]); A_arbace_classes_interp__init_part0_A_const_121 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[234]); A_arbace_classes_interp__init_part0_A_const_122 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[235]); A_arbace_classes_interp__init_part0_A_const_123 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[236]); A_arbace_classes_interp__init_part0_A_const_124 = A_arbace_classes_interp__init_part0_A_const_pool.A[237]; A_arbace_classes_interp__init_part0_A_const_125 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[238]); A_arbace_classes_interp__init_part0_A_const_126 = A_arbace_classes_interp__init_part0_A_const_pool.A[239]; A_arbace_classes_interp__init_part0_A_const_127 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[240]) }

func A_arbace_classes_interp__init_part0_A_clinit_p10() { A_arbace_classes_interp__init_part0_A_const_128 = A_arbace_classes_interp__init_part0_A_const_pool.A[241]; A_arbace_classes_interp__init_part0_A_const_129 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[242]); A_arbace_classes_interp__init_part0_A_const_130 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[243]); A_arbace_classes_interp__init_part0_A_const_131 = A_arbace_classes_interp__init_part0_A_const_pool.A[244]; A_arbace_classes_interp__init_part0_A_const_132 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[245]); A_arbace_classes_interp__init_part0_A_const_133 = A_arbace_classes_interp__init_part0_A_const_pool.A[246]; A_arbace_classes_interp__init_part0_A_const_134 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[247]); A_arbace_classes_interp__init_part0_A_const_135 = A_arbace_classes_interp__init_part0_A_const_pool.A[248]; A_arbace_classes_interp__init_part0_A_const_136 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[249]); A_arbace_classes_interp__init_part0_A_const_137 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[250]); A_arbace_classes_interp__init_part0_A_const_138 = A_arbace_classes_interp__init_part0_A_const_pool.A[251]; A_arbace_classes_interp__init_part0_A_const_139 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[252]); A_arbace_classes_interp__init_part0_A_const_140 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[253]) }

func A_arbace_classes_interp__init_part0_A_clinit_p11() { A_arbace_classes_interp__init_part0_A_const_141 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[254]); A_arbace_classes_interp__init_part0_A_const_142 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[255]); A_arbace_classes_interp__init_part0_A_const_143 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[256]); A_arbace_classes_interp__init_part0_A_const_144 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[257]); A_arbace_classes_interp__init_part0_A_const_145 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[258]); A_arbace_classes_interp__init_part0_A_const_146 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[259]); A_arbace_classes_interp__init_part0_A_const_147 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[260]); A_arbace_classes_interp__init_part0_A_const_148 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[261]); A_arbace_classes_interp__init_part0_A_const_149 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[262]); A_arbace_classes_interp__init_part0_A_const_150 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[263]); A_arbace_classes_interp__init_part0_A_const_151 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[264]); A_arbace_classes_interp__init_part0_A_const_152 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[265]) }

func A_arbace_classes_interp__init_part0_A_New() *A_arbace_classes_interp__init_part0_A { A_arbace_classes_interp__init_part0_A_Init(); t := &A_arbace_classes_interp__init_part0_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_interp__init_part0_A) Ctor() {}

func (t *A_arbace_classes_interp__init_part0_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_interp__init_part0_A) GetClass__Class() *jrt.Class { return A_arbace_classes_interp__init_part0_A_class }

func (t *A_arbace_classes_interp__init_part0_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_interp__init_part0_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_interp__init_part0_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_interp__init_part0_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_interp__init_part0_A); return ok }

func A_arbace_classes_interp__init_part0_A_Cast(x any) *A_arbace_classes_interp__init_part0_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_interp__init_part0_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_interp__init_part0_A_class)) }; return v }



type A_arbace_classes_interp__init_part1_A struct{ jrt.Object }

var A_arbace_classes_interp__init_part1_A_const_pool *jrt.RefArray

var A_arbace_classes_interp__init_part1_A_const_0 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_1 any

var A_arbace_classes_interp__init_part1_A_const_2 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_3 any

var A_arbace_classes_interp__init_part1_A_const_4 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_5 *lang.Keyword

var A_arbace_classes_interp__init_part1_A_const_6 *lang.Keyword

var A_arbace_classes_interp__init_part1_A_const_7 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_8 any

var A_arbace_classes_interp__init_part1_A_const_9 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_10 any

var A_arbace_classes_interp__init_part1_A_const_11 any

var A_arbace_classes_interp__init_part1_A_const_12 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_13 any

var A_arbace_classes_interp__init_part1_A_const_14 any

var A_arbace_classes_interp__init_part1_A_const_15 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_16 any

var A_arbace_classes_interp__init_part1_A_const_17 any

var A_arbace_classes_interp__init_part1_A_const_18 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_19 any

var A_arbace_classes_interp__init_part1_A_const_20 any

var A_arbace_classes_interp__init_part1_A_const_21 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_22 any

var A_arbace_classes_interp__init_part1_A_const_23 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_24 any

var A_arbace_classes_interp__init_part1_A_const_25 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_26 any

var A_arbace_classes_interp__init_part1_A_const_27 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_28 any

var A_arbace_classes_interp__init_part1_A_const_29 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_30 any

var A_arbace_classes_interp__init_part1_A_const_31 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_32 any

var A_arbace_classes_interp__init_part1_A_const_33 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_34 any

var A_arbace_classes_interp__init_part1_A_const_35 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_36 any

var A_arbace_classes_interp__init_part1_A_const_37 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_38 any

var A_arbace_classes_interp__init_part1_A_const_39 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_40 any

var A_arbace_classes_interp__init_part1_A_const_41 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_42 any

var A_arbace_classes_interp__init_part1_A_const_43 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_44 any

var A_arbace_classes_interp__init_part1_A_const_45 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_46 any

var A_arbace_classes_interp__init_part1_A_const_47 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_48 any

var A_arbace_classes_interp__init_part1_A_const_49 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_50 any

var A_arbace_classes_interp__init_part1_A_const_51 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_52 any

var A_arbace_classes_interp__init_part1_A_const_53 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_54 any

var A_arbace_classes_interp__init_part1_A_const_55 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_56 any

var A_arbace_classes_interp__init_part1_A_const_57 any

var A_arbace_classes_interp__init_part1_A_const_58 *lang.Keyword

var A_arbace_classes_interp__init_part1_A_const_59 any

var A_arbace_classes_interp__init_part1_A_const_60 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_61 any

var A_arbace_classes_interp__init_part1_A_const_62 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_63 any

var A_arbace_classes_interp__init_part1_A_const_64 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_65 any

var A_arbace_classes_interp__init_part1_A_const_66 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_67 any

var A_arbace_classes_interp__init_part1_A_const_68 any

var A_arbace_classes_interp__init_part1_A_const_69 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_70 any

var A_arbace_classes_interp__init_part1_A_const_71 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_72 any

var A_arbace_classes_interp__init_part1_A_const_73 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_74 any

var A_arbace_classes_interp__init_part1_A_const_75 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_76 any

var A_arbace_classes_interp__init_part1_A_const_77 *lang.Keyword

var A_arbace_classes_interp__init_part1_A_const_78 *lang.Keyword

var A_arbace_classes_interp__init_part1_A_const_79 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_80 any

var A_arbace_classes_interp__init_part1_A_const_81 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_82 any

var A_arbace_classes_interp__init_part1_A_const_83 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_84 any

var A_arbace_classes_interp__init_part1_A_const_85 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_86 any

var A_arbace_classes_interp__init_part1_A_const_87 any

var A_arbace_classes_interp__init_part1_A_const_88 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_89 any

var A_arbace_classes_interp__init_part1_A_const_90 any

var A_arbace_classes_interp__init_part1_A_const_91 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_92 any

var A_arbace_classes_interp__init_part1_A_const_93 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_94 any

var A_arbace_classes_interp__init_part1_A_const_95 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_96 any

var A_arbace_classes_interp__init_part1_A_init jrt.ClassInit

func A_arbace_classes_interp__init_part1_A_Init() { if !A_arbace_classes_interp__init_part1_A_init.Done() { A_arbace_classes_interp__init_part1_A_init.Run(A_arbace_classes_interp__init_part1_A_clinit) } }

func A_arbace_classes_interp__init_part1_A_clinit() { A_arbace_classes_interp__init_part1_A_clinit_p0(); A_arbace_classes_interp__init_part1_A_clinit_p1() }

func A_arbace_classes_interp__init_part1_A_clinit_p0() { A_arbace_classes_interp__init_part1_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_357, 142); A_arbace_classes_interp__init_part1_A_const_0 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[47]); A_arbace_classes_interp__init_part1_A_const_1 = A_arbace_classes_interp__init_part1_A_const_pool.A[48]; A_arbace_classes_interp__init_part1_A_const_2 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[49]); A_arbace_classes_interp__init_part1_A_const_3 = A_arbace_classes_interp__init_part1_A_const_pool.A[50] }

func A_arbace_classes_interp__init_part1_A_clinit_p1() { var tmp1 *lang.Var; A_arbace_classes_interp__init_part0_A_Init(); tmp1 = A_arbace_classes_interp__init_part0_A_const_79; A_arbace_classes_interp__init_part1_A_const_4 = tmp1; A_arbace_classes_interp__init_part1_A_const_5 = lang.Keyword_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[51]); A_arbace_classes_interp__init_part1_A_const_6 = lang.Keyword_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[52]); A_arbace_classes_interp__init_part1_A_const_7 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[53]); A_arbace_classes_interp__init_part1_A_const_8 = A_arbace_classes_interp__init_part1_A_const_pool.A[54]; A_arbace_classes_interp__init_part1_A_const_9 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[55]); A_arbace_classes_interp__init_part1_A_const_10 = A_arbace_classes_interp__init_part1_A_const_pool.A[56]; A_arbace_classes_interp__init_part1_A_const_11 = A_arbace_classes_interp__init_part1_A_const_pool.A[57]; A_arbace_classes_interp__init_part1_A_const_12 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[58]); A_arbace_classes_interp__init_part1_A_const_13 = A_arbace_classes_interp__init_part1_A_const_pool.A[59]; A_arbace_classes_interp__init_part1_A_const_14 = A_arbace_classes_interp__init_part1_A_const_pool.A[60]; A_arbace_classes_interp__init_part1_A_const_15 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[61]); A_arbace_classes_interp__init_part1_A_const_16 = A_arbace_classes_interp__init_part1_A_const_pool.A[62]; A_arbace_classes_interp__init_part1_A_const_17 = A_arbace_classes_interp__init_part1_A_const_pool.A[63]; A_arbace_classes_interp__init_part1_A_const_18 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[64]); A_arbace_classes_interp__init_part1_A_const_19 = A_arbace_classes_interp__init_part1_A_const_pool.A[65]; A_arbace_classes_interp__init_part1_A_const_20 = A_arbace_classes_interp__init_part1_A_const_pool.A[66]; A_arbace_classes_interp__init_part1_A_const_21 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[67]); A_arbace_classes_interp__init_part1_A_const_22 = A_arbace_classes_interp__init_part1_A_const_pool.A[68]; A_arbace_classes_interp__init_part1_A_const_23 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[69]); A_arbace_classes_interp__init_part1_A_const_24 = A_arbace_classes_interp__init_part1_A_const_pool.A[70]; A_arbace_classes_interp__init_part1_A_const_25 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[71]); A_arbace_classes_interp__init_part1_A_const_26 = A_arbace_classes_interp__init_part1_A_const_pool.A[72]; A_arbace_classes_interp__init_part1_A_const_27 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[73]); A_arbace_classes_interp__init_part1_A_const_28 = A_arbace_classes_interp__init_part1_A_const_pool.A[74]; A_arbace_classes_interp__init_part1_A_const_29 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[75]); A_arbace_classes_interp__init_part1_A_const_30 = A_arbace_classes_interp__init_part1_A_const_pool.A[76]; A_arbace_classes_interp__init_part1_A_const_31 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[77]); A_arbace_classes_interp__init_part1_A_const_32 = A_arbace_classes_interp__init_part1_A_const_pool.A[78]; A_arbace_classes_interp__init_part1_A_const_33 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[79]); A_arbace_classes_interp__init_part1_A_const_34 = A_arbace_classes_interp__init_part1_A_const_pool.A[80]; A_arbace_classes_interp__init_part1_A_const_35 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[81]); A_arbace_classes_interp__init_part1_A_const_36 = A_arbace_classes_interp__init_part1_A_const_pool.A[82]; A_arbace_classes_interp__init_part1_A_const_37 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[83]); A_arbace_classes_interp__init_part1_A_const_38 = A_arbace_classes_interp__init_part1_A_const_pool.A[84]; A_arbace_classes_interp__init_part1_A_const_39 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[85]); A_arbace_classes_interp__init_part1_A_const_40 = A_arbace_classes_interp__init_part1_A_const_pool.A[86]; A_arbace_classes_interp__init_part1_A_const_41 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[87]); A_arbace_classes_interp__init_part1_A_const_42 = A_arbace_classes_interp__init_part1_A_const_pool.A[88]; A_arbace_classes_interp__init_part1_A_const_43 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[89]); A_arbace_classes_interp__init_part1_A_const_44 = A_arbace_classes_interp__init_part1_A_const_pool.A[90]; A_arbace_classes_interp__init_part1_A_const_45 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[91]); A_arbace_classes_interp__init_part1_A_const_46 = A_arbace_classes_interp__init_part1_A_const_pool.A[92]; A_arbace_classes_interp__init_part1_A_const_47 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[93]); A_arbace_classes_interp__init_part1_A_const_48 = A_arbace_classes_interp__init_part1_A_const_pool.A[94]; A_arbace_classes_interp__init_part1_A_const_49 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[95]); A_arbace_classes_interp__init_part1_A_const_50 = A_arbace_classes_interp__init_part1_A_const_pool.A[96]; A_arbace_classes_interp__init_part1_A_const_51 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[97]); A_arbace_classes_interp__init_part1_A_const_52 = A_arbace_classes_interp__init_part1_A_const_pool.A[98]; A_arbace_classes_interp__init_part1_A_const_53 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[99]); A_arbace_classes_interp__init_part1_A_const_54 = A_arbace_classes_interp__init_part1_A_const_pool.A[100]; A_arbace_classes_interp__init_part1_A_const_55 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[101]); A_arbace_classes_interp__init_part1_A_const_56 = A_arbace_classes_interp__init_part1_A_const_pool.A[102]; A_arbace_classes_interp__init_part1_A_const_57 = A_arbace_classes_interp__init_part1_A_const_pool.A[103]; A_arbace_classes_interp__init_part1_A_const_58 = lang.Keyword_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[104]); A_arbace_classes_interp__init_part1_A_const_59 = A_arbace_classes_interp__init_part1_A_const_pool.A[105]; A_arbace_classes_interp__init_part1_A_const_60 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[106]); A_arbace_classes_interp__init_part1_A_const_61 = A_arbace_classes_interp__init_part1_A_const_pool.A[107]; A_arbace_classes_interp__init_part1_A_const_62 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[108]); A_arbace_classes_interp__init_part1_A_const_63 = A_arbace_classes_interp__init_part1_A_const_pool.A[109]; A_arbace_classes_interp__init_part1_A_const_64 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[110]); A_arbace_classes_interp__init_part1_A_const_65 = A_arbace_classes_interp__init_part1_A_const_pool.A[111]; var tmp2 *lang.Var; A_arbace_classes_interp__init_part0_A_Init(); tmp2 = A_arbace_classes_interp__init_part0_A_const_6; A_arbace_classes_interp__init_part1_A_const_66 = tmp2; A_arbace_classes_interp__init_part1_A_const_67 = A_arbace_classes_interp__init_part1_A_const_pool.A[112]; A_arbace_classes_interp__init_part1_A_const_68 = A_arbace_classes_interp__init_part1_A_const_pool.A[113]; A_arbace_classes_interp__init_part1_A_const_69 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[114]); A_arbace_classes_interp__init_part1_A_const_70 = A_arbace_classes_interp__init_part1_A_const_pool.A[115]; A_arbace_classes_interp__init_part1_A_const_71 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[116]); A_arbace_classes_interp__init_part1_A_const_72 = A_arbace_classes_interp__init_part1_A_const_pool.A[117]; A_arbace_classes_interp__init_part1_A_const_73 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[118]); A_arbace_classes_interp__init_part1_A_const_74 = A_arbace_classes_interp__init_part1_A_const_pool.A[119]; A_arbace_classes_interp__init_part1_A_const_75 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[120]); A_arbace_classes_interp__init_part1_A_const_76 = A_arbace_classes_interp__init_part1_A_const_pool.A[121]; A_arbace_classes_interp__init_part1_A_const_77 = lang.Keyword_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[122]); A_arbace_classes_interp__init_part1_A_const_78 = lang.Keyword_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[123]); A_arbace_classes_interp__init_part1_A_const_79 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[124]); A_arbace_classes_interp__init_part1_A_const_80 = A_arbace_classes_interp__init_part1_A_const_pool.A[125]; A_arbace_classes_interp__init_part1_A_const_81 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[126]); A_arbace_classes_interp__init_part1_A_const_82 = A_arbace_classes_interp__init_part1_A_const_pool.A[127]; A_arbace_classes_interp__init_part1_A_const_83 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[128]); A_arbace_classes_interp__init_part1_A_const_84 = A_arbace_classes_interp__init_part1_A_const_pool.A[129]; A_arbace_classes_interp__init_part1_A_const_85 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[130]); A_arbace_classes_interp__init_part1_A_const_86 = A_arbace_classes_interp__init_part1_A_const_pool.A[131]; A_arbace_classes_interp__init_part1_A_const_87 = A_arbace_classes_interp__init_part1_A_const_pool.A[132]; A_arbace_classes_interp__init_part1_A_const_88 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[133]); A_arbace_classes_interp__init_part1_A_const_89 = A_arbace_classes_interp__init_part1_A_const_pool.A[134]; A_arbace_classes_interp__init_part1_A_const_90 = A_arbace_classes_interp__init_part1_A_const_pool.A[135]; A_arbace_classes_interp__init_part1_A_const_91 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[136]); A_arbace_classes_interp__init_part1_A_const_92 = A_arbace_classes_interp__init_part1_A_const_pool.A[137]; A_arbace_classes_interp__init_part1_A_const_93 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[138]); A_arbace_classes_interp__init_part1_A_const_94 = A_arbace_classes_interp__init_part1_A_const_pool.A[139]; A_arbace_classes_interp__init_part1_A_const_95 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[140]); A_arbace_classes_interp__init_part1_A_const_96 = A_arbace_classes_interp__init_part1_A_const_pool.A[141] }

func A_arbace_classes_interp__init_part1_A_New() *A_arbace_classes_interp__init_part1_A { A_arbace_classes_interp__init_part1_A_Init(); t := &A_arbace_classes_interp__init_part1_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_interp__init_part1_A) Ctor() {}

func (t *A_arbace_classes_interp__init_part1_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_interp__init_part1_A) GetClass__Class() *jrt.Class { return A_arbace_classes_interp__init_part1_A_class }

func (t *A_arbace_classes_interp__init_part1_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_interp__init_part1_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_interp__init_part1_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_interp__init_part1_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_interp__init_part1_A); return ok }

func A_arbace_classes_interp__init_part1_A_Cast(x any) *A_arbace_classes_interp__init_part1_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_interp__init_part1_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_interp__init_part1_A_class)) }; return v }
