//line aot_arbace_classes_interp__init.ae:1
package aot_arbace_classes_interp

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_interp__init_part0_A_Unit0__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_classes_interp__init_part0_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_interp__init_part0_A_const_1) }
//line :1:1
func A_arbace_classes_interp__init_part0_A_Unit1__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_classes_interp__init_part0_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_2)) }
//line :1:1
func A_arbace_classes_interp__init_part0_A_Unit2__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 any = A_arbace_classes_interp_eval393000004_loading__1927001464__auto____393000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_classes_interp_eval393000004_loading__1927001464__auto____393000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_266, false); A_arbace_classes_interp_eval393000004_loading__1927001464__auto____393000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_classes_interp__init_part0_A_Unit3__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_classes_interp__init_part0_A_const_1)).Equals_O__Z(A_arbace_classes_interp__init_part0_A_const_3) { return nil } else { var tmp1 any = A_arbace_classes_interp_eval393000008_fn__393000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_classes_interp_eval393000008_fn__393000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_267, false); A_arbace_classes_interp_eval393000008_fn__393000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }
//line :1:1
func A_arbace_classes_interp__init_part0_A_Init__O() any { A_arbace_classes_interp__init_part0_A_Init(); return nil }
//line :1:1
func A_arbace_classes_interp__init_part0_A_Load__O() any { A_arbace_classes_interp__init_part0_A_Init(); A_arbace_classes_interp__init_part0_A_Unit0__O(); A_arbace_classes_interp__init_part0_A_Unit1__O(); A_arbace_classes_interp__init_part0_A_Unit2__O(); A_arbace_classes_interp__init_part0_A_Unit3__O(); A_arbace_classes_interp__init_part0_A_Unit4__O(); A_arbace_classes_interp__init_part0_A_Unit5__O(); A_arbace_classes_interp__init_part0_A_Unit6__O(); A_arbace_classes_interp__init_part0_A_Unit7__O(); A_arbace_classes_interp__init_part0_A_Unit8__O(); A_arbace_classes_interp__init_part0_A_Unit9__O(); A_arbace_classes_interp__init_part0_A_Unit10__O(); A_arbace_classes_interp__init_part0_A_Unit11__O(); A_arbace_classes_interp__init_part0_A_Unit12__O(); A_arbace_classes_interp__init_part0_A_Unit13__O(); A_arbace_classes_interp__init_part0_A_Unit14__O(); A_arbace_classes_interp__init_part0_A_Unit15__O(); A_arbace_classes_interp__init_part0_A_Unit16__O(); A_arbace_classes_interp__init_part0_A_Unit17__O(); A_arbace_classes_interp__init_part0_A_Unit18__O(); A_arbace_classes_interp__init_part0_A_Unit19__O(); A_arbace_classes_interp__init_part0_A_Unit20__O(); A_arbace_classes_interp__init_part0_A_Unit21__O(); A_arbace_classes_interp__init_part0_A_Unit22__O(); A_arbace_classes_interp__init_part0_A_Unit23__O(); A_arbace_classes_interp__init_part0_A_Unit24__O(); A_arbace_classes_interp__init_part0_A_Unit25__O(); A_arbace_classes_interp__init_part0_A_Unit26__O(); A_arbace_classes_interp__init_part0_A_Unit27__O(); A_arbace_classes_interp__init_part0_A_Unit28__O(); A_arbace_classes_interp__init_part0_A_Unit29__O(); A_arbace_classes_interp__init_part0_A_Unit30__O(); A_arbace_classes_interp__init_part0_A_Unit31__O(); A_arbace_classes_interp__init_part0_A_Unit32__O(); A_arbace_classes_interp__init_part0_A_Unit33__O(); A_arbace_classes_interp__init_part0_A_Unit34__O(); A_arbace_classes_interp__init_part0_A_Unit35__O(); A_arbace_classes_interp__init_part0_A_Unit36__O(); A_arbace_classes_interp__init_part0_A_Unit37__O(); A_arbace_classes_interp__init_part0_A_Unit38__O(); A_arbace_classes_interp__init_part0_A_Unit39__O(); A_arbace_classes_interp__init_part0_A_Unit40__O(); A_arbace_classes_interp__init_part0_A_Unit41__O(); A_arbace_classes_interp__init_part0_A_Unit42__O(); A_arbace_classes_interp__init_part0_A_Unit43__O(); A_arbace_classes_interp__init_part0_A_Unit44__O(); A_arbace_classes_interp__init_part0_A_Unit45__O(); A_arbace_classes_interp__init_part0_A_Unit46__O(); A_arbace_classes_interp__init_part0_A_Unit47__O(); A_arbace_classes_interp__init_part0_A_Unit48__O(); A_arbace_classes_interp__init_part0_A_Unit49__O(); A_arbace_classes_interp__init_part0_A_Unit50__O(); A_arbace_classes_interp__init_part0_A_Unit51__O(); A_arbace_classes_interp__init_part0_A_Unit52__O(); A_arbace_classes_interp__init_part0_A_Unit53__O(); A_arbace_classes_interp__init_part0_A_Unit54__O(); A_arbace_classes_interp__init_part0_A_Unit55__O(); A_arbace_classes_interp__init_part0_A_Unit56__O(); A_arbace_classes_interp__init_part0_A_Unit57__O(); A_arbace_classes_interp__init_part0_A_Unit58__O(); A_arbace_classes_interp__init_part0_A_Unit59__O(); A_arbace_classes_interp__init_part0_A_Unit60__O(); A_arbace_classes_interp__init_part0_A_Unit61__O(); A_arbace_classes_interp__init_part0_A_Unit62__O(); A_arbace_classes_interp__init_part0_A_Unit63__O(); A_arbace_classes_interp__init_part0_A_Unit64__O(); A_arbace_classes_interp__init_part0_A_Unit65__O(); A_arbace_classes_interp__init_part0_A_Unit66__O(); A_arbace_classes_interp__init_part0_A_Unit67__O(); A_arbace_classes_interp__init_part0_A_Unit68__O(); A_arbace_classes_interp__init_part0_A_Unit69__O(); A_arbace_classes_interp__init_part0_A_Unit70__O(); A_arbace_classes_interp__init_part0_A_Unit71__O(); A_arbace_classes_interp__init_part0_A_Unit72__O(); A_arbace_classes_interp__init_part0_A_Unit73__O(); A_arbace_classes_interp__init_part0_A_Unit74__O(); A_arbace_classes_interp__init_part0_A_Unit75__O(); A_arbace_classes_interp__init_part0_A_Unit76__O(); A_arbace_classes_interp__init_part0_A_Unit77__O(); A_arbace_classes_interp__init_part0_A_Unit78__O(); A_arbace_classes_interp__init_part0_A_Unit79__O(); A_arbace_classes_interp__init_part0_A_Unit80__O(); A_arbace_classes_interp__init_part0_A_Unit81__O(); A_arbace_classes_interp__init_part0_A_Unit82__O(); A_arbace_classes_interp__init_part0_A_Unit83__O(); A_arbace_classes_interp__init_part0_A_Unit84__O(); A_arbace_classes_interp__init_part0_A_Unit85__O(); A_arbace_classes_interp__init_part0_A_Unit86__O(); A_arbace_classes_interp__init_part0_A_Unit87__O(); A_arbace_classes_interp__init_part0_A_Unit88__O(); A_arbace_classes_interp__init_part0_A_Unit89__O(); A_arbace_classes_interp__init_part0_A_Unit90__O(); A_arbace_classes_interp__init_part0_A_Unit91__O(); A_arbace_classes_interp__init_part0_A_Unit92__O(); A_arbace_classes_interp__init_part0_A_Unit93__O(); A_arbace_classes_interp__init_part0_A_Unit94__O(); A_arbace_classes_interp__init_part0_A_Unit95__O(); A_arbace_classes_interp__init_part0_A_Unit96__O(); A_arbace_classes_interp__init_part0_A_Unit97__O(); A_arbace_classes_interp__init_part0_A_Unit98__O(); A_arbace_classes_interp__init_part0_A_Unit99__O(); return nil }



func A_arbace_classes_interp__init_A_Load__O() any { jrt.StartCheck(); A_arbace_classes_interp__init_part0_A_Init__O(); A_arbace_classes_interp__init_part1_A_Init__O(); A_arbace_classes_interp__init_part0_A_Load__O(); A_arbace_classes_interp__init_part1_A_Load__O(); return nil }

































func A_arbace_classes_interp__init_part0_A_Unit4__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(39, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_5)); v__1927001498__auto____1 = A_arbace_classes_interp__init_part0_A_const_4; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_classes_interp__init_part0_A_const_4; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_7)); var tmp3 *lang.Var = A_arbace_classes_interp__init_part0_A_const_4; var tmp4 any; var root_3 any = A_arbace_classes_interp__init_part0_A_const_6.GetRawRoot__O(); var linked_4 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_5 lang.IFn
								if linked_4 == nil { ifn_5 = lang.IFn_Cast(root_3) } else { ifn_5 = nil }; var arg_6 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_4 == nil { tmp4 = ifn_5.Invoke_O__O(arg_6) } else { tmp4 = linked_4.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_3, arg_6) }
//line :39:1
	tmp3.BindRoot_O__V(tmp4); return A_arbace_classes_interp__init_part0_A_const_4 } }


func A_arbace_classes_interp__init_part0_A_Unit5__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(42, 1); A_arbace_classes_interp__init_part0_A_const_8.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_8; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_9)); return A_arbace_classes_interp__init_part0_A_const_8.SetDynamic_Z__Var(true).Ref() }



func A_arbace_classes_interp__init_part0_A_Unit6__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(46, 1); A_arbace_classes_interp__init_part0_A_const_10.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_10; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_11)); return A_arbace_classes_interp__init_part0_A_const_10.SetDynamic_Z__Var(true).Ref() }




func A_arbace_classes_interp__init_part0_A_Unit7__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(51, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_12; var tmp2 any = A_arbace_classes_interp_sibling_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_classes_interp_sibling_QMARK__A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_268, false); A_arbace_classes_interp_sibling_QMARK__A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_13)); return A_arbace_classes_interp__init_part0_A_const_12 }





func A_arbace_classes_interp__init_part0_A_Unit8__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(57, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_14; var tmp2 any = A_arbace_classes_interp_pending_BANG__A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_classes_interp_pending_BANG__A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_269, false); A_arbace_classes_interp_pending_BANG__A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_15)); return A_arbace_classes_interp__init_part0_A_const_14 }







func A_arbace_classes_interp__init_part0_A_Unit9__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(65, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_16; var tmp2 any = A_arbace_classes_interp_pending_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_classes_interp_pending_QMARK__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_270, false); A_arbace_classes_interp_pending_QMARK__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_17)); return A_arbace_classes_interp__init_part0_A_const_16 }

func A_arbace_classes_interp__init_part0_A_Unit10__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(67, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_18; var tmp2 any = A_arbace_classes_interp_klass_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_classes_interp_klass_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_271, false); A_arbace_classes_interp_klass_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_19)); return A_arbace_classes_interp__init_part0_A_const_18 }












func A_arbace_classes_interp__init_part0_A_Unit11__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(80, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_20; var tmp2 any = A_arbace_classes_interp_fail_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_classes_interp_fail_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_272, true); A_arbace_classes_interp_fail_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_21)); return A_arbace_classes_interp__init_part0_A_const_20 }




func A_arbace_classes_interp__init_part0_A_Unit12__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(85, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_22; var tmp2 any = A_arbace_classes_interp_tc_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_classes_interp_tc_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_273, false); A_arbace_classes_interp_tc_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_23)); return A_arbace_classes_interp__init_part0_A_const_22 }








func A_arbace_classes_interp__init_part0_A_Unit13__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(94, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_24; var tmp2 any = A_arbace_classes_interp_kind_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_classes_interp_kind_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_274, false); A_arbace_classes_interp_kind_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_25)); return A_arbace_classes_interp__init_part0_A_const_24 }

func A_arbace_classes_interp__init_part0_A_Unit14__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(96, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_26; tmp1.BindRoot_O__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_275, jrt.Long_TYPE.Ref(), Lit_276, jrt.Short_TYPE.Ref(), Lit_6, jrt.Boolean_TYPE.Ref(), Lit_277, jrt.Character_TYPE.Ref(), Lit_278, jrt.Float_TYPE.Ref(), Lit_279, jrt.Byte_TYPE.Ref(), Lit_9, jrt.Void_TYPE.Ref(), Lit_11, jrt.Integer_TYPE.Ref(), Lit_280, jrt.Double_TYPE.Ref()))); var tmp2 *lang.Var = A_arbace_classes_interp__init_part0_A_const_26; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_27)); return A_arbace_classes_interp__init_part0_A_const_26 }



func A_arbace_classes_interp__init_part0_A_Unit15__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(100, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_28; var tmp2 any = A_arbace_classes_interp_desc__GT_class_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_classes_interp_desc__GT_class_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_281, false); A_arbace_classes_interp_desc__GT_class_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_29)); return A_arbace_classes_interp__init_part0_A_const_28 }


















func A_arbace_classes_interp__init_part0_A_Unit16__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(119, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_30; var tmp2 any = A_arbace_classes_interp_internal__GT_class_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_classes_interp_internal__GT_class_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_282, false); A_arbace_classes_interp_internal__GT_class_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_31)); return A_arbace_classes_interp__init_part0_A_const_30 }








func A_arbace_classes_interp__init_part0_A_Unit17__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(128, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_32; var tmp2 any = A_arbace_classes_interp_new_ctx_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_classes_interp_new_ctx_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_283, false); A_arbace_classes_interp_new_ctx_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_33)); return A_arbace_classes_interp__init_part0_A_const_32 }



func A_arbace_classes_interp__init_part0_A_Unit18__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(132, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_34; var tmp2 any = A_arbace_classes_interp_slot_BANG__A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_classes_interp_slot_BANG__A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_284, false); A_arbace_classes_interp_slot_BANG__A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_35)); return A_arbace_classes_interp__init_part0_A_const_34 }






func A_arbace_classes_interp__init_part0_A_Unit19__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(139, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_36; var tmp2 any = A_arbace_classes_interp_bind_BANG__A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_classes_interp_bind_BANG__A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_285, false); A_arbace_classes_interp_bind_BANG__A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_37)); return A_arbace_classes_interp__init_part0_A_const_36 }







func A_arbace_classes_interp__init_part0_A_Unit20__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(147, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_38; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_39)); return A_arbace_classes_interp__init_part0_A_const_38 }
//line :147:1
func A_arbace_classes_interp__init_part0_A_Unit21__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(147, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_40; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_41)); return A_arbace_classes_interp__init_part0_A_const_40 }

func A_arbace_classes_interp__init_part0_A_Unit22__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(149, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_42; var tmp2 any = A_arbace_classes_interp_konst_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_classes_interp_konst_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_286, false); A_arbace_classes_interp_konst_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_43)); return A_arbace_classes_interp__init_part0_A_const_42 }

func A_arbace_classes_interp__init_part0_A_Unit23__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(151, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_44; var tmp2 any = A_arbace_classes_interp_nodes_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_classes_interp_nodes_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_287, false); A_arbace_classes_interp_nodes_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_45)); return A_arbace_classes_interp__init_part0_A_const_44 }


func A_arbace_classes_interp__init_part0_A_Unit24__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(154, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_46; var tmp2 any = A_arbace_classes_interp_target_code_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_classes_interp_target_code_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_288, false); A_arbace_classes_interp_target_code_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_47)); return A_arbace_classes_interp__init_part0_A_const_46 }



func A_arbace_classes_interp__init_part0_A_Unit25__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(158, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_48; var tmp2 any = A_arbace_classes_interp_instance_fields_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_classes_interp_instance_fields_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_289, false); A_arbace_classes_interp_instance_fields_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_49)); return A_arbace_classes_interp__init_part0_A_const_48 }





func A_arbace_classes_interp__init_part0_A_Unit26__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(164, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_50; var tmp2 any = A_arbace_classes_interp_field_index_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_classes_interp_field_index_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_290, false); A_arbace_classes_interp_field_index_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_51)); return A_arbace_classes_interp__init_part0_A_const_50 }








func A_arbace_classes_interp__init_part0_A_Unit27__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(173, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_52; var tmp2 any = A_arbace_classes_interp_static_index_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_classes_interp_static_index_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_291, false); A_arbace_classes_interp_static_index_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_53)); return A_arbace_classes_interp__init_part0_A_const_52 }


func A_arbace_classes_interp__init_part0_A_Unit28__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(176, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_54; var tmp2 any = A_arbace_classes_interp_find_static_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_classes_interp_find_static_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_292, false); A_arbace_classes_interp_find_static_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_55)); return A_arbace_classes_interp__init_part0_A_const_54 }











func A_arbace_classes_interp__init_part0_A_Unit29__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(188, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_56; var tmp2 any = A_arbace_classes_interp_params_of_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_classes_interp_params_of_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_293, false); A_arbace_classes_interp_params_of_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_57)); return A_arbace_classes_interp__init_part0_A_const_56 }

func A_arbace_classes_interp__init_part0_A_Unit30__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(190, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_58; var tmp2 any = A_arbace_classes_interp_find_method_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_classes_interp_find_method_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_294, false); A_arbace_classes_interp_find_method_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_59)); return A_arbace_classes_interp__init_part0_A_const_58 }












func A_arbace_classes_interp__init_part0_A_Unit31__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(203, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_60; var tmp2 any = A_arbace_classes_interp_real_method_A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_classes_interp_real_method_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_295, false); A_arbace_classes_interp_real_method_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_61)); return A_arbace_classes_interp__init_part0_A_const_60 }
















func A_arbace_classes_interp__init_part0_A_Unit32__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(220, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_62; var tmp2 any = A_arbace_classes_interp_find_field_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_classes_interp_find_field_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_296, false); A_arbace_classes_interp_find_field_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_63)); return A_arbace_classes_interp__init_part0_A_const_62 }









func A_arbace_classes_interp__init_part0_A_Unit33__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(230, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_64; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_65)); return A_arbace_classes_interp__init_part0_A_const_64 }

func A_arbace_classes_interp__init_part0_A_Unit34__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(232, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_66; var tmp2 any = A_arbace_classes_interp_local_node_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_classes_interp_local_node_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_297, false); A_arbace_classes_interp_local_node_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_67)); return A_arbace_classes_interp__init_part0_A_const_66 }









































func A_arbace_classes_interp__init_part0_A_Unit35__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(274, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_68; var tmp2 any = A_arbace_classes_interp_convert_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_classes_interp_convert_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_298, false); A_arbace_classes_interp_convert_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_69)); return A_arbace_classes_interp__init_part0_A_const_68 }













func A_arbace_classes_interp__init_part0_A_Unit36__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(288, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_40; var tmp2 any = A_arbace_classes_interp_coerce_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_classes_interp_coerce_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_299, false); A_arbace_classes_interp_coerce_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_70)); return A_arbace_classes_interp__init_part0_A_const_40 }






func A_arbace_classes_interp__init_part0_A_Unit37__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(295, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_71; var tmp2 any = A_arbace_classes_interp_value_convert_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_classes_interp_value_convert_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_300, false); A_arbace_classes_interp_value_convert_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_72)); return A_arbace_classes_interp__init_part0_A_const_71 }























func A_arbace_classes_interp__init_part0_A_Unit38__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(319, 1); A_arbace_classes_interp__init_part0_A_const_73.BindRoot_O__V(A_arbace_classes_interp__init_part0_A_const_74); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_73; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_75)); return A_arbace_classes_interp__init_part0_A_const_73 }



func A_arbace_classes_interp__init_part0_A_Unit39__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(323, 1); A_arbace_classes_interp__init_part0_A_const_76.BindRoot_O__V(A_arbace_classes_interp__init_part0_A_const_77); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_76; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_78)); return A_arbace_classes_interp__init_part0_A_const_76 }

func A_arbace_classes_interp__init_part0_A_Unit40__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(325, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_79; var tmp2 any = A_arbace_classes_interp_vt_A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_classes_interp_vt_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_301, false); A_arbace_classes_interp_vt_A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_79; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_80)); return A_arbace_classes_interp__init_part0_A_const_79 }

func A_arbace_classes_interp__init_part0_A_Unit41__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(327, 1); var v__1927000386__auto____1 any; var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_81; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_82)); v__1927000386__auto____1 = A_arbace_classes_interp__init_part0_A_const_81; var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { var tmp3 any; var root_35 any = A_arbace_classes_interp__init_part0_A_const_83.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any = v__1927000386__auto____1; if linked_36 == nil { tmp3 = ifn_37.Invoke_O__O(arg_38) } else { tmp3 = linked_36.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_35, arg_38) }; tmp2 = lang.MultiFn_InstanceOf(tmp3) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_81; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_86)); var tmp5 *lang.Var = A_arbace_classes_interp__init_part0_A_const_81; var tmp6 *jrt.String = Lit_302; var tmp7 any = A_arbace_classes_interp_eval393000078_fn__393000079_A_New(); var tmp8 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_classes_interp_eval393000078_fn__393000079_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_303, false); A_arbace_classes_interp_eval393000078_fn__393000079_A_fn_class = fncls__39d; tmp8 = fncls__39d } else { tmp8 = fncls__39 }; var tmp9 lang.IFn = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_classes_interp__init_part0_A_const_84; tmp5.BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp6, tmp9, tmp10, A_arbace_classes_interp__init_part0_A_const_85)); return A_arbace_classes_interp__init_part0_A_const_81 } }

func A_arbace_classes_interp__init_part0_A_Unit42__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(329, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_38; var tmp2 any = A_arbace_classes_interp_node_A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_classes_interp_node_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_304, false); A_arbace_classes_interp_node_A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_87)); return A_arbace_classes_interp__init_part0_A_const_38 }




func A_arbace_classes_interp__init_part0_A_Unit43__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(334, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_84; var tmp3 any = A_arbace_classes_interp_eval393000083_fn__393000084_A_New(); var tmp4 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_classes_interp_eval393000083_fn__393000084_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_305, false); A_arbace_classes_interp_eval393000083_fn__393000084_A_fn_class = fncls__41d; tmp4 = fncls__41d } else { tmp4 = fncls__41 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_classes_interp__init_part0_A_Unit44__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(337, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_88; var tmp3 any = A_arbace_classes_interp_eval393000087_fn__393000088_A_New(); var tmp4 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_classes_interp_eval393000087_fn__393000088_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_306, false); A_arbace_classes_interp_eval393000087_fn__393000088_A_fn_class = fncls__42d; tmp4 = fncls__42d } else { tmp4 = fncls__42 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }







func A_arbace_classes_interp__init_part0_A_Unit45__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(345, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_89; var tmp3 any = A_arbace_classes_interp_eval393000091_fn__393000092_A_New(); var tmp4 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_classes_interp_eval393000091_fn__393000092_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_307, false); A_arbace_classes_interp_eval393000091_fn__393000092_A_fn_class = fncls__43d; tmp4 = fncls__43d } else { tmp4 = fncls__43 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_classes_interp__init_part0_A_Unit46__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(347, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_90; var tmp3 any = A_arbace_classes_interp_eval393000095_fn__393000096_A_New(); var tmp4 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_classes_interp_eval393000095_fn__393000096_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_308, false); A_arbace_classes_interp_eval393000095_fn__393000096_A_fn_class = fncls__44d; tmp4 = fncls__44d } else { tmp4 = fncls__44 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_classes_interp__init_part0_A_Unit47__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(349, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_91; var tmp3 any = A_arbace_classes_interp_eval393000099_fn__393000100_A_New(); var tmp4 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_classes_interp_eval393000099_fn__393000100_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_309, false); A_arbace_classes_interp_eval393000099_fn__393000100_A_fn_class = fncls__45d; tmp4 = fncls__45d } else { tmp4 = fncls__45 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }




func A_arbace_classes_interp__init_part0_A_Unit48__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(354, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_64; var tmp2 any = A_arbace_classes_interp_this0_index_A_New(); var tmp3 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_classes_interp_this0_index_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_310, false); A_arbace_classes_interp_this0_index_A_fn_class = fncls__46d; tmp3 = fncls__46d } else { tmp3 = fncls__46 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_92)); return A_arbace_classes_interp__init_part0_A_const_64 }






func A_arbace_classes_interp__init_part0_A_Unit49__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(361, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_93; var tmp3 any = A_arbace_classes_interp_eval393000107_fn__393000108_A_New(); var tmp4 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_classes_interp_eval393000107_fn__393000108_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_311, false); A_arbace_classes_interp_eval393000107_fn__393000108_A_fn_class = fncls__47d; tmp4 = fncls__47d } else { tmp4 = fncls__47 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_classes_interp__init_part0_A_Unit50__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(367, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_94; var tmp3 any = A_arbace_classes_interp_eval393000111_fn__393000112_A_New(); var tmp4 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_classes_interp_eval393000111_fn__393000112_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_312, false); A_arbace_classes_interp_eval393000111_fn__393000112_A_fn_class = fncls__48d; tmp4 = fncls__48d } else { tmp4 = fncls__48 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_classes_interp__init_part0_A_Unit51__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(370, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_95; var tmp3 any = A_arbace_classes_interp_eval393000115_fn__393000116_A_New(); var tmp4 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_classes_interp_eval393000115_fn__393000116_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_313, false); A_arbace_classes_interp_eval393000115_fn__393000116_A_fn_class = fncls__49d; tmp4 = fncls__49d } else { tmp4 = fncls__49 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_classes_interp__init_part0_A_Unit52__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(376, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_96; var tmp3 any = A_arbace_classes_interp_eval393000119_fn__393000120_A_New(); var tmp4 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_classes_interp_eval393000119_fn__393000120_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_314, false); A_arbace_classes_interp_eval393000119_fn__393000120_A_fn_class = fncls__50d; tmp4 = fncls__50d } else { tmp4 = fncls__50 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_classes_interp__init_part0_A_Unit53__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(379, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_97; var tmp3 any = A_arbace_classes_interp_eval393000123_fn__393000124_A_New(); var tmp4 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_classes_interp_eval393000123_fn__393000124_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_315, false); A_arbace_classes_interp_eval393000123_fn__393000124_A_fn_class = fncls__51d; tmp4 = fncls__51d } else { tmp4 = fncls__51 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_classes_interp__init_part0_A_Unit54__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(382, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_98; var tmp3 any = A_arbace_classes_interp_eval393000127_fn__393000128_A_New(); var tmp4 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_classes_interp_eval393000127_fn__393000128_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_316, false); A_arbace_classes_interp_eval393000127_fn__393000128_A_fn_class = fncls__52d; tmp4 = fncls__52d } else { tmp4 = fncls__52 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_classes_interp__init_part0_A_Unit55__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(389, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_99; var tmp3 any = A_arbace_classes_interp_eval393000131_fn__393000132_A_New(); var tmp4 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_classes_interp_eval393000131_fn__393000132_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_317, false); A_arbace_classes_interp_eval393000131_fn__393000132_A_fn_class = fncls__53d; tmp4 = fncls__53d } else { tmp4 = fncls__53 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }




func A_arbace_classes_interp__init_part0_A_Unit56__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(394, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_100; var tmp3 any = A_arbace_classes_interp_eval393000135_fn__393000136_A_New(); var tmp4 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_classes_interp_eval393000135_fn__393000136_A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_318, false); A_arbace_classes_interp_eval393000135_fn__393000136_A_fn_class = fncls__54d; tmp4 = fncls__54d } else { tmp4 = fncls__54 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }











func A_arbace_classes_interp__init_part0_A_Unit57__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(406, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_101; var tmp3 any = A_arbace_classes_interp_eval393000145_fn__393000146_A_New(); var tmp4 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_classes_interp_eval393000145_fn__393000146_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_319, false); A_arbace_classes_interp_eval393000145_fn__393000146_A_fn_class = fncls__55d; tmp4 = fncls__55d } else { tmp4 = fncls__55 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }




func A_arbace_classes_interp__init_part0_A_Unit58__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(411, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_102; var tmp3 any = A_arbace_classes_interp_eval393000151_fn__393000152_A_New(); var tmp4 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_classes_interp_eval393000151_fn__393000152_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_320, false); A_arbace_classes_interp_eval393000151_fn__393000152_A_fn_class = fncls__56d; tmp4 = fncls__56d } else { tmp4 = fncls__56 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_classes_interp__init_part0_A_Unit59__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(412, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_103; var tmp3 any = A_arbace_classes_interp_eval393000155_fn__393000156_A_New(); var tmp4 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_classes_interp_eval393000155_fn__393000156_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_321, false); A_arbace_classes_interp_eval393000155_fn__393000156_A_fn_class = fncls__57d; tmp4 = fncls__57d } else { tmp4 = fncls__57 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_classes_interp__init_part0_A_Unit60__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(413, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_104; var tmp3 any = A_arbace_classes_interp_eval393000159_fn__393000160_A_New(); var tmp4 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_classes_interp_eval393000159_fn__393000160_A_fn_class; if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_322, false); A_arbace_classes_interp_eval393000159_fn__393000160_A_fn_class = fncls__58d; tmp4 = fncls__58d } else { tmp4 = fncls__58 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_classes_interp__init_part0_A_Unit61__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(415, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_105; var tmp3 any = A_arbace_classes_interp_eval393000163_fn__393000164_A_New(); var tmp4 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_classes_interp_eval393000163_fn__393000164_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_323, false); A_arbace_classes_interp_eval393000163_fn__393000164_A_fn_class = fncls__59d; tmp4 = fncls__59d } else { tmp4 = fncls__59 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_classes_interp__init_part0_A_Unit62__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(418, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_106; var tmp2 any = A_arbace_classes_interp_and_or_A_New(); var tmp3 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_classes_interp_and_or_A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_324, false); A_arbace_classes_interp_and_or_A_fn_class = fncls__60d; tmp3 = fncls__60d } else { tmp3 = fncls__60 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_106; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_107)); return A_arbace_classes_interp__init_part0_A_const_106 }




func A_arbace_classes_interp__init_part0_A_Unit63__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(423, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_108; var tmp3 any = A_arbace_classes_interp_eval393000171_fn__393000172_A_New(); var tmp4 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_classes_interp_eval393000171_fn__393000172_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_325, false); A_arbace_classes_interp_eval393000171_fn__393000172_A_fn_class = fncls__61d; tmp4 = fncls__61d } else { tmp4 = fncls__61 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_classes_interp__init_part0_A_Unit64__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(424, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_109; var tmp3 any = A_arbace_classes_interp_eval393000175_fn__393000176_A_New(); var tmp4 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_classes_interp_eval393000175_fn__393000176_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_326, false); A_arbace_classes_interp_eval393000175_fn__393000176_A_fn_class = fncls__62d; tmp4 = fncls__62d } else { tmp4 = fncls__62 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_classes_interp__init_part0_A_Unit65__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(426, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_110; var tmp3 any = A_arbace_classes_interp_eval393000179_fn__393000180_A_New(); var tmp4 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_classes_interp_eval393000179_fn__393000180_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_327, false); A_arbace_classes_interp_eval393000179_fn__393000180_A_fn_class = fncls__63d; tmp4 = fncls__63d } else { tmp4 = fncls__63 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }




func A_arbace_classes_interp__init_part0_A_Unit66__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(431, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_111; var tmp3 any = A_arbace_classes_interp_eval393000186_fn__393000187_A_New(); var tmp4 *jrt.Class; var fncls__64 *jrt.Class = A_arbace_classes_interp_eval393000186_fn__393000187_A_fn_class; if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_328, false); A_arbace_classes_interp_eval393000186_fn__393000187_A_fn_class = fncls__64d; tmp4 = fncls__64d } else { tmp4 = fncls__64 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_classes_interp__init_part0_A_Unit67__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(434, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_112; var tmp2 any = A_arbace_classes_interp_let_node_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_classes_interp_let_node_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_329, false); A_arbace_classes_interp_let_node_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_112; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_113)); return A_arbace_classes_interp__init_part0_A_const_112 }

























func A_arbace_classes_interp__init_part0_A_Unit68__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(460, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_114; var tmp3 any = A_arbace_classes_interp_eval393000214_fn__393000215_A_New(); var tmp4 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_classes_interp_eval393000214_fn__393000215_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_330, false); A_arbace_classes_interp_eval393000214_fn__393000215_A_fn_class = fncls__66d; tmp4 = fncls__66d } else { tmp4 = fncls__66 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
func A_arbace_classes_interp__init_part0_A_Unit69__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(461, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_115; var tmp3 any = A_arbace_classes_interp_eval393000218_fn__393000219_A_New(); var tmp4 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_classes_interp_eval393000218_fn__393000219_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_331, false); A_arbace_classes_interp_eval393000218_fn__393000219_A_fn_class = fncls__67d; tmp4 = fncls__67d } else { tmp4 = fncls__67 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_classes_interp__init_part0_A_Unit70__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(463, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_116; var tmp3 any = A_arbace_classes_interp_eval393000222_fn__393000223_A_New(); var tmp4 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_classes_interp_eval393000222_fn__393000223_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_332, false); A_arbace_classes_interp_eval393000222_fn__393000223_A_fn_class = fncls__68d; tmp4 = fncls__68d } else { tmp4 = fncls__68 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_classes_interp__init_part0_A_Unit71__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(469, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_117; var tmp3 any = A_arbace_classes_interp_eval393000226_fn__393000227_A_New(); var tmp4 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_classes_interp_eval393000226_fn__393000227_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_333, false); A_arbace_classes_interp_eval393000226_fn__393000227_A_fn_class = fncls__69d; tmp4 = fncls__69d } else { tmp4 = fncls__69 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }








func A_arbace_classes_interp__init_part0_A_Unit72__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(478, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_118; var tmp3 any = A_arbace_classes_interp_eval393000230_fn__393000231_A_New(); var tmp4 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_classes_interp_eval393000230_fn__393000231_A_fn_class; if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_334, false); A_arbace_classes_interp_eval393000230_fn__393000231_A_fn_class = fncls__70d; tmp4 = fncls__70d } else { tmp4 = fncls__70 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_classes_interp__init_part0_A_Unit73__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(484, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_119; var tmp3 any = A_arbace_classes_interp_eval393000236_fn__393000237_A_New(); var tmp4 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_classes_interp_eval393000236_fn__393000237_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_335, false); A_arbace_classes_interp_eval393000236_fn__393000237_A_fn_class = fncls__71d; tmp4 = fncls__71d } else { tmp4 = fncls__71 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_classes_interp__init_part0_A_Unit74__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(491, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_120; var tmp3 any = A_arbace_classes_interp_eval393000240_fn__393000241_A_New(); var tmp4 *jrt.Class; var fncls__72 *jrt.Class = A_arbace_classes_interp_eval393000240_fn__393000241_A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_336, false); A_arbace_classes_interp_eval393000240_fn__393000241_A_fn_class = fncls__72d; tmp4 = fncls__72d } else { tmp4 = fncls__72 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_classes_interp__init_part0_A_Unit75__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(493, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_121; var tmp3 any = A_arbace_classes_interp_eval393000244_fn__393000245_A_New(); var tmp4 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_classes_interp_eval393000244_fn__393000245_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_337, false); A_arbace_classes_interp_eval393000244_fn__393000245_A_fn_class = fncls__73d; tmp4 = fncls__73d } else { tmp4 = fncls__73 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


















func A_arbace_classes_interp__init_part0_A_Unit76__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(512, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_122; var tmp3 any = A_arbace_classes_interp_eval393000285_fn__393000286_A_New(); var tmp4 *jrt.Class; var fncls__74 *jrt.Class = A_arbace_classes_interp_eval393000285_fn__393000286_A_fn_class; if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_338, false); A_arbace_classes_interp_eval393000285_fn__393000286_A_fn_class = fncls__74d; tmp4 = fncls__74d } else { tmp4 = fncls__74 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_classes_interp__init_part0_A_Unit77__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(516, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_123; var tmp3 any = A_arbace_classes_interp_eval393000289_fn__393000290_A_New(); var tmp4 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_classes_interp_eval393000289_fn__393000290_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_339, false); A_arbace_classes_interp_eval393000289_fn__393000290_A_fn_class = fncls__75d; tmp4 = fncls__75d } else { tmp4 = fncls__75 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_classes_interp__init_part0_A_Unit78__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(523, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_124; var tmp2 any = A_arbace_classes_interp_arg_nodes_A_New(); var tmp3 *jrt.Class; var fncls__76 *jrt.Class = A_arbace_classes_interp_arg_nodes_A_fn_class; if fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_340, false); A_arbace_classes_interp_arg_nodes_A_fn_class = fncls__76d; tmp3 = fncls__76d } else { tmp3 = fncls__76 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_124; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_125)); return A_arbace_classes_interp__init_part0_A_const_124 }


func A_arbace_classes_interp__init_part0_A_Unit79__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(526, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_126; var tmp2 any = A_arbace_classes_interp_ptypes_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_classes_interp_ptypes_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_341, false); A_arbace_classes_interp_ptypes_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_126; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_127)); return A_arbace_classes_interp__init_part0_A_const_126 }

func A_arbace_classes_interp__init_part0_A_Unit80__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(528, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_128; var tmp2 any = A_arbace_classes_interp_has_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__78 *jrt.Class = A_arbace_classes_interp_has_QMARK__A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_342, false); A_arbace_classes_interp_has_QMARK__A_fn_class = fncls__78d; tmp3 = fncls__78d } else { tmp3 = fncls__78 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_128; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_129)); return A_arbace_classes_interp__init_part0_A_const_128 }
func A_arbace_classes_interp__init_part0_A_Unit81__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(529, 1); A_arbace_classes_interp__init_part0_A_const_130.BindRoot_O__V(A_arbace_classes_interp__init_part0_A_const_131); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_130; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_132)); return A_arbace_classes_interp__init_part0_A_const_130 }
func A_arbace_classes_interp__init_part0_A_Unit82__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(530, 1); A_arbace_classes_interp__init_part0_A_const_133.BindRoot_O__V(A_arbace_classes_interp__init_part0_A_const_134); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_133; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_135)); return A_arbace_classes_interp__init_part0_A_const_133 }
func A_arbace_classes_interp__init_part0_A_Unit83__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(531, 1); A_arbace_classes_interp__init_part0_A_const_136.BindRoot_O__V(A_arbace_classes_interp__init_part0_A_const_137); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_136; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_138)); return A_arbace_classes_interp__init_part0_A_const_136 }
func A_arbace_classes_interp__init_part0_A_Unit84__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(532, 1); A_arbace_classes_interp__init_part0_A_const_139.BindRoot_O__V(A_arbace_classes_interp__init_part0_A_const_140); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_139; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_141)); return A_arbace_classes_interp__init_part0_A_const_139 }

func A_arbace_classes_interp__init_part0_A_Unit85__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(534, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_142; var tmp2 any = A_arbace_classes_interp_method_of_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_classes_interp_method_of_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_343, false); A_arbace_classes_interp_method_of_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_142; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_143)); return A_arbace_classes_interp__init_part0_A_const_142 }








func A_arbace_classes_interp__init_part0_A_Unit86__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(543, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_144; var tmp2 any = A_arbace_classes_interp_private_method_A_New(); var tmp3 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_classes_interp_private_method_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_344, false); A_arbace_classes_interp_private_method_A_fn_class = fncls__80d; tmp3 = fncls__80d } else { tmp3 = fncls__80 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_144; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_145)); return A_arbace_classes_interp__init_part0_A_const_144 }







func A_arbace_classes_interp__init_part0_A_Unit87__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(551, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_146; var tmp3 any = A_arbace_classes_interp_eval393000303_fn__393000304_A_New(); var tmp4 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_classes_interp_eval393000303_fn__393000304_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_345, false); A_arbace_classes_interp_eval393000303_fn__393000304_A_fn_class = fncls__81d; tmp4 = fncls__81d } else { tmp4 = fncls__81 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }









































func A_arbace_classes_interp__init_part0_A_Unit88__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(593, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_147; var tmp2 any = A_arbace_classes_interp_ctor_meth_A_New(); var tmp3 *jrt.Class; var fncls__82 *jrt.Class = A_arbace_classes_interp_ctor_meth_A_fn_class; if fncls__82 == nil { var fncls__82d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_346, false); A_arbace_classes_interp_ctor_meth_A_fn_class = fncls__82d; tmp3 = fncls__82d } else { tmp3 = fncls__82 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_147; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_148)); return A_arbace_classes_interp__init_part0_A_const_147 }


func A_arbace_classes_interp__init_part0_A_Unit89__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(596, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_149; var tmp2 any = A_arbace_classes_interp_implicit_fields_A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_classes_interp_implicit_fields_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_347, false); A_arbace_classes_interp_implicit_fields_A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_149; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_150)); return A_arbace_classes_interp__init_part0_A_const_149 }












func A_arbace_classes_interp__init_part0_A_Unit90__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(609, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_151; var tmp2 any = A_arbace_classes_interp_super_outer_fields_A_New(); var tmp3 *jrt.Class; var fncls__84 *jrt.Class = A_arbace_classes_interp_super_outer_fields_A_fn_class; if fncls__84 == nil { var fncls__84d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_348, false); A_arbace_classes_interp_super_outer_fields_A_fn_class = fncls__84d; tmp3 = fncls__84d } else { tmp3 = fncls__84 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_151; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_152)); return A_arbace_classes_interp__init_part0_A_const_151 }















func A_arbace_classes_interp__init_part0_A_Unit91__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(625, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_153; var tmp3 any = A_arbace_classes_interp_eval393000324_fn__393000325_A_New(); var tmp4 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_classes_interp_eval393000324_fn__393000325_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_349, false); A_arbace_classes_interp_eval393000324_fn__393000325_A_fn_class = fncls__85d; tmp4 = fncls__85d } else { tmp4 = fncls__85 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





























func A_arbace_classes_interp__init_part0_A_Unit92__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(655, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_154; var tmp2 any = A_arbace_classes_interp_clj_const_value_A_New(); var tmp3 *jrt.Class; var fncls__86 *jrt.Class = A_arbace_classes_interp_clj_const_value_A_fn_class; if fncls__86 == nil { var fncls__86d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_350, false); A_arbace_classes_interp_clj_const_value_A_fn_class = fncls__86d; tmp3 = fncls__86d } else { tmp3 = fncls__86 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_154; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_155)); return A_arbace_classes_interp__init_part0_A_const_154 }










func A_arbace_classes_interp__init_part0_A_Unit93__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(666, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_156; var tmp3 any = A_arbace_classes_interp_eval393000346_fn__393000347_A_New(); var tmp4 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_classes_interp_eval393000346_fn__393000347_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_351, false); A_arbace_classes_interp_eval393000346_fn__393000347_A_fn_class = fncls__87d; tmp4 = fncls__87d } else { tmp4 = fncls__87 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }















func A_arbace_classes_interp__init_part0_A_Unit94__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(682, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_157; var tmp3 any = A_arbace_classes_interp_eval393000353_fn__393000354_A_New(); var tmp4 *jrt.Class; var fncls__88 *jrt.Class = A_arbace_classes_interp_eval393000353_fn__393000354_A_fn_class; if fncls__88 == nil { var fncls__88d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_352, false); A_arbace_classes_interp_eval393000353_fn__393000354_A_fn_class = fncls__88d; tmp4 = fncls__88d } else { tmp4 = fncls__88 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }











func A_arbace_classes_interp__init_part0_A_Unit95__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(694, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_158; var tmp3 any = A_arbace_classes_interp_eval393000360_fn__393000361_A_New(); var tmp4 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_classes_interp_eval393000360_fn__393000361_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_353, false); A_arbace_classes_interp_eval393000360_fn__393000361_A_fn_class = fncls__89d; tmp4 = fncls__89d } else { tmp4 = fncls__89 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }











func A_arbace_classes_interp__init_part0_A_Unit96__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(706, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_159; var tmp3 any = A_arbace_classes_interp_eval393000364_fn__393000365_A_New(); var tmp4 *jrt.Class; var fncls__90 *jrt.Class = A_arbace_classes_interp_eval393000364_fn__393000365_A_fn_class; if fncls__90 == nil { var fncls__90d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_354, false); A_arbace_classes_interp_eval393000364_fn__393000365_A_fn_class = fncls__90d; tmp4 = fncls__90d } else { tmp4 = fncls__90 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }












func A_arbace_classes_interp__init_part0_A_Unit97__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(719, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_160; var tmp3 any = A_arbace_classes_interp_eval393000368_fn__393000369_A_New(); var tmp4 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_classes_interp_eval393000368_fn__393000369_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_355, false); A_arbace_classes_interp_eval393000368_fn__393000369_A_fn_class = fncls__91d; tmp4 = fncls__91d } else { tmp4 = fncls__91 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_classes_interp__init_part0_A_Unit98__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(726, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_161; var tmp3 any = A_arbace_classes_interp_eval393000373_fn__393000374_A_New(); var tmp4 *jrt.Class; var fncls__92 *jrt.Class = A_arbace_classes_interp_eval393000373_fn__393000374_A_fn_class; if fncls__92 == nil { var fncls__92d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_356, false); A_arbace_classes_interp_eval393000373_fn__393000374_A_fn_class = fncls__92d; tmp4 = fncls__92d } else { tmp4 = fncls__92 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }




func A_arbace_classes_interp__init_part0_A_Unit99__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(731, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_162; var tmp3 any = A_arbace_classes_interp_eval393000379_fn__393000380_A_New(); var tmp4 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_classes_interp_eval393000379_fn__393000380_A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_357, false); A_arbace_classes_interp_eval393000379_fn__393000380_A_fn_class = fncls__93d; tmp4 = fncls__93d } else { tmp4 = fncls__93 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_classes_interp__init_part1_A_Unit100__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(737, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part1_A_const_0.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part1_A_const_1; var tmp3 any = A_arbace_classes_interp_eval393000384_fn__393000385_A_New(); var tmp4 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_classes_interp_eval393000384_fn__393000385_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_359, false); A_arbace_classes_interp_eval393000384_fn__393000385_A_fn_class = fncls__1d; tmp4 = fncls__1d } else { tmp4 = fncls__1 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }
//line :737:1
func A_arbace_classes_interp__init_part1_A_Init__O() any { A_arbace_classes_interp__init_part1_A_Init(); return nil }
//line :737:1
func A_arbace_classes_interp__init_part1_A_Load__O() any { A_arbace_classes_interp__init_part1_A_Init(); A_arbace_classes_interp__init_part1_A_Unit100__O(); A_arbace_classes_interp__init_part1_A_Unit101__O(); A_arbace_classes_interp__init_part1_A_Unit102__O(); A_arbace_classes_interp__init_part1_A_Unit103__O(); A_arbace_classes_interp__init_part1_A_Unit104__O(); A_arbace_classes_interp__init_part1_A_Unit105__O(); A_arbace_classes_interp__init_part1_A_Unit106__O(); A_arbace_classes_interp__init_part1_A_Unit107__O(); A_arbace_classes_interp__init_part1_A_Unit108__O(); A_arbace_classes_interp__init_part1_A_Unit109__O(); A_arbace_classes_interp__init_part1_A_Unit110__O(); A_arbace_classes_interp__init_part1_A_Unit111__O(); A_arbace_classes_interp__init_part1_A_Unit112__O(); A_arbace_classes_interp__init_part1_A_Unit113__O(); A_arbace_classes_interp__init_part1_A_Unit114__O(); A_arbace_classes_interp__init_part1_A_Unit115__O(); A_arbace_classes_interp__init_part1_A_Unit116__O(); A_arbace_classes_interp__init_part1_A_Unit117__O(); A_arbace_classes_interp__init_part1_A_Unit118__O(); A_arbace_classes_interp__init_part1_A_Unit119__O(); A_arbace_classes_interp__init_part1_A_Unit120__O(); A_arbace_classes_interp__init_part1_A_Unit121__O(); A_arbace_classes_interp__init_part1_A_Unit122__O(); A_arbace_classes_interp__init_part1_A_Unit123__O(); A_arbace_classes_interp__init_part1_A_Unit124__O(); A_arbace_classes_interp__init_part1_A_Unit125__O(); A_arbace_classes_interp__init_part1_A_Unit126__O(); A_arbace_classes_interp__init_part1_A_Unit127__O(); A_arbace_classes_interp__init_part1_A_Unit128__O(); A_arbace_classes_interp__init_part1_A_Unit129__O(); A_arbace_classes_interp__init_part1_A_Unit130__O(); A_arbace_classes_interp__init_part1_A_Unit131__O(); A_arbace_classes_interp__init_part1_A_Unit132__O(); A_arbace_classes_interp__init_part1_A_Unit133__O(); A_arbace_classes_interp__init_part1_A_Unit134__O(); A_arbace_classes_interp__init_part1_A_Unit135__O(); A_arbace_classes_interp__init_part1_A_Unit136__O(); A_arbace_classes_interp__init_part1_A_Unit137__O(); A_arbace_classes_interp__init_part1_A_Unit138__O(); A_arbace_classes_interp__init_part1_A_Unit139__O(); A_arbace_classes_interp__init_part1_A_Unit140__O(); A_arbace_classes_interp__init_part1_A_Unit141__O(); A_arbace_classes_interp__init_part1_A_Unit142__O(); A_arbace_classes_interp__init_part1_A_Unit143__O(); A_arbace_classes_interp__init_part1_A_Unit144__O(); A_arbace_classes_interp__init_part1_A_Unit145__O(); A_arbace_classes_interp__init_part1_A_Unit146__O(); A_arbace_classes_interp__init_part1_A_Unit147__O(); A_arbace_classes_interp__init_part1_A_Unit148__O(); A_arbace_classes_interp__init_part1_A_Unit149__O(); A_arbace_classes_interp__init_part1_A_Unit150__O(); A_arbace_classes_interp__init_part1_A_Unit151__O(); A_arbace_classes_interp__init_part1_A_Unit152__O(); return nil }





func A_arbace_classes_interp__init_part1_A_Unit101__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(743, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part1_A_const_0.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part1_A_const_2; var tmp3 any = A_arbace_classes_interp_eval393000391_fn__393000392_A_New(); var tmp4 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_classes_interp_eval393000391_fn__393000392_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_360, false); A_arbace_classes_interp_eval393000391_fn__393000392_A_fn_class = fncls__2d; tmp4 = fncls__2d } else { tmp4 = fncls__2 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_classes_interp__init_part1_A_Unit102__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(747, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part1_A_const_0.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part1_A_const_3; var tmp3 any = A_arbace_classes_interp_eval393000397_fn__393000398_A_New(); var tmp4 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_classes_interp_eval393000397_fn__393000398_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_361, false); A_arbace_classes_interp_eval393000397_fn__393000398_A_fn_class = fncls__3d; tmp4 = fncls__3d } else { tmp4 = fncls__3 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_classes_interp__init_part1_A_Unit103__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(750, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part1_A_const_0.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part1_A_const_4; var tmp3 any = A_arbace_classes_interp_eval393000401_fn__393000402_A_New(); var tmp4 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_classes_interp_eval393000401_fn__393000402_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_362, false); A_arbace_classes_interp_eval393000401_fn__393000402_A_fn_class = fncls__4d; tmp4 = fncls__4d } else { tmp4 = fncls__4 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_classes_interp__init_part1_A_Unit104__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(754, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part1_A_const_0.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part1_A_const_5; var tmp3 any = A_arbace_classes_interp_eval393000405_fn__393000406_A_New(); var tmp4 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_classes_interp_eval393000405_fn__393000406_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_363, false); A_arbace_classes_interp_eval393000405_fn__393000406_A_fn_class = fncls__5d; tmp4 = fncls__5d } else { tmp4 = fncls__5 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

func A_arbace_classes_interp__init_part1_A_Unit105__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(756, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part1_A_const_0.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part1_A_const_6; var tmp3 any = A_arbace_classes_interp_eval393000409_fn__393000410_A_New(); var tmp4 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_classes_interp_eval393000409_fn__393000410_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_364, false); A_arbace_classes_interp_eval393000409_fn__393000410_A_fn_class = fncls__6d; tmp4 = fncls__6d } else { tmp4 = fncls__6 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }









func A_arbace_classes_interp__init_part1_A_Unit106__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(766, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part1_A_const_0.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part1_A_const_7; var tmp3 any = A_arbace_classes_interp_eval393000421_fn__393000422_A_New(); var tmp4 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_classes_interp_eval393000421_fn__393000422_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_365, false); A_arbace_classes_interp_eval393000421_fn__393000422_A_fn_class = fncls__7d; tmp4 = fncls__7d } else { tmp4 = fncls__7 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }




















func A_arbace_classes_interp__init_part1_A_Unit107__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(787, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_8; var tmp2 any = A_arbace_classes_interp_accessor_node_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_classes_interp_accessor_node_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_366, false); A_arbace_classes_interp_accessor_node_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_9)); return A_arbace_classes_interp__init_part1_A_const_8 }










func A_arbace_classes_interp__init_part1_A_Unit108__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(798, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_10; var tmp2 any = A_arbace_classes_interp_pattern_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_classes_interp_pattern_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_367, false); A_arbace_classes_interp_pattern_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_11)); return A_arbace_classes_interp__init_part1_A_const_10 }



















func A_arbace_classes_interp__init_part1_A_Unit109__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(818, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part1_A_const_0.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part1_A_const_12; var tmp3 any = A_arbace_classes_interp_eval393000434_fn__393000435_A_New(); var tmp4 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_classes_interp_eval393000434_fn__393000435_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_368, false); A_arbace_classes_interp_eval393000434_fn__393000435_A_fn_class = fncls__10d; tmp4 = fncls__10d } else { tmp4 = fncls__10 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }






func A_arbace_classes_interp__init_part1_A_Unit110__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(825, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part1_A_const_0.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part1_A_const_13; var tmp3 any = A_arbace_classes_interp_eval393000440_fn__393000441_A_New(); var tmp4 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_classes_interp_eval393000440_fn__393000441_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_369, false); A_arbace_classes_interp_eval393000440_fn__393000441_A_fn_class = fncls__11d; tmp4 = fncls__11d } else { tmp4 = fncls__11 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





































func A_arbace_classes_interp__init_part1_A_Unit111__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(863, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_14; var tmp2 any = A_arbace_classes_interp_host_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_classes_interp_host_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_370, false); A_arbace_classes_interp_host_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_15)); return A_arbace_classes_interp__init_part1_A_const_14 }

func A_arbace_classes_interp__init_part1_A_Unit112__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(865, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_16; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_17)); return A_arbace_classes_interp__init_part1_A_const_16 }
//line :865:1
func A_arbace_classes_interp__init_part1_A_Unit113__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(865, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_18; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_19)); return A_arbace_classes_interp__init_part1_A_const_18 }

func A_arbace_classes_interp__init_part1_A_Unit114__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(867, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_20; var tmp2 any = A_arbace_classes_interp_meth_of_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_classes_interp_meth_of_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_371, false); A_arbace_classes_interp_meth_of_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_21)); return A_arbace_classes_interp__init_part1_A_const_20 }









func A_arbace_classes_interp__init_part1_A_Unit115__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(877, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_22; var tmp2 any = A_arbace_classes_interp_zero_of_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_classes_interp_zero_of_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_372, false); A_arbace_classes_interp_zero_of_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_23)); return A_arbace_classes_interp__init_part1_A_const_22 }

func A_arbace_classes_interp__init_part1_A_Unit116__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(879, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_24; var tmp2 any = A_arbace_classes_interp_make_klass_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_classes_interp_make_klass_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_373, false); A_arbace_classes_interp_make_klass_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_25)); return A_arbace_classes_interp__init_part1_A_const_24 }











func A_arbace_classes_interp__init_part1_A_Unit117__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(891, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_26; var tmp2 any = A_arbace_classes_interp_layout_BANG__A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_classes_interp_layout_BANG__A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_374, false); A_arbace_classes_interp_layout_BANG__A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_27)); return A_arbace_classes_interp__init_part1_A_const_26 }
























































func A_arbace_classes_interp__init_part1_A_Unit118__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(948, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_28; var tmp2 any = A_arbace_classes_interp_vtable_BANG__A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_classes_interp_vtable_BANG__A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_375, false); A_arbace_classes_interp_vtable_BANG__A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_29)); return A_arbace_classes_interp__init_part1_A_const_28 }

















func A_arbace_classes_interp__init_part1_A_Unit119__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(966, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_30; var tmp2 any = A_arbace_classes_interp_ctx_for_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_classes_interp_ctx_for_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_376, false); A_arbace_classes_interp_ctx_for_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_31)); return A_arbace_classes_interp__init_part1_A_const_30 }







func A_arbace_classes_interp__init_part1_A_Unit120__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(974, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_32; var tmp2 any = A_arbace_classes_interp_receiver_ctx_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_classes_interp_receiver_ctx_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_377, false); A_arbace_classes_interp_receiver_ctx_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_33)); return A_arbace_classes_interp__init_part1_A_const_32 }




func A_arbace_classes_interp__init_part1_A_Unit121__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(979, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_34; var tmp2 any = A_arbace_classes_interp_params_BANG__A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_classes_interp_params_BANG__A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_378, false); A_arbace_classes_interp_params_BANG__A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_35)); return A_arbace_classes_interp__init_part1_A_const_34 }




func A_arbace_classes_interp__init_part1_A_Unit122__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(984, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_36; var tmp2 any = A_arbace_classes_interp_finish_BANG__A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_classes_interp_finish_BANG__A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_379, false); A_arbace_classes_interp_finish_BANG__A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_37)); return A_arbace_classes_interp__init_part1_A_const_36 }





func A_arbace_classes_interp__init_part1_A_Unit123__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(990, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_38; var tmp2 any = A_arbace_classes_interp_record_op_node_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_classes_interp_record_op_node_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_380, false); A_arbace_classes_interp_record_op_node_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_39)); return A_arbace_classes_interp__init_part1_A_const_38 }








func A_arbace_classes_interp__init_part1_A_Unit124__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(999, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_40; var tmp2 any = A_arbace_classes_interp_derived_body_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_classes_interp_derived_body_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_381, false); A_arbace_classes_interp_derived_body_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_41)); return A_arbace_classes_interp__init_part1_A_const_40 }














































func A_arbace_classes_interp__init_part1_A_Unit125__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1046, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_42; var tmp2 any = A_arbace_classes_interp_init_nodes_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_classes_interp_init_nodes_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_382, false); A_arbace_classes_interp_init_nodes_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_43)); return A_arbace_classes_interp__init_part1_A_const_42 }




func A_arbace_classes_interp__init_part1_A_Unit126__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1051, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_44; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_45)); return A_arbace_classes_interp__init_part1_A_const_44 }

func A_arbace_classes_interp__init_part1_A_Unit127__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1053, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_46; var tmp2 any = A_arbace_classes_interp_trivial_super_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_classes_interp_trivial_super_QMARK__A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_383, false); A_arbace_classes_interp_trivial_super_QMARK__A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_47)); return A_arbace_classes_interp__init_part1_A_const_46 }






func A_arbace_classes_interp__init_part1_A_Unit128__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1060, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_48; var tmp2 any = A_arbace_classes_interp_local_super_fields_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_classes_interp_local_super_fields_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_384, false); A_arbace_classes_interp_local_super_fields_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_49)); return A_arbace_classes_interp__init_part1_A_const_48 }









func A_arbace_classes_interp__init_part1_A_Unit129__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1070, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_50; var tmp2 any = A_arbace_classes_interp_ctor_call_node_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_classes_interp_ctor_call_node_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_385, false); A_arbace_classes_interp_ctor_call_node_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_51)); return A_arbace_classes_interp__init_part1_A_const_50 }
















































func A_arbace_classes_interp__init_part1_A_Unit130__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1119, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_44; var tmp2 any = A_arbace_classes_interp_enum_arg_nodes_A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_classes_interp_enum_arg_nodes_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_386, false); A_arbace_classes_interp_enum_arg_nodes_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_52)); return A_arbace_classes_interp__init_part1_A_const_44 }






func A_arbace_classes_interp__init_part1_A_Unit131__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1126, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part1_A_const_0.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part1_A_const_53; var tmp3 any = A_arbace_classes_interp_eval393000717_fn__393000718_A_New(); var tmp4 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_classes_interp_eval393000717_fn__393000718_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_387, false); A_arbace_classes_interp_eval393000717_fn__393000718_A_fn_class = fncls__29d; tmp4 = fncls__29d } else { tmp4 = fncls__29 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }




func A_arbace_classes_interp__init_part1_A_Unit132__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1131, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_16; var tmp2 any = A_arbace_classes_interp_build_method_BANG__A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_classes_interp_build_method_BANG__A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_388, false); A_arbace_classes_interp_build_method_BANG__A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_54)); return A_arbace_classes_interp__init_part1_A_const_16 }




































































func A_arbace_classes_interp__init_part1_A_Unit133__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1200, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_55; var tmp2 any = A_arbace_classes_interp_declare_siblings_BANG__A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_classes_interp_declare_siblings_BANG__A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_389, false); A_arbace_classes_interp_declare_siblings_BANG__A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_56)); return A_arbace_classes_interp__init_part1_A_const_55 }











func A_arbace_classes_interp__init_part1_A_Unit134__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1212, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_57; var tmp2 any = A_arbace_classes_interp_analyze_forms_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_classes_interp_analyze_forms_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_390, false); A_arbace_classes_interp_analyze_forms_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_58)); return A_arbace_classes_interp__init_part1_A_const_57 }















func A_arbace_classes_interp__init_part1_A_Unit135__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1228, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_59; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_60)); v__1927001498__auto____1 = A_arbace_classes_interp__init_part1_A_const_59; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_classes_interp__init_part1_A_const_59; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_63)); var tmp3 *lang.Var = A_arbace_classes_interp__init_part1_A_const_59; var tmp4 any; var root_33 any = A_arbace_classes_interp__init_part1_A_const_61.GetRawRoot__O(); var linked_34 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_33, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_35 lang.IFn; if linked_34 == nil { ifn_35 = lang.IFn_Cast(root_33) } else { ifn_35 = nil }; var arg_36 any = A_arbace_classes_interp__init_part1_A_const_62; if linked_34 == nil { tmp4 = ifn_35.Invoke_O__O(arg_36) } else { tmp4 = linked_34.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_33, arg_36) }; tmp3.BindRoot_O__V(tmp4); return A_arbace_classes_interp__init_part1_A_const_59 } }

func A_arbace_classes_interp__init_part1_A_Unit136__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1230, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_64; var tmp2 any = A_arbace_classes_interp_new_lambda_klass_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_classes_interp_new_lambda_klass_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_391, false); A_arbace_classes_interp_new_lambda_klass_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_65)); return A_arbace_classes_interp__init_part1_A_const_64 }















func A_arbace_classes_interp__init_part1_A_Unit137__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1246, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_66; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_67)); return A_arbace_classes_interp__init_part1_A_const_66 }
//line :1246:1
func A_arbace_classes_interp__init_part1_A_Unit138__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1246, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_68; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_69)); return A_arbace_classes_interp__init_part1_A_const_68 }

func A_arbace_classes_interp__init_part1_A_Unit139__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1248, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_70; var tmp2 any = A_arbace_classes_interp_lambda_done_BANG__A_New(); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_classes_interp_lambda_done_BANG__A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_392, true); A_arbace_classes_interp_lambda_done_BANG__A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_71)); return A_arbace_classes_interp__init_part1_A_const_70 }














func A_arbace_classes_interp__init_part1_A_Unit140__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1263, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part1_A_const_0.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part1_A_const_72; var tmp3 any = A_arbace_classes_interp_eval393000804_fn__393000805_A_New(); var tmp4 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_classes_interp_eval393000804_fn__393000805_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_393, false); A_arbace_classes_interp_eval393000804_fn__393000805_A_fn_class = fncls__39d; tmp4 = fncls__39d } else { tmp4 = fncls__39 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }




















func A_arbace_classes_interp__init_part1_A_Unit141__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1284, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part1_A_const_0.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part1_A_const_73; var tmp3 any = A_arbace_classes_interp_eval393000816_fn__393000817_A_New(); var tmp4 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_classes_interp_eval393000816_fn__393000817_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_394, false); A_arbace_classes_interp_eval393000816_fn__393000817_A_fn_class = fncls__40d; tmp4 = fncls__40d } else { tmp4 = fncls__40 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }

























































func A_arbace_classes_interp__init_part1_A_Unit142__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1342, 1); A_arbace_classes_interp__init_part1_A_const_74.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_74; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_75)); return A_arbace_classes_interp__init_part1_A_const_74.SetDynamic_Z__Var(true).Ref() }




func A_arbace_classes_interp__init_part1_A_Unit143__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1347, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_76; var tmp2 any; var root_41 any = A_arbace_classes_interp__init_part1_A_const_61.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_41, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_43 lang.IFn; if


	linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_42 == nil { tmp2 = ifn_43.Invoke_O__O(arg_44) } else { tmp2 = linked_42.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_41, arg_44) }; /*line :1347:1*/tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_classes_interp__init_part1_A_const_76; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_77)); return A_arbace_classes_interp__init_part1_A_const_76 }




func A_arbace_classes_interp__init_part1_A_Unit144__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1352, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_78; var tmp2 any = A_arbace_classes_interp_sig_class_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_classes_interp_sig_class_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_395, false); A_arbace_classes_interp_sig_class_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_79)); return A_arbace_classes_interp__init_part1_A_const_78 }













func A_arbace_classes_interp__init_part1_A_Unit145__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1366, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_80; var tmp2 any = A_arbace_classes_interp_meth_classes_A_New(); var tmp3 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_classes_interp_meth_classes_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_396, false); A_arbace_classes_interp_meth_classes_A_fn_class = fncls__46d; tmp3 = fncls__46d } else { tmp3 = fncls__46 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_81)); return A_arbace_classes_interp__init_part1_A_const_80 }




func A_arbace_classes_interp__init_part1_A_Unit146__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1371, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_66; var tmp2 any = A_arbace_classes_interp_publish_BANG__A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_classes_interp_publish_BANG__A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_397, false); A_arbace_classes_interp_publish_BANG__A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_82)); return A_arbace_classes_interp__init_part1_A_const_66 }










func A_arbace_classes_interp__init_part1_A_Unit147__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1382, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_83; var tmp2 any = A_arbace_classes_interp_republish_BANG__A_New(); var tmp3 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_classes_interp_republish_BANG__A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_398, false); A_arbace_classes_interp_republish_BANG__A_fn_class = fncls__48d; tmp3 = fncls__48d } else { tmp3 = fncls__48 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_83; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_84)); return A_arbace_classes_interp__init_part1_A_const_83 }











func A_arbace_classes_interp__init_part1_A_Unit148__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1394, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_68; var tmp2 any = A_arbace_classes_interp_publish_members_BANG__A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_classes_interp_publish_members_BANG__A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_399, false); A_arbace_classes_interp_publish_members_BANG__A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_85)); return A_arbace_classes_interp__init_part1_A_const_68 }




















func A_arbace_classes_interp__init_part1_A_Unit149__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1415, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_86; var tmp2 any = A_arbace_classes_interp_clinit_BANG__A_New(); var tmp3 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_classes_interp_clinit_BANG__A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_400, false); A_arbace_classes_interp_clinit_BANG__A_fn_class = fncls__50d; tmp3 = fncls__50d } else { tmp3 = fncls__50 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_87)); return A_arbace_classes_interp__init_part1_A_const_86 }


























func A_arbace_classes_interp__init_part1_A_Unit150__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1442, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_88; var tmp2 any = A_arbace_classes_interp_define_BANG__A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_classes_interp_define_BANG__A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_401, false); A_arbace_classes_interp_define_BANG__A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_88; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_89)); return A_arbace_classes_interp__init_part1_A_const_88 }



























































func A_arbace_classes_interp__init_part1_A_Unit151__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1502, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_90; var tmp2 any = A_arbace_classes_interp_compile_and_load_BANG__A_New(); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_classes_interp_compile_and_load_BANG__A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_402, true); A_arbace_classes_interp_compile_and_load_BANG__A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_90; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_91)); return A_arbace_classes_interp__init_part1_A_const_90 }






func A_arbace_classes_interp__init_part1_A_Unit152__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1509, 1); var tmp1 lang.Compiler_CF_Host_I; lang.Compiler_CF_Rt_Init(); tmp1 = lang.Compiler_CF_Rt_HOST; if lang.Util_Identical_O_O__Z_NoInit(tmp1, nil) { var temp__1927000414__auto____1 any; var tmp2 any = A_arbace_classes_interp_eval393001028_fn__393001029_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_classes_interp_eval393001028_fn__393001029_A_fn_class
								if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_403, false); A_arbace_classes_interp_eval393001028_fn__393001029_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; temp__1927000414__auto____1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O(); if jrt.J2g_Truth(temp__1927000414__auto____1) { var c__2 any = temp__1927000414__auto____1
									lang.Compiler_CF_Rt_SetHost_Compiler_CF_Host__V(lang.Compiler_CF_Host_Cast(jrt.NN(jrt.Class_Cast(c__2)).NewInstance__O())); return nil } else {
//line :1510:1
			return nil } } else {
//line :1509:1
				return nil } }





type A_arbace_classes_interp__init_A struct{ jrt.Object }

func A_arbace_classes_interp__init_A_New() *A_arbace_classes_interp__init_A { t := &A_arbace_classes_interp__init_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_interp__init_A) Ctor() {}

func (t *A_arbace_classes_interp__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_interp__init_A) GetClass__Class() *jrt.Class { return A_arbace_classes_interp__init_A_class }

func (t *A_arbace_classes_interp__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_interp__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_interp__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_interp__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_interp__init_A); return ok }

func A_arbace_classes_interp__init_A_Cast(x any) *A_arbace_classes_interp__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_interp__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_interp__init_A_class)) }; return v }



type A_arbace_classes_interp__init_part0_A struct{ jrt.Object }

var A_arbace_classes_interp__init_part0_A_const_pool *jrt.RefArray

var A_arbace_classes_interp__init_part0_A_const_0 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_1 any

var A_arbace_classes_interp__init_part0_A_const_2 any

var A_arbace_classes_interp__init_part0_A_const_3 any

var A_arbace_classes_interp__init_part0_A_const_4 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_5 any

var A_arbace_classes_interp__init_part0_A_const_6 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_7 any

var A_arbace_classes_interp__init_part0_A_const_8 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_9 any

var A_arbace_classes_interp__init_part0_A_const_10 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_11 any

var A_arbace_classes_interp__init_part0_A_const_12 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_13 any

var A_arbace_classes_interp__init_part0_A_const_14 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_15 any

var A_arbace_classes_interp__init_part0_A_const_16 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_17 any

var A_arbace_classes_interp__init_part0_A_const_18 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_19 any

var A_arbace_classes_interp__init_part0_A_const_20 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_21 any

var A_arbace_classes_interp__init_part0_A_const_22 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_23 any

var A_arbace_classes_interp__init_part0_A_const_24 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_25 any

var A_arbace_classes_interp__init_part0_A_const_26 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_27 any

var A_arbace_classes_interp__init_part0_A_const_28 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_29 any

var A_arbace_classes_interp__init_part0_A_const_30 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_31 any

var A_arbace_classes_interp__init_part0_A_const_32 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_33 any

var A_arbace_classes_interp__init_part0_A_const_34 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_35 any

var A_arbace_classes_interp__init_part0_A_const_36 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_37 any

var A_arbace_classes_interp__init_part0_A_const_38 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_39 any

var A_arbace_classes_interp__init_part0_A_const_40 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_41 any

var A_arbace_classes_interp__init_part0_A_const_42 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_43 any

var A_arbace_classes_interp__init_part0_A_const_44 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_45 any

var A_arbace_classes_interp__init_part0_A_const_46 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_47 any

var A_arbace_classes_interp__init_part0_A_const_48 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_49 any

var A_arbace_classes_interp__init_part0_A_const_50 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_51 any

var A_arbace_classes_interp__init_part0_A_const_52 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_53 any

var A_arbace_classes_interp__init_part0_A_const_54 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_55 any

var A_arbace_classes_interp__init_part0_A_const_56 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_57 any

var A_arbace_classes_interp__init_part0_A_const_58 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_59 any

var A_arbace_classes_interp__init_part0_A_const_60 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_61 any

var A_arbace_classes_interp__init_part0_A_const_62 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_63 any

var A_arbace_classes_interp__init_part0_A_const_64 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_65 any

var A_arbace_classes_interp__init_part0_A_const_66 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_67 any

var A_arbace_classes_interp__init_part0_A_const_68 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_69 any

var A_arbace_classes_interp__init_part0_A_const_70 any

var A_arbace_classes_interp__init_part0_A_const_71 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_72 any

var A_arbace_classes_interp__init_part0_A_const_73 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_74 any

var A_arbace_classes_interp__init_part0_A_const_75 any

var A_arbace_classes_interp__init_part0_A_const_76 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_77 any

var A_arbace_classes_interp__init_part0_A_const_78 any

var A_arbace_classes_interp__init_part0_A_const_79 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_80 any

var A_arbace_classes_interp__init_part0_A_const_81 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_82 any

var A_arbace_classes_interp__init_part0_A_const_83 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_84 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_85 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_86 any

var A_arbace_classes_interp__init_part0_A_const_87 any

var A_arbace_classes_interp__init_part0_A_const_88 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_89 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_90 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_91 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_92 any

var A_arbace_classes_interp__init_part0_A_const_93 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_94 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_95 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_96 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_97 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_98 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_99 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_100 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_101 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_102 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_103 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_104 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_105 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_106 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_107 any

var A_arbace_classes_interp__init_part0_A_const_108 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_109 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_110 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_111 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_112 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_113 any

var A_arbace_classes_interp__init_part0_A_const_114 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_115 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_116 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_117 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_118 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_119 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_120 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_121 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_122 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_123 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_124 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_125 any

var A_arbace_classes_interp__init_part0_A_const_126 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_127 any

var A_arbace_classes_interp__init_part0_A_const_128 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_129 any

var A_arbace_classes_interp__init_part0_A_const_130 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_131 any

var A_arbace_classes_interp__init_part0_A_const_132 any

var A_arbace_classes_interp__init_part0_A_const_133 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_134 any

var A_arbace_classes_interp__init_part0_A_const_135 any

var A_arbace_classes_interp__init_part0_A_const_136 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_137 any

var A_arbace_classes_interp__init_part0_A_const_138 any

var A_arbace_classes_interp__init_part0_A_const_139 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_140 any

var A_arbace_classes_interp__init_part0_A_const_141 any

var A_arbace_classes_interp__init_part0_A_const_142 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_143 any

var A_arbace_classes_interp__init_part0_A_const_144 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_145 any

var A_arbace_classes_interp__init_part0_A_const_146 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_147 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_148 any

var A_arbace_classes_interp__init_part0_A_const_149 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_150 any

var A_arbace_classes_interp__init_part0_A_const_151 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_152 any

var A_arbace_classes_interp__init_part0_A_const_153 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_154 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_155 any

var A_arbace_classes_interp__init_part0_A_const_156 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_157 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_158 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_159 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_160 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_161 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_162 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_init jrt.ClassInit

func A_arbace_classes_interp__init_part0_A_Init() { if !A_arbace_classes_interp__init_part0_A_init.Done() { A_arbace_classes_interp__init_part0_A_init.Run(A_arbace_classes_interp__init_part0_A_clinit) } }

func A_arbace_classes_interp__init_part0_A_clinit() { A_arbace_classes_interp__init_part0_A_clinit_p0(); A_arbace_classes_interp__init_part0_A_clinit_p1(); A_arbace_classes_interp__init_part0_A_clinit_p2(); A_arbace_classes_interp__init_part0_A_clinit_p3(); A_arbace_classes_interp__init_part0_A_clinit_p4(); A_arbace_classes_interp__init_part0_A_clinit_p5(); A_arbace_classes_interp__init_part0_A_clinit_p6(); A_arbace_classes_interp__init_part0_A_clinit_p7(); A_arbace_classes_interp__init_part0_A_clinit_p8(); A_arbace_classes_interp__init_part0_A_clinit_p9(); A_arbace_classes_interp__init_part0_A_clinit_p10(); A_arbace_classes_interp__init_part0_A_clinit_p11(); A_arbace_classes_interp__init_part0_A_clinit_p12() }

func A_arbace_classes_interp__init_part0_A_clinit_p0() { jrt.StartCheck(); A_arbace_classes_interp__init_part0_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_265, 271); A_arbace_classes_interp__init_part0_A_const_0 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[108]); A_arbace_classes_interp__init_part0_A_const_1 = A_arbace_classes_interp__init_part0_A_const_pool.A[109]; A_arbace_classes_interp__init_part0_A_const_2 = A_arbace_classes_interp__init_part0_A_const_pool.A[110]; A_arbace_classes_interp__init_part0_A_const_3 = A_arbace_classes_interp__init_part0_A_const_pool.A[111]; A_arbace_classes_interp__init_part0_A_const_4 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[112]); A_arbace_classes_interp__init_part0_A_const_5 = A_arbace_classes_interp__init_part0_A_const_pool.A[113]; A_arbace_classes_interp__init_part0_A_const_6 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[114]); A_arbace_classes_interp__init_part0_A_const_7 = A_arbace_classes_interp__init_part0_A_const_pool.A[115]; A_arbace_classes_interp__init_part0_A_const_8 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[116]); A_arbace_classes_interp__init_part0_A_const_9 = A_arbace_classes_interp__init_part0_A_const_pool.A[117]; A_arbace_classes_interp__init_part0_A_const_10 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[118]); A_arbace_classes_interp__init_part0_A_const_11 = A_arbace_classes_interp__init_part0_A_const_pool.A[119]; A_arbace_classes_interp__init_part0_A_const_12 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[120]) }

func A_arbace_classes_interp__init_part0_A_clinit_p1() { A_arbace_classes_interp__init_part0_A_const_13 = A_arbace_classes_interp__init_part0_A_const_pool.A[121]; A_arbace_classes_interp__init_part0_A_const_14 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[122]); A_arbace_classes_interp__init_part0_A_const_15 = A_arbace_classes_interp__init_part0_A_const_pool.A[123]; A_arbace_classes_interp__init_part0_A_const_16 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[124]); A_arbace_classes_interp__init_part0_A_const_17 = A_arbace_classes_interp__init_part0_A_const_pool.A[125]; A_arbace_classes_interp__init_part0_A_const_18 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[126]); A_arbace_classes_interp__init_part0_A_const_19 = A_arbace_classes_interp__init_part0_A_const_pool.A[127]; A_arbace_classes_interp__init_part0_A_const_20 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[128]); A_arbace_classes_interp__init_part0_A_const_21 = A_arbace_classes_interp__init_part0_A_const_pool.A[129]; A_arbace_classes_interp__init_part0_A_const_22 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[130]); A_arbace_classes_interp__init_part0_A_const_23 = A_arbace_classes_interp__init_part0_A_const_pool.A[131]; A_arbace_classes_interp__init_part0_A_const_24 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[132]); A_arbace_classes_interp__init_part0_A_const_25 = A_arbace_classes_interp__init_part0_A_const_pool.A[133] }

func A_arbace_classes_interp__init_part0_A_clinit_p2() { A_arbace_classes_interp__init_part0_A_const_26 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[134]); A_arbace_classes_interp__init_part0_A_const_27 = A_arbace_classes_interp__init_part0_A_const_pool.A[135]; A_arbace_classes_interp__init_part0_A_const_28 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[136]); A_arbace_classes_interp__init_part0_A_const_29 = A_arbace_classes_interp__init_part0_A_const_pool.A[137]; A_arbace_classes_interp__init_part0_A_const_30 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[138]); A_arbace_classes_interp__init_part0_A_const_31 = A_arbace_classes_interp__init_part0_A_const_pool.A[139]; A_arbace_classes_interp__init_part0_A_const_32 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[140]); A_arbace_classes_interp__init_part0_A_const_33 = A_arbace_classes_interp__init_part0_A_const_pool.A[141]; A_arbace_classes_interp__init_part0_A_const_34 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[142]); A_arbace_classes_interp__init_part0_A_const_35 = A_arbace_classes_interp__init_part0_A_const_pool.A[143]; A_arbace_classes_interp__init_part0_A_const_36 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[144]); A_arbace_classes_interp__init_part0_A_const_37 = A_arbace_classes_interp__init_part0_A_const_pool.A[145]; A_arbace_classes_interp__init_part0_A_const_38 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[146]) }

func A_arbace_classes_interp__init_part0_A_clinit_p3() { A_arbace_classes_interp__init_part0_A_const_39 = A_arbace_classes_interp__init_part0_A_const_pool.A[147]; A_arbace_classes_interp__init_part0_A_const_40 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[148]); A_arbace_classes_interp__init_part0_A_const_41 = A_arbace_classes_interp__init_part0_A_const_pool.A[149]; A_arbace_classes_interp__init_part0_A_const_42 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[150]); A_arbace_classes_interp__init_part0_A_const_43 = A_arbace_classes_interp__init_part0_A_const_pool.A[151]; A_arbace_classes_interp__init_part0_A_const_44 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[152]); A_arbace_classes_interp__init_part0_A_const_45 = A_arbace_classes_interp__init_part0_A_const_pool.A[153]; A_arbace_classes_interp__init_part0_A_const_46 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[154]); A_arbace_classes_interp__init_part0_A_const_47 = A_arbace_classes_interp__init_part0_A_const_pool.A[155]; A_arbace_classes_interp__init_part0_A_const_48 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[156]); A_arbace_classes_interp__init_part0_A_const_49 = A_arbace_classes_interp__init_part0_A_const_pool.A[157]; A_arbace_classes_interp__init_part0_A_const_50 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[158]); A_arbace_classes_interp__init_part0_A_const_51 = A_arbace_classes_interp__init_part0_A_const_pool.A[159] }

func A_arbace_classes_interp__init_part0_A_clinit_p4() { A_arbace_classes_interp__init_part0_A_const_52 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[160]); A_arbace_classes_interp__init_part0_A_const_53 = A_arbace_classes_interp__init_part0_A_const_pool.A[161]; A_arbace_classes_interp__init_part0_A_const_54 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[162]); A_arbace_classes_interp__init_part0_A_const_55 = A_arbace_classes_interp__init_part0_A_const_pool.A[163]; A_arbace_classes_interp__init_part0_A_const_56 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[164]); A_arbace_classes_interp__init_part0_A_const_57 = A_arbace_classes_interp__init_part0_A_const_pool.A[165]; A_arbace_classes_interp__init_part0_A_const_58 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[166]); A_arbace_classes_interp__init_part0_A_const_59 = A_arbace_classes_interp__init_part0_A_const_pool.A[167]; A_arbace_classes_interp__init_part0_A_const_60 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[168]); A_arbace_classes_interp__init_part0_A_const_61 = A_arbace_classes_interp__init_part0_A_const_pool.A[169]; A_arbace_classes_interp__init_part0_A_const_62 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[170]); A_arbace_classes_interp__init_part0_A_const_63 = A_arbace_classes_interp__init_part0_A_const_pool.A[171]; A_arbace_classes_interp__init_part0_A_const_64 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[172]) }

func A_arbace_classes_interp__init_part0_A_clinit_p5() { A_arbace_classes_interp__init_part0_A_const_65 = A_arbace_classes_interp__init_part0_A_const_pool.A[173]; A_arbace_classes_interp__init_part0_A_const_66 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[174]); A_arbace_classes_interp__init_part0_A_const_67 = A_arbace_classes_interp__init_part0_A_const_pool.A[175]; A_arbace_classes_interp__init_part0_A_const_68 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[176]); A_arbace_classes_interp__init_part0_A_const_69 = A_arbace_classes_interp__init_part0_A_const_pool.A[177]; A_arbace_classes_interp__init_part0_A_const_70 = A_arbace_classes_interp__init_part0_A_const_pool.A[178]; A_arbace_classes_interp__init_part0_A_const_71 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[179]); A_arbace_classes_interp__init_part0_A_const_72 = A_arbace_classes_interp__init_part0_A_const_pool.A[180]; A_arbace_classes_interp__init_part0_A_const_73 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[181]); A_arbace_classes_interp__init_part0_A_const_74 = A_arbace_classes_interp__init_part0_A_const_pool.A[182]; A_arbace_classes_interp__init_part0_A_const_75 = A_arbace_classes_interp__init_part0_A_const_pool.A[183]; A_arbace_classes_interp__init_part0_A_const_76 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[184]); A_arbace_classes_interp__init_part0_A_const_77 = A_arbace_classes_interp__init_part0_A_const_pool.A[185]; A_arbace_classes_interp__init_part0_A_const_78 = A_arbace_classes_interp__init_part0_A_const_pool.A[186] }

func A_arbace_classes_interp__init_part0_A_clinit_p6() { A_arbace_classes_interp__init_part0_A_const_79 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[187]); A_arbace_classes_interp__init_part0_A_const_80 = A_arbace_classes_interp__init_part0_A_const_pool.A[188]; A_arbace_classes_interp__init_part0_A_const_81 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[189]); A_arbace_classes_interp__init_part0_A_const_82 = A_arbace_classes_interp__init_part0_A_const_pool.A[190]; A_arbace_classes_interp__init_part0_A_const_83 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[191]); A_arbace_classes_interp__init_part0_A_const_84 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[192]); A_arbace_classes_interp__init_part0_A_const_85 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[193]); A_arbace_classes_interp__init_part0_A_const_86 = A_arbace_classes_interp__init_part0_A_const_pool.A[194]; A_arbace_classes_interp__init_part0_A_const_87 = A_arbace_classes_interp__init_part0_A_const_pool.A[195]; A_arbace_classes_interp__init_part0_A_const_88 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[196]); A_arbace_classes_interp__init_part0_A_const_89 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[197]); A_arbace_classes_interp__init_part0_A_const_90 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[198]); A_arbace_classes_interp__init_part0_A_const_91 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[199]) }

func A_arbace_classes_interp__init_part0_A_clinit_p7() { A_arbace_classes_interp__init_part0_A_const_92 = A_arbace_classes_interp__init_part0_A_const_pool.A[200]; A_arbace_classes_interp__init_part0_A_const_93 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[201]); A_arbace_classes_interp__init_part0_A_const_94 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[202]); A_arbace_classes_interp__init_part0_A_const_95 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[203]); A_arbace_classes_interp__init_part0_A_const_96 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[204]); A_arbace_classes_interp__init_part0_A_const_97 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[205]); A_arbace_classes_interp__init_part0_A_const_98 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[206]); A_arbace_classes_interp__init_part0_A_const_99 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[207]); A_arbace_classes_interp__init_part0_A_const_100 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[208]); A_arbace_classes_interp__init_part0_A_const_101 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[209]); A_arbace_classes_interp__init_part0_A_const_102 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[210]); A_arbace_classes_interp__init_part0_A_const_103 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[211]) }

func A_arbace_classes_interp__init_part0_A_clinit_p8() { A_arbace_classes_interp__init_part0_A_const_104 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[212]); A_arbace_classes_interp__init_part0_A_const_105 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[213]); A_arbace_classes_interp__init_part0_A_const_106 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[214]); A_arbace_classes_interp__init_part0_A_const_107 = A_arbace_classes_interp__init_part0_A_const_pool.A[215]; A_arbace_classes_interp__init_part0_A_const_108 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[216]); A_arbace_classes_interp__init_part0_A_const_109 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[217]); A_arbace_classes_interp__init_part0_A_const_110 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[218]); A_arbace_classes_interp__init_part0_A_const_111 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[219]); A_arbace_classes_interp__init_part0_A_const_112 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[220]); A_arbace_classes_interp__init_part0_A_const_113 = A_arbace_classes_interp__init_part0_A_const_pool.A[221]; A_arbace_classes_interp__init_part0_A_const_114 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[222]); A_arbace_classes_interp__init_part0_A_const_115 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[223]) }

func A_arbace_classes_interp__init_part0_A_clinit_p9() { A_arbace_classes_interp__init_part0_A_const_116 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[224]); A_arbace_classes_interp__init_part0_A_const_117 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[225]); A_arbace_classes_interp__init_part0_A_const_118 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[226]); A_arbace_classes_interp__init_part0_A_const_119 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[227]); A_arbace_classes_interp__init_part0_A_const_120 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[228]); A_arbace_classes_interp__init_part0_A_const_121 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[229]); A_arbace_classes_interp__init_part0_A_const_122 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[230]); A_arbace_classes_interp__init_part0_A_const_123 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[231]); A_arbace_classes_interp__init_part0_A_const_124 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[232]); A_arbace_classes_interp__init_part0_A_const_125 = A_arbace_classes_interp__init_part0_A_const_pool.A[233]; A_arbace_classes_interp__init_part0_A_const_126 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[234]); A_arbace_classes_interp__init_part0_A_const_127 = A_arbace_classes_interp__init_part0_A_const_pool.A[235] }

func A_arbace_classes_interp__init_part0_A_clinit_p10() { A_arbace_classes_interp__init_part0_A_const_128 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[236]); A_arbace_classes_interp__init_part0_A_const_129 = A_arbace_classes_interp__init_part0_A_const_pool.A[237]; A_arbace_classes_interp__init_part0_A_const_130 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[238]); A_arbace_classes_interp__init_part0_A_const_131 = A_arbace_classes_interp__init_part0_A_const_pool.A[239]; A_arbace_classes_interp__init_part0_A_const_132 = A_arbace_classes_interp__init_part0_A_const_pool.A[240]; A_arbace_classes_interp__init_part0_A_const_133 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[241]); A_arbace_classes_interp__init_part0_A_const_134 = A_arbace_classes_interp__init_part0_A_const_pool.A[242]; A_arbace_classes_interp__init_part0_A_const_135 = A_arbace_classes_interp__init_part0_A_const_pool.A[243]; A_arbace_classes_interp__init_part0_A_const_136 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[244]); A_arbace_classes_interp__init_part0_A_const_137 = A_arbace_classes_interp__init_part0_A_const_pool.A[245]; A_arbace_classes_interp__init_part0_A_const_138 = A_arbace_classes_interp__init_part0_A_const_pool.A[246]; A_arbace_classes_interp__init_part0_A_const_139 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[247]); A_arbace_classes_interp__init_part0_A_const_140 = A_arbace_classes_interp__init_part0_A_const_pool.A[248]; A_arbace_classes_interp__init_part0_A_const_141 = A_arbace_classes_interp__init_part0_A_const_pool.A[249] }

func A_arbace_classes_interp__init_part0_A_clinit_p11() { A_arbace_classes_interp__init_part0_A_const_142 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[250]); A_arbace_classes_interp__init_part0_A_const_143 = A_arbace_classes_interp__init_part0_A_const_pool.A[251]; A_arbace_classes_interp__init_part0_A_const_144 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[252]); A_arbace_classes_interp__init_part0_A_const_145 = A_arbace_classes_interp__init_part0_A_const_pool.A[253]; A_arbace_classes_interp__init_part0_A_const_146 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[254]); A_arbace_classes_interp__init_part0_A_const_147 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[255]); A_arbace_classes_interp__init_part0_A_const_148 = A_arbace_classes_interp__init_part0_A_const_pool.A[256]; A_arbace_classes_interp__init_part0_A_const_149 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[257]); A_arbace_classes_interp__init_part0_A_const_150 = A_arbace_classes_interp__init_part0_A_const_pool.A[258]; A_arbace_classes_interp__init_part0_A_const_151 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[259]); A_arbace_classes_interp__init_part0_A_const_152 = A_arbace_classes_interp__init_part0_A_const_pool.A[260]; A_arbace_classes_interp__init_part0_A_const_153 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[261]); A_arbace_classes_interp__init_part0_A_const_154 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[262]) }

func A_arbace_classes_interp__init_part0_A_clinit_p12() { A_arbace_classes_interp__init_part0_A_const_155 = A_arbace_classes_interp__init_part0_A_const_pool.A[263]; A_arbace_classes_interp__init_part0_A_const_156 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[264]); A_arbace_classes_interp__init_part0_A_const_157 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[265]); A_arbace_classes_interp__init_part0_A_const_158 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[266]); A_arbace_classes_interp__init_part0_A_const_159 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[267]); A_arbace_classes_interp__init_part0_A_const_160 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[268]); A_arbace_classes_interp__init_part0_A_const_161 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[269]); A_arbace_classes_interp__init_part0_A_const_162 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[270]) }

func A_arbace_classes_interp__init_part0_A_New() *A_arbace_classes_interp__init_part0_A { A_arbace_classes_interp__init_part0_A_Init(); t := &A_arbace_classes_interp__init_part0_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_interp__init_part0_A) Ctor() {}

func (t *A_arbace_classes_interp__init_part0_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_interp__init_part0_A) GetClass__Class() *jrt.Class { return A_arbace_classes_interp__init_part0_A_class }

func (t *A_arbace_classes_interp__init_part0_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_interp__init_part0_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_interp__init_part0_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_interp__init_part0_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_interp__init_part0_A); return ok }

func A_arbace_classes_interp__init_part0_A_Cast(x any) *A_arbace_classes_interp__init_part0_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_interp__init_part0_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_interp__init_part0_A_class)) }; return v }



type A_arbace_classes_interp__init_part1_A struct{ jrt.Object }

var A_arbace_classes_interp__init_part1_A_const_pool *jrt.RefArray

var A_arbace_classes_interp__init_part1_A_const_0 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_1 *lang.Keyword

var A_arbace_classes_interp__init_part1_A_const_2 *lang.Keyword

var A_arbace_classes_interp__init_part1_A_const_3 *lang.Keyword

var A_arbace_classes_interp__init_part1_A_const_4 *lang.Keyword

var A_arbace_classes_interp__init_part1_A_const_5 *lang.Keyword

var A_arbace_classes_interp__init_part1_A_const_6 *lang.Keyword

var A_arbace_classes_interp__init_part1_A_const_7 *lang.Keyword

var A_arbace_classes_interp__init_part1_A_const_8 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_9 any

var A_arbace_classes_interp__init_part1_A_const_10 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_11 any

var A_arbace_classes_interp__init_part1_A_const_12 *lang.Keyword

var A_arbace_classes_interp__init_part1_A_const_13 *lang.Keyword

var A_arbace_classes_interp__init_part1_A_const_14 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_15 any

var A_arbace_classes_interp__init_part1_A_const_16 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_17 any

var A_arbace_classes_interp__init_part1_A_const_18 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_19 any

var A_arbace_classes_interp__init_part1_A_const_20 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_21 any

var A_arbace_classes_interp__init_part1_A_const_22 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_23 any

var A_arbace_classes_interp__init_part1_A_const_24 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_25 any

var A_arbace_classes_interp__init_part1_A_const_26 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_27 any

var A_arbace_classes_interp__init_part1_A_const_28 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_29 any

var A_arbace_classes_interp__init_part1_A_const_30 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_31 any

var A_arbace_classes_interp__init_part1_A_const_32 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_33 any

var A_arbace_classes_interp__init_part1_A_const_34 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_35 any

var A_arbace_classes_interp__init_part1_A_const_36 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_37 any

var A_arbace_classes_interp__init_part1_A_const_38 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_39 any

var A_arbace_classes_interp__init_part1_A_const_40 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_41 any

var A_arbace_classes_interp__init_part1_A_const_42 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_43 any

var A_arbace_classes_interp__init_part1_A_const_44 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_45 any

var A_arbace_classes_interp__init_part1_A_const_46 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_47 any

var A_arbace_classes_interp__init_part1_A_const_48 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_49 any

var A_arbace_classes_interp__init_part1_A_const_50 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_51 any

var A_arbace_classes_interp__init_part1_A_const_52 any

var A_arbace_classes_interp__init_part1_A_const_53 *lang.Keyword

var A_arbace_classes_interp__init_part1_A_const_54 any

var A_arbace_classes_interp__init_part1_A_const_55 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_56 any

var A_arbace_classes_interp__init_part1_A_const_57 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_58 any

var A_arbace_classes_interp__init_part1_A_const_59 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_60 any

var A_arbace_classes_interp__init_part1_A_const_61 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_62 any

var A_arbace_classes_interp__init_part1_A_const_63 any

var A_arbace_classes_interp__init_part1_A_const_64 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_65 any

var A_arbace_classes_interp__init_part1_A_const_66 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_67 any

var A_arbace_classes_interp__init_part1_A_const_68 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_69 any

var A_arbace_classes_interp__init_part1_A_const_70 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_71 any

var A_arbace_classes_interp__init_part1_A_const_72 *lang.Keyword

var A_arbace_classes_interp__init_part1_A_const_73 *lang.Keyword

var A_arbace_classes_interp__init_part1_A_const_74 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_75 any

var A_arbace_classes_interp__init_part1_A_const_76 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_77 any

var A_arbace_classes_interp__init_part1_A_const_78 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_79 any

var A_arbace_classes_interp__init_part1_A_const_80 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_81 any

var A_arbace_classes_interp__init_part1_A_const_82 any

var A_arbace_classes_interp__init_part1_A_const_83 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_84 any

var A_arbace_classes_interp__init_part1_A_const_85 any

var A_arbace_classes_interp__init_part1_A_const_86 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_87 any

var A_arbace_classes_interp__init_part1_A_const_88 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_89 any

var A_arbace_classes_interp__init_part1_A_const_90 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_91 any

var A_arbace_classes_interp__init_part1_A_init jrt.ClassInit

func A_arbace_classes_interp__init_part1_A_Init() { if !A_arbace_classes_interp__init_part1_A_init.Done() { A_arbace_classes_interp__init_part1_A_init.Run(A_arbace_classes_interp__init_part1_A_clinit) } }

func A_arbace_classes_interp__init_part1_A_clinit() { A_arbace_classes_interp__init_part1_A_clinit_p0(); A_arbace_classes_interp__init_part1_A_clinit_p1() }

func A_arbace_classes_interp__init_part1_A_clinit_p0() { jrt.StartCheck(); A_arbace_classes_interp__init_part1_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_358, 143) }

func A_arbace_classes_interp__init_part1_A_clinit_p1() { var tmp1 *lang.Var; A_arbace_classes_interp__init_part0_A_Init(); tmp1 = A_arbace_classes_interp__init_part0_A_const_81; A_arbace_classes_interp__init_part1_A_const_0 = tmp1; A_arbace_classes_interp__init_part1_A_const_1 = lang.Keyword_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[53]); A_arbace_classes_interp__init_part1_A_const_2 = lang.Keyword_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[54]); A_arbace_classes_interp__init_part1_A_const_3 = lang.Keyword_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[55]); A_arbace_classes_interp__init_part1_A_const_4 = lang.Keyword_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[56]); A_arbace_classes_interp__init_part1_A_const_5 = lang.Keyword_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[57]); A_arbace_classes_interp__init_part1_A_const_6 = lang.Keyword_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[58]); A_arbace_classes_interp__init_part1_A_const_7 = lang.Keyword_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[59]); A_arbace_classes_interp__init_part1_A_const_8 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[60]); A_arbace_classes_interp__init_part1_A_const_9 = A_arbace_classes_interp__init_part1_A_const_pool.A[61]; A_arbace_classes_interp__init_part1_A_const_10 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[62]); A_arbace_classes_interp__init_part1_A_const_11 = A_arbace_classes_interp__init_part1_A_const_pool.A[63]; A_arbace_classes_interp__init_part1_A_const_12 = lang.Keyword_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[64]); A_arbace_classes_interp__init_part1_A_const_13 = lang.Keyword_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[65]); A_arbace_classes_interp__init_part1_A_const_14 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[66]); A_arbace_classes_interp__init_part1_A_const_15 = A_arbace_classes_interp__init_part1_A_const_pool.A[67]; A_arbace_classes_interp__init_part1_A_const_16 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[68]); A_arbace_classes_interp__init_part1_A_const_17 = A_arbace_classes_interp__init_part1_A_const_pool.A[69]; A_arbace_classes_interp__init_part1_A_const_18 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[70]); A_arbace_classes_interp__init_part1_A_const_19 = A_arbace_classes_interp__init_part1_A_const_pool.A[71]; A_arbace_classes_interp__init_part1_A_const_20 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[72]); A_arbace_classes_interp__init_part1_A_const_21 = A_arbace_classes_interp__init_part1_A_const_pool.A[73]; A_arbace_classes_interp__init_part1_A_const_22 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[74]); A_arbace_classes_interp__init_part1_A_const_23 = A_arbace_classes_interp__init_part1_A_const_pool.A[75]; A_arbace_classes_interp__init_part1_A_const_24 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[76]); A_arbace_classes_interp__init_part1_A_const_25 = A_arbace_classes_interp__init_part1_A_const_pool.A[77]; A_arbace_classes_interp__init_part1_A_const_26 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[78]); A_arbace_classes_interp__init_part1_A_const_27 = A_arbace_classes_interp__init_part1_A_const_pool.A[79]; A_arbace_classes_interp__init_part1_A_const_28 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[80]); A_arbace_classes_interp__init_part1_A_const_29 = A_arbace_classes_interp__init_part1_A_const_pool.A[81]; A_arbace_classes_interp__init_part1_A_const_30 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[82]); A_arbace_classes_interp__init_part1_A_const_31 = A_arbace_classes_interp__init_part1_A_const_pool.A[83]; A_arbace_classes_interp__init_part1_A_const_32 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[84]); A_arbace_classes_interp__init_part1_A_const_33 = A_arbace_classes_interp__init_part1_A_const_pool.A[85]; A_arbace_classes_interp__init_part1_A_const_34 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[86]); A_arbace_classes_interp__init_part1_A_const_35 = A_arbace_classes_interp__init_part1_A_const_pool.A[87]; A_arbace_classes_interp__init_part1_A_const_36 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[88]); A_arbace_classes_interp__init_part1_A_const_37 = A_arbace_classes_interp__init_part1_A_const_pool.A[89]; A_arbace_classes_interp__init_part1_A_const_38 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[90]); A_arbace_classes_interp__init_part1_A_const_39 = A_arbace_classes_interp__init_part1_A_const_pool.A[91]; A_arbace_classes_interp__init_part1_A_const_40 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[92]); A_arbace_classes_interp__init_part1_A_const_41 = A_arbace_classes_interp__init_part1_A_const_pool.A[93]; A_arbace_classes_interp__init_part1_A_const_42 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[94]); A_arbace_classes_interp__init_part1_A_const_43 = A_arbace_classes_interp__init_part1_A_const_pool.A[95]; A_arbace_classes_interp__init_part1_A_const_44 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[96]); A_arbace_classes_interp__init_part1_A_const_45 = A_arbace_classes_interp__init_part1_A_const_pool.A[97]; A_arbace_classes_interp__init_part1_A_const_46 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[98]); A_arbace_classes_interp__init_part1_A_const_47 = A_arbace_classes_interp__init_part1_A_const_pool.A[99]; A_arbace_classes_interp__init_part1_A_const_48 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[100]); A_arbace_classes_interp__init_part1_A_const_49 = A_arbace_classes_interp__init_part1_A_const_pool.A[101]; A_arbace_classes_interp__init_part1_A_const_50 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[102]); A_arbace_classes_interp__init_part1_A_const_51 = A_arbace_classes_interp__init_part1_A_const_pool.A[103]; A_arbace_classes_interp__init_part1_A_const_52 = A_arbace_classes_interp__init_part1_A_const_pool.A[104]; A_arbace_classes_interp__init_part1_A_const_53 = lang.Keyword_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[105]); A_arbace_classes_interp__init_part1_A_const_54 = A_arbace_classes_interp__init_part1_A_const_pool.A[106]; A_arbace_classes_interp__init_part1_A_const_55 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[107]); A_arbace_classes_interp__init_part1_A_const_56 = A_arbace_classes_interp__init_part1_A_const_pool.A[108]; A_arbace_classes_interp__init_part1_A_const_57 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[109]); A_arbace_classes_interp__init_part1_A_const_58 = A_arbace_classes_interp__init_part1_A_const_pool.A[110]; A_arbace_classes_interp__init_part1_A_const_59 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[111]); A_arbace_classes_interp__init_part1_A_const_60 = A_arbace_classes_interp__init_part1_A_const_pool.A[112]; var tmp2 *lang.Var; A_arbace_classes_interp__init_part0_A_Init(); tmp2 = A_arbace_classes_interp__init_part0_A_const_6; A_arbace_classes_interp__init_part1_A_const_61 = tmp2; A_arbace_classes_interp__init_part1_A_const_62 = A_arbace_classes_interp__init_part1_A_const_pool.A[113]; A_arbace_classes_interp__init_part1_A_const_63 = A_arbace_classes_interp__init_part1_A_const_pool.A[114]; A_arbace_classes_interp__init_part1_A_const_64 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[115]); A_arbace_classes_interp__init_part1_A_const_65 = A_arbace_classes_interp__init_part1_A_const_pool.A[116]; A_arbace_classes_interp__init_part1_A_const_66 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[117]); A_arbace_classes_interp__init_part1_A_const_67 = A_arbace_classes_interp__init_part1_A_const_pool.A[118]; A_arbace_classes_interp__init_part1_A_const_68 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[119]); A_arbace_classes_interp__init_part1_A_const_69 = A_arbace_classes_interp__init_part1_A_const_pool.A[120]; A_arbace_classes_interp__init_part1_A_const_70 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[121]); A_arbace_classes_interp__init_part1_A_const_71 = A_arbace_classes_interp__init_part1_A_const_pool.A[122]; A_arbace_classes_interp__init_part1_A_const_72 = lang.Keyword_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[123]); A_arbace_classes_interp__init_part1_A_const_73 = lang.Keyword_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[124]); A_arbace_classes_interp__init_part1_A_const_74 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[125]); A_arbace_classes_interp__init_part1_A_const_75 = A_arbace_classes_interp__init_part1_A_const_pool.A[126]; A_arbace_classes_interp__init_part1_A_const_76 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[127]); A_arbace_classes_interp__init_part1_A_const_77 = A_arbace_classes_interp__init_part1_A_const_pool.A[128]; A_arbace_classes_interp__init_part1_A_const_78 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[129]); A_arbace_classes_interp__init_part1_A_const_79 = A_arbace_classes_interp__init_part1_A_const_pool.A[130]; A_arbace_classes_interp__init_part1_A_const_80 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[131]); A_arbace_classes_interp__init_part1_A_const_81 = A_arbace_classes_interp__init_part1_A_const_pool.A[132]; A_arbace_classes_interp__init_part1_A_const_82 = A_arbace_classes_interp__init_part1_A_const_pool.A[133]; A_arbace_classes_interp__init_part1_A_const_83 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[134]); A_arbace_classes_interp__init_part1_A_const_84 = A_arbace_classes_interp__init_part1_A_const_pool.A[135]; A_arbace_classes_interp__init_part1_A_const_85 = A_arbace_classes_interp__init_part1_A_const_pool.A[136]; A_arbace_classes_interp__init_part1_A_const_86 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[137]); A_arbace_classes_interp__init_part1_A_const_87 = A_arbace_classes_interp__init_part1_A_const_pool.A[138]; A_arbace_classes_interp__init_part1_A_const_88 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[139]); A_arbace_classes_interp__init_part1_A_const_89 = A_arbace_classes_interp__init_part1_A_const_pool.A[140]; A_arbace_classes_interp__init_part1_A_const_90 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[141]); A_arbace_classes_interp__init_part1_A_const_91 = A_arbace_classes_interp__init_part1_A_const_pool.A[142] }

func A_arbace_classes_interp__init_part1_A_New() *A_arbace_classes_interp__init_part1_A { A_arbace_classes_interp__init_part1_A_Init(); t := &A_arbace_classes_interp__init_part1_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_interp__init_part1_A) Ctor() {}

func (t *A_arbace_classes_interp__init_part1_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_interp__init_part1_A) GetClass__Class() *jrt.Class { return A_arbace_classes_interp__init_part1_A_class }

func (t *A_arbace_classes_interp__init_part1_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_interp__init_part1_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_interp__init_part1_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_interp__init_part1_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_interp__init_part1_A); return ok }

func A_arbace_classes_interp__init_part1_A_Cast(x any) *A_arbace_classes_interp__init_part1_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_interp__init_part1_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_interp__init_part1_A_class)) }; return v }
