//line aot_arbace_classes_interp__init.ae:1
package aot_arbace_classes_interp

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_interp__init_part0_A_Unit0__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_classes_interp__init_part0_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_interp__init_part0_A_const_1) }
//line :1:1
func A_arbace_classes_interp__init_part0_A_Unit1__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_classes_interp__init_part0_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_2)) }
//line :1:1
func A_arbace_classes_interp__init_part0_A_Unit2__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_classes_interp_eval393000004_loading__1927001464__auto____393000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_classes_interp_eval393000004_loading__1927001464__auto____393000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_308, false, nil); A_arbace_classes_interp_eval393000004_loading__1927001464__auto____393000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_classes_interp__init_part0_A_Unit3__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_classes_interp__init_part0_A_const_1)).Equals_O__Z(A_arbace_classes_interp__init_part0_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_classes_interp_eval393000008_fn__393000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_classes_interp_eval393000008_fn__393000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_309, false, nil); A_arbace_classes_interp_eval393000008_fn__393000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }
//line :1:1
func A_arbace_classes_interp__init_part0_A_Init__O() any { A_arbace_classes_interp__init_part0_A_Init(); return nil }
//line :1:1
func A_arbace_classes_interp__init_part0_A_Load__O() any { A_arbace_classes_interp__init_part0_A_Init(); A_arbace_classes_interp__init_part0_A_Unit0__O(); A_arbace_classes_interp__init_part0_A_Unit1__O(); A_arbace_classes_interp__init_part0_A_Unit2__O(); A_arbace_classes_interp__init_part0_A_Unit3__O(); A_arbace_classes_interp__init_part0_A_Unit4__O(); A_arbace_classes_interp__init_part0_A_Unit5__O(); A_arbace_classes_interp__init_part0_A_Unit6__O(); A_arbace_classes_interp__init_part0_A_Unit7__O(); A_arbace_classes_interp__init_part0_A_Unit8__O(); A_arbace_classes_interp__init_part0_A_Unit9__O(); A_arbace_classes_interp__init_part0_A_Unit10__O(); A_arbace_classes_interp__init_part0_A_Unit11__O(); A_arbace_classes_interp__init_part0_A_Unit12__O(); A_arbace_classes_interp__init_part0_A_Unit13__O(); A_arbace_classes_interp__init_part0_A_Unit14__O(); A_arbace_classes_interp__init_part0_A_Unit15__O(); A_arbace_classes_interp__init_part0_A_Unit16__O(); A_arbace_classes_interp__init_part0_A_Unit17__O(); A_arbace_classes_interp__init_part0_A_Unit18__O(); A_arbace_classes_interp__init_part0_A_Unit19__O(); A_arbace_classes_interp__init_part0_A_Unit20__O(); A_arbace_classes_interp__init_part0_A_Unit21__O(); A_arbace_classes_interp__init_part0_A_Unit22__O(); A_arbace_classes_interp__init_part0_A_Unit23__O(); A_arbace_classes_interp__init_part0_A_Unit24__O(); A_arbace_classes_interp__init_part0_A_Unit25__O(); A_arbace_classes_interp__init_part0_A_Unit26__O(); A_arbace_classes_interp__init_part0_A_Unit27__O(); A_arbace_classes_interp__init_part0_A_Unit28__O(); A_arbace_classes_interp__init_part0_A_Unit29__O(); A_arbace_classes_interp__init_part0_A_Unit30__O(); A_arbace_classes_interp__init_part0_A_Unit31__O(); A_arbace_classes_interp__init_part0_A_Unit32__O(); A_arbace_classes_interp__init_part0_A_Unit33__O(); A_arbace_classes_interp__init_part0_A_Unit34__O(); A_arbace_classes_interp__init_part0_A_Unit35__O(); A_arbace_classes_interp__init_part0_A_Unit36__O(); A_arbace_classes_interp__init_part0_A_Unit37__O(); A_arbace_classes_interp__init_part0_A_Unit38__O(); A_arbace_classes_interp__init_part0_A_Unit39__O(); A_arbace_classes_interp__init_part0_A_Unit40__O(); A_arbace_classes_interp__init_part0_A_Unit41__O(); A_arbace_classes_interp__init_part0_A_Unit42__O(); A_arbace_classes_interp__init_part0_A_Unit43__O(); A_arbace_classes_interp__init_part0_A_Unit44__O(); A_arbace_classes_interp__init_part0_A_Unit45__O(); A_arbace_classes_interp__init_part0_A_Unit46__O(); A_arbace_classes_interp__init_part0_A_Unit47__O(); A_arbace_classes_interp__init_part0_A_Unit48__O(); A_arbace_classes_interp__init_part0_A_Unit49__O(); A_arbace_classes_interp__init_part0_A_Unit50__O(); A_arbace_classes_interp__init_part0_A_Unit51__O(); A_arbace_classes_interp__init_part0_A_Unit52__O(); A_arbace_classes_interp__init_part0_A_Unit53__O(); A_arbace_classes_interp__init_part0_A_Unit54__O(); A_arbace_classes_interp__init_part0_A_Unit55__O(); A_arbace_classes_interp__init_part0_A_Unit56__O(); A_arbace_classes_interp__init_part0_A_Unit57__O(); A_arbace_classes_interp__init_part0_A_Unit58__O(); A_arbace_classes_interp__init_part0_A_Unit59__O(); A_arbace_classes_interp__init_part0_A_Unit60__O(); A_arbace_classes_interp__init_part0_A_Unit61__O(); A_arbace_classes_interp__init_part0_A_Unit62__O(); A_arbace_classes_interp__init_part0_A_Unit63__O(); A_arbace_classes_interp__init_part0_A_Unit64__O(); A_arbace_classes_interp__init_part0_A_Unit65__O(); A_arbace_classes_interp__init_part0_A_Unit66__O(); A_arbace_classes_interp__init_part0_A_Unit67__O(); A_arbace_classes_interp__init_part0_A_Unit68__O(); A_arbace_classes_interp__init_part0_A_Unit69__O(); A_arbace_classes_interp__init_part0_A_Unit70__O(); A_arbace_classes_interp__init_part0_A_Unit71__O(); A_arbace_classes_interp__init_part0_A_Unit72__O(); A_arbace_classes_interp__init_part0_A_Unit73__O(); A_arbace_classes_interp__init_part0_A_Unit74__O(); A_arbace_classes_interp__init_part0_A_Unit75__O(); A_arbace_classes_interp__init_part0_A_Unit76__O(); A_arbace_classes_interp__init_part0_A_Unit77__O(); A_arbace_classes_interp__init_part0_A_Unit78__O(); A_arbace_classes_interp__init_part0_A_Unit79__O(); A_arbace_classes_interp__init_part0_A_Unit80__O(); A_arbace_classes_interp__init_part0_A_Unit81__O(); A_arbace_classes_interp__init_part0_A_Unit82__O(); A_arbace_classes_interp__init_part0_A_Unit83__O(); A_arbace_classes_interp__init_part0_A_Unit84__O(); A_arbace_classes_interp__init_part0_A_Unit85__O(); A_arbace_classes_interp__init_part0_A_Unit86__O(); A_arbace_classes_interp__init_part0_A_Unit87__O(); A_arbace_classes_interp__init_part0_A_Unit88__O(); A_arbace_classes_interp__init_part0_A_Unit89__O(); A_arbace_classes_interp__init_part0_A_Unit90__O(); A_arbace_classes_interp__init_part0_A_Unit91__O(); A_arbace_classes_interp__init_part0_A_Unit92__O(); A_arbace_classes_interp__init_part0_A_Unit93__O(); A_arbace_classes_interp__init_part0_A_Unit94__O(); A_arbace_classes_interp__init_part0_A_Unit95__O(); A_arbace_classes_interp__init_part0_A_Unit96__O(); A_arbace_classes_interp__init_part0_A_Unit97__O(); A_arbace_classes_interp__init_part0_A_Unit98__O(); A_arbace_classes_interp__init_part0_A_Unit99__O(); return nil }



func A_arbace_classes_interp__init_A_Load__O() any { jrt.StartCheck(); A_arbace_classes_interp__init_part0_A_Init__O(); A_arbace_classes_interp__init_part1_A_Init__O(); A_arbace_classes_interp__init_part0_A_Load__O(); A_arbace_classes_interp__init_part1_A_Load__O(); return nil }



































func A_arbace_classes_interp__init_part0_A_Unit4__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(41, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_5)); v__1927001498__auto____1 = A_arbace_classes_interp__init_part0_A_const_4; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_classes_interp__init_part0_A_const_4; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_7)); var tmp3 *lang.Var = A_arbace_classes_interp__init_part0_A_const_4; var tmp4 any; var root_5 any = A_arbace_classes_interp__init_part0_A_const_6.GetRawRoot__O(); var linked_6 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_5, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_7 lang.IFn
								if linked_6 == nil { ifn_7 = lang.IFn_Cast(root_5) } else { ifn_7 = nil }; var arg_8 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_6 == nil { tmp4 = ifn_7.Invoke_O__O(arg_8) } else { tmp4 = linked_6.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_5, arg_8) }
//line :41:1
	tmp3.BindRoot_O__V(tmp4); return A_arbace_classes_interp__init_part0_A_const_4 } }


func A_arbace_classes_interp__init_part0_A_Unit5__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(44, 1); A_arbace_classes_interp__init_part0_A_const_8.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_8; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_9)); return A_arbace_classes_interp__init_part0_A_const_8.SetDynamic_Z__Var(true).Ref() }



func A_arbace_classes_interp__init_part0_A_Unit6__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); A_arbace_classes_interp__init_part0_A_const_10.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_10; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_11)); return A_arbace_classes_interp__init_part0_A_const_10.SetDynamic_Z__Var(true).Ref() }




func A_arbace_classes_interp__init_part0_A_Unit7__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(53, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_classes_interp_sibling_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_classes_interp_sibling_QMARK__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_310, false, nil); A_arbace_classes_interp_sibling_QMARK__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_13)); return A_arbace_classes_interp__init_part0_A_const_12 }





func A_arbace_classes_interp__init_part0_A_Unit8__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(59, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_classes_interp_pending_BANG__A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_classes_interp_pending_BANG__A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_311, false, nil); A_arbace_classes_interp_pending_BANG__A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_15)); return A_arbace_classes_interp__init_part0_A_const_14 }







func A_arbace_classes_interp__init_part0_A_Unit9__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(67, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_16; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_classes_interp_pending_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_classes_interp_pending_QMARK__A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_312, false, nil); A_arbace_classes_interp_pending_QMARK__A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_17)); return A_arbace_classes_interp__init_part0_A_const_16 }

func A_arbace_classes_interp__init_part0_A_Unit10__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(69, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_18; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_classes_interp_klass_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_classes_interp_klass_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_313, false, nil); A_arbace_classes_interp_klass_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_19)); return A_arbace_classes_interp__init_part0_A_const_18 }












func A_arbace_classes_interp__init_part0_A_Unit11__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(82, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_20; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__18 any = A_arbace_classes_interp_fail_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_classes_interp_fail_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_314, true, nil); A_arbace_classes_interp_fail_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__18, tmp3, nil, 1); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_21)); return A_arbace_classes_interp__init_part0_A_const_20 }




func A_arbace_classes_interp__init_part0_A_Unit12__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(87, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_22; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_classes_interp_tc_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_classes_interp_tc_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_315, false, nil); A_arbace_classes_interp_tc_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_23)); return A_arbace_classes_interp__init_part0_A_const_22 }








func A_arbace_classes_interp__init_part0_A_Unit13__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(96, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_24; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_classes_interp_kind_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_classes_interp_kind_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_316, false, nil); A_arbace_classes_interp_kind_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_25)); return A_arbace_classes_interp__init_part0_A_const_24 }

func A_arbace_classes_interp__init_part0_A_Unit14__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(98, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_26; tmp1.BindRoot_O__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_317, jrt.Long_TYPE.Ref(), Lit_318, jrt.Short_TYPE.Ref(), Lit_6, jrt.Boolean_TYPE.Ref(), Lit_319, jrt.Character_TYPE.Ref(), Lit_320, jrt.Float_TYPE.Ref(), Lit_321, jrt.Byte_TYPE.Ref(), Lit_14, jrt.Void_TYPE.Ref(), Lit_16, jrt.Integer_TYPE.Ref(), Lit_322, jrt.Double_TYPE.Ref()))); var tmp2 *lang.Var = A_arbace_classes_interp__init_part0_A_const_26; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_27)); return A_arbace_classes_interp__init_part0_A_const_26 }



func A_arbace_classes_interp__init_part0_A_Unit15__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(102, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_28; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_classes_interp_desc__GT_class_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_classes_interp_desc__GT_class_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_323, false, nil); A_arbace_classes_interp_desc__GT_class_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_29)); return A_arbace_classes_interp__init_part0_A_const_28 }


















func A_arbace_classes_interp__init_part0_A_Unit16__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(121, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_30; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_classes_interp_internal__GT_class_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_classes_interp_internal__GT_class_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_324, false, nil); A_arbace_classes_interp_internal__GT_class_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_31)); return A_arbace_classes_interp__init_part0_A_const_30 }








func A_arbace_classes_interp__init_part0_A_Unit17__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(130, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_32; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_classes_interp_new_ctx_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_classes_interp_new_ctx_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_325, false, nil); A_arbace_classes_interp_new_ctx_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_33)); return A_arbace_classes_interp__init_part0_A_const_32 }



func A_arbace_classes_interp__init_part0_A_Unit18__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(134, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_34; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_classes_interp_slot_BANG__A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_classes_interp_slot_BANG__A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_326, false, nil); A_arbace_classes_interp_slot_BANG__A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_35)); return A_arbace_classes_interp__init_part0_A_const_34 }






func A_arbace_classes_interp__init_part0_A_Unit19__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(141, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_36; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_classes_interp_bind_BANG__A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_classes_interp_bind_BANG__A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_327, false, nil); A_arbace_classes_interp_bind_BANG__A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_37)); return A_arbace_classes_interp__init_part0_A_const_36 }







func A_arbace_classes_interp__init_part0_A_Unit20__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(149, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_38; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_39)); return A_arbace_classes_interp__init_part0_A_const_38 }
//line :149:1
func A_arbace_classes_interp__init_part0_A_Unit21__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(149, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_40; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_41)); return A_arbace_classes_interp__init_part0_A_const_40 }

func A_arbace_classes_interp__init_part0_A_Unit22__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(151, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_42; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_classes_interp_konst_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_classes_interp_konst_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_328, false, nil); A_arbace_classes_interp_konst_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_43)); return A_arbace_classes_interp__init_part0_A_const_42 }

func A_arbace_classes_interp__init_part0_A_Unit23__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(153, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_44; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_classes_interp_nodes_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_classes_interp_nodes_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_329, false, nil); A_arbace_classes_interp_nodes_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_45)); return A_arbace_classes_interp__init_part0_A_const_44 }


func A_arbace_classes_interp__init_part0_A_Unit24__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(156, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_46; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_classes_interp_target_code_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_classes_interp_target_code_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_330, false, nil); A_arbace_classes_interp_target_code_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_47)); return A_arbace_classes_interp__init_part0_A_const_46 }



func A_arbace_classes_interp__init_part0_A_Unit25__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(160, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_48; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_classes_interp_instance_fields_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_classes_interp_instance_fields_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_331, false, nil); A_arbace_classes_interp_instance_fields_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_49)); return A_arbace_classes_interp__init_part0_A_const_48 }





func A_arbace_classes_interp__init_part0_A_Unit26__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(166, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_50; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_classes_interp_field_index_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_classes_interp_field_index_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_332, false, nil); A_arbace_classes_interp_field_index_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_51)); return A_arbace_classes_interp__init_part0_A_const_50 }








func A_arbace_classes_interp__init_part0_A_Unit27__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(175, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_52; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_classes_interp_static_index_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_classes_interp_static_index_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_333, false, nil); A_arbace_classes_interp_static_index_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_53)); return A_arbace_classes_interp__init_part0_A_const_52 }


func A_arbace_classes_interp__init_part0_A_Unit28__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_54; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_classes_interp_find_static_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_classes_interp_find_static_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_334, false, nil); A_arbace_classes_interp_find_static_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_55)); return A_arbace_classes_interp__init_part0_A_const_54 }











func A_arbace_classes_interp__init_part0_A_Unit29__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(190, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_56; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_classes_interp_params_of_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_classes_interp_params_of_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_335, false, nil); A_arbace_classes_interp_params_of_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_57)); return A_arbace_classes_interp__init_part0_A_const_56 }

func A_arbace_classes_interp__init_part0_A_Unit30__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(192, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_58; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_classes_interp_find_method_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_classes_interp_find_method_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_336, false, nil); A_arbace_classes_interp_find_method_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_59)); return A_arbace_classes_interp__init_part0_A_const_58 }












func A_arbace_classes_interp__init_part0_A_Unit31__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(205, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_60; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_classes_interp_real_method_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_classes_interp_real_method_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_337, false, nil); A_arbace_classes_interp_real_method_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_61)); return A_arbace_classes_interp__init_part0_A_const_60 }
















func A_arbace_classes_interp__init_part0_A_Unit32__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(222, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_62; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_classes_interp_find_field_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_classes_interp_find_field_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_338, false, nil); A_arbace_classes_interp_find_field_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_63)); return A_arbace_classes_interp__init_part0_A_const_62 }









func A_arbace_classes_interp__init_part0_A_Unit33__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(232, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_64; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_65)); return A_arbace_classes_interp__init_part0_A_const_64 }

func A_arbace_classes_interp__init_part0_A_Unit34__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(234, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_66; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_classes_interp_local_node_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_classes_interp_local_node_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_339, false, nil); A_arbace_classes_interp_local_node_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_67)); return A_arbace_classes_interp__init_part0_A_const_66 }












































func A_arbace_classes_interp__init_part0_A_Unit35__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(279, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_68; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_classes_interp_convert_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_classes_interp_convert_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_340, false, nil); A_arbace_classes_interp_convert_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_69)); return A_arbace_classes_interp__init_part0_A_const_68 }













func A_arbace_classes_interp__init_part0_A_Unit36__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(293, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_40; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_classes_interp_coerce_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_classes_interp_coerce_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_341, false, nil); A_arbace_classes_interp_coerce_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_70)); return A_arbace_classes_interp__init_part0_A_const_40 }






func A_arbace_classes_interp__init_part0_A_Unit37__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(300, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_71; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_classes_interp_value_convert_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_classes_interp_value_convert_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_342, false, nil); A_arbace_classes_interp_value_convert_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_72)); return A_arbace_classes_interp__init_part0_A_const_71 }























func A_arbace_classes_interp__init_part0_A_Unit38__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(324, 1); A_arbace_classes_interp__init_part0_A_const_73.BindRoot_O__V(A_arbace_classes_interp__init_part0_A_const_74); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_73; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_75)); return A_arbace_classes_interp__init_part0_A_const_73 }



func A_arbace_classes_interp__init_part0_A_Unit39__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(328, 1); A_arbace_classes_interp__init_part0_A_const_76.BindRoot_O__V(A_arbace_classes_interp__init_part0_A_const_77); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_76; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_78)); return A_arbace_classes_interp__init_part0_A_const_76 }

func A_arbace_classes_interp__init_part0_A_Unit40__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(330, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_79; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_classes_interp_vt_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_classes_interp_vt_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_343, false, nil); A_arbace_classes_interp_vt_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_79; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_80)); return A_arbace_classes_interp__init_part0_A_const_79 }

func A_arbace_classes_interp__init_part0_A_Unit41__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(332, 1); var v__1927000386__auto____1 any; var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_81; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_82)); v__1927000386__auto____1 = A_arbace_classes_interp__init_part0_A_const_81; var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { var tmp3 any; var root_65 any = A_arbace_classes_interp__init_part0_A_const_83.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_65, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_67 lang.IFn; if linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any = v__1927000386__auto____1; if linked_66 == nil { tmp3 = ifn_67.Invoke_O__O(arg_68) } else { tmp3 = linked_66.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_65, arg_68) }; tmp2 = lang.MultiFn_InstanceOf(tmp3) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_81; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_86)); var tmp5 *lang.Var = A_arbace_classes_interp__init_part0_A_const_81; var tmp6 *jrt.String = Lit_344; var tmp7 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_classes_interp_eval393000079_fn__393000080_A_New(); var tmp8 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_classes_interp_eval393000079_fn__393000080_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_345, false, nil); A_arbace_classes_interp_eval393000079_fn__393000080_A_fn_class = fncls__69d; tmp8 = fncls__69d } else { tmp8 = fncls__69 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp8, nil); var tmp9 lang.IFn = Up_Compiler_AOTFn_IFn(tmp7); var tmp10 any = A_arbace_classes_interp__init_part0_A_const_84; tmp5.BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp6, tmp9, tmp10, A_arbace_classes_interp__init_part0_A_const_85)); return A_arbace_classes_interp__init_part0_A_const_81 } }

func A_arbace_classes_interp__init_part0_A_Unit42__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(334, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_38; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_classes_interp_node_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_classes_interp_node_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_346, false, nil); A_arbace_classes_interp_node_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_87)); return A_arbace_classes_interp__init_part0_A_const_38 }




func A_arbace_classes_interp__init_part0_A_Unit43__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(339, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_84; var tmp3 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_classes_interp_eval393000084_fn__393000085_A_New(); var tmp4 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_classes_interp_eval393000084_fn__393000085_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_347, false, nil); A_arbace_classes_interp_eval393000084_fn__393000085_A_fn_class = fncls__73d; tmp4 = fncls__73d } else { tmp4 = fncls__73 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }


func A_arbace_classes_interp__init_part0_A_Unit44__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(342, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_88; var tmp3 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_classes_interp_eval393000088_fn__393000089_A_New(); var tmp4 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_classes_interp_eval393000088_fn__393000089_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_348, false, nil); A_arbace_classes_interp_eval393000088_fn__393000089_A_fn_class = fncls__75d; tmp4 = fncls__75d } else { tmp4 = fncls__75 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }







func A_arbace_classes_interp__init_part0_A_Unit45__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(350, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_89; var tmp3 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_classes_interp_eval393000092_fn__393000093_A_New(); var tmp4 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_classes_interp_eval393000092_fn__393000093_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_349, false, nil); A_arbace_classes_interp_eval393000092_fn__393000093_A_fn_class = fncls__77d; tmp4 = fncls__77d } else { tmp4 = fncls__77 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }

func A_arbace_classes_interp__init_part0_A_Unit46__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(352, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_90; var tmp3 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_classes_interp_eval393000096_fn__393000097_A_New(); var tmp4 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_classes_interp_eval393000096_fn__393000097_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_350, false, nil); A_arbace_classes_interp_eval393000096_fn__393000097_A_fn_class = fncls__79d; tmp4 = fncls__79d } else { tmp4 = fncls__79 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }

func A_arbace_classes_interp__init_part0_A_Unit47__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(354, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_91; var tmp3 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_classes_interp_eval393000100_fn__393000101_A_New(); var tmp4 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_classes_interp_eval393000100_fn__393000101_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_351, false, nil); A_arbace_classes_interp_eval393000100_fn__393000101_A_fn_class = fncls__81d; tmp4 = fncls__81d } else { tmp4 = fncls__81 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }




func A_arbace_classes_interp__init_part0_A_Unit48__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(359, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_64; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_classes_interp_this0_index_A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_classes_interp_this0_index_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_352, false, nil); A_arbace_classes_interp_this0_index_A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_92)); return A_arbace_classes_interp__init_part0_A_const_64 }






func A_arbace_classes_interp__init_part0_A_Unit49__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(366, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_93; var tmp3 *lang.Compiler_AOTFn; var fnbody__86 any = A_arbace_classes_interp_eval393000108_fn__393000109_A_New(); var tmp4 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_classes_interp_eval393000108_fn__393000109_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_353, false, nil); A_arbace_classes_interp_eval393000108_fn__393000109_A_fn_class = fncls__85d; tmp4 = fncls__85d } else { tmp4 = fncls__85 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__86, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }





func A_arbace_classes_interp__init_part0_A_Unit50__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(372, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_94; var tmp3 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_classes_interp_eval393000112_fn__393000113_A_New(); var tmp4 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_classes_interp_eval393000112_fn__393000113_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_354, false, nil); A_arbace_classes_interp_eval393000112_fn__393000113_A_fn_class = fncls__87d; tmp4 = fncls__87d } else { tmp4 = fncls__87 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }


func A_arbace_classes_interp__init_part0_A_Unit51__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(375, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_95; var tmp3 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_classes_interp_eval393000116_fn__393000117_A_New(); var tmp4 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_classes_interp_eval393000116_fn__393000117_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_355, false, nil); A_arbace_classes_interp_eval393000116_fn__393000117_A_fn_class = fncls__89d; tmp4 = fncls__89d } else { tmp4 = fncls__89 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }





func A_arbace_classes_interp__init_part0_A_Unit52__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(381, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_96; var tmp3 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_classes_interp_eval393000120_fn__393000121_A_New(); var tmp4 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_classes_interp_eval393000120_fn__393000121_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_356, false, nil); A_arbace_classes_interp_eval393000120_fn__393000121_A_fn_class = fncls__91d; tmp4 = fncls__91d } else { tmp4 = fncls__91 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }


func A_arbace_classes_interp__init_part0_A_Unit53__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(384, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_97; var tmp3 *lang.Compiler_AOTFn; var fnbody__94 any = A_arbace_classes_interp_eval393000124_fn__393000125_A_New(); var tmp4 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_classes_interp_eval393000124_fn__393000125_A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_357, false, nil); A_arbace_classes_interp_eval393000124_fn__393000125_A_fn_class = fncls__93d; tmp4 = fncls__93d } else { tmp4 = fncls__93 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__94, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }


func A_arbace_classes_interp__init_part0_A_Unit54__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(387, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_98; var tmp3 *lang.Compiler_AOTFn; var fnbody__96 any = A_arbace_classes_interp_eval393000128_fn__393000129_A_New(); var tmp4 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_classes_interp_eval393000128_fn__393000129_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_358, false, nil); A_arbace_classes_interp_eval393000128_fn__393000129_A_fn_class = fncls__95d; tmp4 = fncls__95d } else { tmp4 = fncls__95 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }






func A_arbace_classes_interp__init_part0_A_Unit55__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(394, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_99; var tmp3 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_classes_interp_eval393000132_fn__393000133_A_New(); var tmp4 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_classes_interp_eval393000132_fn__393000133_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_359, false, nil); A_arbace_classes_interp_eval393000132_fn__393000133_A_fn_class = fncls__97d; tmp4 = fncls__97d } else { tmp4 = fncls__97 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }




func A_arbace_classes_interp__init_part0_A_Unit56__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(399, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_100; var tmp3 *lang.Compiler_AOTFn; var fnbody__100 any = A_arbace_classes_interp_eval393000136_fn__393000137_A_New(); var tmp4 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_classes_interp_eval393000136_fn__393000137_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_360, false, nil); A_arbace_classes_interp_eval393000136_fn__393000137_A_fn_class = fncls__99d; tmp4 = fncls__99d } else { tmp4 = fncls__99 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }











func A_arbace_classes_interp__init_part0_A_Unit57__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(411, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_101; var tmp3 *lang.Compiler_AOTFn; var fnbody__102 any = A_arbace_classes_interp_eval393000146_fn__393000147_A_New(); var tmp4 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_classes_interp_eval393000146_fn__393000147_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_361, false, nil); A_arbace_classes_interp_eval393000146_fn__393000147_A_fn_class = fncls__101d; tmp4 = fncls__101d } else { tmp4 = fncls__101 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }




func A_arbace_classes_interp__init_part0_A_Unit58__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(416, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_102; var tmp3 *lang.Compiler_AOTFn; var fnbody__104 any = A_arbace_classes_interp_eval393000152_fn__393000153_A_New(); var tmp4 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_classes_interp_eval393000152_fn__393000153_A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_362, false, nil); A_arbace_classes_interp_eval393000152_fn__393000153_A_fn_class = fncls__103d; tmp4 = fncls__103d } else { tmp4 = fncls__103 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__104, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }
func A_arbace_classes_interp__init_part0_A_Unit59__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(417, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_103; var tmp3 *lang.Compiler_AOTFn; var fnbody__106 any = A_arbace_classes_interp_eval393000156_fn__393000157_A_New(); var tmp4 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_classes_interp_eval393000156_fn__393000157_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_363, false, nil); A_arbace_classes_interp_eval393000156_fn__393000157_A_fn_class = fncls__105d; tmp4 = fncls__105d } else { tmp4 = fncls__105 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }
func A_arbace_classes_interp__init_part0_A_Unit60__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(418, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_104; var tmp3 *lang.Compiler_AOTFn; var fnbody__108 any = A_arbace_classes_interp_eval393000160_fn__393000161_A_New(); var tmp4 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_classes_interp_eval393000160_fn__393000161_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_364, false, nil); A_arbace_classes_interp_eval393000160_fn__393000161_A_fn_class = fncls__107d; tmp4 = fncls__107d } else { tmp4 = fncls__107 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__108, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }

func A_arbace_classes_interp__init_part0_A_Unit61__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(420, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_105; var tmp3 *lang.Compiler_AOTFn; var fnbody__110 any = A_arbace_classes_interp_eval393000164_fn__393000165_A_New(); var tmp4 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_classes_interp_eval393000164_fn__393000165_A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_365, false, nil); A_arbace_classes_interp_eval393000164_fn__393000165_A_fn_class = fncls__109d; tmp4 = fncls__109d } else { tmp4 = fncls__109 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__110, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }


func A_arbace_classes_interp__init_part0_A_Unit62__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(423, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_106; var tmp2 *lang.Compiler_AOTFn; var fnbody__112 any = A_arbace_classes_interp_and_or_A_New(); var tmp3 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_classes_interp_and_or_A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_366, false, nil); A_arbace_classes_interp_and_or_A_fn_class = fncls__111d; tmp3 = fncls__111d } else { tmp3 = fncls__111 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__112, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_106; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_107)); return A_arbace_classes_interp__init_part0_A_const_106 }




func A_arbace_classes_interp__init_part0_A_Unit63__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(428, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_108; var tmp3 *lang.Compiler_AOTFn; var fnbody__114 any = A_arbace_classes_interp_eval393000172_fn__393000173_A_New(); var tmp4 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_classes_interp_eval393000172_fn__393000173_A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_367, false, nil); A_arbace_classes_interp_eval393000172_fn__393000173_A_fn_class = fncls__113d; tmp4 = fncls__113d } else { tmp4 = fncls__113 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__114, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }
func A_arbace_classes_interp__init_part0_A_Unit64__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(429, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_109; var tmp3 *lang.Compiler_AOTFn; var fnbody__116 any = A_arbace_classes_interp_eval393000176_fn__393000177_A_New(); var tmp4 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_classes_interp_eval393000176_fn__393000177_A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_368, false, nil); A_arbace_classes_interp_eval393000176_fn__393000177_A_fn_class = fncls__115d; tmp4 = fncls__115d } else { tmp4 = fncls__115 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__116, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }

func A_arbace_classes_interp__init_part0_A_Unit65__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(431, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_110; var tmp3 *lang.Compiler_AOTFn; var fnbody__118 any = A_arbace_classes_interp_eval393000180_fn__393000181_A_New(); var tmp4 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_classes_interp_eval393000180_fn__393000181_A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_369, false, nil); A_arbace_classes_interp_eval393000180_fn__393000181_A_fn_class = fncls__117d; tmp4 = fncls__117d } else { tmp4 = fncls__117 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__118, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }




func A_arbace_classes_interp__init_part0_A_Unit66__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(436, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_111; var tmp3 *lang.Compiler_AOTFn; var fnbody__120 any = A_arbace_classes_interp_eval393000187_fn__393000188_A_New(); var tmp4 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_classes_interp_eval393000187_fn__393000188_A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_370, false, nil); A_arbace_classes_interp_eval393000187_fn__393000188_A_fn_class = fncls__119d; tmp4 = fncls__119d } else { tmp4 = fncls__119 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__120, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }


func A_arbace_classes_interp__init_part0_A_Unit67__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(439, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_112; var tmp2 *lang.Compiler_AOTFn; var fnbody__122 any = A_arbace_classes_interp_let_node_A_New(); var tmp3 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_classes_interp_let_node_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_371, false, nil); A_arbace_classes_interp_let_node_A_fn_class = fncls__121d; tmp3 = fncls__121d } else { tmp3 = fncls__121 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__122, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_112; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_113)); return A_arbace_classes_interp__init_part0_A_const_112 }

























func A_arbace_classes_interp__init_part0_A_Unit68__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(465, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_114; var tmp3 *lang.Compiler_AOTFn; var fnbody__124 any = A_arbace_classes_interp_eval393000215_fn__393000216_A_New(); var tmp4 *jrt.Class; var fncls__123 *jrt.Class = A_arbace_classes_interp_eval393000215_fn__393000216_A_fn_class; if fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_372, false, nil); A_arbace_classes_interp_eval393000215_fn__393000216_A_fn_class = fncls__123d; tmp4 = fncls__123d } else { tmp4 = fncls__123 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__124, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }
func A_arbace_classes_interp__init_part0_A_Unit69__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(466, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_115; var tmp3 *lang.Compiler_AOTFn; var fnbody__126 any = A_arbace_classes_interp_eval393000219_fn__393000220_A_New(); var tmp4 *jrt.Class; var fncls__125 *jrt.Class = A_arbace_classes_interp_eval393000219_fn__393000220_A_fn_class; if fncls__125 == nil { var fncls__125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_373, false, nil); A_arbace_classes_interp_eval393000219_fn__393000220_A_fn_class = fncls__125d; tmp4 = fncls__125d } else { tmp4 = fncls__125 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__126, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }

func A_arbace_classes_interp__init_part0_A_Unit70__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(468, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_116; var tmp3 *lang.Compiler_AOTFn; var fnbody__128 any = A_arbace_classes_interp_eval393000223_fn__393000224_A_New(); var tmp4 *jrt.Class; var fncls__127 *jrt.Class = A_arbace_classes_interp_eval393000223_fn__393000224_A_fn_class; if fncls__127 == nil { var fncls__127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_374, false, nil); A_arbace_classes_interp_eval393000223_fn__393000224_A_fn_class = fncls__127d; tmp4 = fncls__127d } else { tmp4 = fncls__127 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__128, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }





func A_arbace_classes_interp__init_part0_A_Unit71__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(474, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_117; var tmp3 *lang.Compiler_AOTFn; var fnbody__130 any = A_arbace_classes_interp_eval393000227_fn__393000228_A_New(); var tmp4 *jrt.Class; var fncls__129 *jrt.Class = A_arbace_classes_interp_eval393000227_fn__393000228_A_fn_class; if fncls__129 == nil { var fncls__129d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_375, false, nil); A_arbace_classes_interp_eval393000227_fn__393000228_A_fn_class = fncls__129d; tmp4 = fncls__129d } else { tmp4 = fncls__129 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__130, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }








func A_arbace_classes_interp__init_part0_A_Unit72__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(483, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_118; var tmp3 *lang.Compiler_AOTFn; var fnbody__132 any = A_arbace_classes_interp_eval393000231_fn__393000232_A_New(); var tmp4 *jrt.Class; var fncls__131 *jrt.Class = A_arbace_classes_interp_eval393000231_fn__393000232_A_fn_class; if fncls__131 == nil { var fncls__131d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_376, false, nil); A_arbace_classes_interp_eval393000231_fn__393000232_A_fn_class = fncls__131d; tmp4 = fncls__131d } else { tmp4 = fncls__131 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__132, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }





func A_arbace_classes_interp__init_part0_A_Unit73__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(489, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_119; var tmp3 *lang.Compiler_AOTFn; var fnbody__134 any = A_arbace_classes_interp_eval393000237_fn__393000238_A_New(); var tmp4 *jrt.Class; var fncls__133 *jrt.Class = A_arbace_classes_interp_eval393000237_fn__393000238_A_fn_class; if fncls__133 == nil { var fncls__133d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_377, false, nil); A_arbace_classes_interp_eval393000237_fn__393000238_A_fn_class = fncls__133d; tmp4 = fncls__133d } else { tmp4 = fncls__133 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__134, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }






func A_arbace_classes_interp__init_part0_A_Unit74__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(496, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_120; var tmp3 *lang.Compiler_AOTFn; var fnbody__136 any = A_arbace_classes_interp_eval393000241_fn__393000242_A_New(); var tmp4 *jrt.Class; var fncls__135 *jrt.Class = A_arbace_classes_interp_eval393000241_fn__393000242_A_fn_class; if fncls__135 == nil { var fncls__135d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_378, false, nil); A_arbace_classes_interp_eval393000241_fn__393000242_A_fn_class = fncls__135d; tmp4 = fncls__135d } else { tmp4 = fncls__135 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__136, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }

func A_arbace_classes_interp__init_part0_A_Unit75__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(498, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_121; var tmp3 *lang.Compiler_AOTFn; var fnbody__138 any = A_arbace_classes_interp_eval393000245_fn__393000246_A_New(); var tmp4 *jrt.Class; var fncls__137 *jrt.Class = A_arbace_classes_interp_eval393000245_fn__393000246_A_fn_class; if fncls__137 == nil { var fncls__137d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_379, false, nil); A_arbace_classes_interp_eval393000245_fn__393000246_A_fn_class = fncls__137d; tmp4 = fncls__137d } else { tmp4 = fncls__137 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__138, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }


















func A_arbace_classes_interp__init_part0_A_Unit76__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(517, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_122; var tmp3 *lang.Compiler_AOTFn; var fnbody__140 any = A_arbace_classes_interp_eval393000286_fn__393000287_A_New(); var tmp4 *jrt.Class; var fncls__139 *jrt.Class = A_arbace_classes_interp_eval393000286_fn__393000287_A_fn_class; if fncls__139 == nil { var fncls__139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_380, false, nil); A_arbace_classes_interp_eval393000286_fn__393000287_A_fn_class = fncls__139d; tmp4 = fncls__139d } else { tmp4 = fncls__139 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__140, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }



func A_arbace_classes_interp__init_part0_A_Unit77__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(521, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_123; var tmp3 *lang.Compiler_AOTFn; var fnbody__142 any = A_arbace_classes_interp_eval393000290_fn__393000291_A_New(); var tmp4 *jrt.Class; var fncls__141 *jrt.Class = A_arbace_classes_interp_eval393000290_fn__393000291_A_fn_class; if fncls__141 == nil { var fncls__141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_381, false, nil); A_arbace_classes_interp_eval393000290_fn__393000291_A_fn_class = fncls__141d; tmp4 = fncls__141d } else { tmp4 = fncls__141 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__142, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }






func A_arbace_classes_interp__init_part0_A_Unit78__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(528, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_124; var tmp2 *lang.Compiler_AOTFn; var fnbody__144 any = A_arbace_classes_interp_arg_nodes_A_New(); var tmp3 *jrt.Class; var fncls__143 *jrt.Class = A_arbace_classes_interp_arg_nodes_A_fn_class; if fncls__143 == nil { var fncls__143d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_382, false, nil); A_arbace_classes_interp_arg_nodes_A_fn_class = fncls__143d; tmp3 = fncls__143d } else { tmp3 = fncls__143 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__144, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_124; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_125)); return A_arbace_classes_interp__init_part0_A_const_124 }


func A_arbace_classes_interp__init_part0_A_Unit79__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(531, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_126; var tmp2 *lang.Compiler_AOTFn; var fnbody__146 any = A_arbace_classes_interp_ptypes_A_New(); var tmp3 *jrt.Class; var fncls__145 *jrt.Class = A_arbace_classes_interp_ptypes_A_fn_class; if fncls__145 == nil { var fncls__145d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_383, false, nil); A_arbace_classes_interp_ptypes_A_fn_class = fncls__145d; tmp3 = fncls__145d } else { tmp3 = fncls__145 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__146, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_126; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_127)); return A_arbace_classes_interp__init_part0_A_const_126 }

func A_arbace_classes_interp__init_part0_A_Unit80__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(533, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_128; var tmp2 *lang.Compiler_AOTFn; var fnbody__148 any = A_arbace_classes_interp_has_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__147 *jrt.Class = A_arbace_classes_interp_has_QMARK__A_fn_class; if fncls__147 == nil { var fncls__147d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_384, false, nil); A_arbace_classes_interp_has_QMARK__A_fn_class = fncls__147d; tmp3 = fncls__147d } else { tmp3 = fncls__147 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__148, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_128; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_129)); return A_arbace_classes_interp__init_part0_A_const_128 }

func A_arbace_classes_interp__init_part0_A_Unit81__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(535, 1); A_arbace_classes_interp__init_part0_A_const_130.BindRoot_O__V(A_arbace_classes_interp__init_part0_A_const_131); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_130; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_132)); return A_arbace_classes_interp__init_part0_A_const_130 }
func A_arbace_classes_interp__init_part0_A_Unit82__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(536, 1); A_arbace_classes_interp__init_part0_A_const_133.BindRoot_O__V(A_arbace_classes_interp__init_part0_A_const_134); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_133; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_135)); return A_arbace_classes_interp__init_part0_A_const_133 }
func A_arbace_classes_interp__init_part0_A_Unit83__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(537, 1); A_arbace_classes_interp__init_part0_A_const_136.BindRoot_O__V(A_arbace_classes_interp__init_part0_A_const_137); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_136; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_138)); return A_arbace_classes_interp__init_part0_A_const_136 }
func A_arbace_classes_interp__init_part0_A_Unit84__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(538, 1); A_arbace_classes_interp__init_part0_A_const_139.BindRoot_O__V(A_arbace_classes_interp__init_part0_A_const_140); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_139; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_141)); return A_arbace_classes_interp__init_part0_A_const_139 }
func A_arbace_classes_interp__init_part0_A_Unit85__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(539, 1); A_arbace_classes_interp__init_part0_A_const_142.BindRoot_O__V(A_arbace_classes_interp__init_part0_A_const_143); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_142; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_144)); return A_arbace_classes_interp__init_part0_A_const_142 }

func A_arbace_classes_interp__init_part0_A_Unit86__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(541, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_145; var tmp2 *lang.Compiler_AOTFn; var fnbody__150 any = A_arbace_classes_interp_volatile_field_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__149 *jrt.Class = A_arbace_classes_interp_volatile_field_QMARK__A_fn_class; if fncls__149 == nil { var fncls__149d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_385, false, nil); A_arbace_classes_interp_volatile_field_QMARK__A_fn_class = fncls__149d; tmp3 = fncls__149d } else { tmp3 = fncls__149 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__150, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_145; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_146)); return A_arbace_classes_interp__init_part0_A_const_145 }





func A_arbace_classes_interp__init_part0_A_Unit87__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(547, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_147; var tmp2 *lang.Compiler_AOTFn; var fnbody__152 any = A_arbace_classes_interp_method_of_A_New(); var tmp3 *jrt.Class; var fncls__151 *jrt.Class = A_arbace_classes_interp_method_of_A_fn_class; if fncls__151 == nil { var fncls__151d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_386, false, nil); A_arbace_classes_interp_method_of_A_fn_class = fncls__151d; tmp3 = fncls__151d } else { tmp3 = fncls__151 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__152, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_147; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_148)); return A_arbace_classes_interp__init_part0_A_const_147 }








func A_arbace_classes_interp__init_part0_A_Unit88__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(556, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_149; var tmp2 *lang.Compiler_AOTFn; var fnbody__154 any = A_arbace_classes_interp_private_method_A_New(); var tmp3 *jrt.Class; var fncls__153 *jrt.Class = A_arbace_classes_interp_private_method_A_fn_class; if fncls__153 == nil { var fncls__153d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_387, false, nil); A_arbace_classes_interp_private_method_A_fn_class = fncls__153d; tmp3 = fncls__153d } else { tmp3 = fncls__153 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__154, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_149; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_150)); return A_arbace_classes_interp__init_part0_A_const_149 }







func A_arbace_classes_interp__init_part0_A_Unit89__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(564, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_151; var tmp3 *lang.Compiler_AOTFn; var fnbody__156 any = A_arbace_classes_interp_eval393000305_fn__393000306_A_New(); var tmp4 *jrt.Class; var fncls__155 *jrt.Class = A_arbace_classes_interp_eval393000305_fn__393000306_A_fn_class; if fncls__155 == nil { var fncls__155d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_388, false, nil); A_arbace_classes_interp_eval393000305_fn__393000306_A_fn_class = fncls__155d; tmp4 = fncls__155d } else { tmp4 = fncls__155 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__156, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }











































func A_arbace_classes_interp__init_part0_A_Unit90__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(608, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_152; var tmp2 *lang.Compiler_AOTFn; var fnbody__158 any = A_arbace_classes_interp_ctor_meth_A_New(); var tmp3 *jrt.Class; var fncls__157 *jrt.Class = A_arbace_classes_interp_ctor_meth_A_fn_class; if fncls__157 == nil { var fncls__157d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_389, false, nil); A_arbace_classes_interp_ctor_meth_A_fn_class = fncls__157d; tmp3 = fncls__157d } else { tmp3 = fncls__157 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__158, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_152; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_153)); return A_arbace_classes_interp__init_part0_A_const_152 }


func A_arbace_classes_interp__init_part0_A_Unit91__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(611, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_154; var tmp2 *lang.Compiler_AOTFn; var fnbody__160 any = A_arbace_classes_interp_implicit_fields_A_New(); var tmp3 *jrt.Class; var fncls__159 *jrt.Class = A_arbace_classes_interp_implicit_fields_A_fn_class; if fncls__159 == nil { var fncls__159d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_390, false, nil); A_arbace_classes_interp_implicit_fields_A_fn_class = fncls__159d; tmp3 = fncls__159d } else { tmp3 = fncls__159 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__160, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_154; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_155)); return A_arbace_classes_interp__init_part0_A_const_154 }












func A_arbace_classes_interp__init_part0_A_Unit92__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(624, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_156; var tmp2 *lang.Compiler_AOTFn; var fnbody__162 any = A_arbace_classes_interp_super_outer_fields_A_New(); var tmp3 *jrt.Class; var fncls__161 *jrt.Class = A_arbace_classes_interp_super_outer_fields_A_fn_class; if fncls__161 == nil { var fncls__161d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_391, false, nil); A_arbace_classes_interp_super_outer_fields_A_fn_class = fncls__161d; tmp3 = fncls__161d } else { tmp3 = fncls__161 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__162, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_156; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_157)); return A_arbace_classes_interp__init_part0_A_const_156 }















func A_arbace_classes_interp__init_part0_A_Unit93__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(640, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_158; var tmp3 *lang.Compiler_AOTFn; var fnbody__164 any = A_arbace_classes_interp_eval393000326_fn__393000327_A_New(); var tmp4 *jrt.Class; var fncls__163 *jrt.Class = A_arbace_classes_interp_eval393000326_fn__393000327_A_fn_class; if fncls__163 == nil { var fncls__163d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_392, false, nil); A_arbace_classes_interp_eval393000326_fn__393000327_A_fn_class = fncls__163d; tmp4 = fncls__163d } else { tmp4 = fncls__163 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__164, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }





























func A_arbace_classes_interp__init_part0_A_Unit94__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(670, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_159; var tmp2 *lang.Compiler_AOTFn; var fnbody__166 any = A_arbace_classes_interp_clj_const_value_A_New(); var tmp3 *jrt.Class; var fncls__165 *jrt.Class = A_arbace_classes_interp_clj_const_value_A_fn_class; if fncls__165 == nil { var fncls__165d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_393, false, nil); A_arbace_classes_interp_clj_const_value_A_fn_class = fncls__165d; tmp3 = fncls__165d } else { tmp3 = fncls__165 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__166, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_159; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_160)); return A_arbace_classes_interp__init_part0_A_const_159 }










func A_arbace_classes_interp__init_part0_A_Unit95__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(681, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_161; var tmp3 *lang.Compiler_AOTFn; var fnbody__168 any = A_arbace_classes_interp_eval393000348_fn__393000349_A_New(); var tmp4 *jrt.Class; var fncls__167 *jrt.Class = A_arbace_classes_interp_eval393000348_fn__393000349_A_fn_class; if fncls__167 == nil { var fncls__167d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_394, false, nil); A_arbace_classes_interp_eval393000348_fn__393000349_A_fn_class = fncls__167d; tmp4 = fncls__167d } else { tmp4 = fncls__167 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__168, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }

















func A_arbace_classes_interp__init_part0_A_Unit96__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(699, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_162; var tmp3 *lang.Compiler_AOTFn; var fnbody__170 any = A_arbace_classes_interp_eval393000355_fn__393000356_A_New(); var tmp4 *jrt.Class; var fncls__169 *jrt.Class = A_arbace_classes_interp_eval393000355_fn__393000356_A_fn_class; if fncls__169 == nil { var fncls__169d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_395, false, nil); A_arbace_classes_interp_eval393000355_fn__393000356_A_fn_class = fncls__169d; tmp4 = fncls__169d } else { tmp4 = fncls__169 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__170, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }













func A_arbace_classes_interp__init_part0_A_Unit97__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(713, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part0_A_const_163; var tmp2 *lang.Compiler_AOTFn; var fnbody__172 any = A_arbace_classes_interp_super_field_A_New(); var tmp3 *jrt.Class; var fncls__171 *jrt.Class = A_arbace_classes_interp_super_field_A_fn_class; if fncls__171 == nil { var fncls__171d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_396, false, nil); A_arbace_classes_interp_super_field_A_fn_class = fncls__171d; tmp3 = fncls__171d } else { tmp3 = fncls__171 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__172, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part0_A_const_163; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part0_A_const_164)); return A_arbace_classes_interp__init_part0_A_const_163 }









func A_arbace_classes_interp__init_part0_A_Unit98__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(723, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_165; var tmp3 *lang.Compiler_AOTFn; var fnbody__174 any = A_arbace_classes_interp_eval393000363_fn__393000364_A_New(); var tmp4 *jrt.Class; var fncls__173 *jrt.Class = A_arbace_classes_interp_eval393000363_fn__393000364_A_fn_class; if fncls__173 == nil { var fncls__173d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_397, false, nil); A_arbace_classes_interp_eval393000363_fn__393000364_A_fn_class = fncls__173d; tmp4 = fncls__173d } else { tmp4 = fncls__173 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__174, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }














func A_arbace_classes_interp__init_part0_A_Unit99__O() any { A_arbace_classes_interp__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(738, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part0_A_const_81.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part0_A_const_166; var tmp3 *lang.Compiler_AOTFn; var fnbody__176 any = A_arbace_classes_interp_eval393000367_fn__393000368_A_New(); var tmp4 *jrt.Class; var fncls__175 *jrt.Class = A_arbace_classes_interp_eval393000367_fn__393000368_A_fn_class; if fncls__175 == nil { var fncls__175d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_398, false, nil); A_arbace_classes_interp_eval393000367_fn__393000368_A_fn_class = fncls__175d; tmp4 = fncls__175d } else { tmp4 = fncls__175 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__176, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }















func A_arbace_classes_interp__init_part1_A_Unit100__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(754, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part1_A_const_0.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part1_A_const_1; var tmp3 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_classes_interp_eval393000371_fn__393000372_A_New(); var tmp4 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_classes_interp_eval393000371_fn__393000372_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_400, false, nil); A_arbace_classes_interp_eval393000371_fn__393000372_A_fn_class = fncls__1d; tmp4 = fncls__1d } else { tmp4 = fncls__1 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }
//line :754:1
func A_arbace_classes_interp__init_part1_A_Init__O() any { A_arbace_classes_interp__init_part1_A_Init(); return nil }
//line :754:1
func A_arbace_classes_interp__init_part1_A_Load__O() any { A_arbace_classes_interp__init_part1_A_Init(); A_arbace_classes_interp__init_part1_A_Unit100__O(); A_arbace_classes_interp__init_part1_A_Unit101__O(); A_arbace_classes_interp__init_part1_A_Unit102__O(); A_arbace_classes_interp__init_part1_A_Unit103__O(); A_arbace_classes_interp__init_part1_A_Unit104__O(); A_arbace_classes_interp__init_part1_A_Unit105__O(); A_arbace_classes_interp__init_part1_A_Unit106__O(); A_arbace_classes_interp__init_part1_A_Unit107__O(); A_arbace_classes_interp__init_part1_A_Unit108__O(); A_arbace_classes_interp__init_part1_A_Unit109__O(); A_arbace_classes_interp__init_part1_A_Unit110__O(); A_arbace_classes_interp__init_part1_A_Unit111__O(); A_arbace_classes_interp__init_part1_A_Unit112__O(); A_arbace_classes_interp__init_part1_A_Unit113__O(); A_arbace_classes_interp__init_part1_A_Unit114__O(); A_arbace_classes_interp__init_part1_A_Unit115__O(); A_arbace_classes_interp__init_part1_A_Unit116__O(); A_arbace_classes_interp__init_part1_A_Unit117__O(); A_arbace_classes_interp__init_part1_A_Unit118__O(); A_arbace_classes_interp__init_part1_A_Unit119__O(); A_arbace_classes_interp__init_part1_A_Unit120__O(); A_arbace_classes_interp__init_part1_A_Unit121__O(); A_arbace_classes_interp__init_part1_A_Unit122__O(); A_arbace_classes_interp__init_part1_A_Unit123__O(); A_arbace_classes_interp__init_part1_A_Unit124__O(); A_arbace_classes_interp__init_part1_A_Unit125__O(); A_arbace_classes_interp__init_part1_A_Unit126__O(); A_arbace_classes_interp__init_part1_A_Unit127__O(); A_arbace_classes_interp__init_part1_A_Unit128__O(); A_arbace_classes_interp__init_part1_A_Unit129__O(); A_arbace_classes_interp__init_part1_A_Unit130__O(); A_arbace_classes_interp__init_part1_A_Unit131__O(); A_arbace_classes_interp__init_part1_A_Unit132__O(); A_arbace_classes_interp__init_part1_A_Unit133__O(); A_arbace_classes_interp__init_part1_A_Unit134__O(); A_arbace_classes_interp__init_part1_A_Unit135__O(); A_arbace_classes_interp__init_part1_A_Unit136__O(); A_arbace_classes_interp__init_part1_A_Unit137__O(); A_arbace_classes_interp__init_part1_A_Unit138__O(); A_arbace_classes_interp__init_part1_A_Unit139__O(); A_arbace_classes_interp__init_part1_A_Unit140__O(); A_arbace_classes_interp__init_part1_A_Unit141__O(); A_arbace_classes_interp__init_part1_A_Unit142__O(); A_arbace_classes_interp__init_part1_A_Unit143__O(); A_arbace_classes_interp__init_part1_A_Unit144__O(); A_arbace_classes_interp__init_part1_A_Unit145__O(); A_arbace_classes_interp__init_part1_A_Unit146__O(); A_arbace_classes_interp__init_part1_A_Unit147__O(); A_arbace_classes_interp__init_part1_A_Unit148__O(); A_arbace_classes_interp__init_part1_A_Unit149__O(); A_arbace_classes_interp__init_part1_A_Unit150__O(); A_arbace_classes_interp__init_part1_A_Unit151__O(); A_arbace_classes_interp__init_part1_A_Unit152__O(); A_arbace_classes_interp__init_part1_A_Unit153__O(); A_arbace_classes_interp__init_part1_A_Unit154__O(); A_arbace_classes_interp__init_part1_A_Unit155__O(); A_arbace_classes_interp__init_part1_A_Unit156__O(); A_arbace_classes_interp__init_part1_A_Unit157__O(); A_arbace_classes_interp__init_part1_A_Unit158__O(); A_arbace_classes_interp__init_part1_A_Unit159__O(); A_arbace_classes_interp__init_part1_A_Unit160__O(); A_arbace_classes_interp__init_part1_A_Unit161__O(); A_arbace_classes_interp__init_part1_A_Unit162__O(); A_arbace_classes_interp__init_part1_A_Unit163__O(); return nil }






func A_arbace_classes_interp__init_part1_A_Unit101__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(761, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part1_A_const_0.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part1_A_const_2; var tmp3 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_classes_interp_eval393000376_fn__393000377_A_New(); var tmp4 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_classes_interp_eval393000376_fn__393000377_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_401, false, nil); A_arbace_classes_interp_eval393000376_fn__393000377_A_fn_class = fncls__3d; tmp4 = fncls__3d } else { tmp4 = fncls__3 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }




func A_arbace_classes_interp__init_part1_A_Unit102__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(766, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part1_A_const_0.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part1_A_const_3; var tmp3 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_classes_interp_eval393000382_fn__393000383_A_New(); var tmp4 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_classes_interp_eval393000382_fn__393000383_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_402, false, nil); A_arbace_classes_interp_eval393000382_fn__393000383_A_fn_class = fncls__5d; tmp4 = fncls__5d } else { tmp4 = fncls__5 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }





func A_arbace_classes_interp__init_part1_A_Unit103__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(772, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part1_A_const_0.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part1_A_const_4; var tmp3 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_classes_interp_eval393000387_fn__393000388_A_New(); var tmp4 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_classes_interp_eval393000387_fn__393000388_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_403, false, nil); A_arbace_classes_interp_eval393000387_fn__393000388_A_fn_class = fncls__7d; tmp4 = fncls__7d } else { tmp4 = fncls__7 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }





func A_arbace_classes_interp__init_part1_A_Unit104__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(778, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part1_A_const_0.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part1_A_const_5; var tmp3 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_classes_interp_eval393000394_fn__393000395_A_New(); var tmp4 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_classes_interp_eval393000394_fn__393000395_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_404, false, nil); A_arbace_classes_interp_eval393000394_fn__393000395_A_fn_class = fncls__9d; tmp4 = fncls__9d } else { tmp4 = fncls__9 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }



func A_arbace_classes_interp__init_part1_A_Unit105__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(782, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part1_A_const_0.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part1_A_const_6; var tmp3 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_classes_interp_eval393000400_fn__393000401_A_New(); var tmp4 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_classes_interp_eval393000400_fn__393000401_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_405, false, nil); A_arbace_classes_interp_eval393000400_fn__393000401_A_fn_class = fncls__11d; tmp4 = fncls__11d } else { tmp4 = fncls__11 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }


func A_arbace_classes_interp__init_part1_A_Unit106__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(785, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part1_A_const_0.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part1_A_const_7; var tmp3 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_classes_interp_eval393000404_fn__393000405_A_New(); var tmp4 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_classes_interp_eval393000404_fn__393000405_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_406, false, nil); A_arbace_classes_interp_eval393000404_fn__393000405_A_fn_class = fncls__13d; tmp4 = fncls__13d } else { tmp4 = fncls__13 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }



func A_arbace_classes_interp__init_part1_A_Unit107__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(789, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part1_A_const_0.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part1_A_const_8; var tmp3 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_classes_interp_eval393000408_fn__393000409_A_New(); var tmp4 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_classes_interp_eval393000408_fn__393000409_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_407, false, nil); A_arbace_classes_interp_eval393000408_fn__393000409_A_fn_class = fncls__15d; tmp4 = fncls__15d } else { tmp4 = fncls__15 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }

func A_arbace_classes_interp__init_part1_A_Unit108__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(791, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part1_A_const_0.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part1_A_const_9; var tmp3 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_classes_interp_eval393000412_fn__393000413_A_New(); var tmp4 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_classes_interp_eval393000412_fn__393000413_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_408, false, nil); A_arbace_classes_interp_eval393000412_fn__393000413_A_fn_class = fncls__17d; tmp4 = fncls__17d } else { tmp4 = fncls__17 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }









func A_arbace_classes_interp__init_part1_A_Unit109__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(801, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part1_A_const_0.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part1_A_const_10; var tmp3 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_classes_interp_eval393000424_fn__393000425_A_New(); var tmp4 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_classes_interp_eval393000424_fn__393000425_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_409, false, nil); A_arbace_classes_interp_eval393000424_fn__393000425_A_fn_class = fncls__19d; tmp4 = fncls__19d } else { tmp4 = fncls__19 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }




















func A_arbace_classes_interp__init_part1_A_Unit110__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(822, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_11; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_classes_interp_accessor_node_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_classes_interp_accessor_node_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_410, false, nil); A_arbace_classes_interp_accessor_node_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_12)); return A_arbace_classes_interp__init_part1_A_const_11 }










func A_arbace_classes_interp__init_part1_A_Unit111__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(833, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_13; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_classes_interp_pattern_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_classes_interp_pattern_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_411, false, nil); A_arbace_classes_interp_pattern_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_14)); return A_arbace_classes_interp__init_part1_A_const_13 }




















func A_arbace_classes_interp__init_part1_A_Unit112__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(854, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part1_A_const_0.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part1_A_const_15; var tmp3 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_classes_interp_eval393000437_fn__393000438_A_New(); var tmp4 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_classes_interp_eval393000437_fn__393000438_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_412, false, nil); A_arbace_classes_interp_eval393000437_fn__393000438_A_fn_class = fncls__25d; tmp4 = fncls__25d } else { tmp4 = fncls__25 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }






func A_arbace_classes_interp__init_part1_A_Unit113__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(861, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_16; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_classes_interp_box_const_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_classes_interp_box_const_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_413, false, nil); A_arbace_classes_interp_box_const_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_17)); return A_arbace_classes_interp__init_part1_A_const_16 }











func A_arbace_classes_interp__init_part1_A_Unit114__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(873, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part1_A_const_0.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part1_A_const_18; var tmp3 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_classes_interp_eval393000445_fn__393000446_A_New(); var tmp4 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_classes_interp_eval393000445_fn__393000446_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_414, false, nil); A_arbace_classes_interp_eval393000445_fn__393000446_A_fn_class = fncls__29d; tmp4 = fncls__29d } else { tmp4 = fncls__29 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }












































func A_arbace_classes_interp__init_part1_A_Unit115__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(918, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_19; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_classes_interp_host_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_classes_interp_host_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_415, false, nil); A_arbace_classes_interp_host_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_20)); return A_arbace_classes_interp__init_part1_A_const_19 }

func A_arbace_classes_interp__init_part1_A_Unit116__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(920, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_21; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_22)); return A_arbace_classes_interp__init_part1_A_const_21 }
//line :920:1
func A_arbace_classes_interp__init_part1_A_Unit117__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(920, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_23; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_24)); return A_arbace_classes_interp__init_part1_A_const_23 }

func A_arbace_classes_interp__init_part1_A_Unit118__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(922, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_25; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_classes_interp_meth_of_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_classes_interp_meth_of_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_416, false, nil); A_arbace_classes_interp_meth_of_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_26)); return A_arbace_classes_interp__init_part1_A_const_25 }









func A_arbace_classes_interp__init_part1_A_Unit119__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(932, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_27; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_classes_interp_zero_of_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_classes_interp_zero_of_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_417, false, nil); A_arbace_classes_interp_zero_of_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_28)); return A_arbace_classes_interp__init_part1_A_const_27 }

func A_arbace_classes_interp__init_part1_A_Unit120__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(934, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_29; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_classes_interp_make_klass_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_classes_interp_make_klass_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_418, false, nil); A_arbace_classes_interp_make_klass_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_30)); return A_arbace_classes_interp__init_part1_A_const_29 }

















func A_arbace_classes_interp__init_part1_A_Unit121__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(952, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_31; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_classes_interp_layout_BANG__A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_classes_interp_layout_BANG__A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_419, false, nil); A_arbace_classes_interp_layout_BANG__A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_31; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_32)); return A_arbace_classes_interp__init_part1_A_const_31 }
























































func A_arbace_classes_interp__init_part1_A_Unit122__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1009, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_33; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_classes_interp_vtable_BANG__A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_classes_interp_vtable_BANG__A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_420, false, nil); A_arbace_classes_interp_vtable_BANG__A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_33; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_34)); return A_arbace_classes_interp__init_part1_A_const_33 }
























func A_arbace_classes_interp__init_part1_A_Unit123__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1034, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_35; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_classes_interp_ctx_for_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_classes_interp_ctx_for_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_421, false, nil); A_arbace_classes_interp_ctx_for_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_35; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_36)); return A_arbace_classes_interp__init_part1_A_const_35 }







func A_arbace_classes_interp__init_part1_A_Unit124__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1042, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_37; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_classes_interp_receiver_ctx_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_classes_interp_receiver_ctx_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_422, false, nil); A_arbace_classes_interp_receiver_ctx_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_38)); return A_arbace_classes_interp__init_part1_A_const_37 }




func A_arbace_classes_interp__init_part1_A_Unit125__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1047, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_39; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_classes_interp_params_BANG__A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_classes_interp_params_BANG__A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_423, false, nil); A_arbace_classes_interp_params_BANG__A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_40)); return A_arbace_classes_interp__init_part1_A_const_39 }




func A_arbace_classes_interp__init_part1_A_Unit126__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1052, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_41; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_classes_interp_finish_BANG__A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_classes_interp_finish_BANG__A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_424, false, nil); A_arbace_classes_interp_finish_BANG__A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_42)); return A_arbace_classes_interp__init_part1_A_const_41 }





func A_arbace_classes_interp__init_part1_A_Unit127__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1058, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_43; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_classes_interp_record_op_node_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_classes_interp_record_op_node_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_425, false, nil); A_arbace_classes_interp_record_op_node_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_44)); return A_arbace_classes_interp__init_part1_A_const_43 }








func A_arbace_classes_interp__init_part1_A_Unit128__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1067, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_45; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_classes_interp_derived_body_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_classes_interp_derived_body_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_426, false, nil); A_arbace_classes_interp_derived_body_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_46)); return A_arbace_classes_interp__init_part1_A_const_45 }



















































func A_arbace_classes_interp__init_part1_A_Unit129__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1119, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_47; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_classes_interp_init_nodes_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_classes_interp_init_nodes_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_427, false, nil); A_arbace_classes_interp_init_nodes_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_48)); return A_arbace_classes_interp__init_part1_A_const_47 }




func A_arbace_classes_interp__init_part1_A_Unit130__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1124, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_49; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_50)); return A_arbace_classes_interp__init_part1_A_const_49 }

func A_arbace_classes_interp__init_part1_A_Unit131__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1126, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_51; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_classes_interp_trivial_super_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_classes_interp_trivial_super_QMARK__A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_428, false, nil); A_arbace_classes_interp_trivial_super_QMARK__A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_52)); return A_arbace_classes_interp__init_part1_A_const_51 }






func A_arbace_classes_interp__init_part1_A_Unit132__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1133, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_53; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_classes_interp_local_super_fields_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_classes_interp_local_super_fields_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_429, false, nil); A_arbace_classes_interp_local_super_fields_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_54)); return A_arbace_classes_interp__init_part1_A_const_53 }









func A_arbace_classes_interp__init_part1_A_Unit133__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1143, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_55; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_classes_interp_ctor_call_node_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_classes_interp_ctor_call_node_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_430, false, nil); A_arbace_classes_interp_ctor_call_node_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_56)); return A_arbace_classes_interp__init_part1_A_const_55 }
















































func A_arbace_classes_interp__init_part1_A_Unit134__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1192, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_49; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_classes_interp_enum_arg_nodes_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_classes_interp_enum_arg_nodes_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_431, false, nil); A_arbace_classes_interp_enum_arg_nodes_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_57)); return A_arbace_classes_interp__init_part1_A_const_49 }






func A_arbace_classes_interp__init_part1_A_Unit135__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1199, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part1_A_const_0.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part1_A_const_58; var tmp3 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_classes_interp_eval393000725_fn__393000726_A_New(); var tmp4 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_classes_interp_eval393000725_fn__393000726_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_432, false, nil); A_arbace_classes_interp_eval393000725_fn__393000726_A_fn_class = fncls__65d; tmp4 = fncls__65d } else { tmp4 = fncls__65 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }




func A_arbace_classes_interp__init_part1_A_Unit136__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1204, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_21; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_classes_interp_build_method_BANG__A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_classes_interp_build_method_BANG__A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_433, false, nil); A_arbace_classes_interp_build_method_BANG__A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_59)); return A_arbace_classes_interp__init_part1_A_const_21 }













































































func A_arbace_classes_interp__init_part1_A_Unit137__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1282, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_60; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_classes_interp_declare_siblings_BANG__A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_classes_interp_declare_siblings_BANG__A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_434, false, nil); A_arbace_classes_interp_declare_siblings_BANG__A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_61)); return A_arbace_classes_interp__init_part1_A_const_60 }











func A_arbace_classes_interp__init_part1_A_Unit138__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1294, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_62; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_classes_interp_analyze_forms_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_classes_interp_analyze_forms_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_435, false, nil); A_arbace_classes_interp_analyze_forms_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_63)); return A_arbace_classes_interp__init_part1_A_const_62 }















func A_arbace_classes_interp__init_part1_A_Unit139__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1310, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_64; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_65)); v__1927001498__auto____1 = A_arbace_classes_interp__init_part1_A_const_64; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_classes_interp__init_part1_A_const_64; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_68)); var tmp3 *lang.Var = A_arbace_classes_interp__init_part1_A_const_64; var tmp4 any; var root_73 any = A_arbace_classes_interp__init_part1_A_const_66.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = A_arbace_classes_interp__init_part1_A_const_67; if linked_74 == nil { tmp4 = ifn_75.Invoke_O__O(arg_76) } else { tmp4 = linked_74.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_73, arg_76) }; tmp3.BindRoot_O__V(tmp4); return A_arbace_classes_interp__init_part1_A_const_64 } }

func A_arbace_classes_interp__init_part1_A_Unit140__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1312, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_69; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_classes_interp_new_lambda_klass_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_classes_interp_new_lambda_klass_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_436, false, nil); A_arbace_classes_interp_new_lambda_klass_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_70)); return A_arbace_classes_interp__init_part1_A_const_69 }















func A_arbace_classes_interp__init_part1_A_Unit141__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1328, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_71; var tmp2 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_classes_interp_lambda_markers_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_classes_interp_lambda_markers_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_437, false, nil); A_arbace_classes_interp_lambda_markers_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_72)); return A_arbace_classes_interp__init_part1_A_const_71 }










func A_arbace_classes_interp__init_part1_A_Unit142__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1339, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_73; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_74)); return A_arbace_classes_interp__init_part1_A_const_73 }
//line :1339:1
func A_arbace_classes_interp__init_part1_A_Unit143__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1339, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_75; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_76)); return A_arbace_classes_interp__init_part1_A_const_75 }

func A_arbace_classes_interp__init_part1_A_Unit144__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1341, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_77; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__82 any = A_arbace_classes_interp_lambda_done_BANG__A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_classes_interp_lambda_done_BANG__A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_438, true, nil); A_arbace_classes_interp_lambda_done_BANG__A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__82, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_77; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_78)); return A_arbace_classes_interp__init_part1_A_const_77 }



























func A_arbace_classes_interp__init_part1_A_Unit145__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1369, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_79; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_classes_interp_fn__393000820_A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_classes_interp_fn__393000820_A_fn_class; if

	fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_439, false, nil); A_arbace_classes_interp_fn__393000820_A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); /*line :1369:1*/tmp1.BindRoot_O__V(lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp2))); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_79; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_80)); return A_arbace_classes_interp__init_part1_A_const_79 }



func A_arbace_classes_interp__init_part1_A_Unit146__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1373, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_81; var tmp2 *lang.Compiler_AOTFn; var fnbody__86 any = A_arbace_classes_interp_serial_lambda_BANG__A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_classes_interp_serial_lambda_BANG__A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_440, false, nil); A_arbace_classes_interp_serial_lambda_BANG__A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__86, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_81; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_82)); return A_arbace_classes_interp__init_part1_A_const_81 }






























func A_arbace_classes_interp__init_part1_A_Unit147__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1404, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part1_A_const_0.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part1_A_const_83; var tmp3 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_classes_interp_eval393000837_fn__393000838_A_New(); var tmp4 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_classes_interp_eval393000837_fn__393000838_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_441, false, nil); A_arbace_classes_interp_eval393000837_fn__393000838_A_fn_class = fncls__87d; tmp4 = fncls__87d } else { tmp4 = fncls__87 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }























func A_arbace_classes_interp__init_part1_A_Unit148__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1428, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_classes_interp__init_part1_A_const_0.GetRawRoot__O()); var tmp2 any = A_arbace_classes_interp__init_part1_A_const_84; var tmp3 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_classes_interp_eval393000849_fn__393000850_A_New(); var tmp4 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_classes_interp_eval393000849_fn__393000850_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_442, false, nil); A_arbace_classes_interp_eval393000849_fn__393000850_A_fn_class = fncls__89d; tmp4 = fncls__89d } else { tmp4 = fncls__89 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }



























































func A_arbace_classes_interp__init_part1_A_Unit149__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1488, 1); A_arbace_classes_interp__init_part1_A_const_85.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_85; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_86)); return A_arbace_classes_interp__init_part1_A_const_85.SetDynamic_Z__Var(true).Ref() }




func A_arbace_classes_interp__init_part1_A_Unit150__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1493, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_87; var tmp2 any; var root_91 any = A_arbace_classes_interp__init_part1_A_const_66.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_91, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_93 lang.IFn; if


	linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_92 == nil { tmp2 = ifn_93.Invoke_O__O(arg_94) } else { tmp2 = linked_92.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_91, arg_94) }; /*line :1493:1*/tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_classes_interp__init_part1_A_const_87; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_88)); return A_arbace_classes_interp__init_part1_A_const_87 }




func A_arbace_classes_interp__init_part1_A_Unit151__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1498, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_89; var tmp2 *lang.Compiler_AOTFn; var fnbody__96 any = A_arbace_classes_interp_sig_class_A_New(); var tmp3 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_classes_interp_sig_class_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_443, false, nil); A_arbace_classes_interp_sig_class_A_fn_class = fncls__95d; tmp3 = fncls__95d } else { tmp3 = fncls__95 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_89; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_90)); return A_arbace_classes_interp__init_part1_A_const_89 }













func A_arbace_classes_interp__init_part1_A_Unit152__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1512, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_91; var tmp2 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_classes_interp_meth_classes_A_New(); var tmp3 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_classes_interp_meth_classes_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_444, false, nil); A_arbace_classes_interp_meth_classes_A_fn_class = fncls__97d; tmp3 = fncls__97d } else { tmp3 = fncls__97 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_91; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_92)); return A_arbace_classes_interp__init_part1_A_const_91 }




func A_arbace_classes_interp__init_part1_A_Unit153__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1517, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_73; var tmp2 *lang.Compiler_AOTFn; var fnbody__100 any = A_arbace_classes_interp_publish_BANG__A_New(); var tmp3 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_classes_interp_publish_BANG__A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_445, false, nil); A_arbace_classes_interp_publish_BANG__A_fn_class = fncls__99d; tmp3 = fncls__99d } else { tmp3 = fncls__99 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_93)); return A_arbace_classes_interp__init_part1_A_const_73 }










func A_arbace_classes_interp__init_part1_A_Unit154__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1528, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_94; var tmp2 *lang.Compiler_AOTFn; var fnbody__102 any = A_arbace_classes_interp_republish_BANG__A_New(); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_classes_interp_republish_BANG__A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_446, false, nil); A_arbace_classes_interp_republish_BANG__A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_94; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_95)); return A_arbace_classes_interp__init_part1_A_const_94 }











func A_arbace_classes_interp__init_part1_A_Unit155__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1540, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_96; var tmp2 *lang.Compiler_AOTFn; var fnbody__104 any = A_arbace_classes_interp_dispatch_only_A_New(); var tmp3 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_classes_interp_dispatch_only_A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_447, false, nil); A_arbace_classes_interp_dispatch_only_A_fn_class = fncls__103d; tmp3 = fncls__103d } else { tmp3 = fncls__103 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__104, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_96; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_97)); return A_arbace_classes_interp__init_part1_A_const_96 }















func A_arbace_classes_interp__init_part1_A_Unit156__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1556, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_98; var tmp2 *lang.Compiler_AOTFn; var fnbody__106 any = A_arbace_classes_interp_implicit_params_BANG__A_New(); var tmp3 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_classes_interp_implicit_params_BANG__A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_448, false, nil); A_arbace_classes_interp_implicit_params_BANG__A_fn_class = fncls__105d; tmp3 = fncls__105d } else { tmp3 = fncls__105 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_98; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_99)); return A_arbace_classes_interp__init_part1_A_const_98 }


















func A_arbace_classes_interp__init_part1_A_Unit157__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1575, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_75; var tmp2 *lang.Compiler_AOTFn; var fnbody__108 any = A_arbace_classes_interp_publish_members_BANG__A_New(); var tmp3 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_classes_interp_publish_members_BANG__A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_449, false, nil); A_arbace_classes_interp_publish_members_BANG__A_fn_class = fncls__107d; tmp3 = fncls__107d } else { tmp3 = fncls__107 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__108, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_75; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_100)); return A_arbace_classes_interp__init_part1_A_const_75 }


































func A_arbace_classes_interp__init_part1_A_Unit158__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1610, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_101; var tmp2 *lang.Compiler_AOTFn; var fnbody__110 any = A_arbace_classes_interp_clinit_BANG__A_New(); var tmp3 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_classes_interp_clinit_BANG__A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_450, false, nil); A_arbace_classes_interp_clinit_BANG__A_fn_class = fncls__109d; tmp3 = fncls__109d } else { tmp3 = fncls__109 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__110, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_101; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_102)); return A_arbace_classes_interp__init_part1_A_const_101 }


























func A_arbace_classes_interp__init_part1_A_Unit159__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1637, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_103; var tmp2 *lang.Compiler_AOTFn; var fnbody__112 any = A_arbace_classes_interp_serial_new_BANG__A_New(); var tmp3 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_classes_interp_serial_new_BANG__A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_451, false, nil); A_arbace_classes_interp_serial_new_BANG__A_fn_class = fncls__111d; tmp3 = fncls__111d } else { tmp3 = fncls__111 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__112, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_103; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_104)); return A_arbace_classes_interp__init_part1_A_const_103 }















func A_arbace_classes_interp__init_part1_A_Unit160__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1653, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_105; var tmp2 *lang.Compiler_AOTFn; var fnbody__114 any = A_arbace_classes_interp_serial_uid_BANG__A_New(); var tmp3 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_classes_interp_serial_uid_BANG__A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_452, false, nil); A_arbace_classes_interp_serial_uid_BANG__A_fn_class = fncls__113d; tmp3 = fncls__113d } else { tmp3 = fncls__113 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__114, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_105; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_106)); return A_arbace_classes_interp__init_part1_A_const_105 }














func A_arbace_classes_interp__init_part1_A_Unit161__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1668, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_107; var tmp2 *lang.Compiler_AOTFn; var fnbody__116 any = A_arbace_classes_interp_define_BANG__A_New(); var tmp3 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_classes_interp_define_BANG__A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_453, false, nil); A_arbace_classes_interp_define_BANG__A_fn_class = fncls__115d; tmp3 = fncls__115d } else { tmp3 = fncls__115 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__116, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_107; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_108)); return A_arbace_classes_interp__init_part1_A_const_107 }




































































func A_arbace_classes_interp__init_part1_A_Unit162__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1737, 1); var tmp1 *lang.Var = A_arbace_classes_interp__init_part1_A_const_109; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__118 any = A_arbace_classes_interp_compile_and_load_BANG__A_New(); var tmp3 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_classes_interp_compile_and_load_BANG__A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_454, true, nil); A_arbace_classes_interp_compile_and_load_BANG__A_fn_class = fncls__117d; tmp3 = fncls__117d } else { tmp3 = fncls__117 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__118, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_interp__init_part1_A_const_109; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_interp__init_part1_A_const_110)); return A_arbace_classes_interp__init_part1_A_const_109 }






func A_arbace_classes_interp__init_part1_A_Unit163__O() any { A_arbace_classes_interp__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1744, 1); var tmp1 lang.Compiler_CF_Host_I; lang.Compiler_CF_Rt_Init(); tmp1 = lang.Compiler_CF_Rt_HOST; if lang.Util_Identical_O_O__Z_NoInit(tmp1, nil) { var temp__1927000414__auto____1 any; var tmp2 *lang.Compiler_AOTFn; var fnbody__120 any = A_arbace_classes_interp_eval393001123_fn__393001124_A_New(); var tmp3 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_classes_interp_eval393001123_fn__393001124_A_fn_class
								if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_455, false, nil); A_arbace_classes_interp_eval393001123_fn__393001124_A_fn_class = fncls__119d; tmp3 = fncls__119d } else { tmp3 = fncls__119 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__120, tmp3, nil); temp__1927000414__auto____1 = Up_Compiler_AOTFn_IFn(tmp2).Invoke__O(); if jrt.J2g_Truth(temp__1927000414__auto____1) { var c__2 any = temp__1927000414__auto____1
									lang.Compiler_CF_Rt_SetHost_Compiler_CF_Host__V(lang.Compiler_CF_Host_Cast(jrt.NN(jrt.Class_Cast(c__2)).NewInstance__O())); return nil } else {
//line :1745:1
			return nil } } else {
//line :1744:1
				return nil } }





type A_arbace_classes_interp__init_A struct{ jrt.Object }

func A_arbace_classes_interp__init_A_New() *A_arbace_classes_interp__init_A { t := &A_arbace_classes_interp__init_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_interp__init_A) Ctor() {}

func (t *A_arbace_classes_interp__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_interp__init_A) GetClass__Class() *jrt.Class { return A_arbace_classes_interp__init_A_class }

func (t *A_arbace_classes_interp__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_interp__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_interp__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_interp__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_interp__init_A); return ok }

func A_arbace_classes_interp__init_A_Cast(x any) *A_arbace_classes_interp__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_interp__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_interp__init_A_class)) }; return v }



type A_arbace_classes_interp__init_part0_A struct{ jrt.Object }

var A_arbace_classes_interp__init_part0_A_const_pool *jrt.RefArray

var A_arbace_classes_interp__init_part0_A_const_0 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_1 any

var A_arbace_classes_interp__init_part0_A_const_2 any

var A_arbace_classes_interp__init_part0_A_const_3 any

var A_arbace_classes_interp__init_part0_A_const_4 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_5 any

var A_arbace_classes_interp__init_part0_A_const_6 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_7 any

var A_arbace_classes_interp__init_part0_A_const_8 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_9 any

var A_arbace_classes_interp__init_part0_A_const_10 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_11 any

var A_arbace_classes_interp__init_part0_A_const_12 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_13 any

var A_arbace_classes_interp__init_part0_A_const_14 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_15 any

var A_arbace_classes_interp__init_part0_A_const_16 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_17 any

var A_arbace_classes_interp__init_part0_A_const_18 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_19 any

var A_arbace_classes_interp__init_part0_A_const_20 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_21 any

var A_arbace_classes_interp__init_part0_A_const_22 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_23 any

var A_arbace_classes_interp__init_part0_A_const_24 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_25 any

var A_arbace_classes_interp__init_part0_A_const_26 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_27 any

var A_arbace_classes_interp__init_part0_A_const_28 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_29 any

var A_arbace_classes_interp__init_part0_A_const_30 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_31 any

var A_arbace_classes_interp__init_part0_A_const_32 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_33 any

var A_arbace_classes_interp__init_part0_A_const_34 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_35 any

var A_arbace_classes_interp__init_part0_A_const_36 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_37 any

var A_arbace_classes_interp__init_part0_A_const_38 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_39 any

var A_arbace_classes_interp__init_part0_A_const_40 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_41 any

var A_arbace_classes_interp__init_part0_A_const_42 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_43 any

var A_arbace_classes_interp__init_part0_A_const_44 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_45 any

var A_arbace_classes_interp__init_part0_A_const_46 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_47 any

var A_arbace_classes_interp__init_part0_A_const_48 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_49 any

var A_arbace_classes_interp__init_part0_A_const_50 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_51 any

var A_arbace_classes_interp__init_part0_A_const_52 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_53 any

var A_arbace_classes_interp__init_part0_A_const_54 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_55 any

var A_arbace_classes_interp__init_part0_A_const_56 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_57 any

var A_arbace_classes_interp__init_part0_A_const_58 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_59 any

var A_arbace_classes_interp__init_part0_A_const_60 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_61 any

var A_arbace_classes_interp__init_part0_A_const_62 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_63 any

var A_arbace_classes_interp__init_part0_A_const_64 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_65 any

var A_arbace_classes_interp__init_part0_A_const_66 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_67 any

var A_arbace_classes_interp__init_part0_A_const_68 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_69 any

var A_arbace_classes_interp__init_part0_A_const_70 any

var A_arbace_classes_interp__init_part0_A_const_71 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_72 any

var A_arbace_classes_interp__init_part0_A_const_73 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_74 any

var A_arbace_classes_interp__init_part0_A_const_75 any

var A_arbace_classes_interp__init_part0_A_const_76 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_77 any

var A_arbace_classes_interp__init_part0_A_const_78 any

var A_arbace_classes_interp__init_part0_A_const_79 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_80 any

var A_arbace_classes_interp__init_part0_A_const_81 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_82 any

var A_arbace_classes_interp__init_part0_A_const_83 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_84 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_85 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_86 any

var A_arbace_classes_interp__init_part0_A_const_87 any

var A_arbace_classes_interp__init_part0_A_const_88 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_89 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_90 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_91 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_92 any

var A_arbace_classes_interp__init_part0_A_const_93 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_94 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_95 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_96 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_97 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_98 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_99 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_100 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_101 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_102 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_103 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_104 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_105 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_106 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_107 any

var A_arbace_classes_interp__init_part0_A_const_108 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_109 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_110 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_111 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_112 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_113 any

var A_arbace_classes_interp__init_part0_A_const_114 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_115 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_116 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_117 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_118 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_119 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_120 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_121 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_122 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_123 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_124 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_125 any

var A_arbace_classes_interp__init_part0_A_const_126 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_127 any

var A_arbace_classes_interp__init_part0_A_const_128 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_129 any

var A_arbace_classes_interp__init_part0_A_const_130 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_131 any

var A_arbace_classes_interp__init_part0_A_const_132 any

var A_arbace_classes_interp__init_part0_A_const_133 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_134 any

var A_arbace_classes_interp__init_part0_A_const_135 any

var A_arbace_classes_interp__init_part0_A_const_136 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_137 any

var A_arbace_classes_interp__init_part0_A_const_138 any

var A_arbace_classes_interp__init_part0_A_const_139 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_140 any

var A_arbace_classes_interp__init_part0_A_const_141 any

var A_arbace_classes_interp__init_part0_A_const_142 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_143 any

var A_arbace_classes_interp__init_part0_A_const_144 any

var A_arbace_classes_interp__init_part0_A_const_145 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_146 any

var A_arbace_classes_interp__init_part0_A_const_147 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_148 any

var A_arbace_classes_interp__init_part0_A_const_149 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_150 any

var A_arbace_classes_interp__init_part0_A_const_151 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_152 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_153 any

var A_arbace_classes_interp__init_part0_A_const_154 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_155 any

var A_arbace_classes_interp__init_part0_A_const_156 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_157 any

var A_arbace_classes_interp__init_part0_A_const_158 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_159 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_160 any

var A_arbace_classes_interp__init_part0_A_const_161 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_162 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_163 *lang.Var

var A_arbace_classes_interp__init_part0_A_const_164 any

var A_arbace_classes_interp__init_part0_A_const_165 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_const_166 *lang.Keyword

var A_arbace_classes_interp__init_part0_A_init jrt.ClassInit

func A_arbace_classes_interp__init_part0_A_Init() { if !A_arbace_classes_interp__init_part0_A_init.Done() { A_arbace_classes_interp__init_part0_A_init.Run(A_arbace_classes_interp__init_part0_A_clinit) } }

func A_arbace_classes_interp__init_part0_A_clinit() { A_arbace_classes_interp__init_part0_A_clinit_p0(); A_arbace_classes_interp__init_part0_A_clinit_p1(); A_arbace_classes_interp__init_part0_A_clinit_p2(); A_arbace_classes_interp__init_part0_A_clinit_p3(); A_arbace_classes_interp__init_part0_A_clinit_p4(); A_arbace_classes_interp__init_part0_A_clinit_p5(); A_arbace_classes_interp__init_part0_A_clinit_p6(); A_arbace_classes_interp__init_part0_A_clinit_p7(); A_arbace_classes_interp__init_part0_A_clinit_p8(); A_arbace_classes_interp__init_part0_A_clinit_p9(); A_arbace_classes_interp__init_part0_A_clinit_p10(); A_arbace_classes_interp__init_part0_A_clinit_p11(); A_arbace_classes_interp__init_part0_A_clinit_p12() }

func A_arbace_classes_interp__init_part0_A_clinit_p0() { jrt.StartCheck(); A_arbace_classes_interp__init_part0_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_307, 274); A_arbace_classes_interp__init_part0_A_const_0 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[107]); A_arbace_classes_interp__init_part0_A_const_1 = A_arbace_classes_interp__init_part0_A_const_pool.A[108]; A_arbace_classes_interp__init_part0_A_const_2 = A_arbace_classes_interp__init_part0_A_const_pool.A[109]; A_arbace_classes_interp__init_part0_A_const_3 = A_arbace_classes_interp__init_part0_A_const_pool.A[110]; A_arbace_classes_interp__init_part0_A_const_4 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[111]); A_arbace_classes_interp__init_part0_A_const_5 = A_arbace_classes_interp__init_part0_A_const_pool.A[112]; A_arbace_classes_interp__init_part0_A_const_6 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[113]); A_arbace_classes_interp__init_part0_A_const_7 = A_arbace_classes_interp__init_part0_A_const_pool.A[114]; A_arbace_classes_interp__init_part0_A_const_8 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[115]); A_arbace_classes_interp__init_part0_A_const_9 = A_arbace_classes_interp__init_part0_A_const_pool.A[116]; A_arbace_classes_interp__init_part0_A_const_10 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[117]); A_arbace_classes_interp__init_part0_A_const_11 = A_arbace_classes_interp__init_part0_A_const_pool.A[118]; A_arbace_classes_interp__init_part0_A_const_12 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[119]) }

func A_arbace_classes_interp__init_part0_A_clinit_p1() { A_arbace_classes_interp__init_part0_A_const_13 = A_arbace_classes_interp__init_part0_A_const_pool.A[120]; A_arbace_classes_interp__init_part0_A_const_14 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[121]); A_arbace_classes_interp__init_part0_A_const_15 = A_arbace_classes_interp__init_part0_A_const_pool.A[122]; A_arbace_classes_interp__init_part0_A_const_16 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[123]); A_arbace_classes_interp__init_part0_A_const_17 = A_arbace_classes_interp__init_part0_A_const_pool.A[124]; A_arbace_classes_interp__init_part0_A_const_18 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[125]); A_arbace_classes_interp__init_part0_A_const_19 = A_arbace_classes_interp__init_part0_A_const_pool.A[126]; A_arbace_classes_interp__init_part0_A_const_20 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[127]); A_arbace_classes_interp__init_part0_A_const_21 = A_arbace_classes_interp__init_part0_A_const_pool.A[128]; A_arbace_classes_interp__init_part0_A_const_22 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[129]); A_arbace_classes_interp__init_part0_A_const_23 = A_arbace_classes_interp__init_part0_A_const_pool.A[130]; A_arbace_classes_interp__init_part0_A_const_24 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[131]); A_arbace_classes_interp__init_part0_A_const_25 = A_arbace_classes_interp__init_part0_A_const_pool.A[132] }

func A_arbace_classes_interp__init_part0_A_clinit_p2() { A_arbace_classes_interp__init_part0_A_const_26 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[133]); A_arbace_classes_interp__init_part0_A_const_27 = A_arbace_classes_interp__init_part0_A_const_pool.A[134]; A_arbace_classes_interp__init_part0_A_const_28 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[135]); A_arbace_classes_interp__init_part0_A_const_29 = A_arbace_classes_interp__init_part0_A_const_pool.A[136]; A_arbace_classes_interp__init_part0_A_const_30 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[137]); A_arbace_classes_interp__init_part0_A_const_31 = A_arbace_classes_interp__init_part0_A_const_pool.A[138]; A_arbace_classes_interp__init_part0_A_const_32 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[139]); A_arbace_classes_interp__init_part0_A_const_33 = A_arbace_classes_interp__init_part0_A_const_pool.A[140]; A_arbace_classes_interp__init_part0_A_const_34 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[141]); A_arbace_classes_interp__init_part0_A_const_35 = A_arbace_classes_interp__init_part0_A_const_pool.A[142]; A_arbace_classes_interp__init_part0_A_const_36 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[143]); A_arbace_classes_interp__init_part0_A_const_37 = A_arbace_classes_interp__init_part0_A_const_pool.A[144]; A_arbace_classes_interp__init_part0_A_const_38 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[145]) }

func A_arbace_classes_interp__init_part0_A_clinit_p3() { A_arbace_classes_interp__init_part0_A_const_39 = A_arbace_classes_interp__init_part0_A_const_pool.A[146]; A_arbace_classes_interp__init_part0_A_const_40 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[147]); A_arbace_classes_interp__init_part0_A_const_41 = A_arbace_classes_interp__init_part0_A_const_pool.A[148]; A_arbace_classes_interp__init_part0_A_const_42 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[149]); A_arbace_classes_interp__init_part0_A_const_43 = A_arbace_classes_interp__init_part0_A_const_pool.A[150]; A_arbace_classes_interp__init_part0_A_const_44 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[151]); A_arbace_classes_interp__init_part0_A_const_45 = A_arbace_classes_interp__init_part0_A_const_pool.A[152]; A_arbace_classes_interp__init_part0_A_const_46 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[153]); A_arbace_classes_interp__init_part0_A_const_47 = A_arbace_classes_interp__init_part0_A_const_pool.A[154]; A_arbace_classes_interp__init_part0_A_const_48 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[155]); A_arbace_classes_interp__init_part0_A_const_49 = A_arbace_classes_interp__init_part0_A_const_pool.A[156]; A_arbace_classes_interp__init_part0_A_const_50 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[157]); A_arbace_classes_interp__init_part0_A_const_51 = A_arbace_classes_interp__init_part0_A_const_pool.A[158] }

func A_arbace_classes_interp__init_part0_A_clinit_p4() { A_arbace_classes_interp__init_part0_A_const_52 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[159]); A_arbace_classes_interp__init_part0_A_const_53 = A_arbace_classes_interp__init_part0_A_const_pool.A[160]; A_arbace_classes_interp__init_part0_A_const_54 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[161]); A_arbace_classes_interp__init_part0_A_const_55 = A_arbace_classes_interp__init_part0_A_const_pool.A[162]; A_arbace_classes_interp__init_part0_A_const_56 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[163]); A_arbace_classes_interp__init_part0_A_const_57 = A_arbace_classes_interp__init_part0_A_const_pool.A[164]; A_arbace_classes_interp__init_part0_A_const_58 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[165]); A_arbace_classes_interp__init_part0_A_const_59 = A_arbace_classes_interp__init_part0_A_const_pool.A[166]; A_arbace_classes_interp__init_part0_A_const_60 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[167]); A_arbace_classes_interp__init_part0_A_const_61 = A_arbace_classes_interp__init_part0_A_const_pool.A[168]; A_arbace_classes_interp__init_part0_A_const_62 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[169]); A_arbace_classes_interp__init_part0_A_const_63 = A_arbace_classes_interp__init_part0_A_const_pool.A[170]; A_arbace_classes_interp__init_part0_A_const_64 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[171]) }

func A_arbace_classes_interp__init_part0_A_clinit_p5() { A_arbace_classes_interp__init_part0_A_const_65 = A_arbace_classes_interp__init_part0_A_const_pool.A[172]; A_arbace_classes_interp__init_part0_A_const_66 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[173]); A_arbace_classes_interp__init_part0_A_const_67 = A_arbace_classes_interp__init_part0_A_const_pool.A[174]; A_arbace_classes_interp__init_part0_A_const_68 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[175]); A_arbace_classes_interp__init_part0_A_const_69 = A_arbace_classes_interp__init_part0_A_const_pool.A[176]; A_arbace_classes_interp__init_part0_A_const_70 = A_arbace_classes_interp__init_part0_A_const_pool.A[177]; A_arbace_classes_interp__init_part0_A_const_71 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[178]); A_arbace_classes_interp__init_part0_A_const_72 = A_arbace_classes_interp__init_part0_A_const_pool.A[179]; A_arbace_classes_interp__init_part0_A_const_73 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[180]); A_arbace_classes_interp__init_part0_A_const_74 = A_arbace_classes_interp__init_part0_A_const_pool.A[181]; A_arbace_classes_interp__init_part0_A_const_75 = A_arbace_classes_interp__init_part0_A_const_pool.A[182]; A_arbace_classes_interp__init_part0_A_const_76 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[183]); A_arbace_classes_interp__init_part0_A_const_77 = A_arbace_classes_interp__init_part0_A_const_pool.A[184]; A_arbace_classes_interp__init_part0_A_const_78 = A_arbace_classes_interp__init_part0_A_const_pool.A[185] }

func A_arbace_classes_interp__init_part0_A_clinit_p6() { A_arbace_classes_interp__init_part0_A_const_79 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[186]); A_arbace_classes_interp__init_part0_A_const_80 = A_arbace_classes_interp__init_part0_A_const_pool.A[187]; A_arbace_classes_interp__init_part0_A_const_81 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[188]); A_arbace_classes_interp__init_part0_A_const_82 = A_arbace_classes_interp__init_part0_A_const_pool.A[189]; A_arbace_classes_interp__init_part0_A_const_83 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[190]); A_arbace_classes_interp__init_part0_A_const_84 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[191]); A_arbace_classes_interp__init_part0_A_const_85 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[192]); A_arbace_classes_interp__init_part0_A_const_86 = A_arbace_classes_interp__init_part0_A_const_pool.A[193]; A_arbace_classes_interp__init_part0_A_const_87 = A_arbace_classes_interp__init_part0_A_const_pool.A[194]; A_arbace_classes_interp__init_part0_A_const_88 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[195]); A_arbace_classes_interp__init_part0_A_const_89 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[196]); A_arbace_classes_interp__init_part0_A_const_90 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[197]); A_arbace_classes_interp__init_part0_A_const_91 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[198]) }

func A_arbace_classes_interp__init_part0_A_clinit_p7() { A_arbace_classes_interp__init_part0_A_const_92 = A_arbace_classes_interp__init_part0_A_const_pool.A[199]; A_arbace_classes_interp__init_part0_A_const_93 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[200]); A_arbace_classes_interp__init_part0_A_const_94 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[201]); A_arbace_classes_interp__init_part0_A_const_95 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[202]); A_arbace_classes_interp__init_part0_A_const_96 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[203]); A_arbace_classes_interp__init_part0_A_const_97 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[204]); A_arbace_classes_interp__init_part0_A_const_98 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[205]); A_arbace_classes_interp__init_part0_A_const_99 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[206]); A_arbace_classes_interp__init_part0_A_const_100 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[207]); A_arbace_classes_interp__init_part0_A_const_101 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[208]); A_arbace_classes_interp__init_part0_A_const_102 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[209]); A_arbace_classes_interp__init_part0_A_const_103 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[210]) }

func A_arbace_classes_interp__init_part0_A_clinit_p8() { A_arbace_classes_interp__init_part0_A_const_104 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[211]); A_arbace_classes_interp__init_part0_A_const_105 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[212]); A_arbace_classes_interp__init_part0_A_const_106 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[213]); A_arbace_classes_interp__init_part0_A_const_107 = A_arbace_classes_interp__init_part0_A_const_pool.A[214]; A_arbace_classes_interp__init_part0_A_const_108 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[215]); A_arbace_classes_interp__init_part0_A_const_109 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[216]); A_arbace_classes_interp__init_part0_A_const_110 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[217]); A_arbace_classes_interp__init_part0_A_const_111 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[218]); A_arbace_classes_interp__init_part0_A_const_112 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[219]); A_arbace_classes_interp__init_part0_A_const_113 = A_arbace_classes_interp__init_part0_A_const_pool.A[220]; A_arbace_classes_interp__init_part0_A_const_114 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[221]); A_arbace_classes_interp__init_part0_A_const_115 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[222]) }

func A_arbace_classes_interp__init_part0_A_clinit_p9() { A_arbace_classes_interp__init_part0_A_const_116 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[223]); A_arbace_classes_interp__init_part0_A_const_117 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[224]); A_arbace_classes_interp__init_part0_A_const_118 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[225]); A_arbace_classes_interp__init_part0_A_const_119 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[226]); A_arbace_classes_interp__init_part0_A_const_120 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[227]); A_arbace_classes_interp__init_part0_A_const_121 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[228]); A_arbace_classes_interp__init_part0_A_const_122 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[229]); A_arbace_classes_interp__init_part0_A_const_123 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[230]); A_arbace_classes_interp__init_part0_A_const_124 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[231]); A_arbace_classes_interp__init_part0_A_const_125 = A_arbace_classes_interp__init_part0_A_const_pool.A[232]; A_arbace_classes_interp__init_part0_A_const_126 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[233]); A_arbace_classes_interp__init_part0_A_const_127 = A_arbace_classes_interp__init_part0_A_const_pool.A[234] }

func A_arbace_classes_interp__init_part0_A_clinit_p10() { A_arbace_classes_interp__init_part0_A_const_128 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[235]); A_arbace_classes_interp__init_part0_A_const_129 = A_arbace_classes_interp__init_part0_A_const_pool.A[236]; A_arbace_classes_interp__init_part0_A_const_130 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[237]); A_arbace_classes_interp__init_part0_A_const_131 = A_arbace_classes_interp__init_part0_A_const_pool.A[238]; A_arbace_classes_interp__init_part0_A_const_132 = A_arbace_classes_interp__init_part0_A_const_pool.A[239]; A_arbace_classes_interp__init_part0_A_const_133 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[240]); A_arbace_classes_interp__init_part0_A_const_134 = A_arbace_classes_interp__init_part0_A_const_pool.A[241]; A_arbace_classes_interp__init_part0_A_const_135 = A_arbace_classes_interp__init_part0_A_const_pool.A[242]; A_arbace_classes_interp__init_part0_A_const_136 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[243]); A_arbace_classes_interp__init_part0_A_const_137 = A_arbace_classes_interp__init_part0_A_const_pool.A[244]; A_arbace_classes_interp__init_part0_A_const_138 = A_arbace_classes_interp__init_part0_A_const_pool.A[245]; A_arbace_classes_interp__init_part0_A_const_139 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[246]); A_arbace_classes_interp__init_part0_A_const_140 = A_arbace_classes_interp__init_part0_A_const_pool.A[247]; A_arbace_classes_interp__init_part0_A_const_141 = A_arbace_classes_interp__init_part0_A_const_pool.A[248] }

func A_arbace_classes_interp__init_part0_A_clinit_p11() { A_arbace_classes_interp__init_part0_A_const_142 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[249]); A_arbace_classes_interp__init_part0_A_const_143 = A_arbace_classes_interp__init_part0_A_const_pool.A[250]; A_arbace_classes_interp__init_part0_A_const_144 = A_arbace_classes_interp__init_part0_A_const_pool.A[251]; A_arbace_classes_interp__init_part0_A_const_145 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[252]); A_arbace_classes_interp__init_part0_A_const_146 = A_arbace_classes_interp__init_part0_A_const_pool.A[253]; A_arbace_classes_interp__init_part0_A_const_147 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[254]); A_arbace_classes_interp__init_part0_A_const_148 = A_arbace_classes_interp__init_part0_A_const_pool.A[255]; A_arbace_classes_interp__init_part0_A_const_149 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[256]); A_arbace_classes_interp__init_part0_A_const_150 = A_arbace_classes_interp__init_part0_A_const_pool.A[257]; A_arbace_classes_interp__init_part0_A_const_151 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[258]); A_arbace_classes_interp__init_part0_A_const_152 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[259]); A_arbace_classes_interp__init_part0_A_const_153 = A_arbace_classes_interp__init_part0_A_const_pool.A[260]; A_arbace_classes_interp__init_part0_A_const_154 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[261]) }

func A_arbace_classes_interp__init_part0_A_clinit_p12() { A_arbace_classes_interp__init_part0_A_const_155 = A_arbace_classes_interp__init_part0_A_const_pool.A[262]; A_arbace_classes_interp__init_part0_A_const_156 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[263]); A_arbace_classes_interp__init_part0_A_const_157 = A_arbace_classes_interp__init_part0_A_const_pool.A[264]; A_arbace_classes_interp__init_part0_A_const_158 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[265]); A_arbace_classes_interp__init_part0_A_const_159 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[266]); A_arbace_classes_interp__init_part0_A_const_160 = A_arbace_classes_interp__init_part0_A_const_pool.A[267]; A_arbace_classes_interp__init_part0_A_const_161 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[268]); A_arbace_classes_interp__init_part0_A_const_162 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[269]); A_arbace_classes_interp__init_part0_A_const_163 = lang.Var_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[270]); A_arbace_classes_interp__init_part0_A_const_164 = A_arbace_classes_interp__init_part0_A_const_pool.A[271]; A_arbace_classes_interp__init_part0_A_const_165 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[272]); A_arbace_classes_interp__init_part0_A_const_166 = lang.Keyword_Cast(A_arbace_classes_interp__init_part0_A_const_pool.A[273]) }

func A_arbace_classes_interp__init_part0_A_New() *A_arbace_classes_interp__init_part0_A { A_arbace_classes_interp__init_part0_A_Init(); t := &A_arbace_classes_interp__init_part0_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_interp__init_part0_A) Ctor() {}

func (t *A_arbace_classes_interp__init_part0_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_interp__init_part0_A) GetClass__Class() *jrt.Class { return A_arbace_classes_interp__init_part0_A_class }

func (t *A_arbace_classes_interp__init_part0_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_interp__init_part0_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_interp__init_part0_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_interp__init_part0_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_interp__init_part0_A); return ok }

func A_arbace_classes_interp__init_part0_A_Cast(x any) *A_arbace_classes_interp__init_part0_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_interp__init_part0_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_interp__init_part0_A_class)) }; return v }



type A_arbace_classes_interp__init_part1_A struct{ jrt.Object }

var A_arbace_classes_interp__init_part1_A_const_pool *jrt.RefArray

var A_arbace_classes_interp__init_part1_A_const_0 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_1 *lang.Keyword

var A_arbace_classes_interp__init_part1_A_const_2 *lang.Keyword

var A_arbace_classes_interp__init_part1_A_const_3 *lang.Keyword

var A_arbace_classes_interp__init_part1_A_const_4 *lang.Keyword

var A_arbace_classes_interp__init_part1_A_const_5 *lang.Keyword

var A_arbace_classes_interp__init_part1_A_const_6 *lang.Keyword

var A_arbace_classes_interp__init_part1_A_const_7 *lang.Keyword

var A_arbace_classes_interp__init_part1_A_const_8 *lang.Keyword

var A_arbace_classes_interp__init_part1_A_const_9 *lang.Keyword

var A_arbace_classes_interp__init_part1_A_const_10 *lang.Keyword

var A_arbace_classes_interp__init_part1_A_const_11 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_12 any

var A_arbace_classes_interp__init_part1_A_const_13 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_14 any

var A_arbace_classes_interp__init_part1_A_const_15 *lang.Keyword

var A_arbace_classes_interp__init_part1_A_const_16 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_17 any

var A_arbace_classes_interp__init_part1_A_const_18 *lang.Keyword

var A_arbace_classes_interp__init_part1_A_const_19 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_20 any

var A_arbace_classes_interp__init_part1_A_const_21 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_22 any

var A_arbace_classes_interp__init_part1_A_const_23 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_24 any

var A_arbace_classes_interp__init_part1_A_const_25 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_26 any

var A_arbace_classes_interp__init_part1_A_const_27 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_28 any

var A_arbace_classes_interp__init_part1_A_const_29 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_30 any

var A_arbace_classes_interp__init_part1_A_const_31 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_32 any

var A_arbace_classes_interp__init_part1_A_const_33 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_34 any

var A_arbace_classes_interp__init_part1_A_const_35 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_36 any

var A_arbace_classes_interp__init_part1_A_const_37 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_38 any

var A_arbace_classes_interp__init_part1_A_const_39 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_40 any

var A_arbace_classes_interp__init_part1_A_const_41 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_42 any

var A_arbace_classes_interp__init_part1_A_const_43 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_44 any

var A_arbace_classes_interp__init_part1_A_const_45 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_46 any

var A_arbace_classes_interp__init_part1_A_const_47 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_48 any

var A_arbace_classes_interp__init_part1_A_const_49 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_50 any

var A_arbace_classes_interp__init_part1_A_const_51 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_52 any

var A_arbace_classes_interp__init_part1_A_const_53 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_54 any

var A_arbace_classes_interp__init_part1_A_const_55 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_56 any

var A_arbace_classes_interp__init_part1_A_const_57 any

var A_arbace_classes_interp__init_part1_A_const_58 *lang.Keyword

var A_arbace_classes_interp__init_part1_A_const_59 any

var A_arbace_classes_interp__init_part1_A_const_60 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_61 any

var A_arbace_classes_interp__init_part1_A_const_62 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_63 any

var A_arbace_classes_interp__init_part1_A_const_64 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_65 any

var A_arbace_classes_interp__init_part1_A_const_66 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_67 any

var A_arbace_classes_interp__init_part1_A_const_68 any

var A_arbace_classes_interp__init_part1_A_const_69 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_70 any

var A_arbace_classes_interp__init_part1_A_const_71 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_72 any

var A_arbace_classes_interp__init_part1_A_const_73 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_74 any

var A_arbace_classes_interp__init_part1_A_const_75 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_76 any

var A_arbace_classes_interp__init_part1_A_const_77 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_78 any

var A_arbace_classes_interp__init_part1_A_const_79 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_80 any

var A_arbace_classes_interp__init_part1_A_const_81 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_82 any

var A_arbace_classes_interp__init_part1_A_const_83 *lang.Keyword

var A_arbace_classes_interp__init_part1_A_const_84 *lang.Keyword

var A_arbace_classes_interp__init_part1_A_const_85 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_86 any

var A_arbace_classes_interp__init_part1_A_const_87 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_88 any

var A_arbace_classes_interp__init_part1_A_const_89 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_90 any

var A_arbace_classes_interp__init_part1_A_const_91 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_92 any

var A_arbace_classes_interp__init_part1_A_const_93 any

var A_arbace_classes_interp__init_part1_A_const_94 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_95 any

var A_arbace_classes_interp__init_part1_A_const_96 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_97 any

var A_arbace_classes_interp__init_part1_A_const_98 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_99 any

var A_arbace_classes_interp__init_part1_A_const_100 any

var A_arbace_classes_interp__init_part1_A_const_101 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_102 any

var A_arbace_classes_interp__init_part1_A_const_103 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_104 any

var A_arbace_classes_interp__init_part1_A_const_105 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_106 any

var A_arbace_classes_interp__init_part1_A_const_107 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_108 any

var A_arbace_classes_interp__init_part1_A_const_109 *lang.Var

var A_arbace_classes_interp__init_part1_A_const_110 any

var A_arbace_classes_interp__init_part1_A_init jrt.ClassInit

func A_arbace_classes_interp__init_part1_A_Init() { if !A_arbace_classes_interp__init_part1_A_init.Done() { A_arbace_classes_interp__init_part1_A_init.Run(A_arbace_classes_interp__init_part1_A_clinit) } }

func A_arbace_classes_interp__init_part1_A_clinit() { A_arbace_classes_interp__init_part1_A_clinit_p0(); A_arbace_classes_interp__init_part1_A_clinit_p1() }

func A_arbace_classes_interp__init_part1_A_clinit_p0() { jrt.StartCheck(); A_arbace_classes_interp__init_part1_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_399, 171) }

func A_arbace_classes_interp__init_part1_A_clinit_p1() { var tmp1 *lang.Var; A_arbace_classes_interp__init_part0_A_Init(); tmp1 = A_arbace_classes_interp__init_part0_A_const_81; A_arbace_classes_interp__init_part1_A_const_0 = tmp1; A_arbace_classes_interp__init_part1_A_const_1 = lang.Keyword_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[62]); A_arbace_classes_interp__init_part1_A_const_2 = lang.Keyword_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[63]); A_arbace_classes_interp__init_part1_A_const_3 = lang.Keyword_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[64]); A_arbace_classes_interp__init_part1_A_const_4 = lang.Keyword_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[65]); A_arbace_classes_interp__init_part1_A_const_5 = lang.Keyword_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[66]); A_arbace_classes_interp__init_part1_A_const_6 = lang.Keyword_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[67]); A_arbace_classes_interp__init_part1_A_const_7 = lang.Keyword_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[68]); A_arbace_classes_interp__init_part1_A_const_8 = lang.Keyword_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[69]); A_arbace_classes_interp__init_part1_A_const_9 = lang.Keyword_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[70]); A_arbace_classes_interp__init_part1_A_const_10 = lang.Keyword_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[71]); A_arbace_classes_interp__init_part1_A_const_11 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[72]); A_arbace_classes_interp__init_part1_A_const_12 = A_arbace_classes_interp__init_part1_A_const_pool.A[73]; A_arbace_classes_interp__init_part1_A_const_13 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[74]); A_arbace_classes_interp__init_part1_A_const_14 = A_arbace_classes_interp__init_part1_A_const_pool.A[75]; A_arbace_classes_interp__init_part1_A_const_15 = lang.Keyword_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[76]); A_arbace_classes_interp__init_part1_A_const_16 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[77]); A_arbace_classes_interp__init_part1_A_const_17 = A_arbace_classes_interp__init_part1_A_const_pool.A[78]; A_arbace_classes_interp__init_part1_A_const_18 = lang.Keyword_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[79]); A_arbace_classes_interp__init_part1_A_const_19 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[80]); A_arbace_classes_interp__init_part1_A_const_20 = A_arbace_classes_interp__init_part1_A_const_pool.A[81]; A_arbace_classes_interp__init_part1_A_const_21 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[82]); A_arbace_classes_interp__init_part1_A_const_22 = A_arbace_classes_interp__init_part1_A_const_pool.A[83]; A_arbace_classes_interp__init_part1_A_const_23 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[84]); A_arbace_classes_interp__init_part1_A_const_24 = A_arbace_classes_interp__init_part1_A_const_pool.A[85]; A_arbace_classes_interp__init_part1_A_const_25 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[86]); A_arbace_classes_interp__init_part1_A_const_26 = A_arbace_classes_interp__init_part1_A_const_pool.A[87]; A_arbace_classes_interp__init_part1_A_const_27 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[88]); A_arbace_classes_interp__init_part1_A_const_28 = A_arbace_classes_interp__init_part1_A_const_pool.A[89]; A_arbace_classes_interp__init_part1_A_const_29 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[90]); A_arbace_classes_interp__init_part1_A_const_30 = A_arbace_classes_interp__init_part1_A_const_pool.A[91]; A_arbace_classes_interp__init_part1_A_const_31 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[92]); A_arbace_classes_interp__init_part1_A_const_32 = A_arbace_classes_interp__init_part1_A_const_pool.A[93]; A_arbace_classes_interp__init_part1_A_const_33 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[94]); A_arbace_classes_interp__init_part1_A_const_34 = A_arbace_classes_interp__init_part1_A_const_pool.A[95]; A_arbace_classes_interp__init_part1_A_const_35 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[96]); A_arbace_classes_interp__init_part1_A_const_36 = A_arbace_classes_interp__init_part1_A_const_pool.A[97]; A_arbace_classes_interp__init_part1_A_const_37 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[98]); A_arbace_classes_interp__init_part1_A_const_38 = A_arbace_classes_interp__init_part1_A_const_pool.A[99]; A_arbace_classes_interp__init_part1_A_const_39 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[100]); A_arbace_classes_interp__init_part1_A_const_40 = A_arbace_classes_interp__init_part1_A_const_pool.A[101]; A_arbace_classes_interp__init_part1_A_const_41 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[102]); A_arbace_classes_interp__init_part1_A_const_42 = A_arbace_classes_interp__init_part1_A_const_pool.A[103]; A_arbace_classes_interp__init_part1_A_const_43 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[104]); A_arbace_classes_interp__init_part1_A_const_44 = A_arbace_classes_interp__init_part1_A_const_pool.A[105]; A_arbace_classes_interp__init_part1_A_const_45 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[106]); A_arbace_classes_interp__init_part1_A_const_46 = A_arbace_classes_interp__init_part1_A_const_pool.A[107]; A_arbace_classes_interp__init_part1_A_const_47 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[108]); A_arbace_classes_interp__init_part1_A_const_48 = A_arbace_classes_interp__init_part1_A_const_pool.A[109]; A_arbace_classes_interp__init_part1_A_const_49 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[110]); A_arbace_classes_interp__init_part1_A_const_50 = A_arbace_classes_interp__init_part1_A_const_pool.A[111]; A_arbace_classes_interp__init_part1_A_const_51 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[112]); A_arbace_classes_interp__init_part1_A_const_52 = A_arbace_classes_interp__init_part1_A_const_pool.A[113]; A_arbace_classes_interp__init_part1_A_const_53 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[114]); A_arbace_classes_interp__init_part1_A_const_54 = A_arbace_classes_interp__init_part1_A_const_pool.A[115]; A_arbace_classes_interp__init_part1_A_const_55 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[116]); A_arbace_classes_interp__init_part1_A_const_56 = A_arbace_classes_interp__init_part1_A_const_pool.A[117]; A_arbace_classes_interp__init_part1_A_const_57 = A_arbace_classes_interp__init_part1_A_const_pool.A[118]; A_arbace_classes_interp__init_part1_A_const_58 = lang.Keyword_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[119]); A_arbace_classes_interp__init_part1_A_const_59 = A_arbace_classes_interp__init_part1_A_const_pool.A[120]; A_arbace_classes_interp__init_part1_A_const_60 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[121]); A_arbace_classes_interp__init_part1_A_const_61 = A_arbace_classes_interp__init_part1_A_const_pool.A[122]; A_arbace_classes_interp__init_part1_A_const_62 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[123]); A_arbace_classes_interp__init_part1_A_const_63 = A_arbace_classes_interp__init_part1_A_const_pool.A[124]; A_arbace_classes_interp__init_part1_A_const_64 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[125]); A_arbace_classes_interp__init_part1_A_const_65 = A_arbace_classes_interp__init_part1_A_const_pool.A[126]; var tmp2 *lang.Var; A_arbace_classes_interp__init_part0_A_Init(); tmp2 = A_arbace_classes_interp__init_part0_A_const_6; A_arbace_classes_interp__init_part1_A_const_66 = tmp2; A_arbace_classes_interp__init_part1_A_const_67 = A_arbace_classes_interp__init_part1_A_const_pool.A[127]; A_arbace_classes_interp__init_part1_A_const_68 = A_arbace_classes_interp__init_part1_A_const_pool.A[128]; A_arbace_classes_interp__init_part1_A_const_69 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[129]); A_arbace_classes_interp__init_part1_A_const_70 = A_arbace_classes_interp__init_part1_A_const_pool.A[130]; A_arbace_classes_interp__init_part1_A_const_71 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[131]); A_arbace_classes_interp__init_part1_A_const_72 = A_arbace_classes_interp__init_part1_A_const_pool.A[132]; A_arbace_classes_interp__init_part1_A_const_73 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[133]); A_arbace_classes_interp__init_part1_A_const_74 = A_arbace_classes_interp__init_part1_A_const_pool.A[134]; A_arbace_classes_interp__init_part1_A_const_75 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[135]); A_arbace_classes_interp__init_part1_A_const_76 = A_arbace_classes_interp__init_part1_A_const_pool.A[136]; A_arbace_classes_interp__init_part1_A_const_77 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[137]); A_arbace_classes_interp__init_part1_A_const_78 = A_arbace_classes_interp__init_part1_A_const_pool.A[138]; A_arbace_classes_interp__init_part1_A_const_79 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[139]); A_arbace_classes_interp__init_part1_A_const_80 = A_arbace_classes_interp__init_part1_A_const_pool.A[140]; A_arbace_classes_interp__init_part1_A_const_81 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[141]); A_arbace_classes_interp__init_part1_A_const_82 = A_arbace_classes_interp__init_part1_A_const_pool.A[142]; A_arbace_classes_interp__init_part1_A_const_83 = lang.Keyword_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[143]); A_arbace_classes_interp__init_part1_A_const_84 = lang.Keyword_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[144]); A_arbace_classes_interp__init_part1_A_const_85 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[145]); A_arbace_classes_interp__init_part1_A_const_86 = A_arbace_classes_interp__init_part1_A_const_pool.A[146]; A_arbace_classes_interp__init_part1_A_const_87 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[147]); A_arbace_classes_interp__init_part1_A_const_88 = A_arbace_classes_interp__init_part1_A_const_pool.A[148]; A_arbace_classes_interp__init_part1_A_const_89 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[149]); A_arbace_classes_interp__init_part1_A_const_90 = A_arbace_classes_interp__init_part1_A_const_pool.A[150]; A_arbace_classes_interp__init_part1_A_const_91 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[151]); A_arbace_classes_interp__init_part1_A_const_92 = A_arbace_classes_interp__init_part1_A_const_pool.A[152]; A_arbace_classes_interp__init_part1_A_const_93 = A_arbace_classes_interp__init_part1_A_const_pool.A[153]; A_arbace_classes_interp__init_part1_A_const_94 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[154]); A_arbace_classes_interp__init_part1_A_const_95 = A_arbace_classes_interp__init_part1_A_const_pool.A[155]; A_arbace_classes_interp__init_part1_A_const_96 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[156]); A_arbace_classes_interp__init_part1_A_const_97 = A_arbace_classes_interp__init_part1_A_const_pool.A[157]; A_arbace_classes_interp__init_part1_A_const_98 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[158]); A_arbace_classes_interp__init_part1_A_const_99 = A_arbace_classes_interp__init_part1_A_const_pool.A[159]; A_arbace_classes_interp__init_part1_A_const_100 = A_arbace_classes_interp__init_part1_A_const_pool.A[160]; A_arbace_classes_interp__init_part1_A_const_101 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[161]); A_arbace_classes_interp__init_part1_A_const_102 = A_arbace_classes_interp__init_part1_A_const_pool.A[162]; A_arbace_classes_interp__init_part1_A_const_103 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[163]); A_arbace_classes_interp__init_part1_A_const_104 = A_arbace_classes_interp__init_part1_A_const_pool.A[164]; A_arbace_classes_interp__init_part1_A_const_105 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[165]); A_arbace_classes_interp__init_part1_A_const_106 = A_arbace_classes_interp__init_part1_A_const_pool.A[166]; A_arbace_classes_interp__init_part1_A_const_107 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[167]); A_arbace_classes_interp__init_part1_A_const_108 = A_arbace_classes_interp__init_part1_A_const_pool.A[168]; A_arbace_classes_interp__init_part1_A_const_109 = lang.Var_Cast(A_arbace_classes_interp__init_part1_A_const_pool.A[169]); A_arbace_classes_interp__init_part1_A_const_110 = A_arbace_classes_interp__init_part1_A_const_pool.A[170] }

func A_arbace_classes_interp__init_part1_A_New() *A_arbace_classes_interp__init_part1_A { A_arbace_classes_interp__init_part1_A_Init(); t := &A_arbace_classes_interp__init_part1_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_interp__init_part1_A) Ctor() {}

func (t *A_arbace_classes_interp__init_part1_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_interp__init_part1_A) GetClass__Class() *jrt.Class { return A_arbace_classes_interp__init_part1_A_class }

func (t *A_arbace_classes_interp__init_part1_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_interp__init_part1_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_interp__init_part1_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_interp__init_part1_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_interp__init_part1_A); return ok }

func A_arbace_classes_interp__init_part1_A_Cast(x any) *A_arbace_classes_interp__init_part1_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_interp__init_part1_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_interp__init_part1_A_class)) }; return v }
