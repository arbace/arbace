//line a2g_classes.ae:1
package aot_arbace_classes_interp

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_classes_interp_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_A_New()}; return nil }

var A_arbace_classes_interp_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_A_new}

var A_arbace_classes_interp_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_A"})

func init() { i := A_arbace_classes_interp_A_class.Info(); i.IsInstance = A_arbace_classes_interp_A_InstanceOf; i.Init = A_arbace_classes_interp_A_Init; i.Table = A_arbace_classes_interp_A_members; jrt.RegisterGoType(A_arbace_classes_interp_A_class, reflect.TypeFor[A_arbace_classes_interp_A]()) }

func A_arbace_classes_interp_accessor_node_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_accessor_node_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_interp_accessor_node_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_accessor_node_A_New()}; return nil }

func A_arbace_classes_interp_accessor_node_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_accessor_node_A_fn_class)}; return nil }

var A_arbace_classes_interp_accessor_node_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_accessor_node_A_invoke, New: A_arbace_classes_interp_accessor_node_A_new, Get: A_arbace_classes_interp_accessor_node_A_get}

var A_arbace_classes_interp_accessor_node_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$accessor_node", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "accessor_node", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_accessor_node_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_accessor_node_A_class.Info(); i.IsInstance = A_arbace_classes_interp_accessor_node_A_InstanceOf; i.Init = A_arbace_classes_interp_accessor_node_A_Init; i.Table = A_arbace_classes_interp_accessor_node_A_members; jrt.RegisterGoType(A_arbace_classes_interp_accessor_node_A_class, reflect.TypeFor[A_arbace_classes_interp_accessor_node_A]()) }

func A_arbace_classes_interp_analyze_forms_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_analyze_forms_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_interp_analyze_forms_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_analyze_forms_A_New()}; return nil }

func A_arbace_classes_interp_analyze_forms_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_analyze_forms_A_fn_class)}; return nil }

var A_arbace_classes_interp_analyze_forms_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_analyze_forms_A_invoke, New: A_arbace_classes_interp_analyze_forms_A_new, Get: A_arbace_classes_interp_analyze_forms_A_get}

var A_arbace_classes_interp_analyze_forms_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$analyze_forms", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "analyze_forms", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_analyze_forms_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_analyze_forms_A_class.Info(); i.IsInstance = A_arbace_classes_interp_analyze_forms_A_InstanceOf; i.Init = A_arbace_classes_interp_analyze_forms_A_Init; i.Table = A_arbace_classes_interp_analyze_forms_A_members; jrt.RegisterGoType(A_arbace_classes_interp_analyze_forms_A_class, reflect.TypeFor[A_arbace_classes_interp_analyze_forms_A]()) }

func A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_A_fn_class)}; return nil }

var A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_A_invoke, New: A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_A_new, Get: A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_A_get}

var A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$analyze_forms$iter__393000763__393000767", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_analyze_forms_A_class, Simple: "iter__393000763__393000767", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_A_class.Info(); i.IsInstance = A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_A_InstanceOf; i.Init = A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_A_Init; i.Table = A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_A_members; jrt.RegisterGoType(A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_A_class, reflect.TypeFor[A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_A]()) }

func A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_A_fn_class)}; return nil }

var A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_A_invoke, New: A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_A_new, Get: A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_A_get}

var A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$analyze_forms$iter__393000763__393000767$fn__393000768", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_A_class, Simple: "fn__393000768", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_A_class.Info(); i.IsInstance = A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_A_InstanceOf; i.Init = A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_A_Init; i.Table = A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_A_members; jrt.RegisterGoType(A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_A_class, reflect.TypeFor[A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_A]()) }

func A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_fn__393000769_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_fn__393000769_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_fn__393000769_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_fn__393000769_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_fn__393000769_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_fn__393000769_A_fn_class)}; return nil }

var A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_fn__393000769_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_fn__393000769_A_invoke, New: A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_fn__393000769_A_new, Get: A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_fn__393000769_A_get}

var A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_fn__393000769_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$analyze_forms$iter__393000763__393000767$fn__393000768$fn__393000769", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_A_class, Simple: "fn__393000769", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_fn__393000769_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_fn__393000769_A_class.Info(); i.IsInstance = A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_fn__393000769_A_InstanceOf; i.Init = A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_fn__393000769_A_Init; i.Table = A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_fn__393000769_A_members; jrt.RegisterGoType(A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_fn__393000769_A_class, reflect.TypeFor[A_arbace_classes_interp_analyze_forms_iter__393000763__393000767_fn__393000768_fn__393000769_A]()) }

func A_arbace_classes_interp_and_or_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_and_or_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_interp_and_or_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_and_or_A_New()}; return nil }

func A_arbace_classes_interp_and_or_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_and_or_A_fn_class)}; return nil }

var A_arbace_classes_interp_and_or_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_and_or_A_invoke, New: A_arbace_classes_interp_and_or_A_new, Get: A_arbace_classes_interp_and_or_A_get}

var A_arbace_classes_interp_and_or_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$and_or", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "and_or", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_and_or_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_and_or_A_class.Info(); i.IsInstance = A_arbace_classes_interp_and_or_A_InstanceOf; i.Init = A_arbace_classes_interp_and_or_A_Init; i.Table = A_arbace_classes_interp_and_or_A_members; jrt.RegisterGoType(A_arbace_classes_interp_and_or_A_class, reflect.TypeFor[A_arbace_classes_interp_and_or_A]()) }

func A_arbace_classes_interp_and_or_fn__393000165_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_and_or_fn__393000165_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_and_or_fn__393000165_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_and_or_fn__393000165_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_and_or_fn__393000165_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_and_or_fn__393000165_A_fn_class)}; return nil }

var A_arbace_classes_interp_and_or_fn__393000165_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_and_or_fn__393000165_A_invoke, New: A_arbace_classes_interp_and_or_fn__393000165_A_new, Get: A_arbace_classes_interp_and_or_fn__393000165_A_get}

var A_arbace_classes_interp_and_or_fn__393000165_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$and_or$fn__393000165", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_and_or_A_class, Simple: "fn__393000165", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_and_or_fn__393000165_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_and_or_fn__393000165_A_class.Info(); i.IsInstance = A_arbace_classes_interp_and_or_fn__393000165_A_InstanceOf; i.Init = A_arbace_classes_interp_and_or_fn__393000165_A_Init; i.Table = A_arbace_classes_interp_and_or_fn__393000165_A_members; jrt.RegisterGoType(A_arbace_classes_interp_and_or_fn__393000165_A_class, reflect.TypeFor[A_arbace_classes_interp_and_or_fn__393000165_A]()) }

func A_arbace_classes_interp_arg_nodes_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_arg_nodes_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_interp_arg_nodes_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_arg_nodes_A_New()}; return nil }

func A_arbace_classes_interp_arg_nodes_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_arg_nodes_A_fn_class)}; return nil }

var A_arbace_classes_interp_arg_nodes_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_arg_nodes_A_invoke, New: A_arbace_classes_interp_arg_nodes_A_new, Get: A_arbace_classes_interp_arg_nodes_A_get}

var A_arbace_classes_interp_arg_nodes_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$arg_nodes", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "arg_nodes", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_arg_nodes_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_arg_nodes_A_class.Info(); i.IsInstance = A_arbace_classes_interp_arg_nodes_A_InstanceOf; i.Init = A_arbace_classes_interp_arg_nodes_A_Init; i.Table = A_arbace_classes_interp_arg_nodes_A_members; jrt.RegisterGoType(A_arbace_classes_interp_arg_nodes_A_class, reflect.TypeFor[A_arbace_classes_interp_arg_nodes_A]()) }

func A_arbace_classes_interp_arg_nodes_fn__393000290_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_arg_nodes_fn__393000290_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_arg_nodes_fn__393000290_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_arg_nodes_fn__393000290_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_arg_nodes_fn__393000290_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_arg_nodes_fn__393000290_A_fn_class)}; return nil }

var A_arbace_classes_interp_arg_nodes_fn__393000290_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_arg_nodes_fn__393000290_A_invoke, New: A_arbace_classes_interp_arg_nodes_fn__393000290_A_new, Get: A_arbace_classes_interp_arg_nodes_fn__393000290_A_get}

var A_arbace_classes_interp_arg_nodes_fn__393000290_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$arg_nodes$fn__393000290", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_arg_nodes_A_class, Simple: "fn__393000290", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_arg_nodes_fn__393000290_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_arg_nodes_fn__393000290_A_class.Info(); i.IsInstance = A_arbace_classes_interp_arg_nodes_fn__393000290_A_InstanceOf; i.Init = A_arbace_classes_interp_arg_nodes_fn__393000290_A_Init; i.Table = A_arbace_classes_interp_arg_nodes_fn__393000290_A_members; jrt.RegisterGoType(A_arbace_classes_interp_arg_nodes_fn__393000290_A_class, reflect.TypeFor[A_arbace_classes_interp_arg_nodes_fn__393000290_A]()) }

func A_arbace_classes_interp_bind_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_bind_BANG__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_bind_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_bind_BANG__A_New()}; return nil }

func A_arbace_classes_interp_bind_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_bind_BANG__A_fn_class)}; return nil }

var A_arbace_classes_interp_bind_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_bind_BANG__A_invoke, New: A_arbace_classes_interp_bind_BANG__A_new, Get: A_arbace_classes_interp_bind_BANG__A_get}

var A_arbace_classes_interp_bind_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$bind_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "bind_BANG_", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_bind_BANG__A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_bind_BANG__A_class.Info(); i.IsInstance = A_arbace_classes_interp_bind_BANG__A_InstanceOf; i.Init = A_arbace_classes_interp_bind_BANG__A_Init; i.Table = A_arbace_classes_interp_bind_BANG__A_members; jrt.RegisterGoType(A_arbace_classes_interp_bind_BANG__A_class, reflect.TypeFor[A_arbace_classes_interp_bind_BANG__A]()) }

func A_arbace_classes_interp_build_method_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_build_method_BANG__A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_classes_interp_build_method_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_build_method_BANG__A_New()}; return nil }

func A_arbace_classes_interp_build_method_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_build_method_BANG__A_fn_class)}; return nil }

var A_arbace_classes_interp_build_method_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_build_method_BANG__A_invoke, New: A_arbace_classes_interp_build_method_BANG__A_new, Get: A_arbace_classes_interp_build_method_BANG__A_get}

var A_arbace_classes_interp_build_method_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$build_method_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "build_method_BANG_", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_build_method_BANG__A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_build_method_BANG__A_class.Info(); i.IsInstance = A_arbace_classes_interp_build_method_BANG__A_InstanceOf; i.Init = A_arbace_classes_interp_build_method_BANG__A_Init; i.Table = A_arbace_classes_interp_build_method_BANG__A_members; jrt.RegisterGoType(A_arbace_classes_interp_build_method_BANG__A_class, reflect.TypeFor[A_arbace_classes_interp_build_method_BANG__A]()) }

func A_arbace_classes_interp_build_method_BANG__call_node__393000710_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_build_method_BANG__call_node__393000710_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_build_method_BANG__call_node__393000710_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_build_method_BANG__call_node__393000710_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_build_method_BANG__call_node__393000710_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_build_method_BANG__call_node__393000710_A_fn_class)}; return nil }

var A_arbace_classes_interp_build_method_BANG__call_node__393000710_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_build_method_BANG__call_node__393000710_A_invoke, New: A_arbace_classes_interp_build_method_BANG__call_node__393000710_A_new, Get: A_arbace_classes_interp_build_method_BANG__call_node__393000710_A_get}

var A_arbace_classes_interp_build_method_BANG__call_node__393000710_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$build_method_BANG_$call_node__393000710", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_build_method_BANG__A_class, Simple: "call_node__393000710", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_build_method_BANG__call_node__393000710_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_build_method_BANG__call_node__393000710_A_class.Info(); i.IsInstance = A_arbace_classes_interp_build_method_BANG__call_node__393000710_A_InstanceOf; i.Init = A_arbace_classes_interp_build_method_BANG__call_node__393000710_A_Init; i.Table = A_arbace_classes_interp_build_method_BANG__call_node__393000710_A_members; jrt.RegisterGoType(A_arbace_classes_interp_build_method_BANG__call_node__393000710_A_class, reflect.TypeFor[A_arbace_classes_interp_build_method_BANG__call_node__393000710_A]()) }

func A_arbace_classes_interp_build_method_BANG__fn__393000712_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_build_method_BANG__fn__393000712_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_build_method_BANG__fn__393000712_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_build_method_BANG__fn__393000712_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_build_method_BANG__fn__393000712_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_build_method_BANG__fn__393000712_A_fn_class)}; return nil }

var A_arbace_classes_interp_build_method_BANG__fn__393000712_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_build_method_BANG__fn__393000712_A_invoke, New: A_arbace_classes_interp_build_method_BANG__fn__393000712_A_new, Get: A_arbace_classes_interp_build_method_BANG__fn__393000712_A_get}

var A_arbace_classes_interp_build_method_BANG__fn__393000712_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$build_method_BANG_$fn__393000712", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_build_method_BANG__A_class, Simple: "fn__393000712", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_build_method_BANG__fn__393000712_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_build_method_BANG__fn__393000712_A_class.Info(); i.IsInstance = A_arbace_classes_interp_build_method_BANG__fn__393000712_A_InstanceOf; i.Init = A_arbace_classes_interp_build_method_BANG__fn__393000712_A_Init; i.Table = A_arbace_classes_interp_build_method_BANG__fn__393000712_A_members; jrt.RegisterGoType(A_arbace_classes_interp_build_method_BANG__fn__393000712_A_class, reflect.TypeFor[A_arbace_classes_interp_build_method_BANG__fn__393000712_A]()) }

func A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_A_fn_class)}; return nil }

var A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_A_invoke, New: A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_A_new, Get: A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_A_get}

var A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$build_method_BANG_$iter__393000714__393000718", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_build_method_BANG__A_class, Simple: "iter__393000714__393000718", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_A_class.Info(); i.IsInstance = A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_A_InstanceOf; i.Init = A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_A_Init; i.Table = A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_A_members; jrt.RegisterGoType(A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_A_class, reflect.TypeFor[A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_A]()) }

func A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_A_fn_class)}; return nil }

var A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_A_invoke, New: A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_A_new, Get: A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_A_get}

var A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$build_method_BANG_$iter__393000714__393000718$fn__393000719", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_A_class, Simple: "fn__393000719", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_A_class.Info(); i.IsInstance = A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_A_InstanceOf; i.Init = A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_A_Init; i.Table = A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_A_members; jrt.RegisterGoType(A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_A_class, reflect.TypeFor[A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_A]()) }

func A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_fn__393000720_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_fn__393000720_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_fn__393000720_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_fn__393000720_A_New_O_O_O_I_O(args[0], args[1], args[2], args[3].(int32), args[4])}; return nil }

func A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_fn__393000720_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_fn__393000720_A_fn_class)}; return nil }

var A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_fn__393000720_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_fn__393000720_A_invoke, New: A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_fn__393000720_A_new, Get: A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_fn__393000720_A_get}

var A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_fn__393000720_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$build_method_BANG_$iter__393000714__393000718$fn__393000719$fn__393000720", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_A_class, Simple: "fn__393000720", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_fn__393000720_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_fn__393000720_A_class.Info(); i.IsInstance = A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_fn__393000720_A_InstanceOf; i.Init = A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_fn__393000720_A_Init; i.Table = A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_fn__393000720_A_members; jrt.RegisterGoType(A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_fn__393000720_A_class, reflect.TypeFor[A_arbace_classes_interp_build_method_BANG__iter__393000714__393000718_fn__393000719_fn__393000720_A]()) }

func A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_A_fn_class)}; return nil }

var A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_A_invoke, New: A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_A_new, Get: A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_A_get}

var A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$build_method_BANG_$iter__393000733__393000737", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_build_method_BANG__A_class, Simple: "iter__393000733__393000737", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_A_class.Info(); i.IsInstance = A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_A_InstanceOf; i.Init = A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_A_Init; i.Table = A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_A_members; jrt.RegisterGoType(A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_A_class, reflect.TypeFor[A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_A]()) }

func A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_A_fn_class)}; return nil }

var A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_A_invoke, New: A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_A_new, Get: A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_A_get}

var A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$build_method_BANG_$iter__393000733__393000737$fn__393000738", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_A_class, Simple: "fn__393000738", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_A_class.Info(); i.IsInstance = A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_A_InstanceOf; i.Init = A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_A_Init; i.Table = A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_A_members; jrt.RegisterGoType(A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_A_class, reflect.TypeFor[A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_A]()) }

func A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_fn__393000739_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_fn__393000739_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_fn__393000739_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_fn__393000739_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_fn__393000739_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_fn__393000739_A_fn_class)}; return nil }

var A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_fn__393000739_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_fn__393000739_A_invoke, New: A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_fn__393000739_A_new, Get: A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_fn__393000739_A_get}

var A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_fn__393000739_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$build_method_BANG_$iter__393000733__393000737$fn__393000738$fn__393000739", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_A_class, Simple: "fn__393000739", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_fn__393000739_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_fn__393000739_A_class.Info(); i.IsInstance = A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_fn__393000739_A_InstanceOf; i.Init = A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_fn__393000739_A_Init; i.Table = A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_fn__393000739_A_members; jrt.RegisterGoType(A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_fn__393000739_A_class, reflect.TypeFor[A_arbace_classes_interp_build_method_BANG__iter__393000733__393000737_fn__393000738_fn__393000739_A]()) }

func A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_A_fn_class)}; return nil }

var A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_A_invoke, New: A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_A_new, Get: A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_A_get}

var A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$build_method_BANG_$iter__393000743__393000747", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_build_method_BANG__A_class, Simple: "iter__393000743__393000747", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_A_class.Info(); i.IsInstance = A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_A_InstanceOf; i.Init = A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_A_Init; i.Table = A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_A_members; jrt.RegisterGoType(A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_A_class, reflect.TypeFor[A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_A]()) }

func A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_A_fn_class)}; return nil }

var A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_A_invoke, New: A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_A_new, Get: A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_A_get}

var A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$build_method_BANG_$iter__393000743__393000747$fn__393000748", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_A_class, Simple: "fn__393000748", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_A_class.Info(); i.IsInstance = A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_A_InstanceOf; i.Init = A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_A_Init; i.Table = A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_A_members; jrt.RegisterGoType(A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_A_class, reflect.TypeFor[A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_A]()) }

func A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_fn__393000749_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_fn__393000749_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_fn__393000749_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_fn__393000749_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_fn__393000749_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_fn__393000749_A_fn_class)}; return nil }

var A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_fn__393000749_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_fn__393000749_A_invoke, New: A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_fn__393000749_A_new, Get: A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_fn__393000749_A_get}

var A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_fn__393000749_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$build_method_BANG_$iter__393000743__393000747$fn__393000748$fn__393000749", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_A_class, Simple: "fn__393000749", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_fn__393000749_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_fn__393000749_A_class.Info(); i.IsInstance = A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_fn__393000749_A_InstanceOf; i.Init = A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_fn__393000749_A_Init; i.Table = A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_fn__393000749_A_members; jrt.RegisterGoType(A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_fn__393000749_A_class, reflect.TypeFor[A_arbace_classes_interp_build_method_BANG__iter__393000743__393000747_fn__393000748_fn__393000749_A]()) }

func A_arbace_classes_interp_clinit_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_clinit_BANG__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_clinit_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_clinit_BANG__A_New()}; return nil }

func A_arbace_classes_interp_clinit_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_clinit_BANG__A_fn_class)}; return nil }

var A_arbace_classes_interp_clinit_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_clinit_BANG__A_invoke, New: A_arbace_classes_interp_clinit_BANG__A_new, Get: A_arbace_classes_interp_clinit_BANG__A_get}

var A_arbace_classes_interp_clinit_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$clinit_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "clinit_BANG_", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_clinit_BANG__A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_clinit_BANG__A_class.Info(); i.IsInstance = A_arbace_classes_interp_clinit_BANG__A_InstanceOf; i.Init = A_arbace_classes_interp_clinit_BANG__A_Init; i.Table = A_arbace_classes_interp_clinit_BANG__A_members; jrt.RegisterGoType(A_arbace_classes_interp_clinit_BANG__A_class, reflect.TypeFor[A_arbace_classes_interp_clinit_BANG__A]()) }

func A_arbace_classes_interp_clinit_BANG__build__393000876_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_clinit_BANG__build__393000876_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_clinit_BANG__build__393000876_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_clinit_BANG__build__393000876_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_clinit_BANG__build__393000876_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_clinit_BANG__build__393000876_A_fn_class)}; return nil }

var A_arbace_classes_interp_clinit_BANG__build__393000876_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_clinit_BANG__build__393000876_A_invoke, New: A_arbace_classes_interp_clinit_BANG__build__393000876_A_new, Get: A_arbace_classes_interp_clinit_BANG__build__393000876_A_get}

var A_arbace_classes_interp_clinit_BANG__build__393000876_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$clinit_BANG_$build__393000876", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_clinit_BANG__A_class, Simple: "build__393000876", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_clinit_BANG__build__393000876_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_clinit_BANG__build__393000876_A_class.Info(); i.IsInstance = A_arbace_classes_interp_clinit_BANG__build__393000876_A_InstanceOf; i.Init = A_arbace_classes_interp_clinit_BANG__build__393000876_A_Init; i.Table = A_arbace_classes_interp_clinit_BANG__build__393000876_A_members; jrt.RegisterGoType(A_arbace_classes_interp_clinit_BANG__build__393000876_A_class, reflect.TypeFor[A_arbace_classes_interp_clinit_BANG__build__393000876_A]()) }

func A_arbace_classes_interp_clinit_BANG__build__393000876_fn__393000877_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_clinit_BANG__build__393000876_fn__393000877_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_clinit_BANG__build__393000876_fn__393000877_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_clinit_BANG__build__393000876_fn__393000877_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_clinit_BANG__build__393000876_fn__393000877_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_clinit_BANG__build__393000876_fn__393000877_A_fn_class)}; return nil }

var A_arbace_classes_interp_clinit_BANG__build__393000876_fn__393000877_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_clinit_BANG__build__393000876_fn__393000877_A_invoke, New: A_arbace_classes_interp_clinit_BANG__build__393000876_fn__393000877_A_new, Get: A_arbace_classes_interp_clinit_BANG__build__393000876_fn__393000877_A_get}

var A_arbace_classes_interp_clinit_BANG__build__393000876_fn__393000877_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$clinit_BANG_$build__393000876$fn__393000877", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_clinit_BANG__build__393000876_A_class, Simple: "fn__393000877", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_clinit_BANG__build__393000876_fn__393000877_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_clinit_BANG__build__393000876_fn__393000877_A_class.Info(); i.IsInstance = A_arbace_classes_interp_clinit_BANG__build__393000876_fn__393000877_A_InstanceOf; i.Init = A_arbace_classes_interp_clinit_BANG__build__393000876_fn__393000877_A_Init; i.Table = A_arbace_classes_interp_clinit_BANG__build__393000876_fn__393000877_A_members; jrt.RegisterGoType(A_arbace_classes_interp_clinit_BANG__build__393000876_fn__393000877_A_class, reflect.TypeFor[A_arbace_classes_interp_clinit_BANG__build__393000876_fn__393000877_A]()) }

func A_arbace_classes_interp_clinit_BANG__fn__393000880_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_clinit_BANG__fn__393000880_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_clinit_BANG__fn__393000880_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_clinit_BANG__fn__393000880_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_clinit_BANG__fn__393000880_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_clinit_BANG__fn__393000880_A_fn_class)}; return nil }

var A_arbace_classes_interp_clinit_BANG__fn__393000880_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_clinit_BANG__fn__393000880_A_invoke, New: A_arbace_classes_interp_clinit_BANG__fn__393000880_A_new, Get: A_arbace_classes_interp_clinit_BANG__fn__393000880_A_get}

var A_arbace_classes_interp_clinit_BANG__fn__393000880_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$clinit_BANG_$fn__393000880", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_clinit_BANG__A_class, Simple: "fn__393000880", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_clinit_BANG__fn__393000880_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_clinit_BANG__fn__393000880_A_class.Info(); i.IsInstance = A_arbace_classes_interp_clinit_BANG__fn__393000880_A_InstanceOf; i.Init = A_arbace_classes_interp_clinit_BANG__fn__393000880_A_Init; i.Table = A_arbace_classes_interp_clinit_BANG__fn__393000880_A_members; jrt.RegisterGoType(A_arbace_classes_interp_clinit_BANG__fn__393000880_A_class, reflect.TypeFor[A_arbace_classes_interp_clinit_BANG__fn__393000880_A]()) }

func A_arbace_classes_interp_clinit_BANG__fn__393000882_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_clinit_BANG__fn__393000882_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_clinit_BANG__fn__393000882_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_clinit_BANG__fn__393000882_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_clinit_BANG__fn__393000882_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_clinit_BANG__fn__393000882_A_fn_class)}; return nil }

var A_arbace_classes_interp_clinit_BANG__fn__393000882_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_clinit_BANG__fn__393000882_A_invoke, New: A_arbace_classes_interp_clinit_BANG__fn__393000882_A_new, Get: A_arbace_classes_interp_clinit_BANG__fn__393000882_A_get}

var A_arbace_classes_interp_clinit_BANG__fn__393000882_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$clinit_BANG_$fn__393000882", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_clinit_BANG__A_class, Simple: "fn__393000882", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_clinit_BANG__fn__393000882_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_clinit_BANG__fn__393000882_A_class.Info(); i.IsInstance = A_arbace_classes_interp_clinit_BANG__fn__393000882_A_InstanceOf; i.Init = A_arbace_classes_interp_clinit_BANG__fn__393000882_A_Init; i.Table = A_arbace_classes_interp_clinit_BANG__fn__393000882_A_members; jrt.RegisterGoType(A_arbace_classes_interp_clinit_BANG__fn__393000882_A_class, reflect.TypeFor[A_arbace_classes_interp_clinit_BANG__fn__393000882_A]()) }

func A_arbace_classes_interp_clj_const_value_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_clj_const_value_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_clj_const_value_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_clj_const_value_A_New()}; return nil }

func A_arbace_classes_interp_clj_const_value_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_clj_const_value_A_fn_class)}; return nil }

var A_arbace_classes_interp_clj_const_value_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_clj_const_value_A_invoke, New: A_arbace_classes_interp_clj_const_value_A_new, Get: A_arbace_classes_interp_clj_const_value_A_get}

var A_arbace_classes_interp_clj_const_value_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$clj_const_value", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "clj_const_value", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_clj_const_value_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_clj_const_value_A_class.Info(); i.IsInstance = A_arbace_classes_interp_clj_const_value_A_InstanceOf; i.Init = A_arbace_classes_interp_clj_const_value_A_Init; i.Table = A_arbace_classes_interp_clj_const_value_A_members; jrt.RegisterGoType(A_arbace_classes_interp_clj_const_value_A_class, reflect.TypeFor[A_arbace_classes_interp_clj_const_value_A]()) }

func A_arbace_classes_interp_clj_const_value_fn__393000334_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_clj_const_value_fn__393000334_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_clj_const_value_fn__393000334_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_clj_const_value_fn__393000334_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_clj_const_value_fn__393000334_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_clj_const_value_fn__393000334_A_fn_class)}; return nil }

var A_arbace_classes_interp_clj_const_value_fn__393000334_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_clj_const_value_fn__393000334_A_invoke, New: A_arbace_classes_interp_clj_const_value_fn__393000334_A_new, Get: A_arbace_classes_interp_clj_const_value_fn__393000334_A_get}

var A_arbace_classes_interp_clj_const_value_fn__393000334_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$clj_const_value$fn__393000334", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_clj_const_value_A_class, Simple: "fn__393000334", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_clj_const_value_fn__393000334_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_clj_const_value_fn__393000334_A_class.Info(); i.IsInstance = A_arbace_classes_interp_clj_const_value_fn__393000334_A_InstanceOf; i.Init = A_arbace_classes_interp_clj_const_value_fn__393000334_A_Init; i.Table = A_arbace_classes_interp_clj_const_value_fn__393000334_A_members; jrt.RegisterGoType(A_arbace_classes_interp_clj_const_value_fn__393000334_A_class, reflect.TypeFor[A_arbace_classes_interp_clj_const_value_fn__393000334_A]()) }

func A_arbace_classes_interp_coerce_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_coerce_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_interp_coerce_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_coerce_A_New()}; return nil }

func A_arbace_classes_interp_coerce_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_coerce_A_fn_class)}; return nil }

var A_arbace_classes_interp_coerce_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_coerce_A_invoke, New: A_arbace_classes_interp_coerce_A_new, Get: A_arbace_classes_interp_coerce_A_get}

var A_arbace_classes_interp_coerce_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$coerce", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "coerce", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_coerce_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_coerce_A_class.Info(); i.IsInstance = A_arbace_classes_interp_coerce_A_InstanceOf; i.Init = A_arbace_classes_interp_coerce_A_Init; i.Table = A_arbace_classes_interp_coerce_A_members; jrt.RegisterGoType(A_arbace_classes_interp_coerce_A_class, reflect.TypeFor[A_arbace_classes_interp_coerce_A]()) }

func A_arbace_classes_interp_compile_and_load_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_compile_and_load_BANG__A).DoInvoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_interp_compile_and_load_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_compile_and_load_BANG__A_New()}; return nil }

func A_arbace_classes_interp_compile_and_load_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_compile_and_load_BANG__A_fn_class)}; return nil }

var A_arbace_classes_interp_compile_and_load_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_compile_and_load_BANG__A_invoke, New: A_arbace_classes_interp_compile_and_load_BANG__A_new, Get: A_arbace_classes_interp_compile_and_load_BANG__A_get}

var A_arbace_classes_interp_compile_and_load_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$compile_and_load_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR2_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "compile_and_load_BANG_", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_compile_and_load_BANG__A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_compile_and_load_BANG__A_class.Info(); i.IsInstance = A_arbace_classes_interp_compile_and_load_BANG__A_InstanceOf; i.Init = A_arbace_classes_interp_compile_and_load_BANG__A_Init; i.Table = A_arbace_classes_interp_compile_and_load_BANG__A_members; jrt.RegisterGoType(A_arbace_classes_interp_compile_and_load_BANG__A_class, reflect.TypeFor[A_arbace_classes_interp_compile_and_load_BANG__A]()) }

func A_arbace_classes_interp_convert_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_convert_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_interp_convert_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_convert_A_New()}; return nil }

func A_arbace_classes_interp_convert_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_convert_A_fn_class)}; return nil }

var A_arbace_classes_interp_convert_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_convert_A_invoke, New: A_arbace_classes_interp_convert_A_new, Get: A_arbace_classes_interp_convert_A_get}

var A_arbace_classes_interp_convert_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$convert", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "convert", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_convert_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_convert_A_class.Info(); i.IsInstance = A_arbace_classes_interp_convert_A_InstanceOf; i.Init = A_arbace_classes_interp_convert_A_Init; i.Table = A_arbace_classes_interp_convert_A_members; jrt.RegisterGoType(A_arbace_classes_interp_convert_A_class, reflect.TypeFor[A_arbace_classes_interp_convert_A]()) }

func A_arbace_classes_interp_ctor_call_node_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_ctor_call_node_A).Invoke_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_classes_interp_ctor_call_node_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_ctor_call_node_A_New()}; return nil }

func A_arbace_classes_interp_ctor_call_node_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_ctor_call_node_A_fn_class)}; return nil }

var A_arbace_classes_interp_ctor_call_node_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_ctor_call_node_A_invoke, New: A_arbace_classes_interp_ctor_call_node_A_new, Get: A_arbace_classes_interp_ctor_call_node_A_get}

var A_arbace_classes_interp_ctor_call_node_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$ctor_call_node", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF5_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "ctor_call_node", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_ctor_call_node_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_ctor_call_node_A_class.Info(); i.IsInstance = A_arbace_classes_interp_ctor_call_node_A_InstanceOf; i.Init = A_arbace_classes_interp_ctor_call_node_A_Init; i.Table = A_arbace_classes_interp_ctor_call_node_A_members; jrt.RegisterGoType(A_arbace_classes_interp_ctor_call_node_A_class, reflect.TypeFor[A_arbace_classes_interp_ctor_call_node_A]()) }

func A_arbace_classes_interp_ctor_call_node_fn__393000695_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_ctor_call_node_fn__393000695_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_ctor_call_node_fn__393000695_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_ctor_call_node_fn__393000695_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_ctor_call_node_fn__393000695_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_ctor_call_node_fn__393000695_A_fn_class)}; return nil }

var A_arbace_classes_interp_ctor_call_node_fn__393000695_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_ctor_call_node_fn__393000695_A_invoke, New: A_arbace_classes_interp_ctor_call_node_fn__393000695_A_new, Get: A_arbace_classes_interp_ctor_call_node_fn__393000695_A_get}

var A_arbace_classes_interp_ctor_call_node_fn__393000695_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$ctor_call_node$fn__393000695", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_ctor_call_node_A_class, Simple: "fn__393000695", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_ctor_call_node_fn__393000695_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_ctor_call_node_fn__393000695_A_class.Info(); i.IsInstance = A_arbace_classes_interp_ctor_call_node_fn__393000695_A_InstanceOf; i.Init = A_arbace_classes_interp_ctor_call_node_fn__393000695_A_Init; i.Table = A_arbace_classes_interp_ctor_call_node_fn__393000695_A_members; jrt.RegisterGoType(A_arbace_classes_interp_ctor_call_node_fn__393000695_A_class, reflect.TypeFor[A_arbace_classes_interp_ctor_call_node_fn__393000695_A]()) }

func A_arbace_classes_interp_ctor_call_node_inits__393000693_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_ctor_call_node_inits__393000693_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_ctor_call_node_inits__393000693_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_ctor_call_node_inits__393000693_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_ctor_call_node_inits__393000693_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_ctor_call_node_inits__393000693_A_fn_class)}; return nil }

var A_arbace_classes_interp_ctor_call_node_inits__393000693_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_ctor_call_node_inits__393000693_A_invoke, New: A_arbace_classes_interp_ctor_call_node_inits__393000693_A_new, Get: A_arbace_classes_interp_ctor_call_node_inits__393000693_A_get}

var A_arbace_classes_interp_ctor_call_node_inits__393000693_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$ctor_call_node$inits__393000693", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_ctor_call_node_A_class, Simple: "inits__393000693", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_ctor_call_node_inits__393000693_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_ctor_call_node_inits__393000693_A_class.Info(); i.IsInstance = A_arbace_classes_interp_ctor_call_node_inits__393000693_A_InstanceOf; i.Init = A_arbace_classes_interp_ctor_call_node_inits__393000693_A_Init; i.Table = A_arbace_classes_interp_ctor_call_node_inits__393000693_A_members; jrt.RegisterGoType(A_arbace_classes_interp_ctor_call_node_inits__393000693_A_class, reflect.TypeFor[A_arbace_classes_interp_ctor_call_node_inits__393000693_A]()) }

func A_arbace_classes_interp_ctor_meth_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_ctor_meth_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_ctor_meth_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_ctor_meth_A_New()}; return nil }

func A_arbace_classes_interp_ctor_meth_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_ctor_meth_A_fn_class)}; return nil }

var A_arbace_classes_interp_ctor_meth_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_ctor_meth_A_invoke, New: A_arbace_classes_interp_ctor_meth_A_new, Get: A_arbace_classes_interp_ctor_meth_A_get}

var A_arbace_classes_interp_ctor_meth_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$ctor_meth", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "ctor_meth", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_ctor_meth_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_ctor_meth_A_class.Info(); i.IsInstance = A_arbace_classes_interp_ctor_meth_A_InstanceOf; i.Init = A_arbace_classes_interp_ctor_meth_A_Init; i.Table = A_arbace_classes_interp_ctor_meth_A_members; jrt.RegisterGoType(A_arbace_classes_interp_ctor_meth_A_class, reflect.TypeFor[A_arbace_classes_interp_ctor_meth_A]()) }

func A_arbace_classes_interp_ctx_for_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_ctx_for_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_interp_ctx_for_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_ctx_for_A_New()}; return nil }

func A_arbace_classes_interp_ctx_for_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_ctx_for_A_fn_class)}; return nil }

var A_arbace_classes_interp_ctx_for_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_ctx_for_A_invoke, New: A_arbace_classes_interp_ctx_for_A_new, Get: A_arbace_classes_interp_ctx_for_A_get}

var A_arbace_classes_interp_ctx_for_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$ctx_for", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "ctx_for", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_ctx_for_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_ctx_for_A_class.Info(); i.IsInstance = A_arbace_classes_interp_ctx_for_A_InstanceOf; i.Init = A_arbace_classes_interp_ctx_for_A_Init; i.Table = A_arbace_classes_interp_ctx_for_A_members; jrt.RegisterGoType(A_arbace_classes_interp_ctx_for_A_class, reflect.TypeFor[A_arbace_classes_interp_ctx_for_A]()) }

func A_arbace_classes_interp_declare_siblings_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_declare_siblings_BANG__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_declare_siblings_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_declare_siblings_BANG__A_New()}; return nil }

func A_arbace_classes_interp_declare_siblings_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_declare_siblings_BANG__A_fn_class)}; return nil }

var A_arbace_classes_interp_declare_siblings_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_declare_siblings_BANG__A_invoke, New: A_arbace_classes_interp_declare_siblings_BANG__A_new, Get: A_arbace_classes_interp_declare_siblings_BANG__A_get}

var A_arbace_classes_interp_declare_siblings_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$declare_siblings_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "declare_siblings_BANG_", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_declare_siblings_BANG__A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_declare_siblings_BANG__A_class.Info(); i.IsInstance = A_arbace_classes_interp_declare_siblings_BANG__A_InstanceOf; i.Init = A_arbace_classes_interp_declare_siblings_BANG__A_Init; i.Table = A_arbace_classes_interp_declare_siblings_BANG__A_members; jrt.RegisterGoType(A_arbace_classes_interp_declare_siblings_BANG__A_class, reflect.TypeFor[A_arbace_classes_interp_declare_siblings_BANG__A]()) }

func A_arbace_classes_interp_define_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_define_BANG__A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_interp_define_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_define_BANG__A_New()}; return nil }

func A_arbace_classes_interp_define_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_define_BANG__A_fn_class)}; return nil }

var A_arbace_classes_interp_define_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_define_BANG__A_invoke, New: A_arbace_classes_interp_define_BANG__A_new, Get: A_arbace_classes_interp_define_BANG__A_get}

var A_arbace_classes_interp_define_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$define_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "define_BANG_", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_define_BANG__A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_define_BANG__A_class.Info(); i.IsInstance = A_arbace_classes_interp_define_BANG__A_InstanceOf; i.Init = A_arbace_classes_interp_define_BANG__A_Init; i.Table = A_arbace_classes_interp_define_BANG__A_members; jrt.RegisterGoType(A_arbace_classes_interp_define_BANG__A_class, reflect.TypeFor[A_arbace_classes_interp_define_BANG__A]()) }

func A_arbace_classes_interp_define_BANG__fn__393000889_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_define_BANG__fn__393000889_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_define_BANG__fn__393000889_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_define_BANG__fn__393000889_A_New()}; return nil }

func A_arbace_classes_interp_define_BANG__fn__393000889_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_define_BANG__fn__393000889_A_fn_class)}; return nil }

var A_arbace_classes_interp_define_BANG__fn__393000889_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_define_BANG__fn__393000889_A_invoke, New: A_arbace_classes_interp_define_BANG__fn__393000889_A_new, Get: A_arbace_classes_interp_define_BANG__fn__393000889_A_get}

var A_arbace_classes_interp_define_BANG__fn__393000889_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$define_BANG_$fn__393000889", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_define_BANG__A_class, Simple: "fn__393000889", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_define_BANG__fn__393000889_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_define_BANG__fn__393000889_A_class.Info(); i.IsInstance = A_arbace_classes_interp_define_BANG__fn__393000889_A_InstanceOf; i.Init = A_arbace_classes_interp_define_BANG__fn__393000889_A_Init; i.Table = A_arbace_classes_interp_define_BANG__fn__393000889_A_members; jrt.RegisterGoType(A_arbace_classes_interp_define_BANG__fn__393000889_A_class, reflect.TypeFor[A_arbace_classes_interp_define_BANG__fn__393000889_A]()) }

func A_arbace_classes_interp_define_BANG__fn__393000891_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_define_BANG__fn__393000891_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_define_BANG__fn__393000891_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_define_BANG__fn__393000891_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_define_BANG__fn__393000891_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_define_BANG__fn__393000891_A_fn_class)}; return nil }

var A_arbace_classes_interp_define_BANG__fn__393000891_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_define_BANG__fn__393000891_A_invoke, New: A_arbace_classes_interp_define_BANG__fn__393000891_A_new, Get: A_arbace_classes_interp_define_BANG__fn__393000891_A_get}

var A_arbace_classes_interp_define_BANG__fn__393000891_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$define_BANG_$fn__393000891", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_define_BANG__A_class, Simple: "fn__393000891", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_define_BANG__fn__393000891_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_define_BANG__fn__393000891_A_class.Info(); i.IsInstance = A_arbace_classes_interp_define_BANG__fn__393000891_A_InstanceOf; i.Init = A_arbace_classes_interp_define_BANG__fn__393000891_A_Init; i.Table = A_arbace_classes_interp_define_BANG__fn__393000891_A_members; jrt.RegisterGoType(A_arbace_classes_interp_define_BANG__fn__393000891_A_class, reflect.TypeFor[A_arbace_classes_interp_define_BANG__fn__393000891_A]()) }

func A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000892_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000892_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000892_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000892_A_New()}; return nil }

func A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000892_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000892_A_fn_class)}; return nil }

var A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000892_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000892_A_invoke, New: A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000892_A_new, Get: A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000892_A_get}

var A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000892_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$define_BANG_$fn__393000891$fn__393000892", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_define_BANG__fn__393000891_A_class, Simple: "fn__393000892", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000892_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000892_A_class.Info(); i.IsInstance = A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000892_A_InstanceOf; i.Init = A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000892_A_Init; i.Table = A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000892_A_members; jrt.RegisterGoType(A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000892_A_class, reflect.TypeFor[A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000892_A]()) }

func A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_A_fn_class)}; return nil }

var A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_A_invoke, New: A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_A_new, Get: A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_A_get}

var A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$define_BANG_$fn__393000891$fn__393000940", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_define_BANG__fn__393000891_A_class, Simple: "fn__393000940", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_A_class.Info(); i.IsInstance = A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_A_InstanceOf; i.Init = A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_A_Init; i.Table = A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_A_members; jrt.RegisterGoType(A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_A_class, reflect.TypeFor[A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_A]()) }

func A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000952_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000952_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000952_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000952_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000952_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000952_A_fn_class)}; return nil }

var A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000952_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000952_A_invoke, New: A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000952_A_new, Get: A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000952_A_get}

var A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000952_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$define_BANG_$fn__393000891$fn__393000940$fn__393000952", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_A_class, Simple: "fn__393000952", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000952_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000952_A_class.Info(); i.IsInstance = A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000952_A_InstanceOf; i.Init = A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000952_A_Init; i.Table = A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000952_A_members; jrt.RegisterGoType(A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000952_A_class, reflect.TypeFor[A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000952_A]()) }

func A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000957_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000957_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000957_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000957_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000957_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000957_A_fn_class)}; return nil }

var A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000957_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000957_A_invoke, New: A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000957_A_new, Get: A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000957_A_get}

var A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000957_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$define_BANG_$fn__393000891$fn__393000940$fn__393000957", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_A_class, Simple: "fn__393000957", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000957_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000957_A_class.Info(); i.IsInstance = A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000957_A_InstanceOf; i.Init = A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000957_A_Init; i.Table = A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000957_A_members; jrt.RegisterGoType(A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000957_A_class, reflect.TypeFor[A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000957_A]()) }

func A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000966_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000966_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000966_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000966_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000966_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000966_A_fn_class)}; return nil }

var A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000966_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000966_A_invoke, New: A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000966_A_new, Get: A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000966_A_get}

var A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000966_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$define_BANG_$fn__393000891$fn__393000940$fn__393000966", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_A_class, Simple: "fn__393000966", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000966_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000966_A_class.Info(); i.IsInstance = A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000966_A_InstanceOf; i.Init = A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000966_A_Init; i.Table = A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000966_A_members; jrt.RegisterGoType(A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000966_A_class, reflect.TypeFor[A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000966_A]()) }

func A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000971_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000971_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000971_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000971_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000971_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000971_A_fn_class)}; return nil }

var A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000971_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000971_A_invoke, New: A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000971_A_new, Get: A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000971_A_get}

var A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000971_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$define_BANG_$fn__393000891$fn__393000940$fn__393000971", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_A_class, Simple: "fn__393000971", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000971_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000971_A_class.Info(); i.IsInstance = A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000971_A_InstanceOf; i.Init = A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000971_A_Init; i.Table = A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000971_A_members; jrt.RegisterGoType(A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000971_A_class, reflect.TypeFor[A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000940_fn__393000971_A]()) }

func A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000994_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000994_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000994_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000994_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000994_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000994_A_fn_class)}; return nil }

var A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000994_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000994_A_invoke, New: A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000994_A_new, Get: A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000994_A_get}

var A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000994_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$define_BANG_$fn__393000891$fn__393000994", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_define_BANG__fn__393000891_A_class, Simple: "fn__393000994", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000994_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000994_A_class.Info(); i.IsInstance = A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000994_A_InstanceOf; i.Init = A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000994_A_Init; i.Table = A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000994_A_members; jrt.RegisterGoType(A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000994_A_class, reflect.TypeFor[A_arbace_classes_interp_define_BANG__fn__393000891_fn__393000994_A]()) }

func A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_A_New()}; return nil }

func A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_A_fn_class)}; return nil }

var A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_A_invoke, New: A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_A_new, Get: A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_A_get}

var A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$define_BANG_$fn__393000891$iter__393000894__393000898", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_define_BANG__fn__393000891_A_class, Simple: "iter__393000894__393000898", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_A_class.Info(); i.IsInstance = A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_A_InstanceOf; i.Init = A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_A_Init; i.Table = A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_A_members; jrt.RegisterGoType(A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_A_class, reflect.TypeFor[A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_A]()) }

func A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_A_fn_class)}; return nil }

var A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_A_invoke, New: A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_A_new, Get: A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_A_get}

var A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$define_BANG_$fn__393000891$iter__393000894__393000898$fn__393000899", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_A_class, Simple: "fn__393000899", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_A_class.Info(); i.IsInstance = A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_A_InstanceOf; i.Init = A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_A_Init; i.Table = A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_A_members; jrt.RegisterGoType(A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_A_class, reflect.TypeFor[A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_A]()) }

func A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_fn__393000900_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_fn__393000900_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_fn__393000900_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_fn__393000900_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_fn__393000900_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_fn__393000900_A_fn_class)}; return nil }

var A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_fn__393000900_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_fn__393000900_A_invoke, New: A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_fn__393000900_A_new, Get: A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_fn__393000900_A_get}

var A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_fn__393000900_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$define_BANG_$fn__393000891$iter__393000894__393000898$fn__393000899$fn__393000900", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_A_class, Simple: "fn__393000900", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_fn__393000900_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_fn__393000900_A_class.Info(); i.IsInstance = A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_fn__393000900_A_InstanceOf; i.Init = A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_fn__393000900_A_Init; i.Table = A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_fn__393000900_A_members; jrt.RegisterGoType(A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_fn__393000900_A_class, reflect.TypeFor[A_arbace_classes_interp_define_BANG__fn__393000891_iter__393000894__393000898_fn__393000899_fn__393000900_A]()) }

func A_arbace_classes_interp_derived_body_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_derived_body_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_classes_interp_derived_body_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_derived_body_A_New()}; return nil }

func A_arbace_classes_interp_derived_body_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_derived_body_A_fn_class)}; return nil }

var A_arbace_classes_interp_derived_body_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_derived_body_A_invoke, New: A_arbace_classes_interp_derived_body_A_new, Get: A_arbace_classes_interp_derived_body_A_get}

var A_arbace_classes_interp_derived_body_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$derived_body", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "derived_body", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_derived_body_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_derived_body_A_class.Info(); i.IsInstance = A_arbace_classes_interp_derived_body_A_InstanceOf; i.Init = A_arbace_classes_interp_derived_body_A_Init; i.Table = A_arbace_classes_interp_derived_body_A_members; jrt.RegisterGoType(A_arbace_classes_interp_derived_body_A_class, reflect.TypeFor[A_arbace_classes_interp_derived_body_A]()) }

func A_arbace_classes_interp_derived_body_fn__393000655_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_derived_body_fn__393000655_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_interp_derived_body_fn__393000655_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_derived_body_fn__393000655_A_New()}; return nil }

func A_arbace_classes_interp_derived_body_fn__393000655_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_derived_body_fn__393000655_A_fn_class)}; return nil }

var A_arbace_classes_interp_derived_body_fn__393000655_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_derived_body_fn__393000655_A_invoke, New: A_arbace_classes_interp_derived_body_fn__393000655_A_new, Get: A_arbace_classes_interp_derived_body_fn__393000655_A_get}

var A_arbace_classes_interp_derived_body_fn__393000655_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$derived_body$fn__393000655", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_classes_interp_derived_body_A_class, Simple: "fn__393000655", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_derived_body_fn__393000655_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_derived_body_fn__393000655_A_class.Info(); i.IsInstance = A_arbace_classes_interp_derived_body_fn__393000655_A_InstanceOf; i.Init = A_arbace_classes_interp_derived_body_fn__393000655_A_Init; i.Table = A_arbace_classes_interp_derived_body_fn__393000655_A_members; jrt.RegisterGoType(A_arbace_classes_interp_derived_body_fn__393000655_A_class, reflect.TypeFor[A_arbace_classes_interp_derived_body_fn__393000655_A]()) }

func A_arbace_classes_interp_derived_body_iter__393000645__393000649_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_derived_body_iter__393000645__393000649_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_derived_body_iter__393000645__393000649_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_derived_body_iter__393000645__393000649_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_derived_body_iter__393000645__393000649_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_derived_body_iter__393000645__393000649_A_fn_class)}; return nil }

var A_arbace_classes_interp_derived_body_iter__393000645__393000649_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_derived_body_iter__393000645__393000649_A_invoke, New: A_arbace_classes_interp_derived_body_iter__393000645__393000649_A_new, Get: A_arbace_classes_interp_derived_body_iter__393000645__393000649_A_get}

var A_arbace_classes_interp_derived_body_iter__393000645__393000649_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$derived_body$iter__393000645__393000649", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_derived_body_A_class, Simple: "iter__393000645__393000649", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_derived_body_iter__393000645__393000649_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_derived_body_iter__393000645__393000649_A_class.Info(); i.IsInstance = A_arbace_classes_interp_derived_body_iter__393000645__393000649_A_InstanceOf; i.Init = A_arbace_classes_interp_derived_body_iter__393000645__393000649_A_Init; i.Table = A_arbace_classes_interp_derived_body_iter__393000645__393000649_A_members; jrt.RegisterGoType(A_arbace_classes_interp_derived_body_iter__393000645__393000649_A_class, reflect.TypeFor[A_arbace_classes_interp_derived_body_iter__393000645__393000649_A]()) }

func A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_A_fn_class)}; return nil }

var A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_A_invoke, New: A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_A_new, Get: A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_A_get}

var A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$derived_body$iter__393000645__393000649$fn__393000650", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_derived_body_iter__393000645__393000649_A_class, Simple: "fn__393000650", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_A_class.Info(); i.IsInstance = A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_A_InstanceOf; i.Init = A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_A_Init; i.Table = A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_A_members; jrt.RegisterGoType(A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_A_class, reflect.TypeFor[A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_A]()) }

func A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_fn__393000651_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_fn__393000651_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_fn__393000651_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_fn__393000651_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_fn__393000651_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_fn__393000651_A_fn_class)}; return nil }

var A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_fn__393000651_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_fn__393000651_A_invoke, New: A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_fn__393000651_A_new, Get: A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_fn__393000651_A_get}

var A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_fn__393000651_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$derived_body$iter__393000645__393000649$fn__393000650$fn__393000651", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_A_class, Simple: "fn__393000651", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_fn__393000651_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_fn__393000651_A_class.Info(); i.IsInstance = A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_fn__393000651_A_InstanceOf; i.Init = A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_fn__393000651_A_Init; i.Table = A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_fn__393000651_A_members; jrt.RegisterGoType(A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_fn__393000651_A_class, reflect.TypeFor[A_arbace_classes_interp_derived_body_iter__393000645__393000649_fn__393000650_fn__393000651_A]()) }

func A_arbace_classes_interp_derived_body_iter__393000660__393000664_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_derived_body_iter__393000660__393000664_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_derived_body_iter__393000660__393000664_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_derived_body_iter__393000660__393000664_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_derived_body_iter__393000660__393000664_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_derived_body_iter__393000660__393000664_A_fn_class)}; return nil }

var A_arbace_classes_interp_derived_body_iter__393000660__393000664_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_derived_body_iter__393000660__393000664_A_invoke, New: A_arbace_classes_interp_derived_body_iter__393000660__393000664_A_new, Get: A_arbace_classes_interp_derived_body_iter__393000660__393000664_A_get}

var A_arbace_classes_interp_derived_body_iter__393000660__393000664_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$derived_body$iter__393000660__393000664", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_derived_body_A_class, Simple: "iter__393000660__393000664", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_derived_body_iter__393000660__393000664_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_derived_body_iter__393000660__393000664_A_class.Info(); i.IsInstance = A_arbace_classes_interp_derived_body_iter__393000660__393000664_A_InstanceOf; i.Init = A_arbace_classes_interp_derived_body_iter__393000660__393000664_A_Init; i.Table = A_arbace_classes_interp_derived_body_iter__393000660__393000664_A_members; jrt.RegisterGoType(A_arbace_classes_interp_derived_body_iter__393000660__393000664_A_class, reflect.TypeFor[A_arbace_classes_interp_derived_body_iter__393000660__393000664_A]()) }

func A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_A_fn_class)}; return nil }

var A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_A_invoke, New: A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_A_new, Get: A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_A_get}

var A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$derived_body$iter__393000660__393000664$fn__393000665", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_derived_body_iter__393000660__393000664_A_class, Simple: "fn__393000665", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_A_class.Info(); i.IsInstance = A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_A_InstanceOf; i.Init = A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_A_Init; i.Table = A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_A_members; jrt.RegisterGoType(A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_A_class, reflect.TypeFor[A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_A]()) }

func A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_fn__393000666_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_fn__393000666_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_fn__393000666_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_fn__393000666_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_fn__393000666_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_fn__393000666_A_fn_class)}; return nil }

var A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_fn__393000666_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_fn__393000666_A_invoke, New: A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_fn__393000666_A_new, Get: A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_fn__393000666_A_get}

var A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_fn__393000666_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$derived_body$iter__393000660__393000664$fn__393000665$fn__393000666", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_A_class, Simple: "fn__393000666", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_fn__393000666_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_fn__393000666_A_class.Info(); i.IsInstance = A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_fn__393000666_A_InstanceOf; i.Init = A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_fn__393000666_A_Init; i.Table = A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_fn__393000666_A_members; jrt.RegisterGoType(A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_fn__393000666_A_class, reflect.TypeFor[A_arbace_classes_interp_derived_body_iter__393000660__393000664_fn__393000665_fn__393000666_A]()) }

func A_arbace_classes_interp_derived_body_iter__393000670__393000674_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_derived_body_iter__393000670__393000674_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_derived_body_iter__393000670__393000674_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_derived_body_iter__393000670__393000674_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_derived_body_iter__393000670__393000674_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_derived_body_iter__393000670__393000674_A_fn_class)}; return nil }

var A_arbace_classes_interp_derived_body_iter__393000670__393000674_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_derived_body_iter__393000670__393000674_A_invoke, New: A_arbace_classes_interp_derived_body_iter__393000670__393000674_A_new, Get: A_arbace_classes_interp_derived_body_iter__393000670__393000674_A_get}

var A_arbace_classes_interp_derived_body_iter__393000670__393000674_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$derived_body$iter__393000670__393000674", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_derived_body_A_class, Simple: "iter__393000670__393000674", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_derived_body_iter__393000670__393000674_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_derived_body_iter__393000670__393000674_A_class.Info(); i.IsInstance = A_arbace_classes_interp_derived_body_iter__393000670__393000674_A_InstanceOf; i.Init = A_arbace_classes_interp_derived_body_iter__393000670__393000674_A_Init; i.Table = A_arbace_classes_interp_derived_body_iter__393000670__393000674_A_members; jrt.RegisterGoType(A_arbace_classes_interp_derived_body_iter__393000670__393000674_A_class, reflect.TypeFor[A_arbace_classes_interp_derived_body_iter__393000670__393000674_A]()) }

func A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_A_fn_class)}; return nil }

var A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_A_invoke, New: A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_A_new, Get: A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_A_get}

var A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$derived_body$iter__393000670__393000674$fn__393000675", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_derived_body_iter__393000670__393000674_A_class, Simple: "fn__393000675", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_A_class.Info(); i.IsInstance = A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_A_InstanceOf; i.Init = A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_A_Init; i.Table = A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_A_members; jrt.RegisterGoType(A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_A_class, reflect.TypeFor[A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_A]()) }

func A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_fn__393000676_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_fn__393000676_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_fn__393000676_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_fn__393000676_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_fn__393000676_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_fn__393000676_A_fn_class)}; return nil }

var A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_fn__393000676_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_fn__393000676_A_invoke, New: A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_fn__393000676_A_new, Get: A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_fn__393000676_A_get}

var A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_fn__393000676_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$derived_body$iter__393000670__393000674$fn__393000675$fn__393000676", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_A_class, Simple: "fn__393000676", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_fn__393000676_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_fn__393000676_A_class.Info(); i.IsInstance = A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_fn__393000676_A_InstanceOf; i.Init = A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_fn__393000676_A_Init; i.Table = A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_fn__393000676_A_members; jrt.RegisterGoType(A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_fn__393000676_A_class, reflect.TypeFor[A_arbace_classes_interp_derived_body_iter__393000670__393000674_fn__393000675_fn__393000676_A]()) }

func A_arbace_classes_interp_desc__GT_class_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_desc__GT_class_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_desc__GT_class_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_desc__GT_class_A_New()}; return nil }

func A_arbace_classes_interp_desc__GT_class_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_desc__GT_class_A_fn_class)}; return nil }

var A_arbace_classes_interp_desc__GT_class_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_desc__GT_class_A_invoke, New: A_arbace_classes_interp_desc__GT_class_A_new, Get: A_arbace_classes_interp_desc__GT_class_A_get}

var A_arbace_classes_interp_desc__GT_class_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$desc__GT_class", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "desc__GT_class", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_desc__GT_class_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_desc__GT_class_A_class.Info(); i.IsInstance = A_arbace_classes_interp_desc__GT_class_A_InstanceOf; i.Init = A_arbace_classes_interp_desc__GT_class_A_Init; i.Table = A_arbace_classes_interp_desc__GT_class_A_members; jrt.RegisterGoType(A_arbace_classes_interp_desc__GT_class_A_class, reflect.TypeFor[A_arbace_classes_interp_desc__GT_class_A]()) }

func A_arbace_classes_interp_desc__GT_class_fn__393000025_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_desc__GT_class_fn__393000025_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_desc__GT_class_fn__393000025_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_desc__GT_class_fn__393000025_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_desc__GT_class_fn__393000025_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_desc__GT_class_fn__393000025_A_fn_class)}; return nil }

var A_arbace_classes_interp_desc__GT_class_fn__393000025_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_desc__GT_class_fn__393000025_A_invoke, New: A_arbace_classes_interp_desc__GT_class_fn__393000025_A_new, Get: A_arbace_classes_interp_desc__GT_class_fn__393000025_A_get}

var A_arbace_classes_interp_desc__GT_class_fn__393000025_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$desc__GT_class$fn__393000025", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_desc__GT_class_A_class, Simple: "fn__393000025", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_desc__GT_class_fn__393000025_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_desc__GT_class_fn__393000025_A_class.Info(); i.IsInstance = A_arbace_classes_interp_desc__GT_class_fn__393000025_A_InstanceOf; i.Init = A_arbace_classes_interp_desc__GT_class_fn__393000025_A_Init; i.Table = A_arbace_classes_interp_desc__GT_class_fn__393000025_A_members; jrt.RegisterGoType(A_arbace_classes_interp_desc__GT_class_fn__393000025_A_class, reflect.TypeFor[A_arbace_classes_interp_desc__GT_class_fn__393000025_A]()) }

func A_arbace_classes_interp_enum_arg_nodes_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_enum_arg_nodes_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_enum_arg_nodes_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_enum_arg_nodes_A_New()}; return nil }

func A_arbace_classes_interp_enum_arg_nodes_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_enum_arg_nodes_A_fn_class)}; return nil }

var A_arbace_classes_interp_enum_arg_nodes_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_enum_arg_nodes_A_invoke, New: A_arbace_classes_interp_enum_arg_nodes_A_new, Get: A_arbace_classes_interp_enum_arg_nodes_A_get}

var A_arbace_classes_interp_enum_arg_nodes_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$enum_arg_nodes", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "enum_arg_nodes", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_enum_arg_nodes_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_enum_arg_nodes_A_class.Info(); i.IsInstance = A_arbace_classes_interp_enum_arg_nodes_A_InstanceOf; i.Init = A_arbace_classes_interp_enum_arg_nodes_A_Init; i.Table = A_arbace_classes_interp_enum_arg_nodes_A_members; jrt.RegisterGoType(A_arbace_classes_interp_enum_arg_nodes_A_class, reflect.TypeFor[A_arbace_classes_interp_enum_arg_nodes_A]()) }

func A_arbace_classes_interp_eval393000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000004_A_New()}; return nil }

var A_arbace_classes_interp_eval393000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000004_A_new}

var A_arbace_classes_interp_eval393000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000004", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000004_A"})

func init() { i := A_arbace_classes_interp_eval393000004_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000004_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000004_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000004_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000004_A]()) }

func A_arbace_classes_interp_eval393000004_loading__1927001464__auto____393000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000004_loading__1927001464__auto____393000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_eval393000004_loading__1927001464__auto____393000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000004_loading__1927001464__auto____393000005_A_New()}; return nil }

func A_arbace_classes_interp_eval393000004_loading__1927001464__auto____393000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000004_loading__1927001464__auto____393000005_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000004_loading__1927001464__auto____393000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000004_loading__1927001464__auto____393000005_A_invoke, New: A_arbace_classes_interp_eval393000004_loading__1927001464__auto____393000005_A_new, Get: A_arbace_classes_interp_eval393000004_loading__1927001464__auto____393000005_A_get}

var A_arbace_classes_interp_eval393000004_loading__1927001464__auto____393000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000004$loading__1927001464__auto____393000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_eval393000004_A_class, Simple: "loading__1927001464__auto____393000005", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000004_loading__1927001464__auto____393000005_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000004_loading__1927001464__auto____393000005_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000004_loading__1927001464__auto____393000005_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000004_loading__1927001464__auto____393000005_A_Init; i.Table = A_arbace_classes_interp_eval393000004_loading__1927001464__auto____393000005_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000004_loading__1927001464__auto____393000005_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000004_loading__1927001464__auto____393000005_A]()) }

func A_arbace_classes_interp_eval393000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000008_A_New()}; return nil }

var A_arbace_classes_interp_eval393000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000008_A_new}

var A_arbace_classes_interp_eval393000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000008", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000008_A"})

func init() { i := A_arbace_classes_interp_eval393000008_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000008_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000008_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000008_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000008_A]()) }

func A_arbace_classes_interp_eval393000008_fn__393000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000008_fn__393000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_eval393000008_fn__393000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000008_fn__393000009_A_New()}; return nil }

func A_arbace_classes_interp_eval393000008_fn__393000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000008_fn__393000009_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000008_fn__393000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000008_fn__393000009_A_invoke, New: A_arbace_classes_interp_eval393000008_fn__393000009_A_new, Get: A_arbace_classes_interp_eval393000008_fn__393000009_A_get}

var A_arbace_classes_interp_eval393000008_fn__393000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000008$fn__393000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_eval393000008_A_class, Simple: "fn__393000009", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000008_fn__393000009_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000008_fn__393000009_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000008_fn__393000009_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000008_fn__393000009_A_Init; i.Table = A_arbace_classes_interp_eval393000008_fn__393000009_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000008_fn__393000009_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000008_fn__393000009_A]()) }

func A_arbace_classes_interp_eval393000075_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000075_A_New()}; return nil }

var A_arbace_classes_interp_eval393000075_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000075_A_new}

var A_arbace_classes_interp_eval393000075_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000075", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000075", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000075_A"})

func init() { i := A_arbace_classes_interp_eval393000075_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000075_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000075_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000075_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000075_A]()) }

func A_arbace_classes_interp_eval393000075_fn__393000076_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000075_fn__393000076_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000075_fn__393000076_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000075_fn__393000076_A_New()}; return nil }

func A_arbace_classes_interp_eval393000075_fn__393000076_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000075_fn__393000076_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000075_fn__393000076_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000075_fn__393000076_A_invoke, New: A_arbace_classes_interp_eval393000075_fn__393000076_A_new, Get: A_arbace_classes_interp_eval393000075_fn__393000076_A_get}

var A_arbace_classes_interp_eval393000075_fn__393000076_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000075$fn__393000076", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000075_A_class, Simple: "fn__393000076", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000075_fn__393000076_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000075_fn__393000076_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000075_fn__393000076_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000075_fn__393000076_A_Init; i.Table = A_arbace_classes_interp_eval393000075_fn__393000076_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000075_fn__393000076_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000075_fn__393000076_A]()) }

func A_arbace_classes_interp_eval393000080_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000080_A_New()}; return nil }

var A_arbace_classes_interp_eval393000080_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000080_A_new}

var A_arbace_classes_interp_eval393000080_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000080", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000080", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000080_A"})

func init() { i := A_arbace_classes_interp_eval393000080_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000080_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000080_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000080_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000080_A]()) }

func A_arbace_classes_interp_eval393000080_fn__393000081_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000080_fn__393000081_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000080_fn__393000081_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000080_fn__393000081_A_New()}; return nil }

func A_arbace_classes_interp_eval393000080_fn__393000081_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000080_fn__393000081_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000080_fn__393000081_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000080_fn__393000081_A_invoke, New: A_arbace_classes_interp_eval393000080_fn__393000081_A_new, Get: A_arbace_classes_interp_eval393000080_fn__393000081_A_get}

var A_arbace_classes_interp_eval393000080_fn__393000081_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000080$fn__393000081", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000080_A_class, Simple: "fn__393000081", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000080_fn__393000081_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000080_fn__393000081_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000080_fn__393000081_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000080_fn__393000081_A_Init; i.Table = A_arbace_classes_interp_eval393000080_fn__393000081_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000080_fn__393000081_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000080_fn__393000081_A]()) }

func A_arbace_classes_interp_eval393000084_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000084_A_New()}; return nil }

var A_arbace_classes_interp_eval393000084_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000084_A_new}

var A_arbace_classes_interp_eval393000084_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000084", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000084", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000084_A"})

func init() { i := A_arbace_classes_interp_eval393000084_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000084_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000084_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000084_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000084_A]()) }

func A_arbace_classes_interp_eval393000084_fn__393000085_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000084_fn__393000085_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000084_fn__393000085_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000084_fn__393000085_A_New()}; return nil }

func A_arbace_classes_interp_eval393000084_fn__393000085_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000084_fn__393000085_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000084_fn__393000085_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000084_fn__393000085_A_invoke, New: A_arbace_classes_interp_eval393000084_fn__393000085_A_new, Get: A_arbace_classes_interp_eval393000084_fn__393000085_A_get}

var A_arbace_classes_interp_eval393000084_fn__393000085_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000084$fn__393000085", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000084_A_class, Simple: "fn__393000085", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000084_fn__393000085_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000084_fn__393000085_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000084_fn__393000085_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000084_fn__393000085_A_Init; i.Table = A_arbace_classes_interp_eval393000084_fn__393000085_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000084_fn__393000085_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000084_fn__393000085_A]()) }

func A_arbace_classes_interp_eval393000088_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000088_A_New()}; return nil }

var A_arbace_classes_interp_eval393000088_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000088_A_new}

var A_arbace_classes_interp_eval393000088_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000088", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000088", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000088_A"})

func init() { i := A_arbace_classes_interp_eval393000088_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000088_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000088_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000088_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000088_A]()) }

func A_arbace_classes_interp_eval393000088_fn__393000089_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000088_fn__393000089_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000088_fn__393000089_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000088_fn__393000089_A_New()}; return nil }

func A_arbace_classes_interp_eval393000088_fn__393000089_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000088_fn__393000089_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000088_fn__393000089_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000088_fn__393000089_A_invoke, New: A_arbace_classes_interp_eval393000088_fn__393000089_A_new, Get: A_arbace_classes_interp_eval393000088_fn__393000089_A_get}

var A_arbace_classes_interp_eval393000088_fn__393000089_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000088$fn__393000089", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000088_A_class, Simple: "fn__393000089", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000088_fn__393000089_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000088_fn__393000089_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000088_fn__393000089_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000088_fn__393000089_A_Init; i.Table = A_arbace_classes_interp_eval393000088_fn__393000089_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000088_fn__393000089_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000088_fn__393000089_A]()) }

func A_arbace_classes_interp_eval393000092_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000092_A_New()}; return nil }

var A_arbace_classes_interp_eval393000092_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000092_A_new}

var A_arbace_classes_interp_eval393000092_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000092", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000092", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000092_A"})

func init() { i := A_arbace_classes_interp_eval393000092_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000092_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000092_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000092_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000092_A]()) }

func A_arbace_classes_interp_eval393000092_fn__393000093_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000092_fn__393000093_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000092_fn__393000093_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000092_fn__393000093_A_New()}; return nil }

func A_arbace_classes_interp_eval393000092_fn__393000093_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000092_fn__393000093_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000092_fn__393000093_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000092_fn__393000093_A_invoke, New: A_arbace_classes_interp_eval393000092_fn__393000093_A_new, Get: A_arbace_classes_interp_eval393000092_fn__393000093_A_get}

var A_arbace_classes_interp_eval393000092_fn__393000093_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000092$fn__393000093", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000092_A_class, Simple: "fn__393000093", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000092_fn__393000093_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000092_fn__393000093_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000092_fn__393000093_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000092_fn__393000093_A_Init; i.Table = A_arbace_classes_interp_eval393000092_fn__393000093_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000092_fn__393000093_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000092_fn__393000093_A]()) }

func A_arbace_classes_interp_eval393000096_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000096_A_New()}; return nil }

var A_arbace_classes_interp_eval393000096_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000096_A_new}

var A_arbace_classes_interp_eval393000096_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000096", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000096", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000096_A"})

func init() { i := A_arbace_classes_interp_eval393000096_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000096_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000096_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000096_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000096_A]()) }

func A_arbace_classes_interp_eval393000096_fn__393000097_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000096_fn__393000097_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000096_fn__393000097_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000096_fn__393000097_A_New()}; return nil }

func A_arbace_classes_interp_eval393000096_fn__393000097_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000096_fn__393000097_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000096_fn__393000097_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000096_fn__393000097_A_invoke, New: A_arbace_classes_interp_eval393000096_fn__393000097_A_new, Get: A_arbace_classes_interp_eval393000096_fn__393000097_A_get}

var A_arbace_classes_interp_eval393000096_fn__393000097_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000096$fn__393000097", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000096_A_class, Simple: "fn__393000097", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000096_fn__393000097_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000096_fn__393000097_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000096_fn__393000097_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000096_fn__393000097_A_Init; i.Table = A_arbace_classes_interp_eval393000096_fn__393000097_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000096_fn__393000097_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000096_fn__393000097_A]()) }

func A_arbace_classes_interp_eval393000104_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000104_A_New()}; return nil }

var A_arbace_classes_interp_eval393000104_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000104_A_new}

var A_arbace_classes_interp_eval393000104_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000104", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000104", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000104_A"})

func init() { i := A_arbace_classes_interp_eval393000104_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000104_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000104_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000104_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000104_A]()) }

func A_arbace_classes_interp_eval393000104_fn__393000105_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000104_fn__393000105_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000104_fn__393000105_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000104_fn__393000105_A_New()}; return nil }

func A_arbace_classes_interp_eval393000104_fn__393000105_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000104_fn__393000105_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000104_fn__393000105_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000104_fn__393000105_A_invoke, New: A_arbace_classes_interp_eval393000104_fn__393000105_A_new, Get: A_arbace_classes_interp_eval393000104_fn__393000105_A_get}

var A_arbace_classes_interp_eval393000104_fn__393000105_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000104$fn__393000105", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000104_A_class, Simple: "fn__393000105", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000104_fn__393000105_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000104_fn__393000105_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000104_fn__393000105_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000104_fn__393000105_A_Init; i.Table = A_arbace_classes_interp_eval393000104_fn__393000105_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000104_fn__393000105_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000104_fn__393000105_A]()) }

func A_arbace_classes_interp_eval393000108_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000108_A_New()}; return nil }

var A_arbace_classes_interp_eval393000108_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000108_A_new}

var A_arbace_classes_interp_eval393000108_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000108", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000108", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000108_A"})

func init() { i := A_arbace_classes_interp_eval393000108_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000108_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000108_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000108_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000108_A]()) }

func A_arbace_classes_interp_eval393000108_fn__393000109_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000108_fn__393000109_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000108_fn__393000109_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000108_fn__393000109_A_New()}; return nil }

func A_arbace_classes_interp_eval393000108_fn__393000109_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000108_fn__393000109_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000108_fn__393000109_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000108_fn__393000109_A_invoke, New: A_arbace_classes_interp_eval393000108_fn__393000109_A_new, Get: A_arbace_classes_interp_eval393000108_fn__393000109_A_get}

var A_arbace_classes_interp_eval393000108_fn__393000109_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000108$fn__393000109", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000108_A_class, Simple: "fn__393000109", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000108_fn__393000109_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000108_fn__393000109_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000108_fn__393000109_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000108_fn__393000109_A_Init; i.Table = A_arbace_classes_interp_eval393000108_fn__393000109_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000108_fn__393000109_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000108_fn__393000109_A]()) }

func A_arbace_classes_interp_eval393000112_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000112_A_New()}; return nil }

var A_arbace_classes_interp_eval393000112_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000112_A_new}

var A_arbace_classes_interp_eval393000112_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000112", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000112", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000112_A"})

func init() { i := A_arbace_classes_interp_eval393000112_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000112_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000112_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000112_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000112_A]()) }

func A_arbace_classes_interp_eval393000112_fn__393000113_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000112_fn__393000113_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000112_fn__393000113_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000112_fn__393000113_A_New()}; return nil }

func A_arbace_classes_interp_eval393000112_fn__393000113_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000112_fn__393000113_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000112_fn__393000113_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000112_fn__393000113_A_invoke, New: A_arbace_classes_interp_eval393000112_fn__393000113_A_new, Get: A_arbace_classes_interp_eval393000112_fn__393000113_A_get}

var A_arbace_classes_interp_eval393000112_fn__393000113_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000112$fn__393000113", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000112_A_class, Simple: "fn__393000113", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000112_fn__393000113_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000112_fn__393000113_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000112_fn__393000113_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000112_fn__393000113_A_Init; i.Table = A_arbace_classes_interp_eval393000112_fn__393000113_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000112_fn__393000113_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000112_fn__393000113_A]()) }

func A_arbace_classes_interp_eval393000116_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000116_A_New()}; return nil }

var A_arbace_classes_interp_eval393000116_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000116_A_new}

var A_arbace_classes_interp_eval393000116_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000116", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000116", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000116_A"})

func init() { i := A_arbace_classes_interp_eval393000116_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000116_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000116_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000116_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000116_A]()) }

func A_arbace_classes_interp_eval393000116_fn__393000117_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000116_fn__393000117_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000116_fn__393000117_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000116_fn__393000117_A_New()}; return nil }

func A_arbace_classes_interp_eval393000116_fn__393000117_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000116_fn__393000117_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000116_fn__393000117_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000116_fn__393000117_A_invoke, New: A_arbace_classes_interp_eval393000116_fn__393000117_A_new, Get: A_arbace_classes_interp_eval393000116_fn__393000117_A_get}

var A_arbace_classes_interp_eval393000116_fn__393000117_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000116$fn__393000117", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000116_A_class, Simple: "fn__393000117", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000116_fn__393000117_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000116_fn__393000117_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000116_fn__393000117_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000116_fn__393000117_A_Init; i.Table = A_arbace_classes_interp_eval393000116_fn__393000117_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000116_fn__393000117_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000116_fn__393000117_A]()) }

func A_arbace_classes_interp_eval393000120_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000120_A_New()}; return nil }

var A_arbace_classes_interp_eval393000120_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000120_A_new}

var A_arbace_classes_interp_eval393000120_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000120", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000120", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000120_A"})

func init() { i := A_arbace_classes_interp_eval393000120_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000120_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000120_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000120_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000120_A]()) }

func A_arbace_classes_interp_eval393000120_fn__393000121_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000120_fn__393000121_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000120_fn__393000121_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000120_fn__393000121_A_New()}; return nil }

func A_arbace_classes_interp_eval393000120_fn__393000121_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000120_fn__393000121_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000120_fn__393000121_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000120_fn__393000121_A_invoke, New: A_arbace_classes_interp_eval393000120_fn__393000121_A_new, Get: A_arbace_classes_interp_eval393000120_fn__393000121_A_get}

var A_arbace_classes_interp_eval393000120_fn__393000121_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000120$fn__393000121", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000120_A_class, Simple: "fn__393000121", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000120_fn__393000121_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000120_fn__393000121_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000120_fn__393000121_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000120_fn__393000121_A_Init; i.Table = A_arbace_classes_interp_eval393000120_fn__393000121_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000120_fn__393000121_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000120_fn__393000121_A]()) }

func A_arbace_classes_interp_eval393000124_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000124_A_New()}; return nil }

var A_arbace_classes_interp_eval393000124_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000124_A_new}

var A_arbace_classes_interp_eval393000124_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000124", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000124", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000124_A"})

func init() { i := A_arbace_classes_interp_eval393000124_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000124_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000124_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000124_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000124_A]()) }

func A_arbace_classes_interp_eval393000124_fn__393000125_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000124_fn__393000125_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000124_fn__393000125_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000124_fn__393000125_A_New()}; return nil }

func A_arbace_classes_interp_eval393000124_fn__393000125_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000124_fn__393000125_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000124_fn__393000125_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000124_fn__393000125_A_invoke, New: A_arbace_classes_interp_eval393000124_fn__393000125_A_new, Get: A_arbace_classes_interp_eval393000124_fn__393000125_A_get}

var A_arbace_classes_interp_eval393000124_fn__393000125_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000124$fn__393000125", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000124_A_class, Simple: "fn__393000125", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000124_fn__393000125_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000124_fn__393000125_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000124_fn__393000125_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000124_fn__393000125_A_Init; i.Table = A_arbace_classes_interp_eval393000124_fn__393000125_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000124_fn__393000125_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000124_fn__393000125_A]()) }

func A_arbace_classes_interp_eval393000128_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000128_A_New()}; return nil }

var A_arbace_classes_interp_eval393000128_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000128_A_new}

var A_arbace_classes_interp_eval393000128_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000128", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000128", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000128_A"})

func init() { i := A_arbace_classes_interp_eval393000128_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000128_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000128_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000128_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000128_A]()) }

func A_arbace_classes_interp_eval393000128_fn__393000129_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000128_fn__393000129_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000128_fn__393000129_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000128_fn__393000129_A_New()}; return nil }

func A_arbace_classes_interp_eval393000128_fn__393000129_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000128_fn__393000129_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000128_fn__393000129_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000128_fn__393000129_A_invoke, New: A_arbace_classes_interp_eval393000128_fn__393000129_A_new, Get: A_arbace_classes_interp_eval393000128_fn__393000129_A_get}

var A_arbace_classes_interp_eval393000128_fn__393000129_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000128$fn__393000129", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000128_A_class, Simple: "fn__393000129", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000128_fn__393000129_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000128_fn__393000129_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000128_fn__393000129_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000128_fn__393000129_A_Init; i.Table = A_arbace_classes_interp_eval393000128_fn__393000129_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000128_fn__393000129_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000128_fn__393000129_A]()) }

func A_arbace_classes_interp_eval393000132_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000132_A_New()}; return nil }

var A_arbace_classes_interp_eval393000132_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000132_A_new}

var A_arbace_classes_interp_eval393000132_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000132", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000132", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000132_A"})

func init() { i := A_arbace_classes_interp_eval393000132_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000132_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000132_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000132_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000132_A]()) }

func A_arbace_classes_interp_eval393000132_fn__393000133_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000132_fn__393000133_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000132_fn__393000133_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000132_fn__393000133_A_New()}; return nil }

func A_arbace_classes_interp_eval393000132_fn__393000133_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000132_fn__393000133_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000132_fn__393000133_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000132_fn__393000133_A_invoke, New: A_arbace_classes_interp_eval393000132_fn__393000133_A_new, Get: A_arbace_classes_interp_eval393000132_fn__393000133_A_get}

var A_arbace_classes_interp_eval393000132_fn__393000133_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000132$fn__393000133", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000132_A_class, Simple: "fn__393000133", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000132_fn__393000133_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000132_fn__393000133_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000132_fn__393000133_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000132_fn__393000133_A_Init; i.Table = A_arbace_classes_interp_eval393000132_fn__393000133_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000132_fn__393000133_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000132_fn__393000133_A]()) }

func A_arbace_classes_interp_eval393000142_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000142_A_New()}; return nil }

var A_arbace_classes_interp_eval393000142_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000142_A_new}

var A_arbace_classes_interp_eval393000142_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000142", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000142", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000142_A"})

func init() { i := A_arbace_classes_interp_eval393000142_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000142_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000142_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000142_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000142_A]()) }

func A_arbace_classes_interp_eval393000142_fn__393000143_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000142_fn__393000143_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000142_fn__393000143_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000142_fn__393000143_A_New()}; return nil }

func A_arbace_classes_interp_eval393000142_fn__393000143_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000142_fn__393000143_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000142_fn__393000143_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000142_fn__393000143_A_invoke, New: A_arbace_classes_interp_eval393000142_fn__393000143_A_new, Get: A_arbace_classes_interp_eval393000142_fn__393000143_A_get}

var A_arbace_classes_interp_eval393000142_fn__393000143_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000142$fn__393000143", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000142_A_class, Simple: "fn__393000143", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000142_fn__393000143_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000142_fn__393000143_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000142_fn__393000143_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000142_fn__393000143_A_Init; i.Table = A_arbace_classes_interp_eval393000142_fn__393000143_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000142_fn__393000143_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000142_fn__393000143_A]()) }

func A_arbace_classes_interp_eval393000148_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000148_A_New()}; return nil }

var A_arbace_classes_interp_eval393000148_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000148_A_new}

var A_arbace_classes_interp_eval393000148_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000148", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000148", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000148_A"})

func init() { i := A_arbace_classes_interp_eval393000148_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000148_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000148_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000148_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000148_A]()) }

func A_arbace_classes_interp_eval393000148_fn__393000149_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000148_fn__393000149_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000148_fn__393000149_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000148_fn__393000149_A_New()}; return nil }

func A_arbace_classes_interp_eval393000148_fn__393000149_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000148_fn__393000149_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000148_fn__393000149_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000148_fn__393000149_A_invoke, New: A_arbace_classes_interp_eval393000148_fn__393000149_A_new, Get: A_arbace_classes_interp_eval393000148_fn__393000149_A_get}

var A_arbace_classes_interp_eval393000148_fn__393000149_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000148$fn__393000149", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000148_A_class, Simple: "fn__393000149", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000148_fn__393000149_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000148_fn__393000149_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000148_fn__393000149_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000148_fn__393000149_A_Init; i.Table = A_arbace_classes_interp_eval393000148_fn__393000149_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000148_fn__393000149_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000148_fn__393000149_A]()) }

func A_arbace_classes_interp_eval393000152_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000152_A_New()}; return nil }

var A_arbace_classes_interp_eval393000152_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000152_A_new}

var A_arbace_classes_interp_eval393000152_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000152", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000152", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000152_A"})

func init() { i := A_arbace_classes_interp_eval393000152_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000152_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000152_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000152_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000152_A]()) }

func A_arbace_classes_interp_eval393000152_fn__393000153_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000152_fn__393000153_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000152_fn__393000153_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000152_fn__393000153_A_New()}; return nil }

func A_arbace_classes_interp_eval393000152_fn__393000153_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000152_fn__393000153_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000152_fn__393000153_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000152_fn__393000153_A_invoke, New: A_arbace_classes_interp_eval393000152_fn__393000153_A_new, Get: A_arbace_classes_interp_eval393000152_fn__393000153_A_get}

var A_arbace_classes_interp_eval393000152_fn__393000153_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000152$fn__393000153", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000152_A_class, Simple: "fn__393000153", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000152_fn__393000153_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000152_fn__393000153_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000152_fn__393000153_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000152_fn__393000153_A_Init; i.Table = A_arbace_classes_interp_eval393000152_fn__393000153_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000152_fn__393000153_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000152_fn__393000153_A]()) }

func A_arbace_classes_interp_eval393000156_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000156_A_New()}; return nil }

var A_arbace_classes_interp_eval393000156_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000156_A_new}

var A_arbace_classes_interp_eval393000156_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000156", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000156", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000156_A"})

func init() { i := A_arbace_classes_interp_eval393000156_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000156_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000156_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000156_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000156_A]()) }

func A_arbace_classes_interp_eval393000156_fn__393000157_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000156_fn__393000157_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000156_fn__393000157_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000156_fn__393000157_A_New()}; return nil }

func A_arbace_classes_interp_eval393000156_fn__393000157_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000156_fn__393000157_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000156_fn__393000157_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000156_fn__393000157_A_invoke, New: A_arbace_classes_interp_eval393000156_fn__393000157_A_new, Get: A_arbace_classes_interp_eval393000156_fn__393000157_A_get}

var A_arbace_classes_interp_eval393000156_fn__393000157_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000156$fn__393000157", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000156_A_class, Simple: "fn__393000157", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000156_fn__393000157_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000156_fn__393000157_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000156_fn__393000157_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000156_fn__393000157_A_Init; i.Table = A_arbace_classes_interp_eval393000156_fn__393000157_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000156_fn__393000157_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000156_fn__393000157_A]()) }

func A_arbace_classes_interp_eval393000160_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000160_A_New()}; return nil }

var A_arbace_classes_interp_eval393000160_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000160_A_new}

var A_arbace_classes_interp_eval393000160_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000160", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000160", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000160_A"})

func init() { i := A_arbace_classes_interp_eval393000160_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000160_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000160_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000160_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000160_A]()) }

func A_arbace_classes_interp_eval393000160_fn__393000161_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000160_fn__393000161_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000160_fn__393000161_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000160_fn__393000161_A_New()}; return nil }

func A_arbace_classes_interp_eval393000160_fn__393000161_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000160_fn__393000161_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000160_fn__393000161_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000160_fn__393000161_A_invoke, New: A_arbace_classes_interp_eval393000160_fn__393000161_A_new, Get: A_arbace_classes_interp_eval393000160_fn__393000161_A_get}

var A_arbace_classes_interp_eval393000160_fn__393000161_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000160$fn__393000161", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000160_A_class, Simple: "fn__393000161", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000160_fn__393000161_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000160_fn__393000161_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000160_fn__393000161_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000160_fn__393000161_A_Init; i.Table = A_arbace_classes_interp_eval393000160_fn__393000161_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000160_fn__393000161_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000160_fn__393000161_A]()) }

func A_arbace_classes_interp_eval393000168_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000168_A_New()}; return nil }

var A_arbace_classes_interp_eval393000168_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000168_A_new}

var A_arbace_classes_interp_eval393000168_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000168", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000168", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000168_A"})

func init() { i := A_arbace_classes_interp_eval393000168_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000168_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000168_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000168_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000168_A]()) }

func A_arbace_classes_interp_eval393000168_fn__393000169_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000168_fn__393000169_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000168_fn__393000169_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000168_fn__393000169_A_New()}; return nil }

func A_arbace_classes_interp_eval393000168_fn__393000169_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000168_fn__393000169_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000168_fn__393000169_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000168_fn__393000169_A_invoke, New: A_arbace_classes_interp_eval393000168_fn__393000169_A_new, Get: A_arbace_classes_interp_eval393000168_fn__393000169_A_get}

var A_arbace_classes_interp_eval393000168_fn__393000169_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000168$fn__393000169", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000168_A_class, Simple: "fn__393000169", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000168_fn__393000169_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000168_fn__393000169_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000168_fn__393000169_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000168_fn__393000169_A_Init; i.Table = A_arbace_classes_interp_eval393000168_fn__393000169_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000168_fn__393000169_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000168_fn__393000169_A]()) }

func A_arbace_classes_interp_eval393000172_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000172_A_New()}; return nil }

var A_arbace_classes_interp_eval393000172_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000172_A_new}

var A_arbace_classes_interp_eval393000172_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000172", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000172", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000172_A"})

func init() { i := A_arbace_classes_interp_eval393000172_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000172_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000172_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000172_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000172_A]()) }

func A_arbace_classes_interp_eval393000172_fn__393000173_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000172_fn__393000173_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000172_fn__393000173_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000172_fn__393000173_A_New()}; return nil }

func A_arbace_classes_interp_eval393000172_fn__393000173_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000172_fn__393000173_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000172_fn__393000173_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000172_fn__393000173_A_invoke, New: A_arbace_classes_interp_eval393000172_fn__393000173_A_new, Get: A_arbace_classes_interp_eval393000172_fn__393000173_A_get}

var A_arbace_classes_interp_eval393000172_fn__393000173_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000172$fn__393000173", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000172_A_class, Simple: "fn__393000173", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000172_fn__393000173_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000172_fn__393000173_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000172_fn__393000173_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000172_fn__393000173_A_Init; i.Table = A_arbace_classes_interp_eval393000172_fn__393000173_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000172_fn__393000173_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000172_fn__393000173_A]()) }

func A_arbace_classes_interp_eval393000176_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000176_A_New()}; return nil }

var A_arbace_classes_interp_eval393000176_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000176_A_new}

var A_arbace_classes_interp_eval393000176_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000176", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000176", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000176_A"})

func init() { i := A_arbace_classes_interp_eval393000176_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000176_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000176_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000176_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000176_A]()) }

func A_arbace_classes_interp_eval393000176_fn__393000177_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000176_fn__393000177_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000176_fn__393000177_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000176_fn__393000177_A_New()}; return nil }

func A_arbace_classes_interp_eval393000176_fn__393000177_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000176_fn__393000177_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000176_fn__393000177_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000176_fn__393000177_A_invoke, New: A_arbace_classes_interp_eval393000176_fn__393000177_A_new, Get: A_arbace_classes_interp_eval393000176_fn__393000177_A_get}

var A_arbace_classes_interp_eval393000176_fn__393000177_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000176$fn__393000177", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000176_A_class, Simple: "fn__393000177", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000176_fn__393000177_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000176_fn__393000177_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000176_fn__393000177_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000176_fn__393000177_A_Init; i.Table = A_arbace_classes_interp_eval393000176_fn__393000177_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000176_fn__393000177_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000176_fn__393000177_A]()) }

func A_arbace_classes_interp_eval393000176_fn__393000177_branch__393000178_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000176_fn__393000177_branch__393000178_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000176_fn__393000177_branch__393000178_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000176_fn__393000177_branch__393000178_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000176_fn__393000177_branch__393000178_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000176_fn__393000177_branch__393000178_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000176_fn__393000177_branch__393000178_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000176_fn__393000177_branch__393000178_A_invoke, New: A_arbace_classes_interp_eval393000176_fn__393000177_branch__393000178_A_new, Get: A_arbace_classes_interp_eval393000176_fn__393000177_branch__393000178_A_get}

var A_arbace_classes_interp_eval393000176_fn__393000177_branch__393000178_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000176$fn__393000177$branch__393000178", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_eval393000176_fn__393000177_A_class, Simple: "branch__393000178", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000176_fn__393000177_branch__393000178_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000176_fn__393000177_branch__393000178_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000176_fn__393000177_branch__393000178_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000176_fn__393000177_branch__393000178_A_Init; i.Table = A_arbace_classes_interp_eval393000176_fn__393000177_branch__393000178_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000176_fn__393000177_branch__393000178_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000176_fn__393000177_branch__393000178_A]()) }

func A_arbace_classes_interp_eval393000183_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000183_A_New()}; return nil }

var A_arbace_classes_interp_eval393000183_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000183_A_new}

var A_arbace_classes_interp_eval393000183_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000183", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000183", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000183_A"})

func init() { i := A_arbace_classes_interp_eval393000183_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000183_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000183_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000183_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000183_A]()) }

func A_arbace_classes_interp_eval393000183_fn__393000184_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000183_fn__393000184_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000183_fn__393000184_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000183_fn__393000184_A_New()}; return nil }

func A_arbace_classes_interp_eval393000183_fn__393000184_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000183_fn__393000184_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000183_fn__393000184_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000183_fn__393000184_A_invoke, New: A_arbace_classes_interp_eval393000183_fn__393000184_A_new, Get: A_arbace_classes_interp_eval393000183_fn__393000184_A_get}

var A_arbace_classes_interp_eval393000183_fn__393000184_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000183$fn__393000184", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000183_A_class, Simple: "fn__393000184", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000183_fn__393000184_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000183_fn__393000184_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000183_fn__393000184_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000183_fn__393000184_A_Init; i.Table = A_arbace_classes_interp_eval393000183_fn__393000184_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000183_fn__393000184_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000183_fn__393000184_A]()) }

func A_arbace_classes_interp_eval393000183_fn__393000184_fn__393000185_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000183_fn__393000184_fn__393000185_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000183_fn__393000184_fn__393000185_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000183_fn__393000184_fn__393000185_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_eval393000183_fn__393000184_fn__393000185_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000183_fn__393000184_fn__393000185_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000183_fn__393000184_fn__393000185_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000183_fn__393000184_fn__393000185_A_invoke, New: A_arbace_classes_interp_eval393000183_fn__393000184_fn__393000185_A_new, Get: A_arbace_classes_interp_eval393000183_fn__393000184_fn__393000185_A_get}

var A_arbace_classes_interp_eval393000183_fn__393000184_fn__393000185_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000183$fn__393000184$fn__393000185", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_eval393000183_fn__393000184_A_class, Simple: "fn__393000185", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000183_fn__393000184_fn__393000185_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000183_fn__393000184_fn__393000185_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000183_fn__393000184_fn__393000185_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000183_fn__393000184_fn__393000185_A_Init; i.Table = A_arbace_classes_interp_eval393000183_fn__393000184_fn__393000185_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000183_fn__393000184_fn__393000185_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000183_fn__393000184_fn__393000185_A]()) }

func A_arbace_classes_interp_eval393000211_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000211_A_New()}; return nil }

var A_arbace_classes_interp_eval393000211_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000211_A_new}

var A_arbace_classes_interp_eval393000211_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000211", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000211", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000211_A"})

func init() { i := A_arbace_classes_interp_eval393000211_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000211_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000211_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000211_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000211_A]()) }

func A_arbace_classes_interp_eval393000211_fn__393000212_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000211_fn__393000212_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000211_fn__393000212_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000211_fn__393000212_A_New()}; return nil }

func A_arbace_classes_interp_eval393000211_fn__393000212_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000211_fn__393000212_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000211_fn__393000212_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000211_fn__393000212_A_invoke, New: A_arbace_classes_interp_eval393000211_fn__393000212_A_new, Get: A_arbace_classes_interp_eval393000211_fn__393000212_A_get}

var A_arbace_classes_interp_eval393000211_fn__393000212_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000211$fn__393000212", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000211_A_class, Simple: "fn__393000212", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000211_fn__393000212_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000211_fn__393000212_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000211_fn__393000212_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000211_fn__393000212_A_Init; i.Table = A_arbace_classes_interp_eval393000211_fn__393000212_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000211_fn__393000212_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000211_fn__393000212_A]()) }

func A_arbace_classes_interp_eval393000215_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000215_A_New()}; return nil }

var A_arbace_classes_interp_eval393000215_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000215_A_new}

var A_arbace_classes_interp_eval393000215_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000215", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000215", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000215_A"})

func init() { i := A_arbace_classes_interp_eval393000215_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000215_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000215_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000215_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000215_A]()) }

func A_arbace_classes_interp_eval393000215_fn__393000216_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000215_fn__393000216_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000215_fn__393000216_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000215_fn__393000216_A_New()}; return nil }

func A_arbace_classes_interp_eval393000215_fn__393000216_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000215_fn__393000216_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000215_fn__393000216_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000215_fn__393000216_A_invoke, New: A_arbace_classes_interp_eval393000215_fn__393000216_A_new, Get: A_arbace_classes_interp_eval393000215_fn__393000216_A_get}

var A_arbace_classes_interp_eval393000215_fn__393000216_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000215$fn__393000216", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000215_A_class, Simple: "fn__393000216", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000215_fn__393000216_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000215_fn__393000216_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000215_fn__393000216_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000215_fn__393000216_A_Init; i.Table = A_arbace_classes_interp_eval393000215_fn__393000216_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000215_fn__393000216_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000215_fn__393000216_A]()) }

func A_arbace_classes_interp_eval393000219_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000219_A_New()}; return nil }

var A_arbace_classes_interp_eval393000219_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000219_A_new}

var A_arbace_classes_interp_eval393000219_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000219", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000219", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000219_A"})

func init() { i := A_arbace_classes_interp_eval393000219_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000219_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000219_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000219_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000219_A]()) }

func A_arbace_classes_interp_eval393000219_fn__393000220_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000219_fn__393000220_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000219_fn__393000220_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000219_fn__393000220_A_New()}; return nil }

func A_arbace_classes_interp_eval393000219_fn__393000220_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000219_fn__393000220_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000219_fn__393000220_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000219_fn__393000220_A_invoke, New: A_arbace_classes_interp_eval393000219_fn__393000220_A_new, Get: A_arbace_classes_interp_eval393000219_fn__393000220_A_get}

var A_arbace_classes_interp_eval393000219_fn__393000220_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000219$fn__393000220", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000219_A_class, Simple: "fn__393000220", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000219_fn__393000220_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000219_fn__393000220_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000219_fn__393000220_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000219_fn__393000220_A_Init; i.Table = A_arbace_classes_interp_eval393000219_fn__393000220_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000219_fn__393000220_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000219_fn__393000220_A]()) }

func A_arbace_classes_interp_eval393000223_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000223_A_New()}; return nil }

var A_arbace_classes_interp_eval393000223_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000223_A_new}

var A_arbace_classes_interp_eval393000223_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000223", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000223", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000223_A"})

func init() { i := A_arbace_classes_interp_eval393000223_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000223_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000223_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000223_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000223_A]()) }

func A_arbace_classes_interp_eval393000223_fn__393000224_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000223_fn__393000224_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000223_fn__393000224_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000223_fn__393000224_A_New()}; return nil }

func A_arbace_classes_interp_eval393000223_fn__393000224_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000223_fn__393000224_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000223_fn__393000224_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000223_fn__393000224_A_invoke, New: A_arbace_classes_interp_eval393000223_fn__393000224_A_new, Get: A_arbace_classes_interp_eval393000223_fn__393000224_A_get}

var A_arbace_classes_interp_eval393000223_fn__393000224_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000223$fn__393000224", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000223_A_class, Simple: "fn__393000224", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000223_fn__393000224_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000223_fn__393000224_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000223_fn__393000224_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000223_fn__393000224_A_Init; i.Table = A_arbace_classes_interp_eval393000223_fn__393000224_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000223_fn__393000224_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000223_fn__393000224_A]()) }

func A_arbace_classes_interp_eval393000227_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000227_A_New()}; return nil }

var A_arbace_classes_interp_eval393000227_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000227_A_new}

var A_arbace_classes_interp_eval393000227_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000227", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000227", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000227_A"})

func init() { i := A_arbace_classes_interp_eval393000227_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000227_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000227_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000227_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000227_A]()) }

func A_arbace_classes_interp_eval393000227_fn__393000228_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000227_fn__393000228_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000227_fn__393000228_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000227_fn__393000228_A_New()}; return nil }

func A_arbace_classes_interp_eval393000227_fn__393000228_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000227_fn__393000228_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000227_fn__393000228_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000227_fn__393000228_A_invoke, New: A_arbace_classes_interp_eval393000227_fn__393000228_A_new, Get: A_arbace_classes_interp_eval393000227_fn__393000228_A_get}

var A_arbace_classes_interp_eval393000227_fn__393000228_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000227$fn__393000228", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000227_A_class, Simple: "fn__393000228", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000227_fn__393000228_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000227_fn__393000228_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000227_fn__393000228_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000227_fn__393000228_A_Init; i.Table = A_arbace_classes_interp_eval393000227_fn__393000228_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000227_fn__393000228_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000227_fn__393000228_A]()) }

func A_arbace_classes_interp_eval393000227_fn__393000228_fn__393000229_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000227_fn__393000228_fn__393000229_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000227_fn__393000228_fn__393000229_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000227_fn__393000228_fn__393000229_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_eval393000227_fn__393000228_fn__393000229_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000227_fn__393000228_fn__393000229_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000227_fn__393000228_fn__393000229_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000227_fn__393000228_fn__393000229_A_invoke, New: A_arbace_classes_interp_eval393000227_fn__393000228_fn__393000229_A_new, Get: A_arbace_classes_interp_eval393000227_fn__393000228_fn__393000229_A_get}

var A_arbace_classes_interp_eval393000227_fn__393000228_fn__393000229_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000227$fn__393000228$fn__393000229", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000227_fn__393000228_A_class, Simple: "fn__393000229", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000227_fn__393000228_fn__393000229_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000227_fn__393000228_fn__393000229_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000227_fn__393000228_fn__393000229_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000227_fn__393000228_fn__393000229_A_Init; i.Table = A_arbace_classes_interp_eval393000227_fn__393000228_fn__393000229_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000227_fn__393000228_fn__393000229_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000227_fn__393000228_fn__393000229_A]()) }

func A_arbace_classes_interp_eval393000233_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000233_A_New()}; return nil }

var A_arbace_classes_interp_eval393000233_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000233_A_new}

var A_arbace_classes_interp_eval393000233_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000233", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000233", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000233_A"})

func init() { i := A_arbace_classes_interp_eval393000233_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000233_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000233_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000233_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000233_A]()) }

func A_arbace_classes_interp_eval393000233_fn__393000234_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000233_fn__393000234_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000233_fn__393000234_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000233_fn__393000234_A_New()}; return nil }

func A_arbace_classes_interp_eval393000233_fn__393000234_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000233_fn__393000234_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000233_fn__393000234_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000233_fn__393000234_A_invoke, New: A_arbace_classes_interp_eval393000233_fn__393000234_A_new, Get: A_arbace_classes_interp_eval393000233_fn__393000234_A_get}

var A_arbace_classes_interp_eval393000233_fn__393000234_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000233$fn__393000234", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000233_A_class, Simple: "fn__393000234", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000233_fn__393000234_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000233_fn__393000234_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000233_fn__393000234_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000233_fn__393000234_A_Init; i.Table = A_arbace_classes_interp_eval393000233_fn__393000234_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000233_fn__393000234_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000233_fn__393000234_A]()) }

func A_arbace_classes_interp_eval393000237_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000237_A_New()}; return nil }

var A_arbace_classes_interp_eval393000237_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000237_A_new}

var A_arbace_classes_interp_eval393000237_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000237", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000237", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000237_A"})

func init() { i := A_arbace_classes_interp_eval393000237_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000237_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000237_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000237_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000237_A]()) }

func A_arbace_classes_interp_eval393000237_fn__393000238_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000237_fn__393000238_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000237_fn__393000238_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000237_fn__393000238_A_New()}; return nil }

func A_arbace_classes_interp_eval393000237_fn__393000238_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000237_fn__393000238_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000237_fn__393000238_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000237_fn__393000238_A_invoke, New: A_arbace_classes_interp_eval393000237_fn__393000238_A_new, Get: A_arbace_classes_interp_eval393000237_fn__393000238_A_get}

var A_arbace_classes_interp_eval393000237_fn__393000238_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000237$fn__393000238", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000237_A_class, Simple: "fn__393000238", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000237_fn__393000238_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000237_fn__393000238_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000237_fn__393000238_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000237_fn__393000238_A_Init; i.Table = A_arbace_classes_interp_eval393000237_fn__393000238_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000237_fn__393000238_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000237_fn__393000238_A]()) }

func A_arbace_classes_interp_eval393000241_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000241_A_New()}; return nil }

var A_arbace_classes_interp_eval393000241_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000241_A_new}

var A_arbace_classes_interp_eval393000241_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000241", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000241", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000241_A"})

func init() { i := A_arbace_classes_interp_eval393000241_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000241_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000241_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000241_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000241_A]()) }

func A_arbace_classes_interp_eval393000241_fn__393000242_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000241_fn__393000242_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000241_fn__393000242_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000241_fn__393000242_A_New()}; return nil }

func A_arbace_classes_interp_eval393000241_fn__393000242_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000241_fn__393000242_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000241_fn__393000242_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000241_fn__393000242_A_invoke, New: A_arbace_classes_interp_eval393000241_fn__393000242_A_new, Get: A_arbace_classes_interp_eval393000241_fn__393000242_A_get}

var A_arbace_classes_interp_eval393000241_fn__393000242_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000241$fn__393000242", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000241_A_class, Simple: "fn__393000242", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000241_fn__393000242_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000241_fn__393000242_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000241_fn__393000242_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000241_fn__393000242_A_Init; i.Table = A_arbace_classes_interp_eval393000241_fn__393000242_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000241_fn__393000242_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000241_fn__393000242_A]()) }

func A_arbace_classes_interp_eval393000241_fn__393000242_conv__393000243_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000241_fn__393000242_conv__393000243_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000241_fn__393000242_conv__393000243_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000241_fn__393000242_conv__393000243_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000241_fn__393000242_conv__393000243_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000241_fn__393000242_conv__393000243_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000241_fn__393000242_conv__393000243_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000241_fn__393000242_conv__393000243_A_invoke, New: A_arbace_classes_interp_eval393000241_fn__393000242_conv__393000243_A_new, Get: A_arbace_classes_interp_eval393000241_fn__393000242_conv__393000243_A_get}

var A_arbace_classes_interp_eval393000241_fn__393000242_conv__393000243_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000241$fn__393000242$conv__393000243", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_eval393000241_fn__393000242_A_class, Simple: "conv__393000243", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000241_fn__393000242_conv__393000243_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000241_fn__393000242_conv__393000243_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000241_fn__393000242_conv__393000243_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000241_fn__393000242_conv__393000243_A_Init; i.Table = A_arbace_classes_interp_eval393000241_fn__393000242_conv__393000243_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000241_fn__393000242_conv__393000243_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000241_fn__393000242_conv__393000243_A]()) }

func A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000245_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000245_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000245_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000245_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000245_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000245_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000245_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000245_A_invoke, New: A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000245_A_new, Get: A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000245_A_get}

var A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000245_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000241$fn__393000242$fn__393000245", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_eval393000241_fn__393000242_A_class, Simple: "fn__393000245", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000245_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000245_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000245_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000245_A_Init; i.Table = A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000245_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000245_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000245_A]()) }

func A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000247_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000247_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000247_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000247_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000247_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000247_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000247_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000247_A_invoke, New: A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000247_A_new, Get: A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000247_A_get}

var A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000247_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000241$fn__393000242$fn__393000247", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_eval393000241_fn__393000242_A_class, Simple: "fn__393000247", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000247_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000247_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000247_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000247_A_Init; i.Table = A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000247_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000247_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000247_A]()) }

func A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000269_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000269_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000269_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000269_A_New()}; return nil }

func A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000269_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000269_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000269_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000269_A_invoke, New: A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000269_A_new, Get: A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000269_A_get}

var A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000269_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000241$fn__393000242$fn__393000269", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_eval393000241_fn__393000242_A_class, Simple: "fn__393000269", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000269_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000269_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000269_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000269_A_Init; i.Table = A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000269_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000269_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000269_A]()) }

func A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000275_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000275_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000275_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000275_A_New()}; return nil }

func A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000275_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000275_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000275_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000275_A_invoke, New: A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000275_A_new, Get: A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000275_A_get}

var A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000275_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000241$fn__393000242$fn__393000275", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_eval393000241_fn__393000242_A_class, Simple: "fn__393000275", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000275_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000275_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000275_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000275_A_Init; i.Table = A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000275_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000275_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000241_fn__393000242_fn__393000275_A]()) }

func A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_A_New()}; return nil }

func A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_A_invoke, New: A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_A_new, Get: A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_A_get}

var A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000241$fn__393000242$iter__393000249__393000255", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_eval393000241_fn__393000242_A_class, Simple: "iter__393000249__393000255", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_A_Init; i.Table = A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_A]()) }

func A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_A_invoke, New: A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_A_new, Get: A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_A_get}

var A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000241$fn__393000242$iter__393000249__393000255$fn__393000256", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_A_class, Simple: "fn__393000256", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_A_Init; i.Table = A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_A]()) }

func A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_A_invoke, New: A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_A_new, Get: A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_A_get}

var A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000241$fn__393000242$iter__393000249__393000255$fn__393000256$iter__393000251__393000260", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_A_class, Simple: "iter__393000251__393000260", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_A_Init; i.Table = A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_A]()) }

func A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_A_invoke, New: A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_A_new, Get: A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_A_get}

var A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000241$fn__393000242$iter__393000249__393000255$fn__393000256$iter__393000251__393000260$fn__393000261", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_A_class, Simple: "fn__393000261", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_A_Init; i.Table = A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_A]()) }

func A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_fn__393000262_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_fn__393000262_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_fn__393000262_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_fn__393000262_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_fn__393000262_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_fn__393000262_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_fn__393000262_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_fn__393000262_A_invoke, New: A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_fn__393000262_A_new, Get: A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_fn__393000262_A_get}

var A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_fn__393000262_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000241$fn__393000242$iter__393000249__393000255$fn__393000256$iter__393000251__393000260$fn__393000261$fn__393000262", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_A_class, Simple: "fn__393000262", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_fn__393000262_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_fn__393000262_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_fn__393000262_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_fn__393000262_A_Init; i.Table = A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_fn__393000262_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_fn__393000262_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000241_fn__393000242_iter__393000249__393000255_fn__393000256_iter__393000251__393000260_fn__393000261_fn__393000262_A]()) }

func A_arbace_classes_interp_eval393000282_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000282_A_New()}; return nil }

var A_arbace_classes_interp_eval393000282_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000282_A_new}

var A_arbace_classes_interp_eval393000282_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000282", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000282", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000282_A"})

func init() { i := A_arbace_classes_interp_eval393000282_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000282_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000282_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000282_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000282_A]()) }

func A_arbace_classes_interp_eval393000282_fn__393000283_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000282_fn__393000283_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000282_fn__393000283_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000282_fn__393000283_A_New()}; return nil }

func A_arbace_classes_interp_eval393000282_fn__393000283_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000282_fn__393000283_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000282_fn__393000283_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000282_fn__393000283_A_invoke, New: A_arbace_classes_interp_eval393000282_fn__393000283_A_new, Get: A_arbace_classes_interp_eval393000282_fn__393000283_A_get}

var A_arbace_classes_interp_eval393000282_fn__393000283_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000282$fn__393000283", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000282_A_class, Simple: "fn__393000283", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000282_fn__393000283_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000282_fn__393000283_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000282_fn__393000283_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000282_fn__393000283_A_Init; i.Table = A_arbace_classes_interp_eval393000282_fn__393000283_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000282_fn__393000283_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000282_fn__393000283_A]()) }

func A_arbace_classes_interp_eval393000286_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000286_A_New()}; return nil }

var A_arbace_classes_interp_eval393000286_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000286_A_new}

var A_arbace_classes_interp_eval393000286_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000286", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000286", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000286_A"})

func init() { i := A_arbace_classes_interp_eval393000286_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000286_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000286_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000286_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000286_A]()) }

func A_arbace_classes_interp_eval393000286_fn__393000287_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000286_fn__393000287_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000286_fn__393000287_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000286_fn__393000287_A_New()}; return nil }

func A_arbace_classes_interp_eval393000286_fn__393000287_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000286_fn__393000287_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000286_fn__393000287_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000286_fn__393000287_A_invoke, New: A_arbace_classes_interp_eval393000286_fn__393000287_A_new, Get: A_arbace_classes_interp_eval393000286_fn__393000287_A_get}

var A_arbace_classes_interp_eval393000286_fn__393000287_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000286$fn__393000287", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000286_A_class, Simple: "fn__393000287", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000286_fn__393000287_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000286_fn__393000287_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000286_fn__393000287_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000286_fn__393000287_A_Init; i.Table = A_arbace_classes_interp_eval393000286_fn__393000287_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000286_fn__393000287_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000286_fn__393000287_A]()) }

func A_arbace_classes_interp_eval393000298_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000298_A_New()}; return nil }

var A_arbace_classes_interp_eval393000298_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000298_A_new}

var A_arbace_classes_interp_eval393000298_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000298", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000298", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000298_A"})

func init() { i := A_arbace_classes_interp_eval393000298_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000298_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000298_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000298_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000298_A]()) }

func A_arbace_classes_interp_eval393000298_fn__393000299_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000298_fn__393000299_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000298_fn__393000299_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000298_fn__393000299_A_New()}; return nil }

func A_arbace_classes_interp_eval393000298_fn__393000299_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000298_fn__393000299_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000298_fn__393000299_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000298_fn__393000299_A_invoke, New: A_arbace_classes_interp_eval393000298_fn__393000299_A_new, Get: A_arbace_classes_interp_eval393000298_fn__393000299_A_get}

var A_arbace_classes_interp_eval393000298_fn__393000299_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000298$fn__393000299", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000298_A_class, Simple: "fn__393000299", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000298_fn__393000299_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000298_fn__393000299_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000298_fn__393000299_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000298_fn__393000299_A_Init; i.Table = A_arbace_classes_interp_eval393000298_fn__393000299_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000298_fn__393000299_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000298_fn__393000299_A]()) }

func A_arbace_classes_interp_eval393000298_fn__393000299_fn__393000302_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000298_fn__393000299_fn__393000302_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_eval393000298_fn__393000299_fn__393000302_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000298_fn__393000299_fn__393000302_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000298_fn__393000299_fn__393000302_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000298_fn__393000299_fn__393000302_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000298_fn__393000299_fn__393000302_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000298_fn__393000299_fn__393000302_A_invoke, New: A_arbace_classes_interp_eval393000298_fn__393000299_fn__393000302_A_new, Get: A_arbace_classes_interp_eval393000298_fn__393000299_fn__393000302_A_get}

var A_arbace_classes_interp_eval393000298_fn__393000299_fn__393000302_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000298$fn__393000299$fn__393000302", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_eval393000298_fn__393000299_A_class, Simple: "fn__393000302", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000298_fn__393000299_fn__393000302_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000298_fn__393000299_fn__393000302_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000298_fn__393000299_fn__393000302_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000298_fn__393000299_fn__393000302_A_Init; i.Table = A_arbace_classes_interp_eval393000298_fn__393000299_fn__393000302_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000298_fn__393000299_fn__393000302_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000298_fn__393000299_fn__393000302_A]()) }

func A_arbace_classes_interp_eval393000319_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000319_A_New()}; return nil }

var A_arbace_classes_interp_eval393000319_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000319_A_new}

var A_arbace_classes_interp_eval393000319_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000319", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000319", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000319_A"})

func init() { i := A_arbace_classes_interp_eval393000319_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000319_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000319_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000319_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000319_A]()) }

func A_arbace_classes_interp_eval393000319_fn__393000320_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000319_fn__393000320_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000319_fn__393000320_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000319_fn__393000320_A_New()}; return nil }

func A_arbace_classes_interp_eval393000319_fn__393000320_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000319_fn__393000320_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000319_fn__393000320_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000319_fn__393000320_A_invoke, New: A_arbace_classes_interp_eval393000319_fn__393000320_A_new, Get: A_arbace_classes_interp_eval393000319_fn__393000320_A_get}

var A_arbace_classes_interp_eval393000319_fn__393000320_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000319$fn__393000320", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000319_A_class, Simple: "fn__393000320", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000319_fn__393000320_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000319_fn__393000320_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000319_fn__393000320_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000319_fn__393000320_A_Init; i.Table = A_arbace_classes_interp_eval393000319_fn__393000320_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000319_fn__393000320_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000319_fn__393000320_A]()) }

func A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000324_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000324_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000324_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000324_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000324_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000324_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000324_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000324_A_invoke, New: A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000324_A_new, Get: A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000324_A_get}

var A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000324_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000319$fn__393000320$fn__393000324", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_eval393000319_fn__393000320_A_class, Simple: "fn__393000324", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000324_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000324_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000324_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000324_A_Init; i.Table = A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000324_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000324_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000324_A]()) }

func A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000327_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000327_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000327_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000327_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000327_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000327_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000327_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000327_A_invoke, New: A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000327_A_new, Get: A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000327_A_get}

var A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000327_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000319$fn__393000320$fn__393000327", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000319_fn__393000320_A_class, Simple: "fn__393000327", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000327_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000327_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000327_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000327_A_Init; i.Table = A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000327_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000327_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000327_A]()) }

func A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000329_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000329_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000329_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000329_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000329_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000329_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000329_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000329_A_invoke, New: A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000329_A_new, Get: A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000329_A_get}

var A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000329_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000319$fn__393000320$fn__393000329", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000319_fn__393000320_A_class, Simple: "fn__393000329", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000329_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000329_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000329_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000329_A_Init; i.Table = A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000329_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000329_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000319_fn__393000320_fn__393000329_A]()) }

func A_arbace_classes_interp_eval393000341_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000341_A_New()}; return nil }

var A_arbace_classes_interp_eval393000341_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000341_A_new}

var A_arbace_classes_interp_eval393000341_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000341", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000341", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000341_A"})

func init() { i := A_arbace_classes_interp_eval393000341_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000341_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000341_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000341_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000341_A]()) }

func A_arbace_classes_interp_eval393000341_fn__393000342_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000341_fn__393000342_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000341_fn__393000342_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000341_fn__393000342_A_New()}; return nil }

func A_arbace_classes_interp_eval393000341_fn__393000342_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000341_fn__393000342_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000341_fn__393000342_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000341_fn__393000342_A_invoke, New: A_arbace_classes_interp_eval393000341_fn__393000342_A_new, Get: A_arbace_classes_interp_eval393000341_fn__393000342_A_get}

var A_arbace_classes_interp_eval393000341_fn__393000342_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000341$fn__393000342", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000341_A_class, Simple: "fn__393000342", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000341_fn__393000342_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000341_fn__393000342_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000341_fn__393000342_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000341_fn__393000342_A_Init; i.Table = A_arbace_classes_interp_eval393000341_fn__393000342_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000341_fn__393000342_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000341_fn__393000342_A]()) }

func A_arbace_classes_interp_eval393000348_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000348_A_New()}; return nil }

var A_arbace_classes_interp_eval393000348_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000348_A_new}

var A_arbace_classes_interp_eval393000348_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000348", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000348", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000348_A"})

func init() { i := A_arbace_classes_interp_eval393000348_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000348_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000348_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000348_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000348_A]()) }

func A_arbace_classes_interp_eval393000348_fn__393000349_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000348_fn__393000349_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000348_fn__393000349_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000348_fn__393000349_A_New()}; return nil }

func A_arbace_classes_interp_eval393000348_fn__393000349_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000348_fn__393000349_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000348_fn__393000349_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000348_fn__393000349_A_invoke, New: A_arbace_classes_interp_eval393000348_fn__393000349_A_new, Get: A_arbace_classes_interp_eval393000348_fn__393000349_A_get}

var A_arbace_classes_interp_eval393000348_fn__393000349_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000348$fn__393000349", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000348_A_class, Simple: "fn__393000349", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000348_fn__393000349_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000348_fn__393000349_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000348_fn__393000349_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000348_fn__393000349_A_Init; i.Table = A_arbace_classes_interp_eval393000348_fn__393000349_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000348_fn__393000349_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000348_fn__393000349_A]()) }

func A_arbace_classes_interp_eval393000355_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000355_A_New()}; return nil }

var A_arbace_classes_interp_eval393000355_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000355_A_new}

var A_arbace_classes_interp_eval393000355_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000355", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000355", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000355_A"})

func init() { i := A_arbace_classes_interp_eval393000355_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000355_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000355_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000355_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000355_A]()) }

func A_arbace_classes_interp_eval393000355_fn__393000356_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000355_fn__393000356_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000355_fn__393000356_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000355_fn__393000356_A_New()}; return nil }

func A_arbace_classes_interp_eval393000355_fn__393000356_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000355_fn__393000356_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000355_fn__393000356_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000355_fn__393000356_A_invoke, New: A_arbace_classes_interp_eval393000355_fn__393000356_A_new, Get: A_arbace_classes_interp_eval393000355_fn__393000356_A_get}

var A_arbace_classes_interp_eval393000355_fn__393000356_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000355$fn__393000356", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000355_A_class, Simple: "fn__393000356", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000355_fn__393000356_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000355_fn__393000356_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000355_fn__393000356_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000355_fn__393000356_A_Init; i.Table = A_arbace_classes_interp_eval393000355_fn__393000356_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000355_fn__393000356_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000355_fn__393000356_A]()) }

func A_arbace_classes_interp_eval393000359_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000359_A_New()}; return nil }

var A_arbace_classes_interp_eval393000359_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000359_A_new}

var A_arbace_classes_interp_eval393000359_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000359", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000359", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000359_A"})

func init() { i := A_arbace_classes_interp_eval393000359_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000359_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000359_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000359_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000359_A]()) }

func A_arbace_classes_interp_eval393000359_fn__393000360_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000359_fn__393000360_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000359_fn__393000360_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000359_fn__393000360_A_New()}; return nil }

func A_arbace_classes_interp_eval393000359_fn__393000360_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000359_fn__393000360_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000359_fn__393000360_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000359_fn__393000360_A_invoke, New: A_arbace_classes_interp_eval393000359_fn__393000360_A_new, Get: A_arbace_classes_interp_eval393000359_fn__393000360_A_get}

var A_arbace_classes_interp_eval393000359_fn__393000360_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000359$fn__393000360", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000359_A_class, Simple: "fn__393000360", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000359_fn__393000360_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000359_fn__393000360_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000359_fn__393000360_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000359_fn__393000360_A_Init; i.Table = A_arbace_classes_interp_eval393000359_fn__393000360_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000359_fn__393000360_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000359_fn__393000360_A]()) }

func A_arbace_classes_interp_eval393000363_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000363_A_New()}; return nil }

var A_arbace_classes_interp_eval393000363_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000363_A_new}

var A_arbace_classes_interp_eval393000363_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000363", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000363", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000363_A"})

func init() { i := A_arbace_classes_interp_eval393000363_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000363_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000363_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000363_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000363_A]()) }

func A_arbace_classes_interp_eval393000363_fn__393000364_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000363_fn__393000364_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000363_fn__393000364_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000363_fn__393000364_A_New()}; return nil }

func A_arbace_classes_interp_eval393000363_fn__393000364_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000363_fn__393000364_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000363_fn__393000364_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000363_fn__393000364_A_invoke, New: A_arbace_classes_interp_eval393000363_fn__393000364_A_new, Get: A_arbace_classes_interp_eval393000363_fn__393000364_A_get}

var A_arbace_classes_interp_eval393000363_fn__393000364_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000363$fn__393000364", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000363_A_class, Simple: "fn__393000364", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000363_fn__393000364_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000363_fn__393000364_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000363_fn__393000364_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000363_fn__393000364_A_Init; i.Table = A_arbace_classes_interp_eval393000363_fn__393000364_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000363_fn__393000364_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000363_fn__393000364_A]()) }

func A_arbace_classes_interp_eval393000368_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000368_A_New()}; return nil }

var A_arbace_classes_interp_eval393000368_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000368_A_new}

var A_arbace_classes_interp_eval393000368_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000368", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000368", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000368_A"})

func init() { i := A_arbace_classes_interp_eval393000368_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000368_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000368_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000368_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000368_A]()) }

func A_arbace_classes_interp_eval393000368_fn__393000369_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000368_fn__393000369_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000368_fn__393000369_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000368_fn__393000369_A_New()}; return nil }

func A_arbace_classes_interp_eval393000368_fn__393000369_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000368_fn__393000369_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000368_fn__393000369_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000368_fn__393000369_A_invoke, New: A_arbace_classes_interp_eval393000368_fn__393000369_A_new, Get: A_arbace_classes_interp_eval393000368_fn__393000369_A_get}

var A_arbace_classes_interp_eval393000368_fn__393000369_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000368$fn__393000369", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000368_A_class, Simple: "fn__393000369", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000368_fn__393000369_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000368_fn__393000369_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000368_fn__393000369_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000368_fn__393000369_A_Init; i.Table = A_arbace_classes_interp_eval393000368_fn__393000369_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000368_fn__393000369_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000368_fn__393000369_A]()) }

func A_arbace_classes_interp_eval393000368_fn__393000369_fn__393000370_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000368_fn__393000369_fn__393000370_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000368_fn__393000369_fn__393000370_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000368_fn__393000369_fn__393000370_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_eval393000368_fn__393000369_fn__393000370_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000368_fn__393000369_fn__393000370_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000368_fn__393000369_fn__393000370_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000368_fn__393000369_fn__393000370_A_invoke, New: A_arbace_classes_interp_eval393000368_fn__393000369_fn__393000370_A_new, Get: A_arbace_classes_interp_eval393000368_fn__393000369_fn__393000370_A_get}

var A_arbace_classes_interp_eval393000368_fn__393000369_fn__393000370_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000368$fn__393000369$fn__393000370", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_eval393000368_fn__393000369_A_class, Simple: "fn__393000370", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000368_fn__393000369_fn__393000370_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000368_fn__393000369_fn__393000370_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000368_fn__393000369_fn__393000370_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000368_fn__393000369_fn__393000370_A_Init; i.Table = A_arbace_classes_interp_eval393000368_fn__393000369_fn__393000370_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000368_fn__393000369_fn__393000370_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000368_fn__393000369_fn__393000370_A]()) }

func A_arbace_classes_interp_eval393000374_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000374_A_New()}; return nil }

var A_arbace_classes_interp_eval393000374_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000374_A_new}

var A_arbace_classes_interp_eval393000374_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000374", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000374", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000374_A"})

func init() { i := A_arbace_classes_interp_eval393000374_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000374_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000374_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000374_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000374_A]()) }

func A_arbace_classes_interp_eval393000374_fn__393000375_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000374_fn__393000375_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000374_fn__393000375_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000374_fn__393000375_A_New()}; return nil }

func A_arbace_classes_interp_eval393000374_fn__393000375_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000374_fn__393000375_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000374_fn__393000375_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000374_fn__393000375_A_invoke, New: A_arbace_classes_interp_eval393000374_fn__393000375_A_new, Get: A_arbace_classes_interp_eval393000374_fn__393000375_A_get}

var A_arbace_classes_interp_eval393000374_fn__393000375_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000374$fn__393000375", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000374_A_class, Simple: "fn__393000375", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000374_fn__393000375_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000374_fn__393000375_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000374_fn__393000375_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000374_fn__393000375_A_Init; i.Table = A_arbace_classes_interp_eval393000374_fn__393000375_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000374_fn__393000375_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000374_fn__393000375_A]()) }

func A_arbace_classes_interp_eval393000379_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000379_A_New()}; return nil }

var A_arbace_classes_interp_eval393000379_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000379_A_new}

var A_arbace_classes_interp_eval393000379_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000379", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000379", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000379_A"})

func init() { i := A_arbace_classes_interp_eval393000379_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000379_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000379_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000379_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000379_A]()) }

func A_arbace_classes_interp_eval393000379_fn__393000380_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000379_fn__393000380_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000379_fn__393000380_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000379_fn__393000380_A_New()}; return nil }

func A_arbace_classes_interp_eval393000379_fn__393000380_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000379_fn__393000380_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000379_fn__393000380_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000379_fn__393000380_A_invoke, New: A_arbace_classes_interp_eval393000379_fn__393000380_A_new, Get: A_arbace_classes_interp_eval393000379_fn__393000380_A_get}

var A_arbace_classes_interp_eval393000379_fn__393000380_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000379$fn__393000380", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000379_A_class, Simple: "fn__393000380", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000379_fn__393000380_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000379_fn__393000380_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000379_fn__393000380_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000379_fn__393000380_A_Init; i.Table = A_arbace_classes_interp_eval393000379_fn__393000380_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000379_fn__393000380_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000379_fn__393000380_A]()) }

func A_arbace_classes_interp_eval393000379_fn__393000380_fn__393000381_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000379_fn__393000380_fn__393000381_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000379_fn__393000380_fn__393000381_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000379_fn__393000380_fn__393000381_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_eval393000379_fn__393000380_fn__393000381_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000379_fn__393000380_fn__393000381_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000379_fn__393000380_fn__393000381_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000379_fn__393000380_fn__393000381_A_invoke, New: A_arbace_classes_interp_eval393000379_fn__393000380_fn__393000381_A_new, Get: A_arbace_classes_interp_eval393000379_fn__393000380_fn__393000381_A_get}

var A_arbace_classes_interp_eval393000379_fn__393000380_fn__393000381_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000379$fn__393000380$fn__393000381", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_eval393000379_fn__393000380_A_class, Simple: "fn__393000381", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000379_fn__393000380_fn__393000381_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000379_fn__393000380_fn__393000381_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000379_fn__393000380_fn__393000381_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000379_fn__393000380_fn__393000381_A_Init; i.Table = A_arbace_classes_interp_eval393000379_fn__393000380_fn__393000381_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000379_fn__393000380_fn__393000381_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000379_fn__393000380_fn__393000381_A]()) }

func A_arbace_classes_interp_eval393000386_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000386_A_New()}; return nil }

var A_arbace_classes_interp_eval393000386_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000386_A_new}

var A_arbace_classes_interp_eval393000386_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000386", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000386", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000386_A"})

func init() { i := A_arbace_classes_interp_eval393000386_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000386_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000386_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000386_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000386_A]()) }

func A_arbace_classes_interp_eval393000386_fn__393000387_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000386_fn__393000387_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000386_fn__393000387_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000386_fn__393000387_A_New()}; return nil }

func A_arbace_classes_interp_eval393000386_fn__393000387_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000386_fn__393000387_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000386_fn__393000387_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000386_fn__393000387_A_invoke, New: A_arbace_classes_interp_eval393000386_fn__393000387_A_new, Get: A_arbace_classes_interp_eval393000386_fn__393000387_A_get}

var A_arbace_classes_interp_eval393000386_fn__393000387_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000386$fn__393000387", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000386_A_class, Simple: "fn__393000387", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000386_fn__393000387_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000386_fn__393000387_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000386_fn__393000387_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000386_fn__393000387_A_Init; i.Table = A_arbace_classes_interp_eval393000386_fn__393000387_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000386_fn__393000387_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000386_fn__393000387_A]()) }

func A_arbace_classes_interp_eval393000386_fn__393000387_fn__393000388_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000386_fn__393000387_fn__393000388_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000386_fn__393000387_fn__393000388_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000386_fn__393000387_fn__393000388_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000386_fn__393000387_fn__393000388_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000386_fn__393000387_fn__393000388_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000386_fn__393000387_fn__393000388_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000386_fn__393000387_fn__393000388_A_invoke, New: A_arbace_classes_interp_eval393000386_fn__393000387_fn__393000388_A_new, Get: A_arbace_classes_interp_eval393000386_fn__393000387_fn__393000388_A_get}

var A_arbace_classes_interp_eval393000386_fn__393000387_fn__393000388_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000386$fn__393000387$fn__393000388", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_eval393000386_fn__393000387_A_class, Simple: "fn__393000388", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000386_fn__393000387_fn__393000388_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000386_fn__393000387_fn__393000388_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000386_fn__393000387_fn__393000388_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000386_fn__393000387_fn__393000388_A_Init; i.Table = A_arbace_classes_interp_eval393000386_fn__393000387_fn__393000388_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000386_fn__393000387_fn__393000388_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000386_fn__393000387_fn__393000388_A]()) }

func A_arbace_classes_interp_eval393000392_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000392_A_New()}; return nil }

var A_arbace_classes_interp_eval393000392_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000392_A_new}

var A_arbace_classes_interp_eval393000392_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000392", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000392", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000392_A"})

func init() { i := A_arbace_classes_interp_eval393000392_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000392_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000392_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000392_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000392_A]()) }

func A_arbace_classes_interp_eval393000392_fn__393000393_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000392_fn__393000393_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000392_fn__393000393_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000392_fn__393000393_A_New()}; return nil }

func A_arbace_classes_interp_eval393000392_fn__393000393_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000392_fn__393000393_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000392_fn__393000393_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000392_fn__393000393_A_invoke, New: A_arbace_classes_interp_eval393000392_fn__393000393_A_new, Get: A_arbace_classes_interp_eval393000392_fn__393000393_A_get}

var A_arbace_classes_interp_eval393000392_fn__393000393_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000392$fn__393000393", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000392_A_class, Simple: "fn__393000393", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000392_fn__393000393_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000392_fn__393000393_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000392_fn__393000393_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000392_fn__393000393_A_Init; i.Table = A_arbace_classes_interp_eval393000392_fn__393000393_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000392_fn__393000393_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000392_fn__393000393_A]()) }

func A_arbace_classes_interp_eval393000396_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000396_A_New()}; return nil }

var A_arbace_classes_interp_eval393000396_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000396_A_new}

var A_arbace_classes_interp_eval393000396_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000396", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000396", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000396_A"})

func init() { i := A_arbace_classes_interp_eval393000396_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000396_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000396_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000396_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000396_A]()) }

func A_arbace_classes_interp_eval393000396_fn__393000397_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000396_fn__393000397_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000396_fn__393000397_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000396_fn__393000397_A_New()}; return nil }

func A_arbace_classes_interp_eval393000396_fn__393000397_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000396_fn__393000397_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000396_fn__393000397_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000396_fn__393000397_A_invoke, New: A_arbace_classes_interp_eval393000396_fn__393000397_A_new, Get: A_arbace_classes_interp_eval393000396_fn__393000397_A_get}

var A_arbace_classes_interp_eval393000396_fn__393000397_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000396$fn__393000397", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000396_A_class, Simple: "fn__393000397", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000396_fn__393000397_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000396_fn__393000397_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000396_fn__393000397_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000396_fn__393000397_A_Init; i.Table = A_arbace_classes_interp_eval393000396_fn__393000397_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000396_fn__393000397_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000396_fn__393000397_A]()) }

func A_arbace_classes_interp_eval393000400_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000400_A_New()}; return nil }

var A_arbace_classes_interp_eval393000400_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000400_A_new}

var A_arbace_classes_interp_eval393000400_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000400", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000400", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000400_A"})

func init() { i := A_arbace_classes_interp_eval393000400_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000400_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000400_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000400_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000400_A]()) }

func A_arbace_classes_interp_eval393000400_fn__393000401_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000400_fn__393000401_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000400_fn__393000401_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000400_fn__393000401_A_New()}; return nil }

func A_arbace_classes_interp_eval393000400_fn__393000401_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000400_fn__393000401_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000400_fn__393000401_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000400_fn__393000401_A_invoke, New: A_arbace_classes_interp_eval393000400_fn__393000401_A_new, Get: A_arbace_classes_interp_eval393000400_fn__393000401_A_get}

var A_arbace_classes_interp_eval393000400_fn__393000401_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000400$fn__393000401", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000400_A_class, Simple: "fn__393000401", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000400_fn__393000401_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000400_fn__393000401_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000400_fn__393000401_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000400_fn__393000401_A_Init; i.Table = A_arbace_classes_interp_eval393000400_fn__393000401_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000400_fn__393000401_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000400_fn__393000401_A]()) }

func A_arbace_classes_interp_eval393000404_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000404_A_New()}; return nil }

var A_arbace_classes_interp_eval393000404_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000404_A_new}

var A_arbace_classes_interp_eval393000404_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000404", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000404", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000404_A"})

func init() { i := A_arbace_classes_interp_eval393000404_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000404_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000404_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000404_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000404_A]()) }

func A_arbace_classes_interp_eval393000404_fn__393000405_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000404_fn__393000405_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000404_fn__393000405_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000404_fn__393000405_A_New()}; return nil }

func A_arbace_classes_interp_eval393000404_fn__393000405_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000404_fn__393000405_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000404_fn__393000405_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000404_fn__393000405_A_invoke, New: A_arbace_classes_interp_eval393000404_fn__393000405_A_new, Get: A_arbace_classes_interp_eval393000404_fn__393000405_A_get}

var A_arbace_classes_interp_eval393000404_fn__393000405_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000404$fn__393000405", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000404_A_class, Simple: "fn__393000405", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000404_fn__393000405_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000404_fn__393000405_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000404_fn__393000405_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000404_fn__393000405_A_Init; i.Table = A_arbace_classes_interp_eval393000404_fn__393000405_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000404_fn__393000405_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000404_fn__393000405_A]()) }

func A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000406_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000406_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000406_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000406_A_New()}; return nil }

func A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000406_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000406_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000406_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000406_A_invoke, New: A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000406_A_new, Get: A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000406_A_get}

var A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000406_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000404$fn__393000405$fn__393000406", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_eval393000404_fn__393000405_A_class, Simple: "fn__393000406", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000406_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000406_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000406_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000406_A_Init; i.Table = A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000406_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000406_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000406_A]()) }

func A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000408_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000408_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000408_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000408_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000408_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000408_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000408_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000408_A_invoke, New: A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000408_A_new, Get: A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000408_A_get}

var A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000408_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000404$fn__393000405$fn__393000408", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_eval393000404_fn__393000405_A_class, Simple: "fn__393000408", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000408_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000408_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000408_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000408_A_Init; i.Table = A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000408_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000408_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000408_A]()) }

func A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000410_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000410_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000410_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000410_A_New()}; return nil }

func A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000410_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000410_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000410_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000410_A_invoke, New: A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000410_A_new, Get: A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000410_A_get}

var A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000410_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000404$fn__393000405$fn__393000410", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_eval393000404_fn__393000405_A_class, Simple: "fn__393000410", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000410_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000410_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000410_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000410_A_Init; i.Table = A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000410_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000410_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000410_A]()) }

func A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000412_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000412_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000412_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000412_A_New()}; return nil }

func A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000412_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000412_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000412_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000412_A_invoke, New: A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000412_A_new, Get: A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000412_A_get}

var A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000412_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000404$fn__393000405$fn__393000412", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_eval393000404_fn__393000405_A_class, Simple: "fn__393000412", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000412_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000412_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000412_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000412_A_Init; i.Table = A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000412_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000412_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000404_fn__393000405_fn__393000412_A]()) }

func A_arbace_classes_interp_eval393000416_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000416_A_New()}; return nil }

var A_arbace_classes_interp_eval393000416_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000416_A_new}

var A_arbace_classes_interp_eval393000416_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000416", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000416", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000416_A"})

func init() { i := A_arbace_classes_interp_eval393000416_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000416_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000416_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000416_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000416_A]()) }

func A_arbace_classes_interp_eval393000416_fn__393000417_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000416_fn__393000417_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000416_fn__393000417_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000416_fn__393000417_A_New()}; return nil }

func A_arbace_classes_interp_eval393000416_fn__393000417_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000416_fn__393000417_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000416_fn__393000417_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000416_fn__393000417_A_invoke, New: A_arbace_classes_interp_eval393000416_fn__393000417_A_new, Get: A_arbace_classes_interp_eval393000416_fn__393000417_A_get}

var A_arbace_classes_interp_eval393000416_fn__393000417_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000416$fn__393000417", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000416_A_class, Simple: "fn__393000417", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000416_fn__393000417_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000416_fn__393000417_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000416_fn__393000417_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000416_fn__393000417_A_Init; i.Table = A_arbace_classes_interp_eval393000416_fn__393000417_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000416_fn__393000417_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000416_fn__393000417_A]()) }

func A_arbace_classes_interp_eval393000429_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000429_A_New()}; return nil }

var A_arbace_classes_interp_eval393000429_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000429_A_new}

var A_arbace_classes_interp_eval393000429_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000429", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000429", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000429_A"})

func init() { i := A_arbace_classes_interp_eval393000429_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000429_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000429_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000429_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000429_A]()) }

func A_arbace_classes_interp_eval393000429_fn__393000430_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000429_fn__393000430_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000429_fn__393000430_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000429_fn__393000430_A_New()}; return nil }

func A_arbace_classes_interp_eval393000429_fn__393000430_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000429_fn__393000430_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000429_fn__393000430_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000429_fn__393000430_A_invoke, New: A_arbace_classes_interp_eval393000429_fn__393000430_A_new, Get: A_arbace_classes_interp_eval393000429_fn__393000430_A_get}

var A_arbace_classes_interp_eval393000429_fn__393000430_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000429$fn__393000430", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000429_A_class, Simple: "fn__393000430", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000429_fn__393000430_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000429_fn__393000430_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000429_fn__393000430_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000429_fn__393000430_A_Init; i.Table = A_arbace_classes_interp_eval393000429_fn__393000430_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000429_fn__393000430_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000429_fn__393000430_A]()) }

func A_arbace_classes_interp_eval393000429_fn__393000430_br__393000431_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000429_fn__393000430_br__393000431_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000429_fn__393000430_br__393000431_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000429_fn__393000430_br__393000431_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000429_fn__393000430_br__393000431_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000429_fn__393000430_br__393000431_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000429_fn__393000430_br__393000431_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000429_fn__393000430_br__393000431_A_invoke, New: A_arbace_classes_interp_eval393000429_fn__393000430_br__393000431_A_new, Get: A_arbace_classes_interp_eval393000429_fn__393000430_br__393000431_A_get}

var A_arbace_classes_interp_eval393000429_fn__393000430_br__393000431_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000429$fn__393000430$br__393000431", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_eval393000429_fn__393000430_A_class, Simple: "br__393000431", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000429_fn__393000430_br__393000431_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000429_fn__393000430_br__393000431_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000429_fn__393000430_br__393000431_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000429_fn__393000430_br__393000431_A_Init; i.Table = A_arbace_classes_interp_eval393000429_fn__393000430_br__393000431_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000429_fn__393000430_br__393000431_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000429_fn__393000430_br__393000431_A]()) }

func A_arbace_classes_interp_eval393000435_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000435_A_New()}; return nil }

var A_arbace_classes_interp_eval393000435_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000435_A_new}

var A_arbace_classes_interp_eval393000435_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000435", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000435", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000435_A"})

func init() { i := A_arbace_classes_interp_eval393000435_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000435_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000435_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000435_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000435_A]()) }

func A_arbace_classes_interp_eval393000435_fn__393000436_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000435_fn__393000436_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000435_fn__393000436_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000435_fn__393000436_A_New()}; return nil }

func A_arbace_classes_interp_eval393000435_fn__393000436_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000435_fn__393000436_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000435_fn__393000436_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000435_fn__393000436_A_invoke, New: A_arbace_classes_interp_eval393000435_fn__393000436_A_new, Get: A_arbace_classes_interp_eval393000435_fn__393000436_A_get}

var A_arbace_classes_interp_eval393000435_fn__393000436_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000435$fn__393000436", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000435_A_class, Simple: "fn__393000436", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000435_fn__393000436_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000435_fn__393000436_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000435_fn__393000436_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000435_fn__393000436_A_Init; i.Table = A_arbace_classes_interp_eval393000435_fn__393000436_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000435_fn__393000436_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000435_fn__393000436_A]()) }

func A_arbace_classes_interp_eval393000435_fn__393000436_arm__393000437_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000435_fn__393000436_arm__393000437_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000435_fn__393000436_arm__393000437_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000435_fn__393000436_arm__393000437_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000435_fn__393000436_arm__393000437_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000435_fn__393000436_arm__393000437_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000435_fn__393000436_arm__393000437_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000435_fn__393000436_arm__393000437_A_invoke, New: A_arbace_classes_interp_eval393000435_fn__393000436_arm__393000437_A_new, Get: A_arbace_classes_interp_eval393000435_fn__393000436_arm__393000437_A_get}

var A_arbace_classes_interp_eval393000435_fn__393000436_arm__393000437_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000435$fn__393000436$arm__393000437", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_eval393000435_fn__393000436_A_class, Simple: "arm__393000437", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000435_fn__393000436_arm__393000437_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000435_fn__393000436_arm__393000437_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000435_fn__393000436_arm__393000437_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000435_fn__393000436_arm__393000437_A_Init; i.Table = A_arbace_classes_interp_eval393000435_fn__393000436_arm__393000437_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000435_fn__393000436_arm__393000437_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000435_fn__393000436_arm__393000437_A]()) }

func A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000460_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000460_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000460_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000460_A_New()}; return nil }

func A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000460_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000460_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000460_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000460_A_invoke, New: A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000460_A_new, Get: A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000460_A_get}

var A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000460_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000435$fn__393000436$fn__393000460", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_eval393000435_fn__393000436_A_class, Simple: "fn__393000460", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000460_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000460_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000460_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000460_A_Init; i.Table = A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000460_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000460_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000460_A]()) }

func A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000466_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000466_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000466_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000466_A_New()}; return nil }

func A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000466_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000466_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000466_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000466_A_invoke, New: A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000466_A_new, Get: A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000466_A_get}

var A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000466_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000435$fn__393000436$fn__393000466", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_eval393000435_fn__393000436_A_class, Simple: "fn__393000466", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000466_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000466_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000466_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000466_A_Init; i.Table = A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000466_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000466_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000466_A]()) }

func A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000519_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000519_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000519_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000519_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000519_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000519_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000519_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000519_A_invoke, New: A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000519_A_new, Get: A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000519_A_get}

var A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000519_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000435$fn__393000436$fn__393000519", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_eval393000435_fn__393000436_A_class, Simple: "fn__393000519", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000519_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000519_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000519_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000519_A_Init; i.Table = A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000519_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000519_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000519_A]()) }

func A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000525_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000525_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000525_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000525_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000525_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000525_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000525_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000525_A_invoke, New: A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000525_A_new, Get: A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000525_A_get}

var A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000525_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000435$fn__393000436$fn__393000525", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_eval393000435_fn__393000436_A_class, Simple: "fn__393000525", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000525_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000525_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000525_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000525_A_Init; i.Table = A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000525_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000525_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000525_A]()) }

func A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000530_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000530_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000530_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000530_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000530_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000530_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000530_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000530_A_invoke, New: A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000530_A_new, Get: A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000530_A_get}

var A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000530_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000435$fn__393000436$fn__393000530", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_eval393000435_fn__393000436_A_class, Simple: "fn__393000530", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000530_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000530_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000530_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000530_A_Init; i.Table = A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000530_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000530_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000530_A]()) }

func A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000534_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000534_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000534_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000534_A_New()}; return nil }

func A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000534_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000534_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000534_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000534_A_invoke, New: A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000534_A_new, Get: A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000534_A_get}

var A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000534_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000435$fn__393000436$fn__393000534", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_eval393000435_fn__393000436_A_class, Simple: "fn__393000534", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000534_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000534_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000534_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000534_A_Init; i.Table = A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000534_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000534_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000435_fn__393000436_fn__393000534_A]()) }

func A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_A_New()}; return nil }

func A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_A_invoke, New: A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_A_new, Get: A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_A_get}

var A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000435$fn__393000436$iter__393000439__393000445", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_eval393000435_fn__393000436_A_class, Simple: "iter__393000439__393000445", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_A_Init; i.Table = A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_A]()) }

func A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_A_invoke, New: A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_A_new, Get: A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_A_get}

var A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000435$fn__393000436$iter__393000439__393000445$fn__393000446", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_A_class, Simple: "fn__393000446", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_A_Init; i.Table = A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_A]()) }

func A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_A_invoke, New: A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_A_new, Get: A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_A_get}

var A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000435$fn__393000436$iter__393000439__393000445$fn__393000446$iter__393000441__393000450", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_A_class, Simple: "iter__393000441__393000450", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_A_Init; i.Table = A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_A]()) }

func A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_A_invoke, New: A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_A_new, Get: A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_A_get}

var A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000435$fn__393000436$iter__393000439__393000445$fn__393000446$iter__393000441__393000450$fn__393000451", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_A_class, Simple: "fn__393000451", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_A_Init; i.Table = A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_A]()) }

func A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_fn__393000452_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_fn__393000452_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_fn__393000452_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_fn__393000452_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_fn__393000452_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_fn__393000452_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_fn__393000452_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_fn__393000452_A_invoke, New: A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_fn__393000452_A_new, Get: A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_fn__393000452_A_get}

var A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_fn__393000452_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000435$fn__393000436$iter__393000439__393000445$fn__393000446$iter__393000441__393000450$fn__393000451$fn__393000452", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_A_class, Simple: "fn__393000452", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_fn__393000452_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_fn__393000452_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_fn__393000452_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_fn__393000452_A_Init; i.Table = A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_fn__393000452_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_fn__393000452_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000439__393000445_fn__393000446_iter__393000441__393000450_fn__393000451_fn__393000452_A]()) }

func A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_A_New()}; return nil }

func A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_A_invoke, New: A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_A_new, Get: A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_A_get}

var A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000435$fn__393000436$iter__393000471__393000475", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_eval393000435_fn__393000436_A_class, Simple: "iter__393000471__393000475", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_A_Init; i.Table = A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_A]()) }

func A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_A_invoke, New: A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_A_new, Get: A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_A_get}

var A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000435$fn__393000436$iter__393000471__393000475$fn__393000476", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_A_class, Simple: "fn__393000476", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_A_Init; i.Table = A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_A]()) }

func A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_fn__393000477_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_fn__393000477_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_fn__393000477_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_fn__393000477_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_fn__393000477_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_fn__393000477_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_fn__393000477_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_fn__393000477_A_invoke, New: A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_fn__393000477_A_new, Get: A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_fn__393000477_A_get}

var A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_fn__393000477_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000435$fn__393000436$iter__393000471__393000475$fn__393000476$fn__393000477", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_A_class, Simple: "fn__393000477", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_fn__393000477_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_fn__393000477_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_fn__393000477_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_fn__393000477_A_Init; i.Table = A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_fn__393000477_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_fn__393000477_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000435_fn__393000436_iter__393000471__393000475_fn__393000476_fn__393000477_A]()) }

func A_arbace_classes_interp_eval393000702_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000702_A_New()}; return nil }

var A_arbace_classes_interp_eval393000702_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000702_A_new}

var A_arbace_classes_interp_eval393000702_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000702", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000702", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000702_A"})

func init() { i := A_arbace_classes_interp_eval393000702_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000702_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000702_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000702_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000702_A]()) }

func A_arbace_classes_interp_eval393000702_fn__393000703_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000702_fn__393000703_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000702_fn__393000703_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000702_fn__393000703_A_New()}; return nil }

func A_arbace_classes_interp_eval393000702_fn__393000703_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000702_fn__393000703_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000702_fn__393000703_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000702_fn__393000703_A_invoke, New: A_arbace_classes_interp_eval393000702_fn__393000703_A_new, Get: A_arbace_classes_interp_eval393000702_fn__393000703_A_get}

var A_arbace_classes_interp_eval393000702_fn__393000703_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000702$fn__393000703", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000702_A_class, Simple: "fn__393000703", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000702_fn__393000703_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000702_fn__393000703_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000702_fn__393000703_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000702_fn__393000703_A_Init; i.Table = A_arbace_classes_interp_eval393000702_fn__393000703_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000702_fn__393000703_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000702_fn__393000703_A]()) }

func A_arbace_classes_interp_eval393000781_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000781_A_New()}; return nil }

var A_arbace_classes_interp_eval393000781_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000781_A_new}

var A_arbace_classes_interp_eval393000781_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000781", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000781", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000781_A"})

func init() { i := A_arbace_classes_interp_eval393000781_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000781_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000781_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000781_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000781_A]()) }

func A_arbace_classes_interp_eval393000781_fn__393000782_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000781_fn__393000782_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000781_fn__393000782_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000781_fn__393000782_A_New()}; return nil }

func A_arbace_classes_interp_eval393000781_fn__393000782_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000781_fn__393000782_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000781_fn__393000782_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000781_fn__393000782_A_invoke, New: A_arbace_classes_interp_eval393000781_fn__393000782_A_new, Get: A_arbace_classes_interp_eval393000781_fn__393000782_A_get}

var A_arbace_classes_interp_eval393000781_fn__393000782_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000781$fn__393000782", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000781_A_class, Simple: "fn__393000782", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000781_fn__393000782_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000781_fn__393000782_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000781_fn__393000782_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000781_fn__393000782_A_Init; i.Table = A_arbace_classes_interp_eval393000781_fn__393000782_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000781_fn__393000782_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000781_fn__393000782_A]()) }

func A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000783_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000783_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000783_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000783_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000783_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000783_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000783_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000783_A_invoke, New: A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000783_A_new, Get: A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000783_A_get}

var A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000783_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000781$fn__393000782$fn__393000783", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_eval393000781_fn__393000782_A_class, Simple: "fn__393000783", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000783_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000783_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000783_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000783_A_Init; i.Table = A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000783_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000783_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000783_A]()) }

func A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000785_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000785_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000785_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000785_A_New()}; return nil }

func A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000785_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000785_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000785_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000785_A_invoke, New: A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000785_A_new, Get: A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000785_A_get}

var A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000785_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000781$fn__393000782$fn__393000785", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_eval393000781_fn__393000782_A_class, Simple: "fn__393000785", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000785_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000785_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000785_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000785_A_Init; i.Table = A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000785_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000785_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000785_A]()) }

func A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000787_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000787_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000787_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000787_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000787_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000787_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000787_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000787_A_invoke, New: A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000787_A_new, Get: A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000787_A_get}

var A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000787_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000781$fn__393000782$fn__393000787", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_eval393000781_fn__393000782_A_class, Simple: "fn__393000787", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000787_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000787_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000787_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000787_A_Init; i.Table = A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000787_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000787_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000781_fn__393000782_fn__393000787_A]()) }

func A_arbace_classes_interp_eval393000792_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000792_A_New()}; return nil }

var A_arbace_classes_interp_eval393000792_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393000792_A_new}

var A_arbace_classes_interp_eval393000792_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000792", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393000792", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000792_A"})

func init() { i := A_arbace_classes_interp_eval393000792_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000792_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393000792_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000792_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000792_A]()) }

func A_arbace_classes_interp_eval393000792_fn__393000793_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000792_fn__393000793_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000792_fn__393000793_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000792_fn__393000793_A_New()}; return nil }

func A_arbace_classes_interp_eval393000792_fn__393000793_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000792_fn__393000793_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000792_fn__393000793_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000792_fn__393000793_A_invoke, New: A_arbace_classes_interp_eval393000792_fn__393000793_A_new, Get: A_arbace_classes_interp_eval393000792_fn__393000793_A_get}

var A_arbace_classes_interp_eval393000792_fn__393000793_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000792$fn__393000793", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000792_A_class, Simple: "fn__393000793", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000792_fn__393000793_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000792_fn__393000793_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000792_fn__393000793_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000792_fn__393000793_A_Init; i.Table = A_arbace_classes_interp_eval393000792_fn__393000793_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000792_fn__393000793_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000792_fn__393000793_A]()) }

func A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_A_invoke, New: A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_A_new, Get: A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_A_get}

var A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000792$fn__393000793$conv_args__393000806", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000792_fn__393000793_A_class, Simple: "conv_args__393000806", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_A_Init; i.Table = A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_A]()) }

func A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_fn__393000807_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_fn__393000807_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_fn__393000807_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_fn__393000807_A_New()}; return nil }

func A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_fn__393000807_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_fn__393000807_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_fn__393000807_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_fn__393000807_A_invoke, New: A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_fn__393000807_A_new, Get: A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_fn__393000807_A_get}

var A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_fn__393000807_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000792$fn__393000793$conv_args__393000806$fn__393000807", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_A_class, Simple: "fn__393000807", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_fn__393000807_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_fn__393000807_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_fn__393000807_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_fn__393000807_A_Init; i.Table = A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_fn__393000807_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_fn__393000807_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000792_fn__393000793_conv_args__393000806_fn__393000807_A]()) }

func A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000802_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000802_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000802_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000802_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000802_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000802_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000802_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000802_A_invoke, New: A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000802_A_new, Get: A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000802_A_get}

var A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000802_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000792$fn__393000793$fn__393000802", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_eval393000792_fn__393000793_A_class, Simple: "fn__393000802", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000802_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000802_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000802_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000802_A_Init; i.Table = A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000802_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000802_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000802_A]()) }

func A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000804_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000804_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000804_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000804_A_New()}; return nil }

func A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000804_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000804_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000804_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000804_A_invoke, New: A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000804_A_new, Get: A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000804_A_get}

var A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000804_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000792$fn__393000793$fn__393000804", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_eval393000792_fn__393000793_A_class, Simple: "fn__393000804", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000804_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000804_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000804_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000804_A_Init; i.Table = A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000804_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000804_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000804_A]()) }

func A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000812_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000812_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000812_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000812_A_New()}; return nil }

func A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000812_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000812_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000812_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000812_A_invoke, New: A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000812_A_new, Get: A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000812_A_get}

var A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000812_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393000792$fn__393000793$fn__393000812", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_classes_interp_eval393000792_fn__393000793_A_class, Simple: "fn__393000812", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000812_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000812_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000812_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000812_A_Init; i.Table = A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000812_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000812_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393000792_fn__393000793_fn__393000812_A]()) }

func A_arbace_classes_interp_eval393001002_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393001002_A_New()}; return nil }

var A_arbace_classes_interp_eval393001002_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_interp_eval393001002_A_new}

var A_arbace_classes_interp_eval393001002_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393001002", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_interp_A_class, Simple: "eval393001002", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393001002_A"})

func init() { i := A_arbace_classes_interp_eval393001002_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393001002_A_InstanceOf; i.Table = A_arbace_classes_interp_eval393001002_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393001002_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393001002_A]()) }

func A_arbace_classes_interp_eval393001002_fn__393001003_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_eval393001002_fn__393001003_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_eval393001002_fn__393001003_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_eval393001002_fn__393001003_A_New()}; return nil }

func A_arbace_classes_interp_eval393001002_fn__393001003_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_eval393001002_fn__393001003_A_fn_class)}; return nil }

var A_arbace_classes_interp_eval393001002_fn__393001003_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_eval393001002_fn__393001003_A_invoke, New: A_arbace_classes_interp_eval393001002_fn__393001003_A_new, Get: A_arbace_classes_interp_eval393001002_fn__393001003_A_get}

var A_arbace_classes_interp_eval393001002_fn__393001003_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$eval393001002$fn__393001003", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_eval393001002_A_class, Simple: "fn__393001003", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_eval393001002_fn__393001003_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_eval393001002_fn__393001003_A_class.Info(); i.IsInstance = A_arbace_classes_interp_eval393001002_fn__393001003_A_InstanceOf; i.Init = A_arbace_classes_interp_eval393001002_fn__393001003_A_Init; i.Table = A_arbace_classes_interp_eval393001002_fn__393001003_A_members; jrt.RegisterGoType(A_arbace_classes_interp_eval393001002_fn__393001003_A_class, reflect.TypeFor[A_arbace_classes_interp_eval393001002_fn__393001003_A]()) }

func A_arbace_classes_interp_fail_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_fail_A).DoInvoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_fail_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_fail_A_New()}; return nil }

func A_arbace_classes_interp_fail_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_fail_A_fn_class)}; return nil }

var A_arbace_classes_interp_fail_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_fail_A_invoke, New: A_arbace_classes_interp_fail_A_new, Get: A_arbace_classes_interp_fail_A_get}

var A_arbace_classes_interp_fail_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$fail", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR1_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "fail", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_fail_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_fail_A_class.Info(); i.IsInstance = A_arbace_classes_interp_fail_A_InstanceOf; i.Init = A_arbace_classes_interp_fail_A_Init; i.Table = A_arbace_classes_interp_fail_A_members; jrt.RegisterGoType(A_arbace_classes_interp_fail_A_class, reflect.TypeFor[A_arbace_classes_interp_fail_A]()) }

func A_arbace_classes_interp_field_index_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_field_index_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_field_index_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_field_index_A_New()}; return nil }

func A_arbace_classes_interp_field_index_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_field_index_A_fn_class)}; return nil }

var A_arbace_classes_interp_field_index_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_field_index_A_invoke, New: A_arbace_classes_interp_field_index_A_new, Get: A_arbace_classes_interp_field_index_A_get}

var A_arbace_classes_interp_field_index_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$field_index", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "field_index", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_field_index_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_field_index_A_class.Info(); i.IsInstance = A_arbace_classes_interp_field_index_A_InstanceOf; i.Init = A_arbace_classes_interp_field_index_A_Init; i.Table = A_arbace_classes_interp_field_index_A_members; jrt.RegisterGoType(A_arbace_classes_interp_field_index_A_class, reflect.TypeFor[A_arbace_classes_interp_field_index_A]()) }

func A_arbace_classes_interp_find_field_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_find_field_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_find_field_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_find_field_A_New()}; return nil }

func A_arbace_classes_interp_find_field_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_find_field_A_fn_class)}; return nil }

var A_arbace_classes_interp_find_field_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_find_field_A_invoke, New: A_arbace_classes_interp_find_field_A_new, Get: A_arbace_classes_interp_find_field_A_get}

var A_arbace_classes_interp_find_field_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$find_field", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "find_field", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_find_field_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_find_field_A_class.Info(); i.IsInstance = A_arbace_classes_interp_find_field_A_InstanceOf; i.Init = A_arbace_classes_interp_find_field_A_Init; i.Table = A_arbace_classes_interp_find_field_A_members; jrt.RegisterGoType(A_arbace_classes_interp_find_field_A_class, reflect.TypeFor[A_arbace_classes_interp_find_field_A]()) }

func A_arbace_classes_interp_find_field_fn__393000061_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_find_field_fn__393000061_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_find_field_fn__393000061_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_find_field_fn__393000061_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_find_field_fn__393000061_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_find_field_fn__393000061_A_fn_class)}; return nil }

var A_arbace_classes_interp_find_field_fn__393000061_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_find_field_fn__393000061_A_invoke, New: A_arbace_classes_interp_find_field_fn__393000061_A_new, Get: A_arbace_classes_interp_find_field_fn__393000061_A_get}

var A_arbace_classes_interp_find_field_fn__393000061_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$find_field$fn__393000061", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_find_field_A_class, Simple: "fn__393000061", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_find_field_fn__393000061_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_find_field_fn__393000061_A_class.Info(); i.IsInstance = A_arbace_classes_interp_find_field_fn__393000061_A_InstanceOf; i.Init = A_arbace_classes_interp_find_field_fn__393000061_A_Init; i.Table = A_arbace_classes_interp_find_field_fn__393000061_A_members; jrt.RegisterGoType(A_arbace_classes_interp_find_field_fn__393000061_A_class, reflect.TypeFor[A_arbace_classes_interp_find_field_fn__393000061_A]()) }

func A_arbace_classes_interp_find_field_fn__393000064_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_find_field_fn__393000064_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_find_field_fn__393000064_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_find_field_fn__393000064_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_find_field_fn__393000064_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_find_field_fn__393000064_A_fn_class)}; return nil }

var A_arbace_classes_interp_find_field_fn__393000064_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_find_field_fn__393000064_A_invoke, New: A_arbace_classes_interp_find_field_fn__393000064_A_new, Get: A_arbace_classes_interp_find_field_fn__393000064_A_get}

var A_arbace_classes_interp_find_field_fn__393000064_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$find_field$fn__393000064", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_find_field_A_class, Simple: "fn__393000064", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_find_field_fn__393000064_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_find_field_fn__393000064_A_class.Info(); i.IsInstance = A_arbace_classes_interp_find_field_fn__393000064_A_InstanceOf; i.Init = A_arbace_classes_interp_find_field_fn__393000064_A_Init; i.Table = A_arbace_classes_interp_find_field_fn__393000064_A_members; jrt.RegisterGoType(A_arbace_classes_interp_find_field_fn__393000064_A_class, reflect.TypeFor[A_arbace_classes_interp_find_field_fn__393000064_A]()) }

func A_arbace_classes_interp_find_method_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_find_method_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_interp_find_method_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_find_method_A_New()}; return nil }

func A_arbace_classes_interp_find_method_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_find_method_A_fn_class)}; return nil }

var A_arbace_classes_interp_find_method_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_find_method_A_invoke, New: A_arbace_classes_interp_find_method_A_new, Get: A_arbace_classes_interp_find_method_A_get}

var A_arbace_classes_interp_find_method_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$find_method", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "find_method", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_find_method_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_find_method_A_class.Info(); i.IsInstance = A_arbace_classes_interp_find_method_A_InstanceOf; i.Init = A_arbace_classes_interp_find_method_A_Init; i.Table = A_arbace_classes_interp_find_method_A_members; jrt.RegisterGoType(A_arbace_classes_interp_find_method_A_class, reflect.TypeFor[A_arbace_classes_interp_find_method_A]()) }

func A_arbace_classes_interp_find_method_fn__393000045_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_find_method_fn__393000045_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_find_method_fn__393000045_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_find_method_fn__393000045_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_find_method_fn__393000045_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_find_method_fn__393000045_A_fn_class)}; return nil }

var A_arbace_classes_interp_find_method_fn__393000045_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_find_method_fn__393000045_A_invoke, New: A_arbace_classes_interp_find_method_fn__393000045_A_new, Get: A_arbace_classes_interp_find_method_fn__393000045_A_get}

var A_arbace_classes_interp_find_method_fn__393000045_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$find_method$fn__393000045", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_find_method_A_class, Simple: "fn__393000045", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_find_method_fn__393000045_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_find_method_fn__393000045_A_class.Info(); i.IsInstance = A_arbace_classes_interp_find_method_fn__393000045_A_InstanceOf; i.Init = A_arbace_classes_interp_find_method_fn__393000045_A_Init; i.Table = A_arbace_classes_interp_find_method_fn__393000045_A_members; jrt.RegisterGoType(A_arbace_classes_interp_find_method_fn__393000045_A_class, reflect.TypeFor[A_arbace_classes_interp_find_method_fn__393000045_A]()) }

func A_arbace_classes_interp_find_method_fn__393000047_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_find_method_fn__393000047_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_find_method_fn__393000047_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_find_method_fn__393000047_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_find_method_fn__393000047_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_find_method_fn__393000047_A_fn_class)}; return nil }

var A_arbace_classes_interp_find_method_fn__393000047_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_find_method_fn__393000047_A_invoke, New: A_arbace_classes_interp_find_method_fn__393000047_A_new, Get: A_arbace_classes_interp_find_method_fn__393000047_A_get}

var A_arbace_classes_interp_find_method_fn__393000047_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$find_method$fn__393000047", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_find_method_A_class, Simple: "fn__393000047", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_find_method_fn__393000047_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_find_method_fn__393000047_A_class.Info(); i.IsInstance = A_arbace_classes_interp_find_method_fn__393000047_A_InstanceOf; i.Init = A_arbace_classes_interp_find_method_fn__393000047_A_Init; i.Table = A_arbace_classes_interp_find_method_fn__393000047_A_members; jrt.RegisterGoType(A_arbace_classes_interp_find_method_fn__393000047_A_class, reflect.TypeFor[A_arbace_classes_interp_find_method_fn__393000047_A]()) }

func A_arbace_classes_interp_find_method_fn__393000050_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_find_method_fn__393000050_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_find_method_fn__393000050_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_find_method_fn__393000050_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_find_method_fn__393000050_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_find_method_fn__393000050_A_fn_class)}; return nil }

var A_arbace_classes_interp_find_method_fn__393000050_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_find_method_fn__393000050_A_invoke, New: A_arbace_classes_interp_find_method_fn__393000050_A_new, Get: A_arbace_classes_interp_find_method_fn__393000050_A_get}

var A_arbace_classes_interp_find_method_fn__393000050_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$find_method$fn__393000050", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_find_method_A_class, Simple: "fn__393000050", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_find_method_fn__393000050_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_find_method_fn__393000050_A_class.Info(); i.IsInstance = A_arbace_classes_interp_find_method_fn__393000050_A_InstanceOf; i.Init = A_arbace_classes_interp_find_method_fn__393000050_A_Init; i.Table = A_arbace_classes_interp_find_method_fn__393000050_A_members; jrt.RegisterGoType(A_arbace_classes_interp_find_method_fn__393000050_A_class, reflect.TypeFor[A_arbace_classes_interp_find_method_fn__393000050_A]()) }

func A_arbace_classes_interp_find_static_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_find_static_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_find_static_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_find_static_A_New()}; return nil }

func A_arbace_classes_interp_find_static_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_find_static_A_fn_class)}; return nil }

var A_arbace_classes_interp_find_static_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_find_static_A_invoke, New: A_arbace_classes_interp_find_static_A_new, Get: A_arbace_classes_interp_find_static_A_get}

var A_arbace_classes_interp_find_static_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$find_static", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "find_static", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_find_static_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_find_static_A_class.Info(); i.IsInstance = A_arbace_classes_interp_find_static_A_InstanceOf; i.Init = A_arbace_classes_interp_find_static_A_Init; i.Table = A_arbace_classes_interp_find_static_A_members; jrt.RegisterGoType(A_arbace_classes_interp_find_static_A_class, reflect.TypeFor[A_arbace_classes_interp_find_static_A]()) }

func A_arbace_classes_interp_find_static_fn__393000040_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_find_static_fn__393000040_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_find_static_fn__393000040_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_find_static_fn__393000040_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_find_static_fn__393000040_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_find_static_fn__393000040_A_fn_class)}; return nil }

var A_arbace_classes_interp_find_static_fn__393000040_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_find_static_fn__393000040_A_invoke, New: A_arbace_classes_interp_find_static_fn__393000040_A_new, Get: A_arbace_classes_interp_find_static_fn__393000040_A_get}

var A_arbace_classes_interp_find_static_fn__393000040_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$find_static$fn__393000040", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_find_static_A_class, Simple: "fn__393000040", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_find_static_fn__393000040_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_find_static_fn__393000040_A_class.Info(); i.IsInstance = A_arbace_classes_interp_find_static_fn__393000040_A_InstanceOf; i.Init = A_arbace_classes_interp_find_static_fn__393000040_A_Init; i.Table = A_arbace_classes_interp_find_static_fn__393000040_A_members; jrt.RegisterGoType(A_arbace_classes_interp_find_static_fn__393000040_A_class, reflect.TypeFor[A_arbace_classes_interp_find_static_fn__393000040_A]()) }

func A_arbace_classes_interp_finish_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_finish_BANG__A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_interp_finish_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_finish_BANG__A_New()}; return nil }

func A_arbace_classes_interp_finish_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_finish_BANG__A_fn_class)}; return nil }

var A_arbace_classes_interp_finish_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_finish_BANG__A_invoke, New: A_arbace_classes_interp_finish_BANG__A_new, Get: A_arbace_classes_interp_finish_BANG__A_get}

var A_arbace_classes_interp_finish_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$finish_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "finish_BANG_", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_finish_BANG__A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_finish_BANG__A_class.Info(); i.IsInstance = A_arbace_classes_interp_finish_BANG__A_InstanceOf; i.Init = A_arbace_classes_interp_finish_BANG__A_Init; i.Table = A_arbace_classes_interp_finish_BANG__A_members; jrt.RegisterGoType(A_arbace_classes_interp_finish_BANG__A_class, reflect.TypeFor[A_arbace_classes_interp_finish_BANG__A]()) }

func A_arbace_classes_interp_has_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_has_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_has_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_has_QMARK__A_New()}; return nil }

func A_arbace_classes_interp_has_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_has_QMARK__A_fn_class)}; return nil }

var A_arbace_classes_interp_has_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_has_QMARK__A_invoke, New: A_arbace_classes_interp_has_QMARK__A_new, Get: A_arbace_classes_interp_has_QMARK__A_get}

var A_arbace_classes_interp_has_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$has_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "has_QMARK_", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_has_QMARK__A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_has_QMARK__A_class.Info(); i.IsInstance = A_arbace_classes_interp_has_QMARK__A_InstanceOf; i.Init = A_arbace_classes_interp_has_QMARK__A_Init; i.Table = A_arbace_classes_interp_has_QMARK__A_members; jrt.RegisterGoType(A_arbace_classes_interp_has_QMARK__A_class, reflect.TypeFor[A_arbace_classes_interp_has_QMARK__A]()) }

func A_arbace_classes_interp_host_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_host_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_host_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_host_A_New()}; return nil }

func A_arbace_classes_interp_host_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_host_A_fn_class)}; return nil }

var A_arbace_classes_interp_host_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_host_A_invoke, New: A_arbace_classes_interp_host_A_new, Get: A_arbace_classes_interp_host_A_get}

var A_arbace_classes_interp_host_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$host", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "host", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_host_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_host_A_class.Info(); i.IsInstance = A_arbace_classes_interp_host_A_InstanceOf; i.Init = A_arbace_classes_interp_host_A_Init; i.Table = A_arbace_classes_interp_host_A_members; jrt.RegisterGoType(A_arbace_classes_interp_host_A_class, reflect.TypeFor[A_arbace_classes_interp_host_A]()) }

func A_arbace_classes_interp_implicit_fields_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_implicit_fields_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_interp_implicit_fields_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_implicit_fields_A_New()}; return nil }

func A_arbace_classes_interp_implicit_fields_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_implicit_fields_A_fn_class)}; return nil }

var A_arbace_classes_interp_implicit_fields_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_implicit_fields_A_invoke, New: A_arbace_classes_interp_implicit_fields_A_new, Get: A_arbace_classes_interp_implicit_fields_A_get}

var A_arbace_classes_interp_implicit_fields_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$implicit_fields", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "implicit_fields", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_implicit_fields_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_implicit_fields_A_class.Info(); i.IsInstance = A_arbace_classes_interp_implicit_fields_A_InstanceOf; i.Init = A_arbace_classes_interp_implicit_fields_A_Init; i.Table = A_arbace_classes_interp_implicit_fields_A_members; jrt.RegisterGoType(A_arbace_classes_interp_implicit_fields_A_class, reflect.TypeFor[A_arbace_classes_interp_implicit_fields_A]()) }

func A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_A_fn_class)}; return nil }

var A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_A_invoke, New: A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_A_new, Get: A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_A_get}

var A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$implicit_fields$iter__393000307__393000311", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_implicit_fields_A_class, Simple: "iter__393000307__393000311", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_A_class.Info(); i.IsInstance = A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_A_InstanceOf; i.Init = A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_A_Init; i.Table = A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_A_members; jrt.RegisterGoType(A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_A_class, reflect.TypeFor[A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_A]()) }

func A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_A_fn_class)}; return nil }

var A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_A_invoke, New: A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_A_new, Get: A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_A_get}

var A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$implicit_fields$iter__393000307__393000311$fn__393000312", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_A_class, Simple: "fn__393000312", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_A_class.Info(); i.IsInstance = A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_A_InstanceOf; i.Init = A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_A_Init; i.Table = A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_A_members; jrt.RegisterGoType(A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_A_class, reflect.TypeFor[A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_A]()) }

func A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_fn__393000313_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_fn__393000313_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_fn__393000313_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_fn__393000313_A_New_O_O_O_I_O(args[0], args[1], args[2], args[3].(int32), args[4])}; return nil }

func A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_fn__393000313_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_fn__393000313_A_fn_class)}; return nil }

var A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_fn__393000313_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_fn__393000313_A_invoke, New: A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_fn__393000313_A_new, Get: A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_fn__393000313_A_get}

var A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_fn__393000313_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$implicit_fields$iter__393000307__393000311$fn__393000312$fn__393000313", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_A_class, Simple: "fn__393000313", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_fn__393000313_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_fn__393000313_A_class.Info(); i.IsInstance = A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_fn__393000313_A_InstanceOf; i.Init = A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_fn__393000313_A_Init; i.Table = A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_fn__393000313_A_members; jrt.RegisterGoType(A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_fn__393000313_A_class, reflect.TypeFor[A_arbace_classes_interp_implicit_fields_iter__393000307__393000311_fn__393000312_fn__393000313_A]()) }

func A_arbace_classes_interp_init_nodes_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_init_nodes_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_init_nodes_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_init_nodes_A_New()}; return nil }

func A_arbace_classes_interp_init_nodes_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_init_nodes_A_fn_class)}; return nil }

var A_arbace_classes_interp_init_nodes_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_init_nodes_A_invoke, New: A_arbace_classes_interp_init_nodes_A_new, Get: A_arbace_classes_interp_init_nodes_A_get}

var A_arbace_classes_interp_init_nodes_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$init_nodes", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "init_nodes", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_init_nodes_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_init_nodes_A_class.Info(); i.IsInstance = A_arbace_classes_interp_init_nodes_A_InstanceOf; i.Init = A_arbace_classes_interp_init_nodes_A_Init; i.Table = A_arbace_classes_interp_init_nodes_A_members; jrt.RegisterGoType(A_arbace_classes_interp_init_nodes_A_class, reflect.TypeFor[A_arbace_classes_interp_init_nodes_A]()) }

func A_arbace_classes_interp_init_nodes_fn__393000688_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_init_nodes_fn__393000688_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_init_nodes_fn__393000688_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_init_nodes_fn__393000688_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_init_nodes_fn__393000688_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_init_nodes_fn__393000688_A_fn_class)}; return nil }

var A_arbace_classes_interp_init_nodes_fn__393000688_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_init_nodes_fn__393000688_A_invoke, New: A_arbace_classes_interp_init_nodes_fn__393000688_A_new, Get: A_arbace_classes_interp_init_nodes_fn__393000688_A_get}

var A_arbace_classes_interp_init_nodes_fn__393000688_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$init_nodes$fn__393000688", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_init_nodes_A_class, Simple: "fn__393000688", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_init_nodes_fn__393000688_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_init_nodes_fn__393000688_A_class.Info(); i.IsInstance = A_arbace_classes_interp_init_nodes_fn__393000688_A_InstanceOf; i.Init = A_arbace_classes_interp_init_nodes_fn__393000688_A_Init; i.Table = A_arbace_classes_interp_init_nodes_fn__393000688_A_members; jrt.RegisterGoType(A_arbace_classes_interp_init_nodes_fn__393000688_A_class, reflect.TypeFor[A_arbace_classes_interp_init_nodes_fn__393000688_A]()) }

func A_arbace_classes_interp_instance_fields_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_instance_fields_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_instance_fields_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_instance_fields_A_New()}; return nil }

func A_arbace_classes_interp_instance_fields_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_instance_fields_A_fn_class)}; return nil }

var A_arbace_classes_interp_instance_fields_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_instance_fields_A_invoke, New: A_arbace_classes_interp_instance_fields_A_new, Get: A_arbace_classes_interp_instance_fields_A_get}

var A_arbace_classes_interp_instance_fields_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$instance_fields", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "instance_fields", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_instance_fields_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_instance_fields_A_class.Info(); i.IsInstance = A_arbace_classes_interp_instance_fields_A_InstanceOf; i.Init = A_arbace_classes_interp_instance_fields_A_Init; i.Table = A_arbace_classes_interp_instance_fields_A_members; jrt.RegisterGoType(A_arbace_classes_interp_instance_fields_A_class, reflect.TypeFor[A_arbace_classes_interp_instance_fields_A]()) }

func A_arbace_classes_interp_internal__GT_class_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_internal__GT_class_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_internal__GT_class_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_internal__GT_class_A_New()}; return nil }

func A_arbace_classes_interp_internal__GT_class_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_internal__GT_class_A_fn_class)}; return nil }

var A_arbace_classes_interp_internal__GT_class_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_internal__GT_class_A_invoke, New: A_arbace_classes_interp_internal__GT_class_A_new, Get: A_arbace_classes_interp_internal__GT_class_A_get}

var A_arbace_classes_interp_internal__GT_class_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$internal__GT_class", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "internal__GT_class", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_internal__GT_class_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_internal__GT_class_A_class.Info(); i.IsInstance = A_arbace_classes_interp_internal__GT_class_A_InstanceOf; i.Init = A_arbace_classes_interp_internal__GT_class_A_Init; i.Table = A_arbace_classes_interp_internal__GT_class_A_members; jrt.RegisterGoType(A_arbace_classes_interp_internal__GT_class_A_class, reflect.TypeFor[A_arbace_classes_interp_internal__GT_class_A]()) }

func A_arbace_classes_interp_kind_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_kind_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_kind_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_kind_A_New()}; return nil }

func A_arbace_classes_interp_kind_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_kind_A_fn_class)}; return nil }

var A_arbace_classes_interp_kind_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_kind_A_invoke, New: A_arbace_classes_interp_kind_A_new, Get: A_arbace_classes_interp_kind_A_get}

var A_arbace_classes_interp_kind_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$kind", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "kind", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_kind_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_kind_A_class.Info(); i.IsInstance = A_arbace_classes_interp_kind_A_InstanceOf; i.Init = A_arbace_classes_interp_kind_A_Init; i.Table = A_arbace_classes_interp_kind_A_members; jrt.RegisterGoType(A_arbace_classes_interp_kind_A_class, reflect.TypeFor[A_arbace_classes_interp_kind_A]()) }

func A_arbace_classes_interp_klass_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_klass_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_klass_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_klass_A_New()}; return nil }

func A_arbace_classes_interp_klass_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_klass_A_fn_class)}; return nil }

var A_arbace_classes_interp_klass_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_klass_A_invoke, New: A_arbace_classes_interp_klass_A_new, Get: A_arbace_classes_interp_klass_A_get}

var A_arbace_classes_interp_klass_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$klass", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "klass", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_klass_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_klass_A_class.Info(); i.IsInstance = A_arbace_classes_interp_klass_A_InstanceOf; i.Init = A_arbace_classes_interp_klass_A_Init; i.Table = A_arbace_classes_interp_klass_A_members; jrt.RegisterGoType(A_arbace_classes_interp_klass_A_class, reflect.TypeFor[A_arbace_classes_interp_klass_A]()) }

func A_arbace_classes_interp_konst_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_konst_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_konst_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_konst_A_New()}; return nil }

func A_arbace_classes_interp_konst_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_konst_A_fn_class)}; return nil }

var A_arbace_classes_interp_konst_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_konst_A_invoke, New: A_arbace_classes_interp_konst_A_new, Get: A_arbace_classes_interp_konst_A_get}

var A_arbace_classes_interp_konst_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$konst", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "konst", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_konst_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_konst_A_class.Info(); i.IsInstance = A_arbace_classes_interp_konst_A_InstanceOf; i.Init = A_arbace_classes_interp_konst_A_Init; i.Table = A_arbace_classes_interp_konst_A_members; jrt.RegisterGoType(A_arbace_classes_interp_konst_A_class, reflect.TypeFor[A_arbace_classes_interp_konst_A]()) }

func A_arbace_classes_interp_lambda_done_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_lambda_done_BANG__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_lambda_done_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_lambda_done_BANG__A_New()}; return nil }

func A_arbace_classes_interp_lambda_done_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_lambda_done_BANG__A_fn_class)}; return nil }

var A_arbace_classes_interp_lambda_done_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_lambda_done_BANG__A_invoke, New: A_arbace_classes_interp_lambda_done_BANG__A_new, Get: A_arbace_classes_interp_lambda_done_BANG__A_get}

var A_arbace_classes_interp_lambda_done_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$lambda_done_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "lambda_done_BANG_", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_lambda_done_BANG__A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_lambda_done_BANG__A_class.Info(); i.IsInstance = A_arbace_classes_interp_lambda_done_BANG__A_InstanceOf; i.Init = A_arbace_classes_interp_lambda_done_BANG__A_Init; i.Table = A_arbace_classes_interp_lambda_done_BANG__A_members; jrt.RegisterGoType(A_arbace_classes_interp_lambda_done_BANG__A_class, reflect.TypeFor[A_arbace_classes_interp_lambda_done_BANG__A]()) }

func A_arbace_classes_interp_layout_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_layout_BANG__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_layout_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_layout_BANG__A_New()}; return nil }

func A_arbace_classes_interp_layout_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_layout_BANG__A_fn_class)}; return nil }

var A_arbace_classes_interp_layout_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_layout_BANG__A_invoke, New: A_arbace_classes_interp_layout_BANG__A_new, Get: A_arbace_classes_interp_layout_BANG__A_get}

var A_arbace_classes_interp_layout_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$layout_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "layout_BANG_", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_layout_BANG__A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_layout_BANG__A_class.Info(); i.IsInstance = A_arbace_classes_interp_layout_BANG__A_InstanceOf; i.Init = A_arbace_classes_interp_layout_BANG__A_Init; i.Table = A_arbace_classes_interp_layout_BANG__A_members; jrt.RegisterGoType(A_arbace_classes_interp_layout_BANG__A_class, reflect.TypeFor[A_arbace_classes_interp_layout_BANG__A]()) }

func A_arbace_classes_interp_layout_BANG__fn__393000554_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_layout_BANG__fn__393000554_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_layout_BANG__fn__393000554_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_layout_BANG__fn__393000554_A_New()}; return nil }

func A_arbace_classes_interp_layout_BANG__fn__393000554_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_layout_BANG__fn__393000554_A_fn_class)}; return nil }

var A_arbace_classes_interp_layout_BANG__fn__393000554_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_layout_BANG__fn__393000554_A_invoke, New: A_arbace_classes_interp_layout_BANG__fn__393000554_A_new, Get: A_arbace_classes_interp_layout_BANG__fn__393000554_A_get}

var A_arbace_classes_interp_layout_BANG__fn__393000554_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$layout_BANG_$fn__393000554", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_layout_BANG__A_class, Simple: "fn__393000554", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_layout_BANG__fn__393000554_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_layout_BANG__fn__393000554_A_class.Info(); i.IsInstance = A_arbace_classes_interp_layout_BANG__fn__393000554_A_InstanceOf; i.Init = A_arbace_classes_interp_layout_BANG__fn__393000554_A_Init; i.Table = A_arbace_classes_interp_layout_BANG__fn__393000554_A_members; jrt.RegisterGoType(A_arbace_classes_interp_layout_BANG__fn__393000554_A_class, reflect.TypeFor[A_arbace_classes_interp_layout_BANG__fn__393000554_A]()) }

func A_arbace_classes_interp_layout_BANG__fn__393000556_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_layout_BANG__fn__393000556_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_layout_BANG__fn__393000556_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_layout_BANG__fn__393000556_A_New()}; return nil }

func A_arbace_classes_interp_layout_BANG__fn__393000556_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_layout_BANG__fn__393000556_A_fn_class)}; return nil }

var A_arbace_classes_interp_layout_BANG__fn__393000556_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_layout_BANG__fn__393000556_A_invoke, New: A_arbace_classes_interp_layout_BANG__fn__393000556_A_new, Get: A_arbace_classes_interp_layout_BANG__fn__393000556_A_get}

var A_arbace_classes_interp_layout_BANG__fn__393000556_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$layout_BANG_$fn__393000556", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_layout_BANG__A_class, Simple: "fn__393000556", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_layout_BANG__fn__393000556_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_layout_BANG__fn__393000556_A_class.Info(); i.IsInstance = A_arbace_classes_interp_layout_BANG__fn__393000556_A_InstanceOf; i.Init = A_arbace_classes_interp_layout_BANG__fn__393000556_A_Init; i.Table = A_arbace_classes_interp_layout_BANG__fn__393000556_A_members; jrt.RegisterGoType(A_arbace_classes_interp_layout_BANG__fn__393000556_A_class, reflect.TypeFor[A_arbace_classes_interp_layout_BANG__fn__393000556_A]()) }

func A_arbace_classes_interp_layout_BANG__fn__393000558_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_layout_BANG__fn__393000558_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_layout_BANG__fn__393000558_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_layout_BANG__fn__393000558_A_New()}; return nil }

func A_arbace_classes_interp_layout_BANG__fn__393000558_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_layout_BANG__fn__393000558_A_fn_class)}; return nil }

var A_arbace_classes_interp_layout_BANG__fn__393000558_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_layout_BANG__fn__393000558_A_invoke, New: A_arbace_classes_interp_layout_BANG__fn__393000558_A_new, Get: A_arbace_classes_interp_layout_BANG__fn__393000558_A_get}

var A_arbace_classes_interp_layout_BANG__fn__393000558_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$layout_BANG_$fn__393000558", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_layout_BANG__A_class, Simple: "fn__393000558", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_layout_BANG__fn__393000558_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_layout_BANG__fn__393000558_A_class.Info(); i.IsInstance = A_arbace_classes_interp_layout_BANG__fn__393000558_A_InstanceOf; i.Init = A_arbace_classes_interp_layout_BANG__fn__393000558_A_Init; i.Table = A_arbace_classes_interp_layout_BANG__fn__393000558_A_members; jrt.RegisterGoType(A_arbace_classes_interp_layout_BANG__fn__393000558_A_class, reflect.TypeFor[A_arbace_classes_interp_layout_BANG__fn__393000558_A]()) }

func A_arbace_classes_interp_layout_BANG__fn__393000560_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_layout_BANG__fn__393000560_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_layout_BANG__fn__393000560_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_layout_BANG__fn__393000560_A_New()}; return nil }

func A_arbace_classes_interp_layout_BANG__fn__393000560_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_layout_BANG__fn__393000560_A_fn_class)}; return nil }

var A_arbace_classes_interp_layout_BANG__fn__393000560_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_layout_BANG__fn__393000560_A_invoke, New: A_arbace_classes_interp_layout_BANG__fn__393000560_A_new, Get: A_arbace_classes_interp_layout_BANG__fn__393000560_A_get}

var A_arbace_classes_interp_layout_BANG__fn__393000560_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$layout_BANG_$fn__393000560", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_layout_BANG__A_class, Simple: "fn__393000560", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_layout_BANG__fn__393000560_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_layout_BANG__fn__393000560_A_class.Info(); i.IsInstance = A_arbace_classes_interp_layout_BANG__fn__393000560_A_InstanceOf; i.Init = A_arbace_classes_interp_layout_BANG__fn__393000560_A_Init; i.Table = A_arbace_classes_interp_layout_BANG__fn__393000560_A_members; jrt.RegisterGoType(A_arbace_classes_interp_layout_BANG__fn__393000560_A_class, reflect.TypeFor[A_arbace_classes_interp_layout_BANG__fn__393000560_A]()) }

func A_arbace_classes_interp_layout_BANG__fn__393000572_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_layout_BANG__fn__393000572_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_layout_BANG__fn__393000572_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_layout_BANG__fn__393000572_A_New()}; return nil }

func A_arbace_classes_interp_layout_BANG__fn__393000572_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_layout_BANG__fn__393000572_A_fn_class)}; return nil }

var A_arbace_classes_interp_layout_BANG__fn__393000572_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_layout_BANG__fn__393000572_A_invoke, New: A_arbace_classes_interp_layout_BANG__fn__393000572_A_new, Get: A_arbace_classes_interp_layout_BANG__fn__393000572_A_get}

var A_arbace_classes_interp_layout_BANG__fn__393000572_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$layout_BANG_$fn__393000572", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_layout_BANG__A_class, Simple: "fn__393000572", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_layout_BANG__fn__393000572_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_layout_BANG__fn__393000572_A_class.Info(); i.IsInstance = A_arbace_classes_interp_layout_BANG__fn__393000572_A_InstanceOf; i.Init = A_arbace_classes_interp_layout_BANG__fn__393000572_A_Init; i.Table = A_arbace_classes_interp_layout_BANG__fn__393000572_A_members; jrt.RegisterGoType(A_arbace_classes_interp_layout_BANG__fn__393000572_A_class, reflect.TypeFor[A_arbace_classes_interp_layout_BANG__fn__393000572_A]()) }

func A_arbace_classes_interp_layout_BANG__fn__393000574_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_layout_BANG__fn__393000574_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_layout_BANG__fn__393000574_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_layout_BANG__fn__393000574_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_layout_BANG__fn__393000574_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_layout_BANG__fn__393000574_A_fn_class)}; return nil }

var A_arbace_classes_interp_layout_BANG__fn__393000574_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_layout_BANG__fn__393000574_A_invoke, New: A_arbace_classes_interp_layout_BANG__fn__393000574_A_new, Get: A_arbace_classes_interp_layout_BANG__fn__393000574_A_get}

var A_arbace_classes_interp_layout_BANG__fn__393000574_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$layout_BANG_$fn__393000574", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_layout_BANG__A_class, Simple: "fn__393000574", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_layout_BANG__fn__393000574_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_layout_BANG__fn__393000574_A_class.Info(); i.IsInstance = A_arbace_classes_interp_layout_BANG__fn__393000574_A_InstanceOf; i.Init = A_arbace_classes_interp_layout_BANG__fn__393000574_A_Init; i.Table = A_arbace_classes_interp_layout_BANG__fn__393000574_A_members; jrt.RegisterGoType(A_arbace_classes_interp_layout_BANG__fn__393000574_A_class, reflect.TypeFor[A_arbace_classes_interp_layout_BANG__fn__393000574_A]()) }

func A_arbace_classes_interp_layout_BANG__fn__393000576_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_layout_BANG__fn__393000576_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_layout_BANG__fn__393000576_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_layout_BANG__fn__393000576_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_layout_BANG__fn__393000576_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_layout_BANG__fn__393000576_A_fn_class)}; return nil }

var A_arbace_classes_interp_layout_BANG__fn__393000576_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_layout_BANG__fn__393000576_A_invoke, New: A_arbace_classes_interp_layout_BANG__fn__393000576_A_new, Get: A_arbace_classes_interp_layout_BANG__fn__393000576_A_get}

var A_arbace_classes_interp_layout_BANG__fn__393000576_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$layout_BANG_$fn__393000576", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_layout_BANG__A_class, Simple: "fn__393000576", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_layout_BANG__fn__393000576_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_layout_BANG__fn__393000576_A_class.Info(); i.IsInstance = A_arbace_classes_interp_layout_BANG__fn__393000576_A_InstanceOf; i.Init = A_arbace_classes_interp_layout_BANG__fn__393000576_A_Init; i.Table = A_arbace_classes_interp_layout_BANG__fn__393000576_A_members; jrt.RegisterGoType(A_arbace_classes_interp_layout_BANG__fn__393000576_A_class, reflect.TypeFor[A_arbace_classes_interp_layout_BANG__fn__393000576_A]()) }

func A_arbace_classes_interp_layout_BANG__fn__393000578_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_layout_BANG__fn__393000578_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_layout_BANG__fn__393000578_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_layout_BANG__fn__393000578_A_New()}; return nil }

func A_arbace_classes_interp_layout_BANG__fn__393000578_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_layout_BANG__fn__393000578_A_fn_class)}; return nil }

var A_arbace_classes_interp_layout_BANG__fn__393000578_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_layout_BANG__fn__393000578_A_invoke, New: A_arbace_classes_interp_layout_BANG__fn__393000578_A_new, Get: A_arbace_classes_interp_layout_BANG__fn__393000578_A_get}

var A_arbace_classes_interp_layout_BANG__fn__393000578_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$layout_BANG_$fn__393000578", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_layout_BANG__A_class, Simple: "fn__393000578", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_layout_BANG__fn__393000578_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_layout_BANG__fn__393000578_A_class.Info(); i.IsInstance = A_arbace_classes_interp_layout_BANG__fn__393000578_A_InstanceOf; i.Init = A_arbace_classes_interp_layout_BANG__fn__393000578_A_Init; i.Table = A_arbace_classes_interp_layout_BANG__fn__393000578_A_members; jrt.RegisterGoType(A_arbace_classes_interp_layout_BANG__fn__393000578_A_class, reflect.TypeFor[A_arbace_classes_interp_layout_BANG__fn__393000578_A]()) }

func A_arbace_classes_interp_let_node_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_let_node_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_interp_let_node_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_let_node_A_New()}; return nil }

func A_arbace_classes_interp_let_node_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_let_node_A_fn_class)}; return nil }

var A_arbace_classes_interp_let_node_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_let_node_A_invoke, New: A_arbace_classes_interp_let_node_A_new, Get: A_arbace_classes_interp_let_node_A_get}

var A_arbace_classes_interp_let_node_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$let_node", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "let_node", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_let_node_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_let_node_A_class.Info(); i.IsInstance = A_arbace_classes_interp_let_node_A_InstanceOf; i.Init = A_arbace_classes_interp_let_node_A_Init; i.Table = A_arbace_classes_interp_let_node_A_members; jrt.RegisterGoType(A_arbace_classes_interp_let_node_A_class, reflect.TypeFor[A_arbace_classes_interp_let_node_A]()) }

func A_arbace_classes_interp_let_node_fn__393000191_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_let_node_fn__393000191_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_let_node_fn__393000191_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_let_node_fn__393000191_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_let_node_fn__393000191_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_let_node_fn__393000191_A_fn_class)}; return nil }

var A_arbace_classes_interp_let_node_fn__393000191_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_let_node_fn__393000191_A_invoke, New: A_arbace_classes_interp_let_node_fn__393000191_A_new, Get: A_arbace_classes_interp_let_node_fn__393000191_A_get}

var A_arbace_classes_interp_let_node_fn__393000191_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$let_node$fn__393000191", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_let_node_A_class, Simple: "fn__393000191", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_let_node_fn__393000191_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_let_node_fn__393000191_A_class.Info(); i.IsInstance = A_arbace_classes_interp_let_node_fn__393000191_A_InstanceOf; i.Init = A_arbace_classes_interp_let_node_fn__393000191_A_Init; i.Table = A_arbace_classes_interp_let_node_fn__393000191_A_members; jrt.RegisterGoType(A_arbace_classes_interp_let_node_fn__393000191_A_class, reflect.TypeFor[A_arbace_classes_interp_let_node_fn__393000191_A]()) }

func A_arbace_classes_interp_let_node_fn__393000197_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_let_node_fn__393000197_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_let_node_fn__393000197_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_let_node_fn__393000197_A_New()}; return nil }

func A_arbace_classes_interp_let_node_fn__393000197_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_let_node_fn__393000197_A_fn_class)}; return nil }

var A_arbace_classes_interp_let_node_fn__393000197_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_let_node_fn__393000197_A_invoke, New: A_arbace_classes_interp_let_node_fn__393000197_A_new, Get: A_arbace_classes_interp_let_node_fn__393000197_A_get}

var A_arbace_classes_interp_let_node_fn__393000197_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$let_node$fn__393000197", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_let_node_A_class, Simple: "fn__393000197", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_let_node_fn__393000197_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_let_node_fn__393000197_A_class.Info(); i.IsInstance = A_arbace_classes_interp_let_node_fn__393000197_A_InstanceOf; i.Init = A_arbace_classes_interp_let_node_fn__393000197_A_Init; i.Table = A_arbace_classes_interp_let_node_fn__393000197_A_members; jrt.RegisterGoType(A_arbace_classes_interp_let_node_fn__393000197_A_class, reflect.TypeFor[A_arbace_classes_interp_let_node_fn__393000197_A]()) }

func A_arbace_classes_interp_let_node_fn__393000203_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_let_node_fn__393000203_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_let_node_fn__393000203_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_let_node_fn__393000203_A_New()}; return nil }

func A_arbace_classes_interp_let_node_fn__393000203_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_let_node_fn__393000203_A_fn_class)}; return nil }

var A_arbace_classes_interp_let_node_fn__393000203_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_let_node_fn__393000203_A_invoke, New: A_arbace_classes_interp_let_node_fn__393000203_A_new, Get: A_arbace_classes_interp_let_node_fn__393000203_A_get}

var A_arbace_classes_interp_let_node_fn__393000203_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$let_node$fn__393000203", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_let_node_A_class, Simple: "fn__393000203", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_let_node_fn__393000203_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_let_node_fn__393000203_A_class.Info(); i.IsInstance = A_arbace_classes_interp_let_node_fn__393000203_A_InstanceOf; i.Init = A_arbace_classes_interp_let_node_fn__393000203_A_Init; i.Table = A_arbace_classes_interp_let_node_fn__393000203_A_members; jrt.RegisterGoType(A_arbace_classes_interp_let_node_fn__393000203_A_class, reflect.TypeFor[A_arbace_classes_interp_let_node_fn__393000203_A]()) }

func A_arbace_classes_interp_let_node_fn__393000208_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_let_node_fn__393000208_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_let_node_fn__393000208_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_let_node_fn__393000208_A_New()}; return nil }

func A_arbace_classes_interp_let_node_fn__393000208_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_let_node_fn__393000208_A_fn_class)}; return nil }

var A_arbace_classes_interp_let_node_fn__393000208_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_let_node_fn__393000208_A_invoke, New: A_arbace_classes_interp_let_node_fn__393000208_A_new, Get: A_arbace_classes_interp_let_node_fn__393000208_A_get}

var A_arbace_classes_interp_let_node_fn__393000208_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$let_node$fn__393000208", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_let_node_A_class, Simple: "fn__393000208", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_let_node_fn__393000208_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_let_node_fn__393000208_A_class.Info(); i.IsInstance = A_arbace_classes_interp_let_node_fn__393000208_A_InstanceOf; i.Init = A_arbace_classes_interp_let_node_fn__393000208_A_Init; i.Table = A_arbace_classes_interp_let_node_fn__393000208_A_members; jrt.RegisterGoType(A_arbace_classes_interp_let_node_fn__393000208_A_class, reflect.TypeFor[A_arbace_classes_interp_let_node_fn__393000208_A]()) }

func A_arbace_classes_interp_local_node_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_local_node_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_local_node_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_local_node_A_New()}; return nil }

func A_arbace_classes_interp_local_node_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_local_node_A_fn_class)}; return nil }

var A_arbace_classes_interp_local_node_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_local_node_A_invoke, New: A_arbace_classes_interp_local_node_A_new, Get: A_arbace_classes_interp_local_node_A_get}

var A_arbace_classes_interp_local_node_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$local_node", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "local_node", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_local_node_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_local_node_A_class.Info(); i.IsInstance = A_arbace_classes_interp_local_node_A_InstanceOf; i.Init = A_arbace_classes_interp_local_node_A_Init; i.Table = A_arbace_classes_interp_local_node_A_members; jrt.RegisterGoType(A_arbace_classes_interp_local_node_A_class, reflect.TypeFor[A_arbace_classes_interp_local_node_A]()) }

func A_arbace_classes_interp_make_klass_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_make_klass_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_make_klass_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_make_klass_A_New()}; return nil }

func A_arbace_classes_interp_make_klass_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_make_klass_A_fn_class)}; return nil }

var A_arbace_classes_interp_make_klass_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_make_klass_A_invoke, New: A_arbace_classes_interp_make_klass_A_new, Get: A_arbace_classes_interp_make_klass_A_get}

var A_arbace_classes_interp_make_klass_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$make_klass", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "make_klass", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_make_klass_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_make_klass_A_class.Info(); i.IsInstance = A_arbace_classes_interp_make_klass_A_InstanceOf; i.Init = A_arbace_classes_interp_make_klass_A_Init; i.Table = A_arbace_classes_interp_make_klass_A_members; jrt.RegisterGoType(A_arbace_classes_interp_make_klass_A_class, reflect.TypeFor[A_arbace_classes_interp_make_klass_A]()) }

func A_arbace_classes_interp_meth_classes_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_meth_classes_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_meth_classes_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_meth_classes_A_New()}; return nil }

func A_arbace_classes_interp_meth_classes_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_meth_classes_A_fn_class)}; return nil }

var A_arbace_classes_interp_meth_classes_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_meth_classes_A_invoke, New: A_arbace_classes_interp_meth_classes_A_new, Get: A_arbace_classes_interp_meth_classes_A_get}

var A_arbace_classes_interp_meth_classes_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$meth_classes", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "meth_classes", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_meth_classes_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_meth_classes_A_class.Info(); i.IsInstance = A_arbace_classes_interp_meth_classes_A_InstanceOf; i.Init = A_arbace_classes_interp_meth_classes_A_Init; i.Table = A_arbace_classes_interp_meth_classes_A_members; jrt.RegisterGoType(A_arbace_classes_interp_meth_classes_A_class, reflect.TypeFor[A_arbace_classes_interp_meth_classes_A]()) }

func A_arbace_classes_interp_meth_of_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_meth_of_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_interp_meth_of_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_meth_of_A_New()}; return nil }

func A_arbace_classes_interp_meth_of_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_meth_of_A_fn_class)}; return nil }

var A_arbace_classes_interp_meth_of_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_meth_of_A_invoke, New: A_arbace_classes_interp_meth_of_A_new, Get: A_arbace_classes_interp_meth_of_A_get}

var A_arbace_classes_interp_meth_of_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$meth_of", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "meth_of", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_meth_of_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_meth_of_A_class.Info(); i.IsInstance = A_arbace_classes_interp_meth_of_A_InstanceOf; i.Init = A_arbace_classes_interp_meth_of_A_Init; i.Table = A_arbace_classes_interp_meth_of_A_members; jrt.RegisterGoType(A_arbace_classes_interp_meth_of_A_class, reflect.TypeFor[A_arbace_classes_interp_meth_of_A]()) }

func A_arbace_classes_interp_meth_of_fn__393000546_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_meth_of_fn__393000546_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_meth_of_fn__393000546_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_meth_of_fn__393000546_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_meth_of_fn__393000546_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_meth_of_fn__393000546_A_fn_class)}; return nil }

var A_arbace_classes_interp_meth_of_fn__393000546_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_meth_of_fn__393000546_A_invoke, New: A_arbace_classes_interp_meth_of_fn__393000546_A_new, Get: A_arbace_classes_interp_meth_of_fn__393000546_A_get}

var A_arbace_classes_interp_meth_of_fn__393000546_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$meth_of$fn__393000546", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_meth_of_A_class, Simple: "fn__393000546", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_meth_of_fn__393000546_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_meth_of_fn__393000546_A_class.Info(); i.IsInstance = A_arbace_classes_interp_meth_of_fn__393000546_A_InstanceOf; i.Init = A_arbace_classes_interp_meth_of_fn__393000546_A_Init; i.Table = A_arbace_classes_interp_meth_of_fn__393000546_A_members; jrt.RegisterGoType(A_arbace_classes_interp_meth_of_fn__393000546_A_class, reflect.TypeFor[A_arbace_classes_interp_meth_of_fn__393000546_A]()) }

func A_arbace_classes_interp_method_of_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_method_of_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_method_of_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_method_of_A_New()}; return nil }

func A_arbace_classes_interp_method_of_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_method_of_A_fn_class)}; return nil }

var A_arbace_classes_interp_method_of_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_method_of_A_invoke, New: A_arbace_classes_interp_method_of_A_new, Get: A_arbace_classes_interp_method_of_A_get}

var A_arbace_classes_interp_method_of_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$method_of", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "method_of", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_method_of_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_method_of_A_class.Info(); i.IsInstance = A_arbace_classes_interp_method_of_A_InstanceOf; i.Init = A_arbace_classes_interp_method_of_A_Init; i.Table = A_arbace_classes_interp_method_of_A_members; jrt.RegisterGoType(A_arbace_classes_interp_method_of_A_class, reflect.TypeFor[A_arbace_classes_interp_method_of_A]()) }

func A_arbace_classes_interp_method_of_fn__393000295_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_method_of_fn__393000295_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_method_of_fn__393000295_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_method_of_fn__393000295_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_method_of_fn__393000295_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_method_of_fn__393000295_A_fn_class)}; return nil }

var A_arbace_classes_interp_method_of_fn__393000295_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_method_of_fn__393000295_A_invoke, New: A_arbace_classes_interp_method_of_fn__393000295_A_new, Get: A_arbace_classes_interp_method_of_fn__393000295_A_get}

var A_arbace_classes_interp_method_of_fn__393000295_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$method_of$fn__393000295", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_method_of_A_class, Simple: "fn__393000295", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_method_of_fn__393000295_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_method_of_fn__393000295_A_class.Info(); i.IsInstance = A_arbace_classes_interp_method_of_fn__393000295_A_InstanceOf; i.Init = A_arbace_classes_interp_method_of_fn__393000295_A_Init; i.Table = A_arbace_classes_interp_method_of_fn__393000295_A_members; jrt.RegisterGoType(A_arbace_classes_interp_method_of_fn__393000295_A_class, reflect.TypeFor[A_arbace_classes_interp_method_of_fn__393000295_A]()) }

func A_arbace_classes_interp_new_ctx_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_new_ctx_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_new_ctx_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_new_ctx_A_New()}; return nil }

func A_arbace_classes_interp_new_ctx_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_new_ctx_A_fn_class)}; return nil }

var A_arbace_classes_interp_new_ctx_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_new_ctx_A_invoke, New: A_arbace_classes_interp_new_ctx_A_new, Get: A_arbace_classes_interp_new_ctx_A_get}

var A_arbace_classes_interp_new_ctx_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$new_ctx", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "new_ctx", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_new_ctx_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_new_ctx_A_class.Info(); i.IsInstance = A_arbace_classes_interp_new_ctx_A_InstanceOf; i.Init = A_arbace_classes_interp_new_ctx_A_Init; i.Table = A_arbace_classes_interp_new_ctx_A_members; jrt.RegisterGoType(A_arbace_classes_interp_new_ctx_A_class, reflect.TypeFor[A_arbace_classes_interp_new_ctx_A]()) }

func A_arbace_classes_interp_new_lambda_klass_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_new_lambda_klass_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_classes_interp_new_lambda_klass_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_new_lambda_klass_A_New()}; return nil }

func A_arbace_classes_interp_new_lambda_klass_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_new_lambda_klass_A_fn_class)}; return nil }

var A_arbace_classes_interp_new_lambda_klass_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_new_lambda_klass_A_invoke, New: A_arbace_classes_interp_new_lambda_klass_A_new, Get: A_arbace_classes_interp_new_lambda_klass_A_get}

var A_arbace_classes_interp_new_lambda_klass_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$new_lambda_klass", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "new_lambda_klass", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_new_lambda_klass_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_new_lambda_klass_A_class.Info(); i.IsInstance = A_arbace_classes_interp_new_lambda_klass_A_InstanceOf; i.Init = A_arbace_classes_interp_new_lambda_klass_A_Init; i.Table = A_arbace_classes_interp_new_lambda_klass_A_members; jrt.RegisterGoType(A_arbace_classes_interp_new_lambda_klass_A_class, reflect.TypeFor[A_arbace_classes_interp_new_lambda_klass_A]()) }

func A_arbace_classes_interp_node_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_node_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_node_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_node_A_New()}; return nil }

func A_arbace_classes_interp_node_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_node_A_fn_class)}; return nil }

var A_arbace_classes_interp_node_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_node_A_invoke, New: A_arbace_classes_interp_node_A_new, Get: A_arbace_classes_interp_node_A_get}

var A_arbace_classes_interp_node_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$node", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "node", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_node_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_node_A_class.Info(); i.IsInstance = A_arbace_classes_interp_node_A_InstanceOf; i.Init = A_arbace_classes_interp_node_A_Init; i.Table = A_arbace_classes_interp_node_A_members; jrt.RegisterGoType(A_arbace_classes_interp_node_A_class, reflect.TypeFor[A_arbace_classes_interp_node_A]()) }

func A_arbace_classes_interp_nodes_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_nodes_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_nodes_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_nodes_A_New()}; return nil }

func A_arbace_classes_interp_nodes_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_nodes_A_fn_class)}; return nil }

var A_arbace_classes_interp_nodes_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_nodes_A_invoke, New: A_arbace_classes_interp_nodes_A_new, Get: A_arbace_classes_interp_nodes_A_get}

var A_arbace_classes_interp_nodes_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$nodes", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "nodes", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_nodes_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_nodes_A_class.Info(); i.IsInstance = A_arbace_classes_interp_nodes_A_InstanceOf; i.Init = A_arbace_classes_interp_nodes_A_Init; i.Table = A_arbace_classes_interp_nodes_A_members; jrt.RegisterGoType(A_arbace_classes_interp_nodes_A_class, reflect.TypeFor[A_arbace_classes_interp_nodes_A]()) }

func A_arbace_classes_interp_params_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_params_BANG__A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_interp_params_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_params_BANG__A_New()}; return nil }

func A_arbace_classes_interp_params_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_params_BANG__A_fn_class)}; return nil }

var A_arbace_classes_interp_params_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_params_BANG__A_invoke, New: A_arbace_classes_interp_params_BANG__A_new, Get: A_arbace_classes_interp_params_BANG__A_get}

var A_arbace_classes_interp_params_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$params_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "params_BANG_", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_params_BANG__A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_params_BANG__A_class.Info(); i.IsInstance = A_arbace_classes_interp_params_BANG__A_InstanceOf; i.Init = A_arbace_classes_interp_params_BANG__A_Init; i.Table = A_arbace_classes_interp_params_BANG__A_members; jrt.RegisterGoType(A_arbace_classes_interp_params_BANG__A_class, reflect.TypeFor[A_arbace_classes_interp_params_BANG__A]()) }

func A_arbace_classes_interp_params_BANG__fn__393000624_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_params_BANG__fn__393000624_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_params_BANG__fn__393000624_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_params_BANG__fn__393000624_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_params_BANG__fn__393000624_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_params_BANG__fn__393000624_A_fn_class)}; return nil }

var A_arbace_classes_interp_params_BANG__fn__393000624_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_params_BANG__fn__393000624_A_invoke, New: A_arbace_classes_interp_params_BANG__fn__393000624_A_new, Get: A_arbace_classes_interp_params_BANG__fn__393000624_A_get}

var A_arbace_classes_interp_params_BANG__fn__393000624_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$params_BANG_$fn__393000624", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_params_BANG__A_class, Simple: "fn__393000624", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_params_BANG__fn__393000624_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_params_BANG__fn__393000624_A_class.Info(); i.IsInstance = A_arbace_classes_interp_params_BANG__fn__393000624_A_InstanceOf; i.Init = A_arbace_classes_interp_params_BANG__fn__393000624_A_Init; i.Table = A_arbace_classes_interp_params_BANG__fn__393000624_A_members; jrt.RegisterGoType(A_arbace_classes_interp_params_BANG__fn__393000624_A_class, reflect.TypeFor[A_arbace_classes_interp_params_BANG__fn__393000624_A]()) }

func A_arbace_classes_interp_params_BANG__fn__393000626_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_params_BANG__fn__393000626_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_params_BANG__fn__393000626_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_params_BANG__fn__393000626_A_New()}; return nil }

func A_arbace_classes_interp_params_BANG__fn__393000626_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_params_BANG__fn__393000626_A_fn_class)}; return nil }

var A_arbace_classes_interp_params_BANG__fn__393000626_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_params_BANG__fn__393000626_A_invoke, New: A_arbace_classes_interp_params_BANG__fn__393000626_A_new, Get: A_arbace_classes_interp_params_BANG__fn__393000626_A_get}

var A_arbace_classes_interp_params_BANG__fn__393000626_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$params_BANG_$fn__393000626", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_params_BANG__A_class, Simple: "fn__393000626", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_params_BANG__fn__393000626_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_params_BANG__fn__393000626_A_class.Info(); i.IsInstance = A_arbace_classes_interp_params_BANG__fn__393000626_A_InstanceOf; i.Init = A_arbace_classes_interp_params_BANG__fn__393000626_A_Init; i.Table = A_arbace_classes_interp_params_BANG__fn__393000626_A_members; jrt.RegisterGoType(A_arbace_classes_interp_params_BANG__fn__393000626_A_class, reflect.TypeFor[A_arbace_classes_interp_params_BANG__fn__393000626_A]()) }

func A_arbace_classes_interp_params_of_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_params_of_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_params_of_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_params_of_A_New()}; return nil }

func A_arbace_classes_interp_params_of_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_params_of_A_fn_class)}; return nil }

var A_arbace_classes_interp_params_of_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_params_of_A_invoke, New: A_arbace_classes_interp_params_of_A_new, Get: A_arbace_classes_interp_params_of_A_get}

var A_arbace_classes_interp_params_of_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$params_of", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "params_of", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_params_of_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_params_of_A_class.Info(); i.IsInstance = A_arbace_classes_interp_params_of_A_InstanceOf; i.Init = A_arbace_classes_interp_params_of_A_Init; i.Table = A_arbace_classes_interp_params_of_A_members; jrt.RegisterGoType(A_arbace_classes_interp_params_of_A_class, reflect.TypeFor[A_arbace_classes_interp_params_of_A]()) }

func A_arbace_classes_interp_pattern_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_pattern_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_pattern_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_pattern_A_New()}; return nil }

func A_arbace_classes_interp_pattern_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_pattern_A_fn_class)}; return nil }

var A_arbace_classes_interp_pattern_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_pattern_A_invoke, New: A_arbace_classes_interp_pattern_A_new, Get: A_arbace_classes_interp_pattern_A_get}

var A_arbace_classes_interp_pattern_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$pattern", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "pattern", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_pattern_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_pattern_A_class.Info(); i.IsInstance = A_arbace_classes_interp_pattern_A_InstanceOf; i.Init = A_arbace_classes_interp_pattern_A_Init; i.Table = A_arbace_classes_interp_pattern_A_members; jrt.RegisterGoType(A_arbace_classes_interp_pattern_A_class, reflect.TypeFor[A_arbace_classes_interp_pattern_A]()) }

func A_arbace_classes_interp_pattern_fn__393000424_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_pattern_fn__393000424_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_pattern_fn__393000424_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_pattern_fn__393000424_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_pattern_fn__393000424_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_pattern_fn__393000424_A_fn_class)}; return nil }

var A_arbace_classes_interp_pattern_fn__393000424_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_pattern_fn__393000424_A_invoke, New: A_arbace_classes_interp_pattern_fn__393000424_A_new, Get: A_arbace_classes_interp_pattern_fn__393000424_A_get}

var A_arbace_classes_interp_pattern_fn__393000424_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$pattern$fn__393000424", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_pattern_A_class, Simple: "fn__393000424", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_pattern_fn__393000424_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_pattern_fn__393000424_A_class.Info(); i.IsInstance = A_arbace_classes_interp_pattern_fn__393000424_A_InstanceOf; i.Init = A_arbace_classes_interp_pattern_fn__393000424_A_Init; i.Table = A_arbace_classes_interp_pattern_fn__393000424_A_members; jrt.RegisterGoType(A_arbace_classes_interp_pattern_fn__393000424_A_class, reflect.TypeFor[A_arbace_classes_interp_pattern_fn__393000424_A]()) }

func A_arbace_classes_interp_pattern_fn__393000426_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_pattern_fn__393000426_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_pattern_fn__393000426_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_pattern_fn__393000426_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_pattern_fn__393000426_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_pattern_fn__393000426_A_fn_class)}; return nil }

var A_arbace_classes_interp_pattern_fn__393000426_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_pattern_fn__393000426_A_invoke, New: A_arbace_classes_interp_pattern_fn__393000426_A_new, Get: A_arbace_classes_interp_pattern_fn__393000426_A_get}

var A_arbace_classes_interp_pattern_fn__393000426_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$pattern$fn__393000426", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_pattern_A_class, Simple: "fn__393000426", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_pattern_fn__393000426_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_pattern_fn__393000426_A_class.Info(); i.IsInstance = A_arbace_classes_interp_pattern_fn__393000426_A_InstanceOf; i.Init = A_arbace_classes_interp_pattern_fn__393000426_A_Init; i.Table = A_arbace_classes_interp_pattern_fn__393000426_A_members; jrt.RegisterGoType(A_arbace_classes_interp_pattern_fn__393000426_A_class, reflect.TypeFor[A_arbace_classes_interp_pattern_fn__393000426_A]()) }

func A_arbace_classes_interp_pending_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_pending_BANG__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_pending_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_pending_BANG__A_New()}; return nil }

func A_arbace_classes_interp_pending_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_pending_BANG__A_fn_class)}; return nil }

var A_arbace_classes_interp_pending_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_pending_BANG__A_invoke, New: A_arbace_classes_interp_pending_BANG__A_new, Get: A_arbace_classes_interp_pending_BANG__A_get}

var A_arbace_classes_interp_pending_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$pending_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "pending_BANG_", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_pending_BANG__A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_pending_BANG__A_class.Info(); i.IsInstance = A_arbace_classes_interp_pending_BANG__A_InstanceOf; i.Init = A_arbace_classes_interp_pending_BANG__A_Init; i.Table = A_arbace_classes_interp_pending_BANG__A_members; jrt.RegisterGoType(A_arbace_classes_interp_pending_BANG__A_class, reflect.TypeFor[A_arbace_classes_interp_pending_BANG__A]()) }

func A_arbace_classes_interp_pending_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_pending_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_pending_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_pending_QMARK__A_New()}; return nil }

func A_arbace_classes_interp_pending_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_pending_QMARK__A_fn_class)}; return nil }

var A_arbace_classes_interp_pending_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_pending_QMARK__A_invoke, New: A_arbace_classes_interp_pending_QMARK__A_new, Get: A_arbace_classes_interp_pending_QMARK__A_get}

var A_arbace_classes_interp_pending_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$pending_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "pending_QMARK_", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_pending_QMARK__A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_pending_QMARK__A_class.Info(); i.IsInstance = A_arbace_classes_interp_pending_QMARK__A_InstanceOf; i.Init = A_arbace_classes_interp_pending_QMARK__A_Init; i.Table = A_arbace_classes_interp_pending_QMARK__A_members; jrt.RegisterGoType(A_arbace_classes_interp_pending_QMARK__A_class, reflect.TypeFor[A_arbace_classes_interp_pending_QMARK__A]()) }

func A_arbace_classes_interp_ptypes_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_ptypes_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_ptypes_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_ptypes_A_New()}; return nil }

func A_arbace_classes_interp_ptypes_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_ptypes_A_fn_class)}; return nil }

var A_arbace_classes_interp_ptypes_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_ptypes_A_invoke, New: A_arbace_classes_interp_ptypes_A_new, Get: A_arbace_classes_interp_ptypes_A_get}

var A_arbace_classes_interp_ptypes_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$ptypes", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "ptypes", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_ptypes_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_ptypes_A_class.Info(); i.IsInstance = A_arbace_classes_interp_ptypes_A_InstanceOf; i.Init = A_arbace_classes_interp_ptypes_A_Init; i.Table = A_arbace_classes_interp_ptypes_A_members; jrt.RegisterGoType(A_arbace_classes_interp_ptypes_A_class, reflect.TypeFor[A_arbace_classes_interp_ptypes_A]()) }

func A_arbace_classes_interp_publish_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_publish_BANG__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_publish_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_publish_BANG__A_New()}; return nil }

func A_arbace_classes_interp_publish_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_publish_BANG__A_fn_class)}; return nil }

var A_arbace_classes_interp_publish_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_publish_BANG__A_invoke, New: A_arbace_classes_interp_publish_BANG__A_new, Get: A_arbace_classes_interp_publish_BANG__A_get}

var A_arbace_classes_interp_publish_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$publish_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "publish_BANG_", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_publish_BANG__A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_publish_BANG__A_class.Info(); i.IsInstance = A_arbace_classes_interp_publish_BANG__A_InstanceOf; i.Init = A_arbace_classes_interp_publish_BANG__A_Init; i.Table = A_arbace_classes_interp_publish_BANG__A_members; jrt.RegisterGoType(A_arbace_classes_interp_publish_BANG__A_class, reflect.TypeFor[A_arbace_classes_interp_publish_BANG__A]()) }

func A_arbace_classes_interp_publish_BANG__fn__393000821_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_publish_BANG__fn__393000821_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_publish_BANG__fn__393000821_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_publish_BANG__fn__393000821_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_publish_BANG__fn__393000821_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_publish_BANG__fn__393000821_A_fn_class)}; return nil }

var A_arbace_classes_interp_publish_BANG__fn__393000821_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_publish_BANG__fn__393000821_A_invoke, New: A_arbace_classes_interp_publish_BANG__fn__393000821_A_new, Get: A_arbace_classes_interp_publish_BANG__fn__393000821_A_get}

var A_arbace_classes_interp_publish_BANG__fn__393000821_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$publish_BANG_$fn__393000821", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_publish_BANG__A_class, Simple: "fn__393000821", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_publish_BANG__fn__393000821_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_publish_BANG__fn__393000821_A_class.Info(); i.IsInstance = A_arbace_classes_interp_publish_BANG__fn__393000821_A_InstanceOf; i.Init = A_arbace_classes_interp_publish_BANG__fn__393000821_A_Init; i.Table = A_arbace_classes_interp_publish_BANG__fn__393000821_A_members; jrt.RegisterGoType(A_arbace_classes_interp_publish_BANG__fn__393000821_A_class, reflect.TypeFor[A_arbace_classes_interp_publish_BANG__fn__393000821_A]()) }

func A_arbace_classes_interp_publish_members_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_publish_members_BANG__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_publish_members_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_publish_members_BANG__A_New()}; return nil }

func A_arbace_classes_interp_publish_members_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_publish_members_BANG__A_fn_class)}; return nil }

var A_arbace_classes_interp_publish_members_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_publish_members_BANG__A_invoke, New: A_arbace_classes_interp_publish_members_BANG__A_new, Get: A_arbace_classes_interp_publish_members_BANG__A_get}

var A_arbace_classes_interp_publish_members_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$publish_members_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "publish_members_BANG_", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_publish_members_BANG__A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_publish_members_BANG__A_class.Info(); i.IsInstance = A_arbace_classes_interp_publish_members_BANG__A_InstanceOf; i.Init = A_arbace_classes_interp_publish_members_BANG__A_Init; i.Table = A_arbace_classes_interp_publish_members_BANG__A_members; jrt.RegisterGoType(A_arbace_classes_interp_publish_members_BANG__A_class, reflect.TypeFor[A_arbace_classes_interp_publish_members_BANG__A]()) }

func A_arbace_classes_interp_real_method_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_real_method_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_interp_real_method_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_real_method_A_New()}; return nil }

func A_arbace_classes_interp_real_method_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_real_method_A_fn_class)}; return nil }

var A_arbace_classes_interp_real_method_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_real_method_A_invoke, New: A_arbace_classes_interp_real_method_A_new, Get: A_arbace_classes_interp_real_method_A_get}

var A_arbace_classes_interp_real_method_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$real_method", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "real_method", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_real_method_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_real_method_A_class.Info(); i.IsInstance = A_arbace_classes_interp_real_method_A_InstanceOf; i.Init = A_arbace_classes_interp_real_method_A_Init; i.Table = A_arbace_classes_interp_real_method_A_members; jrt.RegisterGoType(A_arbace_classes_interp_real_method_A_class, reflect.TypeFor[A_arbace_classes_interp_real_method_A]()) }

func A_arbace_classes_interp_real_method_fn__393000055_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_real_method_fn__393000055_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_real_method_fn__393000055_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_real_method_fn__393000055_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_real_method_fn__393000055_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_real_method_fn__393000055_A_fn_class)}; return nil }

var A_arbace_classes_interp_real_method_fn__393000055_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_real_method_fn__393000055_A_invoke, New: A_arbace_classes_interp_real_method_fn__393000055_A_new, Get: A_arbace_classes_interp_real_method_fn__393000055_A_get}

var A_arbace_classes_interp_real_method_fn__393000055_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$real_method$fn__393000055", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_real_method_A_class, Simple: "fn__393000055", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_real_method_fn__393000055_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_real_method_fn__393000055_A_class.Info(); i.IsInstance = A_arbace_classes_interp_real_method_fn__393000055_A_InstanceOf; i.Init = A_arbace_classes_interp_real_method_fn__393000055_A_Init; i.Table = A_arbace_classes_interp_real_method_fn__393000055_A_members; jrt.RegisterGoType(A_arbace_classes_interp_real_method_fn__393000055_A_class, reflect.TypeFor[A_arbace_classes_interp_real_method_fn__393000055_A]()) }

func A_arbace_classes_interp_real_method_fn__393000057_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_real_method_fn__393000057_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_real_method_fn__393000057_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_real_method_fn__393000057_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_real_method_fn__393000057_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_real_method_fn__393000057_A_fn_class)}; return nil }

var A_arbace_classes_interp_real_method_fn__393000057_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_real_method_fn__393000057_A_invoke, New: A_arbace_classes_interp_real_method_fn__393000057_A_new, Get: A_arbace_classes_interp_real_method_fn__393000057_A_get}

var A_arbace_classes_interp_real_method_fn__393000057_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$real_method$fn__393000057", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_real_method_A_class, Simple: "fn__393000057", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_real_method_fn__393000057_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_real_method_fn__393000057_A_class.Info(); i.IsInstance = A_arbace_classes_interp_real_method_fn__393000057_A_InstanceOf; i.Init = A_arbace_classes_interp_real_method_fn__393000057_A_Init; i.Table = A_arbace_classes_interp_real_method_fn__393000057_A_members; jrt.RegisterGoType(A_arbace_classes_interp_real_method_fn__393000057_A_class, reflect.TypeFor[A_arbace_classes_interp_real_method_fn__393000057_A]()) }

func A_arbace_classes_interp_receiver_ctx_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_receiver_ctx_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_receiver_ctx_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_receiver_ctx_A_New()}; return nil }

func A_arbace_classes_interp_receiver_ctx_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_receiver_ctx_A_fn_class)}; return nil }

var A_arbace_classes_interp_receiver_ctx_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_receiver_ctx_A_invoke, New: A_arbace_classes_interp_receiver_ctx_A_new, Get: A_arbace_classes_interp_receiver_ctx_A_get}

var A_arbace_classes_interp_receiver_ctx_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$receiver_ctx", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "receiver_ctx", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_receiver_ctx_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_receiver_ctx_A_class.Info(); i.IsInstance = A_arbace_classes_interp_receiver_ctx_A_InstanceOf; i.Init = A_arbace_classes_interp_receiver_ctx_A_Init; i.Table = A_arbace_classes_interp_receiver_ctx_A_members; jrt.RegisterGoType(A_arbace_classes_interp_receiver_ctx_A_class, reflect.TypeFor[A_arbace_classes_interp_receiver_ctx_A]()) }

func A_arbace_classes_interp_record_op_node_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_record_op_node_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_classes_interp_record_op_node_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_record_op_node_A_New()}; return nil }

func A_arbace_classes_interp_record_op_node_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_record_op_node_A_fn_class)}; return nil }

var A_arbace_classes_interp_record_op_node_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_record_op_node_A_invoke, New: A_arbace_classes_interp_record_op_node_A_new, Get: A_arbace_classes_interp_record_op_node_A_get}

var A_arbace_classes_interp_record_op_node_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$record_op_node", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "record_op_node", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_record_op_node_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_record_op_node_A_class.Info(); i.IsInstance = A_arbace_classes_interp_record_op_node_A_InstanceOf; i.Init = A_arbace_classes_interp_record_op_node_A_Init; i.Table = A_arbace_classes_interp_record_op_node_A_members; jrt.RegisterGoType(A_arbace_classes_interp_record_op_node_A_class, reflect.TypeFor[A_arbace_classes_interp_record_op_node_A]()) }

func A_arbace_classes_interp_record_op_node_fn__393000633_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_record_op_node_fn__393000633_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_record_op_node_fn__393000633_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_record_op_node_fn__393000633_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_record_op_node_fn__393000633_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_record_op_node_fn__393000633_A_fn_class)}; return nil }

var A_arbace_classes_interp_record_op_node_fn__393000633_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_record_op_node_fn__393000633_A_invoke, New: A_arbace_classes_interp_record_op_node_fn__393000633_A_new, Get: A_arbace_classes_interp_record_op_node_fn__393000633_A_get}

var A_arbace_classes_interp_record_op_node_fn__393000633_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$record_op_node$fn__393000633", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_record_op_node_A_class, Simple: "fn__393000633", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_record_op_node_fn__393000633_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_record_op_node_fn__393000633_A_class.Info(); i.IsInstance = A_arbace_classes_interp_record_op_node_fn__393000633_A_InstanceOf; i.Init = A_arbace_classes_interp_record_op_node_fn__393000633_A_Init; i.Table = A_arbace_classes_interp_record_op_node_fn__393000633_A_members; jrt.RegisterGoType(A_arbace_classes_interp_record_op_node_fn__393000633_A_class, reflect.TypeFor[A_arbace_classes_interp_record_op_node_fn__393000633_A]()) }

func A_arbace_classes_interp_record_op_node_fn__393000635_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_record_op_node_fn__393000635_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_record_op_node_fn__393000635_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_record_op_node_fn__393000635_A_New()}; return nil }

func A_arbace_classes_interp_record_op_node_fn__393000635_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_record_op_node_fn__393000635_A_fn_class)}; return nil }

var A_arbace_classes_interp_record_op_node_fn__393000635_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_record_op_node_fn__393000635_A_invoke, New: A_arbace_classes_interp_record_op_node_fn__393000635_A_new, Get: A_arbace_classes_interp_record_op_node_fn__393000635_A_get}

var A_arbace_classes_interp_record_op_node_fn__393000635_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$record_op_node$fn__393000635", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_record_op_node_A_class, Simple: "fn__393000635", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_record_op_node_fn__393000635_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_record_op_node_fn__393000635_A_class.Info(); i.IsInstance = A_arbace_classes_interp_record_op_node_fn__393000635_A_InstanceOf; i.Init = A_arbace_classes_interp_record_op_node_fn__393000635_A_Init; i.Table = A_arbace_classes_interp_record_op_node_fn__393000635_A_members; jrt.RegisterGoType(A_arbace_classes_interp_record_op_node_fn__393000635_A_class, reflect.TypeFor[A_arbace_classes_interp_record_op_node_fn__393000635_A]()) }

func A_arbace_classes_interp_republish_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_republish_BANG__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_republish_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_republish_BANG__A_New()}; return nil }

func A_arbace_classes_interp_republish_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_republish_BANG__A_fn_class)}; return nil }

var A_arbace_classes_interp_republish_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_republish_BANG__A_invoke, New: A_arbace_classes_interp_republish_BANG__A_new, Get: A_arbace_classes_interp_republish_BANG__A_get}

var A_arbace_classes_interp_republish_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$republish_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "republish_BANG_", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_republish_BANG__A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_republish_BANG__A_class.Info(); i.IsInstance = A_arbace_classes_interp_republish_BANG__A_InstanceOf; i.Init = A_arbace_classes_interp_republish_BANG__A_Init; i.Table = A_arbace_classes_interp_republish_BANG__A_members; jrt.RegisterGoType(A_arbace_classes_interp_republish_BANG__A_class, reflect.TypeFor[A_arbace_classes_interp_republish_BANG__A]()) }

func A_arbace_classes_interp_republish_BANG__fn__393000832_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_republish_BANG__fn__393000832_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_republish_BANG__fn__393000832_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_republish_BANG__fn__393000832_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_republish_BANG__fn__393000832_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_republish_BANG__fn__393000832_A_fn_class)}; return nil }

var A_arbace_classes_interp_republish_BANG__fn__393000832_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_republish_BANG__fn__393000832_A_invoke, New: A_arbace_classes_interp_republish_BANG__fn__393000832_A_new, Get: A_arbace_classes_interp_republish_BANG__fn__393000832_A_get}

var A_arbace_classes_interp_republish_BANG__fn__393000832_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$republish_BANG_$fn__393000832", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_republish_BANG__A_class, Simple: "fn__393000832", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_republish_BANG__fn__393000832_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_republish_BANG__fn__393000832_A_class.Info(); i.IsInstance = A_arbace_classes_interp_republish_BANG__fn__393000832_A_InstanceOf; i.Init = A_arbace_classes_interp_republish_BANG__fn__393000832_A_Init; i.Table = A_arbace_classes_interp_republish_BANG__fn__393000832_A_members; jrt.RegisterGoType(A_arbace_classes_interp_republish_BANG__fn__393000832_A_class, reflect.TypeFor[A_arbace_classes_interp_republish_BANG__fn__393000832_A]()) }

func A_arbace_classes_interp_republish_BANG__fn__393000834_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_republish_BANG__fn__393000834_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_interp_republish_BANG__fn__393000834_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_republish_BANG__fn__393000834_A_New_O(args[0])}; return nil }

func A_arbace_classes_interp_republish_BANG__fn__393000834_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_republish_BANG__fn__393000834_A_fn_class)}; return nil }

var A_arbace_classes_interp_republish_BANG__fn__393000834_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_republish_BANG__fn__393000834_A_invoke, New: A_arbace_classes_interp_republish_BANG__fn__393000834_A_new, Get: A_arbace_classes_interp_republish_BANG__fn__393000834_A_get}

var A_arbace_classes_interp_republish_BANG__fn__393000834_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$republish_BANG_$fn__393000834", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_interp_republish_BANG__A_class, Simple: "fn__393000834", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_republish_BANG__fn__393000834_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_republish_BANG__fn__393000834_A_class.Info(); i.IsInstance = A_arbace_classes_interp_republish_BANG__fn__393000834_A_InstanceOf; i.Init = A_arbace_classes_interp_republish_BANG__fn__393000834_A_Init; i.Table = A_arbace_classes_interp_republish_BANG__fn__393000834_A_members; jrt.RegisterGoType(A_arbace_classes_interp_republish_BANG__fn__393000834_A_class, reflect.TypeFor[A_arbace_classes_interp_republish_BANG__fn__393000834_A]()) }

func A_arbace_classes_interp_sibling_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_sibling_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_sibling_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_sibling_QMARK__A_New()}; return nil }

func A_arbace_classes_interp_sibling_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_sibling_QMARK__A_fn_class)}; return nil }

var A_arbace_classes_interp_sibling_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_sibling_QMARK__A_invoke, New: A_arbace_classes_interp_sibling_QMARK__A_new, Get: A_arbace_classes_interp_sibling_QMARK__A_get}

var A_arbace_classes_interp_sibling_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$sibling_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "sibling_QMARK_", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_sibling_QMARK__A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_sibling_QMARK__A_class.Info(); i.IsInstance = A_arbace_classes_interp_sibling_QMARK__A_InstanceOf; i.Init = A_arbace_classes_interp_sibling_QMARK__A_Init; i.Table = A_arbace_classes_interp_sibling_QMARK__A_members; jrt.RegisterGoType(A_arbace_classes_interp_sibling_QMARK__A_class, reflect.TypeFor[A_arbace_classes_interp_sibling_QMARK__A]()) }

func A_arbace_classes_interp_sig_class_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_sig_class_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_sig_class_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_sig_class_A_New()}; return nil }

func A_arbace_classes_interp_sig_class_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_sig_class_A_fn_class)}; return nil }

var A_arbace_classes_interp_sig_class_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_sig_class_A_invoke, New: A_arbace_classes_interp_sig_class_A_new, Get: A_arbace_classes_interp_sig_class_A_get}

var A_arbace_classes_interp_sig_class_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$sig_class", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "sig_class", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_sig_class_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_sig_class_A_class.Info(); i.IsInstance = A_arbace_classes_interp_sig_class_A_InstanceOf; i.Init = A_arbace_classes_interp_sig_class_A_Init; i.Table = A_arbace_classes_interp_sig_class_A_members; jrt.RegisterGoType(A_arbace_classes_interp_sig_class_A_class, reflect.TypeFor[A_arbace_classes_interp_sig_class_A]()) }

func A_arbace_classes_interp_slot_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_slot_BANG__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_slot_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_slot_BANG__A_New()}; return nil }

func A_arbace_classes_interp_slot_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_slot_BANG__A_fn_class)}; return nil }

var A_arbace_classes_interp_slot_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_slot_BANG__A_invoke, New: A_arbace_classes_interp_slot_BANG__A_new, Get: A_arbace_classes_interp_slot_BANG__A_get}

var A_arbace_classes_interp_slot_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$slot_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "slot_BANG_", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_slot_BANG__A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_slot_BANG__A_class.Info(); i.IsInstance = A_arbace_classes_interp_slot_BANG__A_InstanceOf; i.Init = A_arbace_classes_interp_slot_BANG__A_Init; i.Table = A_arbace_classes_interp_slot_BANG__A_members; jrt.RegisterGoType(A_arbace_classes_interp_slot_BANG__A_class, reflect.TypeFor[A_arbace_classes_interp_slot_BANG__A]()) }

func A_arbace_classes_interp_static_index_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_static_index_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_static_index_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_static_index_A_New()}; return nil }

func A_arbace_classes_interp_static_index_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_static_index_A_fn_class)}; return nil }

var A_arbace_classes_interp_static_index_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_static_index_A_invoke, New: A_arbace_classes_interp_static_index_A_new, Get: A_arbace_classes_interp_static_index_A_get}

var A_arbace_classes_interp_static_index_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$static_index", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "static_index", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_static_index_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_static_index_A_class.Info(); i.IsInstance = A_arbace_classes_interp_static_index_A_InstanceOf; i.Init = A_arbace_classes_interp_static_index_A_Init; i.Table = A_arbace_classes_interp_static_index_A_members; jrt.RegisterGoType(A_arbace_classes_interp_static_index_A_class, reflect.TypeFor[A_arbace_classes_interp_static_index_A]()) }

func A_arbace_classes_interp_super_outer_fields_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_super_outer_fields_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_interp_super_outer_fields_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_super_outer_fields_A_New()}; return nil }

func A_arbace_classes_interp_super_outer_fields_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_super_outer_fields_A_fn_class)}; return nil }

var A_arbace_classes_interp_super_outer_fields_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_super_outer_fields_A_invoke, New: A_arbace_classes_interp_super_outer_fields_A_new, Get: A_arbace_classes_interp_super_outer_fields_A_get}

var A_arbace_classes_interp_super_outer_fields_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$super_outer_fields", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "super_outer_fields", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_super_outer_fields_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_super_outer_fields_A_class.Info(); i.IsInstance = A_arbace_classes_interp_super_outer_fields_A_InstanceOf; i.Init = A_arbace_classes_interp_super_outer_fields_A_Init; i.Table = A_arbace_classes_interp_super_outer_fields_A_members; jrt.RegisterGoType(A_arbace_classes_interp_super_outer_fields_A_class, reflect.TypeFor[A_arbace_classes_interp_super_outer_fields_A]()) }

func A_arbace_classes_interp_target_code_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_target_code_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_target_code_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_target_code_A_New()}; return nil }

func A_arbace_classes_interp_target_code_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_target_code_A_fn_class)}; return nil }

var A_arbace_classes_interp_target_code_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_target_code_A_invoke, New: A_arbace_classes_interp_target_code_A_new, Get: A_arbace_classes_interp_target_code_A_get}

var A_arbace_classes_interp_target_code_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$target_code", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "target_code", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_target_code_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_target_code_A_class.Info(); i.IsInstance = A_arbace_classes_interp_target_code_A_InstanceOf; i.Init = A_arbace_classes_interp_target_code_A_Init; i.Table = A_arbace_classes_interp_target_code_A_members; jrt.RegisterGoType(A_arbace_classes_interp_target_code_A_class, reflect.TypeFor[A_arbace_classes_interp_target_code_A]()) }

func A_arbace_classes_interp_tc_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_tc_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_tc_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_tc_A_New()}; return nil }

func A_arbace_classes_interp_tc_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_tc_A_fn_class)}; return nil }

var A_arbace_classes_interp_tc_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_tc_A_invoke, New: A_arbace_classes_interp_tc_A_new, Get: A_arbace_classes_interp_tc_A_get}

var A_arbace_classes_interp_tc_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$tc", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "tc", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_tc_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_tc_A_class.Info(); i.IsInstance = A_arbace_classes_interp_tc_A_InstanceOf; i.Init = A_arbace_classes_interp_tc_A_Init; i.Table = A_arbace_classes_interp_tc_A_members; jrt.RegisterGoType(A_arbace_classes_interp_tc_A_class, reflect.TypeFor[A_arbace_classes_interp_tc_A]()) }

func A_arbace_classes_interp_this0_index_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_this0_index_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_this0_index_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_this0_index_A_New()}; return nil }

func A_arbace_classes_interp_this0_index_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_this0_index_A_fn_class)}; return nil }

var A_arbace_classes_interp_this0_index_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_this0_index_A_invoke, New: A_arbace_classes_interp_this0_index_A_new, Get: A_arbace_classes_interp_this0_index_A_get}

var A_arbace_classes_interp_this0_index_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$this0_index", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "this0_index", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_this0_index_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_this0_index_A_class.Info(); i.IsInstance = A_arbace_classes_interp_this0_index_A_InstanceOf; i.Init = A_arbace_classes_interp_this0_index_A_Init; i.Table = A_arbace_classes_interp_this0_index_A_members; jrt.RegisterGoType(A_arbace_classes_interp_this0_index_A_class, reflect.TypeFor[A_arbace_classes_interp_this0_index_A]()) }

func A_arbace_classes_interp_trivial_super_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_trivial_super_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_interp_trivial_super_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_trivial_super_QMARK__A_New()}; return nil }

func A_arbace_classes_interp_trivial_super_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_trivial_super_QMARK__A_fn_class)}; return nil }

var A_arbace_classes_interp_trivial_super_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_trivial_super_QMARK__A_invoke, New: A_arbace_classes_interp_trivial_super_QMARK__A_new, Get: A_arbace_classes_interp_trivial_super_QMARK__A_get}

var A_arbace_classes_interp_trivial_super_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$trivial_super_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "trivial_super_QMARK_", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_trivial_super_QMARK__A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_trivial_super_QMARK__A_class.Info(); i.IsInstance = A_arbace_classes_interp_trivial_super_QMARK__A_InstanceOf; i.Init = A_arbace_classes_interp_trivial_super_QMARK__A_Init; i.Table = A_arbace_classes_interp_trivial_super_QMARK__A_members; jrt.RegisterGoType(A_arbace_classes_interp_trivial_super_QMARK__A_class, reflect.TypeFor[A_arbace_classes_interp_trivial_super_QMARK__A]()) }

func A_arbace_classes_interp_value_convert_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_value_convert_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_interp_value_convert_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_value_convert_A_New()}; return nil }

func A_arbace_classes_interp_value_convert_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_value_convert_A_fn_class)}; return nil }

var A_arbace_classes_interp_value_convert_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_value_convert_A_invoke, New: A_arbace_classes_interp_value_convert_A_new, Get: A_arbace_classes_interp_value_convert_A_get}

var A_arbace_classes_interp_value_convert_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$value_convert", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "value_convert", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_value_convert_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_value_convert_A_class.Info(); i.IsInstance = A_arbace_classes_interp_value_convert_A_InstanceOf; i.Init = A_arbace_classes_interp_value_convert_A_Init; i.Table = A_arbace_classes_interp_value_convert_A_members; jrt.RegisterGoType(A_arbace_classes_interp_value_convert_A_class, reflect.TypeFor[A_arbace_classes_interp_value_convert_A]()) }

func A_arbace_classes_interp_vt_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_vt_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_vt_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_vt_A_New()}; return nil }

func A_arbace_classes_interp_vt_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_vt_A_fn_class)}; return nil }

var A_arbace_classes_interp_vt_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_vt_A_invoke, New: A_arbace_classes_interp_vt_A_new, Get: A_arbace_classes_interp_vt_A_get}

var A_arbace_classes_interp_vt_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$vt", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "vt", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_vt_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_vt_A_class.Info(); i.IsInstance = A_arbace_classes_interp_vt_A_InstanceOf; i.Init = A_arbace_classes_interp_vt_A_Init; i.Table = A_arbace_classes_interp_vt_A_members; jrt.RegisterGoType(A_arbace_classes_interp_vt_A_class, reflect.TypeFor[A_arbace_classes_interp_vt_A]()) }

func A_arbace_classes_interp_vtable_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_vtable_BANG__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_vtable_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_vtable_BANG__A_New()}; return nil }

func A_arbace_classes_interp_vtable_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_vtable_BANG__A_fn_class)}; return nil }

var A_arbace_classes_interp_vtable_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_vtable_BANG__A_invoke, New: A_arbace_classes_interp_vtable_BANG__A_new, Get: A_arbace_classes_interp_vtable_BANG__A_get}

var A_arbace_classes_interp_vtable_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$vtable_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "vtable_BANG_", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_vtable_BANG__A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_vtable_BANG__A_class.Info(); i.IsInstance = A_arbace_classes_interp_vtable_BANG__A_InstanceOf; i.Init = A_arbace_classes_interp_vtable_BANG__A_Init; i.Table = A_arbace_classes_interp_vtable_BANG__A_members; jrt.RegisterGoType(A_arbace_classes_interp_vtable_BANG__A_class, reflect.TypeFor[A_arbace_classes_interp_vtable_BANG__A]()) }

func A_arbace_classes_interp_zero_of_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_interp_zero_of_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_interp_zero_of_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp_zero_of_A_New()}; return nil }

func A_arbace_classes_interp_zero_of_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_interp_zero_of_A_fn_class)}; return nil }

var A_arbace_classes_interp_zero_of_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_interp_zero_of_A_invoke, New: A_arbace_classes_interp_zero_of_A_new, Get: A_arbace_classes_interp_zero_of_A_get}

var A_arbace_classes_interp_zero_of_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp$zero_of", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_interp_A_class, Simple: "zero_of", Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp_zero_of_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp_zero_of_A_class.Info(); i.IsInstance = A_arbace_classes_interp_zero_of_A_InstanceOf; i.Init = A_arbace_classes_interp_zero_of_A_Init; i.Table = A_arbace_classes_interp_zero_of_A_members; jrt.RegisterGoType(A_arbace_classes_interp_zero_of_A_class, reflect.TypeFor[A_arbace_classes_interp_zero_of_A]()) }

func A_arbace_classes_interp__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_classes_interp__init_A_Load__O(); case 1: return A_arbace_classes_interp__init_A_Unit0__O(); case 2: return A_arbace_classes_interp__init_A_Unit1__O(); case 3: return A_arbace_classes_interp__init_A_Unit10__O(); case 4: return A_arbace_classes_interp__init_A_Unit100__O(); case 5: return A_arbace_classes_interp__init_A_Unit101__O(); case 6: return A_arbace_classes_interp__init_A_Unit102__O(); case 7: return A_arbace_classes_interp__init_A_Unit103__O(); case 8: return A_arbace_classes_interp__init_A_Unit104__O(); case 9: return A_arbace_classes_interp__init_A_Unit105__O(); case 10: return A_arbace_classes_interp__init_A_Unit106__O(); case 11: return A_arbace_classes_interp__init_A_Unit107__O(); case 12: return A_arbace_classes_interp__init_A_Unit108__O(); case 13: return A_arbace_classes_interp__init_A_Unit109__O(); case 14: return A_arbace_classes_interp__init_A_Unit11__O(); case 15: return A_arbace_classes_interp__init_A_Unit110__O(); case 16: return A_arbace_classes_interp__init_A_Unit111__O(); case 17: return A_arbace_classes_interp__init_A_Unit112__O(); case 18: return A_arbace_classes_interp__init_A_Unit113__O(); case 19: return A_arbace_classes_interp__init_A_Unit114__O(); case 20: return A_arbace_classes_interp__init_A_Unit115__O(); case 21: return A_arbace_classes_interp__init_A_Unit116__O(); case 22: return A_arbace_classes_interp__init_A_Unit117__O(); case 23: return A_arbace_classes_interp__init_A_Unit118__O(); case 24: return A_arbace_classes_interp__init_A_Unit119__O(); case 25: return A_arbace_classes_interp__init_A_Unit12__O(); case 26: return A_arbace_classes_interp__init_A_Unit120__O(); case 27: return A_arbace_classes_interp__init_A_Unit121__O(); case 28: return A_arbace_classes_interp__init_A_Unit122__O(); case 29: return A_arbace_classes_interp__init_A_Unit123__O(); case 30: return A_arbace_classes_interp__init_A_Unit124__O(); case 31: return A_arbace_classes_interp__init_A_Unit125__O(); case 32: return A_arbace_classes_interp__init_A_Unit126__O(); case 33: return A_arbace_classes_interp__init_A_Unit127__O(); case 34: return A_arbace_classes_interp__init_A_Unit128__O(); case 35: return A_arbace_classes_interp__init_A_Unit129__O(); case 36: return A_arbace_classes_interp__init_A_Unit13__O(); case 37: return A_arbace_classes_interp__init_A_Unit130__O(); case 38: return A_arbace_classes_interp__init_A_Unit131__O(); case 39: return A_arbace_classes_interp__init_A_Unit132__O(); case 40: return A_arbace_classes_interp__init_A_Unit133__O(); case 41: return A_arbace_classes_interp__init_A_Unit134__O(); case 42: return A_arbace_classes_interp__init_A_Unit135__O(); case 43: return A_arbace_classes_interp__init_A_Unit136__O(); case 44: return A_arbace_classes_interp__init_A_Unit137__O(); case 45: return A_arbace_classes_interp__init_A_Unit138__O(); case 46: return A_arbace_classes_interp__init_A_Unit139__O(); case 47: return A_arbace_classes_interp__init_A_Unit14__O(); case 48: return A_arbace_classes_interp__init_A_Unit140__O(); case 49: return A_arbace_classes_interp__init_A_Unit141__O(); case 50: return A_arbace_classes_interp__init_A_Unit142__O(); case 51: return A_arbace_classes_interp__init_A_Unit143__O(); case 52: return A_arbace_classes_interp__init_A_Unit144__O(); case 53: return A_arbace_classes_interp__init_A_Unit145__O(); case 54: return A_arbace_classes_interp__init_A_Unit146__O(); case 55: return A_arbace_classes_interp__init_A_Unit147__O(); case 56: return A_arbace_classes_interp__init_A_Unit148__O(); case 57: return A_arbace_classes_interp__init_A_Unit149__O(); case 58: return A_arbace_classes_interp__init_A_Unit15__O(); case 59: return A_arbace_classes_interp__init_A_Unit16__O(); case 60: return A_arbace_classes_interp__init_A_Unit17__O(); case 61: return A_arbace_classes_interp__init_A_Unit18__O(); case 62: return A_arbace_classes_interp__init_A_Unit19__O(); case 63: return A_arbace_classes_interp__init_A_Unit2__O(); case 64: return A_arbace_classes_interp__init_A_Unit20__O(); case 65: return A_arbace_classes_interp__init_A_Unit21__O(); case 66: return A_arbace_classes_interp__init_A_Unit22__O(); case 67: return A_arbace_classes_interp__init_A_Unit23__O(); case 68: return A_arbace_classes_interp__init_A_Unit24__O(); case 69: return A_arbace_classes_interp__init_A_Unit25__O(); case 70: return A_arbace_classes_interp__init_A_Unit26__O(); case 71: return A_arbace_classes_interp__init_A_Unit27__O(); case 72: return A_arbace_classes_interp__init_A_Unit28__O(); case 73: return A_arbace_classes_interp__init_A_Unit29__O(); case 74: return A_arbace_classes_interp__init_A_Unit3__O(); case 75: return A_arbace_classes_interp__init_A_Unit30__O(); case 76: return A_arbace_classes_interp__init_A_Unit31__O(); case 77: return A_arbace_classes_interp__init_A_Unit32__O(); case 78: return A_arbace_classes_interp__init_A_Unit33__O(); case 79: return A_arbace_classes_interp__init_A_Unit34__O(); case 80: return A_arbace_classes_interp__init_A_Unit35__O(); case 81: return A_arbace_classes_interp__init_A_Unit36__O(); case 82: return A_arbace_classes_interp__init_A_Unit37__O(); case 83: return A_arbace_classes_interp__init_A_Unit38__O(); case 84: return A_arbace_classes_interp__init_A_Unit39__O(); case 85: return A_arbace_classes_interp__init_A_Unit4__O(); case 86: return A_arbace_classes_interp__init_A_Unit40__O(); case 87: return A_arbace_classes_interp__init_A_Unit41__O(); case 88: return A_arbace_classes_interp__init_A_Unit42__O(); case 89: return A_arbace_classes_interp__init_A_Unit43__O(); case 90: return A_arbace_classes_interp__init_A_Unit44__O(); case 91: return A_arbace_classes_interp__init_A_Unit45__O(); case 92: return A_arbace_classes_interp__init_A_Unit46__O(); case 93: return A_arbace_classes_interp__init_A_Unit47__O(); case 94: return A_arbace_classes_interp__init_A_Unit48__O(); case 95: return A_arbace_classes_interp__init_A_Unit49__O(); case 96: return A_arbace_classes_interp__init_A_Unit5__O(); case 97: return A_arbace_classes_interp__init_A_Unit50__O(); case 98: return A_arbace_classes_interp__init_A_Unit51__O(); case 99: return A_arbace_classes_interp__init_A_Unit52__O(); case 100: return A_arbace_classes_interp__init_A_Unit53__O(); case 101: return A_arbace_classes_interp__init_A_Unit54__O(); case 102: return A_arbace_classes_interp__init_A_Unit55__O(); case 103: return A_arbace_classes_interp__init_A_Unit56__O(); case 104: return A_arbace_classes_interp__init_A_Unit57__O(); case 105: return A_arbace_classes_interp__init_A_Unit58__O(); case 106: return A_arbace_classes_interp__init_A_Unit59__O(); case 107: return A_arbace_classes_interp__init_A_Unit6__O(); case 108: return A_arbace_classes_interp__init_A_Unit60__O(); case 109: return A_arbace_classes_interp__init_A_Unit61__O(); case 110: return A_arbace_classes_interp__init_A_Unit62__O(); case 111: return A_arbace_classes_interp__init_A_Unit63__O(); case 112: return A_arbace_classes_interp__init_A_Unit64__O(); case 113: return A_arbace_classes_interp__init_A_Unit65__O(); case 114: return A_arbace_classes_interp__init_A_Unit66__O(); case 115: return A_arbace_classes_interp__init_A_Unit67__O(); case 116: return A_arbace_classes_interp__init_A_Unit68__O(); case 117: return A_arbace_classes_interp__init_A_Unit69__O(); case 118: return A_arbace_classes_interp__init_A_Unit7__O(); case 119: return A_arbace_classes_interp__init_A_Unit70__O(); case 120: return A_arbace_classes_interp__init_A_Unit71__O(); case 121: return A_arbace_classes_interp__init_A_Unit72__O(); case 122: return A_arbace_classes_interp__init_A_Unit73__O(); case 123: return A_arbace_classes_interp__init_A_Unit74__O(); case 124: return A_arbace_classes_interp__init_A_Unit75__O(); case 125: return A_arbace_classes_interp__init_A_Unit76__O(); case 126: return A_arbace_classes_interp__init_A_Unit77__O(); case 127: return A_arbace_classes_interp__init_A_Unit78__O(); case 128: return A_arbace_classes_interp__init_A_Unit79__O(); case 129: return A_arbace_classes_interp__init_A_Unit8__O(); case 130: return A_arbace_classes_interp__init_A_Unit80__O(); case 131: return A_arbace_classes_interp__init_A_Unit81__O(); case 132: return A_arbace_classes_interp__init_A_Unit82__O(); case 133: return A_arbace_classes_interp__init_A_Unit83__O(); case 134: return A_arbace_classes_interp__init_A_Unit84__O(); case 135: return A_arbace_classes_interp__init_A_Unit85__O(); case 136: return A_arbace_classes_interp__init_A_Unit86__O(); case 137: return A_arbace_classes_interp__init_A_Unit87__O(); case 138: return A_arbace_classes_interp__init_A_Unit88__O(); case 139: return A_arbace_classes_interp__init_A_Unit89__O(); case 140: return A_arbace_classes_interp__init_A_Unit9__O(); case 141: return A_arbace_classes_interp__init_A_Unit90__O(); case 142: return A_arbace_classes_interp__init_A_Unit91__O(); case 143: return A_arbace_classes_interp__init_A_Unit92__O(); case 144: return A_arbace_classes_interp__init_A_Unit93__O(); case 145: return A_arbace_classes_interp__init_A_Unit94__O(); case 146: return A_arbace_classes_interp__init_A_Unit95__O(); case 147: return A_arbace_classes_interp__init_A_Unit96__O(); case 148: return A_arbace_classes_interp__init_A_Unit97__O(); case 149: return A_arbace_classes_interp__init_A_Unit98__O(); case 150: return A_arbace_classes_interp__init_A_Unit99__O()}; return nil }

func A_arbace_classes_interp__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_interp__init_A_New()}; return nil }

var A_arbace_classes_interp__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit100 ()Ljava.lang.Object;\nM9 unit101 ()Ljava.lang.Object;\nM9 unit102 ()Ljava.lang.Object;\nM9 unit103 ()Ljava.lang.Object;\nM9 unit104 ()Ljava.lang.Object;\nM9 unit105 ()Ljava.lang.Object;\nM9 unit106 ()Ljava.lang.Object;\nM9 unit107 ()Ljava.lang.Object;\nM9 unit108 ()Ljava.lang.Object;\nM9 unit109 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit110 ()Ljava.lang.Object;\nM9 unit111 ()Ljava.lang.Object;\nM9 unit112 ()Ljava.lang.Object;\nM9 unit113 ()Ljava.lang.Object;\nM9 unit114 ()Ljava.lang.Object;\nM9 unit115 ()Ljava.lang.Object;\nM9 unit116 ()Ljava.lang.Object;\nM9 unit117 ()Ljava.lang.Object;\nM9 unit118 ()Ljava.lang.Object;\nM9 unit119 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit120 ()Ljava.lang.Object;\nM9 unit121 ()Ljava.lang.Object;\nM9 unit122 ()Ljava.lang.Object;\nM9 unit123 ()Ljava.lang.Object;\nM9 unit124 ()Ljava.lang.Object;\nM9 unit125 ()Ljava.lang.Object;\nM9 unit126 ()Ljava.lang.Object;\nM9 unit127 ()Ljava.lang.Object;\nM9 unit128 ()Ljava.lang.Object;\nM9 unit129 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit130 ()Ljava.lang.Object;\nM9 unit131 ()Ljava.lang.Object;\nM9 unit132 ()Ljava.lang.Object;\nM9 unit133 ()Ljava.lang.Object;\nM9 unit134 ()Ljava.lang.Object;\nM9 unit135 ()Ljava.lang.Object;\nM9 unit136 ()Ljava.lang.Object;\nM9 unit137 ()Ljava.lang.Object;\nM9 unit138 ()Ljava.lang.Object;\nM9 unit139 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit140 ()Ljava.lang.Object;\nM9 unit141 ()Ljava.lang.Object;\nM9 unit142 ()Ljava.lang.Object;\nM9 unit143 ()Ljava.lang.Object;\nM9 unit144 ()Ljava.lang.Object;\nM9 unit145 ()Ljava.lang.Object;\nM9 unit146 ()Ljava.lang.Object;\nM9 unit147 ()Ljava.lang.Object;\nM9 unit148 ()Ljava.lang.Object;\nM9 unit149 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit28 ()Ljava.lang.Object;\nM9 unit29 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit30 ()Ljava.lang.Object;\nM9 unit31 ()Ljava.lang.Object;\nM9 unit32 ()Ljava.lang.Object;\nM9 unit33 ()Ljava.lang.Object;\nM9 unit34 ()Ljava.lang.Object;\nM9 unit35 ()Ljava.lang.Object;\nM9 unit36 ()Ljava.lang.Object;\nM9 unit37 ()Ljava.lang.Object;\nM9 unit38 ()Ljava.lang.Object;\nM9 unit39 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit40 ()Ljava.lang.Object;\nM9 unit41 ()Ljava.lang.Object;\nM9 unit42 ()Ljava.lang.Object;\nM9 unit43 ()Ljava.lang.Object;\nM9 unit44 ()Ljava.lang.Object;\nM9 unit45 ()Ljava.lang.Object;\nM9 unit46 ()Ljava.lang.Object;\nM9 unit47 ()Ljava.lang.Object;\nM9 unit48 ()Ljava.lang.Object;\nM9 unit49 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit50 ()Ljava.lang.Object;\nM9 unit51 ()Ljava.lang.Object;\nM9 unit52 ()Ljava.lang.Object;\nM9 unit53 ()Ljava.lang.Object;\nM9 unit54 ()Ljava.lang.Object;\nM9 unit55 ()Ljava.lang.Object;\nM9 unit56 ()Ljava.lang.Object;\nM9 unit57 ()Ljava.lang.Object;\nM9 unit58 ()Ljava.lang.Object;\nM9 unit59 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit60 ()Ljava.lang.Object;\nM9 unit61 ()Ljava.lang.Object;\nM9 unit62 ()Ljava.lang.Object;\nM9 unit63 ()Ljava.lang.Object;\nM9 unit64 ()Ljava.lang.Object;\nM9 unit65 ()Ljava.lang.Object;\nM9 unit66 ()Ljava.lang.Object;\nM9 unit67 ()Ljava.lang.Object;\nM9 unit68 ()Ljava.lang.Object;\nM9 unit69 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit70 ()Ljava.lang.Object;\nM9 unit71 ()Ljava.lang.Object;\nM9 unit72 ()Ljava.lang.Object;\nM9 unit73 ()Ljava.lang.Object;\nM9 unit74 ()Ljava.lang.Object;\nM9 unit75 ()Ljava.lang.Object;\nM9 unit76 ()Ljava.lang.Object;\nM9 unit77 ()Ljava.lang.Object;\nM9 unit78 ()Ljava.lang.Object;\nM9 unit79 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit80 ()Ljava.lang.Object;\nM9 unit81 ()Ljava.lang.Object;\nM9 unit82 ()Ljava.lang.Object;\nM9 unit83 ()Ljava.lang.Object;\nM9 unit84 ()Ljava.lang.Object;\nM9 unit85 ()Ljava.lang.Object;\nM9 unit86 ()Ljava.lang.Object;\nM9 unit87 ()Ljava.lang.Object;\nM9 unit88 ()Ljava.lang.Object;\nM9 unit89 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nM9 unit90 ()Ljava.lang.Object;\nM9 unit91 ()Ljava.lang.Object;\nM9 unit92 ()Ljava.lang.Object;\nM9 unit93 ()Ljava.lang.Object;\nM9 unit94 ()Ljava.lang.Object;\nM9 unit95 ()Ljava.lang.Object;\nM9 unit96 ()Ljava.lang.Object;\nM9 unit97 ()Ljava.lang.Object;\nM9 unit98 ()Ljava.lang.Object;\nM9 unit99 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_classes_interp__init_A_invoke, New: A_arbace_classes_interp__init_A_new}

var A_arbace_classes_interp__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.interp__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_classes_interp.A_arbace_classes_interp__init_A", Source: "interp.ae"})

func init() { i := A_arbace_classes_interp__init_A_class.Info(); i.IsInstance = A_arbace_classes_interp__init_A_InstanceOf; i.Init = A_arbace_classes_interp__init_A_Init; i.Table = A_arbace_classes_interp__init_A_members; jrt.RegisterGoType(A_arbace_classes_interp__init_A_class, reflect.TypeFor[A_arbace_classes_interp__init_A]()) }
