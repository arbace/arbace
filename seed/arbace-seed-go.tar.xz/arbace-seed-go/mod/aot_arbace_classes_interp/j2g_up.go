//line j2g_up.ae:1
package aot_arbace_classes_interp

import "arbace/lang"


func Up_Namespace_AReference(p *lang.Namespace) lang.AReference_I { if p == nil { return nil }; return p }

func Up_PersistentVector_IPersistentVector(p *lang.PersistentVector) lang.IPersistentVector { if p == nil { return nil }; return p }
