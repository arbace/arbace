//line j2g_strings.ae:1
package aot_arbace_classes_interp

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn20,arbace.classes.typesyn1,tyn18,arbace.classes.envyn3,envyn20,arbace.classes.parseyn1,pyn22,arbace.classes.analyzeyn1,akn3,dockn13,declared-onlyks6,arbace13,compile-errorks21,arbace.classes.interp7,pendingkn4,nullkn4,nonekn4,elsekn5,classkn5,klasskn5,slotskn2,nrkn2,npkn7,targetskn3,retkn4,selfkn4,typekn2,idkn6,fieldskn11,field-indexkn12,static-indexkn8,receiverkn5,slot0kn3,symkn13,capture-indexkn5,constkn2,opkn3,valkn1,bkn4,pathkn4,basekn4,exprkn4,fromkn2,tokn6,familykn1,okn4,argskn5,exactkn4,ushrkn3,shrkn3,shlkn3,cmpkn1,tkn4,testkn4,thenkn10,statementskn8,bindingskn6,targetkn3,brkkn3,reckn5,kindskn5,typeskn4,bodykn7,catcheskn7,classeskn7,finallykn14,normal-finallykn4,lockkn4,kindkn5,ownerkn4,namekn4,desckn11,array-clonekn7,no-castkn7,cast-tokn6,statickn7,specialkn8,captureskn5,superkn11,super-outerkn20,super-outer-is-outerkn5,outerkn16,super-outer-pathkn4,ctorkn10,enum-constkn7,ordinalkn15,outer-instance?kn10,clj-constskn5,statekn4,initkn3,varkn2,nskn4,readkn4,textks21,arbace.classes.interp4,nonekn5,fieldkn4,dimskn5,elemskn5,arraykn5,indexkn5,partskn4,nodekn9,tag-constkn7,literalkn5,eagerkn6,hiddenkn3,arrkn2,itkn3,lenkn1,ikn4,collkn8,iteratorkn4,elemkn6,recordkn7,patternkn5,compskn8,accessorkn5,caseskn6,labelskn3,intkn3,selkn7,defaultkn5,guardkn6,stringkn4,enumkn5,flagskn10,clojure-fnkn4,metakn4,anonkn5,localkn7,methodskn10,interfaceskn7,nestingkn4,declkn10,own-fieldskn7,staticskn10,componentskn7,derivedkn6,bridgekn9,bridge-ofkn11,enum-valueskn20,record-object-methodkn15,record-accessorkn9,componentkn12,enum-$valueskn12,enum-valueOfkn9,constantskn11,calls-superkn9,enum-argskn9,anon-argskn6,paramskn4,thiskn10,enum-slotskn9,ctor-sitekn6,bodieskn4,recvkn9,enum-bodykn11,nested-callkn8,prologuekn4,callkn7,compactkn16,record-canonicalkn11,compile-setkn7,klasseskn5,orderkn3,topkn6,lambdakn8,boundarykn9,uses-thiskn3,samkn2,fikn7,markerskn9,inst-desckn5,boundkn3,newkn7,unboundkn10,null-checkkn6,clinitkn13,switch-holderkn6,memberkn6,simplekn6,loaderkn8,counterskn11,switch-mapskn14,switch-holderskn12,source-triedkn14,assert-holderskn12,holder-firstkn8,siblingsv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,V3,R10,R2,R11,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn21,arbace.classes.interpm2,R12,s763,The Go build's Java forms (doc/go/CLASSFORMS-REPL.md): the classes of Java forms made at run\n  time, their code interpreted. arbace.classes.analyze analyzes the Java forms as for the JVM\n  (declarations, members, what javac derives, code into typed nodes); in place of\n  arbace.classes.emit, this namespace builds, from the analyzed nodes, the nodes of the\n  interpreter (arbace.lang.Compiler$CF, Java forms translated into the program), one tree per\n  method on its first call, and makes the classes through the host (Compiler$CF$Rt/HOST: on Go\n  classes made at run time, Dyn, J2G-SPEC §5.12).\n\n  It is a namespace of the Go build (arbace/lang/go/ns/), and loads on the JVM too, where the\n  interpreter is tested against the compiled classes (test/classforms/).v11,arbace.core7,string?v11,arbace.core3,notv11,arbace.core9,contains?v21,arbace.classes.interp9,*klasses*R13,v22,arbace.classes.analyze4,declv11,arbace.core7,ex-infov13,arbace.string7,replaceR14,R15,v11,arbace.core7,ex-datav21,arbace.classes.interp7,*eager*v21,arbace.classes.interp8,sibling?v21,arbace.classes.interp8,pending!v21,arbace.classes.interp8,registryv18,arbace.classes.env10,load-classv11,arbace.core5,mergem2,R14,TR16,c78,R17,c88,v11,arbace.core8,keyword?c76,R18,c91,v21,arbace.classes.interp2,tcv21,arbace.classes.interp12,prim-classesC16,java.lang.Objectv20,arbace.classes.types6,array?v20,arbace.classes.types9,elem-typev20,arbace.classes.types11,class-desc?v21,arbace.classes.interp5,klassv20,arbace.classes.types14,desc->internalv11,arbace.core5,applyv11,arbace.core3,strv11,arbace.core6,repeatv20,arbace.classes.types10,array-dimsv20,arbace.classes.types16,desc->class-namev21,arbace.classes.interp4,failv21,arbace.classes.interp11,desc->classv20,arbace.classes.types14,internal->descR19,R20,R21,v11,arbace.core4,atomR22,l0,R23,R24,R25,R26,l-1,v21,arbace.classes.interp4,kindc68,c74,v11,arbace.core5,swap!v11,arbace.core3,incR27,v21,arbace.classes.interp5,slot!v11,arbace.core5,assocR28,v11,arbace.core10,into-arrayC28,arbace.lang.Compiler$CF$NodeR29,R30,R31,v21,arbace.classes.interp12,static-indexv11,arbace.core4,somev21,arbace.classes.interp11,find-staticv11,arbace.core3,seqC15,java.lang.Classv11,arbace.core3,mapv11,arbace.core5,firstv20,arbace.classes.types17,parse-method-descv21,arbace.classes.interp9,params-ofv21,arbace.classes.interp11,find-methodv21,arbace.classes.interp11,real-methodv21,arbace.classes.interp10,find-fieldR32,R33,R34,R35,v22,arbace.classes.analyze10,value-typev20,arbace.classes.types5,prim?v20,arbace.classes.types8,unbox-ofR36,R37,v11,arbace.core4,not=v21,arbace.classes.interp5,konstv22,arbace.classes.analyze13,const-of-typeR38,v21,arbace.classes.interp7,convertv21,arbace.classes.interp4,nodev20,arbace.classes.types6,box-ofv18,arbace.classes.env11,assignable?v21,arbace.classes.interp8,build-opv21,arbace.classes.interp10,local-nodeR39,v21,arbace.classes.interp6,coercev21,arbace.classes.interp11,this0-indexR40,R41,R42,R43,R44,v11,arbace.core4,nextv11,arbace.core8,to-arrayR45,R46,R47,v21,arbace.classes.interp9,arith-opsc70,c73,R48,S3,R49,R50,R51,S3,R49,R50,R51,R52,R53,v21,arbace.classes.interp7,cmp-opsS2,s1,Fs1,Dv11,arbace.core6,secondv21,arbace.classes.interp2,vtv21,arbace.classes.interp5,nodesv21,arbace.classes.interp6,and-orS2,R16,R17,R54,R55,R56,R57,v11,arbace.core6,reducev21,arbace.classes.interp5,bind!R58,v11,arbace.core8,assoc-inR59,v21,arbace.classes.interp11,target-codeR60,v11,arbace.core4,mapvR61,R62,R63,v21,arbace.classes.interp8,let-nodeS2,s1,VR17,c86,S2,s1,VR17,R64,v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv11,arbace.core4,restR65,v11,arbace.core6,concatv21,arbace.classes.interp15,internal->classC29,arbace.lang.Compiler$CF$KlassR66,R67,v11,arbace.core11,map-indexedv11,arbace.core6,vectorR68,v21,arbace.classes.interp9,method-ofR69,R70,R71,R72,R73,R74,R75,R76,v21,arbace.classes.interp9,arg-nodesv21,arbace.classes.interp6,ptypesR77,S3,s8,toStrings8,hashCodes6,equalsR78,R79,R80,R81,R82,R83,R84,v11,arbace.core3,vecv21,arbace.classes.interp15,implicit-fieldsv21,arbace.classes.interp18,super-outer-fieldsv21,arbace.classes.interp9,ctor-methR85,R86,R87,v18,arbace.classes.env4,infoC26,arbace.lang.Compiler$CF$RtV2,c76,c76,R88,R89,R90,R91,R92,R93,R94,v11,arbace.core19,pop-thread-bindingsR95,v11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core11,*read-eval*R96,v13,arbace.string12,starts-with?v21,arbace.classes.interp15,clj-const-valuev21,arbace.classes.interp11,field-indexR97,v11,arbace.core7,iterateR98,R99,R100,R101,C16,java.lang.StringR102,R103,R104,R105,R106,R107,R108,R109,R110,R111,R112,R113,v11,arbace.core4,subsl2,R114,C27,arbace.lang.Compiler$CF$Patv21,arbace.classes.interp7,patternR115,R116,v21,arbace.classes.interp13,accessor-nodeR117,S3,R16,s1,VR17,S3,R16,s1,VR17,R118,R119,R120,R121,R122,R123,R124,R125,v11,arbace.core5,char?R126,v21,arbace.classes.interp13,build-method!v21,arbace.classes.interp4,has?v21,arbace.classes.interp13,ACC_INTERFACER127,R128,v20,arbace.classes.types10,lang-classv11,arbace.core6,removev21,arbace.classes.interp10,ACC_STATICS2,R129,R130,V1,s6,this$0v21,arbace.classes.interp7,zero-ofv11,arbace.core6,filterR131,v21,arbace.classes.interp4,hostv11,arbace.core4,keepR132,R133,v18,arbace.classes.env11,const-valuev11,arbace.core5,some?v11,arbace.core8,boolean?l1,S2,s1,Fs1,DS2,s1,Fs1,DS2,s1,Fs1,DR134,R135,v11,arbace.core4,intoR136,v21,arbace.classes.interp7,meth-ofv21,arbace.classes.interp12,ACC_ABSTRACTv21,arbace.classes.interp11,ACC_PRIVATEv21,arbace.classes.interp7,new-ctxR137,R138,R139,R140,v21,arbace.classes.interp13,value-convertR141,R142,R143,R144,v21,arbace.classes.interp14,record-op-nodeR145,R146,R147,C14,java.lang.EnumV2,c76,c76,S2,s16,java/lang/Records16,java/lang/ObjectR148,v21,arbace.classes.interp10,init-nodesR149,v21,arbace.classes.interp14,enum-arg-nodesV2,c76,c73,R150,R151,v21,arbace.classes.interp14,trivial-super?R152,R153,R154,R155,R156,v21,arbace.classes.interp7,ctx-forv21,arbace.classes.interp12,receiver-ctxR157,v21,arbace.classes.interp7,params!V2,c76,c73,v21,arbace.classes.interp14,ctor-call-nodeR158,R159,R160,R161,R162,v21,arbace.classes.interp7,finish!v21,arbace.classes.interp12,derived-bodyl256,v11,arbace.core8,identityV1,C16,java.lang.StringV1,c76,v18,arbace.classes.env13,*compile-set*R163,R164,R165,v22,arbace.classes.analyze6,*unit*v11,arbace.core6,subvecv20,arbace.classes.parse11,parse-classR166,v22,arbace.classes.analyze8,top-namev22,arbace.classes.analyze14,declare-class!m2,R133,R166,m2,R133,R166,v22,arbace.classes.analyze12,update-decl!m2,R133,R166,m2,R133,R166,v21,arbace.classes.interp17,declare-siblings!v22,arbace.classes.analyze16,process-classes!v21,arbace.classes.interp12,lambda-countR167,v21,arbace.classes.interp7,vtable!v21,arbace.classes.interp8,publish!R168,R169,R170,v21,arbace.classes.interp16,new-lambda-klassR171,R172,V1,c76,v21,arbace.classes.interp12,lambda-done!R173,R174,v11,arbace.core4,takeR175,R176,R177,V1,c76,v21,arbace.classes.interp8,pending?v21,arbace.classes.interp15,*pending-types*v21,arbace.classes.interp9,sig-classv21,arbace.classes.interp16,publish-members!v21,arbace.classes.interp7,waitingv11,arbace.core6,updatev11,arbace.core4,fnilv11,arbace.core6,dissocv21,arbace.classes.interp12,meth-classesR178,v11,arbace.core14,with-redefs-fnv22,arbace.classes.analyze11,accessorizev21,arbace.classes.interp13,analyze-formsR179,v22,arbace.classes.analyze16,supertypes-firstv21,arbace.classes.interp10,make-klassv21,arbace.classes.interp7,clinit!R180,v21,arbace.classes.interp7,layout!R181,v18,arbace.classes.env7,definedR182,v21,arbace.classes.interp10,republish!R183,R184,R185,R186,R187,R188,R189,v21,arbace.classes.interp7,define!")

var Lit_1 *jrt.String = jrt.Intern("No accessor ")

var Lit_2 *jrt.String = jrt.Intern("arbace.classes.interp$analyze_forms$iter__393000763__393000767")

var Lit_3 *jrt.String = jrt.Intern("arbace.classes.interp$analyze_forms$iter__393000763__393000767$fn__393000768")

var Lit_4 *jrt.String = jrt.Intern("arbace.classes.interp$analyze_forms$iter__393000763__393000767$fn__393000768$fn__393000769")

var Lit_5 *jrt.String = jrt.Intern("arbace.classes.interp$and_or$fn__393000165")

var Lit_6 *jrt.String = jrt.Intern("Z")

var Lit_7 *jrt.String = jrt.Intern("arbace.classes.interp$arg_nodes$fn__393000290")

var Lit_8 *jrt.String = jrt.Intern("<init>")

var Lit_9 *jrt.String = jrt.Intern("V")

var Lit_10 *jrt.String = jrt.Intern("Ljava/lang/String;")

var Lit_11 *jrt.String = jrt.Intern("I")

var Lit_12 *jrt.String = jrt.Intern("arbace.classes.interp$build_method_BANG_$call_node__393000710")

var Lit_13 *jrt.String = jrt.Intern("arbace.classes.interp$build_method_BANG_$fn__393000712")

var Lit_14 *jrt.String = jrt.Intern("arbace.classes.interp$build_method_BANG_$iter__393000714__393000718")

var Lit_15 *jrt.String = jrt.Intern("arbace.classes.interp$build_method_BANG_$iter__393000733__393000737")

var Lit_16 *jrt.String = jrt.Intern("java.lang.UnsatisfiedLinkError")

var Lit_17 *jrt.String = jrt.Intern(".")

var Lit_18 *jrt.String = jrt.Intern("/")

var Lit_19 *jrt.String = jrt.Intern("arbace.classes.interp$build_method_BANG_$iter__393000743__393000747")

var Lit_20 *jrt.String = jrt.Intern("Method ")

var Lit_21 *jrt.String = jrt.Intern(" of ")

var Lit_22 *jrt.String = jrt.Intern(" has no body")

var Lit_23 *jrt.String = jrt.Intern("arbace.classes.interp$build_method_BANG_$iter__393000714__393000718$fn__393000719")

var Lit_24 *jrt.String = jrt.Intern("arbace.classes.interp$build_method_BANG_$iter__393000714__393000718$fn__393000719$fn__393000720")

var Lit_25 *jrt.String = jrt.Intern("arbace.classes.interp$build_method_BANG_$iter__393000733__393000737$fn__393000738")

var Lit_26 *jrt.String = jrt.Intern("arbace.classes.interp$build_method_BANG_$iter__393000733__393000737$fn__393000738$fn__393000739")

var Lit_27 *jrt.String = jrt.Intern("arbace.classes.interp$build_method_BANG_$iter__393000743__393000747$fn__393000748")

var Lit_28 *jrt.String = jrt.Intern("arbace.classes.interp$build_method_BANG_$iter__393000743__393000747$fn__393000748$fn__393000749")

var Lit_29 *jrt.String = jrt.Intern("arbace.classes.interp$clinit_BANG_$build__393000876")

var Lit_30 *jrt.String = jrt.Intern("arbace.classes.interp$clinit_BANG_$fn__393000880")

var Lit_31 *jrt.String = jrt.Intern("<clinit>")

var Lit_32 *jrt.String = jrt.Intern("()V")

var Lit_33 *jrt.String = jrt.Intern("arbace.classes.interp$clinit_BANG_$fn__393000882")

var Lit_34 *jrt.String = jrt.Intern("arbace.classes.interp$clinit_BANG_$build__393000876$fn__393000877")

var Lit_35 *jrt.String = jrt.Intern("arbace.classes.interp$clj_const_value$fn__393000334")

var Lit_36 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_37 *jrt.String = jrt.Intern("arbace.classes.interp$ctor_call_node$inits__393000693")

var Lit_38 *jrt.String = jrt.Intern("(Ljava/lang/String;I)V")

var Lit_39 *jrt.String = jrt.Intern("arbace.classes.interp$ctor_call_node$fn__393000695")

var Lit_40 *jrt.String = jrt.Intern("this$0")

var Lit_41 *jrt.String = jrt.Intern("No constructor ")

var Lit_42 *jrt.String = jrt.Intern(" in ")

var Lit_43 *jrt.String = jrt.Intern("arbace.classes.interp$define_BANG_$fn__393000889")

var Lit_44 *jrt.String = jrt.Intern("arbace.classes.interp$define_BANG_$fn__393000891")

var Lit_45 *jrt.String = jrt.Intern("arbace.classes.interp$define_BANG_$fn__393000891$fn__393000892")

var Lit_46 *jrt.String = jrt.Intern("arbace.classes.interp$define_BANG_$fn__393000891$iter__393000894__393000898")

var Lit_47 *jrt.String = jrt.Intern("doInvoke(")

var Lit_48 *jrt.String = jrt.Intern("doInvoke")

var Lit_49 *jrt.String = jrt.Intern("arbace.classes.interp$define_BANG_$fn__393000891$fn__393000940")

var Lit_50 *jrt.String = jrt.Intern("values()[")

var Lit_51 *jrt.String = jrt.Intern("arbace.classes.interp$define_BANG_$fn__393000891$fn__393000994")

var Lit_52 *jrt.String = jrt.Intern("arbace.classes.interp$define_BANG_$fn__393000891$fn__393000940$fn__393000952")

var Lit_53 *jrt.String = jrt.Intern("arbace.classes.interp$define_BANG_$fn__393000891$fn__393000940$fn__393000957")

var Lit_54 *jrt.String = jrt.Intern("arbace.classes.interp$define_BANG_$fn__393000891$fn__393000940$fn__393000966")

var Lit_55 *jrt.String = jrt.Intern("arbace.classes.interp$define_BANG_$fn__393000891$fn__393000940$fn__393000971")

var Lit_56 *jrt.String = jrt.Intern("arbace.classes.interp$define_BANG_$fn__393000891$iter__393000894__393000898$fn__393000899")

var Lit_57 *jrt.String = jrt.Intern("arbace.classes.interp$define_BANG_$fn__393000891$iter__393000894__393000898$fn__393000899$fn__393000900")

var Lit_58 *jrt.String = jrt.Intern("arbace.classes.interp$derived_body$iter__393000645__393000649")

var Lit_59 *jrt.String = jrt.Intern("arbace.classes.interp$derived_body$fn__393000655")

var Lit_60 *jrt.String = jrt.Intern("No bridge target ")

var Lit_61 *jrt.String = jrt.Intern("$VALUES")

var Lit_62 *jrt.String = jrt.Intern("[")

var Lit_63 *jrt.String = jrt.Intern("arbace.classes.interp$derived_body$iter__393000660__393000664")

var Lit_64 *jrt.String = jrt.Intern("arbace.classes.interp$derived_body$iter__393000670__393000674")

var Lit_65 *jrt.String = jrt.Intern("valueOf")

var Lit_66 *jrt.String = jrt.Intern("(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;")

var Lit_67 *jrt.String = jrt.Intern("Ljava/lang/Class;")

var Lit_68 *jrt.String = jrt.Intern("The Go build's Java forms do not support ")

var Lit_69 *jrt.String = jrt.Intern(" yet")

var Lit_70 *jrt.String = jrt.Intern("arbace.classes.interp$derived_body$iter__393000645__393000649$fn__393000650")

var Lit_71 *jrt.String = jrt.Intern("arbace.classes.interp$derived_body$iter__393000645__393000649$fn__393000650$fn__393000651")

var Lit_72 *jrt.String = jrt.Intern("arbace.classes.interp$derived_body$iter__393000660__393000664$fn__393000665")

var Lit_73 *jrt.String = jrt.Intern("arbace.classes.interp$derived_body$iter__393000660__393000664$fn__393000665$fn__393000666")

var Lit_74 *jrt.String = jrt.Intern("arbace.classes.interp$derived_body$iter__393000670__393000674$fn__393000675")

var Lit_75 *jrt.String = jrt.Intern("arbace.classes.interp$derived_body$iter__393000670__393000674$fn__393000675$fn__393000676")

var Lit_76 *jrt.String = jrt.Intern("arbace.classes.interp$desc__GT_class$fn__393000025")

var Lit_77 *jrt.String = jrt.Intern("Ljava.lang.Object;")

var Lit_78 *jrt.String = jrt.Intern("Class not found: ")

var Lit_79 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Rt")

var Lit_80 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Klass")

var Lit_81 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Meth")

var Lit_82 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Node")

var Lit_83 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Const")

var Lit_84 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Local")

var Lit_85 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$SetLocal")

var Lit_86 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$SelfField")

var Lit_87 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$OuterPath")

var Lit_88 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$ArithJ")

var Lit_89 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$ArithD")

var Lit_90 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Conv")

var Lit_91 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Boxing")

var Lit_92 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Unbox")

var Lit_93 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Cmp")

var Lit_94 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Test")

var Lit_95 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$IsInst")

var Lit_96 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$CheckCast")

var Lit_97 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$NullChecked")

var Lit_98 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Do")

var Lit_99 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Let")

var Lit_100 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Labeled")

var Lit_101 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Jump")

var Lit_102 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Recur")

var Lit_103 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$If")

var Lit_104 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$AndOr")

var Lit_105 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Throw")

var Lit_106 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Try")

var Lit_107 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Monitor")

var Lit_108 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$CallI")

var Lit_109 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$CallV")

var Lit_110 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$CallR")

var Lit_111 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$ObjectCall")

var Lit_112 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$VarDeref")

var Lit_113 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$VarInvoke")

var Lit_114 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$FiAdapter")

var Lit_115 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$NewI")

var Lit_116 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$CtorCall")

var Lit_117 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$NewR")

var Lit_118 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$GetField")

var Lit_119 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$SetField")

var Lit_120 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$GetStatic")

var Lit_121 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$SetStatic")

var Lit_122 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$FieldR")

var Lit_123 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$NewArray")

var Lit_124 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$ArrayInit")

var Lit_125 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Aget")

var Lit_126 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Aset")

var Lit_127 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Alength")

var Lit_128 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$ArrayClone")

var Lit_129 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$JavaStr")

var Lit_130 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$ForEach")

var Lit_131 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Pat")

var Lit_132 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Switch")

var Lit_133 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$IfInstance")

var Lit_134 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$MakeLambda")

var Lit_135 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$RecordOp")

var Lit_136 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$SuperCtor")

var Lit_137 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$SuperCall")

var Lit_138 *jrt.String = jrt.Intern("java.lang.reflect.Method")

var Lit_139 *jrt.String = jrt.Intern("java.lang.reflect.Constructor")

var Lit_140 *jrt.String = jrt.Intern("java.lang.reflect.Field")

var Lit_141 *jrt.String = jrt.Intern("java.lang.reflect.Modifier")

var Lit_142 *jrt.String = jrt.Intern("set! of a local not in this frame: ")

var Lit_143 *jrt.String = jrt.Intern("No receiver for an outer instance here")

var Lit_144 *jrt.String = jrt.Intern("cls")

var Lit_145 *jrt.String = jrt.Intern("arith ")

var Lit_146 *jrt.String = jrt.Intern("arith of type ")

var Lit_147 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000176$fn__393000177$branch__393000178")

var Lit_148 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000183$fn__393000184$fn__393000185")

var Lit_149 *jrt.String = jrt.Intern("break target not in scope")

var Lit_150 *jrt.String = jrt.Intern("recur target not in scope")

var Lit_151 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000227$fn__393000228$fn__393000229")

var Lit_152 *jrt.String = jrt.Intern("Ljava/lang/Object;")

var Lit_153 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000241$fn__393000242$conv__393000243")

var Lit_154 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000241$fn__393000242$fn__393000245")

var Lit_155 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000241$fn__393000242$fn__393000247")

var Lit_156 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000241$fn__393000242$iter__393000249__393000255")

var Lit_157 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000241$fn__393000242$fn__393000269")

var Lit_158 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000241$fn__393000242$fn__393000275")

var Lit_159 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000241$fn__393000242$iter__393000249__393000255$fn__393000256")

var Lit_160 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000241$fn__393000242$iter__393000249__393000255$fn__393000256$iter__393000251__393000260")

var Lit_161 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000241$fn__393000242$iter__393000249__393000255$fn__393000256$iter__393000251__393000260$fn__393000261")

var Lit_162 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000241$fn__393000242$iter__393000249__393000255$fn__393000256$iter__393000251__393000260$fn__393000261$fn__393000262")

var Lit_163 *jrt.String = jrt.Intern("No method ")

var Lit_164 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000298$fn__393000299$fn__393000302")

var Lit_165 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000319$fn__393000320$fn__393000324")

var Lit_166 *jrt.String = jrt.Intern("matchException")

var Lit_167 *jrt.String = jrt.Intern("(Ljava/lang/String;Ljava/lang/Throwable;)Ljava/lang/RuntimeException;")

var Lit_168 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000319$fn__393000320$fn__393000327")

var Lit_169 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000319$fn__393000320$fn__393000329")

var Lit_170 *jrt.String = jrt.Intern("java/lang/MatchException")

var Lit_171 *jrt.String = jrt.Intern("const__")

var Lit_172 *jrt.String = jrt.Intern("$assertionsDisabled")

var Lit_173 *jrt.String = jrt.Intern("No static field ")

var Lit_174 *jrt.String = jrt.Intern("No field ")

var Lit_175 *jrt.String = jrt.Intern("No var for ")

var Lit_176 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000368$fn__393000369$fn__393000370")

var Lit_177 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000379$fn__393000380$fn__393000381")

var Lit_178 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000386$fn__393000387$fn__393000388")

var Lit_179 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000404$fn__393000405$fn__393000406")

var Lit_180 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000404$fn__393000405$fn__393000408")

var Lit_181 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000404$fn__393000405$fn__393000410")

var Lit_182 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000404$fn__393000405$fn__393000412")

var Lit_183 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000429$fn__393000430$br__393000431")

var Lit_184 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000435$fn__393000436$arm__393000437")

var Lit_185 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000435$fn__393000436$iter__393000439__393000445")

var Lit_186 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000435$fn__393000436$fn__393000460")

var Lit_187 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000435$fn__393000436$fn__393000466")

var Lit_188 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000435$fn__393000436$iter__393000471__393000475")

var Lit_189 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000435$fn__393000436$fn__393000519")

var Lit_190 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000435$fn__393000436$fn__393000525")

var Lit_191 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000435$fn__393000436$fn__393000530")

var Lit_192 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000435$fn__393000436$fn__393000534")

var Lit_193 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000435$fn__393000436$iter__393000439__393000445$fn__393000446")

var Lit_194 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000435$fn__393000436$iter__393000439__393000445$fn__393000446$iter__393000441__393000450")

var Lit_195 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000435$fn__393000436$iter__393000439__393000445$fn__393000446$iter__393000441__393000450$fn__393000451")

var Lit_196 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000435$fn__393000436$iter__393000439__393000445$fn__393000446$iter__393000441__393000450$fn__393000451$fn__393000452")

var Lit_197 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000435$fn__393000436$iter__393000471__393000475$fn__393000476")

var Lit_198 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000435$fn__393000436$iter__393000471__393000475$fn__393000476$fn__393000477")

var Lit_199 *jrt.String = jrt.Intern("Constructor call outside the constructor prologue")

var Lit_200 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000781$fn__393000782$fn__393000783")

var Lit_201 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000781$fn__393000782$fn__393000785")

var Lit_202 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000781$fn__393000782$fn__393000787")

var Lit_203 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000792$fn__393000793$fn__393000802")

var Lit_204 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000792$fn__393000793$fn__393000804")

var Lit_205 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000792$fn__393000793$conv_args__393000806")

var Lit_206 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000792$fn__393000793$fn__393000812")

var Lit_207 *jrt.String = jrt.Intern("The Go build's Java forms do not support variable arity method references yet")

var Lit_208 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000792$fn__393000793$conv_args__393000806$fn__393000807")

var Lit_209 *jrt.String = jrt.Intern("arbace.lang.Compiler$CFGo$GoHost")

var Lit_210 *jrt.String = jrt.Intern("arbace.classes.interp$find_field$fn__393000061")

var Lit_211 *jrt.String = jrt.Intern("arbace.classes.interp$find_field$fn__393000064")

var Lit_212 *jrt.String = jrt.Intern("arbace.classes.interp$find_method$fn__393000045")

var Lit_213 *jrt.String = jrt.Intern("arbace.classes.interp$find_method$fn__393000047")

var Lit_214 *jrt.String = jrt.Intern("arbace.classes.interp$find_method$fn__393000050")

var Lit_215 *jrt.String = jrt.Intern("arbace.classes.interp$find_static$fn__393000040")

var Lit_216 *jrt.String = jrt.Intern("arbace.classes.interp$implicit_fields$iter__393000307__393000311")

var Lit_217 *jrt.String = jrt.Intern("arbace.classes.interp$implicit_fields$iter__393000307__393000311$fn__393000312")

var Lit_218 *jrt.String = jrt.Intern("arbace.classes.interp$implicit_fields$iter__393000307__393000311$fn__393000312$fn__393000313")

var Lit_219 *jrt.String = jrt.Intern("arbace.classes.interp$init_nodes$fn__393000688")

var Lit_220 *jrt.String = jrt.Intern("The Go build's Java forms cannot extend ")

var Lit_221 *jrt.String = jrt.Intern("arbace.classes.interp$layout_BANG_$fn__393000554")

var Lit_222 *jrt.String = jrt.Intern("arbace.classes.interp$layout_BANG_$fn__393000556")

var Lit_223 *jrt.String = jrt.Intern("arbace.classes.interp$layout_BANG_$fn__393000558")

var Lit_224 *jrt.String = jrt.Intern("arbace.classes.interp$layout_BANG_$fn__393000560")

var Lit_225 *jrt.String = jrt.Intern("arbace.classes.interp$layout_BANG_$fn__393000572")

var Lit_226 *jrt.String = jrt.Intern("arbace.classes.interp$layout_BANG_$fn__393000574")

var Lit_227 *jrt.String = jrt.Intern("arbace.classes.interp$layout_BANG_$fn__393000576")

var Lit_228 *jrt.String = jrt.Intern("arbace.classes.interp$layout_BANG_$fn__393000578")

var Lit_229 *jrt.String = jrt.Intern("val$")

var Lit_230 *jrt.String = jrt.Intern("arbace.classes.interp$let_node$fn__393000191")

var Lit_231 *jrt.String = jrt.Intern("arbace.classes.interp$let_node$fn__393000197")

var Lit_232 *jrt.String = jrt.Intern("arbace.classes.interp$let_node$fn__393000203")

var Lit_233 *jrt.String = jrt.Intern("arbace.classes.interp$let_node$fn__393000208")

var Lit_234 *jrt.String = jrt.Intern("No receiver here: ")

var Lit_235 *jrt.String = jrt.Intern("info")

var Lit_236 *jrt.String = jrt.Intern("Local not available here: ")

var Lit_237 *jrt.String = jrt.Intern("AFunction")

var Lit_238 *jrt.String = jrt.Intern("RestFn")

var Lit_239 *jrt.String = jrt.Intern("arbace.classes.interp$meth_of$fn__393000546")

var Lit_240 *jrt.String = jrt.Intern("arbace.classes.interp$method_of$fn__393000295")

var Lit_241 *jrt.String = jrt.Intern("$$Lambda/")

var Lit_242 *jrt.String = jrt.Intern("arbace.classes.interp$params_BANG_$fn__393000624")

var Lit_243 *jrt.String = jrt.Intern("arbace.classes.interp$params_BANG_$fn__393000626")

var Lit_244 *jrt.String = jrt.Intern("arbace.classes.interp$pattern$fn__393000424")

var Lit_245 *jrt.String = jrt.Intern("arbace.classes.interp$pattern$fn__393000426")

var Lit_246 *jrt.String = jrt.Intern("Class ")

var Lit_247 *jrt.String = jrt.Intern(" (a Java form of the enclosing do) is not defined yet")

var Lit_248 *jrt.String = jrt.Intern("arbace.classes.interp$publish_BANG_$fn__393000821")

var Lit_249 *jrt.String = jrt.Intern("arbace.classes.interp$real_method$fn__393000055")

var Lit_250 *jrt.String = jrt.Intern("arbace.classes.interp$real_method$fn__393000057")

var Lit_251 *jrt.String = jrt.Intern("hashCode")

var Lit_252 *jrt.String = jrt.Intern("equals")

var Lit_253 *jrt.String = jrt.Intern("arbace.classes.interp$record_op_node$fn__393000633")

var Lit_254 *jrt.String = jrt.Intern("arbace.classes.interp$record_op_node$fn__393000635")

var Lit_255 *jrt.String = jrt.Intern("arbace.classes.interp$republish_BANG_$fn__393000832")

var Lit_256 *jrt.String = jrt.Intern("arbace.classes.interp$republish_BANG_$fn__393000834")

var Lit_257 *jrt.String = jrt.Intern("Not an interpreted class: ")

var Lit_258 *jrt.String = jrt.Intern("No outer instance in ")

var Lit_259 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn4,linekn6,columnkn4,filekn7,dynamickn8,arglistsyn1,nyn1,ekn3,tagyn29,arbace.lang.Compiler$CF$Klasskn7,privateyn3,msgyn1,&yn4,datayn2,tyyn1,dyn15,java.lang.Classyn3,clsyn3,retyn3,ctxyn1,bkn8,declaredyn1,vyn2,xsyn2,idyn4,rec?yn5,fnameyn4,descyn5,Classyn5,mnameyn24,java.lang.reflect.Methodyn5,owneryn23,java.lang.reflect.Fieldyn28,arbace.lang.Compiler$CF$Nodeyn4,fromyn2,toyn2,ankn3,addkn3,subkn3,mulkn3,divkn3,remkn3,negkn3,inckn3,deckn3,andkn2,orkn3,xorkn3,shlkn3,shrkn4,ushrkn3,notkn6,andnotkn1,<kn2,<=kn1,>kn2,>=kn2,==kn2,!=kn7,defaultkn5,constkn4,nonekn5,localkn9,set-localyn1,ckn9,this-pathkn16,outer-param-pathkn9,class-litkn7,convertkn12,null-checkedkn4,castkn9,instance?kn5,arithkn7,comparekn4,nil?kn10,identical?kn5,bool=yn3,or?kn2,ifkn2,doyn5,loop?kn3,letkn4,loopkn5,labelkn5,breakkn5,recurkn6,returnkn5,throwkn3,trykn7,monitorkn6,assertyn4,argsyn3,keyyn28,arbace.lang.Compiler$CF$Methkn6,invokeyn2,cnyn8,outer-ankn3,newkn10,get-statickn10,set-statickn9,get-fieldkn9,set-fieldkn9,var-derefkn10,var-invokekn10,fi-adapterkn9,new-arraykn10,array-initkn4,agetkn4,asetkn7,alengthkn8,java-strkn8,for-eachv11,arbace.core5,in-nsMyn21,arbace.classes.interpm2,R0,s763,The Go build's Java forms (doc/go/CLASSFORMS-REPL.md): the classes of Java forms made at run\n  time, their code interpreted. arbace.classes.analyze analyzes the Java forms as for the JVM\n  (declarations, members, what javac derives, code into typed nodes); in place of\n  arbace.classes.emit, this namespace builds, from the analyzed nodes, the nodes of the\n  interpreter (arbace.lang.Compiler$CF, Java forms translated into the program), one tree per\n  method on its first call, and makes the classes through the host (Compiler$CF$Rt/HOST: on Go\n  classes made at run time, Dyn, J2G-SPEC §5.12).\n\n  It is a namespace of the Go build (arbace/lang/go/ns/), and loads on the JVM too, where the\n  interpreter is tested against the compiled classes (test/classforms/).m2,R0,s763,The Go build's Java forms (doc/go/CLASSFORMS-REPL.md): the classes of Java forms made at run\n  time, their code interpreted. arbace.classes.analyze analyzes the Java forms as for the JVM\n  (declarations, members, what javac derives, code into typed nodes); in place of\n  arbace.classes.emit, this namespace builds, from the analyzed nodes, the nodes of the\n  interpreter (arbace.lang.Compiler$CF, Java forms translated into the program), one tree per\n  method on its first call, and makes the classes through the host (Compiler$CF$Rt/HOST: on Go\n  classes made at run time, Dyn, J2G-SPEC §5.12).\n\n  It is a namespace of the Go build (arbace/lang/go/ns/), and loads on the JVM too, where the\n  interpreter is tested against the compiled classes (test/classforms/).R1,v21,arbace.classes.interp8,registrym8,R0,s78,internal name -> the Klass of the interpreted class of that name defined last.R2,i39,R3,i1,R4,s24,arbace/classes/interp.aev11,arbace.core4,atomm8,R0,s78,internal name -> the Klass of the interpreted class of that name defined last.R2,i39,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp9,*klasses*m10,R5,TR2,i42,R3,i1,R4,s24,arbace/classes/interp.aeR0,s69,internal name -> Klass of the classes of the compilation being built.v21,arbace.classes.interp7,*eager*m10,R5,TR2,i46,R3,i1,R4,s24,arbace/classes/interp.aeR0,s168,True while define! builds the compilation's bodies, before any of its methods is called: a\n  sibling class (below) is then pending even when a class of its name exists.v21,arbace.classes.interp8,sibling?m10,R6,L1,V1,R7,R0,s171,Is n a class of the enclosing top-level do entered as a declaration (SPEC §9.2): declared in\n  the compilation being built, compiled and defined by a later form of the do?R2,i51,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp8,pending!m10,R6,L1,V1,R7,R0,s200,Throws the signal that a body refers to sibling class n, not defined yet (define! leaves that\n  body to be built on its first call, when the do's later forms have defined n; at that call, an\n  error).R2,i57,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp8,pending?m8,R6,L1,V1,R8,R2,i65,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp5,klassm10,R6,L1,MV1,R7,m2,R9,R10,R0,s259,The Klass of internal name n when n is an interpreted class (of this compilation, or defined\n  earlier and still the class of that name), else nil. A sibling while define! builds the\n  bodies (*eager*): pending, the class of that name defined later by the do.R2,i67,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp4,failm10,R11,TR6,L1,V3,R12,R13,V1,R14,R2,i80,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp2,tcm10,R6,L1,V1,R15,R0,s134,The type char of a node or binding type: the descriptor's first char for primitives and V,\n  L for references, N for null, X for none.R2,i85,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp4,kindm8,R6,L1,V1,R15,R2,i94,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp12,prim-classesm8,R11,TR2,i96,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp11,desc->classm10,R6,L1,MV1,R16,m2,R9,R17,R0,s147,The Class of a descriptor: a primitive's, an interpreted class's (nil on the JVM's test host,\n  where it is Object), an array's, or a loaded class.R2,i100,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp15,internal->classm8,R6,L1,MV1,R7,m2,R9,R17,R2,i119,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp7,new-ctxm8,R6,L1,V2,R18,R19,R2,i128,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp5,slot!m10,R6,L1,V2,R20,R15,R0,s72,A new slot for a value of type ty (in the long slots for J and D kinds).R2,i132,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp5,bind!m10,R6,L1,V2,R20,R21,R0,s33,A slot for binding b (by its id).R2,i139,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp4,nodem8,R22,TR2,i147,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp6,coercem8,R22,TR2,i147,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp5,konstm10,R9,C28,arbace.lang.Compiler$CF$NodeR6,L1,V2,R15,R23,R2,i149,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp5,nodesm8,R6,L1,MV1,R24,m2,R9,s31,[Larbace.lang.Compiler$CF$Node;R2,i151,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp11,target-codem10,R11,TR6,L1,V2,R25,R26,R2,i154,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp15,instance-fieldsm10,R6,L1,V1,Myn1,km2,R9,R10,R0,s148,The instance fields of interpreted class n in order: [{:name :desc :flags :owner}], its\n  superclasses' first; then the hidden ones (this$0, val$x).R2,i158,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp11,field-indexm10,R6,L1,V2,Myn1,km2,R9,R10,R27,R0,s92,The index of field `fname` of interpreted class k (or of an interpreted superclass), or nil.R2,i164,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp12,static-indexm8,R6,L1,V2,Myn1,km2,R9,R10,R27,R2,i173,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp11,find-staticm12,R11,TR6,L1,V2,Myn1,km2,R9,R10,R27,R0,s125,[Klass index] of static field fname as seen from interpreted class k (its own, its\n  superclasses', its interfaces'), or nil.R2,i176,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp9,params-ofm10,R11,TR6,L1,V1,R28,R2,i188,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp11,find-methodm10,R6,L1,MV3,Myn1,cm2,R9,R29,R30,R28,m2,R9,R31,R0,s113,The java.lang.reflect.Method named mname with descriptor desc of class c or its supertypes,\n  accessible, or nil.R2,i190,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp11,real-methodm10,R6,L1,MV3,R32,R30,R28,m2,R9,R31,R0,s176,The reflective method for a call of owner's method mname desc: owner's own, or for an\n  interpreted owner the one its nearest non-interpreted supertype has (Object's toString).R2,i203,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp10,find-fieldm8,R6,L1,MV2,Myn1,cm2,R9,R29,R27,m2,R9,R33,R2,i216,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp10,local-nodem10,R6,L1,V2,R20,R21,R0,s143,The node reading binding b in ctx: its slot, the receiver, or a captured value (a field of\n  the receiver: local and anonymous classes' val$x).R2,i226,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp7,convertm10,R6,L1,V3,Myn1,nm2,R9,R34,R35,R36,R0,s165,Node n (of type from) as a value of type `to`, converted as the JVM converts: primitive\n  widening and narrowing, boxing by the value's own type, unboxing a wrapper.R2,i246,R3,i1,R4,s24,arbace/classes/interp.aem10,R6,L1,V3,R20,R37,R36,R0,s63,The node of analyzed node an, converted to type `to` (emit-to).R2,i260,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp13,value-convertm10,R6,L1,V3,Myn1,nm2,R9,R34,R35,R36,R0,s161,Node n of type from as type to, also by checkcast and by unboxing from a non-wrapper\n  (method references, bridges: LambdaMetafactory's and javac's adaptations).R2,i267,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp9,arith-opsm32,R38,l0,R39,l1,R40,l2,R41,l3,R42,l4,R43,l5,R44,l6,R45,l7,R46,l8,R47,l9,R48,l10,R49,l11,R50,l12,R51,l13,R52,l14,R53,l15,m8,R11,TR2,i287,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp7,cmp-opsm12,R54,l0,R55,l1,R56,l2,R57,l3,R58,l4,R59,l5,m8,R11,TR2,i291,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp2,vtm10,R11,TR6,L1,V1,R37,R2,i293,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp8,build-opm6,R2,i295,R3,i1,R4,s24,arbace/classes/interp.aev11,arbace.core5,derefR60,v11,arbace.core16,global-hierarchym6,R2,i295,R3,i1,R4,s24,arbace/classes/interp.aem10,R6,L1,MV2,R20,R37,m2,R9,R34,R0,s43,The interpreter's node of analyzed node an.R2,i297,R3,i1,R4,s24,arbace/classes/interp.aeR61,R62,R63,R64,v21,arbace.classes.interp11,this0-indexm12,R11,TR6,L1,V1,R65,R0,s53,The index of the this$0 field of interpreted class c.R2,i318,R3,i1,R4,s24,arbace/classes/interp.aeR66,R67,R68,R69,R70,R71,R72,R73,R74,R52,R75,R76,R77,v21,arbace.classes.interp6,and-orm10,R11,TR6,L1,V3,R20,R37,R78,R2,i382,R3,i1,R4,s24,arbace/classes/interp.aeR46,R47,R79,R80,v21,arbace.classes.interp8,let-nodem10,R11,TR6,L1,V3,R20,R37,R81,R2,i398,R3,i1,R4,s24,arbace/classes/interp.aeR82,R83,R84,R85,R86,R87,R88,R89,R90,R91,v21,arbace.classes.interp9,arg-nodesm10,R11,TR6,L1,V3,R20,R92,R28,R2,i487,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp6,ptypesm10,R11,TR6,L1,V1,R28,R2,i490,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp9,method-ofm10,R6,L1,MV2,Myn1,km2,R9,R10,R93,m2,R9,R94,R0,s166,The Meth of interpreted class k declaring or inheriting method key (non-virtual lookup:\n  its own, then its superclasses', then its interfaces' defaults and statics).R2,i492,R3,i1,R4,s24,arbace/classes/interp.aeR95,v21,arbace.classes.interp9,ctor-methm10,R11,TR6,L1,V2,Myn1,km2,R9,R10,R28,R2,i540,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp15,implicit-fieldsm12,R11,TR6,L1,V3,R20,R96,R97,R0,s178,[[field-index node] ...]: the outer instance and captured values a new object of interpreted\n  class cn gets before its constructor runs (javac's implicit constructor arguments).R2,i543,R3,i1,R4,s24,arbace/classes/interp.aev21,arbace.classes.interp18,super-outer-fieldsm12,R11,TR6,L1,V3,R20,R96,R37,R0,s85,The outer instance of an anonymous class's interpreted superclass, as [[index node]].R2,i556,R3,i1,R4,s24,arbace/classes/interp.aeR98,v21,arbace.classes.interp15,clj-const-valuem12,R11,TR6,L1,V2,R32,R27,R0,s75,The value of a Clojure constant field (const__N) of class owner, or ::none.R2,i602,R3,i1,R4,s24,arbace/classes/interp.aeR99,R100,R101,R102,R103,R104,R105,R106,R107,R108,R109,R110,R111,R112,")

var Lit_260 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000004$loading__1927001464__auto____393000005")

var Lit_261 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000008$fn__393000009")

var Lit_262 *jrt.String = jrt.Intern("arbace.classes.interp$sibling_QMARK_")

var Lit_263 *jrt.String = jrt.Intern("arbace.classes.interp$pending_BANG_")

var Lit_264 *jrt.String = jrt.Intern("arbace.classes.interp$pending_QMARK_")

var Lit_265 *jrt.String = jrt.Intern("arbace.classes.interp$klass")

var Lit_266 *jrt.String = jrt.Intern("arbace.classes.interp$fail")

var Lit_267 *jrt.String = jrt.Intern("arbace.classes.interp$tc")

var Lit_268 *jrt.String = jrt.Intern("arbace.classes.interp$kind")

var Lit_269 *jrt.String = jrt.Intern("J")

var Lit_270 *jrt.String = jrt.Intern("S")

var Lit_271 *jrt.String = jrt.Intern("C")

var Lit_272 *jrt.String = jrt.Intern("F")

var Lit_273 *jrt.String = jrt.Intern("B")

var Lit_274 *jrt.String = jrt.Intern("D")

var Lit_275 *jrt.String = jrt.Intern("arbace.classes.interp$desc__GT_class")

var Lit_276 *jrt.String = jrt.Intern("arbace.classes.interp$internal__GT_class")

var Lit_277 *jrt.String = jrt.Intern("arbace.classes.interp$new_ctx")

var Lit_278 *jrt.String = jrt.Intern("arbace.classes.interp$slot_BANG_")

var Lit_279 *jrt.String = jrt.Intern("arbace.classes.interp$bind_BANG_")

var Lit_280 *jrt.String = jrt.Intern("arbace.classes.interp$konst")

var Lit_281 *jrt.String = jrt.Intern("arbace.classes.interp$nodes")

var Lit_282 *jrt.String = jrt.Intern("arbace.classes.interp$target_code")

var Lit_283 *jrt.String = jrt.Intern("arbace.classes.interp$instance_fields")

var Lit_284 *jrt.String = jrt.Intern("arbace.classes.interp$field_index")

var Lit_285 *jrt.String = jrt.Intern("arbace.classes.interp$static_index")

var Lit_286 *jrt.String = jrt.Intern("arbace.classes.interp$find_static")

var Lit_287 *jrt.String = jrt.Intern("arbace.classes.interp$params_of")

var Lit_288 *jrt.String = jrt.Intern("arbace.classes.interp$find_method")

var Lit_289 *jrt.String = jrt.Intern("arbace.classes.interp$real_method")

var Lit_290 *jrt.String = jrt.Intern("arbace.classes.interp$find_field")

var Lit_291 *jrt.String = jrt.Intern("arbace.classes.interp$local_node")

var Lit_292 *jrt.String = jrt.Intern("arbace.classes.interp$convert")

var Lit_293 *jrt.String = jrt.Intern("arbace.classes.interp$coerce")

var Lit_294 *jrt.String = jrt.Intern("arbace.classes.interp$value_convert")

var Lit_295 *jrt.String = jrt.Intern("arbace.classes.interp$vt")

var Lit_296 *jrt.String = jrt.Intern("build-op")

var Lit_297 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000075$fn__393000076")

var Lit_298 *jrt.String = jrt.Intern("arbace.classes.interp$node")

var Lit_299 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000080$fn__393000081")

var Lit_300 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000084$fn__393000085")

var Lit_301 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000088$fn__393000089")

var Lit_302 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000092$fn__393000093")

var Lit_303 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000096$fn__393000097")

var Lit_304 *jrt.String = jrt.Intern("arbace.classes.interp$this0_index")

var Lit_305 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000104$fn__393000105")

var Lit_306 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000108$fn__393000109")

var Lit_307 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000112$fn__393000113")

var Lit_308 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000116$fn__393000117")

var Lit_309 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000120$fn__393000121")

var Lit_310 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000124$fn__393000125")

var Lit_311 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000128$fn__393000129")

var Lit_312 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000132$fn__393000133")

var Lit_313 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000142$fn__393000143")

var Lit_314 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000148$fn__393000149")

var Lit_315 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000152$fn__393000153")

var Lit_316 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000156$fn__393000157")

var Lit_317 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000160$fn__393000161")

var Lit_318 *jrt.String = jrt.Intern("arbace.classes.interp$and_or")

var Lit_319 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000168$fn__393000169")

var Lit_320 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000172$fn__393000173")

var Lit_321 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000176$fn__393000177")

var Lit_322 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000183$fn__393000184")

var Lit_323 *jrt.String = jrt.Intern("arbace.classes.interp$let_node")

var Lit_324 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000211$fn__393000212")

var Lit_325 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000215$fn__393000216")

var Lit_326 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000219$fn__393000220")

var Lit_327 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000223$fn__393000224")

var Lit_328 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000227$fn__393000228")

var Lit_329 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000233$fn__393000234")

var Lit_330 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000237$fn__393000238")

var Lit_331 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000241$fn__393000242")

var Lit_332 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000282$fn__393000283")

var Lit_333 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000286$fn__393000287")

var Lit_334 *jrt.String = jrt.Intern("arbace.classes.interp$arg_nodes")

var Lit_335 *jrt.String = jrt.Intern("arbace.classes.interp$ptypes")

var Lit_336 *jrt.String = jrt.Intern("arbace.classes.interp$method_of")

var Lit_337 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000298$fn__393000299")

var Lit_338 *jrt.String = jrt.Intern("arbace.classes.interp$ctor_meth")

var Lit_339 *jrt.String = jrt.Intern("arbace.classes.interp$implicit_fields")

var Lit_340 *jrt.String = jrt.Intern("arbace.classes.interp$super_outer_fields")

var Lit_341 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000319$fn__393000320")

var Lit_342 *jrt.String = jrt.Intern("arbace.classes.interp$clj_const_value")

var Lit_343 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000341$fn__393000342")

var Lit_344 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000348$fn__393000349")

var Lit_345 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000355$fn__393000356")

var Lit_346 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000359$fn__393000360")

var Lit_347 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000363$fn__393000364")

var Lit_348 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000368$fn__393000369")

var Lit_349 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000374$fn__393000375")

var Lit_350 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000379$fn__393000380")

var Lit_351 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000386$fn__393000387")

var Lit_352 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000392$fn__393000393")

var Lit_353 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000396$fn__393000397")

var Lit_354 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000400$fn__393000401")

var Lit_355 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000404$fn__393000405")

var Lit_356 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000416$fn__393000417")

var Lit_357 *jrt.String = jrt.Intern("kn7,privatekn8,arglistsyn3,ctxyn3,accyn4,slotkn3,dockn4,linekn6,columnkn4,fileyn1,pkn3,tagyn27,arbace.lang.Compiler$CF$Patkn11,if-instancekn6,switchyn5,flagsyn1,fyn28,arbace.lang.Compiler$CF$Hostkn8,declaredyn29,arbace.lang.Compiler$CF$Klassyn1,dyn1,myn4,descyn1,nyn3,retyn4,recvyn28,arbace.lang.Compiler$CF$Methyn2,bsyn4,bodyyn4,selfyn2,cnyn2,abyn4,callkn9,ctor-callyn2,nsyn8,siblingsyn5,formsyn3,clsyn2,fiyn7,markersyn2,nfkn6,lambdakn10,method-refkn7,dynamicyn15,java.lang.Classyn2,ksyn1,&kn4,keysv21,arbace.classes.interp13,accessor-nodem12,R0,TR1,L1,V3,R2,R3,R4,R5,s62,A call of record accessor acc on the value in ref slot `slot`.R6,i734,R7,i1,R8,s24,arbace/classes/interp.aev21,arbace.classes.interp7,patternm10,R1,L1,MV2,R2,R9,m2,R10,R11,R5,s21,The Pat of pattern p.R6,i745,R7,i1,R8,s24,arbace/classes/interp.aeR12,R13,v21,arbace.classes.interp4,has?m10,R0,TR1,L1,V2,R14,R15,R6,i809,R7,i1,R8,s24,arbace/classes/interp.aev21,arbace.classes.interp10,ACC_STATICl8,m8,R0,TR6,i810,R7,i1,R8,s24,arbace/classes/interp.aev21,arbace.classes.interp11,ACC_PRIVATEl2,m8,R0,TR6,i811,R7,i1,R8,s24,arbace/classes/interp.aev21,arbace.classes.interp12,ACC_ABSTRACTl1024,m8,R0,TR6,i812,R7,i1,R8,s24,arbace/classes/interp.aev21,arbace.classes.interp13,ACC_INTERFACEl512,m8,R0,TR6,i813,R7,i1,R8,s24,arbace/classes/interp.aev21,arbace.classes.interp4,hostm8,R1,L1,MV0,m2,R10,R16,R6,i815,R7,i1,R8,s24,arbace/classes/interp.aev21,arbace.classes.interp13,build-method!m8,R17,TR6,i817,R7,i1,R8,s24,arbace/classes/interp.aev21,arbace.classes.interp12,lambda-klassm8,R17,TR6,i817,R7,i1,R8,s24,arbace/classes/interp.aev21,arbace.classes.interp7,meth-ofm12,R0,TR1,L1,V3,Myn1,km2,R10,R18,R19,R20,R5,s54,A Meth of klass k for method entry m of declaration d.R6,i819,R7,i1,R8,s24,arbace/classes/interp.aev21,arbace.classes.interp7,zero-ofm10,R0,TR1,L1,V1,R21,R6,i829,R7,i1,R8,s24,arbace/classes/interp.aev21,arbace.classes.interp10,make-klassm12,R0,TR1,L1,V1,R22,R5,s64,The Klass of class n of the compilation (members still to come).R6,i831,R7,i1,R8,s24,arbace/classes/interp.aev21,arbace.classes.interp7,layout!m12,R0,TR1,L1,V2,Myn1,km2,R10,R18,R22,R5,s80,Superclass and interfaces, the field layout, statics and methods of k (class n).R6,i843,R7,i1,R8,s24,arbace/classes/interp.aev21,arbace.classes.interp7,vtable!m12,R0,TR1,L1,V1,Myn1,km2,R10,R18,R5,s148,The virtual methods of k: its superclass's, its interfaces' defaults (when nothing else\n  gives them), then its own non-static, non-private methods.R6,i900,R7,i1,R8,s24,arbace/classes/interp.aev21,arbace.classes.interp7,ctx-form12,R0,TR1,L1,V3,R22,R23,R24,R5,s85,The building context of a method of class n with receiver binding recv (nil: static).R6,i918,R7,i1,R8,s24,arbace/classes/interp.aev21,arbace.classes.interp12,receiver-ctxm10,R0,TR1,L1,V2,R22,R23,R6,i926,R7,i1,R8,s24,arbace/classes/interp.aev21,arbace.classes.interp7,params!m10,R0,TR1,L1,V3,R2,Myn2,mtm2,R10,R25,R26,R6,i931,R7,i1,R8,s24,arbace/classes/interp.aev21,arbace.classes.interp7,finish!m10,R0,TR1,L1,V3,R2,Myn2,mtm2,R10,R25,R27,R6,i936,R7,i1,R8,s24,arbace/classes/interp.aev21,arbace.classes.interp14,record-op-nodem10,R0,TR1,L1,V4,Myn1,km2,R10,R18,R19,R20,R28,R6,i942,R7,i1,R8,s24,arbace/classes/interp.aev21,arbace.classes.interp12,derived-bodym12,R0,TR1,L1,V4,R2,Myn1,km2,R10,R18,R19,R20,R5,s55,The body of derived method m (bridges, record members).R6,i951,R7,i1,R8,s24,arbace/classes/interp.aev21,arbace.classes.interp10,init-nodesm12,R0,TR1,L1,V2,R2,R22,R5,s89,The instance initializers of class n (field initializers and initializer blocks), in ctx.R6,i998,R7,i1,R8,s24,arbace/classes/interp.aev21,arbace.classes.interp14,enum-arg-nodesm8,R17,TR6,i1003,R7,i1,R8,s24,arbace/classes/interp.aev21,arbace.classes.interp14,trivial-super?m12,R0,TR1,L1,V2,Myn1,km2,R10,R18,R29,R5,s150,Is cn a superclass whose constructor the interpreter does not run: Object, Record, and the\n  AFunction or RestFn of a Clojure fn's class (CF$FnObj's).R6,i1005,R7,i1,R8,s24,arbace/classes/interp.aev21,arbace.classes.interp14,ctor-call-nodem12,R0,TR1,L1,V5,R2,Myn1,km2,R10,R18,R19,R30,R31,R5,s110,The node of a constructor's call (its super or this call), and after a super call the\n  instance initializers.R6,i1012,R7,i1,R8,s24,arbace/classes/interp.aem12,R0,TR1,L1,V1,R2,R5,s124,An enum constructor's implicit name and ordinal (its first two slots), for its super or this\n  call; none for other classes.R6,i1057,R7,i1,R8,s24,arbace/classes/interp.aeR32,m10,R1,L1,V4,Myn1,km2,R10,R18,R19,R20,Myn2,mtm2,R10,R25,R5,s85,Builds Meth mt (method entry m of class n, declaration d): its frame layout and body.R6,i1069,R7,i1,R8,s24,arbace/classes/interp.aev21,arbace.classes.interp17,declare-siblings!m12,R0,TR1,L1,V2,R33,R34,R5,s145,Enters sibling Java forms (the other Java forms of a top-level do, SPEC §9.2) as\n  declarations only (arbace.classes.compiler/declare-siblings!).R6,i1138,R7,i1,R8,s24,arbace/classes/interp.aev21,arbace.classes.interp13,analyze-formsm10,R1,L1,V3,R33,R35,R34,R5,s277,Analyzes Java forms (each the rest of a defclass form) in namespace ns as one compilation,\n  with sibling Java forms entered as declarations only (arbace.classes.compiler/compile-forms\n  without emitting). Must run inside the bindings of with-unit. Returns the top-level names.R6,i1150,R7,i1,R8,s24,arbace/classes/interp.aev21,arbace.classes.interp12,lambda-countm8,R0,TR6,i1166,R7,i1,R8,s24,arbace/classes/interp.ael0,m8,R0,TR6,i1166,R7,i1,R8,s24,arbace/classes/interp.aev21,arbace.classes.interp16,new-lambda-klassm12,R0,TR1,L1,V4,R36,R37,R38,R39,R5,s78,A Klass for a lambda of class cls implementing fi and markers, with nf fields.R6,i1168,R7,i1,R8,s24,arbace/classes/interp.aev21,arbace.classes.interp8,publish!m8,R17,TR6,i1184,R7,i1,R8,s24,arbace/classes/interp.aev21,arbace.classes.interp16,publish-members!m8,R17,TR6,i1184,R7,i1,R8,s24,arbace/classes/interp.aev21,arbace.classes.interp12,lambda-done!m12,R0,TR1,L1,V2,Myn1,km2,R10,R18,Myn2,mtm2,R10,R25,R5,s181,k (a lambda's class) with its method mt: defined by the host, the method published. Its\n  interfaces' default methods made at run time are its own too, as a class's (vtable!; F2.5).R6,i1186,R7,i1,R8,s24,arbace/classes/interp.aeR40,R41,v21,arbace.classes.interp15,*pending-types*m10,R42,TR6,i1269,R7,i1,R8,s24,arbace/classes/interp.aeR5,s116,While publish! publishes a class: an atom of the sibling classes its members' types name that\n  are not defined yet.v21,arbace.classes.interp7,waitingm10,R0,TR6,i1274,R7,i1,R8,s24,arbace/classes/interp.aeR5,s173,internal name of a sibling class not defined yet -> the Klasses whose members' types name it,\n  published with Object for it, to publish again when it is defined (SA90 (b)).v21,arbace.classes.interp9,sig-classm12,R0,TR1,L1,MV1,R19,m2,R10,R43,R5,s412,The Class of a member's type for the host: desc->class, Object for a sibling class not\n  defined yet (SPEC §9.2: the classes of a top-level do refer to each other in their types too),\n  which publish! records to publish the member again when the sibling is defined. Pending even\n  when a class of its name exists (*eager*): a do evaluated again names the new class, not the\n  one its previous evaluation defined.R6,i1279,R7,i1,R8,s24,arbace/classes/interp.aev21,arbace.classes.interp12,meth-classesm10,R0,TR1,L1,V1,Myn2,mtm2,R10,R25,R6,i1293,R7,i1,R8,s24,arbace/classes/interp.aem10,R1,L1,V1,Myn1,km2,R10,R18,R5,s278,Hands k's members to the host: its virtual methods (its own and those it inherits from\n  interpreted classes), its static and private methods, constructors, fields. A sibling class not\n  defined yet in their types is Object until it is defined: k then waits for it (republish!).R6,i1298,R7,i1,R8,s24,arbace/classes/interp.aev21,arbace.classes.interp10,republish!m12,R0,TR1,L1,V2,R22,R44,R5,s185,The classes whose members' types name n (internal name), just defined, published again with\n  n's class: their compilation's classes and declarations, with the classes defined now (ks).R6,i1309,R7,i1,R8,s24,arbace/classes/interp.aem10,R0,TR1,L1,V1,Myn1,km2,R10,R18,R6,i1321,R7,i1,R8,s24,arbace/classes/interp.aev21,arbace.classes.interp7,clinit!m12,R0,TR1,L1,V2,Myn1,km2,R10,R18,R22,R5,s38,The static initializer of k (class n).R6,i1342,R7,i1,R8,s24,arbace/classes/interp.aev21,arbace.classes.interp7,define!m10,R1,L1,V3,R33,R35,R34,R5,s267,Compiles Java forms (each the rest of a defclass form) in namespace ns as one compilation,\n  the sibling Java forms entered as declarations, into interpreted classes. Returns [[dotted-name\n  Class] ...] of the top-level classes (the Class nil on the JVM's test host).R6,i1369,R7,i1,R8,s24,arbace/classes/interp.aev21,arbace.classes.interp17,compile-and-load!m10,R1,L1,V4,R33,R35,R45,m2,R46,V1,R34,R5,s120,arbace.classes.compiler/compile-and-load! of the Go build (arbace.classes.native's\n  compiler): the classes interpreted.R6,i1428,R7,i1,R8,s24,arbace/classes/interp.ae")

var Lit_358 *jrt.String = jrt.Intern("arbace.classes.interp$accessor_node")

var Lit_359 *jrt.String = jrt.Intern("arbace.classes.interp$pattern")

var Lit_360 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000429$fn__393000430")

var Lit_361 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000435$fn__393000436")

var Lit_362 *jrt.String = jrt.Intern("arbace.classes.interp$has_QMARK_")

var Lit_363 *jrt.String = jrt.Intern("arbace.classes.interp$host")

var Lit_364 *jrt.String = jrt.Intern("arbace.classes.interp$meth_of")

var Lit_365 *jrt.String = jrt.Intern("arbace.classes.interp$zero_of")

var Lit_366 *jrt.String = jrt.Intern("arbace.classes.interp$make_klass")

var Lit_367 *jrt.String = jrt.Intern("arbace.classes.interp$layout_BANG_")

var Lit_368 *jrt.String = jrt.Intern("arbace.classes.interp$vtable_BANG_")

var Lit_369 *jrt.String = jrt.Intern("arbace.classes.interp$ctx_for")

var Lit_370 *jrt.String = jrt.Intern("arbace.classes.interp$receiver_ctx")

var Lit_371 *jrt.String = jrt.Intern("arbace.classes.interp$params_BANG_")

var Lit_372 *jrt.String = jrt.Intern("arbace.classes.interp$finish_BANG_")

var Lit_373 *jrt.String = jrt.Intern("arbace.classes.interp$record_op_node")

var Lit_374 *jrt.String = jrt.Intern("arbace.classes.interp$derived_body")

var Lit_375 *jrt.String = jrt.Intern("arbace.classes.interp$init_nodes")

var Lit_376 *jrt.String = jrt.Intern("arbace.classes.interp$trivial_super_QMARK_")

var Lit_377 *jrt.String = jrt.Intern("arbace.classes.interp$ctor_call_node")

var Lit_378 *jrt.String = jrt.Intern("arbace.classes.interp$enum_arg_nodes")

var Lit_379 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000702$fn__393000703")

var Lit_380 *jrt.String = jrt.Intern("arbace.classes.interp$build_method_BANG_")

var Lit_381 *jrt.String = jrt.Intern("arbace.classes.interp$declare_siblings_BANG_")

var Lit_382 *jrt.String = jrt.Intern("arbace.classes.interp$analyze_forms")

var Lit_383 *jrt.String = jrt.Intern("arbace.classes.interp$new_lambda_klass")

var Lit_384 *jrt.String = jrt.Intern("arbace.classes.interp$lambda_done_BANG_")

var Lit_385 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000781$fn__393000782")

var Lit_386 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000792$fn__393000793")

var Lit_387 *jrt.String = jrt.Intern("arbace.classes.interp$sig_class")

var Lit_388 *jrt.String = jrt.Intern("arbace.classes.interp$meth_classes")

var Lit_389 *jrt.String = jrt.Intern("arbace.classes.interp$publish_BANG_")

var Lit_390 *jrt.String = jrt.Intern("arbace.classes.interp$republish_BANG_")

var Lit_391 *jrt.String = jrt.Intern("arbace.classes.interp$publish_members_BANG_")

var Lit_392 *jrt.String = jrt.Intern("arbace.classes.interp$clinit_BANG_")

var Lit_393 *jrt.String = jrt.Intern("arbace.classes.interp$define_BANG_")

var Lit_394 *jrt.String = jrt.Intern("arbace.classes.interp$compile_and_load_BANG_")

var Lit_395 *jrt.String = jrt.Intern("arbace.classes.interp$eval393001002$fn__393001003")
