//line a2g_strings.ae:1
package aot_arbace_classes_interp

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("require")

var Lit_3 *jrt.String = jrt.Intern("arbace.string")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("str")

var Lit_6 *jrt.String = jrt.Intern("arbace.classes.types")

var Lit_7 *jrt.String = jrt.Intern("t")

var Lit_8 *jrt.String = jrt.Intern("arbace.classes.env")

var Lit_9 *jrt.String = jrt.Intern("env")

var Lit_10 *jrt.String = jrt.Intern("arbace.classes.parse")

var Lit_11 *jrt.String = jrt.Intern("p")

var Lit_12 *jrt.String = jrt.Intern("arbace.classes.analyze")

var Lit_13 *jrt.String = jrt.Intern("a")

var Lit_14 *jrt.String = jrt.Intern("commute")

var Lit_15 *jrt.String = jrt.Intern("deref")

var Lit_16 *jrt.String = jrt.Intern("conj")

var Lit_17 *jrt.String = jrt.Intern("arbace.classes.interp")

var Lit_18 *jrt.String = jrt.Intern("doc")

var Lit_19 *jrt.String = jrt.Intern("The Go build's class forms (doc/go/CLASSFORMS-REPL.md): the classes of class forms made at run\n  time, their code interpreted. arbace.classes.analyze analyzes the class forms as for the JVM\n  (declarations, members, what javac derives, code into typed nodes); in place of\n  arbace.classes.emit, this namespace builds, from the analyzed nodes, the nodes of the\n  interpreter (arbace.lang.Compiler$CF, class forms translated into the program), one tree per\n  method on its first call, and makes the classes through the host (Compiler$CF$Rt/HOST: on Go\n  classes made at run time, Dyn, A2G-SPEC §5.12).\n\n  It is a namespace of the Go build (arbace/lang/go/ns/), and loads on the JVM too, where the\n  interpreter is tested against the compiled classes (test/classforms/).")

var Lit_20 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_21 *jrt.String = jrt.Intern("string?")

var Lit_22 *jrt.String = jrt.Intern("not")

var Lit_23 *jrt.String = jrt.Intern("declared-only")

var Lit_24 *jrt.String = jrt.Intern("decl")

var Lit_25 *jrt.String = jrt.Intern("contains?")

var Lit_26 *jrt.String = jrt.Intern("*klasses*")

var Lit_27 *jrt.String = jrt.Intern("ex-info")

var Lit_28 *jrt.String = jrt.Intern("replace")

var Lit_29 *jrt.String = jrt.Intern("arbace")

var Lit_30 *jrt.String = jrt.Intern("compile-error")

var Lit_31 *jrt.String = jrt.Intern("pending")

var Lit_32 *jrt.String = jrt.Intern("ex-data")

var Lit_33 *jrt.String = jrt.Intern("*eager*")

var Lit_34 *jrt.String = jrt.Intern("sibling?")

var Lit_35 *jrt.String = jrt.Intern("pending!")

var Lit_36 *jrt.String = jrt.Intern("load-class")

var Lit_37 *jrt.String = jrt.Intern("registry")

var Lit_38 *jrt.String = jrt.Intern("merge")

var Lit_39 *jrt.String = jrt.Intern("null")

var Lit_40 *jrt.String = jrt.Intern("none")

var Lit_41 *jrt.String = jrt.Intern("keyword?")

var Lit_42 *jrt.String = jrt.Intern("else")

var Lit_43 *jrt.String = jrt.Intern("tc")

var Lit_44 *jrt.String = jrt.Intern("prim-classes")

var Lit_45 *jrt.String = jrt.Intern("java.lang.Object")

var Lit_46 *jrt.String = jrt.Intern("array?")

var Lit_47 *jrt.String = jrt.Intern("elem-type")

var Lit_48 *jrt.String = jrt.Intern("class-desc?")

var Lit_49 *jrt.String = jrt.Intern("klass")

var Lit_50 *jrt.String = jrt.Intern("apply")

var Lit_51 *jrt.String = jrt.Intern("desc->class-name")

var Lit_52 *jrt.String = jrt.Intern("desc->internal")

var Lit_53 *jrt.String = jrt.Intern("fail")

var Lit_54 *jrt.String = jrt.Intern("repeat")

var Lit_55 *jrt.String = jrt.Intern("array-dims")

var Lit_56 *jrt.String = jrt.Intern("desc->class")

var Lit_57 *jrt.String = jrt.Intern("internal->desc")

var Lit_58 *jrt.String = jrt.Intern("class")

var Lit_59 *jrt.String = jrt.Intern("slots")

var Lit_60 *jrt.String = jrt.Intern("atom")

var Lit_61 *jrt.String = jrt.Intern("nr")

var Lit_62 *jrt.String = jrt.Intern("np")

var Lit_63 *jrt.String = jrt.Intern("targets")

var Lit_64 *jrt.String = jrt.Intern("ret")

var Lit_65 *jrt.String = jrt.Intern("self")

var Lit_66 *jrt.String = jrt.Intern("kind")

var Lit_67 *jrt.String = jrt.Intern("swap!")

var Lit_68 *jrt.String = jrt.Intern("inc")

var Lit_69 *jrt.String = jrt.Intern("type")

var Lit_70 *jrt.String = jrt.Intern("slot!")

var Lit_71 *jrt.String = jrt.Intern("assoc")

var Lit_72 *jrt.String = jrt.Intern("id")

var Lit_73 *jrt.String = jrt.Intern("into-array")

var Lit_74 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Node")

var Lit_75 *jrt.String = jrt.Intern("fields")

var Lit_76 *jrt.String = jrt.Intern("field-index")

var Lit_77 *jrt.String = jrt.Intern("static-index")

var Lit_78 *jrt.String = jrt.Intern("some")

var Lit_79 *jrt.String = jrt.Intern("find-static")

var Lit_80 *jrt.String = jrt.Intern("seq")

var Lit_81 *jrt.String = jrt.Intern("java.lang.Class")

var Lit_82 *jrt.String = jrt.Intern("map")

var Lit_83 *jrt.String = jrt.Intern("first")

var Lit_84 *jrt.String = jrt.Intern("parse-method-desc")

var Lit_85 *jrt.String = jrt.Intern("params-of")

var Lit_86 *jrt.String = jrt.Intern("find-method")

var Lit_87 *jrt.String = jrt.Intern("real-method")

var Lit_88 *jrt.String = jrt.Intern("find-field")

var Lit_89 *jrt.String = jrt.Intern("receiver")

var Lit_90 *jrt.String = jrt.Intern("slot0")

var Lit_91 *jrt.String = jrt.Intern("capture-index")

var Lit_92 *jrt.String = jrt.Intern("sym")

var Lit_93 *jrt.String = jrt.Intern("value-type")

var Lit_94 *jrt.String = jrt.Intern("prim?")

var Lit_95 *jrt.String = jrt.Intern("unbox-of")

var Lit_96 *jrt.String = jrt.Intern("const")

var Lit_97 *jrt.String = jrt.Intern("op")

var Lit_98 *jrt.String = jrt.Intern("not=")

var Lit_99 *jrt.String = jrt.Intern("konst")

var Lit_100 *jrt.String = jrt.Intern("convert")

var Lit_101 *jrt.String = jrt.Intern("const-of-type")

var Lit_102 *jrt.String = jrt.Intern("val")

var Lit_103 *jrt.String = jrt.Intern("node")

var Lit_104 *jrt.String = jrt.Intern("assignable?")

var Lit_105 *jrt.String = jrt.Intern("box-of")

var Lit_106 *jrt.String = jrt.Intern("build-op")

var Lit_107 *jrt.String = jrt.Intern("local-node")

var Lit_108 *jrt.String = jrt.Intern("b")

var Lit_109 *jrt.String = jrt.Intern("coerce")

var Lit_110 *jrt.String = jrt.Intern("this0-index")

var Lit_111 *jrt.String = jrt.Intern("path")

var Lit_112 *jrt.String = jrt.Intern("base")

var Lit_113 *jrt.String = jrt.Intern("from")

var Lit_114 *jrt.String = jrt.Intern("to")

var Lit_115 *jrt.String = jrt.Intern("expr")

var Lit_116 *jrt.String = jrt.Intern("next")

var Lit_117 *jrt.String = jrt.Intern("to-array")

var Lit_118 *jrt.String = jrt.Intern("family")

var Lit_119 *jrt.String = jrt.Intern("o")

var Lit_120 *jrt.String = jrt.Intern("args")

var Lit_121 *jrt.String = jrt.Intern("arith-ops")

var Lit_122 *jrt.String = jrt.Intern("exact")

var Lit_123 *jrt.String = jrt.Intern("ushr")

var Lit_124 *jrt.String = jrt.Intern("shr")

var Lit_125 *jrt.String = jrt.Intern("shl")

var Lit_126 *jrt.String = jrt.Intern("cmp")

var Lit_127 *jrt.String = jrt.Intern("cmp-ops")

var Lit_128 *jrt.String = jrt.Intern("F")

var Lit_129 *jrt.String = jrt.Intern("D")

var Lit_130 *jrt.String = jrt.Intern("second")

var Lit_131 *jrt.String = jrt.Intern("vt")

var Lit_132 *jrt.String = jrt.Intern("nodes")

var Lit_133 *jrt.String = jrt.Intern("and-or")

var Lit_134 *jrt.String = jrt.Intern("test")

var Lit_135 *jrt.String = jrt.Intern("then")

var Lit_136 *jrt.String = jrt.Intern("statements")

var Lit_137 *jrt.String = jrt.Intern("bindings")

var Lit_138 *jrt.String = jrt.Intern("reduce")

var Lit_139 *jrt.String = jrt.Intern("target")

var Lit_140 *jrt.String = jrt.Intern("assoc-in")

var Lit_141 *jrt.String = jrt.Intern("target-code")

var Lit_142 *jrt.String = jrt.Intern("bind!")

var Lit_143 *jrt.String = jrt.Intern("brk")

var Lit_144 *jrt.String = jrt.Intern("rec")

var Lit_145 *jrt.String = jrt.Intern("mapv")

var Lit_146 *jrt.String = jrt.Intern("kinds")

var Lit_147 *jrt.String = jrt.Intern("types")

var Lit_148 *jrt.String = jrt.Intern("body")

var Lit_149 *jrt.String = jrt.Intern("let-node")

var Lit_150 *jrt.String = jrt.Intern("V")

var Lit_151 *jrt.String = jrt.Intern("catches")

var Lit_152 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_153 *jrt.String = jrt.Intern("chunk-first")

var Lit_154 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_155 *jrt.String = jrt.Intern("chunk-append")

var Lit_156 *jrt.String = jrt.Intern("chunk-cons")

var Lit_157 *jrt.String = jrt.Intern("cons")

var Lit_158 *jrt.String = jrt.Intern("chunk")

var Lit_159 *jrt.String = jrt.Intern("chunk-rest")

var Lit_160 *jrt.String = jrt.Intern("rest")

var Lit_161 *jrt.String = jrt.Intern("concat")

var Lit_162 *jrt.String = jrt.Intern("classes")

var Lit_163 *jrt.String = jrt.Intern("finally")

var Lit_164 *jrt.String = jrt.Intern("normal-finally")

var Lit_165 *jrt.String = jrt.Intern("map-indexed")

var Lit_166 *jrt.String = jrt.Intern("vector")

var Lit_167 *jrt.String = jrt.Intern("internal->class")

var Lit_168 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Klass")

var Lit_169 *jrt.String = jrt.Intern("lock")

var Lit_170 *jrt.String = jrt.Intern("method-of")

var Lit_171 *jrt.String = jrt.Intern("owner")

var Lit_172 *jrt.String = jrt.Intern("name")

var Lit_173 *jrt.String = jrt.Intern("desc")

var Lit_174 *jrt.String = jrt.Intern("array-clone")

var Lit_175 *jrt.String = jrt.Intern("no-cast")

var Lit_176 *jrt.String = jrt.Intern("cast-to")

var Lit_177 *jrt.String = jrt.Intern("static")

var Lit_178 *jrt.String = jrt.Intern("arg-nodes")

var Lit_179 *jrt.String = jrt.Intern("ptypes")

var Lit_180 *jrt.String = jrt.Intern("special")

var Lit_181 *jrt.String = jrt.Intern("toString")

var Lit_182 *jrt.String = jrt.Intern("hashCode")

var Lit_183 *jrt.String = jrt.Intern("equals")

var Lit_184 *jrt.String = jrt.Intern("captures")

var Lit_185 *jrt.String = jrt.Intern("super")

var Lit_186 *jrt.String = jrt.Intern("super-outer")

var Lit_187 *jrt.String = jrt.Intern("super-outer-is-outer")

var Lit_188 *jrt.String = jrt.Intern("outer")

var Lit_189 *jrt.String = jrt.Intern("super-outer-path")

var Lit_190 *jrt.String = jrt.Intern("ctor")

var Lit_191 *jrt.String = jrt.Intern("vec")

var Lit_192 *jrt.String = jrt.Intern("ctor-meth")

var Lit_193 *jrt.String = jrt.Intern("outer-instance?")

var Lit_194 *jrt.String = jrt.Intern("info")

var Lit_195 *jrt.String = jrt.Intern("implicit-fields")

var Lit_196 *jrt.String = jrt.Intern("super-outer-fields")

var Lit_197 *jrt.String = jrt.Intern("enum-const")

var Lit_198 *jrt.String = jrt.Intern("ordinal")

var Lit_199 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Rt")

var Lit_200 *jrt.String = jrt.Intern("init")

var Lit_201 *jrt.String = jrt.Intern("var")

var Lit_202 *jrt.String = jrt.Intern("ns")

var Lit_203 *jrt.String = jrt.Intern("read")

var Lit_204 *jrt.String = jrt.Intern("text")

var Lit_205 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_206 *jrt.String = jrt.Intern("clj-consts")

var Lit_207 *jrt.String = jrt.Intern("state")

var Lit_208 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_209 *jrt.String = jrt.Intern("hash-map")

var Lit_210 *jrt.String = jrt.Intern("*read-eval*")

var Lit_211 *jrt.String = jrt.Intern("field")

var Lit_212 *jrt.String = jrt.Intern("starts-with?")

var Lit_213 *jrt.String = jrt.Intern("clj-const-value")

var Lit_214 *jrt.String = jrt.Intern("dims")

var Lit_215 *jrt.String = jrt.Intern("iterate")

var Lit_216 *jrt.String = jrt.Intern("elems")

var Lit_217 *jrt.String = jrt.Intern("array")

var Lit_218 *jrt.String = jrt.Intern("index")

var Lit_219 *jrt.String = jrt.Intern("parts")

var Lit_220 *jrt.String = jrt.Intern("java.lang.String")

var Lit_221 *jrt.String = jrt.Intern("literal")

var Lit_222 *jrt.String = jrt.Intern("tag-const")

var Lit_223 *jrt.String = jrt.Intern("eager")

var Lit_224 *jrt.String = jrt.Intern("hidden")

var Lit_225 *jrt.String = jrt.Intern("arr")

var Lit_226 *jrt.String = jrt.Intern("it")

var Lit_227 *jrt.String = jrt.Intern("len")

var Lit_228 *jrt.String = jrt.Intern("i")

var Lit_229 *jrt.String = jrt.Intern("coll")

var Lit_230 *jrt.String = jrt.Intern("iterator")

var Lit_231 *jrt.String = jrt.Intern("elem")

var Lit_232 *jrt.String = jrt.Intern("subs")

var Lit_233 *jrt.String = jrt.Intern("record")

var Lit_234 *jrt.String = jrt.Intern("accessor-node")

var Lit_235 *jrt.String = jrt.Intern("accessor")

var Lit_236 *jrt.String = jrt.Intern("comps")

var Lit_237 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Pat")

var Lit_238 *jrt.String = jrt.Intern("pattern")

var Lit_239 *jrt.String = jrt.Intern("cases")

var Lit_240 *jrt.String = jrt.Intern("labels")

var Lit_241 *jrt.String = jrt.Intern("int")

var Lit_242 *jrt.String = jrt.Intern("string")

var Lit_243 *jrt.String = jrt.Intern("enum")

var Lit_244 *jrt.String = jrt.Intern("default")

var Lit_245 *jrt.String = jrt.Intern("sel")

var Lit_246 *jrt.String = jrt.Intern("char?")

var Lit_247 *jrt.String = jrt.Intern("guard")

var Lit_248 *jrt.String = jrt.Intern("flags")

var Lit_249 *jrt.String = jrt.Intern("build-method!")

var Lit_250 *jrt.String = jrt.Intern("has?")

var Lit_251 *jrt.String = jrt.Intern("clojure-fn")

var Lit_252 *jrt.String = jrt.Intern("meta")

var Lit_253 *jrt.String = jrt.Intern("lang-class")

var Lit_254 *jrt.String = jrt.Intern("ACC_INTERFACE")

var Lit_255 *jrt.String = jrt.Intern("anon")

var Lit_256 *jrt.String = jrt.Intern("local")

var Lit_257 *jrt.String = jrt.Intern("host")

var Lit_258 *jrt.String = jrt.Intern("keep")

var Lit_259 *jrt.String = jrt.Intern("interfaces")

var Lit_260 *jrt.String = jrt.Intern("remove")

var Lit_261 *jrt.String = jrt.Intern("ACC_STATIC")

var Lit_262 *jrt.String = jrt.Intern("nesting")

var Lit_263 *jrt.String = jrt.Intern("this$0")

var Lit_264 *jrt.String = jrt.Intern("zero-of")

var Lit_265 *jrt.String = jrt.Intern("filter")

var Lit_266 *jrt.String = jrt.Intern("const-value")

var Lit_267 *jrt.String = jrt.Intern("some?")

var Lit_268 *jrt.String = jrt.Intern("own-fields")

var Lit_269 *jrt.String = jrt.Intern("into")

var Lit_270 *jrt.String = jrt.Intern("statics")

var Lit_271 *jrt.String = jrt.Intern("boolean?")

var Lit_272 *jrt.String = jrt.Intern("methods")

var Lit_273 *jrt.String = jrt.Intern("meth-of")

var Lit_274 *jrt.String = jrt.Intern("ACC_ABSTRACT")

var Lit_275 *jrt.String = jrt.Intern("ACC_PRIVATE")

var Lit_276 *jrt.String = jrt.Intern("new-ctx")

var Lit_277 *jrt.String = jrt.Intern("components")

var Lit_278 *jrt.String = jrt.Intern("derived")

var Lit_279 *jrt.String = jrt.Intern("bridge")

var Lit_280 *jrt.String = jrt.Intern("bridge-of")

var Lit_281 *jrt.String = jrt.Intern("enum-values")

var Lit_282 *jrt.String = jrt.Intern("record-object-method")

var Lit_283 *jrt.String = jrt.Intern("record-accessor")

var Lit_284 *jrt.String = jrt.Intern("component")

var Lit_285 *jrt.String = jrt.Intern("value-convert")

var Lit_286 *jrt.String = jrt.Intern("record-op-node")

var Lit_287 *jrt.String = jrt.Intern("enum-$values")

var Lit_288 *jrt.String = jrt.Intern("enum-valueOf")

var Lit_289 *jrt.String = jrt.Intern("constants")

var Lit_290 *jrt.String = jrt.Intern("java.lang.Enum")

var Lit_291 *jrt.String = jrt.Intern("java/lang/Record")

var Lit_292 *jrt.String = jrt.Intern("java/lang/Object")

var Lit_293 *jrt.String = jrt.Intern("calls-super")

var Lit_294 *jrt.String = jrt.Intern("init-nodes")

var Lit_295 *jrt.String = jrt.Intern("enum-args")

var Lit_296 *jrt.String = jrt.Intern("anon-args")

var Lit_297 *jrt.String = jrt.Intern("this")

var Lit_298 *jrt.String = jrt.Intern("enum-arg-nodes")

var Lit_299 *jrt.String = jrt.Intern("params")

var Lit_300 *jrt.String = jrt.Intern("trivial-super?")

var Lit_301 *jrt.String = jrt.Intern("enum-slots")

var Lit_302 *jrt.String = jrt.Intern("ctor-site")

var Lit_303 *jrt.String = jrt.Intern("bodies")

var Lit_304 *jrt.String = jrt.Intern("recv")

var Lit_305 *jrt.String = jrt.Intern("ctx-for")

var Lit_306 *jrt.String = jrt.Intern("receiver-ctx")

var Lit_307 *jrt.String = jrt.Intern("enum-body")

var Lit_308 *jrt.String = jrt.Intern("params!")

var Lit_309 *jrt.String = jrt.Intern("ctor-call-node")

var Lit_310 *jrt.String = jrt.Intern("nested-call")

var Lit_311 *jrt.String = jrt.Intern("compact")

var Lit_312 *jrt.String = jrt.Intern("record-canonical")

var Lit_313 *jrt.String = jrt.Intern("finish!")

var Lit_314 *jrt.String = jrt.Intern("derived-body")

var Lit_315 *jrt.String = jrt.Intern("*compile-set*")

var Lit_316 *jrt.String = jrt.Intern("klasses")

var Lit_317 *jrt.String = jrt.Intern("compile-set")

var Lit_318 *jrt.String = jrt.Intern("prologue")

var Lit_319 *jrt.String = jrt.Intern("call")

var Lit_320 *jrt.String = jrt.Intern("identity")

var Lit_321 *jrt.String = jrt.Intern("order")

var Lit_322 *jrt.String = jrt.Intern("*unit*")

var Lit_323 *jrt.String = jrt.Intern("parse-class")

var Lit_324 *jrt.String = jrt.Intern("declare-class!")

var Lit_325 *jrt.String = jrt.Intern("top")

var Lit_326 *jrt.String = jrt.Intern("top-name")

var Lit_327 *jrt.String = jrt.Intern("subvec")

var Lit_328 *jrt.String = jrt.Intern("update-decl!")

var Lit_329 *jrt.String = jrt.Intern("declare-siblings!")

var Lit_330 *jrt.String = jrt.Intern("process-classes!")

var Lit_331 *jrt.String = jrt.Intern("lambda-count")

var Lit_332 *jrt.String = jrt.Intern("lambda")

var Lit_333 *jrt.String = jrt.Intern("publish!")

var Lit_334 *jrt.String = jrt.Intern("boundary")

var Lit_335 *jrt.String = jrt.Intern("sam")

var Lit_336 *jrt.String = jrt.Intern("new-lambda-klass")

var Lit_337 *jrt.String = jrt.Intern("uses-this")

var Lit_338 *jrt.String = jrt.Intern("fi")

var Lit_339 *jrt.String = jrt.Intern("markers")

var Lit_340 *jrt.String = jrt.Intern("lambda-done!")

var Lit_341 *jrt.String = jrt.Intern("bound")

var Lit_342 *jrt.String = jrt.Intern("take")

var Lit_343 *jrt.String = jrt.Intern("new")

var Lit_344 *jrt.String = jrt.Intern("unbound")

var Lit_345 *jrt.String = jrt.Intern("inst-desc")

var Lit_346 *jrt.String = jrt.Intern("null-check")

var Lit_347 *jrt.String = jrt.Intern("pending?")

var Lit_348 *jrt.String = jrt.Intern("*pending-types*")

var Lit_349 *jrt.String = jrt.Intern("sig-class")

var Lit_350 *jrt.String = jrt.Intern("publish-members!")

var Lit_351 *jrt.String = jrt.Intern("waiting")

var Lit_352 *jrt.String = jrt.Intern("update")

var Lit_353 *jrt.String = jrt.Intern("fnil")

var Lit_354 *jrt.String = jrt.Intern("dissoc")

var Lit_355 *jrt.String = jrt.Intern("meth-classes")

var Lit_356 *jrt.String = jrt.Intern("clinit")

var Lit_357 *jrt.String = jrt.Intern("with-redefs-fn")

var Lit_358 *jrt.String = jrt.Intern("counters")

var Lit_359 *jrt.String = jrt.Intern("switch-maps")

var Lit_360 *jrt.String = jrt.Intern("switch-holders")

var Lit_361 *jrt.String = jrt.Intern("source-tried")

var Lit_362 *jrt.String = jrt.Intern("assert-holders")

var Lit_363 *jrt.String = jrt.Intern("holder-first")

var Lit_364 *jrt.String = jrt.Intern("accessorize")

var Lit_365 *jrt.String = jrt.Intern("analyze-forms")

var Lit_366 *jrt.String = jrt.Intern("supertypes-first")

var Lit_367 *jrt.String = jrt.Intern("switch-holder")

var Lit_368 *jrt.String = jrt.Intern("make-klass")

var Lit_369 *jrt.String = jrt.Intern("clinit!")

var Lit_370 *jrt.String = jrt.Intern("member")

var Lit_371 *jrt.String = jrt.Intern("layout!")

var Lit_372 *jrt.String = jrt.Intern("vtable!")

var Lit_373 *jrt.String = jrt.Intern("simple")

var Lit_374 *jrt.String = jrt.Intern("defined")

var Lit_375 *jrt.String = jrt.Intern("loader")

var Lit_376 *jrt.String = jrt.Intern("republish!")

var Lit_377 *jrt.String = jrt.Intern("siblings")

var Lit_378 *jrt.String = jrt.Intern("define!")

var Lit_379 *jrt.String = jrt.Intern("arbace.classes.interp$accessor_node")

var Lit_380 *jrt.String = jrt.Intern("No accessor ")

var Lit_381 *jrt.String = jrt.Intern("arbace.classes.interp$analyze_forms")

var Lit_382 *jrt.String = jrt.Intern("arbace.classes.interp$analyze_forms$iter__393000763__393000767")

var Lit_383 *jrt.String = jrt.Intern("arbace.classes.interp$analyze_forms$iter__393000763__393000767$fn__393000768")

var Lit_384 *jrt.String = jrt.Intern("arbace.classes.interp$analyze_forms$iter__393000763__393000767$fn__393000768$fn__393000769")

var Lit_385 *jrt.String = jrt.Intern("arbace.classes.interp$and_or")

var Lit_386 *jrt.String = jrt.Intern("arbace.classes.interp$and_or$fn__393000165")

var Lit_387 *jrt.String = jrt.Intern("Z")

var Lit_388 *jrt.String = jrt.Intern("arbace.classes.interp$arg_nodes")

var Lit_389 *jrt.String = jrt.Intern("arbace.classes.interp$arg_nodes$fn__393000290")

var Lit_390 *jrt.String = jrt.Intern("arbace.classes.interp$bind_BANG_")

var Lit_391 *jrt.String = jrt.Intern("arbace.classes.interp$build_method_BANG_")

var Lit_392 *jrt.String = jrt.Intern("<init>")

var Lit_393 *jrt.String = jrt.Intern("Ljava/lang/String;")

var Lit_394 *jrt.String = jrt.Intern("I")

var Lit_395 *jrt.String = jrt.Intern("java.lang.UnsatisfiedLinkError")

var Lit_396 *jrt.String = jrt.Intern(".")

var Lit_397 *jrt.String = jrt.Intern("/")

var Lit_398 *jrt.String = jrt.Intern("Method ")

var Lit_399 *jrt.String = jrt.Intern(" of ")

var Lit_400 *jrt.String = jrt.Intern(" has no body")

var Lit_401 *jrt.String = jrt.Intern("arbace.classes.interp$build_method_BANG_$call_node__393000710")

var Lit_402 *jrt.String = jrt.Intern("arbace.classes.interp$build_method_BANG_$fn__393000712")

var Lit_403 *jrt.String = jrt.Intern("arbace.classes.interp$build_method_BANG_$iter__393000714__393000718")

var Lit_404 *jrt.String = jrt.Intern("arbace.classes.interp$build_method_BANG_$iter__393000714__393000718$fn__393000719")

var Lit_405 *jrt.String = jrt.Intern("arbace.classes.interp$build_method_BANG_$iter__393000714__393000718$fn__393000719$fn__393000720")

var Lit_406 *jrt.String = jrt.Intern("arbace.classes.interp$build_method_BANG_$iter__393000733__393000737")

var Lit_407 *jrt.String = jrt.Intern("arbace.classes.interp$build_method_BANG_$iter__393000733__393000737$fn__393000738")

var Lit_408 *jrt.String = jrt.Intern("arbace.classes.interp$build_method_BANG_$iter__393000733__393000737$fn__393000738$fn__393000739")

var Lit_409 *jrt.String = jrt.Intern("arbace.classes.interp$build_method_BANG_$iter__393000743__393000747")

var Lit_410 *jrt.String = jrt.Intern("arbace.classes.interp$build_method_BANG_$iter__393000743__393000747$fn__393000748")

var Lit_411 *jrt.String = jrt.Intern("arbace.classes.interp$build_method_BANG_$iter__393000743__393000747$fn__393000748$fn__393000749")

var Lit_412 *jrt.String = jrt.Intern("arbace.classes.interp$clinit_BANG_")

var Lit_413 *jrt.String = jrt.Intern("<clinit>")

var Lit_414 *jrt.String = jrt.Intern("()V")

var Lit_415 *jrt.String = jrt.Intern("arbace.classes.interp$clinit_BANG_$build__393000876")

var Lit_416 *jrt.String = jrt.Intern("arbace.classes.interp$clinit_BANG_$build__393000876$fn__393000877")

var Lit_417 *jrt.String = jrt.Intern("arbace.classes.interp$clinit_BANG_$fn__393000880")

var Lit_418 *jrt.String = jrt.Intern("arbace.classes.interp$clinit_BANG_$fn__393000882")

var Lit_419 *jrt.String = jrt.Intern("arbace.classes.interp$clj_const_value")

var Lit_420 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_421 *jrt.String = jrt.Intern("arbace.classes.interp$clj_const_value$fn__393000334")

var Lit_422 *jrt.String = jrt.Intern("arbace.classes.interp$coerce")

var Lit_423 *jrt.String = jrt.Intern("arbace.classes.interp$compile_and_load_BANG_")

var Lit_424 *jrt.String = jrt.Intern("arbace.classes.interp$convert")

var Lit_425 *jrt.String = jrt.Intern("arbace.classes.interp$ctor_call_node")

var Lit_426 *jrt.String = jrt.Intern("(Ljava/lang/String;I)V")

var Lit_427 *jrt.String = jrt.Intern("arbace.classes.interp$ctor_call_node$fn__393000695")

var Lit_428 *jrt.String = jrt.Intern("arbace.classes.interp$ctor_call_node$inits__393000693")

var Lit_429 *jrt.String = jrt.Intern("arbace.classes.interp$ctor_meth")

var Lit_430 *jrt.String = jrt.Intern("No constructor ")

var Lit_431 *jrt.String = jrt.Intern(" in ")

var Lit_432 *jrt.String = jrt.Intern("arbace.classes.interp$ctx_for")

var Lit_433 *jrt.String = jrt.Intern("arbace.classes.interp$declare_siblings_BANG_")

var Lit_434 *jrt.String = jrt.Intern("arbace.classes.interp$define_BANG_")

var Lit_435 *jrt.String = jrt.Intern("arbace.classes.interp$define_BANG_$fn__393000889")

var Lit_436 *jrt.String = jrt.Intern("arbace.classes.interp$define_BANG_$fn__393000891")

var Lit_437 *jrt.String = jrt.Intern("doInvoke(")

var Lit_438 *jrt.String = jrt.Intern("doInvoke")

var Lit_439 *jrt.String = jrt.Intern("values()[")

var Lit_440 *jrt.String = jrt.Intern("arbace.classes.interp$define_BANG_$fn__393000891$fn__393000892")

var Lit_441 *jrt.String = jrt.Intern("arbace.classes.interp$define_BANG_$fn__393000891$fn__393000940")

var Lit_442 *jrt.String = jrt.Intern("arbace.classes.interp$define_BANG_$fn__393000891$fn__393000940$fn__393000952")

var Lit_443 *jrt.String = jrt.Intern("arbace.classes.interp$define_BANG_$fn__393000891$fn__393000940$fn__393000957")

var Lit_444 *jrt.String = jrt.Intern("arbace.classes.interp$define_BANG_$fn__393000891$fn__393000940$fn__393000966")

var Lit_445 *jrt.String = jrt.Intern("arbace.classes.interp$define_BANG_$fn__393000891$fn__393000940$fn__393000971")

var Lit_446 *jrt.String = jrt.Intern("arbace.classes.interp$define_BANG_$fn__393000891$fn__393000994")

var Lit_447 *jrt.String = jrt.Intern("arbace.classes.interp$define_BANG_$fn__393000891$iter__393000894__393000898")

var Lit_448 *jrt.String = jrt.Intern("arbace.classes.interp$define_BANG_$fn__393000891$iter__393000894__393000898$fn__393000899")

var Lit_449 *jrt.String = jrt.Intern("arbace.classes.interp$define_BANG_$fn__393000891$iter__393000894__393000898$fn__393000899$fn__393000900")

var Lit_450 *jrt.String = jrt.Intern("arbace.classes.interp$derived_body")

var Lit_451 *jrt.String = jrt.Intern("No bridge target ")

var Lit_452 *jrt.String = jrt.Intern("$VALUES")

var Lit_453 *jrt.String = jrt.Intern("[")

var Lit_454 *jrt.String = jrt.Intern("valueOf")

var Lit_455 *jrt.String = jrt.Intern("(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;")

var Lit_456 *jrt.String = jrt.Intern("Ljava/lang/Class;")

var Lit_457 *jrt.String = jrt.Intern("The Go build's class forms do not support ")

var Lit_458 *jrt.String = jrt.Intern(" yet")

var Lit_459 *jrt.String = jrt.Intern("arbace.classes.interp$derived_body$fn__393000655")

var Lit_460 *jrt.String = jrt.Intern("arbace.classes.interp$derived_body$iter__393000645__393000649")

var Lit_461 *jrt.String = jrt.Intern("arbace.classes.interp$derived_body$iter__393000645__393000649$fn__393000650")

var Lit_462 *jrt.String = jrt.Intern("arbace.classes.interp$derived_body$iter__393000645__393000649$fn__393000650$fn__393000651")

var Lit_463 *jrt.String = jrt.Intern("arbace.classes.interp$derived_body$iter__393000660__393000664")

var Lit_464 *jrt.String = jrt.Intern("arbace.classes.interp$derived_body$iter__393000660__393000664$fn__393000665")

var Lit_465 *jrt.String = jrt.Intern("arbace.classes.interp$derived_body$iter__393000660__393000664$fn__393000665$fn__393000666")

var Lit_466 *jrt.String = jrt.Intern("arbace.classes.interp$derived_body$iter__393000670__393000674")

var Lit_467 *jrt.String = jrt.Intern("arbace.classes.interp$derived_body$iter__393000670__393000674$fn__393000675")

var Lit_468 *jrt.String = jrt.Intern("arbace.classes.interp$derived_body$iter__393000670__393000674$fn__393000675$fn__393000676")

var Lit_469 *jrt.String = jrt.Intern("arbace.classes.interp$desc__GT_class")

var Lit_470 *jrt.String = jrt.Intern("Ljava.lang.Object;")

var Lit_471 *jrt.String = jrt.Intern("Class not found: ")

var Lit_472 *jrt.String = jrt.Intern("arbace.classes.interp$desc__GT_class$fn__393000025")

var Lit_473 *jrt.String = jrt.Intern("arbace.classes.interp$enum_arg_nodes")

var Lit_474 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000004$loading__1927001464__auto____393000005")

var Lit_475 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Meth")

var Lit_476 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Const")

var Lit_477 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Local")

var Lit_478 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$SetLocal")

var Lit_479 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$SelfField")

var Lit_480 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$OuterPath")

var Lit_481 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$ArithJ")

var Lit_482 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$ArithD")

var Lit_483 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Conv")

var Lit_484 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Boxing")

var Lit_485 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Unbox")

var Lit_486 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Cmp")

var Lit_487 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Test")

var Lit_488 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$IsInst")

var Lit_489 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$CheckCast")

var Lit_490 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$NullChecked")

var Lit_491 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Do")

var Lit_492 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Let")

var Lit_493 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Labeled")

var Lit_494 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Jump")

var Lit_495 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Recur")

var Lit_496 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$If")

var Lit_497 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$AndOr")

var Lit_498 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Throw")

var Lit_499 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Try")

var Lit_500 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Monitor")

var Lit_501 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$CallI")

var Lit_502 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$CallV")

var Lit_503 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$CallR")

var Lit_504 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$ObjectCall")

var Lit_505 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$VarDeref")

var Lit_506 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$VarInvoke")

var Lit_507 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$FiAdapter")

var Lit_508 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$NewI")

var Lit_509 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$CtorCall")

var Lit_510 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$NewR")

var Lit_511 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$GetField")

var Lit_512 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$SetField")

var Lit_513 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$GetStatic")

var Lit_514 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$SetStatic")

var Lit_515 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$FieldR")

var Lit_516 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$NewArray")

var Lit_517 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$ArrayInit")

var Lit_518 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Aget")

var Lit_519 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Aset")

var Lit_520 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Alength")

var Lit_521 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$ArrayClone")

var Lit_522 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$JavaStr")

var Lit_523 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$ForEach")

var Lit_524 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Switch")

var Lit_525 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$IfInstance")

var Lit_526 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$MakeLambda")

var Lit_527 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$RecordOp")

var Lit_528 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$SuperCtor")

var Lit_529 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$SuperCall")

var Lit_530 *jrt.String = jrt.Intern("java.lang.reflect.Method")

var Lit_531 *jrt.String = jrt.Intern("java.lang.reflect.Constructor")

var Lit_532 *jrt.String = jrt.Intern("java.lang.reflect.Field")

var Lit_533 *jrt.String = jrt.Intern("java.lang.reflect.Modifier")

var Lit_534 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000008$fn__393000009")

var Lit_535 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000075$fn__393000076")

var Lit_536 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000080$fn__393000081")

var Lit_537 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000084$fn__393000085")

var Lit_538 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000088$fn__393000089")

var Lit_539 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000092$fn__393000093")

var Lit_540 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000096$fn__393000097")

var Lit_541 *jrt.String = jrt.Intern("set! of a local not in this frame: ")

var Lit_542 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000104$fn__393000105")

var Lit_543 *jrt.String = jrt.Intern("No receiver for an outer instance here")

var Lit_544 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000108$fn__393000109")

var Lit_545 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000112$fn__393000113")

var Lit_546 *jrt.String = jrt.Intern("cls")

var Lit_547 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000116$fn__393000117")

var Lit_548 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000120$fn__393000121")

var Lit_549 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000124$fn__393000125")

var Lit_550 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000128$fn__393000129")

var Lit_551 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000132$fn__393000133")

var Lit_552 *jrt.String = jrt.Intern("arith ")

var Lit_553 *jrt.String = jrt.Intern("arith of type ")

var Lit_554 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000142$fn__393000143")

var Lit_555 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000148$fn__393000149")

var Lit_556 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000152$fn__393000153")

var Lit_557 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000156$fn__393000157")

var Lit_558 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000160$fn__393000161")

var Lit_559 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000168$fn__393000169")

var Lit_560 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000172$fn__393000173")

var Lit_561 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000176$fn__393000177")

var Lit_562 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000176$fn__393000177$branch__393000178")

var Lit_563 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000183$fn__393000184")

var Lit_564 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000183$fn__393000184$fn__393000185")

var Lit_565 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000211$fn__393000212")

var Lit_566 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000215$fn__393000216")

var Lit_567 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000219$fn__393000220")

var Lit_568 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000223$fn__393000224")

var Lit_569 *jrt.String = jrt.Intern("break target not in scope")

var Lit_570 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000227$fn__393000228")

var Lit_571 *jrt.String = jrt.Intern("recur target not in scope")

var Lit_572 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000227$fn__393000228$fn__393000229")

var Lit_573 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000233$fn__393000234")

var Lit_574 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000237$fn__393000238")

var Lit_575 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000241$fn__393000242")

var Lit_576 *jrt.String = jrt.Intern("Ljava/lang/Object;")

var Lit_577 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000241$fn__393000242$conv__393000243")

var Lit_578 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000241$fn__393000242$fn__393000245")

var Lit_579 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000241$fn__393000242$fn__393000247")

var Lit_580 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000241$fn__393000242$fn__393000269")

var Lit_581 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000241$fn__393000242$fn__393000275")

var Lit_582 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000241$fn__393000242$iter__393000249__393000255")

var Lit_583 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000241$fn__393000242$iter__393000249__393000255$fn__393000256")

var Lit_584 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000241$fn__393000242$iter__393000249__393000255$fn__393000256$iter__393000251__393000260")

var Lit_585 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000241$fn__393000242$iter__393000249__393000255$fn__393000256$iter__393000251__393000260$fn__393000261")

var Lit_586 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000241$fn__393000242$iter__393000249__393000255$fn__393000256$iter__393000251__393000260$fn__393000261$fn__393000262")

var Lit_587 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000282$fn__393000283")

var Lit_588 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000286$fn__393000287")

var Lit_589 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000298$fn__393000299")

var Lit_590 *jrt.String = jrt.Intern("No method ")

var Lit_591 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000298$fn__393000299$fn__393000302")

var Lit_592 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000319$fn__393000320")

var Lit_593 *jrt.String = jrt.Intern("matchException")

var Lit_594 *jrt.String = jrt.Intern("(Ljava/lang/String;Ljava/lang/Throwable;)Ljava/lang/RuntimeException;")

var Lit_595 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000319$fn__393000320$fn__393000324")

var Lit_596 *jrt.String = jrt.Intern("java/lang/MatchException")

var Lit_597 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000319$fn__393000320$fn__393000327")

var Lit_598 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000319$fn__393000320$fn__393000329")

var Lit_599 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000341$fn__393000342")

var Lit_600 *jrt.String = jrt.Intern("const__")

var Lit_601 *jrt.String = jrt.Intern("$assertionsDisabled")

var Lit_602 *jrt.String = jrt.Intern("No static field ")

var Lit_603 *jrt.String = jrt.Intern("No field ")

var Lit_604 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000348$fn__393000349")

var Lit_605 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000355$fn__393000356")

var Lit_606 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000359$fn__393000360")

var Lit_607 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000363$fn__393000364")

var Lit_608 *jrt.String = jrt.Intern("No var for ")

var Lit_609 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000368$fn__393000369")

var Lit_610 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000368$fn__393000369$fn__393000370")

var Lit_611 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000374$fn__393000375")

var Lit_612 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000379$fn__393000380")

var Lit_613 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000379$fn__393000380$fn__393000381")

var Lit_614 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000386$fn__393000387")

var Lit_615 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000386$fn__393000387$fn__393000388")

var Lit_616 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000392$fn__393000393")

var Lit_617 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000396$fn__393000397")

var Lit_618 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000400$fn__393000401")

var Lit_619 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000404$fn__393000405")

var Lit_620 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000404$fn__393000405$fn__393000406")

var Lit_621 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000404$fn__393000405$fn__393000408")

var Lit_622 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000404$fn__393000405$fn__393000410")

var Lit_623 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000404$fn__393000405$fn__393000412")

var Lit_624 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000416$fn__393000417")

var Lit_625 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000429$fn__393000430")

var Lit_626 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000429$fn__393000430$br__393000431")

var Lit_627 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000435$fn__393000436")

var Lit_628 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000435$fn__393000436$arm__393000437")

var Lit_629 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000435$fn__393000436$fn__393000460")

var Lit_630 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000435$fn__393000436$fn__393000466")

var Lit_631 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000435$fn__393000436$fn__393000519")

var Lit_632 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000435$fn__393000436$fn__393000525")

var Lit_633 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000435$fn__393000436$fn__393000530")

var Lit_634 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000435$fn__393000436$fn__393000534")

var Lit_635 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000435$fn__393000436$iter__393000439__393000445")

var Lit_636 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000435$fn__393000436$iter__393000439__393000445$fn__393000446")

var Lit_637 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000435$fn__393000436$iter__393000439__393000445$fn__393000446$iter__393000441__393000450")

var Lit_638 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000435$fn__393000436$iter__393000439__393000445$fn__393000446$iter__393000441__393000450$fn__393000451")

var Lit_639 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000435$fn__393000436$iter__393000439__393000445$fn__393000446$iter__393000441__393000450$fn__393000451$fn__393000452")

var Lit_640 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000435$fn__393000436$iter__393000471__393000475")

var Lit_641 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000435$fn__393000436$iter__393000471__393000475$fn__393000476")

var Lit_642 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000435$fn__393000436$iter__393000471__393000475$fn__393000476$fn__393000477")

var Lit_643 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000702$fn__393000703")

var Lit_644 *jrt.String = jrt.Intern("Constructor call outside the constructor prologue")

var Lit_645 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000781$fn__393000782")

var Lit_646 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000781$fn__393000782$fn__393000783")

var Lit_647 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000781$fn__393000782$fn__393000785")

var Lit_648 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000781$fn__393000782$fn__393000787")

var Lit_649 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000792$fn__393000793")

var Lit_650 *jrt.String = jrt.Intern("The Go build's class forms do not support variable arity method references yet")

var Lit_651 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000792$fn__393000793$conv_args__393000806")

var Lit_652 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000792$fn__393000793$conv_args__393000806$fn__393000807")

var Lit_653 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000792$fn__393000793$fn__393000802")

var Lit_654 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000792$fn__393000793$fn__393000804")

var Lit_655 *jrt.String = jrt.Intern("arbace.classes.interp$eval393000792$fn__393000793$fn__393000812")

var Lit_656 *jrt.String = jrt.Intern("arbace.classes.interp$eval393001002$fn__393001003")

var Lit_657 *jrt.String = jrt.Intern("arbace.lang.Compiler$CFGo$GoHost")

var Lit_658 *jrt.String = jrt.Intern("arbace.classes.interp$fail")

var Lit_659 *jrt.String = jrt.Intern("arbace.classes.interp$field_index")

var Lit_660 *jrt.String = jrt.Intern("arbace.classes.interp$find_field")

var Lit_661 *jrt.String = jrt.Intern("arbace.classes.interp$find_field$fn__393000061")

var Lit_662 *jrt.String = jrt.Intern("arbace.classes.interp$find_field$fn__393000064")

var Lit_663 *jrt.String = jrt.Intern("arbace.classes.interp$find_method")

var Lit_664 *jrt.String = jrt.Intern("arbace.classes.interp$find_method$fn__393000045")

var Lit_665 *jrt.String = jrt.Intern("arbace.classes.interp$find_method$fn__393000047")

var Lit_666 *jrt.String = jrt.Intern("arbace.classes.interp$find_method$fn__393000050")

var Lit_667 *jrt.String = jrt.Intern("arbace.classes.interp$find_static")

var Lit_668 *jrt.String = jrt.Intern("arbace.classes.interp$find_static$fn__393000040")

var Lit_669 *jrt.String = jrt.Intern("arbace.classes.interp$finish_BANG_")

var Lit_670 *jrt.String = jrt.Intern("arbace.classes.interp$has_QMARK_")

var Lit_671 *jrt.String = jrt.Intern("arbace.classes.interp$host")

var Lit_672 *jrt.String = jrt.Intern("arbace.classes.interp$implicit_fields")

var Lit_673 *jrt.String = jrt.Intern("arbace.classes.interp$implicit_fields$iter__393000307__393000311")

var Lit_674 *jrt.String = jrt.Intern("arbace.classes.interp$implicit_fields$iter__393000307__393000311$fn__393000312")

var Lit_675 *jrt.String = jrt.Intern("arbace.classes.interp$implicit_fields$iter__393000307__393000311$fn__393000312$fn__393000313")

var Lit_676 *jrt.String = jrt.Intern("arbace.classes.interp$init_nodes")

var Lit_677 *jrt.String = jrt.Intern("arbace.classes.interp$init_nodes$fn__393000688")

var Lit_678 *jrt.String = jrt.Intern("arbace.classes.interp$instance_fields")

var Lit_679 *jrt.String = jrt.Intern("arbace.classes.interp$internal__GT_class")

var Lit_680 *jrt.String = jrt.Intern("arbace.classes.interp$kind")

var Lit_681 *jrt.String = jrt.Intern("arbace.classes.interp$klass")

var Lit_682 *jrt.String = jrt.Intern("arbace.classes.interp$konst")

var Lit_683 *jrt.String = jrt.Intern("arbace.classes.interp$lambda_done_BANG_")

var Lit_684 *jrt.String = jrt.Intern("arbace.classes.interp$layout_BANG_")

var Lit_685 *jrt.String = jrt.Intern("The Go build's class forms cannot extend ")

var Lit_686 *jrt.String = jrt.Intern("arbace.classes.interp$layout_BANG_$fn__393000554")

var Lit_687 *jrt.String = jrt.Intern("arbace.classes.interp$layout_BANG_$fn__393000556")

var Lit_688 *jrt.String = jrt.Intern("val$")

var Lit_689 *jrt.String = jrt.Intern("arbace.classes.interp$layout_BANG_$fn__393000558")

var Lit_690 *jrt.String = jrt.Intern("arbace.classes.interp$layout_BANG_$fn__393000560")

var Lit_691 *jrt.String = jrt.Intern("arbace.classes.interp$layout_BANG_$fn__393000572")

var Lit_692 *jrt.String = jrt.Intern("arbace.classes.interp$layout_BANG_$fn__393000574")

var Lit_693 *jrt.String = jrt.Intern("arbace.classes.interp$layout_BANG_$fn__393000576")

var Lit_694 *jrt.String = jrt.Intern("arbace.classes.interp$layout_BANG_$fn__393000578")

var Lit_695 *jrt.String = jrt.Intern("arbace.classes.interp$let_node")

var Lit_696 *jrt.String = jrt.Intern("arbace.classes.interp$let_node$fn__393000191")

var Lit_697 *jrt.String = jrt.Intern("arbace.classes.interp$let_node$fn__393000197")

var Lit_698 *jrt.String = jrt.Intern("arbace.classes.interp$let_node$fn__393000203")

var Lit_699 *jrt.String = jrt.Intern("arbace.classes.interp$let_node$fn__393000208")

var Lit_700 *jrt.String = jrt.Intern("arbace.classes.interp$local_node")

var Lit_701 *jrt.String = jrt.Intern("No receiver here: ")

var Lit_702 *jrt.String = jrt.Intern("Local not available here: ")

var Lit_703 *jrt.String = jrt.Intern("arbace.classes.interp$make_klass")

var Lit_704 *jrt.String = jrt.Intern("AFunction")

var Lit_705 *jrt.String = jrt.Intern("RestFn")

var Lit_706 *jrt.String = jrt.Intern("arbace.classes.interp$meth_classes")

var Lit_707 *jrt.String = jrt.Intern("arbace.classes.interp$meth_of")

var Lit_708 *jrt.String = jrt.Intern("arbace.classes.interp$meth_of$fn__393000546")

var Lit_709 *jrt.String = jrt.Intern("arbace.classes.interp$method_of")

var Lit_710 *jrt.String = jrt.Intern("arbace.classes.interp$method_of$fn__393000295")

var Lit_711 *jrt.String = jrt.Intern("arbace.classes.interp$new_ctx")

var Lit_712 *jrt.String = jrt.Intern("arbace.classes.interp$new_lambda_klass")

var Lit_713 *jrt.String = jrt.Intern("$$Lambda/")

var Lit_714 *jrt.String = jrt.Intern("arbace.classes.interp$node")

var Lit_715 *jrt.String = jrt.Intern("arbace.classes.interp$nodes")

var Lit_716 *jrt.String = jrt.Intern("arbace.classes.interp$params_BANG_")

var Lit_717 *jrt.String = jrt.Intern("arbace.classes.interp$params_BANG_$fn__393000624")

var Lit_718 *jrt.String = jrt.Intern("arbace.classes.interp$params_BANG_$fn__393000626")

var Lit_719 *jrt.String = jrt.Intern("arbace.classes.interp$params_of")

var Lit_720 *jrt.String = jrt.Intern("arbace.classes.interp$pattern")

var Lit_721 *jrt.String = jrt.Intern("arbace.classes.interp$pattern$fn__393000424")

var Lit_722 *jrt.String = jrt.Intern("arbace.classes.interp$pattern$fn__393000426")

var Lit_723 *jrt.String = jrt.Intern("arbace.classes.interp$pending_BANG_")

var Lit_724 *jrt.String = jrt.Intern("Class ")

var Lit_725 *jrt.String = jrt.Intern(" (a class form of the enclosing do) is not defined yet")

var Lit_726 *jrt.String = jrt.Intern("arbace.classes.interp$pending_QMARK_")

var Lit_727 *jrt.String = jrt.Intern("arbace.classes.interp$ptypes")

var Lit_728 *jrt.String = jrt.Intern("arbace.classes.interp$publish_BANG_")

var Lit_729 *jrt.String = jrt.Intern("arbace.classes.interp$publish_BANG_$fn__393000821")

var Lit_730 *jrt.String = jrt.Intern("arbace.classes.interp$publish_members_BANG_")

var Lit_731 *jrt.String = jrt.Intern("arbace.classes.interp$real_method")

var Lit_732 *jrt.String = jrt.Intern("arbace.classes.interp$real_method$fn__393000055")

var Lit_733 *jrt.String = jrt.Intern("arbace.classes.interp$real_method$fn__393000057")

var Lit_734 *jrt.String = jrt.Intern("arbace.classes.interp$receiver_ctx")

var Lit_735 *jrt.String = jrt.Intern("arbace.classes.interp$record_op_node")

var Lit_736 *jrt.String = jrt.Intern("arbace.classes.interp$record_op_node$fn__393000633")

var Lit_737 *jrt.String = jrt.Intern("arbace.classes.interp$record_op_node$fn__393000635")

var Lit_738 *jrt.String = jrt.Intern("arbace.classes.interp$republish_BANG_")

var Lit_739 *jrt.String = jrt.Intern("arbace.classes.interp$republish_BANG_$fn__393000832")

var Lit_740 *jrt.String = jrt.Intern("arbace.classes.interp$republish_BANG_$fn__393000834")

var Lit_741 *jrt.String = jrt.Intern("arbace.classes.interp$sibling_QMARK_")

var Lit_742 *jrt.String = jrt.Intern("arbace.classes.interp$sig_class")

var Lit_743 *jrt.String = jrt.Intern("arbace.classes.interp$slot_BANG_")

var Lit_744 *jrt.String = jrt.Intern("arbace.classes.interp$static_index")

var Lit_745 *jrt.String = jrt.Intern("arbace.classes.interp$super_outer_fields")

var Lit_746 *jrt.String = jrt.Intern("arbace.classes.interp$target_code")

var Lit_747 *jrt.String = jrt.Intern("arbace.classes.interp$tc")

var Lit_748 *jrt.String = jrt.Intern("arbace.classes.interp$this0_index")

var Lit_749 *jrt.String = jrt.Intern("Not an interpreted class: ")

var Lit_750 *jrt.String = jrt.Intern("No outer instance in ")

var Lit_751 *jrt.String = jrt.Intern("arbace.classes.interp$trivial_super_QMARK_")

var Lit_752 *jrt.String = jrt.Intern("arbace.classes.interp$value_convert")

var Lit_753 *jrt.String = jrt.Intern("arbace.classes.interp$vt")

var Lit_754 *jrt.String = jrt.Intern("arbace.classes.interp$vtable_BANG_")

var Lit_755 *jrt.String = jrt.Intern("arbace.classes.interp$zero_of")

var Lit_756 *jrt.String = jrt.Intern("in-ns")

var Lit_757 *jrt.String = jrt.Intern("internal name -> the Klass of the interpreted class of that name defined last.")

var Lit_758 *jrt.String = jrt.Intern("line")

var Lit_759 *jrt.String = jrt.Intern("column")

var Lit_760 *jrt.String = jrt.Intern("file")

var Lit_761 *jrt.String = jrt.Intern("arbace/classes/interp.ae")

var Lit_762 *jrt.String = jrt.Intern("dynamic")

var Lit_763 *jrt.String = jrt.Intern("internal name -> Klass of the classes of the compilation being built.")

var Lit_764 *jrt.String = jrt.Intern("True while define! builds the compilation's bodies, before any of its methods is called: a\n  sibling class (below) is then pending even when a class of its name exists.")

var Lit_765 *jrt.String = jrt.Intern("arglists")

var Lit_766 *jrt.String = jrt.Intern("n")

var Lit_767 *jrt.String = jrt.Intern("Is n a class of the enclosing top-level do entered as a declaration (SPEC §9.2): declared in\n  the compilation being built, compiled and defined by a later form of the do?")

var Lit_768 *jrt.String = jrt.Intern("Throws the signal that a body refers to sibling class n, not defined yet (define! leaves that\n  body to be built on its first call, when the do's later forms have defined n; at that call, an\n  error).")

var Lit_769 *jrt.String = jrt.Intern("e")

var Lit_770 *jrt.String = jrt.Intern("tag")

var Lit_771 *jrt.String = jrt.Intern("The Klass of internal name n when n is an interpreted class (of this compilation, or defined\n  earlier and still the class of that name), else nil. A sibling while define! builds the\n  bodies (*eager*): pending, the class of that name defined later by the do.")

var Lit_772 *jrt.String = jrt.Intern("private")

var Lit_773 *jrt.String = jrt.Intern("msg")

var Lit_774 *jrt.String = jrt.Intern("&")

var Lit_775 *jrt.String = jrt.Intern("data")

var Lit_776 *jrt.String = jrt.Intern("ty")

var Lit_777 *jrt.String = jrt.Intern("The type char of a node or binding type: the descriptor's first char for primitives and V,\n  L for references, N for null, X for none.")

var Lit_778 *jrt.String = jrt.Intern("d")

var Lit_779 *jrt.String = jrt.Intern("The Class of a descriptor: a primitive's, an interpreted class's (nil on the JVM's test host,\n  where it is Object), an array's, or a loaded class.")

var Lit_780 *jrt.String = jrt.Intern("ctx")

var Lit_781 *jrt.String = jrt.Intern("A new slot for a value of type ty (in the long slots for J and D kinds).")

var Lit_782 *jrt.String = jrt.Intern("A slot for binding b (by its id).")

var Lit_783 *jrt.String = jrt.Intern("declared")

var Lit_784 *jrt.String = jrt.Intern("v")

var Lit_785 *jrt.String = jrt.Intern("xs")

var Lit_786 *jrt.String = jrt.Intern("[Larbace.lang.Compiler$CF$Node;")

var Lit_787 *jrt.String = jrt.Intern("rec?")

var Lit_788 *jrt.String = jrt.Intern("instance-fields")

var Lit_789 *jrt.String = jrt.Intern("k")

var Lit_790 *jrt.String = jrt.Intern("The instance fields of interpreted class n in order: [{:name :desc :flags :owner}], its\n  superclasses' first; then the hidden ones (this$0, val$x).")

var Lit_791 *jrt.String = jrt.Intern("fname")

var Lit_792 *jrt.String = jrt.Intern("The index of field `fname` of interpreted class k (or of an interpreted superclass), or nil.")

var Lit_793 *jrt.String = jrt.Intern("[Klass index] of static field fname as seen from interpreted class k (its own, its\n  superclasses', its interfaces'), or nil.")

var Lit_794 *jrt.String = jrt.Intern("c")

var Lit_795 *jrt.String = jrt.Intern("Class")

var Lit_796 *jrt.String = jrt.Intern("mname")

var Lit_797 *jrt.String = jrt.Intern("The java.lang.reflect.Method named mname with descriptor desc of class c or its supertypes,\n  accessible, or nil.")

var Lit_798 *jrt.String = jrt.Intern("The reflective method for a call of owner's method mname desc: owner's own, or for an\n  interpreted owner the one its nearest non-interpreted supertype has (Object's toString).")

var Lit_799 *jrt.String = jrt.Intern("The node reading binding b in ctx: its slot, the receiver, or a captured value (a field of\n  the receiver: local and anonymous classes' val$x).")

var Lit_800 *jrt.String = jrt.Intern("Node n (of type from) as a value of type `to`, converted as the JVM converts: primitive\n  widening and narrowing, boxing by the value's own type, unboxing a wrapper.")

var Lit_801 *jrt.String = jrt.Intern("an")

var Lit_802 *jrt.String = jrt.Intern("The node of analyzed node an, converted to type `to` (emit-to).")

var Lit_803 *jrt.String = jrt.Intern("Node n of type from as type to, also by checkcast and by unboxing from a non-wrapper\n  (method references, bridges: LambdaMetafactory's and javac's adaptations).")

var Lit_804 *jrt.String = jrt.Intern("add")

var Lit_805 *jrt.String = jrt.Intern("sub")

var Lit_806 *jrt.String = jrt.Intern("mul")

var Lit_807 *jrt.String = jrt.Intern("div")

var Lit_808 *jrt.String = jrt.Intern("rem")

var Lit_809 *jrt.String = jrt.Intern("neg")

var Lit_810 *jrt.String = jrt.Intern("dec")

var Lit_811 *jrt.String = jrt.Intern("and")

var Lit_812 *jrt.String = jrt.Intern("or")

var Lit_813 *jrt.String = jrt.Intern("xor")

var Lit_814 *jrt.String = jrt.Intern("andnot")

var Lit_815 *jrt.String = jrt.Intern("<")

var Lit_816 *jrt.String = jrt.Intern("<=")

var Lit_817 *jrt.String = jrt.Intern(">")

var Lit_818 *jrt.String = jrt.Intern(">=")

var Lit_819 *jrt.String = jrt.Intern("==")

var Lit_820 *jrt.String = jrt.Intern("!=")

var Lit_821 *jrt.String = jrt.Intern("global-hierarchy")

var Lit_822 *jrt.String = jrt.Intern("The interpreter's node of analyzed node an.")

var Lit_823 *jrt.String = jrt.Intern("set-local")

var Lit_824 *jrt.String = jrt.Intern("The index of the this$0 field of interpreted class c.")

var Lit_825 *jrt.String = jrt.Intern("this-path")

var Lit_826 *jrt.String = jrt.Intern("outer-param-path")

var Lit_827 *jrt.String = jrt.Intern("class-lit")

var Lit_828 *jrt.String = jrt.Intern("null-checked")

var Lit_829 *jrt.String = jrt.Intern("cast")

var Lit_830 *jrt.String = jrt.Intern("instance?")

var Lit_831 *jrt.String = jrt.Intern("arith")

var Lit_832 *jrt.String = jrt.Intern("compare")

var Lit_833 *jrt.String = jrt.Intern("nil?")

var Lit_834 *jrt.String = jrt.Intern("identical?")

var Lit_835 *jrt.String = jrt.Intern("bool=")

var Lit_836 *jrt.String = jrt.Intern("or?")

var Lit_837 *jrt.String = jrt.Intern("if")

var Lit_838 *jrt.String = jrt.Intern("do")

var Lit_839 *jrt.String = jrt.Intern("loop?")

var Lit_840 *jrt.String = jrt.Intern("let")

var Lit_841 *jrt.String = jrt.Intern("loop")

var Lit_842 *jrt.String = jrt.Intern("label")

var Lit_843 *jrt.String = jrt.Intern("break")

var Lit_844 *jrt.String = jrt.Intern("recur")

var Lit_845 *jrt.String = jrt.Intern("return")

var Lit_846 *jrt.String = jrt.Intern("throw")

var Lit_847 *jrt.String = jrt.Intern("try")

var Lit_848 *jrt.String = jrt.Intern("monitor")

var Lit_849 *jrt.String = jrt.Intern("assert")

var Lit_850 *jrt.String = jrt.Intern("key")

var Lit_851 *jrt.String = jrt.Intern("The Meth of interpreted class k declaring or inheriting method key (non-virtual lookup:\n  its own, then its superclasses', then its interfaces' defaults and statics).")

var Lit_852 *jrt.String = jrt.Intern("invoke")

var Lit_853 *jrt.String = jrt.Intern("cn")

var Lit_854 *jrt.String = jrt.Intern("outer-an")

var Lit_855 *jrt.String = jrt.Intern("[[field-index node] ...]: the outer instance and captured values a new object of interpreted\n  class cn gets before its constructor runs (javac's implicit constructor arguments).")

var Lit_856 *jrt.String = jrt.Intern("The outer instance of an anonymous class's interpreted superclass, as [[index node]].")

var Lit_857 *jrt.String = jrt.Intern("The value of a Clojure constant field (const__N) of class owner, or ::none.")

var Lit_858 *jrt.String = jrt.Intern("get-static")

var Lit_859 *jrt.String = jrt.Intern("set-static")

var Lit_860 *jrt.String = jrt.Intern("get-field")

var Lit_861 *jrt.String = jrt.Intern("set-field")

var Lit_862 *jrt.String = jrt.Intern("var-deref")

var Lit_863 *jrt.String = jrt.Intern("var-invoke")

var Lit_864 *jrt.String = jrt.Intern("fi-adapter")

var Lit_865 *jrt.String = jrt.Intern("new-array")

var Lit_866 *jrt.String = jrt.Intern("array-init")

var Lit_867 *jrt.String = jrt.Intern("aget")

var Lit_868 *jrt.String = jrt.Intern("aset")

var Lit_869 *jrt.String = jrt.Intern("alength")

var Lit_870 *jrt.String = jrt.Intern("java-str")

var Lit_871 *jrt.String = jrt.Intern("for-each")

var Lit_872 *jrt.String = jrt.Intern("acc")

var Lit_873 *jrt.String = jrt.Intern("slot")

var Lit_874 *jrt.String = jrt.Intern("A call of record accessor acc on the value in ref slot `slot`.")

var Lit_875 *jrt.String = jrt.Intern("The Pat of pattern p.")

var Lit_876 *jrt.String = jrt.Intern("if-instance")

var Lit_877 *jrt.String = jrt.Intern("switch")

var Lit_878 *jrt.String = jrt.Intern("f")

var Lit_879 *jrt.String = jrt.Intern("arbace.lang.Compiler$CF$Host")

var Lit_880 *jrt.String = jrt.Intern("lambda-klass")

var Lit_881 *jrt.String = jrt.Intern("m")

var Lit_882 *jrt.String = jrt.Intern("A Meth of klass k for method entry m of declaration d.")

var Lit_883 *jrt.String = jrt.Intern("The Klass of class n of the compilation (members still to come).")

var Lit_884 *jrt.String = jrt.Intern("Superclass and interfaces, the field layout, statics and methods of k (class n).")

var Lit_885 *jrt.String = jrt.Intern("The virtual methods of k: its superclass's, its interfaces' defaults (when nothing else\n  gives them), then its own non-static, non-private methods.")

var Lit_886 *jrt.String = jrt.Intern("The building context of a method of class n with receiver binding recv (nil: static).")

var Lit_887 *jrt.String = jrt.Intern("mt")

var Lit_888 *jrt.String = jrt.Intern("bs")

var Lit_889 *jrt.String = jrt.Intern("The body of derived method m (bridges, record members).")

var Lit_890 *jrt.String = jrt.Intern("The instance initializers of class n (field initializers and initializer blocks), in ctx.")

var Lit_891 *jrt.String = jrt.Intern("Is cn a superclass whose constructor the interpreter does not run: Object, Record, and the\n  AFunction or RestFn of a Clojure fn's class (CF$FnObj's).")

var Lit_892 *jrt.String = jrt.Intern("ab")

var Lit_893 *jrt.String = jrt.Intern("The node of a constructor's call (its super or this call), and after a super call the\n  instance initializers.")

var Lit_894 *jrt.String = jrt.Intern("An enum constructor's implicit name and ordinal (its first two slots), for its super or this\n  call; none for other classes.")

var Lit_895 *jrt.String = jrt.Intern("ctor-call")

var Lit_896 *jrt.String = jrt.Intern("Builds Meth mt (method entry m of class n, declaration d): its frame layout and body.")

var Lit_897 *jrt.String = jrt.Intern("Enters sibling class forms (the other class forms of a top-level do, SPEC §9.2) as\n  declarations only (arbace.classes.compiler/declare-siblings!).")

var Lit_898 *jrt.String = jrt.Intern("forms")

var Lit_899 *jrt.String = jrt.Intern("Analyzes class forms (each the rest of a defclass form) in namespace ns as one compilation,\n  with sibling class forms entered as declarations only (arbace.classes.compiler/compile-forms\n  without emitting). Must run inside the bindings of with-unit. Returns the top-level names.")

var Lit_900 *jrt.String = jrt.Intern("nf")

var Lit_901 *jrt.String = jrt.Intern("A Klass for a lambda of class cls implementing fi and markers, with nf fields.")

var Lit_902 *jrt.String = jrt.Intern("k (a lambda's class) with its method mt: defined by the host, the method published.")

var Lit_903 *jrt.String = jrt.Intern("method-ref")

var Lit_904 *jrt.String = jrt.Intern("While publish! publishes a class: an atom of the sibling classes its members' types name that\n  are not defined yet.")

var Lit_905 *jrt.String = jrt.Intern("internal name of a sibling class not defined yet -> the Klasses whose members' types name it,\n  published with Object for it, to publish again when it is defined (SA90 (b)).")

var Lit_906 *jrt.String = jrt.Intern("The Class of a member's type for the host: desc->class, Object for a sibling class not\n  defined yet (SPEC §9.2: the classes of a top-level do refer to each other in their types too),\n  which publish! records to publish the member again when the sibling is defined.")

var Lit_907 *jrt.String = jrt.Intern("Hands k's members to the host: its virtual methods (its own and those it inherits from\n  interpreted classes), its static and private methods, constructors, fields. A sibling class not\n  defined yet in their types is Object until it is defined: k then waits for it (republish!).")

var Lit_908 *jrt.String = jrt.Intern("ks")

var Lit_909 *jrt.String = jrt.Intern("The classes whose members' types name n (internal name), just defined, published again with\n  n's class: their compilation's classes and declarations, with the classes defined now (ks).")

var Lit_910 *jrt.String = jrt.Intern("The static initializer of k (class n).")

var Lit_911 *jrt.String = jrt.Intern("Compiles class forms (each the rest of a defclass form) in namespace ns as one compilation,\n  the sibling class forms entered as declarations, into interpreted classes. Returns [[dotted-name\n  Class] ...] of the top-level classes (the Class nil on the JVM's test host).")

var Lit_912 *jrt.String = jrt.Intern("compile-and-load!")

var Lit_913 *jrt.String = jrt.Intern("keys")

var Lit_914 *jrt.String = jrt.Intern("arbace.classes.compiler/compile-and-load! of the Go build (arbace.classes.native's\n  compiler): the classes interpreted.")

var Lit_915 *jrt.String = jrt.Intern("J")

var Lit_916 *jrt.String = jrt.Intern("S")

var Lit_917 *jrt.String = jrt.Intern("C")

var Lit_918 *jrt.String = jrt.Intern("B")
