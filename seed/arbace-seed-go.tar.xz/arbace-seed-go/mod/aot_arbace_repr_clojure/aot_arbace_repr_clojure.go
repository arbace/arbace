//line aot_arbace_repr_clojure.ae:1
package aot_arbace_repr_clojure

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_java_io"
	"arbace/aot_arbace_repr_clojure_rules"
	"arbace/aot_arbace_repr_clojure_text"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_clojure_eval716000004_loading__1927001464__auto____716000005_A_New() *A_arbace_repr_clojure_eval716000004_loading__1927001464__auto____716000005_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_eval716000004_loading__1927001464__auto____716000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_clojure_eval716000004_loading__1927001464__auto____716000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_clojure_eval716000004_loading__1927001464__auto____716000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_clojure_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_A_const_1); lang.IFn_Cast(A_arbace_repr_clojure_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_repr_clojure_A_const_3, A_arbace_repr_clojure_A_const_4, A_arbace_repr_clojure_A_const_5, A_arbace_repr_clojure_A_const_6); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_13)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_repr_clojure_eval716000008_fn__716000009_A_New() *A_arbace_repr_clojure_eval716000008_fn__716000009_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_eval716000008_fn__716000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_clojure_eval716000008_fn__716000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_clojure_eval716000008_fn__716000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_7.GetRawRoot__O()); var tmp2 any; var root_18 any = A_arbace_repr_clojure_A_const_8.GetRawRoot__O(); var linked_19 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_18, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_20 lang.IFn; if linked_19 == nil { ifn_20 = lang.IFn_Cast(root_18) } else { ifn_20 = nil }; var arg_21 any = A_arbace_repr_clojure_A_const_9; if linked_19 == nil { tmp2 = ifn_20.Invoke_O__O(arg_21) } else { tmp2 = linked_19.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_18, arg_21) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_repr_clojure_A_const_10.GetRawRoot__O(), A_arbace_repr_clojure_A_const_11) }


























































func A_arbace_repr_clojure_ext_A_New() *A_arbace_repr_clojure_ext_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_ext_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_repr_clojure_ext_A) Ctor() {}
//line :60:1
func (t *A_arbace_repr_clojure_ext_A) Invoke_O_O__O(self, name__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(name__0)).LastIndexOf_String__I(Lit_12); if
										lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return Lit_14 } else { var root_22 any = A_arbace_repr_clojure_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = name__0; var arg_26 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref(); if linked_23 == nil { return ifn_24.Invoke_O_O__O(arg_25, arg_26) } else { return linked_23.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_22, arg_25, arg_26) } } }

func A_arbace_repr_clojure_base_A_New() *A_arbace_repr_clojure_base_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_base_A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_repr_clojure_base_A) Ctor() {}
//line :63:1
func (t *A_arbace_repr_clojure_base_A) Invoke_O_O__O(self, name__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(name__0)).LastIndexOf_String__I(Lit_12); if
										lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return name__0 } else { var root_27 any = A_arbace_repr_clojure_A_const_12.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = name__0; var arg_31 any = A_arbace_repr_clojure_A_const_13; var arg_32 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref(); if linked_28 == nil { return ifn_29.Invoke_O_O_O__O(arg_30, arg_31, arg_32) } else { return linked_28.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_27, arg_30, arg_31, arg_32) } } }

func A_arbace_repr_clojure_plan_A_New() *A_arbace_repr_clojure_plan_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_plan_A{}; t.Ctor(); return t }
//line :66:1
func (t *A_arbace_repr_clojure_plan_A) Ctor() {}
//line :66:1
func (t *A_arbace_repr_clojure_plan_A) Invoke_O_O_O_O__O(self, name__0, siblings__1, p__716000015__2 any) any { var map__716000016__4 any = p__716000015__2; var map__716000016__5 any; if lang.ISeq_InstanceOf(map__716000016__4) { var tmp1 any; var root_33 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_34 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_33, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_35 lang.IFn; if linked_34 == nil { ifn_35 = lang.IFn_Cast(root_33) } else { ifn_35 = nil }; var arg_36 any = map__716000016__4; if linked_34 == nil { tmp1 = ifn_35.Invoke_O__O(arg_36) } else { tmp1 = linked_34.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_33, arg_36) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_37 any = A_arbace_repr_clojure_A_const_15.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_37, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_39 lang.IFn; if linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any = map__716000016__4; if linked_38 == nil { tmp2 = ifn_39.Invoke_O__O(arg_40) } else { tmp2 = linked_38.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_37, arg_40) }; map__716000016__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_41 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = map__716000016__4; if linked_42 == nil { tmp3 = ifn_43.Invoke_O__O(arg_44) } else { tmp3 = linked_42.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_41, arg_44) }; if jrt.J2g_Truth(tmp3) { var root_45 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any = map__716000016__4; if linked_46 == nil { map__716000016__5 = ifn_47.Invoke_O__O(arg_48) } else { map__716000016__5 = linked_46.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_45, arg_48) } } else { map__716000016__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__716000016__5 = map__716000016__4 }; var keep_ext__6 any = lang.RT_Get_O_O__O_NoInit(map__716000016__5, A_arbace_repr_clojure_A_const_18); var text__7 any = lang.RT_Get_O_O__O_NoInit(map__716000016__5, A_arbace_repr_clojure_A_const_19); var full__8 any = lang.RT_Get_O_O__O_NoInit(map__716000016__5, A_arbace_repr_clojure_A_const_20); var e__9 any; var root_49 any = A_arbace_repr_clojure_A_const_21.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, A_arbace_repr_clojure_ext_A_fn_class); var ifn_51 lang.IFn; if





	linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = name__0; if linked_50 == nil { e__9 = ifn_51.Invoke_O__O(arg_52) } else { e__9 = linked_50.(*A_arbace_repr_clojure_ext_A).Invoke_O_O__O(root_49, arg_52) }; var p__10 any; var tmp4 any; var root_53 any = /*line :66:1*/A_arbace_repr_clojure_A_const_22.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_55 lang.IFn; if







	linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = A_arbace_repr_clojure_A_const_23.GetRawRoot__O(); var arg_57 any = name__0; if linked_54 == nil { tmp4 = ifn_55.Invoke_O_O__O(arg_56, arg_57) } else { tmp4 = linked_54.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_53, arg_56, arg_57) }; if /*line :73:1*/ jrt.J2g_Truth(tmp4) { var tmp5 any = A_arbace_repr_clojure_A_const_24; var tmp6 *lang.Keyword
		if lang.Util_Equiv_O_O__Z_NoInit(e__9, Lit_47) { tmp6 = A_arbace_repr_clojure_A_const_25 } else { tmp6 = A_arbace_repr_clojure_A_const_26 }
//line :73:1
		p__10 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6.Ref(), A_arbace_repr_clojure_A_const_27, jrt.Boolean_FALSE.Ref(), A_arbace_repr_clojure_A_const_28, name__0)) } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_A_const_29).Invoke_O__O(e__9)) {


			if jrt.J2g_Truth(keep_ext__6) { var tmp7 any = A_arbace_repr_clojure_A_const_24; var tmp8 any; var root_58 any = A_arbace_repr_clojure_A_const_30.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_58, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_60 lang.IFn
				if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any; var root_62 any = A_arbace_repr_clojure_A_const_12.GetRawRoot__O(); var linked_63 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_62, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_64 lang.IFn; if linked_63 == nil { ifn_64 = lang.IFn_Cast(root_62) } else { ifn_64 = nil }; var arg_65 any = e__9; var arg_66 any = A_arbace_repr_clojure_A_const_31; if linked_63 == nil { arg_61 = ifn_64.Invoke_O_O__O(arg_65, arg_66) } else { arg_61 = linked_63.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_62, arg_65, arg_66) }; if linked_59 == nil { tmp8 = ifn_60.Invoke_O__O(arg_61) } else { tmp8 = linked_59.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_58, arg_61) }
//line :76:1
				p__10 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8, A_arbace_repr_clojure_A_const_27, jrt.Boolean_FALSE.Ref(), A_arbace_repr_clojure_A_const_28, name__0)) } else { var tmp9 any; var root_67 any = A_arbace_repr_clojure_A_const_32.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, A_arbace_repr_clojure_base_A_fn_class); var ifn_69 lang.IFn



					if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any = name__0; if linked_68 == nil { tmp9 = ifn_69.Invoke_O__O(arg_70) } else { tmp9 = linked_68.(*A_arbace_repr_clojure_base_A).Invoke_O_O__O(root_67, arg_70) }
//line :76:1
					if lang.Util_Equiv_O_O__Z_NoInit(Lit_48, tmp9) {




						var tmp10 any; var or__1927000174__auto____10 any; var root_71 any = A_arbace_repr_clojure_A_const_22.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_73 lang.IFn; if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = siblings__1; var arg_75 any = Lit_49; if linked_72 == nil { or__1927000174__auto____10 = ifn_73.Invoke_O_O__O(arg_74, arg_75) } else { or__1927000174__auto____10 = linked_72.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_71, arg_74, arg_75) }; if jrt.J2g_Truth(or__1927000174__auto____10) { tmp10 = or__1927000174__auto____10 } else { var and__1927000168__auto____11 bool = lang.Util_Equiv_O_O__Z_NoInit(e__9, Lit_47)
							if and__1927000168__auto____11 { var root_76 any = A_arbace_repr_clojure_A_const_22.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var arg_79 any = siblings__1; var arg_80 any = Lit_50; if linked_77 == nil { tmp10 = ifn_78.Invoke_O_O__O(arg_79, arg_80) } else { tmp10 = linked_77.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_76, arg_79, arg_80) } } else { tmp10 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11).Ref() } }
//line :81:1
						if jrt.J2g_Truth(tmp10) { var tmp11 any = A_arbace_repr_clojure_A_const_24; var tmp12 any; var root_81 any = A_arbace_repr_clojure_A_const_30.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_83 lang.IFn

							if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any; var root_85 any = A_arbace_repr_clojure_A_const_12.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = e__9; var arg_89 any = A_arbace_repr_clojure_A_const_31; if linked_86 == nil { arg_84 = ifn_87.Invoke_O_O__O(arg_88, arg_89) } else { arg_84 = linked_86.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_85, arg_88, arg_89) }; if linked_82 == nil { tmp12 = ifn_83.Invoke_O__O(arg_84) } else { tmp12 = linked_82.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_81, arg_84) }
//line :81:1
							p__10 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp11, tmp12, A_arbace_repr_clojure_A_const_27, jrt.Boolean_FALSE.Ref(), A_arbace_repr_clojure_A_const_28, name__0)) } else { var tmp13 any = A_arbace_repr_clojure_A_const_24; var tmp14 any; var root_90 any = A_arbace_repr_clojure_A_const_30.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_92 lang.IFn


								if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any; var root_94 any = A_arbace_repr_clojure_A_const_12.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any = e__9; var arg_98 any = A_arbace_repr_clojure_A_const_31; if linked_95 == nil { arg_93 = ifn_96.Invoke_O_O__O(arg_97, arg_98) } else { arg_93 = linked_95.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_94, arg_97, arg_98) }; if linked_91 == nil { tmp14 = ifn_92.Invoke_O__O(arg_93) } else { tmp14 = linked_91.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_90, arg_93) }
//line :81:1
								p__10 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp14, A_arbace_repr_clojure_A_const_27, jrt.Boolean_TRUE.Ref(), A_arbace_repr_clojure_A_const_28, Lit_49)) } } else {
//line :76:1
									var tmp15 any; var root_99 any = A_arbace_repr_clojure_A_const_22.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_101 lang.IFn








									if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any = siblings__1; var arg_103 any; var tmp16 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_51); var tmp17 any; var root_104 any = A_arbace_repr_clojure_A_const_32.GetRawRoot__O(); var linked_105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_104, A_arbace_repr_clojure_base_A_fn_class); var ifn_106 lang.IFn; if linked_105 == nil { ifn_106 = lang.IFn_Cast(root_104) } else { ifn_106 = nil }; var arg_107 any = name__0; if linked_105 == nil { tmp17 = ifn_106.Invoke_O__O(arg_107) } else { tmp17 = linked_105.(*A_arbace_repr_clojure_base_A).Invoke_O_O__O(root_104, arg_107) }; arg_103 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp16, jrt.RefArrayOf(jrt.Object_class, tmp17, nil)).Ref(); if linked_100 == nil { tmp15 = ifn_101.Invoke_O_O__O(arg_102, arg_103) } else { tmp15 = linked_100.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_99, arg_102, arg_103) }
//line :76:1
									if jrt.J2g_Truth(tmp15) { var tmp18 any = A_arbace_repr_clojure_A_const_33; var tmp19 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_52); var tmp20 any; var root_108 any = A_arbace_repr_clojure_A_const_32.GetRawRoot__O(); var linked_109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_108, A_arbace_repr_clojure_base_A_fn_class); var ifn_110 lang.IFn









										if linked_109 == nil { ifn_110 = lang.IFn_Cast(root_108) } else { ifn_110 = nil }; var arg_111 any = name__0; if linked_109 == nil { tmp20 = ifn_110.Invoke_O__O(arg_111) } else { tmp20 = linked_109.(*A_arbace_repr_clojure_base_A).Invoke_O_O__O(root_108, arg_111) }
//line :76:1
										p__10 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp18, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp19, jrt.RefArrayOf(jrt.Object_class, tmp20, nil)).Ref())) } else { var tmp21 any; var and__1927000168__auto____10 bool = lang.Util_Equiv_O_O__Z_NoInit(e__9, Lit_47)










											if and__1927000168__auto____10 { var root_112 any = A_arbace_repr_clojure_A_const_22.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = siblings__1; var arg_116 any; var tmp22 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_53); var tmp23 any; var root_117 any = A_arbace_repr_clojure_A_const_32.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_117, A_arbace_repr_clojure_base_A_fn_class); var ifn_119 lang.IFn; if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = name__0; if linked_118 == nil { tmp23 = ifn_119.Invoke_O__O(arg_120) } else { tmp23 = linked_118.(*A_arbace_repr_clojure_base_A).Invoke_O_O__O(root_117, arg_120) }; arg_116 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp22, jrt.RefArrayOf(jrt.Object_class, tmp23, nil)).Ref(); if linked_113 == nil { tmp21 = ifn_114.Invoke_O_O__O(arg_115, arg_116) } else { tmp21 = linked_113.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_112, arg_115, arg_116) } } else { tmp21 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10).Ref() }
//line :76:1
											if jrt.J2g_Truth(tmp21) { var tmp24 any = A_arbace_repr_clojure_A_const_33; var tmp25 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_54); var tmp26 any; var root_121 any = A_arbace_repr_clojure_A_const_32.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, A_arbace_repr_clojure_base_A_fn_class); var ifn_123 lang.IFn











												if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = name__0; if linked_122 == nil { tmp26 = ifn_123.Invoke_O__O(arg_124) } else { tmp26 = linked_122.(*A_arbace_repr_clojure_base_A).Invoke_O_O__O(root_121, arg_124) }
//line :76:1
												p__10 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp24, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp25, jrt.RefArrayOf(jrt.Object_class, tmp26, nil)).Ref())) } else { if A_arbace_repr_clojure_A_const_34 != nil { var tmp27 any = A_arbace_repr_clojure_A_const_24; var tmp28 any; var root_125 any = A_arbace_repr_clojure_A_const_30.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_125, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_127 lang.IFn












													if linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; var arg_128 any; var root_129 any = A_arbace_repr_clojure_A_const_12.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_129, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any = e__9; var arg_133 any = A_arbace_repr_clojure_A_const_31; if linked_130 == nil { arg_128 = ifn_131.Invoke_O_O__O(arg_132, arg_133) } else { arg_128 = linked_130.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_129, arg_132, arg_133) }; if linked_126 == nil { tmp28 = ifn_127.Invoke_O__O(arg_128) } else { tmp28 = linked_126.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_125, arg_128) }
//line :76:1
													var tmp29 any = tmp28; var tmp30 any = A_arbace_repr_clojure_A_const_27; var tmp31 any = jrt.Boolean_TRUE.Ref(); var tmp32 any = A_arbace_repr_clojure_A_const_28; var tmp33 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_51); var tmp34 any; var root_134 any = A_arbace_repr_clojure_A_const_32.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, A_arbace_repr_clojure_base_A_fn_class); var ifn_136 lang.IFn












													if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any = name__0; if linked_135 == nil { tmp34 = ifn_136.Invoke_O__O(arg_137) } else { tmp34 = linked_135.(*A_arbace_repr_clojure_base_A).Invoke_O_O__O(root_134, arg_137) }
//line :76:1
													p__10 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp27, tmp29, tmp30, tmp31, tmp32, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp33, jrt.RefArrayOf(jrt.Object_class, tmp34, nil)).Ref())) } else { p__10 = nil } } } } } } else {
//line :73:1
														if lang.Util_Equiv_O_O__Z_NoInit(e__9, Lit_55) { p__10 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_24, A_arbace_repr_clojure_A_const_35, A_arbace_repr_clojure_A_const_27, jrt.Boolean_FALSE.Ref(), A_arbace_repr_clojure_A_const_28, name__0)) } else { var tmp35 any; var root_138 any = A_arbace_repr_clojure_A_const_36.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_140 lang.IFn

















															if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any; var tmp36 any = A_arbace_repr_clojure_plan_fn__716000018_A_New_O(name__0); var tmp37 *jrt.Class; var fncls__148 *jrt.Class = A_arbace_repr_clojure_plan_fn__716000018_A_fn_class; if fncls__148 == nil { var fncls__148d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_repr_clojure_plan_fn__716000018_A_fn_class = fncls__148d; tmp37 = fncls__148d } else { tmp37 = fncls__148 }; arg_141 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp36, tmp37, nil); var arg_142 any = text__7; if linked_139 == nil { tmp35 = ifn_140.Invoke_O_O__O(arg_141, arg_142) } else { tmp35 = linked_139.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_138, arg_141, arg_142) }
//line :73:1
															if jrt.J2g_Truth(tmp35) { p__10 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_24, A_arbace_repr_clojure_A_const_19, A_arbace_repr_clojure_A_const_27, jrt.Boolean_FALSE.Ref(), A_arbace_repr_clojure_A_const_28, name__0)) } else { if lang.Util_Equiv_O_O__Z_NoInit(e__9, Lit_57) { p__10 = A_arbace_repr_clojure_A_const_38 } else { if A_arbace_repr_clojure_A_const_34 != nil { p__10 = A_arbace_repr_clojure_A_const_39 } else { p__10 = nil } } } } } }; var tmp38 any; var and__1927000168__auto____11_2 any = full__8; if





















	jrt.J2g_Truth(and__1927000168__auto____11_2) { var tmp39 any = A_arbace_repr_clojure_A_const_25; var and__1927000168__auto____12 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp39, A_arbace_repr_clojure_A_const_24.Invoke_O__O(p__10)); if and__1927000168__auto____12 { tmp38 = A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__10) } else { tmp38 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____12).Ref() } } else { tmp38 = and__1927000168__auto____11_2 }; if jrt.J2g_Truth(tmp38) { var root_149 any = A_arbace_repr_clojure_A_const_40.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_149, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_151 lang.IFn; if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any = p__10; var arg_153 any = A_arbace_repr_clojure_A_const_20; var arg_154 any = jrt.Boolean_TRUE.Ref(); if linked_150 == nil { return ifn_151.Invoke_O_O_O__O(arg_152, arg_153, arg_154) } else { return linked_150.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_149, arg_152, arg_153, arg_154) } } else { return p__10 } }
//line :91:1
func A_arbace_repr_clojure_plan_fn__716000018_A_New_O(p0 any) *A_arbace_repr_clojure_plan_fn__716000018_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_plan_fn__716000018_A{}; t.Ctor_O(p0); return t }
//line :91:1
func (t *A_arbace_repr_clojure_plan_fn__716000018_A) Ctor_O(c__name any) { t.F_name = c__name }
//line :91:1
func (t *A_arbace_repr_clojure_plan_fn__716000018_A) Invoke_O_O__O(self, p1__716000014_SHARP___1 any) any { var root_143 any = A_arbace_repr_clojure_A_const_37.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_143, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_145 lang.IFn; if linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any = t.F_name; var arg_147 any = p1__716000014_SHARP___1; if linked_144 == nil { return ifn_145.Invoke_O_O__O(arg_146, arg_147) } else { return linked_144.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_143, arg_146, arg_147) } }





func A_arbace_repr_clojure_print_plan_A_New() *A_arbace_repr_clojure_print_plan_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_print_plan_A{}; t.Ctor(); return t }
//line :97:1
func (t *A_arbace_repr_clojure_print_plan_A) Ctor() {}
//line :97:1
func (t *A_arbace_repr_clojure_print_plan_A) Invoke_O_O_O_O__O(self, name__0, siblings__1, p__716000022__2 any) any { var map__716000023__4 any = p__716000022__2; var map__716000023__5 any; if lang.ISeq_InstanceOf(map__716000023__4) { var tmp1 any; var root_155 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = map__716000023__4; if linked_156 == nil { tmp1 = ifn_157.Invoke_O__O(arg_158) } else { tmp1 = linked_156.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_155, arg_158) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_159 any = A_arbace_repr_clojure_A_const_15.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = map__716000023__4; if linked_160 == nil { tmp2 = ifn_161.Invoke_O__O(arg_162) } else { tmp2 = linked_160.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_159, arg_162) }; map__716000023__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_163 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_165 lang.IFn; if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = map__716000023__4; if linked_164 == nil { tmp3 = ifn_165.Invoke_O__O(arg_166) } else { tmp3 = linked_164.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_163, arg_166) }; if jrt.J2g_Truth(tmp3) { var root_167 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_167, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_169 lang.IFn; if linked_168 == nil { ifn_169 = lang.IFn_Cast(root_167) } else { ifn_169 = nil }; var arg_170 any = map__716000023__4; if linked_168 == nil { map__716000023__5 = ifn_169.Invoke_O__O(arg_170) } else { map__716000023__5 = linked_168.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_167, arg_170) } } else { map__716000023__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__716000023__5 = map__716000023__4 }; var text__6 any = lang.RT_Get_O_O__O_NoInit(map__716000023__5, A_arbace_repr_clojure_A_const_19); var e__7 any; var root_171 any = A_arbace_repr_clojure_A_const_21.GetRawRoot__O(); var linked_172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_171, A_arbace_repr_clojure_ext_A_fn_class); var ifn_173 lang.IFn; if









	linked_172 == nil { ifn_173 = lang.IFn_Cast(root_171) } else { ifn_173 = nil }; var arg_174 any = name__0; if linked_172 == nil { e__7 = ifn_173.Invoke_O__O(arg_174) } else { e__7 = linked_172.(*A_arbace_repr_clojure_ext_A).Invoke_O_O__O(root_171, arg_174) }; var b__8 any; var root_175 any = /*line :97:1*/A_arbace_repr_clojure_A_const_32.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_175, A_arbace_repr_clojure_base_A_fn_class); var ifn_177 lang.IFn; if









	linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any = name__0; if linked_176 == nil { b__8 = ifn_177.Invoke_O__O(arg_178) } else { b__8 = linked_176.(*A_arbace_repr_clojure_base_A).Invoke_O_O__O(root_175, arg_178) }; var tmp4 any; var root_179 any =
	A_arbace_repr_clojure_A_const_22.GetRawRoot__O(); var linked_180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_179, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_181 lang.IFn; if
	linked_180 == nil { ifn_181 = lang.IFn_Cast(root_179) } else { ifn_181 = nil }; var arg_182 any = A_arbace_repr_clojure_A_const_23.GetRawRoot__O(); var arg_183 any = name__0; if linked_180 == nil { tmp4 = ifn_181.Invoke_O_O__O(arg_182, arg_183) } else { tmp4 = linked_180.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_179, arg_182, arg_183) }; if /*line :108:1*/ jrt.J2g_Truth(tmp4) { var tmp5 any = A_arbace_repr_clojure_A_const_24; var tmp6 *lang.Keyword
		if lang.Util_Equiv_O_O__Z_NoInit(e__7, Lit_47) { tmp6 = A_arbace_repr_clojure_A_const_25 } else { tmp6 = A_arbace_repr_clojure_A_const_26 }
//line :108:1
		return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6.Ref(), A_arbace_repr_clojure_A_const_27, jrt.Boolean_FALSE.Ref(), A_arbace_repr_clojure_A_const_28, name__0)) } else { if lang.Util_Equiv_O_O__Z_NoInit(e__7, Lit_51) {


			if lang.Util_Equiv_O_O__Z_NoInit(Lit_48, b__8) {
				var tmp7 any; var root_184 any = A_arbace_repr_clojure_A_const_41.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_186 lang.IFn; if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any; var root_188 any = A_arbace_repr_clojure_A_const_22.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any = siblings__1; var arg_192 any = Lit_50; if linked_189 == nil { arg_187 = ifn_190.Invoke_O_O__O(arg_191, arg_192) } else { arg_187 = linked_189.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_188, arg_191, arg_192) }; if linked_185 == nil { tmp7 = ifn_186.Invoke_O__O(arg_187) } else { tmp7 = linked_185.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_184, arg_187) }; if jrt.J2g_Truth(tmp7) { return A_arbace_repr_clojure_A_const_42 } else { var tmp8 any; var root_193 any = A_arbace_repr_clojure_A_const_41.GetRawRoot__O(); var linked_194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_193, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_195 lang.IFn

					if linked_194 == nil { ifn_195 = lang.IFn_Cast(root_193) } else { ifn_195 = nil }; var arg_196 any; var root_197 any = A_arbace_repr_clojure_A_const_22.GetRawRoot__O(); var linked_198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_197, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_199 lang.IFn; if linked_198 == nil { ifn_199 = lang.IFn_Cast(root_197) } else { ifn_199 = nil }; var arg_200 any = siblings__1; var arg_201 any = Lit_58; if linked_198 == nil { arg_196 = ifn_199.Invoke_O_O__O(arg_200, arg_201) } else { arg_196 = linked_198.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_197, arg_200, arg_201) }; if linked_194 == nil { tmp8 = ifn_195.Invoke_O__O(arg_196) } else { tmp8 = linked_194.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_193, arg_196) }
//line :112:1
					if jrt.J2g_Truth(tmp8) { return A_arbace_repr_clojure_A_const_43 } else { if A_arbace_repr_clojure_A_const_34 != nil { return A_arbace_repr_clojure_A_const_44 } else { return nil } } } } else {
//line :111:1
						var tmp9 any = A_arbace_repr_clojure_A_const_24; var tmp10 any = A_arbace_repr_clojure_A_const_26; var tmp11 any = A_arbace_repr_clojure_A_const_27; var tmp12 any = jrt.Boolean_TRUE.Ref(); var tmp13 any = A_arbace_repr_clojure_A_const_28; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, tmp11, tmp12, tmp13, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_53), jrt.RefArrayOf(jrt.Object_class, b__8, nil)).Ref())) } } else {
//line :108:1
							if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_A_const_45).Invoke_O__O(e__7)) {










								var tmp14 any; var and__1927000168__auto____9 any; var root_202 any = A_arbace_repr_clojure_A_const_22.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_204 lang.IFn; if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any = siblings__1; var arg_206 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_51), jrt.RefArrayOf(jrt.Object_class, b__8, nil)).Ref(); if linked_203 == nil { and__1927000168__auto____9 = ifn_204.Invoke_O_O__O(arg_205, arg_206) } else { and__1927000168__auto____9 = linked_203.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_202, arg_205, arg_206) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var root_207 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_208 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_207, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_209 lang.IFn; if linked_208 == nil { ifn_209 = lang.IFn_Cast(root_207) } else { ifn_209 = nil }; var arg_210 any = Lit_48; var arg_211 any = b__8; if linked_208 == nil { tmp14 = ifn_209.Invoke_O_O__O(arg_210, arg_211) } else { tmp14 = linked_208.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_207, arg_210, arg_211) } } else { tmp14 = and__1927000168__auto____9 }; if jrt.J2g_Truth(tmp14) { var tmp15 any = A_arbace_repr_clojure_A_const_33; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp15, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_59), jrt.RefArrayOf(jrt.Object_class, b__8, nil)).Ref())) } else { var tmp16 any = A_arbace_repr_clojure_A_const_24; var tmp17 any; var root_212 any = A_arbace_repr_clojure_A_const_30.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_214 lang.IFn

									if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any; var root_216 any = A_arbace_repr_clojure_A_const_12.GetRawRoot__O(); var linked_217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_216, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_218 lang.IFn; if linked_217 == nil { ifn_218 = lang.IFn_Cast(root_216) } else { ifn_218 = nil }; var arg_219 any = e__7; var arg_220 any = A_arbace_repr_clojure_A_const_31; if linked_217 == nil { arg_215 = ifn_218.Invoke_O_O__O(arg_219, arg_220) } else { arg_215 = linked_217.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_216, arg_219, arg_220) }; if linked_213 == nil { tmp17 = ifn_214.Invoke_O__O(arg_215) } else { tmp17 = linked_213.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_212, arg_215) }
//line :119:1
									return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp17, A_arbace_repr_clojure_A_const_27, jrt.Boolean_FALSE.Ref(), A_arbace_repr_clojure_A_const_28, name__0)) } } else {
//line :108:1
										if lang.Util_Equiv_O_O__Z_NoInit(e__7, Lit_55) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_24, A_arbace_repr_clojure_A_const_35, A_arbace_repr_clojure_A_const_27, jrt.Boolean_FALSE.Ref(), A_arbace_repr_clojure_A_const_28, name__0)) } else { var tmp18 any; var root_221 any = A_arbace_repr_clojure_A_const_36.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_223 lang.IFn














											if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any; var tmp19 any = A_arbace_repr_clojure_print_plan_fn__716000025_A_New_O(name__0); var tmp20 *jrt.Class; var fncls__231 *jrt.Class = A_arbace_repr_clojure_print_plan_fn__716000025_A_fn_class; if fncls__231 == nil { var fncls__231d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); A_arbace_repr_clojure_print_plan_fn__716000025_A_fn_class = fncls__231d; tmp20 = fncls__231d } else { tmp20 = fncls__231 }; arg_224 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil); var arg_225 any = text__6; if linked_222 == nil { tmp18 = ifn_223.Invoke_O_O__O(arg_224, arg_225) } else { tmp18 = linked_222.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_221, arg_224, arg_225) }
//line :108:1
											if jrt.J2g_Truth(tmp18) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_24, A_arbace_repr_clojure_A_const_19, A_arbace_repr_clojure_A_const_27, jrt.Boolean_FALSE.Ref(), A_arbace_repr_clojure_A_const_28, name__0)) } else { if lang.Util_Equiv_O_O__Z_NoInit(e__7, Lit_57) { return A_arbace_repr_clojure_A_const_47 } else { if A_arbace_repr_clojure_A_const_34 != nil { return A_arbace_repr_clojure_A_const_48 } else { return nil } } } } } } } }














func A_arbace_repr_clojure_print_plan_fn__716000025_A_New_O(p0 any) *A_arbace_repr_clojure_print_plan_fn__716000025_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_print_plan_fn__716000025_A{}; t.Ctor_O(p0); return t }
//line :123:1
func (t *A_arbace_repr_clojure_print_plan_fn__716000025_A) Ctor_O(c__name any) { t.F_name = c__name }
//line :123:1
func (t *A_arbace_repr_clojure_print_plan_fn__716000025_A) Invoke_O_O__O(self, p1__716000021_SHARP___1 any) any { var root_226 any = A_arbace_repr_clojure_A_const_37.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_226, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_228 lang.IFn; if linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var arg_229 any = t.F_name; var arg_230 any = p1__716000021_SHARP___1; if linked_227 == nil { return ifn_228.Invoke_O_O__O(arg_229, arg_230) } else { return linked_227.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_226, arg_229, arg_230) } }



func A_arbace_repr_clojure_print_refine_A_New() *A_arbace_repr_clojure_print_refine_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_print_refine_A{}; t.Ctor(); return t }
//line :127:1
func (t *A_arbace_repr_clojure_print_refine_A) Ctor() {}
//line :127:1
func (t *A_arbace_repr_clojure_print_refine_A) Invoke_O_O_O_O_O__O(self, p__0, name__1, siblings__2, s__3 any) any {




	var tmp1 any; var and__1927000168__auto____5 any = A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__0); if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 bool; var tmp2 any; var root_232 any = A_arbace_repr_clojure_A_const_21.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, A_arbace_repr_clojure_ext_A_fn_class); var ifn_234 lang.IFn; if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = name__1; if linked_233 == nil { tmp2 = ifn_234.Invoke_O__O(arg_235) } else { tmp2 = linked_233.(*A_arbace_repr_clojure_ext_A).Invoke_O_O__O(root_232, arg_235) }; and__1927000168__auto____6 = lang.Util_Equiv_O_O__Z_NoInit(Lit_51, tmp2); if and__1927000168__auto____6 { var root_236 any = A_arbace_repr_clojure_A_const_49.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_236, aot_arbace_repr_clojure_rules.A_arbace_repr_clojure_rules_full_QMARK__A_fn_class); var ifn_238 lang.IFn; if linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any = s__3; if linked_237 == nil { tmp1 = ifn_238.Invoke_O__O(arg_239) } else { tmp1 = linked_237.(*aot_arbace_repr_clojure_rules.A_arbace_repr_clojure_rules_full_QMARK__A).Invoke_O_O__O(root_236, arg_239) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() } } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { var out__5 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_47); var tmp4 any; var root_240 any = A_arbace_repr_clojure_A_const_32.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_240, A_arbace_repr_clojure_base_A_fn_class); var ifn_242 lang.IFn
		if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any = name__1; if linked_241 == nil { tmp4 = ifn_242.Invoke_O__O(arg_243) } else { tmp4 = linked_241.(*A_arbace_repr_clojure_base_A).Invoke_O_O__O(root_240, arg_243) }; out__5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, tmp4, nil)).Ref()
		var tmp5 any; var root_244 any = A_arbace_repr_clojure_A_const_22.GetRawRoot__O(); var linked_245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_244, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_246 lang.IFn; if linked_245 == nil { ifn_246 = lang.IFn_Cast(root_244) } else { ifn_246 = nil }; var arg_247 any = siblings__2; var arg_248 any = out__5; if linked_245 == nil { tmp5 = ifn_246.Invoke_O_O__O(arg_247, arg_248) } else { tmp5 = linked_245.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_244, arg_247, arg_248) }; if jrt.J2g_Truth(tmp5) { var tmp6 any = A_arbace_repr_clojure_A_const_33; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_61), jrt.RefArrayOf(jrt.Object_class, out__5, nil)).Ref())) } else {

			return lang.IFn_Cast(A_arbace_repr_clojure_A_const_40.GetRawRoot__O()).Invoke_O_O_O_O_O__O(p__0, A_arbace_repr_clojure_A_const_24, A_arbace_repr_clojure_A_const_25, A_arbace_repr_clojure_A_const_28, out__5) } } else {
//line :132:1
				return p__0
			}
}




func A_arbace_repr_clojure_translate_text_A_New() *A_arbace_repr_clojure_translate_text_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_translate_text_A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_repr_clojure_translate_text_A) Ctor() {}
//line :139:1
func (t *A_arbace_repr_clojure_translate_text_A) Invoke_O_O_O_O_O__O(self, s__0, p__1, path__2, skip__3 any) any {


	var root_257 any = A_arbace_repr_clojure_A_const_50.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, aot_arbace_repr_clojure_rules.A_arbace_repr_clojure_rules_translate_A_fn_class); var ifn_259 lang.IFn; if linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any = s__0; var tmp1 any = A_arbace_repr_clojure_A_const_24; var tmp2 any = A_arbace_repr_clojure_A_const_24.Invoke_O__O(p__1); var tmp3 any = A_arbace_repr_clojure_A_const_27; var tmp4 any = A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__1); var tmp5 any = A_arbace_repr_clojure_A_const_20; var arg_261 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp4, tmp5, A_arbace_repr_clojure_A_const_20.Invoke_O__O(p__1), A_arbace_repr_clojure_A_const_51, A_arbace_repr_clojure_A_const_52, A_arbace_repr_clojure_A_const_53, path__2)); var arg_262 any = skip__3; if linked_258 == nil { return ifn_259.Invoke_O_O_O__O(arg_260, arg_261, arg_262) } else { return linked_258.(*aot_arbace_repr_clojure_rules.A_arbace_repr_clojure_rules_translate_A).Invoke_O_O_O_O__O(root_257, arg_260, arg_261, arg_262)
	} }
func A_arbace_repr_clojure_print_text_A_New() *A_arbace_repr_clojure_print_text_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_print_text_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_repr_clojure_print_text_A) Ctor() {}
//line :144:1
func (t *A_arbace_repr_clojure_print_text_A) Invoke_O_O_O_O_O__O(self, s__0, p__1, path__2, skip__3 any) any {


	var root_263 any = A_arbace_repr_clojure_A_const_54.GetRawRoot__O(); var linked_264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_263, aot_arbace_repr_clojure_rules.A_arbace_repr_clojure_rules_print_text_A_fn_class); var ifn_265 lang.IFn; if linked_264 == nil { ifn_265 = lang.IFn_Cast(root_263) } else { ifn_265 = nil }; var arg_266 any = s__0; var tmp1 any = A_arbace_repr_clojure_A_const_24; var tmp2 any = A_arbace_repr_clojure_A_const_24.Invoke_O__O(p__1); var tmp3 any = A_arbace_repr_clojure_A_const_27; var arg_267 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__1), A_arbace_repr_clojure_A_const_51, A_arbace_repr_clojure_A_const_55, A_arbace_repr_clojure_A_const_53, path__2)); var arg_268 any = skip__3; if linked_264 == nil { return ifn_265.Invoke_O_O_O__O(arg_266, arg_267, arg_268) } else { return linked_264.(*aot_arbace_repr_clojure_rules.A_arbace_repr_clojure_rules_print_text_A).Invoke_O_O_O_O__O(root_263, arg_266, arg_267, arg_268)
	}
}
func A_arbace_repr_clojure_fn__716000031_A_New() *A_arbace_repr_clojure_fn__716000031_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_fn__716000031_A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_repr_clojure_fn__716000031_A) Ctor() {}
//line :150:1
func (t *A_arbace_repr_clojure_fn__716000031_A) Invoke_O_O_O_O_O__O(self, p__0, ___1, ___2, ___3 any) any { return p__0 }


func A_arbace_repr_clojure_files_A_New() *A_arbace_repr_clojure_files_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_files_A{}; t.Ctor(); return t }
//line :153:1
func (t *A_arbace_repr_clojure_files_A) Ctor() {}
//line :153:1
func (t *A_arbace_repr_clojure_files_A) Invoke_O_O__O(self, src__0 any) any {


	if jrt.NN(jrt.File_Cast(src__0)).IsDirectory__Z() { var root__2 any = jrt.NN(jrt.File_Cast(src__0)).ToPath__Path(); var root_269 any = A_arbace_repr_clojure_A_const_56.GetRawRoot__O(); var linked_270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_269, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_271 lang.IFn

		if linked_270 == nil { ifn_271 = lang.IFn_Cast(root_269) } else { ifn_271 = nil }; var arg_272 any = A_arbace_repr_clojure_A_const_57.GetRawRoot__O(); var arg_273 any; var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_repr_clojure_files_iter__716000033__716000037_A_New_O_O(root__2, src__0); var tmp2 *jrt.Class; var fncls__344 *jrt.Class = A_arbace_repr_clojure_files_iter__716000033__716000037_A_fn_class
		if fncls__344 == nil { var fncls__344d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_repr_clojure_files_iter__716000033__716000037_A_fn_class = fncls__344d; tmp2 = fncls__344d } else { tmp2 = fncls__344 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp4 any; var root_345 any = A_arbace_repr_clojure_A_const_68.GetRawRoot__O(); var linked_346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_345, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_347 lang.IFn; if linked_346 == nil { ifn_347 = lang.IFn_Cast(root_345) } else { ifn_347 = nil }; var arg_348 any = src__0; if linked_346 == nil { tmp4 = ifn_347.Invoke_O__O(arg_348) } else { tmp4 = linked_346.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_345, arg_348) }; arg_273 = tmp3.Invoke_O__O(tmp4)
//line :158:1
		if linked_270 == nil { return ifn_271.Invoke_O_O__O(arg_272, arg_273) } else { return linked_270.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_269, arg_272, arg_273) } } else {
//line :156:1
			var tmp5 any; var or__1927000174__auto____2 any = jrt.NN(jrt.NN(jrt.File_Cast(src__0)).GetAbsoluteFile__File()).GetParentFile__File().Ref()




			if jrt.J2g_Truth(or__1927000174__auto____2) { tmp5 = or__1927000174__auto____2 } else { tmp5 = jrt.File_New_String(Lit_12) }
//line :156:1
			return lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(tmp5, jrt.NN(jrt.File_Cast(src__0)).GetName__String().Ref()))
		}
}
func A_arbace_repr_clojure_files_iter__716000033__716000037_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_files_iter__716000033__716000037_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_files_iter__716000033__716000037_A{}; t.Ctor_O_O(p0, p1); return t }
//line :159:1
func (t *A_arbace_repr_clojure_files_iter__716000033__716000037_A) Ctor_O_O(c__root, c__src any) { t.F_root = c__root; t.F_src = c__src }
//line :159:1
func (t *A_arbace_repr_clojure_files_iter__716000033__716000037_A) Invoke_O_O__O(self, s__716000034__1 any) any { var tmp1 any = A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_A_New_O_O_O_O(t.F_root, t.F_src, self, s__716000034__1); var tmp2 *jrt.Class; var fncls__343 *jrt.Class = A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_A_fn_class; if fncls__343 == nil { var fncls__343d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_A_fn_class = fncls__343d; tmp2 = fncls__343d } else { tmp2 = fncls__343 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :159:1
func A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :159:1
func (t *A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_A) Ctor_O_O_O_O(c__root, c__src, c__iter__716000033, c__s__716000034 any) { t.F_root = c__root; t.F_src = c__src; t.F_iter__716000033 = c__iter__716000033; t.F_s__716000034 = c__s__716000034 }
//line :159:1
func (t *A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_A) Invoke_O__O(self any) any { { var s__716000034__1 any; var t_ any = t.F_s__716000034; t.F_s__716000034 = nil; s__716000034__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_274 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_274, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_276 lang.IFn; if linked_275 == nil { ifn_276 = lang.IFn_Cast(root_274) } else { ifn_276 = nil }; var arg_277 any = s__716000034__1; if linked_275 == nil { temp__1927000414__auto____2 = ifn_276.Invoke_O__O(arg_277) } else { temp__1927000414__auto____2 = linked_275.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_274, arg_277) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__716000034__3 any = temp__1927000414__auto____2; var tmp1 any; var root_278 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_278, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_280 lang.IFn; if linked_279 == nil { ifn_280 = lang.IFn_Cast(root_278) } else { ifn_280 = nil }; var arg_281 any = s__716000034__3; if linked_279 == nil { tmp1 = ifn_280.Invoke_O__O(arg_281) } else { tmp1 = linked_279.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_278, arg_281) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_282 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_282, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_284 lang.IFn; if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any = s__716000034__3; if linked_283 == nil { c__1927001037__auto____4 = ifn_284.Invoke_O__O(arg_285) } else { c__1927001037__auto____4 = linked_283.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_282, arg_285) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__716000036__6 any; var root_286 any = A_arbace_repr_clojure_A_const_60.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_286, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_288 lang.IFn; if linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_287 == nil { b__716000036__6 = ifn_288.Invoke_O__O(arg_289) } else { b__716000036__6 = linked_287.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_286, arg_289) }; var tmp2 any = A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_fn__716000039_A_New_O_O_O_I_O(t.F_root, t.F_src, b__716000036__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__299 *jrt.Class = A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_fn__716000039_A_fn_class; if fncls__299 == nil { var fncls__299d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_fn__716000039_A_fn_class = fncls__299d; tmp3 = fncls__299d } else { tmp3 = fncls__299 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_300 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_302 lang.IFn; if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any; var root_305 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_305, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_307 lang.IFn; if linked_306 == nil { ifn_307 = lang.IFn_Cast(root_305) } else { ifn_307 = nil }; var arg_308 any = b__716000036__6; if linked_306 == nil { arg_303 = ifn_307.Invoke_O__O(arg_308) } else { arg_303 = linked_306.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_305, arg_308) }; var arg_304 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__716000033); var tmp5 any; var root_309 any = A_arbace_repr_clojure_A_const_65.GetRawRoot__O(); var linked_310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_309, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_311 lang.IFn; if linked_310 == nil { ifn_311 = lang.IFn_Cast(root_309) } else { ifn_311 = nil }; var arg_312 any = s__716000034__3; if linked_310 == nil { tmp5 = ifn_311.Invoke_O__O(arg_312) } else { tmp5 = linked_310.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_309, arg_312) }; arg_304 = tmp4.Invoke_O__O(tmp5); if linked_301 == nil { return ifn_302.Invoke_O_O__O(arg_303, arg_304) } else { return linked_301.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_300, arg_303, arg_304) } } else { var root_313 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_313, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_315 lang.IFn; if linked_314 == nil { ifn_315 = lang.IFn_Cast(root_313) } else { ifn_315 = nil }; var arg_316 any; var root_318 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_318, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_320 lang.IFn; if linked_319 == nil { ifn_320 = lang.IFn_Cast(root_318) } else { ifn_320 = nil }; var arg_321 any = b__716000036__6; if linked_319 == nil { arg_316 = ifn_320.Invoke_O__O(arg_321) } else { arg_316 = linked_319.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_318, arg_321) }; var arg_317 any; if linked_314 == nil { return ifn_315.Invoke_O_O__O(arg_316, arg_317) } else { return linked_314.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_313, arg_316, arg_317) } } } else { var f__4 any; var root_322 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_322, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_324 lang.IFn; if linked_323 == nil { ifn_324 = lang.IFn_Cast(root_322) } else { ifn_324 = nil }; var arg_325 any = s__716000034__3; if linked_323 == nil { f__4 = ifn_324.Invoke_O__O(arg_325) } else { f__4 = linked_323.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_322, arg_325) }; if jrt.NN(jrt.File_Cast(f__4)).IsFile__Z() { var root_326 any = A_arbace_repr_clojure_A_const_66.GetRawRoot__O(); var linked_327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_326, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_328 lang.IFn; if linked_327 == nil { ifn_328 = lang.IFn_Cast(root_326) } else { ifn_328 = nil }; var arg_329 any; var tmp6 any = t.F_src; var tmp7 any; var root_331 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_332 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_331, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_333 lang.IFn
														if linked_332 == nil { ifn_333 = lang.IFn_Cast(root_331) } else { ifn_333 = nil }; var tmp8 jrt.Path = jrt.Path_Cast(t.F_root); var arg_334 any = tmp8.Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__4)).ToPath__Path()); if linked_332 == nil { tmp7 = ifn_333.Invoke_O__O(arg_334) } else { tmp7 = linked_332.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_331, arg_334) }
//line :159:1
	arg_329 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7); var arg_330 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__716000033); var tmp10 any; var root_335 any = A_arbace_repr_clojure_A_const_67.GetRawRoot__O(); var linked_336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_335, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_337 lang.IFn; if linked_336 == nil { ifn_337 = lang.IFn_Cast(root_335) } else { ifn_337 = nil }; var arg_338 any = s__716000034__3; if linked_336 == nil { tmp10 = ifn_337.Invoke_O__O(arg_338) } else { tmp10 = linked_336.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_335, arg_338) }; arg_330 = tmp9.Invoke_O__O(tmp10); if linked_327 == nil { return ifn_328.Invoke_O_O__O(arg_329, arg_330) } else { return linked_327.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_326, arg_329, arg_330) } } else { var tmp11 any; var root_339 any = A_arbace_repr_clojure_A_const_67.GetRawRoot__O(); var linked_340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_339, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_341 lang.IFn; if linked_340 == nil { ifn_341 = lang.IFn_Cast(root_339) } else { ifn_341 = nil }; var arg_342 any = s__716000034__3; if linked_340 == nil { tmp11 = ifn_341.Invoke_O__O(arg_342) } else { tmp11 = linked_340.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_339, arg_342) }; s__716000034__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :159:1
func A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_fn__716000039_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_fn__716000039_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_fn__716000039_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :159:1
func (t *A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_fn__716000039_A) Ctor_O_O_O_I_O(c__root, c__src, c__b__716000036 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_root = c__root; t.F_src = c__src; t.F_b__716000036 = c__b__716000036; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :159:1
func (t *A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_fn__716000039_A) Invoke_O__O(self any) any { { var i__716000035__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__716000035__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__716000035__1)); if jrt.NN(jrt.File_Cast(f__2)).IsFile__Z() { var root_290 any = A_arbace_repr_clojure_A_const_61.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_290, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_292 lang.IFn; if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any = t.F_b__716000036; var arg_294 any; var tmp2 any = t.F_src; var tmp3 any; var root_295 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_295, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_297 lang.IFn
																if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var tmp4 jrt.Path = jrt.Path_Cast(t.F_root); var arg_298 any = tmp4.Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__2)).ToPath__Path()); if linked_296 == nil { tmp3 = ifn_297.Invoke_O__O(arg_298) } else { tmp3 = linked_296.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_295, arg_298) }
//line :159:1
	arg_294 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3); if linked_291 == nil { ifn_292.Invoke_O_O__O(arg_293, arg_294) } else { linked_291.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_290, arg_293, arg_294) }; i__716000035__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__716000035__1); continue L1 } else { i__716000035__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__716000035__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_repr_clojure_run_A_New() *A_arbace_repr_clojure_run_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_A{}; t.Ctor(); return t }
//line :163:1
func (t *A_arbace_repr_clojure_run_A) Ctor() {}
//line :163:1
func (t *A_arbace_repr_clojure_run_A) Invoke_O_O_O_O_O__O(self, verb__0, sources__1, out__2, opts__3 any) any { var skip__5 any = A_arbace_repr_clojure_A_const_33.Invoke_O_O__O(opts__3, lang.PersistentHashSet_EMPTY.Ref()); var map__716000044__6 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_69.GetRawRoot__O()).Invoke_O__O(verb__0); var map__716000044__7 any; if







	lang.ISeq_InstanceOf(map__716000044__6) { var tmp1 any; var root_349 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_349, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_351 lang.IFn; if linked_350 == nil { ifn_351 = lang.IFn_Cast(root_349) } else { ifn_351 = nil }; var arg_352 any = map__716000044__6; if linked_350 == nil { tmp1 = ifn_351.Invoke_O__O(arg_352) } else { tmp1 = linked_350.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_349, arg_352) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_353 any = A_arbace_repr_clojure_A_const_15.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_353, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_355 lang.IFn; if linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any = map__716000044__6; if linked_354 == nil { tmp2 = ifn_355.Invoke_O__O(arg_356) } else { tmp2 = linked_354.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_353, arg_356) }; map__716000044__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_357 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_357, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_359 lang.IFn; if linked_358 == nil { ifn_359 = lang.IFn_Cast(root_357) } else { ifn_359 = nil }; var arg_360 any = map__716000044__6; if linked_358 == nil { tmp3 = ifn_359.Invoke_O__O(arg_360) } else { tmp3 = linked_358.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_357, arg_360) }; if jrt.J2g_Truth(tmp3) { var root_361 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_361, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_363 lang.IFn; if linked_362 == nil { ifn_363 = lang.IFn_Cast(root_361) } else { ifn_363 = nil }; var arg_364 any = map__716000044__6; if linked_362 == nil { map__716000044__7 = ifn_363.Invoke_O__O(arg_364) } else { map__716000044__7 = linked_362.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_361, arg_364) } } else { map__716000044__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__716000044__7 = map__716000044__6 }; var plan__8 any = /*line :163:1*/lang.RT_Get_O_O__O_NoInit(map__716000044__7, A_arbace_repr_clojure_A_const_70); var translate_text__9 any = lang.RT_Get_O_O__O_NoInit(map__716000044__7, A_arbace_repr_clojure_A_const_19); var refine__10 any = lang.RT_Get_O_O__O_NoInit(map__716000044__7, A_arbace_repr_clojure_A_const_71); var listing__11 any; var root_365 any = A_arbace_repr_clojure_A_const_72.GetRawRoot__O(); var linked_366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_365, aot_arbace_core.A_arbace_core_memoize_A_fn_class); var ifn_367 lang.IFn; if









	linked_366 == nil { ifn_367 = lang.IFn_Cast(root_365) } else { ifn_367 = nil }; var arg_368 any; var tmp4 any = A_arbace_repr_clojure_run_fn__716000046_A_New(); var tmp5 *jrt.Class; var fncls__373 *jrt.Class = A_arbace_repr_clojure_run_fn__716000046_A_fn_class; if fncls__373 == nil { var fncls__373d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_90, false); A_arbace_repr_clojure_run_fn__716000046_A_fn_class = fncls__373d; tmp5 = fncls__373d } else { tmp5 = fncls__373 }; arg_368 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); if linked_366 == nil { listing__11 = ifn_367.Invoke_O__O(arg_368) } else { listing__11 = linked_366.(*aot_arbace_core.A_arbace_core_memoize_A).Invoke_O_O__O(root_365, arg_368) }; var stats__12 any; var root_374 any = /*line :163:1*/A_arbace_repr_clojure_A_const_74.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_374, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_376 lang.IFn; if










	linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any = A_arbace_repr_clojure_A_const_75; if linked_375 == nil { stats__12 = ifn_376.Invoke_O__O(arg_377) } else { stats__12 = linked_375.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_374, arg_377) }; var seq_716000048__13 any; var root_382 any = /*line :163:1*/A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_382, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_384 lang.IFn; if











	linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; var arg_385 any = sources__1; if linked_383 == nil { seq_716000048__13 = ifn_384.Invoke_O__O(arg_385) } else { seq_716000048__13 = linked_383.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_382, arg_385) }; var chunk_716000049__14 any; var count_716000050__15 int64 = 0; var i_716000051__16 int64 = 0; L1:
//line :163:1
	for {











		if lang.Numbers_Lt_J_J__Z_NoInit(i_716000051__16, count_716000050__15) { var src__17 any = lang.Indexed_Cast(chunk_716000049__14).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_716000051__16)); var srcf__18 any; var root_402 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_402, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_404 lang.IFn
			if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any = src__17; if linked_403 == nil { srcf__18 = ifn_404.Invoke_O__O(arg_405) } else { srcf__18 = linked_403.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_402, arg_405) }
//line :175:1
			var seq_716000056__19 any; var root_406 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_406, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_408 lang.IFn; if linked_407 == nil { ifn_408 = lang.IFn_Cast(root_406) } else { ifn_408 = nil }; var arg_409 any; var root_410 any = A_arbace_repr_clojure_A_const_77.GetRawRoot__O(); var linked_411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_410, A_arbace_repr_clojure_files_A_fn_class); var ifn_412 lang.IFn

			if linked_411 == nil { ifn_412 = lang.IFn_Cast(root_410) } else { ifn_412 = nil }; var arg_413 any = srcf__18; if linked_411 == nil { arg_409 = ifn_412.Invoke_O__O(arg_413) } else { arg_409 = linked_411.(*A_arbace_repr_clojure_files_A).Invoke_O_O__O(root_410, arg_413) }
//line :175:1
			if linked_407 == nil { seq_716000056__19 = ifn_408.Invoke_O__O(arg_409) } else { seq_716000056__19 = linked_407.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_406, arg_409) }; var chunk_716000057__20 any; var count_716000058__21 int64 = 0; var i_716000059__22 int64 = 0; L2: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_716000059__22, count_716000058__21) { var vec__716000060__23 any = lang.Indexed_Cast(chunk_716000057__20).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_716000059__22)); var dir__24 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000060__23, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__25 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000060__23, lang.RT_IntCast_J__I_NoInit(1), nil); var f__26 any; var root_430 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_430, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_432 lang.IFn


				if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any = dir__24; var arg_434 any = rel__25; if linked_431 == nil { f__26 = ifn_432.Invoke_O_O__O(arg_433, arg_434) } else { f__26 = linked_431.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_430, arg_433, arg_434) }
//line :175:1
				var parent__27 any = jrt.NN(jrt.File_Cast(f__26)).GetParentFile__File().Ref(); var siblings__28 any = lang.IFn_Cast(listing__11).Invoke_O__O(parent__27); var p0__29 any = lang.IFn_Cast(plan__8).Invoke_O_O_O__O(jrt.NN(jrt.File_Cast(f__26)).GetName__String().Ref(), siblings__28, opts__3); var s__30 any






				if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_24.Invoke_O__O(p0__29)) { s__30 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_78.GetRawRoot__O()).Invoke_O__O(f__26) } else { s__30 = nil }
//line :175:1
				var p__31 any







				if jrt.J2g_Truth(s__30) { p__31 = lang.IFn_Cast(refine__10).Invoke_O_O_O_O__O(p0__29, jrt.NN(jrt.File_Cast(f__26)).GetName__String().Ref(), siblings__28, s__30) } else { p__31 = p0__29 }
//line :175:1
				var rel_out__32 any; var d__32 any; var tmp6 any; var root_439 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_440 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_439, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_441 lang.IFn








				if linked_440 == nil { ifn_441 = lang.IFn_Cast(root_439) } else { ifn_441 = nil }; var arg_442 any = rel__25; if linked_440 == nil { tmp6 = ifn_441.Invoke_O__O(arg_442) } else { tmp6 = linked_440.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_439, arg_442) }; d__32 = jrt.NN(jrt.File_Cast(tmp6)).GetParent__String().Ref(); if jrt.J2g_Truth(d__32) { rel_out__32 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_29, nil), jrt.RefArrayOf(jrt.Object_class, d__32, nil, A_arbace_repr_clojure_A_const_28.Invoke_O__O(p__31))).Ref() } else { rel_out__32 = A_arbace_repr_clojure_A_const_28.Invoke_O__O(p__31) }
				if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_33.Invoke_O__O(p__31)) {

					var root_520 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_521 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_520, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_522 lang.IFn; if linked_521 == nil { ifn_522 = lang.IFn_Cast(root_520) } else { ifn_522 = nil }; var arg_523 any = stats__12; var arg_524 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_525 any = A_arbace_repr_clojure_A_const_93; var arg_526 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_521 == nil { ifn_522.Invoke_O_O_O_O__O(arg_523, arg_524, arg_525, arg_526) } else { linked_521.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_520, arg_523, arg_524, arg_525, arg_526) }
					var root_527 any = A_arbace_repr_clojure_A_const_88.GetRawRoot__O(); var linked_528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_527, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_529 lang.IFn; if linked_528 == nil { ifn_529 = lang.IFn_Cast(root_527) } else { ifn_529 = nil }; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_89.GetRawRoot__O()); var tmp8 any = A_arbace_repr_clojure_A_const_90; var arg_530 any = tmp7.Invoke_O_O__O(tmp8, A_arbace_repr_clojure_A_const_91.Get__O()); if linked_528 == nil { ifn_529.Invoke_O__O(arg_530) } else { linked_528.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_527, arg_530) }; var tmp9 any = A_arbace_repr_clojure_run_fn__716000063_A_New_O_O(f__26, p__31); var tmp10 *jrt.Class; var fncls__457 *jrt.Class = A_arbace_repr_clojure_run_fn__716000063_A_fn_class; if fncls__457 == nil { var fncls__457d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_91, false); A_arbace_repr_clojure_run_fn__716000063_A_fn_class = fncls__457d; tmp10 = fncls__457d } else { tmp10 = fncls__457 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil).Invoke__O() } else {
//line :185:1
						if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_81.Invoke_O__O(p__31)) {




							if jrt.J2g_Truth(out__2) { var t__33 any; var root_536 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_537 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_536, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_538 lang.IFn
								if linked_537 == nil { ifn_538 = lang.IFn_Cast(root_536) } else { ifn_538 = nil }; var arg_539 any = out__2; var arg_540 any = rel__25; if linked_537 == nil { t__33 = ifn_538.Invoke_O_O__O(arg_539, arg_540) } else { t__33 = linked_537.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_536, arg_539, arg_540) }
								lang.IFn_Cast(A_arbace_repr_clojure_A_const_95.GetRawRoot__O()).Invoke_O__O(t__33)
								lang.IFn_Cast(A_arbace_repr_clojure_A_const_94.GetRawRoot__O()).Invoke_O_O__O(f__26, t__33) }
							var root_458 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = stats__12; var arg_462 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_463 any = A_arbace_repr_clojure_A_const_84; var arg_464 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_459 == nil { ifn_460.Invoke_O_O_O_O__O(arg_461, arg_462, arg_463, arg_464) } else { linked_459.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_458, arg_461, arg_462, arg_463, arg_464) } } else {
//line :185:1
								if A_arbace_repr_clojure_A_const_34 != nil { var r__33 any; var tmp11 any = A_arbace_repr_clojure_run_fn__716000065_A_New_O_O_O_O_O_O(f__26, p__31, stats__12, s__30, translate_text__9, skip__5); var tmp12 *jrt.Class
									var fncls__504 /*line :185:1*/*jrt.Class = A_arbace_repr_clojure_run_fn__716000065_A_fn_class










									if fncls__504 == nil { var fncls__504d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_92, false); A_arbace_repr_clojure_run_fn__716000065_A_fn_class = fncls__504d; tmp12 = fncls__504d } else { tmp12 = fncls__504 }; r__33 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil).Invoke__O()




									if jrt.J2g_Truth(r__33) {
										var root_550 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_551 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_550, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_552 lang.IFn; if linked_551 == nil { ifn_552 = lang.IFn_Cast(root_550) } else { ifn_552 = nil }; var arg_553 any = stats__12; var arg_554 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_555 any; if lang.Util_Equiv_O_O__Z_NoInit(s__30, r__33) { arg_555 = A_arbace_repr_clojure_A_const_96 } else { arg_555 = A_arbace_repr_clojure_A_const_97 }; var arg_556 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_551 == nil { ifn_552.Invoke_O_O_O_O__O(arg_553, arg_554, arg_555, arg_556) } else { linked_551.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_550, arg_553, arg_554, arg_555, arg_556) }
										if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__31)) { var root_557 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_557, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_559 lang.IFn; if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any = stats__12; var arg_561 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_562 any = A_arbace_repr_clojure_A_const_27; var arg_563 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_558 == nil { ifn_559.Invoke_O_O_O_O__O(arg_560, arg_561, arg_562, arg_563) } else { linked_558.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_557, arg_560, arg_561, arg_562, arg_563) } }
										if jrt.J2g_Truth(out__2) { var t__34 any; var root_505 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_506 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_505, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_507 lang.IFn
											if linked_506 == nil { ifn_507 = lang.IFn_Cast(root_505) } else { ifn_507 = nil }; var arg_508 any = out__2; var arg_509 any = rel_out__32; if linked_506 == nil { t__34 = ifn_507.Invoke_O_O__O(arg_508, arg_509) } else { t__34 = linked_506.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_505, arg_508, arg_509) }
											lang.IFn_Cast(A_arbace_repr_clojure_A_const_95.GetRawRoot__O()).Invoke_O__O(t__34)
											lang.IFn_Cast(A_arbace_repr_clojure_A_const_92.GetRawRoot__O()).Invoke_O_O__O(t__34, r__33) } else {
//line :204:1
												var moved__34 any; var root_515 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_516 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_515, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_517 lang.IFn



												if linked_516 == nil { ifn_517 = lang.IFn_Cast(root_515) } else { ifn_517 = nil }; var arg_518 any = jrt.NN(jrt.File_Cast(f__26)).GetName__String().Ref(); var arg_519 any = A_arbace_repr_clojure_A_const_28.Invoke_O__O(p__31); if linked_516 == nil { moved__34 = ifn_517.Invoke_O_O__O(arg_518, arg_519) } else { moved__34 = linked_516.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_515, arg_518, arg_519) }
												var tmp13 any; var or__1927000174__auto____35 any; var root_568 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_569 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_568, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_570 lang.IFn; if linked_569 == nil { ifn_570 = lang.IFn_Cast(root_568) } else { ifn_570 = nil }; var arg_571 any = s__30; var arg_572 any = r__33; if linked_569 == nil { or__1927000174__auto____35 = ifn_570.Invoke_O_O__O(arg_571, arg_572) } else { or__1927000174__auto____35 = linked_569.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_568, arg_571, arg_572) }; if jrt.J2g_Truth(or__1927000174__auto____35) { tmp13 = or__1927000174__auto____35 } else { tmp13 = moved__34 }; if jrt.J2g_Truth(tmp13) {
													var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_92.GetRawRoot__O()); var tmp15 any; var root_578 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_579 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_578, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_580 lang.IFn; if linked_579 == nil { ifn_580 = lang.IFn_Cast(root_578) } else { ifn_580 = nil }; var arg_581 any = parent__27; var arg_582 any = A_arbace_repr_clojure_A_const_28.Invoke_O__O(p__31); if linked_579 == nil { tmp15 = ifn_580.Invoke_O_O__O(arg_581, arg_582) } else { tmp15 = linked_579.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_578, arg_581, arg_582) }; tmp14.Invoke_O_O__O(tmp15, r__33) }
												if jrt.J2g_Truth(moved__34) { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(f__26)).Delete__Z()) } } } } } }
//line :175:1
				seq_716000056__19, chunk_716000057__20, count_716000058__21, i_716000059__22 = seq_716000056__19, chunk_716000057__20, count_716000058__21, lang.Numbers_Unchecked_inc_J__J_NoInit(i_716000059__22); continue L2 } else { var temp__1927000414__auto____23 any; var root_414 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_414, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_416 lang.IFn; if linked_415 == nil { ifn_416 = lang.IFn_Cast(root_414) } else { ifn_416 = nil }; var arg_417 any = seq_716000056__19; if linked_415 == nil { temp__1927000414__auto____23 = ifn_416.Invoke_O__O(arg_417) } else { temp__1927000414__auto____23 = linked_415.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_414, arg_417) }; if jrt.J2g_Truth(temp__1927000414__auto____23) { var seq_716000056__24 any = temp__1927000414__auto____23; var tmp16 any; var root_418 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_418, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_420 lang.IFn; if linked_419 == nil { ifn_420 = lang.IFn_Cast(root_418) } else { ifn_420 = nil }; var arg_421 any = seq_716000056__24; if linked_419 == nil { tmp16 = ifn_420.Invoke_O__O(arg_421) } else { tmp16 = linked_419.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_418, arg_421) }; if jrt.J2g_Truth(tmp16) { var c__1927000678__auto____25 any; var root_422 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_422, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_424 lang.IFn; if linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any = seq_716000056__24; if linked_423 == nil { c__1927000678__auto____25 = ifn_424.Invoke_O__O(arg_425) } else { c__1927000678__auto____25 = linked_423.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_422, arg_425) }; var tmp17 any; var root_583 any = A_arbace_repr_clojure_A_const_65.GetRawRoot__O(); var linked_584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_583, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_585 lang.IFn; if linked_584 == nil { ifn_585 = lang.IFn_Cast(root_583) } else { ifn_585 = nil }; var arg_586 any = seq_716000056__24; if linked_584 == nil { tmp17 = ifn_585.Invoke_O__O(arg_586) } else { tmp17 = linked_584.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_583, arg_586) }; seq_716000056__19, chunk_716000057__20, count_716000058__21, i_716000059__22 = tmp17, c__1927000678__auto____25, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____25))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var vec__716000069__25 any; var root_426 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_426, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_428 lang.IFn; if linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any = seq_716000056__24; if linked_427 == nil { vec__716000069__25 = ifn_428.Invoke_O__O(arg_429) } else { vec__716000069__25 = linked_427.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_426, arg_429) }; var dir__26 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000069__25, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__27 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000069__25, lang.RT_IntCast_J__I_NoInit(1), nil); var f__28 any; var root_587 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_588 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_587, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_589 lang.IFn


					if linked_588 == nil { ifn_589 = lang.IFn_Cast(root_587) } else { ifn_589 = nil }; var arg_590 any = dir__26; var arg_591 any = rel__27; if linked_588 == nil { f__28 = ifn_589.Invoke_O_O__O(arg_590, arg_591) } else { f__28 = linked_588.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_587, arg_590, arg_591) }
//line :175:1
					var parent__29 any = jrt.NN(jrt.File_Cast(f__28)).GetParentFile__File().Ref(); var siblings__30 any = lang.IFn_Cast(listing__11).Invoke_O__O(parent__29); var p0__31 any = lang.IFn_Cast(plan__8).Invoke_O_O_O__O(jrt.NN(jrt.File_Cast(f__28)).GetName__String().Ref(), siblings__30, opts__3); var s__32 any






					if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_24.Invoke_O__O(p0__31)) { s__32 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_78.GetRawRoot__O()).Invoke_O__O(f__28) } else { s__32 = nil }
//line :175:1
					var p__33 any







					if jrt.J2g_Truth(s__32) { p__33 = lang.IFn_Cast(refine__10).Invoke_O_O_O_O__O(p0__31, jrt.NN(jrt.File_Cast(f__28)).GetName__String().Ref(), siblings__30, s__32) } else { p__33 = p0__31 }
//line :175:1
					var rel_out__34 any; var d__34 any; var tmp18 any; var root_596 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_597 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_596, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_598 lang.IFn








					if linked_597 == nil { ifn_598 = lang.IFn_Cast(root_596) } else { ifn_598 = nil }; var arg_599 any = rel__27; if linked_597 == nil { tmp18 = ifn_598.Invoke_O__O(arg_599) } else { tmp18 = linked_597.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_596, arg_599) }; d__34 = jrt.NN(jrt.File_Cast(tmp18)).GetParent__String().Ref(); if jrt.J2g_Truth(d__34) { rel_out__34 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_29, nil), jrt.RefArrayOf(jrt.Object_class, d__34, nil, A_arbace_repr_clojure_A_const_28.Invoke_O__O(p__33))).Ref() } else { rel_out__34 = A_arbace_repr_clojure_A_const_28.Invoke_O__O(p__33) }
					if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_33.Invoke_O__O(p__33)) {

						var root_677 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_678 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_677, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_679 lang.IFn; if linked_678 == nil { ifn_679 = lang.IFn_Cast(root_677) } else { ifn_679 = nil }; var arg_680 any = stats__12; var arg_681 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_682 any = A_arbace_repr_clojure_A_const_93; var arg_683 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_678 == nil { ifn_679.Invoke_O_O_O_O__O(arg_680, arg_681, arg_682, arg_683) } else { linked_678.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_677, arg_680, arg_681, arg_682, arg_683) }
						var root_684 any = A_arbace_repr_clojure_A_const_88.GetRawRoot__O(); var linked_685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_684, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_686 lang.IFn; if linked_685 == nil { ifn_686 = lang.IFn_Cast(root_684) } else { ifn_686 = nil }; var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_89.GetRawRoot__O()); var tmp20 any = A_arbace_repr_clojure_A_const_90; var arg_687 any = tmp19.Invoke_O_O__O(tmp20, A_arbace_repr_clojure_A_const_91.Get__O()); if linked_685 == nil { ifn_686.Invoke_O__O(arg_687) } else { linked_685.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_684, arg_687) }; var tmp21 any = A_arbace_repr_clojure_run_fn__716000072_A_New_O_O(f__28, p__33); var tmp22 *jrt.Class; var fncls__614 *jrt.Class = A_arbace_repr_clojure_run_fn__716000072_A_fn_class; if fncls__614 == nil { var fncls__614d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_93, false); A_arbace_repr_clojure_run_fn__716000072_A_fn_class = fncls__614d; tmp22 = fncls__614d } else { tmp22 = fncls__614 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil).Invoke__O() } else {
//line :185:1
							if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_81.Invoke_O__O(p__33)) {




								if jrt.J2g_Truth(out__2) { var t__35 any; var root_693 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_694 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_693, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_695 lang.IFn
									if linked_694 == nil { ifn_695 = lang.IFn_Cast(root_693) } else { ifn_695 = nil }; var arg_696 any = out__2; var arg_697 any = rel__27; if linked_694 == nil { t__35 = ifn_695.Invoke_O_O__O(arg_696, arg_697) } else { t__35 = linked_694.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_693, arg_696, arg_697) }
									lang.IFn_Cast(A_arbace_repr_clojure_A_const_95.GetRawRoot__O()).Invoke_O__O(t__35)
									lang.IFn_Cast(A_arbace_repr_clojure_A_const_94.GetRawRoot__O()).Invoke_O_O__O(f__28, t__35) }
								var root_615 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_615, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_617 lang.IFn; if linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any = stats__12; var arg_619 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_620 any = A_arbace_repr_clojure_A_const_84; var arg_621 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_616 == nil { ifn_617.Invoke_O_O_O_O__O(arg_618, arg_619, arg_620, arg_621) } else { linked_616.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_615, arg_618, arg_619, arg_620, arg_621) } } else {
//line :185:1
									if A_arbace_repr_clojure_A_const_34 != nil { var r__35 any; var tmp23 any = A_arbace_repr_clojure_run_fn__716000074_A_New_O_O_O_O_O_O(f__28, p__33, s__32, stats__12, translate_text__9, skip__5); var tmp24 *jrt.Class
										var fncls__661 /*line :185:1*/*jrt.Class = A_arbace_repr_clojure_run_fn__716000074_A_fn_class










										if fncls__661 == nil { var fncls__661d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_94, false); A_arbace_repr_clojure_run_fn__716000074_A_fn_class = fncls__661d; tmp24 = fncls__661d } else { tmp24 = fncls__661 }; r__35 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil).Invoke__O()




										if jrt.J2g_Truth(r__35) {
											var root_707 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_708 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_707, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_709 lang.IFn; if linked_708 == nil { ifn_709 = lang.IFn_Cast(root_707) } else { ifn_709 = nil }; var arg_710 any = stats__12; var arg_711 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_712 any; if lang.Util_Equiv_O_O__Z_NoInit(s__32, r__35) { arg_712 = A_arbace_repr_clojure_A_const_96 } else { arg_712 = A_arbace_repr_clojure_A_const_97 }; var arg_713 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_708 == nil { ifn_709.Invoke_O_O_O_O__O(arg_710, arg_711, arg_712, arg_713) } else { linked_708.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_707, arg_710, arg_711, arg_712, arg_713) }
											if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__33)) { var root_714 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_715 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_714, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_716 lang.IFn; if linked_715 == nil { ifn_716 = lang.IFn_Cast(root_714) } else { ifn_716 = nil }; var arg_717 any = stats__12; var arg_718 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_719 any = A_arbace_repr_clojure_A_const_27; var arg_720 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_715 == nil { ifn_716.Invoke_O_O_O_O__O(arg_717, arg_718, arg_719, arg_720) } else { linked_715.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_714, arg_717, arg_718, arg_719, arg_720) } }
											if jrt.J2g_Truth(out__2) { var t__36 any; var root_662 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_663 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_662, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_664 lang.IFn
												if linked_663 == nil { ifn_664 = lang.IFn_Cast(root_662) } else { ifn_664 = nil }; var arg_665 any = out__2; var arg_666 any = rel_out__34; if linked_663 == nil { t__36 = ifn_664.Invoke_O_O__O(arg_665, arg_666) } else { t__36 = linked_663.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_662, arg_665, arg_666) }
												lang.IFn_Cast(A_arbace_repr_clojure_A_const_95.GetRawRoot__O()).Invoke_O__O(t__36)
												lang.IFn_Cast(A_arbace_repr_clojure_A_const_92.GetRawRoot__O()).Invoke_O_O__O(t__36, r__35) } else {
//line :204:1
													var moved__36 any; var root_672 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_673 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_672, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_674 lang.IFn



													if linked_673 == nil { ifn_674 = lang.IFn_Cast(root_672) } else { ifn_674 = nil }; var arg_675 any = jrt.NN(jrt.File_Cast(f__28)).GetName__String().Ref(); var arg_676 any = A_arbace_repr_clojure_A_const_28.Invoke_O__O(p__33); if linked_673 == nil { moved__36 = ifn_674.Invoke_O_O__O(arg_675, arg_676) } else { moved__36 = linked_673.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_672, arg_675, arg_676) }
													var tmp25 any; var or__1927000174__auto____37 any; var root_725 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_726 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_725, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_727 lang.IFn; if linked_726 == nil { ifn_727 = lang.IFn_Cast(root_725) } else { ifn_727 = nil }; var arg_728 any = s__32; var arg_729 any = r__35; if linked_726 == nil { or__1927000174__auto____37 = ifn_727.Invoke_O_O__O(arg_728, arg_729) } else { or__1927000174__auto____37 = linked_726.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_725, arg_728, arg_729) }; if jrt.J2g_Truth(or__1927000174__auto____37) { tmp25 = or__1927000174__auto____37 } else { tmp25 = moved__36 }; if jrt.J2g_Truth(tmp25) {
														var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_92.GetRawRoot__O()); var tmp27 any; var root_735 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_736 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_735, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_737 lang.IFn; if linked_736 == nil { ifn_737 = lang.IFn_Cast(root_735) } else { ifn_737 = nil }; var arg_738 any = parent__29; var arg_739 any = A_arbace_repr_clojure_A_const_28.Invoke_O__O(p__33); if linked_736 == nil { tmp27 = ifn_737.Invoke_O_O__O(arg_738, arg_739) } else { tmp27 = linked_736.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_735, arg_738, arg_739) }; tmp26.Invoke_O_O__O(tmp27, r__35) }
													if jrt.J2g_Truth(moved__36) { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(f__28)).Delete__Z()) } } } } } }
//line :175:1
					var tmp28 any; var root_740 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_740, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_742 lang.IFn; if linked_741 == nil { ifn_742 = lang.IFn_Cast(root_740) } else { ifn_742 = nil }; var arg_743 any = seq_716000056__24; if linked_741 == nil { tmp28 = ifn_742.Invoke_O__O(arg_743) } else { tmp28 = linked_741.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_740, arg_743) }; seq_716000056__19, chunk_716000057__20, count_716000058__21, i_716000059__22 = tmp28, nil, 0, 0; continue L2 } } }; break L2 }; seq_716000048__13, chunk_716000049__14, count_716000050__15, i_716000051__16 = seq_716000048__13, chunk_716000049__14, count_716000050__15, lang.Numbers_Unchecked_inc_J__J_NoInit(i_716000051__16); continue L1 } else { var temp__1927000414__auto____17 any; var root_386 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_386, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_388 lang.IFn; if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any = seq_716000048__13; if linked_387 == nil { temp__1927000414__auto____17 = ifn_388.Invoke_O__O(arg_389) } else { temp__1927000414__auto____17 = linked_387.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_386, arg_389) }; if jrt.J2g_Truth(temp__1927000414__auto____17) { var seq_716000048__18 any = temp__1927000414__auto____17; var tmp29 any; var root_390 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_390, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_392 lang.IFn; if linked_391 == nil { ifn_392 = lang.IFn_Cast(root_390) } else { ifn_392 = nil }; var arg_393 any = seq_716000048__18; if linked_391 == nil { tmp29 = ifn_392.Invoke_O__O(arg_393) } else { tmp29 = linked_391.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_390, arg_393) }; if jrt.J2g_Truth(tmp29) { var c__1927000678__auto____19 any; var root_394 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_396 lang.IFn; if linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any = seq_716000048__18; if linked_395 == nil { c__1927000678__auto____19 = ifn_396.Invoke_O__O(arg_397) } else { c__1927000678__auto____19 = linked_395.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_394, arg_397) }; var tmp30 any; var root_744 any = A_arbace_repr_clojure_A_const_65.GetRawRoot__O(); var linked_745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_744, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_746 lang.IFn; if linked_745 == nil { ifn_746 = lang.IFn_Cast(root_744) } else { ifn_746 = nil }; var arg_747 any = seq_716000048__18; if linked_745 == nil { tmp30 = ifn_746.Invoke_O__O(arg_747) } else { tmp30 = linked_745.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_744, arg_747) }; seq_716000048__13, chunk_716000049__14, count_716000050__15, i_716000051__16 = tmp30, c__1927000678__auto____19, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____19))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var src__19 any; var root_398 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any = seq_716000048__18; if linked_399 == nil { src__19 = ifn_400.Invoke_O__O(arg_401) } else { src__19 = linked_399.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_398, arg_401) }; var srcf__20 any; var root_748 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_749 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_748, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_750 lang.IFn
						if linked_749 == nil { ifn_750 = lang.IFn_Cast(root_748) } else { ifn_750 = nil }; var arg_751 any = src__19; if linked_749 == nil { srcf__20 = ifn_750.Invoke_O__O(arg_751) } else { srcf__20 = linked_749.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_748, arg_751) }
//line :175:1
						var seq_716000052__21 any; var root_752 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_752, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_754 lang.IFn; if linked_753 == nil { ifn_754 = lang.IFn_Cast(root_752) } else { ifn_754 = nil }; var arg_755 any; var root_756 any = A_arbace_repr_clojure_A_const_77.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_756, A_arbace_repr_clojure_files_A_fn_class); var ifn_758 lang.IFn

						if linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any = srcf__20; if linked_757 == nil { arg_755 = ifn_758.Invoke_O__O(arg_759) } else { arg_755 = linked_757.(*A_arbace_repr_clojure_files_A).Invoke_O_O__O(root_756, arg_759) }
//line :175:1
						if linked_753 == nil { seq_716000052__21 = ifn_754.Invoke_O__O(arg_755) } else { seq_716000052__21 = linked_753.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_752, arg_755) }; var chunk_716000053__22 any; var count_716000054__23 int64 = 0; var i_716000055__24 int64 = 0; L3: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_716000055__24, count_716000054__23) { var vec__716000078__25 any = lang.Indexed_Cast(chunk_716000053__22).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_716000055__24)); var dir__26_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000078__25, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__27_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000078__25, lang.RT_IntCast_J__I_NoInit(1), nil); var f__28_2 any; var root_776 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_777 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_776, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_778 lang.IFn


							if linked_777 == nil { ifn_778 = lang.IFn_Cast(root_776) } else { ifn_778 = nil }; var arg_779 any = dir__26_2; var arg_780 any = rel__27_2; if linked_777 == nil { f__28_2 = ifn_778.Invoke_O_O__O(arg_779, arg_780) } else { f__28_2 = linked_777.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_776, arg_779, arg_780) }
//line :175:1
							var parent__29_2 any = jrt.NN(jrt.File_Cast(f__28_2)).GetParentFile__File().Ref(); var siblings__30_2 any = lang.IFn_Cast(listing__11).Invoke_O__O(parent__29_2); var p0__31_2 any = lang.IFn_Cast(plan__8).Invoke_O_O_O__O(jrt.NN(jrt.File_Cast(f__28_2)).GetName__String().Ref(), siblings__30_2, opts__3); var s__32_2 any






							if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_24.Invoke_O__O(p0__31_2)) { s__32_2 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_78.GetRawRoot__O()).Invoke_O__O(f__28_2) } else { s__32_2 = nil }
//line :175:1
							var p__33_2 any







							if jrt.J2g_Truth(s__32_2) { p__33_2 = lang.IFn_Cast(refine__10).Invoke_O_O_O_O__O(p0__31_2, jrt.NN(jrt.File_Cast(f__28_2)).GetName__String().Ref(), siblings__30_2, s__32_2) } else { p__33_2 = p0__31_2 }
//line :175:1
							var rel_out__34_2 any; var d__34_2 any; var tmp31 any; var root_785 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_786 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_785, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_787 lang.IFn








							if linked_786 == nil { ifn_787 = lang.IFn_Cast(root_785) } else { ifn_787 = nil }; var arg_788 any = rel__27_2; if linked_786 == nil { tmp31 = ifn_787.Invoke_O__O(arg_788) } else { tmp31 = linked_786.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_785, arg_788) }; d__34_2 = jrt.NN(jrt.File_Cast(tmp31)).GetParent__String().Ref(); if jrt.J2g_Truth(d__34_2) { rel_out__34_2 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_29, nil), jrt.RefArrayOf(jrt.Object_class, d__34_2, nil, A_arbace_repr_clojure_A_const_28.Invoke_O__O(p__33_2))).Ref() } else { rel_out__34_2 = A_arbace_repr_clojure_A_const_28.Invoke_O__O(p__33_2) }
							if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_33.Invoke_O__O(p__33_2)) {

								var root_866 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_867 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_866, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_868 lang.IFn; if linked_867 == nil { ifn_868 = lang.IFn_Cast(root_866) } else { ifn_868 = nil }; var arg_869 any = stats__12; var arg_870 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_871 any = A_arbace_repr_clojure_A_const_93; var arg_872 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_867 == nil { ifn_868.Invoke_O_O_O_O__O(arg_869, arg_870, arg_871, arg_872) } else { linked_867.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_866, arg_869, arg_870, arg_871, arg_872) }
								var root_873 any = A_arbace_repr_clojure_A_const_88.GetRawRoot__O(); var linked_874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_873, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_875 lang.IFn; if linked_874 == nil { ifn_875 = lang.IFn_Cast(root_873) } else { ifn_875 = nil }; var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_89.GetRawRoot__O()); var tmp33 any = A_arbace_repr_clojure_A_const_90; var arg_876 any = tmp32.Invoke_O_O__O(tmp33, A_arbace_repr_clojure_A_const_91.Get__O()); if linked_874 == nil { ifn_875.Invoke_O__O(arg_876) } else { linked_874.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_873, arg_876) }; var tmp34 any = A_arbace_repr_clojure_run_fn__716000081_A_New_O_O(f__28_2, p__33_2); var tmp35 *jrt.Class; var fncls__803 *jrt.Class = A_arbace_repr_clojure_run_fn__716000081_A_fn_class; if fncls__803 == nil { var fncls__803d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_95, false); A_arbace_repr_clojure_run_fn__716000081_A_fn_class = fncls__803d; tmp35 = fncls__803d } else { tmp35 = fncls__803 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp34, tmp35, nil).Invoke__O() } else {
//line :185:1
									if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_81.Invoke_O__O(p__33_2)) {




										if jrt.J2g_Truth(out__2) { var t__35_2 any; var root_882 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_883 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_882, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_884 lang.IFn
											if linked_883 == nil { ifn_884 = lang.IFn_Cast(root_882) } else { ifn_884 = nil }; var arg_885 any = out__2; var arg_886 any = rel__27_2; if linked_883 == nil { t__35_2 = ifn_884.Invoke_O_O__O(arg_885, arg_886) } else { t__35_2 = linked_883.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_882, arg_885, arg_886) }
											lang.IFn_Cast(A_arbace_repr_clojure_A_const_95.GetRawRoot__O()).Invoke_O__O(t__35_2)
											lang.IFn_Cast(A_arbace_repr_clojure_A_const_94.GetRawRoot__O()).Invoke_O_O__O(f__28_2, t__35_2) }
										var root_804 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_805 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_804, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_806 lang.IFn; if linked_805 == nil { ifn_806 = lang.IFn_Cast(root_804) } else { ifn_806 = nil }; var arg_807 any = stats__12; var arg_808 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_809 any = A_arbace_repr_clojure_A_const_84; var arg_810 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_805 == nil { ifn_806.Invoke_O_O_O_O__O(arg_807, arg_808, arg_809, arg_810) } else { linked_805.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_804, arg_807, arg_808, arg_809, arg_810) } } else {
//line :185:1
											if A_arbace_repr_clojure_A_const_34 != nil { var r__35_2 any; var tmp36 any = A_arbace_repr_clojure_run_fn__716000083_A_New_O_O_O_O_O_O(f__28_2, p__33_2, s__32_2, stats__12, translate_text__9, skip__5); var tmp37 *jrt.Class
												var fncls__850 /*line :185:1*/*jrt.Class = A_arbace_repr_clojure_run_fn__716000083_A_fn_class










												if fncls__850 == nil { var fncls__850d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_96, false); A_arbace_repr_clojure_run_fn__716000083_A_fn_class = fncls__850d; tmp37 = fncls__850d } else { tmp37 = fncls__850 }; r__35_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp36, tmp37, nil).Invoke__O()




												if jrt.J2g_Truth(r__35_2) {
													var root_896 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_897 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_896, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_898 lang.IFn; if linked_897 == nil { ifn_898 = lang.IFn_Cast(root_896) } else { ifn_898 = nil }; var arg_899 any = stats__12; var arg_900 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_901 any; if lang.Util_Equiv_O_O__Z_NoInit(s__32_2, r__35_2) { arg_901 = A_arbace_repr_clojure_A_const_96 } else { arg_901 = A_arbace_repr_clojure_A_const_97 }; var arg_902 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_897 == nil { ifn_898.Invoke_O_O_O_O__O(arg_899, arg_900, arg_901, arg_902) } else { linked_897.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_896, arg_899, arg_900, arg_901, arg_902) }
													if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__33_2)) { var root_903 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_904 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_903, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_905 lang.IFn; if linked_904 == nil { ifn_905 = lang.IFn_Cast(root_903) } else { ifn_905 = nil }; var arg_906 any = stats__12; var arg_907 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_908 any = A_arbace_repr_clojure_A_const_27; var arg_909 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_904 == nil { ifn_905.Invoke_O_O_O_O__O(arg_906, arg_907, arg_908, arg_909) } else { linked_904.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_903, arg_906, arg_907, arg_908, arg_909) } }
													if jrt.J2g_Truth(out__2) { var t__36_2 any; var root_851 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_852 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_851, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_853 lang.IFn
														if linked_852 == nil { ifn_853 = lang.IFn_Cast(root_851) } else { ifn_853 = nil }; var arg_854 any = out__2; var arg_855 any = rel_out__34_2; if linked_852 == nil { t__36_2 = ifn_853.Invoke_O_O__O(arg_854, arg_855) } else { t__36_2 = linked_852.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_851, arg_854, arg_855) }
														lang.IFn_Cast(A_arbace_repr_clojure_A_const_95.GetRawRoot__O()).Invoke_O__O(t__36_2)
														lang.IFn_Cast(A_arbace_repr_clojure_A_const_92.GetRawRoot__O()).Invoke_O_O__O(t__36_2, r__35_2) } else {
//line :204:1
															var moved__36_2 any; var root_861 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_862 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_861, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_863 lang.IFn



															if linked_862 == nil { ifn_863 = lang.IFn_Cast(root_861) } else { ifn_863 = nil }; var arg_864 any = jrt.NN(jrt.File_Cast(f__28_2)).GetName__String().Ref(); var arg_865 any = A_arbace_repr_clojure_A_const_28.Invoke_O__O(p__33_2); if linked_862 == nil { moved__36_2 = ifn_863.Invoke_O_O__O(arg_864, arg_865) } else { moved__36_2 = linked_862.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_861, arg_864, arg_865) }
															var tmp38 any; var or__1927000174__auto____37_2 any; var root_914 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_915 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_914, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_916 lang.IFn; if linked_915 == nil { ifn_916 = lang.IFn_Cast(root_914) } else { ifn_916 = nil }; var arg_917 any = s__32_2; var arg_918 any = r__35_2; if linked_915 == nil { or__1927000174__auto____37_2 = ifn_916.Invoke_O_O__O(arg_917, arg_918) } else { or__1927000174__auto____37_2 = linked_915.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_914, arg_917, arg_918) }; if jrt.J2g_Truth(or__1927000174__auto____37_2) { tmp38 = or__1927000174__auto____37_2 } else { tmp38 = moved__36_2 }; if jrt.J2g_Truth(tmp38) {
																var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_92.GetRawRoot__O()); var tmp40 any; var root_924 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_925 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_924, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_926 lang.IFn; if linked_925 == nil { ifn_926 = lang.IFn_Cast(root_924) } else { ifn_926 = nil }; var arg_927 any = parent__29_2; var arg_928 any = A_arbace_repr_clojure_A_const_28.Invoke_O__O(p__33_2); if linked_925 == nil { tmp40 = ifn_926.Invoke_O_O__O(arg_927, arg_928) } else { tmp40 = linked_925.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_924, arg_927, arg_928) }; tmp39.Invoke_O_O__O(tmp40, r__35_2) }
															if jrt.J2g_Truth(moved__36_2) { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(f__28_2)).Delete__Z()) } } } } } }
//line :175:1
							seq_716000052__21, chunk_716000053__22, count_716000054__23, i_716000055__24 = seq_716000052__21, chunk_716000053__22, count_716000054__23, lang.Numbers_Unchecked_inc_J__J_NoInit(i_716000055__24); continue L3 } else { var temp__1927000414__auto____25 any; var root_760 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_760, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_762 lang.IFn; if linked_761 == nil { ifn_762 = lang.IFn_Cast(root_760) } else { ifn_762 = nil }; var arg_763 any = seq_716000052__21; if linked_761 == nil { temp__1927000414__auto____25 = ifn_762.Invoke_O__O(arg_763) } else { temp__1927000414__auto____25 = linked_761.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_760, arg_763) }; if jrt.J2g_Truth(temp__1927000414__auto____25) { var seq_716000052__26 any = temp__1927000414__auto____25; var tmp41 any; var root_764 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_764, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_766 lang.IFn; if linked_765 == nil { ifn_766 = lang.IFn_Cast(root_764) } else { ifn_766 = nil }; var arg_767 any = seq_716000052__26; if linked_765 == nil { tmp41 = ifn_766.Invoke_O__O(arg_767) } else { tmp41 = linked_765.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_764, arg_767) }; if jrt.J2g_Truth(tmp41) { var c__1927000678__auto____27 any; var root_768 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_768, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_770 lang.IFn; if linked_769 == nil { ifn_770 = lang.IFn_Cast(root_768) } else { ifn_770 = nil }; var arg_771 any = seq_716000052__26; if linked_769 == nil { c__1927000678__auto____27 = ifn_770.Invoke_O__O(arg_771) } else { c__1927000678__auto____27 = linked_769.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_768, arg_771) }; var tmp42 any; var root_929 any = A_arbace_repr_clojure_A_const_65.GetRawRoot__O(); var linked_930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_929, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_931 lang.IFn; if linked_930 == nil { ifn_931 = lang.IFn_Cast(root_929) } else { ifn_931 = nil }; var arg_932 any = seq_716000052__26; if linked_930 == nil { tmp42 = ifn_931.Invoke_O__O(arg_932) } else { tmp42 = linked_930.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_929, arg_932) }; seq_716000052__21, chunk_716000053__22, count_716000054__23, i_716000055__24 = tmp42, c__1927000678__auto____27, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____27))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__716000087__27 any; var root_772 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_772, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_774 lang.IFn; if linked_773 == nil { ifn_774 = lang.IFn_Cast(root_772) } else { ifn_774 = nil }; var arg_775 any = seq_716000052__26; if linked_773 == nil { vec__716000087__27 = ifn_774.Invoke_O__O(arg_775) } else { vec__716000087__27 = linked_773.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_772, arg_775) }; var dir__28 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000087__27, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__29 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000087__27, lang.RT_IntCast_J__I_NoInit(1), nil); var f__30 any; var root_933 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_934 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_933, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_935 lang.IFn


								if linked_934 == nil { ifn_935 = lang.IFn_Cast(root_933) } else { ifn_935 = nil }; var arg_936 any = dir__28; var arg_937 any = rel__29; if linked_934 == nil { f__30 = ifn_935.Invoke_O_O__O(arg_936, arg_937) } else { f__30 = linked_934.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_933, arg_936, arg_937) }
//line :175:1
								var parent__31 any = jrt.NN(jrt.File_Cast(f__30)).GetParentFile__File().Ref(); var siblings__32 any = lang.IFn_Cast(listing__11).Invoke_O__O(parent__31); var p0__33 any = lang.IFn_Cast(plan__8).Invoke_O_O_O__O(jrt.NN(jrt.File_Cast(f__30)).GetName__String().Ref(), siblings__32, opts__3); var s__34 any






								if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_24.Invoke_O__O(p0__33)) { s__34 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_78.GetRawRoot__O()).Invoke_O__O(f__30) } else { s__34 = nil }
//line :175:1
								var p__35 any







								if jrt.J2g_Truth(s__34) { p__35 = lang.IFn_Cast(refine__10).Invoke_O_O_O_O__O(p0__33, jrt.NN(jrt.File_Cast(f__30)).GetName__String().Ref(), siblings__32, s__34) } else { p__35 = p0__33 }
//line :175:1
								var rel_out__36 any; var d__36 any; var tmp43 any; var root_942 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_943 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_942, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_944 lang.IFn








								if linked_943 == nil { ifn_944 = lang.IFn_Cast(root_942) } else { ifn_944 = nil }; var arg_945 any = rel__29; if linked_943 == nil { tmp43 = ifn_944.Invoke_O__O(arg_945) } else { tmp43 = linked_943.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_942, arg_945) }; d__36 = jrt.NN(jrt.File_Cast(tmp43)).GetParent__String().Ref(); if jrt.J2g_Truth(d__36) { rel_out__36 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_29, nil), jrt.RefArrayOf(jrt.Object_class, d__36, nil, A_arbace_repr_clojure_A_const_28.Invoke_O__O(p__35))).Ref() } else { rel_out__36 = A_arbace_repr_clojure_A_const_28.Invoke_O__O(p__35) }
								if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_33.Invoke_O__O(p__35)) {

									var root_1023 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_1024 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1023, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1025 lang.IFn; if linked_1024 == nil { ifn_1025 = lang.IFn_Cast(root_1023) } else { ifn_1025 = nil }; var arg_1026 any = stats__12; var arg_1027 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_1028 any = A_arbace_repr_clojure_A_const_93; var arg_1029 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_1024 == nil { ifn_1025.Invoke_O_O_O_O__O(arg_1026, arg_1027, arg_1028, arg_1029) } else { linked_1024.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1023, arg_1026, arg_1027, arg_1028, arg_1029) }
									var root_1030 any = A_arbace_repr_clojure_A_const_88.GetRawRoot__O(); var linked_1031 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1030, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1032 lang.IFn; if linked_1031 == nil { ifn_1032 = lang.IFn_Cast(root_1030) } else { ifn_1032 = nil }; var tmp44 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_89.GetRawRoot__O()); var tmp45 any = A_arbace_repr_clojure_A_const_90; var arg_1033 any = tmp44.Invoke_O_O__O(tmp45, A_arbace_repr_clojure_A_const_91.Get__O()); if linked_1031 == nil { ifn_1032.Invoke_O__O(arg_1033) } else { linked_1031.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1030, arg_1033) }; var tmp46 any = A_arbace_repr_clojure_run_fn__716000090_A_New_O_O(f__30, p__35); var tmp47 *jrt.Class; var fncls__960 *jrt.Class = A_arbace_repr_clojure_run_fn__716000090_A_fn_class; if fncls__960 == nil { var fncls__960d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_97, false); A_arbace_repr_clojure_run_fn__716000090_A_fn_class = fncls__960d; tmp47 = fncls__960d } else { tmp47 = fncls__960 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp46, tmp47, nil).Invoke__O() } else {
//line :185:1
										if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_81.Invoke_O__O(p__35)) {




											if jrt.J2g_Truth(out__2) { var t__37 any; var root_1039 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_1040 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1039, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_1041 lang.IFn
												if linked_1040 == nil { ifn_1041 = lang.IFn_Cast(root_1039) } else { ifn_1041 = nil }; var arg_1042 any = out__2; var arg_1043 any = rel__29; if linked_1040 == nil { t__37 = ifn_1041.Invoke_O_O__O(arg_1042, arg_1043) } else { t__37 = linked_1040.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_1039, arg_1042, arg_1043) }
												lang.IFn_Cast(A_arbace_repr_clojure_A_const_95.GetRawRoot__O()).Invoke_O__O(t__37)
												lang.IFn_Cast(A_arbace_repr_clojure_A_const_94.GetRawRoot__O()).Invoke_O_O__O(f__30, t__37) }
											var root_961 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_962 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_961, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_963 lang.IFn; if linked_962 == nil { ifn_963 = lang.IFn_Cast(root_961) } else { ifn_963 = nil }; var arg_964 any = stats__12; var arg_965 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_966 any = A_arbace_repr_clojure_A_const_84; var arg_967 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_962 == nil { ifn_963.Invoke_O_O_O_O__O(arg_964, arg_965, arg_966, arg_967) } else { linked_962.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_961, arg_964, arg_965, arg_966, arg_967) } } else {
//line :185:1
												if A_arbace_repr_clojure_A_const_34 != nil { var r__37 any; var tmp48 any = A_arbace_repr_clojure_run_fn__716000092_A_New_O_O_O_O_O_O(f__30, p__35, s__34, stats__12, translate_text__9, skip__5); var tmp49 *jrt.Class
													var fncls__1007 /*line :185:1*/*jrt.Class = A_arbace_repr_clojure_run_fn__716000092_A_fn_class










													if fncls__1007 == nil { var fncls__1007d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_98, false); A_arbace_repr_clojure_run_fn__716000092_A_fn_class = fncls__1007d; tmp49 = fncls__1007d } else { tmp49 = fncls__1007 }; r__37 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp48, tmp49, nil).Invoke__O()




													if jrt.J2g_Truth(r__37) {
														var root_1053 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_1054 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1053, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1055 lang.IFn; if linked_1054 == nil { ifn_1055 = lang.IFn_Cast(root_1053) } else { ifn_1055 = nil }; var arg_1056 any = stats__12; var arg_1057 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_1058 any; if lang.Util_Equiv_O_O__Z_NoInit(s__34, r__37) { arg_1058 = A_arbace_repr_clojure_A_const_96 } else { arg_1058 = A_arbace_repr_clojure_A_const_97 }; var arg_1059 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_1054 == nil { ifn_1055.Invoke_O_O_O_O__O(arg_1056, arg_1057, arg_1058, arg_1059) } else { linked_1054.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1053, arg_1056, arg_1057, arg_1058, arg_1059) }
														if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__35)) { var root_1060 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_1061 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1060, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1062 lang.IFn; if linked_1061 == nil { ifn_1062 = lang.IFn_Cast(root_1060) } else { ifn_1062 = nil }; var arg_1063 any = stats__12; var arg_1064 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_1065 any = A_arbace_repr_clojure_A_const_27; var arg_1066 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_1061 == nil { ifn_1062.Invoke_O_O_O_O__O(arg_1063, arg_1064, arg_1065, arg_1066) } else { linked_1061.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1060, arg_1063, arg_1064, arg_1065, arg_1066) } }
														if jrt.J2g_Truth(out__2) { var t__38 any; var root_1008 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_1009 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1008, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_1010 lang.IFn
															if linked_1009 == nil { ifn_1010 = lang.IFn_Cast(root_1008) } else { ifn_1010 = nil }; var arg_1011 any = out__2; var arg_1012 any = rel_out__36; if linked_1009 == nil { t__38 = ifn_1010.Invoke_O_O__O(arg_1011, arg_1012) } else { t__38 = linked_1009.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_1008, arg_1011, arg_1012) }
															lang.IFn_Cast(A_arbace_repr_clojure_A_const_95.GetRawRoot__O()).Invoke_O__O(t__38)
															lang.IFn_Cast(A_arbace_repr_clojure_A_const_92.GetRawRoot__O()).Invoke_O_O__O(t__38, r__37) } else {
//line :204:1
																var moved__38 any; var root_1018 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_1019 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1018, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1020 lang.IFn



																if linked_1019 == nil { ifn_1020 = lang.IFn_Cast(root_1018) } else { ifn_1020 = nil }; var arg_1021 any = jrt.NN(jrt.File_Cast(f__30)).GetName__String().Ref(); var arg_1022 any = A_arbace_repr_clojure_A_const_28.Invoke_O__O(p__35); if linked_1019 == nil { moved__38 = ifn_1020.Invoke_O_O__O(arg_1021, arg_1022) } else { moved__38 = linked_1019.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1018, arg_1021, arg_1022) }
																var tmp50 any; var or__1927000174__auto____39 any; var root_1071 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_1072 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1071, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1073 lang.IFn; if linked_1072 == nil { ifn_1073 = lang.IFn_Cast(root_1071) } else { ifn_1073 = nil }; var arg_1074 any = s__34; var arg_1075 any = r__37; if linked_1072 == nil { or__1927000174__auto____39 = ifn_1073.Invoke_O_O__O(arg_1074, arg_1075) } else { or__1927000174__auto____39 = linked_1072.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1071, arg_1074, arg_1075) }; if jrt.J2g_Truth(or__1927000174__auto____39) { tmp50 = or__1927000174__auto____39 } else { tmp50 = moved__38 }; if jrt.J2g_Truth(tmp50) {
																	var tmp51 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_92.GetRawRoot__O()); var tmp52 any; var root_1081 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_1082 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1081, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_1083 lang.IFn; if linked_1082 == nil { ifn_1083 = lang.IFn_Cast(root_1081) } else { ifn_1083 = nil }; var arg_1084 any = parent__31; var arg_1085 any = A_arbace_repr_clojure_A_const_28.Invoke_O__O(p__35); if linked_1082 == nil { tmp52 = ifn_1083.Invoke_O_O__O(arg_1084, arg_1085) } else { tmp52 = linked_1082.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_1081, arg_1084, arg_1085) }; tmp51.Invoke_O_O__O(tmp52, r__37) }
																if jrt.J2g_Truth(moved__38) { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(f__30)).Delete__Z()) } } } } } }
//line :175:1
								var tmp53 any; var root_1086 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_1087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1086, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1088 lang.IFn; if linked_1087 == nil { ifn_1088 = lang.IFn_Cast(root_1086) } else { ifn_1088 = nil }; var arg_1089 any = seq_716000052__26; if linked_1087 == nil { tmp53 = ifn_1088.Invoke_O__O(arg_1089) } else { tmp53 = linked_1087.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1086, arg_1089) }; seq_716000052__21, chunk_716000053__22, count_716000054__23, i_716000055__24 = tmp53, nil, 0, 0; continue L3 } } }; break L3 }; var tmp54 any; var root_1090 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_1091 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1090, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1092 lang.IFn; if linked_1091 == nil { ifn_1092 = lang.IFn_Cast(root_1090) } else { ifn_1092 = nil }; var arg_1093 any = seq_716000048__18; if linked_1091 == nil { tmp54 = ifn_1092.Invoke_O__O(arg_1093) } else { tmp54 = linked_1091.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1090, arg_1093) }; seq_716000048__13, chunk_716000049__14, count_716000050__15, i_716000051__16 = tmp54, nil, 0, 0; continue L1 } } }
//line :163:1
		break L1 }; var root_378 any =







	A_arbace_repr_clojure_A_const_8.GetRawRoot__O(); var linked_379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_378, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_380 lang.IFn; if linked_379 == nil { ifn_380 = lang.IFn_Cast(root_378) } else { ifn_380 = nil }; var arg_381 any = stats__12; if linked_379 == nil { return ifn_380.Invoke_O__O(arg_381) } else { return linked_379.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_378, arg_381) } }
//line :163:1
func (t *A_arbace_repr_clojure_run_A) Invoke_O_O_O_O__O(self, sources__0, out__1, opts__2 any) any {





	var root_1094 any = A_arbace_repr_clojure_A_const_98.GetRawRoot__O(); var linked_1095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1094, A_arbace_repr_clojure_run_A_fn_class); var ifn_1096 lang.IFn; if linked_1095 == nil { ifn_1096 = lang.IFn_Cast(root_1094) } else { ifn_1096 = nil }; var arg_1097 any = A_arbace_repr_clojure_A_const_99; var arg_1098 any = sources__0; var arg_1099 any = out__1; var arg_1100 any = opts__2; if linked_1095 == nil { return ifn_1096.Invoke_O_O_O_O__O(arg_1097, arg_1098, arg_1099, arg_1100) } else { return linked_1095.(*A_arbace_repr_clojure_run_A).Invoke_O_O_O_O_O__O(root_1094, arg_1097, arg_1098, arg_1099, arg_1100)
	}
}

func A_arbace_repr_clojure_run_fn__716000046_A_New() *A_arbace_repr_clojure_run_fn__716000046_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000046_A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_repr_clojure_run_fn__716000046_A) Ctor() {}
//line :173:1
func (t *A_arbace_repr_clojure_run_fn__716000046_A) Invoke_O_O__O(self, d__1 any) any { var root_369 any = A_arbace_repr_clojure_A_const_73.GetRawRoot__O(); var linked_370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_369, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_371 lang.IFn; if linked_370 == nil { ifn_371 = lang.IFn_Cast(root_369) } else { ifn_371 = nil }; var arg_372 any = jrt.NN(jrt.File_Cast(d__1)).List__String1().Ref(); if linked_370 == nil { return ifn_371.Invoke_O__O(arg_372) } else { return linked_370.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_369, arg_372) } }














func A_arbace_repr_clojure_run_fn__716000063_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_run_fn__716000063_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000063_A{}; t.Ctor_O_O(p0, p1); return t }
//line :188:1
func (t *A_arbace_repr_clojure_run_fn__716000063_A) Ctor_O_O(c__f, c__p any) { t.F_f = c__f; t.F_p = c__p }
//line :188:1
func (t *A_arbace_repr_clojure_run_fn__716000063_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp3 any; var root_450 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_450, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_452 lang.IFn; if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any; var t_ any = t.F_f; t.F_f = nil; arg_453 = t_; if linked_451 == nil { tmp3 = ifn_452.Invoke_O__O(arg_453) } else { tmp3 = linked_451.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_450, arg_453) }; var tmp4 any = tmp3; var tmp5 *lang.Keyword = A_arbace_repr_clojure_A_const_33; var tmp6 any; var t__2 any = t.F_p; t.F_p = nil; tmp6 = t__2; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_99, tmp4, Lit_45, tmp5.Invoke_O__O(tmp6)) }; return nil }(); var root_454 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_456 lang.IFn; if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; if linked_455 == nil { ifn_456.Invoke__O() } else { linked_455.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_454) }; if tmp7 != nil { panic(tmp7) }; return tmp1 }
//line :188:1
func A_arbace_repr_clojure_run_fn__716000072_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_run_fn__716000072_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000072_A{}; t.Ctor_O_O(p0, p1); return t }
//line :188:1
func (t *A_arbace_repr_clojure_run_fn__716000072_A) Ctor_O_O(c__f, c__p any) { t.F_f = c__f; t.F_p = c__p }
//line :188:1
func (t *A_arbace_repr_clojure_run_fn__716000072_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp3 any; var root_607 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_608 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_607, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_609 lang.IFn; if linked_608 == nil { ifn_609 = lang.IFn_Cast(root_607) } else { ifn_609 = nil }; var arg_610 any; var t_ any = t.F_f; t.F_f = nil; arg_610 = t_; if linked_608 == nil { tmp3 = ifn_609.Invoke_O__O(arg_610) } else { tmp3 = linked_608.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_607, arg_610) }; var tmp4 any = tmp3; var tmp5 *lang.Keyword = A_arbace_repr_clojure_A_const_33; var tmp6 any; var t__2 any = t.F_p; t.F_p = nil; tmp6 = t__2; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_99, tmp4, Lit_45, tmp5.Invoke_O__O(tmp6)) }; return nil }(); var root_611 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); var linked_612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_611, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_613 lang.IFn; if linked_612 == nil { ifn_613 = lang.IFn_Cast(root_611) } else { ifn_613 = nil }; if linked_612 == nil { ifn_613.Invoke__O() } else { linked_612.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_611) }; if tmp7 != nil { panic(tmp7) }; return tmp1 }
//line :188:1
func A_arbace_repr_clojure_run_fn__716000081_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_run_fn__716000081_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000081_A{}; t.Ctor_O_O(p0, p1); return t }
//line :188:1
func (t *A_arbace_repr_clojure_run_fn__716000081_A) Ctor_O_O(c__f, c__p any) { t.F_f = c__f; t.F_p = c__p }
//line :188:1
func (t *A_arbace_repr_clojure_run_fn__716000081_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp3 any; var root_796 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_797 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_796, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_798 lang.IFn; if linked_797 == nil { ifn_798 = lang.IFn_Cast(root_796) } else { ifn_798 = nil }; var arg_799 any; var t_ any = t.F_f; t.F_f = nil; arg_799 = t_; if linked_797 == nil { tmp3 = ifn_798.Invoke_O__O(arg_799) } else { tmp3 = linked_797.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_796, arg_799) }; var tmp4 any = tmp3; var tmp5 *lang.Keyword = A_arbace_repr_clojure_A_const_33; var tmp6 any; var t__2 any = t.F_p; t.F_p = nil; tmp6 = t__2; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_99, tmp4, Lit_45, tmp5.Invoke_O__O(tmp6)) }; return nil }(); var root_800 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); var linked_801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_800, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_802 lang.IFn; if linked_801 == nil { ifn_802 = lang.IFn_Cast(root_800) } else { ifn_802 = nil }; if linked_801 == nil { ifn_802.Invoke__O() } else { linked_801.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_800) }; if tmp7 != nil { panic(tmp7) }; return tmp1 }
//line :188:1
func A_arbace_repr_clojure_run_fn__716000090_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_run_fn__716000090_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000090_A{}; t.Ctor_O_O(p0, p1); return t }
//line :188:1
func (t *A_arbace_repr_clojure_run_fn__716000090_A) Ctor_O_O(c__f, c__p any) { t.F_f = c__f; t.F_p = c__p }
//line :188:1
func (t *A_arbace_repr_clojure_run_fn__716000090_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp3 any; var root_953 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_954 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_953, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_955 lang.IFn; if linked_954 == nil { ifn_955 = lang.IFn_Cast(root_953) } else { ifn_955 = nil }; var arg_956 any; var t_ any = t.F_f; t.F_f = nil; arg_956 = t_; if linked_954 == nil { tmp3 = ifn_955.Invoke_O__O(arg_956) } else { tmp3 = linked_954.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_953, arg_956) }; var tmp4 any = tmp3; var tmp5 *lang.Keyword = A_arbace_repr_clojure_A_const_33; var tmp6 any; var t__2 any = t.F_p; t.F_p = nil; tmp6 = t__2; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_99, tmp4, Lit_45, tmp5.Invoke_O__O(tmp6)) }; return nil }(); var root_957 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); var linked_958 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_957, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_959 lang.IFn; if linked_958 == nil { ifn_959 = lang.IFn_Cast(root_957) } else { ifn_959 = nil }; if linked_958 == nil { ifn_959.Invoke__O() } else { linked_958.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_957) }; if tmp7 != nil { panic(tmp7) }; return tmp1 }







func A_arbace_repr_clojure_run_fn__716000065_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_repr_clojure_run_fn__716000065_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000065_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :196:1
func (t *A_arbace_repr_clojure_run_fn__716000065_A) Ctor_O_O_O_O_O_O(c__f, c__p, c__stats, c__s, c__translate_text, c__skip any) { t.F_f = c__f; t.F_p = c__p; t.F_stats = c__stats; t.F_s = c__s; t.F_translate_text = c__translate_text; t.F_skip = c__skip }
//line :196:1
func (t *A_arbace_repr_clojure_run_fn__716000065_A) Invoke_O__O(self any) any { var tmp1 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var t_ any = t.F_translate_text; t.F_translate_text = nil; tmp2 = t_; var tmp3 lang.IFn = lang.IFn_Cast(tmp2); var tmp4 any; var t__2 any = t.F_s; t.F_s = nil; tmp4 = t__2; var tmp5 any = tmp4; var tmp6 any; var t__3 any = t.F_p; t.F_p = nil; tmp6 = t__3; var tmp7 any = tmp6; var tmp8 any; var root_465 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_466 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_465, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_467 lang.IFn; if linked_466 == nil { ifn_467 = lang.IFn_Cast(root_465) } else { ifn_467 = nil }; var arg_468 any = t.F_f; if linked_466 == nil { tmp8 = ifn_467.Invoke_O__O(arg_468) } else { tmp8 = linked_466.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_465, arg_468) }; var tmp9 any = tmp8; var tmp10 any; var t__4 any = t.F_skip; t.F_skip = nil; tmp10 = t__4; tmp1 = tmp3.Invoke_O_O_O_O__O(tmp5, tmp7, tmp9, tmp10) }; return nil }(); if tmp11 != nil { if jrt.Exception_InstanceOf(tmp11) { var e__3 jrt.Exception_I = jrt.Exception_Cast(tmp11); var root_469 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_470 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_469, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_471 lang.IFn

	if linked_470 == nil { ifn_471 = lang.IFn_Cast(root_469) } else { ifn_471 = nil }; var arg_472 any; var t__5 any = t.F_stats; t.F_stats = nil; arg_472 = t__5; var arg_473 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_474 any = A_arbace_repr_clojure_A_const_86; var arg_475 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_470 == nil { ifn_471.Invoke_O_O_O_O__O(arg_472, arg_473, arg_474, arg_475) } else { linked_470.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_469, arg_472, arg_473, arg_474, arg_475) }
	var root_495 any = A_arbace_repr_clojure_A_const_88.GetRawRoot__O(); var linked_496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_495, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_497 lang.IFn; if linked_496 == nil { ifn_497 = lang.IFn_Cast(root_495) } else { ifn_497 = nil }; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_89.GetRawRoot__O()); var tmp13 any = A_arbace_repr_clojure_A_const_90; var arg_498 any = tmp12.Invoke_O_O__O(tmp13, A_arbace_repr_clojure_A_const_91.Get__O()); if linked_496 == nil { ifn_497.Invoke_O__O(arg_498) } else { linked_496.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_495, arg_498) }; var tmp14 any = A_arbace_repr_clojure_run_fn__716000065_fn__716000066_A_New_O_O(e__3, t.F_f); var tmp15 *jrt.Class; var fncls__494 *jrt.Class = A_arbace_repr_clojure_run_fn__716000065_fn__716000066_A_fn_class; if fncls__494 == nil { var fncls__494d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_100, false); A_arbace_repr_clojure_run_fn__716000065_fn__716000066_A_fn_class = fncls__494d; tmp15 = fncls__494d } else { tmp15 = fncls__494 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil).Invoke__O()
//line :196:1
	tmp1 = nil } else { panic(tmp11) } }; return tmp1 }
//line :196:1
func A_arbace_repr_clojure_run_fn__716000074_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_repr_clojure_run_fn__716000074_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000074_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :196:1
func (t *A_arbace_repr_clojure_run_fn__716000074_A) Ctor_O_O_O_O_O_O(c__f, c__p, c__s, c__stats, c__translate_text, c__skip any) { t.F_f = c__f; t.F_p = c__p; t.F_s = c__s; t.F_stats = c__stats; t.F_translate_text = c__translate_text; t.F_skip = c__skip }
//line :196:1
func (t *A_arbace_repr_clojure_run_fn__716000074_A) Invoke_O__O(self any) any { var tmp1 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var t_ any = t.F_translate_text; t.F_translate_text = nil; tmp2 = t_; var tmp3 lang.IFn = lang.IFn_Cast(tmp2); var tmp4 any; var t__2 any = t.F_s; t.F_s = nil; tmp4 = t__2; var tmp5 any = tmp4; var tmp6 any; var t__3 any = t.F_p; t.F_p = nil; tmp6 = t__3; var tmp7 any = tmp6; var tmp8 any; var root_622 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_623 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_622, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_624 lang.IFn; if linked_623 == nil { ifn_624 = lang.IFn_Cast(root_622) } else { ifn_624 = nil }; var arg_625 any = t.F_f; if linked_623 == nil { tmp8 = ifn_624.Invoke_O__O(arg_625) } else { tmp8 = linked_623.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_622, arg_625) }; var tmp9 any = tmp8; var tmp10 any; var t__4 any = t.F_skip; t.F_skip = nil; tmp10 = t__4; tmp1 = tmp3.Invoke_O_O_O_O__O(tmp5, tmp7, tmp9, tmp10) }; return nil }(); if tmp11 != nil { if jrt.Exception_InstanceOf(tmp11) { var e__3 jrt.Exception_I = jrt.Exception_Cast(tmp11); var root_626 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_627 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_626, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_628 lang.IFn

	if linked_627 == nil { ifn_628 = lang.IFn_Cast(root_626) } else { ifn_628 = nil }; var arg_629 any; var t__5 any = t.F_stats; t.F_stats = nil; arg_629 = t__5; var arg_630 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_631 any = A_arbace_repr_clojure_A_const_86; var arg_632 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_627 == nil { ifn_628.Invoke_O_O_O_O__O(arg_629, arg_630, arg_631, arg_632) } else { linked_627.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_626, arg_629, arg_630, arg_631, arg_632) }
	var root_652 any = A_arbace_repr_clojure_A_const_88.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_654 lang.IFn; if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_89.GetRawRoot__O()); var tmp13 any = A_arbace_repr_clojure_A_const_90; var arg_655 any = tmp12.Invoke_O_O__O(tmp13, A_arbace_repr_clojure_A_const_91.Get__O()); if linked_653 == nil { ifn_654.Invoke_O__O(arg_655) } else { linked_653.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_652, arg_655) }; var tmp14 any = A_arbace_repr_clojure_run_fn__716000074_fn__716000075_A_New_O_O(e__3, t.F_f); var tmp15 *jrt.Class; var fncls__651 *jrt.Class = A_arbace_repr_clojure_run_fn__716000074_fn__716000075_A_fn_class; if fncls__651 == nil { var fncls__651d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_102, false); A_arbace_repr_clojure_run_fn__716000074_fn__716000075_A_fn_class = fncls__651d; tmp15 = fncls__651d } else { tmp15 = fncls__651 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil).Invoke__O()
//line :196:1
	tmp1 = nil } else { panic(tmp11) } }; return tmp1 }
//line :196:1
func A_arbace_repr_clojure_run_fn__716000083_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_repr_clojure_run_fn__716000083_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000083_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :196:1
func (t *A_arbace_repr_clojure_run_fn__716000083_A) Ctor_O_O_O_O_O_O(c__f, c__p, c__s, c__stats, c__translate_text, c__skip any) { t.F_f = c__f; t.F_p = c__p; t.F_s = c__s; t.F_stats = c__stats; t.F_translate_text = c__translate_text; t.F_skip = c__skip }
//line :196:1
func (t *A_arbace_repr_clojure_run_fn__716000083_A) Invoke_O__O(self any) any { var tmp1 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var t_ any = t.F_translate_text; t.F_translate_text = nil; tmp2 = t_; var tmp3 lang.IFn = lang.IFn_Cast(tmp2); var tmp4 any; var t__2 any = t.F_s; t.F_s = nil; tmp4 = t__2; var tmp5 any = tmp4; var tmp6 any; var t__3 any = t.F_p; t.F_p = nil; tmp6 = t__3; var tmp7 any = tmp6; var tmp8 any; var root_811 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_812 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_811, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_813 lang.IFn; if linked_812 == nil { ifn_813 = lang.IFn_Cast(root_811) } else { ifn_813 = nil }; var arg_814 any = t.F_f; if linked_812 == nil { tmp8 = ifn_813.Invoke_O__O(arg_814) } else { tmp8 = linked_812.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_811, arg_814) }; var tmp9 any = tmp8; var tmp10 any; var t__4 any = t.F_skip; t.F_skip = nil; tmp10 = t__4; tmp1 = tmp3.Invoke_O_O_O_O__O(tmp5, tmp7, tmp9, tmp10) }; return nil }(); if tmp11 != nil { if jrt.Exception_InstanceOf(tmp11) { var e__3 jrt.Exception_I = jrt.Exception_Cast(tmp11); var root_815 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_816 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_815, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_817 lang.IFn

	if linked_816 == nil { ifn_817 = lang.IFn_Cast(root_815) } else { ifn_817 = nil }; var arg_818 any; var t__5 any = t.F_stats; t.F_stats = nil; arg_818 = t__5; var arg_819 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_820 any = A_arbace_repr_clojure_A_const_86; var arg_821 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_816 == nil { ifn_817.Invoke_O_O_O_O__O(arg_818, arg_819, arg_820, arg_821) } else { linked_816.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_815, arg_818, arg_819, arg_820, arg_821) }
	var root_841 any = A_arbace_repr_clojure_A_const_88.GetRawRoot__O(); var linked_842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_841, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_843 lang.IFn; if linked_842 == nil { ifn_843 = lang.IFn_Cast(root_841) } else { ifn_843 = nil }; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_89.GetRawRoot__O()); var tmp13 any = A_arbace_repr_clojure_A_const_90; var arg_844 any = tmp12.Invoke_O_O__O(tmp13, A_arbace_repr_clojure_A_const_91.Get__O()); if linked_842 == nil { ifn_843.Invoke_O__O(arg_844) } else { linked_842.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_841, arg_844) }; var tmp14 any = A_arbace_repr_clojure_run_fn__716000083_fn__716000084_A_New_O_O(e__3, t.F_f); var tmp15 *jrt.Class; var fncls__840 *jrt.Class = A_arbace_repr_clojure_run_fn__716000083_fn__716000084_A_fn_class; if fncls__840 == nil { var fncls__840d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_103, false); A_arbace_repr_clojure_run_fn__716000083_fn__716000084_A_fn_class = fncls__840d; tmp15 = fncls__840d } else { tmp15 = fncls__840 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil).Invoke__O()
//line :196:1
	tmp1 = nil } else { panic(tmp11) } }; return tmp1 }
//line :196:1
func A_arbace_repr_clojure_run_fn__716000092_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_repr_clojure_run_fn__716000092_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000092_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :196:1
func (t *A_arbace_repr_clojure_run_fn__716000092_A) Ctor_O_O_O_O_O_O(c__f, c__p, c__s, c__stats, c__translate_text, c__skip any) { t.F_f = c__f; t.F_p = c__p; t.F_s = c__s; t.F_stats = c__stats; t.F_translate_text = c__translate_text; t.F_skip = c__skip }
//line :196:1
func (t *A_arbace_repr_clojure_run_fn__716000092_A) Invoke_O__O(self any) any { var tmp1 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var t_ any = t.F_translate_text; t.F_translate_text = nil; tmp2 = t_; var tmp3 lang.IFn = lang.IFn_Cast(tmp2); var tmp4 any; var t__2 any = t.F_s; t.F_s = nil; tmp4 = t__2; var tmp5 any = tmp4; var tmp6 any; var t__3 any = t.F_p; t.F_p = nil; tmp6 = t__3; var tmp7 any = tmp6; var tmp8 any; var root_968 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_969 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_968, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_970 lang.IFn; if linked_969 == nil { ifn_970 = lang.IFn_Cast(root_968) } else { ifn_970 = nil }; var arg_971 any = t.F_f; if linked_969 == nil { tmp8 = ifn_970.Invoke_O__O(arg_971) } else { tmp8 = linked_969.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_968, arg_971) }; var tmp9 any = tmp8; var tmp10 any; var t__4 any = t.F_skip; t.F_skip = nil; tmp10 = t__4; tmp1 = tmp3.Invoke_O_O_O_O__O(tmp5, tmp7, tmp9, tmp10) }; return nil }(); if tmp11 != nil { if jrt.Exception_InstanceOf(tmp11) { var e__3 jrt.Exception_I = jrt.Exception_Cast(tmp11); var root_972 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_973 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_972, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_974 lang.IFn

	if linked_973 == nil { ifn_974 = lang.IFn_Cast(root_972) } else { ifn_974 = nil }; var arg_975 any; var t__5 any = t.F_stats; t.F_stats = nil; arg_975 = t__5; var arg_976 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_977 any = A_arbace_repr_clojure_A_const_86; var arg_978 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_973 == nil { ifn_974.Invoke_O_O_O_O__O(arg_975, arg_976, arg_977, arg_978) } else { linked_973.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_972, arg_975, arg_976, arg_977, arg_978) }
	var root_998 any = A_arbace_repr_clojure_A_const_88.GetRawRoot__O(); var linked_999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_998, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1000 lang.IFn; if linked_999 == nil { ifn_1000 = lang.IFn_Cast(root_998) } else { ifn_1000 = nil }; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_89.GetRawRoot__O()); var tmp13 any = A_arbace_repr_clojure_A_const_90; var arg_1001 any = tmp12.Invoke_O_O__O(tmp13, A_arbace_repr_clojure_A_const_91.Get__O()); if linked_999 == nil { ifn_1000.Invoke_O__O(arg_1001) } else { linked_999.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_998, arg_1001) }; var tmp14 any = A_arbace_repr_clojure_run_fn__716000092_fn__716000093_A_New_O_O(e__3, t.F_f); var tmp15 *jrt.Class; var fncls__997 *jrt.Class = A_arbace_repr_clojure_run_fn__716000092_fn__716000093_A_fn_class; if fncls__997 == nil { var fncls__997d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_104, false); A_arbace_repr_clojure_run_fn__716000092_fn__716000093_A_fn_class = fncls__997d; tmp15 = fncls__997d } else { tmp15 = fncls__997 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil).Invoke__O()
//line :196:1
	tmp1 = nil } else { panic(tmp11) } }; return tmp1 }


func A_arbace_repr_clojure_run_fn__716000065_fn__716000066_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_run_fn__716000065_fn__716000066_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000065_fn__716000066_A{}; t.Ctor_O_O(p0, p1); return t }
//line :199:1
func (t *A_arbace_repr_clojure_run_fn__716000065_fn__716000066_A) Ctor_O_O(c__e, c__f any) { t.F_e = c__e; t.F_f = c__f }
//line :199:1
func (t *A_arbace_repr_clojure_run_fn__716000065_fn__716000066_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp3 any; var root_483 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_483, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_485 lang.IFn; if linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; var arg_486 any; var t_ any = t.F_f; t.F_f = nil; arg_486 = t_; if linked_484 == nil { tmp3 = ifn_485.Invoke_O__O(arg_486) } else { tmp3 = linked_484.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_483, arg_486) }; var tmp4 any = tmp3; var tmp5 any; var root_487 any = A_arbace_repr_clojure_A_const_87.GetRawRoot__O(); var linked_488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_487, aot_arbace_core.A_arbace_core_ex_message_A_fn_class); var ifn_489 lang.IFn; if linked_488 == nil { ifn_489 = lang.IFn_Cast(root_487) } else { ifn_489 = nil }; var arg_490 any; var t__2 any = t.F_e; t.F_e = nil; arg_490 = t__2; if linked_488 == nil { tmp5 = ifn_489.Invoke_O__O(arg_490) } else { tmp5 = linked_488.(*aot_arbace_core.A_arbace_core_ex_message_A).Invoke_O_O__O(root_487, arg_490) }; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_101, tmp4, Lit_45, tmp5) }; return nil }(); var root_491 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); var linked_492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_491, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_493 lang.IFn; if linked_492 == nil { ifn_493 = lang.IFn_Cast(root_491) } else { ifn_493 = nil }; if linked_492 == nil { ifn_493.Invoke__O() } else { linked_492.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_491) }; if tmp6 != nil { panic(tmp6) }; return tmp1 }
//line :199:1
func A_arbace_repr_clojure_run_fn__716000074_fn__716000075_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_run_fn__716000074_fn__716000075_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000074_fn__716000075_A{}; t.Ctor_O_O(p0, p1); return t }
//line :199:1
func (t *A_arbace_repr_clojure_run_fn__716000074_fn__716000075_A) Ctor_O_O(c__e, c__f any) { t.F_e = c__e; t.F_f = c__f }
//line :199:1
func (t *A_arbace_repr_clojure_run_fn__716000074_fn__716000075_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp3 any; var root_640 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_641 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_640, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_642 lang.IFn; if linked_641 == nil { ifn_642 = lang.IFn_Cast(root_640) } else { ifn_642 = nil }; var arg_643 any; var t_ any = t.F_f; t.F_f = nil; arg_643 = t_; if linked_641 == nil { tmp3 = ifn_642.Invoke_O__O(arg_643) } else { tmp3 = linked_641.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_640, arg_643) }; var tmp4 any = tmp3; var tmp5 any; var root_644 any = A_arbace_repr_clojure_A_const_87.GetRawRoot__O(); var linked_645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_644, aot_arbace_core.A_arbace_core_ex_message_A_fn_class); var ifn_646 lang.IFn; if linked_645 == nil { ifn_646 = lang.IFn_Cast(root_644) } else { ifn_646 = nil }; var arg_647 any; var t__2 any = t.F_e; t.F_e = nil; arg_647 = t__2; if linked_645 == nil { tmp5 = ifn_646.Invoke_O__O(arg_647) } else { tmp5 = linked_645.(*aot_arbace_core.A_arbace_core_ex_message_A).Invoke_O_O__O(root_644, arg_647) }; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_101, tmp4, Lit_45, tmp5) }; return nil }(); var root_648 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); var linked_649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_648, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_650 lang.IFn; if linked_649 == nil { ifn_650 = lang.IFn_Cast(root_648) } else { ifn_650 = nil }; if linked_649 == nil { ifn_650.Invoke__O() } else { linked_649.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_648) }; if tmp6 != nil { panic(tmp6) }; return tmp1 }
//line :199:1
func A_arbace_repr_clojure_run_fn__716000083_fn__716000084_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_run_fn__716000083_fn__716000084_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000083_fn__716000084_A{}; t.Ctor_O_O(p0, p1); return t }
//line :199:1
func (t *A_arbace_repr_clojure_run_fn__716000083_fn__716000084_A) Ctor_O_O(c__e, c__f any) { t.F_e = c__e; t.F_f = c__f }
//line :199:1
func (t *A_arbace_repr_clojure_run_fn__716000083_fn__716000084_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp3 any; var root_829 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_830 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_829, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_831 lang.IFn; if linked_830 == nil { ifn_831 = lang.IFn_Cast(root_829) } else { ifn_831 = nil }; var arg_832 any; var t_ any = t.F_f; t.F_f = nil; arg_832 = t_; if linked_830 == nil { tmp3 = ifn_831.Invoke_O__O(arg_832) } else { tmp3 = linked_830.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_829, arg_832) }; var tmp4 any = tmp3; var tmp5 any; var root_833 any = A_arbace_repr_clojure_A_const_87.GetRawRoot__O(); var linked_834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_833, aot_arbace_core.A_arbace_core_ex_message_A_fn_class); var ifn_835 lang.IFn; if linked_834 == nil { ifn_835 = lang.IFn_Cast(root_833) } else { ifn_835 = nil }; var arg_836 any; var t__2 any = t.F_e; t.F_e = nil; arg_836 = t__2; if linked_834 == nil { tmp5 = ifn_835.Invoke_O__O(arg_836) } else { tmp5 = linked_834.(*aot_arbace_core.A_arbace_core_ex_message_A).Invoke_O_O__O(root_833, arg_836) }; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_101, tmp4, Lit_45, tmp5) }; return nil }(); var root_837 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); var linked_838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_837, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_839 lang.IFn; if linked_838 == nil { ifn_839 = lang.IFn_Cast(root_837) } else { ifn_839 = nil }; if linked_838 == nil { ifn_839.Invoke__O() } else { linked_838.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_837) }; if tmp6 != nil { panic(tmp6) }; return tmp1 }
//line :199:1
func A_arbace_repr_clojure_run_fn__716000092_fn__716000093_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_run_fn__716000092_fn__716000093_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000092_fn__716000093_A{}; t.Ctor_O_O(p0, p1); return t }
//line :199:1
func (t *A_arbace_repr_clojure_run_fn__716000092_fn__716000093_A) Ctor_O_O(c__e, c__f any) { t.F_e = c__e; t.F_f = c__f }
//line :199:1
func (t *A_arbace_repr_clojure_run_fn__716000092_fn__716000093_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp3 any; var root_986 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_987 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_986, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_988 lang.IFn; if linked_987 == nil { ifn_988 = lang.IFn_Cast(root_986) } else { ifn_988 = nil }; var arg_989 any; var t_ any = t.F_f; t.F_f = nil; arg_989 = t_; if linked_987 == nil { tmp3 = ifn_988.Invoke_O__O(arg_989) } else { tmp3 = linked_987.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_986, arg_989) }; var tmp4 any = tmp3; var tmp5 any; var root_990 any = A_arbace_repr_clojure_A_const_87.GetRawRoot__O(); var linked_991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_990, aot_arbace_core.A_arbace_core_ex_message_A_fn_class); var ifn_992 lang.IFn; if linked_991 == nil { ifn_992 = lang.IFn_Cast(root_990) } else { ifn_992 = nil }; var arg_993 any; var t__2 any = t.F_e; t.F_e = nil; arg_993 = t__2; if linked_991 == nil { tmp5 = ifn_992.Invoke_O__O(arg_993) } else { tmp5 = linked_991.(*aot_arbace_core.A_arbace_core_ex_message_A).Invoke_O_O__O(root_990, arg_993) }; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_101, tmp4, Lit_45, tmp5) }; return nil }(); var root_994 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); var linked_995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_994, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_996 lang.IFn; if linked_995 == nil { ifn_996 = lang.IFn_Cast(root_994) } else { ifn_996 = nil }; if linked_995 == nil { ifn_996.Invoke__O() } else { linked_995.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_994) }; if tmp6 != nil { panic(tmp6) }; return tmp1 }














func A_arbace_repr_clojure_tree_A_New() *A_arbace_repr_clojure_tree_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_tree_A{}; t.Ctor(); return t }
//line :214:1
func (t *A_arbace_repr_clojure_tree_A) Ctor() {}
//line :214:1
func (t *A_arbace_repr_clojure_tree_A) Invoke_O_O__O(self, sources__0 any) any {


	var root_1101 any = A_arbace_repr_clojure_A_const_100.GetRawRoot__O(); var linked_1102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1101, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1103 lang.IFn; if linked_1102 == nil { ifn_1103 = lang.IFn_Cast(root_1101) } else { ifn_1103 = nil }; var arg_1104 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_101.GetRawRoot__O()).Invoke__O(); var arg_1105 any; var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_repr_clojure_tree_iter__716000097__716000103_A_New(); var tmp2 *jrt.Class; var fncls__1212 *jrt.Class = A_arbace_repr_clojure_tree_iter__716000097__716000103_A_fn_class
	if fncls__1212 == nil { var fncls__1212d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_122, false); A_arbace_repr_clojure_tree_iter__716000097__716000103_A_fn_class = fncls__1212d; tmp2 = fncls__1212d } else { tmp2 = fncls__1212 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_1105 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(sources__0)
//line :217:1
	if linked_1102 == nil { return ifn_1103.Invoke_O_O__O(arg_1104, arg_1105) } else { return linked_1102.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1101, arg_1104, arg_1105) } }
func A_arbace_repr_clojure_tree_iter__716000097__716000103_A_New() *A_arbace_repr_clojure_tree_iter__716000097__716000103_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_tree_iter__716000097__716000103_A{}; t.Ctor(); return t }
//line :218:1
func (t *A_arbace_repr_clojure_tree_iter__716000097__716000103_A) Ctor() {}
//line :218:1
func (t *A_arbace_repr_clojure_tree_iter__716000097__716000103_A) Invoke_O_O__O(self, s__716000098__1 any) any { var tmp1 any = A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_A_New_O_O(self, s__716000098__1); var tmp2 *jrt.Class; var fncls__1211 *jrt.Class = A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_A_fn_class; if fncls__1211 == nil { var fncls__1211d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_123, false); A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_A_fn_class = fncls__1211d; tmp2 = fncls__1211d } else { tmp2 = fncls__1211 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :218:1
func A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_A{}; t.Ctor_O_O(p0, p1); return t }
//line :218:1
func (t *A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_A) Ctor_O_O(c__iter__716000097, c__s__716000098 any) { t.F_iter__716000097 = c__iter__716000097; t.F_s__716000098 = c__s__716000098 }
//line :218:1
func (t *A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_A) Invoke_O__O(self any) any { { var s__716000098__1 any; var t_ any = t.F_s__716000098; t.F_s__716000098 = nil; s__716000098__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1109 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_1110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1109, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1111 lang.IFn; if linked_1110 == nil { ifn_1111 = lang.IFn_Cast(root_1109) } else { ifn_1111 = nil }; var arg_1112 any = s__716000098__1; if linked_1110 == nil { temp__1927000414__auto____2 = ifn_1111.Invoke_O__O(arg_1112) } else { temp__1927000414__auto____2 = linked_1110.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1109, arg_1112) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var src__4 any; var root_1113 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_1114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1113, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1115 lang.IFn; if linked_1114 == nil { ifn_1115 = lang.IFn_Cast(root_1113) } else { ifn_1115 = nil }; var arg_1116 any = xs__1927001018__auto____3; if linked_1114 == nil { src__4 = ifn_1115.Invoke_O__O(arg_1116) } else { src__4 = linked_1114.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1113, arg_1116) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_A_New(); var tmp2 *jrt.Class; var fncls__1185 *jrt.Class = A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_A_fn_class; if fncls__1185 == nil { var fncls__1185d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_124, false); A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_A_fn_class = fncls__1185d; tmp2 = fncls__1185d } else { tmp2 = fncls__1185 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_1186 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_1187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1186, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1188 lang.IFn; if linked_1187 == nil { ifn_1188 = lang.IFn_Cast(root_1186) } else { ifn_1188 = nil }; var arg_1189 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var root_1190 any = A_arbace_repr_clojure_A_const_77.GetRawRoot__O(); var linked_1191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1190, A_arbace_repr_clojure_files_A_fn_class); var ifn_1192 lang.IFn; if linked_1191 == nil { ifn_1192 = lang.IFn_Cast(root_1190) } else { ifn_1192 = nil }; var arg_1193 any; var root_1194 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_1195 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1194, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_1196 lang.IFn; if linked_1195 == nil { ifn_1196 = lang.IFn_Cast(root_1194) } else { ifn_1196 = nil }; var arg_1197 any = src__4; if linked_1195 == nil { arg_1193 = ifn_1196.Invoke_O__O(arg_1197) } else { arg_1193 = linked_1195.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_1194, arg_1197) }; if linked_1191 == nil { tmp4 = ifn_1192.Invoke_O__O(arg_1193) } else { tmp4 = linked_1191.(*A_arbace_repr_clojure_files_A).Invoke_O_O__O(root_1190, arg_1193) }; arg_1189 = tmp3.Invoke_O__O(tmp4); if linked_1187 == nil { fs__1927001036__auto____6 = ifn_1188.Invoke_O__O(arg_1189) } else { fs__1927001036__auto____6 = linked_1187.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1186, arg_1189) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_1198 any = A_arbace_repr_clojure_A_const_102.GetRawRoot__O(); var linked_1199 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1198, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1200 lang.IFn; if linked_1199 == nil { ifn_1200 = lang.IFn_Cast(root_1198) } else { ifn_1200 = nil }; var arg_1201 any = fs__1927001036__auto____6; var arg_1202 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__716000097); var tmp6 any; var root_1203 any = A_arbace_repr_clojure_A_const_67.GetRawRoot__O(); var linked_1204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1203, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1205 lang.IFn; if linked_1204 == nil { ifn_1205 = lang.IFn_Cast(root_1203) } else { ifn_1205 = nil }; var arg_1206 any = s__716000098__1; if linked_1204 == nil { tmp6 = ifn_1205.Invoke_O__O(arg_1206) } else { tmp6 = linked_1204.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1203, arg_1206) }; arg_1202 = tmp5.Invoke_O__O(tmp6); if linked_1199 == nil { return ifn_1200.Invoke_O_O__O(arg_1201, arg_1202) } else { return linked_1199.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1198, arg_1201, arg_1202) } } else { var tmp7 any; var root_1207 any = A_arbace_repr_clojure_A_const_67.GetRawRoot__O(); var linked_1208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1207, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1209 lang.IFn; if linked_1208 == nil { ifn_1209 = lang.IFn_Cast(root_1207) } else { ifn_1209 = nil }; var arg_1210 any = s__716000098__1; if linked_1208 == nil { tmp7 = ifn_1209.Invoke_O__O(arg_1210) } else { tmp7 = linked_1208.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1207, arg_1210) }; s__716000098__1 = tmp7; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :218:1
func A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_A_New() *A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_A{}; t.Ctor(); return t }
//line :218:1
func (t *A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_A) Ctor() {}
//line :218:1
func (t *A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_A) Invoke_O_O__O(self, s__716000100__1 any) any { var tmp1 any = A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_A_New_O_O(self, s__716000100__1); var tmp2 *jrt.Class; var fncls__1184 *jrt.Class = A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_A_fn_class; if fncls__1184 == nil { var fncls__1184d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_125, false); A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_A_fn_class = fncls__1184d; tmp2 = fncls__1184d } else { tmp2 = fncls__1184 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :218:1
func A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_A{}; t.Ctor_O_O(p0, p1); return t }
//line :218:1
func (t *A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_A) Ctor_O_O(c__iter__716000099, c__s__716000100 any) { t.F_iter__716000099 = c__iter__716000099; t.F_s__716000100 = c__s__716000100 }
//line :218:1
func (t *A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_A) Invoke_O__O(self any) any { { var s__716000100__1 any; var t_ any = t.F_s__716000100; t.F_s__716000100 = nil; s__716000100__1 = t_; for { var temp__1927000414__auto____2 any; var root_1117 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_1118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1117, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1119 lang.IFn; if linked_1118 == nil { ifn_1119 = lang.IFn_Cast(root_1117) } else { ifn_1119 = nil }; var arg_1120 any = s__716000100__1; if linked_1118 == nil { temp__1927000414__auto____2 = ifn_1119.Invoke_O__O(arg_1120) } else { temp__1927000414__auto____2 = linked_1118.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1117, arg_1120) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__716000100__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1121 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_1122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1121, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1123 lang.IFn; if linked_1122 == nil { ifn_1123 = lang.IFn_Cast(root_1121) } else { ifn_1123 = nil }; var arg_1124 any = s__716000100__3; if linked_1122 == nil { tmp1 = ifn_1123.Invoke_O__O(arg_1124) } else { tmp1 = linked_1122.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1121, arg_1124) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1125 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_1126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1125, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1127 lang.IFn; if linked_1126 == nil { ifn_1127 = lang.IFn_Cast(root_1125) } else { ifn_1127 = nil }; var arg_1128 any = s__716000100__3; if linked_1126 == nil { c__1927001037__auto____4 = ifn_1127.Invoke_O__O(arg_1128) } else { c__1927001037__auto____4 = linked_1126.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1125, arg_1128) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__716000102__6 any; var root_1129 any = A_arbace_repr_clojure_A_const_60.GetRawRoot__O(); var linked_1130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1129, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1131 lang.IFn; if linked_1130 == nil { ifn_1131 = lang.IFn_Cast(root_1129) } else { ifn_1131 = nil }; var arg_1132 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1130 == nil { b__716000102__6 = ifn_1131.Invoke_O__O(arg_1132) } else { b__716000102__6 = linked_1130.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1129, arg_1132) }; var tmp2 any = A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_fn__716000107_A_New_O_I_O(b__716000102__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1143 *jrt.Class = A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_fn__716000107_A_fn_class; if fncls__1143 == nil { var fncls__1143d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_126, false); A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_fn__716000107_A_fn_class = fncls__1143d; tmp3 = fncls__1143d } else { tmp3 = fncls__1143 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1144 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_1145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1144, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1146 lang.IFn; if linked_1145 == nil { ifn_1146 = lang.IFn_Cast(root_1144) } else { ifn_1146 = nil }; var arg_1147 any; var root_1149 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_1150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1149, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1151 lang.IFn; if linked_1150 == nil { ifn_1151 = lang.IFn_Cast(root_1149) } else { ifn_1151 = nil }; var arg_1152 any = b__716000102__6; if linked_1150 == nil { arg_1147 = ifn_1151.Invoke_O__O(arg_1152) } else { arg_1147 = linked_1150.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1149, arg_1152) }; var arg_1148 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__716000099); var tmp5 any; var root_1153 any = A_arbace_repr_clojure_A_const_65.GetRawRoot__O(); var linked_1154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1153, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1155 lang.IFn; if linked_1154 == nil { ifn_1155 = lang.IFn_Cast(root_1153) } else { ifn_1155 = nil }; var arg_1156 any = s__716000100__3; if linked_1154 == nil { tmp5 = ifn_1155.Invoke_O__O(arg_1156) } else { tmp5 = linked_1154.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1153, arg_1156) }; arg_1148 = tmp4.Invoke_O__O(tmp5); if linked_1145 == nil { return ifn_1146.Invoke_O_O__O(arg_1147, arg_1148) } else { return linked_1145.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1144, arg_1147, arg_1148) } } else { var root_1157 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_1158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1157, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1159 lang.IFn; if linked_1158 == nil { ifn_1159 = lang.IFn_Cast(root_1157) } else { ifn_1159 = nil }; var arg_1160 any; var root_1162 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_1163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1162, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1164 lang.IFn; if linked_1163 == nil { ifn_1164 = lang.IFn_Cast(root_1162) } else { ifn_1164 = nil }; var arg_1165 any = b__716000102__6; if linked_1163 == nil { arg_1160 = ifn_1164.Invoke_O__O(arg_1165) } else { arg_1160 = linked_1163.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1162, arg_1165) }; var arg_1161 any; if linked_1158 == nil { return ifn_1159.Invoke_O_O__O(arg_1160, arg_1161) } else { return linked_1158.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1157, arg_1160, arg_1161) } } } else { var vec__716000112__4 any; var root_1166 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_1167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1166, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1168 lang.IFn; if linked_1167 == nil { ifn_1168 = lang.IFn_Cast(root_1166) } else { ifn_1168 = nil }; var arg_1169 any = s__716000100__3; if linked_1167 == nil { vec__716000112__4 = ifn_1168.Invoke_O__O(arg_1169) } else { vec__716000112__4 = linked_1167.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1166, arg_1169) }; var dir__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000112__4, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000112__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1170 any = A_arbace_repr_clojure_A_const_66.GetRawRoot__O(); var linked_1171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1170, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1172 lang.IFn; if linked_1171 == nil { ifn_1172 = lang.IFn_Cast(root_1170) } else { ifn_1172 = nil }; var arg_1173 any; var tmp6 any; var root_1175 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_1176 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1175, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_1177 lang.IFn; if linked_1176 == nil { ifn_1177 = lang.IFn_Cast(root_1175) } else { ifn_1177 = nil }; var arg_1178 any = dir__5; var arg_1179 any = rel__6; if linked_1176 == nil { tmp6 = ifn_1177.Invoke_O_O__O(arg_1178, arg_1179) } else { tmp6 = linked_1176.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_1175, arg_1178, arg_1179) }; arg_1173 = lang.Tuple_Create_O_O__IPersistentVector(rel__6, tmp6); var arg_1174 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__716000099); var tmp8 any; var root_1180 any = A_arbace_repr_clojure_A_const_67.GetRawRoot__O(); var linked_1181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1180, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1182 lang.IFn; if linked_1181 == nil { ifn_1182 = lang.IFn_Cast(root_1180) } else { ifn_1182 = nil }; var arg_1183 any = s__716000100__3; if linked_1181 == nil { tmp8 = ifn_1182.Invoke_O__O(arg_1183) } else { tmp8 = linked_1181.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1180, arg_1183) }; arg_1174 = tmp7.Invoke_O__O(tmp8); if linked_1171 == nil { return ifn_1172.Invoke_O_O__O(arg_1173, arg_1174) } else { return linked_1171.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1170, arg_1173, arg_1174) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :218:1
func A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_fn__716000107_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_fn__716000107_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_fn__716000107_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :218:1
func (t *A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_fn__716000107_A) Ctor_O_I_O(c__b__716000102 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__716000102 = c__b__716000102; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :218:1
func (t *A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_fn__716000107_A) Invoke_O__O(self any) any { { var i__716000101__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__716000101__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__716000108__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__716000101__1)); var dir__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000108__2, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000108__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1133 any = A_arbace_repr_clojure_A_const_61.GetRawRoot__O(); var linked_1134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1133, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1135 lang.IFn; if linked_1134 == nil { ifn_1135 = lang.IFn_Cast(root_1133) } else { ifn_1135 = nil }; var arg_1136 any = t.F_b__716000102; var arg_1137 any; var tmp2 any; var root_1138 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_1139 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1138, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_1140 lang.IFn; if linked_1139 == nil { ifn_1140 = lang.IFn_Cast(root_1138) } else { ifn_1140 = nil }; var arg_1141 any = dir__3; var arg_1142 any = rel__4; if linked_1139 == nil { tmp2 = ifn_1140.Invoke_O_O__O(arg_1141, arg_1142) } else { tmp2 = linked_1139.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_1138, arg_1141, arg_1142) }; arg_1137 = lang.Tuple_Create_O_O__IPersistentVector(rel__4, tmp2); if linked_1134 == nil { ifn_1135.Invoke_O_O__O(arg_1136, arg_1137) } else { linked_1134.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1133, arg_1136, arg_1137) }; i__716000101__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__716000101__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_repr_clojure_parent_of_A_New() *A_arbace_repr_clojure_parent_of_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_parent_of_A{}; t.Ctor(); return t }
//line :220:1
func (t *A_arbace_repr_clojure_parent_of_A) Ctor() {}
//line :220:1
func (t *A_arbace_repr_clojure_parent_of_A) Invoke_O_O__O(self, rel__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(rel__0)).LastIndexOf_String__I(Lit_29); if lang.Numbers_IsPos_J__Z_NoInit(int64(i__2)) { var root_1213 any = A_arbace_repr_clojure_A_const_12.GetRawRoot__O(); var linked_1214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1213, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1215 lang.IFn; if linked_1214 == nil { ifn_1215 = lang.IFn_Cast(root_1213) } else { ifn_1215 = nil }; var arg_1216 any = rel__0; var arg_1217 any = A_arbace_repr_clojure_A_const_13; var arg_1218 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref(); if linked_1214 == nil { return ifn_1215.Invoke_O_O_O__O(arg_1216, arg_1217, arg_1218) } else { return linked_1214.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1213, arg_1216, arg_1217, arg_1218) } } else { return nil } }
func A_arbace_repr_clojure_name_of_A_New() *A_arbace_repr_clojure_name_of_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_name_of_A{}; t.Ctor(); return t }
//line :221:1
func (t *A_arbace_repr_clojure_name_of_A) Ctor() {}
//line :221:1
func (t *A_arbace_repr_clojure_name_of_A) Invoke_O_O__O(self, rel__0 any) any { var root_1219 any = A_arbace_repr_clojure_A_const_12.GetRawRoot__O(); var linked_1220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1219, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1221 lang.IFn; if linked_1220 == nil { ifn_1221 = lang.IFn_Cast(root_1219) } else { ifn_1221 = nil }; var arg_1222 any = rel__0; var arg_1223 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(jrt.NN(jrt.String_Cast(rel__0)).LastIndexOf_String__I(Lit_29)))).Ref(); if linked_1220 == nil { return ifn_1221.Invoke_O_O__O(arg_1222, arg_1223) } else { return linked_1220.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1219, arg_1222, arg_1223) } }
func A_arbace_repr_clojure_under_A_New() *A_arbace_repr_clojure_under_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_under_A{}; t.Ctor(); return t }
//line :222:1
func (t *A_arbace_repr_clojure_under_A) Ctor() {}
//line :222:1
func (t *A_arbace_repr_clojure_under_A) Invoke_O_O_O__O(self, d__0, n__1 any) any { if jrt.J2g_Truth(d__0) { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_29, nil), jrt.RefArrayOf(jrt.Object_class, d__0, nil, n__1)).Ref() } else { return n__1 } }

func A_arbace_repr_clojure_half_A_New() *A_arbace_repr_clojure_half_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_half_A{}; t.Ctor(); return t }
//line :224:1
func (t *A_arbace_repr_clojure_half_A) Ctor() {}
//line :224:1
func (t *A_arbace_repr_clojure_half_A) Invoke_O_O_O_O__O(self, verb__0, t__1, opts__2 any) any { var map__716000123__4 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_69.GetRawRoot__O()).Invoke_O__O(verb__0); var map__716000123__5 any; if






	lang.ISeq_InstanceOf(map__716000123__4) { var tmp1 any; var root_1224 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_1225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1224, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1226 lang.IFn; if linked_1225 == nil { ifn_1226 = lang.IFn_Cast(root_1224) } else { ifn_1226 = nil }; var arg_1227 any = map__716000123__4; if linked_1225 == nil { tmp1 = ifn_1226.Invoke_O__O(arg_1227) } else { tmp1 = linked_1225.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1224, arg_1227) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1228 any = A_arbace_repr_clojure_A_const_15.GetRawRoot__O(); var linked_1229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1228, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1230 lang.IFn; if linked_1229 == nil { ifn_1230 = lang.IFn_Cast(root_1228) } else { ifn_1230 = nil }; var arg_1231 any = map__716000123__4; if linked_1229 == nil { tmp2 = ifn_1230.Invoke_O__O(arg_1231) } else { tmp2 = linked_1229.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1228, arg_1231) }; map__716000123__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_1232 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_1233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1232, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1234 lang.IFn; if linked_1233 == nil { ifn_1234 = lang.IFn_Cast(root_1232) } else { ifn_1234 = nil }; var arg_1235 any = map__716000123__4; if linked_1233 == nil { tmp3 = ifn_1234.Invoke_O__O(arg_1235) } else { tmp3 = linked_1233.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1232, arg_1235) }; if jrt.J2g_Truth(tmp3) { var root_1236 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_1237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1236, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1238 lang.IFn; if linked_1237 == nil { ifn_1238 = lang.IFn_Cast(root_1236) } else { ifn_1238 = nil }; var arg_1239 any = map__716000123__4; if linked_1237 == nil { map__716000123__5 = ifn_1238.Invoke_O__O(arg_1239) } else { map__716000123__5 = linked_1237.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1236, arg_1239) } } else { map__716000123__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__716000123__5 = map__716000123__4 }; var plan__6 any = /*line :224:1*/lang.RT_Get_O_O__O_NoInit(map__716000123__5, A_arbace_repr_clojure_A_const_70); var translate_text__7 any = lang.RT_Get_O_O__O_NoInit(map__716000123__5, A_arbace_repr_clojure_A_const_19); var refine__8 any = lang.RT_Get_O_O__O_NoInit(map__716000123__5, A_arbace_repr_clojure_A_const_71); var dirs__9 any; var root_1240 any = A_arbace_repr_clojure_A_const_103.GetRawRoot__O(); var linked_1241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1240, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1242 lang.IFn; if







	linked_1241 == nil { ifn_1242 = lang.IFn_Cast(root_1240) } else { ifn_1242 = nil }; var arg_1243 any; var tmp4 any = A_arbace_repr_clojure_half_fn__716000125_A_New(); var tmp5 *jrt.Class; var fncls__1266 *jrt.Class = A_arbace_repr_clojure_half_fn__716000125_A_fn_class; if fncls__1266 == nil { var fncls__1266d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_repr_clojure_half_fn__716000125_A_fn_class = fncls__1266d; tmp5 = fncls__1266d } else { tmp5 = fncls__1266 }; arg_1243 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_1244 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1245 any; var root_1267 any = A_arbace_repr_clojure_A_const_107.GetRawRoot__O(); var linked_1268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1267, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_1269 lang.IFn; if linked_1268 == nil { ifn_1269 = lang.IFn_Cast(root_1267) } else { ifn_1269 = nil }; var arg_1270 any = t__1; if linked_1268 == nil { arg_1245 = ifn_1269.Invoke_O__O(arg_1270) } else { arg_1245 = linked_1268.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_1267, arg_1270) }; if linked_1241 == nil { dirs__9 = ifn_1242.Invoke_O_O_O__O(arg_1243, arg_1244, arg_1245) } else { dirs__9 = linked_1241.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1240, arg_1243, arg_1244, arg_1245) }; var root_1271 any =
	A_arbace_repr_clojure_A_const_103.GetRawRoot__O(); var linked_1272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1271, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1273 lang.IFn; if linked_1272 == nil { ifn_1273 = lang.IFn_Cast(root_1271) } else { ifn_1273 = nil }; var arg_1274 any; var tmp6 any = A_arbace_repr_clojure_half_fn__716000128_A_New(); var tmp7 *jrt.Class; var fncls__1320 *jrt.Class = A_arbace_repr_clojure_half_fn__716000128_A_fn_class; if fncls__1320 == nil { var fncls__1320d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_repr_clojure_half_fn__716000128_A_fn_class = fncls__1320d; tmp7 = fncls__1320d } else { tmp7 = fncls__1320 }; arg_1274 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp8 any = A_arbace_repr_clojure_A_const_109; var arg_1275 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, lang.IFn_Cast(A_arbace_repr_clojure_A_const_101.GetRawRoot__O()).Invoke__O(), A_arbace_repr_clojure_A_const_112, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_repr_clojure_A_const_113, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_repr_clojure_A_const_86, lang.PersistentArrayMap_EMPTY.Ref())); var arg_1276 any; var root_1324 any = A_arbace_repr_clojure_A_const_115.GetRawRoot__O(); var linked_1325 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1324, aot_arbace_core.A_arbace_core_pmap_A_fn_class); var ifn_1326 lang.IFn; if









	linked_1325 == nil { ifn_1326 = lang.IFn_Cast(root_1324) } else { ifn_1326 = nil }; var arg_1327 any; var tmp9 any = A_arbace_repr_clojure_half_fn__716000134_A_New_O_O_O_O_O(plan__6, refine__8, translate_text__7, opts__2, dirs__9); var tmp10 *jrt.Class; var fncls__1354 *jrt.Class = A_arbace_repr_clojure_half_fn__716000134_A_fn_class; if fncls__1354 == nil { var fncls__1354d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_repr_clojure_half_fn__716000134_A_fn_class = fncls__1354d; tmp10 = fncls__1354d } else { tmp10 = fncls__1354 }; arg_1327 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var arg_1328 any = t__1; if linked_1325 == nil { arg_1276 = ifn_1326.Invoke_O_O__O(arg_1327, arg_1328) } else { arg_1276 = linked_1325.(*aot_arbace_core.A_arbace_core_pmap_A).Invoke_O_O_O__O(root_1324, arg_1327, arg_1328) }; if /*line :233:1*/ linked_1272 == nil { return ifn_1273.Invoke_O_O_O__O(arg_1274, arg_1275, arg_1276) } else { return linked_1272.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1271, arg_1274, arg_1275, arg_1276) } }
//line :232:1
func A_arbace_repr_clojure_half_fn__716000125_A_New() *A_arbace_repr_clojure_half_fn__716000125_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_half_fn__716000125_A{}; t.Ctor(); return t }
//line :232:1
func (t *A_arbace_repr_clojure_half_fn__716000125_A) Ctor() {}
//line :232:1
func (t *A_arbace_repr_clojure_half_fn__716000125_A) Invoke_O_O_O__O(self, m__1, rel__2 any) any { var root_1246 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var linked_1247 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1246, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1248 lang.IFn; if linked_1247 == nil { ifn_1248 = lang.IFn_Cast(root_1246) } else { ifn_1248 = nil }; var arg_1249 any = m__1; var arg_1250 any; var root_1253 any = A_arbace_repr_clojure_A_const_104.GetRawRoot__O(); var linked_1254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1253, A_arbace_repr_clojure_parent_of_A_fn_class); var ifn_1255 lang.IFn; if linked_1254 == nil { ifn_1255 = lang.IFn_Cast(root_1253) } else { ifn_1255 = nil }; var arg_1256 any = rel__2; if linked_1254 == nil { arg_1250 = ifn_1255.Invoke_O__O(arg_1256) } else { arg_1250 = linked_1254.(*A_arbace_repr_clojure_parent_of_A).Invoke_O_O__O(root_1253, arg_1256) }; var arg_1251 any; var root_1257 any = A_arbace_repr_clojure_A_const_105.GetRawRoot__O(); var linked_1258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1257, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_1259 lang.IFn; if linked_1258 == nil { ifn_1259 = lang.IFn_Cast(root_1257) } else { ifn_1259 = nil }; var arg_1260 any = A_arbace_repr_clojure_A_const_10.GetRawRoot__O(); var arg_1261 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_1258 == nil { arg_1251 = ifn_1259.Invoke_O_O__O(arg_1260, arg_1261) } else { arg_1251 = linked_1258.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_1257, arg_1260, arg_1261) }; var arg_1252 any; var root_1262 any = A_arbace_repr_clojure_A_const_106.GetRawRoot__O(); var linked_1263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1262, A_arbace_repr_clojure_name_of_A_fn_class); var ifn_1264 lang.IFn; if linked_1263 == nil { ifn_1264 = lang.IFn_Cast(root_1262) } else { ifn_1264 = nil }; var arg_1265 any = rel__2; if linked_1263 == nil { arg_1252 = ifn_1264.Invoke_O__O(arg_1265) } else { arg_1252 = linked_1263.(*A_arbace_repr_clojure_name_of_A).Invoke_O_O__O(root_1262, arg_1265) }; if linked_1247 == nil { return ifn_1248.Invoke_O_O_O_O__O(arg_1249, arg_1250, arg_1251, arg_1252) } else { return linked_1247.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1246, arg_1249, arg_1250, arg_1251, arg_1252) } }
func A_arbace_repr_clojure_half_fn__716000128_A_New() *A_arbace_repr_clojure_half_fn__716000128_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_half_fn__716000128_A{}; t.Ctor(); return t }
//line :233:1
func (t *A_arbace_repr_clojure_half_fn__716000128_A) Ctor() {}
//line :233:1
func (t *A_arbace_repr_clojure_half_fn__716000128_A) Invoke_O_O_O__O(self, acc__1, p__716000127__2 any) any { var vec__716000129__3 any = p__716000127__2; var rel__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000129__3, lang.RT_IntCast_J__I_NoInit(0), nil); var x__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000129__3, lang.RT_IntCast_J__I_NoInit(1), nil); var p__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000129__3, lang.RT_IntCast_J__I_NoInit(2), nil); var r__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000129__3, lang.RT_IntCast_J__I_NoInit(3), nil); if
														jrt.J2g_Truth(A_arbace_repr_clojure_A_const_33.Invoke_O__O(p__6)) { return acc__1 } else { if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_81.Invoke_O__O(p__6)) {
															var root_1277 any = A_arbace_repr_clojure_A_const_108.GetRawRoot__O(); var linked_1278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1277, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1279 lang.IFn; if linked_1278 == nil { ifn_1279 = lang.IFn_Cast(root_1277) } else { ifn_1279 = nil }; var arg_1280 any = acc__1; var arg_1281 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_clojure_A_const_109, rel__4); var arg_1282 any = x__5; if linked_1278 == nil { return ifn_1279.Invoke_O_O_O__O(arg_1280, arg_1281, arg_1282) } else { return linked_1278.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1277, arg_1280, arg_1281, arg_1282) } } else {
//line :234:1
			if A_arbace_repr_clojure_A_const_34 != nil { var out__8 any; var root_1283 any = A_arbace_repr_clojure_A_const_110.GetRawRoot__O(); var linked_1284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1283, A_arbace_repr_clojure_under_A_fn_class); var ifn_1285 lang.IFn

				if linked_1284 == nil { ifn_1285 = lang.IFn_Cast(root_1283) } else { ifn_1285 = nil }; var arg_1286 any; var root_1288 any = A_arbace_repr_clojure_A_const_104.GetRawRoot__O(); var linked_1289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1288, A_arbace_repr_clojure_parent_of_A_fn_class); var ifn_1290 lang.IFn; if linked_1289 == nil { ifn_1290 = lang.IFn_Cast(root_1288) } else { ifn_1290 = nil }; var arg_1291 any = rel__4; if linked_1289 == nil { arg_1286 = ifn_1290.Invoke_O__O(arg_1291) } else { arg_1286 = linked_1289.(*A_arbace_repr_clojure_parent_of_A).Invoke_O_O__O(root_1288, arg_1291) }; var arg_1287 any = A_arbace_repr_clojure_A_const_28.Invoke_O__O(p__6); if linked_1284 == nil { out__8 = ifn_1285.Invoke_O_O__O(arg_1286, arg_1287) } else { out__8 = linked_1284.(*A_arbace_repr_clojure_under_A).Invoke_O_O_O__O(root_1283, arg_1286, arg_1287) }
				var tmp1 any; var root_1292 any = A_arbace_repr_clojure_A_const_111.GetRawRoot__O(); var linked_1293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1292, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1294 lang.IFn; if linked_1293 == nil { ifn_1294 = lang.IFn_Cast(root_1292) } else { ifn_1294 = nil }; var arg_1295 any = r__7; if linked_1293 == nil { tmp1 = ifn_1294.Invoke_O__O(arg_1295) } else { tmp1 = linked_1293.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1292, arg_1295) }; if jrt.J2g_Truth(tmp1) {

					var root_1296 any = A_arbace_repr_clojure_A_const_108.GetRawRoot__O(); var linked_1297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1296, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1298 lang.IFn; if linked_1297 == nil { ifn_1298 = lang.IFn_Cast(root_1296) } else { ifn_1298 = nil }; var arg_1299 any; var root_1302 any = A_arbace_repr_clojure_A_const_108.GetRawRoot__O(); var linked_1303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1302, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1304 lang.IFn
//line :238:1
					if linked_1303 == nil { ifn_1304 = lang.IFn_Cast(root_1302) } else { ifn_1304 = nil }; var arg_1305 any; var root_1308 any = A_arbace_repr_clojure_A_const_108.GetRawRoot__O(); var linked_1309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1308, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1310 lang.IFn; if linked_1309 == nil { ifn_1310 = lang.IFn_Cast(root_1308) } else { ifn_1310 = nil }; var arg_1311 any = acc__1; var arg_1312 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_clojure_A_const_109, out__8); var arg_1313 any = r__7; if linked_1309 == nil { arg_1305 = ifn_1310.Invoke_O_O_O__O(arg_1311, arg_1312, arg_1313) } else { arg_1305 = linked_1309.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1308, arg_1311, arg_1312, arg_1313) }; var arg_1306 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_clojure_A_const_112, out__8); var arg_1307 any = rel__4; if linked_1303 == nil { arg_1299 = ifn_1304.Invoke_O_O_O__O(arg_1305, arg_1306, arg_1307) } else { arg_1299 = linked_1303.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1302, arg_1305, arg_1306, arg_1307) }
					var arg_1300 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_clojure_A_const_113, out__8); var arg_1301 any = p__6; if linked_1297 == nil { return ifn_1298.Invoke_O_O_O__O(arg_1299, arg_1300, arg_1301) } else { return linked_1297.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1296, arg_1299, arg_1300, arg_1301) } } else {
						var root_1314 any = A_arbace_repr_clojure_A_const_108.GetRawRoot__O(); var linked_1315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1314, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1316 lang.IFn; if linked_1315 == nil { ifn_1316 = lang.IFn_Cast(root_1314) } else { ifn_1316 = nil }; var arg_1317 any = acc__1; var arg_1318 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_clojure_A_const_86, rel__4); var arg_1319 any = A_arbace_repr_clojure_A_const_114.Invoke_O__O(r__7); if linked_1315 == nil { return ifn_1316.Invoke_O_O_O__O(arg_1317, arg_1318, arg_1319) } else { return linked_1315.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1314, arg_1317, arg_1318, arg_1319) } } } else {
//line :234:1
							return nil } } } }








func A_arbace_repr_clojure_half_fn__716000134_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_repr_clojure_half_fn__716000134_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_half_fn__716000134_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :243:1
func (t *A_arbace_repr_clojure_half_fn__716000134_A) Ctor_O_O_O_O_O(c__plan, c__refine, c__translate_text, c__opts, c__dirs any) { t.F_plan = c__plan; t.F_refine = c__refine; t.F_translate_text = c__translate_text; t.F_opts = c__opts; t.F_dirs = c__dirs }
//line :243:1
func (t *A_arbace_repr_clojure_half_fn__716000134_A) Invoke_O_O__O(self, p__716000133__1 any) any { var vec__716000135__2 any = p__716000133__1; var rel__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000135__2, lang.RT_IntCast_J__I_NoInit(0), nil); var x__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000135__2, lang.RT_IntCast_J__I_NoInit(1), nil); var sibs__5 any; var tmp1 lang.IFn = lang.IFn_Cast(t.F_dirs); var tmp2 any; var root_1337 any = A_arbace_repr_clojure_A_const_104.GetRawRoot__O(); var linked_1338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1337, A_arbace_repr_clojure_parent_of_A_fn_class); var ifn_1339 lang.IFn; if
													linked_1338 == nil { ifn_1339 = lang.IFn_Cast(root_1337) } else { ifn_1339 = nil }; var arg_1340 any = rel__3; if linked_1338 == nil { tmp2 = ifn_1339.Invoke_O__O(arg_1340) } else { tmp2 = linked_1338.(*A_arbace_repr_clojure_parent_of_A).Invoke_O_O__O(root_1337, arg_1340) }; sibs__5 = tmp1.Invoke_O__O(tmp2); var p0__6 any; var tmp3 lang.IFn = /*line :243:1*/lang.IFn_Cast(t.F_plan); var tmp4 any; var root_1341 any = A_arbace_repr_clojure_A_const_106.GetRawRoot__O(); var linked_1342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1341, A_arbace_repr_clojure_name_of_A_fn_class); var ifn_1343 lang.IFn; if

	linked_1342 == nil { ifn_1343 = lang.IFn_Cast(root_1341) } else { ifn_1343 = nil }; var arg_1344 any = rel__3; if linked_1342 == nil { tmp4 = ifn_1343.Invoke_O__O(arg_1344) } else { tmp4 = linked_1342.(*A_arbace_repr_clojure_name_of_A).Invoke_O_O__O(root_1341, arg_1344) }; p0__6 = tmp3.Invoke_O_O_O__O(tmp4, sibs__5, t.F_opts); var s__7 any; if
	jrt.J2g_Truth(A_arbace_repr_clojure_A_const_24.Invoke_O__O(p0__6)) { var tmp5 any; var root_1329 any = A_arbace_repr_clojure_A_const_111.GetRawRoot__O(); var linked_1330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1329, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1331 lang.IFn; if linked_1330 == nil { ifn_1331 = lang.IFn_Cast(root_1329) } else { ifn_1331 = nil }; var arg_1332 any = x__4; if linked_1330 == nil { tmp5 = ifn_1331.Invoke_O__O(arg_1332) } else { tmp5 = linked_1330.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1329, arg_1332) }; if jrt.J2g_Truth(tmp5) { s__7 = x__4 } else { s__7 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_78.GetRawRoot__O()).Invoke_O__O(x__4) } } else { s__7 = nil }; var p__8 any; if
	jrt.J2g_Truth(s__7) { var tmp6 lang.IFn = lang.IFn_Cast(t.F_refine); var tmp7 any; var root_1345 any = A_arbace_repr_clojure_A_const_106.GetRawRoot__O(); var linked_1346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1345, A_arbace_repr_clojure_name_of_A_fn_class); var ifn_1347 lang.IFn; if linked_1346 == nil { ifn_1347 = lang.IFn_Cast(root_1345) } else { ifn_1347 = nil }; var arg_1348 any = rel__3; if linked_1346 == nil { tmp7 = ifn_1347.Invoke_O__O(arg_1348) } else { tmp7 = linked_1346.(*A_arbace_repr_clojure_name_of_A).Invoke_O_O__O(root_1345, arg_1348) }; p__8 = tmp6.Invoke_O_O_O_O__O(p0__6, tmp7, sibs__5, s__7) } else { p__8 = p0__6 }; var tmp8 any; if
	jrt.J2g_Truth(A_arbace_repr_clojure_A_const_24.Invoke_O__O(p__8)) {
		var tmp9 any = A_arbace_repr_clojure_half_fn__716000134_fn__716000138_A_New_O_O_O_O_O(p__8, s__7, rel__3, t.F_translate_text, t.F_opts); var tmp10 *jrt.Class; var fncls__1353 *jrt.Class = A_arbace_repr_clojure_half_fn__716000134_fn__716000138_A_fn_class; if fncls__1353 == nil { var fncls__1353d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_repr_clojure_half_fn__716000134_fn__716000138_A_fn_class = fncls__1353d; tmp10 = fncls__1353d } else { tmp10 = fncls__1353 }; tmp8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil).Invoke__O() } else {
//line :248:1
			tmp8 = nil }; return /*line :243:1*/ lang.Tuple_Create_O_O_O_O__IPersistentVector(rel__3, x__4, p__8, tmp8) }





func A_arbace_repr_clojure_half_fn__716000134_fn__716000138_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_repr_clojure_half_fn__716000134_fn__716000138_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_half_fn__716000134_fn__716000138_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :249:1
func (t *A_arbace_repr_clojure_half_fn__716000134_fn__716000138_A) Ctor_O_O_O_O_O(c__p, c__s, c__rel, c__translate_text, c__opts any) { t.F_p = c__p; t.F_s = c__s; t.F_rel = c__rel; t.F_translate_text = c__translate_text; t.F_opts = c__opts }
//line :249:1
func (t *A_arbace_repr_clojure_half_fn__716000134_fn__716000138_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var t_ any = t.F_translate_text; t.F_translate_text = nil; tmp2 = t_; var tmp3 lang.IFn = lang.IFn_Cast(tmp2); var tmp4 any; var t__2 any = t.F_s; t.F_s = nil; tmp4 = t__2; var tmp5 any = tmp4; var tmp6 any; var t__3 any = t.F_p; t.F_p = nil; tmp6 = t__3; var tmp7 any = tmp6; var tmp8 any; var t__4 any = t.F_rel; t.F_rel = nil; tmp8 = t__4; var tmp9 any = tmp8; var tmp10 lang.IFn = A_arbace_repr_clojure_A_const_33; var tmp11 any; var t__5 any = t.F_opts; t.F_opts = nil; tmp11 = t__5; tmp1 = tmp3.Invoke_O_O_O_O__O(tmp5, tmp7, tmp9, tmp10.Invoke_O_O__O(tmp11, lang.PersistentHashSet_EMPTY.Ref())) }; return nil }(); if tmp12 != nil { if jrt.Exception_InstanceOf(tmp12) { var e__3 jrt.Exception_I = jrt.Exception_Cast(tmp12); var tmp13 any = A_arbace_repr_clojure_A_const_114; var tmp14 any; var root_1349 any = A_arbace_repr_clojure_A_const_87.GetRawRoot__O(); var linked_1350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1349, aot_arbace_core.A_arbace_core_ex_message_A_fn_class); var ifn_1351 lang.IFn
												if linked_1350 == nil { ifn_1351 = lang.IFn_Cast(root_1349) } else { ifn_1351 = nil }; var arg_1352 any = e__3; if linked_1350 == nil { tmp14 = ifn_1351.Invoke_O__O(arg_1352) } else { tmp14 = linked_1350.(*aot_arbace_core.A_arbace_core_ex_message_A).Invoke_O_O__O(root_1349, arg_1352) }
//line :249:1
	tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp14)) } else { panic(tmp12) } }; return tmp1 }



func A_arbace_repr_clojure_first_difference_A_New() *A_arbace_repr_clojure_first_difference_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_first_difference_A{}; t.Ctor(); return t }
//line :253:1
func (t *A_arbace_repr_clojure_first_difference_A) Ctor() {}
//line :253:1
func (t *A_arbace_repr_clojure_first_difference_A) Invoke_O_O_O__O(self, a__0, b__1 any) any { var n__3 int64 = lang.Numbers_Min_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(a__0)), int64(lang.RT_Count_O__I_NoInit(b__1))); var i__4 any; var tmp1 any = A_arbace_repr_clojure_first_difference_fn__716000143_A_New_O_O_J(a__0, b__1, n__3); var tmp2 *jrt.Class; var fncls__1355 *jrt.Class = A_arbace_repr_clojure_first_difference_fn__716000143_A_fn_class; if

	fncls__1355 == nil { var fncls__1355d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_repr_clojure_first_difference_fn__716000143_A_fn_class = fncls__1355d; tmp2 = fncls__1355d } else { tmp2 = fncls__1355 }; i__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O(); var line__5 int64; var tmp3 any; var root_1356 any = /*line :253:1*/A_arbace_repr_clojure_A_const_116.GetRawRoot__O(); var linked_1357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1356, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1358 lang.IFn; if


	linked_1357 == nil { ifn_1358 = lang.IFn_Cast(root_1356) } else { ifn_1358 = nil }; var arg_1359 any; var tmp4 any = A_arbace_repr_clojure_first_difference_fn__716000145_A_New(); var tmp5 *jrt.Class; var fncls__1361 *jrt.Class = A_arbace_repr_clojure_first_difference_fn__716000145_A_fn_class; if fncls__1361 == nil { var fncls__1361d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_repr_clojure_first_difference_fn__716000145_A_fn_class = fncls__1361d; tmp5 = fncls__1361d } else { tmp5 = fncls__1361 }; arg_1359 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_1360 any; var root_1362 any = A_arbace_repr_clojure_A_const_12.GetRawRoot__O(); var linked_1363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1362, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1364 lang.IFn; if linked_1363 == nil { ifn_1364 = lang.IFn_Cast(root_1362) } else { ifn_1364 = nil }; var arg_1365 any = a__0; var arg_1366 any = A_arbace_repr_clojure_A_const_13; var arg_1367 any = i__4; if linked_1363 == nil { arg_1360 = ifn_1364.Invoke_O_O_O__O(arg_1365, arg_1366, arg_1367) } else { arg_1360 = linked_1363.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1362, arg_1365, arg_1366, arg_1367) }; if linked_1357 == nil { tmp3 = ifn_1358.Invoke_O_O__O(arg_1359, arg_1360) } else { tmp3 = linked_1357.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1356, arg_1359, arg_1360) }; line__5 = lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(tmp3))); var ln__6 any; var tmp6 any = /*line :253:1*/A_arbace_repr_clojure_first_difference_ln__716000147_A_New_O(i__4); var tmp7 *jrt.Class; var fncls__1376 *jrt.Class = A_arbace_repr_clojure_first_difference_ln__716000147_A_fn_class; if



	fncls__1376 == nil { var fncls__1376d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_repr_clojure_first_difference_ln__716000147_A_fn_class = fncls__1376d; tmp7 = fncls__1376d } else { tmp7 = fncls__1376 }; ln__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); return /*line :260:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_21, nil, Lit_22, nil, Lit_23, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Long_ValueOf_J__Long_NoInit(line__5).Ref(), nil, lang.IFn_Cast(A_arbace_repr_clojure_A_const_118.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(ln__6).Invoke_O__O(a__0)), nil, lang.IFn_Cast(A_arbace_repr_clojure_A_const_118.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(ln__6).Invoke_O__O(b__1)))).Ref() }
//line :255:1
func A_arbace_repr_clojure_first_difference_fn__716000143_A_New_O_O_J(p0, p1 any, p2 int64) *A_arbace_repr_clojure_first_difference_fn__716000143_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_first_difference_fn__716000143_A{}; t.Ctor_O_O_J(p0, p1, p2); return t }
//line :255:1
func (t *A_arbace_repr_clojure_first_difference_fn__716000143_A) Ctor_O_O_J(c__a, c__b any, c__n int64) { t.F_a = c__a; t.F_b = c__b; t.F_n = c__n }
//line :255:1
func (t *A_arbace_repr_clojure_first_difference_fn__716000143_A) Invoke_O__O(self any) any { { var i__1 int64 = 0; L1: for { var tmp1 bool; var and__1927000168__auto____2 bool = lang.Numbers_Lt_J_J__Z_NoInit(i__1, t.F_n); if and__1927000168__auto____2 { var tmp2 *jrt.String = jrt.String_Cast(t.F_a); var tmp3 *jrt.String = jrt.String_Cast(t.F_b); tmp1 = lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(tmp2).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(i__1)), jrt.NN(tmp3).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(i__1))) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { i__1 = lang.Numbers_Inc_J__J_NoInit(i__1); continue L1 } else { return jrt.Long_ValueOf_J__Long_NoInit(i__1).Ref() } } }; panic("j2g: unreachable") }
func A_arbace_repr_clojure_first_difference_fn__716000145_A_New() *A_arbace_repr_clojure_first_difference_fn__716000145_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_first_difference_fn__716000145_A{}; t.Ctor(); return t }
//line :256:1
func (t *A_arbace_repr_clojure_first_difference_fn__716000145_A) Ctor() {}
//line :256:1
func (t *A_arbace_repr_clojure_first_difference_fn__716000145_A) Invoke_O_O__O(self, p1__716000142_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_repr_clojure_A_const_117, p1__716000142_SHARP___1)).Ref() }
func A_arbace_repr_clojure_first_difference_ln__716000147_A_New_O(p0 any) *A_arbace_repr_clojure_first_difference_ln__716000147_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_first_difference_ln__716000147_A{}; t.Ctor_O(p0); return t }
//line :257:1
func (t *A_arbace_repr_clojure_first_difference_ln__716000147_A) Ctor_O(c__i any) { t.F_i = c__i }
//line :257:1
func (t *A_arbace_repr_clojure_first_difference_ln__716000147_A) Invoke_O_O__O(self, s__1 any) any { var st__2 int64; var tmp1 *jrt.String = jrt.String_Cast(s__1); var tmp2 *jrt.String = Lit_24; var tmp3 jrt.Number_I; var na_1368 any = t.F_i; if jrt.Long_InstanceOf(na_1368) { var n0_1369 int64 = jrt.NN(jrt.Long_Cast(na_1368)).LongValue__J(); if n0_1369 == -9223372036854775808 { tmp3 = lang.Numbers_Dec_O__Number_NoInit(na_1368) } else { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1369 - 1)) } } else { if jrt.Double_InstanceOf(na_1368) { var n0_1369_2 float64 = jrt.NN(jrt.Double_Cast(na_1368)).DoubleValue__D(); tmp3 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1369_2 - 1.0)) } else { tmp3 = lang.Numbers_Dec_O__Number_NoInit(na_1368) } }; st__2 = lang.Numbers_Inc_J__J_NoInit(int64(jrt.NN(tmp1).LastIndexOf_String_I__I(tmp2, lang.RT_IntCast_O__I_NoInit(lang.Numbers_Max_J_O__O_NoInit(0, tmp3))))); var e__3 int32 = jrt.NN(jrt.String_Cast(s__1)).IndexOf_String_I__I(Lit_24, lang.RT_IntCast_O__I_NoInit(t.F_i)); var root_1370 any = A_arbace_repr_clojure_A_const_12.GetRawRoot__O(); var linked_1371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1370, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1372 lang.IFn; if

	linked_1371 == nil { ifn_1372 = lang.IFn_Cast(root_1370) } else { ifn_1372 = nil }; var arg_1373 any = s__1; var arg_1374 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Min_J_J__J_NoInit(st__2, int64(lang.RT_Count_O__I_NoInit(s__1)))).Ref(); var arg_1375 any; if lang.Numbers_IsNeg_J__Z_NoInit(int64(e__3)) { arg_1375 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(s__1)).Ref() } else { arg_1375 = jrt.Integer_ValueOf_I__Integer_NoInit(e__3).Ref() }; if linked_1371 == nil { return ifn_1372.Invoke_O_O_O__O(arg_1373, arg_1374, arg_1375) } else { return linked_1371.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1370, arg_1373, arg_1374, arg_1375) } }


func A_arbace_repr_clojure_roundtrip_A_New() *A_arbace_repr_clojure_roundtrip_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_A{}; t.Ctor(); return t }
//line :262:1
func (t *A_arbace_repr_clojure_roundtrip_A) Ctor() {}
//line :262:1
func (t *A_arbace_repr_clojure_roundtrip_A) Invoke_O_O_O__O(self, sources__0, opts__1 any) any { var vec__716000150__3 any; var tmp1 any = A_arbace_repr_clojure_A_const_119; if










	lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_repr_clojure_A_const_112.Invoke_O__O(opts__1)) { vec__716000150__3 = A_arbace_repr_clojure_A_const_120 } else { vec__716000150__3 = A_arbace_repr_clojure_A_const_121 }; var v1__4 any = /*line :262:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__716000150__3, lang.RT_IntCast_J__I_NoInit(0), nil); var v2__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000150__3, lang.RT_IntCast_J__I_NoInit(1), nil); var t__6 any; var root_1385 any = A_arbace_repr_clojure_A_const_122.GetRawRoot__O(); var linked_1386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1385, A_arbace_repr_clojure_tree_A_fn_class); var ifn_1387 lang.IFn; if











	linked_1386 == nil { ifn_1387 = lang.IFn_Cast(root_1385) } else { ifn_1387 = nil }; var arg_1388 any = sources__0; if linked_1386 == nil { t__6 = ifn_1387.Invoke_O__O(arg_1388) } else { t__6 = linked_1386.(*A_arbace_repr_clojure_tree_A).Invoke_O_O__O(root_1385, arg_1388) }; var a__7 any; var root_1389 any = /*line :262:1*/A_arbace_repr_clojure_A_const_123.GetRawRoot__O(); var linked_1390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1389, A_arbace_repr_clojure_half_A_fn_class); var ifn_1391 lang.IFn; if












	linked_1390 == nil { ifn_1391 = lang.IFn_Cast(root_1389) } else { ifn_1391 = nil }; var arg_1392 any = v1__4; var arg_1393 any = t__6; var arg_1394 any = opts__1; if linked_1390 == nil { a__7 = ifn_1391.Invoke_O_O_O__O(arg_1392, arg_1393, arg_1394) } else { a__7 = linked_1390.(*A_arbace_repr_clojure_half_A).Invoke_O_O_O_O__O(root_1389, arg_1392, arg_1393, arg_1394) }; var b__8 any; var root_1395 any = /*line :262:1*/A_arbace_repr_clojure_A_const_123.GetRawRoot__O(); var linked_1396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1395, A_arbace_repr_clojure_half_A_fn_class); var ifn_1397 lang.IFn; if













	linked_1396 == nil { ifn_1397 = lang.IFn_Cast(root_1395) } else { ifn_1397 = nil }; var arg_1398 any = v2__5; var arg_1399 any = A_arbace_repr_clojure_A_const_109.Invoke_O__O(a__7); var arg_1400 any = opts__1; if linked_1396 == nil { b__8 = ifn_1397.Invoke_O_O_O__O(arg_1398, arg_1399, arg_1400) } else { b__8 = linked_1396.(*A_arbace_repr_clojure_half_A).Invoke_O_O_O_O__O(root_1395, arg_1398, arg_1399, arg_1400) }; var c__9 any; var tmp2 any = A_arbace_repr_clojure_A_const_119; if

	lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_repr_clojure_A_const_112.Invoke_O__O(opts__1)) { var root_1401 any = A_arbace_repr_clojure_A_const_123.GetRawRoot__O(); var linked_1402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1401, A_arbace_repr_clojure_half_A_fn_class); var ifn_1403 lang.IFn; if linked_1402 == nil { ifn_1403 = lang.IFn_Cast(root_1401) } else { ifn_1403 = nil }; var arg_1404 any = v1__4; var arg_1405 any = A_arbace_repr_clojure_A_const_109.Invoke_O__O(b__8); var arg_1406 any = opts__1; if linked_1402 == nil { c__9 = ifn_1403.Invoke_O_O_O__O(arg_1404, arg_1405, arg_1406) } else { c__9 = linked_1402.(*A_arbace_repr_clojure_half_A).Invoke_O_O_O_O__O(root_1401, arg_1404, arg_1405, arg_1406) } } else { c__9 = nil }; var back2__10 any; var root_1407 any = /*line :262:1*/A_arbace_repr_clojure_A_const_100.GetRawRoot__O(); var linked_1408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1407, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1409 lang.IFn; if
















	linked_1408 == nil { ifn_1409 = lang.IFn_Cast(root_1407) } else { ifn_1409 = nil }; var arg_1410 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1411 any; var iter__1927001039__auto____10 any; var tmp3 any = A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_A_New(); var tmp4 *jrt.Class; var fncls__1470 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_A_fn_class; if fncls__1470 == nil { var fncls__1470d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_A_fn_class = fncls__1470d; tmp4 = fncls__1470d } else { tmp4 = fncls__1470 }; iter__1927001039__auto____10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); arg_1411 = lang.IFn_Cast(iter__1927001039__auto____10).Invoke_O__O(A_arbace_repr_clojure_A_const_112.Invoke_O__O(c__9)); if linked_1408 == nil { back2__10 = ifn_1409.Invoke_O_O__O(arg_1410, arg_1411) } else { back2__10 = linked_1408.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1407, arg_1410, arg_1411) }; var back__11 any; var root_1471 any = /*line :262:1*/A_arbace_repr_clojure_A_const_100.GetRawRoot__O(); var linked_1472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1471, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1473 lang.IFn; if


















	linked_1472 == nil { ifn_1473 = lang.IFn_Cast(root_1471) } else { ifn_1473 = nil }; var arg_1474 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1475 any; var iter__1927001039__auto____11 any; var tmp5 any = A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_A_New(); var tmp6 *jrt.Class; var fncls__1534 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_A_fn_class; if fncls__1534 == nil { var fncls__1534d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_A_fn_class = fncls__1534d; tmp6 = fncls__1534d } else { tmp6 = fncls__1534 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); arg_1475 = lang.IFn_Cast(iter__1927001039__auto____11).Invoke_O__O(A_arbace_repr_clojure_A_const_112.Invoke_O__O(b__8)); if linked_1472 == nil { back__11 = ifn_1473.Invoke_O_O__O(arg_1474, arg_1475) } else { back__11 = linked_1472.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1471, arg_1474, arg_1475) }; var results__12 any; var iter__1927001039__auto____12 any; var tmp7 any = /*line :262:1*/A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_A_New_O_O_O_O_O_O_O(back2__10, t__6, a__7, b__8, c__9, back__11, opts__1); var tmp8 *jrt.Class; var fncls__1795 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_A_fn_class; if



















	fncls__1795 == nil { var fncls__1795d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_A_fn_class = fncls__1795d; tmp8 = fncls__1795d } else { tmp8 = fncls__1795 }; iter__1927001039__auto____12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); results__12 = lang.IFn_Cast(iter__1927001039__auto____12).Invoke_O__O(A_arbace_repr_clojure_A_const_112.Invoke_O__O(a__7)); var tmp9 any = A_arbace_repr_clojure_A_const_139; var tmp10 any = /*line :262:1*/jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(results__12)), int64(lang.RT_Count_O__I_NoInit(A_arbace_repr_clojure_A_const_86.Invoke_O__O(a__7))))).Ref(); var tmp11 any = A_arbace_repr_clojure_A_const_140; var tmp12 any; var root_1796 any = A_arbace_repr_clojure_A_const_141.GetRawRoot__O(); var linked_1797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1796, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1798 lang.IFn; if














































	linked_1797 == nil { ifn_1798 = lang.IFn_Cast(root_1796) } else { ifn_1798 = nil }; var arg_1799 any = A_arbace_repr_clojure_A_const_57.GetRawRoot__O(); var arg_1800 any = results__12; if linked_1797 == nil { tmp12 = ifn_1798.Invoke_O_O__O(arg_1799, arg_1800) } else { tmp12 = linked_1797.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1796, arg_1799, arg_1800) }; var tmp13 any = /*line :262:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp12)).Ref(); var tmp14 any = A_arbace_repr_clojure_A_const_142; var tmp15 any; var root_1801 any = A_arbace_repr_clojure_A_const_100.GetRawRoot__O(); var linked_1802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1801, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1803 lang.IFn; if















































	linked_1802 == nil { ifn_1803 = lang.IFn_Cast(root_1801) } else { ifn_1803 = nil }; var arg_1804 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_101.GetRawRoot__O()).Invoke__O(); var arg_1805 any; var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_102.GetRawRoot__O()); var tmp17 any; var root_1815 any = A_arbace_repr_clojure_A_const_116.GetRawRoot__O(); var linked_1816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1815, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1817 lang.IFn; if
	linked_1816 == nil { ifn_1817 = lang.IFn_Cast(root_1815) } else { ifn_1817 = nil }; var arg_1818 any = A_arbace_repr_clojure_A_const_57.GetRawRoot__O(); var arg_1819 any = results__12; if linked_1816 == nil { tmp17 = ifn_1817.Invoke_O_O__O(arg_1818, arg_1819) } else { tmp17 = linked_1816.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1815, arg_1818, arg_1819) }; var tmp18 any = tmp17; var tmp19 any; var iter__1927001039__auto____13 any; var tmp20 any = A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_A_New(); var tmp21 *jrt.Class; var fncls__1878 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_A_fn_class; if
	fncls__1878 == nil { var fncls__1878d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_A_fn_class = fncls__1878d; tmp21 = fncls__1878d } else { tmp21 = fncls__1878 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil); tmp19 = lang.IFn_Cast(iter__1927001039__auto____13).Invoke_O__O(A_arbace_repr_clojure_A_const_86.Invoke_O__O(a__7)); var tmp22 any = tmp19; var tmp23 any; var iter__1927001039__auto____13_2 any; var tmp24 any = /*line :311:1*/A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_A_New_O(a__7); var tmp25 *jrt.Class; var fncls__1937 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_A_fn_class; if


	fncls__1937 == nil { var fncls__1937d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_A_fn_class = fncls__1937d; tmp25 = fncls__1937d } else { tmp25 = fncls__1937 }; iter__1927001039__auto____13_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil); tmp23 = lang.IFn_Cast(iter__1927001039__auto____13_2).Invoke_O__O(A_arbace_repr_clojure_A_const_86.Invoke_O__O(b__8)); arg_1805 = /*line :311:1*/tmp16.Invoke_O_O_O__O(tmp18, tmp22, tmp23); if /*line :310:1*/ linked_1802 == nil { tmp15 = ifn_1803.Invoke_O_O__O(arg_1804, arg_1805) } else { tmp15 = linked_1802.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1801, arg_1804, arg_1805) }; return /*line :262:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, tmp11, tmp13, tmp14, tmp15)) }
















func A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_A_New() *A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_A{}; t.Ctor(); return t }
//line :279:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_A) Ctor() {}
//line :279:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_A) Invoke_O_O__O(self, s__716000154__1 any) any { var tmp1 any = A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_A_New_O_O(self, s__716000154__1); var tmp2 *jrt.Class; var fncls__1469 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_A_fn_class; if fncls__1469 == nil { var fncls__1469d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_A_fn_class = fncls__1469d; tmp2 = fncls__1469d } else { tmp2 = fncls__1469 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :279:1
func A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_A{}; t.Ctor_O_O(p0, p1); return t }
//line :279:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_A) Ctor_O_O(c__iter__716000153, c__s__716000154 any) { t.F_iter__716000153 = c__iter__716000153; t.F_s__716000154 = c__s__716000154 }
//line :279:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_A) Invoke_O__O(self any) any { { var s__716000154__1 any; var t_ any = t.F_s__716000154; t.F_s__716000154 = nil; s__716000154__1 = t_; for { var temp__1927000414__auto____2 any; var root_1412 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_1413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1412, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1414 lang.IFn; if linked_1413 == nil { ifn_1414 = lang.IFn_Cast(root_1412) } else { ifn_1414 = nil }; var arg_1415 any = s__716000154__1; if linked_1413 == nil { temp__1927000414__auto____2 = ifn_1414.Invoke_O__O(arg_1415) } else { temp__1927000414__auto____2 = linked_1413.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1412, arg_1415) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__716000154__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1416 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_1417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1416, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1418 lang.IFn; if linked_1417 == nil { ifn_1418 = lang.IFn_Cast(root_1416) } else { ifn_1418 = nil }; var arg_1419 any = s__716000154__3; if linked_1417 == nil { tmp1 = ifn_1418.Invoke_O__O(arg_1419) } else { tmp1 = linked_1417.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1416, arg_1419) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1420 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_1421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1420, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1422 lang.IFn; if linked_1421 == nil { ifn_1422 = lang.IFn_Cast(root_1420) } else { ifn_1422 = nil }; var arg_1423 any = s__716000154__3; if linked_1421 == nil { c__1927001037__auto____4 = ifn_1422.Invoke_O__O(arg_1423) } else { c__1927001037__auto____4 = linked_1421.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1420, arg_1423) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__716000156__6 any; var root_1424 any = A_arbace_repr_clojure_A_const_60.GetRawRoot__O(); var linked_1425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1424, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1426 lang.IFn; if linked_1425 == nil { ifn_1426 = lang.IFn_Cast(root_1424) } else { ifn_1426 = nil }; var arg_1427 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1425 == nil { b__716000156__6 = ifn_1426.Invoke_O__O(arg_1427) } else { b__716000156__6 = linked_1425.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1424, arg_1427) }; var tmp2 any = A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_fn__716000159_A_New_O_I_O(b__716000156__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1433 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_fn__716000159_A_fn_class; if fncls__1433 == nil { var fncls__1433d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_fn__716000159_A_fn_class = fncls__1433d; tmp3 = fncls__1433d } else { tmp3 = fncls__1433 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1434 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_1435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1434, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1436 lang.IFn; if linked_1435 == nil { ifn_1436 = lang.IFn_Cast(root_1434) } else { ifn_1436 = nil }; var arg_1437 any; var root_1439 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_1440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1439, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1441 lang.IFn; if linked_1440 == nil { ifn_1441 = lang.IFn_Cast(root_1439) } else { ifn_1441 = nil }; var arg_1442 any = b__716000156__6; if linked_1440 == nil { arg_1437 = ifn_1441.Invoke_O__O(arg_1442) } else { arg_1437 = linked_1440.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1439, arg_1442) }; var arg_1438 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__716000153); var tmp5 any; var root_1443 any = A_arbace_repr_clojure_A_const_65.GetRawRoot__O(); var linked_1444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1443, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1445 lang.IFn; if linked_1444 == nil { ifn_1445 = lang.IFn_Cast(root_1443) } else { ifn_1445 = nil }; var arg_1446 any = s__716000154__3; if linked_1444 == nil { tmp5 = ifn_1445.Invoke_O__O(arg_1446) } else { tmp5 = linked_1444.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1443, arg_1446) }; arg_1438 = tmp4.Invoke_O__O(tmp5); if linked_1435 == nil { return ifn_1436.Invoke_O_O__O(arg_1437, arg_1438) } else { return linked_1435.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1434, arg_1437, arg_1438) } } else { var root_1447 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_1448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1447, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1449 lang.IFn; if linked_1448 == nil { ifn_1449 = lang.IFn_Cast(root_1447) } else { ifn_1449 = nil }; var arg_1450 any; var root_1452 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_1453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1452, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1454 lang.IFn; if linked_1453 == nil { ifn_1454 = lang.IFn_Cast(root_1452) } else { ifn_1454 = nil }; var arg_1455 any = b__716000156__6; if linked_1453 == nil { arg_1450 = ifn_1454.Invoke_O__O(arg_1455) } else { arg_1450 = linked_1453.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1452, arg_1455) }; var arg_1451 any; if linked_1448 == nil { return ifn_1449.Invoke_O_O__O(arg_1450, arg_1451) } else { return linked_1448.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1447, arg_1450, arg_1451) } } } else { var vec__716000164__4 any; var root_1456 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_1457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1456, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1458 lang.IFn; if linked_1457 == nil { ifn_1458 = lang.IFn_Cast(root_1456) } else { ifn_1458 = nil }; var arg_1459 any = s__716000154__3; if linked_1457 == nil { vec__716000164__4 = ifn_1458.Invoke_O__O(arg_1459) } else { vec__716000164__4 = linked_1457.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1456, arg_1459) }; var out__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000164__4, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000164__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1460 any = A_arbace_repr_clojure_A_const_66.GetRawRoot__O(); var linked_1461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1460, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1462 lang.IFn; if linked_1461 == nil { ifn_1462 = lang.IFn_Cast(root_1460) } else { ifn_1462 = nil }; var arg_1463 any = lang.Tuple_Create_O_O__IPersistentVector(rel__6, out__5); var arg_1464 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__716000153); var tmp7 any; var root_1465 any = A_arbace_repr_clojure_A_const_67.GetRawRoot__O(); var linked_1466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1465, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1467 lang.IFn; if linked_1466 == nil { ifn_1467 = lang.IFn_Cast(root_1465) } else { ifn_1467 = nil }; var arg_1468 any = s__716000154__3; if linked_1466 == nil { tmp7 = ifn_1467.Invoke_O__O(arg_1468) } else { tmp7 = linked_1466.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1465, arg_1468) }; arg_1464 = tmp6.Invoke_O__O(tmp7); if linked_1461 == nil { return ifn_1462.Invoke_O_O__O(arg_1463, arg_1464) } else { return linked_1461.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1460, arg_1463, arg_1464) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :279:1
func A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_fn__716000159_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_fn__716000159_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_fn__716000159_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :279:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_fn__716000159_A) Ctor_O_I_O(c__b__716000156 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__716000156 = c__b__716000156; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :279:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_fn__716000159_A) Invoke_O__O(self any) any { { var i__716000155__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__716000155__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__716000160__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__716000155__1)); var out__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000160__2, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000160__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1428 any = A_arbace_repr_clojure_A_const_61.GetRawRoot__O(); var linked_1429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1428, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1430 lang.IFn; if linked_1429 == nil { ifn_1430 = lang.IFn_Cast(root_1428) } else { ifn_1430 = nil }; var arg_1431 any = t.F_b__716000156; var arg_1432 any = lang.Tuple_Create_O_O__IPersistentVector(rel__4, out__3); if linked_1429 == nil { ifn_1430.Invoke_O_O__O(arg_1431, arg_1432) } else { linked_1429.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1428, arg_1431, arg_1432) }; i__716000155__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__716000155__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_A_New() *A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_A{}; t.Ctor(); return t }
//line :281:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_A) Ctor() {}
//line :281:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_A) Invoke_O_O__O(self, s__716000170__1 any) any { var tmp1 any = A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_A_New_O_O(s__716000170__1, self); var tmp2 *jrt.Class; var fncls__1533 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_A_fn_class; if fncls__1533 == nil { var fncls__1533d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_A_fn_class = fncls__1533d; tmp2 = fncls__1533d } else { tmp2 = fncls__1533 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :281:1
func A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_A{}; t.Ctor_O_O(p0, p1); return t }
//line :281:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_A) Ctor_O_O(c__s__716000170, c__iter__716000169 any) { t.F_s__716000170 = c__s__716000170; t.F_iter__716000169 = c__iter__716000169 }
//line :281:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_A) Invoke_O__O(self any) any { { var s__716000170__1 any; var t_ any = t.F_s__716000170; t.F_s__716000170 = nil; s__716000170__1 = t_; for { var temp__1927000414__auto____2 any; var root_1476 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_1477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1476, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1478 lang.IFn; if linked_1477 == nil { ifn_1478 = lang.IFn_Cast(root_1476) } else { ifn_1478 = nil }; var arg_1479 any = s__716000170__1; if linked_1477 == nil { temp__1927000414__auto____2 = ifn_1478.Invoke_O__O(arg_1479) } else { temp__1927000414__auto____2 = linked_1477.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1476, arg_1479) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__716000170__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1480 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_1481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1480, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1482 lang.IFn; if linked_1481 == nil { ifn_1482 = lang.IFn_Cast(root_1480) } else { ifn_1482 = nil }; var arg_1483 any = s__716000170__3; if linked_1481 == nil { tmp1 = ifn_1482.Invoke_O__O(arg_1483) } else { tmp1 = linked_1481.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1480, arg_1483) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1484 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_1485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1484, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1486 lang.IFn; if linked_1485 == nil { ifn_1486 = lang.IFn_Cast(root_1484) } else { ifn_1486 = nil }; var arg_1487 any = s__716000170__3; if linked_1485 == nil { c__1927001037__auto____4 = ifn_1486.Invoke_O__O(arg_1487) } else { c__1927001037__auto____4 = linked_1485.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1484, arg_1487) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__716000172__6 any; var root_1488 any = A_arbace_repr_clojure_A_const_60.GetRawRoot__O(); var linked_1489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1488, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1490 lang.IFn; if linked_1489 == nil { ifn_1490 = lang.IFn_Cast(root_1488) } else { ifn_1490 = nil }; var arg_1491 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1489 == nil { b__716000172__6 = ifn_1490.Invoke_O__O(arg_1491) } else { b__716000172__6 = linked_1489.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1488, arg_1491) }; var tmp2 any = A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_fn__716000175_A_New_O_I_O(b__716000172__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1497 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_fn__716000175_A_fn_class; if fncls__1497 == nil { var fncls__1497d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_79, false); A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_fn__716000175_A_fn_class = fncls__1497d; tmp3 = fncls__1497d } else { tmp3 = fncls__1497 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1498 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_1499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1498, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1500 lang.IFn; if linked_1499 == nil { ifn_1500 = lang.IFn_Cast(root_1498) } else { ifn_1500 = nil }; var arg_1501 any; var root_1503 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_1504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1503, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1505 lang.IFn; if linked_1504 == nil { ifn_1505 = lang.IFn_Cast(root_1503) } else { ifn_1505 = nil }; var arg_1506 any = b__716000172__6; if linked_1504 == nil { arg_1501 = ifn_1505.Invoke_O__O(arg_1506) } else { arg_1501 = linked_1504.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1503, arg_1506) }; var arg_1502 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__716000169); var tmp5 any; var root_1507 any = A_arbace_repr_clojure_A_const_65.GetRawRoot__O(); var linked_1508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1507, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1509 lang.IFn; if linked_1508 == nil { ifn_1509 = lang.IFn_Cast(root_1507) } else { ifn_1509 = nil }; var arg_1510 any = s__716000170__3; if linked_1508 == nil { tmp5 = ifn_1509.Invoke_O__O(arg_1510) } else { tmp5 = linked_1508.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1507, arg_1510) }; arg_1502 = tmp4.Invoke_O__O(tmp5); if linked_1499 == nil { return ifn_1500.Invoke_O_O__O(arg_1501, arg_1502) } else { return linked_1499.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1498, arg_1501, arg_1502) } } else { var root_1511 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_1512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1511, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1513 lang.IFn; if linked_1512 == nil { ifn_1513 = lang.IFn_Cast(root_1511) } else { ifn_1513 = nil }; var arg_1514 any; var root_1516 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_1517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1516, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1518 lang.IFn; if linked_1517 == nil { ifn_1518 = lang.IFn_Cast(root_1516) } else { ifn_1518 = nil }; var arg_1519 any = b__716000172__6; if linked_1517 == nil { arg_1514 = ifn_1518.Invoke_O__O(arg_1519) } else { arg_1514 = linked_1517.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1516, arg_1519) }; var arg_1515 any; if linked_1512 == nil { return ifn_1513.Invoke_O_O__O(arg_1514, arg_1515) } else { return linked_1512.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1511, arg_1514, arg_1515) } } } else { var vec__716000180__4 any; var root_1520 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_1521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1520, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1522 lang.IFn; if linked_1521 == nil { ifn_1522 = lang.IFn_Cast(root_1520) } else { ifn_1522 = nil }; var arg_1523 any = s__716000170__3; if linked_1521 == nil { vec__716000180__4 = ifn_1522.Invoke_O__O(arg_1523) } else { vec__716000180__4 = linked_1521.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1520, arg_1523) }; var out__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000180__4, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000180__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1524 any = A_arbace_repr_clojure_A_const_66.GetRawRoot__O(); var linked_1525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1524, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1526 lang.IFn; if linked_1525 == nil { ifn_1526 = lang.IFn_Cast(root_1524) } else { ifn_1526 = nil }; var arg_1527 any = lang.Tuple_Create_O_O__IPersistentVector(rel__6, out__5); var arg_1528 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__716000169); var tmp7 any; var root_1529 any = A_arbace_repr_clojure_A_const_67.GetRawRoot__O(); var linked_1530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1529, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1531 lang.IFn; if linked_1530 == nil { ifn_1531 = lang.IFn_Cast(root_1529) } else { ifn_1531 = nil }; var arg_1532 any = s__716000170__3; if linked_1530 == nil { tmp7 = ifn_1531.Invoke_O__O(arg_1532) } else { tmp7 = linked_1530.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1529, arg_1532) }; arg_1528 = tmp6.Invoke_O__O(tmp7); if linked_1525 == nil { return ifn_1526.Invoke_O_O__O(arg_1527, arg_1528) } else { return linked_1525.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1524, arg_1527, arg_1528) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :281:1
func A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_fn__716000175_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_fn__716000175_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_fn__716000175_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :281:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_fn__716000175_A) Ctor_O_I_O(c__b__716000172 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__716000172 = c__b__716000172; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :281:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_fn__716000175_A) Invoke_O__O(self any) any { { var i__716000171__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__716000171__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__716000176__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__716000171__1)); var out__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000176__2, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000176__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1492 any = A_arbace_repr_clojure_A_const_61.GetRawRoot__O(); var linked_1493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1492, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1494 lang.IFn; if linked_1493 == nil { ifn_1494 = lang.IFn_Cast(root_1492) } else { ifn_1494 = nil }; var arg_1495 any = t.F_b__716000172; var arg_1496 any = lang.Tuple_Create_O_O__IPersistentVector(rel__4, out__3); if linked_1493 == nil { ifn_1494.Invoke_O_O__O(arg_1495, arg_1496) } else { linked_1493.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1492, arg_1495, arg_1496) }; i__716000171__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__716000171__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_A_New_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6 any) *A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_A{}; t.Ctor_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :282:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_A) Ctor_O_O_O_O_O_O_O(c__back2, c__t, c__a, c__b, c__c, c__back, c__opts any) { t.F_back2 = c__back2; t.F_t = c__t; t.F_a = c__a; t.F_b = c__b; t.F_c = c__c; t.F_back = c__back; t.F_opts = c__opts }
//line :282:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_A) Invoke_O_O__O(self, s__716000186__1 any) any { var tmp1 any = A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_A_New_O_O_O_O_O_O_O_O_O(t.F_back2, self, s__716000186__1, t.F_t, t.F_a, t.F_b, t.F_c, t.F_back, t.F_opts); var tmp2 *jrt.Class; var fncls__1794 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_A_fn_class; if fncls__1794 == nil { var fncls__1794d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_A_fn_class = fncls__1794d; tmp2 = fncls__1794d } else { tmp2 = fncls__1794 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :282:1
func A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_A_New_O_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7, p8 any) *A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_A{}; t.Ctor_O_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7, p8); return t }
//line :282:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_A) Ctor_O_O_O_O_O_O_O_O_O(c__back2, c__iter__716000185, c__s__716000186, c__t, c__a, c__b, c__c, c__back, c__opts any) { t.F_back2 = c__back2; t.F_iter__716000185 = c__iter__716000185; t.F_s__716000186 = c__s__716000186; t.F_t = c__t; t.F_a = c__a; t.F_b = c__b; t.F_c = c__c; t.F_back = c__back; t.F_opts = c__opts }
//line :282:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_A) Invoke_O__O(self any) any { { var s__716000186__1 any; var t_ any = t.F_s__716000186; t.F_s__716000186 = nil; s__716000186__1 = t_; for { var temp__1927000414__auto____2 any; var root_1535 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_1536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1535, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1537 lang.IFn; if linked_1536 == nil { ifn_1537 = lang.IFn_Cast(root_1535) } else { ifn_1537 = nil }; var arg_1538 any = s__716000186__1; if linked_1536 == nil { temp__1927000414__auto____2 = ifn_1537.Invoke_O__O(arg_1538) } else { temp__1927000414__auto____2 = linked_1536.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1535, arg_1538) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__716000186__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1539 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_1540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1539, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1541 lang.IFn; if linked_1540 == nil { ifn_1541 = lang.IFn_Cast(root_1539) } else { ifn_1541 = nil }; var arg_1542 any = s__716000186__3; if linked_1540 == nil { tmp1 = ifn_1541.Invoke_O__O(arg_1542) } else { tmp1 = linked_1540.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1539, arg_1542) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1543 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_1544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1543, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1545 lang.IFn; if linked_1544 == nil { ifn_1545 = lang.IFn_Cast(root_1543) } else { ifn_1545 = nil }; var arg_1546 any = s__716000186__3; if linked_1544 == nil { c__1927001037__auto____4 = ifn_1545.Invoke_O__O(arg_1546) } else { c__1927001037__auto____4 = linked_1544.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1543, arg_1546) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__716000188__6 any; var root_1547 any = A_arbace_repr_clojure_A_const_60.GetRawRoot__O(); var linked_1548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1547, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1549 lang.IFn; if linked_1548 == nil { ifn_1549 = lang.IFn_Cast(root_1547) } else { ifn_1549 = nil }; var arg_1550 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1548 == nil { b__716000188__6 = ifn_1549.Invoke_O__O(arg_1550) } else { b__716000188__6 = linked_1548.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1547, arg_1550) }; var tmp2 any = A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_fn__716000191_A_New_O_O_O_O_O_O_I_O_O_O(t.F_back2, t.F_t, b__716000188__6, t.F_a, t.F_b, t.F_c, size__1927001038__auto____5, t.F_back, t.F_opts, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1657 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_fn__716000191_A_fn_class; if fncls__1657 == nil { var fncls__1657d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_fn__716000191_A_fn_class = fncls__1657d; tmp3 = fncls__1657d } else { tmp3 = fncls__1657 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1658 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_1659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1658, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1660 lang.IFn; if linked_1659 == nil { ifn_1660 = lang.IFn_Cast(root_1658) } else { ifn_1660 = nil }; var arg_1661 any; var root_1663 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_1664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1663, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1665 lang.IFn; if linked_1664 == nil { ifn_1665 = lang.IFn_Cast(root_1663) } else { ifn_1665 = nil }; var arg_1666 any = b__716000188__6; if linked_1664 == nil { arg_1661 = ifn_1665.Invoke_O__O(arg_1666) } else { arg_1661 = linked_1664.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1663, arg_1666) }; var arg_1662 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__716000185); var tmp5 any; var root_1667 any = A_arbace_repr_clojure_A_const_65.GetRawRoot__O(); var linked_1668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1667, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1669 lang.IFn; if linked_1668 == nil { ifn_1669 = lang.IFn_Cast(root_1667) } else { ifn_1669 = nil }; var arg_1670 any = s__716000186__3; if linked_1668 == nil { tmp5 = ifn_1669.Invoke_O__O(arg_1670) } else { tmp5 = linked_1668.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1667, arg_1670) }; arg_1662 = tmp4.Invoke_O__O(tmp5); if linked_1659 == nil { return ifn_1660.Invoke_O_O__O(arg_1661, arg_1662) } else { return linked_1659.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1658, arg_1661, arg_1662) } } else { var root_1671 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_1672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1671, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1673 lang.IFn; if linked_1672 == nil { ifn_1673 = lang.IFn_Cast(root_1671) } else { ifn_1673 = nil }; var arg_1674 any; var root_1676 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_1677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1676, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1678 lang.IFn; if linked_1677 == nil { ifn_1678 = lang.IFn_Cast(root_1676) } else { ifn_1678 = nil }; var arg_1679 any = b__716000188__6; if linked_1677 == nil { arg_1674 = ifn_1678.Invoke_O__O(arg_1679) } else { arg_1674 = linked_1677.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1676, arg_1679) }; var arg_1675 any; if linked_1672 == nil { return ifn_1673.Invoke_O_O__O(arg_1674, arg_1675) } else { return linked_1672.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1671, arg_1674, arg_1675) } } } else { var vec__716000196__4 any; var root_1680 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_1681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1680, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1682 lang.IFn; if linked_1681 == nil { ifn_1682 = lang.IFn_Cast(root_1680) } else { ifn_1682 = nil }; var arg_1683 any = s__716000186__3; if linked_1681 == nil { vec__716000196__4 = ifn_1682.Invoke_O__O(arg_1683) } else { vec__716000196__4 = linked_1681.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1680, arg_1683) }; var out__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000196__4, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000196__4, lang.RT_IntCast_J__I_NoInit(1), nil); var orig__7 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_78.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_t).Invoke_O__O(rel__6)); var out2__8 any = lang.IFn_Cast(t.F_back).Invoke_O__O(out__5); var txt__9 any


	if jrt.J2g_Truth(out2__8) { var root_1688 any = A_arbace_repr_clojure_A_const_124.GetRawRoot__O(); var linked_1689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1688, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1690 lang.IFn; if linked_1689 == nil { ifn_1690 = lang.IFn_Cast(root_1688) } else { ifn_1690 = nil }; var arg_1691 any = t.F_b; var arg_1692 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_clojure_A_const_109, out2__8); if linked_1689 == nil { txt__9 = ifn_1690.Invoke_O_O__O(arg_1691, arg_1692) } else { txt__9 = linked_1689.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1688, arg_1691, arg_1692) } } else { txt__9 = nil }
//line :282:1
	var p__10 any; var root_1693 any = A_arbace_repr_clojure_A_const_124.GetRawRoot__O(); var linked_1694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1693, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1695 lang.IFn



	if linked_1694 == nil { ifn_1695 = lang.IFn_Cast(root_1693) } else { ifn_1695 = nil }; var arg_1696 any = t.F_a; var arg_1697 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_clojure_A_const_113, out__5); if linked_1694 == nil { p__10 = ifn_1695.Invoke_O_O__O(arg_1696, arg_1697) } else { p__10 = linked_1694.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1693, arg_1696, arg_1697) }
//line :282:1
	var root_1698 any = A_arbace_repr_clojure_A_const_66.GetRawRoot__O(); var linked_1699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1698, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1700 lang.IFn; if linked_1699 == nil { ifn_1700 = lang.IFn_Cast(root_1698) } else { ifn_1700 = nil }; var arg_1701 any; var tmp6 any




	if lang.Util_Identical_O_O__Z_NoInit(out2__8, nil) { tmp6 = A_arbace_repr_clojure_A_const_136 } else { var tmp7 any; var tmp8 any = A_arbace_repr_clojure_A_const_25; var and__1927000168__auto____11 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp8, A_arbace_repr_clojure_A_const_24.Invoke_O__O(p__10))

		if and__1927000168__auto____11 { var and__1927000168__auto____12 any = A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__10); if jrt.J2g_Truth(and__1927000168__auto____12) { var and__1927000168__auto____13 any; var root_1703 any = A_arbace_repr_clojure_A_const_41.GetRawRoot__O(); var linked_1704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1703, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1705 lang.IFn; if linked_1704 == nil { ifn_1705 = lang.IFn_Cast(root_1703) } else { ifn_1705 = nil }; var arg_1706 any = A_arbace_repr_clojure_A_const_20.Invoke_O__O(p__10); if linked_1704 == nil { and__1927000168__auto____13 = ifn_1705.Invoke_O__O(arg_1706) } else { and__1927000168__auto____13 = linked_1704.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1703, arg_1706) }; if jrt.J2g_Truth(and__1927000168__auto____13) {
			var root_1707 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_1708 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1707, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1709 lang.IFn; if linked_1708 == nil { ifn_1709 = lang.IFn_Cast(root_1707) } else { ifn_1709 = nil }; var arg_1710 any = A_arbace_repr_clojure_A_const_119; var arg_1711 any = A_arbace_repr_clojure_A_const_112.Invoke_O__O(t.F_opts); if linked_1708 == nil { tmp7 = ifn_1709.Invoke_O_O__O(arg_1710, arg_1711) } else { tmp7 = linked_1708.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1707, arg_1710, arg_1711) } } else {
//line :289:1
				tmp7 = and__1927000168__auto____13 } } else { tmp7 = and__1927000168__auto____12 } } else { tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11).Ref() }
//line :287:1
		if jrt.J2g_Truth(tmp7) { var want__11 any; var root_1712 any = A_arbace_repr_clojure_A_const_110.GetRawRoot__O(); var linked_1713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1712, A_arbace_repr_clojure_under_A_fn_class); var ifn_1714 lang.IFn



			if linked_1713 == nil { ifn_1714 = lang.IFn_Cast(root_1712) } else { ifn_1714 = nil }; var arg_1715 any; var root_1717 any = A_arbace_repr_clojure_A_const_104.GetRawRoot__O(); var linked_1718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1717, A_arbace_repr_clojure_parent_of_A_fn_class); var ifn_1719 lang.IFn; if linked_1718 == nil { ifn_1719 = lang.IFn_Cast(root_1717) } else { ifn_1719 = nil }; var arg_1720 any = rel__6; if linked_1718 == nil { arg_1715 = ifn_1719.Invoke_O__O(arg_1720) } else { arg_1715 = linked_1718.(*A_arbace_repr_clojure_parent_of_A).Invoke_O_O__O(root_1717, arg_1720) }; var arg_1716 any; var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_53); var tmp10 any; var root_1721 any = A_arbace_repr_clojure_A_const_32.GetRawRoot__O(); var linked_1722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1721, A_arbace_repr_clojure_base_A_fn_class); var ifn_1723 lang.IFn; if linked_1722 == nil { ifn_1723 = lang.IFn_Cast(root_1721) } else { ifn_1723 = nil }; var arg_1724 any; var root_1725 any = A_arbace_repr_clojure_A_const_106.GetRawRoot__O(); var linked_1726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1725, A_arbace_repr_clojure_name_of_A_fn_class); var ifn_1727 lang.IFn; if linked_1726 == nil { ifn_1727 = lang.IFn_Cast(root_1725) } else { ifn_1727 = nil }; var arg_1728 any = rel__6; if linked_1726 == nil { arg_1724 = ifn_1727.Invoke_O__O(arg_1728) } else { arg_1724 = linked_1726.(*A_arbace_repr_clojure_name_of_A).Invoke_O_O__O(root_1725, arg_1728) }; if linked_1722 == nil { tmp10 = ifn_1723.Invoke_O__O(arg_1724) } else { tmp10 = linked_1722.(*A_arbace_repr_clojure_base_A).Invoke_O_O__O(root_1721, arg_1724) }; arg_1716 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, tmp10, nil)).Ref(); if linked_1713 == nil { want__11 = ifn_1714.Invoke_O_O__O(arg_1715, arg_1716) } else { want__11 = linked_1713.(*A_arbace_repr_clojure_under_A).Invoke_O_O_O__O(root_1712, arg_1715, arg_1716) }
//line :287:1
			var resolved__12 any; var root_1729 any = A_arbace_repr_clojure_A_const_126.GetRawRoot__O(); var linked_1730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1729, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_resolve_conditionals_A_fn_class); var ifn_1731 lang.IFn




			if linked_1730 == nil { ifn_1731 = lang.IFn_Cast(root_1729) } else { ifn_1731 = nil }; var arg_1732 any = orig__7; var arg_1733 any = A_arbace_repr_clojure_A_const_137; if linked_1730 == nil { resolved__12 = ifn_1731.Invoke_O_O__O(arg_1732, arg_1733) } else { resolved__12 = linked_1730.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_resolve_conditionals_A).Invoke_O_O_O__O(root_1729, arg_1732, arg_1733) }
			var tmp11 any; var root_1734 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_1735 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1734, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1736 lang.IFn; if linked_1735 == nil { ifn_1736 = lang.IFn_Cast(root_1734) } else { ifn_1736 = nil }; var arg_1737 any = out2__8; var arg_1738 any = want__11; if linked_1735 == nil { tmp11 = ifn_1736.Invoke_O_O__O(arg_1737, arg_1738) } else { tmp11 = linked_1735.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1734, arg_1737, arg_1738) }; if jrt.J2g_Truth(tmp11) { tmp6 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_128, A_arbace_repr_clojure_A_const_129, A_arbace_repr_clojure_A_const_130, out2__8)) } else { var tmp12 any; var root_1739 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_1740 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1739, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1741 lang.IFn
				if linked_1740 == nil { ifn_1741 = lang.IFn_Cast(root_1739) } else { ifn_1741 = nil }; var arg_1742 any = txt__9; var arg_1743 any = resolved__12; if linked_1740 == nil { tmp12 = ifn_1741.Invoke_O_O__O(arg_1742, arg_1743) } else { tmp12 = linked_1740.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1739, arg_1742, arg_1743) }
//line :293:1
				if jrt.J2g_Truth(tmp12) { var tmp13 any = A_arbace_repr_clojure_A_const_128; var tmp14 any = A_arbace_repr_clojure_A_const_19; var tmp15 any = A_arbace_repr_clojure_A_const_131; var tmp16 any; var root_1744 any = A_arbace_repr_clojure_A_const_132.GetRawRoot__O(); var linked_1745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1744, A_arbace_repr_clojure_first_difference_A_fn_class); var ifn_1746 lang.IFn
					if linked_1745 == nil { ifn_1746 = lang.IFn_Cast(root_1744) } else { ifn_1746 = nil }; var arg_1747 any = resolved__12; var arg_1748 any = txt__9; if linked_1745 == nil { tmp16 = ifn_1746.Invoke_O_O__O(arg_1747, arg_1748) } else { tmp16 = linked_1745.(*A_arbace_repr_clojure_first_difference_A).Invoke_O_O_O__O(root_1744, arg_1747, arg_1748) }
//line :293:1
					tmp6 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp14, tmp15, tmp16)) } else { if A_arbace_repr_clojure_A_const_34 != nil { tmp6 = A_arbace_repr_clojure_A_const_138 } else { tmp6 = nil } } } } else {
//line :287:1
						var tmp17 any; var root_1749 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_1750 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1749, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1751 lang.IFn








						if linked_1750 == nil { ifn_1751 = lang.IFn_Cast(root_1749) } else { ifn_1751 = nil }; var arg_1752 any = out2__8; var arg_1753 any = rel__6; if linked_1750 == nil { tmp17 = ifn_1751.Invoke_O_O__O(arg_1752, arg_1753) } else { tmp17 = linked_1750.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1749, arg_1752, arg_1753) }
//line :287:1
						if jrt.J2g_Truth(tmp17) { tmp6 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_128, A_arbace_repr_clojure_A_const_129, A_arbace_repr_clojure_A_const_130, out2__8)) } else { if lang.Util_Equiv_O_O__Z_NoInit(txt__9, orig__7) { tmp6 = nil } else { var tmp18 any; var tmp19 any = A_arbace_repr_clojure_A_const_119; var and__1927000168__auto____11_2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp19, A_arbace_repr_clojure_A_const_112.Invoke_O__O(t.F_opts))












							if and__1927000168__auto____11_2 { var and__1927000168__auto____12_2 any; var p__12 any; var tmp20 *lang.Keyword = A_arbace_repr_clojure_A_const_70; var tmp21 lang.IFn = lang.IFn_Cast(tmp20.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_A_const_69.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_A_const_99))); var tmp22 any; var root_1786 any = A_arbace_repr_clojure_A_const_106.GetRawRoot__O(); var linked_1787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1786, A_arbace_repr_clojure_name_of_A_fn_class); var ifn_1788 lang.IFn
								if linked_1787 == nil { ifn_1788 = lang.IFn_Cast(root_1786) } else { ifn_1788 = nil }; var arg_1789 any = out__5; if linked_1787 == nil { tmp22 = ifn_1788.Invoke_O__O(arg_1789) } else { tmp22 = linked_1787.(*A_arbace_repr_clojure_name_of_A).Invoke_O_O__O(root_1786, arg_1789) }; p__12 = tmp21.Invoke_O_O_O__O(tmp22, lang.PersistentHashSet_EMPTY.Ref(), t.F_opts)
//line :300:1
								var and__1927000168__auto____13_2 any = A_arbace_repr_clojure_A_const_24.Invoke_O__O(p__12)

								if jrt.J2g_Truth(and__1927000168__auto____13_2) {
									var root_1754 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_1755 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1754, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1756 lang.IFn; if linked_1755 == nil { ifn_1756 = lang.IFn_Cast(root_1754) } else { ifn_1756 = nil }; var arg_1757 any = orig__7; var arg_1758 any; var root_1759 any = A_arbace_repr_clojure_A_const_134.GetRawRoot__O(); var linked_1760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1759, A_arbace_repr_clojure_translate_text_A_fn_class); var ifn_1761 lang.IFn; if linked_1760 == nil { ifn_1761 = lang.IFn_Cast(root_1759) } else { ifn_1761 = nil }; var arg_1762 any = orig__7; var arg_1763 any = p__12; var arg_1764 any = rel__6; var arg_1765 any = A_arbace_repr_clojure_A_const_33.Invoke_O_O__O(t.F_opts, lang.PersistentHashSet_EMPTY.Ref()); if linked_1760 == nil { arg_1758 = ifn_1761.Invoke_O_O_O_O__O(arg_1762, arg_1763, arg_1764, arg_1765) } else { arg_1758 = linked_1760.(*A_arbace_repr_clojure_translate_text_A).Invoke_O_O_O_O_O__O(root_1759, arg_1762, arg_1763, arg_1764, arg_1765) }; if linked_1755 == nil { and__1927000168__auto____12_2 = ifn_1756.Invoke_O_O__O(arg_1757, arg_1758) } else { and__1927000168__auto____12_2 = linked_1755.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1754, arg_1757, arg_1758) } } else {
//line :302:1
										and__1927000168__auto____12_2 = and__1927000168__auto____13_2 }
//line :300:1
								if jrt.J2g_Truth(and__1927000168__auto____12_2) {




									var tmp23 any; var root_1766 any = A_arbace_repr_clojure_A_const_124.GetRawRoot__O(); var linked_1767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1766, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1768 lang.IFn; if linked_1767 == nil { ifn_1768 = lang.IFn_Cast(root_1766) } else { ifn_1768 = nil }; var arg_1769 any = t.F_a; var arg_1770 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_clojure_A_const_109, out__5); if linked_1767 == nil { tmp23 = ifn_1768.Invoke_O_O__O(arg_1769, arg_1770) } else { tmp23 = linked_1767.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1766, arg_1769, arg_1770) }; var tmp24 any = tmp23; var tmp25 any; var root_1771 any = A_arbace_repr_clojure_A_const_124.GetRawRoot__O(); var linked_1772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1771, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1773 lang.IFn; if linked_1772 == nil { ifn_1773 = lang.IFn_Cast(root_1771) } else { ifn_1773 = nil }; var arg_1774 any = t.F_c; var tmp26 any = A_arbace_repr_clojure_A_const_109; var arg_1775 any = lang.Tuple_Create_O_O__IPersistentVector(tmp26, lang.IFn_Cast(t.F_back2).Invoke_O__O(out2__8)); if linked_1772 == nil { tmp25 = ifn_1773.Invoke_O_O__O(arg_1774, arg_1775) } else { tmp25 = linked_1772.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1771, arg_1774, arg_1775) }; tmp18 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp24, tmp25)).Ref() } else {
//line :300:1
										tmp18 = and__1927000168__auto____12_2 } } else { tmp18 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11_2).Ref() }
//line :287:1
							if jrt.J2g_Truth(tmp18) { var tmp27 any = A_arbace_repr_clojure_A_const_128; var tmp28 any = A_arbace_repr_clojure_A_const_135; var tmp29 any = A_arbace_repr_clojure_A_const_131; var tmp30 any; var root_1776 any = A_arbace_repr_clojure_A_const_132.GetRawRoot__O(); var linked_1777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1776, A_arbace_repr_clojure_first_difference_A_fn_class); var ifn_1778 lang.IFn


















								if linked_1777 == nil { ifn_1778 = lang.IFn_Cast(root_1776) } else { ifn_1778 = nil }; var arg_1779 any = orig__7; var arg_1780 any = txt__9; if linked_1777 == nil { tmp30 = ifn_1778.Invoke_O_O__O(arg_1779, arg_1780) } else { tmp30 = linked_1777.(*A_arbace_repr_clojure_first_difference_A).Invoke_O_O_O__O(root_1776, arg_1779, arg_1780) }
//line :287:1
								tmp6 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp27, tmp28, tmp29, tmp30)) } else { if A_arbace_repr_clojure_A_const_34 != nil { var tmp31 any = A_arbace_repr_clojure_A_const_128; var tmp32 any = A_arbace_repr_clojure_A_const_19; var tmp33 any = A_arbace_repr_clojure_A_const_131; var tmp34 any; var root_1781 any = A_arbace_repr_clojure_A_const_132.GetRawRoot__O(); var linked_1782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1781, A_arbace_repr_clojure_first_difference_A_fn_class); var ifn_1783 lang.IFn



















									if linked_1782 == nil { ifn_1783 = lang.IFn_Cast(root_1781) } else { ifn_1783 = nil }; var arg_1784 any = orig__7; var arg_1785 any = txt__9; if linked_1782 == nil { tmp34 = ifn_1783.Invoke_O_O__O(arg_1784, arg_1785) } else { tmp34 = linked_1782.(*A_arbace_repr_clojure_first_difference_A).Invoke_O_O_O__O(root_1781, arg_1784, arg_1785) }
//line :287:1
									tmp6 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp31, tmp32, tmp33, tmp34)) } else { tmp6 = nil } } } } } }
//line :282:1
	arg_1701 = lang.Tuple_Create_O_O__IPersistentVector(rel__6, tmp6); var arg_1702 any; var tmp35 lang.IFn = lang.IFn_Cast(t.F_iter__716000185); var tmp36 any; var root_1790 any = A_arbace_repr_clojure_A_const_67.GetRawRoot__O(); var linked_1791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1790, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1792 lang.IFn; if linked_1791 == nil { ifn_1792 = lang.IFn_Cast(root_1790) } else { ifn_1792 = nil }; var arg_1793 any = s__716000186__3; if linked_1791 == nil { tmp36 = ifn_1792.Invoke_O__O(arg_1793) } else { tmp36 = linked_1791.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1790, arg_1793) }; arg_1702 = tmp35.Invoke_O__O(tmp36); if linked_1699 == nil { return ifn_1700.Invoke_O_O__O(arg_1701, arg_1702) } else { return linked_1699.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1698, arg_1701, arg_1702) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :282:1
func A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_fn__716000191_A_New_O_O_O_O_O_O_I_O_O_O(p0, p1, p2, p3, p4, p5 any, p6 int32, p7, p8, p9 any) *A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_fn__716000191_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_fn__716000191_A{}; t.Ctor_O_O_O_O_O_O_I_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9); return t }
//line :282:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_fn__716000191_A) Ctor_O_O_O_O_O_O_I_O_O_O(c__back2, c__t, c__b__716000188, c__a, c__b, c__c any, c__size__1927001038__auto__ int32, c__back, c__opts, c__c__1927001037__auto__ any) { t.F_back2 = c__back2; t.F_t = c__t; t.F_b__716000188 = c__b__716000188; t.F_a = c__a; t.F_b = c__b; t.F_c = c__c; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_back = c__back; t.F_opts = c__opts; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :282:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_fn__716000191_A) Invoke_O__O(self any) any { { var i__716000187__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__716000187__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__716000192__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__716000187__1)); var out__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000192__2, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000192__2, lang.RT_IntCast_J__I_NoInit(1), nil); var orig__5 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_78.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_t).Invoke_O__O(rel__4)); var out2__6 any = lang.IFn_Cast(t.F_back).Invoke_O__O(out__3); var txt__7 any


	if jrt.J2g_Truth(out2__6) { var root_1555 any = A_arbace_repr_clojure_A_const_124.GetRawRoot__O(); var linked_1556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1555, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1557 lang.IFn; if linked_1556 == nil { ifn_1557 = lang.IFn_Cast(root_1555) } else { ifn_1557 = nil }; var arg_1558 any = t.F_b; var arg_1559 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_clojure_A_const_109, out2__6); if linked_1556 == nil { txt__7 = ifn_1557.Invoke_O_O__O(arg_1558, arg_1559) } else { txt__7 = linked_1556.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1555, arg_1558, arg_1559) } } else { txt__7 = nil }
//line :282:1
	var p__8 any; var root_1560 any = A_arbace_repr_clojure_A_const_124.GetRawRoot__O(); var linked_1561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1560, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1562 lang.IFn



	if linked_1561 == nil { ifn_1562 = lang.IFn_Cast(root_1560) } else { ifn_1562 = nil }; var arg_1563 any = t.F_a; var arg_1564 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_clojure_A_const_113, out__3); if linked_1561 == nil { p__8 = ifn_1562.Invoke_O_O__O(arg_1563, arg_1564) } else { p__8 = linked_1561.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1560, arg_1563, arg_1564) }
//line :282:1
	var root_1565 any = A_arbace_repr_clojure_A_const_61.GetRawRoot__O(); var linked_1566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1565, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1567 lang.IFn; if linked_1566 == nil { ifn_1567 = lang.IFn_Cast(root_1565) } else { ifn_1567 = nil }; var arg_1568 any = t.F_b__716000188; var arg_1569 any; var tmp2 any




	if lang.Util_Identical_O_O__Z_NoInit(out2__6, nil) { tmp2 = A_arbace_repr_clojure_A_const_125 } else { var tmp3 any; var tmp4 any = A_arbace_repr_clojure_A_const_25; var and__1927000168__auto____9 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp4, A_arbace_repr_clojure_A_const_24.Invoke_O__O(p__8))

		if and__1927000168__auto____9 { var and__1927000168__auto____10 any = A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__8); if jrt.J2g_Truth(and__1927000168__auto____10) { var and__1927000168__auto____11 any; var root_1570 any = A_arbace_repr_clojure_A_const_41.GetRawRoot__O(); var linked_1571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1570, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1572 lang.IFn; if linked_1571 == nil { ifn_1572 = lang.IFn_Cast(root_1570) } else { ifn_1572 = nil }; var arg_1573 any = A_arbace_repr_clojure_A_const_20.Invoke_O__O(p__8); if linked_1571 == nil { and__1927000168__auto____11 = ifn_1572.Invoke_O__O(arg_1573) } else { and__1927000168__auto____11 = linked_1571.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1570, arg_1573) }; if jrt.J2g_Truth(and__1927000168__auto____11) {
			var root_1574 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_1575 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1574, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1576 lang.IFn; if linked_1575 == nil { ifn_1576 = lang.IFn_Cast(root_1574) } else { ifn_1576 = nil }; var arg_1577 any = A_arbace_repr_clojure_A_const_119; var arg_1578 any = A_arbace_repr_clojure_A_const_112.Invoke_O__O(t.F_opts); if linked_1575 == nil { tmp3 = ifn_1576.Invoke_O_O__O(arg_1577, arg_1578) } else { tmp3 = linked_1575.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1574, arg_1577, arg_1578) } } else {
//line :289:1
				tmp3 = and__1927000168__auto____11 } } else { tmp3 = and__1927000168__auto____10 } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____9).Ref() }
//line :287:1
		if jrt.J2g_Truth(tmp3) { var want__9 any; var root_1579 any = A_arbace_repr_clojure_A_const_110.GetRawRoot__O(); var linked_1580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1579, A_arbace_repr_clojure_under_A_fn_class); var ifn_1581 lang.IFn



			if linked_1580 == nil { ifn_1581 = lang.IFn_Cast(root_1579) } else { ifn_1581 = nil }; var arg_1582 any; var root_1584 any = A_arbace_repr_clojure_A_const_104.GetRawRoot__O(); var linked_1585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1584, A_arbace_repr_clojure_parent_of_A_fn_class); var ifn_1586 lang.IFn; if linked_1585 == nil { ifn_1586 = lang.IFn_Cast(root_1584) } else { ifn_1586 = nil }; var arg_1587 any = rel__4; if linked_1585 == nil { arg_1582 = ifn_1586.Invoke_O__O(arg_1587) } else { arg_1582 = linked_1585.(*A_arbace_repr_clojure_parent_of_A).Invoke_O_O__O(root_1584, arg_1587) }; var arg_1583 any; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_53); var tmp6 any; var root_1588 any = A_arbace_repr_clojure_A_const_32.GetRawRoot__O(); var linked_1589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1588, A_arbace_repr_clojure_base_A_fn_class); var ifn_1590 lang.IFn; if linked_1589 == nil { ifn_1590 = lang.IFn_Cast(root_1588) } else { ifn_1590 = nil }; var arg_1591 any; var root_1592 any = A_arbace_repr_clojure_A_const_106.GetRawRoot__O(); var linked_1593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1592, A_arbace_repr_clojure_name_of_A_fn_class); var ifn_1594 lang.IFn; if linked_1593 == nil { ifn_1594 = lang.IFn_Cast(root_1592) } else { ifn_1594 = nil }; var arg_1595 any = rel__4; if linked_1593 == nil { arg_1591 = ifn_1594.Invoke_O__O(arg_1595) } else { arg_1591 = linked_1593.(*A_arbace_repr_clojure_name_of_A).Invoke_O_O__O(root_1592, arg_1595) }; if linked_1589 == nil { tmp6 = ifn_1590.Invoke_O__O(arg_1591) } else { tmp6 = linked_1589.(*A_arbace_repr_clojure_base_A).Invoke_O_O__O(root_1588, arg_1591) }; arg_1583 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp6, nil)).Ref(); if linked_1580 == nil { want__9 = ifn_1581.Invoke_O_O__O(arg_1582, arg_1583) } else { want__9 = linked_1580.(*A_arbace_repr_clojure_under_A).Invoke_O_O_O__O(root_1579, arg_1582, arg_1583) }
//line :287:1
			var resolved__10 any; var root_1596 any = A_arbace_repr_clojure_A_const_126.GetRawRoot__O(); var linked_1597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1596, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_resolve_conditionals_A_fn_class); var ifn_1598 lang.IFn




			if linked_1597 == nil { ifn_1598 = lang.IFn_Cast(root_1596) } else { ifn_1598 = nil }; var arg_1599 any = orig__5; var arg_1600 any = A_arbace_repr_clojure_A_const_127; if linked_1597 == nil { resolved__10 = ifn_1598.Invoke_O_O__O(arg_1599, arg_1600) } else { resolved__10 = linked_1597.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_resolve_conditionals_A).Invoke_O_O_O__O(root_1596, arg_1599, arg_1600) }
			var tmp7 any; var root_1601 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_1602 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1601, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1603 lang.IFn; if linked_1602 == nil { ifn_1603 = lang.IFn_Cast(root_1601) } else { ifn_1603 = nil }; var arg_1604 any = out2__6; var arg_1605 any = want__9; if linked_1602 == nil { tmp7 = ifn_1603.Invoke_O_O__O(arg_1604, arg_1605) } else { tmp7 = linked_1602.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1601, arg_1604, arg_1605) }; if jrt.J2g_Truth(tmp7) { tmp2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_128, A_arbace_repr_clojure_A_const_129, A_arbace_repr_clojure_A_const_130, out2__6)) } else { var tmp8 any; var root_1606 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_1607 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1606, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1608 lang.IFn
				if linked_1607 == nil { ifn_1608 = lang.IFn_Cast(root_1606) } else { ifn_1608 = nil }; var arg_1609 any = txt__7; var arg_1610 any = resolved__10; if linked_1607 == nil { tmp8 = ifn_1608.Invoke_O_O__O(arg_1609, arg_1610) } else { tmp8 = linked_1607.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1606, arg_1609, arg_1610) }
//line :293:1
				if jrt.J2g_Truth(tmp8) { var tmp9 any = A_arbace_repr_clojure_A_const_128; var tmp10 any = A_arbace_repr_clojure_A_const_19; var tmp11 any = A_arbace_repr_clojure_A_const_131; var tmp12 any; var root_1611 any = A_arbace_repr_clojure_A_const_132.GetRawRoot__O(); var linked_1612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1611, A_arbace_repr_clojure_first_difference_A_fn_class); var ifn_1613 lang.IFn
					if linked_1612 == nil { ifn_1613 = lang.IFn_Cast(root_1611) } else { ifn_1613 = nil }; var arg_1614 any = resolved__10; var arg_1615 any = txt__7; if linked_1612 == nil { tmp12 = ifn_1613.Invoke_O_O__O(arg_1614, arg_1615) } else { tmp12 = linked_1612.(*A_arbace_repr_clojure_first_difference_A).Invoke_O_O_O__O(root_1611, arg_1614, arg_1615) }
//line :293:1
					tmp2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, tmp11, tmp12)) } else { if A_arbace_repr_clojure_A_const_34 != nil { tmp2 = A_arbace_repr_clojure_A_const_133 } else { tmp2 = nil } } } } else {
//line :287:1
						var tmp13 any; var root_1616 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_1617 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1616, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1618 lang.IFn








						if linked_1617 == nil { ifn_1618 = lang.IFn_Cast(root_1616) } else { ifn_1618 = nil }; var arg_1619 any = out2__6; var arg_1620 any = rel__4; if linked_1617 == nil { tmp13 = ifn_1618.Invoke_O_O__O(arg_1619, arg_1620) } else { tmp13 = linked_1617.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1616, arg_1619, arg_1620) }
//line :287:1
						if jrt.J2g_Truth(tmp13) { tmp2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_128, A_arbace_repr_clojure_A_const_129, A_arbace_repr_clojure_A_const_130, out2__6)) } else { if lang.Util_Equiv_O_O__Z_NoInit(txt__7, orig__5) { tmp2 = nil } else { var tmp14 any; var tmp15 any = A_arbace_repr_clojure_A_const_119; var and__1927000168__auto____9_2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp15, A_arbace_repr_clojure_A_const_112.Invoke_O__O(t.F_opts))












							if and__1927000168__auto____9_2 { var and__1927000168__auto____10_2 any; var p__10 any; var tmp16 *lang.Keyword = A_arbace_repr_clojure_A_const_70; var tmp17 lang.IFn = lang.IFn_Cast(tmp16.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_A_const_69.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_A_const_99))); var tmp18 any; var root_1653 any = A_arbace_repr_clojure_A_const_106.GetRawRoot__O(); var linked_1654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1653, A_arbace_repr_clojure_name_of_A_fn_class); var ifn_1655 lang.IFn
								if linked_1654 == nil { ifn_1655 = lang.IFn_Cast(root_1653) } else { ifn_1655 = nil }; var arg_1656 any = out__3; if linked_1654 == nil { tmp18 = ifn_1655.Invoke_O__O(arg_1656) } else { tmp18 = linked_1654.(*A_arbace_repr_clojure_name_of_A).Invoke_O_O__O(root_1653, arg_1656) }; p__10 = tmp17.Invoke_O_O_O__O(tmp18, lang.PersistentHashSet_EMPTY.Ref(), t.F_opts)
//line :300:1
								var and__1927000168__auto____11_2 any = A_arbace_repr_clojure_A_const_24.Invoke_O__O(p__10)

								if jrt.J2g_Truth(and__1927000168__auto____11_2) {
									var root_1621 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_1622 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1621, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1623 lang.IFn; if linked_1622 == nil { ifn_1623 = lang.IFn_Cast(root_1621) } else { ifn_1623 = nil }; var arg_1624 any = orig__5; var arg_1625 any; var root_1626 any = A_arbace_repr_clojure_A_const_134.GetRawRoot__O(); var linked_1627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1626, A_arbace_repr_clojure_translate_text_A_fn_class); var ifn_1628 lang.IFn; if linked_1627 == nil { ifn_1628 = lang.IFn_Cast(root_1626) } else { ifn_1628 = nil }; var arg_1629 any = orig__5; var arg_1630 any = p__10; var arg_1631 any = rel__4; var arg_1632 any = A_arbace_repr_clojure_A_const_33.Invoke_O_O__O(t.F_opts, lang.PersistentHashSet_EMPTY.Ref()); if linked_1627 == nil { arg_1625 = ifn_1628.Invoke_O_O_O_O__O(arg_1629, arg_1630, arg_1631, arg_1632) } else { arg_1625 = linked_1627.(*A_arbace_repr_clojure_translate_text_A).Invoke_O_O_O_O_O__O(root_1626, arg_1629, arg_1630, arg_1631, arg_1632) }; if linked_1622 == nil { and__1927000168__auto____10_2 = ifn_1623.Invoke_O_O__O(arg_1624, arg_1625) } else { and__1927000168__auto____10_2 = linked_1622.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1621, arg_1624, arg_1625) } } else {
//line :302:1
										and__1927000168__auto____10_2 = and__1927000168__auto____11_2 }
//line :300:1
								if jrt.J2g_Truth(and__1927000168__auto____10_2) {




									var tmp19 any; var root_1633 any = A_arbace_repr_clojure_A_const_124.GetRawRoot__O(); var linked_1634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1633, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1635 lang.IFn; if linked_1634 == nil { ifn_1635 = lang.IFn_Cast(root_1633) } else { ifn_1635 = nil }; var arg_1636 any = t.F_a; var arg_1637 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_clojure_A_const_109, out__3); if linked_1634 == nil { tmp19 = ifn_1635.Invoke_O_O__O(arg_1636, arg_1637) } else { tmp19 = linked_1634.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1633, arg_1636, arg_1637) }; var tmp20 any = tmp19; var tmp21 any; var root_1638 any = A_arbace_repr_clojure_A_const_124.GetRawRoot__O(); var linked_1639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1638, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1640 lang.IFn; if linked_1639 == nil { ifn_1640 = lang.IFn_Cast(root_1638) } else { ifn_1640 = nil }; var arg_1641 any = t.F_c; var tmp22 any = A_arbace_repr_clojure_A_const_109; var arg_1642 any = lang.Tuple_Create_O_O__IPersistentVector(tmp22, lang.IFn_Cast(t.F_back2).Invoke_O__O(out2__6)); if linked_1639 == nil { tmp21 = ifn_1640.Invoke_O_O__O(arg_1641, arg_1642) } else { tmp21 = linked_1639.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1638, arg_1641, arg_1642) }; tmp14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp20, tmp21)).Ref() } else {
//line :300:1
										tmp14 = and__1927000168__auto____10_2 } } else { tmp14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____9_2).Ref() }
//line :287:1
							if jrt.J2g_Truth(tmp14) { var tmp23 any = A_arbace_repr_clojure_A_const_128; var tmp24 any = A_arbace_repr_clojure_A_const_135; var tmp25 any = A_arbace_repr_clojure_A_const_131; var tmp26 any; var root_1643 any = A_arbace_repr_clojure_A_const_132.GetRawRoot__O(); var linked_1644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1643, A_arbace_repr_clojure_first_difference_A_fn_class); var ifn_1645 lang.IFn


















								if linked_1644 == nil { ifn_1645 = lang.IFn_Cast(root_1643) } else { ifn_1645 = nil }; var arg_1646 any = orig__5; var arg_1647 any = txt__7; if linked_1644 == nil { tmp26 = ifn_1645.Invoke_O_O__O(arg_1646, arg_1647) } else { tmp26 = linked_1644.(*A_arbace_repr_clojure_first_difference_A).Invoke_O_O_O__O(root_1643, arg_1646, arg_1647) }
//line :287:1
								tmp2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp23, tmp24, tmp25, tmp26)) } else { if A_arbace_repr_clojure_A_const_34 != nil { var tmp27 any = A_arbace_repr_clojure_A_const_128; var tmp28 any = A_arbace_repr_clojure_A_const_19; var tmp29 any = A_arbace_repr_clojure_A_const_131; var tmp30 any; var root_1648 any = A_arbace_repr_clojure_A_const_132.GetRawRoot__O(); var linked_1649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1648, A_arbace_repr_clojure_first_difference_A_fn_class); var ifn_1650 lang.IFn



















									if linked_1649 == nil { ifn_1650 = lang.IFn_Cast(root_1648) } else { ifn_1650 = nil }; var arg_1651 any = orig__5; var arg_1652 any = txt__7; if linked_1649 == nil { tmp30 = ifn_1650.Invoke_O_O__O(arg_1651, arg_1652) } else { tmp30 = linked_1649.(*A_arbace_repr_clojure_first_difference_A).Invoke_O_O_O__O(root_1648, arg_1651, arg_1652) }
//line :287:1
									tmp2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp27, tmp28, tmp29, tmp30)) } else { tmp2 = nil } } } } } }
//line :282:1
	arg_1569 = lang.Tuple_Create_O_O__IPersistentVector(rel__4, tmp2); if linked_1566 == nil { ifn_1567.Invoke_O_O__O(arg_1568, arg_1569) } else { linked_1566.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1565, arg_1568, arg_1569) }; i__716000187__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__716000187__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





























func A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_A_New() *A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_A{}; t.Ctor(); return t }
//line :312:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_A) Ctor() {}
//line :312:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_A) Invoke_O_O__O(self, s__716000202__1 any) any { var tmp1 any = A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_A_New_O_O(self, s__716000202__1); var tmp2 *jrt.Class; var fncls__1877 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_A_fn_class; if fncls__1877 == nil { var fncls__1877d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_82, false); A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_A_fn_class = fncls__1877d; tmp2 = fncls__1877d } else { tmp2 = fncls__1877 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :312:1
func A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_A{}; t.Ctor_O_O(p0, p1); return t }
//line :312:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_A) Ctor_O_O(c__iter__716000201, c__s__716000202 any) { t.F_iter__716000201 = c__iter__716000201; t.F_s__716000202 = c__s__716000202 }
//line :312:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_A) Invoke_O__O(self any) any { { var s__716000202__1 any; var t_ any = t.F_s__716000202; t.F_s__716000202 = nil; s__716000202__1 = t_; for { var temp__1927000414__auto____2 any; var root_1820 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_1821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1820, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1822 lang.IFn; if linked_1821 == nil { ifn_1822 = lang.IFn_Cast(root_1820) } else { ifn_1822 = nil }; var arg_1823 any = s__716000202__1; if linked_1821 == nil { temp__1927000414__auto____2 = ifn_1822.Invoke_O__O(arg_1823) } else { temp__1927000414__auto____2 = linked_1821.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1820, arg_1823) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__716000202__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1824 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_1825 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1824, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1826 lang.IFn; if linked_1825 == nil { ifn_1826 = lang.IFn_Cast(root_1824) } else { ifn_1826 = nil }; var arg_1827 any = s__716000202__3; if linked_1825 == nil { tmp1 = ifn_1826.Invoke_O__O(arg_1827) } else { tmp1 = linked_1825.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1824, arg_1827) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1828 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_1829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1828, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1830 lang.IFn; if linked_1829 == nil { ifn_1830 = lang.IFn_Cast(root_1828) } else { ifn_1830 = nil }; var arg_1831 any = s__716000202__3; if linked_1829 == nil { c__1927001037__auto____4 = ifn_1830.Invoke_O__O(arg_1831) } else { c__1927001037__auto____4 = linked_1829.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1828, arg_1831) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__716000204__6 any; var root_1832 any = A_arbace_repr_clojure_A_const_60.GetRawRoot__O(); var linked_1833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1832, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1834 lang.IFn; if linked_1833 == nil { ifn_1834 = lang.IFn_Cast(root_1832) } else { ifn_1834 = nil }; var arg_1835 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1833 == nil { b__716000204__6 = ifn_1834.Invoke_O__O(arg_1835) } else { b__716000204__6 = linked_1833.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1832, arg_1835) }; var tmp2 any = A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_fn__716000207_A_New_O_I_O(b__716000204__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1841 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_fn__716000207_A_fn_class; if fncls__1841 == nil { var fncls__1841d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, false); A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_fn__716000207_A_fn_class = fncls__1841d; tmp3 = fncls__1841d } else { tmp3 = fncls__1841 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1842 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_1843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1842, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1844 lang.IFn; if linked_1843 == nil { ifn_1844 = lang.IFn_Cast(root_1842) } else { ifn_1844 = nil }; var arg_1845 any; var root_1847 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_1848 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1847, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1849 lang.IFn; if linked_1848 == nil { ifn_1849 = lang.IFn_Cast(root_1847) } else { ifn_1849 = nil }; var arg_1850 any = b__716000204__6; if linked_1848 == nil { arg_1845 = ifn_1849.Invoke_O__O(arg_1850) } else { arg_1845 = linked_1848.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1847, arg_1850) }; var arg_1846 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__716000201); var tmp5 any; var root_1851 any = A_arbace_repr_clojure_A_const_65.GetRawRoot__O(); var linked_1852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1851, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1853 lang.IFn; if linked_1852 == nil { ifn_1853 = lang.IFn_Cast(root_1851) } else { ifn_1853 = nil }; var arg_1854 any = s__716000202__3; if linked_1852 == nil { tmp5 = ifn_1853.Invoke_O__O(arg_1854) } else { tmp5 = linked_1852.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1851, arg_1854) }; arg_1846 = tmp4.Invoke_O__O(tmp5); if linked_1843 == nil { return ifn_1844.Invoke_O_O__O(arg_1845, arg_1846) } else { return linked_1843.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1842, arg_1845, arg_1846) } } else { var root_1855 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_1856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1855, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1857 lang.IFn; if linked_1856 == nil { ifn_1857 = lang.IFn_Cast(root_1855) } else { ifn_1857 = nil }; var arg_1858 any; var root_1860 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_1861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1860, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1862 lang.IFn; if linked_1861 == nil { ifn_1862 = lang.IFn_Cast(root_1860) } else { ifn_1862 = nil }; var arg_1863 any = b__716000204__6; if linked_1861 == nil { arg_1858 = ifn_1862.Invoke_O__O(arg_1863) } else { arg_1858 = linked_1861.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1860, arg_1863) }; var arg_1859 any; if linked_1856 == nil { return ifn_1857.Invoke_O_O__O(arg_1858, arg_1859) } else { return linked_1856.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1855, arg_1858, arg_1859) } } } else { var vec__716000212__4 any; var root_1864 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_1865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1864, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1866 lang.IFn; if linked_1865 == nil { ifn_1866 = lang.IFn_Cast(root_1864) } else { ifn_1866 = nil }; var arg_1867 any = s__716000202__3; if linked_1865 == nil { vec__716000212__4 = ifn_1866.Invoke_O__O(arg_1867) } else { vec__716000212__4 = linked_1865.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1864, arg_1867) }; var rel__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000212__4, lang.RT_IntCast_J__I_NoInit(0), nil); var m__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000212__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1868 any = A_arbace_repr_clojure_A_const_66.GetRawRoot__O(); var linked_1869 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1868, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1870 lang.IFn; if linked_1869 == nil { ifn_1870 = lang.IFn_Cast(root_1868) } else { ifn_1870 = nil }; var arg_1871 any = lang.Tuple_Create_O_O__IPersistentVector(rel__5, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_128, A_arbace_repr_clojure_A_const_114, A_arbace_repr_clojure_A_const_131, m__6))); var arg_1872 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__716000201); var tmp7 any; var root_1873 any = A_arbace_repr_clojure_A_const_67.GetRawRoot__O(); var linked_1874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1873, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1875 lang.IFn; if linked_1874 == nil { ifn_1875 = lang.IFn_Cast(root_1873) } else { ifn_1875 = nil }; var arg_1876 any = s__716000202__3; if linked_1874 == nil { tmp7 = ifn_1875.Invoke_O__O(arg_1876) } else { tmp7 = linked_1874.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1873, arg_1876) }; arg_1872 = tmp6.Invoke_O__O(tmp7); if linked_1869 == nil { return ifn_1870.Invoke_O_O__O(arg_1871, arg_1872) } else { return linked_1869.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1868, arg_1871, arg_1872) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :312:1
func A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_fn__716000207_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_fn__716000207_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_fn__716000207_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :312:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_fn__716000207_A) Ctor_O_I_O(c__b__716000204 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__716000204 = c__b__716000204; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :312:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_fn__716000207_A) Invoke_O__O(self any) any { { var i__716000203__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__716000203__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__716000208__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__716000203__1)); var rel__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000208__2, lang.RT_IntCast_J__I_NoInit(0), nil); var m__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000208__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1836 any = A_arbace_repr_clojure_A_const_61.GetRawRoot__O(); var linked_1837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1836, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1838 lang.IFn; if linked_1837 == nil { ifn_1838 = lang.IFn_Cast(root_1836) } else { ifn_1838 = nil }; var arg_1839 any = t.F_b__716000204; var arg_1840 any = lang.Tuple_Create_O_O__IPersistentVector(rel__3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_128, A_arbace_repr_clojure_A_const_114, A_arbace_repr_clojure_A_const_131, m__4))); if linked_1837 == nil { ifn_1838.Invoke_O_O__O(arg_1839, arg_1840) } else { linked_1837.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1836, arg_1839, arg_1840) }; i__716000203__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__716000203__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_A_New_O(p0 any) *A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_A{}; t.Ctor_O(p0); return t }
//line :314:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_A) Ctor_O(c__a any) { t.F_a = c__a }
//line :314:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_A) Invoke_O_O__O(self, s__716000218__1 any) any { var tmp1 any = A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_A_New_O_O_O(self, s__716000218__1, t.F_a); var tmp2 *jrt.Class; var fncls__1936 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_A_fn_class; if fncls__1936 == nil { var fncls__1936d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_84, false); A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_A_fn_class = fncls__1936d; tmp2 = fncls__1936d } else { tmp2 = fncls__1936 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :314:1
func A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :314:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_A) Ctor_O_O_O(c__iter__716000217, c__s__716000218, c__a any) { t.F_iter__716000217 = c__iter__716000217; t.F_s__716000218 = c__s__716000218; t.F_a = c__a }
//line :314:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_A) Invoke_O__O(self any) any { { var s__716000218__1 any; var t_ any = t.F_s__716000218; t.F_s__716000218 = nil; s__716000218__1 = t_; for { var temp__1927000414__auto____2 any; var root_1879 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_1880 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1879, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1881 lang.IFn; if linked_1880 == nil { ifn_1881 = lang.IFn_Cast(root_1879) } else { ifn_1881 = nil }; var arg_1882 any = s__716000218__1; if linked_1880 == nil { temp__1927000414__auto____2 = ifn_1881.Invoke_O__O(arg_1882) } else { temp__1927000414__auto____2 = linked_1880.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1879, arg_1882) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__716000218__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1883 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_1884 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1883, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1885 lang.IFn; if linked_1884 == nil { ifn_1885 = lang.IFn_Cast(root_1883) } else { ifn_1885 = nil }; var arg_1886 any = s__716000218__3; if linked_1884 == nil { tmp1 = ifn_1885.Invoke_O__O(arg_1886) } else { tmp1 = linked_1884.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1883, arg_1886) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1887 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_1888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1887, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1889 lang.IFn; if linked_1888 == nil { ifn_1889 = lang.IFn_Cast(root_1887) } else { ifn_1889 = nil }; var arg_1890 any = s__716000218__3; if linked_1888 == nil { c__1927001037__auto____4 = ifn_1889.Invoke_O__O(arg_1890) } else { c__1927001037__auto____4 = linked_1888.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1887, arg_1890) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__716000220__6 any; var root_1891 any = A_arbace_repr_clojure_A_const_60.GetRawRoot__O(); var linked_1892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1891, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1893 lang.IFn; if linked_1892 == nil { ifn_1893 = lang.IFn_Cast(root_1891) } else { ifn_1893 = nil }; var arg_1894 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1892 == nil { b__716000220__6 = ifn_1893.Invoke_O__O(arg_1894) } else { b__716000220__6 = linked_1892.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1891, arg_1894) }; var tmp2 any = A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_fn__716000223_A_New_O_O_I_O(b__716000220__6, t.F_a, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1900 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_fn__716000223_A_fn_class; if fncls__1900 == nil { var fncls__1900d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_85, false); A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_fn__716000223_A_fn_class = fncls__1900d; tmp3 = fncls__1900d } else { tmp3 = fncls__1900 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1901 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_1902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1901, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1903 lang.IFn; if linked_1902 == nil { ifn_1903 = lang.IFn_Cast(root_1901) } else { ifn_1903 = nil }; var arg_1904 any; var root_1906 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_1907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1906, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1908 lang.IFn; if linked_1907 == nil { ifn_1908 = lang.IFn_Cast(root_1906) } else { ifn_1908 = nil }; var arg_1909 any = b__716000220__6; if linked_1907 == nil { arg_1904 = ifn_1908.Invoke_O__O(arg_1909) } else { arg_1904 = linked_1907.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1906, arg_1909) }; var arg_1905 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__716000217); var tmp5 any; var root_1910 any = A_arbace_repr_clojure_A_const_65.GetRawRoot__O(); var linked_1911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1910, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1912 lang.IFn; if linked_1911 == nil { ifn_1912 = lang.IFn_Cast(root_1910) } else { ifn_1912 = nil }; var arg_1913 any = s__716000218__3; if linked_1911 == nil { tmp5 = ifn_1912.Invoke_O__O(arg_1913) } else { tmp5 = linked_1911.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1910, arg_1913) }; arg_1905 = tmp4.Invoke_O__O(tmp5); if linked_1902 == nil { return ifn_1903.Invoke_O_O__O(arg_1904, arg_1905) } else { return linked_1902.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1901, arg_1904, arg_1905) } } else { var root_1914 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_1915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1914, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1916 lang.IFn; if linked_1915 == nil { ifn_1916 = lang.IFn_Cast(root_1914) } else { ifn_1916 = nil }; var arg_1917 any; var root_1919 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_1920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1919, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1921 lang.IFn; if linked_1920 == nil { ifn_1921 = lang.IFn_Cast(root_1919) } else { ifn_1921 = nil }; var arg_1922 any = b__716000220__6; if linked_1920 == nil { arg_1917 = ifn_1921.Invoke_O__O(arg_1922) } else { arg_1917 = linked_1920.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1919, arg_1922) }; var arg_1918 any; if linked_1915 == nil { return ifn_1916.Invoke_O_O__O(arg_1917, arg_1918) } else { return linked_1915.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1914, arg_1917, arg_1918) } } } else { var vec__716000228__4 any; var root_1923 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_1924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1923, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1925 lang.IFn; if linked_1924 == nil { ifn_1925 = lang.IFn_Cast(root_1923) } else { ifn_1925 = nil }; var arg_1926 any = s__716000218__3; if linked_1924 == nil { vec__716000228__4 = ifn_1925.Invoke_O__O(arg_1926) } else { vec__716000228__4 = linked_1924.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1923, arg_1926) }; var out__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000228__4, lang.RT_IntCast_J__I_NoInit(0), nil); var m__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000228__4, lang.RT_IntCast_J__I_NoInit(1), nil); var rel__7 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_112.Invoke_O__O(t.F_a)).Invoke_O__O(out__5); var root_1927 any = A_arbace_repr_clojure_A_const_66.GetRawRoot__O(); var linked_1928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1927, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1929 lang.IFn; if linked_1928 == nil { ifn_1929 = lang.IFn_Cast(root_1927) } else { ifn_1929 = nil }; var arg_1930 any = lang.Tuple_Create_O_O__IPersistentVector(rel__7, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_128, A_arbace_repr_clojure_A_const_114, A_arbace_repr_clojure_A_const_131, m__6))); var arg_1931 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__716000217); var tmp7 any; var root_1932 any = A_arbace_repr_clojure_A_const_67.GetRawRoot__O(); var linked_1933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1932, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1934 lang.IFn; if linked_1933 == nil { ifn_1934 = lang.IFn_Cast(root_1932) } else { ifn_1934 = nil }; var arg_1935 any = s__716000218__3; if linked_1933 == nil { tmp7 = ifn_1934.Invoke_O__O(arg_1935) } else { tmp7 = linked_1933.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1932, arg_1935) }; arg_1931 = tmp6.Invoke_O__O(tmp7); if linked_1928 == nil { return ifn_1929.Invoke_O_O__O(arg_1930, arg_1931) } else { return linked_1928.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1927, arg_1930, arg_1931) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :314:1
func A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_fn__716000223_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_fn__716000223_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_fn__716000223_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :314:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_fn__716000223_A) Ctor_O_O_I_O(c__b__716000220, c__a any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__716000220 = c__b__716000220; t.F_a = c__a; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :314:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_fn__716000223_A) Invoke_O__O(self any) any { { var i__716000219__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__716000219__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__716000224__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__716000219__1)); var out__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000224__2, lang.RT_IntCast_J__I_NoInit(0), nil); var m__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000224__2, lang.RT_IntCast_J__I_NoInit(1), nil); var rel__5 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_112.Invoke_O__O(t.F_a)).Invoke_O__O(out__3); var root_1895 any = A_arbace_repr_clojure_A_const_61.GetRawRoot__O(); var linked_1896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1895, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1897 lang.IFn; if linked_1896 == nil { ifn_1897 = lang.IFn_Cast(root_1895) } else { ifn_1897 = nil }; var arg_1898 any = t.F_b__716000220; var arg_1899 any = lang.Tuple_Create_O_O__IPersistentVector(rel__5, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_128, A_arbace_repr_clojure_A_const_114, A_arbace_repr_clojure_A_const_131, m__4))); if linked_1896 == nil { ifn_1897.Invoke_O_O__O(arg_1898, arg_1899) } else { linked_1896.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1895, arg_1898, arg_1899) }; i__716000219__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__716000219__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_repr_clojure_parse_args_A_New() *A_arbace_repr_clojure_parse_args_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_parse_args_A{}; t.Ctor(); return t }
//line :317:1
func (t *A_arbace_repr_clojure_parse_args_A) Ctor() {}
//line :317:1
func (t *A_arbace_repr_clojure_parse_args_A) Invoke_O_O__O(self, args__0 any) any { { var G__716000237__2_ any = args__0; var vec__716000238__3 any = G__716000237__2_; var seq__716000239__4 any; var root_1938 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_1939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1938, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1940 lang.IFn
											if linked_1939 == nil { ifn_1940 = lang.IFn_Cast(root_1938) } else { ifn_1940 = nil }; var arg_1941 any = vec__716000238__3; if linked_1939 == nil { seq__716000239__4 = ifn_1940.Invoke_O__O(arg_1941) } else { seq__716000239__4 = linked_1939.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1938, arg_1941) }
//line :317:1
	var first__716000240__5 any; var root_1942 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_1943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1942, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1944 lang.IFn
	if linked_1943 == nil { ifn_1944 = lang.IFn_Cast(root_1942) } else { ifn_1944 = nil }; var arg_1945 any = seq__716000239__4; if linked_1943 == nil { first__716000240__5 = ifn_1944.Invoke_O__O(arg_1945) } else { first__716000240__5 = linked_1943.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1942, arg_1945) }
//line :317:1
	var seq__716000239__6 any; var root_1946 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_1947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1946, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1948 lang.IFn
	if linked_1947 == nil { ifn_1948 = lang.IFn_Cast(root_1946) } else { ifn_1948 = nil }; var arg_1949 any = seq__716000239__4; if linked_1947 == nil { seq__716000239__6 = ifn_1948.Invoke_O__O(arg_1949) } else { seq__716000239__6 = linked_1947.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1946, arg_1949) }
//line :317:1
	var a__7 any = first__716000240__5; var more__8 any = seq__716000239__6; var args__9 any = vec__716000238__3; var o__10 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_143, lang.PersistentVector_EMPTY.Ref(), A_arbace_repr_clojure_A_const_19, lang.PersistentVector_EMPTY.Ref(), A_arbace_repr_clojure_A_const_33, lang.PersistentHashSet_EMPTY.Ref(), A_arbace_repr_clojure_A_const_24, A_arbace_repr_clojure_A_const_26)); var G__716000237__11_ any = G__716000237__2_; var o__12 any = o__10; _ = a__7; _ = more__8; _ = args__9; L1: for { var vec__716000241__13 any = G__716000237__11_; var seq__716000242__14 any; var root_1950 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_1951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1950, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1952 lang.IFn
		if linked_1951 == nil { ifn_1952 = lang.IFn_Cast(root_1950) } else { ifn_1952 = nil }; var arg_1953 any = vec__716000241__13; if linked_1951 == nil { seq__716000242__14 = ifn_1952.Invoke_O__O(arg_1953) } else { seq__716000242__14 = linked_1951.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1950, arg_1953) }
//line :317:1
		var first__716000243__15 any; var root_1954 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_1955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1954, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1956 lang.IFn
		if linked_1955 == nil { ifn_1956 = lang.IFn_Cast(root_1954) } else { ifn_1956 = nil }; var arg_1957 any = seq__716000242__14; if linked_1955 == nil { first__716000243__15 = ifn_1956.Invoke_O__O(arg_1957) } else { first__716000243__15 = linked_1955.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1954, arg_1957) }
//line :317:1
		var seq__716000242__16 any; var root_1958 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_1959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1958, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1960 lang.IFn
		if linked_1959 == nil { ifn_1960 = lang.IFn_Cast(root_1958) } else { ifn_1960 = nil }; var arg_1961 any = seq__716000242__14; if linked_1959 == nil { seq__716000242__16 = ifn_1960.Invoke_O__O(arg_1961) } else { seq__716000242__16 = linked_1959.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1958, arg_1961) }
//line :317:1
		var a__17 any = first__716000243__15; var more__18 any = seq__716000242__16; var args__19 any = vec__716000241__13; var o__20 any = o__12; var tmp1 any; var root_1962 any = A_arbace_repr_clojure_A_const_144.GetRawRoot__O(); var linked_1963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1962, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1964 lang.IFn


		if linked_1963 == nil { ifn_1964 = lang.IFn_Cast(root_1962) } else { ifn_1964 = nil }; var arg_1965 any = args__19; if linked_1963 == nil { tmp1 = ifn_1964.Invoke_O__O(arg_1965) } else { tmp1 = linked_1963.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1962, arg_1965) }
//line :319:1
		if jrt.J2g_Truth(tmp1) { return o__20 } else { if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_30) {

			var tmp2 any; var root_1976 any = A_arbace_repr_clojure_A_const_67.GetRawRoot__O(); var linked_1977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1976, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1978 lang.IFn; if linked_1977 == nil { ifn_1978 = lang.IFn_Cast(root_1976) } else { ifn_1978 = nil }; var arg_1979 any = more__18; if linked_1977 == nil { tmp2 = ifn_1978.Invoke_O__O(arg_1979) } else { tmp2 = linked_1977.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1976, arg_1979) }; var tmp3 any = tmp2; var tmp4 any; var root_1980 any = A_arbace_repr_clojure_A_const_40.GetRawRoot__O(); var linked_1981 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1980, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1982 lang.IFn; if linked_1981 == nil { ifn_1982 = lang.IFn_Cast(root_1980) } else { ifn_1982 = nil }; var arg_1983 any = o__20; var arg_1984 any = A_arbace_repr_clojure_A_const_28; var arg_1985 any; var root_1986 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_1987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1986, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1988 lang.IFn; if linked_1987 == nil { ifn_1988 = lang.IFn_Cast(root_1986) } else { ifn_1988 = nil }; var arg_1989 any = more__18; if linked_1987 == nil { arg_1985 = ifn_1988.Invoke_O__O(arg_1989) } else { arg_1985 = linked_1987.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1986, arg_1989) }; if linked_1981 == nil { tmp4 = ifn_1982.Invoke_O_O_O__O(arg_1983, arg_1984, arg_1985) } else { tmp4 = linked_1981.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1980, arg_1983, arg_1984, arg_1985) }; G__716000237__11_, o__12 = tmp3, tmp4; continue L1 } else {
//line :319:1
				if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_31) {


					var tmp5 any; var root_1990 any = A_arbace_repr_clojure_A_const_40.GetRawRoot__O(); var linked_1991 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1990, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1992 lang.IFn; if linked_1991 == nil { ifn_1992 = lang.IFn_Cast(root_1990) } else { ifn_1992 = nil }; var arg_1993 any = o__20; var arg_1994 any = A_arbace_repr_clojure_A_const_147; var arg_1995 any = jrt.Boolean_TRUE.Ref(); if linked_1991 == nil { tmp5 = ifn_1992.Invoke_O_O_O__O(arg_1993, arg_1994, arg_1995) } else { tmp5 = linked_1991.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1990, arg_1993, arg_1994, arg_1995) }; G__716000237__11_, o__12 = more__18, tmp5; continue L1 } else {
//line :319:1
						if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_32) {



							var tmp6 any; var root_1996 any = A_arbace_repr_clojure_A_const_40.GetRawRoot__O(); var linked_1997 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1996, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1998 lang.IFn; if linked_1997 == nil { ifn_1998 = lang.IFn_Cast(root_1996) } else { ifn_1998 = nil }; var arg_1999 any = o__20; var arg_2000 any = A_arbace_repr_clojure_A_const_148; var arg_2001 any = jrt.Boolean_TRUE.Ref(); if linked_1997 == nil { tmp6 = ifn_1998.Invoke_O_O_O__O(arg_1999, arg_2000, arg_2001) } else { tmp6 = linked_1997.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1996, arg_1999, arg_2000, arg_2001) }; G__716000237__11_, o__12 = more__18, tmp6; continue L1 } else {
//line :319:1
								if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_33) {




									var tmp7 any; var root_2002 any = A_arbace_repr_clojure_A_const_40.GetRawRoot__O(); var linked_2003 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2002, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2004 lang.IFn; if linked_2003 == nil { ifn_2004 = lang.IFn_Cast(root_2002) } else { ifn_2004 = nil }; var arg_2005 any = o__20; var arg_2006 any = A_arbace_repr_clojure_A_const_149; var arg_2007 any = jrt.Boolean_TRUE.Ref(); if linked_2003 == nil { tmp7 = ifn_2004.Invoke_O_O_O__O(arg_2005, arg_2006, arg_2007) } else { tmp7 = linked_2003.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2002, arg_2005, arg_2006, arg_2007) }; G__716000237__11_, o__12 = more__18, tmp7; continue L1 } else {
//line :319:1
										if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_34) {





											var tmp8 any; var root_2008 any = A_arbace_repr_clojure_A_const_40.GetRawRoot__O(); var linked_2009 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2008, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2010 lang.IFn; if linked_2009 == nil { ifn_2010 = lang.IFn_Cast(root_2008) } else { ifn_2010 = nil }; var arg_2011 any = o__20; var arg_2012 any = A_arbace_repr_clojure_A_const_18; var arg_2013 any = jrt.Boolean_TRUE.Ref(); if linked_2009 == nil { tmp8 = ifn_2010.Invoke_O_O_O__O(arg_2011, arg_2012, arg_2013) } else { tmp8 = linked_2009.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2008, arg_2011, arg_2012, arg_2013) }; G__716000237__11_, o__12 = more__18, tmp8; continue L1 } else {
//line :319:1
												if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_35) {






													var tmp9 any; var root_2014 any = A_arbace_repr_clojure_A_const_40.GetRawRoot__O(); var linked_2015 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2014, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2016 lang.IFn; if linked_2015 == nil { ifn_2016 = lang.IFn_Cast(root_2014) } else { ifn_2016 = nil }; var arg_2017 any = o__20; var arg_2018 any = A_arbace_repr_clojure_A_const_20; var arg_2019 any = jrt.Boolean_TRUE.Ref(); if linked_2015 == nil { tmp9 = ifn_2016.Invoke_O_O_O__O(arg_2017, arg_2018, arg_2019) } else { tmp9 = linked_2015.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2014, arg_2017, arg_2018, arg_2019) }; G__716000237__11_, o__12 = more__18, tmp9; continue L1 } else {
//line :319:1
														if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_36) {







															var tmp10 any; var root_2020 any = A_arbace_repr_clojure_A_const_40.GetRawRoot__O(); var linked_2021 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2020, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2022 lang.IFn; if linked_2021 == nil { ifn_2022 = lang.IFn_Cast(root_2020) } else { ifn_2022 = nil }; var arg_2023 any = o__20; var arg_2024 any = A_arbace_repr_clojure_A_const_150; var arg_2025 any = jrt.Boolean_TRUE.Ref(); if linked_2021 == nil { tmp10 = ifn_2022.Invoke_O_O_O__O(arg_2023, arg_2024, arg_2025) } else { tmp10 = linked_2021.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2020, arg_2023, arg_2024, arg_2025) }; G__716000237__11_, o__12 = more__18, tmp10; continue L1 } else {
//line :319:1
																if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_37) {








																	var tmp11 any; var root_2026 any = A_arbace_repr_clojure_A_const_40.GetRawRoot__O(); var linked_2027 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2026, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2028 lang.IFn; if linked_2027 == nil { ifn_2028 = lang.IFn_Cast(root_2026) } else { ifn_2028 = nil }; var arg_2029 any = o__20; var arg_2030 any = A_arbace_repr_clojure_A_const_151; var arg_2031 any = jrt.Boolean_TRUE.Ref(); if linked_2027 == nil { tmp11 = ifn_2028.Invoke_O_O_O__O(arg_2029, arg_2030, arg_2031) } else { tmp11 = linked_2027.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2026, arg_2029, arg_2030, arg_2031) }; G__716000237__11_, o__12 = more__18, tmp11; continue L1 } else {
//line :319:1
																		if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_38) {









																			var tmp12 any; var root_2032 any = A_arbace_repr_clojure_A_const_40.GetRawRoot__O(); var linked_2033 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2032, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2034 lang.IFn; if linked_2033 == nil { ifn_2034 = lang.IFn_Cast(root_2032) } else { ifn_2034 = nil }; var arg_2035 any = o__20; var arg_2036 any = A_arbace_repr_clojure_A_const_152; var arg_2037 any = jrt.Boolean_TRUE.Ref(); if linked_2033 == nil { tmp12 = ifn_2034.Invoke_O_O_O__O(arg_2035, arg_2036, arg_2037) } else { tmp12 = linked_2033.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2032, arg_2035, arg_2036, arg_2037) }; G__716000237__11_, o__12 = more__18, tmp12; continue L1 } else {
//line :319:1
																				if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_39) {










																					var tmp13 any; var root_2038 any = A_arbace_repr_clojure_A_const_40.GetRawRoot__O(); var linked_2039 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2038, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2040 lang.IFn; if linked_2039 == nil { ifn_2040 = lang.IFn_Cast(root_2038) } else { ifn_2040 = nil }; var arg_2041 any = o__20; var arg_2042 any = A_arbace_repr_clojure_A_const_112; var arg_2043 any = A_arbace_repr_clojure_A_const_119; if linked_2039 == nil { tmp13 = ifn_2040.Invoke_O_O_O__O(arg_2041, arg_2042, arg_2043) } else { tmp13 = linked_2039.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2038, arg_2041, arg_2042, arg_2043) }; G__716000237__11_, o__12 = more__18, tmp13; continue L1 } else {
//line :319:1
																						if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_40) {











																							var tmp14 any; var root_2044 any = A_arbace_repr_clojure_A_const_67.GetRawRoot__O(); var linked_2045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2044, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2046 lang.IFn; if linked_2045 == nil { ifn_2046 = lang.IFn_Cast(root_2044) } else { ifn_2046 = nil }; var arg_2047 any = more__18; if linked_2045 == nil { tmp14 = ifn_2046.Invoke_O__O(arg_2047) } else { tmp14 = linked_2045.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2044, arg_2047) }; var tmp15 any = tmp14; var tmp16 any; var root_2048 any = A_arbace_repr_clojure_A_const_40.GetRawRoot__O(); var linked_2049 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2048, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2050 lang.IFn; if linked_2049 == nil { ifn_2050 = lang.IFn_Cast(root_2048) } else { ifn_2050 = nil }; var arg_2051 any = o__20; var arg_2052 any = A_arbace_repr_clojure_A_const_153; var arg_2053 any; var root_2054 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2055 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2054, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2056 lang.IFn; if linked_2055 == nil { ifn_2056 = lang.IFn_Cast(root_2054) } else { ifn_2056 = nil }; var arg_2057 any = more__18; if linked_2055 == nil { arg_2053 = ifn_2056.Invoke_O__O(arg_2057) } else { arg_2053 = linked_2055.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2054, arg_2057) }; if linked_2049 == nil { tmp16 = ifn_2050.Invoke_O_O_O__O(arg_2051, arg_2052, arg_2053) } else { tmp16 = linked_2049.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2048, arg_2051, arg_2052, arg_2053) }; G__716000237__11_, o__12 = tmp15, tmp16; continue L1 } else {
//line :319:1
																								if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_41) {












																									var tmp17 any; var root_2058 any = A_arbace_repr_clojure_A_const_67.GetRawRoot__O(); var linked_2059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2058, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2060 lang.IFn; if linked_2059 == nil { ifn_2060 = lang.IFn_Cast(root_2058) } else { ifn_2060 = nil }; var arg_2061 any = more__18; if linked_2059 == nil { tmp17 = ifn_2060.Invoke_O__O(arg_2061) } else { tmp17 = linked_2059.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2058, arg_2061) }; var tmp18 any = tmp17; var tmp19 any; var root_2062 any = A_arbace_repr_clojure_A_const_40.GetRawRoot__O(); var linked_2063 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2062, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2064 lang.IFn; if linked_2063 == nil { ifn_2064 = lang.IFn_Cast(root_2062) } else { ifn_2064 = nil }; var arg_2065 any = o__20; var arg_2066 any = A_arbace_repr_clojure_A_const_154; var arg_2067 any; var root_2068 any = A_arbace_repr_clojure_A_const_30.GetRawRoot__O(); var linked_2069 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2068, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_2070 lang.IFn; if linked_2069 == nil { ifn_2070 = lang.IFn_Cast(root_2068) } else { ifn_2070 = nil }; var arg_2071 any; var root_2072 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2073 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2072, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2074 lang.IFn; if linked_2073 == nil { ifn_2074 = lang.IFn_Cast(root_2072) } else { ifn_2074 = nil }; var arg_2075 any = more__18; if linked_2073 == nil { arg_2071 = ifn_2074.Invoke_O__O(arg_2075) } else { arg_2071 = linked_2073.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2072, arg_2075) }; if linked_2069 == nil { arg_2067 = ifn_2070.Invoke_O__O(arg_2071) } else { arg_2067 = linked_2069.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_2068, arg_2071) }; if linked_2063 == nil { tmp19 = ifn_2064.Invoke_O_O_O__O(arg_2065, arg_2066, arg_2067) } else { tmp19 = linked_2063.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2062, arg_2065, arg_2066, arg_2067) }; G__716000237__11_, o__12 = tmp18, tmp19; continue L1 } else {
//line :319:1
																										if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_42) {













																											var tmp20 any; var root_2076 any = A_arbace_repr_clojure_A_const_67.GetRawRoot__O(); var linked_2077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2076, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2078 lang.IFn; if linked_2077 == nil { ifn_2078 = lang.IFn_Cast(root_2076) } else { ifn_2078 = nil }; var arg_2079 any = more__18; if linked_2077 == nil { tmp20 = ifn_2078.Invoke_O__O(arg_2079) } else { tmp20 = linked_2077.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2076, arg_2079) }; var tmp21 any = tmp20; var tmp22 any; var root_2080 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var linked_2081 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2080, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_2082 lang.IFn; if linked_2081 == nil { ifn_2082 = lang.IFn_Cast(root_2080) } else { ifn_2082 = nil }; var arg_2083 any = o__20; var arg_2084 any = A_arbace_repr_clojure_A_const_19; var arg_2085 any = A_arbace_repr_clojure_A_const_10.GetRawRoot__O(); var arg_2086 any; var root_2087 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2088 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2087, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2089 lang.IFn; if linked_2088 == nil { ifn_2089 = lang.IFn_Cast(root_2087) } else { ifn_2089 = nil }; var arg_2090 any = more__18; if linked_2088 == nil { arg_2086 = ifn_2089.Invoke_O__O(arg_2090) } else { arg_2086 = linked_2088.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2087, arg_2090) }; if linked_2081 == nil { tmp22 = ifn_2082.Invoke_O_O_O_O__O(arg_2083, arg_2084, arg_2085, arg_2086) } else { tmp22 = linked_2081.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_2080, arg_2083, arg_2084, arg_2085, arg_2086) }; G__716000237__11_, o__12 = tmp21, tmp22; continue L1 } else {
//line :319:1
																												if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_43) {














																													var tmp23 any; var root_2091 any = A_arbace_repr_clojure_A_const_67.GetRawRoot__O(); var linked_2092 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2091, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2093 lang.IFn; if linked_2092 == nil { ifn_2093 = lang.IFn_Cast(root_2091) } else { ifn_2093 = nil }; var arg_2094 any = more__18; if linked_2092 == nil { tmp23 = ifn_2093.Invoke_O__O(arg_2094) } else { tmp23 = linked_2092.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2091, arg_2094) }; var tmp24 any = tmp23; var tmp25 any; var root_2095 any = A_arbace_repr_clojure_A_const_40.GetRawRoot__O(); var linked_2096 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2095, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2097 lang.IFn; if linked_2096 == nil { ifn_2097 = lang.IFn_Cast(root_2095) } else { ifn_2097 = nil }; var arg_2098 any = o__20; var arg_2099 any = A_arbace_repr_clojure_A_const_24; var arg_2100 any; var root_2101 any = A_arbace_repr_clojure_A_const_30.GetRawRoot__O(); var linked_2102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2101, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_2103 lang.IFn; if linked_2102 == nil { ifn_2103 = lang.IFn_Cast(root_2101) } else { ifn_2103 = nil }; var arg_2104 any; var root_2105 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2105, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2107 lang.IFn; if linked_2106 == nil { ifn_2107 = lang.IFn_Cast(root_2105) } else { ifn_2107 = nil }; var arg_2108 any = more__18; if linked_2106 == nil { arg_2104 = ifn_2107.Invoke_O__O(arg_2108) } else { arg_2104 = linked_2106.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2105, arg_2108) }; if linked_2102 == nil { arg_2100 = ifn_2103.Invoke_O__O(arg_2104) } else { arg_2100 = linked_2102.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_2101, arg_2104) }; if linked_2096 == nil { tmp25 = ifn_2097.Invoke_O_O_O__O(arg_2098, arg_2099, arg_2100) } else { tmp25 = linked_2096.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2095, arg_2098, arg_2099, arg_2100) }; G__716000237__11_, o__12 = tmp24, tmp25; continue L1 } else {
//line :319:1
																														if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_44) {















																															var tmp26 any; var root_2109 any = A_arbace_repr_clojure_A_const_67.GetRawRoot__O(); var linked_2110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2109, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2111 lang.IFn; if linked_2110 == nil { ifn_2111 = lang.IFn_Cast(root_2109) } else { ifn_2111 = nil }; var arg_2112 any = more__18; if linked_2110 == nil { tmp26 = ifn_2111.Invoke_O__O(arg_2112) } else { tmp26 = linked_2110.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2109, arg_2112) }; var tmp27 any = tmp26; var tmp28 any; var root_2113 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var linked_2114 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2113, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_2115 lang.IFn; if linked_2114 == nil { ifn_2115 = lang.IFn_Cast(root_2113) } else { ifn_2115 = nil }; var arg_2116 any = o__20; var arg_2117 any = A_arbace_repr_clojure_A_const_33; var arg_2118 any = A_arbace_repr_clojure_A_const_100.GetRawRoot__O(); var arg_2119 any; var root_2120 any = A_arbace_repr_clojure_A_const_155.GetRawRoot__O(); var linked_2121 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2120, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2122 lang.IFn; if linked_2121 == nil { ifn_2122 = lang.IFn_Cast(root_2120) } else { ifn_2122 = nil }; var arg_2123 any = A_arbace_repr_clojure_A_const_30.GetRawRoot__O(); var arg_2124 any; var root_2125 any = A_arbace_repr_clojure_A_const_156.GetRawRoot__O(); var linked_2126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2125, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_2127 lang.IFn; if linked_2126 == nil { ifn_2127 = lang.IFn_Cast(root_2125) } else { ifn_2127 = nil }; var arg_2128 any; var root_2130 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2130, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2132 lang.IFn; if linked_2131 == nil { ifn_2132 = lang.IFn_Cast(root_2130) } else { ifn_2132 = nil }; var arg_2133 any = more__18; if linked_2131 == nil { arg_2128 = ifn_2132.Invoke_O__O(arg_2133) } else { arg_2128 = linked_2131.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2130, arg_2133) }; var arg_2129 any = A_arbace_repr_clojure_A_const_157; if linked_2126 == nil { arg_2124 = ifn_2127.Invoke_O_O__O(arg_2128, arg_2129) } else { arg_2124 = linked_2126.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_2125, arg_2128, arg_2129) }; if linked_2121 == nil { arg_2119 = ifn_2122.Invoke_O_O__O(arg_2123, arg_2124) } else { arg_2119 = linked_2121.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2120, arg_2123, arg_2124) }; if linked_2114 == nil { tmp28 = ifn_2115.Invoke_O_O_O_O__O(arg_2116, arg_2117, arg_2118, arg_2119) } else { tmp28 = linked_2114.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_2113, arg_2116, arg_2117, arg_2118, arg_2119) }; G__716000237__11_, o__12 = tmp27, tmp28; continue L1 } else {
//line :319:1
																																var tmp29 any; var root_1966 any = A_arbace_repr_clojure_A_const_145.GetRawRoot__O(); var linked_1967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1966, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1968 lang.IFn
















																																if linked_1967 == nil { ifn_1968 = lang.IFn_Cast(root_1966) } else { ifn_1968 = nil }; var arg_1969 any = a__17; var arg_1970 any = Lit_45; if linked_1967 == nil { tmp29 = ifn_1968.Invoke_O_O__O(arg_1969, arg_1970) } else { tmp29 = linked_1967.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1966, arg_1969, arg_1970) }
//line :319:1
																																if jrt.J2g_Truth(tmp29) { var tmp30 any; var root_1971 any = A_arbace_repr_clojure_A_const_146.GetRawRoot__O(); var linked_1972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1971, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1973 lang.IFn
















																																	if linked_1972 == nil { ifn_1973 = lang.IFn_Cast(root_1971) } else { ifn_1973 = nil }; var arg_1974 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_46, nil), jrt.RefArrayOf(jrt.Object_class, nil, a__17)).Ref(); var arg_1975 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1972 == nil { tmp30 = ifn_1973.Invoke_O_O__O(arg_1974, arg_1975) } else { tmp30 = linked_1972.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1971, arg_1974, arg_1975) }
//line :319:1
																																	panic(jrt.Thrown(jrt.Throwable_Cast(tmp30))) } else { if A_arbace_repr_clojure_A_const_34 != nil {

















																																		var tmp31 any; var root_2134 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var linked_2135 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2134, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_2136 lang.IFn; if linked_2135 == nil { ifn_2136 = lang.IFn_Cast(root_2134) } else { ifn_2136 = nil }; var arg_2137 any = o__20; var arg_2138 any = A_arbace_repr_clojure_A_const_143; var arg_2139 any = A_arbace_repr_clojure_A_const_10.GetRawRoot__O(); var arg_2140 any = a__17; if linked_2135 == nil { tmp31 = ifn_2136.Invoke_O_O_O_O__O(arg_2137, arg_2138, arg_2139, arg_2140) } else { tmp31 = linked_2135.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_2134, arg_2137, arg_2138, arg_2139, arg_2140) }; G__716000237__11_, o__12 = more__18, tmp31; continue L1 } else {
//line :319:1
																																			return nil } } } } } } } } } } } } } } } } } } } }; /*line :317:1*/panic("j2g: unreachable") }





















func A_arbace_repr_clojure_print_rules_A_New() *A_arbace_repr_clojure_print_rules_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_print_rules_A{}; t.Ctor(); return t }
//line :339:1
func (t *A_arbace_repr_clojure_print_rules_A) Ctor() {}
//line :339:1
func (t *A_arbace_repr_clojure_print_rules_A) Invoke_O__O(self any) any {
	lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()).Invoke_O__O(Lit_62)
//line :339:1
	{ var seq_716000245__1 any; var root_2165 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2165, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2167 lang.IFn

		if linked_2166 == nil { ifn_2167 = lang.IFn_Cast(root_2165) } else { ifn_2167 = nil }; var arg_2168 any = A_arbace_repr_clojure_A_const_159.GetRawRoot__O(); if linked_2166 == nil { seq_716000245__1 = ifn_2167.Invoke_O__O(arg_2168) } else { seq_716000245__1 = linked_2166.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2165, arg_2168) }
//line :339:1
		var chunk_716000246__2 any; var count_716000247__3 int64 = 0; var i_716000248__4 int64 = 0; L1: for {

			if lang.Numbers_Lt_J_J__Z_NoInit(i_716000248__4, count_716000247__3) { var r__5 any = lang.Indexed_Cast(chunk_716000246__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_716000248__4)); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_63, nil, Lit_64, nil, Lit_65, nil); var tmp3 any; var root_2203 any = A_arbace_repr_clojure_A_const_163.GetRawRoot__O(); var linked_2204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2203, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2205 lang.IFn
				if linked_2204 == nil { ifn_2205 = lang.IFn_Cast(root_2203) } else { ifn_2205 = nil }; var arg_2206 any = A_arbace_repr_clojure_A_const_164.Invoke_O__O(r__5); if linked_2204 == nil { tmp3 = ifn_2205.Invoke_O__O(arg_2206) } else { tmp3 = linked_2204.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2203, arg_2206) }; var tmp4 any = tmp3; var tmp5 any; var root_2207 any = A_arbace_repr_clojure_A_const_163.GetRawRoot__O(); var linked_2208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2207, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2209 lang.IFn; if linked_2208 == nil { ifn_2209 = lang.IFn_Cast(root_2207) } else { ifn_2209 = nil }; var arg_2210 any = A_arbace_repr_clojure_A_const_165.Invoke_O__O(r__5); if linked_2208 == nil { tmp5 = ifn_2209.Invoke_O__O(arg_2210) } else { tmp5 = linked_2208.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2207, arg_2210) }; var tmp6 any = tmp5; var tmp7 any; var root_2211 any = A_arbace_repr_clojure_A_const_160.GetRawRoot__O(); var linked_2212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2211, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2213 lang.IFn; if linked_2212 == nil { ifn_2213 = lang.IFn_Cast(root_2211) } else { ifn_2213 = nil }; var arg_2214 any = A_arbace_repr_clojure_A_const_166.Invoke_O__O(r__5); var arg_2215 any = A_arbace_repr_clojure_A_const_167; var arg_2216 any = Lit_66; if linked_2212 == nil { tmp7 = ifn_2213.Invoke_O_O_O__O(arg_2214, arg_2215, arg_2216) } else { tmp7 = linked_2212.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2211, arg_2214, arg_2215, arg_2216) }; tmp1.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp4, nil, tmp6, nil, tmp7)).Ref())
				var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_67, nil); var tmp10 any; var root_2193 any = A_arbace_repr_clojure_A_const_160.GetRawRoot__O(); var linked_2194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2193, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2195 lang.IFn; if linked_2194 == nil { ifn_2195 = lang.IFn_Cast(root_2193) } else { ifn_2195 = nil }; var arg_2196 any = A_arbace_repr_clojure_A_const_161.Invoke_O__O(r__5); var arg_2197 any = A_arbace_repr_clojure_A_const_162; var arg_2198 any = Lit_66; if linked_2194 == nil { tmp10 = ifn_2195.Invoke_O_O_O__O(arg_2196, arg_2197, arg_2198) } else { tmp10 = linked_2194.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2193, arg_2196, arg_2197, arg_2198) }; tmp8.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp10)).Ref())
//line :341:1
				seq_716000245__1, chunk_716000246__2, count_716000247__3, i_716000248__4 = seq_716000245__1, chunk_716000246__2, count_716000247__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_716000248__4); continue L1 } else { var temp__1927000414__auto____5 any; var root_2169 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2169, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2171 lang.IFn; if linked_2170 == nil { ifn_2171 = lang.IFn_Cast(root_2169) } else { ifn_2171 = nil }; var arg_2172 any = seq_716000245__1; if linked_2170 == nil { temp__1927000414__auto____5 = ifn_2171.Invoke_O__O(arg_2172) } else { temp__1927000414__auto____5 = linked_2170.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2169, arg_2172) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_716000245__6 any = temp__1927000414__auto____5; var tmp11 any; var root_2173 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_2174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2173, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2175 lang.IFn; if linked_2174 == nil { ifn_2175 = lang.IFn_Cast(root_2173) } else { ifn_2175 = nil }; var arg_2176 any = seq_716000245__6; if linked_2174 == nil { tmp11 = ifn_2175.Invoke_O__O(arg_2176) } else { tmp11 = linked_2174.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2173, arg_2176) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____7 any; var root_2177 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_2178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2177, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2179 lang.IFn; if linked_2178 == nil { ifn_2179 = lang.IFn_Cast(root_2177) } else { ifn_2179 = nil }; var arg_2180 any = seq_716000245__6; if linked_2178 == nil { c__1927000678__auto____7 = ifn_2179.Invoke_O__O(arg_2180) } else { c__1927000678__auto____7 = linked_2178.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2177, arg_2180) }; var tmp12 any; var root_2217 any = A_arbace_repr_clojure_A_const_65.GetRawRoot__O(); var linked_2218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2217, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2219 lang.IFn; if linked_2218 == nil { ifn_2219 = lang.IFn_Cast(root_2217) } else { ifn_2219 = nil }; var arg_2220 any = seq_716000245__6; if linked_2218 == nil { tmp12 = ifn_2219.Invoke_O__O(arg_2220) } else { tmp12 = linked_2218.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2217, arg_2220) }; seq_716000245__1, chunk_716000246__2, count_716000247__3, i_716000248__4 = tmp12, c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var r__7 any; var root_2181 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2181, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2183 lang.IFn; if linked_2182 == nil { ifn_2183 = lang.IFn_Cast(root_2181) } else { ifn_2183 = nil }; var arg_2184 any = seq_716000245__6; if linked_2182 == nil { r__7 = ifn_2183.Invoke_O__O(arg_2184) } else { r__7 = linked_2182.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2181, arg_2184) }
					var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp14 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_63, nil, Lit_64, nil, Lit_65, nil); var tmp15 any; var root_2235 any = A_arbace_repr_clojure_A_const_163.GetRawRoot__O(); var linked_2236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2235, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2237 lang.IFn; if linked_2236 == nil { ifn_2237 = lang.IFn_Cast(root_2235) } else { ifn_2237 = nil }; var arg_2238 any = A_arbace_repr_clojure_A_const_164.Invoke_O__O(r__7); if linked_2236 == nil { tmp15 = ifn_2237.Invoke_O__O(arg_2238) } else { tmp15 = linked_2236.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2235, arg_2238) }; var tmp16 any = tmp15; var tmp17 any; var root_2239 any = A_arbace_repr_clojure_A_const_163.GetRawRoot__O(); var linked_2240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2239, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2241 lang.IFn; if linked_2240 == nil { ifn_2241 = lang.IFn_Cast(root_2239) } else { ifn_2241 = nil }; var arg_2242 any = A_arbace_repr_clojure_A_const_165.Invoke_O__O(r__7); if linked_2240 == nil { tmp17 = ifn_2241.Invoke_O__O(arg_2242) } else { tmp17 = linked_2240.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2239, arg_2242) }; var tmp18 any = tmp17; var tmp19 any; var root_2243 any = A_arbace_repr_clojure_A_const_160.GetRawRoot__O(); var linked_2244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2243, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2245 lang.IFn; if linked_2244 == nil { ifn_2245 = lang.IFn_Cast(root_2243) } else { ifn_2245 = nil }; var arg_2246 any = A_arbace_repr_clojure_A_const_166.Invoke_O__O(r__7); var arg_2247 any = A_arbace_repr_clojure_A_const_167; var arg_2248 any = Lit_66; if linked_2244 == nil { tmp19 = ifn_2245.Invoke_O_O_O__O(arg_2246, arg_2247, arg_2248) } else { tmp19 = linked_2244.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2243, arg_2246, arg_2247, arg_2248) }; tmp13.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp14, jrt.RefArrayOf(jrt.Object_class, nil, tmp16, nil, tmp18, nil, tmp19)).Ref())
					var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp21 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_67, nil); var tmp22 any; var root_2225 any = A_arbace_repr_clojure_A_const_160.GetRawRoot__O(); var linked_2226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2225, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2227 lang.IFn; if linked_2226 == nil { ifn_2227 = lang.IFn_Cast(root_2225) } else { ifn_2227 = nil }; var arg_2228 any = A_arbace_repr_clojure_A_const_161.Invoke_O__O(r__7); var arg_2229 any = A_arbace_repr_clojure_A_const_162; var arg_2230 any = Lit_66; if linked_2226 == nil { tmp22 = ifn_2227.Invoke_O_O_O__O(arg_2228, arg_2229, arg_2230) } else { tmp22 = linked_2226.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2225, arg_2228, arg_2229, arg_2230) }; tmp20.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp21, jrt.RefArrayOf(jrt.Object_class, nil, tmp22)).Ref())
//line :341:1
					var tmp23 any; var root_2249 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_2250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2249, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2251 lang.IFn; if linked_2250 == nil { ifn_2251 = lang.IFn_Cast(root_2249) } else { ifn_2251 = nil }; var arg_2252 any = seq_716000245__6; if linked_2250 == nil { tmp23 = ifn_2251.Invoke_O__O(arg_2252) } else { tmp23 = linked_2250.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2249, arg_2252) }; seq_716000245__1, chunk_716000246__2, count_716000247__3, i_716000248__4 = tmp23, nil, 0, 0; continue L1 } } }
//line :339:1
			break L1
		}



		lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()).Invoke_O__O(Lit_68)
//line :339:1
		var seq_716000249__1 any; var root_2141 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2141, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2143 lang.IFn





		if linked_2142 == nil { ifn_2143 = lang.IFn_Cast(root_2141) } else { ifn_2143 = nil }; var arg_2144 any = A_arbace_repr_clojure_A_const_158.GetRawRoot__O(); if linked_2142 == nil { seq_716000249__1 = ifn_2143.Invoke_O__O(arg_2144) } else { seq_716000249__1 = linked_2142.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2141, arg_2144) }
//line :339:1
		var chunk_716000250__2 any; var count_716000251__3 int64 = 0; var i_716000252__4 int64 = 0; L2: for {





			if lang.Numbers_Lt_J_J__Z_NoInit(i_716000252__4, count_716000251__3) { var d__5 any = lang.Indexed_Cast(chunk_716000250__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_716000252__4)); var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp25 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_63, nil, Lit_22, nil, nil); var tmp26 any = A_arbace_repr_clojure_A_const_168.Invoke_O__O(d__5); var tmp27 any
				var tmp28 any = A_arbace_repr_clojure_A_const_169
				if lang.Util_Equiv_O_O__Z_NoInit(tmp28, A_arbace_repr_clojure_A_const_170.Invoke_O__O(d__5)) { tmp27 = Lit_69 } else { var root_2257 any = A_arbace_repr_clojure_A_const_163.GetRawRoot__O(); var linked_2258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2257, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2259 lang.IFn; if linked_2258 == nil { ifn_2259 = lang.IFn_Cast(root_2257) } else { ifn_2259 = nil }; var arg_2260 any = A_arbace_repr_clojure_A_const_170.Invoke_O__O(d__5); if linked_2258 == nil { tmp27 = ifn_2259.Invoke_O__O(arg_2260) } else { tmp27 = linked_2258.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2257, arg_2260) } }
//line :346:1
				var tmp29 any = tmp27; var tmp30 *jrt.String

				if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_128.Invoke_O__O(d__5)) { var tmp31 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_70, nil); var tmp32 any; var root_2261 any = A_arbace_repr_clojure_A_const_160.GetRawRoot__O(); var linked_2262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2261, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2263 lang.IFn; if linked_2262 == nil { ifn_2263 = lang.IFn_Cast(root_2261) } else { ifn_2263 = nil }; var arg_2264 any = A_arbace_repr_clojure_A_const_128.Invoke_O__O(d__5); var arg_2265 any = A_arbace_repr_clojure_A_const_171; var arg_2266 any = Lit_66; if linked_2262 == nil { tmp32 = ifn_2263.Invoke_O_O_O__O(arg_2264, arg_2265, arg_2266) } else { tmp32 = linked_2262.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2261, arg_2264, arg_2265, arg_2266) }; tmp30 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp31, jrt.RefArrayOf(jrt.Object_class, nil, tmp32)) } else { tmp30 = nil }
//line :346:1
				tmp24.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp25, jrt.RefArrayOf(jrt.Object_class, nil, tmp26, nil, tmp29, tmp30.Ref())).Ref())
//line :345:1
				seq_716000249__1, chunk_716000250__2, count_716000251__3, i_716000252__4 = seq_716000249__1, chunk_716000250__2, count_716000251__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_716000252__4); continue L2 } else { var temp__1927000414__auto____5_2 any; var root_2145 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2145, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2147 lang.IFn; if linked_2146 == nil { ifn_2147 = lang.IFn_Cast(root_2145) } else { ifn_2147 = nil }; var arg_2148 any = seq_716000249__1; if linked_2146 == nil { temp__1927000414__auto____5_2 = ifn_2147.Invoke_O__O(arg_2148) } else { temp__1927000414__auto____5_2 = linked_2146.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2145, arg_2148) }; if jrt.J2g_Truth(temp__1927000414__auto____5_2) { var seq_716000249__6 any = temp__1927000414__auto____5_2; var tmp33 any; var root_2149 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_2150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2149, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2151 lang.IFn; if linked_2150 == nil { ifn_2151 = lang.IFn_Cast(root_2149) } else { ifn_2151 = nil }; var arg_2152 any = seq_716000249__6; if linked_2150 == nil { tmp33 = ifn_2151.Invoke_O__O(arg_2152) } else { tmp33 = linked_2150.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2149, arg_2152) }; if jrt.J2g_Truth(tmp33) { var c__1927000678__auto____7_2 any; var root_2153 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_2154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2153, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2155 lang.IFn; if linked_2154 == nil { ifn_2155 = lang.IFn_Cast(root_2153) } else { ifn_2155 = nil }; var arg_2156 any = seq_716000249__6; if linked_2154 == nil { c__1927000678__auto____7_2 = ifn_2155.Invoke_O__O(arg_2156) } else { c__1927000678__auto____7_2 = linked_2154.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2153, arg_2156) }; var tmp34 any; var root_2267 any = A_arbace_repr_clojure_A_const_65.GetRawRoot__O(); var linked_2268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2267, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2269 lang.IFn; if linked_2268 == nil { ifn_2269 = lang.IFn_Cast(root_2267) } else { ifn_2269 = nil }; var arg_2270 any = seq_716000249__6; if linked_2268 == nil { tmp34 = ifn_2269.Invoke_O__O(arg_2270) } else { tmp34 = linked_2268.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2267, arg_2270) }; seq_716000249__1, chunk_716000250__2, count_716000251__3, i_716000252__4 = tmp34, c__1927000678__auto____7_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var d__7 any; var root_2157 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2157, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2159 lang.IFn; if linked_2158 == nil { ifn_2159 = lang.IFn_Cast(root_2157) } else { ifn_2159 = nil }; var arg_2160 any = seq_716000249__6; if linked_2158 == nil { d__7 = ifn_2159.Invoke_O__O(arg_2160) } else { d__7 = linked_2158.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2157, arg_2160) }
					var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp36 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_63, nil, Lit_22, nil, nil); var tmp37 any = A_arbace_repr_clojure_A_const_168.Invoke_O__O(d__7); var tmp38 any; var tmp39 any = A_arbace_repr_clojure_A_const_169
					if lang.Util_Equiv_O_O__Z_NoInit(tmp39, A_arbace_repr_clojure_A_const_170.Invoke_O__O(d__7)) { tmp38 = Lit_69 } else { var root_2275 any = A_arbace_repr_clojure_A_const_163.GetRawRoot__O(); var linked_2276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2275, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2277 lang.IFn; if linked_2276 == nil { ifn_2277 = lang.IFn_Cast(root_2275) } else { ifn_2277 = nil }; var arg_2278 any = A_arbace_repr_clojure_A_const_170.Invoke_O__O(d__7); if linked_2276 == nil { tmp38 = ifn_2277.Invoke_O__O(arg_2278) } else { tmp38 = linked_2276.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2275, arg_2278) } }
//line :346:1
					var tmp40 any = tmp38; var tmp41 *jrt.String

					if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_128.Invoke_O__O(d__7)) { var tmp42 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_70, nil); var tmp43 any; var root_2279 any = A_arbace_repr_clojure_A_const_160.GetRawRoot__O(); var linked_2280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2279, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2281 lang.IFn; if linked_2280 == nil { ifn_2281 = lang.IFn_Cast(root_2279) } else { ifn_2281 = nil }; var arg_2282 any = A_arbace_repr_clojure_A_const_128.Invoke_O__O(d__7); var arg_2283 any = A_arbace_repr_clojure_A_const_171; var arg_2284 any = Lit_66; if linked_2280 == nil { tmp43 = ifn_2281.Invoke_O_O_O__O(arg_2282, arg_2283, arg_2284) } else { tmp43 = linked_2280.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2279, arg_2282, arg_2283, arg_2284) }; tmp41 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp42, jrt.RefArrayOf(jrt.Object_class, nil, tmp43)) } else { tmp41 = nil }
//line :346:1
					tmp35.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp36, jrt.RefArrayOf(jrt.Object_class, nil, tmp37, nil, tmp40, tmp41.Ref())).Ref())
//line :345:1
					var tmp44 any; var root_2285 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_2286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2285, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2287 lang.IFn; if linked_2286 == nil { ifn_2287 = lang.IFn_Cast(root_2285) } else { ifn_2287 = nil }; var arg_2288 any = seq_716000249__6; if linked_2286 == nil { tmp44 = ifn_2287.Invoke_O__O(arg_2288) } else { tmp44 = linked_2286.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2285, arg_2288) }; seq_716000249__1, chunk_716000250__2, count_716000251__3, i_716000252__4 = tmp44, nil, 0, 0; continue L2 } } else { return nil } } } }
//line :339:1
	panic("j2g: unreachable")
}









func A_arbace_repr_clojure_usage_A_New() *A_arbace_repr_clojure_usage_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_usage_A{}; t.Ctor(); return t }
//line :350:1
func (t *A_arbace_repr_clojure_usage_A) Ctor() {}
//line :350:1
func (t *A_arbace_repr_clojure_usage_A) Invoke_O__O(self any) any {
	var root_2301 any = A_arbace_repr_clojure_A_const_88.GetRawRoot__O(); var linked_2302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2301, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2303 lang.IFn; if linked_2302 == nil { ifn_2303 = lang.IFn_Cast(root_2301) } else { ifn_2303 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_89.GetRawRoot__O()); var tmp2 any = A_arbace_repr_clojure_A_const_90; var arg_2304 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_repr_clojure_A_const_91.Get__O()); if linked_2302 == nil { ifn_2303.Invoke_O__O(arg_2304) } else { linked_2302.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2301, arg_2304) }; var tmp3 any = A_arbace_repr_clojure_usage_fn__716000254_A_New(); var tmp4 *jrt.Class; var fncls__2300 *jrt.Class = A_arbace_repr_clojure_usage_fn__716000254_A_fn_class; if fncls__2300 == nil { var fncls__2300d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_127, false); A_arbace_repr_clojure_usage_fn__716000254_A_fn_class = fncls__2300d; tmp4 = fncls__2300d } else { tmp4 = fncls__2300 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()
	jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2)); return nil }
//line :351:1
func A_arbace_repr_clojure_usage_fn__716000254_A_New() *A_arbace_repr_clojure_usage_fn__716000254_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_usage_fn__716000254_A{}; t.Ctor(); return t }
//line :351:1
func (t *A_arbace_repr_clojure_usage_fn__716000254_A) Ctor() {}
//line :351:1
func (t *A_arbace_repr_clojure_usage_fn__716000254_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp3 *lang.Keyword = A_arbace_repr_clojure_A_const_166; var tmp4 any; var root_2293 any = A_arbace_repr_clojure_A_const_172.GetRawRoot__O(); var linked_2294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2293, aot_arbace_core.A_arbace_core_the_ns_A_fn_class); var ifn_2295 lang.IFn; if linked_2294 == nil { ifn_2295 = lang.IFn_Cast(root_2293) } else { ifn_2295 = nil }; var arg_2296 any = A_arbace_repr_clojure_A_const_173; if linked_2294 == nil { tmp4 = ifn_2295.Invoke_O__O(arg_2296) } else { tmp4 = linked_2294.(*aot_arbace_core.A_arbace_core_the_ns_A).Invoke_O_O__O(root_2293, arg_2296) }; tmp1 = tmp2.Invoke_O__O(tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(tmp4))) }; return nil }(); var root_2297 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); var linked_2298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2297, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2299 lang.IFn; if linked_2298 == nil { ifn_2299 = lang.IFn_Cast(root_2297) } else { ifn_2299 = nil }; if linked_2298 == nil { ifn_2299.Invoke__O() } else { linked_2298.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2297) }; if tmp5 != nil { panic(tmp5) }; return tmp1 }


func A_arbace_repr_clojure_roundtrips_A_New() *A_arbace_repr_clojure_roundtrips_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrips_A{}; t.Ctor(); return t }
//line :354:1
func (t *A_arbace_repr_clojure_roundtrips_A) Ctor() {}
//line :354:1
func (t *A_arbace_repr_clojure_roundtrips_A) Invoke_O_O_O__O(self, sources__0, opts__1 any) any {



	if lang.Numbers_Lt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(sources__0)), 2) {
		var root_2310 any = A_arbace_repr_clojure_A_const_174.GetRawRoot__O(); var linked_2311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2310, A_arbace_repr_clojure_roundtrip_A_fn_class); var ifn_2312 lang.IFn; if linked_2311 == nil { ifn_2312 = lang.IFn_Cast(root_2310) } else { ifn_2312 = nil }; var arg_2313 any = sources__0; var arg_2314 any = opts__1; if linked_2311 == nil { return ifn_2312.Invoke_O_O__O(arg_2313, arg_2314) } else { return linked_2311.(*A_arbace_repr_clojure_roundtrip_A).Invoke_O_O_O__O(root_2310, arg_2313, arg_2314) } } else {
			var root_2315 any = A_arbace_repr_clojure_A_const_103.GetRawRoot__O(); var linked_2316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2315, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_2317 lang.IFn; if linked_2316 == nil { ifn_2317 = lang.IFn_Cast(root_2315) } else { ifn_2317 = nil }; var arg_2318 any; var tmp1 any = A_arbace_repr_clojure_roundtrips_fn__716000257_A_New_O(opts__1); var tmp2 *jrt.Class; var fncls__2410 *jrt.Class = A_arbace_repr_clojure_roundtrips_fn__716000257_A_fn_class; if fncls__2410 == nil { var fncls__2410d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, false); A_arbace_repr_clojure_roundtrips_fn__716000257_A_fn_class = fncls__2410d; tmp2 = fncls__2410d } else { tmp2 = fncls__2410 }; arg_2318 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 any = A_arbace_repr_clojure_A_const_139; var tmp4 any = A_arbace_repr_clojure_A_const_13; var tmp5 any = A_arbace_repr_clojure_A_const_140; var tmp6 any = A_arbace_repr_clojure_A_const_13; var tmp7 any = A_arbace_repr_clojure_A_const_142; var arg_2319 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp5, tmp6, tmp7, lang.IFn_Cast(A_arbace_repr_clojure_A_const_101.GetRawRoot__O()).Invoke__O())); var arg_2320 any = sources__0; if linked_2316 == nil { return ifn_2317.Invoke_O_O_O__O(arg_2318, arg_2319, arg_2320) } else { return linked_2316.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_2315, arg_2318, arg_2319, arg_2320) } } }
//line :360:1
func A_arbace_repr_clojure_roundtrips_fn__716000257_A_New_O(p0 any) *A_arbace_repr_clojure_roundtrips_fn__716000257_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrips_fn__716000257_A{}; t.Ctor_O(p0); return t }
//line :360:1
func (t *A_arbace_repr_clojure_roundtrips_fn__716000257_A) Ctor_O(c__opts any) { t.F_opts = c__opts }
//line :360:1
func (t *A_arbace_repr_clojure_roundtrips_fn__716000257_A) Invoke_O_O_O__O(self, acc__1, src__2 any) any { var r__3 any; var root_2321 any = A_arbace_repr_clojure_A_const_174.GetRawRoot__O(); var linked_2322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2321, A_arbace_repr_clojure_roundtrip_A_fn_class); var ifn_2323 lang.IFn; if
														linked_2322 == nil { ifn_2323 = lang.IFn_Cast(root_2321) } else { ifn_2323 = nil }; var arg_2324 any = lang.Tuple_Create_O__IPersistentVector(src__2); var arg_2325 any = t.F_opts; if linked_2322 == nil { r__3 = ifn_2323.Invoke_O_O__O(arg_2324, arg_2325) } else { r__3 = linked_2322.(*A_arbace_repr_clojure_roundtrip_A).Invoke_O_O_O__O(root_2321, arg_2324, arg_2325) }; var n__4 any; var tmp1 any; var root_2326 any = /*line :360:1*/A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_2327 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2326, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_2328 lang.IFn; if
														linked_2327 == nil { ifn_2328 = lang.IFn_Cast(root_2326) } else { ifn_2328 = nil }; var arg_2329 any = src__2; if linked_2327 == nil { tmp1 = ifn_2328.Invoke_O__O(arg_2329) } else { tmp1 = linked_2327.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_2326, arg_2329) }; n__4 = jrt.NN(jrt.File_Cast(tmp1)).GetName__String().Ref(); var root_2330 any =

	A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var linked_2331 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2330, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_2332 lang.IFn; if linked_2331 == nil { ifn_2332 = lang.IFn_Cast(root_2330) } else { ifn_2332 = nil }; var arg_2333 any; var root_2337 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var linked_2338 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2337, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_2339 lang.IFn; if /*line :362:1*/ linked_2338 == nil { ifn_2339 = lang.IFn_Cast(root_2337) } else { ifn_2339 = nil }; var arg_2340 any; var root_2344 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var linked_2345 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2344, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_2346 lang.IFn; if linked_2345 == nil { ifn_2346 = lang.IFn_Cast(root_2344) } else { ifn_2346 = nil }; var arg_2347 any = acc__1; var arg_2348 any = A_arbace_repr_clojure_A_const_139; var arg_2349 any = A_arbace_repr_clojure_A_const_175.GetRawRoot__O(); var arg_2350 any = A_arbace_repr_clojure_A_const_139.Invoke_O__O(r__3); if linked_2345 == nil { arg_2340 = ifn_2346.Invoke_O_O_O_O__O(arg_2347, arg_2348, arg_2349, arg_2350) } else { arg_2340 = linked_2345.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_2344, arg_2347, arg_2348, arg_2349, arg_2350) }; var arg_2341 any = A_arbace_repr_clojure_A_const_140; var arg_2342 any = A_arbace_repr_clojure_A_const_175.GetRawRoot__O(); var arg_2343 any = A_arbace_repr_clojure_A_const_140.Invoke_O__O(r__3); if linked_2338 == nil { arg_2333 = ifn_2339.Invoke_O_O_O_O__O(arg_2340, arg_2341, arg_2342, arg_2343) } else { arg_2333 = linked_2338.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_2337, arg_2340, arg_2341, arg_2342, arg_2343) }; var arg_2334 any = A_arbace_repr_clojure_A_const_142; var arg_2335 any =
	A_arbace_repr_clojure_A_const_100.GetRawRoot__O(); var arg_2336 any; var iter__1927001039__auto____5 any; var tmp2 any = A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_A_New_O(n__4); var tmp3 *jrt.Class; var fncls__2409 *jrt.Class = A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_A_fn_class; if fncls__2409 == nil { var fncls__2409d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_87, false); A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_A_fn_class = fncls__2409d; tmp3 = fncls__2409d } else { tmp3 = fncls__2409 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); arg_2336 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(A_arbace_repr_clojure_A_const_142.Invoke_O__O(r__3)); if linked_2331 == nil { return ifn_2332.Invoke_O_O_O_O__O(arg_2333, arg_2334, arg_2335, arg_2336) } else { return linked_2331.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_2330, arg_2333, arg_2334, arg_2335, arg_2336) } }
//line :363:1
func A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_A_New_O(p0 any) *A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_A{}; t.Ctor_O(p0); return t }
//line :363:1
func (t *A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :363:1
func (t *A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_A) Invoke_O_O__O(self, s__716000259__1 any) any { var tmp1 any = A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_A_New_O_O_O(self, t.F_n, s__716000259__1); var tmp2 *jrt.Class; var fncls__2408 *jrt.Class = A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_A_fn_class; if fncls__2408 == nil { var fncls__2408d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_88, false); A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_A_fn_class = fncls__2408d; tmp2 = fncls__2408d } else { tmp2 = fncls__2408 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :363:1
func A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :363:1
func (t *A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_A) Ctor_O_O_O(c__iter__716000258, c__n, c__s__716000259 any) { t.F_iter__716000258 = c__iter__716000258; t.F_n = c__n; t.F_s__716000259 = c__s__716000259 }
//line :363:1
func (t *A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_A) Invoke_O__O(self any) any { { var s__716000259__1 any; var t_ any = t.F_s__716000259; t.F_s__716000259 = nil; s__716000259__1 = t_; for { var temp__1927000414__auto____2 any; var root_2351 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2351, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2353 lang.IFn; if linked_2352 == nil { ifn_2353 = lang.IFn_Cast(root_2351) } else { ifn_2353 = nil }; var arg_2354 any = s__716000259__1; if linked_2352 == nil { temp__1927000414__auto____2 = ifn_2353.Invoke_O__O(arg_2354) } else { temp__1927000414__auto____2 = linked_2352.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2351, arg_2354) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__716000259__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2355 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_2356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2355, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2357 lang.IFn; if linked_2356 == nil { ifn_2357 = lang.IFn_Cast(root_2355) } else { ifn_2357 = nil }; var arg_2358 any = s__716000259__3; if linked_2356 == nil { tmp1 = ifn_2357.Invoke_O__O(arg_2358) } else { tmp1 = linked_2356.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2355, arg_2358) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2359 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_2360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2359, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2361 lang.IFn; if linked_2360 == nil { ifn_2361 = lang.IFn_Cast(root_2359) } else { ifn_2361 = nil }; var arg_2362 any = s__716000259__3; if linked_2360 == nil { c__1927001037__auto____4 = ifn_2361.Invoke_O__O(arg_2362) } else { c__1927001037__auto____4 = linked_2360.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2359, arg_2362) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__716000261__6 any; var root_2363 any = A_arbace_repr_clojure_A_const_60.GetRawRoot__O(); var linked_2364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2363, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2365 lang.IFn; if linked_2364 == nil { ifn_2365 = lang.IFn_Cast(root_2363) } else { ifn_2365 = nil }; var arg_2366 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2364 == nil { b__716000261__6 = ifn_2365.Invoke_O__O(arg_2366) } else { b__716000261__6 = linked_2364.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2363, arg_2366) }; var tmp2 any = A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_fn__716000264_A_New_O_O_I_O(t.F_n, b__716000261__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2372 *jrt.Class = A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_fn__716000264_A_fn_class; if fncls__2372 == nil { var fncls__2372d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_89, false); A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_fn__716000264_A_fn_class = fncls__2372d; tmp3 = fncls__2372d } else { tmp3 = fncls__2372 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2373 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_2374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2373, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2375 lang.IFn; if linked_2374 == nil { ifn_2375 = lang.IFn_Cast(root_2373) } else { ifn_2375 = nil }; var arg_2376 any; var root_2378 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_2379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2378, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2380 lang.IFn; if linked_2379 == nil { ifn_2380 = lang.IFn_Cast(root_2378) } else { ifn_2380 = nil }; var arg_2381 any = b__716000261__6; if linked_2379 == nil { arg_2376 = ifn_2380.Invoke_O__O(arg_2381) } else { arg_2376 = linked_2379.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2378, arg_2381) }; var arg_2377 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__716000258); var tmp5 any; var root_2382 any = A_arbace_repr_clojure_A_const_65.GetRawRoot__O(); var linked_2383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2382, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2384 lang.IFn; if linked_2383 == nil { ifn_2384 = lang.IFn_Cast(root_2382) } else { ifn_2384 = nil }; var arg_2385 any = s__716000259__3; if linked_2383 == nil { tmp5 = ifn_2384.Invoke_O__O(arg_2385) } else { tmp5 = linked_2383.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2382, arg_2385) }; arg_2377 = tmp4.Invoke_O__O(tmp5); if linked_2374 == nil { return ifn_2375.Invoke_O_O__O(arg_2376, arg_2377) } else { return linked_2374.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2373, arg_2376, arg_2377) } } else { var root_2386 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_2387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2386, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2388 lang.IFn; if linked_2387 == nil { ifn_2388 = lang.IFn_Cast(root_2386) } else { ifn_2388 = nil }; var arg_2389 any; var root_2391 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_2392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2391, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2393 lang.IFn; if linked_2392 == nil { ifn_2393 = lang.IFn_Cast(root_2391) } else { ifn_2393 = nil }; var arg_2394 any = b__716000261__6; if linked_2392 == nil { arg_2389 = ifn_2393.Invoke_O__O(arg_2394) } else { arg_2389 = linked_2392.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2391, arg_2394) }; var arg_2390 any; if linked_2387 == nil { return ifn_2388.Invoke_O_O__O(arg_2389, arg_2390) } else { return linked_2387.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2386, arg_2389, arg_2390) } } } else { var vec__716000269__4 any; var root_2395 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2395, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2397 lang.IFn; if linked_2396 == nil { ifn_2397 = lang.IFn_Cast(root_2395) } else { ifn_2397 = nil }; var arg_2398 any = s__716000259__3; if linked_2396 == nil { vec__716000269__4 = ifn_2397.Invoke_O__O(arg_2398) } else { vec__716000269__4 = linked_2396.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2395, arg_2398) }; var rel__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000269__4, lang.RT_IntCast_J__I_NoInit(0), nil); var d__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000269__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2399 any = A_arbace_repr_clojure_A_const_66.GetRawRoot__O(); var linked_2400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2399, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2401 lang.IFn; if linked_2400 == nil { ifn_2401 = lang.IFn_Cast(root_2399) } else { ifn_2401 = nil }; var arg_2402 any = lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_29, nil), jrt.RefArrayOf(jrt.Object_class, t.F_n, nil, rel__5)).Ref(), d__6); var arg_2403 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__716000258); var tmp7 any; var root_2404 any = A_arbace_repr_clojure_A_const_67.GetRawRoot__O(); var linked_2405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2404, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2406 lang.IFn; if linked_2405 == nil { ifn_2406 = lang.IFn_Cast(root_2404) } else { ifn_2406 = nil }; var arg_2407 any = s__716000259__3; if linked_2405 == nil { tmp7 = ifn_2406.Invoke_O__O(arg_2407) } else { tmp7 = linked_2405.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2404, arg_2407) }; arg_2403 = tmp6.Invoke_O__O(tmp7); if linked_2400 == nil { return ifn_2401.Invoke_O_O__O(arg_2402, arg_2403) } else { return linked_2400.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2399, arg_2402, arg_2403) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :363:1
func A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_fn__716000264_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_fn__716000264_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_fn__716000264_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :363:1
func (t *A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_fn__716000264_A) Ctor_O_O_I_O(c__n, c__b__716000261 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__716000261 = c__b__716000261; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :363:1
func (t *A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_fn__716000264_A) Invoke_O__O(self any) any { { var i__716000260__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__716000260__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__716000265__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__716000260__1)); var rel__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000265__2, lang.RT_IntCast_J__I_NoInit(0), nil); var d__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000265__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2367 any = A_arbace_repr_clojure_A_const_61.GetRawRoot__O(); var linked_2368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2367, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2369 lang.IFn; if linked_2368 == nil { ifn_2369 = lang.IFn_Cast(root_2367) } else { ifn_2369 = nil }; var arg_2370 any = t.F_b__716000261; var arg_2371 any = lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_29, nil), jrt.RefArrayOf(jrt.Object_class, t.F_n, nil, rel__3)).Ref(), d__4); if linked_2368 == nil { ifn_2369.Invoke_O_O__O(arg_2370, arg_2371) } else { linked_2368.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2367, arg_2370, arg_2371) }; i__716000260__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__716000260__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_repr_clojure_run_roundtrip_A_New() *A_arbace_repr_clojure_run_roundtrip_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_roundtrip_A{}; t.Ctor(); return t }
//line :366:1
func (t *A_arbace_repr_clojure_run_roundtrip_A) Ctor() {}
//line :366:1
func (t *A_arbace_repr_clojure_run_roundtrip_A) Invoke_O_O__O(self, o__0 any) any { var r__2 any; var root_2414 any = A_arbace_repr_clojure_A_const_176.GetRawRoot__O(); var linked_2415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2414, A_arbace_repr_clojure_roundtrips_A_fn_class); var ifn_2416 lang.IFn; if




	linked_2415 == nil { ifn_2416 = lang.IFn_Cast(root_2414) } else { ifn_2416 = nil }; var arg_2417 any = A_arbace_repr_clojure_A_const_143.Invoke_O__O(o__0); var arg_2418 any = o__0; if linked_2415 == nil { r__2 = ifn_2416.Invoke_O_O__O(arg_2417, arg_2418) } else { r__2 = linked_2415.(*A_arbace_repr_clojure_roundtrips_A).Invoke_O_O_O__O(root_2414, arg_2417, arg_2418) }; var known__3 any; if
	jrt.J2g_Truth(A_arbace_repr_clojure_A_const_153.Invoke_O__O(o__0)) { var tmp1 any; var root_2419 any = A_arbace_repr_clojure_A_const_177.GetRawRoot__O(); var linked_2420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2419, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_2421 lang.IFn; if linked_2420 == nil { ifn_2421 = lang.IFn_Cast(root_2419) } else { ifn_2421 = nil }; var arg_2422 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_78.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_A_const_153.Invoke_O__O(o__0)); if linked_2420 == nil { tmp1 = ifn_2421.Invoke_O__O(arg_2422) } else { tmp1 = linked_2420.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_2419, arg_2422) }; known__3 = lang.RT_Get_O_O_O__O_NoInit(tmp1, A_arbace_repr_clojure_A_const_154.Invoke_O__O(o__0), lang.PersistentArrayMap_EMPTY.Ref()) } else { known__3 = lang.PersistentArrayMap_EMPTY.Ref() }; var outside__4 any; var root_2427 any = /*line :366:1*/A_arbace_repr_clojure_A_const_100.GetRawRoot__O(); var linked_2428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2427, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2429 lang.IFn; if






	linked_2428 == nil { ifn_2429 = lang.IFn_Cast(root_2427) } else { ifn_2429 = nil }; var arg_2430 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_101.GetRawRoot__O()).Invoke__O(); var arg_2431 any; var root_2435 any = A_arbace_repr_clojure_A_const_116.GetRawRoot__O(); var linked_2436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2435, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_2437 lang.IFn; if linked_2436 == nil { ifn_2437 = lang.IFn_Cast(root_2435) } else { ifn_2437 = nil }; var arg_2438 any; var tmp2 any = A_arbace_repr_clojure_run_roundtrip_fn__716000280_A_New(); var tmp3 *jrt.Class; var fncls__2444 *jrt.Class = A_arbace_repr_clojure_run_roundtrip_fn__716000280_A_fn_class; if fncls__2444 == nil { var fncls__2444d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_105, false); A_arbace_repr_clojure_run_roundtrip_fn__716000280_A_fn_class = fncls__2444d; tmp3 = fncls__2444d } else { tmp3 = fncls__2444 }; arg_2438 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_2439 any = A_arbace_repr_clojure_A_const_142.Invoke_O__O(r__2); if linked_2436 == nil { arg_2431 = ifn_2437.Invoke_O_O__O(arg_2438, arg_2439) } else { arg_2431 = linked_2436.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_2435, arg_2438, arg_2439) }; if linked_2428 == nil { outside__4 = ifn_2429.Invoke_O_O__O(arg_2430, arg_2431) } else { outside__4 = linked_2428.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2427, arg_2430, arg_2431) }; var one_way__5 any; var root_2445 any = /*line :366:1*/A_arbace_repr_clojure_A_const_100.GetRawRoot__O(); var linked_2446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2445, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2447 lang.IFn; if







	linked_2446 == nil { ifn_2447 = lang.IFn_Cast(root_2445) } else { ifn_2447 = nil }; var arg_2448 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_101.GetRawRoot__O()).Invoke__O(); var arg_2449 any; var root_2453 any = A_arbace_repr_clojure_A_const_116.GetRawRoot__O(); var linked_2454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2453, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_2455 lang.IFn; if linked_2454 == nil { ifn_2455 = lang.IFn_Cast(root_2453) } else { ifn_2455 = nil }; var arg_2456 any; var tmp4 any = A_arbace_repr_clojure_run_roundtrip_fn__716000282_A_New(); var tmp5 *jrt.Class; var fncls__2462 *jrt.Class = A_arbace_repr_clojure_run_roundtrip_fn__716000282_A_fn_class; if fncls__2462 == nil { var fncls__2462d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_106, false); A_arbace_repr_clojure_run_roundtrip_fn__716000282_A_fn_class = fncls__2462d; tmp5 = fncls__2462d } else { tmp5 = fncls__2462 }; arg_2456 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_2457 any = A_arbace_repr_clojure_A_const_142.Invoke_O__O(r__2); if linked_2454 == nil { arg_2449 = ifn_2455.Invoke_O_O__O(arg_2456, arg_2457) } else { arg_2449 = linked_2454.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_2453, arg_2456, arg_2457) }; if linked_2446 == nil { one_way__5 = ifn_2447.Invoke_O_O__O(arg_2448, arg_2449) } else { one_way__5 = linked_2446.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2445, arg_2448, arg_2449) }; var diff__6 any; var root_2463 any = /*line :366:1*/A_arbace_repr_clojure_A_const_180.GetRawRoot__O(); var linked_2464 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2463, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2465 lang.IFn; if








	linked_2464 == nil { ifn_2465 = lang.IFn_Cast(root_2463) } else { ifn_2465 = nil }; var arg_2466 any = A_arbace_repr_clojure_A_const_181.GetRawRoot__O(); var arg_2467 any = A_arbace_repr_clojure_A_const_142.Invoke_O__O(r__2); var arg_2468 any; var root_2469 any = A_arbace_repr_clojure_A_const_102.GetRawRoot__O(); var linked_2470 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2469, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2471 lang.IFn; if linked_2470 == nil { ifn_2471 = lang.IFn_Cast(root_2469) } else { ifn_2471 = nil }; var arg_2472 any; var root_2474 any = A_arbace_repr_clojure_A_const_107.GetRawRoot__O(); var linked_2475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2474, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2476 lang.IFn; if linked_2475 == nil { ifn_2476 = lang.IFn_Cast(root_2474) } else { ifn_2476 = nil }; var arg_2477 any = outside__4; if linked_2475 == nil { arg_2472 = ifn_2476.Invoke_O__O(arg_2477) } else { arg_2472 = linked_2475.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2474, arg_2477) }; var arg_2473 any; var root_2478 any = A_arbace_repr_clojure_A_const_107.GetRawRoot__O(); var linked_2479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2478, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2480 lang.IFn; if linked_2479 == nil { ifn_2480 = lang.IFn_Cast(root_2478) } else { ifn_2480 = nil }; var arg_2481 any = one_way__5; if linked_2479 == nil { arg_2473 = ifn_2480.Invoke_O__O(arg_2481) } else { arg_2473 = linked_2479.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2478, arg_2481) }; if linked_2470 == nil { arg_2468 = ifn_2471.Invoke_O_O__O(arg_2472, arg_2473) } else { arg_2468 = linked_2470.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2469, arg_2472, arg_2473) }; if linked_2464 == nil { diff__6 = ifn_2465.Invoke_O_O_O__O(arg_2466, arg_2467, arg_2468) } else { diff__6 = linked_2464.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_2463, arg_2466, arg_2467, arg_2468) }; var new__7 any; var root_2482 any = /*line :366:1*/A_arbace_repr_clojure_A_const_141.GetRawRoot__O(); var linked_2483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2482, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_2484 lang.IFn; if









	linked_2483 == nil { ifn_2484 = lang.IFn_Cast(root_2482) } else { ifn_2484 = nil }; var arg_2485 any; var tmp6 any = A_arbace_repr_clojure_run_roundtrip_fn__716000284_A_New_O(known__3); var tmp7 *jrt.Class; var fncls__2492 *jrt.Class = A_arbace_repr_clojure_run_roundtrip_fn__716000284_A_fn_class; if fncls__2492 == nil { var fncls__2492d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_107, false); A_arbace_repr_clojure_run_roundtrip_fn__716000284_A_fn_class = fncls__2492d; tmp7 = fncls__2492d } else { tmp7 = fncls__2492 }; arg_2485 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_2486 any; var root_2493 any = A_arbace_repr_clojure_A_const_107.GetRawRoot__O(); var linked_2494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2493, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2495 lang.IFn; if linked_2494 == nil { ifn_2495 = lang.IFn_Cast(root_2493) } else { ifn_2495 = nil }; var arg_2496 any = diff__6; if linked_2494 == nil { arg_2486 = ifn_2495.Invoke_O__O(arg_2496) } else { arg_2486 = linked_2494.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2493, arg_2496) }; if linked_2483 == nil { new__7 = ifn_2484.Invoke_O_O__O(arg_2485, arg_2486) } else { new__7 = linked_2483.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_2482, arg_2485, arg_2486) }; var stale__8 any; var root_2497 any = /*line :366:1*/A_arbace_repr_clojure_A_const_141.GetRawRoot__O(); var linked_2498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2497, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_2499 lang.IFn; if










	linked_2498 == nil { ifn_2499 = lang.IFn_Cast(root_2497) } else { ifn_2499 = nil }; var arg_2500 any; var tmp8 any = A_arbace_repr_clojure_run_roundtrip_fn__716000286_A_New_O(diff__6); var tmp9 *jrt.Class; var fncls__2507 *jrt.Class = A_arbace_repr_clojure_run_roundtrip_fn__716000286_A_fn_class; if fncls__2507 == nil { var fncls__2507d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_108, false); A_arbace_repr_clojure_run_roundtrip_fn__716000286_A_fn_class = fncls__2507d; tmp9 = fncls__2507d } else { tmp9 = fncls__2507 }; arg_2500 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var arg_2501 any; var root_2508 any = A_arbace_repr_clojure_A_const_107.GetRawRoot__O(); var linked_2509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2508, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2510 lang.IFn; if linked_2509 == nil { ifn_2510 = lang.IFn_Cast(root_2508) } else { ifn_2510 = nil }; var arg_2511 any = known__3; if linked_2509 == nil { arg_2501 = ifn_2510.Invoke_O__O(arg_2511) } else { arg_2501 = linked_2509.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2508, arg_2511) }; if linked_2498 == nil { stale__8 = ifn_2499.Invoke_O_O__O(arg_2500, arg_2501) } else { stale__8 = linked_2498.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_2497, arg_2500, arg_2501) }; var seq_716000288__9 any; var root_2520 any = /*line :366:1*/A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2520, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2522 lang.IFn; if











	linked_2521 == nil { ifn_2522 = lang.IFn_Cast(root_2520) } else { ifn_2522 = nil }; var arg_2523 any = diff__6; if linked_2521 == nil { seq_716000288__9 = ifn_2522.Invoke_O__O(arg_2523) } else { seq_716000288__9 = linked_2521.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2520, arg_2523) }; var chunk_716000289__10 any; var count_716000290__11 int64 = 0; var i_716000291__12 int64 = 0; L1:
//line :366:1
	for {











		if lang.Numbers_Lt_J_J__Z_NoInit(i_716000291__12, count_716000290__11) { var vec__716000292__13 any = lang.Indexed_Cast(chunk_716000289__10).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_716000291__12)); var rel__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000292__13, lang.RT_IntCast_J__I_NoInit(0), nil); var d__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000292__13, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_63, nil, nil, Lit_70, nil, nil, nil, nil); var tmp12 *jrt.String; var tmp13 any; var root_2618 any = A_arbace_repr_clojure_A_const_22.GetRawRoot__O(); var linked_2619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2618, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2620 lang.IFn
			if linked_2619 == nil { ifn_2620 = lang.IFn_Cast(root_2618) } else { ifn_2620 = nil }; var arg_2621 any = known__3; var arg_2622 any = rel__14; if linked_2619 == nil { tmp13 = ifn_2620.Invoke_O_O__O(arg_2621, arg_2622) } else { tmp13 = linked_2619.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2618, arg_2621, arg_2622) }; if jrt.J2g_Truth(tmp13) { tmp12 = Lit_109 } else { tmp12 = Lit_110 }; var tmp14 any = tmp12.Ref(); var tmp15 any; var root_2623 any = A_arbace_repr_clojure_A_const_163.GetRawRoot__O(); var linked_2624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2623, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2625 lang.IFn; if linked_2624 == nil { ifn_2625 = lang.IFn_Cast(root_2623) } else { ifn_2625 = nil }; var arg_2626 any = A_arbace_repr_clojure_A_const_128.Invoke_O__O(d__15); if linked_2624 == nil { tmp15 = ifn_2625.Invoke_O__O(arg_2626) } else { tmp15 = linked_2624.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2623, arg_2626) }; var tmp16 any = tmp15; var tmp17 *jrt.String
			if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_130.Invoke_O__O(d__15)) { tmp17 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_111, nil, Lit_112), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_repr_clojure_A_const_130.Invoke_O__O(d__15), nil)) } else { tmp17 = nil }
//line :379:1
			var tmp18 any = tmp17.Ref(); var tmp19 *jrt.String; var temp__1927000414__auto____24 any = lang.IFn_Cast(known__3).Invoke_O__O(rel__14)

			if jrt.J2g_Truth(temp__1927000414__auto____24) { var k__25 any = temp__1927000414__auto____24; tmp19 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_22, nil), jrt.RefArrayOf(jrt.Object_class, nil, k__25)) } else { tmp19 = nil }
//line :379:1
			var tmp20 any = tmp19.Ref(); var tmp21 *jrt.String; var tmp22 any; var and__1927000168__auto____24 any = A_arbace_repr_clojure_A_const_131.Invoke_O__O(d__15)


			if jrt.J2g_Truth(and__1927000168__auto____24) { var or__1927000174__auto____25 any = A_arbace_repr_clojure_A_const_152.Invoke_O__O(o__0); if jrt.J2g_Truth(or__1927000174__auto____25) { tmp22 = or__1927000174__auto____25 } else { var root_2627 any = A_arbace_repr_clojure_A_const_41.GetRawRoot__O(); var linked_2628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2627, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2629 lang.IFn; if linked_2628 == nil { ifn_2629 = lang.IFn_Cast(root_2627) } else { ifn_2629 = nil }; var arg_2630 any; var root_2631 any = A_arbace_repr_clojure_A_const_22.GetRawRoot__O(); var linked_2632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2631, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2633 lang.IFn; if linked_2632 == nil { ifn_2633 = lang.IFn_Cast(root_2631) } else { ifn_2633 = nil }; var arg_2634 any = known__3; var arg_2635 any = rel__14; if linked_2632 == nil { arg_2630 = ifn_2633.Invoke_O_O__O(arg_2634, arg_2635) } else { arg_2630 = linked_2632.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2631, arg_2634, arg_2635) }; if linked_2628 == nil { tmp22 = ifn_2629.Invoke_O__O(arg_2630) } else { tmp22 = linked_2628.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2627, arg_2630) } } } else { tmp22 = and__1927000168__auto____24 }; if jrt.J2g_Truth(tmp22) { tmp21 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_113, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_repr_clojure_A_const_131.Invoke_O__O(d__15))) } else { tmp21 = nil }
//line :379:1
			tmp10.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp14, rel__14, nil, tmp16, tmp18, tmp20, tmp21.Ref())).Ref())
//line :378:1
			seq_716000288__9, chunk_716000289__10, count_716000290__11, i_716000291__12 = seq_716000288__9, chunk_716000289__10, count_716000290__11, lang.Numbers_Unchecked_inc_J__J_NoInit(i_716000291__12); continue L1 } else { var temp__1927000414__auto____13 any; var root_2524 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2524, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2526 lang.IFn; if linked_2525 == nil { ifn_2526 = lang.IFn_Cast(root_2524) } else { ifn_2526 = nil }; var arg_2527 any = seq_716000288__9; if linked_2525 == nil { temp__1927000414__auto____13 = ifn_2526.Invoke_O__O(arg_2527) } else { temp__1927000414__auto____13 = linked_2525.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2524, arg_2527) }; if jrt.J2g_Truth(temp__1927000414__auto____13) { var seq_716000288__14 any = temp__1927000414__auto____13; var tmp23 any; var root_2528 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_2529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2528, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2530 lang.IFn; if linked_2529 == nil { ifn_2530 = lang.IFn_Cast(root_2528) } else { ifn_2530 = nil }; var arg_2531 any = seq_716000288__14; if linked_2529 == nil { tmp23 = ifn_2530.Invoke_O__O(arg_2531) } else { tmp23 = linked_2529.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2528, arg_2531) }; if jrt.J2g_Truth(tmp23) { var c__1927000678__auto____15 any; var root_2532 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_2533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2532, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2534 lang.IFn; if linked_2533 == nil { ifn_2534 = lang.IFn_Cast(root_2532) } else { ifn_2534 = nil }; var arg_2535 any = seq_716000288__14; if linked_2533 == nil { c__1927000678__auto____15 = ifn_2534.Invoke_O__O(arg_2535) } else { c__1927000678__auto____15 = linked_2533.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2532, arg_2535) }; var tmp24 any; var root_2636 any = A_arbace_repr_clojure_A_const_65.GetRawRoot__O(); var linked_2637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2636, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2638 lang.IFn; if linked_2637 == nil { ifn_2638 = lang.IFn_Cast(root_2636) } else { ifn_2638 = nil }; var arg_2639 any = seq_716000288__14; if linked_2637 == nil { tmp24 = ifn_2638.Invoke_O__O(arg_2639) } else { tmp24 = linked_2637.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2636, arg_2639) }; seq_716000288__9, chunk_716000289__10, count_716000290__11, i_716000291__12 = tmp24, c__1927000678__auto____15, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____15))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__716000295__15 any; var root_2536 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2536, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2538 lang.IFn; if linked_2537 == nil { ifn_2538 = lang.IFn_Cast(root_2536) } else { ifn_2538 = nil }; var arg_2539 any = seq_716000288__14; if linked_2537 == nil { vec__716000295__15 = ifn_2538.Invoke_O__O(arg_2539) } else { vec__716000295__15 = linked_2537.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2536, arg_2539) }; var rel__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000295__15, lang.RT_IntCast_J__I_NoInit(0), nil); var d__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000295__15, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp26 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_63, nil, nil, Lit_70, nil, nil, nil, nil); var tmp27 *jrt.String; var tmp28 any; var root_2644 any = A_arbace_repr_clojure_A_const_22.GetRawRoot__O(); var linked_2645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2644, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2646 lang.IFn
				if linked_2645 == nil { ifn_2646 = lang.IFn_Cast(root_2644) } else { ifn_2646 = nil }; var arg_2647 any = known__3; var arg_2648 any = rel__16; if linked_2645 == nil { tmp28 = ifn_2646.Invoke_O_O__O(arg_2647, arg_2648) } else { tmp28 = linked_2645.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2644, arg_2647, arg_2648) }; if jrt.J2g_Truth(tmp28) { tmp27 = Lit_109 } else { tmp27 = Lit_110 }; var tmp29 any = tmp27.Ref(); var tmp30 any; var root_2649 any = A_arbace_repr_clojure_A_const_163.GetRawRoot__O(); var linked_2650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2649, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2651 lang.IFn; if linked_2650 == nil { ifn_2651 = lang.IFn_Cast(root_2649) } else { ifn_2651 = nil }; var arg_2652 any = A_arbace_repr_clojure_A_const_128.Invoke_O__O(d__17); if linked_2650 == nil { tmp30 = ifn_2651.Invoke_O__O(arg_2652) } else { tmp30 = linked_2650.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2649, arg_2652) }; var tmp31 any = tmp30; var tmp32 *jrt.String
				if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_130.Invoke_O__O(d__17)) { tmp32 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_111, nil, Lit_112), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_repr_clojure_A_const_130.Invoke_O__O(d__17), nil)) } else { tmp32 = nil }
//line :379:1
				var tmp33 any = tmp32.Ref(); var tmp34 *jrt.String; var temp__1927000414__auto____26 any = lang.IFn_Cast(known__3).Invoke_O__O(rel__16)

				if jrt.J2g_Truth(temp__1927000414__auto____26) { var k__27 any = temp__1927000414__auto____26; tmp34 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_22, nil), jrt.RefArrayOf(jrt.Object_class, nil, k__27)) } else { tmp34 = nil }
//line :379:1
				var tmp35 any = tmp34.Ref(); var tmp36 *jrt.String; var tmp37 any; var and__1927000168__auto____26 any = A_arbace_repr_clojure_A_const_131.Invoke_O__O(d__17)


				if jrt.J2g_Truth(and__1927000168__auto____26) { var or__1927000174__auto____27 any = A_arbace_repr_clojure_A_const_152.Invoke_O__O(o__0); if jrt.J2g_Truth(or__1927000174__auto____27) { tmp37 = or__1927000174__auto____27 } else { var root_2653 any = A_arbace_repr_clojure_A_const_41.GetRawRoot__O(); var linked_2654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2653, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2655 lang.IFn; if linked_2654 == nil { ifn_2655 = lang.IFn_Cast(root_2653) } else { ifn_2655 = nil }; var arg_2656 any; var root_2657 any = A_arbace_repr_clojure_A_const_22.GetRawRoot__O(); var linked_2658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2657, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2659 lang.IFn; if linked_2658 == nil { ifn_2659 = lang.IFn_Cast(root_2657) } else { ifn_2659 = nil }; var arg_2660 any = known__3; var arg_2661 any = rel__16; if linked_2658 == nil { arg_2656 = ifn_2659.Invoke_O_O__O(arg_2660, arg_2661) } else { arg_2656 = linked_2658.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2657, arg_2660, arg_2661) }; if linked_2654 == nil { tmp37 = ifn_2655.Invoke_O__O(arg_2656) } else { tmp37 = linked_2654.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2653, arg_2656) } } } else { tmp37 = and__1927000168__auto____26 }; if jrt.J2g_Truth(tmp37) { tmp36 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_113, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_repr_clojure_A_const_131.Invoke_O__O(d__17))) } else { tmp36 = nil }
//line :379:1
				tmp25.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp26, jrt.RefArrayOf(jrt.Object_class, nil, tmp29, rel__16, nil, tmp31, tmp33, tmp35, tmp36.Ref())).Ref())
//line :378:1
				var tmp38 any; var root_2662 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_2663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2662, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2664 lang.IFn; if linked_2663 == nil { ifn_2664 = lang.IFn_Cast(root_2662) } else { ifn_2664 = nil }; var arg_2665 any = seq_716000288__14; if linked_2663 == nil { tmp38 = ifn_2664.Invoke_O__O(arg_2665) } else { tmp38 = linked_2663.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2662, arg_2665) }; seq_716000288__9, chunk_716000289__10, count_716000290__11, i_716000291__12 = tmp38, nil, 0, 0; continue L1 } } }
//line :366:1
		break L1 }; var seq_716000298__9 any; var root_2540 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2540, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2542 lang.IFn; if
















	linked_2541 == nil { ifn_2542 = lang.IFn_Cast(root_2540) } else { ifn_2542 = nil }; var arg_2543 any = stale__8; if linked_2541 == nil { seq_716000298__9 = ifn_2542.Invoke_O__O(arg_2543) } else { seq_716000298__9 = linked_2541.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2540, arg_2543) }; var chunk_716000299__10 any; var count_716000300__11 int64 = 0; var i_716000301__12 int64 = 0; L2:
//line :366:1
	for {
















		if lang.Numbers_Lt_J_J__Z_NoInit(i_716000301__12, count_716000300__11) { var rel__13 any = lang.Indexed_Cast(chunk_716000299__10).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_716000301__12)); lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_114, nil, Lit_115), jrt.RefArrayOf(jrt.Object_class, nil, rel__13, nil)).Ref()); seq_716000298__9, chunk_716000299__10, count_716000300__11, i_716000301__12 = seq_716000298__9, chunk_716000299__10, count_716000300__11, lang.Numbers_Unchecked_inc_J__J_NoInit(i_716000301__12); continue L2 } else { var temp__1927000414__auto____13_2 any; var root_2544 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2544, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2546 lang.IFn; if linked_2545 == nil { ifn_2546 = lang.IFn_Cast(root_2544) } else { ifn_2546 = nil }; var arg_2547 any = seq_716000298__9; if linked_2545 == nil { temp__1927000414__auto____13_2 = ifn_2546.Invoke_O__O(arg_2547) } else { temp__1927000414__auto____13_2 = linked_2545.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2544, arg_2547) }; if jrt.J2g_Truth(temp__1927000414__auto____13_2) { var seq_716000298__14 any = temp__1927000414__auto____13_2; var tmp39 any; var root_2548 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_2549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2548, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2550 lang.IFn; if linked_2549 == nil { ifn_2550 = lang.IFn_Cast(root_2548) } else { ifn_2550 = nil }; var arg_2551 any = seq_716000298__14; if linked_2549 == nil { tmp39 = ifn_2550.Invoke_O__O(arg_2551) } else { tmp39 = linked_2549.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2548, arg_2551) }; if jrt.J2g_Truth(tmp39) { var c__1927000678__auto____15_2 any; var root_2552 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_2553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2552, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2554 lang.IFn; if linked_2553 == nil { ifn_2554 = lang.IFn_Cast(root_2552) } else { ifn_2554 = nil }; var arg_2555 any = seq_716000298__14; if linked_2553 == nil { c__1927000678__auto____15_2 = ifn_2554.Invoke_O__O(arg_2555) } else { c__1927000678__auto____15_2 = linked_2553.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2552, arg_2555) }; var tmp40 any; var root_2670 any = A_arbace_repr_clojure_A_const_65.GetRawRoot__O(); var linked_2671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2670, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2672 lang.IFn; if linked_2671 == nil { ifn_2672 = lang.IFn_Cast(root_2670) } else { ifn_2672 = nil }; var arg_2673 any = seq_716000298__14; if linked_2671 == nil { tmp40 = ifn_2672.Invoke_O__O(arg_2673) } else { tmp40 = linked_2671.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2670, arg_2673) }; seq_716000298__9, chunk_716000299__10, count_716000300__11, i_716000301__12 = tmp40, c__1927000678__auto____15_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____15_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var rel__15 any; var root_2556 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2556, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2558 lang.IFn; if linked_2557 == nil { ifn_2558 = lang.IFn_Cast(root_2556) } else { ifn_2558 = nil }; var arg_2559 any = seq_716000298__14; if linked_2557 == nil { rel__15 = ifn_2558.Invoke_O__O(arg_2559) } else { rel__15 = linked_2557.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2556, arg_2559) }; lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_114, nil, Lit_115), jrt.RefArrayOf(jrt.Object_class, nil, rel__15, nil)).Ref()); var tmp41 any; var root_2678 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_2679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2678, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2680 lang.IFn; if linked_2679 == nil { ifn_2680 = lang.IFn_Cast(root_2678) } else { ifn_2680 = nil }; var arg_2681 any = seq_716000298__14; if linked_2679 == nil { tmp41 = ifn_2680.Invoke_O__O(arg_2681) } else { tmp41 = linked_2679.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2678, arg_2681) }; seq_716000298__9, chunk_716000299__10, count_716000300__11, i_716000301__12 = tmp41, nil, 0, 0; continue L2 } } }
//line :366:1
		break L2 }; if

















	jrt.J2g_Truth(A_arbace_repr_clojure_A_const_152.Invoke_O__O(o__0)) { var seq_716000302__9 any; var root_2560 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2560, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2562 lang.IFn
		if linked_2561 == nil { ifn_2562 = lang.IFn_Cast(root_2560) } else { ifn_2562 = nil }; var arg_2563 any = outside__4; if linked_2561 == nil { seq_716000302__9 = ifn_2562.Invoke_O__O(arg_2563) } else { seq_716000302__9 = linked_2561.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2560, arg_2563) }
//line :384:1
		var chunk_716000303__10 any; var count_716000304__11 int64 = 0; var i_716000305__12 int64 = 0; L3: for {
			if lang.Numbers_Lt_J_J__Z_NoInit(i_716000305__12, count_716000304__11) { var vec__716000306__13 any = lang.Indexed_Cast(chunk_716000303__10).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_716000305__12)); var rel__14_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000306__13, lang.RT_IntCast_J__I_NoInit(0), nil); var d__15_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000306__13, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_116, nil, Lit_113, nil), jrt.RefArrayOf(jrt.Object_class, nil, rel__14_2, nil, A_arbace_repr_clojure_A_const_131.Invoke_O__O(d__15_2))).Ref()); seq_716000302__9, chunk_716000303__10, count_716000304__11, i_716000305__12 = seq_716000302__9, chunk_716000303__10, count_716000304__11, lang.Numbers_Unchecked_inc_J__J_NoInit(i_716000305__12); continue L3 } else { var temp__1927000414__auto____13_3 any; var root_2564 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2564, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2566 lang.IFn; if linked_2565 == nil { ifn_2566 = lang.IFn_Cast(root_2564) } else { ifn_2566 = nil }; var arg_2567 any = seq_716000302__9; if linked_2565 == nil { temp__1927000414__auto____13_3 = ifn_2566.Invoke_O__O(arg_2567) } else { temp__1927000414__auto____13_3 = linked_2565.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2564, arg_2567) }; if jrt.J2g_Truth(temp__1927000414__auto____13_3) { var seq_716000302__14 any = temp__1927000414__auto____13_3; var tmp42 any; var root_2568 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_2569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2568, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2570 lang.IFn; if linked_2569 == nil { ifn_2570 = lang.IFn_Cast(root_2568) } else { ifn_2570 = nil }; var arg_2571 any = seq_716000302__14; if linked_2569 == nil { tmp42 = ifn_2570.Invoke_O__O(arg_2571) } else { tmp42 = linked_2569.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2568, arg_2571) }; if jrt.J2g_Truth(tmp42) { var c__1927000678__auto____15_3 any; var root_2572 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_2573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2572, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2574 lang.IFn; if linked_2573 == nil { ifn_2574 = lang.IFn_Cast(root_2572) } else { ifn_2574 = nil }; var arg_2575 any = seq_716000302__14; if linked_2573 == nil { c__1927000678__auto____15_3 = ifn_2574.Invoke_O__O(arg_2575) } else { c__1927000678__auto____15_3 = linked_2573.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2572, arg_2575) }; var tmp43 any; var root_2686 any = A_arbace_repr_clojure_A_const_65.GetRawRoot__O(); var linked_2687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2686, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2688 lang.IFn; if linked_2687 == nil { ifn_2688 = lang.IFn_Cast(root_2686) } else { ifn_2688 = nil }; var arg_2689 any = seq_716000302__14; if linked_2687 == nil { tmp43 = ifn_2688.Invoke_O__O(arg_2689) } else { tmp43 = linked_2687.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2686, arg_2689) }; seq_716000302__9, chunk_716000303__10, count_716000304__11, i_716000305__12 = tmp43, c__1927000678__auto____15_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____15_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__716000309__15 any; var root_2576 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2576, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2578 lang.IFn; if linked_2577 == nil { ifn_2578 = lang.IFn_Cast(root_2576) } else { ifn_2578 = nil }; var arg_2579 any = seq_716000302__14; if linked_2577 == nil { vec__716000309__15 = ifn_2578.Invoke_O__O(arg_2579) } else { vec__716000309__15 = linked_2577.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2576, arg_2579) }; var rel__16_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000309__15, lang.RT_IntCast_J__I_NoInit(0), nil); var d__17_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000309__15, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_116, nil, Lit_113, nil), jrt.RefArrayOf(jrt.Object_class, nil, rel__16_2, nil, A_arbace_repr_clojure_A_const_131.Invoke_O__O(d__17_2))).Ref()); var tmp44 any; var root_2694 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_2695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2694, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2696 lang.IFn; if linked_2695 == nil { ifn_2696 = lang.IFn_Cast(root_2694) } else { ifn_2696 = nil }; var arg_2697 any = seq_716000302__14; if linked_2695 == nil { tmp44 = ifn_2696.Invoke_O__O(arg_2697) } else { tmp44 = linked_2695.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2694, arg_2697) }; seq_716000302__9, chunk_716000303__10, count_716000304__11, i_716000305__12 = tmp44, nil, 0, 0; continue L3 } } }
//line :384:1
			break L3 } }; var tmp45 lang.IFn =

	lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp46 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_182.GetRawRoot__O()); var tmp47 *jrt.String; if
	jrt.J2g_Truth(A_arbace_repr_clojure_A_const_154.Invoke_O__O(o__0)) { var tmp48 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_66, nil); var tmp49 any; var root_2597 any = A_arbace_repr_clojure_A_const_163.GetRawRoot__O(); var linked_2598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2597, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2599 lang.IFn; if linked_2598 == nil { ifn_2599 = lang.IFn_Cast(root_2597) } else { ifn_2599 = nil }; var arg_2600 any = A_arbace_repr_clojure_A_const_154.Invoke_O__O(o__0); if linked_2598 == nil { tmp49 = ifn_2599.Invoke_O__O(arg_2600) } else { tmp49 = linked_2598.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2597, arg_2600) }; tmp47 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp48, jrt.RefArrayOf(jrt.Object_class, nil, tmp49)) } else { tmp47 = Lit_14 }; var tmp50 any = /*line :386:1*/tmp47.Ref(); var tmp51 *jrt.String; var tmp52 any = A_arbace_repr_clojure_A_const_119; if

	lang.Util_Equiv_O_O__Z_NoInit(tmp52, A_arbace_repr_clojure_A_const_112.Invoke_O__O(o__0)) { tmp51 = Lit_118 } else { tmp51 = Lit_119 }; var tmp53 any = /*line :386:1*/tmp51.Ref(); var tmp54 any = A_arbace_repr_clojure_A_const_139.Invoke_O__O(r__2); var tmp55 any = A_arbace_repr_clojure_A_const_140.Invoke_O__O(r__2); var tmp56 any; var tmp57 any = A_arbace_repr_clojure_A_const_119; if



	lang.Util_Equiv_O_O__Z_NoInit(tmp57, A_arbace_repr_clojure_A_const_112.Invoke_O__O(o__0)) {
		tmp56 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_182.GetRawRoot__O()).Invoke_O_O__O(Lit_120, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(outside__4)).Ref()) } else {
			tmp56 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_182.GetRawRoot__O()).Invoke_O_O__O(Lit_121, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(one_way__5)).Ref()) }; /*line :386:1*/tmp45.Invoke_O__O(tmp46.Invoke_O_O_O_O_O_O_O_O_O_O__O(Lit_117, tmp50, tmp53, tmp54, tmp55, tmp56, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(diff__6)).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(diff__6)), int64(lang.RT_Count_O__I_NoInit(new__7)))).Ref(), jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(new__7)).Ref(), jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(stale__8)).Ref())); var root_2611 any =







	A_arbace_repr_clojure_A_const_183.GetRawRoot__O(); var linked_2612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2611, aot_arbace_core.A_arbace_core_shutdown_agents_A_fn_class); var ifn_2613 lang.IFn; if linked_2612 == nil { ifn_2613 = lang.IFn_Cast(root_2611) } else { ifn_2613 = nil }; if linked_2612 == nil { ifn_2613.Invoke__O() } else { linked_2612.(*aot_arbace_core.A_arbace_core_shutdown_agents_A).Invoke_O__O(root_2611) }; var tmp58 any; var or__1927000174__auto____9 any; var root_2512 any =
	A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2512, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2514 lang.IFn; if linked_2513 == nil { ifn_2514 = lang.IFn_Cast(root_2512) } else { ifn_2514 = nil }; var arg_2515 any = new__7; if linked_2513 == nil { or__1927000174__auto____9 = ifn_2514.Invoke_O__O(arg_2515) } else { or__1927000174__auto____9 = linked_2513.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2512, arg_2515) }; if jrt.J2g_Truth(or__1927000174__auto____9) { tmp58 = or__1927000174__auto____9 } else { var root_2516 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2516, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2518 lang.IFn; if linked_2517 == nil { ifn_2518 = lang.IFn_Cast(root_2516) } else { ifn_2518 = nil }; var arg_2519 any = stale__8; if linked_2517 == nil { tmp58 = ifn_2518.Invoke_O__O(arg_2519) } else { tmp58 = linked_2517.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2516, arg_2519) } }; if jrt.J2g_Truth(tmp58) { jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(1)); return nil } else { return nil } }
//line :373:1
func A_arbace_repr_clojure_run_roundtrip_fn__716000280_A_New() *A_arbace_repr_clojure_run_roundtrip_fn__716000280_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_roundtrip_fn__716000280_A{}; t.Ctor(); return t }
//line :373:1
func (t *A_arbace_repr_clojure_run_roundtrip_fn__716000280_A) Ctor() {}
//line :373:1
func (t *A_arbace_repr_clojure_run_roundtrip_fn__716000280_A) Invoke_O_O__O(self, p1__716000276_SHARP___1 any) any { var tmp1 any = A_arbace_repr_clojure_A_const_135; var tmp2 *lang.Keyword = A_arbace_repr_clojure_A_const_128; var tmp3 any; var root_2440 any = A_arbace_repr_clojure_A_const_178.GetRawRoot__O(); var linked_2441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2440, aot_arbace_core.A_arbace_core_val_A_fn_class); var ifn_2442 lang.IFn; if linked_2441 == nil { ifn_2442 = lang.IFn_Cast(root_2440) } else { ifn_2442 = nil }; var arg_2443 any = p1__716000276_SHARP___1; if linked_2441 == nil { tmp3 = ifn_2442.Invoke_O__O(arg_2443) } else { tmp3 = linked_2441.(*aot_arbace_core.A_arbace_core_val_A).Invoke_O_O__O(root_2440, arg_2443) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2.Invoke_O__O(tmp3))).Ref() }
func A_arbace_repr_clojure_run_roundtrip_fn__716000282_A_New() *A_arbace_repr_clojure_run_roundtrip_fn__716000282_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_roundtrip_fn__716000282_A{}; t.Ctor(); return t }
//line :374:1
func (t *A_arbace_repr_clojure_run_roundtrip_fn__716000282_A) Ctor() {}
//line :374:1
func (t *A_arbace_repr_clojure_run_roundtrip_fn__716000282_A) Invoke_O_O__O(self, p1__716000277_SHARP___1 any) any { var tmp1 any = A_arbace_repr_clojure_A_const_179; var tmp2 *lang.Keyword = A_arbace_repr_clojure_A_const_128; var tmp3 any; var root_2458 any = A_arbace_repr_clojure_A_const_178.GetRawRoot__O(); var linked_2459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2458, aot_arbace_core.A_arbace_core_val_A_fn_class); var ifn_2460 lang.IFn; if linked_2459 == nil { ifn_2460 = lang.IFn_Cast(root_2458) } else { ifn_2460 = nil }; var arg_2461 any = p1__716000277_SHARP___1; if linked_2459 == nil { tmp3 = ifn_2460.Invoke_O__O(arg_2461) } else { tmp3 = linked_2459.(*aot_arbace_core.A_arbace_core_val_A).Invoke_O_O__O(root_2458, arg_2461) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2.Invoke_O__O(tmp3))).Ref() }

func A_arbace_repr_clojure_run_roundtrip_fn__716000284_A_New_O(p0 any) *A_arbace_repr_clojure_run_roundtrip_fn__716000284_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_roundtrip_fn__716000284_A{}; t.Ctor_O(p0); return t }
//line :376:1
func (t *A_arbace_repr_clojure_run_roundtrip_fn__716000284_A) Ctor_O(c__known any) { t.F_known = c__known }
//line :376:1
func (t *A_arbace_repr_clojure_run_roundtrip_fn__716000284_A) Invoke_O_O__O(self, p1__716000278_SHARP___1 any) any { var root_2487 any = A_arbace_repr_clojure_A_const_22.GetRawRoot__O(); var linked_2488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2487, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2489 lang.IFn; if linked_2488 == nil { ifn_2489 = lang.IFn_Cast(root_2487) } else { ifn_2489 = nil }; var arg_2490 any = t.F_known; var arg_2491 any = p1__716000278_SHARP___1; if linked_2488 == nil { return ifn_2489.Invoke_O_O__O(arg_2490, arg_2491) } else { return linked_2488.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2487, arg_2490, arg_2491) } }
func A_arbace_repr_clojure_run_roundtrip_fn__716000286_A_New_O(p0 any) *A_arbace_repr_clojure_run_roundtrip_fn__716000286_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_roundtrip_fn__716000286_A{}; t.Ctor_O(p0); return t }
//line :377:1
func (t *A_arbace_repr_clojure_run_roundtrip_fn__716000286_A) Ctor_O(c__diff any) { t.F_diff = c__diff }
//line :377:1
func (t *A_arbace_repr_clojure_run_roundtrip_fn__716000286_A) Invoke_O_O__O(self, p1__716000279_SHARP___1 any) any { var root_2502 any = A_arbace_repr_clojure_A_const_22.GetRawRoot__O(); var linked_2503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2502, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2504 lang.IFn; if linked_2503 == nil { ifn_2504 = lang.IFn_Cast(root_2502) } else { ifn_2504 = nil }; var arg_2505 any = t.F_diff; var arg_2506 any = p1__716000279_SHARP___1; if linked_2503 == nil { return ifn_2504.Invoke_O_O__O(arg_2505, arg_2506) } else { return linked_2503.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2502, arg_2505, arg_2506) } }



















func A_arbace_repr_clojure__main_A_New() *A_arbace_repr_clojure__main_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure__main_A{}; t.Ctor(); return t }
//line :397:1
func (t *A_arbace_repr_clojure__main_A) Ctor() {}
//line :397:1
func (t *A_arbace_repr_clojure__main_A) DoInvoke_O_O__O(self, args__0 any) any { var vec__716000313__2 any = args__0; var seq__716000314__3 any; var root_2698 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2698, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2700 lang.IFn; if
										linked_2699 == nil { ifn_2700 = lang.IFn_Cast(root_2698) } else { ifn_2700 = nil }; var arg_2701 any = vec__716000313__2; if linked_2699 == nil { seq__716000314__3 = ifn_2700.Invoke_O__O(arg_2701) } else { seq__716000314__3 = linked_2699.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2698, arg_2701) }; var first__716000315__4 any; var root_2702 any = /*line :397:1*/A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2702, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2704 lang.IFn; if
										linked_2703 == nil { ifn_2704 = lang.IFn_Cast(root_2702) } else { ifn_2704 = nil }; var arg_2705 any = seq__716000314__3; if linked_2703 == nil { first__716000315__4 = ifn_2704.Invoke_O__O(arg_2705) } else { first__716000315__4 = linked_2703.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2702, arg_2705) }; var seq__716000314__5 any; var root_2706 any = /*line :397:1*/A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_2707 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2706, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2708 lang.IFn; if
										linked_2707 == nil { ifn_2708 = lang.IFn_Cast(root_2706) } else { ifn_2708 = nil }; var arg_2709 any = seq__716000314__3; if linked_2707 == nil { seq__716000314__5 = ifn_2708.Invoke_O__O(arg_2709) } else { seq__716000314__5 = linked_2707.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2706, arg_2709) }; var cmd__6 any = first__716000315__4; var args__7 any = seq__716000314__5; var verb__8 any = /*line :397:1*/lang.RT_Get_O_O__O_NoInit(A_arbace_repr_clojure_A_const_184, cmd__6); var ___9 any; _ = ___9; if


	jrt.J2g_Truth(verb__8) { ___9 = nil } else { var root_2710 any = A_arbace_repr_clojure_A_const_185.GetRawRoot__O(); var linked_2711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2710, A_arbace_repr_clojure_usage_A_fn_class); var ifn_2712 lang.IFn; if linked_2711 == nil { ifn_2712 = lang.IFn_Cast(root_2710) } else { ifn_2712 = nil }; if linked_2711 == nil { ___9 = ifn_2712.Invoke__O() } else { ___9 = linked_2711.(*A_arbace_repr_clojure_usage_A).Invoke_O__O(root_2710) } }; var o__10 any; var root_2713 any = /*line :397:1*/A_arbace_repr_clojure_A_const_186.GetRawRoot__O(); var linked_2714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2713, A_arbace_repr_clojure_parse_args_A_fn_class); var ifn_2715 lang.IFn; if



	linked_2714 == nil { ifn_2715 = lang.IFn_Cast(root_2713) } else { ifn_2715 = nil }; var arg_2716 any = args__7; if linked_2714 == nil { o__10 = ifn_2715.Invoke_O__O(arg_2716) } else { o__10 = linked_2714.(*A_arbace_repr_clojure_parse_args_A).Invoke_O_O__O(root_2713, arg_2716) }; var known__11 any; var root_2717 any = /*line :397:1*/A_arbace_repr_clojure_A_const_73.GetRawRoot__O(); var linked_2718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2717, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2719 lang.IFn; if




	linked_2718 == nil { ifn_2719 = lang.IFn_Cast(root_2717) } else { ifn_2719 = nil }; var arg_2720 any; var root_2721 any = A_arbace_repr_clojure_A_const_155.GetRawRoot__O(); var linked_2722 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2721, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2723 lang.IFn; if linked_2722 == nil { ifn_2723 = lang.IFn_Cast(root_2721) } else { ifn_2723 = nil }; var arg_2724 any = A_arbace_repr_clojure_A_const_164; var arg_2725 any = A_arbace_repr_clojure_A_const_159.GetRawRoot__O(); if linked_2722 == nil { arg_2720 = ifn_2723.Invoke_O_O__O(arg_2724, arg_2725) } else { arg_2720 = linked_2722.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2721, arg_2724, arg_2725) }; if linked_2718 == nil { known__11 = ifn_2719.Invoke_O__O(arg_2720) } else { known__11 = linked_2718.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2717, arg_2720) }; var temp__1927000414__auto____12 any; var root_2756 any = /*line :397:1*/A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2756, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2758 lang.IFn; if





	linked_2757 == nil { ifn_2758 = lang.IFn_Cast(root_2756) } else { ifn_2758 = nil }; var arg_2759 any; var root_2760 any = A_arbace_repr_clojure_A_const_141.GetRawRoot__O(); var linked_2761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2760, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_2762 lang.IFn; if linked_2761 == nil { ifn_2762 = lang.IFn_Cast(root_2760) } else { ifn_2762 = nil }; var arg_2763 any = known__11; var arg_2764 any = A_arbace_repr_clojure_A_const_33.Invoke_O__O(o__10); if linked_2761 == nil { arg_2759 = ifn_2762.Invoke_O_O__O(arg_2763, arg_2764) } else { arg_2759 = linked_2761.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_2760, arg_2763, arg_2764) }; if linked_2757 == nil { temp__1927000414__auto____12 = ifn_2758.Invoke_O__O(arg_2759) } else { temp__1927000414__auto____12 = linked_2757.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2756, arg_2759) }; if jrt.J2g_Truth(temp__1927000414__auto____12) { var bad__13 any = temp__1927000414__auto____12; var tmp1 any; var root_2765 any = A_arbace_repr_clojure_A_const_146.GetRawRoot__O(); var linked_2766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2765, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2767 lang.IFn
		if linked_2766 == nil { ifn_2767 = lang.IFn_Cast(root_2765) } else { ifn_2767 = nil }; var arg_2768 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_1, nil); var tmp3 any; var root_2770 any = A_arbace_repr_clojure_A_const_191.GetRawRoot__O(); var linked_2771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2770, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_2772 lang.IFn; if linked_2771 == nil { ifn_2772 = lang.IFn_Cast(root_2770) } else { ifn_2772 = nil }; var arg_2773 any = Lit_2; var arg_2774 any; var root_2775 any = A_arbace_repr_clojure_A_const_155.GetRawRoot__O(); var linked_2776 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2775, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2777 lang.IFn; if linked_2776 == nil { ifn_2777 = lang.IFn_Cast(root_2775) } else { ifn_2777 = nil }; var arg_2778 any = A_arbace_repr_clojure_A_const_163.GetRawRoot__O(); var arg_2779 any = bad__13; if linked_2776 == nil { arg_2774 = ifn_2777.Invoke_O_O__O(arg_2778, arg_2779) } else { arg_2774 = linked_2776.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2775, arg_2778, arg_2779) }; if linked_2771 == nil { tmp3 = ifn_2772.Invoke_O_O__O(arg_2773, arg_2774) } else { tmp3 = linked_2771.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_2770, arg_2773, arg_2774) }; arg_2768 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref(); var arg_2769 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_2766 == nil { tmp1 = ifn_2767.Invoke_O_O__O(arg_2768, arg_2769) } else { tmp1 = linked_2766.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_2765, arg_2768, arg_2769) }
//line :403:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }; if

	jrt.J2g_Truth(A_arbace_repr_clojure_A_const_149.Invoke_O__O(o__10)) {
		var root_2726 any = A_arbace_repr_clojure_A_const_187.GetRawRoot__O(); var linked_2727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2726, A_arbace_repr_clojure_print_rules_A_fn_class); var ifn_2728 lang.IFn; if linked_2727 == nil { ifn_2728 = lang.IFn_Cast(root_2726) } else { ifn_2728 = nil }; if linked_2727 == nil { return ifn_2728.Invoke__O() } else { return linked_2727.(*A_arbace_repr_clojure_print_rules_A).Invoke_O__O(root_2726) } } else {
//line :405:1
			if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_148.Invoke_O__O(o__10)) { var p__12 any; var tmp4 any = A_arbace_repr_clojure_A_const_24; var tmp5 any = A_arbace_repr_clojure_A_const_24.Invoke_O__O(o__10); var tmp6 any = A_arbace_repr_clojure_A_const_27; var tmp7 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(A_arbace_repr_clojure_A_const_150.Invoke_O__O(o__10))).Ref(); var tmp8 any = A_arbace_repr_clojure_A_const_20; var tmp9 any; var and__1927000168__auto____12 any = A_arbace_repr_clojure_A_const_20.Invoke_O__O(o__10)


				if jrt.J2g_Truth(and__1927000168__auto____12) { var tmp10 any = A_arbace_repr_clojure_A_const_25; var and__1927000168__auto____13 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp10, A_arbace_repr_clojure_A_const_24.Invoke_O__O(o__10)); if and__1927000168__auto____13 { tmp9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(A_arbace_repr_clojure_A_const_150.Invoke_O__O(o__10))).Ref() } else { tmp9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____13).Ref() } } else { tmp9 = and__1927000168__auto____12 }
//line :405:1
				p__12 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9))



				var tmp11 *lang.Keyword = A_arbace_repr_clojure_A_const_19; lang.IFn_Cast(A_arbace_repr_clojure_A_const_192.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(tmp11.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_A_const_69.GetRawRoot__O()).Invoke_O__O(verb__8))).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_repr_clojure_A_const_78.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_A_const_193.Get__O()), p__12, Lit_3, A_arbace_repr_clojure_A_const_33.Invoke_O__O(o__10)))
				var root_2729 any = A_arbace_repr_clojure_A_const_188.GetRawRoot__O(); var linked_2730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2729, aot_arbace_core.A_arbace_core_flush_A_fn_class); var ifn_2731 lang.IFn; if linked_2730 == nil { ifn_2731 = lang.IFn_Cast(root_2729) } else { ifn_2731 = nil }; if linked_2730 == nil { return ifn_2731.Invoke__O() } else { return linked_2730.(*aot_arbace_core.A_arbace_core_flush_A).Invoke_O__O(root_2729) } } else {
//line :405:1
					var tmp12 any; var root_2732 any = A_arbace_repr_clojure_A_const_144.GetRawRoot__O(); var linked_2733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2732, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2734 lang.IFn





					if linked_2733 == nil { ifn_2734 = lang.IFn_Cast(root_2732) } else { ifn_2734 = nil }; var arg_2735 any = A_arbace_repr_clojure_A_const_143.Invoke_O__O(o__10); if linked_2733 == nil { tmp12 = ifn_2734.Invoke_O__O(arg_2735) } else { tmp12 = linked_2733.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2732, arg_2735) }
//line :405:1
					if jrt.J2g_Truth(tmp12) {





						var root_2736 any = A_arbace_repr_clojure_A_const_185.GetRawRoot__O(); var linked_2737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2736, A_arbace_repr_clojure_usage_A_fn_class); var ifn_2738 lang.IFn; if linked_2737 == nil { ifn_2738 = lang.IFn_Cast(root_2736) } else { ifn_2738 = nil }; if linked_2737 == nil { return ifn_2738.Invoke__O() } else { return linked_2737.(*A_arbace_repr_clojure_usage_A).Invoke_O__O(root_2736) } } else {
//line :405:1
							if lang.Util_Equiv_O_O__Z_NoInit(verb__8, A_arbace_repr_clojure_A_const_189) {






								var root_2739 any = A_arbace_repr_clojure_A_const_190.GetRawRoot__O(); var linked_2740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2739, A_arbace_repr_clojure_run_roundtrip_A_fn_class); var ifn_2741 lang.IFn; if linked_2740 == nil { ifn_2741 = lang.IFn_Cast(root_2739) } else { ifn_2741 = nil }; var arg_2742 any = o__10; if linked_2740 == nil { return ifn_2741.Invoke_O__O(arg_2742) } else { return linked_2740.(*A_arbace_repr_clojure_run_roundtrip_A).Invoke_O_O__O(root_2739, arg_2742) } } else {
//line :405:1
									var tmp13 any; var root_2743 any = A_arbace_repr_clojure_A_const_41.GetRawRoot__O(); var linked_2744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2743, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2745 lang.IFn







									if linked_2744 == nil { ifn_2745 = lang.IFn_Cast(root_2743) } else { ifn_2745 = nil }; var arg_2746 any; var or__1927000174__auto____12 any = A_arbace_repr_clojure_A_const_28.Invoke_O__O(o__10); if jrt.J2g_Truth(or__1927000174__auto____12) { arg_2746 = or__1927000174__auto____12 } else { arg_2746 = A_arbace_repr_clojure_A_const_147.Invoke_O__O(o__10) }; if linked_2744 == nil { tmp13 = ifn_2745.Invoke_O__O(arg_2746) } else { tmp13 = linked_2744.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2743, arg_2746) }
//line :405:1
									if jrt.J2g_Truth(tmp13) {








										var root_2796 any = A_arbace_repr_clojure_A_const_88.GetRawRoot__O(); var linked_2797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2796, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2798 lang.IFn; if linked_2797 == nil { ifn_2798 = lang.IFn_Cast(root_2796) } else { ifn_2798 = nil }; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_89.GetRawRoot__O()); var tmp15 any = A_arbace_repr_clojure_A_const_90; var arg_2799 any = tmp14.Invoke_O_O__O(tmp15, A_arbace_repr_clojure_A_const_91.Get__O()); if linked_2797 == nil { ifn_2798.Invoke_O__O(arg_2799) } else { linked_2797.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2796, arg_2799) }; var tmp16 any = A_arbace_repr_clojure__main_fn__716000316_A_New(); var tmp17 *jrt.Class; var fncls__2795 *jrt.Class = A_arbace_repr_clojure__main_fn__716000316_A_fn_class; if fncls__2795 == nil { var fncls__2795d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_repr_clojure__main_fn__716000316_A_fn_class = fncls__2795d; tmp17 = fncls__2795d } else { tmp17 = fncls__2795 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil).Invoke__O(); jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2)); return nil } else {
//line :405:1
											if A_arbace_repr_clojure_A_const_34 != nil { var s__12 any; var root_2747 any = A_arbace_repr_clojure_A_const_98.GetRawRoot__O(); var linked_2748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2747, A_arbace_repr_clojure_run_A_fn_class); var ifn_2749 lang.IFn










												if linked_2748 == nil { ifn_2749 = lang.IFn_Cast(root_2747) } else { ifn_2749 = nil }; var arg_2750 any = verb__8; var arg_2751 any = A_arbace_repr_clojure_A_const_143.Invoke_O__O(o__10); var arg_2752 any; if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_147.Invoke_O__O(o__10)) { arg_2752 = nil } else { arg_2752 = A_arbace_repr_clojure_A_const_28.Invoke_O__O(o__10) }; var arg_2753 any = o__10; if linked_2748 == nil { s__12 = ifn_2749.Invoke_O_O_O_O__O(arg_2750, arg_2751, arg_2752, arg_2753) } else { s__12 = linked_2748.(*A_arbace_repr_clojure_run_A).Invoke_O_O_O_O_O__O(root_2747, arg_2750, arg_2751, arg_2752, arg_2753) }
												if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_151.Invoke_O__O(o__10)) { } else {
													var root_2825 any = A_arbace_repr_clojure_A_const_88.GetRawRoot__O(); var linked_2826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2825, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2827 lang.IFn; if linked_2826 == nil { ifn_2827 = lang.IFn_Cast(root_2825) } else { ifn_2827 = nil }; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_89.GetRawRoot__O()); var tmp19 any = A_arbace_repr_clojure_A_const_90; var arg_2828 any = tmp18.Invoke_O_O__O(tmp19, A_arbace_repr_clojure_A_const_91.Get__O()); if linked_2826 == nil { ifn_2827.Invoke_O__O(arg_2828) } else { linked_2826.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2825, arg_2828) }; var tmp20 any = A_arbace_repr_clojure__main_fn__716000318_A_New_O_O(s__12, verb__8); var tmp21 *jrt.Class; var fncls__2824 *jrt.Class = A_arbace_repr_clojure__main_fn__716000318_A_fn_class; if fncls__2824 == nil { var fncls__2824d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_repr_clojure__main_fn__716000318_A_fn_class = fncls__2824d; tmp21 = fncls__2824d } else { tmp21 = fncls__2824 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil).Invoke__O()
												}



												var tmp22 bool; var na_2754 any = A_arbace_repr_clojure_A_const_86.Invoke_O__O(s__12); if jrt.Long_InstanceOf(na_2754) { var n0_2755 int64 = jrt.NN(jrt.Long_Cast(na_2754)).LongValue__J(); tmp22 = n0_2755 > 0 } else { if jrt.Double_InstanceOf(na_2754) { var n0_2755_2 float64 = jrt.NN(jrt.Double_Cast(na_2754)).DoubleValue__D(); tmp22 = n0_2755_2 > 0.0 } else { tmp22 = lang.Numbers_IsPos_O__Z_NoInit(na_2754) } }; if tmp22 { jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(1)); return nil } else { return nil } } else {
//line :405:1
													return nil } } } } } } }








func A_arbace_repr_clojure__main_fn__716000316_A_New() *A_arbace_repr_clojure__main_fn__716000316_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure__main_fn__716000316_A{}; t.Ctor(); return t }
//line :414:1
func (t *A_arbace_repr_clojure__main_fn__716000316_A) Ctor() {}
//line :414:1
func (t *A_arbace_repr_clojure__main_fn__716000316_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()).Invoke_O__O(Lit_6); return nil }(); var root_2792 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); var linked_2793 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2792, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2794 lang.IFn; if linked_2793 == nil { ifn_2794 = lang.IFn_Cast(root_2792) } else { ifn_2794 = nil }; if linked_2793 == nil { ifn_2794.Invoke__O() } else { linked_2793.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2792) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }



func A_arbace_repr_clojure__main_fn__716000318_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure__main_fn__716000318_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure__main_fn__716000318_A{}; t.Ctor_O_O(p0, p1); return t }
//line :418:1
func (t *A_arbace_repr_clojure__main_fn__716000318_A) Ctor_O_O(c__s, c__verb any) { t.F_s = c__s; t.F_verb = c__verb }
//line :418:1
func (t *A_arbace_repr_clojure__main_fn__716000318_A) Invoke_O__O(self any) any { var tmp1 any; tmp16 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_182.GetRawRoot__O()); var tmp4 any = A_arbace_repr_clojure_A_const_97.Invoke_O__O(t.F_s); var tmp5 *jrt.String
											if lang.Util_Equiv_O_O__Z_NoInit(t.F_verb, A_arbace_repr_clojure_A_const_194) { tmp5 = Lit_8 } else { tmp5 = Lit_9 }
//line :419:1
		var tmp6 any = tmp5.Ref(); var tmp7 any = A_arbace_repr_clojure_A_const_27.Invoke_O__O(t.F_s); var tmp8 *jrt.String; var tmp9 any; var t_ any = t.F_verb

		t.F_verb = nil; tmp9 = t_; if lang.Util_Equiv_O_O__Z_NoInit(tmp9, A_arbace_repr_clojure_A_const_194) { tmp8 = Lit_10 } else { tmp8 = Lit_11 }
//line :419:1
		var tmp10 any = tmp8.Ref(); var tmp11 any = A_arbace_repr_clojure_A_const_96.Invoke_O__O(t.F_s); var tmp12 any = A_arbace_repr_clojure_A_const_84.Invoke_O__O(t.F_s); var tmp13 any = A_arbace_repr_clojure_A_const_93.Invoke_O__O(t.F_s); var tmp14 *lang.Keyword = A_arbace_repr_clojure_A_const_86; var tmp15 any; var t__2 any = t.F_s


		t.F_s = nil; tmp15 = t__2
//line :419:1
		tmp1 = tmp2.Invoke_O__O(tmp3.Invoke_O_O_O_O_O_O_O_O_O__O(Lit_7, tmp4, tmp6, tmp7, tmp10, tmp11, tmp12, tmp13, tmp14.Invoke_O__O(tmp15))) }
//line :418:1
	return nil }(); var root_2821 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); var linked_2822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2821, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2823 lang.IFn; if linked_2822 == nil { ifn_2823 = lang.IFn_Cast(root_2821) } else { ifn_2823 = nil }; if linked_2822 == nil { ifn_2823.Invoke__O() } else { linked_2822.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2821) }; if tmp16 != nil { panic(tmp16) }; return tmp1 }



























































































































































type A_arbace_repr_clojure_A struct{ jrt.Object }

var A_arbace_repr_clojure_A_const_pool *jrt.RefArray

var A_arbace_repr_clojure_A_const_0 *lang.Var

var A_arbace_repr_clojure_A_const_1 any

var A_arbace_repr_clojure_A_const_2 *lang.Var

var A_arbace_repr_clojure_A_const_3 any

var A_arbace_repr_clojure_A_const_4 any

var A_arbace_repr_clojure_A_const_5 any

var A_arbace_repr_clojure_A_const_6 any

var A_arbace_repr_clojure_A_const_7 *lang.Var

var A_arbace_repr_clojure_A_const_8 *lang.Var

var A_arbace_repr_clojure_A_const_9 *lang.Var

var A_arbace_repr_clojure_A_const_10 *lang.Var

var A_arbace_repr_clojure_A_const_11 any

var A_arbace_repr_clojure_A_const_12 *lang.Var

var A_arbace_repr_clojure_A_const_13 any

var A_arbace_repr_clojure_A_const_14 *lang.Var

var A_arbace_repr_clojure_A_const_15 *lang.Var

var A_arbace_repr_clojure_A_const_16 *lang.Var

var A_arbace_repr_clojure_A_const_17 *lang.Var

var A_arbace_repr_clojure_A_const_18 *lang.Keyword

var A_arbace_repr_clojure_A_const_19 *lang.Keyword

var A_arbace_repr_clojure_A_const_20 *lang.Keyword

var A_arbace_repr_clojure_A_const_21 *lang.Var

var A_arbace_repr_clojure_A_const_22 *lang.Var

var A_arbace_repr_clojure_A_const_23 *lang.Var

var A_arbace_repr_clojure_A_const_24 *lang.Keyword

var A_arbace_repr_clojure_A_const_25 *lang.Keyword

var A_arbace_repr_clojure_A_const_26 *lang.Keyword

var A_arbace_repr_clojure_A_const_27 *lang.Keyword

var A_arbace_repr_clojure_A_const_28 *lang.Keyword

var A_arbace_repr_clojure_A_const_29 any

var A_arbace_repr_clojure_A_const_30 *lang.Var

var A_arbace_repr_clojure_A_const_31 any

var A_arbace_repr_clojure_A_const_32 *lang.Var

var A_arbace_repr_clojure_A_const_33 *lang.Keyword

var A_arbace_repr_clojure_A_const_34 *lang.Keyword

var A_arbace_repr_clojure_A_const_35 *lang.Keyword

var A_arbace_repr_clojure_A_const_36 *lang.Var

var A_arbace_repr_clojure_A_const_37 *lang.Var

var A_arbace_repr_clojure_A_const_38 any

var A_arbace_repr_clojure_A_const_39 any

var A_arbace_repr_clojure_A_const_40 *lang.Var

var A_arbace_repr_clojure_A_const_41 *lang.Var

var A_arbace_repr_clojure_A_const_42 any

var A_arbace_repr_clojure_A_const_43 any

var A_arbace_repr_clojure_A_const_44 any

var A_arbace_repr_clojure_A_const_45 any

var A_arbace_repr_clojure_A_const_46 *lang.Var

var A_arbace_repr_clojure_A_const_47 any

var A_arbace_repr_clojure_A_const_48 any

var A_arbace_repr_clojure_A_const_49 *lang.Var

var A_arbace_repr_clojure_A_const_50 *lang.Var

var A_arbace_repr_clojure_A_const_51 *lang.Keyword

var A_arbace_repr_clojure_A_const_52 any

var A_arbace_repr_clojure_A_const_53 *lang.Keyword

var A_arbace_repr_clojure_A_const_54 *lang.Var

var A_arbace_repr_clojure_A_const_55 any

var A_arbace_repr_clojure_A_const_56 *lang.Var

var A_arbace_repr_clojure_A_const_57 *lang.Var

var A_arbace_repr_clojure_A_const_58 *lang.Var

var A_arbace_repr_clojure_A_const_59 *lang.Var

var A_arbace_repr_clojure_A_const_60 *lang.Var

var A_arbace_repr_clojure_A_const_61 *lang.Var

var A_arbace_repr_clojure_A_const_62 *lang.Var

var A_arbace_repr_clojure_A_const_63 *lang.Var

var A_arbace_repr_clojure_A_const_64 *lang.Var

var A_arbace_repr_clojure_A_const_65 *lang.Var

var A_arbace_repr_clojure_A_const_66 *lang.Var

var A_arbace_repr_clojure_A_const_67 *lang.Var

var A_arbace_repr_clojure_A_const_68 *lang.Var

var A_arbace_repr_clojure_A_const_69 *lang.Var

var A_arbace_repr_clojure_A_const_70 *lang.Keyword

var A_arbace_repr_clojure_A_const_71 *lang.Keyword

var A_arbace_repr_clojure_A_const_72 *lang.Var

var A_arbace_repr_clojure_A_const_73 *lang.Var

var A_arbace_repr_clojure_A_const_74 *lang.Var

var A_arbace_repr_clojure_A_const_75 any

var A_arbace_repr_clojure_A_const_76 *lang.Var

var A_arbace_repr_clojure_A_const_77 *lang.Var

var A_arbace_repr_clojure_A_const_78 *lang.Var

var A_arbace_repr_clojure_A_const_79 *lang.Var

var A_arbace_repr_clojure_A_const_80 *lang.Var

var A_arbace_repr_clojure_A_const_81 *lang.Keyword

var A_arbace_repr_clojure_A_const_82 *lang.Var

var A_arbace_repr_clojure_A_const_83 *lang.Var

var A_arbace_repr_clojure_A_const_84 *lang.Keyword

var A_arbace_repr_clojure_A_const_85 *lang.Var

var A_arbace_repr_clojure_A_const_86 *lang.Keyword

var A_arbace_repr_clojure_A_const_87 *lang.Var

var A_arbace_repr_clojure_A_const_88 *lang.Var

var A_arbace_repr_clojure_A_const_89 *lang.Var

var A_arbace_repr_clojure_A_const_90 *lang.Var

var A_arbace_repr_clojure_A_const_91 *lang.Var

var A_arbace_repr_clojure_A_const_92 *lang.Var

var A_arbace_repr_clojure_A_const_93 *lang.Keyword

var A_arbace_repr_clojure_A_const_94 *lang.Var

var A_arbace_repr_clojure_A_const_95 *lang.Var

var A_arbace_repr_clojure_A_const_96 *lang.Keyword

var A_arbace_repr_clojure_A_const_97 *lang.Keyword

var A_arbace_repr_clojure_A_const_98 *lang.Var

var A_arbace_repr_clojure_A_const_99 *lang.Keyword

var A_arbace_repr_clojure_A_const_100 *lang.Var

var A_arbace_repr_clojure_A_const_101 *lang.Var

var A_arbace_repr_clojure_A_const_102 *lang.Var

var A_arbace_repr_clojure_A_const_103 *lang.Var

var A_arbace_repr_clojure_A_const_104 *lang.Var

var A_arbace_repr_clojure_A_const_105 *lang.Var

var A_arbace_repr_clojure_A_const_106 *lang.Var

var A_arbace_repr_clojure_A_const_107 *lang.Var

var A_arbace_repr_clojure_A_const_108 *lang.Var

var A_arbace_repr_clojure_A_const_109 *lang.Keyword

var A_arbace_repr_clojure_A_const_110 *lang.Var

var A_arbace_repr_clojure_A_const_111 *lang.Var

var A_arbace_repr_clojure_A_const_112 *lang.Keyword

var A_arbace_repr_clojure_A_const_113 *lang.Keyword

var A_arbace_repr_clojure_A_const_114 *lang.Keyword

var A_arbace_repr_clojure_A_const_115 *lang.Var

var A_arbace_repr_clojure_A_const_116 *lang.Var

var A_arbace_repr_clojure_A_const_117 any

var A_arbace_repr_clojure_A_const_118 *lang.Var

var A_arbace_repr_clojure_A_const_119 *lang.Keyword

var A_arbace_repr_clojure_A_const_120 any

var A_arbace_repr_clojure_A_const_121 any

var A_arbace_repr_clojure_A_const_122 *lang.Var

var A_arbace_repr_clojure_A_const_123 *lang.Var

var A_arbace_repr_clojure_A_const_124 *lang.Var

var A_arbace_repr_clojure_A_const_125 any

var A_arbace_repr_clojure_A_const_126 *lang.Var

var A_arbace_repr_clojure_A_const_127 any

var A_arbace_repr_clojure_A_const_128 *lang.Keyword

var A_arbace_repr_clojure_A_const_129 *lang.Keyword

var A_arbace_repr_clojure_A_const_130 *lang.Keyword

var A_arbace_repr_clojure_A_const_131 *lang.Keyword

var A_arbace_repr_clojure_A_const_132 *lang.Var

var A_arbace_repr_clojure_A_const_133 any

var A_arbace_repr_clojure_A_const_134 *lang.Var

var A_arbace_repr_clojure_A_const_135 *lang.Keyword

var A_arbace_repr_clojure_A_const_136 any

var A_arbace_repr_clojure_A_const_137 any

var A_arbace_repr_clojure_A_const_138 any

var A_arbace_repr_clojure_A_const_139 *lang.Keyword

var A_arbace_repr_clojure_A_const_140 *lang.Keyword

var A_arbace_repr_clojure_A_const_141 *lang.Var

var A_arbace_repr_clojure_A_const_142 *lang.Keyword

var A_arbace_repr_clojure_A_const_143 *lang.Keyword

var A_arbace_repr_clojure_A_const_144 *lang.Var

var A_arbace_repr_clojure_A_const_145 *lang.Var

var A_arbace_repr_clojure_A_const_146 *lang.Var

var A_arbace_repr_clojure_A_const_147 *lang.Keyword

var A_arbace_repr_clojure_A_const_148 *lang.Keyword

var A_arbace_repr_clojure_A_const_149 *lang.Keyword

var A_arbace_repr_clojure_A_const_150 *lang.Keyword

var A_arbace_repr_clojure_A_const_151 *lang.Keyword

var A_arbace_repr_clojure_A_const_152 *lang.Keyword

var A_arbace_repr_clojure_A_const_153 *lang.Keyword

var A_arbace_repr_clojure_A_const_154 *lang.Keyword

var A_arbace_repr_clojure_A_const_155 *lang.Var

var A_arbace_repr_clojure_A_const_156 *lang.Var

var A_arbace_repr_clojure_A_const_157 any

var A_arbace_repr_clojure_A_const_158 *lang.Var

var A_arbace_repr_clojure_A_const_159 *lang.Var

var A_arbace_repr_clojure_A_const_160 *lang.Var

var A_arbace_repr_clojure_A_const_161 *lang.Keyword

var A_arbace_repr_clojure_A_const_162 any

var A_arbace_repr_clojure_A_const_163 *lang.Var

var A_arbace_repr_clojure_A_const_164 *lang.Keyword

var A_arbace_repr_clojure_A_const_165 *lang.Keyword

var A_arbace_repr_clojure_A_const_166 *lang.Keyword

var A_arbace_repr_clojure_A_const_167 any

var A_arbace_repr_clojure_A_const_168 *lang.Keyword

var A_arbace_repr_clojure_A_const_169 *lang.Keyword

var A_arbace_repr_clojure_A_const_170 *lang.Keyword

var A_arbace_repr_clojure_A_const_171 any

var A_arbace_repr_clojure_A_const_172 *lang.Var

var A_arbace_repr_clojure_A_const_173 any

var A_arbace_repr_clojure_A_const_174 *lang.Var

var A_arbace_repr_clojure_A_const_175 *lang.Var

var A_arbace_repr_clojure_A_const_176 *lang.Var

var A_arbace_repr_clojure_A_const_177 *lang.Var

var A_arbace_repr_clojure_A_const_178 *lang.Var

var A_arbace_repr_clojure_A_const_179 *lang.Keyword

var A_arbace_repr_clojure_A_const_180 *lang.Var

var A_arbace_repr_clojure_A_const_181 *lang.Var

var A_arbace_repr_clojure_A_const_182 *lang.Var

var A_arbace_repr_clojure_A_const_183 *lang.Var

var A_arbace_repr_clojure_A_const_184 any

var A_arbace_repr_clojure_A_const_185 *lang.Var

var A_arbace_repr_clojure_A_const_186 *lang.Var

var A_arbace_repr_clojure_A_const_187 *lang.Var

var A_arbace_repr_clojure_A_const_188 *lang.Var

var A_arbace_repr_clojure_A_const_189 *lang.Keyword

var A_arbace_repr_clojure_A_const_190 *lang.Var

var A_arbace_repr_clojure_A_const_191 *lang.Var

var A_arbace_repr_clojure_A_const_192 *lang.Var

var A_arbace_repr_clojure_A_const_193 *lang.Var

var A_arbace_repr_clojure_A_const_194 *lang.Keyword

var A_arbace_repr_clojure_A_init jrt.ClassInit

func A_arbace_repr_clojure_A_Init() { if !A_arbace_repr_clojure_A_init.Done() { A_arbace_repr_clojure_A_init.Run(A_arbace_repr_clojure_A_clinit) } }

func A_arbace_repr_clojure_A_clinit() { A_arbace_repr_clojure_A_clinit_p0(); A_arbace_repr_clojure_A_clinit_p1(); A_arbace_repr_clojure_A_clinit_p2(); A_arbace_repr_clojure_A_clinit_p3(); A_arbace_repr_clojure_A_clinit_p4(); A_arbace_repr_clojure_A_clinit_p5(); A_arbace_repr_clojure_A_clinit_p6(); A_arbace_repr_clojure_A_clinit_p7(); A_arbace_repr_clojure_A_clinit_p8(); A_arbace_repr_clojure_A_clinit_p9(); A_arbace_repr_clojure_A_clinit_p10(); A_arbace_repr_clojure_A_clinit_p11(); A_arbace_repr_clojure_A_clinit_p12(); A_arbace_repr_clojure_A_clinit_p13(); A_arbace_repr_clojure_A_clinit_p14(); A_arbace_repr_clojure_A_clinit_p15(); A_arbace_repr_clojure_A_clinit_p16() }

func A_arbace_repr_clojure_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_clojure_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 260); A_arbace_repr_clojure_A_const_0 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[65]); A_arbace_repr_clojure_A_const_1 = A_arbace_repr_clojure_A_const_pool.A[66]; A_arbace_repr_clojure_A_const_2 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[67]); A_arbace_repr_clojure_A_const_3 = A_arbace_repr_clojure_A_const_pool.A[68]; A_arbace_repr_clojure_A_const_4 = A_arbace_repr_clojure_A_const_pool.A[69]; A_arbace_repr_clojure_A_const_5 = A_arbace_repr_clojure_A_const_pool.A[70]; A_arbace_repr_clojure_A_const_6 = A_arbace_repr_clojure_A_const_pool.A[71]; A_arbace_repr_clojure_A_const_7 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[72]); A_arbace_repr_clojure_A_const_8 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[73]); A_arbace_repr_clojure_A_const_9 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[74]); A_arbace_repr_clojure_A_const_10 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[75]); A_arbace_repr_clojure_A_const_11 = A_arbace_repr_clojure_A_const_pool.A[76] }

func A_arbace_repr_clojure_A_clinit_p1() { A_arbace_repr_clojure_A_const_12 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[77]); A_arbace_repr_clojure_A_const_13 = A_arbace_repr_clojure_A_const_pool.A[78]; A_arbace_repr_clojure_A_const_14 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[79]); A_arbace_repr_clojure_A_const_15 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[80]); A_arbace_repr_clojure_A_const_16 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[81]); A_arbace_repr_clojure_A_const_17 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[82]); A_arbace_repr_clojure_A_const_18 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[83]); A_arbace_repr_clojure_A_const_19 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[84]); A_arbace_repr_clojure_A_const_20 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[85]); A_arbace_repr_clojure_A_const_21 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[86]); A_arbace_repr_clojure_A_const_22 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[87]); A_arbace_repr_clojure_A_const_23 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[88]) }

func A_arbace_repr_clojure_A_clinit_p2() { A_arbace_repr_clojure_A_const_24 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[89]); A_arbace_repr_clojure_A_const_25 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[90]); A_arbace_repr_clojure_A_const_26 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[91]); A_arbace_repr_clojure_A_const_27 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[92]); A_arbace_repr_clojure_A_const_28 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[93]); A_arbace_repr_clojure_A_const_29 = A_arbace_repr_clojure_A_const_pool.A[94]; A_arbace_repr_clojure_A_const_30 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[95]); A_arbace_repr_clojure_A_const_31 = A_arbace_repr_clojure_A_const_pool.A[96]; A_arbace_repr_clojure_A_const_32 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[97]); A_arbace_repr_clojure_A_const_33 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[98]); A_arbace_repr_clojure_A_const_34 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[99]); A_arbace_repr_clojure_A_const_35 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[100]) }

func A_arbace_repr_clojure_A_clinit_p3() { A_arbace_repr_clojure_A_const_36 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[101]); A_arbace_repr_clojure_A_const_37 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[102]); A_arbace_repr_clojure_A_const_38 = A_arbace_repr_clojure_A_const_pool.A[103]; A_arbace_repr_clojure_A_const_39 = A_arbace_repr_clojure_A_const_pool.A[104]; A_arbace_repr_clojure_A_const_40 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[105]); A_arbace_repr_clojure_A_const_41 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[106]); A_arbace_repr_clojure_A_const_42 = A_arbace_repr_clojure_A_const_pool.A[107]; A_arbace_repr_clojure_A_const_43 = A_arbace_repr_clojure_A_const_pool.A[108]; A_arbace_repr_clojure_A_const_44 = A_arbace_repr_clojure_A_const_pool.A[109]; A_arbace_repr_clojure_A_const_45 = A_arbace_repr_clojure_A_const_pool.A[110]; A_arbace_repr_clojure_A_const_46 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[111]); A_arbace_repr_clojure_A_const_47 = A_arbace_repr_clojure_A_const_pool.A[112]; A_arbace_repr_clojure_A_const_48 = A_arbace_repr_clojure_A_const_pool.A[113]; A_arbace_repr_clojure_A_const_49 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[114]) }

func A_arbace_repr_clojure_A_clinit_p4() { A_arbace_repr_clojure_A_const_50 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[115]); A_arbace_repr_clojure_A_const_51 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[116]); A_arbace_repr_clojure_A_const_52 = A_arbace_repr_clojure_A_const_pool.A[117]; A_arbace_repr_clojure_A_const_53 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[118]); A_arbace_repr_clojure_A_const_54 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[119]); A_arbace_repr_clojure_A_const_55 = A_arbace_repr_clojure_A_const_pool.A[120]; A_arbace_repr_clojure_A_const_56 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[121]); A_arbace_repr_clojure_A_const_57 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[122]); A_arbace_repr_clojure_A_const_58 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[123]); A_arbace_repr_clojure_A_const_59 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[124]); A_arbace_repr_clojure_A_const_60 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[125]); A_arbace_repr_clojure_A_const_61 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[126]) }

func A_arbace_repr_clojure_A_clinit_p5() { A_arbace_repr_clojure_A_const_62 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[127]); A_arbace_repr_clojure_A_const_63 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[128]); A_arbace_repr_clojure_A_const_64 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[129]); A_arbace_repr_clojure_A_const_65 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[130]); A_arbace_repr_clojure_A_const_66 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[131]); A_arbace_repr_clojure_A_const_67 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[132]); A_arbace_repr_clojure_A_const_68 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[133]); A_arbace_repr_clojure_A_const_69 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[134]); A_arbace_repr_clojure_A_const_70 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[135]); A_arbace_repr_clojure_A_const_71 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[136]); A_arbace_repr_clojure_A_const_72 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[137]); A_arbace_repr_clojure_A_const_73 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[138]) }

func A_arbace_repr_clojure_A_clinit_p6() { A_arbace_repr_clojure_A_const_74 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[139]); A_arbace_repr_clojure_A_const_75 = A_arbace_repr_clojure_A_const_pool.A[140]; A_arbace_repr_clojure_A_const_76 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[141]); A_arbace_repr_clojure_A_const_77 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[142]); A_arbace_repr_clojure_A_const_78 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[143]); A_arbace_repr_clojure_A_const_79 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[144]); A_arbace_repr_clojure_A_const_80 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[145]); A_arbace_repr_clojure_A_const_81 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[146]); A_arbace_repr_clojure_A_const_82 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[147]); A_arbace_repr_clojure_A_const_83 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[148]); A_arbace_repr_clojure_A_const_84 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[149]); A_arbace_repr_clojure_A_const_85 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[150]) }

func A_arbace_repr_clojure_A_clinit_p7() { A_arbace_repr_clojure_A_const_86 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[151]); A_arbace_repr_clojure_A_const_87 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[152]); A_arbace_repr_clojure_A_const_88 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[153]); A_arbace_repr_clojure_A_const_89 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[154]); A_arbace_repr_clojure_A_const_90 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[155]); A_arbace_repr_clojure_A_const_91 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[156]); A_arbace_repr_clojure_A_const_92 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[157]); A_arbace_repr_clojure_A_const_93 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[158]); A_arbace_repr_clojure_A_const_94 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[159]); A_arbace_repr_clojure_A_const_95 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[160]); A_arbace_repr_clojure_A_const_96 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[161]); A_arbace_repr_clojure_A_const_97 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[162]) }

func A_arbace_repr_clojure_A_clinit_p8() { A_arbace_repr_clojure_A_const_98 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[163]); A_arbace_repr_clojure_A_const_99 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[164]); A_arbace_repr_clojure_A_const_100 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[165]); A_arbace_repr_clojure_A_const_101 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[166]); A_arbace_repr_clojure_A_const_102 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[167]); A_arbace_repr_clojure_A_const_103 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[168]); A_arbace_repr_clojure_A_const_104 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[169]); A_arbace_repr_clojure_A_const_105 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[170]); A_arbace_repr_clojure_A_const_106 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[171]); A_arbace_repr_clojure_A_const_107 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[172]); A_arbace_repr_clojure_A_const_108 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[173]); A_arbace_repr_clojure_A_const_109 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[174]) }

func A_arbace_repr_clojure_A_clinit_p9() { A_arbace_repr_clojure_A_const_110 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[175]); A_arbace_repr_clojure_A_const_111 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[176]); A_arbace_repr_clojure_A_const_112 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[177]); A_arbace_repr_clojure_A_const_113 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[178]); A_arbace_repr_clojure_A_const_114 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[179]); A_arbace_repr_clojure_A_const_115 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[180]); A_arbace_repr_clojure_A_const_116 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[181]); A_arbace_repr_clojure_A_const_117 = A_arbace_repr_clojure_A_const_pool.A[182]; A_arbace_repr_clojure_A_const_118 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[183]); A_arbace_repr_clojure_A_const_119 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[184]); A_arbace_repr_clojure_A_const_120 = A_arbace_repr_clojure_A_const_pool.A[185]; A_arbace_repr_clojure_A_const_121 = A_arbace_repr_clojure_A_const_pool.A[186] }

func A_arbace_repr_clojure_A_clinit_p10() { A_arbace_repr_clojure_A_const_122 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[187]); A_arbace_repr_clojure_A_const_123 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[188]); A_arbace_repr_clojure_A_const_124 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[189]); A_arbace_repr_clojure_A_const_125 = A_arbace_repr_clojure_A_const_pool.A[190]; A_arbace_repr_clojure_A_const_126 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[191]); A_arbace_repr_clojure_A_const_127 = A_arbace_repr_clojure_A_const_pool.A[192]; A_arbace_repr_clojure_A_const_128 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[193]); A_arbace_repr_clojure_A_const_129 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[194]); A_arbace_repr_clojure_A_const_130 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[195]); A_arbace_repr_clojure_A_const_131 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[196]); A_arbace_repr_clojure_A_const_132 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[197]); A_arbace_repr_clojure_A_const_133 = A_arbace_repr_clojure_A_const_pool.A[198] }

func A_arbace_repr_clojure_A_clinit_p11() { A_arbace_repr_clojure_A_const_134 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[199]); A_arbace_repr_clojure_A_const_135 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[200]); A_arbace_repr_clojure_A_const_136 = A_arbace_repr_clojure_A_const_pool.A[201]; A_arbace_repr_clojure_A_const_137 = A_arbace_repr_clojure_A_const_pool.A[202]; A_arbace_repr_clojure_A_const_138 = A_arbace_repr_clojure_A_const_pool.A[203]; A_arbace_repr_clojure_A_const_139 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[204]); A_arbace_repr_clojure_A_const_140 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[205]); A_arbace_repr_clojure_A_const_141 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[206]); A_arbace_repr_clojure_A_const_142 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[207]); A_arbace_repr_clojure_A_const_143 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[208]); A_arbace_repr_clojure_A_const_144 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[209]); A_arbace_repr_clojure_A_const_145 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[210]) }

func A_arbace_repr_clojure_A_clinit_p12() { A_arbace_repr_clojure_A_const_146 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[211]); A_arbace_repr_clojure_A_const_147 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[212]); A_arbace_repr_clojure_A_const_148 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[213]); A_arbace_repr_clojure_A_const_149 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[214]); A_arbace_repr_clojure_A_const_150 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[215]); A_arbace_repr_clojure_A_const_151 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[216]); A_arbace_repr_clojure_A_const_152 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[217]); A_arbace_repr_clojure_A_const_153 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[218]); A_arbace_repr_clojure_A_const_154 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[219]); A_arbace_repr_clojure_A_const_155 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[220]); A_arbace_repr_clojure_A_const_156 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[221]); A_arbace_repr_clojure_A_const_157 = A_arbace_repr_clojure_A_const_pool.A[222] }

func A_arbace_repr_clojure_A_clinit_p13() { A_arbace_repr_clojure_A_const_158 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[223]); A_arbace_repr_clojure_A_const_159 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[224]); A_arbace_repr_clojure_A_const_160 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[225]); A_arbace_repr_clojure_A_const_161 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[226]); A_arbace_repr_clojure_A_const_162 = A_arbace_repr_clojure_A_const_pool.A[227]; A_arbace_repr_clojure_A_const_163 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[228]); A_arbace_repr_clojure_A_const_164 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[229]); A_arbace_repr_clojure_A_const_165 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[230]); A_arbace_repr_clojure_A_const_166 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[231]); A_arbace_repr_clojure_A_const_167 = A_arbace_repr_clojure_A_const_pool.A[232]; A_arbace_repr_clojure_A_const_168 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[233]); A_arbace_repr_clojure_A_const_169 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[234]) }

func A_arbace_repr_clojure_A_clinit_p14() { A_arbace_repr_clojure_A_const_170 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[235]); A_arbace_repr_clojure_A_const_171 = A_arbace_repr_clojure_A_const_pool.A[236]; A_arbace_repr_clojure_A_const_172 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[237]); A_arbace_repr_clojure_A_const_173 = A_arbace_repr_clojure_A_const_pool.A[238]; A_arbace_repr_clojure_A_const_174 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[239]); A_arbace_repr_clojure_A_const_175 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[240]); A_arbace_repr_clojure_A_const_176 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[241]); A_arbace_repr_clojure_A_const_177 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[242]); A_arbace_repr_clojure_A_const_178 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[243]); A_arbace_repr_clojure_A_const_179 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[244]); A_arbace_repr_clojure_A_const_180 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[245]); A_arbace_repr_clojure_A_const_181 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[246]) }

func A_arbace_repr_clojure_A_clinit_p15() { A_arbace_repr_clojure_A_const_182 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[247]); A_arbace_repr_clojure_A_const_183 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[248]); A_arbace_repr_clojure_A_const_184 = A_arbace_repr_clojure_A_const_pool.A[249]; A_arbace_repr_clojure_A_const_185 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[250]); A_arbace_repr_clojure_A_const_186 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[251]); A_arbace_repr_clojure_A_const_187 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[252]); A_arbace_repr_clojure_A_const_188 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[253]); A_arbace_repr_clojure_A_const_189 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[254]); A_arbace_repr_clojure_A_const_190 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[255]); A_arbace_repr_clojure_A_const_191 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[256]); A_arbace_repr_clojure_A_const_192 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[257]); A_arbace_repr_clojure_A_const_193 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[258]) }

func A_arbace_repr_clojure_A_clinit_p16() { A_arbace_repr_clojure_A_const_194 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[259]) }

func A_arbace_repr_clojure_A_New() *A_arbace_repr_clojure_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_A) Ctor() {}

func (t *A_arbace_repr_clojure_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_A_class }

func (t *A_arbace_repr_clojure_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_A); return ok }

func A_arbace_repr_clojure_A_Cast(x any) *A_arbace_repr_clojure_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_A_class)) }; return v }



type A_arbace_repr_clojure__main_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure__main_A_fn_class *jrt.Class



type A_arbace_repr_clojure__main_fn__716000316_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure__main_fn__716000316_A_fn_class *jrt.Class



type A_arbace_repr_clojure__main_fn__716000318_A struct{ j2g_header uint64; F_s, F_verb any }

var A_arbace_repr_clojure__main_fn__716000318_A_fn_class *jrt.Class



type A_arbace_repr_clojure_base_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_base_A_fn_class *jrt.Class



type A_arbace_repr_clojure_eval716000004_A struct{ jrt.Object }

func A_arbace_repr_clojure_eval716000004_A_New() *A_arbace_repr_clojure_eval716000004_A { t := &A_arbace_repr_clojure_eval716000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_eval716000004_A) Ctor() {}

func (t *A_arbace_repr_clojure_eval716000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_eval716000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_eval716000004_A_class }

func (t *A_arbace_repr_clojure_eval716000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_eval716000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_eval716000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_eval716000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_eval716000004_A); return ok }

func A_arbace_repr_clojure_eval716000004_A_Cast(x any) *A_arbace_repr_clojure_eval716000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_eval716000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_eval716000004_A_class)) }; return v }



type A_arbace_repr_clojure_eval716000004_loading__1927001464__auto____716000005_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_eval716000004_loading__1927001464__auto____716000005_A_fn_class *jrt.Class



type A_arbace_repr_clojure_eval716000008_A struct{ jrt.Object }

func A_arbace_repr_clojure_eval716000008_A_New() *A_arbace_repr_clojure_eval716000008_A { t := &A_arbace_repr_clojure_eval716000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_eval716000008_A) Ctor() {}

func (t *A_arbace_repr_clojure_eval716000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_eval716000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_eval716000008_A_class }

func (t *A_arbace_repr_clojure_eval716000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_eval716000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_eval716000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_eval716000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_eval716000008_A); return ok }

func A_arbace_repr_clojure_eval716000008_A_Cast(x any) *A_arbace_repr_clojure_eval716000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_eval716000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_eval716000008_A_class)) }; return v }



type A_arbace_repr_clojure_eval716000008_fn__716000009_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_eval716000008_fn__716000009_A_fn_class *jrt.Class



type A_arbace_repr_clojure_ext_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_ext_A_fn_class *jrt.Class



type A_arbace_repr_clojure_files_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_files_A_fn_class *jrt.Class



type A_arbace_repr_clojure_files_iter__716000033__716000037_A struct{ j2g_header uint64; F_root, F_src any }

var A_arbace_repr_clojure_files_iter__716000033__716000037_A_fn_class *jrt.Class



type A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_A struct{ j2g_header uint64; F_root, F_src, F_iter__716000033, F_s__716000034 any }

var A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_A_fn_class *jrt.Class



type A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_fn__716000039_A struct{ j2g_header uint64; F_root, F_src, F_b__716000036 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_fn__716000039_A_fn_class *jrt.Class



type A_arbace_repr_clojure_first_difference_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_first_difference_A_fn_class *jrt.Class



type A_arbace_repr_clojure_first_difference_fn__716000143_A struct{ j2g_header uint64; F_a, F_b any; F_n int64 }

var A_arbace_repr_clojure_first_difference_fn__716000143_A_fn_class *jrt.Class



type A_arbace_repr_clojure_first_difference_fn__716000145_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_first_difference_fn__716000145_A_fn_class *jrt.Class



type A_arbace_repr_clojure_first_difference_ln__716000147_A struct{ j2g_header uint64; F_i any }

var A_arbace_repr_clojure_first_difference_ln__716000147_A_fn_class *jrt.Class



type A_arbace_repr_clojure_fn__716000031_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_fn__716000031_A_fn_class *jrt.Class



type A_arbace_repr_clojure_half_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_half_A_fn_class *jrt.Class



type A_arbace_repr_clojure_half_fn__716000125_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_half_fn__716000125_A_fn_class *jrt.Class



type A_arbace_repr_clojure_half_fn__716000128_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_half_fn__716000128_A_fn_class *jrt.Class



type A_arbace_repr_clojure_half_fn__716000134_A struct{ j2g_header uint64; F_plan, F_refine, F_translate_text, F_opts, F_dirs any }

var A_arbace_repr_clojure_half_fn__716000134_A_fn_class *jrt.Class



type A_arbace_repr_clojure_half_fn__716000134_fn__716000138_A struct{ j2g_header uint64; F_p, F_s, F_rel, F_translate_text, F_opts any }

var A_arbace_repr_clojure_half_fn__716000134_fn__716000138_A_fn_class *jrt.Class



type A_arbace_repr_clojure_name_of_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_name_of_A_fn_class *jrt.Class



type A_arbace_repr_clojure_parent_of_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_parent_of_A_fn_class *jrt.Class



type A_arbace_repr_clojure_parse_args_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_parse_args_A_fn_class *jrt.Class



type A_arbace_repr_clojure_plan_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_plan_A_fn_class *jrt.Class



type A_arbace_repr_clojure_plan_fn__716000018_A struct{ j2g_header uint64; F_name any }

var A_arbace_repr_clojure_plan_fn__716000018_A_fn_class *jrt.Class



type A_arbace_repr_clojure_print_plan_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_print_plan_A_fn_class *jrt.Class



type A_arbace_repr_clojure_print_plan_fn__716000025_A struct{ j2g_header uint64; F_name any }

var A_arbace_repr_clojure_print_plan_fn__716000025_A_fn_class *jrt.Class



type A_arbace_repr_clojure_print_refine_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_print_refine_A_fn_class *jrt.Class



type A_arbace_repr_clojure_print_rules_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_print_rules_A_fn_class *jrt.Class



type A_arbace_repr_clojure_print_text_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_print_text_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_roundtrip_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_A struct{ j2g_header uint64; F_iter__716000153, F_s__716000154 any }

var A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_fn__716000159_A struct{ j2g_header uint64; F_b__716000156 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_fn__716000159_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_A struct{ j2g_header uint64; F_s__716000170, F_iter__716000169 any }

var A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_fn__716000175_A struct{ j2g_header uint64; F_b__716000172 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_fn__716000175_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_A struct{ j2g_header uint64; F_back2, F_t, F_a, F_b, F_c, F_back, F_opts any }

var A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_A struct{ j2g_header uint64; F_back2, F_iter__716000185, F_s__716000186, F_t, F_a, F_b, F_c, F_back, F_opts any }

var A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_fn__716000191_A struct{ j2g_header uint64; F_back2, F_t, F_b__716000188, F_a, F_b, F_c any; F_size__1927001038__auto__ int32; F_back, F_opts, F_c__1927001037__auto__ any }

var A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_fn__716000191_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_A struct{ j2g_header uint64; F_iter__716000201, F_s__716000202 any }

var A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_fn__716000207_A struct{ j2g_header uint64; F_b__716000204 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_fn__716000207_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_A struct{ j2g_header uint64; F_a any }

var A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_A struct{ j2g_header uint64; F_iter__716000217, F_s__716000218, F_a any }

var A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_fn__716000223_A struct{ j2g_header uint64; F_b__716000220, F_a any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_fn__716000223_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrips_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_roundtrips_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrips_fn__716000257_A struct{ j2g_header uint64; F_opts any }

var A_arbace_repr_clojure_roundtrips_fn__716000257_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_A struct{ j2g_header uint64; F_n any }

var A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_A struct{ j2g_header uint64; F_iter__716000258, F_n, F_s__716000259 any }

var A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_fn__716000264_A struct{ j2g_header uint64; F_n, F_b__716000261 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_fn__716000264_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_run_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000046_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_run_fn__716000046_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000063_A struct{ j2g_header uint64; F_f, F_p any }

var A_arbace_repr_clojure_run_fn__716000063_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000065_A struct{ j2g_header uint64; F_f, F_p, F_stats, F_s, F_translate_text, F_skip any }

var A_arbace_repr_clojure_run_fn__716000065_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000065_fn__716000066_A struct{ j2g_header uint64; F_e, F_f any }

var A_arbace_repr_clojure_run_fn__716000065_fn__716000066_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000072_A struct{ j2g_header uint64; F_f, F_p any }

var A_arbace_repr_clojure_run_fn__716000072_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000074_A struct{ j2g_header uint64; F_f, F_p, F_s, F_stats, F_translate_text, F_skip any }

var A_arbace_repr_clojure_run_fn__716000074_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000074_fn__716000075_A struct{ j2g_header uint64; F_e, F_f any }

var A_arbace_repr_clojure_run_fn__716000074_fn__716000075_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000081_A struct{ j2g_header uint64; F_f, F_p any }

var A_arbace_repr_clojure_run_fn__716000081_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000083_A struct{ j2g_header uint64; F_f, F_p, F_s, F_stats, F_translate_text, F_skip any }

var A_arbace_repr_clojure_run_fn__716000083_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000083_fn__716000084_A struct{ j2g_header uint64; F_e, F_f any }

var A_arbace_repr_clojure_run_fn__716000083_fn__716000084_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000090_A struct{ j2g_header uint64; F_f, F_p any }

var A_arbace_repr_clojure_run_fn__716000090_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000092_A struct{ j2g_header uint64; F_f, F_p, F_s, F_stats, F_translate_text, F_skip any }

var A_arbace_repr_clojure_run_fn__716000092_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000092_fn__716000093_A struct{ j2g_header uint64; F_e, F_f any }

var A_arbace_repr_clojure_run_fn__716000092_fn__716000093_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_roundtrip_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_run_roundtrip_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_roundtrip_fn__716000280_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_run_roundtrip_fn__716000280_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_roundtrip_fn__716000282_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_run_roundtrip_fn__716000282_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_roundtrip_fn__716000284_A struct{ j2g_header uint64; F_known any }

var A_arbace_repr_clojure_run_roundtrip_fn__716000284_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_roundtrip_fn__716000286_A struct{ j2g_header uint64; F_diff any }

var A_arbace_repr_clojure_run_roundtrip_fn__716000286_A_fn_class *jrt.Class



type A_arbace_repr_clojure_translate_text_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_translate_text_A_fn_class *jrt.Class



type A_arbace_repr_clojure_tree_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_tree_A_fn_class *jrt.Class



type A_arbace_repr_clojure_tree_iter__716000097__716000103_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_tree_iter__716000097__716000103_A_fn_class *jrt.Class



type A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_A struct{ j2g_header uint64; F_iter__716000097, F_s__716000098 any }

var A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_A_fn_class *jrt.Class



type A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_A_fn_class *jrt.Class



type A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_A struct{ j2g_header uint64; F_iter__716000099, F_s__716000100 any }

var A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_A_fn_class *jrt.Class



type A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_fn__716000107_A struct{ j2g_header uint64; F_b__716000102 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_fn__716000107_A_fn_class *jrt.Class



type A_arbace_repr_clojure_under_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_under_A_fn_class *jrt.Class



type A_arbace_repr_clojure_usage_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_usage_A_fn_class *jrt.Class



type A_arbace_repr_clojure_usage_fn__716000254_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_usage_fn__716000254_A_fn_class *jrt.Class
