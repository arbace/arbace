//line aot_arbace_repr_clojure.ae:1
package aot_arbace_repr_clojure

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_java_io"
	"arbace/aot_arbace_repr_clojure_rules"
	"arbace/aot_arbace_repr_clojure_text"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_clojure_eval716000004_loading__1927001464__auto____716000005_A_New() *A_arbace_repr_clojure_eval716000004_loading__1927001464__auto____716000005_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_eval716000004_loading__1927001464__auto____716000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_clojure_eval716000004_loading__1927001464__auto____716000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_clojure_eval716000004_loading__1927001464__auto____716000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_clojure_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_A_const_1); lang.IFn_Cast(A_arbace_repr_clojure_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_repr_clojure_A_const_3, A_arbace_repr_clojure_A_const_4, A_arbace_repr_clojure_A_const_5, A_arbace_repr_clojure_A_const_6); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_13)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_repr_clojure_eval716000008_fn__716000009_A_New() *A_arbace_repr_clojure_eval716000008_fn__716000009_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_eval716000008_fn__716000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_clojure_eval716000008_fn__716000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_clojure_eval716000008_fn__716000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_7.GetRawRoot__O()); var tmp2 any; var root_12 any = A_arbace_repr_clojure_A_const_8.GetRawRoot__O(); var linked_13 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_12, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_14 lang.IFn; if linked_13 == nil { ifn_14 = lang.IFn_Cast(root_12) } else { ifn_14 = nil }; var arg_15 any = A_arbace_repr_clojure_A_const_9; if linked_13 == nil { tmp2 = ifn_14.Invoke_O__O(arg_15) } else { tmp2 = linked_13.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_12, arg_15) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_repr_clojure_A_const_10.GetRawRoot__O(), A_arbace_repr_clojure_A_const_11) }





















































func A_arbace_repr_clojure_ext_A_New() *A_arbace_repr_clojure_ext_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_ext_A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_repr_clojure_ext_A) Ctor() {}
//line :55:1
func (t *A_arbace_repr_clojure_ext_A) Invoke_O_O__O(self, name__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(name__0)).LastIndexOf_String__I(Lit_12); if
										lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return Lit_14 } else { var root_22 any = A_arbace_repr_clojure_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = name__0; var arg_26 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref(); if linked_23 == nil { return ifn_24.Invoke_O_O__O(arg_25, arg_26) } else { return linked_23.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_22, arg_25, arg_26) } } }

func A_arbace_repr_clojure_base_A_New() *A_arbace_repr_clojure_base_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_base_A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_repr_clojure_base_A) Ctor() {}
//line :58:1
func (t *A_arbace_repr_clojure_base_A) Invoke_O_O__O(self, name__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(name__0)).LastIndexOf_String__I(Lit_12); if
										lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return name__0 } else { var root_27 any = A_arbace_repr_clojure_A_const_12.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = name__0; var arg_31 any = A_arbace_repr_clojure_A_const_13; var arg_32 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref(); if linked_28 == nil { return ifn_29.Invoke_O_O_O__O(arg_30, arg_31, arg_32) } else { return linked_28.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_27, arg_30, arg_31, arg_32) } } }

func A_arbace_repr_clojure_plan_A_New() *A_arbace_repr_clojure_plan_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_plan_A{}; t.Ctor(); return t }
//line :61:1
func (t *A_arbace_repr_clojure_plan_A) Ctor() {}
//line :61:1
func (t *A_arbace_repr_clojure_plan_A) Invoke_O_O_O_O__O(self, name__0, siblings__1, p__716000015__2 any) any { var map__716000016__4 any = p__716000015__2; var map__716000016__5 any; if lang.ISeq_InstanceOf(map__716000016__4) { var tmp1 any; var root_33 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_34 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_33, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_35 lang.IFn; if linked_34 == nil { ifn_35 = lang.IFn_Cast(root_33) } else { ifn_35 = nil }; var arg_36 any = map__716000016__4; if linked_34 == nil { tmp1 = ifn_35.Invoke_O__O(arg_36) } else { tmp1 = linked_34.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_33, arg_36) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_37 any = A_arbace_repr_clojure_A_const_15.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_37, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_39 lang.IFn; if linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any = map__716000016__4; if linked_38 == nil { tmp2 = ifn_39.Invoke_O__O(arg_40) } else { tmp2 = linked_38.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_37, arg_40) }; map__716000016__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_41 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = map__716000016__4; if linked_42 == nil { tmp3 = ifn_43.Invoke_O__O(arg_44) } else { tmp3 = linked_42.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_41, arg_44) }; if jrt.J2g_Truth(tmp3) { var root_45 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any = map__716000016__4; if linked_46 == nil { map__716000016__5 = ifn_47.Invoke_O__O(arg_48) } else { map__716000016__5 = linked_46.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_45, arg_48) } } else { map__716000016__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__716000016__5 = map__716000016__4 }; var keep_ext__6 any = lang.RT_Get_O_O__O_NoInit(map__716000016__5, A_arbace_repr_clojure_A_const_18); var text__7 any = lang.RT_Get_O_O__O_NoInit(map__716000016__5, A_arbace_repr_clojure_A_const_19); var e__8 any; var root_49 any = A_arbace_repr_clojure_A_const_20.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, A_arbace_repr_clojure_ext_A_fn_class); var ifn_51 lang.IFn; if




	linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = name__0; if linked_50 == nil { e__8 = ifn_51.Invoke_O__O(arg_52) } else { e__8 = linked_50.(*A_arbace_repr_clojure_ext_A).Invoke_O_O__O(root_49, arg_52) }; var tmp4 any; var root_53 any =
	A_arbace_repr_clojure_A_const_21.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_55 lang.IFn; if
	linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = A_arbace_repr_clojure_A_const_22.GetRawRoot__O(); var arg_57 any = name__0; if linked_54 == nil { tmp4 = ifn_55.Invoke_O_O__O(arg_56, arg_57) } else { tmp4 = linked_54.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_53, arg_56, arg_57) }; if /*line :67:1*/ jrt.J2g_Truth(tmp4) { var tmp5 any = A_arbace_repr_clojure_A_const_23; var tmp6 *lang.Keyword
		if lang.Util_Equiv_O_O__Z_NoInit(e__8, Lit_46) { tmp6 = A_arbace_repr_clojure_A_const_24 } else { tmp6 = A_arbace_repr_clojure_A_const_25 }
//line :67:1
		return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6.Ref(), A_arbace_repr_clojure_A_const_26, jrt.Boolean_FALSE.Ref(), A_arbace_repr_clojure_A_const_27, name__0)) } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_A_const_28).Invoke_O__O(e__8)) {


			if jrt.J2g_Truth(keep_ext__6) { var tmp7 any = A_arbace_repr_clojure_A_const_23; var tmp8 any; var root_63 any = A_arbace_repr_clojure_A_const_29.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_63, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_65 lang.IFn
				if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any; var root_58 any = A_arbace_repr_clojure_A_const_12.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_58, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_60 lang.IFn; if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = e__8; var arg_62 any = A_arbace_repr_clojure_A_const_30; if linked_59 == nil { arg_66 = ifn_60.Invoke_O_O__O(arg_61, arg_62) } else { arg_66 = linked_59.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_58, arg_61, arg_62) }; if linked_64 == nil { tmp8 = ifn_65.Invoke_O__O(arg_66) } else { tmp8 = linked_64.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_63, arg_66) }
//line :70:1
				return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8, A_arbace_repr_clojure_A_const_26, jrt.Boolean_FALSE.Ref(), A_arbace_repr_clojure_A_const_27, name__0)) } else { var tmp9 any; var root_67 any = A_arbace_repr_clojure_A_const_31.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, A_arbace_repr_clojure_base_A_fn_class); var ifn_69 lang.IFn



					if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any = name__0; if linked_68 == nil { tmp9 = ifn_69.Invoke_O__O(arg_70) } else { tmp9 = linked_68.(*A_arbace_repr_clojure_base_A).Invoke_O_O__O(root_67, arg_70) }
//line :70:1
					if lang.Util_Equiv_O_O__Z_NoInit(Lit_47, tmp9) {




						var tmp10 any; var or__1927000174__auto____9 any; var root_71 any = A_arbace_repr_clojure_A_const_21.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_73 lang.IFn; if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = siblings__1; var arg_75 any = Lit_48; if linked_72 == nil { or__1927000174__auto____9 = ifn_73.Invoke_O_O__O(arg_74, arg_75) } else { or__1927000174__auto____9 = linked_72.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_71, arg_74, arg_75) }; if jrt.J2g_Truth(or__1927000174__auto____9) { tmp10 = or__1927000174__auto____9 } else { var and__1927000168__auto____10 bool = lang.Util_Equiv_O_O__Z_NoInit(e__8, Lit_46)
							if and__1927000168__auto____10 { var root_76 any = A_arbace_repr_clojure_A_const_21.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var arg_79 any = siblings__1; var arg_80 any = Lit_49; if linked_77 == nil { tmp10 = ifn_78.Invoke_O_O__O(arg_79, arg_80) } else { tmp10 = linked_77.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_76, arg_79, arg_80) } } else { tmp10 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10).Ref() } }
//line :75:1
						if jrt.J2g_Truth(tmp10) { var tmp11 any = A_arbace_repr_clojure_A_const_23; var tmp12 any; var root_86 any = A_arbace_repr_clojure_A_const_29.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_88 lang.IFn

							if linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any; var root_81 any = A_arbace_repr_clojure_A_const_12.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = e__8; var arg_85 any = A_arbace_repr_clojure_A_const_30; if linked_82 == nil { arg_89 = ifn_83.Invoke_O_O__O(arg_84, arg_85) } else { arg_89 = linked_82.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_81, arg_84, arg_85) }; if linked_87 == nil { tmp12 = ifn_88.Invoke_O__O(arg_89) } else { tmp12 = linked_87.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_86, arg_89) }
//line :75:1
							return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp11, tmp12, A_arbace_repr_clojure_A_const_26, jrt.Boolean_FALSE.Ref(), A_arbace_repr_clojure_A_const_27, name__0)) } else { var tmp13 any = A_arbace_repr_clojure_A_const_23; var tmp14 any; var root_95 any = A_arbace_repr_clojure_A_const_29.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_97 lang.IFn


								if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any; var root_90 any = A_arbace_repr_clojure_A_const_12.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_92 lang.IFn; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = e__8; var arg_94 any = A_arbace_repr_clojure_A_const_30; if linked_91 == nil { arg_98 = ifn_92.Invoke_O_O__O(arg_93, arg_94) } else { arg_98 = linked_91.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_90, arg_93, arg_94) }; if linked_96 == nil { tmp14 = ifn_97.Invoke_O__O(arg_98) } else { tmp14 = linked_96.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_95, arg_98) }
//line :75:1
								return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp14, A_arbace_repr_clojure_A_const_26, jrt.Boolean_TRUE.Ref(), A_arbace_repr_clojure_A_const_27, Lit_48)) } } else {
//line :70:1
									var tmp15 any; var root_103 any = A_arbace_repr_clojure_A_const_21.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_103, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_105 lang.IFn








									if linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any = siblings__1; var arg_107 any; var tmp16 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_50); var tmp17 any; var root_99 any = A_arbace_repr_clojure_A_const_31.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_99, A_arbace_repr_clojure_base_A_fn_class); var ifn_101 lang.IFn; if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any = name__0; if linked_100 == nil { tmp17 = ifn_101.Invoke_O__O(arg_102) } else { tmp17 = linked_100.(*A_arbace_repr_clojure_base_A).Invoke_O_O__O(root_99, arg_102) }; arg_107 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp16, jrt.RefArrayOf(jrt.Object_class, tmp17, nil)).Ref(); if linked_104 == nil { tmp15 = ifn_105.Invoke_O_O__O(arg_106, arg_107) } else { tmp15 = linked_104.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_103, arg_106, arg_107) }
//line :70:1
									if jrt.J2g_Truth(tmp15) { var tmp18 any = A_arbace_repr_clojure_A_const_32; var tmp19 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_51); var tmp20 any; var root_108 any = A_arbace_repr_clojure_A_const_31.GetRawRoot__O(); var linked_109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_108, A_arbace_repr_clojure_base_A_fn_class); var ifn_110 lang.IFn









										if linked_109 == nil { ifn_110 = lang.IFn_Cast(root_108) } else { ifn_110 = nil }; var arg_111 any = name__0; if linked_109 == nil { tmp20 = ifn_110.Invoke_O__O(arg_111) } else { tmp20 = linked_109.(*A_arbace_repr_clojure_base_A).Invoke_O_O__O(root_108, arg_111) }
//line :70:1
										return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp18, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp19, jrt.RefArrayOf(jrt.Object_class, tmp20, nil)).Ref())) } else { var tmp21 any; var and__1927000168__auto____9 bool = lang.Util_Equiv_O_O__Z_NoInit(e__8, Lit_46)










											if and__1927000168__auto____9 { var root_116 any = A_arbace_repr_clojure_A_const_21.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_116, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_118 lang.IFn; if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any = siblings__1; var arg_120 any; var tmp22 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_52); var tmp23 any; var root_112 any = A_arbace_repr_clojure_A_const_31.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, A_arbace_repr_clojure_base_A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = name__0; if linked_113 == nil { tmp23 = ifn_114.Invoke_O__O(arg_115) } else { tmp23 = linked_113.(*A_arbace_repr_clojure_base_A).Invoke_O_O__O(root_112, arg_115) }; arg_120 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp22, jrt.RefArrayOf(jrt.Object_class, tmp23, nil)).Ref(); if linked_117 == nil { tmp21 = ifn_118.Invoke_O_O__O(arg_119, arg_120) } else { tmp21 = linked_117.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_116, arg_119, arg_120) } } else { tmp21 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____9).Ref() }
//line :70:1
											if jrt.J2g_Truth(tmp21) { var tmp24 any = A_arbace_repr_clojure_A_const_32; var tmp25 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_53); var tmp26 any; var root_121 any = A_arbace_repr_clojure_A_const_31.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, A_arbace_repr_clojure_base_A_fn_class); var ifn_123 lang.IFn











												if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = name__0; if linked_122 == nil { tmp26 = ifn_123.Invoke_O__O(arg_124) } else { tmp26 = linked_122.(*A_arbace_repr_clojure_base_A).Invoke_O_O__O(root_121, arg_124) }
//line :70:1
												return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp24, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp25, jrt.RefArrayOf(jrt.Object_class, tmp26, nil)).Ref())) } else { if A_arbace_repr_clojure_A_const_33 != nil { var tmp27 any = A_arbace_repr_clojure_A_const_23; var tmp28 any; var root_130 any = A_arbace_repr_clojure_A_const_29.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_132 lang.IFn












													if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any; var root_125 any = A_arbace_repr_clojure_A_const_12.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_125, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_127 lang.IFn; if linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; var arg_128 any = e__8; var arg_129 any = A_arbace_repr_clojure_A_const_30; if linked_126 == nil { arg_133 = ifn_127.Invoke_O_O__O(arg_128, arg_129) } else { arg_133 = linked_126.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_125, arg_128, arg_129) }; if linked_131 == nil { tmp28 = ifn_132.Invoke_O__O(arg_133) } else { tmp28 = linked_131.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_130, arg_133) }
//line :70:1
													var tmp29 any = tmp28; var tmp30 any = A_arbace_repr_clojure_A_const_26; var tmp31 any = jrt.Boolean_TRUE.Ref(); var tmp32 any = A_arbace_repr_clojure_A_const_27; var tmp33 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_50); var tmp34 any; var root_134 any = A_arbace_repr_clojure_A_const_31.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, A_arbace_repr_clojure_base_A_fn_class); var ifn_136 lang.IFn












													if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any = name__0; if linked_135 == nil { tmp34 = ifn_136.Invoke_O__O(arg_137) } else { tmp34 = linked_135.(*A_arbace_repr_clojure_base_A).Invoke_O_O__O(root_134, arg_137) }
//line :70:1
													return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp27, tmp29, tmp30, tmp31, tmp32, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp33, jrt.RefArrayOf(jrt.Object_class, tmp34, nil)).Ref())) } else { return nil } } } } } } else {
//line :67:1
														if lang.Util_Equiv_O_O__Z_NoInit(e__8, Lit_54) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_23, A_arbace_repr_clojure_A_const_34, A_arbace_repr_clojure_A_const_26, jrt.Boolean_FALSE.Ref(), A_arbace_repr_clojure_A_const_27, name__0)) } else { var tmp35 any; var root_144 any = A_arbace_repr_clojure_A_const_35.GetRawRoot__O(); var linked_145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_144, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_146 lang.IFn

















															if linked_145 == nil { ifn_146 = lang.IFn_Cast(root_144) } else { ifn_146 = nil }; var arg_147 any; var tmp36 any = A_arbace_repr_clojure_plan_fn__716000018_A_New_O(name__0); var tmp37 *jrt.Class; var fncls__143 *jrt.Class = A_arbace_repr_clojure_plan_fn__716000018_A_fn_class; if fncls__143 == nil { var fncls__143d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_repr_clojure_plan_fn__716000018_A_fn_class = fncls__143d; tmp37 = fncls__143d } else { tmp37 = fncls__143 }; arg_147 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp36, tmp37, nil); var arg_148 any = text__7; if linked_145 == nil { tmp35 = ifn_146.Invoke_O_O__O(arg_147, arg_148) } else { tmp35 = linked_145.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_144, arg_147, arg_148) }
//line :67:1
															if jrt.J2g_Truth(tmp35) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_23, A_arbace_repr_clojure_A_const_19, A_arbace_repr_clojure_A_const_26, jrt.Boolean_FALSE.Ref(), A_arbace_repr_clojure_A_const_27, name__0)) } else { if lang.Util_Equiv_O_O__Z_NoInit(e__8, Lit_56) { return A_arbace_repr_clojure_A_const_37 } else { if A_arbace_repr_clojure_A_const_33 != nil { return A_arbace_repr_clojure_A_const_38 } else { return nil } } } } } } }

















func A_arbace_repr_clojure_plan_fn__716000018_A_New_O(p0 any) *A_arbace_repr_clojure_plan_fn__716000018_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_plan_fn__716000018_A{}; t.Ctor_O(p0); return t }
//line :85:1
func (t *A_arbace_repr_clojure_plan_fn__716000018_A) Ctor_O(c__name any) { t.F_name = c__name }
//line :85:1
func (t *A_arbace_repr_clojure_plan_fn__716000018_A) Invoke_O_O__O(self, p1__716000014_SHARP___1 any) any { var root_138 any = A_arbace_repr_clojure_A_const_36.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_140 lang.IFn; if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = t.F_name; var arg_142 any = p1__716000014_SHARP___1; if linked_139 == nil { return ifn_140.Invoke_O_O__O(arg_141, arg_142) } else { return linked_139.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_138, arg_141, arg_142) } }



func A_arbace_repr_clojure_print_plan_A_New() *A_arbace_repr_clojure_print_plan_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_print_plan_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_repr_clojure_print_plan_A) Ctor() {}
//line :89:1
func (t *A_arbace_repr_clojure_print_plan_A) Invoke_O_O_O_O__O(self, name__0, siblings__1, p__716000022__2 any) any { var map__716000023__4 any = p__716000022__2; var map__716000023__5 any; if lang.ISeq_InstanceOf(map__716000023__4) { var tmp1 any; var root_149 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_149, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_151 lang.IFn; if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any = map__716000023__4; if linked_150 == nil { tmp1 = ifn_151.Invoke_O__O(arg_152) } else { tmp1 = linked_150.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_149, arg_152) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_153 any = A_arbace_repr_clojure_A_const_15.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_153, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_155 lang.IFn; if linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any = map__716000023__4; if linked_154 == nil { tmp2 = ifn_155.Invoke_O__O(arg_156) } else { tmp2 = linked_154.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_153, arg_156) }; map__716000023__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_157 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_157, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_159 lang.IFn; if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any = map__716000023__4; if linked_158 == nil { tmp3 = ifn_159.Invoke_O__O(arg_160) } else { tmp3 = linked_158.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_157, arg_160) }; if jrt.J2g_Truth(tmp3) { var root_161 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_161, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_163 lang.IFn; if linked_162 == nil { ifn_163 = lang.IFn_Cast(root_161) } else { ifn_163 = nil }; var arg_164 any = map__716000023__4; if linked_162 == nil { map__716000023__5 = ifn_163.Invoke_O__O(arg_164) } else { map__716000023__5 = linked_162.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_161, arg_164) } } else { map__716000023__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__716000023__5 = map__716000023__4 }; var text__6 any = lang.RT_Get_O_O__O_NoInit(map__716000023__5, A_arbace_repr_clojure_A_const_19); var e__7 any; var root_165 any = A_arbace_repr_clojure_A_const_20.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, A_arbace_repr_clojure_ext_A_fn_class); var ifn_167 lang.IFn; if









	linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = name__0; if linked_166 == nil { e__7 = ifn_167.Invoke_O__O(arg_168) } else { e__7 = linked_166.(*A_arbace_repr_clojure_ext_A).Invoke_O_O__O(root_165, arg_168) }; var b__8 any; var root_169 any = /*line :89:1*/A_arbace_repr_clojure_A_const_31.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, A_arbace_repr_clojure_base_A_fn_class); var ifn_171 lang.IFn; if









	linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = name__0; if linked_170 == nil { b__8 = ifn_171.Invoke_O__O(arg_172) } else { b__8 = linked_170.(*A_arbace_repr_clojure_base_A).Invoke_O_O__O(root_169, arg_172) }; var tmp4 any; var root_173 any =
	A_arbace_repr_clojure_A_const_21.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_175 lang.IFn; if
	linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any = A_arbace_repr_clojure_A_const_22.GetRawRoot__O(); var arg_177 any = name__0; if linked_174 == nil { tmp4 = ifn_175.Invoke_O_O__O(arg_176, arg_177) } else { tmp4 = linked_174.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_173, arg_176, arg_177) }; if /*line :100:1*/ jrt.J2g_Truth(tmp4) { var tmp5 any = A_arbace_repr_clojure_A_const_23; var tmp6 *lang.Keyword
		if lang.Util_Equiv_O_O__Z_NoInit(e__7, Lit_46) { tmp6 = A_arbace_repr_clojure_A_const_24 } else { tmp6 = A_arbace_repr_clojure_A_const_25 }
//line :100:1
		return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6.Ref(), A_arbace_repr_clojure_A_const_26, jrt.Boolean_FALSE.Ref(), A_arbace_repr_clojure_A_const_27, name__0)) } else { if lang.Util_Equiv_O_O__Z_NoInit(e__7, Lit_50) {


			if lang.Util_Equiv_O_O__Z_NoInit(Lit_47, b__8) {
				var tmp7 any; var root_183 any = A_arbace_repr_clojure_A_const_39.GetRawRoot__O(); var linked_184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_183, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_185 lang.IFn; if linked_184 == nil { ifn_185 = lang.IFn_Cast(root_183) } else { ifn_185 = nil }; var arg_186 any; var root_178 any = A_arbace_repr_clojure_A_const_21.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_180 lang.IFn; if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any = siblings__1; var arg_182 any = Lit_49; if linked_179 == nil { arg_186 = ifn_180.Invoke_O_O__O(arg_181, arg_182) } else { arg_186 = linked_179.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_178, arg_181, arg_182) }; if linked_184 == nil { tmp7 = ifn_185.Invoke_O__O(arg_186) } else { tmp7 = linked_184.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_183, arg_186) }; if jrt.J2g_Truth(tmp7) { return A_arbace_repr_clojure_A_const_40 } else { var tmp8 any; var root_192 any = A_arbace_repr_clojure_A_const_39.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_194 lang.IFn

					if linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any; var root_187 any = A_arbace_repr_clojure_A_const_21.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_187, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_189 lang.IFn; if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var arg_190 any = siblings__1; var arg_191 any = Lit_57; if linked_188 == nil { arg_195 = ifn_189.Invoke_O_O__O(arg_190, arg_191) } else { arg_195 = linked_188.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_187, arg_190, arg_191) }; if linked_193 == nil { tmp8 = ifn_194.Invoke_O__O(arg_195) } else { tmp8 = linked_193.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_192, arg_195) }
//line :104:1
					if jrt.J2g_Truth(tmp8) { return A_arbace_repr_clojure_A_const_41 } else { if A_arbace_repr_clojure_A_const_33 != nil { return A_arbace_repr_clojure_A_const_42 } else { return nil } } } } else {
//line :103:1
						var tmp9 any = A_arbace_repr_clojure_A_const_23; var tmp10 any = A_arbace_repr_clojure_A_const_25; var tmp11 any = A_arbace_repr_clojure_A_const_26; var tmp12 any = jrt.Boolean_TRUE.Ref(); var tmp13 any = A_arbace_repr_clojure_A_const_27; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, tmp11, tmp12, tmp13, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_52), jrt.RefArrayOf(jrt.Object_class, b__8, nil)).Ref())) } } else {
//line :100:1
							if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_A_const_43).Invoke_O__O(e__7)) {










								var tmp14 any; var and__1927000168__auto____9 any; var root_196 any = A_arbace_repr_clojure_A_const_21.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_198 lang.IFn; if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any = siblings__1; var arg_200 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_50), jrt.RefArrayOf(jrt.Object_class, b__8, nil)).Ref(); if linked_197 == nil { and__1927000168__auto____9 = ifn_198.Invoke_O_O__O(arg_199, arg_200) } else { and__1927000168__auto____9 = linked_197.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_196, arg_199, arg_200) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var root_201 any = A_arbace_repr_clojure_A_const_44.GetRawRoot__O(); var linked_202 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_201, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_203 lang.IFn; if linked_202 == nil { ifn_203 = lang.IFn_Cast(root_201) } else { ifn_203 = nil }; var arg_204 any = Lit_47; var arg_205 any = b__8; if linked_202 == nil { tmp14 = ifn_203.Invoke_O_O__O(arg_204, arg_205) } else { tmp14 = linked_202.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_201, arg_204, arg_205) } } else { tmp14 = and__1927000168__auto____9 }; if jrt.J2g_Truth(tmp14) { var tmp15 any = A_arbace_repr_clojure_A_const_32; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp15, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_58), jrt.RefArrayOf(jrt.Object_class, b__8, nil)).Ref())) } else { var tmp16 any = A_arbace_repr_clojure_A_const_23; var tmp17 any; var root_211 any = A_arbace_repr_clojure_A_const_29.GetRawRoot__O(); var linked_212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_211, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_213 lang.IFn

									if linked_212 == nil { ifn_213 = lang.IFn_Cast(root_211) } else { ifn_213 = nil }; var arg_214 any; var root_206 any = A_arbace_repr_clojure_A_const_12.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_208 lang.IFn; if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any = e__7; var arg_210 any = A_arbace_repr_clojure_A_const_30; if linked_207 == nil { arg_214 = ifn_208.Invoke_O_O__O(arg_209, arg_210) } else { arg_214 = linked_207.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_206, arg_209, arg_210) }; if linked_212 == nil { tmp17 = ifn_213.Invoke_O__O(arg_214) } else { tmp17 = linked_212.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_211, arg_214) }
//line :111:1
									return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp17, A_arbace_repr_clojure_A_const_26, jrt.Boolean_FALSE.Ref(), A_arbace_repr_clojure_A_const_27, name__0)) } } else {
//line :100:1
										if lang.Util_Equiv_O_O__Z_NoInit(e__7, Lit_54) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_23, A_arbace_repr_clojure_A_const_34, A_arbace_repr_clojure_A_const_26, jrt.Boolean_FALSE.Ref(), A_arbace_repr_clojure_A_const_27, name__0)) } else { var tmp18 any; var root_221 any = A_arbace_repr_clojure_A_const_35.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_223 lang.IFn














											if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any; var tmp19 any = A_arbace_repr_clojure_print_plan_fn__716000025_A_New_O(name__0); var tmp20 *jrt.Class; var fncls__220 *jrt.Class = A_arbace_repr_clojure_print_plan_fn__716000025_A_fn_class; if fncls__220 == nil { var fncls__220d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_repr_clojure_print_plan_fn__716000025_A_fn_class = fncls__220d; tmp20 = fncls__220d } else { tmp20 = fncls__220 }; arg_224 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil); var arg_225 any = text__6; if linked_222 == nil { tmp18 = ifn_223.Invoke_O_O__O(arg_224, arg_225) } else { tmp18 = linked_222.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_221, arg_224, arg_225) }
//line :100:1
											if jrt.J2g_Truth(tmp18) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_23, A_arbace_repr_clojure_A_const_19, A_arbace_repr_clojure_A_const_26, jrt.Boolean_FALSE.Ref(), A_arbace_repr_clojure_A_const_27, name__0)) } else { if lang.Util_Equiv_O_O__Z_NoInit(e__7, Lit_56) { return A_arbace_repr_clojure_A_const_45 } else { if A_arbace_repr_clojure_A_const_33 != nil { return A_arbace_repr_clojure_A_const_46 } else { return nil } } } } } } } }














func A_arbace_repr_clojure_print_plan_fn__716000025_A_New_O(p0 any) *A_arbace_repr_clojure_print_plan_fn__716000025_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_print_plan_fn__716000025_A{}; t.Ctor_O(p0); return t }
//line :115:1
func (t *A_arbace_repr_clojure_print_plan_fn__716000025_A) Ctor_O(c__name any) { t.F_name = c__name }
//line :115:1
func (t *A_arbace_repr_clojure_print_plan_fn__716000025_A) Invoke_O_O__O(self, p1__716000021_SHARP___1 any) any { var root_215 any = A_arbace_repr_clojure_A_const_36.GetRawRoot__O(); var linked_216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_215, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_217 lang.IFn; if linked_216 == nil { ifn_217 = lang.IFn_Cast(root_215) } else { ifn_217 = nil }; var arg_218 any = t.F_name; var arg_219 any = p1__716000021_SHARP___1; if linked_216 == nil { return ifn_217.Invoke_O_O__O(arg_218, arg_219) } else { return linked_216.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_215, arg_218, arg_219) } }



func A_arbace_repr_clojure_translate_text_A_New() *A_arbace_repr_clojure_translate_text_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_translate_text_A{}; t.Ctor(); return t }
//line :119:1
func (t *A_arbace_repr_clojure_translate_text_A) Ctor() {}
//line :119:1
func (t *A_arbace_repr_clojure_translate_text_A) Invoke_O_O_O_O_O__O(self, s__0, p__1, path__2, skip__3 any) any {


	var root_226 any = A_arbace_repr_clojure_A_const_47.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_226, aot_arbace_repr_clojure_rules.A_arbace_repr_clojure_rules_translate_A_fn_class); var ifn_228 lang.IFn; if linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var arg_229 any = s__0; var tmp1 any = A_arbace_repr_clojure_A_const_23; var tmp2 any = A_arbace_repr_clojure_A_const_23.Invoke_O__O(p__1); var tmp3 any = A_arbace_repr_clojure_A_const_26; var arg_230 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, A_arbace_repr_clojure_A_const_26.Invoke_O__O(p__1), A_arbace_repr_clojure_A_const_48, A_arbace_repr_clojure_A_const_49, A_arbace_repr_clojure_A_const_50, path__2)); var arg_231 any = skip__3; if linked_227 == nil { return ifn_228.Invoke_O_O_O__O(arg_229, arg_230, arg_231) } else { return linked_227.(*aot_arbace_repr_clojure_rules.A_arbace_repr_clojure_rules_translate_A).Invoke_O_O_O_O__O(root_226, arg_229, arg_230, arg_231)
	} }
func A_arbace_repr_clojure_print_text_A_New() *A_arbace_repr_clojure_print_text_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_print_text_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_repr_clojure_print_text_A) Ctor() {}
//line :124:1
func (t *A_arbace_repr_clojure_print_text_A) Invoke_O_O_O_O_O__O(self, s__0, p__1, path__2, skip__3 any) any {


	var root_232 any = A_arbace_repr_clojure_A_const_51.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, aot_arbace_repr_clojure_rules.A_arbace_repr_clojure_rules_print_text_A_fn_class); var ifn_234 lang.IFn; if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = s__0; var tmp1 any = A_arbace_repr_clojure_A_const_23; var tmp2 any = A_arbace_repr_clojure_A_const_23.Invoke_O__O(p__1); var tmp3 any = A_arbace_repr_clojure_A_const_26; var arg_236 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, A_arbace_repr_clojure_A_const_26.Invoke_O__O(p__1), A_arbace_repr_clojure_A_const_48, A_arbace_repr_clojure_A_const_52, A_arbace_repr_clojure_A_const_50, path__2)); var arg_237 any = skip__3; if linked_233 == nil { return ifn_234.Invoke_O_O_O__O(arg_235, arg_236, arg_237) } else { return linked_233.(*aot_arbace_repr_clojure_rules.A_arbace_repr_clojure_rules_print_text_A).Invoke_O_O_O_O__O(root_232, arg_235, arg_236, arg_237)
	}
}



func A_arbace_repr_clojure_files_A_New() *A_arbace_repr_clojure_files_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_files_A{}; t.Ctor(); return t }
//line :133:1
func (t *A_arbace_repr_clojure_files_A) Ctor() {}
//line :133:1
func (t *A_arbace_repr_clojure_files_A) Invoke_O_O__O(self, src__0 any) any {


	if jrt.NN(jrt.File_Cast(src__0)).IsDirectory__Z() { var root__2 any = jrt.NN(jrt.File_Cast(src__0)).ToPath__Path(); var root_313 any = A_arbace_repr_clojure_A_const_53.GetRawRoot__O(); var linked_314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_313, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_315 lang.IFn

		if linked_314 == nil { ifn_315 = lang.IFn_Cast(root_313) } else { ifn_315 = nil }; var arg_316 any = A_arbace_repr_clojure_A_const_54.GetRawRoot__O(); var arg_317 any; var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_repr_clojure_files_iter__716000030__716000034_A_New_O_O(root__2, src__0); var tmp2 *jrt.Class; var fncls__308 *jrt.Class = A_arbace_repr_clojure_files_iter__716000030__716000034_A_fn_class
		if fncls__308 == nil { var fncls__308d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_repr_clojure_files_iter__716000030__716000034_A_fn_class = fncls__308d; tmp2 = fncls__308d } else { tmp2 = fncls__308 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp4 any; var root_309 any = A_arbace_repr_clojure_A_const_65.GetRawRoot__O(); var linked_310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_309, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_311 lang.IFn; if linked_310 == nil { ifn_311 = lang.IFn_Cast(root_309) } else { ifn_311 = nil }; var arg_312 any = src__0; if linked_310 == nil { tmp4 = ifn_311.Invoke_O__O(arg_312) } else { tmp4 = linked_310.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_309, arg_312) }; arg_317 = tmp3.Invoke_O__O(tmp4)
//line :138:1
		if linked_314 == nil { return ifn_315.Invoke_O_O__O(arg_316, arg_317) } else { return linked_314.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_313, arg_316, arg_317) } } else {
//line :136:1
			var tmp5 any; var or__1927000174__auto____2 any = jrt.NN(jrt.NN(jrt.File_Cast(src__0)).GetAbsoluteFile__File()).GetParentFile__File().Ref()




			if jrt.J2g_Truth(or__1927000174__auto____2) { tmp5 = or__1927000174__auto____2 } else { tmp5 = jrt.File_New_String(Lit_12) }
//line :136:1
			return lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(tmp5, jrt.NN(jrt.File_Cast(src__0)).GetName__String().Ref()))
		}
}
func A_arbace_repr_clojure_files_iter__716000030__716000034_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_files_iter__716000030__716000034_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_files_iter__716000030__716000034_A{}; t.Ctor_O_O(p0, p1); return t }
//line :139:1
func (t *A_arbace_repr_clojure_files_iter__716000030__716000034_A) Ctor_O_O(c__root, c__src any) { t.F_root = c__root; t.F_src = c__src }
//line :139:1
func (t *A_arbace_repr_clojure_files_iter__716000030__716000034_A) Invoke_O_O__O(self, s__716000031__1 any) any { var tmp1 any = A_arbace_repr_clojure_files_iter__716000030__716000034_fn__716000035_A_New_O_O_O_O(t.F_root, self, t.F_src, s__716000031__1); var tmp2 *jrt.Class; var fncls__307 *jrt.Class = A_arbace_repr_clojure_files_iter__716000030__716000034_fn__716000035_A_fn_class; if fncls__307 == nil { var fncls__307d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_repr_clojure_files_iter__716000030__716000034_fn__716000035_A_fn_class = fncls__307d; tmp2 = fncls__307d } else { tmp2 = fncls__307 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :139:1
func A_arbace_repr_clojure_files_iter__716000030__716000034_fn__716000035_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_repr_clojure_files_iter__716000030__716000034_fn__716000035_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_files_iter__716000030__716000034_fn__716000035_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :139:1
func (t *A_arbace_repr_clojure_files_iter__716000030__716000034_fn__716000035_A) Ctor_O_O_O_O(c__root, c__iter__716000030, c__src, c__s__716000031 any) { t.F_root = c__root; t.F_iter__716000030 = c__iter__716000030; t.F_src = c__src; t.F_s__716000031 = c__s__716000031 }
//line :139:1
func (t *A_arbace_repr_clojure_files_iter__716000030__716000034_fn__716000035_A) Invoke_O__O(self any) any { { var s__716000031__1 any; var t_ any = t.F_s__716000031; t.F_s__716000031 = nil; s__716000031__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_238 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_240 lang.IFn; if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any = s__716000031__1; if linked_239 == nil { temp__1927000414__auto____2 = ifn_240.Invoke_O__O(arg_241) } else { temp__1927000414__auto____2 = linked_239.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_238, arg_241) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__716000031__3 any = temp__1927000414__auto____2; var tmp1 any; var root_242 any = A_arbace_repr_clojure_A_const_55.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = s__716000031__3; if linked_243 == nil { tmp1 = ifn_244.Invoke_O__O(arg_245) } else { tmp1 = linked_243.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_242, arg_245) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_246 any = A_arbace_repr_clojure_A_const_56.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_248 lang.IFn; if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = s__716000031__3; if linked_247 == nil { c__1927001037__auto____4 = ifn_248.Invoke_O__O(arg_249) } else { c__1927001037__auto____4 = linked_247.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_246, arg_249) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__716000033__6 any; var root_250 any = A_arbace_repr_clojure_A_const_57.GetRawRoot__O(); var linked_251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_250, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_252 lang.IFn; if linked_251 == nil { ifn_252 = lang.IFn_Cast(root_250) } else { ifn_252 = nil }; var arg_253 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_251 == nil { b__716000033__6 = ifn_252.Invoke_O__O(arg_253) } else { b__716000033__6 = linked_251.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_250, arg_253) }; var tmp2 any = A_arbace_repr_clojure_files_iter__716000030__716000034_fn__716000035_fn__716000036_A_New_O_O_O_I_O(t.F_root, t.F_src, b__716000033__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__263 *jrt.Class = A_arbace_repr_clojure_files_iter__716000030__716000034_fn__716000035_fn__716000036_A_fn_class; if fncls__263 == nil { var fncls__263d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_repr_clojure_files_iter__716000030__716000034_fn__716000035_fn__716000036_A_fn_class = fncls__263d; tmp3 = fncls__263d } else { tmp3 = fncls__263 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_272 any = A_arbace_repr_clojure_A_const_60.GetRawRoot__O(); var linked_273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_272, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_274 lang.IFn; if linked_273 == nil { ifn_274 = lang.IFn_Cast(root_272) } else { ifn_274 = nil }; var arg_275 any; var root_264 any = A_arbace_repr_clojure_A_const_61.GetRawRoot__O(); var linked_265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_264, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_266 lang.IFn; if linked_265 == nil { ifn_266 = lang.IFn_Cast(root_264) } else { ifn_266 = nil }; var arg_267 any = b__716000033__6; if linked_265 == nil { arg_275 = ifn_266.Invoke_O__O(arg_267) } else { arg_275 = linked_265.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_264, arg_267) }; var arg_276 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__716000030); var tmp5 any; var root_268 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_268, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_270 lang.IFn; if linked_269 == nil { ifn_270 = lang.IFn_Cast(root_268) } else { ifn_270 = nil }; var arg_271 any = s__716000031__3; if linked_269 == nil { tmp5 = ifn_270.Invoke_O__O(arg_271) } else { tmp5 = linked_269.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_268, arg_271) }; arg_276 = tmp4.Invoke_O__O(tmp5); if linked_273 == nil { return ifn_274.Invoke_O_O__O(arg_275, arg_276) } else { return linked_273.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_272, arg_275, arg_276) } } else { var root_281 any = A_arbace_repr_clojure_A_const_60.GetRawRoot__O(); var linked_282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_281, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_283 lang.IFn; if linked_282 == nil { ifn_283 = lang.IFn_Cast(root_281) } else { ifn_283 = nil }; var arg_284 any; var root_277 any = A_arbace_repr_clojure_A_const_61.GetRawRoot__O(); var linked_278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_277, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_279 lang.IFn; if linked_278 == nil { ifn_279 = lang.IFn_Cast(root_277) } else { ifn_279 = nil }; var arg_280 any = b__716000033__6; if linked_278 == nil { arg_284 = ifn_279.Invoke_O__O(arg_280) } else { arg_284 = linked_278.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_277, arg_280) }; var arg_285 any; if linked_282 == nil { return ifn_283.Invoke_O_O__O(arg_284, arg_285) } else { return linked_282.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_281, arg_284, arg_285) } } } else { var f__4 any; var root_286 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_286, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_288 lang.IFn; if linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any = s__716000031__3; if linked_287 == nil { f__4 = ifn_288.Invoke_O__O(arg_289) } else { f__4 = linked_287.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_286, arg_289) }; if jrt.NN(jrt.File_Cast(f__4)).IsFile__Z() { var root_298 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_298, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_300 lang.IFn; if linked_299 == nil { ifn_300 = lang.IFn_Cast(root_298) } else { ifn_300 = nil }; var arg_301 any; var tmp6 any = t.F_src; var tmp7 any; var root_290 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_290, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_292 lang.IFn
														if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var tmp8 jrt.Path = jrt.Path_Cast(t.F_root); var arg_293 any = tmp8.Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__4)).ToPath__Path()); if linked_291 == nil { tmp7 = ifn_292.Invoke_O__O(arg_293) } else { tmp7 = linked_291.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_290, arg_293) }
//line :139:1
	arg_301 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7); var arg_302 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__716000030); var tmp10 any; var root_294 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_294, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_296 lang.IFn; if linked_295 == nil { ifn_296 = lang.IFn_Cast(root_294) } else { ifn_296 = nil }; var arg_297 any = s__716000031__3; if linked_295 == nil { tmp10 = ifn_296.Invoke_O__O(arg_297) } else { tmp10 = linked_295.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_294, arg_297) }; arg_302 = tmp9.Invoke_O__O(tmp10); if linked_299 == nil { return ifn_300.Invoke_O_O__O(arg_301, arg_302) } else { return linked_299.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_298, arg_301, arg_302) } } else { var tmp11 any; var root_303 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_303, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_305 lang.IFn; if linked_304 == nil { ifn_305 = lang.IFn_Cast(root_303) } else { ifn_305 = nil }; var arg_306 any = s__716000031__3; if linked_304 == nil { tmp11 = ifn_305.Invoke_O__O(arg_306) } else { tmp11 = linked_304.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_303, arg_306) }; s__716000031__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :139:1
func A_arbace_repr_clojure_files_iter__716000030__716000034_fn__716000035_fn__716000036_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_repr_clojure_files_iter__716000030__716000034_fn__716000035_fn__716000036_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_files_iter__716000030__716000034_fn__716000035_fn__716000036_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :139:1
func (t *A_arbace_repr_clojure_files_iter__716000030__716000034_fn__716000035_fn__716000036_A) Ctor_O_O_O_I_O(c__root, c__src, c__b__716000033 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_root = c__root; t.F_src = c__src; t.F_b__716000033 = c__b__716000033; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :139:1
func (t *A_arbace_repr_clojure_files_iter__716000030__716000034_fn__716000035_fn__716000036_A) Invoke_O__O(self any) any { { var i__716000032__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__716000032__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__716000032__1)); if jrt.NN(jrt.File_Cast(f__2)).IsFile__Z() { var root_258 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = t.F_b__716000033; var arg_262 any; var tmp2 any = t.F_src; var tmp3 any; var root_254 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_254, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_256 lang.IFn
																if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var tmp4 jrt.Path = jrt.Path_Cast(t.F_root); var arg_257 any = tmp4.Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__2)).ToPath__Path()); if linked_255 == nil { tmp3 = ifn_256.Invoke_O__O(arg_257) } else { tmp3 = linked_255.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_254, arg_257) }
//line :139:1
	arg_262 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3); if linked_259 == nil { ifn_260.Invoke_O_O__O(arg_261, arg_262) } else { linked_259.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_258, arg_261, arg_262) }; i__716000032__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__716000032__1); continue L1 } else { i__716000032__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__716000032__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_repr_clojure_run_A_New() *A_arbace_repr_clojure_run_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_A{}; t.Ctor(); return t }
//line :143:1
func (t *A_arbace_repr_clojure_run_A) Ctor() {}
//line :143:1
func (t *A_arbace_repr_clojure_run_A) Invoke_O_O_O_O_O__O(self, verb__0, sources__1, out__2, opts__3 any) any { var skip__5 any = A_arbace_repr_clojure_A_const_32.Invoke_O_O__O(opts__3, lang.PersistentHashSet_EMPTY.Ref()); var map__716000041__6 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_66.GetRawRoot__O()).Invoke_O__O(verb__0); var map__716000041__7 any; if







	lang.ISeq_InstanceOf(map__716000041__6) { var tmp1 any; var root_318 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_318, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_320 lang.IFn; if linked_319 == nil { ifn_320 = lang.IFn_Cast(root_318) } else { ifn_320 = nil }; var arg_321 any = map__716000041__6; if linked_319 == nil { tmp1 = ifn_320.Invoke_O__O(arg_321) } else { tmp1 = linked_319.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_318, arg_321) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_322 any = A_arbace_repr_clojure_A_const_15.GetRawRoot__O(); var linked_323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_322, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_324 lang.IFn; if linked_323 == nil { ifn_324 = lang.IFn_Cast(root_322) } else { ifn_324 = nil }; var arg_325 any = map__716000041__6; if linked_323 == nil { tmp2 = ifn_324.Invoke_O__O(arg_325) } else { tmp2 = linked_323.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_322, arg_325) }; map__716000041__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_326 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_326, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_328 lang.IFn; if linked_327 == nil { ifn_328 = lang.IFn_Cast(root_326) } else { ifn_328 = nil }; var arg_329 any = map__716000041__6; if linked_327 == nil { tmp3 = ifn_328.Invoke_O__O(arg_329) } else { tmp3 = linked_327.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_326, arg_329) }; if jrt.J2g_Truth(tmp3) { var root_330 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_330, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_332 lang.IFn; if linked_331 == nil { ifn_332 = lang.IFn_Cast(root_330) } else { ifn_332 = nil }; var arg_333 any = map__716000041__6; if linked_331 == nil { map__716000041__7 = ifn_332.Invoke_O__O(arg_333) } else { map__716000041__7 = linked_331.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_330, arg_333) } } else { map__716000041__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__716000041__7 = map__716000041__6 }; var plan__8 any = /*line :143:1*/lang.RT_Get_O_O__O_NoInit(map__716000041__7, A_arbace_repr_clojure_A_const_67); var translate_text__9 any = lang.RT_Get_O_O__O_NoInit(map__716000041__7, A_arbace_repr_clojure_A_const_19); var listing__10 any; var root_339 any = A_arbace_repr_clojure_A_const_68.GetRawRoot__O(); var linked_340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_339, aot_arbace_core.A_arbace_core_memoize_A_fn_class); var ifn_341 lang.IFn; if









	linked_340 == nil { ifn_341 = lang.IFn_Cast(root_339) } else { ifn_341 = nil }; var arg_342 any; var tmp4 any = A_arbace_repr_clojure_run_fn__716000043_A_New(); var tmp5 *jrt.Class; var fncls__338 *jrt.Class = A_arbace_repr_clojure_run_fn__716000043_A_fn_class; if fncls__338 == nil { var fncls__338d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_88, false); A_arbace_repr_clojure_run_fn__716000043_A_fn_class = fncls__338d; tmp5 = fncls__338d } else { tmp5 = fncls__338 }; arg_342 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); if linked_340 == nil { listing__10 = ifn_341.Invoke_O__O(arg_342) } else { listing__10 = linked_340.(*aot_arbace_core.A_arbace_core_memoize_A).Invoke_O_O__O(root_339, arg_342) }; var stats__11 any; var root_343 any = /*line :143:1*/A_arbace_repr_clojure_A_const_70.GetRawRoot__O(); var linked_344 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_343, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_345 lang.IFn; if










	linked_344 == nil { ifn_345 = lang.IFn_Cast(root_343) } else { ifn_345 = nil }; var arg_346 any = A_arbace_repr_clojure_A_const_71; if linked_344 == nil { stats__11 = ifn_345.Invoke_O__O(arg_346) } else { stats__11 = linked_344.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_343, arg_346) }; var seq_716000045__12 any; var root_351 any = /*line :143:1*/A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_351, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_353 lang.IFn; if











	linked_352 == nil { ifn_353 = lang.IFn_Cast(root_351) } else { ifn_353 = nil }; var arg_354 any = sources__1; if linked_352 == nil { seq_716000045__12 = ifn_353.Invoke_O__O(arg_354) } else { seq_716000045__12 = linked_352.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_351, arg_354) }; var chunk_716000046__13 any; var count_716000047__14 int64 = 0; var i_716000048__15 int64 = 0; L1:
//line :143:1
	for {











		if lang.Numbers_Lt_J_J__Z_NoInit(i_716000048__15, count_716000047__14) { var src__16 any = lang.Indexed_Cast(chunk_716000046__13).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_716000048__15)); var srcf__17 any; var root_371 any = A_arbace_repr_clojure_A_const_72.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_371, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_373 lang.IFn
			if linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any = src__16; if linked_372 == nil { srcf__17 = ifn_373.Invoke_O__O(arg_374) } else { srcf__17 = linked_372.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_371, arg_374) }
//line :155:1
			var seq_716000053__18 any; var root_379 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_379, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_381 lang.IFn; if linked_380 == nil { ifn_381 = lang.IFn_Cast(root_379) } else { ifn_381 = nil }; var arg_382 any; var root_375 any = A_arbace_repr_clojure_A_const_73.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_375, A_arbace_repr_clojure_files_A_fn_class); var ifn_377 lang.IFn

			if linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any = srcf__17; if linked_376 == nil { arg_382 = ifn_377.Invoke_O__O(arg_378) } else { arg_382 = linked_376.(*A_arbace_repr_clojure_files_A).Invoke_O_O__O(root_375, arg_378) }
//line :155:1
			if linked_380 == nil { seq_716000053__18 = ifn_381.Invoke_O__O(arg_382) } else { seq_716000053__18 = linked_380.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_379, arg_382) }; var chunk_716000054__19 any; var count_716000055__20 int64 = 0; var i_716000056__21 int64 = 0; L2: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_716000056__21, count_716000055__20) { var vec__716000057__22 any = lang.Indexed_Cast(chunk_716000054__19).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_716000056__21)); var dir__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000057__22, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__24 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000057__22, lang.RT_IntCast_J__I_NoInit(1), nil); var f__25 any; var root_399 any = A_arbace_repr_clojure_A_const_72.GetRawRoot__O(); var linked_400 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_399, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_401 lang.IFn


				if linked_400 == nil { ifn_401 = lang.IFn_Cast(root_399) } else { ifn_401 = nil }; var arg_402 any = dir__23; var arg_403 any = rel__24; if linked_400 == nil { f__25 = ifn_401.Invoke_O_O__O(arg_402, arg_403) } else { f__25 = linked_400.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_399, arg_402, arg_403) }
//line :155:1
				var parent__26 any = jrt.NN(jrt.File_Cast(f__25)).GetParentFile__File().Ref(); var siblings__27 any = lang.IFn_Cast(listing__10).Invoke_O__O(parent__26); var p__28 any = lang.IFn_Cast(plan__8).Invoke_O_O_O__O(jrt.NN(jrt.File_Cast(f__25)).GetName__String().Ref(), siblings__27, opts__3); var rel_out__29 any; var d__29 any; var tmp6 any; var root_404 any = A_arbace_repr_clojure_A_const_72.GetRawRoot__O(); var linked_405 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_404, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_406 lang.IFn






				if linked_405 == nil { ifn_406 = lang.IFn_Cast(root_404) } else { ifn_406 = nil }; var arg_407 any = rel__24; if linked_405 == nil { tmp6 = ifn_406.Invoke_O__O(arg_407) } else { tmp6 = linked_405.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_404, arg_407) }; d__29 = jrt.NN(jrt.File_Cast(tmp6)).GetParent__String().Ref(); if jrt.J2g_Truth(d__29) { rel_out__29 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_29, nil), jrt.RefArrayOf(jrt.Object_class, d__29, nil, A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__28))).Ref() } else { rel_out__29 = A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__28) }
				if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_32.Invoke_O__O(p__28)) {

					var root_489 any = A_arbace_repr_clojure_A_const_77.GetRawRoot__O(); var linked_490 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_489, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_491 lang.IFn; if linked_490 == nil { ifn_491 = lang.IFn_Cast(root_489) } else { ifn_491 = nil }; var arg_492 any = stats__11; var arg_493 any = A_arbace_repr_clojure_A_const_78.GetRawRoot__O(); var arg_494 any = A_arbace_repr_clojure_A_const_89; var arg_495 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); if linked_490 == nil { ifn_491.Invoke_O_O_O_O__O(arg_492, arg_493, arg_494, arg_495) } else { linked_490.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_489, arg_492, arg_493, arg_494, arg_495) }
					var root_501 any = A_arbace_repr_clojure_A_const_84.GetRawRoot__O(); var linked_502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_501, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_503 lang.IFn; if linked_502 == nil { ifn_503 = lang.IFn_Cast(root_501) } else { ifn_503 = nil }; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_85.GetRawRoot__O()); var tmp8 any = A_arbace_repr_clojure_A_const_86; var arg_504 any = tmp7.Invoke_O_O__O(tmp8, A_arbace_repr_clojure_A_const_87.Get__O()); if linked_502 == nil { ifn_503.Invoke_O__O(arg_504) } else { linked_502.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_501, arg_504) }; var tmp9 any = A_arbace_repr_clojure_run_fn__716000060_A_New_O_O(f__25, p__28); var tmp10 *jrt.Class; var fncls__422 *jrt.Class = A_arbace_repr_clojure_run_fn__716000060_A_fn_class; if fncls__422 == nil { var fncls__422d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_89, false); A_arbace_repr_clojure_run_fn__716000060_A_fn_class = fncls__422d; tmp10 = fncls__422d } else { tmp10 = fncls__422 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil).Invoke__O() } else {
//line :163:1
						if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_76.Invoke_O__O(p__28)) {




							if jrt.J2g_Truth(out__2) { var t__30 any; var root_505 any = A_arbace_repr_clojure_A_const_72.GetRawRoot__O(); var linked_506 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_505, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_507 lang.IFn
								if linked_506 == nil { ifn_507 = lang.IFn_Cast(root_505) } else { ifn_507 = nil }; var arg_508 any = out__2; var arg_509 any = rel__24; if linked_506 == nil { t__30 = ifn_507.Invoke_O_O__O(arg_508, arg_509) } else { t__30 = linked_506.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_505, arg_508, arg_509) }
								lang.IFn_Cast(A_arbace_repr_clojure_A_const_91.GetRawRoot__O()).Invoke_O__O(t__30)
								lang.IFn_Cast(A_arbace_repr_clojure_A_const_90.GetRawRoot__O()).Invoke_O_O__O(f__25, t__30) }
							var root_423 any = A_arbace_repr_clojure_A_const_77.GetRawRoot__O(); var linked_424 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_423, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_425 lang.IFn; if linked_424 == nil { ifn_425 = lang.IFn_Cast(root_423) } else { ifn_425 = nil }; var arg_426 any = stats__11; var arg_427 any = A_arbace_repr_clojure_A_const_78.GetRawRoot__O(); var arg_428 any = A_arbace_repr_clojure_A_const_79; var arg_429 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); if linked_424 == nil { ifn_425.Invoke_O_O_O_O__O(arg_426, arg_427, arg_428, arg_429) } else { linked_424.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_423, arg_426, arg_427, arg_428, arg_429) } } else {
//line :163:1
								if A_arbace_repr_clojure_A_const_33 != nil { var s__30 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_81.GetRawRoot__O()).Invoke_O__O(f__25); var r__31 any; var tmp11 any = A_arbace_repr_clojure_run_fn__716000062_A_New_O_O_O_O_O_O(f__25, stats__11, p__28, s__30, translate_text__9, skip__5); var tmp12 *jrt.Class
									var fncls__473 /*line :163:1*/*jrt.Class = A_arbace_repr_clojure_run_fn__716000062_A_fn_class











									if fncls__473 == nil { var fncls__473d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_90, false); A_arbace_repr_clojure_run_fn__716000062_A_fn_class = fncls__473d; tmp12 = fncls__473d } else { tmp12 = fncls__473 }; r__31 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil).Invoke__O()




									if jrt.J2g_Truth(r__31) {
										var root_519 any = A_arbace_repr_clojure_A_const_77.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_519, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_521 lang.IFn; if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = stats__11; var arg_523 any = A_arbace_repr_clojure_A_const_78.GetRawRoot__O(); var arg_524 any; if lang.Util_Equiv_O_O__Z_NoInit(s__30, r__31) { arg_524 = A_arbace_repr_clojure_A_const_92 } else { arg_524 = A_arbace_repr_clojure_A_const_93 }; var arg_525 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); if linked_520 == nil { ifn_521.Invoke_O_O_O_O__O(arg_522, arg_523, arg_524, arg_525) } else { linked_520.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_519, arg_522, arg_523, arg_524, arg_525) }
										if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_26.Invoke_O__O(p__28)) { var root_526 any = A_arbace_repr_clojure_A_const_77.GetRawRoot__O(); var linked_527 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_526, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_528 lang.IFn; if linked_527 == nil { ifn_528 = lang.IFn_Cast(root_526) } else { ifn_528 = nil }; var arg_529 any = stats__11; var arg_530 any = A_arbace_repr_clojure_A_const_78.GetRawRoot__O(); var arg_531 any = A_arbace_repr_clojure_A_const_26; var arg_532 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); if linked_527 == nil { ifn_528.Invoke_O_O_O_O__O(arg_529, arg_530, arg_531, arg_532) } else { linked_527.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_526, arg_529, arg_530, arg_531, arg_532) } }
										if jrt.J2g_Truth(out__2) { var t__32 any; var root_474 any = A_arbace_repr_clojure_A_const_72.GetRawRoot__O(); var linked_475 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_474, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_476 lang.IFn
											if linked_475 == nil { ifn_476 = lang.IFn_Cast(root_474) } else { ifn_476 = nil }; var arg_477 any = out__2; var arg_478 any = rel_out__29; if linked_475 == nil { t__32 = ifn_476.Invoke_O_O__O(arg_477, arg_478) } else { t__32 = linked_475.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_474, arg_477, arg_478) }
											lang.IFn_Cast(A_arbace_repr_clojure_A_const_91.GetRawRoot__O()).Invoke_O__O(t__32)
											lang.IFn_Cast(A_arbace_repr_clojure_A_const_88.GetRawRoot__O()).Invoke_O_O__O(t__32, r__31) } else {
//line :183:1
												var moved__32 any; var root_484 any = A_arbace_repr_clojure_A_const_44.GetRawRoot__O(); var linked_485 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_484, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_486 lang.IFn



												if linked_485 == nil { ifn_486 = lang.IFn_Cast(root_484) } else { ifn_486 = nil }; var arg_487 any = jrt.NN(jrt.File_Cast(f__25)).GetName__String().Ref(); var arg_488 any = A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__28); if linked_485 == nil { moved__32 = ifn_486.Invoke_O_O__O(arg_487, arg_488) } else { moved__32 = linked_485.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_484, arg_487, arg_488) }
												var tmp13 any; var or__1927000174__auto____33 any; var root_537 any = A_arbace_repr_clojure_A_const_44.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_537, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_539 lang.IFn; if linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any = s__30; var arg_541 any = r__31; if linked_538 == nil { or__1927000174__auto____33 = ifn_539.Invoke_O_O__O(arg_540, arg_541) } else { or__1927000174__auto____33 = linked_538.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_537, arg_540, arg_541) }; if jrt.J2g_Truth(or__1927000174__auto____33) { tmp13 = or__1927000174__auto____33 } else { tmp13 = moved__32 }; if jrt.J2g_Truth(tmp13) {
													var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_88.GetRawRoot__O()); var tmp15 any; var root_542 any = A_arbace_repr_clojure_A_const_72.GetRawRoot__O(); var linked_543 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_542, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_544 lang.IFn; if linked_543 == nil { ifn_544 = lang.IFn_Cast(root_542) } else { ifn_544 = nil }; var arg_545 any = parent__26; var arg_546 any = A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__28); if linked_543 == nil { tmp15 = ifn_544.Invoke_O_O__O(arg_545, arg_546) } else { tmp15 = linked_543.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_542, arg_545, arg_546) }; tmp14.Invoke_O_O__O(tmp15, r__31) }
												if jrt.J2g_Truth(moved__32) { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(f__25)).Delete__Z()) } } } } } }
//line :155:1
				seq_716000053__18, chunk_716000054__19, count_716000055__20, i_716000056__21 = seq_716000053__18, chunk_716000054__19, count_716000055__20, lang.Numbers_Unchecked_inc_J__J_NoInit(i_716000056__21); continue L2 } else { var temp__1927000414__auto____22 any; var root_383 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_383, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_385 lang.IFn; if linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any = seq_716000053__18; if linked_384 == nil { temp__1927000414__auto____22 = ifn_385.Invoke_O__O(arg_386) } else { temp__1927000414__auto____22 = linked_384.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_383, arg_386) }; if jrt.J2g_Truth(temp__1927000414__auto____22) { var seq_716000053__23 any = temp__1927000414__auto____22; var tmp16 any; var root_387 any = A_arbace_repr_clojure_A_const_55.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_389 lang.IFn; if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any = seq_716000053__23; if linked_388 == nil { tmp16 = ifn_389.Invoke_O__O(arg_390) } else { tmp16 = linked_388.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_387, arg_390) }; if jrt.J2g_Truth(tmp16) { var c__1927000678__auto____24 any; var root_391 any = A_arbace_repr_clojure_A_const_56.GetRawRoot__O(); var linked_392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_391, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_393 lang.IFn; if linked_392 == nil { ifn_393 = lang.IFn_Cast(root_391) } else { ifn_393 = nil }; var arg_394 any = seq_716000053__23; if linked_392 == nil { c__1927000678__auto____24 = ifn_393.Invoke_O__O(arg_394) } else { c__1927000678__auto____24 = linked_392.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_391, arg_394) }; var tmp17 any; var root_552 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_552, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_554 lang.IFn; if linked_553 == nil { ifn_554 = lang.IFn_Cast(root_552) } else { ifn_554 = nil }; var arg_555 any = seq_716000053__23; if linked_553 == nil { tmp17 = ifn_554.Invoke_O__O(arg_555) } else { tmp17 = linked_553.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_552, arg_555) }; seq_716000053__18, chunk_716000054__19, count_716000055__20, i_716000056__21 = tmp17, c__1927000678__auto____24, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____24))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var vec__716000066__24 any; var root_395 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_395, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_397 lang.IFn; if linked_396 == nil { ifn_397 = lang.IFn_Cast(root_395) } else { ifn_397 = nil }; var arg_398 any = seq_716000053__23; if linked_396 == nil { vec__716000066__24 = ifn_397.Invoke_O__O(arg_398) } else { vec__716000066__24 = linked_396.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_395, arg_398) }; var dir__25 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000066__24, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__26 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000066__24, lang.RT_IntCast_J__I_NoInit(1), nil); var f__27 any; var root_556 any = A_arbace_repr_clojure_A_const_72.GetRawRoot__O(); var linked_557 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_556, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_558 lang.IFn


					if linked_557 == nil { ifn_558 = lang.IFn_Cast(root_556) } else { ifn_558 = nil }; var arg_559 any = dir__25; var arg_560 any = rel__26; if linked_557 == nil { f__27 = ifn_558.Invoke_O_O__O(arg_559, arg_560) } else { f__27 = linked_557.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_556, arg_559, arg_560) }
//line :155:1
					var parent__28 any = jrt.NN(jrt.File_Cast(f__27)).GetParentFile__File().Ref(); var siblings__29 any = lang.IFn_Cast(listing__10).Invoke_O__O(parent__28); var p__30 any = lang.IFn_Cast(plan__8).Invoke_O_O_O__O(jrt.NN(jrt.File_Cast(f__27)).GetName__String().Ref(), siblings__29, opts__3); var rel_out__31 any; var d__31 any; var tmp18 any; var root_561 any = A_arbace_repr_clojure_A_const_72.GetRawRoot__O(); var linked_562 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_561, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_563 lang.IFn






					if linked_562 == nil { ifn_563 = lang.IFn_Cast(root_561) } else { ifn_563 = nil }; var arg_564 any = rel__26; if linked_562 == nil { tmp18 = ifn_563.Invoke_O__O(arg_564) } else { tmp18 = linked_562.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_561, arg_564) }; d__31 = jrt.NN(jrt.File_Cast(tmp18)).GetParent__String().Ref(); if jrt.J2g_Truth(d__31) { rel_out__31 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_29, nil), jrt.RefArrayOf(jrt.Object_class, d__31, nil, A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__30))).Ref() } else { rel_out__31 = A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__30) }
					if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_32.Invoke_O__O(p__30)) {

						var root_646 any = A_arbace_repr_clojure_A_const_77.GetRawRoot__O(); var linked_647 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_646, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_648 lang.IFn; if linked_647 == nil { ifn_648 = lang.IFn_Cast(root_646) } else { ifn_648 = nil }; var arg_649 any = stats__11; var arg_650 any = A_arbace_repr_clojure_A_const_78.GetRawRoot__O(); var arg_651 any = A_arbace_repr_clojure_A_const_89; var arg_652 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); if linked_647 == nil { ifn_648.Invoke_O_O_O_O__O(arg_649, arg_650, arg_651, arg_652) } else { linked_647.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_646, arg_649, arg_650, arg_651, arg_652) }
						var root_658 any = A_arbace_repr_clojure_A_const_84.GetRawRoot__O(); var linked_659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_658, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_660 lang.IFn; if linked_659 == nil { ifn_660 = lang.IFn_Cast(root_658) } else { ifn_660 = nil }; var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_85.GetRawRoot__O()); var tmp20 any = A_arbace_repr_clojure_A_const_86; var arg_661 any = tmp19.Invoke_O_O__O(tmp20, A_arbace_repr_clojure_A_const_87.Get__O()); if linked_659 == nil { ifn_660.Invoke_O__O(arg_661) } else { linked_659.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_658, arg_661) }; var tmp21 any = A_arbace_repr_clojure_run_fn__716000069_A_New_O_O(f__27, p__30); var tmp22 *jrt.Class; var fncls__579 *jrt.Class = A_arbace_repr_clojure_run_fn__716000069_A_fn_class; if fncls__579 == nil { var fncls__579d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_91, false); A_arbace_repr_clojure_run_fn__716000069_A_fn_class = fncls__579d; tmp22 = fncls__579d } else { tmp22 = fncls__579 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil).Invoke__O() } else {
//line :163:1
							if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_76.Invoke_O__O(p__30)) {




								if jrt.J2g_Truth(out__2) { var t__32_2 any; var root_662 any = A_arbace_repr_clojure_A_const_72.GetRawRoot__O(); var linked_663 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_662, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_664 lang.IFn
									if linked_663 == nil { ifn_664 = lang.IFn_Cast(root_662) } else { ifn_664 = nil }; var arg_665 any = out__2; var arg_666 any = rel__26; if linked_663 == nil { t__32_2 = ifn_664.Invoke_O_O__O(arg_665, arg_666) } else { t__32_2 = linked_663.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_662, arg_665, arg_666) }
									lang.IFn_Cast(A_arbace_repr_clojure_A_const_91.GetRawRoot__O()).Invoke_O__O(t__32_2)
									lang.IFn_Cast(A_arbace_repr_clojure_A_const_90.GetRawRoot__O()).Invoke_O_O__O(f__27, t__32_2) }
								var root_580 any = A_arbace_repr_clojure_A_const_77.GetRawRoot__O(); var linked_581 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_580, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_582 lang.IFn; if linked_581 == nil { ifn_582 = lang.IFn_Cast(root_580) } else { ifn_582 = nil }; var arg_583 any = stats__11; var arg_584 any = A_arbace_repr_clojure_A_const_78.GetRawRoot__O(); var arg_585 any = A_arbace_repr_clojure_A_const_79; var arg_586 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); if linked_581 == nil { ifn_582.Invoke_O_O_O_O__O(arg_583, arg_584, arg_585, arg_586) } else { linked_581.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_580, arg_583, arg_584, arg_585, arg_586) } } else {
//line :163:1
									if A_arbace_repr_clojure_A_const_33 != nil { var s__32 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_81.GetRawRoot__O()).Invoke_O__O(f__27); var r__33 any; var tmp23 any = A_arbace_repr_clojure_run_fn__716000071_A_New_O_O_O_O_O_O(f__27, p__30, s__32, stats__11, translate_text__9, skip__5); var tmp24 *jrt.Class
										var fncls__630 /*line :163:1*/*jrt.Class = A_arbace_repr_clojure_run_fn__716000071_A_fn_class











										if fncls__630 == nil { var fncls__630d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_92, false); A_arbace_repr_clojure_run_fn__716000071_A_fn_class = fncls__630d; tmp24 = fncls__630d } else { tmp24 = fncls__630 }; r__33 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil).Invoke__O()




										if jrt.J2g_Truth(r__33) {
											var root_676 any = A_arbace_repr_clojure_A_const_77.GetRawRoot__O(); var linked_677 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_676, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_678 lang.IFn; if linked_677 == nil { ifn_678 = lang.IFn_Cast(root_676) } else { ifn_678 = nil }; var arg_679 any = stats__11; var arg_680 any = A_arbace_repr_clojure_A_const_78.GetRawRoot__O(); var arg_681 any; if lang.Util_Equiv_O_O__Z_NoInit(s__32, r__33) { arg_681 = A_arbace_repr_clojure_A_const_92 } else { arg_681 = A_arbace_repr_clojure_A_const_93 }; var arg_682 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); if linked_677 == nil { ifn_678.Invoke_O_O_O_O__O(arg_679, arg_680, arg_681, arg_682) } else { linked_677.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_676, arg_679, arg_680, arg_681, arg_682) }
											if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_26.Invoke_O__O(p__30)) { var root_683 any = A_arbace_repr_clojure_A_const_77.GetRawRoot__O(); var linked_684 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_683, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_685 lang.IFn; if linked_684 == nil { ifn_685 = lang.IFn_Cast(root_683) } else { ifn_685 = nil }; var arg_686 any = stats__11; var arg_687 any = A_arbace_repr_clojure_A_const_78.GetRawRoot__O(); var arg_688 any = A_arbace_repr_clojure_A_const_26; var arg_689 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); if linked_684 == nil { ifn_685.Invoke_O_O_O_O__O(arg_686, arg_687, arg_688, arg_689) } else { linked_684.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_683, arg_686, arg_687, arg_688, arg_689) } }
											if jrt.J2g_Truth(out__2) { var t__34 any; var root_631 any = A_arbace_repr_clojure_A_const_72.GetRawRoot__O(); var linked_632 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_631, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_633 lang.IFn
												if linked_632 == nil { ifn_633 = lang.IFn_Cast(root_631) } else { ifn_633 = nil }; var arg_634 any = out__2; var arg_635 any = rel_out__31; if linked_632 == nil { t__34 = ifn_633.Invoke_O_O__O(arg_634, arg_635) } else { t__34 = linked_632.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_631, arg_634, arg_635) }
												lang.IFn_Cast(A_arbace_repr_clojure_A_const_91.GetRawRoot__O()).Invoke_O__O(t__34)
												lang.IFn_Cast(A_arbace_repr_clojure_A_const_88.GetRawRoot__O()).Invoke_O_O__O(t__34, r__33) } else {
//line :183:1
													var moved__34 any; var root_641 any = A_arbace_repr_clojure_A_const_44.GetRawRoot__O(); var linked_642 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_641, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_643 lang.IFn



													if linked_642 == nil { ifn_643 = lang.IFn_Cast(root_641) } else { ifn_643 = nil }; var arg_644 any = jrt.NN(jrt.File_Cast(f__27)).GetName__String().Ref(); var arg_645 any = A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__30); if linked_642 == nil { moved__34 = ifn_643.Invoke_O_O__O(arg_644, arg_645) } else { moved__34 = linked_642.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_641, arg_644, arg_645) }
													var tmp25 any; var or__1927000174__auto____35 any; var root_694 any = A_arbace_repr_clojure_A_const_44.GetRawRoot__O(); var linked_695 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_694, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_696 lang.IFn; if linked_695 == nil { ifn_696 = lang.IFn_Cast(root_694) } else { ifn_696 = nil }; var arg_697 any = s__32; var arg_698 any = r__33; if linked_695 == nil { or__1927000174__auto____35 = ifn_696.Invoke_O_O__O(arg_697, arg_698) } else { or__1927000174__auto____35 = linked_695.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_694, arg_697, arg_698) }; if jrt.J2g_Truth(or__1927000174__auto____35) { tmp25 = or__1927000174__auto____35 } else { tmp25 = moved__34 }; if jrt.J2g_Truth(tmp25) {
														var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_88.GetRawRoot__O()); var tmp27 any; var root_699 any = A_arbace_repr_clojure_A_const_72.GetRawRoot__O(); var linked_700 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_699, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_701 lang.IFn; if linked_700 == nil { ifn_701 = lang.IFn_Cast(root_699) } else { ifn_701 = nil }; var arg_702 any = parent__28; var arg_703 any = A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__30); if linked_700 == nil { tmp27 = ifn_701.Invoke_O_O__O(arg_702, arg_703) } else { tmp27 = linked_700.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_699, arg_702, arg_703) }; tmp26.Invoke_O_O__O(tmp27, r__33) }
													if jrt.J2g_Truth(moved__34) { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(f__27)).Delete__Z()) } } } } } }
//line :155:1
					var tmp28 any; var root_709 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_709, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_711 lang.IFn; if linked_710 == nil { ifn_711 = lang.IFn_Cast(root_709) } else { ifn_711 = nil }; var arg_712 any = seq_716000053__23; if linked_710 == nil { tmp28 = ifn_711.Invoke_O__O(arg_712) } else { tmp28 = linked_710.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_709, arg_712) }; seq_716000053__18, chunk_716000054__19, count_716000055__20, i_716000056__21 = tmp28, nil, 0, 0; continue L2 } } }; break L2 }; seq_716000045__12, chunk_716000046__13, count_716000047__14, i_716000048__15 = seq_716000045__12, chunk_716000046__13, count_716000047__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_716000048__15); continue L1 } else { var temp__1927000414__auto____16 any; var root_355 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_355, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_357 lang.IFn; if linked_356 == nil { ifn_357 = lang.IFn_Cast(root_355) } else { ifn_357 = nil }; var arg_358 any = seq_716000045__12; if linked_356 == nil { temp__1927000414__auto____16 = ifn_357.Invoke_O__O(arg_358) } else { temp__1927000414__auto____16 = linked_356.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_355, arg_358) }; if jrt.J2g_Truth(temp__1927000414__auto____16) { var seq_716000045__17 any = temp__1927000414__auto____16; var tmp29 any; var root_359 any = A_arbace_repr_clojure_A_const_55.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_361 lang.IFn; if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any = seq_716000045__17; if linked_360 == nil { tmp29 = ifn_361.Invoke_O__O(arg_362) } else { tmp29 = linked_360.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_359, arg_362) }; if jrt.J2g_Truth(tmp29) { var c__1927000678__auto____18 any; var root_363 any = A_arbace_repr_clojure_A_const_56.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_363, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_365 lang.IFn; if linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any = seq_716000045__17; if linked_364 == nil { c__1927000678__auto____18 = ifn_365.Invoke_O__O(arg_366) } else { c__1927000678__auto____18 = linked_364.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_363, arg_366) }; var tmp30 any; var root_713 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_713, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_715 lang.IFn; if linked_714 == nil { ifn_715 = lang.IFn_Cast(root_713) } else { ifn_715 = nil }; var arg_716 any = seq_716000045__17; if linked_714 == nil { tmp30 = ifn_715.Invoke_O__O(arg_716) } else { tmp30 = linked_714.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_713, arg_716) }; seq_716000045__12, chunk_716000046__13, count_716000047__14, i_716000048__15 = tmp30, c__1927000678__auto____18, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____18))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var src__18 any; var root_367 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_367, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_369 lang.IFn; if linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any = seq_716000045__17; if linked_368 == nil { src__18 = ifn_369.Invoke_O__O(arg_370) } else { src__18 = linked_368.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_367, arg_370) }; var srcf__19 any; var root_717 any = A_arbace_repr_clojure_A_const_72.GetRawRoot__O(); var linked_718 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_717, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_719 lang.IFn
						if linked_718 == nil { ifn_719 = lang.IFn_Cast(root_717) } else { ifn_719 = nil }; var arg_720 any = src__18; if linked_718 == nil { srcf__19 = ifn_719.Invoke_O__O(arg_720) } else { srcf__19 = linked_718.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_717, arg_720) }
//line :155:1
						var seq_716000049__20 any; var root_725 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_725, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_727 lang.IFn; if linked_726 == nil { ifn_727 = lang.IFn_Cast(root_725) } else { ifn_727 = nil }; var arg_728 any; var root_721 any = A_arbace_repr_clojure_A_const_73.GetRawRoot__O(); var linked_722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_721, A_arbace_repr_clojure_files_A_fn_class); var ifn_723 lang.IFn

						if linked_722 == nil { ifn_723 = lang.IFn_Cast(root_721) } else { ifn_723 = nil }; var arg_724 any = srcf__19; if linked_722 == nil { arg_728 = ifn_723.Invoke_O__O(arg_724) } else { arg_728 = linked_722.(*A_arbace_repr_clojure_files_A).Invoke_O_O__O(root_721, arg_724) }
//line :155:1
						if linked_726 == nil { seq_716000049__20 = ifn_727.Invoke_O__O(arg_728) } else { seq_716000049__20 = linked_726.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_725, arg_728) }; var chunk_716000050__21 any; var count_716000051__22 int64 = 0; var i_716000052__23 int64 = 0; L3: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_716000052__23, count_716000051__22) { var vec__716000075__24 any = lang.Indexed_Cast(chunk_716000050__21).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_716000052__23)); var dir__25_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000075__24, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__26_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000075__24, lang.RT_IntCast_J__I_NoInit(1), nil); var f__27_2 any; var root_745 any = A_arbace_repr_clojure_A_const_72.GetRawRoot__O(); var linked_746 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_745, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_747 lang.IFn


							if linked_746 == nil { ifn_747 = lang.IFn_Cast(root_745) } else { ifn_747 = nil }; var arg_748 any = dir__25_2; var arg_749 any = rel__26_2; if linked_746 == nil { f__27_2 = ifn_747.Invoke_O_O__O(arg_748, arg_749) } else { f__27_2 = linked_746.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_745, arg_748, arg_749) }
//line :155:1
							var parent__28_2 any = jrt.NN(jrt.File_Cast(f__27_2)).GetParentFile__File().Ref(); var siblings__29_2 any = lang.IFn_Cast(listing__10).Invoke_O__O(parent__28_2); var p__30_2 any = lang.IFn_Cast(plan__8).Invoke_O_O_O__O(jrt.NN(jrt.File_Cast(f__27_2)).GetName__String().Ref(), siblings__29_2, opts__3); var rel_out__31_2 any; var d__31_2 any; var tmp31 any; var root_750 any = A_arbace_repr_clojure_A_const_72.GetRawRoot__O(); var linked_751 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_750, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_752 lang.IFn






							if linked_751 == nil { ifn_752 = lang.IFn_Cast(root_750) } else { ifn_752 = nil }; var arg_753 any = rel__26_2; if linked_751 == nil { tmp31 = ifn_752.Invoke_O__O(arg_753) } else { tmp31 = linked_751.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_750, arg_753) }; d__31_2 = jrt.NN(jrt.File_Cast(tmp31)).GetParent__String().Ref(); if jrt.J2g_Truth(d__31_2) { rel_out__31_2 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_29, nil), jrt.RefArrayOf(jrt.Object_class, d__31_2, nil, A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__30_2))).Ref() } else { rel_out__31_2 = A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__30_2) }
							if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_32.Invoke_O__O(p__30_2)) {

								var root_835 any = A_arbace_repr_clojure_A_const_77.GetRawRoot__O(); var linked_836 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_835, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_837 lang.IFn; if linked_836 == nil { ifn_837 = lang.IFn_Cast(root_835) } else { ifn_837 = nil }; var arg_838 any = stats__11; var arg_839 any = A_arbace_repr_clojure_A_const_78.GetRawRoot__O(); var arg_840 any = A_arbace_repr_clojure_A_const_89; var arg_841 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); if linked_836 == nil { ifn_837.Invoke_O_O_O_O__O(arg_838, arg_839, arg_840, arg_841) } else { linked_836.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_835, arg_838, arg_839, arg_840, arg_841) }
								var root_847 any = A_arbace_repr_clojure_A_const_84.GetRawRoot__O(); var linked_848 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_847, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_849 lang.IFn; if linked_848 == nil { ifn_849 = lang.IFn_Cast(root_847) } else { ifn_849 = nil }; var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_85.GetRawRoot__O()); var tmp33 any = A_arbace_repr_clojure_A_const_86; var arg_850 any = tmp32.Invoke_O_O__O(tmp33, A_arbace_repr_clojure_A_const_87.Get__O()); if linked_848 == nil { ifn_849.Invoke_O__O(arg_850) } else { linked_848.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_847, arg_850) }; var tmp34 any = A_arbace_repr_clojure_run_fn__716000078_A_New_O_O(f__27_2, p__30_2); var tmp35 *jrt.Class; var fncls__768 *jrt.Class = A_arbace_repr_clojure_run_fn__716000078_A_fn_class; if fncls__768 == nil { var fncls__768d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_93, false); A_arbace_repr_clojure_run_fn__716000078_A_fn_class = fncls__768d; tmp35 = fncls__768d } else { tmp35 = fncls__768 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp34, tmp35, nil).Invoke__O() } else {
//line :163:1
									if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_76.Invoke_O__O(p__30_2)) {




										if jrt.J2g_Truth(out__2) { var t__32_3 any; var root_851 any = A_arbace_repr_clojure_A_const_72.GetRawRoot__O(); var linked_852 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_851, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_853 lang.IFn
											if linked_852 == nil { ifn_853 = lang.IFn_Cast(root_851) } else { ifn_853 = nil }; var arg_854 any = out__2; var arg_855 any = rel__26_2; if linked_852 == nil { t__32_3 = ifn_853.Invoke_O_O__O(arg_854, arg_855) } else { t__32_3 = linked_852.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_851, arg_854, arg_855) }
											lang.IFn_Cast(A_arbace_repr_clojure_A_const_91.GetRawRoot__O()).Invoke_O__O(t__32_3)
											lang.IFn_Cast(A_arbace_repr_clojure_A_const_90.GetRawRoot__O()).Invoke_O_O__O(f__27_2, t__32_3) }
										var root_769 any = A_arbace_repr_clojure_A_const_77.GetRawRoot__O(); var linked_770 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_769, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_771 lang.IFn; if linked_770 == nil { ifn_771 = lang.IFn_Cast(root_769) } else { ifn_771 = nil }; var arg_772 any = stats__11; var arg_773 any = A_arbace_repr_clojure_A_const_78.GetRawRoot__O(); var arg_774 any = A_arbace_repr_clojure_A_const_79; var arg_775 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); if linked_770 == nil { ifn_771.Invoke_O_O_O_O__O(arg_772, arg_773, arg_774, arg_775) } else { linked_770.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_769, arg_772, arg_773, arg_774, arg_775) } } else {
//line :163:1
											if A_arbace_repr_clojure_A_const_33 != nil { var s__32_2 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_81.GetRawRoot__O()).Invoke_O__O(f__27_2); var r__33_2 any; var tmp36 any = A_arbace_repr_clojure_run_fn__716000080_A_New_O_O_O_O_O_O(f__27_2, p__30_2, s__32_2, stats__11, translate_text__9, skip__5); var tmp37 *jrt.Class
												var fncls__819 /*line :163:1*/*jrt.Class = A_arbace_repr_clojure_run_fn__716000080_A_fn_class











												if fncls__819 == nil { var fncls__819d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_94, false); A_arbace_repr_clojure_run_fn__716000080_A_fn_class = fncls__819d; tmp37 = fncls__819d } else { tmp37 = fncls__819 }; r__33_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp36, tmp37, nil).Invoke__O()




												if jrt.J2g_Truth(r__33_2) {
													var root_865 any = A_arbace_repr_clojure_A_const_77.GetRawRoot__O(); var linked_866 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_865, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_867 lang.IFn; if linked_866 == nil { ifn_867 = lang.IFn_Cast(root_865) } else { ifn_867 = nil }; var arg_868 any = stats__11; var arg_869 any = A_arbace_repr_clojure_A_const_78.GetRawRoot__O(); var arg_870 any; if lang.Util_Equiv_O_O__Z_NoInit(s__32_2, r__33_2) { arg_870 = A_arbace_repr_clojure_A_const_92 } else { arg_870 = A_arbace_repr_clojure_A_const_93 }; var arg_871 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); if linked_866 == nil { ifn_867.Invoke_O_O_O_O__O(arg_868, arg_869, arg_870, arg_871) } else { linked_866.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_865, arg_868, arg_869, arg_870, arg_871) }
													if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_26.Invoke_O__O(p__30_2)) { var root_872 any = A_arbace_repr_clojure_A_const_77.GetRawRoot__O(); var linked_873 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_872, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_874 lang.IFn; if linked_873 == nil { ifn_874 = lang.IFn_Cast(root_872) } else { ifn_874 = nil }; var arg_875 any = stats__11; var arg_876 any = A_arbace_repr_clojure_A_const_78.GetRawRoot__O(); var arg_877 any = A_arbace_repr_clojure_A_const_26; var arg_878 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); if linked_873 == nil { ifn_874.Invoke_O_O_O_O__O(arg_875, arg_876, arg_877, arg_878) } else { linked_873.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_872, arg_875, arg_876, arg_877, arg_878) } }
													if jrt.J2g_Truth(out__2) { var t__34_2 any; var root_820 any = A_arbace_repr_clojure_A_const_72.GetRawRoot__O(); var linked_821 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_820, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_822 lang.IFn
														if linked_821 == nil { ifn_822 = lang.IFn_Cast(root_820) } else { ifn_822 = nil }; var arg_823 any = out__2; var arg_824 any = rel_out__31_2; if linked_821 == nil { t__34_2 = ifn_822.Invoke_O_O__O(arg_823, arg_824) } else { t__34_2 = linked_821.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_820, arg_823, arg_824) }
														lang.IFn_Cast(A_arbace_repr_clojure_A_const_91.GetRawRoot__O()).Invoke_O__O(t__34_2)
														lang.IFn_Cast(A_arbace_repr_clojure_A_const_88.GetRawRoot__O()).Invoke_O_O__O(t__34_2, r__33_2) } else {
//line :183:1
															var moved__34_2 any; var root_830 any = A_arbace_repr_clojure_A_const_44.GetRawRoot__O(); var linked_831 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_830, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_832 lang.IFn



															if linked_831 == nil { ifn_832 = lang.IFn_Cast(root_830) } else { ifn_832 = nil }; var arg_833 any = jrt.NN(jrt.File_Cast(f__27_2)).GetName__String().Ref(); var arg_834 any = A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__30_2); if linked_831 == nil { moved__34_2 = ifn_832.Invoke_O_O__O(arg_833, arg_834) } else { moved__34_2 = linked_831.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_830, arg_833, arg_834) }
															var tmp38 any; var or__1927000174__auto____35_2 any; var root_883 any = A_arbace_repr_clojure_A_const_44.GetRawRoot__O(); var linked_884 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_883, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_885 lang.IFn; if linked_884 == nil { ifn_885 = lang.IFn_Cast(root_883) } else { ifn_885 = nil }; var arg_886 any = s__32_2; var arg_887 any = r__33_2; if linked_884 == nil { or__1927000174__auto____35_2 = ifn_885.Invoke_O_O__O(arg_886, arg_887) } else { or__1927000174__auto____35_2 = linked_884.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_883, arg_886, arg_887) }; if jrt.J2g_Truth(or__1927000174__auto____35_2) { tmp38 = or__1927000174__auto____35_2 } else { tmp38 = moved__34_2 }; if jrt.J2g_Truth(tmp38) {
																var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_88.GetRawRoot__O()); var tmp40 any; var root_888 any = A_arbace_repr_clojure_A_const_72.GetRawRoot__O(); var linked_889 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_888, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_890 lang.IFn; if linked_889 == nil { ifn_890 = lang.IFn_Cast(root_888) } else { ifn_890 = nil }; var arg_891 any = parent__28_2; var arg_892 any = A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__30_2); if linked_889 == nil { tmp40 = ifn_890.Invoke_O_O__O(arg_891, arg_892) } else { tmp40 = linked_889.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_888, arg_891, arg_892) }; tmp39.Invoke_O_O__O(tmp40, r__33_2) }
															if jrt.J2g_Truth(moved__34_2) { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(f__27_2)).Delete__Z()) } } } } } }
//line :155:1
							seq_716000049__20, chunk_716000050__21, count_716000051__22, i_716000052__23 = seq_716000049__20, chunk_716000050__21, count_716000051__22, lang.Numbers_Unchecked_inc_J__J_NoInit(i_716000052__23); continue L3 } else { var temp__1927000414__auto____24 any; var root_729 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_729, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_731 lang.IFn; if linked_730 == nil { ifn_731 = lang.IFn_Cast(root_729) } else { ifn_731 = nil }; var arg_732 any = seq_716000049__20; if linked_730 == nil { temp__1927000414__auto____24 = ifn_731.Invoke_O__O(arg_732) } else { temp__1927000414__auto____24 = linked_730.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_729, arg_732) }; if jrt.J2g_Truth(temp__1927000414__auto____24) { var seq_716000049__25 any = temp__1927000414__auto____24; var tmp41 any; var root_733 any = A_arbace_repr_clojure_A_const_55.GetRawRoot__O(); var linked_734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_733, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_735 lang.IFn; if linked_734 == nil { ifn_735 = lang.IFn_Cast(root_733) } else { ifn_735 = nil }; var arg_736 any = seq_716000049__25; if linked_734 == nil { tmp41 = ifn_735.Invoke_O__O(arg_736) } else { tmp41 = linked_734.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_733, arg_736) }; if jrt.J2g_Truth(tmp41) { var c__1927000678__auto____26 any; var root_737 any = A_arbace_repr_clojure_A_const_56.GetRawRoot__O(); var linked_738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_737, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_739 lang.IFn; if linked_738 == nil { ifn_739 = lang.IFn_Cast(root_737) } else { ifn_739 = nil }; var arg_740 any = seq_716000049__25; if linked_738 == nil { c__1927000678__auto____26 = ifn_739.Invoke_O__O(arg_740) } else { c__1927000678__auto____26 = linked_738.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_737, arg_740) }; var tmp42 any; var root_898 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_898, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_900 lang.IFn; if linked_899 == nil { ifn_900 = lang.IFn_Cast(root_898) } else { ifn_900 = nil }; var arg_901 any = seq_716000049__25; if linked_899 == nil { tmp42 = ifn_900.Invoke_O__O(arg_901) } else { tmp42 = linked_899.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_898, arg_901) }; seq_716000049__20, chunk_716000050__21, count_716000051__22, i_716000052__23 = tmp42, c__1927000678__auto____26, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____26))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__716000084__26 any; var root_741 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_741, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_743 lang.IFn; if linked_742 == nil { ifn_743 = lang.IFn_Cast(root_741) } else { ifn_743 = nil }; var arg_744 any = seq_716000049__25; if linked_742 == nil { vec__716000084__26 = ifn_743.Invoke_O__O(arg_744) } else { vec__716000084__26 = linked_742.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_741, arg_744) }; var dir__27 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000084__26, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__28 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000084__26, lang.RT_IntCast_J__I_NoInit(1), nil); var f__29 any; var root_902 any = A_arbace_repr_clojure_A_const_72.GetRawRoot__O(); var linked_903 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_902, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_904 lang.IFn


								if linked_903 == nil { ifn_904 = lang.IFn_Cast(root_902) } else { ifn_904 = nil }; var arg_905 any = dir__27; var arg_906 any = rel__28; if linked_903 == nil { f__29 = ifn_904.Invoke_O_O__O(arg_905, arg_906) } else { f__29 = linked_903.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_902, arg_905, arg_906) }
//line :155:1
								var parent__30 any = jrt.NN(jrt.File_Cast(f__29)).GetParentFile__File().Ref(); var siblings__31 any = lang.IFn_Cast(listing__10).Invoke_O__O(parent__30); var p__32 any = lang.IFn_Cast(plan__8).Invoke_O_O_O__O(jrt.NN(jrt.File_Cast(f__29)).GetName__String().Ref(), siblings__31, opts__3); var rel_out__33 any; var d__33 any; var tmp43 any; var root_907 any = A_arbace_repr_clojure_A_const_72.GetRawRoot__O(); var linked_908 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_907, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_909 lang.IFn






								if linked_908 == nil { ifn_909 = lang.IFn_Cast(root_907) } else { ifn_909 = nil }; var arg_910 any = rel__28; if linked_908 == nil { tmp43 = ifn_909.Invoke_O__O(arg_910) } else { tmp43 = linked_908.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_907, arg_910) }; d__33 = jrt.NN(jrt.File_Cast(tmp43)).GetParent__String().Ref(); if jrt.J2g_Truth(d__33) { rel_out__33 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_29, nil), jrt.RefArrayOf(jrt.Object_class, d__33, nil, A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__32))).Ref() } else { rel_out__33 = A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__32) }
								if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_32.Invoke_O__O(p__32)) {

									var root_992 any = A_arbace_repr_clojure_A_const_77.GetRawRoot__O(); var linked_993 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_992, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_994 lang.IFn; if linked_993 == nil { ifn_994 = lang.IFn_Cast(root_992) } else { ifn_994 = nil }; var arg_995 any = stats__11; var arg_996 any = A_arbace_repr_clojure_A_const_78.GetRawRoot__O(); var arg_997 any = A_arbace_repr_clojure_A_const_89; var arg_998 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); if linked_993 == nil { ifn_994.Invoke_O_O_O_O__O(arg_995, arg_996, arg_997, arg_998) } else { linked_993.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_992, arg_995, arg_996, arg_997, arg_998) }
									var root_1004 any = A_arbace_repr_clojure_A_const_84.GetRawRoot__O(); var linked_1005 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1004, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1006 lang.IFn; if linked_1005 == nil { ifn_1006 = lang.IFn_Cast(root_1004) } else { ifn_1006 = nil }; var tmp44 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_85.GetRawRoot__O()); var tmp45 any = A_arbace_repr_clojure_A_const_86; var arg_1007 any = tmp44.Invoke_O_O__O(tmp45, A_arbace_repr_clojure_A_const_87.Get__O()); if linked_1005 == nil { ifn_1006.Invoke_O__O(arg_1007) } else { linked_1005.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1004, arg_1007) }; var tmp46 any = A_arbace_repr_clojure_run_fn__716000087_A_New_O_O(f__29, p__32); var tmp47 *jrt.Class; var fncls__925 *jrt.Class = A_arbace_repr_clojure_run_fn__716000087_A_fn_class; if fncls__925 == nil { var fncls__925d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_95, false); A_arbace_repr_clojure_run_fn__716000087_A_fn_class = fncls__925d; tmp47 = fncls__925d } else { tmp47 = fncls__925 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp46, tmp47, nil).Invoke__O() } else {
//line :163:1
										if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_76.Invoke_O__O(p__32)) {




											if jrt.J2g_Truth(out__2) { var t__34_3 any; var root_1008 any = A_arbace_repr_clojure_A_const_72.GetRawRoot__O(); var linked_1009 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1008, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_1010 lang.IFn
												if linked_1009 == nil { ifn_1010 = lang.IFn_Cast(root_1008) } else { ifn_1010 = nil }; var arg_1011 any = out__2; var arg_1012 any = rel__28; if linked_1009 == nil { t__34_3 = ifn_1010.Invoke_O_O__O(arg_1011, arg_1012) } else { t__34_3 = linked_1009.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_1008, arg_1011, arg_1012) }
												lang.IFn_Cast(A_arbace_repr_clojure_A_const_91.GetRawRoot__O()).Invoke_O__O(t__34_3)
												lang.IFn_Cast(A_arbace_repr_clojure_A_const_90.GetRawRoot__O()).Invoke_O_O__O(f__29, t__34_3) }
											var root_926 any = A_arbace_repr_clojure_A_const_77.GetRawRoot__O(); var linked_927 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_926, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_928 lang.IFn; if linked_927 == nil { ifn_928 = lang.IFn_Cast(root_926) } else { ifn_928 = nil }; var arg_929 any = stats__11; var arg_930 any = A_arbace_repr_clojure_A_const_78.GetRawRoot__O(); var arg_931 any = A_arbace_repr_clojure_A_const_79; var arg_932 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); if linked_927 == nil { ifn_928.Invoke_O_O_O_O__O(arg_929, arg_930, arg_931, arg_932) } else { linked_927.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_926, arg_929, arg_930, arg_931, arg_932) } } else {
//line :163:1
												if A_arbace_repr_clojure_A_const_33 != nil { var s__34 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_81.GetRawRoot__O()).Invoke_O__O(f__29); var r__35 any; var tmp48 any = A_arbace_repr_clojure_run_fn__716000089_A_New_O_O_O_O_O_O(f__29, p__32, s__34, stats__11, translate_text__9, skip__5); var tmp49 *jrt.Class
													var fncls__976 /*line :163:1*/*jrt.Class = A_arbace_repr_clojure_run_fn__716000089_A_fn_class











													if fncls__976 == nil { var fncls__976d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_96, false); A_arbace_repr_clojure_run_fn__716000089_A_fn_class = fncls__976d; tmp49 = fncls__976d } else { tmp49 = fncls__976 }; r__35 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp48, tmp49, nil).Invoke__O()




													if jrt.J2g_Truth(r__35) {
														var root_1022 any = A_arbace_repr_clojure_A_const_77.GetRawRoot__O(); var linked_1023 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1022, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1024 lang.IFn; if linked_1023 == nil { ifn_1024 = lang.IFn_Cast(root_1022) } else { ifn_1024 = nil }; var arg_1025 any = stats__11; var arg_1026 any = A_arbace_repr_clojure_A_const_78.GetRawRoot__O(); var arg_1027 any; if lang.Util_Equiv_O_O__Z_NoInit(s__34, r__35) { arg_1027 = A_arbace_repr_clojure_A_const_92 } else { arg_1027 = A_arbace_repr_clojure_A_const_93 }; var arg_1028 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); if linked_1023 == nil { ifn_1024.Invoke_O_O_O_O__O(arg_1025, arg_1026, arg_1027, arg_1028) } else { linked_1023.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1022, arg_1025, arg_1026, arg_1027, arg_1028) }
														if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_26.Invoke_O__O(p__32)) { var root_1029 any = A_arbace_repr_clojure_A_const_77.GetRawRoot__O(); var linked_1030 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1029, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1031 lang.IFn; if linked_1030 == nil { ifn_1031 = lang.IFn_Cast(root_1029) } else { ifn_1031 = nil }; var arg_1032 any = stats__11; var arg_1033 any = A_arbace_repr_clojure_A_const_78.GetRawRoot__O(); var arg_1034 any = A_arbace_repr_clojure_A_const_26; var arg_1035 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); if linked_1030 == nil { ifn_1031.Invoke_O_O_O_O__O(arg_1032, arg_1033, arg_1034, arg_1035) } else { linked_1030.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1029, arg_1032, arg_1033, arg_1034, arg_1035) } }
														if jrt.J2g_Truth(out__2) { var t__36 any; var root_977 any = A_arbace_repr_clojure_A_const_72.GetRawRoot__O(); var linked_978 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_977, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_979 lang.IFn
															if linked_978 == nil { ifn_979 = lang.IFn_Cast(root_977) } else { ifn_979 = nil }; var arg_980 any = out__2; var arg_981 any = rel_out__33; if linked_978 == nil { t__36 = ifn_979.Invoke_O_O__O(arg_980, arg_981) } else { t__36 = linked_978.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_977, arg_980, arg_981) }
															lang.IFn_Cast(A_arbace_repr_clojure_A_const_91.GetRawRoot__O()).Invoke_O__O(t__36)
															lang.IFn_Cast(A_arbace_repr_clojure_A_const_88.GetRawRoot__O()).Invoke_O_O__O(t__36, r__35) } else {
//line :183:1
																var moved__36 any; var root_987 any = A_arbace_repr_clojure_A_const_44.GetRawRoot__O(); var linked_988 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_987, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_989 lang.IFn



																if linked_988 == nil { ifn_989 = lang.IFn_Cast(root_987) } else { ifn_989 = nil }; var arg_990 any = jrt.NN(jrt.File_Cast(f__29)).GetName__String().Ref(); var arg_991 any = A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__32); if linked_988 == nil { moved__36 = ifn_989.Invoke_O_O__O(arg_990, arg_991) } else { moved__36 = linked_988.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_987, arg_990, arg_991) }
																var tmp50 any; var or__1927000174__auto____37 any; var root_1040 any = A_arbace_repr_clojure_A_const_44.GetRawRoot__O(); var linked_1041 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1040, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1042 lang.IFn; if linked_1041 == nil { ifn_1042 = lang.IFn_Cast(root_1040) } else { ifn_1042 = nil }; var arg_1043 any = s__34; var arg_1044 any = r__35; if linked_1041 == nil { or__1927000174__auto____37 = ifn_1042.Invoke_O_O__O(arg_1043, arg_1044) } else { or__1927000174__auto____37 = linked_1041.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1040, arg_1043, arg_1044) }; if jrt.J2g_Truth(or__1927000174__auto____37) { tmp50 = or__1927000174__auto____37 } else { tmp50 = moved__36 }; if jrt.J2g_Truth(tmp50) {
																	var tmp51 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_88.GetRawRoot__O()); var tmp52 any; var root_1045 any = A_arbace_repr_clojure_A_const_72.GetRawRoot__O(); var linked_1046 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1045, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_1047 lang.IFn; if linked_1046 == nil { ifn_1047 = lang.IFn_Cast(root_1045) } else { ifn_1047 = nil }; var arg_1048 any = parent__30; var arg_1049 any = A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__32); if linked_1046 == nil { tmp52 = ifn_1047.Invoke_O_O__O(arg_1048, arg_1049) } else { tmp52 = linked_1046.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_1045, arg_1048, arg_1049) }; tmp51.Invoke_O_O__O(tmp52, r__35) }
																if jrt.J2g_Truth(moved__36) { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(f__29)).Delete__Z()) } } } } } }
//line :155:1
								var tmp53 any; var root_1055 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_1056 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1055, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1057 lang.IFn; if linked_1056 == nil { ifn_1057 = lang.IFn_Cast(root_1055) } else { ifn_1057 = nil }; var arg_1058 any = seq_716000049__25; if linked_1056 == nil { tmp53 = ifn_1057.Invoke_O__O(arg_1058) } else { tmp53 = linked_1056.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1055, arg_1058) }; seq_716000049__20, chunk_716000050__21, count_716000051__22, i_716000052__23 = tmp53, nil, 0, 0; continue L3 } } }; break L3 }; var tmp54 any; var root_1059 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_1060 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1059, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1061 lang.IFn; if linked_1060 == nil { ifn_1061 = lang.IFn_Cast(root_1059) } else { ifn_1061 = nil }; var arg_1062 any = seq_716000045__17; if linked_1060 == nil { tmp54 = ifn_1061.Invoke_O__O(arg_1062) } else { tmp54 = linked_1060.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1059, arg_1062) }; seq_716000045__12, chunk_716000046__13, count_716000047__14, i_716000048__15 = tmp54, nil, 0, 0; continue L1 } } }
//line :143:1
		break L1 }; var root_347 any =







	A_arbace_repr_clojure_A_const_8.GetRawRoot__O(); var linked_348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_347, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_349 lang.IFn; if linked_348 == nil { ifn_349 = lang.IFn_Cast(root_347) } else { ifn_349 = nil }; var arg_350 any = stats__11; if linked_348 == nil { return ifn_349.Invoke_O__O(arg_350) } else { return linked_348.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_347, arg_350) } }
//line :143:1
func (t *A_arbace_repr_clojure_run_A) Invoke_O_O_O_O__O(self, sources__0, out__1, opts__2 any) any {





	var root_1063 any = A_arbace_repr_clojure_A_const_94.GetRawRoot__O(); var linked_1064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1063, A_arbace_repr_clojure_run_A_fn_class); var ifn_1065 lang.IFn; if linked_1064 == nil { ifn_1065 = lang.IFn_Cast(root_1063) } else { ifn_1065 = nil }; var arg_1066 any = A_arbace_repr_clojure_A_const_95; var arg_1067 any = sources__0; var arg_1068 any = out__1; var arg_1069 any = opts__2; if linked_1064 == nil { return ifn_1065.Invoke_O_O_O_O__O(arg_1066, arg_1067, arg_1068, arg_1069) } else { return linked_1064.(*A_arbace_repr_clojure_run_A).Invoke_O_O_O_O_O__O(root_1063, arg_1066, arg_1067, arg_1068, arg_1069)
	}
}

func A_arbace_repr_clojure_run_fn__716000043_A_New() *A_arbace_repr_clojure_run_fn__716000043_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000043_A{}; t.Ctor(); return t }
//line :153:1
func (t *A_arbace_repr_clojure_run_fn__716000043_A) Ctor() {}
//line :153:1
func (t *A_arbace_repr_clojure_run_fn__716000043_A) Invoke_O_O__O(self, d__1 any) any { var root_334 any = A_arbace_repr_clojure_A_const_69.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_334, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_336 lang.IFn; if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = jrt.NN(jrt.File_Cast(d__1)).List__String1().Ref(); if linked_335 == nil { return ifn_336.Invoke_O__O(arg_337) } else { return linked_335.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_334, arg_337) } }












func A_arbace_repr_clojure_run_fn__716000060_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_run_fn__716000060_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000060_A{}; t.Ctor_O_O(p0, p1); return t }
//line :166:1
func (t *A_arbace_repr_clojure_run_fn__716000060_A) Ctor_O_O(c__f, c__p any) { t.F_f = c__f; t.F_p = c__p }
//line :166:1
func (t *A_arbace_repr_clojure_run_fn__716000060_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_74.GetRawRoot__O()); var tmp3 any; var root_408 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_408, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_410 lang.IFn; if linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; var arg_411 any; var t_ any = t.F_f; t.F_f = nil; arg_411 = t_; if linked_409 == nil { tmp3 = ifn_410.Invoke_O__O(arg_411) } else { tmp3 = linked_409.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_408, arg_411) }; var tmp4 any = tmp3; var tmp5 *lang.Keyword = A_arbace_repr_clojure_A_const_32; var tmp6 any; var t__2 any = t.F_p; t.F_p = nil; tmp6 = t__2; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_97, tmp4, Lit_44, tmp5.Invoke_O__O(tmp6)) }; return nil }(); var root_419 any = A_arbace_repr_clojure_A_const_75.GetRawRoot__O(); var linked_420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_419, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_421 lang.IFn; if linked_420 == nil { ifn_421 = lang.IFn_Cast(root_419) } else { ifn_421 = nil }; if linked_420 == nil { ifn_421.Invoke__O() } else { linked_420.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_419) }; if tmp7 != nil { panic(tmp7) }; return tmp1 }
//line :166:1
func A_arbace_repr_clojure_run_fn__716000069_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_run_fn__716000069_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000069_A{}; t.Ctor_O_O(p0, p1); return t }
//line :166:1
func (t *A_arbace_repr_clojure_run_fn__716000069_A) Ctor_O_O(c__f, c__p any) { t.F_f = c__f; t.F_p = c__p }
//line :166:1
func (t *A_arbace_repr_clojure_run_fn__716000069_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_74.GetRawRoot__O()); var tmp3 any; var root_565 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_566 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_565, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_567 lang.IFn; if linked_566 == nil { ifn_567 = lang.IFn_Cast(root_565) } else { ifn_567 = nil }; var arg_568 any; var t_ any = t.F_f; t.F_f = nil; arg_568 = t_; if linked_566 == nil { tmp3 = ifn_567.Invoke_O__O(arg_568) } else { tmp3 = linked_566.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_565, arg_568) }; var tmp4 any = tmp3; var tmp5 *lang.Keyword = A_arbace_repr_clojure_A_const_32; var tmp6 any; var t__2 any = t.F_p; t.F_p = nil; tmp6 = t__2; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_97, tmp4, Lit_44, tmp5.Invoke_O__O(tmp6)) }; return nil }(); var root_576 any = A_arbace_repr_clojure_A_const_75.GetRawRoot__O(); var linked_577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_576, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_578 lang.IFn; if linked_577 == nil { ifn_578 = lang.IFn_Cast(root_576) } else { ifn_578 = nil }; if linked_577 == nil { ifn_578.Invoke__O() } else { linked_577.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_576) }; if tmp7 != nil { panic(tmp7) }; return tmp1 }
//line :166:1
func A_arbace_repr_clojure_run_fn__716000078_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_run_fn__716000078_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000078_A{}; t.Ctor_O_O(p0, p1); return t }
//line :166:1
func (t *A_arbace_repr_clojure_run_fn__716000078_A) Ctor_O_O(c__f, c__p any) { t.F_f = c__f; t.F_p = c__p }
//line :166:1
func (t *A_arbace_repr_clojure_run_fn__716000078_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_74.GetRawRoot__O()); var tmp3 any; var root_754 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_755 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_754, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_756 lang.IFn; if linked_755 == nil { ifn_756 = lang.IFn_Cast(root_754) } else { ifn_756 = nil }; var arg_757 any; var t_ any = t.F_f; t.F_f = nil; arg_757 = t_; if linked_755 == nil { tmp3 = ifn_756.Invoke_O__O(arg_757) } else { tmp3 = linked_755.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_754, arg_757) }; var tmp4 any = tmp3; var tmp5 *lang.Keyword = A_arbace_repr_clojure_A_const_32; var tmp6 any; var t__2 any = t.F_p; t.F_p = nil; tmp6 = t__2; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_97, tmp4, Lit_44, tmp5.Invoke_O__O(tmp6)) }; return nil }(); var root_765 any = A_arbace_repr_clojure_A_const_75.GetRawRoot__O(); var linked_766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_765, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_767 lang.IFn; if linked_766 == nil { ifn_767 = lang.IFn_Cast(root_765) } else { ifn_767 = nil }; if linked_766 == nil { ifn_767.Invoke__O() } else { linked_766.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_765) }; if tmp7 != nil { panic(tmp7) }; return tmp1 }
//line :166:1
func A_arbace_repr_clojure_run_fn__716000087_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_run_fn__716000087_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000087_A{}; t.Ctor_O_O(p0, p1); return t }
//line :166:1
func (t *A_arbace_repr_clojure_run_fn__716000087_A) Ctor_O_O(c__f, c__p any) { t.F_f = c__f; t.F_p = c__p }
//line :166:1
func (t *A_arbace_repr_clojure_run_fn__716000087_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_74.GetRawRoot__O()); var tmp3 any; var root_911 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_912 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_911, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_913 lang.IFn; if linked_912 == nil { ifn_913 = lang.IFn_Cast(root_911) } else { ifn_913 = nil }; var arg_914 any; var t_ any = t.F_f; t.F_f = nil; arg_914 = t_; if linked_912 == nil { tmp3 = ifn_913.Invoke_O__O(arg_914) } else { tmp3 = linked_912.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_911, arg_914) }; var tmp4 any = tmp3; var tmp5 *lang.Keyword = A_arbace_repr_clojure_A_const_32; var tmp6 any; var t__2 any = t.F_p; t.F_p = nil; tmp6 = t__2; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_97, tmp4, Lit_44, tmp5.Invoke_O__O(tmp6)) }; return nil }(); var root_922 any = A_arbace_repr_clojure_A_const_75.GetRawRoot__O(); var linked_923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_922, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_924 lang.IFn; if linked_923 == nil { ifn_924 = lang.IFn_Cast(root_922) } else { ifn_924 = nil }; if linked_923 == nil { ifn_924.Invoke__O() } else { linked_923.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_922) }; if tmp7 != nil { panic(tmp7) }; return tmp1 }








func A_arbace_repr_clojure_run_fn__716000062_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_repr_clojure_run_fn__716000062_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000062_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :175:1
func (t *A_arbace_repr_clojure_run_fn__716000062_A) Ctor_O_O_O_O_O_O(c__f, c__stats, c__p, c__s, c__translate_text, c__skip any) { t.F_f = c__f; t.F_stats = c__stats; t.F_p = c__p; t.F_s = c__s; t.F_translate_text = c__translate_text; t.F_skip = c__skip }
//line :175:1
func (t *A_arbace_repr_clojure_run_fn__716000062_A) Invoke_O__O(self any) any { var tmp1 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var t_ any = t.F_translate_text; t.F_translate_text = nil; tmp2 = t_; var tmp3 lang.IFn = lang.IFn_Cast(tmp2); var tmp4 any; var t__2 any = t.F_s; t.F_s = nil; tmp4 = t__2; var tmp5 any = tmp4; var tmp6 any; var t__3 any = t.F_p; t.F_p = nil; tmp6 = t__3; var tmp7 any = tmp6; var tmp8 any; var root_434 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_434, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = t.F_f; if linked_435 == nil { tmp8 = ifn_436.Invoke_O__O(arg_437) } else { tmp8 = linked_435.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_434, arg_437) }; var tmp9 any = tmp8; var tmp10 any; var t__4 any = t.F_skip; t.F_skip = nil; tmp10 = t__4; tmp1 = tmp3.Invoke_O_O_O_O__O(tmp5, tmp7, tmp9, tmp10) }; return nil }(); if tmp11 != nil { if jrt.Exception_InstanceOf(tmp11) { var e__3 jrt.Exception_I = jrt.Exception_Cast(tmp11); var root_438 any = A_arbace_repr_clojure_A_const_77.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_438, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_440 lang.IFn

	if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any; var t__5 any = t.F_stats; t.F_stats = nil; arg_441 = t__5; var arg_442 any = A_arbace_repr_clojure_A_const_78.GetRawRoot__O(); var arg_443 any = A_arbace_repr_clojure_A_const_82; var arg_444 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); if linked_439 == nil { ifn_440.Invoke_O_O_O_O__O(arg_441, arg_442, arg_443, arg_444) } else { linked_439.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_438, arg_441, arg_442, arg_443, arg_444) }
	var root_469 any = A_arbace_repr_clojure_A_const_84.GetRawRoot__O(); var linked_470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_469, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_471 lang.IFn; if linked_470 == nil { ifn_471 = lang.IFn_Cast(root_469) } else { ifn_471 = nil }; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_85.GetRawRoot__O()); var tmp13 any = A_arbace_repr_clojure_A_const_86; var arg_472 any = tmp12.Invoke_O_O__O(tmp13, A_arbace_repr_clojure_A_const_87.Get__O()); if linked_470 == nil { ifn_471.Invoke_O__O(arg_472) } else { linked_470.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_469, arg_472) }; var tmp14 any = A_arbace_repr_clojure_run_fn__716000062_fn__716000063_A_New_O_O(e__3, t.F_f); var tmp15 *jrt.Class; var fncls__463 *jrt.Class = A_arbace_repr_clojure_run_fn__716000062_fn__716000063_A_fn_class; if fncls__463 == nil { var fncls__463d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_98, false); A_arbace_repr_clojure_run_fn__716000062_fn__716000063_A_fn_class = fncls__463d; tmp15 = fncls__463d } else { tmp15 = fncls__463 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil).Invoke__O()
//line :175:1
	tmp1 = nil } else { panic(tmp11) } }; return tmp1 }
//line :175:1
func A_arbace_repr_clojure_run_fn__716000071_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_repr_clojure_run_fn__716000071_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000071_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :175:1
func (t *A_arbace_repr_clojure_run_fn__716000071_A) Ctor_O_O_O_O_O_O(c__f, c__p, c__s, c__stats, c__translate_text, c__skip any) { t.F_f = c__f; t.F_p = c__p; t.F_s = c__s; t.F_stats = c__stats; t.F_translate_text = c__translate_text; t.F_skip = c__skip }
//line :175:1
func (t *A_arbace_repr_clojure_run_fn__716000071_A) Invoke_O__O(self any) any { var tmp1 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var t_ any = t.F_translate_text; t.F_translate_text = nil; tmp2 = t_; var tmp3 lang.IFn = lang.IFn_Cast(tmp2); var tmp4 any; var t__2 any = t.F_s; t.F_s = nil; tmp4 = t__2; var tmp5 any = tmp4; var tmp6 any; var t__3 any = t.F_p; t.F_p = nil; tmp6 = t__3; var tmp7 any = tmp6; var tmp8 any; var root_591 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_592 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_591, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_593 lang.IFn; if linked_592 == nil { ifn_593 = lang.IFn_Cast(root_591) } else { ifn_593 = nil }; var arg_594 any = t.F_f; if linked_592 == nil { tmp8 = ifn_593.Invoke_O__O(arg_594) } else { tmp8 = linked_592.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_591, arg_594) }; var tmp9 any = tmp8; var tmp10 any; var t__4 any = t.F_skip; t.F_skip = nil; tmp10 = t__4; tmp1 = tmp3.Invoke_O_O_O_O__O(tmp5, tmp7, tmp9, tmp10) }; return nil }(); if tmp11 != nil { if jrt.Exception_InstanceOf(tmp11) { var e__3 jrt.Exception_I = jrt.Exception_Cast(tmp11); var root_595 any = A_arbace_repr_clojure_A_const_77.GetRawRoot__O(); var linked_596 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_595, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_597 lang.IFn

	if linked_596 == nil { ifn_597 = lang.IFn_Cast(root_595) } else { ifn_597 = nil }; var arg_598 any; var t__5 any = t.F_stats; t.F_stats = nil; arg_598 = t__5; var arg_599 any = A_arbace_repr_clojure_A_const_78.GetRawRoot__O(); var arg_600 any = A_arbace_repr_clojure_A_const_82; var arg_601 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); if linked_596 == nil { ifn_597.Invoke_O_O_O_O__O(arg_598, arg_599, arg_600, arg_601) } else { linked_596.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_595, arg_598, arg_599, arg_600, arg_601) }
	var root_626 any = A_arbace_repr_clojure_A_const_84.GetRawRoot__O(); var linked_627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_626, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_628 lang.IFn; if linked_627 == nil { ifn_628 = lang.IFn_Cast(root_626) } else { ifn_628 = nil }; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_85.GetRawRoot__O()); var tmp13 any = A_arbace_repr_clojure_A_const_86; var arg_629 any = tmp12.Invoke_O_O__O(tmp13, A_arbace_repr_clojure_A_const_87.Get__O()); if linked_627 == nil { ifn_628.Invoke_O__O(arg_629) } else { linked_627.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_626, arg_629) }; var tmp14 any = A_arbace_repr_clojure_run_fn__716000071_fn__716000072_A_New_O_O(e__3, t.F_f); var tmp15 *jrt.Class; var fncls__620 *jrt.Class = A_arbace_repr_clojure_run_fn__716000071_fn__716000072_A_fn_class; if fncls__620 == nil { var fncls__620d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_100, false); A_arbace_repr_clojure_run_fn__716000071_fn__716000072_A_fn_class = fncls__620d; tmp15 = fncls__620d } else { tmp15 = fncls__620 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil).Invoke__O()
//line :175:1
	tmp1 = nil } else { panic(tmp11) } }; return tmp1 }
//line :175:1
func A_arbace_repr_clojure_run_fn__716000080_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_repr_clojure_run_fn__716000080_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000080_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :175:1
func (t *A_arbace_repr_clojure_run_fn__716000080_A) Ctor_O_O_O_O_O_O(c__f, c__p, c__s, c__stats, c__translate_text, c__skip any) { t.F_f = c__f; t.F_p = c__p; t.F_s = c__s; t.F_stats = c__stats; t.F_translate_text = c__translate_text; t.F_skip = c__skip }
//line :175:1
func (t *A_arbace_repr_clojure_run_fn__716000080_A) Invoke_O__O(self any) any { var tmp1 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var t_ any = t.F_translate_text; t.F_translate_text = nil; tmp2 = t_; var tmp3 lang.IFn = lang.IFn_Cast(tmp2); var tmp4 any; var t__2 any = t.F_s; t.F_s = nil; tmp4 = t__2; var tmp5 any = tmp4; var tmp6 any; var t__3 any = t.F_p; t.F_p = nil; tmp6 = t__3; var tmp7 any = tmp6; var tmp8 any; var root_780 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_781 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_780, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_782 lang.IFn; if linked_781 == nil { ifn_782 = lang.IFn_Cast(root_780) } else { ifn_782 = nil }; var arg_783 any = t.F_f; if linked_781 == nil { tmp8 = ifn_782.Invoke_O__O(arg_783) } else { tmp8 = linked_781.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_780, arg_783) }; var tmp9 any = tmp8; var tmp10 any; var t__4 any = t.F_skip; t.F_skip = nil; tmp10 = t__4; tmp1 = tmp3.Invoke_O_O_O_O__O(tmp5, tmp7, tmp9, tmp10) }; return nil }(); if tmp11 != nil { if jrt.Exception_InstanceOf(tmp11) { var e__3 jrt.Exception_I = jrt.Exception_Cast(tmp11); var root_784 any = A_arbace_repr_clojure_A_const_77.GetRawRoot__O(); var linked_785 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_784, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_786 lang.IFn

	if linked_785 == nil { ifn_786 = lang.IFn_Cast(root_784) } else { ifn_786 = nil }; var arg_787 any; var t__5 any = t.F_stats; t.F_stats = nil; arg_787 = t__5; var arg_788 any = A_arbace_repr_clojure_A_const_78.GetRawRoot__O(); var arg_789 any = A_arbace_repr_clojure_A_const_82; var arg_790 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); if linked_785 == nil { ifn_786.Invoke_O_O_O_O__O(arg_787, arg_788, arg_789, arg_790) } else { linked_785.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_784, arg_787, arg_788, arg_789, arg_790) }
	var root_815 any = A_arbace_repr_clojure_A_const_84.GetRawRoot__O(); var linked_816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_815, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_817 lang.IFn; if linked_816 == nil { ifn_817 = lang.IFn_Cast(root_815) } else { ifn_817 = nil }; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_85.GetRawRoot__O()); var tmp13 any = A_arbace_repr_clojure_A_const_86; var arg_818 any = tmp12.Invoke_O_O__O(tmp13, A_arbace_repr_clojure_A_const_87.Get__O()); if linked_816 == nil { ifn_817.Invoke_O__O(arg_818) } else { linked_816.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_815, arg_818) }; var tmp14 any = A_arbace_repr_clojure_run_fn__716000080_fn__716000081_A_New_O_O(e__3, t.F_f); var tmp15 *jrt.Class; var fncls__809 *jrt.Class = A_arbace_repr_clojure_run_fn__716000080_fn__716000081_A_fn_class; if fncls__809 == nil { var fncls__809d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_101, false); A_arbace_repr_clojure_run_fn__716000080_fn__716000081_A_fn_class = fncls__809d; tmp15 = fncls__809d } else { tmp15 = fncls__809 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil).Invoke__O()
//line :175:1
	tmp1 = nil } else { panic(tmp11) } }; return tmp1 }
//line :175:1
func A_arbace_repr_clojure_run_fn__716000089_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_repr_clojure_run_fn__716000089_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000089_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :175:1
func (t *A_arbace_repr_clojure_run_fn__716000089_A) Ctor_O_O_O_O_O_O(c__f, c__p, c__s, c__stats, c__translate_text, c__skip any) { t.F_f = c__f; t.F_p = c__p; t.F_s = c__s; t.F_stats = c__stats; t.F_translate_text = c__translate_text; t.F_skip = c__skip }
//line :175:1
func (t *A_arbace_repr_clojure_run_fn__716000089_A) Invoke_O__O(self any) any { var tmp1 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var t_ any = t.F_translate_text; t.F_translate_text = nil; tmp2 = t_; var tmp3 lang.IFn = lang.IFn_Cast(tmp2); var tmp4 any; var t__2 any = t.F_s; t.F_s = nil; tmp4 = t__2; var tmp5 any = tmp4; var tmp6 any; var t__3 any = t.F_p; t.F_p = nil; tmp6 = t__3; var tmp7 any = tmp6; var tmp8 any; var root_937 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_938 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_937, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_939 lang.IFn; if linked_938 == nil { ifn_939 = lang.IFn_Cast(root_937) } else { ifn_939 = nil }; var arg_940 any = t.F_f; if linked_938 == nil { tmp8 = ifn_939.Invoke_O__O(arg_940) } else { tmp8 = linked_938.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_937, arg_940) }; var tmp9 any = tmp8; var tmp10 any; var t__4 any = t.F_skip; t.F_skip = nil; tmp10 = t__4; tmp1 = tmp3.Invoke_O_O_O_O__O(tmp5, tmp7, tmp9, tmp10) }; return nil }(); if tmp11 != nil { if jrt.Exception_InstanceOf(tmp11) { var e__3 jrt.Exception_I = jrt.Exception_Cast(tmp11); var root_941 any = A_arbace_repr_clojure_A_const_77.GetRawRoot__O(); var linked_942 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_941, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_943 lang.IFn

	if linked_942 == nil { ifn_943 = lang.IFn_Cast(root_941) } else { ifn_943 = nil }; var arg_944 any; var t__5 any = t.F_stats; t.F_stats = nil; arg_944 = t__5; var arg_945 any = A_arbace_repr_clojure_A_const_78.GetRawRoot__O(); var arg_946 any = A_arbace_repr_clojure_A_const_82; var arg_947 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); if linked_942 == nil { ifn_943.Invoke_O_O_O_O__O(arg_944, arg_945, arg_946, arg_947) } else { linked_942.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_941, arg_944, arg_945, arg_946, arg_947) }
	var root_972 any = A_arbace_repr_clojure_A_const_84.GetRawRoot__O(); var linked_973 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_972, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_974 lang.IFn; if linked_973 == nil { ifn_974 = lang.IFn_Cast(root_972) } else { ifn_974 = nil }; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_85.GetRawRoot__O()); var tmp13 any = A_arbace_repr_clojure_A_const_86; var arg_975 any = tmp12.Invoke_O_O__O(tmp13, A_arbace_repr_clojure_A_const_87.Get__O()); if linked_973 == nil { ifn_974.Invoke_O__O(arg_975) } else { linked_973.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_972, arg_975) }; var tmp14 any = A_arbace_repr_clojure_run_fn__716000089_fn__716000090_A_New_O_O(e__3, t.F_f); var tmp15 *jrt.Class; var fncls__966 *jrt.Class = A_arbace_repr_clojure_run_fn__716000089_fn__716000090_A_fn_class; if fncls__966 == nil { var fncls__966d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_102, false); A_arbace_repr_clojure_run_fn__716000089_fn__716000090_A_fn_class = fncls__966d; tmp15 = fncls__966d } else { tmp15 = fncls__966 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil).Invoke__O()
//line :175:1
	tmp1 = nil } else { panic(tmp11) } }; return tmp1 }


func A_arbace_repr_clojure_run_fn__716000062_fn__716000063_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_run_fn__716000062_fn__716000063_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000062_fn__716000063_A{}; t.Ctor_O_O(p0, p1); return t }
//line :178:1
func (t *A_arbace_repr_clojure_run_fn__716000062_fn__716000063_A) Ctor_O_O(c__e, c__f any) { t.F_e = c__e; t.F_f = c__f }
//line :178:1
func (t *A_arbace_repr_clojure_run_fn__716000062_fn__716000063_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_74.GetRawRoot__O()); var tmp3 any; var root_445 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_446 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_445, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_447 lang.IFn; if linked_446 == nil { ifn_447 = lang.IFn_Cast(root_445) } else { ifn_447 = nil }; var arg_448 any; var t_ any = t.F_f; t.F_f = nil; arg_448 = t_; if linked_446 == nil { tmp3 = ifn_447.Invoke_O__O(arg_448) } else { tmp3 = linked_446.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_445, arg_448) }; var tmp4 any = tmp3; var tmp5 any; var root_449 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var linked_450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_449, aot_arbace_core.A_arbace_core_ex_message_A_fn_class); var ifn_451 lang.IFn; if linked_450 == nil { ifn_451 = lang.IFn_Cast(root_449) } else { ifn_451 = nil }; var arg_452 any; var t__2 any = t.F_e; t.F_e = nil; arg_452 = t__2; if linked_450 == nil { tmp5 = ifn_451.Invoke_O__O(arg_452) } else { tmp5 = linked_450.(*aot_arbace_core.A_arbace_core_ex_message_A).Invoke_O_O__O(root_449, arg_452) }; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_99, tmp4, Lit_44, tmp5) }; return nil }(); var root_460 any = A_arbace_repr_clojure_A_const_75.GetRawRoot__O(); var linked_461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_460, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_462 lang.IFn; if linked_461 == nil { ifn_462 = lang.IFn_Cast(root_460) } else { ifn_462 = nil }; if linked_461 == nil { ifn_462.Invoke__O() } else { linked_461.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_460) }; if tmp6 != nil { panic(tmp6) }; return tmp1 }
//line :178:1
func A_arbace_repr_clojure_run_fn__716000071_fn__716000072_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_run_fn__716000071_fn__716000072_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000071_fn__716000072_A{}; t.Ctor_O_O(p0, p1); return t }
//line :178:1
func (t *A_arbace_repr_clojure_run_fn__716000071_fn__716000072_A) Ctor_O_O(c__e, c__f any) { t.F_e = c__e; t.F_f = c__f }
//line :178:1
func (t *A_arbace_repr_clojure_run_fn__716000071_fn__716000072_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_74.GetRawRoot__O()); var tmp3 any; var root_602 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_602, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_604 lang.IFn; if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any; var t_ any = t.F_f; t.F_f = nil; arg_605 = t_; if linked_603 == nil { tmp3 = ifn_604.Invoke_O__O(arg_605) } else { tmp3 = linked_603.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_602, arg_605) }; var tmp4 any = tmp3; var tmp5 any; var root_606 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_ex_message_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any; var t__2 any = t.F_e; t.F_e = nil; arg_609 = t__2; if linked_607 == nil { tmp5 = ifn_608.Invoke_O__O(arg_609) } else { tmp5 = linked_607.(*aot_arbace_core.A_arbace_core_ex_message_A).Invoke_O_O__O(root_606, arg_609) }; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_99, tmp4, Lit_44, tmp5) }; return nil }(); var root_617 any = A_arbace_repr_clojure_A_const_75.GetRawRoot__O(); var linked_618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_617, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_619 lang.IFn; if linked_618 == nil { ifn_619 = lang.IFn_Cast(root_617) } else { ifn_619 = nil }; if linked_618 == nil { ifn_619.Invoke__O() } else { linked_618.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_617) }; if tmp6 != nil { panic(tmp6) }; return tmp1 }
//line :178:1
func A_arbace_repr_clojure_run_fn__716000080_fn__716000081_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_run_fn__716000080_fn__716000081_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000080_fn__716000081_A{}; t.Ctor_O_O(p0, p1); return t }
//line :178:1
func (t *A_arbace_repr_clojure_run_fn__716000080_fn__716000081_A) Ctor_O_O(c__e, c__f any) { t.F_e = c__e; t.F_f = c__f }
//line :178:1
func (t *A_arbace_repr_clojure_run_fn__716000080_fn__716000081_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_74.GetRawRoot__O()); var tmp3 any; var root_791 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_792 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_791, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_793 lang.IFn; if linked_792 == nil { ifn_793 = lang.IFn_Cast(root_791) } else { ifn_793 = nil }; var arg_794 any; var t_ any = t.F_f; t.F_f = nil; arg_794 = t_; if linked_792 == nil { tmp3 = ifn_793.Invoke_O__O(arg_794) } else { tmp3 = linked_792.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_791, arg_794) }; var tmp4 any = tmp3; var tmp5 any; var root_795 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var linked_796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_795, aot_arbace_core.A_arbace_core_ex_message_A_fn_class); var ifn_797 lang.IFn; if linked_796 == nil { ifn_797 = lang.IFn_Cast(root_795) } else { ifn_797 = nil }; var arg_798 any; var t__2 any = t.F_e; t.F_e = nil; arg_798 = t__2; if linked_796 == nil { tmp5 = ifn_797.Invoke_O__O(arg_798) } else { tmp5 = linked_796.(*aot_arbace_core.A_arbace_core_ex_message_A).Invoke_O_O__O(root_795, arg_798) }; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_99, tmp4, Lit_44, tmp5) }; return nil }(); var root_806 any = A_arbace_repr_clojure_A_const_75.GetRawRoot__O(); var linked_807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_806, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_808 lang.IFn; if linked_807 == nil { ifn_808 = lang.IFn_Cast(root_806) } else { ifn_808 = nil }; if linked_807 == nil { ifn_808.Invoke__O() } else { linked_807.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_806) }; if tmp6 != nil { panic(tmp6) }; return tmp1 }
//line :178:1
func A_arbace_repr_clojure_run_fn__716000089_fn__716000090_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_run_fn__716000089_fn__716000090_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000089_fn__716000090_A{}; t.Ctor_O_O(p0, p1); return t }
//line :178:1
func (t *A_arbace_repr_clojure_run_fn__716000089_fn__716000090_A) Ctor_O_O(c__e, c__f any) { t.F_e = c__e; t.F_f = c__f }
//line :178:1
func (t *A_arbace_repr_clojure_run_fn__716000089_fn__716000090_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_74.GetRawRoot__O()); var tmp3 any; var root_948 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_949 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_948, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_950 lang.IFn; if linked_949 == nil { ifn_950 = lang.IFn_Cast(root_948) } else { ifn_950 = nil }; var arg_951 any; var t_ any = t.F_f; t.F_f = nil; arg_951 = t_; if linked_949 == nil { tmp3 = ifn_950.Invoke_O__O(arg_951) } else { tmp3 = linked_949.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_948, arg_951) }; var tmp4 any = tmp3; var tmp5 any; var root_952 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var linked_953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_952, aot_arbace_core.A_arbace_core_ex_message_A_fn_class); var ifn_954 lang.IFn; if linked_953 == nil { ifn_954 = lang.IFn_Cast(root_952) } else { ifn_954 = nil }; var arg_955 any; var t__2 any = t.F_e; t.F_e = nil; arg_955 = t__2; if linked_953 == nil { tmp5 = ifn_954.Invoke_O__O(arg_955) } else { tmp5 = linked_953.(*aot_arbace_core.A_arbace_core_ex_message_A).Invoke_O_O__O(root_952, arg_955) }; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_99, tmp4, Lit_44, tmp5) }; return nil }(); var root_963 any = A_arbace_repr_clojure_A_const_75.GetRawRoot__O(); var linked_964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_963, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_965 lang.IFn; if linked_964 == nil { ifn_965 = lang.IFn_Cast(root_963) } else { ifn_965 = nil }; if linked_964 == nil { ifn_965.Invoke__O() } else { linked_964.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_963) }; if tmp6 != nil { panic(tmp6) }; return tmp1 }














func A_arbace_repr_clojure_tree_A_New() *A_arbace_repr_clojure_tree_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_tree_A{}; t.Ctor(); return t }
//line :193:1
func (t *A_arbace_repr_clojure_tree_A) Ctor() {}
//line :193:1
func (t *A_arbace_repr_clojure_tree_A) Invoke_O_O__O(self, sources__0 any) any {


	var root_1177 any = A_arbace_repr_clojure_A_const_96.GetRawRoot__O(); var linked_1178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1177, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1179 lang.IFn; if linked_1178 == nil { ifn_1179 = lang.IFn_Cast(root_1177) } else { ifn_1179 = nil }; var arg_1180 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_97.GetRawRoot__O()).Invoke__O(); var arg_1181 any; var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_repr_clojure_tree_iter__716000094__716000100_A_New(); var tmp2 *jrt.Class; var fncls__1176 *jrt.Class = A_arbace_repr_clojure_tree_iter__716000094__716000100_A_fn_class
	if fncls__1176 == nil { var fncls__1176d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_120, false); A_arbace_repr_clojure_tree_iter__716000094__716000100_A_fn_class = fncls__1176d; tmp2 = fncls__1176d } else { tmp2 = fncls__1176 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_1181 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(sources__0)
//line :196:1
	if linked_1178 == nil { return ifn_1179.Invoke_O_O__O(arg_1180, arg_1181) } else { return linked_1178.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1177, arg_1180, arg_1181) } }
func A_arbace_repr_clojure_tree_iter__716000094__716000100_A_New() *A_arbace_repr_clojure_tree_iter__716000094__716000100_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_tree_iter__716000094__716000100_A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_repr_clojure_tree_iter__716000094__716000100_A) Ctor() {}
//line :197:1
func (t *A_arbace_repr_clojure_tree_iter__716000094__716000100_A) Invoke_O_O__O(self, s__716000095__1 any) any { var tmp1 any = A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_A_New_O_O(s__716000095__1, self); var tmp2 *jrt.Class; var fncls__1175 *jrt.Class = A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_A_fn_class; if fncls__1175 == nil { var fncls__1175d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_121, false); A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_A_fn_class = fncls__1175d; tmp2 = fncls__1175d } else { tmp2 = fncls__1175 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :197:1
func A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_A{}; t.Ctor_O_O(p0, p1); return t }
//line :197:1
func (t *A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_A) Ctor_O_O(c__s__716000095, c__iter__716000094 any) { t.F_s__716000095 = c__s__716000095; t.F_iter__716000094 = c__iter__716000094 }
//line :197:1
func (t *A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_A) Invoke_O__O(self any) any { { var s__716000095__1 any; var t_ any = t.F_s__716000095; t.F_s__716000095 = nil; s__716000095__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1073 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_1074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1073, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1075 lang.IFn; if linked_1074 == nil { ifn_1075 = lang.IFn_Cast(root_1073) } else { ifn_1075 = nil }; var arg_1076 any = s__716000095__1; if linked_1074 == nil { temp__1927000414__auto____2 = ifn_1075.Invoke_O__O(arg_1076) } else { temp__1927000414__auto____2 = linked_1074.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1073, arg_1076) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var src__4 any; var root_1077 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_1078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1077, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1079 lang.IFn; if linked_1078 == nil { ifn_1079 = lang.IFn_Cast(root_1077) } else { ifn_1079 = nil }; var arg_1080 any = xs__1927001018__auto____3; if linked_1078 == nil { src__4 = ifn_1079.Invoke_O__O(arg_1080) } else { src__4 = linked_1078.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1077, arg_1080) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_iter__716000096__716000102_A_New(); var tmp2 *jrt.Class; var fncls__1149 *jrt.Class = A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_iter__716000096__716000102_A_fn_class; if fncls__1149 == nil { var fncls__1149d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_122, false); A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_iter__716000096__716000102_A_fn_class = fncls__1149d; tmp2 = fncls__1149d } else { tmp2 = fncls__1149 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_1158 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_1159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1158, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1160 lang.IFn; if linked_1159 == nil { ifn_1160 = lang.IFn_Cast(root_1158) } else { ifn_1160 = nil }; var arg_1161 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var root_1154 any = A_arbace_repr_clojure_A_const_73.GetRawRoot__O(); var linked_1155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1154, A_arbace_repr_clojure_files_A_fn_class); var ifn_1156 lang.IFn; if linked_1155 == nil { ifn_1156 = lang.IFn_Cast(root_1154) } else { ifn_1156 = nil }; var arg_1157 any; var root_1150 any = A_arbace_repr_clojure_A_const_72.GetRawRoot__O(); var linked_1151 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1150, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_1152 lang.IFn; if linked_1151 == nil { ifn_1152 = lang.IFn_Cast(root_1150) } else { ifn_1152 = nil }; var arg_1153 any = src__4; if linked_1151 == nil { arg_1157 = ifn_1152.Invoke_O__O(arg_1153) } else { arg_1157 = linked_1151.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_1150, arg_1153) }; if linked_1155 == nil { tmp4 = ifn_1156.Invoke_O__O(arg_1157) } else { tmp4 = linked_1155.(*A_arbace_repr_clojure_files_A).Invoke_O_O__O(root_1154, arg_1157) }; arg_1161 = tmp3.Invoke_O__O(tmp4); if linked_1159 == nil { fs__1927001036__auto____6 = ifn_1160.Invoke_O__O(arg_1161) } else { fs__1927001036__auto____6 = linked_1159.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1158, arg_1161) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_1166 any = A_arbace_repr_clojure_A_const_98.GetRawRoot__O(); var linked_1167 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1166, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1168 lang.IFn; if linked_1167 == nil { ifn_1168 = lang.IFn_Cast(root_1166) } else { ifn_1168 = nil }; var arg_1169 any = fs__1927001036__auto____6; var arg_1170 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__716000094); var tmp6 any; var root_1162 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_1163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1162, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1164 lang.IFn; if linked_1163 == nil { ifn_1164 = lang.IFn_Cast(root_1162) } else { ifn_1164 = nil }; var arg_1165 any = s__716000095__1; if linked_1163 == nil { tmp6 = ifn_1164.Invoke_O__O(arg_1165) } else { tmp6 = linked_1163.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1162, arg_1165) }; arg_1170 = tmp5.Invoke_O__O(tmp6); if linked_1167 == nil { return ifn_1168.Invoke_O_O__O(arg_1169, arg_1170) } else { return linked_1167.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1166, arg_1169, arg_1170) } } else { var tmp7 any; var root_1171 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_1172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1171, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1173 lang.IFn; if linked_1172 == nil { ifn_1173 = lang.IFn_Cast(root_1171) } else { ifn_1173 = nil }; var arg_1174 any = s__716000095__1; if linked_1172 == nil { tmp7 = ifn_1173.Invoke_O__O(arg_1174) } else { tmp7 = linked_1172.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1171, arg_1174) }; s__716000095__1 = tmp7; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :197:1
func A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_iter__716000096__716000102_A_New() *A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_iter__716000096__716000102_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_iter__716000096__716000102_A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_iter__716000096__716000102_A) Ctor() {}
//line :197:1
func (t *A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_iter__716000096__716000102_A) Invoke_O_O__O(self, s__716000097__1 any) any { var tmp1 any = A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_iter__716000096__716000102_fn__716000103_A_New_O_O(self, s__716000097__1); var tmp2 *jrt.Class; var fncls__1148 *jrt.Class = A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_iter__716000096__716000102_fn__716000103_A_fn_class; if fncls__1148 == nil { var fncls__1148d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_123, false); A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_iter__716000096__716000102_fn__716000103_A_fn_class = fncls__1148d; tmp2 = fncls__1148d } else { tmp2 = fncls__1148 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :197:1
func A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_iter__716000096__716000102_fn__716000103_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_iter__716000096__716000102_fn__716000103_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_iter__716000096__716000102_fn__716000103_A{}; t.Ctor_O_O(p0, p1); return t }
//line :197:1
func (t *A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_iter__716000096__716000102_fn__716000103_A) Ctor_O_O(c__iter__716000096, c__s__716000097 any) { t.F_iter__716000096 = c__iter__716000096; t.F_s__716000097 = c__s__716000097 }
//line :197:1
func (t *A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_iter__716000096__716000102_fn__716000103_A) Invoke_O__O(self any) any { { var s__716000097__1 any; var t_ any = t.F_s__716000097; t.F_s__716000097 = nil; s__716000097__1 = t_; for { var temp__1927000414__auto____2 any; var root_1081 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_1082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1081, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1083 lang.IFn; if linked_1082 == nil { ifn_1083 = lang.IFn_Cast(root_1081) } else { ifn_1083 = nil }; var arg_1084 any = s__716000097__1; if linked_1082 == nil { temp__1927000414__auto____2 = ifn_1083.Invoke_O__O(arg_1084) } else { temp__1927000414__auto____2 = linked_1082.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1081, arg_1084) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__716000097__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1085 any = A_arbace_repr_clojure_A_const_55.GetRawRoot__O(); var linked_1086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1085, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1087 lang.IFn; if linked_1086 == nil { ifn_1087 = lang.IFn_Cast(root_1085) } else { ifn_1087 = nil }; var arg_1088 any = s__716000097__3; if linked_1086 == nil { tmp1 = ifn_1087.Invoke_O__O(arg_1088) } else { tmp1 = linked_1086.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1085, arg_1088) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1089 any = A_arbace_repr_clojure_A_const_56.GetRawRoot__O(); var linked_1090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1089, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1091 lang.IFn; if linked_1090 == nil { ifn_1091 = lang.IFn_Cast(root_1089) } else { ifn_1091 = nil }; var arg_1092 any = s__716000097__3; if linked_1090 == nil { c__1927001037__auto____4 = ifn_1091.Invoke_O__O(arg_1092) } else { c__1927001037__auto____4 = linked_1090.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1089, arg_1092) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__716000099__6 any; var root_1093 any = A_arbace_repr_clojure_A_const_57.GetRawRoot__O(); var linked_1094 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1093, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1095 lang.IFn; if linked_1094 == nil { ifn_1095 = lang.IFn_Cast(root_1093) } else { ifn_1095 = nil }; var arg_1096 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1094 == nil { b__716000099__6 = ifn_1095.Invoke_O__O(arg_1096) } else { b__716000099__6 = linked_1094.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1093, arg_1096) }; var tmp2 any = A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_iter__716000096__716000102_fn__716000103_fn__716000104_A_New_O_I_O(b__716000099__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1107 *jrt.Class = A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_iter__716000096__716000102_fn__716000103_fn__716000104_A_fn_class; if fncls__1107 == nil { var fncls__1107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_124, false); A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_iter__716000096__716000102_fn__716000103_fn__716000104_A_fn_class = fncls__1107d; tmp3 = fncls__1107d } else { tmp3 = fncls__1107 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1116 any = A_arbace_repr_clojure_A_const_60.GetRawRoot__O(); var linked_1117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1116, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1118 lang.IFn; if linked_1117 == nil { ifn_1118 = lang.IFn_Cast(root_1116) } else { ifn_1118 = nil }; var arg_1119 any; var root_1108 any = A_arbace_repr_clojure_A_const_61.GetRawRoot__O(); var linked_1109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1108, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1110 lang.IFn; if linked_1109 == nil { ifn_1110 = lang.IFn_Cast(root_1108) } else { ifn_1110 = nil }; var arg_1111 any = b__716000099__6; if linked_1109 == nil { arg_1119 = ifn_1110.Invoke_O__O(arg_1111) } else { arg_1119 = linked_1109.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1108, arg_1111) }; var arg_1120 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__716000096); var tmp5 any; var root_1112 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_1113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1112, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1114 lang.IFn; if linked_1113 == nil { ifn_1114 = lang.IFn_Cast(root_1112) } else { ifn_1114 = nil }; var arg_1115 any = s__716000097__3; if linked_1113 == nil { tmp5 = ifn_1114.Invoke_O__O(arg_1115) } else { tmp5 = linked_1113.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1112, arg_1115) }; arg_1120 = tmp4.Invoke_O__O(tmp5); if linked_1117 == nil { return ifn_1118.Invoke_O_O__O(arg_1119, arg_1120) } else { return linked_1117.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1116, arg_1119, arg_1120) } } else { var root_1125 any = A_arbace_repr_clojure_A_const_60.GetRawRoot__O(); var linked_1126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1125, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1127 lang.IFn; if linked_1126 == nil { ifn_1127 = lang.IFn_Cast(root_1125) } else { ifn_1127 = nil }; var arg_1128 any; var root_1121 any = A_arbace_repr_clojure_A_const_61.GetRawRoot__O(); var linked_1122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1121, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1123 lang.IFn; if linked_1122 == nil { ifn_1123 = lang.IFn_Cast(root_1121) } else { ifn_1123 = nil }; var arg_1124 any = b__716000099__6; if linked_1122 == nil { arg_1128 = ifn_1123.Invoke_O__O(arg_1124) } else { arg_1128 = linked_1122.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1121, arg_1124) }; var arg_1129 any; if linked_1126 == nil { return ifn_1127.Invoke_O_O__O(arg_1128, arg_1129) } else { return linked_1126.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1125, arg_1128, arg_1129) } } } else { var vec__716000109__4 any; var root_1130 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_1131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1130, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1132 lang.IFn; if linked_1131 == nil { ifn_1132 = lang.IFn_Cast(root_1130) } else { ifn_1132 = nil }; var arg_1133 any = s__716000097__3; if linked_1131 == nil { vec__716000109__4 = ifn_1132.Invoke_O__O(arg_1133) } else { vec__716000109__4 = linked_1131.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1130, arg_1133) }; var dir__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000109__4, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000109__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1143 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_1144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1143, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1145 lang.IFn; if linked_1144 == nil { ifn_1145 = lang.IFn_Cast(root_1143) } else { ifn_1145 = nil }; var arg_1146 any; var tmp6 any; var root_1134 any = A_arbace_repr_clojure_A_const_72.GetRawRoot__O(); var linked_1135 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1134, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_1136 lang.IFn; if linked_1135 == nil { ifn_1136 = lang.IFn_Cast(root_1134) } else { ifn_1136 = nil }; var arg_1137 any = dir__5; var arg_1138 any = rel__6; if linked_1135 == nil { tmp6 = ifn_1136.Invoke_O_O__O(arg_1137, arg_1138) } else { tmp6 = linked_1135.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_1134, arg_1137, arg_1138) }; arg_1146 = lang.Tuple_Create_O_O__IPersistentVector(rel__6, tmp6); var arg_1147 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__716000096); var tmp8 any; var root_1139 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_1140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1139, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1141 lang.IFn; if linked_1140 == nil { ifn_1141 = lang.IFn_Cast(root_1139) } else { ifn_1141 = nil }; var arg_1142 any = s__716000097__3; if linked_1140 == nil { tmp8 = ifn_1141.Invoke_O__O(arg_1142) } else { tmp8 = linked_1140.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1139, arg_1142) }; arg_1147 = tmp7.Invoke_O__O(tmp8); if linked_1144 == nil { return ifn_1145.Invoke_O_O__O(arg_1146, arg_1147) } else { return linked_1144.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1143, arg_1146, arg_1147) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :197:1
func A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_iter__716000096__716000102_fn__716000103_fn__716000104_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_iter__716000096__716000102_fn__716000103_fn__716000104_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_iter__716000096__716000102_fn__716000103_fn__716000104_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :197:1
func (t *A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_iter__716000096__716000102_fn__716000103_fn__716000104_A) Ctor_O_I_O(c__b__716000099 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__716000099 = c__b__716000099; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :197:1
func (t *A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_iter__716000096__716000102_fn__716000103_fn__716000104_A) Invoke_O__O(self any) any { { var i__716000098__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__716000098__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__716000105__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__716000098__1)); var dir__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000105__2, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000105__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1102 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_1103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1102, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1104 lang.IFn; if linked_1103 == nil { ifn_1104 = lang.IFn_Cast(root_1102) } else { ifn_1104 = nil }; var arg_1105 any = t.F_b__716000099; var arg_1106 any; var tmp2 any; var root_1097 any = A_arbace_repr_clojure_A_const_72.GetRawRoot__O(); var linked_1098 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1097, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_1099 lang.IFn; if linked_1098 == nil { ifn_1099 = lang.IFn_Cast(root_1097) } else { ifn_1099 = nil }; var arg_1100 any = dir__3; var arg_1101 any = rel__4; if linked_1098 == nil { tmp2 = ifn_1099.Invoke_O_O__O(arg_1100, arg_1101) } else { tmp2 = linked_1098.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_1097, arg_1100, arg_1101) }; arg_1106 = lang.Tuple_Create_O_O__IPersistentVector(rel__4, tmp2); if linked_1103 == nil { ifn_1104.Invoke_O_O__O(arg_1105, arg_1106) } else { linked_1103.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1102, arg_1105, arg_1106) }; i__716000098__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__716000098__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_repr_clojure_parent_of_A_New() *A_arbace_repr_clojure_parent_of_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_parent_of_A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_repr_clojure_parent_of_A) Ctor() {}
//line :199:1
func (t *A_arbace_repr_clojure_parent_of_A) Invoke_O_O__O(self, rel__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(rel__0)).LastIndexOf_String__I(Lit_29); if lang.Numbers_IsPos_J__Z_NoInit(int64(i__2)) { var root_1182 any = A_arbace_repr_clojure_A_const_12.GetRawRoot__O(); var linked_1183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1182, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1184 lang.IFn; if linked_1183 == nil { ifn_1184 = lang.IFn_Cast(root_1182) } else { ifn_1184 = nil }; var arg_1185 any = rel__0; var arg_1186 any = A_arbace_repr_clojure_A_const_13; var arg_1187 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref(); if linked_1183 == nil { return ifn_1184.Invoke_O_O_O__O(arg_1185, arg_1186, arg_1187) } else { return linked_1183.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1182, arg_1185, arg_1186, arg_1187) } } else { return nil } }
func A_arbace_repr_clojure_name_of_A_New() *A_arbace_repr_clojure_name_of_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_name_of_A{}; t.Ctor(); return t }
//line :200:1
func (t *A_arbace_repr_clojure_name_of_A) Ctor() {}
//line :200:1
func (t *A_arbace_repr_clojure_name_of_A) Invoke_O_O__O(self, rel__0 any) any { var root_1188 any = A_arbace_repr_clojure_A_const_12.GetRawRoot__O(); var linked_1189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1188, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1190 lang.IFn; if linked_1189 == nil { ifn_1190 = lang.IFn_Cast(root_1188) } else { ifn_1190 = nil }; var arg_1191 any = rel__0; var arg_1192 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(jrt.NN(jrt.String_Cast(rel__0)).LastIndexOf_String__I(Lit_29)))).Ref(); if linked_1189 == nil { return ifn_1190.Invoke_O_O__O(arg_1191, arg_1192) } else { return linked_1189.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1188, arg_1191, arg_1192) } }
func A_arbace_repr_clojure_under_A_New() *A_arbace_repr_clojure_under_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_under_A{}; t.Ctor(); return t }
//line :201:1
func (t *A_arbace_repr_clojure_under_A) Ctor() {}
//line :201:1
func (t *A_arbace_repr_clojure_under_A) Invoke_O_O_O__O(self, d__0, n__1 any) any { if jrt.J2g_Truth(d__0) { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_29, nil), jrt.RefArrayOf(jrt.Object_class, d__0, nil, n__1)).Ref() } else { return n__1 } }

func A_arbace_repr_clojure_half_A_New() *A_arbace_repr_clojure_half_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_half_A{}; t.Ctor(); return t }
//line :203:1
func (t *A_arbace_repr_clojure_half_A) Ctor() {}
//line :203:1
func (t *A_arbace_repr_clojure_half_A) Invoke_O_O_O_O__O(self, verb__0, t__1, opts__2 any) any { var map__716000120__4 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_66.GetRawRoot__O()).Invoke_O__O(verb__0); var map__716000120__5 any; if






	lang.ISeq_InstanceOf(map__716000120__4) { var tmp1 any; var root_1193 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_1194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1193, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1195 lang.IFn; if linked_1194 == nil { ifn_1195 = lang.IFn_Cast(root_1193) } else { ifn_1195 = nil }; var arg_1196 any = map__716000120__4; if linked_1194 == nil { tmp1 = ifn_1195.Invoke_O__O(arg_1196) } else { tmp1 = linked_1194.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1193, arg_1196) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1197 any = A_arbace_repr_clojure_A_const_15.GetRawRoot__O(); var linked_1198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1197, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1199 lang.IFn; if linked_1198 == nil { ifn_1199 = lang.IFn_Cast(root_1197) } else { ifn_1199 = nil }; var arg_1200 any = map__716000120__4; if linked_1198 == nil { tmp2 = ifn_1199.Invoke_O__O(arg_1200) } else { tmp2 = linked_1198.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1197, arg_1200) }; map__716000120__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_1201 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_1202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1201, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1203 lang.IFn; if linked_1202 == nil { ifn_1203 = lang.IFn_Cast(root_1201) } else { ifn_1203 = nil }; var arg_1204 any = map__716000120__4; if linked_1202 == nil { tmp3 = ifn_1203.Invoke_O__O(arg_1204) } else { tmp3 = linked_1202.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1201, arg_1204) }; if jrt.J2g_Truth(tmp3) { var root_1205 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_1206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1205, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1207 lang.IFn; if linked_1206 == nil { ifn_1207 = lang.IFn_Cast(root_1205) } else { ifn_1207 = nil }; var arg_1208 any = map__716000120__4; if linked_1206 == nil { map__716000120__5 = ifn_1207.Invoke_O__O(arg_1208) } else { map__716000120__5 = linked_1206.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1205, arg_1208) } } else { map__716000120__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__716000120__5 = map__716000120__4 }; var plan__6 any = /*line :203:1*/lang.RT_Get_O_O__O_NoInit(map__716000120__5, A_arbace_repr_clojure_A_const_67); var translate_text__7 any = lang.RT_Get_O_O__O_NoInit(map__716000120__5, A_arbace_repr_clojure_A_const_19); var dirs__8 any; var root_1234 any = A_arbace_repr_clojure_A_const_99.GetRawRoot__O(); var linked_1235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1234, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1236 lang.IFn; if







	linked_1235 == nil { ifn_1236 = lang.IFn_Cast(root_1234) } else { ifn_1236 = nil }; var arg_1237 any; var tmp4 any = A_arbace_repr_clojure_half_fn__716000122_A_New(); var tmp5 *jrt.Class; var fncls__1229 *jrt.Class = A_arbace_repr_clojure_half_fn__716000122_A_fn_class; if fncls__1229 == nil { var fncls__1229d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_repr_clojure_half_fn__716000122_A_fn_class = fncls__1229d; tmp5 = fncls__1229d } else { tmp5 = fncls__1229 }; arg_1237 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_1238 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1239 any; var root_1230 any = A_arbace_repr_clojure_A_const_103.GetRawRoot__O(); var linked_1231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1230, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_1232 lang.IFn; if linked_1231 == nil { ifn_1232 = lang.IFn_Cast(root_1230) } else { ifn_1232 = nil }; var arg_1233 any = t__1; if linked_1231 == nil { arg_1239 = ifn_1232.Invoke_O__O(arg_1233) } else { arg_1239 = linked_1231.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_1230, arg_1233) }; if linked_1235 == nil { dirs__8 = ifn_1236.Invoke_O_O_O__O(arg_1237, arg_1238, arg_1239) } else { dirs__8 = linked_1235.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1234, arg_1237, arg_1238, arg_1239) }; var root_1314 any =
	A_arbace_repr_clojure_A_const_99.GetRawRoot__O(); var linked_1315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1314, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1316 lang.IFn; if linked_1315 == nil { ifn_1316 = lang.IFn_Cast(root_1314) } else { ifn_1316 = nil }; var arg_1317 any; var tmp6 any = A_arbace_repr_clojure_half_fn__716000125_A_New(); var tmp7 *jrt.Class; var fncls__1283 *jrt.Class = A_arbace_repr_clojure_half_fn__716000125_A_fn_class; if fncls__1283 == nil { var fncls__1283d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_repr_clojure_half_fn__716000125_A_fn_class = fncls__1283d; tmp7 = fncls__1283d } else { tmp7 = fncls__1283 }; arg_1317 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp8 any = A_arbace_repr_clojure_A_const_105; var arg_1318 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, lang.IFn_Cast(A_arbace_repr_clojure_A_const_97.GetRawRoot__O()).Invoke__O(), A_arbace_repr_clojure_A_const_108, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_repr_clojure_A_const_109, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_repr_clojure_A_const_82, lang.PersistentArrayMap_EMPTY.Ref())); var arg_1319 any; var root_1309 any = A_arbace_repr_clojure_A_const_111.GetRawRoot__O(); var linked_1310 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1309, aot_arbace_core.A_arbace_core_pmap_A_fn_class); var ifn_1311 lang.IFn; if









	linked_1310 == nil { ifn_1311 = lang.IFn_Cast(root_1309) } else { ifn_1311 = nil }; var arg_1312 any; var tmp9 any = A_arbace_repr_clojure_half_fn__716000131_A_New_O_O_O_O(plan__6, translate_text__7, opts__2, dirs__8); var tmp10 *jrt.Class; var fncls__1308 *jrt.Class = A_arbace_repr_clojure_half_fn__716000131_A_fn_class; if fncls__1308 == nil { var fncls__1308d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_repr_clojure_half_fn__716000131_A_fn_class = fncls__1308d; tmp10 = fncls__1308d } else { tmp10 = fncls__1308 }; arg_1312 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var arg_1313 any = t__1; if linked_1310 == nil { arg_1319 = ifn_1311.Invoke_O_O__O(arg_1312, arg_1313) } else { arg_1319 = linked_1310.(*aot_arbace_core.A_arbace_core_pmap_A).Invoke_O_O_O__O(root_1309, arg_1312, arg_1313) }; if /*line :212:1*/ linked_1315 == nil { return ifn_1316.Invoke_O_O_O__O(arg_1317, arg_1318, arg_1319) } else { return linked_1315.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1314, arg_1317, arg_1318, arg_1319) } }
//line :211:1
func A_arbace_repr_clojure_half_fn__716000122_A_New() *A_arbace_repr_clojure_half_fn__716000122_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_half_fn__716000122_A{}; t.Ctor(); return t }
//line :211:1
func (t *A_arbace_repr_clojure_half_fn__716000122_A) Ctor() {}
//line :211:1
func (t *A_arbace_repr_clojure_half_fn__716000122_A) Invoke_O_O_O__O(self, m__1, rel__2 any) any { var root_1222 any = A_arbace_repr_clojure_A_const_78.GetRawRoot__O(); var linked_1223 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1222, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1224 lang.IFn; if linked_1223 == nil { ifn_1224 = lang.IFn_Cast(root_1222) } else { ifn_1224 = nil }; var arg_1225 any = m__1; var arg_1226 any; var root_1209 any = A_arbace_repr_clojure_A_const_100.GetRawRoot__O(); var linked_1210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1209, A_arbace_repr_clojure_parent_of_A_fn_class); var ifn_1211 lang.IFn; if linked_1210 == nil { ifn_1211 = lang.IFn_Cast(root_1209) } else { ifn_1211 = nil }; var arg_1212 any = rel__2; if linked_1210 == nil { arg_1226 = ifn_1211.Invoke_O__O(arg_1212) } else { arg_1226 = linked_1210.(*A_arbace_repr_clojure_parent_of_A).Invoke_O_O__O(root_1209, arg_1212) }; var arg_1227 any; var root_1213 any = A_arbace_repr_clojure_A_const_101.GetRawRoot__O(); var linked_1214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1213, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_1215 lang.IFn; if linked_1214 == nil { ifn_1215 = lang.IFn_Cast(root_1213) } else { ifn_1215 = nil }; var arg_1216 any = A_arbace_repr_clojure_A_const_10.GetRawRoot__O(); var arg_1217 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_1214 == nil { arg_1227 = ifn_1215.Invoke_O_O__O(arg_1216, arg_1217) } else { arg_1227 = linked_1214.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_1213, arg_1216, arg_1217) }; var arg_1228 any; var root_1218 any = A_arbace_repr_clojure_A_const_102.GetRawRoot__O(); var linked_1219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1218, A_arbace_repr_clojure_name_of_A_fn_class); var ifn_1220 lang.IFn; if linked_1219 == nil { ifn_1220 = lang.IFn_Cast(root_1218) } else { ifn_1220 = nil }; var arg_1221 any = rel__2; if linked_1219 == nil { arg_1228 = ifn_1220.Invoke_O__O(arg_1221) } else { arg_1228 = linked_1219.(*A_arbace_repr_clojure_name_of_A).Invoke_O_O__O(root_1218, arg_1221) }; if linked_1223 == nil { return ifn_1224.Invoke_O_O_O_O__O(arg_1225, arg_1226, arg_1227, arg_1228) } else { return linked_1223.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1222, arg_1225, arg_1226, arg_1227, arg_1228) } }
func A_arbace_repr_clojure_half_fn__716000125_A_New() *A_arbace_repr_clojure_half_fn__716000125_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_half_fn__716000125_A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_repr_clojure_half_fn__716000125_A) Ctor() {}
//line :212:1
func (t *A_arbace_repr_clojure_half_fn__716000125_A) Invoke_O_O_O__O(self, acc__1, p__716000124__2 any) any { var vec__716000126__3 any = p__716000124__2; var rel__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000126__3, lang.RT_IntCast_J__I_NoInit(0), nil); var x__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000126__3, lang.RT_IntCast_J__I_NoInit(1), nil); var p__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000126__3, lang.RT_IntCast_J__I_NoInit(2), nil); var r__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000126__3, lang.RT_IntCast_J__I_NoInit(3), nil); if
														jrt.J2g_Truth(A_arbace_repr_clojure_A_const_32.Invoke_O__O(p__6)) { return acc__1 } else { if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_76.Invoke_O__O(p__6)) {
															var root_1240 any = A_arbace_repr_clojure_A_const_104.GetRawRoot__O(); var linked_1241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1240, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1242 lang.IFn; if linked_1241 == nil { ifn_1242 = lang.IFn_Cast(root_1240) } else { ifn_1242 = nil }; var arg_1243 any = acc__1; var arg_1244 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_clojure_A_const_105, rel__4); var arg_1245 any = x__5; if linked_1241 == nil { return ifn_1242.Invoke_O_O_O__O(arg_1243, arg_1244, arg_1245) } else { return linked_1241.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1240, arg_1243, arg_1244, arg_1245) } } else {
//line :213:1
			if A_arbace_repr_clojure_A_const_33 != nil { var out__8 any; var root_1250 any = A_arbace_repr_clojure_A_const_106.GetRawRoot__O(); var linked_1251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1250, A_arbace_repr_clojure_under_A_fn_class); var ifn_1252 lang.IFn

				if linked_1251 == nil { ifn_1252 = lang.IFn_Cast(root_1250) } else { ifn_1252 = nil }; var arg_1253 any; var root_1246 any = A_arbace_repr_clojure_A_const_100.GetRawRoot__O(); var linked_1247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1246, A_arbace_repr_clojure_parent_of_A_fn_class); var ifn_1248 lang.IFn; if linked_1247 == nil { ifn_1248 = lang.IFn_Cast(root_1246) } else { ifn_1248 = nil }; var arg_1249 any = rel__4; if linked_1247 == nil { arg_1253 = ifn_1248.Invoke_O__O(arg_1249) } else { arg_1253 = linked_1247.(*A_arbace_repr_clojure_parent_of_A).Invoke_O_O__O(root_1246, arg_1249) }; var arg_1254 any = A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__6); if linked_1251 == nil { out__8 = ifn_1252.Invoke_O_O__O(arg_1253, arg_1254) } else { out__8 = linked_1251.(*A_arbace_repr_clojure_under_A).Invoke_O_O_O__O(root_1250, arg_1253, arg_1254) }
				var tmp1 any; var root_1255 any = A_arbace_repr_clojure_A_const_107.GetRawRoot__O(); var linked_1256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1255, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1257 lang.IFn; if linked_1256 == nil { ifn_1257 = lang.IFn_Cast(root_1255) } else { ifn_1257 = nil }; var arg_1258 any = r__7; if linked_1256 == nil { tmp1 = ifn_1257.Invoke_O__O(arg_1258) } else { tmp1 = linked_1256.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1255, arg_1258) }; if jrt.J2g_Truth(tmp1) {

					var root_1271 any = A_arbace_repr_clojure_A_const_104.GetRawRoot__O(); var linked_1272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1271, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1273 lang.IFn; if linked_1272 == nil { ifn_1273 = lang.IFn_Cast(root_1271) } else { ifn_1273 = nil }; var arg_1274 any; var root_1265 any = A_arbace_repr_clojure_A_const_104.GetRawRoot__O(); var linked_1266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1265, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1267 lang.IFn
//line :217:1
					if linked_1266 == nil { ifn_1267 = lang.IFn_Cast(root_1265) } else { ifn_1267 = nil }; var arg_1268 any; var root_1259 any = A_arbace_repr_clojure_A_const_104.GetRawRoot__O(); var linked_1260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1259, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1261 lang.IFn; if linked_1260 == nil { ifn_1261 = lang.IFn_Cast(root_1259) } else { ifn_1261 = nil }; var arg_1262 any = acc__1; var arg_1263 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_clojure_A_const_105, out__8); var arg_1264 any = r__7; if linked_1260 == nil { arg_1268 = ifn_1261.Invoke_O_O_O__O(arg_1262, arg_1263, arg_1264) } else { arg_1268 = linked_1260.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1259, arg_1262, arg_1263, arg_1264) }; var arg_1269 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_clojure_A_const_108, out__8); var arg_1270 any = rel__4; if linked_1266 == nil { arg_1274 = ifn_1267.Invoke_O_O_O__O(arg_1268, arg_1269, arg_1270) } else { arg_1274 = linked_1266.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1265, arg_1268, arg_1269, arg_1270) }
					var arg_1275 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_clojure_A_const_109, out__8); var arg_1276 any = p__6; if linked_1272 == nil { return ifn_1273.Invoke_O_O_O__O(arg_1274, arg_1275, arg_1276) } else { return linked_1272.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1271, arg_1274, arg_1275, arg_1276) } } else {
						var root_1277 any = A_arbace_repr_clojure_A_const_104.GetRawRoot__O(); var linked_1278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1277, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1279 lang.IFn; if linked_1278 == nil { ifn_1279 = lang.IFn_Cast(root_1277) } else { ifn_1279 = nil }; var arg_1280 any = acc__1; var arg_1281 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_clojure_A_const_82, rel__4); var arg_1282 any = A_arbace_repr_clojure_A_const_110.Invoke_O__O(r__7); if linked_1278 == nil { return ifn_1279.Invoke_O_O_O__O(arg_1280, arg_1281, arg_1282) } else { return linked_1278.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1277, arg_1280, arg_1281, arg_1282) } } } else {
//line :213:1
							return nil } } } }








func A_arbace_repr_clojure_half_fn__716000131_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_repr_clojure_half_fn__716000131_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_half_fn__716000131_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :222:1
func (t *A_arbace_repr_clojure_half_fn__716000131_A) Ctor_O_O_O_O(c__plan, c__translate_text, c__opts, c__dirs any) { t.F_plan = c__plan; t.F_translate_text = c__translate_text; t.F_opts = c__opts; t.F_dirs = c__dirs }
//line :222:1
func (t *A_arbace_repr_clojure_half_fn__716000131_A) Invoke_O_O__O(self, p__716000130__1 any) any { var vec__716000132__2 any = p__716000130__1; var rel__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000132__2, lang.RT_IntCast_J__I_NoInit(0), nil); var x__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000132__2, lang.RT_IntCast_J__I_NoInit(1), nil); var p__5 any; var tmp1 lang.IFn = lang.IFn_Cast(t.F_plan); var tmp2 any; var root_1287 any = A_arbace_repr_clojure_A_const_102.GetRawRoot__O(); var linked_1288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1287, A_arbace_repr_clojure_name_of_A_fn_class); var ifn_1289 lang.IFn; if
													linked_1288 == nil { ifn_1289 = lang.IFn_Cast(root_1287) } else { ifn_1289 = nil }; var arg_1290 any = rel__3; if linked_1288 == nil { tmp2 = ifn_1289.Invoke_O__O(arg_1290) } else { tmp2 = linked_1288.(*A_arbace_repr_clojure_name_of_A).Invoke_O_O__O(root_1287, arg_1290) }; var tmp3 any = tmp2; var tmp4 lang.IFn = lang.IFn_Cast(t.F_dirs); var tmp5 any; var root_1291 any = A_arbace_repr_clojure_A_const_100.GetRawRoot__O(); var linked_1292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1291, A_arbace_repr_clojure_parent_of_A_fn_class); var ifn_1293 lang.IFn; if linked_1292 == nil { ifn_1293 = lang.IFn_Cast(root_1291) } else { ifn_1293 = nil }; var arg_1294 any = rel__3; if linked_1292 == nil { tmp5 = ifn_1293.Invoke_O__O(arg_1294) } else { tmp5 = linked_1292.(*A_arbace_repr_clojure_parent_of_A).Invoke_O_O__O(root_1291, arg_1294) }; p__5 = tmp1.Invoke_O_O_O__O(tmp3, tmp4.Invoke_O__O(tmp5), t.F_opts); var tmp6 any; if
													jrt.J2g_Truth(A_arbace_repr_clojure_A_const_23.Invoke_O__O(p__5)) {
														var tmp7 any = A_arbace_repr_clojure_half_fn__716000131_fn__716000135_A_New_O_O_O_O_O(p__5, x__4, rel__3, t.F_translate_text, t.F_opts); var tmp8 *jrt.Class; var fncls__1307 *jrt.Class = A_arbace_repr_clojure_half_fn__716000131_fn__716000135_A_fn_class; if fncls__1307 == nil { var fncls__1307d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_repr_clojure_half_fn__716000131_fn__716000135_A_fn_class = fncls__1307d; tmp8 = fncls__1307d } else { tmp8 = fncls__1307 }; tmp6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil).Invoke__O() } else {
//line :224:1
			tmp6 = nil }; return /*line :222:1*/ lang.Tuple_Create_O_O_O_O__IPersistentVector(rel__3, x__4, p__5, tmp6) }


func A_arbace_repr_clojure_half_fn__716000131_fn__716000135_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_repr_clojure_half_fn__716000131_fn__716000135_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_half_fn__716000131_fn__716000135_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :225:1
func (t *A_arbace_repr_clojure_half_fn__716000131_fn__716000135_A) Ctor_O_O_O_O_O(c__p, c__x, c__rel, c__translate_text, c__opts any) { t.F_p = c__p; t.F_x = c__x; t.F_rel = c__rel; t.F_translate_text = c__translate_text; t.F_opts = c__opts }
//line :225:1
func (t *A_arbace_repr_clojure_half_fn__716000131_fn__716000135_A) Invoke_O__O(self any) any { var tmp1 any; tmp15 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var t_ any = t.F_translate_text; t.F_translate_text = nil; tmp2 = t_; var tmp3 lang.IFn = lang.IFn_Cast(tmp2); var tmp4 any; var tmp5 any; var root_1295 any = A_arbace_repr_clojure_A_const_107.GetRawRoot__O(); var linked_1296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1295, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1297 lang.IFn; if linked_1296 == nil { ifn_1297 = lang.IFn_Cast(root_1295) } else { ifn_1297 = nil }; var arg_1298 any = t.F_x; if linked_1296 == nil { tmp5 = ifn_1297.Invoke_O__O(arg_1298) } else { tmp5 = linked_1296.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1295, arg_1298) }; if jrt.J2g_Truth(tmp5) { var t__2 any = t.F_x; t.F_x = nil; tmp4 = t__2 } else { var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_81.GetRawRoot__O()); var tmp7 any; var t__3 any = t.F_x; t.F_x = nil; tmp7 = t__3; tmp4 = tmp6.Invoke_O__O(tmp7) }; var tmp8 any = tmp4; var tmp9 any; var t__4 any = t.F_p; t.F_p = nil; tmp9 = t__4; var tmp10 any = tmp9; var tmp11 any; var t__5 any = t.F_rel; t.F_rel = nil; tmp11 = t__5; var tmp12 any = tmp11; var tmp13 lang.IFn = A_arbace_repr_clojure_A_const_32; var tmp14 any; var t__6 any = t.F_opts; t.F_opts = nil; tmp14 = t__6; tmp1 = tmp3.Invoke_O_O_O_O__O(tmp8, tmp10, tmp12, tmp13.Invoke_O_O__O(tmp14, lang.PersistentHashSet_EMPTY.Ref())) }; return nil }(); if tmp15 != nil { if jrt.Exception_InstanceOf(tmp15) { var e__3 jrt.Exception_I = jrt.Exception_Cast(tmp15); var tmp16 any = A_arbace_repr_clojure_A_const_110; var tmp17 any; var root_1303 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var linked_1304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1303, aot_arbace_core.A_arbace_core_ex_message_A_fn_class); var ifn_1305 lang.IFn
												if linked_1304 == nil { ifn_1305 = lang.IFn_Cast(root_1303) } else { ifn_1305 = nil }; var arg_1306 any = e__3; if linked_1304 == nil { tmp17 = ifn_1305.Invoke_O__O(arg_1306) } else { tmp17 = linked_1304.(*aot_arbace_core.A_arbace_core_ex_message_A).Invoke_O_O__O(root_1303, arg_1306) }
//line :225:1
	tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp17)) } else { panic(tmp15) } }; return tmp1 }



func A_arbace_repr_clojure_first_difference_A_New() *A_arbace_repr_clojure_first_difference_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_first_difference_A{}; t.Ctor(); return t }
//line :229:1
func (t *A_arbace_repr_clojure_first_difference_A) Ctor() {}
//line :229:1
func (t *A_arbace_repr_clojure_first_difference_A) Invoke_O_O_O__O(self, a__0, b__1 any) any { var n__3 int64 = lang.Numbers_Min_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(a__0)), int64(lang.RT_Count_O__I_NoInit(b__1))); var i__4 any; var tmp1 any = A_arbace_repr_clojure_first_difference_fn__716000140_A_New_O_O_J(a__0, b__1, n__3); var tmp2 *jrt.Class; var fncls__1320 *jrt.Class = A_arbace_repr_clojure_first_difference_fn__716000140_A_fn_class; if

	fncls__1320 == nil { var fncls__1320d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_repr_clojure_first_difference_fn__716000140_A_fn_class = fncls__1320d; tmp2 = fncls__1320d } else { tmp2 = fncls__1320 }; i__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O(); var line__5 int64; var tmp3 any; var root_1328 any = /*line :229:1*/A_arbace_repr_clojure_A_const_112.GetRawRoot__O(); var linked_1329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1328, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1330 lang.IFn; if


	linked_1329 == nil { ifn_1330 = lang.IFn_Cast(root_1328) } else { ifn_1330 = nil }; var arg_1331 any; var tmp4 any = A_arbace_repr_clojure_first_difference_fn__716000142_A_New(); var tmp5 *jrt.Class; var fncls__1321 *jrt.Class = A_arbace_repr_clojure_first_difference_fn__716000142_A_fn_class; if fncls__1321 == nil { var fncls__1321d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_repr_clojure_first_difference_fn__716000142_A_fn_class = fncls__1321d; tmp5 = fncls__1321d } else { tmp5 = fncls__1321 }; arg_1331 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_1332 any; var root_1322 any = A_arbace_repr_clojure_A_const_12.GetRawRoot__O(); var linked_1323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1322, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1324 lang.IFn; if linked_1323 == nil { ifn_1324 = lang.IFn_Cast(root_1322) } else { ifn_1324 = nil }; var arg_1325 any = a__0; var arg_1326 any = A_arbace_repr_clojure_A_const_13; var arg_1327 any = i__4; if linked_1323 == nil { arg_1332 = ifn_1324.Invoke_O_O_O__O(arg_1325, arg_1326, arg_1327) } else { arg_1332 = linked_1323.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1322, arg_1325, arg_1326, arg_1327) }; if linked_1329 == nil { tmp3 = ifn_1330.Invoke_O_O__O(arg_1331, arg_1332) } else { tmp3 = linked_1329.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1328, arg_1331, arg_1332) }; line__5 = lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(tmp3))); var ln__6 any; var tmp6 any = /*line :229:1*/A_arbace_repr_clojure_first_difference_ln__716000144_A_New_O(i__4); var tmp7 *jrt.Class; var fncls__1341 *jrt.Class = A_arbace_repr_clojure_first_difference_ln__716000144_A_fn_class; if



	fncls__1341 == nil { var fncls__1341d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_repr_clojure_first_difference_ln__716000144_A_fn_class = fncls__1341d; tmp7 = fncls__1341d } else { tmp7 = fncls__1341 }; ln__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); return /*line :236:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_21, nil, Lit_22, nil, Lit_23, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Long_ValueOf_J__Long_NoInit(line__5).Ref(), nil, lang.IFn_Cast(A_arbace_repr_clojure_A_const_114.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(ln__6).Invoke_O__O(a__0)), nil, lang.IFn_Cast(A_arbace_repr_clojure_A_const_114.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(ln__6).Invoke_O__O(b__1)))).Ref() }
//line :231:1
func A_arbace_repr_clojure_first_difference_fn__716000140_A_New_O_O_J(p0, p1 any, p2 int64) *A_arbace_repr_clojure_first_difference_fn__716000140_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_first_difference_fn__716000140_A{}; t.Ctor_O_O_J(p0, p1, p2); return t }
//line :231:1
func (t *A_arbace_repr_clojure_first_difference_fn__716000140_A) Ctor_O_O_J(c__a, c__b any, c__n int64) { t.F_a = c__a; t.F_b = c__b; t.F_n = c__n }
//line :231:1
func (t *A_arbace_repr_clojure_first_difference_fn__716000140_A) Invoke_O__O(self any) any { { var i__1 int64 = 0; L1: for { var tmp1 bool; var and__1927000168__auto____2 bool = lang.Numbers_Lt_J_J__Z_NoInit(i__1, t.F_n); if and__1927000168__auto____2 { var tmp2 *jrt.String = jrt.String_Cast(t.F_a); var tmp3 *jrt.String = jrt.String_Cast(t.F_b); tmp1 = lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(tmp2).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(i__1)), jrt.NN(tmp3).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(i__1))) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { i__1 = lang.Numbers_Inc_J__J_NoInit(i__1); continue L1 } else { return jrt.Long_ValueOf_J__Long_NoInit(i__1).Ref() } } }; panic("j2g: unreachable") }
func A_arbace_repr_clojure_first_difference_fn__716000142_A_New() *A_arbace_repr_clojure_first_difference_fn__716000142_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_first_difference_fn__716000142_A{}; t.Ctor(); return t }
//line :232:1
func (t *A_arbace_repr_clojure_first_difference_fn__716000142_A) Ctor() {}
//line :232:1
func (t *A_arbace_repr_clojure_first_difference_fn__716000142_A) Invoke_O_O__O(self, p1__716000139_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_repr_clojure_A_const_113, p1__716000139_SHARP___1)).Ref() }
func A_arbace_repr_clojure_first_difference_ln__716000144_A_New_O(p0 any) *A_arbace_repr_clojure_first_difference_ln__716000144_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_first_difference_ln__716000144_A{}; t.Ctor_O(p0); return t }
//line :233:1
func (t *A_arbace_repr_clojure_first_difference_ln__716000144_A) Ctor_O(c__i any) { t.F_i = c__i }
//line :233:1
func (t *A_arbace_repr_clojure_first_difference_ln__716000144_A) Invoke_O_O__O(self, s__1 any) any { var st__2 int64; var tmp1 *jrt.String = jrt.String_Cast(s__1); var tmp2 *jrt.String = Lit_24; var tmp3 jrt.Number_I; var na_1333 any = t.F_i; if jrt.Long_InstanceOf(na_1333) { var n0_1334 int64 = jrt.NN(jrt.Long_Cast(na_1333)).LongValue__J(); if n0_1334 == -9223372036854775808 { tmp3 = lang.Numbers_Dec_O__Number_NoInit(na_1333) } else { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1334 - 1)) } } else { if jrt.Double_InstanceOf(na_1333) { var n0_1334_2 float64 = jrt.NN(jrt.Double_Cast(na_1333)).DoubleValue__D(); tmp3 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1334_2 - 1.0)) } else { tmp3 = lang.Numbers_Dec_O__Number_NoInit(na_1333) } }; st__2 = lang.Numbers_Inc_J__J_NoInit(int64(jrt.NN(tmp1).LastIndexOf_String_I__I(tmp2, lang.RT_IntCast_O__I_NoInit(lang.Numbers_Max_J_O__O_NoInit(0, tmp3))))); var e__3 int32 = jrt.NN(jrt.String_Cast(s__1)).IndexOf_String_I__I(Lit_24, lang.RT_IntCast_O__I_NoInit(t.F_i)); var root_1335 any = A_arbace_repr_clojure_A_const_12.GetRawRoot__O(); var linked_1336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1335, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1337 lang.IFn; if

	linked_1336 == nil { ifn_1337 = lang.IFn_Cast(root_1335) } else { ifn_1337 = nil }; var arg_1338 any = s__1; var arg_1339 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Min_J_J__J_NoInit(st__2, int64(lang.RT_Count_O__I_NoInit(s__1)))).Ref(); var arg_1340 any; if lang.Numbers_IsNeg_J__Z_NoInit(int64(e__3)) { arg_1340 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(s__1)).Ref() } else { arg_1340 = jrt.Integer_ValueOf_I__Integer_NoInit(e__3).Ref() }; if linked_1336 == nil { return ifn_1337.Invoke_O_O_O__O(arg_1338, arg_1339, arg_1340) } else { return linked_1336.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1335, arg_1338, arg_1339, arg_1340) } }


func A_arbace_repr_clojure_roundtrip_A_New() *A_arbace_repr_clojure_roundtrip_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_A{}; t.Ctor(); return t }
//line :238:1
func (t *A_arbace_repr_clojure_roundtrip_A) Ctor() {}
//line :238:1
func (t *A_arbace_repr_clojure_roundtrip_A) Invoke_O_O_O__O(self, sources__0, opts__1 any) any { var vec__716000147__3 any; var tmp1 any = A_arbace_repr_clojure_A_const_115; if










	lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_repr_clojure_A_const_108.Invoke_O__O(opts__1)) { vec__716000147__3 = A_arbace_repr_clojure_A_const_116 } else { vec__716000147__3 = A_arbace_repr_clojure_A_const_117 }; var v1__4 any = /*line :238:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__716000147__3, lang.RT_IntCast_J__I_NoInit(0), nil); var v2__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000147__3, lang.RT_IntCast_J__I_NoInit(1), nil); var t__6 any; var root_1350 any = A_arbace_repr_clojure_A_const_118.GetRawRoot__O(); var linked_1351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1350, A_arbace_repr_clojure_tree_A_fn_class); var ifn_1352 lang.IFn; if











	linked_1351 == nil { ifn_1352 = lang.IFn_Cast(root_1350) } else { ifn_1352 = nil }; var arg_1353 any = sources__0; if linked_1351 == nil { t__6 = ifn_1352.Invoke_O__O(arg_1353) } else { t__6 = linked_1351.(*A_arbace_repr_clojure_tree_A).Invoke_O_O__O(root_1350, arg_1353) }; var a__7 any; var root_1354 any = /*line :238:1*/A_arbace_repr_clojure_A_const_119.GetRawRoot__O(); var linked_1355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1354, A_arbace_repr_clojure_half_A_fn_class); var ifn_1356 lang.IFn; if












	linked_1355 == nil { ifn_1356 = lang.IFn_Cast(root_1354) } else { ifn_1356 = nil }; var arg_1357 any = v1__4; var arg_1358 any = t__6; var arg_1359 any = opts__1; if linked_1355 == nil { a__7 = ifn_1356.Invoke_O_O_O__O(arg_1357, arg_1358, arg_1359) } else { a__7 = linked_1355.(*A_arbace_repr_clojure_half_A).Invoke_O_O_O_O__O(root_1354, arg_1357, arg_1358, arg_1359) }; var b__8 any; var root_1360 any = /*line :238:1*/A_arbace_repr_clojure_A_const_119.GetRawRoot__O(); var linked_1361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1360, A_arbace_repr_clojure_half_A_fn_class); var ifn_1362 lang.IFn; if













	linked_1361 == nil { ifn_1362 = lang.IFn_Cast(root_1360) } else { ifn_1362 = nil }; var arg_1363 any = v2__5; var arg_1364 any = A_arbace_repr_clojure_A_const_105.Invoke_O__O(a__7); var arg_1365 any = opts__1; if linked_1361 == nil { b__8 = ifn_1362.Invoke_O_O_O__O(arg_1363, arg_1364, arg_1365) } else { b__8 = linked_1361.(*A_arbace_repr_clojure_half_A).Invoke_O_O_O_O__O(root_1360, arg_1363, arg_1364, arg_1365) }; var c__9 any; var tmp2 any = A_arbace_repr_clojure_A_const_115; if

	lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_repr_clojure_A_const_108.Invoke_O__O(opts__1)) { var root_1366 any = A_arbace_repr_clojure_A_const_119.GetRawRoot__O(); var linked_1367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1366, A_arbace_repr_clojure_half_A_fn_class); var ifn_1368 lang.IFn; if linked_1367 == nil { ifn_1368 = lang.IFn_Cast(root_1366) } else { ifn_1368 = nil }; var arg_1369 any = v1__4; var arg_1370 any = A_arbace_repr_clojure_A_const_105.Invoke_O__O(b__8); var arg_1371 any = opts__1; if linked_1367 == nil { c__9 = ifn_1368.Invoke_O_O_O__O(arg_1369, arg_1370, arg_1371) } else { c__9 = linked_1367.(*A_arbace_repr_clojure_half_A).Invoke_O_O_O_O__O(root_1366, arg_1369, arg_1370, arg_1371) } } else { c__9 = nil }; var back2__10 any; var root_1431 any = /*line :238:1*/A_arbace_repr_clojure_A_const_96.GetRawRoot__O(); var linked_1432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1431, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1433 lang.IFn; if
















	linked_1432 == nil { ifn_1433 = lang.IFn_Cast(root_1431) } else { ifn_1433 = nil }; var arg_1434 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1435 any; var iter__1927001039__auto____10 any; var tmp3 any = A_arbace_repr_clojure_roundtrip_iter__716000150__716000154_A_New(); var tmp4 *jrt.Class; var fncls__1430 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000150__716000154_A_fn_class; if fncls__1430 == nil { var fncls__1430d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_repr_clojure_roundtrip_iter__716000150__716000154_A_fn_class = fncls__1430d; tmp4 = fncls__1430d } else { tmp4 = fncls__1430 }; iter__1927001039__auto____10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); arg_1435 = lang.IFn_Cast(iter__1927001039__auto____10).Invoke_O__O(A_arbace_repr_clojure_A_const_108.Invoke_O__O(c__9)); if linked_1432 == nil { back2__10 = ifn_1433.Invoke_O_O__O(arg_1434, arg_1435) } else { back2__10 = linked_1432.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1431, arg_1434, arg_1435) }; var back__11 any; var root_1495 any = /*line :238:1*/A_arbace_repr_clojure_A_const_96.GetRawRoot__O(); var linked_1496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1495, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1497 lang.IFn; if


















	linked_1496 == nil { ifn_1497 = lang.IFn_Cast(root_1495) } else { ifn_1497 = nil }; var arg_1498 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1499 any; var iter__1927001039__auto____11 any; var tmp5 any = A_arbace_repr_clojure_roundtrip_iter__716000166__716000170_A_New(); var tmp6 *jrt.Class; var fncls__1494 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000166__716000170_A_fn_class; if fncls__1494 == nil { var fncls__1494d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_repr_clojure_roundtrip_iter__716000166__716000170_A_fn_class = fncls__1494d; tmp6 = fncls__1494d } else { tmp6 = fncls__1494 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); arg_1499 = lang.IFn_Cast(iter__1927001039__auto____11).Invoke_O__O(A_arbace_repr_clojure_A_const_108.Invoke_O__O(b__8)); if linked_1496 == nil { back__11 = ifn_1497.Invoke_O_O__O(arg_1498, arg_1499) } else { back__11 = linked_1496.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1495, arg_1498, arg_1499) }; var results__12 any; var iter__1927001039__auto____12 any; var tmp7 any = /*line :238:1*/A_arbace_repr_clojure_roundtrip_iter__716000182__716000186_A_New_O_O_O_O_O_O_O(back2__10, t__6, a__7, b__8, c__9, back__11, opts__1); var tmp8 *jrt.Class; var fncls__1752 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000182__716000186_A_fn_class; if



















	fncls__1752 == nil { var fncls__1752d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_repr_clojure_roundtrip_iter__716000182__716000186_A_fn_class = fncls__1752d; tmp8 = fncls__1752d } else { tmp8 = fncls__1752 }; iter__1927001039__auto____12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); results__12 = lang.IFn_Cast(iter__1927001039__auto____12).Invoke_O__O(A_arbace_repr_clojure_A_const_108.Invoke_O__O(a__7)); var tmp9 any = A_arbace_repr_clojure_A_const_135; var tmp10 any = /*line :238:1*/jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(results__12)), int64(lang.RT_Count_O__I_NoInit(A_arbace_repr_clojure_A_const_82.Invoke_O__O(a__7))))).Ref(); var tmp11 any = A_arbace_repr_clojure_A_const_136; var tmp12 any; var root_1753 any = A_arbace_repr_clojure_A_const_137.GetRawRoot__O(); var linked_1754 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1753, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1755 lang.IFn; if













































	linked_1754 == nil { ifn_1755 = lang.IFn_Cast(root_1753) } else { ifn_1755 = nil }; var arg_1756 any = A_arbace_repr_clojure_A_const_54.GetRawRoot__O(); var arg_1757 any = results__12; if linked_1754 == nil { tmp12 = ifn_1755.Invoke_O_O__O(arg_1756, arg_1757) } else { tmp12 = linked_1754.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1753, arg_1756, arg_1757) }; var tmp13 any = /*line :238:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp12)).Ref(); var tmp14 any = A_arbace_repr_clojure_A_const_138; var tmp15 any; var root_1890 any = A_arbace_repr_clojure_A_const_96.GetRawRoot__O(); var linked_1891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1890, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1892 lang.IFn; if














































	linked_1891 == nil { ifn_1892 = lang.IFn_Cast(root_1890) } else { ifn_1892 = nil }; var arg_1893 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_97.GetRawRoot__O()).Invoke__O(); var arg_1894 any; var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_98.GetRawRoot__O()); var tmp17 any; var root_1761 any = A_arbace_repr_clojure_A_const_112.GetRawRoot__O(); var linked_1762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1761, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1763 lang.IFn; if
	linked_1762 == nil { ifn_1763 = lang.IFn_Cast(root_1761) } else { ifn_1763 = nil }; var arg_1764 any = A_arbace_repr_clojure_A_const_54.GetRawRoot__O(); var arg_1765 any = results__12; if linked_1762 == nil { tmp17 = ifn_1763.Invoke_O_O__O(arg_1764, arg_1765) } else { tmp17 = linked_1762.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1761, arg_1764, arg_1765) }; var tmp18 any = tmp17; var tmp19 any; var iter__1927001039__auto____13 any; var tmp20 any = A_arbace_repr_clojure_roundtrip_iter__716000198__716000202_A_New(); var tmp21 *jrt.Class; var fncls__1824 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000198__716000202_A_fn_class; if
	fncls__1824 == nil { var fncls__1824d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_repr_clojure_roundtrip_iter__716000198__716000202_A_fn_class = fncls__1824d; tmp21 = fncls__1824d } else { tmp21 = fncls__1824 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil); tmp19 = lang.IFn_Cast(iter__1927001039__auto____13).Invoke_O__O(A_arbace_repr_clojure_A_const_82.Invoke_O__O(a__7)); var tmp22 any = tmp19; var tmp23 any; var iter__1927001039__auto____13_2 any; var tmp24 any = /*line :286:1*/A_arbace_repr_clojure_roundtrip_iter__716000214__716000218_A_New_O(a__7); var tmp25 *jrt.Class; var fncls__1883 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000214__716000218_A_fn_class; if


	fncls__1883 == nil { var fncls__1883d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_repr_clojure_roundtrip_iter__716000214__716000218_A_fn_class = fncls__1883d; tmp25 = fncls__1883d } else { tmp25 = fncls__1883 }; iter__1927001039__auto____13_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil); tmp23 = lang.IFn_Cast(iter__1927001039__auto____13_2).Invoke_O__O(A_arbace_repr_clojure_A_const_82.Invoke_O__O(b__8)); arg_1894 = /*line :286:1*/tmp16.Invoke_O_O_O__O(tmp18, tmp22, tmp23); if /*line :285:1*/ linked_1891 == nil { tmp15 = ifn_1892.Invoke_O_O__O(arg_1893, arg_1894) } else { tmp15 = linked_1891.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1890, arg_1893, arg_1894) }; return /*line :238:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, tmp11, tmp13, tmp14, tmp15)) }
















func A_arbace_repr_clojure_roundtrip_iter__716000150__716000154_A_New() *A_arbace_repr_clojure_roundtrip_iter__716000150__716000154_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000150__716000154_A{}; t.Ctor(); return t }
//line :255:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000150__716000154_A) Ctor() {}
//line :255:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000150__716000154_A) Invoke_O_O__O(self, s__716000151__1 any) any { var tmp1 any = A_arbace_repr_clojure_roundtrip_iter__716000150__716000154_fn__716000155_A_New_O_O(self, s__716000151__1); var tmp2 *jrt.Class; var fncls__1429 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000150__716000154_fn__716000155_A_fn_class; if fncls__1429 == nil { var fncls__1429d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_repr_clojure_roundtrip_iter__716000150__716000154_fn__716000155_A_fn_class = fncls__1429d; tmp2 = fncls__1429d } else { tmp2 = fncls__1429 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :255:1
func A_arbace_repr_clojure_roundtrip_iter__716000150__716000154_fn__716000155_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_roundtrip_iter__716000150__716000154_fn__716000155_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000150__716000154_fn__716000155_A{}; t.Ctor_O_O(p0, p1); return t }
//line :255:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000150__716000154_fn__716000155_A) Ctor_O_O(c__iter__716000150, c__s__716000151 any) { t.F_iter__716000150 = c__iter__716000150; t.F_s__716000151 = c__s__716000151 }
//line :255:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000150__716000154_fn__716000155_A) Invoke_O__O(self any) any { { var s__716000151__1 any; var t_ any = t.F_s__716000151; t.F_s__716000151 = nil; s__716000151__1 = t_; for { var temp__1927000414__auto____2 any; var root_1372 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_1373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1372, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1374 lang.IFn; if linked_1373 == nil { ifn_1374 = lang.IFn_Cast(root_1372) } else { ifn_1374 = nil }; var arg_1375 any = s__716000151__1; if linked_1373 == nil { temp__1927000414__auto____2 = ifn_1374.Invoke_O__O(arg_1375) } else { temp__1927000414__auto____2 = linked_1373.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1372, arg_1375) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__716000151__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1376 any = A_arbace_repr_clojure_A_const_55.GetRawRoot__O(); var linked_1377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1376, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1378 lang.IFn; if linked_1377 == nil { ifn_1378 = lang.IFn_Cast(root_1376) } else { ifn_1378 = nil }; var arg_1379 any = s__716000151__3; if linked_1377 == nil { tmp1 = ifn_1378.Invoke_O__O(arg_1379) } else { tmp1 = linked_1377.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1376, arg_1379) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1380 any = A_arbace_repr_clojure_A_const_56.GetRawRoot__O(); var linked_1381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1380, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1382 lang.IFn; if linked_1381 == nil { ifn_1382 = lang.IFn_Cast(root_1380) } else { ifn_1382 = nil }; var arg_1383 any = s__716000151__3; if linked_1381 == nil { c__1927001037__auto____4 = ifn_1382.Invoke_O__O(arg_1383) } else { c__1927001037__auto____4 = linked_1381.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1380, arg_1383) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__716000153__6 any; var root_1384 any = A_arbace_repr_clojure_A_const_57.GetRawRoot__O(); var linked_1385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1384, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1386 lang.IFn; if linked_1385 == nil { ifn_1386 = lang.IFn_Cast(root_1384) } else { ifn_1386 = nil }; var arg_1387 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1385 == nil { b__716000153__6 = ifn_1386.Invoke_O__O(arg_1387) } else { b__716000153__6 = linked_1385.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1384, arg_1387) }; var tmp2 any = A_arbace_repr_clojure_roundtrip_iter__716000150__716000154_fn__716000155_fn__716000156_A_New_O_I_O(b__716000153__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1393 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000150__716000154_fn__716000155_fn__716000156_A_fn_class; if fncls__1393 == nil { var fncls__1393d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_repr_clojure_roundtrip_iter__716000150__716000154_fn__716000155_fn__716000156_A_fn_class = fncls__1393d; tmp3 = fncls__1393d } else { tmp3 = fncls__1393 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1402 any = A_arbace_repr_clojure_A_const_60.GetRawRoot__O(); var linked_1403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1402, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1404 lang.IFn; if linked_1403 == nil { ifn_1404 = lang.IFn_Cast(root_1402) } else { ifn_1404 = nil }; var arg_1405 any; var root_1394 any = A_arbace_repr_clojure_A_const_61.GetRawRoot__O(); var linked_1395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1394, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1396 lang.IFn; if linked_1395 == nil { ifn_1396 = lang.IFn_Cast(root_1394) } else { ifn_1396 = nil }; var arg_1397 any = b__716000153__6; if linked_1395 == nil { arg_1405 = ifn_1396.Invoke_O__O(arg_1397) } else { arg_1405 = linked_1395.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1394, arg_1397) }; var arg_1406 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__716000150); var tmp5 any; var root_1398 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_1399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1398, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1400 lang.IFn; if linked_1399 == nil { ifn_1400 = lang.IFn_Cast(root_1398) } else { ifn_1400 = nil }; var arg_1401 any = s__716000151__3; if linked_1399 == nil { tmp5 = ifn_1400.Invoke_O__O(arg_1401) } else { tmp5 = linked_1399.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1398, arg_1401) }; arg_1406 = tmp4.Invoke_O__O(tmp5); if linked_1403 == nil { return ifn_1404.Invoke_O_O__O(arg_1405, arg_1406) } else { return linked_1403.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1402, arg_1405, arg_1406) } } else { var root_1411 any = A_arbace_repr_clojure_A_const_60.GetRawRoot__O(); var linked_1412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1411, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1413 lang.IFn; if linked_1412 == nil { ifn_1413 = lang.IFn_Cast(root_1411) } else { ifn_1413 = nil }; var arg_1414 any; var root_1407 any = A_arbace_repr_clojure_A_const_61.GetRawRoot__O(); var linked_1408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1407, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1409 lang.IFn; if linked_1408 == nil { ifn_1409 = lang.IFn_Cast(root_1407) } else { ifn_1409 = nil }; var arg_1410 any = b__716000153__6; if linked_1408 == nil { arg_1414 = ifn_1409.Invoke_O__O(arg_1410) } else { arg_1414 = linked_1408.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1407, arg_1410) }; var arg_1415 any; if linked_1412 == nil { return ifn_1413.Invoke_O_O__O(arg_1414, arg_1415) } else { return linked_1412.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1411, arg_1414, arg_1415) } } } else { var vec__716000161__4 any; var root_1416 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_1417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1416, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1418 lang.IFn; if linked_1417 == nil { ifn_1418 = lang.IFn_Cast(root_1416) } else { ifn_1418 = nil }; var arg_1419 any = s__716000151__3; if linked_1417 == nil { vec__716000161__4 = ifn_1418.Invoke_O__O(arg_1419) } else { vec__716000161__4 = linked_1417.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1416, arg_1419) }; var out__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000161__4, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000161__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1424 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_1425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1424, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1426 lang.IFn; if linked_1425 == nil { ifn_1426 = lang.IFn_Cast(root_1424) } else { ifn_1426 = nil }; var arg_1427 any = lang.Tuple_Create_O_O__IPersistentVector(rel__6, out__5); var arg_1428 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__716000150); var tmp7 any; var root_1420 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_1421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1420, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1422 lang.IFn; if linked_1421 == nil { ifn_1422 = lang.IFn_Cast(root_1420) } else { ifn_1422 = nil }; var arg_1423 any = s__716000151__3; if linked_1421 == nil { tmp7 = ifn_1422.Invoke_O__O(arg_1423) } else { tmp7 = linked_1421.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1420, arg_1423) }; arg_1428 = tmp6.Invoke_O__O(tmp7); if linked_1425 == nil { return ifn_1426.Invoke_O_O__O(arg_1427, arg_1428) } else { return linked_1425.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1424, arg_1427, arg_1428) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :255:1
func A_arbace_repr_clojure_roundtrip_iter__716000150__716000154_fn__716000155_fn__716000156_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_clojure_roundtrip_iter__716000150__716000154_fn__716000155_fn__716000156_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000150__716000154_fn__716000155_fn__716000156_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :255:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000150__716000154_fn__716000155_fn__716000156_A) Ctor_O_I_O(c__b__716000153 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__716000153 = c__b__716000153; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :255:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000150__716000154_fn__716000155_fn__716000156_A) Invoke_O__O(self any) any { { var i__716000152__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__716000152__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__716000157__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__716000152__1)); var out__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000157__2, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000157__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1388 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_1389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1388, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1390 lang.IFn; if linked_1389 == nil { ifn_1390 = lang.IFn_Cast(root_1388) } else { ifn_1390 = nil }; var arg_1391 any = t.F_b__716000153; var arg_1392 any = lang.Tuple_Create_O_O__IPersistentVector(rel__4, out__3); if linked_1389 == nil { ifn_1390.Invoke_O_O__O(arg_1391, arg_1392) } else { linked_1389.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1388, arg_1391, arg_1392) }; i__716000152__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__716000152__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_repr_clojure_roundtrip_iter__716000166__716000170_A_New() *A_arbace_repr_clojure_roundtrip_iter__716000166__716000170_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000166__716000170_A{}; t.Ctor(); return t }
//line :257:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000166__716000170_A) Ctor() {}
//line :257:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000166__716000170_A) Invoke_O_O__O(self, s__716000167__1 any) any { var tmp1 any = A_arbace_repr_clojure_roundtrip_iter__716000166__716000170_fn__716000171_A_New_O_O(self, s__716000167__1); var tmp2 *jrt.Class; var fncls__1493 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000166__716000170_fn__716000171_A_fn_class; if fncls__1493 == nil { var fncls__1493d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_repr_clojure_roundtrip_iter__716000166__716000170_fn__716000171_A_fn_class = fncls__1493d; tmp2 = fncls__1493d } else { tmp2 = fncls__1493 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :257:1
func A_arbace_repr_clojure_roundtrip_iter__716000166__716000170_fn__716000171_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_roundtrip_iter__716000166__716000170_fn__716000171_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000166__716000170_fn__716000171_A{}; t.Ctor_O_O(p0, p1); return t }
//line :257:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000166__716000170_fn__716000171_A) Ctor_O_O(c__iter__716000166, c__s__716000167 any) { t.F_iter__716000166 = c__iter__716000166; t.F_s__716000167 = c__s__716000167 }
//line :257:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000166__716000170_fn__716000171_A) Invoke_O__O(self any) any { { var s__716000167__1 any; var t_ any = t.F_s__716000167; t.F_s__716000167 = nil; s__716000167__1 = t_; for { var temp__1927000414__auto____2 any; var root_1436 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_1437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1436, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1438 lang.IFn; if linked_1437 == nil { ifn_1438 = lang.IFn_Cast(root_1436) } else { ifn_1438 = nil }; var arg_1439 any = s__716000167__1; if linked_1437 == nil { temp__1927000414__auto____2 = ifn_1438.Invoke_O__O(arg_1439) } else { temp__1927000414__auto____2 = linked_1437.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1436, arg_1439) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__716000167__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1440 any = A_arbace_repr_clojure_A_const_55.GetRawRoot__O(); var linked_1441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1440, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1442 lang.IFn; if linked_1441 == nil { ifn_1442 = lang.IFn_Cast(root_1440) } else { ifn_1442 = nil }; var arg_1443 any = s__716000167__3; if linked_1441 == nil { tmp1 = ifn_1442.Invoke_O__O(arg_1443) } else { tmp1 = linked_1441.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1440, arg_1443) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1444 any = A_arbace_repr_clojure_A_const_56.GetRawRoot__O(); var linked_1445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1444, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1446 lang.IFn; if linked_1445 == nil { ifn_1446 = lang.IFn_Cast(root_1444) } else { ifn_1446 = nil }; var arg_1447 any = s__716000167__3; if linked_1445 == nil { c__1927001037__auto____4 = ifn_1446.Invoke_O__O(arg_1447) } else { c__1927001037__auto____4 = linked_1445.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1444, arg_1447) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__716000169__6 any; var root_1448 any = A_arbace_repr_clojure_A_const_57.GetRawRoot__O(); var linked_1449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1448, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1450 lang.IFn; if linked_1449 == nil { ifn_1450 = lang.IFn_Cast(root_1448) } else { ifn_1450 = nil }; var arg_1451 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1449 == nil { b__716000169__6 = ifn_1450.Invoke_O__O(arg_1451) } else { b__716000169__6 = linked_1449.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1448, arg_1451) }; var tmp2 any = A_arbace_repr_clojure_roundtrip_iter__716000166__716000170_fn__716000171_fn__716000172_A_New_O_I_O(b__716000169__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1457 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000166__716000170_fn__716000171_fn__716000172_A_fn_class; if fncls__1457 == nil { var fncls__1457d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); A_arbace_repr_clojure_roundtrip_iter__716000166__716000170_fn__716000171_fn__716000172_A_fn_class = fncls__1457d; tmp3 = fncls__1457d } else { tmp3 = fncls__1457 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1466 any = A_arbace_repr_clojure_A_const_60.GetRawRoot__O(); var linked_1467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1466, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1468 lang.IFn; if linked_1467 == nil { ifn_1468 = lang.IFn_Cast(root_1466) } else { ifn_1468 = nil }; var arg_1469 any; var root_1458 any = A_arbace_repr_clojure_A_const_61.GetRawRoot__O(); var linked_1459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1458, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1460 lang.IFn; if linked_1459 == nil { ifn_1460 = lang.IFn_Cast(root_1458) } else { ifn_1460 = nil }; var arg_1461 any = b__716000169__6; if linked_1459 == nil { arg_1469 = ifn_1460.Invoke_O__O(arg_1461) } else { arg_1469 = linked_1459.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1458, arg_1461) }; var arg_1470 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__716000166); var tmp5 any; var root_1462 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_1463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1462, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1464 lang.IFn; if linked_1463 == nil { ifn_1464 = lang.IFn_Cast(root_1462) } else { ifn_1464 = nil }; var arg_1465 any = s__716000167__3; if linked_1463 == nil { tmp5 = ifn_1464.Invoke_O__O(arg_1465) } else { tmp5 = linked_1463.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1462, arg_1465) }; arg_1470 = tmp4.Invoke_O__O(tmp5); if linked_1467 == nil { return ifn_1468.Invoke_O_O__O(arg_1469, arg_1470) } else { return linked_1467.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1466, arg_1469, arg_1470) } } else { var root_1475 any = A_arbace_repr_clojure_A_const_60.GetRawRoot__O(); var linked_1476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1475, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1477 lang.IFn; if linked_1476 == nil { ifn_1477 = lang.IFn_Cast(root_1475) } else { ifn_1477 = nil }; var arg_1478 any; var root_1471 any = A_arbace_repr_clojure_A_const_61.GetRawRoot__O(); var linked_1472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1471, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1473 lang.IFn; if linked_1472 == nil { ifn_1473 = lang.IFn_Cast(root_1471) } else { ifn_1473 = nil }; var arg_1474 any = b__716000169__6; if linked_1472 == nil { arg_1478 = ifn_1473.Invoke_O__O(arg_1474) } else { arg_1478 = linked_1472.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1471, arg_1474) }; var arg_1479 any; if linked_1476 == nil { return ifn_1477.Invoke_O_O__O(arg_1478, arg_1479) } else { return linked_1476.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1475, arg_1478, arg_1479) } } } else { var vec__716000177__4 any; var root_1480 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_1481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1480, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1482 lang.IFn; if linked_1481 == nil { ifn_1482 = lang.IFn_Cast(root_1480) } else { ifn_1482 = nil }; var arg_1483 any = s__716000167__3; if linked_1481 == nil { vec__716000177__4 = ifn_1482.Invoke_O__O(arg_1483) } else { vec__716000177__4 = linked_1481.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1480, arg_1483) }; var out__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000177__4, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000177__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1488 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_1489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1488, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1490 lang.IFn; if linked_1489 == nil { ifn_1490 = lang.IFn_Cast(root_1488) } else { ifn_1490 = nil }; var arg_1491 any = lang.Tuple_Create_O_O__IPersistentVector(rel__6, out__5); var arg_1492 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__716000166); var tmp7 any; var root_1484 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_1485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1484, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1486 lang.IFn; if linked_1485 == nil { ifn_1486 = lang.IFn_Cast(root_1484) } else { ifn_1486 = nil }; var arg_1487 any = s__716000167__3; if linked_1485 == nil { tmp7 = ifn_1486.Invoke_O__O(arg_1487) } else { tmp7 = linked_1485.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1484, arg_1487) }; arg_1492 = tmp6.Invoke_O__O(tmp7); if linked_1489 == nil { return ifn_1490.Invoke_O_O__O(arg_1491, arg_1492) } else { return linked_1489.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1488, arg_1491, arg_1492) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :257:1
func A_arbace_repr_clojure_roundtrip_iter__716000166__716000170_fn__716000171_fn__716000172_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_clojure_roundtrip_iter__716000166__716000170_fn__716000171_fn__716000172_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000166__716000170_fn__716000171_fn__716000172_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :257:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000166__716000170_fn__716000171_fn__716000172_A) Ctor_O_I_O(c__b__716000169 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__716000169 = c__b__716000169; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :257:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000166__716000170_fn__716000171_fn__716000172_A) Invoke_O__O(self any) any { { var i__716000168__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__716000168__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__716000173__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__716000168__1)); var out__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000173__2, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000173__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1452 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_1453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1452, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1454 lang.IFn; if linked_1453 == nil { ifn_1454 = lang.IFn_Cast(root_1452) } else { ifn_1454 = nil }; var arg_1455 any = t.F_b__716000169; var arg_1456 any = lang.Tuple_Create_O_O__IPersistentVector(rel__4, out__3); if linked_1453 == nil { ifn_1454.Invoke_O_O__O(arg_1455, arg_1456) } else { linked_1453.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1452, arg_1455, arg_1456) }; i__716000168__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__716000168__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_repr_clojure_roundtrip_iter__716000182__716000186_A_New_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6 any) *A_arbace_repr_clojure_roundtrip_iter__716000182__716000186_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000182__716000186_A{}; t.Ctor_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :258:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000182__716000186_A) Ctor_O_O_O_O_O_O_O(c__back2, c__t, c__a, c__b, c__c, c__back, c__opts any) { t.F_back2 = c__back2; t.F_t = c__t; t.F_a = c__a; t.F_b = c__b; t.F_c = c__c; t.F_back = c__back; t.F_opts = c__opts }
//line :258:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000182__716000186_A) Invoke_O_O__O(self, s__716000183__1 any) any { var tmp1 any = A_arbace_repr_clojure_roundtrip_iter__716000182__716000186_fn__716000187_A_New_O_O_O_O_O_O_O_O_O(t.F_back2, s__716000183__1, t.F_t, t.F_a, t.F_b, t.F_c, t.F_back, t.F_opts, self); var tmp2 *jrt.Class; var fncls__1751 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000182__716000186_fn__716000187_A_fn_class; if fncls__1751 == nil { var fncls__1751d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); A_arbace_repr_clojure_roundtrip_iter__716000182__716000186_fn__716000187_A_fn_class = fncls__1751d; tmp2 = fncls__1751d } else { tmp2 = fncls__1751 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :258:1
func A_arbace_repr_clojure_roundtrip_iter__716000182__716000186_fn__716000187_A_New_O_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7, p8 any) *A_arbace_repr_clojure_roundtrip_iter__716000182__716000186_fn__716000187_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000182__716000186_fn__716000187_A{}; t.Ctor_O_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7, p8); return t }
//line :258:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000182__716000186_fn__716000187_A) Ctor_O_O_O_O_O_O_O_O_O(c__back2, c__s__716000183, c__t, c__a, c__b, c__c, c__back, c__opts, c__iter__716000182 any) { t.F_back2 = c__back2; t.F_s__716000183 = c__s__716000183; t.F_t = c__t; t.F_a = c__a; t.F_b = c__b; t.F_c = c__c; t.F_back = c__back; t.F_opts = c__opts; t.F_iter__716000182 = c__iter__716000182 }
//line :258:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000182__716000186_fn__716000187_A) Invoke_O__O(self any) any { { var s__716000183__1 any; var t_ any = t.F_s__716000183; t.F_s__716000183 = nil; s__716000183__1 = t_; for { var temp__1927000414__auto____2 any; var root_1500 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_1501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1500, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1502 lang.IFn; if linked_1501 == nil { ifn_1502 = lang.IFn_Cast(root_1500) } else { ifn_1502 = nil }; var arg_1503 any = s__716000183__1; if linked_1501 == nil { temp__1927000414__auto____2 = ifn_1502.Invoke_O__O(arg_1503) } else { temp__1927000414__auto____2 = linked_1501.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1500, arg_1503) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__716000183__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1504 any = A_arbace_repr_clojure_A_const_55.GetRawRoot__O(); var linked_1505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1504, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1506 lang.IFn; if linked_1505 == nil { ifn_1506 = lang.IFn_Cast(root_1504) } else { ifn_1506 = nil }; var arg_1507 any = s__716000183__3; if linked_1505 == nil { tmp1 = ifn_1506.Invoke_O__O(arg_1507) } else { tmp1 = linked_1505.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1504, arg_1507) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1508 any = A_arbace_repr_clojure_A_const_56.GetRawRoot__O(); var linked_1509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1508, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1510 lang.IFn; if linked_1509 == nil { ifn_1510 = lang.IFn_Cast(root_1508) } else { ifn_1510 = nil }; var arg_1511 any = s__716000183__3; if linked_1509 == nil { c__1927001037__auto____4 = ifn_1510.Invoke_O__O(arg_1511) } else { c__1927001037__auto____4 = linked_1509.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1508, arg_1511) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__716000185__6 any; var root_1512 any = A_arbace_repr_clojure_A_const_57.GetRawRoot__O(); var linked_1513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1512, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1514 lang.IFn; if linked_1513 == nil { ifn_1514 = lang.IFn_Cast(root_1512) } else { ifn_1514 = nil }; var arg_1515 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1513 == nil { b__716000185__6 = ifn_1514.Invoke_O__O(arg_1515) } else { b__716000185__6 = linked_1513.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1512, arg_1515) }; var tmp2 any = A_arbace_repr_clojure_roundtrip_iter__716000182__716000186_fn__716000187_fn__716000188_A_New_O_O_O_O_O_O_I_O_O_O(t.F_back2, t.F_t, b__716000185__6, t.F_a, t.F_b, t.F_c, size__1927001038__auto____5, t.F_back, t.F_opts, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1618 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000182__716000186_fn__716000187_fn__716000188_A_fn_class; if fncls__1618 == nil { var fncls__1618d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_79, false); A_arbace_repr_clojure_roundtrip_iter__716000182__716000186_fn__716000187_fn__716000188_A_fn_class = fncls__1618d; tmp3 = fncls__1618d } else { tmp3 = fncls__1618 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1627 any = A_arbace_repr_clojure_A_const_60.GetRawRoot__O(); var linked_1628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1627, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1629 lang.IFn; if linked_1628 == nil { ifn_1629 = lang.IFn_Cast(root_1627) } else { ifn_1629 = nil }; var arg_1630 any; var root_1619 any = A_arbace_repr_clojure_A_const_61.GetRawRoot__O(); var linked_1620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1619, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1621 lang.IFn; if linked_1620 == nil { ifn_1621 = lang.IFn_Cast(root_1619) } else { ifn_1621 = nil }; var arg_1622 any = b__716000185__6; if linked_1620 == nil { arg_1630 = ifn_1621.Invoke_O__O(arg_1622) } else { arg_1630 = linked_1620.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1619, arg_1622) }; var arg_1631 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__716000182); var tmp5 any; var root_1623 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_1624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1623, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1625 lang.IFn; if linked_1624 == nil { ifn_1625 = lang.IFn_Cast(root_1623) } else { ifn_1625 = nil }; var arg_1626 any = s__716000183__3; if linked_1624 == nil { tmp5 = ifn_1625.Invoke_O__O(arg_1626) } else { tmp5 = linked_1624.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1623, arg_1626) }; arg_1631 = tmp4.Invoke_O__O(tmp5); if linked_1628 == nil { return ifn_1629.Invoke_O_O__O(arg_1630, arg_1631) } else { return linked_1628.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1627, arg_1630, arg_1631) } } else { var root_1636 any = A_arbace_repr_clojure_A_const_60.GetRawRoot__O(); var linked_1637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1636, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1638 lang.IFn; if linked_1637 == nil { ifn_1638 = lang.IFn_Cast(root_1636) } else { ifn_1638 = nil }; var arg_1639 any; var root_1632 any = A_arbace_repr_clojure_A_const_61.GetRawRoot__O(); var linked_1633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1632, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1634 lang.IFn; if linked_1633 == nil { ifn_1634 = lang.IFn_Cast(root_1632) } else { ifn_1634 = nil }; var arg_1635 any = b__716000185__6; if linked_1633 == nil { arg_1639 = ifn_1634.Invoke_O__O(arg_1635) } else { arg_1639 = linked_1633.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1632, arg_1635) }; var arg_1640 any; if linked_1637 == nil { return ifn_1638.Invoke_O_O__O(arg_1639, arg_1640) } else { return linked_1637.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1636, arg_1639, arg_1640) } } } else { var vec__716000193__4 any; var root_1641 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_1642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1641, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1643 lang.IFn; if linked_1642 == nil { ifn_1643 = lang.IFn_Cast(root_1641) } else { ifn_1643 = nil }; var arg_1644 any = s__716000183__3; if linked_1642 == nil { vec__716000193__4 = ifn_1643.Invoke_O__O(arg_1644) } else { vec__716000193__4 = linked_1642.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1641, arg_1644) }; var out__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000193__4, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000193__4, lang.RT_IntCast_J__I_NoInit(1), nil); var orig__7 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_81.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_t).Invoke_O__O(rel__6)); var out2__8 any = lang.IFn_Cast(t.F_back).Invoke_O__O(out__5); var txt__9 any


	if jrt.J2g_Truth(out2__8) { var root_1649 any = A_arbace_repr_clojure_A_const_120.GetRawRoot__O(); var linked_1650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1649, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1651 lang.IFn; if linked_1650 == nil { ifn_1651 = lang.IFn_Cast(root_1649) } else { ifn_1651 = nil }; var arg_1652 any = t.F_b; var arg_1653 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_clojure_A_const_105, out2__8); if linked_1650 == nil { txt__9 = ifn_1651.Invoke_O_O__O(arg_1652, arg_1653) } else { txt__9 = linked_1650.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1649, arg_1652, arg_1653) } } else { txt__9 = nil }
//line :258:1
	var p__10 any; var root_1654 any = A_arbace_repr_clojure_A_const_120.GetRawRoot__O(); var linked_1655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1654, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1656 lang.IFn



	if linked_1655 == nil { ifn_1656 = lang.IFn_Cast(root_1654) } else { ifn_1656 = nil }; var arg_1657 any = t.F_a; var arg_1658 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_clojure_A_const_109, out__5); if linked_1655 == nil { p__10 = ifn_1656.Invoke_O_O__O(arg_1657, arg_1658) } else { p__10 = linked_1655.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1654, arg_1657, arg_1658) }
//line :258:1
	var root_1746 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_1747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1746, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1748 lang.IFn; if linked_1747 == nil { ifn_1748 = lang.IFn_Cast(root_1746) } else { ifn_1748 = nil }; var arg_1749 any; var tmp6 any




	if lang.Util_Identical_O_O__Z_NoInit(out2__8, nil) { tmp6 = A_arbace_repr_clojure_A_const_132 } else { var tmp7 any; var tmp8 any = A_arbace_repr_clojure_A_const_24; var and__1927000168__auto____11 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp8, A_arbace_repr_clojure_A_const_23.Invoke_O__O(p__10))

		if and__1927000168__auto____11 { var and__1927000168__auto____12 any = A_arbace_repr_clojure_A_const_26.Invoke_O__O(p__10); if jrt.J2g_Truth(and__1927000168__auto____12) { var root_1659 any = A_arbace_repr_clojure_A_const_44.GetRawRoot__O(); var linked_1660 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1659, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1661 lang.IFn; if linked_1660 == nil { ifn_1661 = lang.IFn_Cast(root_1659) } else { ifn_1661 = nil }; var arg_1662 any = A_arbace_repr_clojure_A_const_115; var arg_1663 any = A_arbace_repr_clojure_A_const_108.Invoke_O__O(t.F_opts); if linked_1660 == nil { tmp7 = ifn_1661.Invoke_O_O__O(arg_1662, arg_1663) } else { tmp7 = linked_1660.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1659, arg_1662, arg_1663) } } else { tmp7 = and__1927000168__auto____12 } } else { tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11).Ref() }
//line :263:1
		if jrt.J2g_Truth(tmp7) { var want__11 any; var root_1676 any = A_arbace_repr_clojure_A_const_106.GetRawRoot__O(); var linked_1677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1676, A_arbace_repr_clojure_under_A_fn_class); var ifn_1678 lang.IFn


			if linked_1677 == nil { ifn_1678 = lang.IFn_Cast(root_1676) } else { ifn_1678 = nil }; var arg_1679 any; var root_1664 any = A_arbace_repr_clojure_A_const_100.GetRawRoot__O(); var linked_1665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1664, A_arbace_repr_clojure_parent_of_A_fn_class); var ifn_1666 lang.IFn; if linked_1665 == nil { ifn_1666 = lang.IFn_Cast(root_1664) } else { ifn_1666 = nil }; var arg_1667 any = rel__6; if linked_1665 == nil { arg_1679 = ifn_1666.Invoke_O__O(arg_1667) } else { arg_1679 = linked_1665.(*A_arbace_repr_clojure_parent_of_A).Invoke_O_O__O(root_1664, arg_1667) }; var arg_1680 any; var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_52); var tmp10 any; var root_1672 any = A_arbace_repr_clojure_A_const_31.GetRawRoot__O(); var linked_1673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1672, A_arbace_repr_clojure_base_A_fn_class); var ifn_1674 lang.IFn; if linked_1673 == nil { ifn_1674 = lang.IFn_Cast(root_1672) } else { ifn_1674 = nil }; var arg_1675 any; var root_1668 any = A_arbace_repr_clojure_A_const_102.GetRawRoot__O(); var linked_1669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1668, A_arbace_repr_clojure_name_of_A_fn_class); var ifn_1670 lang.IFn; if linked_1669 == nil { ifn_1670 = lang.IFn_Cast(root_1668) } else { ifn_1670 = nil }; var arg_1671 any = rel__6; if linked_1669 == nil { arg_1675 = ifn_1670.Invoke_O__O(arg_1671) } else { arg_1675 = linked_1669.(*A_arbace_repr_clojure_name_of_A).Invoke_O_O__O(root_1668, arg_1671) }; if linked_1673 == nil { tmp10 = ifn_1674.Invoke_O__O(arg_1675) } else { tmp10 = linked_1673.(*A_arbace_repr_clojure_base_A).Invoke_O_O__O(root_1672, arg_1675) }; arg_1680 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, tmp10, nil)).Ref(); if linked_1677 == nil { want__11 = ifn_1678.Invoke_O_O__O(arg_1679, arg_1680) } else { want__11 = linked_1677.(*A_arbace_repr_clojure_under_A).Invoke_O_O_O__O(root_1676, arg_1679, arg_1680) }
//line :263:1
			var resolved__12 any; var root_1681 any = A_arbace_repr_clojure_A_const_122.GetRawRoot__O(); var linked_1682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1681, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_resolve_conditionals_A_fn_class); var ifn_1683 lang.IFn



			if linked_1682 == nil { ifn_1683 = lang.IFn_Cast(root_1681) } else { ifn_1683 = nil }; var arg_1684 any = orig__7; var arg_1685 any = A_arbace_repr_clojure_A_const_133; if linked_1682 == nil { resolved__12 = ifn_1683.Invoke_O_O__O(arg_1684, arg_1685) } else { resolved__12 = linked_1682.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_resolve_conditionals_A).Invoke_O_O_O__O(root_1681, arg_1684, arg_1685) }
			var tmp11 any; var root_1686 any = A_arbace_repr_clojure_A_const_44.GetRawRoot__O(); var linked_1687 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1686, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1688 lang.IFn; if linked_1687 == nil { ifn_1688 = lang.IFn_Cast(root_1686) } else { ifn_1688 = nil }; var arg_1689 any = out2__8; var arg_1690 any = want__11; if linked_1687 == nil { tmp11 = ifn_1688.Invoke_O_O__O(arg_1689, arg_1690) } else { tmp11 = linked_1687.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1686, arg_1689, arg_1690) }; if jrt.J2g_Truth(tmp11) { tmp6 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_124, A_arbace_repr_clojure_A_const_125, A_arbace_repr_clojure_A_const_126, out2__8)) } else { var tmp12 any; var root_1691 any = A_arbace_repr_clojure_A_const_44.GetRawRoot__O(); var linked_1692 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1691, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1693 lang.IFn
				if linked_1692 == nil { ifn_1693 = lang.IFn_Cast(root_1691) } else { ifn_1693 = nil }; var arg_1694 any = txt__9; var arg_1695 any = resolved__12; if linked_1692 == nil { tmp12 = ifn_1693.Invoke_O_O__O(arg_1694, arg_1695) } else { tmp12 = linked_1692.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1691, arg_1694, arg_1695) }
//line :268:1
				if jrt.J2g_Truth(tmp12) { var tmp13 any = A_arbace_repr_clojure_A_const_124; var tmp14 any = A_arbace_repr_clojure_A_const_19; var tmp15 any = A_arbace_repr_clojure_A_const_127; var tmp16 any; var root_1696 any = A_arbace_repr_clojure_A_const_128.GetRawRoot__O(); var linked_1697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1696, A_arbace_repr_clojure_first_difference_A_fn_class); var ifn_1698 lang.IFn
					if linked_1697 == nil { ifn_1698 = lang.IFn_Cast(root_1696) } else { ifn_1698 = nil }; var arg_1699 any = resolved__12; var arg_1700 any = txt__9; if linked_1697 == nil { tmp16 = ifn_1698.Invoke_O_O__O(arg_1699, arg_1700) } else { tmp16 = linked_1697.(*A_arbace_repr_clojure_first_difference_A).Invoke_O_O_O__O(root_1696, arg_1699, arg_1700) }
//line :268:1
					tmp6 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp14, tmp15, tmp16)) } else { if A_arbace_repr_clojure_A_const_33 != nil { tmp6 = A_arbace_repr_clojure_A_const_134 } else { tmp6 = nil } } } } else {
//line :263:1
						var tmp17 any; var root_1701 any = A_arbace_repr_clojure_A_const_44.GetRawRoot__O(); var linked_1702 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1701, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1703 lang.IFn







						if linked_1702 == nil { ifn_1703 = lang.IFn_Cast(root_1701) } else { ifn_1703 = nil }; var arg_1704 any = out2__8; var arg_1705 any = rel__6; if linked_1702 == nil { tmp17 = ifn_1703.Invoke_O_O__O(arg_1704, arg_1705) } else { tmp17 = linked_1702.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1701, arg_1704, arg_1705) }
//line :263:1
						if jrt.J2g_Truth(tmp17) { tmp6 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_124, A_arbace_repr_clojure_A_const_125, A_arbace_repr_clojure_A_const_126, out2__8)) } else { if lang.Util_Equiv_O_O__Z_NoInit(txt__9, orig__7) { tmp6 = nil } else { var tmp18 any; var tmp19 any = A_arbace_repr_clojure_A_const_115; var and__1927000168__auto____11_2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp19, A_arbace_repr_clojure_A_const_108.Invoke_O__O(t.F_opts))











							if and__1927000168__auto____11_2 { var and__1927000168__auto____12_2 any; var p__12 any; var tmp20 *lang.Keyword = A_arbace_repr_clojure_A_const_67; var tmp21 lang.IFn = lang.IFn_Cast(tmp20.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_A_const_66.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_A_const_95))); var tmp22 any; var root_1738 any = A_arbace_repr_clojure_A_const_102.GetRawRoot__O(); var linked_1739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1738, A_arbace_repr_clojure_name_of_A_fn_class); var ifn_1740 lang.IFn
								if linked_1739 == nil { ifn_1740 = lang.IFn_Cast(root_1738) } else { ifn_1740 = nil }; var arg_1741 any = out__5; if linked_1739 == nil { tmp22 = ifn_1740.Invoke_O__O(arg_1741) } else { tmp22 = linked_1739.(*A_arbace_repr_clojure_name_of_A).Invoke_O_O__O(root_1738, arg_1741) }; p__12 = tmp21.Invoke_O_O_O__O(tmp22, lang.PersistentHashSet_EMPTY.Ref(), t.F_opts)
//line :275:1
								var and__1927000168__auto____13 any = A_arbace_repr_clojure_A_const_23.Invoke_O__O(p__12)

								if jrt.J2g_Truth(and__1927000168__auto____13) {
									var root_1713 any = A_arbace_repr_clojure_A_const_44.GetRawRoot__O(); var linked_1714 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1713, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1715 lang.IFn; if linked_1714 == nil { ifn_1715 = lang.IFn_Cast(root_1713) } else { ifn_1715 = nil }; var arg_1716 any = orig__7; var arg_1717 any; var root_1706 any = A_arbace_repr_clojure_A_const_130.GetRawRoot__O(); var linked_1707 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1706, A_arbace_repr_clojure_translate_text_A_fn_class); var ifn_1708 lang.IFn; if linked_1707 == nil { ifn_1708 = lang.IFn_Cast(root_1706) } else { ifn_1708 = nil }; var arg_1709 any = orig__7; var arg_1710 any = p__12; var arg_1711 any = rel__6; var arg_1712 any = A_arbace_repr_clojure_A_const_32.Invoke_O_O__O(t.F_opts, lang.PersistentHashSet_EMPTY.Ref()); if linked_1707 == nil { arg_1717 = ifn_1708.Invoke_O_O_O_O__O(arg_1709, arg_1710, arg_1711, arg_1712) } else { arg_1717 = linked_1707.(*A_arbace_repr_clojure_translate_text_A).Invoke_O_O_O_O_O__O(root_1706, arg_1709, arg_1710, arg_1711, arg_1712) }; if linked_1714 == nil { and__1927000168__auto____12_2 = ifn_1715.Invoke_O_O__O(arg_1716, arg_1717) } else { and__1927000168__auto____12_2 = linked_1714.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1713, arg_1716, arg_1717) } } else {
//line :277:1
										and__1927000168__auto____12_2 = and__1927000168__auto____13 }
//line :275:1
								if jrt.J2g_Truth(and__1927000168__auto____12_2) {




									var tmp23 any; var root_1718 any = A_arbace_repr_clojure_A_const_120.GetRawRoot__O(); var linked_1719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1718, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1720 lang.IFn; if linked_1719 == nil { ifn_1720 = lang.IFn_Cast(root_1718) } else { ifn_1720 = nil }; var arg_1721 any = t.F_a; var arg_1722 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_clojure_A_const_105, out__5); if linked_1719 == nil { tmp23 = ifn_1720.Invoke_O_O__O(arg_1721, arg_1722) } else { tmp23 = linked_1719.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1718, arg_1721, arg_1722) }; var tmp24 any = tmp23; var tmp25 any; var root_1723 any = A_arbace_repr_clojure_A_const_120.GetRawRoot__O(); var linked_1724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1723, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1725 lang.IFn; if linked_1724 == nil { ifn_1725 = lang.IFn_Cast(root_1723) } else { ifn_1725 = nil }; var arg_1726 any = t.F_c; var tmp26 any = A_arbace_repr_clojure_A_const_105; var arg_1727 any = lang.Tuple_Create_O_O__IPersistentVector(tmp26, lang.IFn_Cast(t.F_back2).Invoke_O__O(out2__8)); if linked_1724 == nil { tmp25 = ifn_1725.Invoke_O_O__O(arg_1726, arg_1727) } else { tmp25 = linked_1724.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1723, arg_1726, arg_1727) }; tmp18 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp24, tmp25)).Ref() } else {
//line :275:1
										tmp18 = and__1927000168__auto____12_2 } } else { tmp18 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11_2).Ref() }
//line :263:1
							if jrt.J2g_Truth(tmp18) { var tmp27 any = A_arbace_repr_clojure_A_const_124; var tmp28 any = A_arbace_repr_clojure_A_const_131; var tmp29 any = A_arbace_repr_clojure_A_const_127; var tmp30 any; var root_1728 any = A_arbace_repr_clojure_A_const_128.GetRawRoot__O(); var linked_1729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1728, A_arbace_repr_clojure_first_difference_A_fn_class); var ifn_1730 lang.IFn

















								if linked_1729 == nil { ifn_1730 = lang.IFn_Cast(root_1728) } else { ifn_1730 = nil }; var arg_1731 any = orig__7; var arg_1732 any = txt__9; if linked_1729 == nil { tmp30 = ifn_1730.Invoke_O_O__O(arg_1731, arg_1732) } else { tmp30 = linked_1729.(*A_arbace_repr_clojure_first_difference_A).Invoke_O_O_O__O(root_1728, arg_1731, arg_1732) }
//line :263:1
								tmp6 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp27, tmp28, tmp29, tmp30)) } else { if A_arbace_repr_clojure_A_const_33 != nil { var tmp31 any = A_arbace_repr_clojure_A_const_124; var tmp32 any = A_arbace_repr_clojure_A_const_19; var tmp33 any = A_arbace_repr_clojure_A_const_127; var tmp34 any; var root_1733 any = A_arbace_repr_clojure_A_const_128.GetRawRoot__O(); var linked_1734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1733, A_arbace_repr_clojure_first_difference_A_fn_class); var ifn_1735 lang.IFn


















									if linked_1734 == nil { ifn_1735 = lang.IFn_Cast(root_1733) } else { ifn_1735 = nil }; var arg_1736 any = orig__7; var arg_1737 any = txt__9; if linked_1734 == nil { tmp34 = ifn_1735.Invoke_O_O__O(arg_1736, arg_1737) } else { tmp34 = linked_1734.(*A_arbace_repr_clojure_first_difference_A).Invoke_O_O_O__O(root_1733, arg_1736, arg_1737) }
//line :263:1
									tmp6 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp31, tmp32, tmp33, tmp34)) } else { tmp6 = nil } } } } } }
//line :258:1
	arg_1749 = lang.Tuple_Create_O_O__IPersistentVector(rel__6, tmp6); var arg_1750 any; var tmp35 lang.IFn = lang.IFn_Cast(t.F_iter__716000182); var tmp36 any; var root_1742 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_1743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1742, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1744 lang.IFn; if linked_1743 == nil { ifn_1744 = lang.IFn_Cast(root_1742) } else { ifn_1744 = nil }; var arg_1745 any = s__716000183__3; if linked_1743 == nil { tmp36 = ifn_1744.Invoke_O__O(arg_1745) } else { tmp36 = linked_1743.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1742, arg_1745) }; arg_1750 = tmp35.Invoke_O__O(tmp36); if linked_1747 == nil { return ifn_1748.Invoke_O_O__O(arg_1749, arg_1750) } else { return linked_1747.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1746, arg_1749, arg_1750) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :258:1
func A_arbace_repr_clojure_roundtrip_iter__716000182__716000186_fn__716000187_fn__716000188_A_New_O_O_O_O_O_O_I_O_O_O(p0, p1, p2, p3, p4, p5 any, p6 int32, p7, p8, p9 any) *A_arbace_repr_clojure_roundtrip_iter__716000182__716000186_fn__716000187_fn__716000188_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000182__716000186_fn__716000187_fn__716000188_A{}; t.Ctor_O_O_O_O_O_O_I_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9); return t }
//line :258:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000182__716000186_fn__716000187_fn__716000188_A) Ctor_O_O_O_O_O_O_I_O_O_O(c__back2, c__t, c__b__716000185, c__a, c__b, c__c any, c__size__1927001038__auto__ int32, c__back, c__opts, c__c__1927001037__auto__ any) { t.F_back2 = c__back2; t.F_t = c__t; t.F_b__716000185 = c__b__716000185; t.F_a = c__a; t.F_b = c__b; t.F_c = c__c; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_back = c__back; t.F_opts = c__opts; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :258:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000182__716000186_fn__716000187_fn__716000188_A) Invoke_O__O(self any) any { { var i__716000184__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__716000184__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__716000189__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__716000184__1)); var out__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000189__2, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000189__2, lang.RT_IntCast_J__I_NoInit(1), nil); var orig__5 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_81.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_t).Invoke_O__O(rel__4)); var out2__6 any = lang.IFn_Cast(t.F_back).Invoke_O__O(out__3); var txt__7 any


	if jrt.J2g_Truth(out2__6) { var root_1520 any = A_arbace_repr_clojure_A_const_120.GetRawRoot__O(); var linked_1521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1520, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1522 lang.IFn; if linked_1521 == nil { ifn_1522 = lang.IFn_Cast(root_1520) } else { ifn_1522 = nil }; var arg_1523 any = t.F_b; var arg_1524 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_clojure_A_const_105, out2__6); if linked_1521 == nil { txt__7 = ifn_1522.Invoke_O_O__O(arg_1523, arg_1524) } else { txt__7 = linked_1521.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1520, arg_1523, arg_1524) } } else { txt__7 = nil }
//line :258:1
	var p__8 any; var root_1525 any = A_arbace_repr_clojure_A_const_120.GetRawRoot__O(); var linked_1526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1525, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1527 lang.IFn



	if linked_1526 == nil { ifn_1527 = lang.IFn_Cast(root_1525) } else { ifn_1527 = nil }; var arg_1528 any = t.F_a; var arg_1529 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_clojure_A_const_109, out__3); if linked_1526 == nil { p__8 = ifn_1527.Invoke_O_O__O(arg_1528, arg_1529) } else { p__8 = linked_1526.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1525, arg_1528, arg_1529) }
//line :258:1
	var root_1613 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_1614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1613, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1615 lang.IFn; if linked_1614 == nil { ifn_1615 = lang.IFn_Cast(root_1613) } else { ifn_1615 = nil }; var arg_1616 any = t.F_b__716000185; var arg_1617 any; var tmp2 any




	if lang.Util_Identical_O_O__Z_NoInit(out2__6, nil) { tmp2 = A_arbace_repr_clojure_A_const_121 } else { var tmp3 any; var tmp4 any = A_arbace_repr_clojure_A_const_24; var and__1927000168__auto____9 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp4, A_arbace_repr_clojure_A_const_23.Invoke_O__O(p__8))

		if and__1927000168__auto____9 { var and__1927000168__auto____10 any = A_arbace_repr_clojure_A_const_26.Invoke_O__O(p__8); if jrt.J2g_Truth(and__1927000168__auto____10) { var root_1530 any = A_arbace_repr_clojure_A_const_44.GetRawRoot__O(); var linked_1531 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1530, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1532 lang.IFn; if linked_1531 == nil { ifn_1532 = lang.IFn_Cast(root_1530) } else { ifn_1532 = nil }; var arg_1533 any = A_arbace_repr_clojure_A_const_115; var arg_1534 any = A_arbace_repr_clojure_A_const_108.Invoke_O__O(t.F_opts); if linked_1531 == nil { tmp3 = ifn_1532.Invoke_O_O__O(arg_1533, arg_1534) } else { tmp3 = linked_1531.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1530, arg_1533, arg_1534) } } else { tmp3 = and__1927000168__auto____10 } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____9).Ref() }
//line :263:1
		if jrt.J2g_Truth(tmp3) { var want__9 any; var root_1547 any = A_arbace_repr_clojure_A_const_106.GetRawRoot__O(); var linked_1548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1547, A_arbace_repr_clojure_under_A_fn_class); var ifn_1549 lang.IFn


			if linked_1548 == nil { ifn_1549 = lang.IFn_Cast(root_1547) } else { ifn_1549 = nil }; var arg_1550 any; var root_1535 any = A_arbace_repr_clojure_A_const_100.GetRawRoot__O(); var linked_1536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1535, A_arbace_repr_clojure_parent_of_A_fn_class); var ifn_1537 lang.IFn; if linked_1536 == nil { ifn_1537 = lang.IFn_Cast(root_1535) } else { ifn_1537 = nil }; var arg_1538 any = rel__4; if linked_1536 == nil { arg_1550 = ifn_1537.Invoke_O__O(arg_1538) } else { arg_1550 = linked_1536.(*A_arbace_repr_clojure_parent_of_A).Invoke_O_O__O(root_1535, arg_1538) }; var arg_1551 any; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_52); var tmp6 any; var root_1543 any = A_arbace_repr_clojure_A_const_31.GetRawRoot__O(); var linked_1544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1543, A_arbace_repr_clojure_base_A_fn_class); var ifn_1545 lang.IFn; if linked_1544 == nil { ifn_1545 = lang.IFn_Cast(root_1543) } else { ifn_1545 = nil }; var arg_1546 any; var root_1539 any = A_arbace_repr_clojure_A_const_102.GetRawRoot__O(); var linked_1540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1539, A_arbace_repr_clojure_name_of_A_fn_class); var ifn_1541 lang.IFn; if linked_1540 == nil { ifn_1541 = lang.IFn_Cast(root_1539) } else { ifn_1541 = nil }; var arg_1542 any = rel__4; if linked_1540 == nil { arg_1546 = ifn_1541.Invoke_O__O(arg_1542) } else { arg_1546 = linked_1540.(*A_arbace_repr_clojure_name_of_A).Invoke_O_O__O(root_1539, arg_1542) }; if linked_1544 == nil { tmp6 = ifn_1545.Invoke_O__O(arg_1546) } else { tmp6 = linked_1544.(*A_arbace_repr_clojure_base_A).Invoke_O_O__O(root_1543, arg_1546) }; arg_1551 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp6, nil)).Ref(); if linked_1548 == nil { want__9 = ifn_1549.Invoke_O_O__O(arg_1550, arg_1551) } else { want__9 = linked_1548.(*A_arbace_repr_clojure_under_A).Invoke_O_O_O__O(root_1547, arg_1550, arg_1551) }
//line :263:1
			var resolved__10 any; var root_1552 any = A_arbace_repr_clojure_A_const_122.GetRawRoot__O(); var linked_1553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1552, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_resolve_conditionals_A_fn_class); var ifn_1554 lang.IFn



			if linked_1553 == nil { ifn_1554 = lang.IFn_Cast(root_1552) } else { ifn_1554 = nil }; var arg_1555 any = orig__5; var arg_1556 any = A_arbace_repr_clojure_A_const_123; if linked_1553 == nil { resolved__10 = ifn_1554.Invoke_O_O__O(arg_1555, arg_1556) } else { resolved__10 = linked_1553.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_resolve_conditionals_A).Invoke_O_O_O__O(root_1552, arg_1555, arg_1556) }
			var tmp7 any; var root_1557 any = A_arbace_repr_clojure_A_const_44.GetRawRoot__O(); var linked_1558 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1557, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1559 lang.IFn; if linked_1558 == nil { ifn_1559 = lang.IFn_Cast(root_1557) } else { ifn_1559 = nil }; var arg_1560 any = out2__6; var arg_1561 any = want__9; if linked_1558 == nil { tmp7 = ifn_1559.Invoke_O_O__O(arg_1560, arg_1561) } else { tmp7 = linked_1558.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1557, arg_1560, arg_1561) }; if jrt.J2g_Truth(tmp7) { tmp2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_124, A_arbace_repr_clojure_A_const_125, A_arbace_repr_clojure_A_const_126, out2__6)) } else { var tmp8 any; var root_1562 any = A_arbace_repr_clojure_A_const_44.GetRawRoot__O(); var linked_1563 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1562, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1564 lang.IFn
				if linked_1563 == nil { ifn_1564 = lang.IFn_Cast(root_1562) } else { ifn_1564 = nil }; var arg_1565 any = txt__7; var arg_1566 any = resolved__10; if linked_1563 == nil { tmp8 = ifn_1564.Invoke_O_O__O(arg_1565, arg_1566) } else { tmp8 = linked_1563.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1562, arg_1565, arg_1566) }
//line :268:1
				if jrt.J2g_Truth(tmp8) { var tmp9 any = A_arbace_repr_clojure_A_const_124; var tmp10 any = A_arbace_repr_clojure_A_const_19; var tmp11 any = A_arbace_repr_clojure_A_const_127; var tmp12 any; var root_1567 any = A_arbace_repr_clojure_A_const_128.GetRawRoot__O(); var linked_1568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1567, A_arbace_repr_clojure_first_difference_A_fn_class); var ifn_1569 lang.IFn
					if linked_1568 == nil { ifn_1569 = lang.IFn_Cast(root_1567) } else { ifn_1569 = nil }; var arg_1570 any = resolved__10; var arg_1571 any = txt__7; if linked_1568 == nil { tmp12 = ifn_1569.Invoke_O_O__O(arg_1570, arg_1571) } else { tmp12 = linked_1568.(*A_arbace_repr_clojure_first_difference_A).Invoke_O_O_O__O(root_1567, arg_1570, arg_1571) }
//line :268:1
					tmp2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, tmp11, tmp12)) } else { if A_arbace_repr_clojure_A_const_33 != nil { tmp2 = A_arbace_repr_clojure_A_const_129 } else { tmp2 = nil } } } } else {
//line :263:1
						var tmp13 any; var root_1572 any = A_arbace_repr_clojure_A_const_44.GetRawRoot__O(); var linked_1573 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1572, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1574 lang.IFn







						if linked_1573 == nil { ifn_1574 = lang.IFn_Cast(root_1572) } else { ifn_1574 = nil }; var arg_1575 any = out2__6; var arg_1576 any = rel__4; if linked_1573 == nil { tmp13 = ifn_1574.Invoke_O_O__O(arg_1575, arg_1576) } else { tmp13 = linked_1573.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1572, arg_1575, arg_1576) }
//line :263:1
						if jrt.J2g_Truth(tmp13) { tmp2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_124, A_arbace_repr_clojure_A_const_125, A_arbace_repr_clojure_A_const_126, out2__6)) } else { if lang.Util_Equiv_O_O__Z_NoInit(txt__7, orig__5) { tmp2 = nil } else { var tmp14 any; var tmp15 any = A_arbace_repr_clojure_A_const_115; var and__1927000168__auto____9_2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp15, A_arbace_repr_clojure_A_const_108.Invoke_O__O(t.F_opts))











							if and__1927000168__auto____9_2 { var and__1927000168__auto____10_2 any; var p__10 any; var tmp16 *lang.Keyword = A_arbace_repr_clojure_A_const_67; var tmp17 lang.IFn = lang.IFn_Cast(tmp16.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_A_const_66.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_A_const_95))); var tmp18 any; var root_1609 any = A_arbace_repr_clojure_A_const_102.GetRawRoot__O(); var linked_1610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1609, A_arbace_repr_clojure_name_of_A_fn_class); var ifn_1611 lang.IFn
								if linked_1610 == nil { ifn_1611 = lang.IFn_Cast(root_1609) } else { ifn_1611 = nil }; var arg_1612 any = out__3; if linked_1610 == nil { tmp18 = ifn_1611.Invoke_O__O(arg_1612) } else { tmp18 = linked_1610.(*A_arbace_repr_clojure_name_of_A).Invoke_O_O__O(root_1609, arg_1612) }; p__10 = tmp17.Invoke_O_O_O__O(tmp18, lang.PersistentHashSet_EMPTY.Ref(), t.F_opts)
//line :275:1
								var and__1927000168__auto____11 any = A_arbace_repr_clojure_A_const_23.Invoke_O__O(p__10)

								if jrt.J2g_Truth(and__1927000168__auto____11) {
									var root_1584 any = A_arbace_repr_clojure_A_const_44.GetRawRoot__O(); var linked_1585 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1584, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1586 lang.IFn; if linked_1585 == nil { ifn_1586 = lang.IFn_Cast(root_1584) } else { ifn_1586 = nil }; var arg_1587 any = orig__5; var arg_1588 any; var root_1577 any = A_arbace_repr_clojure_A_const_130.GetRawRoot__O(); var linked_1578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1577, A_arbace_repr_clojure_translate_text_A_fn_class); var ifn_1579 lang.IFn; if linked_1578 == nil { ifn_1579 = lang.IFn_Cast(root_1577) } else { ifn_1579 = nil }; var arg_1580 any = orig__5; var arg_1581 any = p__10; var arg_1582 any = rel__4; var arg_1583 any = A_arbace_repr_clojure_A_const_32.Invoke_O_O__O(t.F_opts, lang.PersistentHashSet_EMPTY.Ref()); if linked_1578 == nil { arg_1588 = ifn_1579.Invoke_O_O_O_O__O(arg_1580, arg_1581, arg_1582, arg_1583) } else { arg_1588 = linked_1578.(*A_arbace_repr_clojure_translate_text_A).Invoke_O_O_O_O_O__O(root_1577, arg_1580, arg_1581, arg_1582, arg_1583) }; if linked_1585 == nil { and__1927000168__auto____10_2 = ifn_1586.Invoke_O_O__O(arg_1587, arg_1588) } else { and__1927000168__auto____10_2 = linked_1585.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1584, arg_1587, arg_1588) } } else {
//line :277:1
										and__1927000168__auto____10_2 = and__1927000168__auto____11 }
//line :275:1
								if jrt.J2g_Truth(and__1927000168__auto____10_2) {




									var tmp19 any; var root_1589 any = A_arbace_repr_clojure_A_const_120.GetRawRoot__O(); var linked_1590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1589, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1591 lang.IFn; if linked_1590 == nil { ifn_1591 = lang.IFn_Cast(root_1589) } else { ifn_1591 = nil }; var arg_1592 any = t.F_a; var arg_1593 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_clojure_A_const_105, out__3); if linked_1590 == nil { tmp19 = ifn_1591.Invoke_O_O__O(arg_1592, arg_1593) } else { tmp19 = linked_1590.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1589, arg_1592, arg_1593) }; var tmp20 any = tmp19; var tmp21 any; var root_1594 any = A_arbace_repr_clojure_A_const_120.GetRawRoot__O(); var linked_1595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1594, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1596 lang.IFn; if linked_1595 == nil { ifn_1596 = lang.IFn_Cast(root_1594) } else { ifn_1596 = nil }; var arg_1597 any = t.F_c; var tmp22 any = A_arbace_repr_clojure_A_const_105; var arg_1598 any = lang.Tuple_Create_O_O__IPersistentVector(tmp22, lang.IFn_Cast(t.F_back2).Invoke_O__O(out2__6)); if linked_1595 == nil { tmp21 = ifn_1596.Invoke_O_O__O(arg_1597, arg_1598) } else { tmp21 = linked_1595.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1594, arg_1597, arg_1598) }; tmp14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp20, tmp21)).Ref() } else {
//line :275:1
										tmp14 = and__1927000168__auto____10_2 } } else { tmp14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____9_2).Ref() }
//line :263:1
							if jrt.J2g_Truth(tmp14) { var tmp23 any = A_arbace_repr_clojure_A_const_124; var tmp24 any = A_arbace_repr_clojure_A_const_131; var tmp25 any = A_arbace_repr_clojure_A_const_127; var tmp26 any; var root_1599 any = A_arbace_repr_clojure_A_const_128.GetRawRoot__O(); var linked_1600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1599, A_arbace_repr_clojure_first_difference_A_fn_class); var ifn_1601 lang.IFn

















								if linked_1600 == nil { ifn_1601 = lang.IFn_Cast(root_1599) } else { ifn_1601 = nil }; var arg_1602 any = orig__5; var arg_1603 any = txt__7; if linked_1600 == nil { tmp26 = ifn_1601.Invoke_O_O__O(arg_1602, arg_1603) } else { tmp26 = linked_1600.(*A_arbace_repr_clojure_first_difference_A).Invoke_O_O_O__O(root_1599, arg_1602, arg_1603) }
//line :263:1
								tmp2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp23, tmp24, tmp25, tmp26)) } else { if A_arbace_repr_clojure_A_const_33 != nil { var tmp27 any = A_arbace_repr_clojure_A_const_124; var tmp28 any = A_arbace_repr_clojure_A_const_19; var tmp29 any = A_arbace_repr_clojure_A_const_127; var tmp30 any; var root_1604 any = A_arbace_repr_clojure_A_const_128.GetRawRoot__O(); var linked_1605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1604, A_arbace_repr_clojure_first_difference_A_fn_class); var ifn_1606 lang.IFn


















									if linked_1605 == nil { ifn_1606 = lang.IFn_Cast(root_1604) } else { ifn_1606 = nil }; var arg_1607 any = orig__5; var arg_1608 any = txt__7; if linked_1605 == nil { tmp30 = ifn_1606.Invoke_O_O__O(arg_1607, arg_1608) } else { tmp30 = linked_1605.(*A_arbace_repr_clojure_first_difference_A).Invoke_O_O_O__O(root_1604, arg_1607, arg_1608) }
//line :263:1
									tmp2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp27, tmp28, tmp29, tmp30)) } else { tmp2 = nil } } } } } }
//line :258:1
	arg_1617 = lang.Tuple_Create_O_O__IPersistentVector(rel__4, tmp2); if linked_1614 == nil { ifn_1615.Invoke_O_O__O(arg_1616, arg_1617) } else { linked_1614.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1613, arg_1616, arg_1617) }; i__716000184__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__716000184__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




























func A_arbace_repr_clojure_roundtrip_iter__716000198__716000202_A_New() *A_arbace_repr_clojure_roundtrip_iter__716000198__716000202_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000198__716000202_A{}; t.Ctor(); return t }
//line :287:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000198__716000202_A) Ctor() {}
//line :287:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000198__716000202_A) Invoke_O_O__O(self, s__716000199__1 any) any { var tmp1 any = A_arbace_repr_clojure_roundtrip_iter__716000198__716000202_fn__716000203_A_New_O_O(self, s__716000199__1); var tmp2 *jrt.Class; var fncls__1823 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000198__716000202_fn__716000203_A_fn_class; if fncls__1823 == nil { var fncls__1823d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_repr_clojure_roundtrip_iter__716000198__716000202_fn__716000203_A_fn_class = fncls__1823d; tmp2 = fncls__1823d } else { tmp2 = fncls__1823 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :287:1
func A_arbace_repr_clojure_roundtrip_iter__716000198__716000202_fn__716000203_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_roundtrip_iter__716000198__716000202_fn__716000203_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000198__716000202_fn__716000203_A{}; t.Ctor_O_O(p0, p1); return t }
//line :287:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000198__716000202_fn__716000203_A) Ctor_O_O(c__iter__716000198, c__s__716000199 any) { t.F_iter__716000198 = c__iter__716000198; t.F_s__716000199 = c__s__716000199 }
//line :287:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000198__716000202_fn__716000203_A) Invoke_O__O(self any) any { { var s__716000199__1 any; var t_ any = t.F_s__716000199; t.F_s__716000199 = nil; s__716000199__1 = t_; for { var temp__1927000414__auto____2 any; var root_1766 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_1767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1766, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1768 lang.IFn; if linked_1767 == nil { ifn_1768 = lang.IFn_Cast(root_1766) } else { ifn_1768 = nil }; var arg_1769 any = s__716000199__1; if linked_1767 == nil { temp__1927000414__auto____2 = ifn_1768.Invoke_O__O(arg_1769) } else { temp__1927000414__auto____2 = linked_1767.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1766, arg_1769) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__716000199__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1770 any = A_arbace_repr_clojure_A_const_55.GetRawRoot__O(); var linked_1771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1770, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1772 lang.IFn; if linked_1771 == nil { ifn_1772 = lang.IFn_Cast(root_1770) } else { ifn_1772 = nil }; var arg_1773 any = s__716000199__3; if linked_1771 == nil { tmp1 = ifn_1772.Invoke_O__O(arg_1773) } else { tmp1 = linked_1771.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1770, arg_1773) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1774 any = A_arbace_repr_clojure_A_const_56.GetRawRoot__O(); var linked_1775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1774, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1776 lang.IFn; if linked_1775 == nil { ifn_1776 = lang.IFn_Cast(root_1774) } else { ifn_1776 = nil }; var arg_1777 any = s__716000199__3; if linked_1775 == nil { c__1927001037__auto____4 = ifn_1776.Invoke_O__O(arg_1777) } else { c__1927001037__auto____4 = linked_1775.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1774, arg_1777) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__716000201__6 any; var root_1778 any = A_arbace_repr_clojure_A_const_57.GetRawRoot__O(); var linked_1779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1778, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1780 lang.IFn; if linked_1779 == nil { ifn_1780 = lang.IFn_Cast(root_1778) } else { ifn_1780 = nil }; var arg_1781 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1779 == nil { b__716000201__6 = ifn_1780.Invoke_O__O(arg_1781) } else { b__716000201__6 = linked_1779.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1778, arg_1781) }; var tmp2 any = A_arbace_repr_clojure_roundtrip_iter__716000198__716000202_fn__716000203_fn__716000204_A_New_O_I_O(b__716000201__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1787 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000198__716000202_fn__716000203_fn__716000204_A_fn_class; if fncls__1787 == nil { var fncls__1787d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_repr_clojure_roundtrip_iter__716000198__716000202_fn__716000203_fn__716000204_A_fn_class = fncls__1787d; tmp3 = fncls__1787d } else { tmp3 = fncls__1787 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1796 any = A_arbace_repr_clojure_A_const_60.GetRawRoot__O(); var linked_1797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1796, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1798 lang.IFn; if linked_1797 == nil { ifn_1798 = lang.IFn_Cast(root_1796) } else { ifn_1798 = nil }; var arg_1799 any; var root_1788 any = A_arbace_repr_clojure_A_const_61.GetRawRoot__O(); var linked_1789 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1788, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1790 lang.IFn; if linked_1789 == nil { ifn_1790 = lang.IFn_Cast(root_1788) } else { ifn_1790 = nil }; var arg_1791 any = b__716000201__6; if linked_1789 == nil { arg_1799 = ifn_1790.Invoke_O__O(arg_1791) } else { arg_1799 = linked_1789.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1788, arg_1791) }; var arg_1800 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__716000198); var tmp5 any; var root_1792 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_1793 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1792, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1794 lang.IFn; if linked_1793 == nil { ifn_1794 = lang.IFn_Cast(root_1792) } else { ifn_1794 = nil }; var arg_1795 any = s__716000199__3; if linked_1793 == nil { tmp5 = ifn_1794.Invoke_O__O(arg_1795) } else { tmp5 = linked_1793.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1792, arg_1795) }; arg_1800 = tmp4.Invoke_O__O(tmp5); if linked_1797 == nil { return ifn_1798.Invoke_O_O__O(arg_1799, arg_1800) } else { return linked_1797.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1796, arg_1799, arg_1800) } } else { var root_1805 any = A_arbace_repr_clojure_A_const_60.GetRawRoot__O(); var linked_1806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1805, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1807 lang.IFn; if linked_1806 == nil { ifn_1807 = lang.IFn_Cast(root_1805) } else { ifn_1807 = nil }; var arg_1808 any; var root_1801 any = A_arbace_repr_clojure_A_const_61.GetRawRoot__O(); var linked_1802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1801, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1803 lang.IFn; if linked_1802 == nil { ifn_1803 = lang.IFn_Cast(root_1801) } else { ifn_1803 = nil }; var arg_1804 any = b__716000201__6; if linked_1802 == nil { arg_1808 = ifn_1803.Invoke_O__O(arg_1804) } else { arg_1808 = linked_1802.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1801, arg_1804) }; var arg_1809 any; if linked_1806 == nil { return ifn_1807.Invoke_O_O__O(arg_1808, arg_1809) } else { return linked_1806.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1805, arg_1808, arg_1809) } } } else { var vec__716000209__4 any; var root_1810 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_1811 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1810, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1812 lang.IFn; if linked_1811 == nil { ifn_1812 = lang.IFn_Cast(root_1810) } else { ifn_1812 = nil }; var arg_1813 any = s__716000199__3; if linked_1811 == nil { vec__716000209__4 = ifn_1812.Invoke_O__O(arg_1813) } else { vec__716000209__4 = linked_1811.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1810, arg_1813) }; var rel__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000209__4, lang.RT_IntCast_J__I_NoInit(0), nil); var m__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000209__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1818 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_1819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1818, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1820 lang.IFn; if linked_1819 == nil { ifn_1820 = lang.IFn_Cast(root_1818) } else { ifn_1820 = nil }; var arg_1821 any = lang.Tuple_Create_O_O__IPersistentVector(rel__5, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_124, A_arbace_repr_clojure_A_const_110, A_arbace_repr_clojure_A_const_127, m__6))); var arg_1822 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__716000198); var tmp7 any; var root_1814 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_1815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1814, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1816 lang.IFn; if linked_1815 == nil { ifn_1816 = lang.IFn_Cast(root_1814) } else { ifn_1816 = nil }; var arg_1817 any = s__716000199__3; if linked_1815 == nil { tmp7 = ifn_1816.Invoke_O__O(arg_1817) } else { tmp7 = linked_1815.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1814, arg_1817) }; arg_1822 = tmp6.Invoke_O__O(tmp7); if linked_1819 == nil { return ifn_1820.Invoke_O_O__O(arg_1821, arg_1822) } else { return linked_1819.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1818, arg_1821, arg_1822) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :287:1
func A_arbace_repr_clojure_roundtrip_iter__716000198__716000202_fn__716000203_fn__716000204_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_clojure_roundtrip_iter__716000198__716000202_fn__716000203_fn__716000204_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000198__716000202_fn__716000203_fn__716000204_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :287:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000198__716000202_fn__716000203_fn__716000204_A) Ctor_O_I_O(c__b__716000201 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__716000201 = c__b__716000201; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :287:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000198__716000202_fn__716000203_fn__716000204_A) Invoke_O__O(self any) any { { var i__716000200__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__716000200__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__716000205__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__716000200__1)); var rel__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000205__2, lang.RT_IntCast_J__I_NoInit(0), nil); var m__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000205__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1782 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_1783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1782, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1784 lang.IFn; if linked_1783 == nil { ifn_1784 = lang.IFn_Cast(root_1782) } else { ifn_1784 = nil }; var arg_1785 any = t.F_b__716000201; var arg_1786 any = lang.Tuple_Create_O_O__IPersistentVector(rel__3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_124, A_arbace_repr_clojure_A_const_110, A_arbace_repr_clojure_A_const_127, m__4))); if linked_1783 == nil { ifn_1784.Invoke_O_O__O(arg_1785, arg_1786) } else { linked_1783.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1782, arg_1785, arg_1786) }; i__716000200__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__716000200__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_repr_clojure_roundtrip_iter__716000214__716000218_A_New_O(p0 any) *A_arbace_repr_clojure_roundtrip_iter__716000214__716000218_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000214__716000218_A{}; t.Ctor_O(p0); return t }
//line :289:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000214__716000218_A) Ctor_O(c__a any) { t.F_a = c__a }
//line :289:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000214__716000218_A) Invoke_O_O__O(self, s__716000215__1 any) any { var tmp1 any = A_arbace_repr_clojure_roundtrip_iter__716000214__716000218_fn__716000219_A_New_O_O_O(self, s__716000215__1, t.F_a); var tmp2 *jrt.Class; var fncls__1882 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000214__716000218_fn__716000219_A_fn_class; if fncls__1882 == nil { var fncls__1882d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_82, false); A_arbace_repr_clojure_roundtrip_iter__716000214__716000218_fn__716000219_A_fn_class = fncls__1882d; tmp2 = fncls__1882d } else { tmp2 = fncls__1882 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :289:1
func A_arbace_repr_clojure_roundtrip_iter__716000214__716000218_fn__716000219_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_clojure_roundtrip_iter__716000214__716000218_fn__716000219_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000214__716000218_fn__716000219_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :289:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000214__716000218_fn__716000219_A) Ctor_O_O_O(c__iter__716000214, c__s__716000215, c__a any) { t.F_iter__716000214 = c__iter__716000214; t.F_s__716000215 = c__s__716000215; t.F_a = c__a }
//line :289:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000214__716000218_fn__716000219_A) Invoke_O__O(self any) any { { var s__716000215__1 any; var t_ any = t.F_s__716000215; t.F_s__716000215 = nil; s__716000215__1 = t_; for { var temp__1927000414__auto____2 any; var root_1825 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_1826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1825, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1827 lang.IFn; if linked_1826 == nil { ifn_1827 = lang.IFn_Cast(root_1825) } else { ifn_1827 = nil }; var arg_1828 any = s__716000215__1; if linked_1826 == nil { temp__1927000414__auto____2 = ifn_1827.Invoke_O__O(arg_1828) } else { temp__1927000414__auto____2 = linked_1826.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1825, arg_1828) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__716000215__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1829 any = A_arbace_repr_clojure_A_const_55.GetRawRoot__O(); var linked_1830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1829, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1831 lang.IFn; if linked_1830 == nil { ifn_1831 = lang.IFn_Cast(root_1829) } else { ifn_1831 = nil }; var arg_1832 any = s__716000215__3; if linked_1830 == nil { tmp1 = ifn_1831.Invoke_O__O(arg_1832) } else { tmp1 = linked_1830.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1829, arg_1832) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1833 any = A_arbace_repr_clojure_A_const_56.GetRawRoot__O(); var linked_1834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1833, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1835 lang.IFn; if linked_1834 == nil { ifn_1835 = lang.IFn_Cast(root_1833) } else { ifn_1835 = nil }; var arg_1836 any = s__716000215__3; if linked_1834 == nil { c__1927001037__auto____4 = ifn_1835.Invoke_O__O(arg_1836) } else { c__1927001037__auto____4 = linked_1834.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1833, arg_1836) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__716000217__6 any; var root_1837 any = A_arbace_repr_clojure_A_const_57.GetRawRoot__O(); var linked_1838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1837, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1839 lang.IFn; if linked_1838 == nil { ifn_1839 = lang.IFn_Cast(root_1837) } else { ifn_1839 = nil }; var arg_1840 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1838 == nil { b__716000217__6 = ifn_1839.Invoke_O__O(arg_1840) } else { b__716000217__6 = linked_1838.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1837, arg_1840) }; var tmp2 any = A_arbace_repr_clojure_roundtrip_iter__716000214__716000218_fn__716000219_fn__716000220_A_New_O_O_I_O(t.F_a, b__716000217__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1846 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000214__716000218_fn__716000219_fn__716000220_A_fn_class; if fncls__1846 == nil { var fncls__1846d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, false); A_arbace_repr_clojure_roundtrip_iter__716000214__716000218_fn__716000219_fn__716000220_A_fn_class = fncls__1846d; tmp3 = fncls__1846d } else { tmp3 = fncls__1846 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1855 any = A_arbace_repr_clojure_A_const_60.GetRawRoot__O(); var linked_1856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1855, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1857 lang.IFn; if linked_1856 == nil { ifn_1857 = lang.IFn_Cast(root_1855) } else { ifn_1857 = nil }; var arg_1858 any; var root_1847 any = A_arbace_repr_clojure_A_const_61.GetRawRoot__O(); var linked_1848 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1847, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1849 lang.IFn; if linked_1848 == nil { ifn_1849 = lang.IFn_Cast(root_1847) } else { ifn_1849 = nil }; var arg_1850 any = b__716000217__6; if linked_1848 == nil { arg_1858 = ifn_1849.Invoke_O__O(arg_1850) } else { arg_1858 = linked_1848.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1847, arg_1850) }; var arg_1859 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__716000214); var tmp5 any; var root_1851 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_1852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1851, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1853 lang.IFn; if linked_1852 == nil { ifn_1853 = lang.IFn_Cast(root_1851) } else { ifn_1853 = nil }; var arg_1854 any = s__716000215__3; if linked_1852 == nil { tmp5 = ifn_1853.Invoke_O__O(arg_1854) } else { tmp5 = linked_1852.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1851, arg_1854) }; arg_1859 = tmp4.Invoke_O__O(tmp5); if linked_1856 == nil { return ifn_1857.Invoke_O_O__O(arg_1858, arg_1859) } else { return linked_1856.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1855, arg_1858, arg_1859) } } else { var root_1864 any = A_arbace_repr_clojure_A_const_60.GetRawRoot__O(); var linked_1865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1864, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1866 lang.IFn; if linked_1865 == nil { ifn_1866 = lang.IFn_Cast(root_1864) } else { ifn_1866 = nil }; var arg_1867 any; var root_1860 any = A_arbace_repr_clojure_A_const_61.GetRawRoot__O(); var linked_1861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1860, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1862 lang.IFn; if linked_1861 == nil { ifn_1862 = lang.IFn_Cast(root_1860) } else { ifn_1862 = nil }; var arg_1863 any = b__716000217__6; if linked_1861 == nil { arg_1867 = ifn_1862.Invoke_O__O(arg_1863) } else { arg_1867 = linked_1861.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1860, arg_1863) }; var arg_1868 any; if linked_1865 == nil { return ifn_1866.Invoke_O_O__O(arg_1867, arg_1868) } else { return linked_1865.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1864, arg_1867, arg_1868) } } } else { var vec__716000225__4 any; var root_1869 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_1870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1869, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1871 lang.IFn; if linked_1870 == nil { ifn_1871 = lang.IFn_Cast(root_1869) } else { ifn_1871 = nil }; var arg_1872 any = s__716000215__3; if linked_1870 == nil { vec__716000225__4 = ifn_1871.Invoke_O__O(arg_1872) } else { vec__716000225__4 = linked_1870.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1869, arg_1872) }; var out__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000225__4, lang.RT_IntCast_J__I_NoInit(0), nil); var m__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000225__4, lang.RT_IntCast_J__I_NoInit(1), nil); var rel__7 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_108.Invoke_O__O(t.F_a)).Invoke_O__O(out__5); var root_1877 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_1878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1877, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1879 lang.IFn; if linked_1878 == nil { ifn_1879 = lang.IFn_Cast(root_1877) } else { ifn_1879 = nil }; var arg_1880 any = lang.Tuple_Create_O_O__IPersistentVector(rel__7, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_124, A_arbace_repr_clojure_A_const_110, A_arbace_repr_clojure_A_const_127, m__6))); var arg_1881 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__716000214); var tmp7 any; var root_1873 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_1874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1873, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1875 lang.IFn; if linked_1874 == nil { ifn_1875 = lang.IFn_Cast(root_1873) } else { ifn_1875 = nil }; var arg_1876 any = s__716000215__3; if linked_1874 == nil { tmp7 = ifn_1875.Invoke_O__O(arg_1876) } else { tmp7 = linked_1874.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1873, arg_1876) }; arg_1881 = tmp6.Invoke_O__O(tmp7); if linked_1878 == nil { return ifn_1879.Invoke_O_O__O(arg_1880, arg_1881) } else { return linked_1878.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1877, arg_1880, arg_1881) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :289:1
func A_arbace_repr_clojure_roundtrip_iter__716000214__716000218_fn__716000219_fn__716000220_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_repr_clojure_roundtrip_iter__716000214__716000218_fn__716000219_fn__716000220_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000214__716000218_fn__716000219_fn__716000220_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :289:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000214__716000218_fn__716000219_fn__716000220_A) Ctor_O_O_I_O(c__a, c__b__716000217 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_a = c__a; t.F_b__716000217 = c__b__716000217; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :289:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000214__716000218_fn__716000219_fn__716000220_A) Invoke_O__O(self any) any { { var i__716000216__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__716000216__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__716000221__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__716000216__1)); var out__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000221__2, lang.RT_IntCast_J__I_NoInit(0), nil); var m__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000221__2, lang.RT_IntCast_J__I_NoInit(1), nil); var rel__5 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_108.Invoke_O__O(t.F_a)).Invoke_O__O(out__3); var root_1841 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_1842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1841, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1843 lang.IFn; if linked_1842 == nil { ifn_1843 = lang.IFn_Cast(root_1841) } else { ifn_1843 = nil }; var arg_1844 any = t.F_b__716000217; var arg_1845 any = lang.Tuple_Create_O_O__IPersistentVector(rel__5, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_124, A_arbace_repr_clojure_A_const_110, A_arbace_repr_clojure_A_const_127, m__4))); if linked_1842 == nil { ifn_1843.Invoke_O_O__O(arg_1844, arg_1845) } else { linked_1842.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1841, arg_1844, arg_1845) }; i__716000216__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__716000216__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_repr_clojure_parse_args_A_New() *A_arbace_repr_clojure_parse_args_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_parse_args_A{}; t.Ctor(); return t }
//line :292:1
func (t *A_arbace_repr_clojure_parse_args_A) Ctor() {}
//line :292:1
func (t *A_arbace_repr_clojure_parse_args_A) Invoke_O_O__O(self, args__0 any) any { { var G__716000234__2_ any = args__0; var vec__716000235__3 any = G__716000234__2_; var seq__716000236__4 any; var root_1895 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_1896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1895, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1897 lang.IFn
											if linked_1896 == nil { ifn_1897 = lang.IFn_Cast(root_1895) } else { ifn_1897 = nil }; var arg_1898 any = vec__716000235__3; if linked_1896 == nil { seq__716000236__4 = ifn_1897.Invoke_O__O(arg_1898) } else { seq__716000236__4 = linked_1896.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1895, arg_1898) }
//line :292:1
	var first__716000237__5 any; var root_1899 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_1900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1899, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1901 lang.IFn
	if linked_1900 == nil { ifn_1901 = lang.IFn_Cast(root_1899) } else { ifn_1901 = nil }; var arg_1902 any = seq__716000236__4; if linked_1900 == nil { first__716000237__5 = ifn_1901.Invoke_O__O(arg_1902) } else { first__716000237__5 = linked_1900.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1899, arg_1902) }
//line :292:1
	var seq__716000236__6 any; var root_1903 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_1904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1903, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1905 lang.IFn
	if linked_1904 == nil { ifn_1905 = lang.IFn_Cast(root_1903) } else { ifn_1905 = nil }; var arg_1906 any = seq__716000236__4; if linked_1904 == nil { seq__716000236__6 = ifn_1905.Invoke_O__O(arg_1906) } else { seq__716000236__6 = linked_1904.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1903, arg_1906) }
//line :292:1
	var a__7 any = first__716000237__5; var more__8 any = seq__716000236__6; var args__9 any = vec__716000235__3; var o__10 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_139, lang.PersistentVector_EMPTY.Ref(), A_arbace_repr_clojure_A_const_19, lang.PersistentVector_EMPTY.Ref(), A_arbace_repr_clojure_A_const_32, lang.PersistentHashSet_EMPTY.Ref(), A_arbace_repr_clojure_A_const_23, A_arbace_repr_clojure_A_const_25)); var G__716000234__11_ any = G__716000234__2_; var o__12 any = o__10; _ = a__7; _ = more__8; _ = args__9; L1: for { var vec__716000238__13 any = G__716000234__11_; var seq__716000239__14 any; var root_1907 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_1908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1907, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1909 lang.IFn
		if linked_1908 == nil { ifn_1909 = lang.IFn_Cast(root_1907) } else { ifn_1909 = nil }; var arg_1910 any = vec__716000238__13; if linked_1908 == nil { seq__716000239__14 = ifn_1909.Invoke_O__O(arg_1910) } else { seq__716000239__14 = linked_1908.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1907, arg_1910) }
//line :292:1
		var first__716000240__15 any; var root_1911 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_1912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1911, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1913 lang.IFn
		if linked_1912 == nil { ifn_1913 = lang.IFn_Cast(root_1911) } else { ifn_1913 = nil }; var arg_1914 any = seq__716000239__14; if linked_1912 == nil { first__716000240__15 = ifn_1913.Invoke_O__O(arg_1914) } else { first__716000240__15 = linked_1912.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1911, arg_1914) }
//line :292:1
		var seq__716000239__16 any; var root_1915 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_1916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1915, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1917 lang.IFn
		if linked_1916 == nil { ifn_1917 = lang.IFn_Cast(root_1915) } else { ifn_1917 = nil }; var arg_1918 any = seq__716000239__14; if linked_1916 == nil { seq__716000239__16 = ifn_1917.Invoke_O__O(arg_1918) } else { seq__716000239__16 = linked_1916.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1915, arg_1918) }
//line :292:1
		var a__17 any = first__716000240__15; var more__18 any = seq__716000239__16; var args__19 any = vec__716000238__13; var o__20 any = o__12; var tmp1 any; var root_1919 any = A_arbace_repr_clojure_A_const_140.GetRawRoot__O(); var linked_1920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1919, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1921 lang.IFn


		if linked_1920 == nil { ifn_1921 = lang.IFn_Cast(root_1919) } else { ifn_1921 = nil }; var arg_1922 any = args__19; if linked_1920 == nil { tmp1 = ifn_1921.Invoke_O__O(arg_1922) } else { tmp1 = linked_1920.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1919, arg_1922) }
//line :294:1
		if jrt.J2g_Truth(tmp1) { return o__20 } else { if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_30) {

			var tmp2 any; var root_1933 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_1934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1933, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1935 lang.IFn; if linked_1934 == nil { ifn_1935 = lang.IFn_Cast(root_1933) } else { ifn_1935 = nil }; var arg_1936 any = more__18; if linked_1934 == nil { tmp2 = ifn_1935.Invoke_O__O(arg_1936) } else { tmp2 = linked_1934.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1933, arg_1936) }; var tmp3 any = tmp2; var tmp4 any; var root_1941 any = A_arbace_repr_clojure_A_const_143.GetRawRoot__O(); var linked_1942 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1941, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1943 lang.IFn; if linked_1942 == nil { ifn_1943 = lang.IFn_Cast(root_1941) } else { ifn_1943 = nil }; var arg_1944 any = o__20; var arg_1945 any = A_arbace_repr_clojure_A_const_27; var arg_1946 any; var root_1937 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_1938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1937, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1939 lang.IFn; if linked_1938 == nil { ifn_1939 = lang.IFn_Cast(root_1937) } else { ifn_1939 = nil }; var arg_1940 any = more__18; if linked_1938 == nil { arg_1946 = ifn_1939.Invoke_O__O(arg_1940) } else { arg_1946 = linked_1938.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1937, arg_1940) }; if linked_1942 == nil { tmp4 = ifn_1943.Invoke_O_O_O__O(arg_1944, arg_1945, arg_1946) } else { tmp4 = linked_1942.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1941, arg_1944, arg_1945, arg_1946) }; G__716000234__11_, o__12 = tmp3, tmp4; continue L1 } else {
//line :294:1
				if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_31) {


					var tmp5 any; var root_1947 any = A_arbace_repr_clojure_A_const_143.GetRawRoot__O(); var linked_1948 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1947, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1949 lang.IFn; if linked_1948 == nil { ifn_1949 = lang.IFn_Cast(root_1947) } else { ifn_1949 = nil }; var arg_1950 any = o__20; var arg_1951 any = A_arbace_repr_clojure_A_const_144; var arg_1952 any = jrt.Boolean_TRUE.Ref(); if linked_1948 == nil { tmp5 = ifn_1949.Invoke_O_O_O__O(arg_1950, arg_1951, arg_1952) } else { tmp5 = linked_1948.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1947, arg_1950, arg_1951, arg_1952) }; G__716000234__11_, o__12 = more__18, tmp5; continue L1 } else {
//line :294:1
						if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_32) {



							var tmp6 any; var root_1953 any = A_arbace_repr_clojure_A_const_143.GetRawRoot__O(); var linked_1954 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1953, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1955 lang.IFn; if linked_1954 == nil { ifn_1955 = lang.IFn_Cast(root_1953) } else { ifn_1955 = nil }; var arg_1956 any = o__20; var arg_1957 any = A_arbace_repr_clojure_A_const_145; var arg_1958 any = jrt.Boolean_TRUE.Ref(); if linked_1954 == nil { tmp6 = ifn_1955.Invoke_O_O_O__O(arg_1956, arg_1957, arg_1958) } else { tmp6 = linked_1954.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1953, arg_1956, arg_1957, arg_1958) }; G__716000234__11_, o__12 = more__18, tmp6; continue L1 } else {
//line :294:1
								if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_33) {




									var tmp7 any; var root_1959 any = A_arbace_repr_clojure_A_const_143.GetRawRoot__O(); var linked_1960 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1959, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1961 lang.IFn; if linked_1960 == nil { ifn_1961 = lang.IFn_Cast(root_1959) } else { ifn_1961 = nil }; var arg_1962 any = o__20; var arg_1963 any = A_arbace_repr_clojure_A_const_146; var arg_1964 any = jrt.Boolean_TRUE.Ref(); if linked_1960 == nil { tmp7 = ifn_1961.Invoke_O_O_O__O(arg_1962, arg_1963, arg_1964) } else { tmp7 = linked_1960.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1959, arg_1962, arg_1963, arg_1964) }; G__716000234__11_, o__12 = more__18, tmp7; continue L1 } else {
//line :294:1
										if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_34) {





											var tmp8 any; var root_1965 any = A_arbace_repr_clojure_A_const_143.GetRawRoot__O(); var linked_1966 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1965, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1967 lang.IFn; if linked_1966 == nil { ifn_1967 = lang.IFn_Cast(root_1965) } else { ifn_1967 = nil }; var arg_1968 any = o__20; var arg_1969 any = A_arbace_repr_clojure_A_const_18; var arg_1970 any = jrt.Boolean_TRUE.Ref(); if linked_1966 == nil { tmp8 = ifn_1967.Invoke_O_O_O__O(arg_1968, arg_1969, arg_1970) } else { tmp8 = linked_1966.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1965, arg_1968, arg_1969, arg_1970) }; G__716000234__11_, o__12 = more__18, tmp8; continue L1 } else {
//line :294:1
												if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_35) {






													var tmp9 any; var root_1971 any = A_arbace_repr_clojure_A_const_143.GetRawRoot__O(); var linked_1972 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1971, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1973 lang.IFn; if linked_1972 == nil { ifn_1973 = lang.IFn_Cast(root_1971) } else { ifn_1973 = nil }; var arg_1974 any = o__20; var arg_1975 any = A_arbace_repr_clojure_A_const_147; var arg_1976 any = jrt.Boolean_TRUE.Ref(); if linked_1972 == nil { tmp9 = ifn_1973.Invoke_O_O_O__O(arg_1974, arg_1975, arg_1976) } else { tmp9 = linked_1972.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1971, arg_1974, arg_1975, arg_1976) }; G__716000234__11_, o__12 = more__18, tmp9; continue L1 } else {
//line :294:1
														if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_36) {







															var tmp10 any; var root_1977 any = A_arbace_repr_clojure_A_const_143.GetRawRoot__O(); var linked_1978 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1977, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1979 lang.IFn; if linked_1978 == nil { ifn_1979 = lang.IFn_Cast(root_1977) } else { ifn_1979 = nil }; var arg_1980 any = o__20; var arg_1981 any = A_arbace_repr_clojure_A_const_148; var arg_1982 any = jrt.Boolean_TRUE.Ref(); if linked_1978 == nil { tmp10 = ifn_1979.Invoke_O_O_O__O(arg_1980, arg_1981, arg_1982) } else { tmp10 = linked_1978.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1977, arg_1980, arg_1981, arg_1982) }; G__716000234__11_, o__12 = more__18, tmp10; continue L1 } else {
//line :294:1
																if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_37) {








																	var tmp11 any; var root_1983 any = A_arbace_repr_clojure_A_const_143.GetRawRoot__O(); var linked_1984 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1983, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1985 lang.IFn; if linked_1984 == nil { ifn_1985 = lang.IFn_Cast(root_1983) } else { ifn_1985 = nil }; var arg_1986 any = o__20; var arg_1987 any = A_arbace_repr_clojure_A_const_149; var arg_1988 any = jrt.Boolean_TRUE.Ref(); if linked_1984 == nil { tmp11 = ifn_1985.Invoke_O_O_O__O(arg_1986, arg_1987, arg_1988) } else { tmp11 = linked_1984.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1983, arg_1986, arg_1987, arg_1988) }; G__716000234__11_, o__12 = more__18, tmp11; continue L1 } else {
//line :294:1
																		if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_38) {









																			var tmp12 any; var root_1989 any = A_arbace_repr_clojure_A_const_143.GetRawRoot__O(); var linked_1990 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1989, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1991 lang.IFn; if linked_1990 == nil { ifn_1991 = lang.IFn_Cast(root_1989) } else { ifn_1991 = nil }; var arg_1992 any = o__20; var arg_1993 any = A_arbace_repr_clojure_A_const_108; var arg_1994 any = A_arbace_repr_clojure_A_const_115; if linked_1990 == nil { tmp12 = ifn_1991.Invoke_O_O_O__O(arg_1992, arg_1993, arg_1994) } else { tmp12 = linked_1990.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1989, arg_1992, arg_1993, arg_1994) }; G__716000234__11_, o__12 = more__18, tmp12; continue L1 } else {
//line :294:1
																				if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_39) {










																					var tmp13 any; var root_1995 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_1996 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1995, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1997 lang.IFn; if linked_1996 == nil { ifn_1997 = lang.IFn_Cast(root_1995) } else { ifn_1997 = nil }; var arg_1998 any = more__18; if linked_1996 == nil { tmp13 = ifn_1997.Invoke_O__O(arg_1998) } else { tmp13 = linked_1996.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1995, arg_1998) }; var tmp14 any = tmp13; var tmp15 any; var root_2003 any = A_arbace_repr_clojure_A_const_143.GetRawRoot__O(); var linked_2004 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2003, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2005 lang.IFn; if linked_2004 == nil { ifn_2005 = lang.IFn_Cast(root_2003) } else { ifn_2005 = nil }; var arg_2006 any = o__20; var arg_2007 any = A_arbace_repr_clojure_A_const_150; var arg_2008 any; var root_1999 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2000 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1999, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2001 lang.IFn; if linked_2000 == nil { ifn_2001 = lang.IFn_Cast(root_1999) } else { ifn_2001 = nil }; var arg_2002 any = more__18; if linked_2000 == nil { arg_2008 = ifn_2001.Invoke_O__O(arg_2002) } else { arg_2008 = linked_2000.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1999, arg_2002) }; if linked_2004 == nil { tmp15 = ifn_2005.Invoke_O_O_O__O(arg_2006, arg_2007, arg_2008) } else { tmp15 = linked_2004.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2003, arg_2006, arg_2007, arg_2008) }; G__716000234__11_, o__12 = tmp14, tmp15; continue L1 } else {
//line :294:1
																						if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_40) {











																							var tmp16 any; var root_2009 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_2010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2009, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2011 lang.IFn; if linked_2010 == nil { ifn_2011 = lang.IFn_Cast(root_2009) } else { ifn_2011 = nil }; var arg_2012 any = more__18; if linked_2010 == nil { tmp16 = ifn_2011.Invoke_O__O(arg_2012) } else { tmp16 = linked_2010.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2009, arg_2012) }; var tmp17 any = tmp16; var tmp18 any; var root_2021 any = A_arbace_repr_clojure_A_const_143.GetRawRoot__O(); var linked_2022 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2021, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2023 lang.IFn; if linked_2022 == nil { ifn_2023 = lang.IFn_Cast(root_2021) } else { ifn_2023 = nil }; var arg_2024 any = o__20; var arg_2025 any = A_arbace_repr_clojure_A_const_151; var arg_2026 any; var root_2017 any = A_arbace_repr_clojure_A_const_29.GetRawRoot__O(); var linked_2018 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2017, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_2019 lang.IFn; if linked_2018 == nil { ifn_2019 = lang.IFn_Cast(root_2017) } else { ifn_2019 = nil }; var arg_2020 any; var root_2013 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2014 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2013, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2015 lang.IFn; if linked_2014 == nil { ifn_2015 = lang.IFn_Cast(root_2013) } else { ifn_2015 = nil }; var arg_2016 any = more__18; if linked_2014 == nil { arg_2020 = ifn_2015.Invoke_O__O(arg_2016) } else { arg_2020 = linked_2014.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2013, arg_2016) }; if linked_2018 == nil { arg_2026 = ifn_2019.Invoke_O__O(arg_2020) } else { arg_2026 = linked_2018.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_2017, arg_2020) }; if linked_2022 == nil { tmp18 = ifn_2023.Invoke_O_O_O__O(arg_2024, arg_2025, arg_2026) } else { tmp18 = linked_2022.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2021, arg_2024, arg_2025, arg_2026) }; G__716000234__11_, o__12 = tmp17, tmp18; continue L1 } else {
//line :294:1
																								if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_41) {












																									var tmp19 any; var root_2027 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_2028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2027, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2029 lang.IFn; if linked_2028 == nil { ifn_2029 = lang.IFn_Cast(root_2027) } else { ifn_2029 = nil }; var arg_2030 any = more__18; if linked_2028 == nil { tmp19 = ifn_2029.Invoke_O__O(arg_2030) } else { tmp19 = linked_2028.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2027, arg_2030) }; var tmp20 any = tmp19; var tmp21 any; var root_2035 any = A_arbace_repr_clojure_A_const_78.GetRawRoot__O(); var linked_2036 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2035, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_2037 lang.IFn; if linked_2036 == nil { ifn_2037 = lang.IFn_Cast(root_2035) } else { ifn_2037 = nil }; var arg_2038 any = o__20; var arg_2039 any = A_arbace_repr_clojure_A_const_19; var arg_2040 any = A_arbace_repr_clojure_A_const_10.GetRawRoot__O(); var arg_2041 any; var root_2031 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2031, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2033 lang.IFn; if linked_2032 == nil { ifn_2033 = lang.IFn_Cast(root_2031) } else { ifn_2033 = nil }; var arg_2034 any = more__18; if linked_2032 == nil { arg_2041 = ifn_2033.Invoke_O__O(arg_2034) } else { arg_2041 = linked_2032.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2031, arg_2034) }; if linked_2036 == nil { tmp21 = ifn_2037.Invoke_O_O_O_O__O(arg_2038, arg_2039, arg_2040, arg_2041) } else { tmp21 = linked_2036.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_2035, arg_2038, arg_2039, arg_2040, arg_2041) }; G__716000234__11_, o__12 = tmp20, tmp21; continue L1 } else {
//line :294:1
																										if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_42) {













																											var tmp22 any; var root_2042 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_2043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2042, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2044 lang.IFn; if linked_2043 == nil { ifn_2044 = lang.IFn_Cast(root_2042) } else { ifn_2044 = nil }; var arg_2045 any = more__18; if linked_2043 == nil { tmp22 = ifn_2044.Invoke_O__O(arg_2045) } else { tmp22 = linked_2043.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2042, arg_2045) }; var tmp23 any = tmp22; var tmp24 any; var root_2054 any = A_arbace_repr_clojure_A_const_143.GetRawRoot__O(); var linked_2055 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2054, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2056 lang.IFn; if linked_2055 == nil { ifn_2056 = lang.IFn_Cast(root_2054) } else { ifn_2056 = nil }; var arg_2057 any = o__20; var arg_2058 any = A_arbace_repr_clojure_A_const_23; var arg_2059 any; var root_2050 any = A_arbace_repr_clojure_A_const_29.GetRawRoot__O(); var linked_2051 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2050, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_2052 lang.IFn; if linked_2051 == nil { ifn_2052 = lang.IFn_Cast(root_2050) } else { ifn_2052 = nil }; var arg_2053 any; var root_2046 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2047 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2046, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2048 lang.IFn; if linked_2047 == nil { ifn_2048 = lang.IFn_Cast(root_2046) } else { ifn_2048 = nil }; var arg_2049 any = more__18; if linked_2047 == nil { arg_2053 = ifn_2048.Invoke_O__O(arg_2049) } else { arg_2053 = linked_2047.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2046, arg_2049) }; if linked_2051 == nil { arg_2059 = ifn_2052.Invoke_O__O(arg_2053) } else { arg_2059 = linked_2051.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_2050, arg_2053) }; if linked_2055 == nil { tmp24 = ifn_2056.Invoke_O_O_O__O(arg_2057, arg_2058, arg_2059) } else { tmp24 = linked_2055.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2054, arg_2057, arg_2058, arg_2059) }; G__716000234__11_, o__12 = tmp23, tmp24; continue L1 } else {
//line :294:1
																												if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_43) {














																													var tmp25 any; var root_2060 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_2061 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2060, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2062 lang.IFn; if linked_2061 == nil { ifn_2062 = lang.IFn_Cast(root_2060) } else { ifn_2062 = nil }; var arg_2063 any = more__18; if linked_2061 == nil { tmp25 = ifn_2062.Invoke_O__O(arg_2063) } else { tmp25 = linked_2061.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2060, arg_2063) }; var tmp26 any = tmp25; var tmp27 any; var root_2078 any = A_arbace_repr_clojure_A_const_78.GetRawRoot__O(); var linked_2079 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2078, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_2080 lang.IFn; if linked_2079 == nil { ifn_2080 = lang.IFn_Cast(root_2078) } else { ifn_2080 = nil }; var arg_2081 any = o__20; var arg_2082 any = A_arbace_repr_clojure_A_const_32; var arg_2083 any = A_arbace_repr_clojure_A_const_96.GetRawRoot__O(); var arg_2084 any; var root_2073 any = A_arbace_repr_clojure_A_const_152.GetRawRoot__O(); var linked_2074 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2073, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2075 lang.IFn; if linked_2074 == nil { ifn_2075 = lang.IFn_Cast(root_2073) } else { ifn_2075 = nil }; var arg_2076 any = A_arbace_repr_clojure_A_const_29.GetRawRoot__O(); var arg_2077 any; var root_2068 any = A_arbace_repr_clojure_A_const_153.GetRawRoot__O(); var linked_2069 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2068, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_2070 lang.IFn; if linked_2069 == nil { ifn_2070 = lang.IFn_Cast(root_2068) } else { ifn_2070 = nil }; var arg_2071 any; var root_2064 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2065 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2064, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2066 lang.IFn; if linked_2065 == nil { ifn_2066 = lang.IFn_Cast(root_2064) } else { ifn_2066 = nil }; var arg_2067 any = more__18; if linked_2065 == nil { arg_2071 = ifn_2066.Invoke_O__O(arg_2067) } else { arg_2071 = linked_2065.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2064, arg_2067) }; var arg_2072 any = A_arbace_repr_clojure_A_const_154; if linked_2069 == nil { arg_2077 = ifn_2070.Invoke_O_O__O(arg_2071, arg_2072) } else { arg_2077 = linked_2069.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_2068, arg_2071, arg_2072) }; if linked_2074 == nil { arg_2084 = ifn_2075.Invoke_O_O__O(arg_2076, arg_2077) } else { arg_2084 = linked_2074.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2073, arg_2076, arg_2077) }; if linked_2079 == nil { tmp27 = ifn_2080.Invoke_O_O_O_O__O(arg_2081, arg_2082, arg_2083, arg_2084) } else { tmp27 = linked_2079.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_2078, arg_2081, arg_2082, arg_2083, arg_2084) }; G__716000234__11_, o__12 = tmp26, tmp27; continue L1 } else {
//line :294:1
																														var tmp28 any; var root_1923 any = A_arbace_repr_clojure_A_const_141.GetRawRoot__O(); var linked_1924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1923, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1925 lang.IFn















																														if linked_1924 == nil { ifn_1925 = lang.IFn_Cast(root_1923) } else { ifn_1925 = nil }; var arg_1926 any = a__17; var arg_1927 any = Lit_44; if linked_1924 == nil { tmp28 = ifn_1925.Invoke_O_O__O(arg_1926, arg_1927) } else { tmp28 = linked_1924.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1923, arg_1926, arg_1927) }
//line :294:1
																														if jrt.J2g_Truth(tmp28) { var tmp29 any; var root_1928 any = A_arbace_repr_clojure_A_const_142.GetRawRoot__O(); var linked_1929 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1928, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1930 lang.IFn















																															if linked_1929 == nil { ifn_1930 = lang.IFn_Cast(root_1928) } else { ifn_1930 = nil }; var arg_1931 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_45, nil), jrt.RefArrayOf(jrt.Object_class, nil, a__17)).Ref(); var arg_1932 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1929 == nil { tmp29 = ifn_1930.Invoke_O_O__O(arg_1931, arg_1932) } else { tmp29 = linked_1929.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1928, arg_1931, arg_1932) }
//line :294:1
																															panic(jrt.Thrown(jrt.Throwable_Cast(tmp29))) } else { if A_arbace_repr_clojure_A_const_33 != nil {
















																																var tmp30 any; var root_2085 any = A_arbace_repr_clojure_A_const_78.GetRawRoot__O(); var linked_2086 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2085, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_2087 lang.IFn; if linked_2086 == nil { ifn_2087 = lang.IFn_Cast(root_2085) } else { ifn_2087 = nil }; var arg_2088 any = o__20; var arg_2089 any = A_arbace_repr_clojure_A_const_139; var arg_2090 any = A_arbace_repr_clojure_A_const_10.GetRawRoot__O(); var arg_2091 any = a__17; if linked_2086 == nil { tmp30 = ifn_2087.Invoke_O_O_O_O__O(arg_2088, arg_2089, arg_2090, arg_2091) } else { tmp30 = linked_2086.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_2085, arg_2088, arg_2089, arg_2090, arg_2091) }; G__716000234__11_, o__12 = more__18, tmp30; continue L1 } else {
//line :294:1
																																	return nil } } } } } } } } } } } } } } } } } } }; /*line :292:1*/panic("j2g: unreachable") }




















func A_arbace_repr_clojure_print_rules_A_New() *A_arbace_repr_clojure_print_rules_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_print_rules_A{}; t.Ctor(); return t }
//line :313:1
func (t *A_arbace_repr_clojure_print_rules_A) Ctor() {}
//line :313:1
func (t *A_arbace_repr_clojure_print_rules_A) Invoke_O__O(self any) any {
	lang.IFn_Cast(A_arbace_repr_clojure_A_const_74.GetRawRoot__O()).Invoke_O__O(Lit_60)
//line :313:1
	{ var seq_716000242__1 any; var root_2116 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2116, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2118 lang.IFn

		if linked_2117 == nil { ifn_2118 = lang.IFn_Cast(root_2116) } else { ifn_2118 = nil }; var arg_2119 any = A_arbace_repr_clojure_A_const_156.GetRawRoot__O(); if linked_2117 == nil { seq_716000242__1 = ifn_2118.Invoke_O__O(arg_2119) } else { seq_716000242__1 = linked_2117.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2116, arg_2119) }
//line :313:1
		var chunk_716000243__2 any; var count_716000244__3 int64 = 0; var i_716000245__4 int64 = 0; L1: for {

			if lang.Numbers_Lt_J_J__Z_NoInit(i_716000245__4, count_716000244__3) { var r__5 any = lang.Indexed_Cast(chunk_716000243__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_716000245__4)); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_74.GetRawRoot__O()); var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_61, nil, Lit_62, nil, Lit_63, nil); var tmp3 any; var root_2150 any = A_arbace_repr_clojure_A_const_160.GetRawRoot__O(); var linked_2151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2150, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2152 lang.IFn
				if linked_2151 == nil { ifn_2152 = lang.IFn_Cast(root_2150) } else { ifn_2152 = nil }; var arg_2153 any = A_arbace_repr_clojure_A_const_161.Invoke_O__O(r__5); if linked_2151 == nil { tmp3 = ifn_2152.Invoke_O__O(arg_2153) } else { tmp3 = linked_2151.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2150, arg_2153) }; var tmp4 any = tmp3; var tmp5 any; var root_2154 any = A_arbace_repr_clojure_A_const_160.GetRawRoot__O(); var linked_2155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2154, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2156 lang.IFn; if linked_2155 == nil { ifn_2156 = lang.IFn_Cast(root_2154) } else { ifn_2156 = nil }; var arg_2157 any = A_arbace_repr_clojure_A_const_162.Invoke_O__O(r__5); if linked_2155 == nil { tmp5 = ifn_2156.Invoke_O__O(arg_2157) } else { tmp5 = linked_2155.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2154, arg_2157) }; var tmp6 any = tmp5; var tmp7 any; var root_2158 any = A_arbace_repr_clojure_A_const_157.GetRawRoot__O(); var linked_2159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2158, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2160 lang.IFn; if linked_2159 == nil { ifn_2160 = lang.IFn_Cast(root_2158) } else { ifn_2160 = nil }; var arg_2161 any = A_arbace_repr_clojure_A_const_163.Invoke_O__O(r__5); var arg_2162 any = A_arbace_repr_clojure_A_const_164; var arg_2163 any = Lit_64; if linked_2159 == nil { tmp7 = ifn_2160.Invoke_O_O_O__O(arg_2161, arg_2162, arg_2163) } else { tmp7 = linked_2159.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2158, arg_2161, arg_2162, arg_2163) }; tmp1.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp4, nil, tmp6, nil, tmp7)).Ref())
				var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_74.GetRawRoot__O()); var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_65, nil); var tmp10 any; var root_2140 any = A_arbace_repr_clojure_A_const_157.GetRawRoot__O(); var linked_2141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2140, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2142 lang.IFn; if linked_2141 == nil { ifn_2142 = lang.IFn_Cast(root_2140) } else { ifn_2142 = nil }; var arg_2143 any = A_arbace_repr_clojure_A_const_158.Invoke_O__O(r__5); var arg_2144 any = A_arbace_repr_clojure_A_const_159; var arg_2145 any = Lit_64; if linked_2141 == nil { tmp10 = ifn_2142.Invoke_O_O_O__O(arg_2143, arg_2144, arg_2145) } else { tmp10 = linked_2141.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2140, arg_2143, arg_2144, arg_2145) }; tmp8.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp10)).Ref())
//line :315:1
				seq_716000242__1, chunk_716000243__2, count_716000244__3, i_716000245__4 = seq_716000242__1, chunk_716000243__2, count_716000244__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_716000245__4); continue L1 } else { var temp__1927000414__auto____5 any; var root_2120 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2120, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2122 lang.IFn; if linked_2121 == nil { ifn_2122 = lang.IFn_Cast(root_2120) } else { ifn_2122 = nil }; var arg_2123 any = seq_716000242__1; if linked_2121 == nil { temp__1927000414__auto____5 = ifn_2122.Invoke_O__O(arg_2123) } else { temp__1927000414__auto____5 = linked_2121.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2120, arg_2123) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_716000242__6 any = temp__1927000414__auto____5; var tmp11 any; var root_2124 any = A_arbace_repr_clojure_A_const_55.GetRawRoot__O(); var linked_2125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2124, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2126 lang.IFn; if linked_2125 == nil { ifn_2126 = lang.IFn_Cast(root_2124) } else { ifn_2126 = nil }; var arg_2127 any = seq_716000242__6; if linked_2125 == nil { tmp11 = ifn_2126.Invoke_O__O(arg_2127) } else { tmp11 = linked_2125.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2124, arg_2127) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____7 any; var root_2128 any = A_arbace_repr_clojure_A_const_56.GetRawRoot__O(); var linked_2129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2128, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2130 lang.IFn; if linked_2129 == nil { ifn_2130 = lang.IFn_Cast(root_2128) } else { ifn_2130 = nil }; var arg_2131 any = seq_716000242__6; if linked_2129 == nil { c__1927000678__auto____7 = ifn_2130.Invoke_O__O(arg_2131) } else { c__1927000678__auto____7 = linked_2129.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2128, arg_2131) }; var tmp12 any; var root_2168 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_2169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2168, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2170 lang.IFn; if linked_2169 == nil { ifn_2170 = lang.IFn_Cast(root_2168) } else { ifn_2170 = nil }; var arg_2171 any = seq_716000242__6; if linked_2169 == nil { tmp12 = ifn_2170.Invoke_O__O(arg_2171) } else { tmp12 = linked_2169.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2168, arg_2171) }; seq_716000242__1, chunk_716000243__2, count_716000244__3, i_716000245__4 = tmp12, c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var r__7 any; var root_2132 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2132, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2134 lang.IFn; if linked_2133 == nil { ifn_2134 = lang.IFn_Cast(root_2132) } else { ifn_2134 = nil }; var arg_2135 any = seq_716000242__6; if linked_2133 == nil { r__7 = ifn_2134.Invoke_O__O(arg_2135) } else { r__7 = linked_2133.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2132, arg_2135) }
					var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_74.GetRawRoot__O()); var tmp14 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_61, nil, Lit_62, nil, Lit_63, nil); var tmp15 any; var root_2182 any = A_arbace_repr_clojure_A_const_160.GetRawRoot__O(); var linked_2183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2182, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2184 lang.IFn; if linked_2183 == nil { ifn_2184 = lang.IFn_Cast(root_2182) } else { ifn_2184 = nil }; var arg_2185 any = A_arbace_repr_clojure_A_const_161.Invoke_O__O(r__7); if linked_2183 == nil { tmp15 = ifn_2184.Invoke_O__O(arg_2185) } else { tmp15 = linked_2183.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2182, arg_2185) }; var tmp16 any = tmp15; var tmp17 any; var root_2186 any = A_arbace_repr_clojure_A_const_160.GetRawRoot__O(); var linked_2187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2186, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2188 lang.IFn; if linked_2187 == nil { ifn_2188 = lang.IFn_Cast(root_2186) } else { ifn_2188 = nil }; var arg_2189 any = A_arbace_repr_clojure_A_const_162.Invoke_O__O(r__7); if linked_2187 == nil { tmp17 = ifn_2188.Invoke_O__O(arg_2189) } else { tmp17 = linked_2187.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2186, arg_2189) }; var tmp18 any = tmp17; var tmp19 any; var root_2190 any = A_arbace_repr_clojure_A_const_157.GetRawRoot__O(); var linked_2191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2190, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2192 lang.IFn; if linked_2191 == nil { ifn_2192 = lang.IFn_Cast(root_2190) } else { ifn_2192 = nil }; var arg_2193 any = A_arbace_repr_clojure_A_const_163.Invoke_O__O(r__7); var arg_2194 any = A_arbace_repr_clojure_A_const_164; var arg_2195 any = Lit_64; if linked_2191 == nil { tmp19 = ifn_2192.Invoke_O_O_O__O(arg_2193, arg_2194, arg_2195) } else { tmp19 = linked_2191.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2190, arg_2193, arg_2194, arg_2195) }; tmp13.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp14, jrt.RefArrayOf(jrt.Object_class, nil, tmp16, nil, tmp18, nil, tmp19)).Ref())
					var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_74.GetRawRoot__O()); var tmp21 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_65, nil); var tmp22 any; var root_2172 any = A_arbace_repr_clojure_A_const_157.GetRawRoot__O(); var linked_2173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2172, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2174 lang.IFn; if linked_2173 == nil { ifn_2174 = lang.IFn_Cast(root_2172) } else { ifn_2174 = nil }; var arg_2175 any = A_arbace_repr_clojure_A_const_158.Invoke_O__O(r__7); var arg_2176 any = A_arbace_repr_clojure_A_const_159; var arg_2177 any = Lit_64; if linked_2173 == nil { tmp22 = ifn_2174.Invoke_O_O_O__O(arg_2175, arg_2176, arg_2177) } else { tmp22 = linked_2173.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2172, arg_2175, arg_2176, arg_2177) }; tmp20.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp21, jrt.RefArrayOf(jrt.Object_class, nil, tmp22)).Ref())
//line :315:1
					var tmp23 any; var root_2200 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_2201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2200, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2202 lang.IFn; if linked_2201 == nil { ifn_2202 = lang.IFn_Cast(root_2200) } else { ifn_2202 = nil }; var arg_2203 any = seq_716000242__6; if linked_2201 == nil { tmp23 = ifn_2202.Invoke_O__O(arg_2203) } else { tmp23 = linked_2201.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2200, arg_2203) }; seq_716000242__1, chunk_716000243__2, count_716000244__3, i_716000245__4 = tmp23, nil, 0, 0; continue L1 } } }
//line :313:1
			break L1
		}



		lang.IFn_Cast(A_arbace_repr_clojure_A_const_74.GetRawRoot__O()).Invoke_O__O(Lit_66)
//line :313:1
		var seq_716000246__1 any; var root_2092 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2092, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2094 lang.IFn





		if linked_2093 == nil { ifn_2094 = lang.IFn_Cast(root_2092) } else { ifn_2094 = nil }; var arg_2095 any = A_arbace_repr_clojure_A_const_155.GetRawRoot__O(); if linked_2093 == nil { seq_716000246__1 = ifn_2094.Invoke_O__O(arg_2095) } else { seq_716000246__1 = linked_2093.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2092, arg_2095) }
//line :313:1
		var chunk_716000247__2 any; var count_716000248__3 int64 = 0; var i_716000249__4 int64 = 0; L2: for {





			if lang.Numbers_Lt_J_J__Z_NoInit(i_716000249__4, count_716000248__3) { var d__5 any = lang.Indexed_Cast(chunk_716000247__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_716000249__4)); var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_74.GetRawRoot__O()); var tmp25 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_61, nil, Lit_22, nil, nil); var tmp26 any = A_arbace_repr_clojure_A_const_165.Invoke_O__O(d__5); var tmp27 any
				var tmp28 any = A_arbace_repr_clojure_A_const_166
				if lang.Util_Equiv_O_O__Z_NoInit(tmp28, A_arbace_repr_clojure_A_const_167.Invoke_O__O(d__5)) { tmp27 = Lit_67 } else { var root_2204 any = A_arbace_repr_clojure_A_const_160.GetRawRoot__O(); var linked_2205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2204, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2206 lang.IFn; if linked_2205 == nil { ifn_2206 = lang.IFn_Cast(root_2204) } else { ifn_2206 = nil }; var arg_2207 any = A_arbace_repr_clojure_A_const_167.Invoke_O__O(d__5); if linked_2205 == nil { tmp27 = ifn_2206.Invoke_O__O(arg_2207) } else { tmp27 = linked_2205.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2204, arg_2207) } }
//line :320:1
				var tmp29 any = tmp27; var tmp30 *jrt.String

				if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_124.Invoke_O__O(d__5)) { var tmp31 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_68, nil); var tmp32 any; var root_2208 any = A_arbace_repr_clojure_A_const_157.GetRawRoot__O(); var linked_2209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2208, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2210 lang.IFn; if linked_2209 == nil { ifn_2210 = lang.IFn_Cast(root_2208) } else { ifn_2210 = nil }; var arg_2211 any = A_arbace_repr_clojure_A_const_124.Invoke_O__O(d__5); var arg_2212 any = A_arbace_repr_clojure_A_const_168; var arg_2213 any = Lit_64; if linked_2209 == nil { tmp32 = ifn_2210.Invoke_O_O_O__O(arg_2211, arg_2212, arg_2213) } else { tmp32 = linked_2209.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2208, arg_2211, arg_2212, arg_2213) }; tmp30 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp31, jrt.RefArrayOf(jrt.Object_class, nil, tmp32)) } else { tmp30 = nil }
//line :320:1
				tmp24.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp25, jrt.RefArrayOf(jrt.Object_class, nil, tmp26, nil, tmp29, tmp30.Ref())).Ref())
//line :319:1
				seq_716000246__1, chunk_716000247__2, count_716000248__3, i_716000249__4 = seq_716000246__1, chunk_716000247__2, count_716000248__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_716000249__4); continue L2 } else { var temp__1927000414__auto____5_2 any; var root_2096 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2096, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2098 lang.IFn; if linked_2097 == nil { ifn_2098 = lang.IFn_Cast(root_2096) } else { ifn_2098 = nil }; var arg_2099 any = seq_716000246__1; if linked_2097 == nil { temp__1927000414__auto____5_2 = ifn_2098.Invoke_O__O(arg_2099) } else { temp__1927000414__auto____5_2 = linked_2097.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2096, arg_2099) }; if jrt.J2g_Truth(temp__1927000414__auto____5_2) { var seq_716000246__6 any = temp__1927000414__auto____5_2; var tmp33 any; var root_2100 any = A_arbace_repr_clojure_A_const_55.GetRawRoot__O(); var linked_2101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2100, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2102 lang.IFn; if linked_2101 == nil { ifn_2102 = lang.IFn_Cast(root_2100) } else { ifn_2102 = nil }; var arg_2103 any = seq_716000246__6; if linked_2101 == nil { tmp33 = ifn_2102.Invoke_O__O(arg_2103) } else { tmp33 = linked_2101.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2100, arg_2103) }; if jrt.J2g_Truth(tmp33) { var c__1927000678__auto____7_2 any; var root_2104 any = A_arbace_repr_clojure_A_const_56.GetRawRoot__O(); var linked_2105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2104, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2106 lang.IFn; if linked_2105 == nil { ifn_2106 = lang.IFn_Cast(root_2104) } else { ifn_2106 = nil }; var arg_2107 any = seq_716000246__6; if linked_2105 == nil { c__1927000678__auto____7_2 = ifn_2106.Invoke_O__O(arg_2107) } else { c__1927000678__auto____7_2 = linked_2105.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2104, arg_2107) }; var tmp34 any; var root_2218 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_2219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2218, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2220 lang.IFn; if linked_2219 == nil { ifn_2220 = lang.IFn_Cast(root_2218) } else { ifn_2220 = nil }; var arg_2221 any = seq_716000246__6; if linked_2219 == nil { tmp34 = ifn_2220.Invoke_O__O(arg_2221) } else { tmp34 = linked_2219.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2218, arg_2221) }; seq_716000246__1, chunk_716000247__2, count_716000248__3, i_716000249__4 = tmp34, c__1927000678__auto____7_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var d__7 any; var root_2108 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2108, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2110 lang.IFn; if linked_2109 == nil { ifn_2110 = lang.IFn_Cast(root_2108) } else { ifn_2110 = nil }; var arg_2111 any = seq_716000246__6; if linked_2109 == nil { d__7 = ifn_2110.Invoke_O__O(arg_2111) } else { d__7 = linked_2109.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2108, arg_2111) }
					var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_74.GetRawRoot__O()); var tmp36 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_61, nil, Lit_22, nil, nil); var tmp37 any = A_arbace_repr_clojure_A_const_165.Invoke_O__O(d__7); var tmp38 any; var tmp39 any = A_arbace_repr_clojure_A_const_166
					if lang.Util_Equiv_O_O__Z_NoInit(tmp39, A_arbace_repr_clojure_A_const_167.Invoke_O__O(d__7)) { tmp38 = Lit_67 } else { var root_2222 any = A_arbace_repr_clojure_A_const_160.GetRawRoot__O(); var linked_2223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2222, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2224 lang.IFn; if linked_2223 == nil { ifn_2224 = lang.IFn_Cast(root_2222) } else { ifn_2224 = nil }; var arg_2225 any = A_arbace_repr_clojure_A_const_167.Invoke_O__O(d__7); if linked_2223 == nil { tmp38 = ifn_2224.Invoke_O__O(arg_2225) } else { tmp38 = linked_2223.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2222, arg_2225) } }
//line :320:1
					var tmp40 any = tmp38; var tmp41 *jrt.String

					if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_124.Invoke_O__O(d__7)) { var tmp42 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_68, nil); var tmp43 any; var root_2226 any = A_arbace_repr_clojure_A_const_157.GetRawRoot__O(); var linked_2227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2226, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2228 lang.IFn; if linked_2227 == nil { ifn_2228 = lang.IFn_Cast(root_2226) } else { ifn_2228 = nil }; var arg_2229 any = A_arbace_repr_clojure_A_const_124.Invoke_O__O(d__7); var arg_2230 any = A_arbace_repr_clojure_A_const_168; var arg_2231 any = Lit_64; if linked_2227 == nil { tmp43 = ifn_2228.Invoke_O_O_O__O(arg_2229, arg_2230, arg_2231) } else { tmp43 = linked_2227.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2226, arg_2229, arg_2230, arg_2231) }; tmp41 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp42, jrt.RefArrayOf(jrt.Object_class, nil, tmp43)) } else { tmp41 = nil }
//line :320:1
					tmp35.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp36, jrt.RefArrayOf(jrt.Object_class, nil, tmp37, nil, tmp40, tmp41.Ref())).Ref())
//line :319:1
					var tmp44 any; var root_2236 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_2237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2236, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2238 lang.IFn; if linked_2237 == nil { ifn_2238 = lang.IFn_Cast(root_2236) } else { ifn_2238 = nil }; var arg_2239 any = seq_716000246__6; if linked_2237 == nil { tmp44 = ifn_2238.Invoke_O__O(arg_2239) } else { tmp44 = linked_2237.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2236, arg_2239) }; seq_716000246__1, chunk_716000247__2, count_716000248__3, i_716000249__4 = tmp44, nil, 0, 0; continue L2 } } else { return nil } } } }
//line :313:1
	panic("j2g: unreachable")
}









func A_arbace_repr_clojure_usage_A_New() *A_arbace_repr_clojure_usage_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_usage_A{}; t.Ctor(); return t }
//line :324:1
func (t *A_arbace_repr_clojure_usage_A) Ctor() {}
//line :324:1
func (t *A_arbace_repr_clojure_usage_A) Invoke_O__O(self any) any {
	var root_2257 any = A_arbace_repr_clojure_A_const_84.GetRawRoot__O(); var linked_2258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2257, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2259 lang.IFn; if linked_2258 == nil { ifn_2259 = lang.IFn_Cast(root_2257) } else { ifn_2259 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_85.GetRawRoot__O()); var tmp2 any = A_arbace_repr_clojure_A_const_86; var arg_2260 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_repr_clojure_A_const_87.Get__O()); if linked_2258 == nil { ifn_2259.Invoke_O__O(arg_2260) } else { linked_2258.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2257, arg_2260) }; var tmp3 any = A_arbace_repr_clojure_usage_fn__716000251_A_New(); var tmp4 *jrt.Class; var fncls__2251 *jrt.Class = A_arbace_repr_clojure_usage_fn__716000251_A_fn_class; if fncls__2251 == nil { var fncls__2251d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_125, false); A_arbace_repr_clojure_usage_fn__716000251_A_fn_class = fncls__2251d; tmp4 = fncls__2251d } else { tmp4 = fncls__2251 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()
	jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2)); return nil }
//line :325:1
func A_arbace_repr_clojure_usage_fn__716000251_A_New() *A_arbace_repr_clojure_usage_fn__716000251_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_usage_fn__716000251_A{}; t.Ctor(); return t }
//line :325:1
func (t *A_arbace_repr_clojure_usage_fn__716000251_A) Ctor() {}
//line :325:1
func (t *A_arbace_repr_clojure_usage_fn__716000251_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_74.GetRawRoot__O()); var tmp3 *lang.Keyword = A_arbace_repr_clojure_A_const_163; var tmp4 any; var root_2240 any = A_arbace_repr_clojure_A_const_169.GetRawRoot__O(); var linked_2241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2240, aot_arbace_core.A_arbace_core_the_ns_A_fn_class); var ifn_2242 lang.IFn; if linked_2241 == nil { ifn_2242 = lang.IFn_Cast(root_2240) } else { ifn_2242 = nil }; var arg_2243 any = A_arbace_repr_clojure_A_const_170; if linked_2241 == nil { tmp4 = ifn_2242.Invoke_O__O(arg_2243) } else { tmp4 = linked_2241.(*aot_arbace_core.A_arbace_core_the_ns_A).Invoke_O_O__O(root_2240, arg_2243) }; tmp1 = tmp2.Invoke_O__O(tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(tmp4))) }; return nil }(); var root_2248 any = A_arbace_repr_clojure_A_const_75.GetRawRoot__O(); var linked_2249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2248, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2250 lang.IFn; if linked_2249 == nil { ifn_2250 = lang.IFn_Cast(root_2248) } else { ifn_2250 = nil }; if linked_2249 == nil { ifn_2250.Invoke__O() } else { linked_2249.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2248) }; if tmp5 != nil { panic(tmp5) }; return tmp1 }


func A_arbace_repr_clojure_roundtrips_A_New() *A_arbace_repr_clojure_roundtrips_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrips_A{}; t.Ctor(); return t }
//line :328:1
func (t *A_arbace_repr_clojure_roundtrips_A) Ctor() {}
//line :328:1
func (t *A_arbace_repr_clojure_roundtrips_A) Invoke_O_O_O__O(self, sources__0, opts__1 any) any {



	if lang.Numbers_Lt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(sources__0)), 2) {
		var root_2261 any = A_arbace_repr_clojure_A_const_171.GetRawRoot__O(); var linked_2262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2261, A_arbace_repr_clojure_roundtrip_A_fn_class); var ifn_2263 lang.IFn; if linked_2262 == nil { ifn_2263 = lang.IFn_Cast(root_2261) } else { ifn_2263 = nil }; var arg_2264 any = sources__0; var arg_2265 any = opts__1; if linked_2262 == nil { return ifn_2263.Invoke_O_O__O(arg_2264, arg_2265) } else { return linked_2262.(*A_arbace_repr_clojure_roundtrip_A).Invoke_O_O_O__O(root_2261, arg_2264, arg_2265) } } else {
			var root_2359 any = A_arbace_repr_clojure_A_const_99.GetRawRoot__O(); var linked_2360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2359, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_2361 lang.IFn; if linked_2360 == nil { ifn_2361 = lang.IFn_Cast(root_2359) } else { ifn_2361 = nil }; var arg_2362 any; var tmp1 any = A_arbace_repr_clojure_roundtrips_fn__716000254_A_New_O(opts__1); var tmp2 *jrt.Class; var fncls__2355 *jrt.Class = A_arbace_repr_clojure_roundtrips_fn__716000254_A_fn_class; if fncls__2355 == nil { var fncls__2355d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_84, false); A_arbace_repr_clojure_roundtrips_fn__716000254_A_fn_class = fncls__2355d; tmp2 = fncls__2355d } else { tmp2 = fncls__2355 }; arg_2362 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 any = A_arbace_repr_clojure_A_const_135; var tmp4 any = A_arbace_repr_clojure_A_const_13; var tmp5 any = A_arbace_repr_clojure_A_const_136; var tmp6 any = A_arbace_repr_clojure_A_const_13; var tmp7 any = A_arbace_repr_clojure_A_const_138; var arg_2363 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp5, tmp6, tmp7, lang.IFn_Cast(A_arbace_repr_clojure_A_const_97.GetRawRoot__O()).Invoke__O())); var arg_2364 any = sources__0; if linked_2360 == nil { return ifn_2361.Invoke_O_O_O__O(arg_2362, arg_2363, arg_2364) } else { return linked_2360.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_2359, arg_2362, arg_2363, arg_2364) } } }
//line :334:1
func A_arbace_repr_clojure_roundtrips_fn__716000254_A_New_O(p0 any) *A_arbace_repr_clojure_roundtrips_fn__716000254_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrips_fn__716000254_A{}; t.Ctor_O(p0); return t }
//line :334:1
func (t *A_arbace_repr_clojure_roundtrips_fn__716000254_A) Ctor_O(c__opts any) { t.F_opts = c__opts }
//line :334:1
func (t *A_arbace_repr_clojure_roundtrips_fn__716000254_A) Invoke_O_O_O__O(self, acc__1, src__2 any) any { var r__3 any; var root_2266 any = A_arbace_repr_clojure_A_const_171.GetRawRoot__O(); var linked_2267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2266, A_arbace_repr_clojure_roundtrip_A_fn_class); var ifn_2268 lang.IFn; if
														linked_2267 == nil { ifn_2268 = lang.IFn_Cast(root_2266) } else { ifn_2268 = nil }; var arg_2269 any = lang.Tuple_Create_O__IPersistentVector(src__2); var arg_2270 any = t.F_opts; if linked_2267 == nil { r__3 = ifn_2268.Invoke_O_O__O(arg_2269, arg_2270) } else { r__3 = linked_2267.(*A_arbace_repr_clojure_roundtrip_A).Invoke_O_O_O__O(root_2266, arg_2269, arg_2270) }; var n__4 any; var tmp1 any; var root_2271 any = /*line :334:1*/A_arbace_repr_clojure_A_const_72.GetRawRoot__O(); var linked_2272 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2271, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_2273 lang.IFn; if
														linked_2272 == nil { ifn_2273 = lang.IFn_Cast(root_2271) } else { ifn_2273 = nil }; var arg_2274 any = src__2; if linked_2272 == nil { tmp1 = ifn_2273.Invoke_O__O(arg_2274) } else { tmp1 = linked_2272.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_2271, arg_2274) }; n__4 = jrt.NN(jrt.File_Cast(tmp1)).GetName__String().Ref(); var root_2348 any =

	A_arbace_repr_clojure_A_const_78.GetRawRoot__O(); var linked_2349 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2348, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_2350 lang.IFn; if linked_2349 == nil { ifn_2350 = lang.IFn_Cast(root_2348) } else { ifn_2350 = nil }; var arg_2351 any; var root_2282 any = A_arbace_repr_clojure_A_const_78.GetRawRoot__O(); var linked_2283 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2282, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_2284 lang.IFn; if /*line :336:1*/ linked_2283 == nil { ifn_2284 = lang.IFn_Cast(root_2282) } else { ifn_2284 = nil }; var arg_2285 any; var root_2275 any = A_arbace_repr_clojure_A_const_78.GetRawRoot__O(); var linked_2276 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2275, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_2277 lang.IFn; if linked_2276 == nil { ifn_2277 = lang.IFn_Cast(root_2275) } else { ifn_2277 = nil }; var arg_2278 any = acc__1; var arg_2279 any = A_arbace_repr_clojure_A_const_135; var arg_2280 any = A_arbace_repr_clojure_A_const_172.GetRawRoot__O(); var arg_2281 any = A_arbace_repr_clojure_A_const_135.Invoke_O__O(r__3); if linked_2276 == nil { arg_2285 = ifn_2277.Invoke_O_O_O_O__O(arg_2278, arg_2279, arg_2280, arg_2281) } else { arg_2285 = linked_2276.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_2275, arg_2278, arg_2279, arg_2280, arg_2281) }; var arg_2286 any = A_arbace_repr_clojure_A_const_136; var arg_2287 any = A_arbace_repr_clojure_A_const_172.GetRawRoot__O(); var arg_2288 any = A_arbace_repr_clojure_A_const_136.Invoke_O__O(r__3); if linked_2283 == nil { arg_2351 = ifn_2284.Invoke_O_O_O_O__O(arg_2285, arg_2286, arg_2287, arg_2288) } else { arg_2351 = linked_2283.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_2282, arg_2285, arg_2286, arg_2287, arg_2288) }; var arg_2352 any = A_arbace_repr_clojure_A_const_138; var arg_2353 any =
	A_arbace_repr_clojure_A_const_96.GetRawRoot__O(); var arg_2354 any; var iter__1927001039__auto____5 any; var tmp2 any = A_arbace_repr_clojure_roundtrips_fn__716000254_iter__716000255__716000259_A_New_O(n__4); var tmp3 *jrt.Class; var fncls__2347 *jrt.Class = A_arbace_repr_clojure_roundtrips_fn__716000254_iter__716000255__716000259_A_fn_class; if fncls__2347 == nil { var fncls__2347d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_85, false); A_arbace_repr_clojure_roundtrips_fn__716000254_iter__716000255__716000259_A_fn_class = fncls__2347d; tmp3 = fncls__2347d } else { tmp3 = fncls__2347 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); arg_2354 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(A_arbace_repr_clojure_A_const_138.Invoke_O__O(r__3)); if linked_2349 == nil { return ifn_2350.Invoke_O_O_O_O__O(arg_2351, arg_2352, arg_2353, arg_2354) } else { return linked_2349.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_2348, arg_2351, arg_2352, arg_2353, arg_2354) } }
//line :337:1
func A_arbace_repr_clojure_roundtrips_fn__716000254_iter__716000255__716000259_A_New_O(p0 any) *A_arbace_repr_clojure_roundtrips_fn__716000254_iter__716000255__716000259_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrips_fn__716000254_iter__716000255__716000259_A{}; t.Ctor_O(p0); return t }
//line :337:1
func (t *A_arbace_repr_clojure_roundtrips_fn__716000254_iter__716000255__716000259_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :337:1
func (t *A_arbace_repr_clojure_roundtrips_fn__716000254_iter__716000255__716000259_A) Invoke_O_O__O(self, s__716000256__1 any) any { var tmp1 any = A_arbace_repr_clojure_roundtrips_fn__716000254_iter__716000255__716000259_fn__716000260_A_New_O_O_O(self, t.F_n, s__716000256__1); var tmp2 *jrt.Class; var fncls__2346 *jrt.Class = A_arbace_repr_clojure_roundtrips_fn__716000254_iter__716000255__716000259_fn__716000260_A_fn_class; if fncls__2346 == nil { var fncls__2346d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, false); A_arbace_repr_clojure_roundtrips_fn__716000254_iter__716000255__716000259_fn__716000260_A_fn_class = fncls__2346d; tmp2 = fncls__2346d } else { tmp2 = fncls__2346 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :337:1
func A_arbace_repr_clojure_roundtrips_fn__716000254_iter__716000255__716000259_fn__716000260_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_clojure_roundtrips_fn__716000254_iter__716000255__716000259_fn__716000260_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrips_fn__716000254_iter__716000255__716000259_fn__716000260_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :337:1
func (t *A_arbace_repr_clojure_roundtrips_fn__716000254_iter__716000255__716000259_fn__716000260_A) Ctor_O_O_O(c__iter__716000255, c__n, c__s__716000256 any) { t.F_iter__716000255 = c__iter__716000255; t.F_n = c__n; t.F_s__716000256 = c__s__716000256 }
//line :337:1
func (t *A_arbace_repr_clojure_roundtrips_fn__716000254_iter__716000255__716000259_fn__716000260_A) Invoke_O__O(self any) any { { var s__716000256__1 any; var t_ any = t.F_s__716000256; t.F_s__716000256 = nil; s__716000256__1 = t_; for { var temp__1927000414__auto____2 any; var root_2289 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2289, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2291 lang.IFn; if linked_2290 == nil { ifn_2291 = lang.IFn_Cast(root_2289) } else { ifn_2291 = nil }; var arg_2292 any = s__716000256__1; if linked_2290 == nil { temp__1927000414__auto____2 = ifn_2291.Invoke_O__O(arg_2292) } else { temp__1927000414__auto____2 = linked_2290.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2289, arg_2292) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__716000256__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2293 any = A_arbace_repr_clojure_A_const_55.GetRawRoot__O(); var linked_2294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2293, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2295 lang.IFn; if linked_2294 == nil { ifn_2295 = lang.IFn_Cast(root_2293) } else { ifn_2295 = nil }; var arg_2296 any = s__716000256__3; if linked_2294 == nil { tmp1 = ifn_2295.Invoke_O__O(arg_2296) } else { tmp1 = linked_2294.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2293, arg_2296) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2297 any = A_arbace_repr_clojure_A_const_56.GetRawRoot__O(); var linked_2298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2297, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2299 lang.IFn; if linked_2298 == nil { ifn_2299 = lang.IFn_Cast(root_2297) } else { ifn_2299 = nil }; var arg_2300 any = s__716000256__3; if linked_2298 == nil { c__1927001037__auto____4 = ifn_2299.Invoke_O__O(arg_2300) } else { c__1927001037__auto____4 = linked_2298.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2297, arg_2300) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__716000258__6 any; var root_2301 any = A_arbace_repr_clojure_A_const_57.GetRawRoot__O(); var linked_2302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2301, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2303 lang.IFn; if linked_2302 == nil { ifn_2303 = lang.IFn_Cast(root_2301) } else { ifn_2303 = nil }; var arg_2304 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2302 == nil { b__716000258__6 = ifn_2303.Invoke_O__O(arg_2304) } else { b__716000258__6 = linked_2302.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2301, arg_2304) }; var tmp2 any = A_arbace_repr_clojure_roundtrips_fn__716000254_iter__716000255__716000259_fn__716000260_fn__716000261_A_New_O_O_I_O(t.F_n, b__716000258__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2310 *jrt.Class = A_arbace_repr_clojure_roundtrips_fn__716000254_iter__716000255__716000259_fn__716000260_fn__716000261_A_fn_class; if fncls__2310 == nil { var fncls__2310d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_87, false); A_arbace_repr_clojure_roundtrips_fn__716000254_iter__716000255__716000259_fn__716000260_fn__716000261_A_fn_class = fncls__2310d; tmp3 = fncls__2310d } else { tmp3 = fncls__2310 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2319 any = A_arbace_repr_clojure_A_const_60.GetRawRoot__O(); var linked_2320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2319, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2321 lang.IFn; if linked_2320 == nil { ifn_2321 = lang.IFn_Cast(root_2319) } else { ifn_2321 = nil }; var arg_2322 any; var root_2311 any = A_arbace_repr_clojure_A_const_61.GetRawRoot__O(); var linked_2312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2311, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2313 lang.IFn; if linked_2312 == nil { ifn_2313 = lang.IFn_Cast(root_2311) } else { ifn_2313 = nil }; var arg_2314 any = b__716000258__6; if linked_2312 == nil { arg_2322 = ifn_2313.Invoke_O__O(arg_2314) } else { arg_2322 = linked_2312.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2311, arg_2314) }; var arg_2323 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__716000255); var tmp5 any; var root_2315 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_2316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2315, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2317 lang.IFn; if linked_2316 == nil { ifn_2317 = lang.IFn_Cast(root_2315) } else { ifn_2317 = nil }; var arg_2318 any = s__716000256__3; if linked_2316 == nil { tmp5 = ifn_2317.Invoke_O__O(arg_2318) } else { tmp5 = linked_2316.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2315, arg_2318) }; arg_2323 = tmp4.Invoke_O__O(tmp5); if linked_2320 == nil { return ifn_2321.Invoke_O_O__O(arg_2322, arg_2323) } else { return linked_2320.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2319, arg_2322, arg_2323) } } else { var root_2328 any = A_arbace_repr_clojure_A_const_60.GetRawRoot__O(); var linked_2329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2328, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2330 lang.IFn; if linked_2329 == nil { ifn_2330 = lang.IFn_Cast(root_2328) } else { ifn_2330 = nil }; var arg_2331 any; var root_2324 any = A_arbace_repr_clojure_A_const_61.GetRawRoot__O(); var linked_2325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2324, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2326 lang.IFn; if linked_2325 == nil { ifn_2326 = lang.IFn_Cast(root_2324) } else { ifn_2326 = nil }; var arg_2327 any = b__716000258__6; if linked_2325 == nil { arg_2331 = ifn_2326.Invoke_O__O(arg_2327) } else { arg_2331 = linked_2325.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2324, arg_2327) }; var arg_2332 any; if linked_2329 == nil { return ifn_2330.Invoke_O_O__O(arg_2331, arg_2332) } else { return linked_2329.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2328, arg_2331, arg_2332) } } } else { var vec__716000266__4 any; var root_2333 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2333, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2335 lang.IFn; if linked_2334 == nil { ifn_2335 = lang.IFn_Cast(root_2333) } else { ifn_2335 = nil }; var arg_2336 any = s__716000256__3; if linked_2334 == nil { vec__716000266__4 = ifn_2335.Invoke_O__O(arg_2336) } else { vec__716000266__4 = linked_2334.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2333, arg_2336) }; var rel__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000266__4, lang.RT_IntCast_J__I_NoInit(0), nil); var d__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000266__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2341 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_2342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2341, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2343 lang.IFn; if linked_2342 == nil { ifn_2343 = lang.IFn_Cast(root_2341) } else { ifn_2343 = nil }; var arg_2344 any = lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_29, nil), jrt.RefArrayOf(jrt.Object_class, t.F_n, nil, rel__5)).Ref(), d__6); var arg_2345 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__716000255); var tmp7 any; var root_2337 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_2338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2337, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2339 lang.IFn; if linked_2338 == nil { ifn_2339 = lang.IFn_Cast(root_2337) } else { ifn_2339 = nil }; var arg_2340 any = s__716000256__3; if linked_2338 == nil { tmp7 = ifn_2339.Invoke_O__O(arg_2340) } else { tmp7 = linked_2338.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2337, arg_2340) }; arg_2345 = tmp6.Invoke_O__O(tmp7); if linked_2342 == nil { return ifn_2343.Invoke_O_O__O(arg_2344, arg_2345) } else { return linked_2342.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2341, arg_2344, arg_2345) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :337:1
func A_arbace_repr_clojure_roundtrips_fn__716000254_iter__716000255__716000259_fn__716000260_fn__716000261_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_repr_clojure_roundtrips_fn__716000254_iter__716000255__716000259_fn__716000260_fn__716000261_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrips_fn__716000254_iter__716000255__716000259_fn__716000260_fn__716000261_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :337:1
func (t *A_arbace_repr_clojure_roundtrips_fn__716000254_iter__716000255__716000259_fn__716000260_fn__716000261_A) Ctor_O_O_I_O(c__n, c__b__716000258 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__716000258 = c__b__716000258; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :337:1
func (t *A_arbace_repr_clojure_roundtrips_fn__716000254_iter__716000255__716000259_fn__716000260_fn__716000261_A) Invoke_O__O(self any) any { { var i__716000257__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__716000257__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__716000262__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__716000257__1)); var rel__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000262__2, lang.RT_IntCast_J__I_NoInit(0), nil); var d__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000262__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2305 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_2306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2305, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2307 lang.IFn; if linked_2306 == nil { ifn_2307 = lang.IFn_Cast(root_2305) } else { ifn_2307 = nil }; var arg_2308 any = t.F_b__716000258; var arg_2309 any = lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_29, nil), jrt.RefArrayOf(jrt.Object_class, t.F_n, nil, rel__3)).Ref(), d__4); if linked_2306 == nil { ifn_2307.Invoke_O_O__O(arg_2308, arg_2309) } else { linked_2306.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2305, arg_2308, arg_2309) }; i__716000257__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__716000257__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_repr_clojure_run_roundtrip_A_New() *A_arbace_repr_clojure_run_roundtrip_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_roundtrip_A{}; t.Ctor(); return t }
//line :340:1
func (t *A_arbace_repr_clojure_run_roundtrip_A) Ctor() {}
//line :340:1
func (t *A_arbace_repr_clojure_run_roundtrip_A) Invoke_O_O__O(self, o__0 any) any { var r__2 any; var root_2365 any = A_arbace_repr_clojure_A_const_173.GetRawRoot__O(); var linked_2366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2365, A_arbace_repr_clojure_roundtrips_A_fn_class); var ifn_2367 lang.IFn; if




	linked_2366 == nil { ifn_2367 = lang.IFn_Cast(root_2365) } else { ifn_2367 = nil }; var arg_2368 any = A_arbace_repr_clojure_A_const_139.Invoke_O__O(o__0); var arg_2369 any = o__0; if linked_2366 == nil { r__2 = ifn_2367.Invoke_O_O__O(arg_2368, arg_2369) } else { r__2 = linked_2366.(*A_arbace_repr_clojure_roundtrips_A).Invoke_O_O_O__O(root_2365, arg_2368, arg_2369) }; var known__3 any; if
	jrt.J2g_Truth(A_arbace_repr_clojure_A_const_150.Invoke_O__O(o__0)) { var tmp1 any; var root_2374 any = A_arbace_repr_clojure_A_const_174.GetRawRoot__O(); var linked_2375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2374, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_2376 lang.IFn; if linked_2375 == nil { ifn_2376 = lang.IFn_Cast(root_2374) } else { ifn_2376 = nil }; var arg_2377 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_81.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_A_const_150.Invoke_O__O(o__0)); if linked_2375 == nil { tmp1 = ifn_2376.Invoke_O__O(arg_2377) } else { tmp1 = linked_2375.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_2374, arg_2377) }; known__3 = lang.RT_Get_O_O_O__O_NoInit(tmp1, A_arbace_repr_clojure_A_const_151.Invoke_O__O(o__0), lang.PersistentArrayMap_EMPTY.Ref()) } else { known__3 = lang.PersistentArrayMap_EMPTY.Ref() }; var outside__4 any; var root_2391 any = /*line :340:1*/A_arbace_repr_clojure_A_const_96.GetRawRoot__O(); var linked_2392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2391, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2393 lang.IFn; if






	linked_2392 == nil { ifn_2393 = lang.IFn_Cast(root_2391) } else { ifn_2393 = nil }; var arg_2394 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_97.GetRawRoot__O()).Invoke__O(); var arg_2395 any; var root_2386 any = A_arbace_repr_clojure_A_const_112.GetRawRoot__O(); var linked_2387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2386, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_2388 lang.IFn; if linked_2387 == nil { ifn_2388 = lang.IFn_Cast(root_2386) } else { ifn_2388 = nil }; var arg_2389 any; var tmp2 any = A_arbace_repr_clojure_run_roundtrip_fn__716000277_A_New(); var tmp3 *jrt.Class; var fncls__2385 *jrt.Class = A_arbace_repr_clojure_run_roundtrip_fn__716000277_A_fn_class; if fncls__2385 == nil { var fncls__2385d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_103, false); A_arbace_repr_clojure_run_roundtrip_fn__716000277_A_fn_class = fncls__2385d; tmp3 = fncls__2385d } else { tmp3 = fncls__2385 }; arg_2389 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_2390 any = A_arbace_repr_clojure_A_const_138.Invoke_O__O(r__2); if linked_2387 == nil { arg_2395 = ifn_2388.Invoke_O_O__O(arg_2389, arg_2390) } else { arg_2395 = linked_2387.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_2386, arg_2389, arg_2390) }; if linked_2392 == nil { outside__4 = ifn_2393.Invoke_O_O__O(arg_2394, arg_2395) } else { outside__4 = linked_2392.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2391, arg_2394, arg_2395) }; var one_way__5 any; var root_2409 any = /*line :340:1*/A_arbace_repr_clojure_A_const_96.GetRawRoot__O(); var linked_2410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2409, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2411 lang.IFn; if







	linked_2410 == nil { ifn_2411 = lang.IFn_Cast(root_2409) } else { ifn_2411 = nil }; var arg_2412 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_97.GetRawRoot__O()).Invoke__O(); var arg_2413 any; var root_2404 any = A_arbace_repr_clojure_A_const_112.GetRawRoot__O(); var linked_2405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2404, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_2406 lang.IFn; if linked_2405 == nil { ifn_2406 = lang.IFn_Cast(root_2404) } else { ifn_2406 = nil }; var arg_2407 any; var tmp4 any = A_arbace_repr_clojure_run_roundtrip_fn__716000279_A_New(); var tmp5 *jrt.Class; var fncls__2403 *jrt.Class = A_arbace_repr_clojure_run_roundtrip_fn__716000279_A_fn_class; if fncls__2403 == nil { var fncls__2403d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_104, false); A_arbace_repr_clojure_run_roundtrip_fn__716000279_A_fn_class = fncls__2403d; tmp5 = fncls__2403d } else { tmp5 = fncls__2403 }; arg_2407 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_2408 any = A_arbace_repr_clojure_A_const_138.Invoke_O__O(r__2); if linked_2405 == nil { arg_2413 = ifn_2406.Invoke_O_O__O(arg_2407, arg_2408) } else { arg_2413 = linked_2405.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_2404, arg_2407, arg_2408) }; if linked_2410 == nil { one_way__5 = ifn_2411.Invoke_O_O__O(arg_2412, arg_2413) } else { one_way__5 = linked_2410.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2409, arg_2412, arg_2413) }; var diff__6 any; var root_2427 any = /*line :340:1*/A_arbace_repr_clojure_A_const_177.GetRawRoot__O(); var linked_2428 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2427, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2429 lang.IFn; if








	linked_2428 == nil { ifn_2429 = lang.IFn_Cast(root_2427) } else { ifn_2429 = nil }; var arg_2430 any = A_arbace_repr_clojure_A_const_178.GetRawRoot__O(); var arg_2431 any = A_arbace_repr_clojure_A_const_138.Invoke_O__O(r__2); var arg_2432 any; var root_2422 any = A_arbace_repr_clojure_A_const_98.GetRawRoot__O(); var linked_2423 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2422, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2424 lang.IFn; if linked_2423 == nil { ifn_2424 = lang.IFn_Cast(root_2422) } else { ifn_2424 = nil }; var arg_2425 any; var root_2414 any = A_arbace_repr_clojure_A_const_103.GetRawRoot__O(); var linked_2415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2414, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2416 lang.IFn; if linked_2415 == nil { ifn_2416 = lang.IFn_Cast(root_2414) } else { ifn_2416 = nil }; var arg_2417 any = outside__4; if linked_2415 == nil { arg_2425 = ifn_2416.Invoke_O__O(arg_2417) } else { arg_2425 = linked_2415.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2414, arg_2417) }; var arg_2426 any; var root_2418 any = A_arbace_repr_clojure_A_const_103.GetRawRoot__O(); var linked_2419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2418, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2420 lang.IFn; if linked_2419 == nil { ifn_2420 = lang.IFn_Cast(root_2418) } else { ifn_2420 = nil }; var arg_2421 any = one_way__5; if linked_2419 == nil { arg_2426 = ifn_2420.Invoke_O__O(arg_2421) } else { arg_2426 = linked_2419.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2418, arg_2421) }; if linked_2423 == nil { arg_2432 = ifn_2424.Invoke_O_O__O(arg_2425, arg_2426) } else { arg_2432 = linked_2423.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2422, arg_2425, arg_2426) }; if linked_2428 == nil { diff__6 = ifn_2429.Invoke_O_O_O__O(arg_2430, arg_2431, arg_2432) } else { diff__6 = linked_2428.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_2427, arg_2430, arg_2431, arg_2432) }; var new__7 any; var root_2443 any = /*line :340:1*/A_arbace_repr_clojure_A_const_137.GetRawRoot__O(); var linked_2444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2443, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_2445 lang.IFn; if









	linked_2444 == nil { ifn_2445 = lang.IFn_Cast(root_2443) } else { ifn_2445 = nil }; var arg_2446 any; var tmp6 any = A_arbace_repr_clojure_run_roundtrip_fn__716000281_A_New_O(known__3); var tmp7 *jrt.Class; var fncls__2438 *jrt.Class = A_arbace_repr_clojure_run_roundtrip_fn__716000281_A_fn_class; if fncls__2438 == nil { var fncls__2438d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_105, false); A_arbace_repr_clojure_run_roundtrip_fn__716000281_A_fn_class = fncls__2438d; tmp7 = fncls__2438d } else { tmp7 = fncls__2438 }; arg_2446 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_2447 any; var root_2439 any = A_arbace_repr_clojure_A_const_103.GetRawRoot__O(); var linked_2440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2439, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2441 lang.IFn; if linked_2440 == nil { ifn_2441 = lang.IFn_Cast(root_2439) } else { ifn_2441 = nil }; var arg_2442 any = diff__6; if linked_2440 == nil { arg_2447 = ifn_2441.Invoke_O__O(arg_2442) } else { arg_2447 = linked_2440.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2439, arg_2442) }; if linked_2444 == nil { new__7 = ifn_2445.Invoke_O_O__O(arg_2446, arg_2447) } else { new__7 = linked_2444.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_2443, arg_2446, arg_2447) }; var stale__8 any; var root_2458 any = /*line :340:1*/A_arbace_repr_clojure_A_const_137.GetRawRoot__O(); var linked_2459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2458, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_2460 lang.IFn; if










	linked_2459 == nil { ifn_2460 = lang.IFn_Cast(root_2458) } else { ifn_2460 = nil }; var arg_2461 any; var tmp8 any = A_arbace_repr_clojure_run_roundtrip_fn__716000283_A_New_O(diff__6); var tmp9 *jrt.Class; var fncls__2453 *jrt.Class = A_arbace_repr_clojure_run_roundtrip_fn__716000283_A_fn_class; if fncls__2453 == nil { var fncls__2453d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_106, false); A_arbace_repr_clojure_run_roundtrip_fn__716000283_A_fn_class = fncls__2453d; tmp9 = fncls__2453d } else { tmp9 = fncls__2453 }; arg_2461 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var arg_2462 any; var root_2454 any = A_arbace_repr_clojure_A_const_103.GetRawRoot__O(); var linked_2455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2454, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2456 lang.IFn; if linked_2455 == nil { ifn_2456 = lang.IFn_Cast(root_2454) } else { ifn_2456 = nil }; var arg_2457 any = known__3; if linked_2455 == nil { arg_2462 = ifn_2456.Invoke_O__O(arg_2457) } else { arg_2462 = linked_2455.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2454, arg_2457) }; if linked_2459 == nil { stale__8 = ifn_2460.Invoke_O_O__O(arg_2461, arg_2462) } else { stale__8 = linked_2459.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_2458, arg_2461, arg_2462) }; var seq_716000285__9 any; var root_2471 any = /*line :340:1*/A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2471, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2473 lang.IFn; if











	linked_2472 == nil { ifn_2473 = lang.IFn_Cast(root_2471) } else { ifn_2473 = nil }; var arg_2474 any = diff__6; if linked_2472 == nil { seq_716000285__9 = ifn_2473.Invoke_O__O(arg_2474) } else { seq_716000285__9 = linked_2472.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2471, arg_2474) }; var chunk_716000286__10 any; var count_716000287__11 int64 = 0; var i_716000288__12 int64 = 0; L1:
//line :340:1
	for {











		if lang.Numbers_Lt_J_J__Z_NoInit(i_716000288__12, count_716000287__11) { var vec__716000289__13 any = lang.Indexed_Cast(chunk_716000286__10).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_716000288__12)); var rel__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000289__13, lang.RT_IntCast_J__I_NoInit(0), nil); var d__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000289__13, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_74.GetRawRoot__O()); var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_61, nil, nil, Lit_68, nil, nil, nil, nil); var tmp12 *jrt.String; var tmp13 any; var root_2565 any = A_arbace_repr_clojure_A_const_21.GetRawRoot__O(); var linked_2566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2565, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2567 lang.IFn
			if linked_2566 == nil { ifn_2567 = lang.IFn_Cast(root_2565) } else { ifn_2567 = nil }; var arg_2568 any = known__3; var arg_2569 any = rel__14; if linked_2566 == nil { tmp13 = ifn_2567.Invoke_O_O__O(arg_2568, arg_2569) } else { tmp13 = linked_2566.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2565, arg_2568, arg_2569) }; if jrt.J2g_Truth(tmp13) { tmp12 = Lit_107 } else { tmp12 = Lit_108 }; var tmp14 any = tmp12.Ref(); var tmp15 any; var root_2570 any = A_arbace_repr_clojure_A_const_160.GetRawRoot__O(); var linked_2571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2570, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2572 lang.IFn; if linked_2571 == nil { ifn_2572 = lang.IFn_Cast(root_2570) } else { ifn_2572 = nil }; var arg_2573 any = A_arbace_repr_clojure_A_const_124.Invoke_O__O(d__15); if linked_2571 == nil { tmp15 = ifn_2572.Invoke_O__O(arg_2573) } else { tmp15 = linked_2571.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2570, arg_2573) }; var tmp16 any = tmp15; var tmp17 *jrt.String
			if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_126.Invoke_O__O(d__15)) { tmp17 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_109, nil, Lit_110), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_repr_clojure_A_const_126.Invoke_O__O(d__15), nil)) } else { tmp17 = nil }
//line :353:1
			var tmp18 any = tmp17.Ref(); var tmp19 *jrt.String; var temp__1927000414__auto____24 any = lang.IFn_Cast(known__3).Invoke_O__O(rel__14)

			if jrt.J2g_Truth(temp__1927000414__auto____24) { var k__25 any = temp__1927000414__auto____24; tmp19 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_22, nil), jrt.RefArrayOf(jrt.Object_class, nil, k__25)) } else { tmp19 = nil }
//line :353:1
			var tmp20 any = tmp19.Ref(); var tmp21 *jrt.String; var tmp22 any; var and__1927000168__auto____24 any = A_arbace_repr_clojure_A_const_127.Invoke_O__O(d__15)


			if jrt.J2g_Truth(and__1927000168__auto____24) { var or__1927000174__auto____25 any = A_arbace_repr_clojure_A_const_149.Invoke_O__O(o__0); if jrt.J2g_Truth(or__1927000174__auto____25) { tmp22 = or__1927000174__auto____25 } else { var root_2579 any = A_arbace_repr_clojure_A_const_39.GetRawRoot__O(); var linked_2580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2579, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2581 lang.IFn; if linked_2580 == nil { ifn_2581 = lang.IFn_Cast(root_2579) } else { ifn_2581 = nil }; var arg_2582 any; var root_2574 any = A_arbace_repr_clojure_A_const_21.GetRawRoot__O(); var linked_2575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2574, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2576 lang.IFn; if linked_2575 == nil { ifn_2576 = lang.IFn_Cast(root_2574) } else { ifn_2576 = nil }; var arg_2577 any = known__3; var arg_2578 any = rel__14; if linked_2575 == nil { arg_2582 = ifn_2576.Invoke_O_O__O(arg_2577, arg_2578) } else { arg_2582 = linked_2575.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2574, arg_2577, arg_2578) }; if linked_2580 == nil { tmp22 = ifn_2581.Invoke_O__O(arg_2582) } else { tmp22 = linked_2580.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2579, arg_2582) } } } else { tmp22 = and__1927000168__auto____24 }; if jrt.J2g_Truth(tmp22) { tmp21 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_111, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_repr_clojure_A_const_127.Invoke_O__O(d__15))) } else { tmp21 = nil }
//line :353:1
			tmp10.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp14, rel__14, nil, tmp16, tmp18, tmp20, tmp21.Ref())).Ref())
//line :352:1
			seq_716000285__9, chunk_716000286__10, count_716000287__11, i_716000288__12 = seq_716000285__9, chunk_716000286__10, count_716000287__11, lang.Numbers_Unchecked_inc_J__J_NoInit(i_716000288__12); continue L1 } else { var temp__1927000414__auto____13 any; var root_2475 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2475, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2477 lang.IFn; if linked_2476 == nil { ifn_2477 = lang.IFn_Cast(root_2475) } else { ifn_2477 = nil }; var arg_2478 any = seq_716000285__9; if linked_2476 == nil { temp__1927000414__auto____13 = ifn_2477.Invoke_O__O(arg_2478) } else { temp__1927000414__auto____13 = linked_2476.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2475, arg_2478) }; if jrt.J2g_Truth(temp__1927000414__auto____13) { var seq_716000285__14 any = temp__1927000414__auto____13; var tmp23 any; var root_2479 any = A_arbace_repr_clojure_A_const_55.GetRawRoot__O(); var linked_2480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2479, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2481 lang.IFn; if linked_2480 == nil { ifn_2481 = lang.IFn_Cast(root_2479) } else { ifn_2481 = nil }; var arg_2482 any = seq_716000285__14; if linked_2480 == nil { tmp23 = ifn_2481.Invoke_O__O(arg_2482) } else { tmp23 = linked_2480.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2479, arg_2482) }; if jrt.J2g_Truth(tmp23) { var c__1927000678__auto____15 any; var root_2483 any = A_arbace_repr_clojure_A_const_56.GetRawRoot__O(); var linked_2484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2483, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2485 lang.IFn; if linked_2484 == nil { ifn_2485 = lang.IFn_Cast(root_2483) } else { ifn_2485 = nil }; var arg_2486 any = seq_716000285__14; if linked_2484 == nil { c__1927000678__auto____15 = ifn_2485.Invoke_O__O(arg_2486) } else { c__1927000678__auto____15 = linked_2484.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2483, arg_2486) }; var tmp24 any; var root_2587 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_2588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2587, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2589 lang.IFn; if linked_2588 == nil { ifn_2589 = lang.IFn_Cast(root_2587) } else { ifn_2589 = nil }; var arg_2590 any = seq_716000285__14; if linked_2588 == nil { tmp24 = ifn_2589.Invoke_O__O(arg_2590) } else { tmp24 = linked_2588.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2587, arg_2590) }; seq_716000285__9, chunk_716000286__10, count_716000287__11, i_716000288__12 = tmp24, c__1927000678__auto____15, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____15))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__716000292__15 any; var root_2487 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2487, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2489 lang.IFn; if linked_2488 == nil { ifn_2489 = lang.IFn_Cast(root_2487) } else { ifn_2489 = nil }; var arg_2490 any = seq_716000285__14; if linked_2488 == nil { vec__716000292__15 = ifn_2489.Invoke_O__O(arg_2490) } else { vec__716000292__15 = linked_2488.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2487, arg_2490) }; var rel__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000292__15, lang.RT_IntCast_J__I_NoInit(0), nil); var d__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000292__15, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_74.GetRawRoot__O()); var tmp26 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_61, nil, nil, Lit_68, nil, nil, nil, nil); var tmp27 *jrt.String; var tmp28 any; var root_2591 any = A_arbace_repr_clojure_A_const_21.GetRawRoot__O(); var linked_2592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2591, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2593 lang.IFn
				if linked_2592 == nil { ifn_2593 = lang.IFn_Cast(root_2591) } else { ifn_2593 = nil }; var arg_2594 any = known__3; var arg_2595 any = rel__16; if linked_2592 == nil { tmp28 = ifn_2593.Invoke_O_O__O(arg_2594, arg_2595) } else { tmp28 = linked_2592.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2591, arg_2594, arg_2595) }; if jrt.J2g_Truth(tmp28) { tmp27 = Lit_107 } else { tmp27 = Lit_108 }; var tmp29 any = tmp27.Ref(); var tmp30 any; var root_2596 any = A_arbace_repr_clojure_A_const_160.GetRawRoot__O(); var linked_2597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2596, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2598 lang.IFn; if linked_2597 == nil { ifn_2598 = lang.IFn_Cast(root_2596) } else { ifn_2598 = nil }; var arg_2599 any = A_arbace_repr_clojure_A_const_124.Invoke_O__O(d__17); if linked_2597 == nil { tmp30 = ifn_2598.Invoke_O__O(arg_2599) } else { tmp30 = linked_2597.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2596, arg_2599) }; var tmp31 any = tmp30; var tmp32 *jrt.String
				if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_126.Invoke_O__O(d__17)) { tmp32 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_109, nil, Lit_110), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_repr_clojure_A_const_126.Invoke_O__O(d__17), nil)) } else { tmp32 = nil }
//line :353:1
				var tmp33 any = tmp32.Ref(); var tmp34 *jrt.String; var temp__1927000414__auto____26 any = lang.IFn_Cast(known__3).Invoke_O__O(rel__16)

				if jrt.J2g_Truth(temp__1927000414__auto____26) { var k__27 any = temp__1927000414__auto____26; tmp34 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_22, nil), jrt.RefArrayOf(jrt.Object_class, nil, k__27)) } else { tmp34 = nil }
//line :353:1
				var tmp35 any = tmp34.Ref(); var tmp36 *jrt.String; var tmp37 any; var and__1927000168__auto____26 any = A_arbace_repr_clojure_A_const_127.Invoke_O__O(d__17)


				if jrt.J2g_Truth(and__1927000168__auto____26) { var or__1927000174__auto____27 any = A_arbace_repr_clojure_A_const_149.Invoke_O__O(o__0); if jrt.J2g_Truth(or__1927000174__auto____27) { tmp37 = or__1927000174__auto____27 } else { var root_2605 any = A_arbace_repr_clojure_A_const_39.GetRawRoot__O(); var linked_2606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2605, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2607 lang.IFn; if linked_2606 == nil { ifn_2607 = lang.IFn_Cast(root_2605) } else { ifn_2607 = nil }; var arg_2608 any; var root_2600 any = A_arbace_repr_clojure_A_const_21.GetRawRoot__O(); var linked_2601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2600, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2602 lang.IFn; if linked_2601 == nil { ifn_2602 = lang.IFn_Cast(root_2600) } else { ifn_2602 = nil }; var arg_2603 any = known__3; var arg_2604 any = rel__16; if linked_2601 == nil { arg_2608 = ifn_2602.Invoke_O_O__O(arg_2603, arg_2604) } else { arg_2608 = linked_2601.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2600, arg_2603, arg_2604) }; if linked_2606 == nil { tmp37 = ifn_2607.Invoke_O__O(arg_2608) } else { tmp37 = linked_2606.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2605, arg_2608) } } } else { tmp37 = and__1927000168__auto____26 }; if jrt.J2g_Truth(tmp37) { tmp36 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_111, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_repr_clojure_A_const_127.Invoke_O__O(d__17))) } else { tmp36 = nil }
//line :353:1
				tmp25.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp26, jrt.RefArrayOf(jrt.Object_class, nil, tmp29, rel__16, nil, tmp31, tmp33, tmp35, tmp36.Ref())).Ref())
//line :352:1
				var tmp38 any; var root_2613 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_2614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2613, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2615 lang.IFn; if linked_2614 == nil { ifn_2615 = lang.IFn_Cast(root_2613) } else { ifn_2615 = nil }; var arg_2616 any = seq_716000285__14; if linked_2614 == nil { tmp38 = ifn_2615.Invoke_O__O(arg_2616) } else { tmp38 = linked_2614.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2613, arg_2616) }; seq_716000285__9, chunk_716000286__10, count_716000287__11, i_716000288__12 = tmp38, nil, 0, 0; continue L1 } } }
//line :340:1
		break L1 }; var seq_716000295__9 any; var root_2491 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2491, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2493 lang.IFn; if
















	linked_2492 == nil { ifn_2493 = lang.IFn_Cast(root_2491) } else { ifn_2493 = nil }; var arg_2494 any = stale__8; if linked_2492 == nil { seq_716000295__9 = ifn_2493.Invoke_O__O(arg_2494) } else { seq_716000295__9 = linked_2492.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2491, arg_2494) }; var chunk_716000296__10 any; var count_716000297__11 int64 = 0; var i_716000298__12 int64 = 0; L2:
//line :340:1
	for {
















		if lang.Numbers_Lt_J_J__Z_NoInit(i_716000298__12, count_716000297__11) { var rel__13 any = lang.Indexed_Cast(chunk_716000296__10).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_716000298__12)); lang.IFn_Cast(A_arbace_repr_clojure_A_const_74.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_112, nil, Lit_113), jrt.RefArrayOf(jrt.Object_class, nil, rel__13, nil)).Ref()); seq_716000295__9, chunk_716000296__10, count_716000297__11, i_716000298__12 = seq_716000295__9, chunk_716000296__10, count_716000297__11, lang.Numbers_Unchecked_inc_J__J_NoInit(i_716000298__12); continue L2 } else { var temp__1927000414__auto____13_2 any; var root_2495 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2495, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2497 lang.IFn; if linked_2496 == nil { ifn_2497 = lang.IFn_Cast(root_2495) } else { ifn_2497 = nil }; var arg_2498 any = seq_716000295__9; if linked_2496 == nil { temp__1927000414__auto____13_2 = ifn_2497.Invoke_O__O(arg_2498) } else { temp__1927000414__auto____13_2 = linked_2496.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2495, arg_2498) }; if jrt.J2g_Truth(temp__1927000414__auto____13_2) { var seq_716000295__14 any = temp__1927000414__auto____13_2; var tmp39 any; var root_2499 any = A_arbace_repr_clojure_A_const_55.GetRawRoot__O(); var linked_2500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2499, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2501 lang.IFn; if linked_2500 == nil { ifn_2501 = lang.IFn_Cast(root_2499) } else { ifn_2501 = nil }; var arg_2502 any = seq_716000295__14; if linked_2500 == nil { tmp39 = ifn_2501.Invoke_O__O(arg_2502) } else { tmp39 = linked_2500.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2499, arg_2502) }; if jrt.J2g_Truth(tmp39) { var c__1927000678__auto____15_2 any; var root_2503 any = A_arbace_repr_clojure_A_const_56.GetRawRoot__O(); var linked_2504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2503, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2505 lang.IFn; if linked_2504 == nil { ifn_2505 = lang.IFn_Cast(root_2503) } else { ifn_2505 = nil }; var arg_2506 any = seq_716000295__14; if linked_2504 == nil { c__1927000678__auto____15_2 = ifn_2505.Invoke_O__O(arg_2506) } else { c__1927000678__auto____15_2 = linked_2504.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2503, arg_2506) }; var tmp40 any; var root_2621 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_2622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2621, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2623 lang.IFn; if linked_2622 == nil { ifn_2623 = lang.IFn_Cast(root_2621) } else { ifn_2623 = nil }; var arg_2624 any = seq_716000295__14; if linked_2622 == nil { tmp40 = ifn_2623.Invoke_O__O(arg_2624) } else { tmp40 = linked_2622.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2621, arg_2624) }; seq_716000295__9, chunk_716000296__10, count_716000297__11, i_716000298__12 = tmp40, c__1927000678__auto____15_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____15_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var rel__15 any; var root_2507 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2507, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2509 lang.IFn; if linked_2508 == nil { ifn_2509 = lang.IFn_Cast(root_2507) } else { ifn_2509 = nil }; var arg_2510 any = seq_716000295__14; if linked_2508 == nil { rel__15 = ifn_2509.Invoke_O__O(arg_2510) } else { rel__15 = linked_2508.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2507, arg_2510) }; lang.IFn_Cast(A_arbace_repr_clojure_A_const_74.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_112, nil, Lit_113), jrt.RefArrayOf(jrt.Object_class, nil, rel__15, nil)).Ref()); var tmp41 any; var root_2629 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_2630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2629, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2631 lang.IFn; if linked_2630 == nil { ifn_2631 = lang.IFn_Cast(root_2629) } else { ifn_2631 = nil }; var arg_2632 any = seq_716000295__14; if linked_2630 == nil { tmp41 = ifn_2631.Invoke_O__O(arg_2632) } else { tmp41 = linked_2630.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2629, arg_2632) }; seq_716000295__9, chunk_716000296__10, count_716000297__11, i_716000298__12 = tmp41, nil, 0, 0; continue L2 } } }
//line :340:1
		break L2 }; if

















	jrt.J2g_Truth(A_arbace_repr_clojure_A_const_149.Invoke_O__O(o__0)) { var seq_716000299__9 any; var root_2511 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2511, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2513 lang.IFn
		if linked_2512 == nil { ifn_2513 = lang.IFn_Cast(root_2511) } else { ifn_2513 = nil }; var arg_2514 any = outside__4; if linked_2512 == nil { seq_716000299__9 = ifn_2513.Invoke_O__O(arg_2514) } else { seq_716000299__9 = linked_2512.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2511, arg_2514) }
//line :358:1
		var chunk_716000300__10 any; var count_716000301__11 int64 = 0; var i_716000302__12 int64 = 0; L3: for {
			if lang.Numbers_Lt_J_J__Z_NoInit(i_716000302__12, count_716000301__11) { var vec__716000303__13 any = lang.Indexed_Cast(chunk_716000300__10).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_716000302__12)); var rel__14_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000303__13, lang.RT_IntCast_J__I_NoInit(0), nil); var d__15_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000303__13, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(A_arbace_repr_clojure_A_const_74.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_114, nil, Lit_111, nil), jrt.RefArrayOf(jrt.Object_class, nil, rel__14_2, nil, A_arbace_repr_clojure_A_const_127.Invoke_O__O(d__15_2))).Ref()); seq_716000299__9, chunk_716000300__10, count_716000301__11, i_716000302__12 = seq_716000299__9, chunk_716000300__10, count_716000301__11, lang.Numbers_Unchecked_inc_J__J_NoInit(i_716000302__12); continue L3 } else { var temp__1927000414__auto____13_3 any; var root_2515 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2515, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2517 lang.IFn; if linked_2516 == nil { ifn_2517 = lang.IFn_Cast(root_2515) } else { ifn_2517 = nil }; var arg_2518 any = seq_716000299__9; if linked_2516 == nil { temp__1927000414__auto____13_3 = ifn_2517.Invoke_O__O(arg_2518) } else { temp__1927000414__auto____13_3 = linked_2516.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2515, arg_2518) }; if jrt.J2g_Truth(temp__1927000414__auto____13_3) { var seq_716000299__14 any = temp__1927000414__auto____13_3; var tmp42 any; var root_2519 any = A_arbace_repr_clojure_A_const_55.GetRawRoot__O(); var linked_2520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2519, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2521 lang.IFn; if linked_2520 == nil { ifn_2521 = lang.IFn_Cast(root_2519) } else { ifn_2521 = nil }; var arg_2522 any = seq_716000299__14; if linked_2520 == nil { tmp42 = ifn_2521.Invoke_O__O(arg_2522) } else { tmp42 = linked_2520.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2519, arg_2522) }; if jrt.J2g_Truth(tmp42) { var c__1927000678__auto____15_3 any; var root_2523 any = A_arbace_repr_clojure_A_const_56.GetRawRoot__O(); var linked_2524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2523, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2525 lang.IFn; if linked_2524 == nil { ifn_2525 = lang.IFn_Cast(root_2523) } else { ifn_2525 = nil }; var arg_2526 any = seq_716000299__14; if linked_2524 == nil { c__1927000678__auto____15_3 = ifn_2525.Invoke_O__O(arg_2526) } else { c__1927000678__auto____15_3 = linked_2524.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2523, arg_2526) }; var tmp43 any; var root_2637 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_2638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2637, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2639 lang.IFn; if linked_2638 == nil { ifn_2639 = lang.IFn_Cast(root_2637) } else { ifn_2639 = nil }; var arg_2640 any = seq_716000299__14; if linked_2638 == nil { tmp43 = ifn_2639.Invoke_O__O(arg_2640) } else { tmp43 = linked_2638.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2637, arg_2640) }; seq_716000299__9, chunk_716000300__10, count_716000301__11, i_716000302__12 = tmp43, c__1927000678__auto____15_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____15_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__716000306__15 any; var root_2527 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2527, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2529 lang.IFn; if linked_2528 == nil { ifn_2529 = lang.IFn_Cast(root_2527) } else { ifn_2529 = nil }; var arg_2530 any = seq_716000299__14; if linked_2528 == nil { vec__716000306__15 = ifn_2529.Invoke_O__O(arg_2530) } else { vec__716000306__15 = linked_2528.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2527, arg_2530) }; var rel__16_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000306__15, lang.RT_IntCast_J__I_NoInit(0), nil); var d__17_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000306__15, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(A_arbace_repr_clojure_A_const_74.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_114, nil, Lit_111, nil), jrt.RefArrayOf(jrt.Object_class, nil, rel__16_2, nil, A_arbace_repr_clojure_A_const_127.Invoke_O__O(d__17_2))).Ref()); var tmp44 any; var root_2645 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_2646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2645, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2647 lang.IFn; if linked_2646 == nil { ifn_2647 = lang.IFn_Cast(root_2645) } else { ifn_2647 = nil }; var arg_2648 any = seq_716000299__14; if linked_2646 == nil { tmp44 = ifn_2647.Invoke_O__O(arg_2648) } else { tmp44 = linked_2646.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2645, arg_2648) }; seq_716000299__9, chunk_716000300__10, count_716000301__11, i_716000302__12 = tmp44, nil, 0, 0; continue L3 } } }
//line :358:1
			break L3 } }; var tmp45 lang.IFn =

	lang.IFn_Cast(A_arbace_repr_clojure_A_const_74.GetRawRoot__O()); var tmp46 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_179.GetRawRoot__O()); var tmp47 *jrt.String; if
	jrt.J2g_Truth(A_arbace_repr_clojure_A_const_151.Invoke_O__O(o__0)) { var tmp48 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_64, nil); var tmp49 any; var root_2531 any = A_arbace_repr_clojure_A_const_160.GetRawRoot__O(); var linked_2532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2531, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2533 lang.IFn; if linked_2532 == nil { ifn_2533 = lang.IFn_Cast(root_2531) } else { ifn_2533 = nil }; var arg_2534 any = A_arbace_repr_clojure_A_const_151.Invoke_O__O(o__0); if linked_2532 == nil { tmp49 = ifn_2533.Invoke_O__O(arg_2534) } else { tmp49 = linked_2532.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2531, arg_2534) }; tmp47 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp48, jrt.RefArrayOf(jrt.Object_class, nil, tmp49)) } else { tmp47 = Lit_14 }; var tmp50 any = /*line :360:1*/tmp47.Ref(); var tmp51 *jrt.String; var tmp52 any = A_arbace_repr_clojure_A_const_115; if

	lang.Util_Equiv_O_O__Z_NoInit(tmp52, A_arbace_repr_clojure_A_const_108.Invoke_O__O(o__0)) { tmp51 = Lit_116 } else { tmp51 = Lit_117 }; var tmp53 any = /*line :360:1*/tmp51.Ref(); var tmp54 any = A_arbace_repr_clojure_A_const_135.Invoke_O__O(r__2); var tmp55 any = A_arbace_repr_clojure_A_const_136.Invoke_O__O(r__2); var tmp56 any; var tmp57 any = A_arbace_repr_clojure_A_const_115; if



	lang.Util_Equiv_O_O__Z_NoInit(tmp57, A_arbace_repr_clojure_A_const_108.Invoke_O__O(o__0)) {
		tmp56 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_179.GetRawRoot__O()).Invoke_O_O__O(Lit_118, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(outside__4)).Ref()) } else {
			tmp56 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_179.GetRawRoot__O()).Invoke_O_O__O(Lit_119, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(one_way__5)).Ref()) }; /*line :360:1*/tmp45.Invoke_O__O(tmp46.Invoke_O_O_O_O_O_O_O_O_O_O__O(Lit_115, tmp50, tmp53, tmp54, tmp55, tmp56, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(diff__6)).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(diff__6)), int64(lang.RT_Count_O__I_NoInit(new__7)))).Ref(), jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(new__7)).Ref(), jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(stale__8)).Ref())); var root_2562 any =







	A_arbace_repr_clojure_A_const_180.GetRawRoot__O(); var linked_2563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2562, aot_arbace_core.A_arbace_core_shutdown_agents_A_fn_class); var ifn_2564 lang.IFn; if linked_2563 == nil { ifn_2564 = lang.IFn_Cast(root_2562) } else { ifn_2564 = nil }; if linked_2563 == nil { ifn_2564.Invoke__O() } else { linked_2563.(*aot_arbace_core.A_arbace_core_shutdown_agents_A).Invoke_O__O(root_2562) }; var tmp58 any; var or__1927000174__auto____9 any; var root_2463 any =
	A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2463, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2465 lang.IFn; if linked_2464 == nil { ifn_2465 = lang.IFn_Cast(root_2463) } else { ifn_2465 = nil }; var arg_2466 any = new__7; if linked_2464 == nil { or__1927000174__auto____9 = ifn_2465.Invoke_O__O(arg_2466) } else { or__1927000174__auto____9 = linked_2464.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2463, arg_2466) }; if jrt.J2g_Truth(or__1927000174__auto____9) { tmp58 = or__1927000174__auto____9 } else { var root_2467 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2467, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2469 lang.IFn; if linked_2468 == nil { ifn_2469 = lang.IFn_Cast(root_2467) } else { ifn_2469 = nil }; var arg_2470 any = stale__8; if linked_2468 == nil { tmp58 = ifn_2469.Invoke_O__O(arg_2470) } else { tmp58 = linked_2468.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2467, arg_2470) } }; if jrt.J2g_Truth(tmp58) { jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(1)); return nil } else { return nil } }
//line :347:1
func A_arbace_repr_clojure_run_roundtrip_fn__716000277_A_New() *A_arbace_repr_clojure_run_roundtrip_fn__716000277_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_roundtrip_fn__716000277_A{}; t.Ctor(); return t }
//line :347:1
func (t *A_arbace_repr_clojure_run_roundtrip_fn__716000277_A) Ctor() {}
//line :347:1
func (t *A_arbace_repr_clojure_run_roundtrip_fn__716000277_A) Invoke_O_O__O(self, p1__716000273_SHARP___1 any) any { var tmp1 any = A_arbace_repr_clojure_A_const_131; var tmp2 *lang.Keyword = A_arbace_repr_clojure_A_const_124; var tmp3 any; var root_2381 any = A_arbace_repr_clojure_A_const_175.GetRawRoot__O(); var linked_2382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2381, aot_arbace_core.A_arbace_core_val_A_fn_class); var ifn_2383 lang.IFn; if linked_2382 == nil { ifn_2383 = lang.IFn_Cast(root_2381) } else { ifn_2383 = nil }; var arg_2384 any = p1__716000273_SHARP___1; if linked_2382 == nil { tmp3 = ifn_2383.Invoke_O__O(arg_2384) } else { tmp3 = linked_2382.(*aot_arbace_core.A_arbace_core_val_A).Invoke_O_O__O(root_2381, arg_2384) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2.Invoke_O__O(tmp3))).Ref() }
func A_arbace_repr_clojure_run_roundtrip_fn__716000279_A_New() *A_arbace_repr_clojure_run_roundtrip_fn__716000279_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_roundtrip_fn__716000279_A{}; t.Ctor(); return t }
//line :348:1
func (t *A_arbace_repr_clojure_run_roundtrip_fn__716000279_A) Ctor() {}
//line :348:1
func (t *A_arbace_repr_clojure_run_roundtrip_fn__716000279_A) Invoke_O_O__O(self, p1__716000274_SHARP___1 any) any { var tmp1 any = A_arbace_repr_clojure_A_const_176; var tmp2 *lang.Keyword = A_arbace_repr_clojure_A_const_124; var tmp3 any; var root_2399 any = A_arbace_repr_clojure_A_const_175.GetRawRoot__O(); var linked_2400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2399, aot_arbace_core.A_arbace_core_val_A_fn_class); var ifn_2401 lang.IFn; if linked_2400 == nil { ifn_2401 = lang.IFn_Cast(root_2399) } else { ifn_2401 = nil }; var arg_2402 any = p1__716000274_SHARP___1; if linked_2400 == nil { tmp3 = ifn_2401.Invoke_O__O(arg_2402) } else { tmp3 = linked_2400.(*aot_arbace_core.A_arbace_core_val_A).Invoke_O_O__O(root_2399, arg_2402) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2.Invoke_O__O(tmp3))).Ref() }

func A_arbace_repr_clojure_run_roundtrip_fn__716000281_A_New_O(p0 any) *A_arbace_repr_clojure_run_roundtrip_fn__716000281_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_roundtrip_fn__716000281_A{}; t.Ctor_O(p0); return t }
//line :350:1
func (t *A_arbace_repr_clojure_run_roundtrip_fn__716000281_A) Ctor_O(c__known any) { t.F_known = c__known }
//line :350:1
func (t *A_arbace_repr_clojure_run_roundtrip_fn__716000281_A) Invoke_O_O__O(self, p1__716000275_SHARP___1 any) any { var root_2433 any = A_arbace_repr_clojure_A_const_21.GetRawRoot__O(); var linked_2434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2433, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2435 lang.IFn; if linked_2434 == nil { ifn_2435 = lang.IFn_Cast(root_2433) } else { ifn_2435 = nil }; var arg_2436 any = t.F_known; var arg_2437 any = p1__716000275_SHARP___1; if linked_2434 == nil { return ifn_2435.Invoke_O_O__O(arg_2436, arg_2437) } else { return linked_2434.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2433, arg_2436, arg_2437) } }
func A_arbace_repr_clojure_run_roundtrip_fn__716000283_A_New_O(p0 any) *A_arbace_repr_clojure_run_roundtrip_fn__716000283_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_roundtrip_fn__716000283_A{}; t.Ctor_O(p0); return t }
//line :351:1
func (t *A_arbace_repr_clojure_run_roundtrip_fn__716000283_A) Ctor_O(c__diff any) { t.F_diff = c__diff }
//line :351:1
func (t *A_arbace_repr_clojure_run_roundtrip_fn__716000283_A) Invoke_O_O__O(self, p1__716000276_SHARP___1 any) any { var root_2448 any = A_arbace_repr_clojure_A_const_21.GetRawRoot__O(); var linked_2449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2448, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2450 lang.IFn; if linked_2449 == nil { ifn_2450 = lang.IFn_Cast(root_2448) } else { ifn_2450 = nil }; var arg_2451 any = t.F_diff; var arg_2452 any = p1__716000276_SHARP___1; if linked_2449 == nil { return ifn_2450.Invoke_O_O__O(arg_2451, arg_2452) } else { return linked_2449.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2448, arg_2451, arg_2452) } }



















func A_arbace_repr_clojure__main_A_New() *A_arbace_repr_clojure__main_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure__main_A{}; t.Ctor(); return t }
//line :371:1
func (t *A_arbace_repr_clojure__main_A) Ctor() {}
//line :371:1
func (t *A_arbace_repr_clojure__main_A) DoInvoke_O_O__O(self, args__0 any) any { var vec__716000310__2 any = args__0; var seq__716000311__3 any; var root_2649 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2649, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2651 lang.IFn; if
										linked_2650 == nil { ifn_2651 = lang.IFn_Cast(root_2649) } else { ifn_2651 = nil }; var arg_2652 any = vec__716000310__2; if linked_2650 == nil { seq__716000311__3 = ifn_2651.Invoke_O__O(arg_2652) } else { seq__716000311__3 = linked_2650.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2649, arg_2652) }; var first__716000312__4 any; var root_2653 any = /*line :371:1*/A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2653, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2655 lang.IFn; if
										linked_2654 == nil { ifn_2655 = lang.IFn_Cast(root_2653) } else { ifn_2655 = nil }; var arg_2656 any = seq__716000311__3; if linked_2654 == nil { first__716000312__4 = ifn_2655.Invoke_O__O(arg_2656) } else { first__716000312__4 = linked_2654.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2653, arg_2656) }; var seq__716000311__5 any; var root_2657 any = /*line :371:1*/A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_2658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2657, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2659 lang.IFn; if
										linked_2658 == nil { ifn_2659 = lang.IFn_Cast(root_2657) } else { ifn_2659 = nil }; var arg_2660 any = seq__716000311__3; if linked_2658 == nil { seq__716000311__5 = ifn_2659.Invoke_O__O(arg_2660) } else { seq__716000311__5 = linked_2658.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2657, arg_2660) }; var cmd__6 any = first__716000312__4; var args__7 any = seq__716000311__5; var verb__8 any = /*line :371:1*/lang.RT_Get_O_O__O_NoInit(A_arbace_repr_clojure_A_const_181, cmd__6); var ___9 any; _ = ___9; if


	jrt.J2g_Truth(verb__8) { ___9 = nil } else { var root_2661 any = A_arbace_repr_clojure_A_const_182.GetRawRoot__O(); var linked_2662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2661, A_arbace_repr_clojure_usage_A_fn_class); var ifn_2663 lang.IFn; if linked_2662 == nil { ifn_2663 = lang.IFn_Cast(root_2661) } else { ifn_2663 = nil }; if linked_2662 == nil { ___9 = ifn_2663.Invoke__O() } else { ___9 = linked_2662.(*A_arbace_repr_clojure_usage_A).Invoke_O__O(root_2661) } }; var o__10 any; var root_2664 any = /*line :371:1*/A_arbace_repr_clojure_A_const_183.GetRawRoot__O(); var linked_2665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2664, A_arbace_repr_clojure_parse_args_A_fn_class); var ifn_2666 lang.IFn; if



	linked_2665 == nil { ifn_2666 = lang.IFn_Cast(root_2664) } else { ifn_2666 = nil }; var arg_2667 any = args__7; if linked_2665 == nil { o__10 = ifn_2666.Invoke_O__O(arg_2667) } else { o__10 = linked_2665.(*A_arbace_repr_clojure_parse_args_A).Invoke_O_O__O(root_2664, arg_2667) }; var known__11 any; var root_2673 any = /*line :371:1*/A_arbace_repr_clojure_A_const_69.GetRawRoot__O(); var linked_2674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2673, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2675 lang.IFn; if




	linked_2674 == nil { ifn_2675 = lang.IFn_Cast(root_2673) } else { ifn_2675 = nil }; var arg_2676 any; var root_2668 any = A_arbace_repr_clojure_A_const_152.GetRawRoot__O(); var linked_2669 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2668, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2670 lang.IFn; if linked_2669 == nil { ifn_2670 = lang.IFn_Cast(root_2668) } else { ifn_2670 = nil }; var arg_2671 any = A_arbace_repr_clojure_A_const_161; var arg_2672 any = A_arbace_repr_clojure_A_const_156.GetRawRoot__O(); if linked_2669 == nil { arg_2676 = ifn_2670.Invoke_O_O__O(arg_2671, arg_2672) } else { arg_2676 = linked_2669.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2668, arg_2671, arg_2672) }; if linked_2674 == nil { known__11 = ifn_2675.Invoke_O__O(arg_2676) } else { known__11 = linked_2674.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2673, arg_2676) }; var temp__1927000414__auto____12 any; var root_2712 any = /*line :371:1*/A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2712, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2714 lang.IFn; if





	linked_2713 == nil { ifn_2714 = lang.IFn_Cast(root_2712) } else { ifn_2714 = nil }; var arg_2715 any; var root_2707 any = A_arbace_repr_clojure_A_const_137.GetRawRoot__O(); var linked_2708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2707, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_2709 lang.IFn; if linked_2708 == nil { ifn_2709 = lang.IFn_Cast(root_2707) } else { ifn_2709 = nil }; var arg_2710 any = known__11; var arg_2711 any = A_arbace_repr_clojure_A_const_32.Invoke_O__O(o__10); if linked_2708 == nil { arg_2715 = ifn_2709.Invoke_O_O__O(arg_2710, arg_2711) } else { arg_2715 = linked_2708.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_2707, arg_2710, arg_2711) }; if linked_2713 == nil { temp__1927000414__auto____12 = ifn_2714.Invoke_O__O(arg_2715) } else { temp__1927000414__auto____12 = linked_2713.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2712, arg_2715) }; if jrt.J2g_Truth(temp__1927000414__auto____12) { var bad__13 any = temp__1927000414__auto____12; var tmp1 any; var root_2726 any = A_arbace_repr_clojure_A_const_142.GetRawRoot__O(); var linked_2727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2726, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2728 lang.IFn
		if linked_2727 == nil { ifn_2728 = lang.IFn_Cast(root_2726) } else { ifn_2728 = nil }; var arg_2729 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_1, nil); var tmp3 any; var root_2721 any = A_arbace_repr_clojure_A_const_188.GetRawRoot__O(); var linked_2722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2721, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_2723 lang.IFn; if linked_2722 == nil { ifn_2723 = lang.IFn_Cast(root_2721) } else { ifn_2723 = nil }; var arg_2724 any = Lit_2; var arg_2725 any; var root_2716 any = A_arbace_repr_clojure_A_const_152.GetRawRoot__O(); var linked_2717 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2716, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2718 lang.IFn; if linked_2717 == nil { ifn_2718 = lang.IFn_Cast(root_2716) } else { ifn_2718 = nil }; var arg_2719 any = A_arbace_repr_clojure_A_const_160.GetRawRoot__O(); var arg_2720 any = bad__13; if linked_2717 == nil { arg_2725 = ifn_2718.Invoke_O_O__O(arg_2719, arg_2720) } else { arg_2725 = linked_2717.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2716, arg_2719, arg_2720) }; if linked_2722 == nil { tmp3 = ifn_2723.Invoke_O_O__O(arg_2724, arg_2725) } else { tmp3 = linked_2722.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_2721, arg_2724, arg_2725) }; arg_2729 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref(); var arg_2730 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_2727 == nil { tmp1 = ifn_2728.Invoke_O_O__O(arg_2729, arg_2730) } else { tmp1 = linked_2727.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_2726, arg_2729, arg_2730) }
//line :377:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }; if

	jrt.J2g_Truth(A_arbace_repr_clojure_A_const_146.Invoke_O__O(o__10)) {
		var root_2677 any = A_arbace_repr_clojure_A_const_184.GetRawRoot__O(); var linked_2678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2677, A_arbace_repr_clojure_print_rules_A_fn_class); var ifn_2679 lang.IFn; if linked_2678 == nil { ifn_2679 = lang.IFn_Cast(root_2677) } else { ifn_2679 = nil }; if linked_2678 == nil { return ifn_2679.Invoke__O() } else { return linked_2678.(*A_arbace_repr_clojure_print_rules_A).Invoke_O__O(root_2677) } } else {
//line :379:1
			if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_145.Invoke_O__O(o__10)) { var tmp4 any = A_arbace_repr_clojure_A_const_23; var tmp5 any = A_arbace_repr_clojure_A_const_23.Invoke_O__O(o__10); var tmp6 any = A_arbace_repr_clojure_A_const_26; var p__12 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp6, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(A_arbace_repr_clojure_A_const_147.Invoke_O__O(o__10))).Ref()))
				var tmp7 /*line :379:1*/*lang.Keyword = A_arbace_repr_clojure_A_const_19


				lang.IFn_Cast(A_arbace_repr_clojure_A_const_189.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_A_const_66.GetRawRoot__O()).Invoke_O__O(verb__8))).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_repr_clojure_A_const_81.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_A_const_190.Get__O()), p__12, Lit_3, A_arbace_repr_clojure_A_const_32.Invoke_O__O(o__10)))
				var root_2680 any = A_arbace_repr_clojure_A_const_185.GetRawRoot__O(); var linked_2681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2680, aot_arbace_core.A_arbace_core_flush_A_fn_class); var ifn_2682 lang.IFn; if linked_2681 == nil { ifn_2682 = lang.IFn_Cast(root_2680) } else { ifn_2682 = nil }; if linked_2681 == nil { return ifn_2682.Invoke__O() } else { return linked_2681.(*aot_arbace_core.A_arbace_core_flush_A).Invoke_O__O(root_2680) } } else {
//line :379:1
					var tmp8 any; var root_2683 any = A_arbace_repr_clojure_A_const_140.GetRawRoot__O(); var linked_2684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2683, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2685 lang.IFn




					if linked_2684 == nil { ifn_2685 = lang.IFn_Cast(root_2683) } else { ifn_2685 = nil }; var arg_2686 any = A_arbace_repr_clojure_A_const_139.Invoke_O__O(o__10); if linked_2684 == nil { tmp8 = ifn_2685.Invoke_O__O(arg_2686) } else { tmp8 = linked_2684.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2683, arg_2686) }
//line :379:1
					if jrt.J2g_Truth(tmp8) {




						var root_2687 any = A_arbace_repr_clojure_A_const_182.GetRawRoot__O(); var linked_2688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2687, A_arbace_repr_clojure_usage_A_fn_class); var ifn_2689 lang.IFn; if linked_2688 == nil { ifn_2689 = lang.IFn_Cast(root_2687) } else { ifn_2689 = nil }; if linked_2688 == nil { return ifn_2689.Invoke__O() } else { return linked_2688.(*A_arbace_repr_clojure_usage_A).Invoke_O__O(root_2687) } } else {
//line :379:1
							if lang.Util_Equiv_O_O__Z_NoInit(verb__8, A_arbace_repr_clojure_A_const_186) {





								var root_2690 any = A_arbace_repr_clojure_A_const_187.GetRawRoot__O(); var linked_2691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2690, A_arbace_repr_clojure_run_roundtrip_A_fn_class); var ifn_2692 lang.IFn; if linked_2691 == nil { ifn_2692 = lang.IFn_Cast(root_2690) } else { ifn_2692 = nil }; var arg_2693 any = o__10; if linked_2691 == nil { return ifn_2692.Invoke_O__O(arg_2693) } else { return linked_2691.(*A_arbace_repr_clojure_run_roundtrip_A).Invoke_O_O__O(root_2690, arg_2693) } } else {
//line :379:1
									var tmp9 any; var root_2694 any = A_arbace_repr_clojure_A_const_39.GetRawRoot__O(); var linked_2695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2694, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2696 lang.IFn






									if linked_2695 == nil { ifn_2696 = lang.IFn_Cast(root_2694) } else { ifn_2696 = nil }; var arg_2697 any; var or__1927000174__auto____12 any = A_arbace_repr_clojure_A_const_27.Invoke_O__O(o__10); if jrt.J2g_Truth(or__1927000174__auto____12) { arg_2697 = or__1927000174__auto____12 } else { arg_2697 = A_arbace_repr_clojure_A_const_144.Invoke_O__O(o__10) }; if linked_2695 == nil { tmp9 = ifn_2696.Invoke_O__O(arg_2697) } else { tmp9 = linked_2695.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2694, arg_2697) }
//line :379:1
									if jrt.J2g_Truth(tmp9) {







										var root_2752 any = A_arbace_repr_clojure_A_const_84.GetRawRoot__O(); var linked_2753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2752, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2754 lang.IFn; if linked_2753 == nil { ifn_2754 = lang.IFn_Cast(root_2752) } else { ifn_2754 = nil }; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_85.GetRawRoot__O()); var tmp11 any = A_arbace_repr_clojure_A_const_86; var arg_2755 any = tmp10.Invoke_O_O__O(tmp11, A_arbace_repr_clojure_A_const_87.Get__O()); if linked_2753 == nil { ifn_2754.Invoke_O__O(arg_2755) } else { linked_2753.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2752, arg_2755) }; var tmp12 any = A_arbace_repr_clojure__main_fn__716000313_A_New(); var tmp13 *jrt.Class; var fncls__2746 *jrt.Class = A_arbace_repr_clojure__main_fn__716000313_A_fn_class; if fncls__2746 == nil { var fncls__2746d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_repr_clojure__main_fn__716000313_A_fn_class = fncls__2746d; tmp13 = fncls__2746d } else { tmp13 = fncls__2746 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil).Invoke__O(); jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2)); return nil } else {
//line :379:1
											if A_arbace_repr_clojure_A_const_33 != nil { var s__12 any; var root_2698 any = A_arbace_repr_clojure_A_const_94.GetRawRoot__O(); var linked_2699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2698, A_arbace_repr_clojure_run_A_fn_class); var ifn_2700 lang.IFn









												if linked_2699 == nil { ifn_2700 = lang.IFn_Cast(root_2698) } else { ifn_2700 = nil }; var arg_2701 any = verb__8; var arg_2702 any = A_arbace_repr_clojure_A_const_139.Invoke_O__O(o__10); var arg_2703 any; if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_144.Invoke_O__O(o__10)) { arg_2703 = nil } else { arg_2703 = A_arbace_repr_clojure_A_const_27.Invoke_O__O(o__10) }; var arg_2704 any = o__10; if linked_2699 == nil { s__12 = ifn_2700.Invoke_O_O_O_O__O(arg_2701, arg_2702, arg_2703, arg_2704) } else { s__12 = linked_2699.(*A_arbace_repr_clojure_run_A).Invoke_O_O_O_O_O__O(root_2698, arg_2701, arg_2702, arg_2703, arg_2704) }
												if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_148.Invoke_O__O(o__10)) { } else {
													var root_2781 any = A_arbace_repr_clojure_A_const_84.GetRawRoot__O(); var linked_2782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2781, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2783 lang.IFn; if linked_2782 == nil { ifn_2783 = lang.IFn_Cast(root_2781) } else { ifn_2783 = nil }; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_85.GetRawRoot__O()); var tmp15 any = A_arbace_repr_clojure_A_const_86; var arg_2784 any = tmp14.Invoke_O_O__O(tmp15, A_arbace_repr_clojure_A_const_87.Get__O()); if linked_2782 == nil { ifn_2783.Invoke_O__O(arg_2784) } else { linked_2782.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2781, arg_2784) }; var tmp16 any = A_arbace_repr_clojure__main_fn__716000315_A_New_O_O(s__12, verb__8); var tmp17 *jrt.Class; var fncls__2775 *jrt.Class = A_arbace_repr_clojure__main_fn__716000315_A_fn_class; if fncls__2775 == nil { var fncls__2775d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_repr_clojure__main_fn__716000315_A_fn_class = fncls__2775d; tmp17 = fncls__2775d } else { tmp17 = fncls__2775 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil).Invoke__O()
												}



												var tmp18 bool; var na_2705 any = A_arbace_repr_clojure_A_const_82.Invoke_O__O(s__12); if jrt.Long_InstanceOf(na_2705) { var n0_2706 int64 = jrt.NN(jrt.Long_Cast(na_2705)).LongValue__J(); tmp18 = n0_2706 > 0 } else { if jrt.Double_InstanceOf(na_2705) { var n0_2706_2 float64 = jrt.NN(jrt.Double_Cast(na_2705)).DoubleValue__D(); tmp18 = n0_2706_2 > 0.0 } else { tmp18 = lang.Numbers_IsPos_O__Z_NoInit(na_2705) } }; if tmp18 { jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(1)); return nil } else { return nil } } else {
//line :379:1
													return nil } } } } } } }







func A_arbace_repr_clojure__main_fn__716000313_A_New() *A_arbace_repr_clojure__main_fn__716000313_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure__main_fn__716000313_A{}; t.Ctor(); return t }
//line :387:1
func (t *A_arbace_repr_clojure__main_fn__716000313_A) Ctor() {}
//line :387:1
func (t *A_arbace_repr_clojure__main_fn__716000313_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_74.GetRawRoot__O()).Invoke_O__O(Lit_6); return nil }(); var root_2743 any = A_arbace_repr_clojure_A_const_75.GetRawRoot__O(); var linked_2744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2743, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2745 lang.IFn; if linked_2744 == nil { ifn_2745 = lang.IFn_Cast(root_2743) } else { ifn_2745 = nil }; if linked_2744 == nil { ifn_2745.Invoke__O() } else { linked_2744.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2743) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }



func A_arbace_repr_clojure__main_fn__716000315_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure__main_fn__716000315_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure__main_fn__716000315_A{}; t.Ctor_O_O(p0, p1); return t }
//line :391:1
func (t *A_arbace_repr_clojure__main_fn__716000315_A) Ctor_O_O(c__s, c__verb any) { t.F_s = c__s; t.F_verb = c__verb }
//line :391:1
func (t *A_arbace_repr_clojure__main_fn__716000315_A) Invoke_O__O(self any) any { var tmp1 any; tmp16 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_74.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_179.GetRawRoot__O()); var tmp4 any = A_arbace_repr_clojure_A_const_93.Invoke_O__O(t.F_s); var tmp5 *jrt.String
											if lang.Util_Equiv_O_O__Z_NoInit(t.F_verb, A_arbace_repr_clojure_A_const_191) { tmp5 = Lit_8 } else { tmp5 = Lit_9 }
//line :392:1
		var tmp6 any = tmp5.Ref(); var tmp7 any = A_arbace_repr_clojure_A_const_26.Invoke_O__O(t.F_s); var tmp8 *jrt.String; var tmp9 any; var t_ any = t.F_verb

		t.F_verb = nil; tmp9 = t_; if lang.Util_Equiv_O_O__Z_NoInit(tmp9, A_arbace_repr_clojure_A_const_191) { tmp8 = Lit_10 } else { tmp8 = Lit_11 }
//line :392:1
		var tmp10 any = tmp8.Ref(); var tmp11 any = A_arbace_repr_clojure_A_const_92.Invoke_O__O(t.F_s); var tmp12 any = A_arbace_repr_clojure_A_const_79.Invoke_O__O(t.F_s); var tmp13 any = A_arbace_repr_clojure_A_const_89.Invoke_O__O(t.F_s); var tmp14 *lang.Keyword = A_arbace_repr_clojure_A_const_82; var tmp15 any; var t__2 any = t.F_s


		t.F_s = nil; tmp15 = t__2
//line :392:1
		tmp1 = tmp2.Invoke_O__O(tmp3.Invoke_O_O_O_O_O_O_O_O_O__O(Lit_7, tmp4, tmp6, tmp7, tmp10, tmp11, tmp12, tmp13, tmp14.Invoke_O__O(tmp15))) }
//line :391:1
	return nil }(); var root_2772 any = A_arbace_repr_clojure_A_const_75.GetRawRoot__O(); var linked_2773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2772, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2774 lang.IFn; if linked_2773 == nil { ifn_2774 = lang.IFn_Cast(root_2772) } else { ifn_2774 = nil }; if linked_2773 == nil { ifn_2774.Invoke__O() } else { linked_2773.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2772) }; if tmp16 != nil { panic(tmp16) }; return tmp1 }































































































































































type A_arbace_repr_clojure_A struct{ jrt.Object }

var A_arbace_repr_clojure_A_const_pool *jrt.RefArray

var A_arbace_repr_clojure_A_const_0 *lang.Var

var A_arbace_repr_clojure_A_const_1 any

var A_arbace_repr_clojure_A_const_2 *lang.Var

var A_arbace_repr_clojure_A_const_3 any

var A_arbace_repr_clojure_A_const_4 any

var A_arbace_repr_clojure_A_const_5 any

var A_arbace_repr_clojure_A_const_6 any

var A_arbace_repr_clojure_A_const_7 *lang.Var

var A_arbace_repr_clojure_A_const_8 *lang.Var

var A_arbace_repr_clojure_A_const_9 *lang.Var

var A_arbace_repr_clojure_A_const_10 *lang.Var

var A_arbace_repr_clojure_A_const_11 any

var A_arbace_repr_clojure_A_const_12 *lang.Var

var A_arbace_repr_clojure_A_const_13 any

var A_arbace_repr_clojure_A_const_14 *lang.Var

var A_arbace_repr_clojure_A_const_15 *lang.Var

var A_arbace_repr_clojure_A_const_16 *lang.Var

var A_arbace_repr_clojure_A_const_17 *lang.Var

var A_arbace_repr_clojure_A_const_18 *lang.Keyword

var A_arbace_repr_clojure_A_const_19 *lang.Keyword

var A_arbace_repr_clojure_A_const_20 *lang.Var

var A_arbace_repr_clojure_A_const_21 *lang.Var

var A_arbace_repr_clojure_A_const_22 *lang.Var

var A_arbace_repr_clojure_A_const_23 *lang.Keyword

var A_arbace_repr_clojure_A_const_24 *lang.Keyword

var A_arbace_repr_clojure_A_const_25 *lang.Keyword

var A_arbace_repr_clojure_A_const_26 *lang.Keyword

var A_arbace_repr_clojure_A_const_27 *lang.Keyword

var A_arbace_repr_clojure_A_const_28 any

var A_arbace_repr_clojure_A_const_29 *lang.Var

var A_arbace_repr_clojure_A_const_30 any

var A_arbace_repr_clojure_A_const_31 *lang.Var

var A_arbace_repr_clojure_A_const_32 *lang.Keyword

var A_arbace_repr_clojure_A_const_33 *lang.Keyword

var A_arbace_repr_clojure_A_const_34 *lang.Keyword

var A_arbace_repr_clojure_A_const_35 *lang.Var

var A_arbace_repr_clojure_A_const_36 *lang.Var

var A_arbace_repr_clojure_A_const_37 any

var A_arbace_repr_clojure_A_const_38 any

var A_arbace_repr_clojure_A_const_39 *lang.Var

var A_arbace_repr_clojure_A_const_40 any

var A_arbace_repr_clojure_A_const_41 any

var A_arbace_repr_clojure_A_const_42 any

var A_arbace_repr_clojure_A_const_43 any

var A_arbace_repr_clojure_A_const_44 *lang.Var

var A_arbace_repr_clojure_A_const_45 any

var A_arbace_repr_clojure_A_const_46 any

var A_arbace_repr_clojure_A_const_47 *lang.Var

var A_arbace_repr_clojure_A_const_48 *lang.Keyword

var A_arbace_repr_clojure_A_const_49 any

var A_arbace_repr_clojure_A_const_50 *lang.Keyword

var A_arbace_repr_clojure_A_const_51 *lang.Var

var A_arbace_repr_clojure_A_const_52 any

var A_arbace_repr_clojure_A_const_53 *lang.Var

var A_arbace_repr_clojure_A_const_54 *lang.Var

var A_arbace_repr_clojure_A_const_55 *lang.Var

var A_arbace_repr_clojure_A_const_56 *lang.Var

var A_arbace_repr_clojure_A_const_57 *lang.Var

var A_arbace_repr_clojure_A_const_58 *lang.Var

var A_arbace_repr_clojure_A_const_59 *lang.Var

var A_arbace_repr_clojure_A_const_60 *lang.Var

var A_arbace_repr_clojure_A_const_61 *lang.Var

var A_arbace_repr_clojure_A_const_62 *lang.Var

var A_arbace_repr_clojure_A_const_63 *lang.Var

var A_arbace_repr_clojure_A_const_64 *lang.Var

var A_arbace_repr_clojure_A_const_65 *lang.Var

var A_arbace_repr_clojure_A_const_66 *lang.Var

var A_arbace_repr_clojure_A_const_67 *lang.Keyword

var A_arbace_repr_clojure_A_const_68 *lang.Var

var A_arbace_repr_clojure_A_const_69 *lang.Var

var A_arbace_repr_clojure_A_const_70 *lang.Var

var A_arbace_repr_clojure_A_const_71 any

var A_arbace_repr_clojure_A_const_72 *lang.Var

var A_arbace_repr_clojure_A_const_73 *lang.Var

var A_arbace_repr_clojure_A_const_74 *lang.Var

var A_arbace_repr_clojure_A_const_75 *lang.Var

var A_arbace_repr_clojure_A_const_76 *lang.Keyword

var A_arbace_repr_clojure_A_const_77 *lang.Var

var A_arbace_repr_clojure_A_const_78 *lang.Var

var A_arbace_repr_clojure_A_const_79 *lang.Keyword

var A_arbace_repr_clojure_A_const_80 *lang.Var

var A_arbace_repr_clojure_A_const_81 *lang.Var

var A_arbace_repr_clojure_A_const_82 *lang.Keyword

var A_arbace_repr_clojure_A_const_83 *lang.Var

var A_arbace_repr_clojure_A_const_84 *lang.Var

var A_arbace_repr_clojure_A_const_85 *lang.Var

var A_arbace_repr_clojure_A_const_86 *lang.Var

var A_arbace_repr_clojure_A_const_87 *lang.Var

var A_arbace_repr_clojure_A_const_88 *lang.Var

var A_arbace_repr_clojure_A_const_89 *lang.Keyword

var A_arbace_repr_clojure_A_const_90 *lang.Var

var A_arbace_repr_clojure_A_const_91 *lang.Var

var A_arbace_repr_clojure_A_const_92 *lang.Keyword

var A_arbace_repr_clojure_A_const_93 *lang.Keyword

var A_arbace_repr_clojure_A_const_94 *lang.Var

var A_arbace_repr_clojure_A_const_95 *lang.Keyword

var A_arbace_repr_clojure_A_const_96 *lang.Var

var A_arbace_repr_clojure_A_const_97 *lang.Var

var A_arbace_repr_clojure_A_const_98 *lang.Var

var A_arbace_repr_clojure_A_const_99 *lang.Var

var A_arbace_repr_clojure_A_const_100 *lang.Var

var A_arbace_repr_clojure_A_const_101 *lang.Var

var A_arbace_repr_clojure_A_const_102 *lang.Var

var A_arbace_repr_clojure_A_const_103 *lang.Var

var A_arbace_repr_clojure_A_const_104 *lang.Var

var A_arbace_repr_clojure_A_const_105 *lang.Keyword

var A_arbace_repr_clojure_A_const_106 *lang.Var

var A_arbace_repr_clojure_A_const_107 *lang.Var

var A_arbace_repr_clojure_A_const_108 *lang.Keyword

var A_arbace_repr_clojure_A_const_109 *lang.Keyword

var A_arbace_repr_clojure_A_const_110 *lang.Keyword

var A_arbace_repr_clojure_A_const_111 *lang.Var

var A_arbace_repr_clojure_A_const_112 *lang.Var

var A_arbace_repr_clojure_A_const_113 any

var A_arbace_repr_clojure_A_const_114 *lang.Var

var A_arbace_repr_clojure_A_const_115 *lang.Keyword

var A_arbace_repr_clojure_A_const_116 any

var A_arbace_repr_clojure_A_const_117 any

var A_arbace_repr_clojure_A_const_118 *lang.Var

var A_arbace_repr_clojure_A_const_119 *lang.Var

var A_arbace_repr_clojure_A_const_120 *lang.Var

var A_arbace_repr_clojure_A_const_121 any

var A_arbace_repr_clojure_A_const_122 *lang.Var

var A_arbace_repr_clojure_A_const_123 any

var A_arbace_repr_clojure_A_const_124 *lang.Keyword

var A_arbace_repr_clojure_A_const_125 *lang.Keyword

var A_arbace_repr_clojure_A_const_126 *lang.Keyword

var A_arbace_repr_clojure_A_const_127 *lang.Keyword

var A_arbace_repr_clojure_A_const_128 *lang.Var

var A_arbace_repr_clojure_A_const_129 any

var A_arbace_repr_clojure_A_const_130 *lang.Var

var A_arbace_repr_clojure_A_const_131 *lang.Keyword

var A_arbace_repr_clojure_A_const_132 any

var A_arbace_repr_clojure_A_const_133 any

var A_arbace_repr_clojure_A_const_134 any

var A_arbace_repr_clojure_A_const_135 *lang.Keyword

var A_arbace_repr_clojure_A_const_136 *lang.Keyword

var A_arbace_repr_clojure_A_const_137 *lang.Var

var A_arbace_repr_clojure_A_const_138 *lang.Keyword

var A_arbace_repr_clojure_A_const_139 *lang.Keyword

var A_arbace_repr_clojure_A_const_140 *lang.Var

var A_arbace_repr_clojure_A_const_141 *lang.Var

var A_arbace_repr_clojure_A_const_142 *lang.Var

var A_arbace_repr_clojure_A_const_143 *lang.Var

var A_arbace_repr_clojure_A_const_144 *lang.Keyword

var A_arbace_repr_clojure_A_const_145 *lang.Keyword

var A_arbace_repr_clojure_A_const_146 *lang.Keyword

var A_arbace_repr_clojure_A_const_147 *lang.Keyword

var A_arbace_repr_clojure_A_const_148 *lang.Keyword

var A_arbace_repr_clojure_A_const_149 *lang.Keyword

var A_arbace_repr_clojure_A_const_150 *lang.Keyword

var A_arbace_repr_clojure_A_const_151 *lang.Keyword

var A_arbace_repr_clojure_A_const_152 *lang.Var

var A_arbace_repr_clojure_A_const_153 *lang.Var

var A_arbace_repr_clojure_A_const_154 any

var A_arbace_repr_clojure_A_const_155 *lang.Var

var A_arbace_repr_clojure_A_const_156 *lang.Var

var A_arbace_repr_clojure_A_const_157 *lang.Var

var A_arbace_repr_clojure_A_const_158 *lang.Keyword

var A_arbace_repr_clojure_A_const_159 any

var A_arbace_repr_clojure_A_const_160 *lang.Var

var A_arbace_repr_clojure_A_const_161 *lang.Keyword

var A_arbace_repr_clojure_A_const_162 *lang.Keyword

var A_arbace_repr_clojure_A_const_163 *lang.Keyword

var A_arbace_repr_clojure_A_const_164 any

var A_arbace_repr_clojure_A_const_165 *lang.Keyword

var A_arbace_repr_clojure_A_const_166 *lang.Keyword

var A_arbace_repr_clojure_A_const_167 *lang.Keyword

var A_arbace_repr_clojure_A_const_168 any

var A_arbace_repr_clojure_A_const_169 *lang.Var

var A_arbace_repr_clojure_A_const_170 any

var A_arbace_repr_clojure_A_const_171 *lang.Var

var A_arbace_repr_clojure_A_const_172 *lang.Var

var A_arbace_repr_clojure_A_const_173 *lang.Var

var A_arbace_repr_clojure_A_const_174 *lang.Var

var A_arbace_repr_clojure_A_const_175 *lang.Var

var A_arbace_repr_clojure_A_const_176 *lang.Keyword

var A_arbace_repr_clojure_A_const_177 *lang.Var

var A_arbace_repr_clojure_A_const_178 *lang.Var

var A_arbace_repr_clojure_A_const_179 *lang.Var

var A_arbace_repr_clojure_A_const_180 *lang.Var

var A_arbace_repr_clojure_A_const_181 any

var A_arbace_repr_clojure_A_const_182 *lang.Var

var A_arbace_repr_clojure_A_const_183 *lang.Var

var A_arbace_repr_clojure_A_const_184 *lang.Var

var A_arbace_repr_clojure_A_const_185 *lang.Var

var A_arbace_repr_clojure_A_const_186 *lang.Keyword

var A_arbace_repr_clojure_A_const_187 *lang.Var

var A_arbace_repr_clojure_A_const_188 *lang.Var

var A_arbace_repr_clojure_A_const_189 *lang.Var

var A_arbace_repr_clojure_A_const_190 *lang.Var

var A_arbace_repr_clojure_A_const_191 *lang.Keyword

var A_arbace_repr_clojure_A_init jrt.ClassInit

func A_arbace_repr_clojure_A_Init() { if !A_arbace_repr_clojure_A_init.Done() { A_arbace_repr_clojure_A_init.Run(A_arbace_repr_clojure_A_clinit) } }

func A_arbace_repr_clojure_A_clinit() { A_arbace_repr_clojure_A_clinit_p0(); A_arbace_repr_clojure_A_clinit_p1(); A_arbace_repr_clojure_A_clinit_p2(); A_arbace_repr_clojure_A_clinit_p3(); A_arbace_repr_clojure_A_clinit_p4(); A_arbace_repr_clojure_A_clinit_p5(); A_arbace_repr_clojure_A_clinit_p6(); A_arbace_repr_clojure_A_clinit_p7(); A_arbace_repr_clojure_A_clinit_p8(); A_arbace_repr_clojure_A_clinit_p9(); A_arbace_repr_clojure_A_clinit_p10(); A_arbace_repr_clojure_A_clinit_p11(); A_arbace_repr_clojure_A_clinit_p12(); A_arbace_repr_clojure_A_clinit_p13(); A_arbace_repr_clojure_A_clinit_p14(); A_arbace_repr_clojure_A_clinit_p15() }

func A_arbace_repr_clojure_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_clojure_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 255); A_arbace_repr_clojure_A_const_0 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[63]); A_arbace_repr_clojure_A_const_1 = A_arbace_repr_clojure_A_const_pool.A[64]; A_arbace_repr_clojure_A_const_2 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[65]); A_arbace_repr_clojure_A_const_3 = A_arbace_repr_clojure_A_const_pool.A[66]; A_arbace_repr_clojure_A_const_4 = A_arbace_repr_clojure_A_const_pool.A[67]; A_arbace_repr_clojure_A_const_5 = A_arbace_repr_clojure_A_const_pool.A[68]; A_arbace_repr_clojure_A_const_6 = A_arbace_repr_clojure_A_const_pool.A[69]; A_arbace_repr_clojure_A_const_7 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[70]); A_arbace_repr_clojure_A_const_8 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[71]); A_arbace_repr_clojure_A_const_9 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[72]); A_arbace_repr_clojure_A_const_10 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[73]); A_arbace_repr_clojure_A_const_11 = A_arbace_repr_clojure_A_const_pool.A[74] }

func A_arbace_repr_clojure_A_clinit_p1() { A_arbace_repr_clojure_A_const_12 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[75]); A_arbace_repr_clojure_A_const_13 = A_arbace_repr_clojure_A_const_pool.A[76]; A_arbace_repr_clojure_A_const_14 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[77]); A_arbace_repr_clojure_A_const_15 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[78]); A_arbace_repr_clojure_A_const_16 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[79]); A_arbace_repr_clojure_A_const_17 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[80]); A_arbace_repr_clojure_A_const_18 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[81]); A_arbace_repr_clojure_A_const_19 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[82]); A_arbace_repr_clojure_A_const_20 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[83]); A_arbace_repr_clojure_A_const_21 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[84]); A_arbace_repr_clojure_A_const_22 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[85]); A_arbace_repr_clojure_A_const_23 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[86]) }

func A_arbace_repr_clojure_A_clinit_p2() { A_arbace_repr_clojure_A_const_24 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[87]); A_arbace_repr_clojure_A_const_25 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[88]); A_arbace_repr_clojure_A_const_26 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[89]); A_arbace_repr_clojure_A_const_27 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[90]); A_arbace_repr_clojure_A_const_28 = A_arbace_repr_clojure_A_const_pool.A[91]; A_arbace_repr_clojure_A_const_29 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[92]); A_arbace_repr_clojure_A_const_30 = A_arbace_repr_clojure_A_const_pool.A[93]; A_arbace_repr_clojure_A_const_31 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[94]); A_arbace_repr_clojure_A_const_32 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[95]); A_arbace_repr_clojure_A_const_33 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[96]); A_arbace_repr_clojure_A_const_34 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[97]); A_arbace_repr_clojure_A_const_35 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[98]) }

func A_arbace_repr_clojure_A_clinit_p3() { A_arbace_repr_clojure_A_const_36 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[99]); A_arbace_repr_clojure_A_const_37 = A_arbace_repr_clojure_A_const_pool.A[100]; A_arbace_repr_clojure_A_const_38 = A_arbace_repr_clojure_A_const_pool.A[101]; A_arbace_repr_clojure_A_const_39 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[102]); A_arbace_repr_clojure_A_const_40 = A_arbace_repr_clojure_A_const_pool.A[103]; A_arbace_repr_clojure_A_const_41 = A_arbace_repr_clojure_A_const_pool.A[104]; A_arbace_repr_clojure_A_const_42 = A_arbace_repr_clojure_A_const_pool.A[105]; A_arbace_repr_clojure_A_const_43 = A_arbace_repr_clojure_A_const_pool.A[106]; A_arbace_repr_clojure_A_const_44 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[107]); A_arbace_repr_clojure_A_const_45 = A_arbace_repr_clojure_A_const_pool.A[108]; A_arbace_repr_clojure_A_const_46 = A_arbace_repr_clojure_A_const_pool.A[109]; A_arbace_repr_clojure_A_const_47 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[110]); A_arbace_repr_clojure_A_const_48 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[111]); A_arbace_repr_clojure_A_const_49 = A_arbace_repr_clojure_A_const_pool.A[112] }

func A_arbace_repr_clojure_A_clinit_p4() { A_arbace_repr_clojure_A_const_50 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[113]); A_arbace_repr_clojure_A_const_51 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[114]); A_arbace_repr_clojure_A_const_52 = A_arbace_repr_clojure_A_const_pool.A[115]; A_arbace_repr_clojure_A_const_53 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[116]); A_arbace_repr_clojure_A_const_54 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[117]); A_arbace_repr_clojure_A_const_55 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[118]); A_arbace_repr_clojure_A_const_56 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[119]); A_arbace_repr_clojure_A_const_57 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[120]); A_arbace_repr_clojure_A_const_58 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[121]); A_arbace_repr_clojure_A_const_59 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[122]); A_arbace_repr_clojure_A_const_60 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[123]); A_arbace_repr_clojure_A_const_61 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[124]) }

func A_arbace_repr_clojure_A_clinit_p5() { A_arbace_repr_clojure_A_const_62 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[125]); A_arbace_repr_clojure_A_const_63 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[126]); A_arbace_repr_clojure_A_const_64 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[127]); A_arbace_repr_clojure_A_const_65 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[128]); A_arbace_repr_clojure_A_const_66 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[129]); A_arbace_repr_clojure_A_const_67 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[130]); A_arbace_repr_clojure_A_const_68 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[131]); A_arbace_repr_clojure_A_const_69 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[132]); A_arbace_repr_clojure_A_const_70 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[133]); A_arbace_repr_clojure_A_const_71 = A_arbace_repr_clojure_A_const_pool.A[134]; A_arbace_repr_clojure_A_const_72 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[135]); A_arbace_repr_clojure_A_const_73 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[136]) }

func A_arbace_repr_clojure_A_clinit_p6() { A_arbace_repr_clojure_A_const_74 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[137]); A_arbace_repr_clojure_A_const_75 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[138]); A_arbace_repr_clojure_A_const_76 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[139]); A_arbace_repr_clojure_A_const_77 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[140]); A_arbace_repr_clojure_A_const_78 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[141]); A_arbace_repr_clojure_A_const_79 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[142]); A_arbace_repr_clojure_A_const_80 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[143]); A_arbace_repr_clojure_A_const_81 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[144]); A_arbace_repr_clojure_A_const_82 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[145]); A_arbace_repr_clojure_A_const_83 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[146]); A_arbace_repr_clojure_A_const_84 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[147]); A_arbace_repr_clojure_A_const_85 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[148]) }

func A_arbace_repr_clojure_A_clinit_p7() { A_arbace_repr_clojure_A_const_86 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[149]); A_arbace_repr_clojure_A_const_87 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[150]); A_arbace_repr_clojure_A_const_88 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[151]); A_arbace_repr_clojure_A_const_89 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[152]); A_arbace_repr_clojure_A_const_90 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[153]); A_arbace_repr_clojure_A_const_91 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[154]); A_arbace_repr_clojure_A_const_92 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[155]); A_arbace_repr_clojure_A_const_93 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[156]); A_arbace_repr_clojure_A_const_94 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[157]); A_arbace_repr_clojure_A_const_95 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[158]); A_arbace_repr_clojure_A_const_96 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[159]); A_arbace_repr_clojure_A_const_97 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[160]) }

func A_arbace_repr_clojure_A_clinit_p8() { A_arbace_repr_clojure_A_const_98 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[161]); A_arbace_repr_clojure_A_const_99 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[162]); A_arbace_repr_clojure_A_const_100 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[163]); A_arbace_repr_clojure_A_const_101 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[164]); A_arbace_repr_clojure_A_const_102 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[165]); A_arbace_repr_clojure_A_const_103 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[166]); A_arbace_repr_clojure_A_const_104 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[167]); A_arbace_repr_clojure_A_const_105 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[168]); A_arbace_repr_clojure_A_const_106 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[169]); A_arbace_repr_clojure_A_const_107 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[170]); A_arbace_repr_clojure_A_const_108 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[171]); A_arbace_repr_clojure_A_const_109 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[172]) }

func A_arbace_repr_clojure_A_clinit_p9() { A_arbace_repr_clojure_A_const_110 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[173]); A_arbace_repr_clojure_A_const_111 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[174]); A_arbace_repr_clojure_A_const_112 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[175]); A_arbace_repr_clojure_A_const_113 = A_arbace_repr_clojure_A_const_pool.A[176]; A_arbace_repr_clojure_A_const_114 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[177]); A_arbace_repr_clojure_A_const_115 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[178]); A_arbace_repr_clojure_A_const_116 = A_arbace_repr_clojure_A_const_pool.A[179]; A_arbace_repr_clojure_A_const_117 = A_arbace_repr_clojure_A_const_pool.A[180]; A_arbace_repr_clojure_A_const_118 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[181]); A_arbace_repr_clojure_A_const_119 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[182]); A_arbace_repr_clojure_A_const_120 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[183]); A_arbace_repr_clojure_A_const_121 = A_arbace_repr_clojure_A_const_pool.A[184]; A_arbace_repr_clojure_A_const_122 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[185]) }

func A_arbace_repr_clojure_A_clinit_p10() { A_arbace_repr_clojure_A_const_123 = A_arbace_repr_clojure_A_const_pool.A[186]; A_arbace_repr_clojure_A_const_124 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[187]); A_arbace_repr_clojure_A_const_125 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[188]); A_arbace_repr_clojure_A_const_126 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[189]); A_arbace_repr_clojure_A_const_127 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[190]); A_arbace_repr_clojure_A_const_128 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[191]); A_arbace_repr_clojure_A_const_129 = A_arbace_repr_clojure_A_const_pool.A[192]; A_arbace_repr_clojure_A_const_130 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[193]); A_arbace_repr_clojure_A_const_131 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[194]); A_arbace_repr_clojure_A_const_132 = A_arbace_repr_clojure_A_const_pool.A[195]; A_arbace_repr_clojure_A_const_133 = A_arbace_repr_clojure_A_const_pool.A[196]; A_arbace_repr_clojure_A_const_134 = A_arbace_repr_clojure_A_const_pool.A[197]; A_arbace_repr_clojure_A_const_135 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[198]) }

func A_arbace_repr_clojure_A_clinit_p11() { A_arbace_repr_clojure_A_const_136 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[199]); A_arbace_repr_clojure_A_const_137 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[200]); A_arbace_repr_clojure_A_const_138 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[201]); A_arbace_repr_clojure_A_const_139 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[202]); A_arbace_repr_clojure_A_const_140 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[203]); A_arbace_repr_clojure_A_const_141 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[204]); A_arbace_repr_clojure_A_const_142 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[205]); A_arbace_repr_clojure_A_const_143 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[206]); A_arbace_repr_clojure_A_const_144 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[207]); A_arbace_repr_clojure_A_const_145 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[208]); A_arbace_repr_clojure_A_const_146 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[209]); A_arbace_repr_clojure_A_const_147 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[210]) }

func A_arbace_repr_clojure_A_clinit_p12() { A_arbace_repr_clojure_A_const_148 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[211]); A_arbace_repr_clojure_A_const_149 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[212]); A_arbace_repr_clojure_A_const_150 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[213]); A_arbace_repr_clojure_A_const_151 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[214]); A_arbace_repr_clojure_A_const_152 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[215]); A_arbace_repr_clojure_A_const_153 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[216]); A_arbace_repr_clojure_A_const_154 = A_arbace_repr_clojure_A_const_pool.A[217]; A_arbace_repr_clojure_A_const_155 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[218]); A_arbace_repr_clojure_A_const_156 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[219]); A_arbace_repr_clojure_A_const_157 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[220]); A_arbace_repr_clojure_A_const_158 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[221]); A_arbace_repr_clojure_A_const_159 = A_arbace_repr_clojure_A_const_pool.A[222] }

func A_arbace_repr_clojure_A_clinit_p13() { A_arbace_repr_clojure_A_const_160 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[223]); A_arbace_repr_clojure_A_const_161 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[224]); A_arbace_repr_clojure_A_const_162 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[225]); A_arbace_repr_clojure_A_const_163 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[226]); A_arbace_repr_clojure_A_const_164 = A_arbace_repr_clojure_A_const_pool.A[227]; A_arbace_repr_clojure_A_const_165 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[228]); A_arbace_repr_clojure_A_const_166 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[229]); A_arbace_repr_clojure_A_const_167 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[230]); A_arbace_repr_clojure_A_const_168 = A_arbace_repr_clojure_A_const_pool.A[231]; A_arbace_repr_clojure_A_const_169 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[232]); A_arbace_repr_clojure_A_const_170 = A_arbace_repr_clojure_A_const_pool.A[233]; A_arbace_repr_clojure_A_const_171 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[234]) }

func A_arbace_repr_clojure_A_clinit_p14() { A_arbace_repr_clojure_A_const_172 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[235]); A_arbace_repr_clojure_A_const_173 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[236]); A_arbace_repr_clojure_A_const_174 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[237]); A_arbace_repr_clojure_A_const_175 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[238]); A_arbace_repr_clojure_A_const_176 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[239]); A_arbace_repr_clojure_A_const_177 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[240]); A_arbace_repr_clojure_A_const_178 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[241]); A_arbace_repr_clojure_A_const_179 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[242]); A_arbace_repr_clojure_A_const_180 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[243]); A_arbace_repr_clojure_A_const_181 = A_arbace_repr_clojure_A_const_pool.A[244]; A_arbace_repr_clojure_A_const_182 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[245]); A_arbace_repr_clojure_A_const_183 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[246]) }

func A_arbace_repr_clojure_A_clinit_p15() { A_arbace_repr_clojure_A_const_184 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[247]); A_arbace_repr_clojure_A_const_185 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[248]); A_arbace_repr_clojure_A_const_186 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[249]); A_arbace_repr_clojure_A_const_187 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[250]); A_arbace_repr_clojure_A_const_188 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[251]); A_arbace_repr_clojure_A_const_189 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[252]); A_arbace_repr_clojure_A_const_190 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[253]); A_arbace_repr_clojure_A_const_191 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[254]) }

func A_arbace_repr_clojure_A_New() *A_arbace_repr_clojure_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_A) Ctor() {}

func (t *A_arbace_repr_clojure_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_A_class }

func (t *A_arbace_repr_clojure_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_A); return ok }

func A_arbace_repr_clojure_A_Cast(x any) *A_arbace_repr_clojure_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_A_class)) }; return v }



type A_arbace_repr_clojure__main_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure__main_A_fn_class *jrt.Class



type A_arbace_repr_clojure__main_fn__716000313_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure__main_fn__716000313_A_fn_class *jrt.Class



type A_arbace_repr_clojure__main_fn__716000315_A struct{ j2g_header uint64; F_s, F_verb any }

var A_arbace_repr_clojure__main_fn__716000315_A_fn_class *jrt.Class



type A_arbace_repr_clojure_base_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_base_A_fn_class *jrt.Class



type A_arbace_repr_clojure_eval716000004_A struct{ jrt.Object }

func A_arbace_repr_clojure_eval716000004_A_New() *A_arbace_repr_clojure_eval716000004_A { t := &A_arbace_repr_clojure_eval716000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_eval716000004_A) Ctor() {}

func (t *A_arbace_repr_clojure_eval716000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_eval716000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_eval716000004_A_class }

func (t *A_arbace_repr_clojure_eval716000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_eval716000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_eval716000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_eval716000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_eval716000004_A); return ok }

func A_arbace_repr_clojure_eval716000004_A_Cast(x any) *A_arbace_repr_clojure_eval716000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_eval716000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_eval716000004_A_class)) }; return v }



type A_arbace_repr_clojure_eval716000004_loading__1927001464__auto____716000005_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_eval716000004_loading__1927001464__auto____716000005_A_fn_class *jrt.Class



type A_arbace_repr_clojure_eval716000008_A struct{ jrt.Object }

func A_arbace_repr_clojure_eval716000008_A_New() *A_arbace_repr_clojure_eval716000008_A { t := &A_arbace_repr_clojure_eval716000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_eval716000008_A) Ctor() {}

func (t *A_arbace_repr_clojure_eval716000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_eval716000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_eval716000008_A_class }

func (t *A_arbace_repr_clojure_eval716000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_eval716000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_eval716000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_eval716000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_eval716000008_A); return ok }

func A_arbace_repr_clojure_eval716000008_A_Cast(x any) *A_arbace_repr_clojure_eval716000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_eval716000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_eval716000008_A_class)) }; return v }



type A_arbace_repr_clojure_eval716000008_fn__716000009_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_eval716000008_fn__716000009_A_fn_class *jrt.Class



type A_arbace_repr_clojure_ext_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_ext_A_fn_class *jrt.Class



type A_arbace_repr_clojure_files_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_files_A_fn_class *jrt.Class



type A_arbace_repr_clojure_files_iter__716000030__716000034_A struct{ j2g_header uint64; F_root, F_src any }

var A_arbace_repr_clojure_files_iter__716000030__716000034_A_fn_class *jrt.Class



type A_arbace_repr_clojure_files_iter__716000030__716000034_fn__716000035_A struct{ j2g_header uint64; F_root, F_iter__716000030, F_src, F_s__716000031 any }

var A_arbace_repr_clojure_files_iter__716000030__716000034_fn__716000035_A_fn_class *jrt.Class



type A_arbace_repr_clojure_files_iter__716000030__716000034_fn__716000035_fn__716000036_A struct{ j2g_header uint64; F_root, F_src, F_b__716000033 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_clojure_files_iter__716000030__716000034_fn__716000035_fn__716000036_A_fn_class *jrt.Class



type A_arbace_repr_clojure_first_difference_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_first_difference_A_fn_class *jrt.Class



type A_arbace_repr_clojure_first_difference_fn__716000140_A struct{ j2g_header uint64; F_a, F_b any; F_n int64 }

var A_arbace_repr_clojure_first_difference_fn__716000140_A_fn_class *jrt.Class



type A_arbace_repr_clojure_first_difference_fn__716000142_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_first_difference_fn__716000142_A_fn_class *jrt.Class



type A_arbace_repr_clojure_first_difference_ln__716000144_A struct{ j2g_header uint64; F_i any }

var A_arbace_repr_clojure_first_difference_ln__716000144_A_fn_class *jrt.Class



type A_arbace_repr_clojure_half_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_half_A_fn_class *jrt.Class



type A_arbace_repr_clojure_half_fn__716000122_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_half_fn__716000122_A_fn_class *jrt.Class



type A_arbace_repr_clojure_half_fn__716000125_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_half_fn__716000125_A_fn_class *jrt.Class



type A_arbace_repr_clojure_half_fn__716000131_A struct{ j2g_header uint64; F_plan, F_translate_text, F_opts, F_dirs any }

var A_arbace_repr_clojure_half_fn__716000131_A_fn_class *jrt.Class



type A_arbace_repr_clojure_half_fn__716000131_fn__716000135_A struct{ j2g_header uint64; F_p, F_x, F_rel, F_translate_text, F_opts any }

var A_arbace_repr_clojure_half_fn__716000131_fn__716000135_A_fn_class *jrt.Class



type A_arbace_repr_clojure_name_of_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_name_of_A_fn_class *jrt.Class



type A_arbace_repr_clojure_parent_of_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_parent_of_A_fn_class *jrt.Class



type A_arbace_repr_clojure_parse_args_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_parse_args_A_fn_class *jrt.Class



type A_arbace_repr_clojure_plan_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_plan_A_fn_class *jrt.Class



type A_arbace_repr_clojure_plan_fn__716000018_A struct{ j2g_header uint64; F_name any }

var A_arbace_repr_clojure_plan_fn__716000018_A_fn_class *jrt.Class



type A_arbace_repr_clojure_print_plan_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_print_plan_A_fn_class *jrt.Class



type A_arbace_repr_clojure_print_plan_fn__716000025_A struct{ j2g_header uint64; F_name any }

var A_arbace_repr_clojure_print_plan_fn__716000025_A_fn_class *jrt.Class



type A_arbace_repr_clojure_print_rules_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_print_rules_A_fn_class *jrt.Class



type A_arbace_repr_clojure_print_text_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_print_text_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_roundtrip_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000150__716000154_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_roundtrip_iter__716000150__716000154_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000150__716000154_fn__716000155_A struct{ j2g_header uint64; F_iter__716000150, F_s__716000151 any }

var A_arbace_repr_clojure_roundtrip_iter__716000150__716000154_fn__716000155_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000150__716000154_fn__716000155_fn__716000156_A struct{ j2g_header uint64; F_b__716000153 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_clojure_roundtrip_iter__716000150__716000154_fn__716000155_fn__716000156_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000166__716000170_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_roundtrip_iter__716000166__716000170_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000166__716000170_fn__716000171_A struct{ j2g_header uint64; F_iter__716000166, F_s__716000167 any }

var A_arbace_repr_clojure_roundtrip_iter__716000166__716000170_fn__716000171_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000166__716000170_fn__716000171_fn__716000172_A struct{ j2g_header uint64; F_b__716000169 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_clojure_roundtrip_iter__716000166__716000170_fn__716000171_fn__716000172_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000182__716000186_A struct{ j2g_header uint64; F_back2, F_t, F_a, F_b, F_c, F_back, F_opts any }

var A_arbace_repr_clojure_roundtrip_iter__716000182__716000186_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000182__716000186_fn__716000187_A struct{ j2g_header uint64; F_back2, F_s__716000183, F_t, F_a, F_b, F_c, F_back, F_opts, F_iter__716000182 any }

var A_arbace_repr_clojure_roundtrip_iter__716000182__716000186_fn__716000187_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000182__716000186_fn__716000187_fn__716000188_A struct{ j2g_header uint64; F_back2, F_t, F_b__716000185, F_a, F_b, F_c any; F_size__1927001038__auto__ int32; F_back, F_opts, F_c__1927001037__auto__ any }

var A_arbace_repr_clojure_roundtrip_iter__716000182__716000186_fn__716000187_fn__716000188_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000198__716000202_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_roundtrip_iter__716000198__716000202_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000198__716000202_fn__716000203_A struct{ j2g_header uint64; F_iter__716000198, F_s__716000199 any }

var A_arbace_repr_clojure_roundtrip_iter__716000198__716000202_fn__716000203_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000198__716000202_fn__716000203_fn__716000204_A struct{ j2g_header uint64; F_b__716000201 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_clojure_roundtrip_iter__716000198__716000202_fn__716000203_fn__716000204_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000214__716000218_A struct{ j2g_header uint64; F_a any }

var A_arbace_repr_clojure_roundtrip_iter__716000214__716000218_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000214__716000218_fn__716000219_A struct{ j2g_header uint64; F_iter__716000214, F_s__716000215, F_a any }

var A_arbace_repr_clojure_roundtrip_iter__716000214__716000218_fn__716000219_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000214__716000218_fn__716000219_fn__716000220_A struct{ j2g_header uint64; F_a, F_b__716000217 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_clojure_roundtrip_iter__716000214__716000218_fn__716000219_fn__716000220_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrips_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_roundtrips_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrips_fn__716000254_A struct{ j2g_header uint64; F_opts any }

var A_arbace_repr_clojure_roundtrips_fn__716000254_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrips_fn__716000254_iter__716000255__716000259_A struct{ j2g_header uint64; F_n any }

var A_arbace_repr_clojure_roundtrips_fn__716000254_iter__716000255__716000259_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrips_fn__716000254_iter__716000255__716000259_fn__716000260_A struct{ j2g_header uint64; F_iter__716000255, F_n, F_s__716000256 any }

var A_arbace_repr_clojure_roundtrips_fn__716000254_iter__716000255__716000259_fn__716000260_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrips_fn__716000254_iter__716000255__716000259_fn__716000260_fn__716000261_A struct{ j2g_header uint64; F_n, F_b__716000258 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_clojure_roundtrips_fn__716000254_iter__716000255__716000259_fn__716000260_fn__716000261_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_run_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000043_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_run_fn__716000043_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000060_A struct{ j2g_header uint64; F_f, F_p any }

var A_arbace_repr_clojure_run_fn__716000060_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000062_A struct{ j2g_header uint64; F_f, F_stats, F_p, F_s, F_translate_text, F_skip any }

var A_arbace_repr_clojure_run_fn__716000062_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000062_fn__716000063_A struct{ j2g_header uint64; F_e, F_f any }

var A_arbace_repr_clojure_run_fn__716000062_fn__716000063_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000069_A struct{ j2g_header uint64; F_f, F_p any }

var A_arbace_repr_clojure_run_fn__716000069_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000071_A struct{ j2g_header uint64; F_f, F_p, F_s, F_stats, F_translate_text, F_skip any }

var A_arbace_repr_clojure_run_fn__716000071_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000071_fn__716000072_A struct{ j2g_header uint64; F_e, F_f any }

var A_arbace_repr_clojure_run_fn__716000071_fn__716000072_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000078_A struct{ j2g_header uint64; F_f, F_p any }

var A_arbace_repr_clojure_run_fn__716000078_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000080_A struct{ j2g_header uint64; F_f, F_p, F_s, F_stats, F_translate_text, F_skip any }

var A_arbace_repr_clojure_run_fn__716000080_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000080_fn__716000081_A struct{ j2g_header uint64; F_e, F_f any }

var A_arbace_repr_clojure_run_fn__716000080_fn__716000081_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000087_A struct{ j2g_header uint64; F_f, F_p any }

var A_arbace_repr_clojure_run_fn__716000087_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000089_A struct{ j2g_header uint64; F_f, F_p, F_s, F_stats, F_translate_text, F_skip any }

var A_arbace_repr_clojure_run_fn__716000089_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000089_fn__716000090_A struct{ j2g_header uint64; F_e, F_f any }

var A_arbace_repr_clojure_run_fn__716000089_fn__716000090_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_roundtrip_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_run_roundtrip_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_roundtrip_fn__716000277_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_run_roundtrip_fn__716000277_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_roundtrip_fn__716000279_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_run_roundtrip_fn__716000279_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_roundtrip_fn__716000281_A struct{ j2g_header uint64; F_known any }

var A_arbace_repr_clojure_run_roundtrip_fn__716000281_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_roundtrip_fn__716000283_A struct{ j2g_header uint64; F_diff any }

var A_arbace_repr_clojure_run_roundtrip_fn__716000283_A_fn_class *jrt.Class



type A_arbace_repr_clojure_translate_text_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_translate_text_A_fn_class *jrt.Class



type A_arbace_repr_clojure_tree_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_tree_A_fn_class *jrt.Class



type A_arbace_repr_clojure_tree_iter__716000094__716000100_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_tree_iter__716000094__716000100_A_fn_class *jrt.Class



type A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_A struct{ j2g_header uint64; F_s__716000095, F_iter__716000094 any }

var A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_A_fn_class *jrt.Class



type A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_iter__716000096__716000102_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_iter__716000096__716000102_A_fn_class *jrt.Class



type A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_iter__716000096__716000102_fn__716000103_A struct{ j2g_header uint64; F_iter__716000096, F_s__716000097 any }

var A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_iter__716000096__716000102_fn__716000103_A_fn_class *jrt.Class



type A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_iter__716000096__716000102_fn__716000103_fn__716000104_A struct{ j2g_header uint64; F_b__716000099 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_clojure_tree_iter__716000094__716000100_fn__716000101_iter__716000096__716000102_fn__716000103_fn__716000104_A_fn_class *jrt.Class



type A_arbace_repr_clojure_under_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_under_A_fn_class *jrt.Class



type A_arbace_repr_clojure_usage_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_usage_A_fn_class *jrt.Class



type A_arbace_repr_clojure_usage_fn__716000251_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_usage_fn__716000251_A_fn_class *jrt.Class
