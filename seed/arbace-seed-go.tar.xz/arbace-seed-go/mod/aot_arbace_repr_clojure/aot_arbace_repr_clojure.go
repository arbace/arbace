//line aot_arbace_repr_clojure.ae:1
package aot_arbace_repr_clojure

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_clojure_eval716000004_loading__1927001464__auto____716000005_A_New() *A_arbace_repr_clojure_eval716000004_loading__1927001464__auto____716000005_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_eval716000004_loading__1927001464__auto____716000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_clojure_eval716000004_loading__1927001464__auto____716000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_clojure_eval716000004_loading__1927001464__auto____716000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_clojure_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_A_const_2); lang.IFn_Cast(A_arbace_repr_clojure_A_const_1.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_clojure_A_const_3, A_arbace_repr_clojure_A_const_4, A_arbace_repr_clojure_A_const_5); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_repr_clojure_eval716000008_fn__716000009_A_New() *A_arbace_repr_clojure_eval716000008_fn__716000009_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_eval716000008_fn__716000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_clojure_eval716000008_fn__716000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_clojure_eval716000008_fn__716000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_repr_clojure_A_const_6.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_clojure_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_A_const_10), A_arbace_repr_clojure_A_const_8.GetRawRoot__O(), A_arbace_repr_clojure_A_const_9) }





































func A_arbace_repr_clojure_ext_A_New() *A_arbace_repr_clojure_ext_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_ext_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_repr_clojure_ext_A) Ctor() {}
//line :39:1
func (t *A_arbace_repr_clojure_ext_A) Invoke_O_O__O(self, name__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(name__0)).LastIndexOf_String__I(Lit_11); if
										lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return Lit_13 } else { return lang.IFn_Cast(A_arbace_repr_clojure_A_const_11.GetRawRoot__O()).Invoke_O_O__O(name__0, jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref()) } }

func A_arbace_repr_clojure_base_A_New() *A_arbace_repr_clojure_base_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_base_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_repr_clojure_base_A) Ctor() {}
//line :42:1
func (t *A_arbace_repr_clojure_base_A) Invoke_O_O__O(self, name__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(name__0)).LastIndexOf_String__I(Lit_11); if
										lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return name__0 } else { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_11.GetRawRoot__O()); var tmp2 any = A_arbace_repr_clojure_A_const_12; return tmp1.Invoke_O_O_O__O(name__0, tmp2, jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref()) } }

func A_arbace_repr_clojure_plan_A_New() *A_arbace_repr_clojure_plan_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_plan_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_repr_clojure_plan_A) Ctor() {}
//line :45:1
func (t *A_arbace_repr_clojure_plan_A) Invoke_O_O_O_O__O(self, name__0, siblings__1, p__716000015__2 any) any { var map__716000016__4 any = p__716000015__2; var map__716000016__5 any; if lang.ISeq_InstanceOf(map__716000016__4) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_A_const_13.GetRawRoot__O()).Invoke_O__O(map__716000016__4)) { map__716000016__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_repr_clojure_A_const_14.GetRawRoot__O()).Invoke_O__O(map__716000016__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_A_const_15.GetRawRoot__O()).Invoke_O__O(map__716000016__4)) { map__716000016__5 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_16.GetRawRoot__O()).Invoke_O__O(map__716000016__4) } else { map__716000016__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__716000016__5 = map__716000016__4 }; var keep_ext__6 any = lang.RT_Get_O_O__O_NoInit(map__716000016__5, A_arbace_repr_clojure_A_const_17); var text__7 any = lang.RT_Get_O_O__O_NoInit(map__716000016__5, A_arbace_repr_clojure_A_const_18); var e__8 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_19.GetRawRoot__O()).Invoke_O__O(name__0); if





	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_A_const_20.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_clojure_A_const_35.GetRawRoot__O(), name__0)) { var tmp1 any = A_arbace_repr_clojure_A_const_21; var tmp2 *lang.Keyword
		if lang.Util_Equiv_O_O__Z_NoInit(e__8, Lit_29) { tmp2 = A_arbace_repr_clojure_A_const_22 } else { tmp2 = A_arbace_repr_clojure_A_const_23 }
//line :51:1
		return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2.Ref(), A_arbace_repr_clojure_A_const_24, jrt.Boolean_FALSE.Ref(), A_arbace_repr_clojure_A_const_25, name__0)) } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_A_const_26).Invoke_O__O(e__8)) {


			if jrt.J2g_Truth(keep_ext__6) { var tmp3 any = A_arbace_repr_clojure_A_const_21; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, lang.IFn_Cast(A_arbace_repr_clojure_A_const_27.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_A_const_11.GetRawRoot__O()).Invoke_O_O__O(e__8, A_arbace_repr_clojure_A_const_36)), A_arbace_repr_clojure_A_const_24, jrt.Boolean_FALSE.Ref(), A_arbace_repr_clojure_A_const_25, name__0)) } else { if lang.Util_Equiv_O_O__Z_NoInit(Lit_30, lang.IFn_Cast(A_arbace_repr_clojure_A_const_28.GetRawRoot__O()).Invoke_O__O(name__0)) {




				var tmp4 any; var or__1927000174__auto____9 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_20.GetRawRoot__O()).Invoke_O_O__O(siblings__1, Lit_31); if jrt.J2g_Truth(or__1927000174__auto____9) { tmp4 = or__1927000174__auto____9 } else { var and__1927000168__auto____10 bool = lang.Util_Equiv_O_O__Z_NoInit(e__8, Lit_29)
					if and__1927000168__auto____10 { tmp4 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_20.GetRawRoot__O()).Invoke_O_O__O(siblings__1, Lit_32) } else { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10).Ref() } }
//line :59:1
				if jrt.J2g_Truth(tmp4) { var tmp5 any = A_arbace_repr_clojure_A_const_21; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, lang.IFn_Cast(A_arbace_repr_clojure_A_const_27.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_A_const_11.GetRawRoot__O()).Invoke_O_O__O(e__8, A_arbace_repr_clojure_A_const_36)), A_arbace_repr_clojure_A_const_24, jrt.Boolean_FALSE.Ref(), A_arbace_repr_clojure_A_const_25, name__0)) } else { var tmp6 any = A_arbace_repr_clojure_A_const_21; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, lang.IFn_Cast(A_arbace_repr_clojure_A_const_27.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_A_const_11.GetRawRoot__O()).Invoke_O_O__O(e__8, A_arbace_repr_clojure_A_const_36)), A_arbace_repr_clojure_A_const_24, jrt.Boolean_TRUE.Ref(), A_arbace_repr_clojure_A_const_25, Lit_31)) } } else {
//line :54:1
					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_A_const_20.GetRawRoot__O()).Invoke_O_O__O(siblings__1, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_33), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_repr_clojure_A_const_28.GetRawRoot__O()).Invoke_O__O(name__0), nil)).Ref())) { var tmp7 any = A_arbace_repr_clojure_A_const_29; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_34), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_repr_clojure_A_const_28.GetRawRoot__O()).Invoke_O__O(name__0), nil)).Ref())) } else { var tmp8 any; var and__1927000168__auto____9 bool = lang.Util_Equiv_O_O__Z_NoInit(e__8, Lit_29)










						if and__1927000168__auto____9 { tmp8 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_20.GetRawRoot__O()).Invoke_O_O__O(siblings__1, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_35), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_repr_clojure_A_const_28.GetRawRoot__O()).Invoke_O__O(name__0), nil)).Ref()) } else { tmp8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____9).Ref() }
//line :54:1
						if jrt.J2g_Truth(tmp8) { var tmp9 any = A_arbace_repr_clojure_A_const_29; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_36), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_repr_clojure_A_const_28.GetRawRoot__O()).Invoke_O__O(name__0), nil)).Ref())) } else { if A_arbace_repr_clojure_A_const_30 != nil { var tmp10 any = A_arbace_repr_clojure_A_const_21; var tmp11 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_27.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_A_const_11.GetRawRoot__O()).Invoke_O_O__O(e__8, A_arbace_repr_clojure_A_const_36)); var tmp12 any = A_arbace_repr_clojure_A_const_24; var tmp13 any = jrt.Boolean_TRUE.Ref(); var tmp14 any = A_arbace_repr_clojure_A_const_25; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp11, tmp12, tmp13, tmp14, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_33), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_repr_clojure_A_const_28.GetRawRoot__O()).Invoke_O__O(name__0), nil)).Ref())) } else { return nil } } } } } } else {
//line :51:1
							if lang.Util_Equiv_O_O__Z_NoInit(e__8, Lit_37) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_21, A_arbace_repr_clojure_A_const_31, A_arbace_repr_clojure_A_const_24, jrt.Boolean_FALSE.Ref(), A_arbace_repr_clojure_A_const_25, name__0)) } else { var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_32.GetRawRoot__O()); var tmp16 any = A_arbace_repr_clojure_plan_fn__716000018_A_New_O(name__0); var tmp17 *jrt.Class
								var fncls__1 /*line :51:1*/*jrt.Class = A_arbace_repr_clojure_plan_fn__716000018_A_fn_class

















								if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_repr_clojure_plan_fn__716000018_A_fn_class = fncls__1d; tmp17 = fncls__1d } else { tmp17 = fncls__1 }
//line :51:1
								if jrt.J2g_Truth(tmp15.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil), text__7)) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_21, A_arbace_repr_clojure_A_const_18, A_arbace_repr_clojure_A_const_24, jrt.Boolean_FALSE.Ref(), A_arbace_repr_clojure_A_const_25, name__0)) } else { if lang.Util_Equiv_O_O__Z_NoInit(e__8, Lit_39) { return A_arbace_repr_clojure_A_const_33 } else { if A_arbace_repr_clojure_A_const_30 != nil { return A_arbace_repr_clojure_A_const_34 } else { return nil } } } } } } }

















func A_arbace_repr_clojure_plan_fn__716000018_A_New_O(p0 any) *A_arbace_repr_clojure_plan_fn__716000018_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_plan_fn__716000018_A{}; t.Ctor_O(p0); return t }
//line :69:1
func (t *A_arbace_repr_clojure_plan_fn__716000018_A) Ctor_O(c__name any) { t.F_name = c__name }
//line :69:1
func (t *A_arbace_repr_clojure_plan_fn__716000018_A) Invoke_O_O__O(self, p1__716000014_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_repr_clojure_A_const_37.GetRawRoot__O()).Invoke_O_O__O(t.F_name, p1__716000014_SHARP___1) }



func A_arbace_repr_clojure_translate_text_A_New() *A_arbace_repr_clojure_translate_text_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_translate_text_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_repr_clojure_translate_text_A) Ctor() {}
//line :73:1
func (t *A_arbace_repr_clojure_translate_text_A) Invoke_O_O_O_O_O__O(self, s__0, p__1, path__2, skip__3 any) any {


	var tmp1 any = A_arbace_repr_clojure_A_const_21; var tmp2 any = A_arbace_repr_clojure_A_const_21.Invoke_O__O(p__1); var tmp3 any = A_arbace_repr_clojure_A_const_24; return lang.IFn_Cast(A_arbace_repr_clojure_A_const_38.GetRawRoot__O()).Invoke_O_O_O__O(s__0, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, A_arbace_repr_clojure_A_const_24.Invoke_O__O(p__1), A_arbace_repr_clojure_A_const_39, A_arbace_repr_clojure_A_const_40, A_arbace_repr_clojure_A_const_41, path__2)), skip__3)
}
func A_arbace_repr_clojure_files_A_New() *A_arbace_repr_clojure_files_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_files_A{}; t.Ctor(); return t }
//line :78:1
func (t *A_arbace_repr_clojure_files_A) Ctor() {}
//line :78:1
func (t *A_arbace_repr_clojure_files_A) Invoke_O_O__O(self, src__0 any) any {


	if jrt.NN(jrt.File_Cast(src__0)).IsDirectory__Z() { var root__2 any = jrt.NN(jrt.File_Cast(src__0)).ToPath__Path(); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_repr_clojure_A_const_43.GetRawRoot__O(); var tmp3 any; var iter__1927001039__auto____3 any; var tmp4 any = A_arbace_repr_clojure_files_iter__716000022__716000026_A_New_O_O(root__2, src__0); var tmp5 *jrt.Class
		var fncls__4 /*line :81:1*/*jrt.Class = A_arbace_repr_clojure_files_iter__716000022__716000026_A_fn_class


		if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_repr_clojure_files_iter__716000022__716000026_A_fn_class = fncls__4d; tmp5 = fncls__4d } else { tmp5 = fncls__4 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); tmp3 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_A_const_54.GetRawRoot__O()).Invoke_O__O(src__0))
//line :83:1
		return tmp1.Invoke_O_O__O(tmp2, tmp3) } else {
//line :81:1
			var tmp6 any; var or__1927000174__auto____2 any = jrt.NN(jrt.NN(jrt.File_Cast(src__0)).GetAbsoluteFile__File()).GetParentFile__File().Ref()




			if jrt.J2g_Truth(or__1927000174__auto____2) { tmp6 = or__1927000174__auto____2 } else { tmp6 = jrt.File_New_String(Lit_11) }
//line :81:1
			return lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(tmp6, jrt.NN(jrt.File_Cast(src__0)).GetName__String().Ref()))
		}
}
func A_arbace_repr_clojure_files_iter__716000022__716000026_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_files_iter__716000022__716000026_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_files_iter__716000022__716000026_A{}; t.Ctor_O_O(p0, p1); return t }
//line :84:1
func (t *A_arbace_repr_clojure_files_iter__716000022__716000026_A) Ctor_O_O(c__root, c__src any) { t.F_root = c__root; t.F_src = c__src }
//line :84:1
func (t *A_arbace_repr_clojure_files_iter__716000022__716000026_A) Invoke_O_O__O(self, s__716000023__1 any) any { var tmp1 any = A_arbace_repr_clojure_files_iter__716000022__716000026_fn__716000027_A_New_O_O_O_O(t.F_root, t.F_src, self, s__716000023__1); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_repr_clojure_files_iter__716000022__716000026_fn__716000027_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_repr_clojure_files_iter__716000022__716000026_fn__716000027_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :84:1
func A_arbace_repr_clojure_files_iter__716000022__716000026_fn__716000027_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_repr_clojure_files_iter__716000022__716000026_fn__716000027_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_files_iter__716000022__716000026_fn__716000027_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :84:1
func (t *A_arbace_repr_clojure_files_iter__716000022__716000026_fn__716000027_A) Ctor_O_O_O_O(c__root, c__src, c__iter__716000022, c__s__716000023 any) { t.F_root = c__root; t.F_src = c__src; t.F_iter__716000022 = c__iter__716000022; t.F_s__716000023 = c__s__716000023 }
//line :84:1
func (t *A_arbace_repr_clojure_files_iter__716000022__716000026_fn__716000027_A) Invoke_O__O(self any) any { { var s__716000023__1 any; var t_ any = t.F_s__716000023; t.F_s__716000023 = nil; s__716000023__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_15.GetRawRoot__O()).Invoke_O__O(s__716000023__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__716000023__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_A_const_44.GetRawRoot__O()).Invoke_O__O(s__716000023__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_45.GetRawRoot__O()).Invoke_O__O(s__716000023__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__716000025__6 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_46.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_repr_clojure_files_iter__716000022__716000026_fn__716000027_fn__716000028_A_New_O_O_O_I_O(t.F_root, t.F_src, b__716000025__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_repr_clojure_files_iter__716000022__716000026_fn__716000027_fn__716000028_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_repr_clojure_files_iter__716000022__716000026_fn__716000027_fn__716000028_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__716000022); return lang.IFn_Cast(A_arbace_repr_clojure_A_const_49.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_clojure_A_const_51.GetRawRoot__O()).Invoke_O__O(b__716000025__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_A_const_52.GetRawRoot__O()).Invoke_O__O(s__716000023__3))) } else { return lang.IFn_Cast(A_arbace_repr_clojure_A_const_49.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_clojure_A_const_51.GetRawRoot__O()).Invoke_O__O(b__716000025__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_16.GetRawRoot__O()).Invoke_O__O(s__716000023__3); if jrt.NN(jrt.File_Cast(f__4)).IsFile__Z() { var tmp4 any = t.F_src; var tmp5 jrt.Path = jrt.Path_Cast(t.F_root); var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__716000022); return lang.IFn_Cast(A_arbace_repr_clojure_A_const_50.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(tmp4, lang.IFn_Cast(A_arbace_repr_clojure_A_const_48.GetRawRoot__O()).Invoke_O__O(tmp5.Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__4)).ToPath__Path()))), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_A_const_53.GetRawRoot__O()).Invoke_O__O(s__716000023__3))) } else { s__716000023__1 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_53.GetRawRoot__O()).Invoke_O__O(s__716000023__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :84:1
func A_arbace_repr_clojure_files_iter__716000022__716000026_fn__716000027_fn__716000028_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_repr_clojure_files_iter__716000022__716000026_fn__716000027_fn__716000028_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_files_iter__716000022__716000026_fn__716000027_fn__716000028_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :84:1
func (t *A_arbace_repr_clojure_files_iter__716000022__716000026_fn__716000027_fn__716000028_A) Ctor_O_O_O_I_O(c__root, c__src, c__b__716000025 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_root = c__root; t.F_src = c__src; t.F_b__716000025 = c__b__716000025; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :84:1
func (t *A_arbace_repr_clojure_files_iter__716000022__716000026_fn__716000027_fn__716000028_A) Invoke_O__O(self any) any { { var i__716000024__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__716000024__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__716000024__1)); if jrt.NN(jrt.File_Cast(f__2)).IsFile__Z() { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_47.GetRawRoot__O()); var tmp3 any = t.F_b__716000025; var tmp4 any = t.F_src; var tmp5 jrt.Path = jrt.Path_Cast(t.F_root); tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(tmp4, lang.IFn_Cast(A_arbace_repr_clojure_A_const_48.GetRawRoot__O()).Invoke_O__O(tmp5.Relativize_Path__Path(jrt.NN(jrt.File_Cast(f__2)).ToPath__Path())))); i__716000024__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__716000024__1); continue L1 } else { i__716000024__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__716000024__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_repr_clojure_run_A_New() *A_arbace_repr_clojure_run_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_A{}; t.Ctor(); return t }
//line :88:1
func (t *A_arbace_repr_clojure_run_A) Ctor() {}
//line :88:1
func (t *A_arbace_repr_clojure_run_A) Invoke_O_O_O_O__O(self, sources__0, out__1, opts__2 any) any { var skip__4 any = A_arbace_repr_clojure_A_const_29.Invoke_O_O__O(opts__2, lang.PersistentHashSet_EMPTY.Ref()); var stats__5 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_55.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_A_const_56); var seq_716000033__6 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_15.GetRawRoot__O()).Invoke_O__O(sources__0); var chunk_716000034__7 any; var count_716000035__8 int64 = 0; var i_716000036__9 int64 = 0; L1: for {






	if lang.Numbers_Lt_J_J__Z_NoInit(i_716000036__9, count_716000035__8) { var src__10 any = lang.Indexed_Cast(chunk_716000034__7).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_716000036__9)); var srcf__11 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_57.GetRawRoot__O()).Invoke_O__O(src__10); var seq_716000041__12 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_A_const_58.GetRawRoot__O()).Invoke_O__O(srcf__11)); var chunk_716000042__13 any; var count_716000043__14 int64 = 0; var i_716000044__15 int64 = 0; L2: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_716000044__15, count_716000043__14) { var vec__716000045__16 any = lang.Indexed_Cast(chunk_716000042__13).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_716000044__15)); var dir__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000045__16, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000045__16, lang.RT_IntCast_J__I_NoInit(1), nil); var f__19 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_57.GetRawRoot__O()).Invoke_O_O__O(dir__17, rel__18); var parent__20 any = jrt.NN(jrt.File_Cast(f__19)).GetParentFile__File().Ref(); var siblings__21 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_59.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.File_Cast(parent__20)).List__String1().Ref()); var p__22 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_60.GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(jrt.File_Cast(f__19)).GetName__String().Ref(), siblings__21, opts__2); var rel_out__23 any; var d__23 any = jrt.NN(jrt.File_Cast(lang.IFn_Cast(A_arbace_repr_clojure_A_const_57.GetRawRoot__O()).Invoke_O__O(rel__18))).GetParent__String().Ref()






		if jrt.J2g_Truth(d__23) { rel_out__23 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_47, nil), jrt.RefArrayOf(jrt.Object_class, d__23, nil, A_arbace_repr_clojure_A_const_25.Invoke_O__O(p__22))).Ref() } else { rel_out__23 = A_arbace_repr_clojure_A_const_25.Invoke_O__O(p__22) }
		if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_29.Invoke_O__O(p__22)) {

			var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_64.GetRawRoot__O()); var tmp2 any = A_arbace_repr_clojure_A_const_68.GetRawRoot__O(); var tmp3 any = A_arbace_repr_clojure_A_const_76; tmp1.Invoke_O_O_O_O__O(stats__5, tmp2, tmp3, A_arbace_repr_clojure_A_const_70.GetRawRoot__O())
			var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_72.GetRawRoot__O()); var tmp5 any = A_arbace_repr_clojure_A_const_73; lang.IFn_Cast(A_arbace_repr_clojure_A_const_71.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O_O__O(tmp5, A_arbace_repr_clojure_A_const_74.Get__O())); var tmp6 any = A_arbace_repr_clojure_run_fn__716000048_A_New_O_O(f__19, p__22); var tmp7 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_repr_clojure_run_fn__716000048_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_repr_clojure_run_fn__716000048_A_fn_class = fncls__5d; tmp7 = fncls__5d } else { tmp7 = fncls__5 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O() } else {
//line :103:1
				if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_63.Invoke_O__O(p__22)) {




					if jrt.J2g_Truth(out__1) { var t__24 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_57.GetRawRoot__O()).Invoke_O_O__O(out__1, rel__18)

						lang.IFn_Cast(A_arbace_repr_clojure_A_const_78.GetRawRoot__O()).Invoke_O__O(t__24)
						lang.IFn_Cast(A_arbace_repr_clojure_A_const_77.GetRawRoot__O()).Invoke_O_O__O(f__19, t__24) }
					var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_64.GetRawRoot__O()); var tmp9 any = A_arbace_repr_clojure_A_const_68.GetRawRoot__O(); var tmp10 any = A_arbace_repr_clojure_A_const_79; tmp8.Invoke_O_O_O_O__O(stats__5, tmp9, tmp10, A_arbace_repr_clojure_A_const_70.GetRawRoot__O()) } else {
//line :103:1
						if A_arbace_repr_clojure_A_const_30 != nil { var s__24 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_65.GetRawRoot__O()).Invoke_O__O(f__19); var r__25 any; var tmp11 any = A_arbace_repr_clojure_run_fn__716000050_A_New_O_O_O_O_O(f__19, stats__5, p__22, skip__4, s__24); var tmp12 *jrt.Class
							var fncls__7 /*line :103:1*/*jrt.Class = A_arbace_repr_clojure_run_fn__716000050_A_fn_class











							if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_repr_clojure_run_fn__716000050_A_fn_class = fncls__7d; tmp12 = fncls__7d } else { tmp12 = fncls__7 }; r__25 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil).Invoke__O()




							if jrt.J2g_Truth(r__25) {
								var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_64.GetRawRoot__O()); var tmp14 any = A_arbace_repr_clojure_A_const_68.GetRawRoot__O(); var tmp15 *lang.Keyword; if lang.Util_Equiv_O_O__Z_NoInit(s__24, r__25) { tmp15 = A_arbace_repr_clojure_A_const_80 } else { tmp15 = A_arbace_repr_clojure_A_const_81 }; tmp13.Invoke_O_O_O_O__O(stats__5, tmp14, tmp15.Ref(), A_arbace_repr_clojure_A_const_70.GetRawRoot__O())
								if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_24.Invoke_O__O(p__22)) { var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_64.GetRawRoot__O()); var tmp17 any = A_arbace_repr_clojure_A_const_68.GetRawRoot__O(); var tmp18 any = A_arbace_repr_clojure_A_const_24; tmp16.Invoke_O_O_O_O__O(stats__5, tmp17, tmp18, A_arbace_repr_clojure_A_const_70.GetRawRoot__O()) }
								if jrt.J2g_Truth(out__1) { var t__26 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_57.GetRawRoot__O()).Invoke_O_O__O(out__1, rel_out__23)

									lang.IFn_Cast(A_arbace_repr_clojure_A_const_78.GetRawRoot__O()).Invoke_O__O(t__26)
									lang.IFn_Cast(A_arbace_repr_clojure_A_const_75.GetRawRoot__O()).Invoke_O_O__O(t__26, r__25) } else {
										var tmp19 any; var or__1927000174__auto____26 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_82.GetRawRoot__O()).Invoke_O_O__O(s__24, r__25); if jrt.J2g_Truth(or__1927000174__auto____26) { tmp19 = or__1927000174__auto____26 } else { tmp19 = A_arbace_repr_clojure_A_const_24.Invoke_O__O(p__22) }; if jrt.J2g_Truth(tmp19) {
											lang.IFn_Cast(A_arbace_repr_clojure_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_clojure_A_const_57.GetRawRoot__O()).Invoke_O_O__O(parent__20, A_arbace_repr_clojure_A_const_25.Invoke_O__O(p__22)), r__25) }
										if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_24.Invoke_O__O(p__22)) { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(f__19)).Delete__Z()) } } } } } }
//line :95:1
		seq_716000041__12, chunk_716000042__13, count_716000043__14, i_716000044__15 = seq_716000041__12, chunk_716000042__13, count_716000043__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_716000044__15); continue L2 } else { var temp__1927000414__auto____16 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_716000041__12); if jrt.J2g_Truth(temp__1927000414__auto____16) { var seq_716000041__17 any = temp__1927000414__auto____16; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_A_const_44.GetRawRoot__O()).Invoke_O__O(seq_716000041__17)) { var c__1927000678__auto____18 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_45.GetRawRoot__O()).Invoke_O__O(seq_716000041__17); seq_716000041__12, chunk_716000042__13, count_716000043__14, i_716000044__15 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_52.GetRawRoot__O()).Invoke_O__O(seq_716000041__17), c__1927000678__auto____18, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____18))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var vec__716000054__18 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_16.GetRawRoot__O()).Invoke_O__O(seq_716000041__17); var dir__19 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000054__18, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__20 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000054__18, lang.RT_IntCast_J__I_NoInit(1), nil); var f__21 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_57.GetRawRoot__O()).Invoke_O_O__O(dir__19, rel__20); var parent__22 any = jrt.NN(jrt.File_Cast(f__21)).GetParentFile__File().Ref(); var siblings__23 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_59.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.File_Cast(parent__22)).List__String1().Ref()); var p__24 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_60.GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(jrt.File_Cast(f__21)).GetName__String().Ref(), siblings__23, opts__2); var rel_out__25 any; var d__25 any = jrt.NN(jrt.File_Cast(lang.IFn_Cast(A_arbace_repr_clojure_A_const_57.GetRawRoot__O()).Invoke_O__O(rel__20))).GetParent__String().Ref()






			if jrt.J2g_Truth(d__25) { rel_out__25 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_47, nil), jrt.RefArrayOf(jrt.Object_class, d__25, nil, A_arbace_repr_clojure_A_const_25.Invoke_O__O(p__24))).Ref() } else { rel_out__25 = A_arbace_repr_clojure_A_const_25.Invoke_O__O(p__24) }
			if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_29.Invoke_O__O(p__24)) {

				var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_64.GetRawRoot__O()); var tmp21 any = A_arbace_repr_clojure_A_const_68.GetRawRoot__O(); var tmp22 any = A_arbace_repr_clojure_A_const_76; tmp20.Invoke_O_O_O_O__O(stats__5, tmp21, tmp22, A_arbace_repr_clojure_A_const_70.GetRawRoot__O())
				var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_72.GetRawRoot__O()); var tmp24 any = A_arbace_repr_clojure_A_const_73; lang.IFn_Cast(A_arbace_repr_clojure_A_const_71.GetRawRoot__O()).Invoke_O__O(tmp23.Invoke_O_O__O(tmp24, A_arbace_repr_clojure_A_const_74.Get__O())); var tmp25 any = A_arbace_repr_clojure_run_fn__716000057_A_New_O_O(f__21, p__24); var tmp26 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_repr_clojure_run_fn__716000057_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_repr_clojure_run_fn__716000057_A_fn_class = fncls__8d; tmp26 = fncls__8d } else { tmp26 = fncls__8 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil).Invoke__O() } else {
//line :103:1
					if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_63.Invoke_O__O(p__24)) {




						if jrt.J2g_Truth(out__1) { var t__26_2 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_57.GetRawRoot__O()).Invoke_O_O__O(out__1, rel__20)

							lang.IFn_Cast(A_arbace_repr_clojure_A_const_78.GetRawRoot__O()).Invoke_O__O(t__26_2)
							lang.IFn_Cast(A_arbace_repr_clojure_A_const_77.GetRawRoot__O()).Invoke_O_O__O(f__21, t__26_2) }
						var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_64.GetRawRoot__O()); var tmp28 any = A_arbace_repr_clojure_A_const_68.GetRawRoot__O(); var tmp29 any = A_arbace_repr_clojure_A_const_79; tmp27.Invoke_O_O_O_O__O(stats__5, tmp28, tmp29, A_arbace_repr_clojure_A_const_70.GetRawRoot__O()) } else {
//line :103:1
							if A_arbace_repr_clojure_A_const_30 != nil { var s__26 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_65.GetRawRoot__O()).Invoke_O__O(f__21); var r__27 any; var tmp30 any = A_arbace_repr_clojure_run_fn__716000059_A_New_O_O_O_O_O(f__21, p__24, s__26, stats__5, skip__4); var tmp31 *jrt.Class
								var fncls__10 /*line :103:1*/*jrt.Class = A_arbace_repr_clojure_run_fn__716000059_A_fn_class











								if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_repr_clojure_run_fn__716000059_A_fn_class = fncls__10d; tmp31 = fncls__10d } else { tmp31 = fncls__10 }; r__27 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp30, tmp31, nil).Invoke__O()




								if jrt.J2g_Truth(r__27) {
									var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_64.GetRawRoot__O()); var tmp33 any = A_arbace_repr_clojure_A_const_68.GetRawRoot__O(); var tmp34 *lang.Keyword; if lang.Util_Equiv_O_O__Z_NoInit(s__26, r__27) { tmp34 = A_arbace_repr_clojure_A_const_80 } else { tmp34 = A_arbace_repr_clojure_A_const_81 }; tmp32.Invoke_O_O_O_O__O(stats__5, tmp33, tmp34.Ref(), A_arbace_repr_clojure_A_const_70.GetRawRoot__O())
									if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_24.Invoke_O__O(p__24)) { var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_64.GetRawRoot__O()); var tmp36 any = A_arbace_repr_clojure_A_const_68.GetRawRoot__O(); var tmp37 any = A_arbace_repr_clojure_A_const_24; tmp35.Invoke_O_O_O_O__O(stats__5, tmp36, tmp37, A_arbace_repr_clojure_A_const_70.GetRawRoot__O()) }
									if jrt.J2g_Truth(out__1) { var t__28 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_57.GetRawRoot__O()).Invoke_O_O__O(out__1, rel_out__25)

										lang.IFn_Cast(A_arbace_repr_clojure_A_const_78.GetRawRoot__O()).Invoke_O__O(t__28)
										lang.IFn_Cast(A_arbace_repr_clojure_A_const_75.GetRawRoot__O()).Invoke_O_O__O(t__28, r__27) } else {
											var tmp38 any; var or__1927000174__auto____28 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_82.GetRawRoot__O()).Invoke_O_O__O(s__26, r__27); if jrt.J2g_Truth(or__1927000174__auto____28) { tmp38 = or__1927000174__auto____28 } else { tmp38 = A_arbace_repr_clojure_A_const_24.Invoke_O__O(p__24) }; if jrt.J2g_Truth(tmp38) {
												lang.IFn_Cast(A_arbace_repr_clojure_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_clojure_A_const_57.GetRawRoot__O()).Invoke_O_O__O(parent__22, A_arbace_repr_clojure_A_const_25.Invoke_O__O(p__24)), r__27) }
											if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_24.Invoke_O__O(p__24)) { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(f__21)).Delete__Z()) } } } } } }
//line :95:1
			seq_716000041__12, chunk_716000042__13, count_716000043__14, i_716000044__15 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_13.GetRawRoot__O()).Invoke_O__O(seq_716000041__17), nil, 0, 0; continue L2 } } }; break L2 }; seq_716000033__6, chunk_716000034__7, count_716000035__8, i_716000036__9 = seq_716000033__6, chunk_716000034__7, count_716000035__8, lang.Numbers_Unchecked_inc_J__J_NoInit(i_716000036__9); continue L1 } else { var temp__1927000414__auto____10 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_716000033__6); if jrt.J2g_Truth(temp__1927000414__auto____10) { var seq_716000033__11 any = temp__1927000414__auto____10; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_A_const_44.GetRawRoot__O()).Invoke_O__O(seq_716000033__11)) { var c__1927000678__auto____12 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_45.GetRawRoot__O()).Invoke_O__O(seq_716000033__11); seq_716000033__6, chunk_716000034__7, count_716000035__8, i_716000036__9 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_52.GetRawRoot__O()).Invoke_O__O(seq_716000033__11), c__1927000678__auto____12, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____12))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var src__12 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_16.GetRawRoot__O()).Invoke_O__O(seq_716000033__11); var srcf__13 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_57.GetRawRoot__O()).Invoke_O__O(src__12); var seq_716000037__14 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_A_const_58.GetRawRoot__O()).Invoke_O__O(srcf__13)); var chunk_716000038__15 any; var count_716000039__16 int64 = 0; var i_716000040__17 int64 = 0; L3: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_716000040__17, count_716000039__16) { var vec__716000063__18 any = lang.Indexed_Cast(chunk_716000038__15).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_716000040__17)); var dir__19_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000063__18, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__20_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000063__18, lang.RT_IntCast_J__I_NoInit(1), nil); var f__21_2 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_57.GetRawRoot__O()).Invoke_O_O__O(dir__19_2, rel__20_2); var parent__22_2 any = jrt.NN(jrt.File_Cast(f__21_2)).GetParentFile__File().Ref(); var siblings__23_2 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_59.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.File_Cast(parent__22_2)).List__String1().Ref()); var p__24_2 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_60.GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(jrt.File_Cast(f__21_2)).GetName__String().Ref(), siblings__23_2, opts__2); var rel_out__25_2 any; var d__25_2 any = jrt.NN(jrt.File_Cast(lang.IFn_Cast(A_arbace_repr_clojure_A_const_57.GetRawRoot__O()).Invoke_O__O(rel__20_2))).GetParent__String().Ref()






				if jrt.J2g_Truth(d__25_2) { rel_out__25_2 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_47, nil), jrt.RefArrayOf(jrt.Object_class, d__25_2, nil, A_arbace_repr_clojure_A_const_25.Invoke_O__O(p__24_2))).Ref() } else { rel_out__25_2 = A_arbace_repr_clojure_A_const_25.Invoke_O__O(p__24_2) }
				if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_29.Invoke_O__O(p__24_2)) {

					var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_64.GetRawRoot__O()); var tmp40 any = A_arbace_repr_clojure_A_const_68.GetRawRoot__O(); var tmp41 any = A_arbace_repr_clojure_A_const_76; tmp39.Invoke_O_O_O_O__O(stats__5, tmp40, tmp41, A_arbace_repr_clojure_A_const_70.GetRawRoot__O())
					var tmp42 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_72.GetRawRoot__O()); var tmp43 any = A_arbace_repr_clojure_A_const_73; lang.IFn_Cast(A_arbace_repr_clojure_A_const_71.GetRawRoot__O()).Invoke_O__O(tmp42.Invoke_O_O__O(tmp43, A_arbace_repr_clojure_A_const_74.Get__O())); var tmp44 any = A_arbace_repr_clojure_run_fn__716000066_A_New_O_O(f__21_2, p__24_2); var tmp45 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_repr_clojure_run_fn__716000066_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_52, false); A_arbace_repr_clojure_run_fn__716000066_A_fn_class = fncls__11d; tmp45 = fncls__11d } else { tmp45 = fncls__11 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp44, tmp45, nil).Invoke__O() } else {
//line :103:1
						if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_63.Invoke_O__O(p__24_2)) {




							if jrt.J2g_Truth(out__1) { var t__26_3 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_57.GetRawRoot__O()).Invoke_O_O__O(out__1, rel__20_2)

								lang.IFn_Cast(A_arbace_repr_clojure_A_const_78.GetRawRoot__O()).Invoke_O__O(t__26_3)
								lang.IFn_Cast(A_arbace_repr_clojure_A_const_77.GetRawRoot__O()).Invoke_O_O__O(f__21_2, t__26_3) }
							var tmp46 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_64.GetRawRoot__O()); var tmp47 any = A_arbace_repr_clojure_A_const_68.GetRawRoot__O(); var tmp48 any = A_arbace_repr_clojure_A_const_79; tmp46.Invoke_O_O_O_O__O(stats__5, tmp47, tmp48, A_arbace_repr_clojure_A_const_70.GetRawRoot__O()) } else {
//line :103:1
								if A_arbace_repr_clojure_A_const_30 != nil { var s__26_2 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_65.GetRawRoot__O()).Invoke_O__O(f__21_2); var r__27_2 any; var tmp49 any = A_arbace_repr_clojure_run_fn__716000068_A_New_O_O_O_O_O(f__21_2, p__24_2, s__26_2, stats__5, skip__4); var tmp50 *jrt.Class
									var fncls__13 /*line :103:1*/*jrt.Class = A_arbace_repr_clojure_run_fn__716000068_A_fn_class











									if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_repr_clojure_run_fn__716000068_A_fn_class = fncls__13d; tmp50 = fncls__13d } else { tmp50 = fncls__13 }; r__27_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp49, tmp50, nil).Invoke__O()




									if jrt.J2g_Truth(r__27_2) {
										var tmp51 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_64.GetRawRoot__O()); var tmp52 any = A_arbace_repr_clojure_A_const_68.GetRawRoot__O(); var tmp53 *lang.Keyword; if lang.Util_Equiv_O_O__Z_NoInit(s__26_2, r__27_2) { tmp53 = A_arbace_repr_clojure_A_const_80 } else { tmp53 = A_arbace_repr_clojure_A_const_81 }; tmp51.Invoke_O_O_O_O__O(stats__5, tmp52, tmp53.Ref(), A_arbace_repr_clojure_A_const_70.GetRawRoot__O())
										if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_24.Invoke_O__O(p__24_2)) { var tmp54 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_64.GetRawRoot__O()); var tmp55 any = A_arbace_repr_clojure_A_const_68.GetRawRoot__O(); var tmp56 any = A_arbace_repr_clojure_A_const_24; tmp54.Invoke_O_O_O_O__O(stats__5, tmp55, tmp56, A_arbace_repr_clojure_A_const_70.GetRawRoot__O()) }
										if jrt.J2g_Truth(out__1) { var t__28_2 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_57.GetRawRoot__O()).Invoke_O_O__O(out__1, rel_out__25_2)

											lang.IFn_Cast(A_arbace_repr_clojure_A_const_78.GetRawRoot__O()).Invoke_O__O(t__28_2)
											lang.IFn_Cast(A_arbace_repr_clojure_A_const_75.GetRawRoot__O()).Invoke_O_O__O(t__28_2, r__27_2) } else {
												var tmp57 any; var or__1927000174__auto____28_2 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_82.GetRawRoot__O()).Invoke_O_O__O(s__26_2, r__27_2); if jrt.J2g_Truth(or__1927000174__auto____28_2) { tmp57 = or__1927000174__auto____28_2 } else { tmp57 = A_arbace_repr_clojure_A_const_24.Invoke_O__O(p__24_2) }; if jrt.J2g_Truth(tmp57) {
													lang.IFn_Cast(A_arbace_repr_clojure_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_clojure_A_const_57.GetRawRoot__O()).Invoke_O_O__O(parent__22_2, A_arbace_repr_clojure_A_const_25.Invoke_O__O(p__24_2)), r__27_2) }
												if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_24.Invoke_O__O(p__24_2)) { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(f__21_2)).Delete__Z()) } } } } } }
//line :95:1
				seq_716000037__14, chunk_716000038__15, count_716000039__16, i_716000040__17 = seq_716000037__14, chunk_716000038__15, count_716000039__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_716000040__17); continue L3 } else { var temp__1927000414__auto____18 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_716000037__14); if jrt.J2g_Truth(temp__1927000414__auto____18) { var seq_716000037__19 any = temp__1927000414__auto____18; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_A_const_44.GetRawRoot__O()).Invoke_O__O(seq_716000037__19)) { var c__1927000678__auto____20 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_45.GetRawRoot__O()).Invoke_O__O(seq_716000037__19); seq_716000037__14, chunk_716000038__15, count_716000039__16, i_716000040__17 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_52.GetRawRoot__O()).Invoke_O__O(seq_716000037__19), c__1927000678__auto____20, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____20))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__716000072__20 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_16.GetRawRoot__O()).Invoke_O__O(seq_716000037__19); var dir__21 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000072__20, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__22 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000072__20, lang.RT_IntCast_J__I_NoInit(1), nil); var f__23 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_57.GetRawRoot__O()).Invoke_O_O__O(dir__21, rel__22); var parent__24 any = jrt.NN(jrt.File_Cast(f__23)).GetParentFile__File().Ref(); var siblings__25 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_59.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.File_Cast(parent__24)).List__String1().Ref()); var p__26 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_60.GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(jrt.File_Cast(f__23)).GetName__String().Ref(), siblings__25, opts__2); var rel_out__27 any; var d__27 any = jrt.NN(jrt.File_Cast(lang.IFn_Cast(A_arbace_repr_clojure_A_const_57.GetRawRoot__O()).Invoke_O__O(rel__22))).GetParent__String().Ref()






					if jrt.J2g_Truth(d__27) { rel_out__27 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_47, nil), jrt.RefArrayOf(jrt.Object_class, d__27, nil, A_arbace_repr_clojure_A_const_25.Invoke_O__O(p__26))).Ref() } else { rel_out__27 = A_arbace_repr_clojure_A_const_25.Invoke_O__O(p__26) }
					if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_29.Invoke_O__O(p__26)) {

						var tmp58 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_64.GetRawRoot__O()); var tmp59 any = A_arbace_repr_clojure_A_const_68.GetRawRoot__O(); var tmp60 any = A_arbace_repr_clojure_A_const_76; tmp58.Invoke_O_O_O_O__O(stats__5, tmp59, tmp60, A_arbace_repr_clojure_A_const_70.GetRawRoot__O())
						var tmp61 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_72.GetRawRoot__O()); var tmp62 any = A_arbace_repr_clojure_A_const_73; lang.IFn_Cast(A_arbace_repr_clojure_A_const_71.GetRawRoot__O()).Invoke_O__O(tmp61.Invoke_O_O__O(tmp62, A_arbace_repr_clojure_A_const_74.Get__O())); var tmp63 any = A_arbace_repr_clojure_run_fn__716000075_A_New_O_O(f__23, p__26); var tmp64 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_repr_clojure_run_fn__716000075_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_repr_clojure_run_fn__716000075_A_fn_class = fncls__14d; tmp64 = fncls__14d } else { tmp64 = fncls__14 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp63, tmp64, nil).Invoke__O() } else {
//line :103:1
							if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_63.Invoke_O__O(p__26)) {




								if jrt.J2g_Truth(out__1) { var t__28_3 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_57.GetRawRoot__O()).Invoke_O_O__O(out__1, rel__22)

									lang.IFn_Cast(A_arbace_repr_clojure_A_const_78.GetRawRoot__O()).Invoke_O__O(t__28_3)
									lang.IFn_Cast(A_arbace_repr_clojure_A_const_77.GetRawRoot__O()).Invoke_O_O__O(f__23, t__28_3) }
								var tmp65 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_64.GetRawRoot__O()); var tmp66 any = A_arbace_repr_clojure_A_const_68.GetRawRoot__O(); var tmp67 any = A_arbace_repr_clojure_A_const_79; tmp65.Invoke_O_O_O_O__O(stats__5, tmp66, tmp67, A_arbace_repr_clojure_A_const_70.GetRawRoot__O()) } else {
//line :103:1
									if A_arbace_repr_clojure_A_const_30 != nil { var s__28 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_65.GetRawRoot__O()).Invoke_O__O(f__23); var r__29 any; var tmp68 any = A_arbace_repr_clojure_run_fn__716000077_A_New_O_O_O_O_O(f__23, p__26, s__28, stats__5, skip__4); var tmp69 *jrt.Class
										var fncls__16 /*line :103:1*/*jrt.Class = A_arbace_repr_clojure_run_fn__716000077_A_fn_class











										if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_repr_clojure_run_fn__716000077_A_fn_class = fncls__16d; tmp69 = fncls__16d } else { tmp69 = fncls__16 }; r__29 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp68, tmp69, nil).Invoke__O()




										if jrt.J2g_Truth(r__29) {
											var tmp70 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_64.GetRawRoot__O()); var tmp71 any = A_arbace_repr_clojure_A_const_68.GetRawRoot__O(); var tmp72 *lang.Keyword; if lang.Util_Equiv_O_O__Z_NoInit(s__28, r__29) { tmp72 = A_arbace_repr_clojure_A_const_80 } else { tmp72 = A_arbace_repr_clojure_A_const_81 }; tmp70.Invoke_O_O_O_O__O(stats__5, tmp71, tmp72.Ref(), A_arbace_repr_clojure_A_const_70.GetRawRoot__O())
											if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_24.Invoke_O__O(p__26)) { var tmp73 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_64.GetRawRoot__O()); var tmp74 any = A_arbace_repr_clojure_A_const_68.GetRawRoot__O(); var tmp75 any = A_arbace_repr_clojure_A_const_24; tmp73.Invoke_O_O_O_O__O(stats__5, tmp74, tmp75, A_arbace_repr_clojure_A_const_70.GetRawRoot__O()) }
											if jrt.J2g_Truth(out__1) { var t__30 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_57.GetRawRoot__O()).Invoke_O_O__O(out__1, rel_out__27)

												lang.IFn_Cast(A_arbace_repr_clojure_A_const_78.GetRawRoot__O()).Invoke_O__O(t__30)
												lang.IFn_Cast(A_arbace_repr_clojure_A_const_75.GetRawRoot__O()).Invoke_O_O__O(t__30, r__29) } else {
													var tmp76 any; var or__1927000174__auto____30 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_82.GetRawRoot__O()).Invoke_O_O__O(s__28, r__29); if jrt.J2g_Truth(or__1927000174__auto____30) { tmp76 = or__1927000174__auto____30 } else { tmp76 = A_arbace_repr_clojure_A_const_24.Invoke_O__O(p__26) }; if jrt.J2g_Truth(tmp76) {
														lang.IFn_Cast(A_arbace_repr_clojure_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_clojure_A_const_57.GetRawRoot__O()).Invoke_O_O__O(parent__24, A_arbace_repr_clojure_A_const_25.Invoke_O__O(p__26)), r__29) }
													if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_24.Invoke_O__O(p__26)) { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(f__23)).Delete__Z()) } } } } } }
//line :95:1
					seq_716000037__14, chunk_716000038__15, count_716000039__16, i_716000040__17 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_13.GetRawRoot__O()).Invoke_O__O(seq_716000037__19), nil, 0, 0; continue L3 } } }; break L3 }; seq_716000033__6, chunk_716000034__7, count_716000035__8, i_716000036__9 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_13.GetRawRoot__O()).Invoke_O__O(seq_716000033__11), nil, 0, 0; continue L1 } } }
//line :88:1
	break L1 }; return /*line :93:1*/ lang.IFn_Cast(A_arbace_repr_clojure_A_const_7.GetRawRoot__O()).Invoke_O__O(stats__5) }












func A_arbace_repr_clojure_run_fn__716000048_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_run_fn__716000048_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000048_A{}; t.Ctor_O_O(p0, p1); return t }
//line :106:1
func (t *A_arbace_repr_clojure_run_fn__716000048_A) Ctor_O_O(c__f, c__p any) { t.F_f = c__f; t.F_p = c__p }
//line :106:1
func (t *A_arbace_repr_clojure_run_fn__716000048_A) Invoke_O__O(self any) any { var tmp1 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_61.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_48.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_f; t.F_f = nil; tmp4 = t_; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 *lang.Keyword = A_arbace_repr_clojure_A_const_29; var tmp7 any; var t__2 any = t.F_p; t.F_p = nil; tmp7 = t__2; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_56, tmp5, Lit_27, tmp6.Invoke_O__O(tmp7)) }; return nil }(); lang.IFn_Cast(A_arbace_repr_clojure_A_const_62.GetRawRoot__O()).Invoke__O(); if tmp8 != nil { panic(tmp8) }; return tmp1 }
//line :106:1
func A_arbace_repr_clojure_run_fn__716000057_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_run_fn__716000057_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000057_A{}; t.Ctor_O_O(p0, p1); return t }
//line :106:1
func (t *A_arbace_repr_clojure_run_fn__716000057_A) Ctor_O_O(c__f, c__p any) { t.F_f = c__f; t.F_p = c__p }
//line :106:1
func (t *A_arbace_repr_clojure_run_fn__716000057_A) Invoke_O__O(self any) any { var tmp1 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_61.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_48.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_f; t.F_f = nil; tmp4 = t_; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 *lang.Keyword = A_arbace_repr_clojure_A_const_29; var tmp7 any; var t__2 any = t.F_p; t.F_p = nil; tmp7 = t__2; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_56, tmp5, Lit_27, tmp6.Invoke_O__O(tmp7)) }; return nil }(); lang.IFn_Cast(A_arbace_repr_clojure_A_const_62.GetRawRoot__O()).Invoke__O(); if tmp8 != nil { panic(tmp8) }; return tmp1 }
//line :106:1
func A_arbace_repr_clojure_run_fn__716000066_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_run_fn__716000066_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000066_A{}; t.Ctor_O_O(p0, p1); return t }
//line :106:1
func (t *A_arbace_repr_clojure_run_fn__716000066_A) Ctor_O_O(c__f, c__p any) { t.F_f = c__f; t.F_p = c__p }
//line :106:1
func (t *A_arbace_repr_clojure_run_fn__716000066_A) Invoke_O__O(self any) any { var tmp1 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_61.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_48.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_f; t.F_f = nil; tmp4 = t_; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 *lang.Keyword = A_arbace_repr_clojure_A_const_29; var tmp7 any; var t__2 any = t.F_p; t.F_p = nil; tmp7 = t__2; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_56, tmp5, Lit_27, tmp6.Invoke_O__O(tmp7)) }; return nil }(); lang.IFn_Cast(A_arbace_repr_clojure_A_const_62.GetRawRoot__O()).Invoke__O(); if tmp8 != nil { panic(tmp8) }; return tmp1 }
//line :106:1
func A_arbace_repr_clojure_run_fn__716000075_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_run_fn__716000075_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000075_A{}; t.Ctor_O_O(p0, p1); return t }
//line :106:1
func (t *A_arbace_repr_clojure_run_fn__716000075_A) Ctor_O_O(c__f, c__p any) { t.F_f = c__f; t.F_p = c__p }
//line :106:1
func (t *A_arbace_repr_clojure_run_fn__716000075_A) Invoke_O__O(self any) any { var tmp1 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_61.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_48.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_f; t.F_f = nil; tmp4 = t_; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 *lang.Keyword = A_arbace_repr_clojure_A_const_29; var tmp7 any; var t__2 any = t.F_p; t.F_p = nil; tmp7 = t__2; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_56, tmp5, Lit_27, tmp6.Invoke_O__O(tmp7)) }; return nil }(); lang.IFn_Cast(A_arbace_repr_clojure_A_const_62.GetRawRoot__O()).Invoke__O(); if tmp8 != nil { panic(tmp8) }; return tmp1 }








func A_arbace_repr_clojure_run_fn__716000050_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_repr_clojure_run_fn__716000050_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000050_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :115:1
func (t *A_arbace_repr_clojure_run_fn__716000050_A) Ctor_O_O_O_O_O(c__f, c__stats, c__p, c__skip, c__s any) { t.F_f = c__f; t.F_stats = c__stats; t.F_p = c__p; t.F_skip = c__skip; t.F_s = c__s }
//line :115:1
func (t *A_arbace_repr_clojure_run_fn__716000050_A) Invoke_O__O(self any) any { var tmp1 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_66.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_s; t.F_s = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var t__2 any = t.F_p; t.F_p = nil; tmp5 = t__2; var tmp6 any = tmp5; var tmp7 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_48.GetRawRoot__O()).Invoke_O__O(t.F_f); var tmp8 any; var t__3 any = t.F_skip; t.F_skip = nil; tmp8 = t__3; tmp1 = tmp2.Invoke_O_O_O_O__O(tmp4, tmp6, tmp7, tmp8) }; return nil }(); if tmp9 != nil { if jrt.Exception_InstanceOf(tmp9) { var e__3 jrt.Exception_I = jrt.Exception_Cast(tmp9); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_64.GetRawRoot__O()); var tmp11 any; var t__4 any = t.F_stats

	t.F_stats = nil; tmp11 = t__4; var tmp12 any = tmp11; var tmp13 any = A_arbace_repr_clojure_A_const_68.GetRawRoot__O(); var tmp14 any = A_arbace_repr_clojure_A_const_69; tmp10.Invoke_O_O_O_O__O(tmp12, tmp13, tmp14, A_arbace_repr_clojure_A_const_70.GetRawRoot__O())
	var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_72.GetRawRoot__O()); var tmp16 any = A_arbace_repr_clojure_A_const_73; lang.IFn_Cast(A_arbace_repr_clojure_A_const_71.GetRawRoot__O()).Invoke_O__O(tmp15.Invoke_O_O__O(tmp16, A_arbace_repr_clojure_A_const_74.Get__O())); var tmp17 any = A_arbace_repr_clojure_run_fn__716000050_fn__716000051_A_New_O_O(e__3, t.F_f); var tmp18 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_repr_clojure_run_fn__716000050_fn__716000051_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); A_arbace_repr_clojure_run_fn__716000050_fn__716000051_A_fn_class = fncls__6d; tmp18 = fncls__6d } else { tmp18 = fncls__6 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil).Invoke__O()
//line :115:1
	tmp1 = nil } else { panic(tmp9) } }; return tmp1 }
//line :115:1
func A_arbace_repr_clojure_run_fn__716000059_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_repr_clojure_run_fn__716000059_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000059_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :115:1
func (t *A_arbace_repr_clojure_run_fn__716000059_A) Ctor_O_O_O_O_O(c__f, c__p, c__s, c__stats, c__skip any) { t.F_f = c__f; t.F_p = c__p; t.F_s = c__s; t.F_stats = c__stats; t.F_skip = c__skip }
//line :115:1
func (t *A_arbace_repr_clojure_run_fn__716000059_A) Invoke_O__O(self any) any { var tmp1 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_66.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_s; t.F_s = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var t__2 any = t.F_p; t.F_p = nil; tmp5 = t__2; var tmp6 any = tmp5; var tmp7 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_48.GetRawRoot__O()).Invoke_O__O(t.F_f); var tmp8 any; var t__3 any = t.F_skip; t.F_skip = nil; tmp8 = t__3; tmp1 = tmp2.Invoke_O_O_O_O__O(tmp4, tmp6, tmp7, tmp8) }; return nil }(); if tmp9 != nil { if jrt.Exception_InstanceOf(tmp9) { var e__3 jrt.Exception_I = jrt.Exception_Cast(tmp9); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_64.GetRawRoot__O()); var tmp11 any; var t__4 any = t.F_stats

	t.F_stats = nil; tmp11 = t__4; var tmp12 any = tmp11; var tmp13 any = A_arbace_repr_clojure_A_const_68.GetRawRoot__O(); var tmp14 any = A_arbace_repr_clojure_A_const_69; tmp10.Invoke_O_O_O_O__O(tmp12, tmp13, tmp14, A_arbace_repr_clojure_A_const_70.GetRawRoot__O())
	var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_72.GetRawRoot__O()); var tmp16 any = A_arbace_repr_clojure_A_const_73; lang.IFn_Cast(A_arbace_repr_clojure_A_const_71.GetRawRoot__O()).Invoke_O__O(tmp15.Invoke_O_O__O(tmp16, A_arbace_repr_clojure_A_const_74.Get__O())); var tmp17 any = A_arbace_repr_clojure_run_fn__716000059_fn__716000060_A_New_O_O(e__3, t.F_f); var tmp18 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_repr_clojure_run_fn__716000059_fn__716000060_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_repr_clojure_run_fn__716000059_fn__716000060_A_fn_class = fncls__9d; tmp18 = fncls__9d } else { tmp18 = fncls__9 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil).Invoke__O()
//line :115:1
	tmp1 = nil } else { panic(tmp9) } }; return tmp1 }
//line :115:1
func A_arbace_repr_clojure_run_fn__716000068_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_repr_clojure_run_fn__716000068_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000068_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :115:1
func (t *A_arbace_repr_clojure_run_fn__716000068_A) Ctor_O_O_O_O_O(c__f, c__p, c__s, c__stats, c__skip any) { t.F_f = c__f; t.F_p = c__p; t.F_s = c__s; t.F_stats = c__stats; t.F_skip = c__skip }
//line :115:1
func (t *A_arbace_repr_clojure_run_fn__716000068_A) Invoke_O__O(self any) any { var tmp1 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_66.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_s; t.F_s = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var t__2 any = t.F_p; t.F_p = nil; tmp5 = t__2; var tmp6 any = tmp5; var tmp7 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_48.GetRawRoot__O()).Invoke_O__O(t.F_f); var tmp8 any; var t__3 any = t.F_skip; t.F_skip = nil; tmp8 = t__3; tmp1 = tmp2.Invoke_O_O_O_O__O(tmp4, tmp6, tmp7, tmp8) }; return nil }(); if tmp9 != nil { if jrt.Exception_InstanceOf(tmp9) { var e__3 jrt.Exception_I = jrt.Exception_Cast(tmp9); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_64.GetRawRoot__O()); var tmp11 any; var t__4 any = t.F_stats

	t.F_stats = nil; tmp11 = t__4; var tmp12 any = tmp11; var tmp13 any = A_arbace_repr_clojure_A_const_68.GetRawRoot__O(); var tmp14 any = A_arbace_repr_clojure_A_const_69; tmp10.Invoke_O_O_O_O__O(tmp12, tmp13, tmp14, A_arbace_repr_clojure_A_const_70.GetRawRoot__O())
	var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_72.GetRawRoot__O()); var tmp16 any = A_arbace_repr_clojure_A_const_73; lang.IFn_Cast(A_arbace_repr_clojure_A_const_71.GetRawRoot__O()).Invoke_O__O(tmp15.Invoke_O_O__O(tmp16, A_arbace_repr_clojure_A_const_74.Get__O())); var tmp17 any = A_arbace_repr_clojure_run_fn__716000068_fn__716000069_A_New_O_O(e__3, t.F_f); var tmp18 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_repr_clojure_run_fn__716000068_fn__716000069_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); A_arbace_repr_clojure_run_fn__716000068_fn__716000069_A_fn_class = fncls__12d; tmp18 = fncls__12d } else { tmp18 = fncls__12 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil).Invoke__O()
//line :115:1
	tmp1 = nil } else { panic(tmp9) } }; return tmp1 }
//line :115:1
func A_arbace_repr_clojure_run_fn__716000077_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_repr_clojure_run_fn__716000077_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000077_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :115:1
func (t *A_arbace_repr_clojure_run_fn__716000077_A) Ctor_O_O_O_O_O(c__f, c__p, c__s, c__stats, c__skip any) { t.F_f = c__f; t.F_p = c__p; t.F_s = c__s; t.F_stats = c__stats; t.F_skip = c__skip }
//line :115:1
func (t *A_arbace_repr_clojure_run_fn__716000077_A) Invoke_O__O(self any) any { var tmp1 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_66.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_s; t.F_s = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var t__2 any = t.F_p; t.F_p = nil; tmp5 = t__2; var tmp6 any = tmp5; var tmp7 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_48.GetRawRoot__O()).Invoke_O__O(t.F_f); var tmp8 any; var t__3 any = t.F_skip; t.F_skip = nil; tmp8 = t__3; tmp1 = tmp2.Invoke_O_O_O_O__O(tmp4, tmp6, tmp7, tmp8) }; return nil }(); if tmp9 != nil { if jrt.Exception_InstanceOf(tmp9) { var e__3 jrt.Exception_I = jrt.Exception_Cast(tmp9); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_64.GetRawRoot__O()); var tmp11 any; var t__4 any = t.F_stats

	t.F_stats = nil; tmp11 = t__4; var tmp12 any = tmp11; var tmp13 any = A_arbace_repr_clojure_A_const_68.GetRawRoot__O(); var tmp14 any = A_arbace_repr_clojure_A_const_69; tmp10.Invoke_O_O_O_O__O(tmp12, tmp13, tmp14, A_arbace_repr_clojure_A_const_70.GetRawRoot__O())
	var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_72.GetRawRoot__O()); var tmp16 any = A_arbace_repr_clojure_A_const_73; lang.IFn_Cast(A_arbace_repr_clojure_A_const_71.GetRawRoot__O()).Invoke_O__O(tmp15.Invoke_O_O__O(tmp16, A_arbace_repr_clojure_A_const_74.Get__O())); var tmp17 any = A_arbace_repr_clojure_run_fn__716000077_fn__716000078_A_New_O_O(e__3, t.F_f); var tmp18 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_repr_clojure_run_fn__716000077_fn__716000078_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_61, false); A_arbace_repr_clojure_run_fn__716000077_fn__716000078_A_fn_class = fncls__15d; tmp18 = fncls__15d } else { tmp18 = fncls__15 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil).Invoke__O()
//line :115:1
	tmp1 = nil } else { panic(tmp9) } }; return tmp1 }


func A_arbace_repr_clojure_run_fn__716000050_fn__716000051_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_run_fn__716000050_fn__716000051_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000050_fn__716000051_A{}; t.Ctor_O_O(p0, p1); return t }
//line :118:1
func (t *A_arbace_repr_clojure_run_fn__716000050_fn__716000051_A) Ctor_O_O(c__e, c__f any) { t.F_e = c__e; t.F_f = c__f }
//line :118:1
func (t *A_arbace_repr_clojure_run_fn__716000050_fn__716000051_A) Invoke_O__O(self any) any { var tmp1 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_61.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_48.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_f; t.F_f = nil; tmp4 = t_; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_67.GetRawRoot__O()); var tmp7 any; var t__2 any = t.F_e; t.F_e = nil; tmp7 = t__2; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_58, tmp5, Lit_27, tmp6.Invoke_O__O(tmp7)) }; return nil }(); lang.IFn_Cast(A_arbace_repr_clojure_A_const_62.GetRawRoot__O()).Invoke__O(); if tmp8 != nil { panic(tmp8) }; return tmp1 }
//line :118:1
func A_arbace_repr_clojure_run_fn__716000059_fn__716000060_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_run_fn__716000059_fn__716000060_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000059_fn__716000060_A{}; t.Ctor_O_O(p0, p1); return t }
//line :118:1
func (t *A_arbace_repr_clojure_run_fn__716000059_fn__716000060_A) Ctor_O_O(c__e, c__f any) { t.F_e = c__e; t.F_f = c__f }
//line :118:1
func (t *A_arbace_repr_clojure_run_fn__716000059_fn__716000060_A) Invoke_O__O(self any) any { var tmp1 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_61.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_48.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_f; t.F_f = nil; tmp4 = t_; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_67.GetRawRoot__O()); var tmp7 any; var t__2 any = t.F_e; t.F_e = nil; tmp7 = t__2; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_58, tmp5, Lit_27, tmp6.Invoke_O__O(tmp7)) }; return nil }(); lang.IFn_Cast(A_arbace_repr_clojure_A_const_62.GetRawRoot__O()).Invoke__O(); if tmp8 != nil { panic(tmp8) }; return tmp1 }
//line :118:1
func A_arbace_repr_clojure_run_fn__716000068_fn__716000069_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_run_fn__716000068_fn__716000069_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000068_fn__716000069_A{}; t.Ctor_O_O(p0, p1); return t }
//line :118:1
func (t *A_arbace_repr_clojure_run_fn__716000068_fn__716000069_A) Ctor_O_O(c__e, c__f any) { t.F_e = c__e; t.F_f = c__f }
//line :118:1
func (t *A_arbace_repr_clojure_run_fn__716000068_fn__716000069_A) Invoke_O__O(self any) any { var tmp1 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_61.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_48.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_f; t.F_f = nil; tmp4 = t_; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_67.GetRawRoot__O()); var tmp7 any; var t__2 any = t.F_e; t.F_e = nil; tmp7 = t__2; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_58, tmp5, Lit_27, tmp6.Invoke_O__O(tmp7)) }; return nil }(); lang.IFn_Cast(A_arbace_repr_clojure_A_const_62.GetRawRoot__O()).Invoke__O(); if tmp8 != nil { panic(tmp8) }; return tmp1 }
//line :118:1
func A_arbace_repr_clojure_run_fn__716000077_fn__716000078_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_run_fn__716000077_fn__716000078_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000077_fn__716000078_A{}; t.Ctor_O_O(p0, p1); return t }
//line :118:1
func (t *A_arbace_repr_clojure_run_fn__716000077_fn__716000078_A) Ctor_O_O(c__e, c__f any) { t.F_e = c__e; t.F_f = c__f }
//line :118:1
func (t *A_arbace_repr_clojure_run_fn__716000077_fn__716000078_A) Invoke_O__O(self any) any { var tmp1 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_61.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_48.GetRawRoot__O()); var tmp4 any; var t_ any = t.F_f; t.F_f = nil; tmp4 = t_; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_67.GetRawRoot__O()); var tmp7 any; var t__2 any = t.F_e; t.F_e = nil; tmp7 = t__2; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_58, tmp5, Lit_27, tmp6.Invoke_O__O(tmp7)) }; return nil }(); lang.IFn_Cast(A_arbace_repr_clojure_A_const_62.GetRawRoot__O()).Invoke__O(); if tmp8 != nil { panic(tmp8) }; return tmp1 }













func A_arbace_repr_clojure_parse_args_A_New() *A_arbace_repr_clojure_parse_args_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_parse_args_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_repr_clojure_parse_args_A) Ctor() {}
//line :132:1
func (t *A_arbace_repr_clojure_parse_args_A) Invoke_O_O__O(self, args__0 any) any { { var G__716000085__2_ any = args__0; var vec__716000086__3 any = G__716000085__2_; var seq__716000087__4 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_15.GetRawRoot__O()).Invoke_O__O(vec__716000086__3); var first__716000088__5 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_16.GetRawRoot__O()).Invoke_O__O(seq__716000087__4); var seq__716000087__6 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_13.GetRawRoot__O()).Invoke_O__O(seq__716000087__4); var a__7 any = first__716000088__5; var more__8 any = seq__716000087__6; var args__9 any = vec__716000086__3; var o__10 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_83, lang.PersistentVector_EMPTY.Ref(), A_arbace_repr_clojure_A_const_18, lang.PersistentVector_EMPTY.Ref(), A_arbace_repr_clojure_A_const_29, lang.PersistentHashSet_EMPTY.Ref(), A_arbace_repr_clojure_A_const_21, A_arbace_repr_clojure_A_const_23)); var G__716000085__11_ any = G__716000085__2_; var o__12 any = o__10; _ = a__7; _ = more__8; _ = args__9; L1: for { var vec__716000089__13 any = G__716000085__11_; var seq__716000090__14 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_15.GetRawRoot__O()).Invoke_O__O(vec__716000089__13); var first__716000091__15 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_16.GetRawRoot__O()).Invoke_O__O(seq__716000090__14); var seq__716000090__16 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_13.GetRawRoot__O()).Invoke_O__O(seq__716000090__14)
											var a__17 any = first__716000091__15; var more__18 any = seq__716000090__16; var args__19 any = vec__716000089__13; var o__20 any = o__12
											if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_A_const_84.GetRawRoot__O()).Invoke_O__O(args__19)) { return o__20 } else { if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_17) {

		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_87.GetRawRoot__O()); var tmp2 any = A_arbace_repr_clojure_A_const_25; G__716000085__11_, o__12 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_53.GetRawRoot__O()).Invoke_O__O(more__18), tmp1.Invoke_O_O_O__O(o__20, tmp2, lang.IFn_Cast(A_arbace_repr_clojure_A_const_16.GetRawRoot__O()).Invoke_O__O(more__18)); continue L1 } else {
//line :134:1
			if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_18) {


				G__716000085__11_, o__12 = more__18, lang.IFn_Cast(A_arbace_repr_clojure_A_const_87.GetRawRoot__O()).Invoke_O_O_O__O(o__20, A_arbace_repr_clojure_A_const_88, jrt.Boolean_TRUE.Ref()); continue L1 } else {
//line :134:1
					if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_19) {



						G__716000085__11_, o__12 = more__18, lang.IFn_Cast(A_arbace_repr_clojure_A_const_87.GetRawRoot__O()).Invoke_O_O_O__O(o__20, A_arbace_repr_clojure_A_const_89, jrt.Boolean_TRUE.Ref()); continue L1 } else {
//line :134:1
							if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_20) {




								G__716000085__11_, o__12 = more__18, lang.IFn_Cast(A_arbace_repr_clojure_A_const_87.GetRawRoot__O()).Invoke_O_O_O__O(o__20, A_arbace_repr_clojure_A_const_90, jrt.Boolean_TRUE.Ref()); continue L1 } else {
//line :134:1
									if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_21) {





										G__716000085__11_, o__12 = more__18, lang.IFn_Cast(A_arbace_repr_clojure_A_const_87.GetRawRoot__O()).Invoke_O_O_O__O(o__20, A_arbace_repr_clojure_A_const_17, jrt.Boolean_TRUE.Ref()); continue L1 } else {
//line :134:1
											if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_22) {






												G__716000085__11_, o__12 = more__18, lang.IFn_Cast(A_arbace_repr_clojure_A_const_87.GetRawRoot__O()).Invoke_O_O_O__O(o__20, A_arbace_repr_clojure_A_const_91, jrt.Boolean_TRUE.Ref()); continue L1 } else {
//line :134:1
													if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_23) {







														G__716000085__11_, o__12 = more__18, lang.IFn_Cast(A_arbace_repr_clojure_A_const_87.GetRawRoot__O()).Invoke_O_O_O__O(o__20, A_arbace_repr_clojure_A_const_92, jrt.Boolean_TRUE.Ref()); continue L1 } else {
//line :134:1
															if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_24) {








																var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_68.GetRawRoot__O()); var tmp4 any = A_arbace_repr_clojure_A_const_18; G__716000085__11_, o__12 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_53.GetRawRoot__O()).Invoke_O__O(more__18), tmp3.Invoke_O_O_O_O__O(o__20, tmp4, A_arbace_repr_clojure_A_const_8.GetRawRoot__O(), lang.IFn_Cast(A_arbace_repr_clojure_A_const_16.GetRawRoot__O()).Invoke_O__O(more__18)); continue L1 } else {
//line :134:1
																	if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_25) {









																		var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_87.GetRawRoot__O()); var tmp6 any = A_arbace_repr_clojure_A_const_21; G__716000085__11_, o__12 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_53.GetRawRoot__O()).Invoke_O__O(more__18), tmp5.Invoke_O_O_O__O(o__20, tmp6, lang.IFn_Cast(A_arbace_repr_clojure_A_const_27.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_A_const_16.GetRawRoot__O()).Invoke_O__O(more__18))); continue L1 } else {
//line :134:1
																			if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_26) {










																				var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_68.GetRawRoot__O()); var tmp8 any = A_arbace_repr_clojure_A_const_29; G__716000085__11_, o__12 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_53.GetRawRoot__O()).Invoke_O__O(more__18), tmp7.Invoke_O_O_O_O__O(o__20, tmp8, A_arbace_repr_clojure_A_const_93.GetRawRoot__O(), lang.IFn_Cast(A_arbace_repr_clojure_A_const_94.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_clojure_A_const_27.GetRawRoot__O(), lang.IFn_Cast(A_arbace_repr_clojure_A_const_95.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_clojure_A_const_16.GetRawRoot__O()).Invoke_O__O(more__18), A_arbace_repr_clojure_A_const_96))); continue L1 } else {
//line :134:1
																					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_A_const_85.GetRawRoot__O()).Invoke_O_O__O(a__17, Lit_27)) { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_repr_clojure_A_const_86.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_28, nil), jrt.RefArrayOf(jrt.Object_class, nil, a__17)).Ref(), lang.PersistentArrayMap_EMPTY.Ref())))) } else { if A_arbace_repr_clojure_A_const_30 != nil {












																						var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_68.GetRawRoot__O()); var tmp10 any = A_arbace_repr_clojure_A_const_83; G__716000085__11_, o__12 = more__18, tmp9.Invoke_O_O_O_O__O(o__20, tmp10, A_arbace_repr_clojure_A_const_8.GetRawRoot__O(), a__17); continue L1 } else {
//line :134:1
																							return nil } } } } } } } } } } } } } } }; /*line :132:1*/panic("j2g: unreachable") }
















func A_arbace_repr_clojure_print_rules_A_New() *A_arbace_repr_clojure_print_rules_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_print_rules_A{}; t.Ctor(); return t }
//line :149:1
func (t *A_arbace_repr_clojure_print_rules_A) Ctor() {}
//line :149:1
func (t *A_arbace_repr_clojure_print_rules_A) Invoke_O__O(self any) any {
	lang.IFn_Cast(A_arbace_repr_clojure_A_const_61.GetRawRoot__O()).Invoke_O__O(Lit_40)
//line :149:1
	{ var seq_716000093__1 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_A_const_97.GetRawRoot__O()); var chunk_716000094__2 any; var count_716000095__3 int64 = 0; var i_716000096__4 int64 = 0; L1: for {

		if lang.Numbers_Lt_J_J__Z_NoInit(i_716000096__4, count_716000095__3) { var r__5 any = lang.Indexed_Cast(chunk_716000094__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_716000096__4))
			lang.IFn_Cast(A_arbace_repr_clojure_A_const_61.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_41, nil, Lit_42, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_clojure_A_const_98.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_A_const_100.Invoke_O__O(r__5)), nil, lang.IFn_Cast(A_arbace_repr_clojure_A_const_99.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_clojure_A_const_101.Invoke_O__O(r__5), A_arbace_repr_clojure_A_const_102, Lit_43))).Ref())
//line :151:1
			seq_716000093__1, chunk_716000094__2, count_716000095__3, i_716000096__4 = seq_716000093__1, chunk_716000094__2, count_716000095__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_716000096__4); continue L1 } else { var temp__1927000414__auto____5 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_716000093__1); if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_716000093__6 any = temp__1927000414__auto____5; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_A_const_44.GetRawRoot__O()).Invoke_O__O(seq_716000093__6)) { var c__1927000678__auto____7 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_45.GetRawRoot__O()).Invoke_O__O(seq_716000093__6); seq_716000093__1, chunk_716000094__2, count_716000095__3, i_716000096__4 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_52.GetRawRoot__O()).Invoke_O__O(seq_716000093__6), c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var r__7 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_16.GetRawRoot__O()).Invoke_O__O(seq_716000093__6)
				lang.IFn_Cast(A_arbace_repr_clojure_A_const_61.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_41, nil, Lit_42, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_clojure_A_const_98.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_A_const_100.Invoke_O__O(r__7)), nil, lang.IFn_Cast(A_arbace_repr_clojure_A_const_99.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_clojure_A_const_101.Invoke_O__O(r__7), A_arbace_repr_clojure_A_const_102, Lit_43))).Ref())
//line :151:1
				seq_716000093__1, chunk_716000094__2, count_716000095__3, i_716000096__4 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_13.GetRawRoot__O()).Invoke_O__O(seq_716000093__6), nil, 0, 0; continue L1 } } }
//line :149:1
		break L1
	}


		lang.IFn_Cast(A_arbace_repr_clojure_A_const_61.GetRawRoot__O()).Invoke_O__O(Lit_44)
//line :149:1
		var seq_716000097__1 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_15.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_A_const_103.GetRawRoot__O()); var chunk_716000098__2 any; var count_716000099__3 int64 = 0; var i_716000100__4 int64 = 0; L2: for {




			if lang.Numbers_Lt_J_J__Z_NoInit(i_716000100__4, count_716000099__3) { var d__5 any = lang.Indexed_Cast(chunk_716000098__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_716000100__4)); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_61.GetRawRoot__O()); var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_41, nil, Lit_42, nil, nil); var tmp3 any = A_arbace_repr_clojure_A_const_104.Invoke_O__O(d__5); var tmp4 any
				var tmp5 any = A_arbace_repr_clojure_A_const_105
				if lang.Util_Equiv_O_O__Z_NoInit(tmp5, A_arbace_repr_clojure_A_const_106.Invoke_O__O(d__5)) { tmp4 = Lit_45 } else { tmp4 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_98.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_A_const_106.Invoke_O__O(d__5)) }
//line :155:1
				var tmp6 any = tmp4; var tmp7 *jrt.String

				if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_107.Invoke_O__O(d__5)) { tmp7 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_46, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_clojure_A_const_99.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_clojure_A_const_107.Invoke_O__O(d__5), A_arbace_repr_clojure_A_const_108, Lit_43))) } else { tmp7 = nil }
//line :155:1
				tmp1.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil, tmp6, tmp7.Ref())).Ref())
//line :154:1
				seq_716000097__1, chunk_716000098__2, count_716000099__3, i_716000100__4 = seq_716000097__1, chunk_716000098__2, count_716000099__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_716000100__4); continue L2 } else { var temp__1927000414__auto____5_2 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_15.GetRawRoot__O()).Invoke_O__O(seq_716000097__1); if jrt.J2g_Truth(temp__1927000414__auto____5_2) { var seq_716000097__6 any = temp__1927000414__auto____5_2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_A_const_44.GetRawRoot__O()).Invoke_O__O(seq_716000097__6)) { var c__1927000678__auto____7_2 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_45.GetRawRoot__O()).Invoke_O__O(seq_716000097__6); seq_716000097__1, chunk_716000098__2, count_716000099__3, i_716000100__4 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_52.GetRawRoot__O()).Invoke_O__O(seq_716000097__6), c__1927000678__auto____7_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var d__7 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_16.GetRawRoot__O()).Invoke_O__O(seq_716000097__6); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_61.GetRawRoot__O()); var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_41, nil, Lit_42, nil, nil); var tmp10 any = A_arbace_repr_clojure_A_const_104.Invoke_O__O(d__7); var tmp11 any
					var tmp12 any = A_arbace_repr_clojure_A_const_105
					if lang.Util_Equiv_O_O__Z_NoInit(tmp12, A_arbace_repr_clojure_A_const_106.Invoke_O__O(d__7)) { tmp11 = Lit_45 } else { tmp11 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_98.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_A_const_106.Invoke_O__O(d__7)) }
//line :155:1
					var tmp13 any = tmp11; var tmp14 *jrt.String

					if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_107.Invoke_O__O(d__7)) { tmp14 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_46, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_clojure_A_const_99.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_clojure_A_const_107.Invoke_O__O(d__7), A_arbace_repr_clojure_A_const_108, Lit_43))) } else { tmp14 = nil }
//line :155:1
					tmp8.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp10, nil, tmp13, tmp14.Ref())).Ref())
//line :154:1
					seq_716000097__1, chunk_716000098__2, count_716000099__3, i_716000100__4 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_13.GetRawRoot__O()).Invoke_O__O(seq_716000097__6), nil, 0, 0; continue L2 } } else { return nil } } } }
//line :149:1
	panic("j2g: unreachable")
}








func A_arbace_repr_clojure__main_A_New() *A_arbace_repr_clojure__main_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure__main_A{}; t.Ctor(); return t }
//line :159:1
func (t *A_arbace_repr_clojure__main_A) Ctor() {}
//line :159:1
func (t *A_arbace_repr_clojure__main_A) DoInvoke_O_O__O(self, args__0 any) any { var vec__716000102__2 any = args__0; var seq__716000103__3 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_15.GetRawRoot__O()).Invoke_O__O(vec__716000102__2); var first__716000104__4 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_16.GetRawRoot__O()).Invoke_O__O(seq__716000103__3); var seq__716000103__5 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_13.GetRawRoot__O()).Invoke_O__O(seq__716000103__3); var cmd__6 any = first__716000104__4; var args__7 any = seq__716000103__5; var ___8 any; _ = ___8; if

	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_A_const_82.GetRawRoot__O()).Invoke_O_O__O(cmd__6, Lit_1)) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_72.GetRawRoot__O()); var tmp2 any = A_arbace_repr_clojure_A_const_73; lang.IFn_Cast(A_arbace_repr_clojure_A_const_71.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, A_arbace_repr_clojure_A_const_74.Get__O())); var tmp3 any = A_arbace_repr_clojure__main_fn__716000105_A_New(); var tmp4 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_repr_clojure__main_fn__716000105_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_repr_clojure__main_fn__716000105_A_fn_class = fncls__19d; tmp4 = fncls__19d } else { tmp4 = fncls__19 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()
		jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2)); ___8 = nil } else {
//line :161:1
			___8 = nil }; var o__9 any = /*line :159:1*/lang.IFn_Cast(A_arbace_repr_clojure_A_const_109.GetRawRoot__O()).Invoke_O__O(args__7); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_94.GetRawRoot__O()); var tmp6 any = A_arbace_repr_clojure_A_const_100; var known__10 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_59.GetRawRoot__O()).Invoke_O__O(tmp5.Invoke_O_O__O(tmp6, A_arbace_repr_clojure_A_const_97.GetRawRoot__O())); var temp__1927000414__auto____11 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_A_const_116.GetRawRoot__O()).Invoke_O_O__O(known__10, A_arbace_repr_clojure_A_const_29.Invoke_O__O(o__9))); if






	jrt.J2g_Truth(temp__1927000414__auto____11) { var bad__12 any = temp__1927000414__auto____11; panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_repr_clojure_A_const_86.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_3, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_clojure_A_const_117.GetRawRoot__O()).Invoke_O_O__O(Lit_4, lang.IFn_Cast(A_arbace_repr_clojure_A_const_94.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_clojure_A_const_98.GetRawRoot__O(), bad__12)))).Ref(), lang.PersistentArrayMap_EMPTY.Ref())))) }; if

	jrt.J2g_Truth(A_arbace_repr_clojure_A_const_90.Invoke_O__O(o__9)) {
		return lang.IFn_Cast(A_arbace_repr_clojure_A_const_110.GetRawRoot__O()).Invoke__O() } else {
//line :168:1
			if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_89.Invoke_O__O(o__9)) { var tmp7 any = A_arbace_repr_clojure_A_const_21; var tmp8 any = A_arbace_repr_clojure_A_const_21.Invoke_O__O(o__9); var tmp9 any = A_arbace_repr_clojure_A_const_24; var p__11 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8, tmp9, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(A_arbace_repr_clojure_A_const_91.Invoke_O__O(o__9))).Ref()))


				lang.IFn_Cast(A_arbace_repr_clojure_A_const_118.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_A_const_66.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_repr_clojure_A_const_65.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_A_const_119.Get__O()), p__11, Lit_5, A_arbace_repr_clojure_A_const_29.Invoke_O__O(o__9)))
				return lang.IFn_Cast(A_arbace_repr_clojure_A_const_111.GetRawRoot__O()).Invoke__O() } else {
//line :168:1
					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_A_const_84.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_A_const_83.Invoke_O__O(o__9))) {





						var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_72.GetRawRoot__O()); var tmp11 any = A_arbace_repr_clojure_A_const_73; lang.IFn_Cast(A_arbace_repr_clojure_A_const_71.GetRawRoot__O()).Invoke_O__O(tmp10.Invoke_O_O__O(tmp11, A_arbace_repr_clojure_A_const_74.Get__O())); var tmp12 any = A_arbace_repr_clojure__main_fn__716000107_A_New(); var tmp13 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_repr_clojure__main_fn__716000107_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_repr_clojure__main_fn__716000107_A_fn_class = fncls__20d; tmp13 = fncls__20d } else { tmp13 = fncls__20 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil).Invoke__O()
						jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2)); return nil } else {
//line :168:1
							var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_112.GetRawRoot__O()); var tmp15 any; var or__1927000174__auto____11 any = A_arbace_repr_clojure_A_const_25.Invoke_O__O(o__9)







							if jrt.J2g_Truth(or__1927000174__auto____11) { tmp15 = or__1927000174__auto____11 } else { tmp15 = A_arbace_repr_clojure_A_const_88.Invoke_O__O(o__9) }
//line :168:1
							if jrt.J2g_Truth(tmp14.Invoke_O__O(tmp15)) {








								var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_72.GetRawRoot__O()); var tmp17 any = A_arbace_repr_clojure_A_const_73; lang.IFn_Cast(A_arbace_repr_clojure_A_const_71.GetRawRoot__O()).Invoke_O__O(tmp16.Invoke_O_O__O(tmp17, A_arbace_repr_clojure_A_const_74.Get__O())); var tmp18 any = A_arbace_repr_clojure__main_fn__716000109_A_New(); var tmp19 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_repr_clojure__main_fn__716000109_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_repr_clojure__main_fn__716000109_A_fn_class = fncls__21d; tmp19 = fncls__21d } else { tmp19 = fncls__21 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil).Invoke__O(); jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2)); return nil } else {
//line :168:1
									if A_arbace_repr_clojure_A_const_30 != nil { var s__11 any; var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_113.GetRawRoot__O()); var tmp21 any = A_arbace_repr_clojure_A_const_83.Invoke_O__O(o__9); var tmp22 any










										if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_88.Invoke_O__O(o__9)) { tmp22 = nil } else { tmp22 = A_arbace_repr_clojure_A_const_25.Invoke_O__O(o__9) }; s__11 = tmp20.Invoke_O_O_O__O(tmp21, tmp22, o__9)
										if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_92.Invoke_O__O(o__9)) { } else {
											var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_72.GetRawRoot__O()); var tmp24 any = A_arbace_repr_clojure_A_const_73; lang.IFn_Cast(A_arbace_repr_clojure_A_const_71.GetRawRoot__O()).Invoke_O__O(tmp23.Invoke_O_O__O(tmp24, A_arbace_repr_clojure_A_const_74.Get__O())); var tmp25 any = A_arbace_repr_clojure__main_fn__716000111_A_New_O(s__11); var tmp26 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_repr_clojure__main_fn__716000111_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_repr_clojure__main_fn__716000111_A_fn_class = fncls__22d; tmp26 = fncls__22d } else { tmp26 = fncls__22 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil).Invoke__O()
										}

										var tmp27 bool; var na_17 any = A_arbace_repr_clojure_A_const_69.Invoke_O__O(s__11); if jrt.Long_InstanceOf(na_17) { var n0_18 int64 = jrt.NN(jrt.Long_Cast(na_17)).LongValue__J(); tmp27 = n0_18 > 0 } else { if jrt.Double_InstanceOf(na_17) { var n0_18_2 float64 = jrt.NN(jrt.Double_Cast(na_17)).DoubleValue__D(); tmp27 = n0_18_2 > 0.0 } else { tmp27 = lang.Numbers_IsPos_O__Z_NoInit(na_17) } }; if tmp27 { jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(1)); return nil } else { return nil } } else {
//line :168:1
											return nil } } } } } }
//line :162:1
func A_arbace_repr_clojure__main_fn__716000105_A_New() *A_arbace_repr_clojure__main_fn__716000105_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure__main_fn__716000105_A{}; t.Ctor(); return t }
//line :162:1
func (t *A_arbace_repr_clojure__main_fn__716000105_A) Ctor() {}
//line :162:1
func (t *A_arbace_repr_clojure__main_fn__716000105_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 *lang.Keyword = A_arbace_repr_clojure_A_const_101; tmp1 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_61.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(lang.IFn_Cast(A_arbace_repr_clojure_A_const_114.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_A_const_115)))) }; return nil }(); lang.IFn_Cast(A_arbace_repr_clojure_A_const_62.GetRawRoot__O()).Invoke__O(); if tmp3 != nil { panic(tmp3) }; return tmp1 }











func A_arbace_repr_clojure__main_fn__716000107_A_New() *A_arbace_repr_clojure__main_fn__716000107_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure__main_fn__716000107_A{}; t.Ctor(); return t }
//line :174:1
func (t *A_arbace_repr_clojure__main_fn__716000107_A) Ctor() {}
//line :174:1
func (t *A_arbace_repr_clojure__main_fn__716000107_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 *lang.Keyword = A_arbace_repr_clojure_A_const_101; tmp1 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_61.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(lang.IFn_Cast(A_arbace_repr_clojure_A_const_114.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_A_const_120)))) }; return nil }(); lang.IFn_Cast(A_arbace_repr_clojure_A_const_62.GetRawRoot__O()).Invoke__O(); if tmp3 != nil { panic(tmp3) }; return tmp1 }


func A_arbace_repr_clojure__main_fn__716000109_A_New() *A_arbace_repr_clojure__main_fn__716000109_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure__main_fn__716000109_A{}; t.Ctor(); return t }
//line :177:1
func (t *A_arbace_repr_clojure__main_fn__716000109_A) Ctor() {}
//line :177:1
func (t *A_arbace_repr_clojure__main_fn__716000109_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_61.GetRawRoot__O()).Invoke_O__O(Lit_9); return nil }(); lang.IFn_Cast(A_arbace_repr_clojure_A_const_62.GetRawRoot__O()).Invoke__O(); if tmp2 != nil { panic(tmp2) }; return tmp1 }



func A_arbace_repr_clojure__main_fn__716000111_A_New_O(p0 any) *A_arbace_repr_clojure__main_fn__716000111_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure__main_fn__716000111_A{}; t.Ctor_O(p0); return t }
//line :181:1
func (t *A_arbace_repr_clojure__main_fn__716000111_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :181:1
func (t *A_arbace_repr_clojure__main_fn__716000111_A) Invoke_O__O(self any) any { var tmp1 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_61.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_121.GetRawRoot__O()); var tmp4 any = A_arbace_repr_clojure_A_const_81.Invoke_O__O(t.F_s); var tmp5 any = A_arbace_repr_clojure_A_const_24.Invoke_O__O(t.F_s); var tmp6 any = A_arbace_repr_clojure_A_const_80.Invoke_O__O(t.F_s); var tmp7 any = A_arbace_repr_clojure_A_const_79.Invoke_O__O(t.F_s); var tmp8 any = A_arbace_repr_clojure_A_const_76.Invoke_O__O(t.F_s); var tmp9 *lang.Keyword = A_arbace_repr_clojure_A_const_69; var tmp10 any; var t_ any = t.F_s
											t.F_s = nil; tmp10 = t_
//line :182:1
		tmp1 = tmp2.Invoke_O__O(tmp3.Invoke_O_O_O_O_O_O_O__O(Lit_10, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9.Invoke_O__O(tmp10))) }
//line :181:1
	return nil }(); lang.IFn_Cast(A_arbace_repr_clojure_A_const_62.GetRawRoot__O()).Invoke__O(); if tmp11 != nil { panic(tmp11) }; return tmp1 }













































type A_arbace_repr_clojure_A struct{ jrt.Object }

var A_arbace_repr_clojure_A_const_pool *jrt.RefArray

var A_arbace_repr_clojure_A_const_0 *lang.Var

var A_arbace_repr_clojure_A_const_1 *lang.Var

var A_arbace_repr_clojure_A_const_2 any

var A_arbace_repr_clojure_A_const_3 any

var A_arbace_repr_clojure_A_const_4 any

var A_arbace_repr_clojure_A_const_5 any

var A_arbace_repr_clojure_A_const_6 *lang.Var

var A_arbace_repr_clojure_A_const_7 *lang.Var

var A_arbace_repr_clojure_A_const_8 *lang.Var

var A_arbace_repr_clojure_A_const_9 any

var A_arbace_repr_clojure_A_const_10 *lang.Var

var A_arbace_repr_clojure_A_const_11 *lang.Var

var A_arbace_repr_clojure_A_const_12 any

var A_arbace_repr_clojure_A_const_13 *lang.Var

var A_arbace_repr_clojure_A_const_14 *lang.Var

var A_arbace_repr_clojure_A_const_15 *lang.Var

var A_arbace_repr_clojure_A_const_16 *lang.Var

var A_arbace_repr_clojure_A_const_17 *lang.Keyword

var A_arbace_repr_clojure_A_const_18 *lang.Keyword

var A_arbace_repr_clojure_A_const_19 *lang.Var

var A_arbace_repr_clojure_A_const_20 *lang.Var

var A_arbace_repr_clojure_A_const_21 *lang.Keyword

var A_arbace_repr_clojure_A_const_22 *lang.Keyword

var A_arbace_repr_clojure_A_const_23 *lang.Keyword

var A_arbace_repr_clojure_A_const_24 *lang.Keyword

var A_arbace_repr_clojure_A_const_25 *lang.Keyword

var A_arbace_repr_clojure_A_const_26 any

var A_arbace_repr_clojure_A_const_27 *lang.Var

var A_arbace_repr_clojure_A_const_28 *lang.Var

var A_arbace_repr_clojure_A_const_29 *lang.Keyword

var A_arbace_repr_clojure_A_const_30 *lang.Keyword

var A_arbace_repr_clojure_A_const_31 *lang.Keyword

var A_arbace_repr_clojure_A_const_32 *lang.Var

var A_arbace_repr_clojure_A_const_33 any

var A_arbace_repr_clojure_A_const_34 any

var A_arbace_repr_clojure_A_const_35 *lang.Var

var A_arbace_repr_clojure_A_const_36 any

var A_arbace_repr_clojure_A_const_37 *lang.Var

var A_arbace_repr_clojure_A_const_38 *lang.Var

var A_arbace_repr_clojure_A_const_39 *lang.Keyword

var A_arbace_repr_clojure_A_const_40 any

var A_arbace_repr_clojure_A_const_41 *lang.Keyword

var A_arbace_repr_clojure_A_const_42 *lang.Var

var A_arbace_repr_clojure_A_const_43 *lang.Var

var A_arbace_repr_clojure_A_const_44 *lang.Var

var A_arbace_repr_clojure_A_const_45 *lang.Var

var A_arbace_repr_clojure_A_const_46 *lang.Var

var A_arbace_repr_clojure_A_const_47 *lang.Var

var A_arbace_repr_clojure_A_const_48 *lang.Var

var A_arbace_repr_clojure_A_const_49 *lang.Var

var A_arbace_repr_clojure_A_const_50 *lang.Var

var A_arbace_repr_clojure_A_const_51 *lang.Var

var A_arbace_repr_clojure_A_const_52 *lang.Var

var A_arbace_repr_clojure_A_const_53 *lang.Var

var A_arbace_repr_clojure_A_const_54 *lang.Var

var A_arbace_repr_clojure_A_const_55 *lang.Var

var A_arbace_repr_clojure_A_const_56 any

var A_arbace_repr_clojure_A_const_57 *lang.Var

var A_arbace_repr_clojure_A_const_58 *lang.Var

var A_arbace_repr_clojure_A_const_59 *lang.Var

var A_arbace_repr_clojure_A_const_60 *lang.Var

var A_arbace_repr_clojure_A_const_61 *lang.Var

var A_arbace_repr_clojure_A_const_62 *lang.Var

var A_arbace_repr_clojure_A_const_63 *lang.Keyword

var A_arbace_repr_clojure_A_const_64 *lang.Var

var A_arbace_repr_clojure_A_const_65 *lang.Var

var A_arbace_repr_clojure_A_const_66 *lang.Var

var A_arbace_repr_clojure_A_const_67 *lang.Var

var A_arbace_repr_clojure_A_const_68 *lang.Var

var A_arbace_repr_clojure_A_const_69 *lang.Keyword

var A_arbace_repr_clojure_A_const_70 *lang.Var

var A_arbace_repr_clojure_A_const_71 *lang.Var

var A_arbace_repr_clojure_A_const_72 *lang.Var

var A_arbace_repr_clojure_A_const_73 *lang.Var

var A_arbace_repr_clojure_A_const_74 *lang.Var

var A_arbace_repr_clojure_A_const_75 *lang.Var

var A_arbace_repr_clojure_A_const_76 *lang.Keyword

var A_arbace_repr_clojure_A_const_77 *lang.Var

var A_arbace_repr_clojure_A_const_78 *lang.Var

var A_arbace_repr_clojure_A_const_79 *lang.Keyword

var A_arbace_repr_clojure_A_const_80 *lang.Keyword

var A_arbace_repr_clojure_A_const_81 *lang.Keyword

var A_arbace_repr_clojure_A_const_82 *lang.Var

var A_arbace_repr_clojure_A_const_83 *lang.Keyword

var A_arbace_repr_clojure_A_const_84 *lang.Var

var A_arbace_repr_clojure_A_const_85 *lang.Var

var A_arbace_repr_clojure_A_const_86 *lang.Var

var A_arbace_repr_clojure_A_const_87 *lang.Var

var A_arbace_repr_clojure_A_const_88 *lang.Keyword

var A_arbace_repr_clojure_A_const_89 *lang.Keyword

var A_arbace_repr_clojure_A_const_90 *lang.Keyword

var A_arbace_repr_clojure_A_const_91 *lang.Keyword

var A_arbace_repr_clojure_A_const_92 *lang.Keyword

var A_arbace_repr_clojure_A_const_93 *lang.Var

var A_arbace_repr_clojure_A_const_94 *lang.Var

var A_arbace_repr_clojure_A_const_95 *lang.Var

var A_arbace_repr_clojure_A_const_96 any

var A_arbace_repr_clojure_A_const_97 *lang.Var

var A_arbace_repr_clojure_A_const_98 *lang.Var

var A_arbace_repr_clojure_A_const_99 *lang.Var

var A_arbace_repr_clojure_A_const_100 *lang.Keyword

var A_arbace_repr_clojure_A_const_101 *lang.Keyword

var A_arbace_repr_clojure_A_const_102 any

var A_arbace_repr_clojure_A_const_103 *lang.Var

var A_arbace_repr_clojure_A_const_104 *lang.Keyword

var A_arbace_repr_clojure_A_const_105 *lang.Keyword

var A_arbace_repr_clojure_A_const_106 *lang.Keyword

var A_arbace_repr_clojure_A_const_107 *lang.Keyword

var A_arbace_repr_clojure_A_const_108 any

var A_arbace_repr_clojure_A_const_109 *lang.Var

var A_arbace_repr_clojure_A_const_110 *lang.Var

var A_arbace_repr_clojure_A_const_111 *lang.Var

var A_arbace_repr_clojure_A_const_112 *lang.Var

var A_arbace_repr_clojure_A_const_113 *lang.Var

var A_arbace_repr_clojure_A_const_114 *lang.Var

var A_arbace_repr_clojure_A_const_115 any

var A_arbace_repr_clojure_A_const_116 *lang.Var

var A_arbace_repr_clojure_A_const_117 *lang.Var

var A_arbace_repr_clojure_A_const_118 *lang.Var

var A_arbace_repr_clojure_A_const_119 *lang.Var

var A_arbace_repr_clojure_A_const_120 any

var A_arbace_repr_clojure_A_const_121 *lang.Var

var A_arbace_repr_clojure_A_init jrt.ClassInit

func A_arbace_repr_clojure_A_Init() { if !A_arbace_repr_clojure_A_init.Done() { A_arbace_repr_clojure_A_init.Run(A_arbace_repr_clojure_A_clinit) } }

func A_arbace_repr_clojure_A_clinit() { A_arbace_repr_clojure_A_clinit_p0(); A_arbace_repr_clojure_A_clinit_p1(); A_arbace_repr_clojure_A_clinit_p2(); A_arbace_repr_clojure_A_clinit_p3(); A_arbace_repr_clojure_A_clinit_p4(); A_arbace_repr_clojure_A_clinit_p5(); A_arbace_repr_clojure_A_clinit_p6(); A_arbace_repr_clojure_A_clinit_p7(); A_arbace_repr_clojure_A_clinit_p8(); A_arbace_repr_clojure_A_clinit_p9(); A_arbace_repr_clojure_A_clinit_p10() }

func A_arbace_repr_clojure_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_clojure_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 161); A_arbace_repr_clojure_A_const_0 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[39]); A_arbace_repr_clojure_A_const_1 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[40]); A_arbace_repr_clojure_A_const_2 = A_arbace_repr_clojure_A_const_pool.A[41]; A_arbace_repr_clojure_A_const_3 = A_arbace_repr_clojure_A_const_pool.A[42]; A_arbace_repr_clojure_A_const_4 = A_arbace_repr_clojure_A_const_pool.A[43]; A_arbace_repr_clojure_A_const_5 = A_arbace_repr_clojure_A_const_pool.A[44]; A_arbace_repr_clojure_A_const_6 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[45]); A_arbace_repr_clojure_A_const_7 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[46]); A_arbace_repr_clojure_A_const_8 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[47]); A_arbace_repr_clojure_A_const_9 = A_arbace_repr_clojure_A_const_pool.A[48]; A_arbace_repr_clojure_A_const_10 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[49]); A_arbace_repr_clojure_A_const_11 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[50]) }

func A_arbace_repr_clojure_A_clinit_p1() { A_arbace_repr_clojure_A_const_12 = A_arbace_repr_clojure_A_const_pool.A[51]; A_arbace_repr_clojure_A_const_13 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[52]); A_arbace_repr_clojure_A_const_14 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[53]); A_arbace_repr_clojure_A_const_15 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[54]); A_arbace_repr_clojure_A_const_16 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[55]); A_arbace_repr_clojure_A_const_17 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[56]); A_arbace_repr_clojure_A_const_18 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[57]); A_arbace_repr_clojure_A_const_19 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[58]); A_arbace_repr_clojure_A_const_20 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[59]); A_arbace_repr_clojure_A_const_21 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[60]); A_arbace_repr_clojure_A_const_22 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[61]); A_arbace_repr_clojure_A_const_23 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[62]) }

func A_arbace_repr_clojure_A_clinit_p2() { A_arbace_repr_clojure_A_const_24 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[63]); A_arbace_repr_clojure_A_const_25 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[64]); A_arbace_repr_clojure_A_const_26 = A_arbace_repr_clojure_A_const_pool.A[65]; A_arbace_repr_clojure_A_const_27 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[66]); A_arbace_repr_clojure_A_const_28 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[67]); A_arbace_repr_clojure_A_const_29 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[68]); A_arbace_repr_clojure_A_const_30 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[69]); A_arbace_repr_clojure_A_const_31 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[70]); A_arbace_repr_clojure_A_const_32 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[71]); A_arbace_repr_clojure_A_const_33 = A_arbace_repr_clojure_A_const_pool.A[72]; A_arbace_repr_clojure_A_const_34 = A_arbace_repr_clojure_A_const_pool.A[73]; A_arbace_repr_clojure_A_const_35 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[74]); A_arbace_repr_clojure_A_const_36 = A_arbace_repr_clojure_A_const_pool.A[75] }

func A_arbace_repr_clojure_A_clinit_p3() { A_arbace_repr_clojure_A_const_37 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[76]); A_arbace_repr_clojure_A_const_38 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[77]); A_arbace_repr_clojure_A_const_39 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[78]); A_arbace_repr_clojure_A_const_40 = A_arbace_repr_clojure_A_const_pool.A[79]; A_arbace_repr_clojure_A_const_41 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[80]); A_arbace_repr_clojure_A_const_42 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[81]); A_arbace_repr_clojure_A_const_43 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[82]); A_arbace_repr_clojure_A_const_44 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[83]); A_arbace_repr_clojure_A_const_45 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[84]); A_arbace_repr_clojure_A_const_46 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[85]); A_arbace_repr_clojure_A_const_47 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[86]); A_arbace_repr_clojure_A_const_48 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[87]) }

func A_arbace_repr_clojure_A_clinit_p4() { A_arbace_repr_clojure_A_const_49 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[88]); A_arbace_repr_clojure_A_const_50 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[89]); A_arbace_repr_clojure_A_const_51 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[90]); A_arbace_repr_clojure_A_const_52 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[91]); A_arbace_repr_clojure_A_const_53 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[92]); A_arbace_repr_clojure_A_const_54 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[93]); A_arbace_repr_clojure_A_const_55 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[94]); A_arbace_repr_clojure_A_const_56 = A_arbace_repr_clojure_A_const_pool.A[95]; A_arbace_repr_clojure_A_const_57 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[96]); A_arbace_repr_clojure_A_const_58 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[97]); A_arbace_repr_clojure_A_const_59 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[98]); A_arbace_repr_clojure_A_const_60 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[99]) }

func A_arbace_repr_clojure_A_clinit_p5() { A_arbace_repr_clojure_A_const_61 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[100]); A_arbace_repr_clojure_A_const_62 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[101]); A_arbace_repr_clojure_A_const_63 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[102]); A_arbace_repr_clojure_A_const_64 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[103]); A_arbace_repr_clojure_A_const_65 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[104]); A_arbace_repr_clojure_A_const_66 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[105]); A_arbace_repr_clojure_A_const_67 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[106]); A_arbace_repr_clojure_A_const_68 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[107]); A_arbace_repr_clojure_A_const_69 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[108]); A_arbace_repr_clojure_A_const_70 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[109]); A_arbace_repr_clojure_A_const_71 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[110]); A_arbace_repr_clojure_A_const_72 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[111]) }

func A_arbace_repr_clojure_A_clinit_p6() { A_arbace_repr_clojure_A_const_73 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[112]); A_arbace_repr_clojure_A_const_74 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[113]); A_arbace_repr_clojure_A_const_75 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[114]); A_arbace_repr_clojure_A_const_76 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[115]); A_arbace_repr_clojure_A_const_77 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[116]); A_arbace_repr_clojure_A_const_78 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[117]); A_arbace_repr_clojure_A_const_79 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[118]); A_arbace_repr_clojure_A_const_80 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[119]); A_arbace_repr_clojure_A_const_81 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[120]); A_arbace_repr_clojure_A_const_82 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[121]); A_arbace_repr_clojure_A_const_83 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[122]); A_arbace_repr_clojure_A_const_84 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[123]) }

func A_arbace_repr_clojure_A_clinit_p7() { A_arbace_repr_clojure_A_const_85 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[124]); A_arbace_repr_clojure_A_const_86 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[125]); A_arbace_repr_clojure_A_const_87 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[126]); A_arbace_repr_clojure_A_const_88 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[127]); A_arbace_repr_clojure_A_const_89 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[128]); A_arbace_repr_clojure_A_const_90 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[129]); A_arbace_repr_clojure_A_const_91 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[130]); A_arbace_repr_clojure_A_const_92 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[131]); A_arbace_repr_clojure_A_const_93 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[132]); A_arbace_repr_clojure_A_const_94 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[133]); A_arbace_repr_clojure_A_const_95 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[134]); A_arbace_repr_clojure_A_const_96 = A_arbace_repr_clojure_A_const_pool.A[135] }

func A_arbace_repr_clojure_A_clinit_p8() { A_arbace_repr_clojure_A_const_97 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[136]); A_arbace_repr_clojure_A_const_98 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[137]); A_arbace_repr_clojure_A_const_99 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[138]); A_arbace_repr_clojure_A_const_100 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[139]); A_arbace_repr_clojure_A_const_101 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[140]); A_arbace_repr_clojure_A_const_102 = A_arbace_repr_clojure_A_const_pool.A[141]; A_arbace_repr_clojure_A_const_103 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[142]); A_arbace_repr_clojure_A_const_104 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[143]); A_arbace_repr_clojure_A_const_105 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[144]); A_arbace_repr_clojure_A_const_106 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[145]); A_arbace_repr_clojure_A_const_107 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[146]); A_arbace_repr_clojure_A_const_108 = A_arbace_repr_clojure_A_const_pool.A[147] }

func A_arbace_repr_clojure_A_clinit_p9() { A_arbace_repr_clojure_A_const_109 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[148]); A_arbace_repr_clojure_A_const_110 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[149]); A_arbace_repr_clojure_A_const_111 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[150]); A_arbace_repr_clojure_A_const_112 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[151]); A_arbace_repr_clojure_A_const_113 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[152]); A_arbace_repr_clojure_A_const_114 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[153]); A_arbace_repr_clojure_A_const_115 = A_arbace_repr_clojure_A_const_pool.A[154]; A_arbace_repr_clojure_A_const_116 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[155]); A_arbace_repr_clojure_A_const_117 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[156]); A_arbace_repr_clojure_A_const_118 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[157]); A_arbace_repr_clojure_A_const_119 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[158]); A_arbace_repr_clojure_A_const_120 = A_arbace_repr_clojure_A_const_pool.A[159] }

func A_arbace_repr_clojure_A_clinit_p10() { A_arbace_repr_clojure_A_const_121 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[160]) }

func A_arbace_repr_clojure_A_New() *A_arbace_repr_clojure_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_A) Ctor() {}

func (t *A_arbace_repr_clojure_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_A_class }

func (t *A_arbace_repr_clojure_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_A); return ok }

func A_arbace_repr_clojure_A_Cast(x any) *A_arbace_repr_clojure_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_A_class)) }; return v }



type A_arbace_repr_clojure__main_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure__main_A_fn_class *jrt.Class



type A_arbace_repr_clojure__main_fn__716000105_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure__main_fn__716000105_A_fn_class *jrt.Class



type A_arbace_repr_clojure__main_fn__716000107_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure__main_fn__716000107_A_fn_class *jrt.Class



type A_arbace_repr_clojure__main_fn__716000109_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure__main_fn__716000109_A_fn_class *jrt.Class



type A_arbace_repr_clojure__main_fn__716000111_A struct{ j2g_header uint64; F_s any }

var A_arbace_repr_clojure__main_fn__716000111_A_fn_class *jrt.Class



type A_arbace_repr_clojure_base_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_base_A_fn_class *jrt.Class



type A_arbace_repr_clojure_eval716000004_A struct{ jrt.Object }

func A_arbace_repr_clojure_eval716000004_A_New() *A_arbace_repr_clojure_eval716000004_A { t := &A_arbace_repr_clojure_eval716000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_eval716000004_A) Ctor() {}

func (t *A_arbace_repr_clojure_eval716000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_eval716000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_eval716000004_A_class }

func (t *A_arbace_repr_clojure_eval716000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_eval716000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_eval716000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_eval716000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_eval716000004_A); return ok }

func A_arbace_repr_clojure_eval716000004_A_Cast(x any) *A_arbace_repr_clojure_eval716000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_eval716000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_eval716000004_A_class)) }; return v }



type A_arbace_repr_clojure_eval716000004_loading__1927001464__auto____716000005_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_eval716000004_loading__1927001464__auto____716000005_A_fn_class *jrt.Class



type A_arbace_repr_clojure_eval716000008_A struct{ jrt.Object }

func A_arbace_repr_clojure_eval716000008_A_New() *A_arbace_repr_clojure_eval716000008_A { t := &A_arbace_repr_clojure_eval716000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_eval716000008_A) Ctor() {}

func (t *A_arbace_repr_clojure_eval716000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_eval716000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_eval716000008_A_class }

func (t *A_arbace_repr_clojure_eval716000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_eval716000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_eval716000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_eval716000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_eval716000008_A); return ok }

func A_arbace_repr_clojure_eval716000008_A_Cast(x any) *A_arbace_repr_clojure_eval716000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_eval716000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_eval716000008_A_class)) }; return v }



type A_arbace_repr_clojure_eval716000008_fn__716000009_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_eval716000008_fn__716000009_A_fn_class *jrt.Class



type A_arbace_repr_clojure_ext_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_ext_A_fn_class *jrt.Class



type A_arbace_repr_clojure_files_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_files_A_fn_class *jrt.Class



type A_arbace_repr_clojure_files_iter__716000022__716000026_A struct{ j2g_header uint64; F_root, F_src any }

var A_arbace_repr_clojure_files_iter__716000022__716000026_A_fn_class *jrt.Class



type A_arbace_repr_clojure_files_iter__716000022__716000026_fn__716000027_A struct{ j2g_header uint64; F_root, F_src, F_iter__716000022, F_s__716000023 any }

var A_arbace_repr_clojure_files_iter__716000022__716000026_fn__716000027_A_fn_class *jrt.Class



type A_arbace_repr_clojure_files_iter__716000022__716000026_fn__716000027_fn__716000028_A struct{ j2g_header uint64; F_root, F_src, F_b__716000025 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_clojure_files_iter__716000022__716000026_fn__716000027_fn__716000028_A_fn_class *jrt.Class



type A_arbace_repr_clojure_parse_args_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_parse_args_A_fn_class *jrt.Class



type A_arbace_repr_clojure_plan_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_plan_A_fn_class *jrt.Class



type A_arbace_repr_clojure_plan_fn__716000018_A struct{ j2g_header uint64; F_name any }

var A_arbace_repr_clojure_plan_fn__716000018_A_fn_class *jrt.Class



type A_arbace_repr_clojure_print_rules_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_print_rules_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_run_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000048_A struct{ j2g_header uint64; F_f, F_p any }

var A_arbace_repr_clojure_run_fn__716000048_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000050_A struct{ j2g_header uint64; F_f, F_stats, F_p, F_skip, F_s any }

var A_arbace_repr_clojure_run_fn__716000050_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000050_fn__716000051_A struct{ j2g_header uint64; F_e, F_f any }

var A_arbace_repr_clojure_run_fn__716000050_fn__716000051_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000057_A struct{ j2g_header uint64; F_f, F_p any }

var A_arbace_repr_clojure_run_fn__716000057_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000059_A struct{ j2g_header uint64; F_f, F_p, F_s, F_stats, F_skip any }

var A_arbace_repr_clojure_run_fn__716000059_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000059_fn__716000060_A struct{ j2g_header uint64; F_e, F_f any }

var A_arbace_repr_clojure_run_fn__716000059_fn__716000060_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000066_A struct{ j2g_header uint64; F_f, F_p any }

var A_arbace_repr_clojure_run_fn__716000066_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000068_A struct{ j2g_header uint64; F_f, F_p, F_s, F_stats, F_skip any }

var A_arbace_repr_clojure_run_fn__716000068_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000068_fn__716000069_A struct{ j2g_header uint64; F_e, F_f any }

var A_arbace_repr_clojure_run_fn__716000068_fn__716000069_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000075_A struct{ j2g_header uint64; F_f, F_p any }

var A_arbace_repr_clojure_run_fn__716000075_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000077_A struct{ j2g_header uint64; F_f, F_p, F_s, F_stats, F_skip any }

var A_arbace_repr_clojure_run_fn__716000077_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000077_fn__716000078_A struct{ j2g_header uint64; F_e, F_f any }

var A_arbace_repr_clojure_run_fn__716000077_fn__716000078_A_fn_class *jrt.Class



type A_arbace_repr_clojure_translate_text_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_translate_text_A_fn_class *jrt.Class
