//line aot_arbace_repr_clojure.ae:1
package aot_arbace_repr_clojure

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_java_io"
	"arbace/aot_arbace_repr_clojure_rules"
	"arbace/aot_arbace_repr_clojure_text"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_clojure_eval716000004_loading__1927001464__auto____716000005_A_New() *A_arbace_repr_clojure_eval716000004_loading__1927001464__auto____716000005_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_eval716000004_loading__1927001464__auto____716000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_clojure_eval716000004_loading__1927001464__auto____716000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_clojure_eval716000004_loading__1927001464__auto____716000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_clojure_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_A_const_1); lang.IFn_Cast(A_arbace_repr_clojure_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_repr_clojure_A_const_3, A_arbace_repr_clojure_A_const_4, A_arbace_repr_clojure_A_const_5, A_arbace_repr_clojure_A_const_6); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_13)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_repr_clojure_eval716000008_fn__716000009_A_New() *A_arbace_repr_clojure_eval716000008_fn__716000009_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_eval716000008_fn__716000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_clojure_eval716000008_fn__716000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_clojure_eval716000008_fn__716000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_7.GetRawRoot__O()); var tmp2 any; var root_18 any = A_arbace_repr_clojure_A_const_8.GetRawRoot__O(); var linked_19 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_18, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_20 lang.IFn; if linked_19 == nil { ifn_20 = lang.IFn_Cast(root_18) } else { ifn_20 = nil }; var arg_21 any = A_arbace_repr_clojure_A_const_9; if linked_19 == nil { tmp2 = ifn_20.Invoke_O__O(arg_21) } else { tmp2 = linked_19.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_18, arg_21) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_repr_clojure_A_const_10.GetRawRoot__O(), A_arbace_repr_clojure_A_const_11) }


























































func A_arbace_repr_clojure_ext_A_New() *A_arbace_repr_clojure_ext_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_ext_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_repr_clojure_ext_A) Ctor() {}
//line :60:1
func (t *A_arbace_repr_clojure_ext_A) Invoke_O_O__O(self, name__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(name__0)).LastIndexOf_String__I(Lit_12); if
										lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return Lit_14 } else { var root_22 any = A_arbace_repr_clojure_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = name__0; var arg_26 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref(); if linked_23 == nil { return ifn_24.Invoke_O_O__O(arg_25, arg_26) } else { return linked_23.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_22, arg_25, arg_26) } } }

func A_arbace_repr_clojure_base_A_New() *A_arbace_repr_clojure_base_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_base_A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_repr_clojure_base_A) Ctor() {}
//line :63:1
func (t *A_arbace_repr_clojure_base_A) Invoke_O_O__O(self, name__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(name__0)).LastIndexOf_String__I(Lit_12); if
										lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return name__0 } else { var root_27 any = A_arbace_repr_clojure_A_const_12.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = name__0; var arg_31 any = A_arbace_repr_clojure_A_const_13; var arg_32 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref(); if linked_28 == nil { return ifn_29.Invoke_O_O_O__O(arg_30, arg_31, arg_32) } else { return linked_28.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_27, arg_30, arg_31, arg_32) } } }

func A_arbace_repr_clojure_plan_A_New() *A_arbace_repr_clojure_plan_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_plan_A{}; t.Ctor(); return t }
//line :66:1
func (t *A_arbace_repr_clojure_plan_A) Ctor() {}
//line :66:1
func (t *A_arbace_repr_clojure_plan_A) Invoke_O_O_O_O__O(self, name__0, siblings__1, p__716000015__2 any) any { var map__716000016__4 any = p__716000015__2; var map__716000016__5 any; if lang.ISeq_InstanceOf(map__716000016__4) { var tmp1 any; var root_33 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_34 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_33, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_35 lang.IFn; if linked_34 == nil { ifn_35 = lang.IFn_Cast(root_33) } else { ifn_35 = nil }; var arg_36 any = map__716000016__4; if linked_34 == nil { tmp1 = ifn_35.Invoke_O__O(arg_36) } else { tmp1 = linked_34.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_33, arg_36) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_37 any = A_arbace_repr_clojure_A_const_15.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_37, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_39 lang.IFn; if linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any = map__716000016__4; if linked_38 == nil { tmp2 = ifn_39.Invoke_O__O(arg_40) } else { tmp2 = linked_38.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_37, arg_40) }; map__716000016__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_41 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = map__716000016__4; if linked_42 == nil { tmp3 = ifn_43.Invoke_O__O(arg_44) } else { tmp3 = linked_42.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_41, arg_44) }; if jrt.J2g_Truth(tmp3) { var root_45 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any = map__716000016__4; if linked_46 == nil { map__716000016__5 = ifn_47.Invoke_O__O(arg_48) } else { map__716000016__5 = linked_46.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_45, arg_48) } } else { map__716000016__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__716000016__5 = map__716000016__4 }; var keep_ext__6 any = lang.RT_Get_O_O__O_NoInit(map__716000016__5, A_arbace_repr_clojure_A_const_18); var text__7 any = lang.RT_Get_O_O__O_NoInit(map__716000016__5, A_arbace_repr_clojure_A_const_19); var full__8 any = lang.RT_Get_O_O__O_NoInit(map__716000016__5, A_arbace_repr_clojure_A_const_20); var e__9 any; var root_49 any = A_arbace_repr_clojure_A_const_21.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, A_arbace_repr_clojure_ext_A_fn_class); var ifn_51 lang.IFn; if





	linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = name__0; if linked_50 == nil { e__9 = ifn_51.Invoke_O__O(arg_52) } else { e__9 = linked_50.(*A_arbace_repr_clojure_ext_A).Invoke_O_O__O(root_49, arg_52) }; var p__10 any; var tmp4 any; var root_53 any = /*line :66:1*/A_arbace_repr_clojure_A_const_22.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_55 lang.IFn; if







	linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = A_arbace_repr_clojure_A_const_23.GetRawRoot__O(); var arg_57 any = name__0; if linked_54 == nil { tmp4 = ifn_55.Invoke_O_O__O(arg_56, arg_57) } else { tmp4 = linked_54.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_53, arg_56, arg_57) }; if /*line :73:1*/ jrt.J2g_Truth(tmp4) { var tmp5 any = A_arbace_repr_clojure_A_const_24; var tmp6 *lang.Keyword
		if lang.Util_Equiv_O_O__Z_NoInit(e__9, Lit_47) { tmp6 = A_arbace_repr_clojure_A_const_25 } else { tmp6 = A_arbace_repr_clojure_A_const_26 }
//line :73:1
		p__10 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6.Ref(), A_arbace_repr_clojure_A_const_27, jrt.Boolean_FALSE.Ref(), A_arbace_repr_clojure_A_const_28, name__0)) } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_A_const_29).Invoke_O__O(e__9)) {


			if jrt.J2g_Truth(keep_ext__6) { var tmp7 any = A_arbace_repr_clojure_A_const_24; var tmp8 any; var root_58 any = A_arbace_repr_clojure_A_const_30.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_58, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_60 lang.IFn
				if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any; var root_62 any = A_arbace_repr_clojure_A_const_12.GetRawRoot__O(); var linked_63 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_62, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_64 lang.IFn; if linked_63 == nil { ifn_64 = lang.IFn_Cast(root_62) } else { ifn_64 = nil }; var arg_65 any = e__9; var arg_66 any = A_arbace_repr_clojure_A_const_31; if linked_63 == nil { arg_61 = ifn_64.Invoke_O_O__O(arg_65, arg_66) } else { arg_61 = linked_63.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_62, arg_65, arg_66) }; if linked_59 == nil { tmp8 = ifn_60.Invoke_O__O(arg_61) } else { tmp8 = linked_59.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_58, arg_61) }
//line :76:1
				p__10 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8, A_arbace_repr_clojure_A_const_27, jrt.Boolean_FALSE.Ref(), A_arbace_repr_clojure_A_const_28, name__0)) } else { var tmp9 any; var root_67 any = A_arbace_repr_clojure_A_const_32.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, A_arbace_repr_clojure_base_A_fn_class); var ifn_69 lang.IFn



					if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any = name__0; if linked_68 == nil { tmp9 = ifn_69.Invoke_O__O(arg_70) } else { tmp9 = linked_68.(*A_arbace_repr_clojure_base_A).Invoke_O_O__O(root_67, arg_70) }
//line :76:1
					if lang.Util_Equiv_O_O__Z_NoInit(Lit_48, tmp9) {




						var tmp10 any; var or__1927000174__auto____10 any; var root_71 any = A_arbace_repr_clojure_A_const_22.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_73 lang.IFn; if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = siblings__1; var arg_75 any = Lit_49; if linked_72 == nil { or__1927000174__auto____10 = ifn_73.Invoke_O_O__O(arg_74, arg_75) } else { or__1927000174__auto____10 = linked_72.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_71, arg_74, arg_75) }; if jrt.J2g_Truth(or__1927000174__auto____10) { tmp10 = or__1927000174__auto____10 } else { var and__1927000168__auto____11 bool = lang.Util_Equiv_O_O__Z_NoInit(e__9, Lit_47)
							if and__1927000168__auto____11 { var root_76 any = A_arbace_repr_clojure_A_const_22.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var arg_79 any = siblings__1; var arg_80 any = Lit_50; if linked_77 == nil { tmp10 = ifn_78.Invoke_O_O__O(arg_79, arg_80) } else { tmp10 = linked_77.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_76, arg_79, arg_80) } } else { tmp10 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11).Ref() } }
//line :81:1
						if jrt.J2g_Truth(tmp10) { var tmp11 any = A_arbace_repr_clojure_A_const_24; var tmp12 any; var root_81 any = A_arbace_repr_clojure_A_const_30.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_83 lang.IFn

							if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any; var root_85 any = A_arbace_repr_clojure_A_const_12.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = e__9; var arg_89 any = A_arbace_repr_clojure_A_const_31; if linked_86 == nil { arg_84 = ifn_87.Invoke_O_O__O(arg_88, arg_89) } else { arg_84 = linked_86.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_85, arg_88, arg_89) }; if linked_82 == nil { tmp12 = ifn_83.Invoke_O__O(arg_84) } else { tmp12 = linked_82.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_81, arg_84) }
//line :81:1
							p__10 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp11, tmp12, A_arbace_repr_clojure_A_const_27, jrt.Boolean_FALSE.Ref(), A_arbace_repr_clojure_A_const_28, name__0)) } else { var tmp13 any = A_arbace_repr_clojure_A_const_24; var tmp14 any; var root_90 any = A_arbace_repr_clojure_A_const_30.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_92 lang.IFn


								if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any; var root_94 any = A_arbace_repr_clojure_A_const_12.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any = e__9; var arg_98 any = A_arbace_repr_clojure_A_const_31; if linked_95 == nil { arg_93 = ifn_96.Invoke_O_O__O(arg_97, arg_98) } else { arg_93 = linked_95.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_94, arg_97, arg_98) }; if linked_91 == nil { tmp14 = ifn_92.Invoke_O__O(arg_93) } else { tmp14 = linked_91.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_90, arg_93) }
//line :81:1
								p__10 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp14, A_arbace_repr_clojure_A_const_27, jrt.Boolean_TRUE.Ref(), A_arbace_repr_clojure_A_const_28, Lit_49)) } } else {
//line :76:1
									var tmp15 any; var root_99 any = A_arbace_repr_clojure_A_const_22.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_101 lang.IFn








									if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any = siblings__1; var arg_103 any; var tmp16 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_51); var tmp17 any; var root_104 any = A_arbace_repr_clojure_A_const_32.GetRawRoot__O(); var linked_105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_104, A_arbace_repr_clojure_base_A_fn_class); var ifn_106 lang.IFn; if linked_105 == nil { ifn_106 = lang.IFn_Cast(root_104) } else { ifn_106 = nil }; var arg_107 any = name__0; if linked_105 == nil { tmp17 = ifn_106.Invoke_O__O(arg_107) } else { tmp17 = linked_105.(*A_arbace_repr_clojure_base_A).Invoke_O_O__O(root_104, arg_107) }; arg_103 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp16, jrt.RefArrayOf(jrt.Object_class, tmp17, nil)).Ref(); if linked_100 == nil { tmp15 = ifn_101.Invoke_O_O__O(arg_102, arg_103) } else { tmp15 = linked_100.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_99, arg_102, arg_103) }
//line :76:1
									if jrt.J2g_Truth(tmp15) { var tmp18 any = A_arbace_repr_clojure_A_const_33; var tmp19 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_52); var tmp20 any; var root_108 any = A_arbace_repr_clojure_A_const_32.GetRawRoot__O(); var linked_109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_108, A_arbace_repr_clojure_base_A_fn_class); var ifn_110 lang.IFn









										if linked_109 == nil { ifn_110 = lang.IFn_Cast(root_108) } else { ifn_110 = nil }; var arg_111 any = name__0; if linked_109 == nil { tmp20 = ifn_110.Invoke_O__O(arg_111) } else { tmp20 = linked_109.(*A_arbace_repr_clojure_base_A).Invoke_O_O__O(root_108, arg_111) }
//line :76:1
										p__10 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp18, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp19, jrt.RefArrayOf(jrt.Object_class, tmp20, nil)).Ref())) } else { var tmp21 any; var and__1927000168__auto____10 bool = lang.Util_Equiv_O_O__Z_NoInit(e__9, Lit_47)










											if and__1927000168__auto____10 { var root_112 any = A_arbace_repr_clojure_A_const_22.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = siblings__1; var arg_116 any; var tmp22 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_53); var tmp23 any; var root_117 any = A_arbace_repr_clojure_A_const_32.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_117, A_arbace_repr_clojure_base_A_fn_class); var ifn_119 lang.IFn; if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = name__0; if linked_118 == nil { tmp23 = ifn_119.Invoke_O__O(arg_120) } else { tmp23 = linked_118.(*A_arbace_repr_clojure_base_A).Invoke_O_O__O(root_117, arg_120) }; arg_116 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp22, jrt.RefArrayOf(jrt.Object_class, tmp23, nil)).Ref(); if linked_113 == nil { tmp21 = ifn_114.Invoke_O_O__O(arg_115, arg_116) } else { tmp21 = linked_113.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_112, arg_115, arg_116) } } else { tmp21 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10).Ref() }
//line :76:1
											if jrt.J2g_Truth(tmp21) { var tmp24 any = A_arbace_repr_clojure_A_const_33; var tmp25 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_54); var tmp26 any; var root_121 any = A_arbace_repr_clojure_A_const_32.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, A_arbace_repr_clojure_base_A_fn_class); var ifn_123 lang.IFn











												if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = name__0; if linked_122 == nil { tmp26 = ifn_123.Invoke_O__O(arg_124) } else { tmp26 = linked_122.(*A_arbace_repr_clojure_base_A).Invoke_O_O__O(root_121, arg_124) }
//line :76:1
												p__10 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp24, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp25, jrt.RefArrayOf(jrt.Object_class, tmp26, nil)).Ref())) } else { if A_arbace_repr_clojure_A_const_34 != nil { var tmp27 any = A_arbace_repr_clojure_A_const_24; var tmp28 any; var root_125 any = A_arbace_repr_clojure_A_const_30.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_125, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_127 lang.IFn












													if linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; var arg_128 any; var root_129 any = A_arbace_repr_clojure_A_const_12.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_129, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any = e__9; var arg_133 any = A_arbace_repr_clojure_A_const_31; if linked_130 == nil { arg_128 = ifn_131.Invoke_O_O__O(arg_132, arg_133) } else { arg_128 = linked_130.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_129, arg_132, arg_133) }; if linked_126 == nil { tmp28 = ifn_127.Invoke_O__O(arg_128) } else { tmp28 = linked_126.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_125, arg_128) }
//line :76:1
													var tmp29 any = tmp28; var tmp30 any = A_arbace_repr_clojure_A_const_27; var tmp31 any = jrt.Boolean_TRUE.Ref(); var tmp32 any = A_arbace_repr_clojure_A_const_28; var tmp33 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_51); var tmp34 any; var root_134 any = A_arbace_repr_clojure_A_const_32.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, A_arbace_repr_clojure_base_A_fn_class); var ifn_136 lang.IFn












													if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any = name__0; if linked_135 == nil { tmp34 = ifn_136.Invoke_O__O(arg_137) } else { tmp34 = linked_135.(*A_arbace_repr_clojure_base_A).Invoke_O_O__O(root_134, arg_137) }
//line :76:1
													p__10 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp27, tmp29, tmp30, tmp31, tmp32, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp33, jrt.RefArrayOf(jrt.Object_class, tmp34, nil)).Ref())) } else { p__10 = nil } } } } } } else {
//line :73:1
														if lang.Util_Equiv_O_O__Z_NoInit(e__9, Lit_55) { p__10 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_24, A_arbace_repr_clojure_A_const_35, A_arbace_repr_clojure_A_const_27, jrt.Boolean_FALSE.Ref(), A_arbace_repr_clojure_A_const_28, name__0)) } else { var tmp35 any; var root_138 any = A_arbace_repr_clojure_A_const_36.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_140 lang.IFn

















															if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any; var fnbody__149 any = A_arbace_repr_clojure_plan_fn__716000018_A_New_O(name__0); var tmp36 *jrt.Class; var fncls__148 *jrt.Class = A_arbace_repr_clojure_plan_fn__716000018_A_fn_class; if fncls__148 == nil { var fncls__148d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_56, false, fnbody__149); A_arbace_repr_clojure_plan_fn__716000018_A_fn_class = fncls__148d; tmp36 = fncls__148d } else { tmp36 = fncls__148 }; arg_141 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__149, tmp36, nil); var arg_142 any = text__7; if linked_139 == nil { tmp35 = ifn_140.Invoke_O_O__O(arg_141, arg_142) } else { tmp35 = linked_139.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_138, arg_141, arg_142) }
//line :73:1
															if jrt.J2g_Truth(tmp35) { p__10 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_24, A_arbace_repr_clojure_A_const_19, A_arbace_repr_clojure_A_const_27, jrt.Boolean_FALSE.Ref(), A_arbace_repr_clojure_A_const_28, name__0)) } else { if lang.Util_Equiv_O_O__Z_NoInit(e__9, Lit_57) { p__10 = A_arbace_repr_clojure_A_const_38 } else { if A_arbace_repr_clojure_A_const_34 != nil { p__10 = A_arbace_repr_clojure_A_const_39 } else { p__10 = nil } } } } } }; var tmp37 any; var and__1927000168__auto____11_2 any = full__8; if





















	jrt.J2g_Truth(and__1927000168__auto____11_2) { var tmp38 any = A_arbace_repr_clojure_A_const_25; var and__1927000168__auto____12 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp38, A_arbace_repr_clojure_A_const_24.Invoke_O__O(p__10)); if and__1927000168__auto____12 { tmp37 = A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__10) } else { tmp37 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____12).Ref() } } else { tmp37 = and__1927000168__auto____11_2 }; if jrt.J2g_Truth(tmp37) { var root_150 any = A_arbace_repr_clojure_A_const_40.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_150, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_152 lang.IFn; if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any = p__10; var arg_154 any = A_arbace_repr_clojure_A_const_20; var arg_155 any = jrt.Boolean_TRUE.Ref(); if linked_151 == nil { return ifn_152.Invoke_O_O_O__O(arg_153, arg_154, arg_155) } else { return linked_151.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_150, arg_153, arg_154, arg_155) } } else { return p__10 } }
//line :91:1
func A_arbace_repr_clojure_plan_fn__716000018_A_New_O(p0 any) *A_arbace_repr_clojure_plan_fn__716000018_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_plan_fn__716000018_A{}; t.Ctor_O(p0); return t }
//line :91:1
func (t *A_arbace_repr_clojure_plan_fn__716000018_A) Ctor_O(c__name any) { t.F_name = c__name }
//line :91:1
func (t *A_arbace_repr_clojure_plan_fn__716000018_A) Invoke_O_O__O(self, p1__716000014_SHARP___1 any) any { var root_143 any = A_arbace_repr_clojure_A_const_37.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_143, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_145 lang.IFn; if linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any = t.F_name; var arg_147 any = p1__716000014_SHARP___1; if linked_144 == nil { return ifn_145.Invoke_O_O__O(arg_146, arg_147) } else { return linked_144.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_143, arg_146, arg_147) } }





func A_arbace_repr_clojure_print_plan_A_New() *A_arbace_repr_clojure_print_plan_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_print_plan_A{}; t.Ctor(); return t }
//line :97:1
func (t *A_arbace_repr_clojure_print_plan_A) Ctor() {}
//line :97:1
func (t *A_arbace_repr_clojure_print_plan_A) Invoke_O_O_O_O__O(self, name__0, siblings__1, p__716000022__2 any) any { var map__716000023__4 any = p__716000022__2; var map__716000023__5 any; if lang.ISeq_InstanceOf(map__716000023__4) { var tmp1 any; var root_156 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_158 lang.IFn; if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = map__716000023__4; if linked_157 == nil { tmp1 = ifn_158.Invoke_O__O(arg_159) } else { tmp1 = linked_157.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_156, arg_159) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_160 any = A_arbace_repr_clojure_A_const_15.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any = map__716000023__4; if linked_161 == nil { tmp2 = ifn_162.Invoke_O__O(arg_163) } else { tmp2 = linked_161.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_160, arg_163) }; map__716000023__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_164 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_166 lang.IFn; if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = map__716000023__4; if linked_165 == nil { tmp3 = ifn_166.Invoke_O__O(arg_167) } else { tmp3 = linked_165.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_164, arg_167) }; if jrt.J2g_Truth(tmp3) { var root_168 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_170 lang.IFn; if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = map__716000023__4; if linked_169 == nil { map__716000023__5 = ifn_170.Invoke_O__O(arg_171) } else { map__716000023__5 = linked_169.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_168, arg_171) } } else { map__716000023__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__716000023__5 = map__716000023__4 }; var text__6 any = lang.RT_Get_O_O__O_NoInit(map__716000023__5, A_arbace_repr_clojure_A_const_19); var e__7 any; var root_172 any = A_arbace_repr_clojure_A_const_21.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, A_arbace_repr_clojure_ext_A_fn_class); var ifn_174 lang.IFn; if









	linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = name__0; if linked_173 == nil { e__7 = ifn_174.Invoke_O__O(arg_175) } else { e__7 = linked_173.(*A_arbace_repr_clojure_ext_A).Invoke_O_O__O(root_172, arg_175) }; var b__8 any; var root_176 any = /*line :97:1*/A_arbace_repr_clojure_A_const_32.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, A_arbace_repr_clojure_base_A_fn_class); var ifn_178 lang.IFn; if









	linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any = name__0; if linked_177 == nil { b__8 = ifn_178.Invoke_O__O(arg_179) } else { b__8 = linked_177.(*A_arbace_repr_clojure_base_A).Invoke_O_O__O(root_176, arg_179) }; var tmp4 any; var root_180 any =
	A_arbace_repr_clojure_A_const_22.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_182 lang.IFn; if
	linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any = A_arbace_repr_clojure_A_const_23.GetRawRoot__O(); var arg_184 any = name__0; if linked_181 == nil { tmp4 = ifn_182.Invoke_O_O__O(arg_183, arg_184) } else { tmp4 = linked_181.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_180, arg_183, arg_184) }; if /*line :108:1*/ jrt.J2g_Truth(tmp4) { var tmp5 any = A_arbace_repr_clojure_A_const_24; var tmp6 *lang.Keyword
		if lang.Util_Equiv_O_O__Z_NoInit(e__7, Lit_47) { tmp6 = A_arbace_repr_clojure_A_const_25 } else { tmp6 = A_arbace_repr_clojure_A_const_26 }
//line :108:1
		return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6.Ref(), A_arbace_repr_clojure_A_const_27, jrt.Boolean_FALSE.Ref(), A_arbace_repr_clojure_A_const_28, name__0)) } else { if lang.Util_Equiv_O_O__Z_NoInit(e__7, Lit_51) {


			if lang.Util_Equiv_O_O__Z_NoInit(Lit_48, b__8) {
				var tmp7 any; var root_185 any = A_arbace_repr_clojure_A_const_41.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_187 lang.IFn; if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any; var root_189 any = A_arbace_repr_clojure_A_const_22.GetRawRoot__O(); var linked_190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_189, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_191 lang.IFn; if linked_190 == nil { ifn_191 = lang.IFn_Cast(root_189) } else { ifn_191 = nil }; var arg_192 any = siblings__1; var arg_193 any = Lit_50; if linked_190 == nil { arg_188 = ifn_191.Invoke_O_O__O(arg_192, arg_193) } else { arg_188 = linked_190.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_189, arg_192, arg_193) }; if linked_186 == nil { tmp7 = ifn_187.Invoke_O__O(arg_188) } else { tmp7 = linked_186.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_185, arg_188) }; if jrt.J2g_Truth(tmp7) { return A_arbace_repr_clojure_A_const_42 } else { var tmp8 any; var root_194 any = A_arbace_repr_clojure_A_const_41.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_194, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_196 lang.IFn

					if linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any; var root_198 any = A_arbace_repr_clojure_A_const_22.GetRawRoot__O(); var linked_199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_198, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_200 lang.IFn; if linked_199 == nil { ifn_200 = lang.IFn_Cast(root_198) } else { ifn_200 = nil }; var arg_201 any = siblings__1; var arg_202 any = Lit_58; if linked_199 == nil { arg_197 = ifn_200.Invoke_O_O__O(arg_201, arg_202) } else { arg_197 = linked_199.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_198, arg_201, arg_202) }; if linked_195 == nil { tmp8 = ifn_196.Invoke_O__O(arg_197) } else { tmp8 = linked_195.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_194, arg_197) }
//line :112:1
					if jrt.J2g_Truth(tmp8) { return A_arbace_repr_clojure_A_const_43 } else { if A_arbace_repr_clojure_A_const_34 != nil { return A_arbace_repr_clojure_A_const_44 } else { return nil } } } } else {
//line :111:1
						var tmp9 any = A_arbace_repr_clojure_A_const_24; var tmp10 any = A_arbace_repr_clojure_A_const_26; var tmp11 any = A_arbace_repr_clojure_A_const_27; var tmp12 any = jrt.Boolean_TRUE.Ref(); var tmp13 any = A_arbace_repr_clojure_A_const_28; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, tmp11, tmp12, tmp13, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_53), jrt.RefArrayOf(jrt.Object_class, b__8, nil)).Ref())) } } else {
//line :108:1
							if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_clojure_A_const_45).Invoke_O__O(e__7)) {










								var tmp14 any; var and__1927000168__auto____9 any; var root_203 any = A_arbace_repr_clojure_A_const_22.GetRawRoot__O(); var linked_204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_203, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_205 lang.IFn; if linked_204 == nil { ifn_205 = lang.IFn_Cast(root_203) } else { ifn_205 = nil }; var arg_206 any = siblings__1; var arg_207 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_51), jrt.RefArrayOf(jrt.Object_class, b__8, nil)).Ref(); if linked_204 == nil { and__1927000168__auto____9 = ifn_205.Invoke_O_O__O(arg_206, arg_207) } else { and__1927000168__auto____9 = linked_204.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_203, arg_206, arg_207) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var root_208 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_208, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any = Lit_48; var arg_212 any = b__8; if linked_209 == nil { tmp14 = ifn_210.Invoke_O_O__O(arg_211, arg_212) } else { tmp14 = linked_209.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_208, arg_211, arg_212) } } else { tmp14 = and__1927000168__auto____9 }; if jrt.J2g_Truth(tmp14) { var tmp15 any = A_arbace_repr_clojure_A_const_33; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp15, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_59), jrt.RefArrayOf(jrt.Object_class, b__8, nil)).Ref())) } else { var tmp16 any = A_arbace_repr_clojure_A_const_24; var tmp17 any; var root_213 any = A_arbace_repr_clojure_A_const_30.GetRawRoot__O(); var linked_214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_213, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_215 lang.IFn

									if linked_214 == nil { ifn_215 = lang.IFn_Cast(root_213) } else { ifn_215 = nil }; var arg_216 any; var root_217 any = A_arbace_repr_clojure_A_const_12.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any = e__7; var arg_221 any = A_arbace_repr_clojure_A_const_31; if linked_218 == nil { arg_216 = ifn_219.Invoke_O_O__O(arg_220, arg_221) } else { arg_216 = linked_218.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_217, arg_220, arg_221) }; if linked_214 == nil { tmp17 = ifn_215.Invoke_O__O(arg_216) } else { tmp17 = linked_214.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_213, arg_216) }
//line :119:1
									return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp17, A_arbace_repr_clojure_A_const_27, jrt.Boolean_FALSE.Ref(), A_arbace_repr_clojure_A_const_28, name__0)) } } else {
//line :108:1
										if lang.Util_Equiv_O_O__Z_NoInit(e__7, Lit_55) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_24, A_arbace_repr_clojure_A_const_35, A_arbace_repr_clojure_A_const_27, jrt.Boolean_FALSE.Ref(), A_arbace_repr_clojure_A_const_28, name__0)) } else { var tmp18 any; var root_222 any = A_arbace_repr_clojure_A_const_36.GetRawRoot__O(); var linked_223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_222, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_224 lang.IFn














											if linked_223 == nil { ifn_224 = lang.IFn_Cast(root_222) } else { ifn_224 = nil }; var arg_225 any; var fnbody__233 any = A_arbace_repr_clojure_print_plan_fn__716000025_A_New_O(name__0); var tmp19 *jrt.Class; var fncls__232 *jrt.Class = A_arbace_repr_clojure_print_plan_fn__716000025_A_fn_class; if fncls__232 == nil { var fncls__232d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_60, false, fnbody__233); A_arbace_repr_clojure_print_plan_fn__716000025_A_fn_class = fncls__232d; tmp19 = fncls__232d } else { tmp19 = fncls__232 }; arg_225 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__233, tmp19, nil); var arg_226 any = text__6; if linked_223 == nil { tmp18 = ifn_224.Invoke_O_O__O(arg_225, arg_226) } else { tmp18 = linked_223.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_222, arg_225, arg_226) }
//line :108:1
											if jrt.J2g_Truth(tmp18) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_24, A_arbace_repr_clojure_A_const_19, A_arbace_repr_clojure_A_const_27, jrt.Boolean_FALSE.Ref(), A_arbace_repr_clojure_A_const_28, name__0)) } else { if lang.Util_Equiv_O_O__Z_NoInit(e__7, Lit_57) { return A_arbace_repr_clojure_A_const_47 } else { if A_arbace_repr_clojure_A_const_34 != nil { return A_arbace_repr_clojure_A_const_48 } else { return nil } } } } } } } }














func A_arbace_repr_clojure_print_plan_fn__716000025_A_New_O(p0 any) *A_arbace_repr_clojure_print_plan_fn__716000025_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_print_plan_fn__716000025_A{}; t.Ctor_O(p0); return t }
//line :123:1
func (t *A_arbace_repr_clojure_print_plan_fn__716000025_A) Ctor_O(c__name any) { t.F_name = c__name }
//line :123:1
func (t *A_arbace_repr_clojure_print_plan_fn__716000025_A) Invoke_O_O__O(self, p1__716000021_SHARP___1 any) any { var root_227 any = A_arbace_repr_clojure_A_const_37.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_229 lang.IFn; if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any = t.F_name; var arg_231 any = p1__716000021_SHARP___1; if linked_228 == nil { return ifn_229.Invoke_O_O__O(arg_230, arg_231) } else { return linked_228.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_227, arg_230, arg_231) } }



func A_arbace_repr_clojure_print_refine_A_New() *A_arbace_repr_clojure_print_refine_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_print_refine_A{}; t.Ctor(); return t }
//line :127:1
func (t *A_arbace_repr_clojure_print_refine_A) Ctor() {}
//line :127:1
func (t *A_arbace_repr_clojure_print_refine_A) Invoke_O_O_O_O_O__O(self, p__0, name__1, siblings__2, s__3 any) any {




	var tmp1 any; var and__1927000168__auto____5 any = A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__0); if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 bool; var tmp2 any; var root_234 any = A_arbace_repr_clojure_A_const_21.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_234, A_arbace_repr_clojure_ext_A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = name__1; if linked_235 == nil { tmp2 = ifn_236.Invoke_O__O(arg_237) } else { tmp2 = linked_235.(*A_arbace_repr_clojure_ext_A).Invoke_O_O__O(root_234, arg_237) }; and__1927000168__auto____6 = lang.Util_Equiv_O_O__Z_NoInit(Lit_51, tmp2); if and__1927000168__auto____6 { var root_238 any = A_arbace_repr_clojure_A_const_49.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_repr_clojure_rules.A_arbace_repr_clojure_rules_full_QMARK__A_fn_class); var ifn_240 lang.IFn; if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any = s__3; if linked_239 == nil { tmp1 = ifn_240.Invoke_O__O(arg_241) } else { tmp1 = linked_239.(*aot_arbace_repr_clojure_rules.A_arbace_repr_clojure_rules_full_QMARK__A).Invoke_O_O__O(root_238, arg_241) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() } } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { var out__5 any; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_47); var tmp4 any; var root_242 any = A_arbace_repr_clojure_A_const_32.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, A_arbace_repr_clojure_base_A_fn_class); var ifn_244 lang.IFn
		if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = name__1; if linked_243 == nil { tmp4 = ifn_244.Invoke_O__O(arg_245) } else { tmp4 = linked_243.(*A_arbace_repr_clojure_base_A).Invoke_O_O__O(root_242, arg_245) }; out__5 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, tmp4, nil)).Ref()
		var tmp5 any; var root_246 any = A_arbace_repr_clojure_A_const_22.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_248 lang.IFn; if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = siblings__2; var arg_250 any = out__5; if linked_247 == nil { tmp5 = ifn_248.Invoke_O_O__O(arg_249, arg_250) } else { tmp5 = linked_247.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_246, arg_249, arg_250) }; if jrt.J2g_Truth(tmp5) { var tmp6 any = A_arbace_repr_clojure_A_const_33; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_61), jrt.RefArrayOf(jrt.Object_class, out__5, nil)).Ref())) } else {

			return lang.IFn_Cast(A_arbace_repr_clojure_A_const_40.GetRawRoot__O()).Invoke_O_O_O_O_O__O(p__0, A_arbace_repr_clojure_A_const_24, A_arbace_repr_clojure_A_const_25, A_arbace_repr_clojure_A_const_28, out__5) } } else {
//line :132:1
				return p__0
			}
}




func A_arbace_repr_clojure_translate_text_A_New() *A_arbace_repr_clojure_translate_text_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_translate_text_A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_repr_clojure_translate_text_A) Ctor() {}
//line :139:1
func (t *A_arbace_repr_clojure_translate_text_A) Invoke_O_O_O_O_O__O(self, s__0, p__1, path__2, skip__3 any) any {


	var root_259 any = A_arbace_repr_clojure_A_const_50.GetRawRoot__O(); var linked_260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_259, aot_arbace_repr_clojure_rules.A_arbace_repr_clojure_rules_translate_A_fn_class); var ifn_261 lang.IFn; if linked_260 == nil { ifn_261 = lang.IFn_Cast(root_259) } else { ifn_261 = nil }; var arg_262 any = s__0; var tmp1 any = A_arbace_repr_clojure_A_const_24; var tmp2 any = A_arbace_repr_clojure_A_const_24.Invoke_O__O(p__1); var tmp3 any = A_arbace_repr_clojure_A_const_27; var tmp4 any = A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__1); var tmp5 any = A_arbace_repr_clojure_A_const_20; var arg_263 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp4, tmp5, A_arbace_repr_clojure_A_const_20.Invoke_O__O(p__1), A_arbace_repr_clojure_A_const_51, A_arbace_repr_clojure_A_const_52, A_arbace_repr_clojure_A_const_53, path__2)); var arg_264 any = skip__3; if linked_260 == nil { return ifn_261.Invoke_O_O_O__O(arg_262, arg_263, arg_264) } else { return linked_260.(*aot_arbace_repr_clojure_rules.A_arbace_repr_clojure_rules_translate_A).Invoke_O_O_O_O__O(root_259, arg_262, arg_263, arg_264)
	} }
func A_arbace_repr_clojure_print_text_A_New() *A_arbace_repr_clojure_print_text_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_print_text_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_repr_clojure_print_text_A) Ctor() {}
//line :144:1
func (t *A_arbace_repr_clojure_print_text_A) Invoke_O_O_O_O_O__O(self, s__0, p__1, path__2, skip__3 any) any {


	var root_265 any = A_arbace_repr_clojure_A_const_54.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_265, aot_arbace_repr_clojure_rules.A_arbace_repr_clojure_rules_print_text_A_fn_class); var ifn_267 lang.IFn; if linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any = s__0; var tmp1 any = A_arbace_repr_clojure_A_const_24; var tmp2 any = A_arbace_repr_clojure_A_const_24.Invoke_O__O(p__1); var tmp3 any = A_arbace_repr_clojure_A_const_27; var arg_269 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__1), A_arbace_repr_clojure_A_const_51, A_arbace_repr_clojure_A_const_55, A_arbace_repr_clojure_A_const_53, path__2)); var arg_270 any = skip__3; if linked_266 == nil { return ifn_267.Invoke_O_O_O__O(arg_268, arg_269, arg_270) } else { return linked_266.(*aot_arbace_repr_clojure_rules.A_arbace_repr_clojure_rules_print_text_A).Invoke_O_O_O_O__O(root_265, arg_268, arg_269, arg_270)
	}
}
func A_arbace_repr_clojure_fn__716000031_A_New() *A_arbace_repr_clojure_fn__716000031_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_fn__716000031_A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_repr_clojure_fn__716000031_A) Ctor() {}
//line :150:1
func (t *A_arbace_repr_clojure_fn__716000031_A) Invoke_O_O_O_O_O__O(self, p__0, ___1, ___2, ___3 any) any { return p__0 }


func A_arbace_repr_clojure_files_A_New() *A_arbace_repr_clojure_files_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_files_A{}; t.Ctor(); return t }
//line :153:1
func (t *A_arbace_repr_clojure_files_A) Ctor() {}
//line :153:1
func (t *A_arbace_repr_clojure_files_A) Invoke_O_O__O(self, src__0 any) any {


	if jrt.File_Cast(src__0).IsDirectory__Z() { var root__2 any = jrt.File_Cast(src__0).ToPath__Path(); var root_271 any = A_arbace_repr_clojure_A_const_56.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_273 lang.IFn

		if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = A_arbace_repr_clojure_A_const_57.GetRawRoot__O(); var arg_275 any; var iter__1927001039__auto____3 any; var fnbody__349 any = A_arbace_repr_clojure_files_iter__716000033__716000037_A_New_O_O(root__2, src__0); var tmp1 *jrt.Class; var fncls__348 *jrt.Class = A_arbace_repr_clojure_files_iter__716000033__716000037_A_fn_class
		if fncls__348 == nil { var fncls__348d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_15, false, fnbody__349); A_arbace_repr_clojure_files_iter__716000033__716000037_A_fn_class = fncls__348d; tmp1 = fncls__348d } else { tmp1 = fncls__348 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__349, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp3 any; var root_350 any = A_arbace_repr_clojure_A_const_68.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any = src__0; if linked_351 == nil { tmp3 = ifn_352.Invoke_O__O(arg_353) } else { tmp3 = linked_351.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_350, arg_353) }; arg_275 = tmp2.Invoke_O__O(tmp3)
//line :158:1
		if linked_272 == nil { return ifn_273.Invoke_O_O__O(arg_274, arg_275) } else { return linked_272.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_271, arg_274, arg_275) } } else {
//line :156:1
			var tmp4 any; var or__1927000174__auto____2 any = jrt.File_Cast(src__0).GetAbsoluteFile__File().GetParentFile__File()




			if jrt.J2g_Truth(or__1927000174__auto____2) { tmp4 = or__1927000174__auto____2 } else { tmp4 = jrt.File_New_String(Lit_12) }
//line :156:1
			return lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(tmp4, jrt.File_Cast(src__0).GetName__String().Ref()))
		}
}
func A_arbace_repr_clojure_files_iter__716000033__716000037_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_files_iter__716000033__716000037_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_files_iter__716000033__716000037_A{}; t.Ctor_O_O(p0, p1); return t }
//line :159:1
func (t *A_arbace_repr_clojure_files_iter__716000033__716000037_A) Ctor_O_O(c__root, c__src any) { t.F_root = c__root; t.F_src = c__src }
//line :159:1
func (t *A_arbace_repr_clojure_files_iter__716000033__716000037_A) Invoke_O_O__O(self, s__716000034__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__347 any = A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_A_New_O_O_O_O(t.F_root, t.F_src, self, s__716000034__1); var tmp2 *jrt.Class; var fncls__346 *jrt.Class = A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_A_fn_class; if fncls__346 == nil { var fncls__346d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_16, false, fnbody__347); A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_A_fn_class = fncls__346d; tmp2 = fncls__346d } else { tmp2 = fncls__346 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__347, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :159:1
func A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :159:1
func (t *A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_A) Ctor_O_O_O_O(c__root, c__src, c__iter__716000033, c__s__716000034 any) { t.F_root = c__root; t.F_src = c__src; t.F_iter__716000033 = c__iter__716000033; t.F_s__716000034 = c__s__716000034 }
//line :159:1
func (t *A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_A) Invoke_O__O(self any) any { { var s__716000034__1 any; var t_ any = t.F_s__716000034; t.F_s__716000034 = nil; s__716000034__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_276 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_276, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_278 lang.IFn; if linked_277 == nil { ifn_278 = lang.IFn_Cast(root_276) } else { ifn_278 = nil }; var arg_279 any = s__716000034__1; if linked_277 == nil { temp__1927000414__auto____2 = ifn_278.Invoke_O__O(arg_279) } else { temp__1927000414__auto____2 = linked_277.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_276, arg_279) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__716000034__3 any = temp__1927000414__auto____2; var tmp1 any; var root_280 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_280, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_282 lang.IFn; if linked_281 == nil { ifn_282 = lang.IFn_Cast(root_280) } else { ifn_282 = nil }; var arg_283 any = s__716000034__3; if linked_281 == nil { tmp1 = ifn_282.Invoke_O__O(arg_283) } else { tmp1 = linked_281.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_280, arg_283) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_284 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_284, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_286 lang.IFn; if linked_285 == nil { ifn_286 = lang.IFn_Cast(root_284) } else { ifn_286 = nil }; var arg_287 any = s__716000034__3; if linked_285 == nil { c__1927001037__auto____4 = ifn_286.Invoke_O__O(arg_287) } else { c__1927001037__auto____4 = linked_285.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_284, arg_287) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__716000036__6 any; var root_288 any = A_arbace_repr_clojure_A_const_60.GetRawRoot__O(); var linked_289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_288, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_290 lang.IFn; if linked_289 == nil { ifn_290 = lang.IFn_Cast(root_288) } else { ifn_290 = nil }; var arg_291 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_289 == nil { b__716000036__6 = ifn_290.Invoke_O__O(arg_291) } else { b__716000036__6 = linked_289.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_288, arg_291) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__302 any = A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_fn__716000039_A_New_O_O_O_I_O(t.F_root, t.F_src, b__716000036__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__301 *jrt.Class = A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_fn__716000039_A_fn_class; if fncls__301 == nil { var fncls__301d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_17, false, fnbody__302); A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_fn__716000039_A_fn_class = fncls__301d; tmp3 = fncls__301d } else { tmp3 = fncls__301 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__302, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_303 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_303, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_305 lang.IFn; if linked_304 == nil { ifn_305 = lang.IFn_Cast(root_303) } else { ifn_305 = nil }; var arg_306 any; var root_308 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_310 lang.IFn; if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = b__716000036__6; if linked_309 == nil { arg_306 = ifn_310.Invoke_O__O(arg_311) } else { arg_306 = linked_309.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_308, arg_311) }; var arg_307 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__716000033); var tmp5 any; var root_312 any = A_arbace_repr_clojure_A_const_65.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = s__716000034__3; if linked_313 == nil { tmp5 = ifn_314.Invoke_O__O(arg_315) } else { tmp5 = linked_313.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_312, arg_315) }; arg_307 = tmp4.Invoke_O__O(tmp5); if linked_304 == nil { return ifn_305.Invoke_O_O__O(arg_306, arg_307) } else { return linked_304.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_303, arg_306, arg_307) } } else { var root_316 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_318 lang.IFn; if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any; var root_321 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_321, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_323 lang.IFn; if linked_322 == nil { ifn_323 = lang.IFn_Cast(root_321) } else { ifn_323 = nil }; var arg_324 any = b__716000036__6; if linked_322 == nil { arg_319 = ifn_323.Invoke_O__O(arg_324) } else { arg_319 = linked_322.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_321, arg_324) }; var arg_320 any; if linked_317 == nil { return ifn_318.Invoke_O_O__O(arg_319, arg_320) } else { return linked_317.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_316, arg_319, arg_320) } } } else { var f__4 any; var root_325 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_325, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_327 lang.IFn; if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any = s__716000034__3; if linked_326 == nil { f__4 = ifn_327.Invoke_O__O(arg_328) } else { f__4 = linked_326.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_325, arg_328) }; if jrt.File_Cast(f__4).IsFile__Z() { var root_329 any = A_arbace_repr_clojure_A_const_66.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_331 lang.IFn; if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any; var tmp6 any = t.F_src; var tmp7 any; var root_334 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_334, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_336 lang.IFn
														if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var tmp8 jrt.Path = jrt.Path_Cast(t.F_root); var arg_337 any = tmp8.Relativize_Path__Path(jrt.File_Cast(f__4).ToPath__Path()); if linked_335 == nil { tmp7 = ifn_336.Invoke_O__O(arg_337) } else { tmp7 = linked_335.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_334, arg_337) }
//line :159:1
	arg_332 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7); var arg_333 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__716000033); var tmp10 any; var root_338 any = A_arbace_repr_clojure_A_const_67.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_340 lang.IFn; if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = s__716000034__3; if linked_339 == nil { tmp10 = ifn_340.Invoke_O__O(arg_341) } else { tmp10 = linked_339.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_338, arg_341) }; arg_333 = tmp9.Invoke_O__O(tmp10); if linked_330 == nil { return ifn_331.Invoke_O_O__O(arg_332, arg_333) } else { return linked_330.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_329, arg_332, arg_333) } } else { var tmp11 any; var root_342 any = A_arbace_repr_clojure_A_const_67.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = s__716000034__3; if linked_343 == nil { tmp11 = ifn_344.Invoke_O__O(arg_345) } else { tmp11 = linked_343.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_342, arg_345) }; s__716000034__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :159:1
func A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_fn__716000039_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_fn__716000039_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_fn__716000039_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :159:1
func (t *A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_fn__716000039_A) Ctor_O_O_O_I_O(c__root, c__src, c__b__716000036 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_root = c__root; t.F_src = c__src; t.F_b__716000036 = c__b__716000036; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :159:1
func (t *A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_fn__716000039_A) Invoke_O__O(self any) any { { var i__716000035__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__716000035__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__716000035__1)); if jrt.File_Cast(f__2).IsFile__Z() { var root_292 any = A_arbace_repr_clojure_A_const_61.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_292, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_294 lang.IFn; if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any = t.F_b__716000036; var arg_296 any; var tmp2 any = t.F_src; var tmp3 any; var root_297 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_298 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_297, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_299 lang.IFn
																if linked_298 == nil { ifn_299 = lang.IFn_Cast(root_297) } else { ifn_299 = nil }; var tmp4 jrt.Path = jrt.Path_Cast(t.F_root); var arg_300 any = tmp4.Relativize_Path__Path(jrt.File_Cast(f__2).ToPath__Path()); if linked_298 == nil { tmp3 = ifn_299.Invoke_O__O(arg_300) } else { tmp3 = linked_298.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_297, arg_300) }
//line :159:1
	arg_296 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3); if linked_293 == nil { ifn_294.Invoke_O_O__O(arg_295, arg_296) } else { linked_293.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_292, arg_295, arg_296) }; i__716000035__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__716000035__1); continue L1 } else { i__716000035__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__716000035__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_repr_clojure_run_A_New() *A_arbace_repr_clojure_run_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_A{}; t.Ctor(); return t }
//line :163:1
func (t *A_arbace_repr_clojure_run_A) Ctor() {}
//line :163:1
func (t *A_arbace_repr_clojure_run_A) Invoke_O_O_O_O_O__O(self, verb__0, sources__1, out__2, opts__3 any) any { var skip__5 any = A_arbace_repr_clojure_A_const_33.Invoke_O_O__O(opts__3, lang.PersistentHashSet_EMPTY.Ref()); var map__716000044__6 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_69.GetRawRoot__O()).Invoke_O__O(verb__0); var map__716000044__7 any; if







	lang.ISeq_InstanceOf(map__716000044__6) { var tmp1 any; var root_354 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_354, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_356 lang.IFn; if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any = map__716000044__6; if linked_355 == nil { tmp1 = ifn_356.Invoke_O__O(arg_357) } else { tmp1 = linked_355.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_354, arg_357) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_358 any = A_arbace_repr_clojure_A_const_15.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_360 lang.IFn; if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = map__716000044__6; if linked_359 == nil { tmp2 = ifn_360.Invoke_O__O(arg_361) } else { tmp2 = linked_359.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_358, arg_361) }; map__716000044__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_362 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_362, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_364 lang.IFn; if linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any = map__716000044__6; if linked_363 == nil { tmp3 = ifn_364.Invoke_O__O(arg_365) } else { tmp3 = linked_363.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_362, arg_365) }; if jrt.J2g_Truth(tmp3) { var root_366 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_366, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_368 lang.IFn; if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any = map__716000044__6; if linked_367 == nil { map__716000044__7 = ifn_368.Invoke_O__O(arg_369) } else { map__716000044__7 = linked_367.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_366, arg_369) } } else { map__716000044__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__716000044__7 = map__716000044__6 }; var plan__8 any = /*line :163:1*/lang.RT_Get_O_O__O_NoInit(map__716000044__7, A_arbace_repr_clojure_A_const_70); var translate_text__9 any = lang.RT_Get_O_O__O_NoInit(map__716000044__7, A_arbace_repr_clojure_A_const_19); var refine__10 any = lang.RT_Get_O_O__O_NoInit(map__716000044__7, A_arbace_repr_clojure_A_const_71); var listing__11 any; var root_370 any = A_arbace_repr_clojure_A_const_72.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_370, aot_arbace_core.A_arbace_core_memoize_A_fn_class); var ifn_372 lang.IFn; if









	linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any; var fnbody__379 any = A_arbace_repr_clojure_run_fn__716000046_A_New(); var tmp4 *jrt.Class; var fncls__378 *jrt.Class = A_arbace_repr_clojure_run_fn__716000046_A_fn_class; if fncls__378 == nil { var fncls__378d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_90, false, nil); A_arbace_repr_clojure_run_fn__716000046_A_fn_class = fncls__378d; tmp4 = fncls__378d } else { tmp4 = fncls__378 }; arg_373 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__379, tmp4, nil); if linked_371 == nil { listing__11 = ifn_372.Invoke_O__O(arg_373) } else { listing__11 = linked_371.(*aot_arbace_core.A_arbace_core_memoize_A).Invoke_O_O__O(root_370, arg_373) }; var stats__12 any; var root_380 any = /*line :163:1*/A_arbace_repr_clojure_A_const_74.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_380, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_382 lang.IFn; if










	linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any = A_arbace_repr_clojure_A_const_75; if linked_381 == nil { stats__12 = ifn_382.Invoke_O__O(arg_383) } else { stats__12 = linked_381.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_380, arg_383) }; var seq_716000048__13 any; var root_388 any = /*line :163:1*/A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_388, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_390 lang.IFn; if











	linked_389 == nil { ifn_390 = lang.IFn_Cast(root_388) } else { ifn_390 = nil }; var arg_391 any = sources__1; if linked_389 == nil { seq_716000048__13 = ifn_390.Invoke_O__O(arg_391) } else { seq_716000048__13 = linked_389.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_388, arg_391) }; var chunk_716000049__14 any; var count_716000050__15 int64 = 0; var i_716000051__16 int64 = 0; L1:
//line :163:1
	for {











		if lang.Numbers_Lt_J_J__Z_NoInit(i_716000051__16, count_716000050__15) { var src__17 any = lang.Indexed_Cast(chunk_716000049__14).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_716000051__16)); var srcf__18 any; var root_408 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_408, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_410 lang.IFn
			if linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; var arg_411 any = src__17; if linked_409 == nil { srcf__18 = ifn_410.Invoke_O__O(arg_411) } else { srcf__18 = linked_409.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_408, arg_411) }
//line :175:1
			var seq_716000056__19 any; var root_412 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_414 lang.IFn; if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any; var root_416 any = A_arbace_repr_clojure_A_const_77.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, A_arbace_repr_clojure_files_A_fn_class); var ifn_418 lang.IFn

			if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any = srcf__18; if linked_417 == nil { arg_415 = ifn_418.Invoke_O__O(arg_419) } else { arg_415 = linked_417.(*A_arbace_repr_clojure_files_A).Invoke_O_O__O(root_416, arg_419) }
//line :175:1
			if linked_413 == nil { seq_716000056__19 = ifn_414.Invoke_O__O(arg_415) } else { seq_716000056__19 = linked_413.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_412, arg_415) }; var chunk_716000057__20 any; var count_716000058__21 int64 = 0; var i_716000059__22 int64 = 0; L2: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_716000059__22, count_716000058__21) { var vec__716000060__23 any = lang.Indexed_Cast(chunk_716000057__20).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_716000059__22)); var dir__24 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000060__23, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__25 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000060__23, lang.RT_IntCast_J__I_NoInit(1), nil); var f__26 any; var root_436 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_437 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_436, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_438 lang.IFn


				if linked_437 == nil { ifn_438 = lang.IFn_Cast(root_436) } else { ifn_438 = nil }; var arg_439 any = dir__24; var arg_440 any = rel__25; if linked_437 == nil { f__26 = ifn_438.Invoke_O_O__O(arg_439, arg_440) } else { f__26 = linked_437.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_436, arg_439, arg_440) }
//line :175:1
				var parent__27 any = jrt.File_Cast(f__26).GetParentFile__File(); var siblings__28 any = lang.IFn_Cast(listing__11).Invoke_O__O(parent__27); var p0__29 any = lang.IFn_Cast(plan__8).Invoke_O_O_O__O(jrt.File_Cast(f__26).GetName__String().Ref(), siblings__28, opts__3); var s__30 any






				if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_24.Invoke_O__O(p0__29)) { s__30 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_78.GetRawRoot__O()).Invoke_O__O(f__26) } else { s__30 = nil }
//line :175:1
				var p__31 any







				if jrt.J2g_Truth(s__30) { p__31 = lang.IFn_Cast(refine__10).Invoke_O_O_O_O__O(p0__29, jrt.File_Cast(f__26).GetName__String().Ref(), siblings__28, s__30) } else { p__31 = p0__29 }
//line :175:1
				var rel_out__32 any; var d__32 any; var tmp5 any; var root_445 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_446 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_445, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_447 lang.IFn








				if linked_446 == nil { ifn_447 = lang.IFn_Cast(root_445) } else { ifn_447 = nil }; var arg_448 any = rel__25; if linked_446 == nil { tmp5 = ifn_447.Invoke_O__O(arg_448) } else { tmp5 = linked_446.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_445, arg_448) }; d__32 = jrt.File_Cast(tmp5).GetParent__String().Ref(); if jrt.J2g_Truth(d__32) { rel_out__32 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_29, nil), jrt.RefArrayOf(jrt.Object_class, d__32, nil, A_arbace_repr_clojure_A_const_28.Invoke_O__O(p__31))).Ref() } else { rel_out__32 = A_arbace_repr_clojure_A_const_28.Invoke_O__O(p__31) }
				if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_33.Invoke_O__O(p__31)) {

					var root_529 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_529, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_531 lang.IFn; if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any = stats__12; var arg_533 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_534 any = A_arbace_repr_clojure_A_const_93; var arg_535 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_530 == nil { ifn_531.Invoke_O_O_O_O__O(arg_532, arg_533, arg_534, arg_535) } else { linked_530.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_529, arg_532, arg_533, arg_534, arg_535) }
					var root_536 any = A_arbace_repr_clojure_A_const_88.GetRawRoot__O(); var linked_537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_536, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_538 lang.IFn; if linked_537 == nil { ifn_538 = lang.IFn_Cast(root_536) } else { ifn_538 = nil }; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_89.GetRawRoot__O()); var tmp7 any = A_arbace_repr_clojure_A_const_90; var arg_539 any = tmp6.Invoke_O_O__O(tmp7, A_arbace_repr_clojure_A_const_91.Get__O()); if linked_537 == nil { ifn_538.Invoke_O__O(arg_539) } else { linked_537.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_536, arg_539) }; var tmp8 *lang.Compiler_AOTFn; var fnbody__464 any = A_arbace_repr_clojure_run_fn__716000063_A_New_O_O(f__26, p__31); var tmp9 *jrt.Class; var fncls__463 *jrt.Class = A_arbace_repr_clojure_run_fn__716000063_A_fn_class; if fncls__463 == nil { var fncls__463d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_91, false, fnbody__464); A_arbace_repr_clojure_run_fn__716000063_A_fn_class = fncls__463d; tmp9 = fncls__463d } else { tmp9 = fncls__463 }; tmp8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__464, tmp9, nil); Up_Compiler_AOTFn_IFn(tmp8).Invoke__O() } else {
//line :185:1
						if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_81.Invoke_O__O(p__31)) {




							if jrt.J2g_Truth(out__2) { var t__33 any; var root_545 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_546 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_545, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_547 lang.IFn
								if linked_546 == nil { ifn_547 = lang.IFn_Cast(root_545) } else { ifn_547 = nil }; var arg_548 any = out__2; var arg_549 any = rel__25; if linked_546 == nil { t__33 = ifn_547.Invoke_O_O__O(arg_548, arg_549) } else { t__33 = linked_546.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_545, arg_548, arg_549) }
								lang.IFn_Cast(A_arbace_repr_clojure_A_const_95.GetRawRoot__O()).Invoke_O__O(t__33)
								lang.IFn_Cast(A_arbace_repr_clojure_A_const_94.GetRawRoot__O()).Invoke_O_O__O(f__26, t__33) }
							var root_465 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_466 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_465, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_467 lang.IFn; if linked_466 == nil { ifn_467 = lang.IFn_Cast(root_465) } else { ifn_467 = nil }; var arg_468 any = stats__12; var arg_469 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_470 any = A_arbace_repr_clojure_A_const_84; var arg_471 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_466 == nil { ifn_467.Invoke_O_O_O_O__O(arg_468, arg_469, arg_470, arg_471) } else { linked_466.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_465, arg_468, arg_469, arg_470, arg_471) } } else {
//line :185:1
								if A_arbace_repr_clojure_A_const_34 != nil { var r__33 any; var tmp10 *lang.Compiler_AOTFn; var fnbody__513 any = A_arbace_repr_clojure_run_fn__716000065_A_New_O_O_O_O_O_O(f__26, p__31, stats__12, s__30, translate_text__9, skip__5); var tmp11 *jrt.Class
									var fncls__512 /*line :185:1*/*jrt.Class = A_arbace_repr_clojure_run_fn__716000065_A_fn_class










									if fncls__512 == nil { var fncls__512d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_92, false, fnbody__513); A_arbace_repr_clojure_run_fn__716000065_A_fn_class = fncls__512d; tmp11 = fncls__512d } else { tmp11 = fncls__512 }; tmp10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__513, tmp11, nil); r__33 = Up_Compiler_AOTFn_IFn(tmp10).Invoke__O()




									if jrt.J2g_Truth(r__33) {
										var root_559 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_560 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_559, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_561 lang.IFn; if linked_560 == nil { ifn_561 = lang.IFn_Cast(root_559) } else { ifn_561 = nil }; var arg_562 any = stats__12; var arg_563 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_564 any; if lang.Util_Equiv_O_O__Z_NoInit(s__30, r__33) { arg_564 = A_arbace_repr_clojure_A_const_96 } else { arg_564 = A_arbace_repr_clojure_A_const_97 }; var arg_565 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_560 == nil { ifn_561.Invoke_O_O_O_O__O(arg_562, arg_563, arg_564, arg_565) } else { linked_560.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_559, arg_562, arg_563, arg_564, arg_565) }
										if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__31)) { var root_566 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_566, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_568 lang.IFn; if linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any = stats__12; var arg_570 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_571 any = A_arbace_repr_clojure_A_const_27; var arg_572 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_567 == nil { ifn_568.Invoke_O_O_O_O__O(arg_569, arg_570, arg_571, arg_572) } else { linked_567.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_566, arg_569, arg_570, arg_571, arg_572) } }
										if jrt.J2g_Truth(out__2) { var t__34 any; var root_514 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_514, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_516 lang.IFn
											if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any = out__2; var arg_518 any = rel_out__32; if linked_515 == nil { t__34 = ifn_516.Invoke_O_O__O(arg_517, arg_518) } else { t__34 = linked_515.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_514, arg_517, arg_518) }
											lang.IFn_Cast(A_arbace_repr_clojure_A_const_95.GetRawRoot__O()).Invoke_O__O(t__34)
											lang.IFn_Cast(A_arbace_repr_clojure_A_const_92.GetRawRoot__O()).Invoke_O_O__O(t__34, r__33) } else {
//line :204:1
												var moved__34 any; var root_524 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_525 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_524, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_526 lang.IFn



												if linked_525 == nil { ifn_526 = lang.IFn_Cast(root_524) } else { ifn_526 = nil }; var arg_527 any = jrt.File_Cast(f__26).GetName__String().Ref(); var arg_528 any = A_arbace_repr_clojure_A_const_28.Invoke_O__O(p__31); if linked_525 == nil { moved__34 = ifn_526.Invoke_O_O__O(arg_527, arg_528) } else { moved__34 = linked_525.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_524, arg_527, arg_528) }
												var tmp12 any; var or__1927000174__auto____35 any; var root_577 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_578 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_577, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_579 lang.IFn; if linked_578 == nil { ifn_579 = lang.IFn_Cast(root_577) } else { ifn_579 = nil }; var arg_580 any = s__30; var arg_581 any = r__33; if linked_578 == nil { or__1927000174__auto____35 = ifn_579.Invoke_O_O__O(arg_580, arg_581) } else { or__1927000174__auto____35 = linked_578.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_577, arg_580, arg_581) }; if jrt.J2g_Truth(or__1927000174__auto____35) { tmp12 = or__1927000174__auto____35 } else { tmp12 = moved__34 }; if jrt.J2g_Truth(tmp12) {
													var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_92.GetRawRoot__O()); var tmp14 any; var root_587 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_588 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_587, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_589 lang.IFn; if linked_588 == nil { ifn_589 = lang.IFn_Cast(root_587) } else { ifn_589 = nil }; var arg_590 any = parent__27; var arg_591 any = A_arbace_repr_clojure_A_const_28.Invoke_O__O(p__31); if linked_588 == nil { tmp14 = ifn_589.Invoke_O_O__O(arg_590, arg_591) } else { tmp14 = linked_588.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_587, arg_590, arg_591) }; tmp13.Invoke_O_O__O(tmp14, r__33) }
												if jrt.J2g_Truth(moved__34) { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(f__26).Delete__Z()) } } } } } }
//line :175:1
				seq_716000056__19, chunk_716000057__20, count_716000058__21, i_716000059__22 = seq_716000056__19, chunk_716000057__20, count_716000058__21, lang.Numbers_Unchecked_inc_J__J_NoInit(i_716000059__22); continue L2 } else { var temp__1927000414__auto____23 any; var root_420 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_420, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_422 lang.IFn; if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any = seq_716000056__19; if linked_421 == nil { temp__1927000414__auto____23 = ifn_422.Invoke_O__O(arg_423) } else { temp__1927000414__auto____23 = linked_421.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_420, arg_423) }; if jrt.J2g_Truth(temp__1927000414__auto____23) { var seq_716000056__24 any = temp__1927000414__auto____23; var tmp15 any; var root_424 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_424, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_426 lang.IFn; if linked_425 == nil { ifn_426 = lang.IFn_Cast(root_424) } else { ifn_426 = nil }; var arg_427 any = seq_716000056__24; if linked_425 == nil { tmp15 = ifn_426.Invoke_O__O(arg_427) } else { tmp15 = linked_425.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_424, arg_427) }; if jrt.J2g_Truth(tmp15) { var c__1927000678__auto____25 any; var root_428 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_428, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_430 lang.IFn; if linked_429 == nil { ifn_430 = lang.IFn_Cast(root_428) } else { ifn_430 = nil }; var arg_431 any = seq_716000056__24; if linked_429 == nil { c__1927000678__auto____25 = ifn_430.Invoke_O__O(arg_431) } else { c__1927000678__auto____25 = linked_429.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_428, arg_431) }; var tmp16 any; var root_592 any = A_arbace_repr_clojure_A_const_65.GetRawRoot__O(); var linked_593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_592, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_594 lang.IFn; if linked_593 == nil { ifn_594 = lang.IFn_Cast(root_592) } else { ifn_594 = nil }; var arg_595 any = seq_716000056__24; if linked_593 == nil { tmp16 = ifn_594.Invoke_O__O(arg_595) } else { tmp16 = linked_593.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_592, arg_595) }; seq_716000056__19, chunk_716000057__20, count_716000058__21, i_716000059__22 = tmp16, c__1927000678__auto____25, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____25))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var vec__716000069__25 any; var root_432 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_432, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_434 lang.IFn; if linked_433 == nil { ifn_434 = lang.IFn_Cast(root_432) } else { ifn_434 = nil }; var arg_435 any = seq_716000056__24; if linked_433 == nil { vec__716000069__25 = ifn_434.Invoke_O__O(arg_435) } else { vec__716000069__25 = linked_433.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_432, arg_435) }; var dir__26 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000069__25, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__27 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000069__25, lang.RT_IntCast_J__I_NoInit(1), nil); var f__28 any; var root_596 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_597 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_596, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_598 lang.IFn


					if linked_597 == nil { ifn_598 = lang.IFn_Cast(root_596) } else { ifn_598 = nil }; var arg_599 any = dir__26; var arg_600 any = rel__27; if linked_597 == nil { f__28 = ifn_598.Invoke_O_O__O(arg_599, arg_600) } else { f__28 = linked_597.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_596, arg_599, arg_600) }
//line :175:1
					var parent__29 any = jrt.File_Cast(f__28).GetParentFile__File(); var siblings__30 any = lang.IFn_Cast(listing__11).Invoke_O__O(parent__29); var p0__31 any = lang.IFn_Cast(plan__8).Invoke_O_O_O__O(jrt.File_Cast(f__28).GetName__String().Ref(), siblings__30, opts__3); var s__32 any






					if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_24.Invoke_O__O(p0__31)) { s__32 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_78.GetRawRoot__O()).Invoke_O__O(f__28) } else { s__32 = nil }
//line :175:1
					var p__33 any







					if jrt.J2g_Truth(s__32) { p__33 = lang.IFn_Cast(refine__10).Invoke_O_O_O_O__O(p0__31, jrt.File_Cast(f__28).GetName__String().Ref(), siblings__30, s__32) } else { p__33 = p0__31 }
//line :175:1
					var rel_out__34 any; var d__34 any; var tmp17 any; var root_605 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_606 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_605, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_607 lang.IFn








					if linked_606 == nil { ifn_607 = lang.IFn_Cast(root_605) } else { ifn_607 = nil }; var arg_608 any = rel__27; if linked_606 == nil { tmp17 = ifn_607.Invoke_O__O(arg_608) } else { tmp17 = linked_606.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_605, arg_608) }; d__34 = jrt.File_Cast(tmp17).GetParent__String().Ref(); if jrt.J2g_Truth(d__34) { rel_out__34 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_29, nil), jrt.RefArrayOf(jrt.Object_class, d__34, nil, A_arbace_repr_clojure_A_const_28.Invoke_O__O(p__33))).Ref() } else { rel_out__34 = A_arbace_repr_clojure_A_const_28.Invoke_O__O(p__33) }
					if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_33.Invoke_O__O(p__33)) {

						var root_689 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_690 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_689, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_691 lang.IFn; if linked_690 == nil { ifn_691 = lang.IFn_Cast(root_689) } else { ifn_691 = nil }; var arg_692 any = stats__12; var arg_693 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_694 any = A_arbace_repr_clojure_A_const_93; var arg_695 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_690 == nil { ifn_691.Invoke_O_O_O_O__O(arg_692, arg_693, arg_694, arg_695) } else { linked_690.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_689, arg_692, arg_693, arg_694, arg_695) }
						var root_696 any = A_arbace_repr_clojure_A_const_88.GetRawRoot__O(); var linked_697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_696, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_698 lang.IFn; if linked_697 == nil { ifn_698 = lang.IFn_Cast(root_696) } else { ifn_698 = nil }; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_89.GetRawRoot__O()); var tmp19 any = A_arbace_repr_clojure_A_const_90; var arg_699 any = tmp18.Invoke_O_O__O(tmp19, A_arbace_repr_clojure_A_const_91.Get__O()); if linked_697 == nil { ifn_698.Invoke_O__O(arg_699) } else { linked_697.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_696, arg_699) }; var tmp20 *lang.Compiler_AOTFn; var fnbody__624 any = A_arbace_repr_clojure_run_fn__716000072_A_New_O_O(f__28, p__33); var tmp21 *jrt.Class; var fncls__623 *jrt.Class = A_arbace_repr_clojure_run_fn__716000072_A_fn_class; if fncls__623 == nil { var fncls__623d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_93, false, fnbody__624); A_arbace_repr_clojure_run_fn__716000072_A_fn_class = fncls__623d; tmp21 = fncls__623d } else { tmp21 = fncls__623 }; tmp20 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__624, tmp21, nil); Up_Compiler_AOTFn_IFn(tmp20).Invoke__O() } else {
//line :185:1
							if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_81.Invoke_O__O(p__33)) {




								if jrt.J2g_Truth(out__2) { var t__35 any; var root_705 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_706 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_705, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_707 lang.IFn
									if linked_706 == nil { ifn_707 = lang.IFn_Cast(root_705) } else { ifn_707 = nil }; var arg_708 any = out__2; var arg_709 any = rel__27; if linked_706 == nil { t__35 = ifn_707.Invoke_O_O__O(arg_708, arg_709) } else { t__35 = linked_706.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_705, arg_708, arg_709) }
									lang.IFn_Cast(A_arbace_repr_clojure_A_const_95.GetRawRoot__O()).Invoke_O__O(t__35)
									lang.IFn_Cast(A_arbace_repr_clojure_A_const_94.GetRawRoot__O()).Invoke_O_O__O(f__28, t__35) }
								var root_625 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_625, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_627 lang.IFn; if linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any = stats__12; var arg_629 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_630 any = A_arbace_repr_clojure_A_const_84; var arg_631 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_626 == nil { ifn_627.Invoke_O_O_O_O__O(arg_628, arg_629, arg_630, arg_631) } else { linked_626.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_625, arg_628, arg_629, arg_630, arg_631) } } else {
//line :185:1
									if A_arbace_repr_clojure_A_const_34 != nil { var r__35 any; var tmp22 *lang.Compiler_AOTFn; var fnbody__673 any = A_arbace_repr_clojure_run_fn__716000074_A_New_O_O_O_O_O_O(f__28, p__33, s__32, stats__12, translate_text__9, skip__5); var tmp23 *jrt.Class
										var fncls__672 /*line :185:1*/*jrt.Class = A_arbace_repr_clojure_run_fn__716000074_A_fn_class










										if fncls__672 == nil { var fncls__672d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_94, false, fnbody__673); A_arbace_repr_clojure_run_fn__716000074_A_fn_class = fncls__672d; tmp23 = fncls__672d } else { tmp23 = fncls__672 }; tmp22 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__673, tmp23, nil); r__35 = Up_Compiler_AOTFn_IFn(tmp22).Invoke__O()




										if jrt.J2g_Truth(r__35) {
											var root_719 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_720 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_719, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_721 lang.IFn; if linked_720 == nil { ifn_721 = lang.IFn_Cast(root_719) } else { ifn_721 = nil }; var arg_722 any = stats__12; var arg_723 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_724 any; if lang.Util_Equiv_O_O__Z_NoInit(s__32, r__35) { arg_724 = A_arbace_repr_clojure_A_const_96 } else { arg_724 = A_arbace_repr_clojure_A_const_97 }; var arg_725 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_720 == nil { ifn_721.Invoke_O_O_O_O__O(arg_722, arg_723, arg_724, arg_725) } else { linked_720.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_719, arg_722, arg_723, arg_724, arg_725) }
											if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__33)) { var root_726 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_727 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_726, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_728 lang.IFn; if linked_727 == nil { ifn_728 = lang.IFn_Cast(root_726) } else { ifn_728 = nil }; var arg_729 any = stats__12; var arg_730 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_731 any = A_arbace_repr_clojure_A_const_27; var arg_732 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_727 == nil { ifn_728.Invoke_O_O_O_O__O(arg_729, arg_730, arg_731, arg_732) } else { linked_727.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_726, arg_729, arg_730, arg_731, arg_732) } }
											if jrt.J2g_Truth(out__2) { var t__36 any; var root_674 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_674, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_676 lang.IFn
												if linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any = out__2; var arg_678 any = rel_out__34; if linked_675 == nil { t__36 = ifn_676.Invoke_O_O__O(arg_677, arg_678) } else { t__36 = linked_675.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_674, arg_677, arg_678) }
												lang.IFn_Cast(A_arbace_repr_clojure_A_const_95.GetRawRoot__O()).Invoke_O__O(t__36)
												lang.IFn_Cast(A_arbace_repr_clojure_A_const_92.GetRawRoot__O()).Invoke_O_O__O(t__36, r__35) } else {
//line :204:1
													var moved__36 any; var root_684 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_685 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_684, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_686 lang.IFn



													if linked_685 == nil { ifn_686 = lang.IFn_Cast(root_684) } else { ifn_686 = nil }; var arg_687 any = jrt.File_Cast(f__28).GetName__String().Ref(); var arg_688 any = A_arbace_repr_clojure_A_const_28.Invoke_O__O(p__33); if linked_685 == nil { moved__36 = ifn_686.Invoke_O_O__O(arg_687, arg_688) } else { moved__36 = linked_685.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_684, arg_687, arg_688) }
													var tmp24 any; var or__1927000174__auto____37 any; var root_737 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_738 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_737, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_739 lang.IFn; if linked_738 == nil { ifn_739 = lang.IFn_Cast(root_737) } else { ifn_739 = nil }; var arg_740 any = s__32; var arg_741 any = r__35; if linked_738 == nil { or__1927000174__auto____37 = ifn_739.Invoke_O_O__O(arg_740, arg_741) } else { or__1927000174__auto____37 = linked_738.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_737, arg_740, arg_741) }; if jrt.J2g_Truth(or__1927000174__auto____37) { tmp24 = or__1927000174__auto____37 } else { tmp24 = moved__36 }; if jrt.J2g_Truth(tmp24) {
														var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_92.GetRawRoot__O()); var tmp26 any; var root_747 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_748 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_747, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_749 lang.IFn; if linked_748 == nil { ifn_749 = lang.IFn_Cast(root_747) } else { ifn_749 = nil }; var arg_750 any = parent__29; var arg_751 any = A_arbace_repr_clojure_A_const_28.Invoke_O__O(p__33); if linked_748 == nil { tmp26 = ifn_749.Invoke_O_O__O(arg_750, arg_751) } else { tmp26 = linked_748.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_747, arg_750, arg_751) }; tmp25.Invoke_O_O__O(tmp26, r__35) }
													if jrt.J2g_Truth(moved__36) { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(f__28).Delete__Z()) } } } } } }
//line :175:1
					var tmp27 any; var root_752 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_752, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_754 lang.IFn; if linked_753 == nil { ifn_754 = lang.IFn_Cast(root_752) } else { ifn_754 = nil }; var arg_755 any = seq_716000056__24; if linked_753 == nil { tmp27 = ifn_754.Invoke_O__O(arg_755) } else { tmp27 = linked_753.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_752, arg_755) }; seq_716000056__19, chunk_716000057__20, count_716000058__21, i_716000059__22 = tmp27, nil, 0, 0; continue L2 } } }; break L2 }; seq_716000048__13, chunk_716000049__14, count_716000050__15, i_716000051__16 = seq_716000048__13, chunk_716000049__14, count_716000050__15, lang.Numbers_Unchecked_inc_J__J_NoInit(i_716000051__16); continue L1 } else { var temp__1927000414__auto____17 any; var root_392 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_392, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_394 lang.IFn; if linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any = seq_716000048__13; if linked_393 == nil { temp__1927000414__auto____17 = ifn_394.Invoke_O__O(arg_395) } else { temp__1927000414__auto____17 = linked_393.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_392, arg_395) }; if jrt.J2g_Truth(temp__1927000414__auto____17) { var seq_716000048__18 any = temp__1927000414__auto____17; var tmp28 any; var root_396 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_396, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_398 lang.IFn; if linked_397 == nil { ifn_398 = lang.IFn_Cast(root_396) } else { ifn_398 = nil }; var arg_399 any = seq_716000048__18; if linked_397 == nil { tmp28 = ifn_398.Invoke_O__O(arg_399) } else { tmp28 = linked_397.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_396, arg_399) }; if jrt.J2g_Truth(tmp28) { var c__1927000678__auto____19 any; var root_400 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_400, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_402 lang.IFn; if linked_401 == nil { ifn_402 = lang.IFn_Cast(root_400) } else { ifn_402 = nil }; var arg_403 any = seq_716000048__18; if linked_401 == nil { c__1927000678__auto____19 = ifn_402.Invoke_O__O(arg_403) } else { c__1927000678__auto____19 = linked_401.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_400, arg_403) }; var tmp29 any; var root_756 any = A_arbace_repr_clojure_A_const_65.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_756, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_758 lang.IFn; if linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any = seq_716000048__18; if linked_757 == nil { tmp29 = ifn_758.Invoke_O__O(arg_759) } else { tmp29 = linked_757.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_756, arg_759) }; seq_716000048__13, chunk_716000049__14, count_716000050__15, i_716000051__16 = tmp29, c__1927000678__auto____19, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____19))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var src__19 any; var root_404 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_404, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_406 lang.IFn; if linked_405 == nil { ifn_406 = lang.IFn_Cast(root_404) } else { ifn_406 = nil }; var arg_407 any = seq_716000048__18; if linked_405 == nil { src__19 = ifn_406.Invoke_O__O(arg_407) } else { src__19 = linked_405.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_404, arg_407) }; var srcf__20 any; var root_760 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_761 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_760, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_762 lang.IFn
						if linked_761 == nil { ifn_762 = lang.IFn_Cast(root_760) } else { ifn_762 = nil }; var arg_763 any = src__19; if linked_761 == nil { srcf__20 = ifn_762.Invoke_O__O(arg_763) } else { srcf__20 = linked_761.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_760, arg_763) }
//line :175:1
						var seq_716000052__21 any; var root_764 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_764, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_766 lang.IFn; if linked_765 == nil { ifn_766 = lang.IFn_Cast(root_764) } else { ifn_766 = nil }; var arg_767 any; var root_768 any = A_arbace_repr_clojure_A_const_77.GetRawRoot__O(); var linked_769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_768, A_arbace_repr_clojure_files_A_fn_class); var ifn_770 lang.IFn

						if linked_769 == nil { ifn_770 = lang.IFn_Cast(root_768) } else { ifn_770 = nil }; var arg_771 any = srcf__20; if linked_769 == nil { arg_767 = ifn_770.Invoke_O__O(arg_771) } else { arg_767 = linked_769.(*A_arbace_repr_clojure_files_A).Invoke_O_O__O(root_768, arg_771) }
//line :175:1
						if linked_765 == nil { seq_716000052__21 = ifn_766.Invoke_O__O(arg_767) } else { seq_716000052__21 = linked_765.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_764, arg_767) }; var chunk_716000053__22 any; var count_716000054__23 int64 = 0; var i_716000055__24 int64 = 0; L3: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_716000055__24, count_716000054__23) { var vec__716000078__25 any = lang.Indexed_Cast(chunk_716000053__22).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_716000055__24)); var dir__26_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000078__25, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__27_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000078__25, lang.RT_IntCast_J__I_NoInit(1), nil); var f__28_2 any; var root_788 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_789 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_788, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_790 lang.IFn


							if linked_789 == nil { ifn_790 = lang.IFn_Cast(root_788) } else { ifn_790 = nil }; var arg_791 any = dir__26_2; var arg_792 any = rel__27_2; if linked_789 == nil { f__28_2 = ifn_790.Invoke_O_O__O(arg_791, arg_792) } else { f__28_2 = linked_789.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_788, arg_791, arg_792) }
//line :175:1
							var parent__29_2 any = jrt.File_Cast(f__28_2).GetParentFile__File(); var siblings__30_2 any = lang.IFn_Cast(listing__11).Invoke_O__O(parent__29_2); var p0__31_2 any = lang.IFn_Cast(plan__8).Invoke_O_O_O__O(jrt.File_Cast(f__28_2).GetName__String().Ref(), siblings__30_2, opts__3); var s__32_2 any






							if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_24.Invoke_O__O(p0__31_2)) { s__32_2 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_78.GetRawRoot__O()).Invoke_O__O(f__28_2) } else { s__32_2 = nil }
//line :175:1
							var p__33_2 any







							if jrt.J2g_Truth(s__32_2) { p__33_2 = lang.IFn_Cast(refine__10).Invoke_O_O_O_O__O(p0__31_2, jrt.File_Cast(f__28_2).GetName__String().Ref(), siblings__30_2, s__32_2) } else { p__33_2 = p0__31_2 }
//line :175:1
							var rel_out__34_2 any; var d__34_2 any; var tmp30 any; var root_797 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_798 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_797, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_799 lang.IFn








							if linked_798 == nil { ifn_799 = lang.IFn_Cast(root_797) } else { ifn_799 = nil }; var arg_800 any = rel__27_2; if linked_798 == nil { tmp30 = ifn_799.Invoke_O__O(arg_800) } else { tmp30 = linked_798.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_797, arg_800) }; d__34_2 = jrt.File_Cast(tmp30).GetParent__String().Ref(); if jrt.J2g_Truth(d__34_2) { rel_out__34_2 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_29, nil), jrt.RefArrayOf(jrt.Object_class, d__34_2, nil, A_arbace_repr_clojure_A_const_28.Invoke_O__O(p__33_2))).Ref() } else { rel_out__34_2 = A_arbace_repr_clojure_A_const_28.Invoke_O__O(p__33_2) }
							if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_33.Invoke_O__O(p__33_2)) {

								var root_881 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_882 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_881, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_883 lang.IFn; if linked_882 == nil { ifn_883 = lang.IFn_Cast(root_881) } else { ifn_883 = nil }; var arg_884 any = stats__12; var arg_885 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_886 any = A_arbace_repr_clojure_A_const_93; var arg_887 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_882 == nil { ifn_883.Invoke_O_O_O_O__O(arg_884, arg_885, arg_886, arg_887) } else { linked_882.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_881, arg_884, arg_885, arg_886, arg_887) }
								var root_888 any = A_arbace_repr_clojure_A_const_88.GetRawRoot__O(); var linked_889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_888, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_890 lang.IFn; if linked_889 == nil { ifn_890 = lang.IFn_Cast(root_888) } else { ifn_890 = nil }; var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_89.GetRawRoot__O()); var tmp32 any = A_arbace_repr_clojure_A_const_90; var arg_891 any = tmp31.Invoke_O_O__O(tmp32, A_arbace_repr_clojure_A_const_91.Get__O()); if linked_889 == nil { ifn_890.Invoke_O__O(arg_891) } else { linked_889.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_888, arg_891) }; var tmp33 *lang.Compiler_AOTFn; var fnbody__816 any = A_arbace_repr_clojure_run_fn__716000081_A_New_O_O(f__28_2, p__33_2); var tmp34 *jrt.Class; var fncls__815 *jrt.Class = A_arbace_repr_clojure_run_fn__716000081_A_fn_class; if fncls__815 == nil { var fncls__815d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_95, false, fnbody__816); A_arbace_repr_clojure_run_fn__716000081_A_fn_class = fncls__815d; tmp34 = fncls__815d } else { tmp34 = fncls__815 }; tmp33 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__816, tmp34, nil); Up_Compiler_AOTFn_IFn(tmp33).Invoke__O() } else {
//line :185:1
									if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_81.Invoke_O__O(p__33_2)) {




										if jrt.J2g_Truth(out__2) { var t__35_2 any; var root_897 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_898 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_897, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_899 lang.IFn
											if linked_898 == nil { ifn_899 = lang.IFn_Cast(root_897) } else { ifn_899 = nil }; var arg_900 any = out__2; var arg_901 any = rel__27_2; if linked_898 == nil { t__35_2 = ifn_899.Invoke_O_O__O(arg_900, arg_901) } else { t__35_2 = linked_898.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_897, arg_900, arg_901) }
											lang.IFn_Cast(A_arbace_repr_clojure_A_const_95.GetRawRoot__O()).Invoke_O__O(t__35_2)
											lang.IFn_Cast(A_arbace_repr_clojure_A_const_94.GetRawRoot__O()).Invoke_O_O__O(f__28_2, t__35_2) }
										var root_817 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_818 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_817, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_819 lang.IFn; if linked_818 == nil { ifn_819 = lang.IFn_Cast(root_817) } else { ifn_819 = nil }; var arg_820 any = stats__12; var arg_821 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_822 any = A_arbace_repr_clojure_A_const_84; var arg_823 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_818 == nil { ifn_819.Invoke_O_O_O_O__O(arg_820, arg_821, arg_822, arg_823) } else { linked_818.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_817, arg_820, arg_821, arg_822, arg_823) } } else {
//line :185:1
											if A_arbace_repr_clojure_A_const_34 != nil { var r__35_2 any; var tmp35 *lang.Compiler_AOTFn; var fnbody__865 any = A_arbace_repr_clojure_run_fn__716000083_A_New_O_O_O_O_O_O(f__28_2, p__33_2, s__32_2, stats__12, translate_text__9, skip__5); var tmp36 *jrt.Class
												var fncls__864 /*line :185:1*/*jrt.Class = A_arbace_repr_clojure_run_fn__716000083_A_fn_class










												if fncls__864 == nil { var fncls__864d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_96, false, fnbody__865); A_arbace_repr_clojure_run_fn__716000083_A_fn_class = fncls__864d; tmp36 = fncls__864d } else { tmp36 = fncls__864 }; tmp35 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__865, tmp36, nil); r__35_2 = Up_Compiler_AOTFn_IFn(tmp35).Invoke__O()




												if jrt.J2g_Truth(r__35_2) {
													var root_911 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_912 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_911, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_913 lang.IFn; if linked_912 == nil { ifn_913 = lang.IFn_Cast(root_911) } else { ifn_913 = nil }; var arg_914 any = stats__12; var arg_915 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_916 any; if lang.Util_Equiv_O_O__Z_NoInit(s__32_2, r__35_2) { arg_916 = A_arbace_repr_clojure_A_const_96 } else { arg_916 = A_arbace_repr_clojure_A_const_97 }; var arg_917 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_912 == nil { ifn_913.Invoke_O_O_O_O__O(arg_914, arg_915, arg_916, arg_917) } else { linked_912.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_911, arg_914, arg_915, arg_916, arg_917) }
													if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__33_2)) { var root_918 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_919 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_918, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_920 lang.IFn; if linked_919 == nil { ifn_920 = lang.IFn_Cast(root_918) } else { ifn_920 = nil }; var arg_921 any = stats__12; var arg_922 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_923 any = A_arbace_repr_clojure_A_const_27; var arg_924 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_919 == nil { ifn_920.Invoke_O_O_O_O__O(arg_921, arg_922, arg_923, arg_924) } else { linked_919.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_918, arg_921, arg_922, arg_923, arg_924) } }
													if jrt.J2g_Truth(out__2) { var t__36_2 any; var root_866 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_867 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_866, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_868 lang.IFn
														if linked_867 == nil { ifn_868 = lang.IFn_Cast(root_866) } else { ifn_868 = nil }; var arg_869 any = out__2; var arg_870 any = rel_out__34_2; if linked_867 == nil { t__36_2 = ifn_868.Invoke_O_O__O(arg_869, arg_870) } else { t__36_2 = linked_867.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_866, arg_869, arg_870) }
														lang.IFn_Cast(A_arbace_repr_clojure_A_const_95.GetRawRoot__O()).Invoke_O__O(t__36_2)
														lang.IFn_Cast(A_arbace_repr_clojure_A_const_92.GetRawRoot__O()).Invoke_O_O__O(t__36_2, r__35_2) } else {
//line :204:1
															var moved__36_2 any; var root_876 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_877 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_876, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_878 lang.IFn



															if linked_877 == nil { ifn_878 = lang.IFn_Cast(root_876) } else { ifn_878 = nil }; var arg_879 any = jrt.File_Cast(f__28_2).GetName__String().Ref(); var arg_880 any = A_arbace_repr_clojure_A_const_28.Invoke_O__O(p__33_2); if linked_877 == nil { moved__36_2 = ifn_878.Invoke_O_O__O(arg_879, arg_880) } else { moved__36_2 = linked_877.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_876, arg_879, arg_880) }
															var tmp37 any; var or__1927000174__auto____37_2 any; var root_929 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_930 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_929, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_931 lang.IFn; if linked_930 == nil { ifn_931 = lang.IFn_Cast(root_929) } else { ifn_931 = nil }; var arg_932 any = s__32_2; var arg_933 any = r__35_2; if linked_930 == nil { or__1927000174__auto____37_2 = ifn_931.Invoke_O_O__O(arg_932, arg_933) } else { or__1927000174__auto____37_2 = linked_930.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_929, arg_932, arg_933) }; if jrt.J2g_Truth(or__1927000174__auto____37_2) { tmp37 = or__1927000174__auto____37_2 } else { tmp37 = moved__36_2 }; if jrt.J2g_Truth(tmp37) {
																var tmp38 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_92.GetRawRoot__O()); var tmp39 any; var root_939 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_940 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_939, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_941 lang.IFn; if linked_940 == nil { ifn_941 = lang.IFn_Cast(root_939) } else { ifn_941 = nil }; var arg_942 any = parent__29_2; var arg_943 any = A_arbace_repr_clojure_A_const_28.Invoke_O__O(p__33_2); if linked_940 == nil { tmp39 = ifn_941.Invoke_O_O__O(arg_942, arg_943) } else { tmp39 = linked_940.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_939, arg_942, arg_943) }; tmp38.Invoke_O_O__O(tmp39, r__35_2) }
															if jrt.J2g_Truth(moved__36_2) { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(f__28_2).Delete__Z()) } } } } } }
//line :175:1
							seq_716000052__21, chunk_716000053__22, count_716000054__23, i_716000055__24 = seq_716000052__21, chunk_716000053__22, count_716000054__23, lang.Numbers_Unchecked_inc_J__J_NoInit(i_716000055__24); continue L3 } else { var temp__1927000414__auto____25 any; var root_772 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_772, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_774 lang.IFn; if linked_773 == nil { ifn_774 = lang.IFn_Cast(root_772) } else { ifn_774 = nil }; var arg_775 any = seq_716000052__21; if linked_773 == nil { temp__1927000414__auto____25 = ifn_774.Invoke_O__O(arg_775) } else { temp__1927000414__auto____25 = linked_773.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_772, arg_775) }; if jrt.J2g_Truth(temp__1927000414__auto____25) { var seq_716000052__26 any = temp__1927000414__auto____25; var tmp40 any; var root_776 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_776, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_778 lang.IFn; if linked_777 == nil { ifn_778 = lang.IFn_Cast(root_776) } else { ifn_778 = nil }; var arg_779 any = seq_716000052__26; if linked_777 == nil { tmp40 = ifn_778.Invoke_O__O(arg_779) } else { tmp40 = linked_777.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_776, arg_779) }; if jrt.J2g_Truth(tmp40) { var c__1927000678__auto____27 any; var root_780 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_780, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_782 lang.IFn; if linked_781 == nil { ifn_782 = lang.IFn_Cast(root_780) } else { ifn_782 = nil }; var arg_783 any = seq_716000052__26; if linked_781 == nil { c__1927000678__auto____27 = ifn_782.Invoke_O__O(arg_783) } else { c__1927000678__auto____27 = linked_781.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_780, arg_783) }; var tmp41 any; var root_944 any = A_arbace_repr_clojure_A_const_65.GetRawRoot__O(); var linked_945 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_944, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_946 lang.IFn; if linked_945 == nil { ifn_946 = lang.IFn_Cast(root_944) } else { ifn_946 = nil }; var arg_947 any = seq_716000052__26; if linked_945 == nil { tmp41 = ifn_946.Invoke_O__O(arg_947) } else { tmp41 = linked_945.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_944, arg_947) }; seq_716000052__21, chunk_716000053__22, count_716000054__23, i_716000055__24 = tmp41, c__1927000678__auto____27, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____27))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__716000087__27 any; var root_784 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_785 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_784, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_786 lang.IFn; if linked_785 == nil { ifn_786 = lang.IFn_Cast(root_784) } else { ifn_786 = nil }; var arg_787 any = seq_716000052__26; if linked_785 == nil { vec__716000087__27 = ifn_786.Invoke_O__O(arg_787) } else { vec__716000087__27 = linked_785.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_784, arg_787) }; var dir__28 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000087__27, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__29 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000087__27, lang.RT_IntCast_J__I_NoInit(1), nil); var f__30 any; var root_948 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_949 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_948, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_950 lang.IFn


								if linked_949 == nil { ifn_950 = lang.IFn_Cast(root_948) } else { ifn_950 = nil }; var arg_951 any = dir__28; var arg_952 any = rel__29; if linked_949 == nil { f__30 = ifn_950.Invoke_O_O__O(arg_951, arg_952) } else { f__30 = linked_949.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_948, arg_951, arg_952) }
//line :175:1
								var parent__31 any = jrt.File_Cast(f__30).GetParentFile__File(); var siblings__32 any = lang.IFn_Cast(listing__11).Invoke_O__O(parent__31); var p0__33 any = lang.IFn_Cast(plan__8).Invoke_O_O_O__O(jrt.File_Cast(f__30).GetName__String().Ref(), siblings__32, opts__3); var s__34 any






								if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_24.Invoke_O__O(p0__33)) { s__34 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_78.GetRawRoot__O()).Invoke_O__O(f__30) } else { s__34 = nil }
//line :175:1
								var p__35 any







								if jrt.J2g_Truth(s__34) { p__35 = lang.IFn_Cast(refine__10).Invoke_O_O_O_O__O(p0__33, jrt.File_Cast(f__30).GetName__String().Ref(), siblings__32, s__34) } else { p__35 = p0__33 }
//line :175:1
								var rel_out__36 any; var d__36 any; var tmp42 any; var root_957 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_958 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_957, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_959 lang.IFn








								if linked_958 == nil { ifn_959 = lang.IFn_Cast(root_957) } else { ifn_959 = nil }; var arg_960 any = rel__29; if linked_958 == nil { tmp42 = ifn_959.Invoke_O__O(arg_960) } else { tmp42 = linked_958.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_957, arg_960) }; d__36 = jrt.File_Cast(tmp42).GetParent__String().Ref(); if jrt.J2g_Truth(d__36) { rel_out__36 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_29, nil), jrt.RefArrayOf(jrt.Object_class, d__36, nil, A_arbace_repr_clojure_A_const_28.Invoke_O__O(p__35))).Ref() } else { rel_out__36 = A_arbace_repr_clojure_A_const_28.Invoke_O__O(p__35) }
								if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_33.Invoke_O__O(p__35)) {

									var root_1041 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_1042 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1041, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1043 lang.IFn; if linked_1042 == nil { ifn_1043 = lang.IFn_Cast(root_1041) } else { ifn_1043 = nil }; var arg_1044 any = stats__12; var arg_1045 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_1046 any = A_arbace_repr_clojure_A_const_93; var arg_1047 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_1042 == nil { ifn_1043.Invoke_O_O_O_O__O(arg_1044, arg_1045, arg_1046, arg_1047) } else { linked_1042.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1041, arg_1044, arg_1045, arg_1046, arg_1047) }
									var root_1048 any = A_arbace_repr_clojure_A_const_88.GetRawRoot__O(); var linked_1049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1048, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1050 lang.IFn; if linked_1049 == nil { ifn_1050 = lang.IFn_Cast(root_1048) } else { ifn_1050 = nil }; var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_89.GetRawRoot__O()); var tmp44 any = A_arbace_repr_clojure_A_const_90; var arg_1051 any = tmp43.Invoke_O_O__O(tmp44, A_arbace_repr_clojure_A_const_91.Get__O()); if linked_1049 == nil { ifn_1050.Invoke_O__O(arg_1051) } else { linked_1049.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1048, arg_1051) }; var tmp45 *lang.Compiler_AOTFn; var fnbody__976 any = A_arbace_repr_clojure_run_fn__716000090_A_New_O_O(f__30, p__35); var tmp46 *jrt.Class; var fncls__975 *jrt.Class = A_arbace_repr_clojure_run_fn__716000090_A_fn_class; if fncls__975 == nil { var fncls__975d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_97, false, fnbody__976); A_arbace_repr_clojure_run_fn__716000090_A_fn_class = fncls__975d; tmp46 = fncls__975d } else { tmp46 = fncls__975 }; tmp45 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__976, tmp46, nil); Up_Compiler_AOTFn_IFn(tmp45).Invoke__O() } else {
//line :185:1
										if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_81.Invoke_O__O(p__35)) {




											if jrt.J2g_Truth(out__2) { var t__37 any; var root_1057 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_1058 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1057, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_1059 lang.IFn
												if linked_1058 == nil { ifn_1059 = lang.IFn_Cast(root_1057) } else { ifn_1059 = nil }; var arg_1060 any = out__2; var arg_1061 any = rel__29; if linked_1058 == nil { t__37 = ifn_1059.Invoke_O_O__O(arg_1060, arg_1061) } else { t__37 = linked_1058.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_1057, arg_1060, arg_1061) }
												lang.IFn_Cast(A_arbace_repr_clojure_A_const_95.GetRawRoot__O()).Invoke_O__O(t__37)
												lang.IFn_Cast(A_arbace_repr_clojure_A_const_94.GetRawRoot__O()).Invoke_O_O__O(f__30, t__37) }
											var root_977 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_978 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_977, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_979 lang.IFn; if linked_978 == nil { ifn_979 = lang.IFn_Cast(root_977) } else { ifn_979 = nil }; var arg_980 any = stats__12; var arg_981 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_982 any = A_arbace_repr_clojure_A_const_84; var arg_983 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_978 == nil { ifn_979.Invoke_O_O_O_O__O(arg_980, arg_981, arg_982, arg_983) } else { linked_978.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_977, arg_980, arg_981, arg_982, arg_983) } } else {
//line :185:1
												if A_arbace_repr_clojure_A_const_34 != nil { var r__37 any; var tmp47 *lang.Compiler_AOTFn; var fnbody__1025 any = A_arbace_repr_clojure_run_fn__716000092_A_New_O_O_O_O_O_O(f__30, p__35, s__34, stats__12, translate_text__9, skip__5); var tmp48 *jrt.Class
													var fncls__1024 /*line :185:1*/*jrt.Class = A_arbace_repr_clojure_run_fn__716000092_A_fn_class










													if fncls__1024 == nil { var fncls__1024d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_98, false, fnbody__1025); A_arbace_repr_clojure_run_fn__716000092_A_fn_class = fncls__1024d; tmp48 = fncls__1024d } else { tmp48 = fncls__1024 }; tmp47 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1025, tmp48, nil); r__37 = Up_Compiler_AOTFn_IFn(tmp47).Invoke__O()




													if jrt.J2g_Truth(r__37) {
														var root_1071 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_1072 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1071, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1073 lang.IFn; if linked_1072 == nil { ifn_1073 = lang.IFn_Cast(root_1071) } else { ifn_1073 = nil }; var arg_1074 any = stats__12; var arg_1075 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_1076 any; if lang.Util_Equiv_O_O__Z_NoInit(s__34, r__37) { arg_1076 = A_arbace_repr_clojure_A_const_96 } else { arg_1076 = A_arbace_repr_clojure_A_const_97 }; var arg_1077 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_1072 == nil { ifn_1073.Invoke_O_O_O_O__O(arg_1074, arg_1075, arg_1076, arg_1077) } else { linked_1072.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1071, arg_1074, arg_1075, arg_1076, arg_1077) }
														if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__35)) { var root_1078 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_1079 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1078, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1080 lang.IFn; if linked_1079 == nil { ifn_1080 = lang.IFn_Cast(root_1078) } else { ifn_1080 = nil }; var arg_1081 any = stats__12; var arg_1082 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_1083 any = A_arbace_repr_clojure_A_const_27; var arg_1084 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_1079 == nil { ifn_1080.Invoke_O_O_O_O__O(arg_1081, arg_1082, arg_1083, arg_1084) } else { linked_1079.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1078, arg_1081, arg_1082, arg_1083, arg_1084) } }
														if jrt.J2g_Truth(out__2) { var t__38 any; var root_1026 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_1027 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1026, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_1028 lang.IFn
															if linked_1027 == nil { ifn_1028 = lang.IFn_Cast(root_1026) } else { ifn_1028 = nil }; var arg_1029 any = out__2; var arg_1030 any = rel_out__36; if linked_1027 == nil { t__38 = ifn_1028.Invoke_O_O__O(arg_1029, arg_1030) } else { t__38 = linked_1027.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_1026, arg_1029, arg_1030) }
															lang.IFn_Cast(A_arbace_repr_clojure_A_const_95.GetRawRoot__O()).Invoke_O__O(t__38)
															lang.IFn_Cast(A_arbace_repr_clojure_A_const_92.GetRawRoot__O()).Invoke_O_O__O(t__38, r__37) } else {
//line :204:1
																var moved__38 any; var root_1036 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_1037 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1036, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1038 lang.IFn



																if linked_1037 == nil { ifn_1038 = lang.IFn_Cast(root_1036) } else { ifn_1038 = nil }; var arg_1039 any = jrt.File_Cast(f__30).GetName__String().Ref(); var arg_1040 any = A_arbace_repr_clojure_A_const_28.Invoke_O__O(p__35); if linked_1037 == nil { moved__38 = ifn_1038.Invoke_O_O__O(arg_1039, arg_1040) } else { moved__38 = linked_1037.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1036, arg_1039, arg_1040) }
																var tmp49 any; var or__1927000174__auto____39 any; var root_1089 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_1090 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1089, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1091 lang.IFn; if linked_1090 == nil { ifn_1091 = lang.IFn_Cast(root_1089) } else { ifn_1091 = nil }; var arg_1092 any = s__34; var arg_1093 any = r__37; if linked_1090 == nil { or__1927000174__auto____39 = ifn_1091.Invoke_O_O__O(arg_1092, arg_1093) } else { or__1927000174__auto____39 = linked_1090.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1089, arg_1092, arg_1093) }; if jrt.J2g_Truth(or__1927000174__auto____39) { tmp49 = or__1927000174__auto____39 } else { tmp49 = moved__38 }; if jrt.J2g_Truth(tmp49) {
																	var tmp50 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_92.GetRawRoot__O()); var tmp51 any; var root_1099 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_1100 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1099, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_1101 lang.IFn; if linked_1100 == nil { ifn_1101 = lang.IFn_Cast(root_1099) } else { ifn_1101 = nil }; var arg_1102 any = parent__31; var arg_1103 any = A_arbace_repr_clojure_A_const_28.Invoke_O__O(p__35); if linked_1100 == nil { tmp51 = ifn_1101.Invoke_O_O__O(arg_1102, arg_1103) } else { tmp51 = linked_1100.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_1099, arg_1102, arg_1103) }; tmp50.Invoke_O_O__O(tmp51, r__37) }
																if jrt.J2g_Truth(moved__38) { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(f__30).Delete__Z()) } } } } } }
//line :175:1
								var tmp52 any; var root_1104 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_1105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1104, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1106 lang.IFn; if linked_1105 == nil { ifn_1106 = lang.IFn_Cast(root_1104) } else { ifn_1106 = nil }; var arg_1107 any = seq_716000052__26; if linked_1105 == nil { tmp52 = ifn_1106.Invoke_O__O(arg_1107) } else { tmp52 = linked_1105.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1104, arg_1107) }; seq_716000052__21, chunk_716000053__22, count_716000054__23, i_716000055__24 = tmp52, nil, 0, 0; continue L3 } } }; break L3 }; var tmp53 any; var root_1108 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_1109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1108, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1110 lang.IFn; if linked_1109 == nil { ifn_1110 = lang.IFn_Cast(root_1108) } else { ifn_1110 = nil }; var arg_1111 any = seq_716000048__18; if linked_1109 == nil { tmp53 = ifn_1110.Invoke_O__O(arg_1111) } else { tmp53 = linked_1109.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1108, arg_1111) }; seq_716000048__13, chunk_716000049__14, count_716000050__15, i_716000051__16 = tmp53, nil, 0, 0; continue L1 } } }
//line :163:1
		break L1 }; var root_384 any =







	A_arbace_repr_clojure_A_const_8.GetRawRoot__O(); var linked_385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_384, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_386 lang.IFn; if linked_385 == nil { ifn_386 = lang.IFn_Cast(root_384) } else { ifn_386 = nil }; var arg_387 any = stats__12; if linked_385 == nil { return ifn_386.Invoke_O__O(arg_387) } else { return linked_385.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_384, arg_387) } }
//line :163:1
func (t *A_arbace_repr_clojure_run_A) Invoke_O_O_O_O__O(self, sources__0, out__1, opts__2 any) any {





	var root_1112 any = A_arbace_repr_clojure_A_const_98.GetRawRoot__O(); var linked_1113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1112, A_arbace_repr_clojure_run_A_fn_class); var ifn_1114 lang.IFn; if linked_1113 == nil { ifn_1114 = lang.IFn_Cast(root_1112) } else { ifn_1114 = nil }; var arg_1115 any = A_arbace_repr_clojure_A_const_99; var arg_1116 any = sources__0; var arg_1117 any = out__1; var arg_1118 any = opts__2; if linked_1113 == nil { return ifn_1114.Invoke_O_O_O_O__O(arg_1115, arg_1116, arg_1117, arg_1118) } else { return linked_1113.(*A_arbace_repr_clojure_run_A).Invoke_O_O_O_O_O__O(root_1112, arg_1115, arg_1116, arg_1117, arg_1118)
	}
}

func A_arbace_repr_clojure_run_fn__716000046_A_New() *A_arbace_repr_clojure_run_fn__716000046_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000046_A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_repr_clojure_run_fn__716000046_A) Ctor() {}
//line :173:1
func (t *A_arbace_repr_clojure_run_fn__716000046_A) Invoke_O_O__O(self, d__1 any) any { var root_374 any = A_arbace_repr_clojure_A_const_73.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_374, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_376 lang.IFn; if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any = jrt.File_Cast(d__1).List__String1().Ref(); if linked_375 == nil { return ifn_376.Invoke_O__O(arg_377) } else { return linked_375.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_374, arg_377) } }














func A_arbace_repr_clojure_run_fn__716000063_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_run_fn__716000063_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000063_A{}; t.Ctor_O_O(p0, p1); return t }
//line :188:1
func (t *A_arbace_repr_clojure_run_fn__716000063_A) Ctor_O_O(c__f, c__p any) { t.F_f = c__f; t.F_p = c__p }
//line :188:1
func (t *A_arbace_repr_clojure_run_fn__716000063_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp3 any; var root_456 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_457 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_456, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_458 lang.IFn; if linked_457 == nil { ifn_458 = lang.IFn_Cast(root_456) } else { ifn_458 = nil }; var arg_459 any; var t_ any = t.F_f; t.F_f = nil; arg_459 = t_; if linked_457 == nil { tmp3 = ifn_458.Invoke_O__O(arg_459) } else { tmp3 = linked_457.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_456, arg_459) }; var tmp4 any = tmp3; var tmp5 *lang.Keyword = A_arbace_repr_clojure_A_const_33; var tmp6 any; var t__2 any = t.F_p; t.F_p = nil; tmp6 = t__2; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_99, tmp4, Lit_45, tmp5.Invoke_O__O(tmp6)) }; return nil }(); var root_460 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); var linked_461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_460, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_462 lang.IFn; if linked_461 == nil { ifn_462 = lang.IFn_Cast(root_460) } else { ifn_462 = nil }; if linked_461 == nil { ifn_462.Invoke__O() } else { linked_461.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_460) }; if tmp7 != nil { panic(tmp7) }; return tmp1 }
//line :188:1
func A_arbace_repr_clojure_run_fn__716000072_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_run_fn__716000072_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000072_A{}; t.Ctor_O_O(p0, p1); return t }
//line :188:1
func (t *A_arbace_repr_clojure_run_fn__716000072_A) Ctor_O_O(c__f, c__p any) { t.F_f = c__f; t.F_p = c__p }
//line :188:1
func (t *A_arbace_repr_clojure_run_fn__716000072_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp3 any; var root_616 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_617 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_616, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_618 lang.IFn; if linked_617 == nil { ifn_618 = lang.IFn_Cast(root_616) } else { ifn_618 = nil }; var arg_619 any; var t_ any = t.F_f; t.F_f = nil; arg_619 = t_; if linked_617 == nil { tmp3 = ifn_618.Invoke_O__O(arg_619) } else { tmp3 = linked_617.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_616, arg_619) }; var tmp4 any = tmp3; var tmp5 *lang.Keyword = A_arbace_repr_clojure_A_const_33; var tmp6 any; var t__2 any = t.F_p; t.F_p = nil; tmp6 = t__2; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_99, tmp4, Lit_45, tmp5.Invoke_O__O(tmp6)) }; return nil }(); var root_620 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); var linked_621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_620, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_622 lang.IFn; if linked_621 == nil { ifn_622 = lang.IFn_Cast(root_620) } else { ifn_622 = nil }; if linked_621 == nil { ifn_622.Invoke__O() } else { linked_621.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_620) }; if tmp7 != nil { panic(tmp7) }; return tmp1 }
//line :188:1
func A_arbace_repr_clojure_run_fn__716000081_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_run_fn__716000081_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000081_A{}; t.Ctor_O_O(p0, p1); return t }
//line :188:1
func (t *A_arbace_repr_clojure_run_fn__716000081_A) Ctor_O_O(c__f, c__p any) { t.F_f = c__f; t.F_p = c__p }
//line :188:1
func (t *A_arbace_repr_clojure_run_fn__716000081_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp3 any; var root_808 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_809 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_808, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_810 lang.IFn; if linked_809 == nil { ifn_810 = lang.IFn_Cast(root_808) } else { ifn_810 = nil }; var arg_811 any; var t_ any = t.F_f; t.F_f = nil; arg_811 = t_; if linked_809 == nil { tmp3 = ifn_810.Invoke_O__O(arg_811) } else { tmp3 = linked_809.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_808, arg_811) }; var tmp4 any = tmp3; var tmp5 *lang.Keyword = A_arbace_repr_clojure_A_const_33; var tmp6 any; var t__2 any = t.F_p; t.F_p = nil; tmp6 = t__2; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_99, tmp4, Lit_45, tmp5.Invoke_O__O(tmp6)) }; return nil }(); var root_812 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); var linked_813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_812, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_814 lang.IFn; if linked_813 == nil { ifn_814 = lang.IFn_Cast(root_812) } else { ifn_814 = nil }; if linked_813 == nil { ifn_814.Invoke__O() } else { linked_813.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_812) }; if tmp7 != nil { panic(tmp7) }; return tmp1 }
//line :188:1
func A_arbace_repr_clojure_run_fn__716000090_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_run_fn__716000090_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000090_A{}; t.Ctor_O_O(p0, p1); return t }
//line :188:1
func (t *A_arbace_repr_clojure_run_fn__716000090_A) Ctor_O_O(c__f, c__p any) { t.F_f = c__f; t.F_p = c__p }
//line :188:1
func (t *A_arbace_repr_clojure_run_fn__716000090_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp3 any; var root_968 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_969 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_968, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_970 lang.IFn; if linked_969 == nil { ifn_970 = lang.IFn_Cast(root_968) } else { ifn_970 = nil }; var arg_971 any; var t_ any = t.F_f; t.F_f = nil; arg_971 = t_; if linked_969 == nil { tmp3 = ifn_970.Invoke_O__O(arg_971) } else { tmp3 = linked_969.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_968, arg_971) }; var tmp4 any = tmp3; var tmp5 *lang.Keyword = A_arbace_repr_clojure_A_const_33; var tmp6 any; var t__2 any = t.F_p; t.F_p = nil; tmp6 = t__2; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_99, tmp4, Lit_45, tmp5.Invoke_O__O(tmp6)) }; return nil }(); var root_972 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); var linked_973 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_972, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_974 lang.IFn; if linked_973 == nil { ifn_974 = lang.IFn_Cast(root_972) } else { ifn_974 = nil }; if linked_973 == nil { ifn_974.Invoke__O() } else { linked_973.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_972) }; if tmp7 != nil { panic(tmp7) }; return tmp1 }







func A_arbace_repr_clojure_run_fn__716000065_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_repr_clojure_run_fn__716000065_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000065_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :196:1
func (t *A_arbace_repr_clojure_run_fn__716000065_A) Ctor_O_O_O_O_O_O(c__f, c__p, c__stats, c__s, c__translate_text, c__skip any) { t.F_f = c__f; t.F_p = c__p; t.F_stats = c__stats; t.F_s = c__s; t.F_translate_text = c__translate_text; t.F_skip = c__skip }
//line :196:1
func (t *A_arbace_repr_clojure_run_fn__716000065_A) Invoke_O__O(self any) any { var tmp1 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var t_ any = t.F_translate_text; t.F_translate_text = nil; tmp2 = t_; var tmp3 lang.IFn = lang.IFn_Cast(tmp2); var tmp4 any; var t__2 any = t.F_s; t.F_s = nil; tmp4 = t__2; var tmp5 any = tmp4; var tmp6 any; var t__3 any = t.F_p; t.F_p = nil; tmp6 = t__3; var tmp7 any = tmp6; var tmp8 any; var root_472 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_473 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_472, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_474 lang.IFn; if linked_473 == nil { ifn_474 = lang.IFn_Cast(root_472) } else { ifn_474 = nil }; var arg_475 any = t.F_f; if linked_473 == nil { tmp8 = ifn_474.Invoke_O__O(arg_475) } else { tmp8 = linked_473.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_472, arg_475) }; var tmp9 any = tmp8; var tmp10 any; var t__4 any = t.F_skip; t.F_skip = nil; tmp10 = t__4; tmp1 = tmp3.Invoke_O_O_O_O__O(tmp5, tmp7, tmp9, tmp10) }; return nil }(); if tmp11 != nil { if jrt.Exception_InstanceOf(tmp11) { var e__3 jrt.Exception_I = jrt.Exception_Cast(tmp11); var root_476 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_477 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_476, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_478 lang.IFn

	if linked_477 == nil { ifn_478 = lang.IFn_Cast(root_476) } else { ifn_478 = nil }; var arg_479 any; var t__5 any = t.F_stats; t.F_stats = nil; arg_479 = t__5; var arg_480 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_481 any = A_arbace_repr_clojure_A_const_86; var arg_482 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_477 == nil { ifn_478.Invoke_O_O_O_O__O(arg_479, arg_480, arg_481, arg_482) } else { linked_477.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_476, arg_479, arg_480, arg_481, arg_482) }
	var root_503 any = A_arbace_repr_clojure_A_const_88.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_89.GetRawRoot__O()); var tmp13 any = A_arbace_repr_clojure_A_const_90; var arg_506 any = tmp12.Invoke_O_O__O(tmp13, A_arbace_repr_clojure_A_const_91.Get__O()); if linked_504 == nil { ifn_505.Invoke_O__O(arg_506) } else { linked_504.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_503, arg_506) }; var tmp14 *lang.Compiler_AOTFn; var fnbody__502 any = A_arbace_repr_clojure_run_fn__716000065_fn__716000066_A_New_O_O(e__3, t.F_f); var tmp15 *jrt.Class; var fncls__501 *jrt.Class = A_arbace_repr_clojure_run_fn__716000065_fn__716000066_A_fn_class; if fncls__501 == nil { var fncls__501d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_100, false, fnbody__502); A_arbace_repr_clojure_run_fn__716000065_fn__716000066_A_fn_class = fncls__501d; tmp15 = fncls__501d } else { tmp15 = fncls__501 }; tmp14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__502, tmp15, nil); Up_Compiler_AOTFn_IFn(tmp14).Invoke__O()
//line :196:1
	tmp1 = nil } else { panic(tmp11) } }; return tmp1 }
//line :196:1
func A_arbace_repr_clojure_run_fn__716000074_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_repr_clojure_run_fn__716000074_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000074_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :196:1
func (t *A_arbace_repr_clojure_run_fn__716000074_A) Ctor_O_O_O_O_O_O(c__f, c__p, c__s, c__stats, c__translate_text, c__skip any) { t.F_f = c__f; t.F_p = c__p; t.F_s = c__s; t.F_stats = c__stats; t.F_translate_text = c__translate_text; t.F_skip = c__skip }
//line :196:1
func (t *A_arbace_repr_clojure_run_fn__716000074_A) Invoke_O__O(self any) any { var tmp1 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var t_ any = t.F_translate_text; t.F_translate_text = nil; tmp2 = t_; var tmp3 lang.IFn = lang.IFn_Cast(tmp2); var tmp4 any; var t__2 any = t.F_s; t.F_s = nil; tmp4 = t__2; var tmp5 any = tmp4; var tmp6 any; var t__3 any = t.F_p; t.F_p = nil; tmp6 = t__3; var tmp7 any = tmp6; var tmp8 any; var root_632 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_633 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_632, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_634 lang.IFn; if linked_633 == nil { ifn_634 = lang.IFn_Cast(root_632) } else { ifn_634 = nil }; var arg_635 any = t.F_f; if linked_633 == nil { tmp8 = ifn_634.Invoke_O__O(arg_635) } else { tmp8 = linked_633.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_632, arg_635) }; var tmp9 any = tmp8; var tmp10 any; var t__4 any = t.F_skip; t.F_skip = nil; tmp10 = t__4; tmp1 = tmp3.Invoke_O_O_O_O__O(tmp5, tmp7, tmp9, tmp10) }; return nil }(); if tmp11 != nil { if jrt.Exception_InstanceOf(tmp11) { var e__3 jrt.Exception_I = jrt.Exception_Cast(tmp11); var root_636 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_637 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_636, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_638 lang.IFn

	if linked_637 == nil { ifn_638 = lang.IFn_Cast(root_636) } else { ifn_638 = nil }; var arg_639 any; var t__5 any = t.F_stats; t.F_stats = nil; arg_639 = t__5; var arg_640 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_641 any = A_arbace_repr_clojure_A_const_86; var arg_642 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_637 == nil { ifn_638.Invoke_O_O_O_O__O(arg_639, arg_640, arg_641, arg_642) } else { linked_637.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_636, arg_639, arg_640, arg_641, arg_642) }
	var root_663 any = A_arbace_repr_clojure_A_const_88.GetRawRoot__O(); var linked_664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_663, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_665 lang.IFn; if linked_664 == nil { ifn_665 = lang.IFn_Cast(root_663) } else { ifn_665 = nil }; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_89.GetRawRoot__O()); var tmp13 any = A_arbace_repr_clojure_A_const_90; var arg_666 any = tmp12.Invoke_O_O__O(tmp13, A_arbace_repr_clojure_A_const_91.Get__O()); if linked_664 == nil { ifn_665.Invoke_O__O(arg_666) } else { linked_664.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_663, arg_666) }; var tmp14 *lang.Compiler_AOTFn; var fnbody__662 any = A_arbace_repr_clojure_run_fn__716000074_fn__716000075_A_New_O_O(e__3, t.F_f); var tmp15 *jrt.Class; var fncls__661 *jrt.Class = A_arbace_repr_clojure_run_fn__716000074_fn__716000075_A_fn_class; if fncls__661 == nil { var fncls__661d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_102, false, fnbody__662); A_arbace_repr_clojure_run_fn__716000074_fn__716000075_A_fn_class = fncls__661d; tmp15 = fncls__661d } else { tmp15 = fncls__661 }; tmp14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__662, tmp15, nil); Up_Compiler_AOTFn_IFn(tmp14).Invoke__O()
//line :196:1
	tmp1 = nil } else { panic(tmp11) } }; return tmp1 }
//line :196:1
func A_arbace_repr_clojure_run_fn__716000083_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_repr_clojure_run_fn__716000083_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000083_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :196:1
func (t *A_arbace_repr_clojure_run_fn__716000083_A) Ctor_O_O_O_O_O_O(c__f, c__p, c__s, c__stats, c__translate_text, c__skip any) { t.F_f = c__f; t.F_p = c__p; t.F_s = c__s; t.F_stats = c__stats; t.F_translate_text = c__translate_text; t.F_skip = c__skip }
//line :196:1
func (t *A_arbace_repr_clojure_run_fn__716000083_A) Invoke_O__O(self any) any { var tmp1 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var t_ any = t.F_translate_text; t.F_translate_text = nil; tmp2 = t_; var tmp3 lang.IFn = lang.IFn_Cast(tmp2); var tmp4 any; var t__2 any = t.F_s; t.F_s = nil; tmp4 = t__2; var tmp5 any = tmp4; var tmp6 any; var t__3 any = t.F_p; t.F_p = nil; tmp6 = t__3; var tmp7 any = tmp6; var tmp8 any; var root_824 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_825 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_824, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_826 lang.IFn; if linked_825 == nil { ifn_826 = lang.IFn_Cast(root_824) } else { ifn_826 = nil }; var arg_827 any = t.F_f; if linked_825 == nil { tmp8 = ifn_826.Invoke_O__O(arg_827) } else { tmp8 = linked_825.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_824, arg_827) }; var tmp9 any = tmp8; var tmp10 any; var t__4 any = t.F_skip; t.F_skip = nil; tmp10 = t__4; tmp1 = tmp3.Invoke_O_O_O_O__O(tmp5, tmp7, tmp9, tmp10) }; return nil }(); if tmp11 != nil { if jrt.Exception_InstanceOf(tmp11) { var e__3 jrt.Exception_I = jrt.Exception_Cast(tmp11); var root_828 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_829 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_828, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_830 lang.IFn

	if linked_829 == nil { ifn_830 = lang.IFn_Cast(root_828) } else { ifn_830 = nil }; var arg_831 any; var t__5 any = t.F_stats; t.F_stats = nil; arg_831 = t__5; var arg_832 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_833 any = A_arbace_repr_clojure_A_const_86; var arg_834 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_829 == nil { ifn_830.Invoke_O_O_O_O__O(arg_831, arg_832, arg_833, arg_834) } else { linked_829.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_828, arg_831, arg_832, arg_833, arg_834) }
	var root_855 any = A_arbace_repr_clojure_A_const_88.GetRawRoot__O(); var linked_856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_855, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_857 lang.IFn; if linked_856 == nil { ifn_857 = lang.IFn_Cast(root_855) } else { ifn_857 = nil }; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_89.GetRawRoot__O()); var tmp13 any = A_arbace_repr_clojure_A_const_90; var arg_858 any = tmp12.Invoke_O_O__O(tmp13, A_arbace_repr_clojure_A_const_91.Get__O()); if linked_856 == nil { ifn_857.Invoke_O__O(arg_858) } else { linked_856.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_855, arg_858) }; var tmp14 *lang.Compiler_AOTFn; var fnbody__854 any = A_arbace_repr_clojure_run_fn__716000083_fn__716000084_A_New_O_O(e__3, t.F_f); var tmp15 *jrt.Class; var fncls__853 *jrt.Class = A_arbace_repr_clojure_run_fn__716000083_fn__716000084_A_fn_class; if fncls__853 == nil { var fncls__853d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_103, false, fnbody__854); A_arbace_repr_clojure_run_fn__716000083_fn__716000084_A_fn_class = fncls__853d; tmp15 = fncls__853d } else { tmp15 = fncls__853 }; tmp14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__854, tmp15, nil); Up_Compiler_AOTFn_IFn(tmp14).Invoke__O()
//line :196:1
	tmp1 = nil } else { panic(tmp11) } }; return tmp1 }
//line :196:1
func A_arbace_repr_clojure_run_fn__716000092_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_repr_clojure_run_fn__716000092_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000092_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :196:1
func (t *A_arbace_repr_clojure_run_fn__716000092_A) Ctor_O_O_O_O_O_O(c__f, c__p, c__s, c__stats, c__translate_text, c__skip any) { t.F_f = c__f; t.F_p = c__p; t.F_s = c__s; t.F_stats = c__stats; t.F_translate_text = c__translate_text; t.F_skip = c__skip }
//line :196:1
func (t *A_arbace_repr_clojure_run_fn__716000092_A) Invoke_O__O(self any) any { var tmp1 any; tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var t_ any = t.F_translate_text; t.F_translate_text = nil; tmp2 = t_; var tmp3 lang.IFn = lang.IFn_Cast(tmp2); var tmp4 any; var t__2 any = t.F_s; t.F_s = nil; tmp4 = t__2; var tmp5 any = tmp4; var tmp6 any; var t__3 any = t.F_p; t.F_p = nil; tmp6 = t__3; var tmp7 any = tmp6; var tmp8 any; var root_984 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_984, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_986 lang.IFn; if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any = t.F_f; if linked_985 == nil { tmp8 = ifn_986.Invoke_O__O(arg_987) } else { tmp8 = linked_985.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_984, arg_987) }; var tmp9 any = tmp8; var tmp10 any; var t__4 any = t.F_skip; t.F_skip = nil; tmp10 = t__4; tmp1 = tmp3.Invoke_O_O_O_O__O(tmp5, tmp7, tmp9, tmp10) }; return nil }(); if tmp11 != nil { if jrt.Exception_InstanceOf(tmp11) { var e__3 jrt.Exception_I = jrt.Exception_Cast(tmp11); var root_988 any = A_arbace_repr_clojure_A_const_82.GetRawRoot__O(); var linked_989 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_988, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_990 lang.IFn

	if linked_989 == nil { ifn_990 = lang.IFn_Cast(root_988) } else { ifn_990 = nil }; var arg_991 any; var t__5 any = t.F_stats; t.F_stats = nil; arg_991 = t__5; var arg_992 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var arg_993 any = A_arbace_repr_clojure_A_const_86; var arg_994 any = A_arbace_repr_clojure_A_const_85.GetRawRoot__O(); if linked_989 == nil { ifn_990.Invoke_O_O_O_O__O(arg_991, arg_992, arg_993, arg_994) } else { linked_989.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_988, arg_991, arg_992, arg_993, arg_994) }
	var root_1015 any = A_arbace_repr_clojure_A_const_88.GetRawRoot__O(); var linked_1016 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1015, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1017 lang.IFn; if linked_1016 == nil { ifn_1017 = lang.IFn_Cast(root_1015) } else { ifn_1017 = nil }; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_89.GetRawRoot__O()); var tmp13 any = A_arbace_repr_clojure_A_const_90; var arg_1018 any = tmp12.Invoke_O_O__O(tmp13, A_arbace_repr_clojure_A_const_91.Get__O()); if linked_1016 == nil { ifn_1017.Invoke_O__O(arg_1018) } else { linked_1016.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1015, arg_1018) }; var tmp14 *lang.Compiler_AOTFn; var fnbody__1014 any = A_arbace_repr_clojure_run_fn__716000092_fn__716000093_A_New_O_O(e__3, t.F_f); var tmp15 *jrt.Class; var fncls__1013 *jrt.Class = A_arbace_repr_clojure_run_fn__716000092_fn__716000093_A_fn_class; if fncls__1013 == nil { var fncls__1013d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_104, false, fnbody__1014); A_arbace_repr_clojure_run_fn__716000092_fn__716000093_A_fn_class = fncls__1013d; tmp15 = fncls__1013d } else { tmp15 = fncls__1013 }; tmp14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1014, tmp15, nil); Up_Compiler_AOTFn_IFn(tmp14).Invoke__O()
//line :196:1
	tmp1 = nil } else { panic(tmp11) } }; return tmp1 }


func A_arbace_repr_clojure_run_fn__716000065_fn__716000066_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_run_fn__716000065_fn__716000066_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000065_fn__716000066_A{}; t.Ctor_O_O(p0, p1); return t }
//line :199:1
func (t *A_arbace_repr_clojure_run_fn__716000065_fn__716000066_A) Ctor_O_O(c__e, c__f any) { t.F_e = c__e; t.F_f = c__f }
//line :199:1
func (t *A_arbace_repr_clojure_run_fn__716000065_fn__716000066_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp3 any; var root_490 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_491 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_490, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_492 lang.IFn; if linked_491 == nil { ifn_492 = lang.IFn_Cast(root_490) } else { ifn_492 = nil }; var arg_493 any; var t_ any = t.F_f; t.F_f = nil; arg_493 = t_; if linked_491 == nil { tmp3 = ifn_492.Invoke_O__O(arg_493) } else { tmp3 = linked_491.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_490, arg_493) }; var tmp4 any = tmp3; var tmp5 any; var root_494 any = A_arbace_repr_clojure_A_const_87.GetRawRoot__O(); var linked_495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_494, aot_arbace_core.A_arbace_core_ex_message_A_fn_class); var ifn_496 lang.IFn; if linked_495 == nil { ifn_496 = lang.IFn_Cast(root_494) } else { ifn_496 = nil }; var arg_497 any; var t__2 any = t.F_e; t.F_e = nil; arg_497 = t__2; if linked_495 == nil { tmp5 = ifn_496.Invoke_O__O(arg_497) } else { tmp5 = linked_495.(*aot_arbace_core.A_arbace_core_ex_message_A).Invoke_O_O__O(root_494, arg_497) }; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_101, tmp4, Lit_45, tmp5) }; return nil }(); var root_498 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; if linked_499 == nil { ifn_500.Invoke__O() } else { linked_499.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_498) }; if tmp6 != nil { panic(tmp6) }; return tmp1 }
//line :199:1
func A_arbace_repr_clojure_run_fn__716000074_fn__716000075_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_run_fn__716000074_fn__716000075_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000074_fn__716000075_A{}; t.Ctor_O_O(p0, p1); return t }
//line :199:1
func (t *A_arbace_repr_clojure_run_fn__716000074_fn__716000075_A) Ctor_O_O(c__e, c__f any) { t.F_e = c__e; t.F_f = c__f }
//line :199:1
func (t *A_arbace_repr_clojure_run_fn__716000074_fn__716000075_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp3 any; var root_650 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_651 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_650, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_652 lang.IFn; if linked_651 == nil { ifn_652 = lang.IFn_Cast(root_650) } else { ifn_652 = nil }; var arg_653 any; var t_ any = t.F_f; t.F_f = nil; arg_653 = t_; if linked_651 == nil { tmp3 = ifn_652.Invoke_O__O(arg_653) } else { tmp3 = linked_651.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_650, arg_653) }; var tmp4 any = tmp3; var tmp5 any; var root_654 any = A_arbace_repr_clojure_A_const_87.GetRawRoot__O(); var linked_655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_654, aot_arbace_core.A_arbace_core_ex_message_A_fn_class); var ifn_656 lang.IFn; if linked_655 == nil { ifn_656 = lang.IFn_Cast(root_654) } else { ifn_656 = nil }; var arg_657 any; var t__2 any = t.F_e; t.F_e = nil; arg_657 = t__2; if linked_655 == nil { tmp5 = ifn_656.Invoke_O__O(arg_657) } else { tmp5 = linked_655.(*aot_arbace_core.A_arbace_core_ex_message_A).Invoke_O_O__O(root_654, arg_657) }; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_101, tmp4, Lit_45, tmp5) }; return nil }(); var root_658 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); var linked_659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_658, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_660 lang.IFn; if linked_659 == nil { ifn_660 = lang.IFn_Cast(root_658) } else { ifn_660 = nil }; if linked_659 == nil { ifn_660.Invoke__O() } else { linked_659.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_658) }; if tmp6 != nil { panic(tmp6) }; return tmp1 }
//line :199:1
func A_arbace_repr_clojure_run_fn__716000083_fn__716000084_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_run_fn__716000083_fn__716000084_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000083_fn__716000084_A{}; t.Ctor_O_O(p0, p1); return t }
//line :199:1
func (t *A_arbace_repr_clojure_run_fn__716000083_fn__716000084_A) Ctor_O_O(c__e, c__f any) { t.F_e = c__e; t.F_f = c__f }
//line :199:1
func (t *A_arbace_repr_clojure_run_fn__716000083_fn__716000084_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp3 any; var root_842 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_843 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_842, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_844 lang.IFn; if linked_843 == nil { ifn_844 = lang.IFn_Cast(root_842) } else { ifn_844 = nil }; var arg_845 any; var t_ any = t.F_f; t.F_f = nil; arg_845 = t_; if linked_843 == nil { tmp3 = ifn_844.Invoke_O__O(arg_845) } else { tmp3 = linked_843.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_842, arg_845) }; var tmp4 any = tmp3; var tmp5 any; var root_846 any = A_arbace_repr_clojure_A_const_87.GetRawRoot__O(); var linked_847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_846, aot_arbace_core.A_arbace_core_ex_message_A_fn_class); var ifn_848 lang.IFn; if linked_847 == nil { ifn_848 = lang.IFn_Cast(root_846) } else { ifn_848 = nil }; var arg_849 any; var t__2 any = t.F_e; t.F_e = nil; arg_849 = t__2; if linked_847 == nil { tmp5 = ifn_848.Invoke_O__O(arg_849) } else { tmp5 = linked_847.(*aot_arbace_core.A_arbace_core_ex_message_A).Invoke_O_O__O(root_846, arg_849) }; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_101, tmp4, Lit_45, tmp5) }; return nil }(); var root_850 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); var linked_851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_850, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_852 lang.IFn; if linked_851 == nil { ifn_852 = lang.IFn_Cast(root_850) } else { ifn_852 = nil }; if linked_851 == nil { ifn_852.Invoke__O() } else { linked_851.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_850) }; if tmp6 != nil { panic(tmp6) }; return tmp1 }
//line :199:1
func A_arbace_repr_clojure_run_fn__716000092_fn__716000093_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_run_fn__716000092_fn__716000093_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_fn__716000092_fn__716000093_A{}; t.Ctor_O_O(p0, p1); return t }
//line :199:1
func (t *A_arbace_repr_clojure_run_fn__716000092_fn__716000093_A) Ctor_O_O(c__e, c__f any) { t.F_e = c__e; t.F_f = c__f }
//line :199:1
func (t *A_arbace_repr_clojure_run_fn__716000092_fn__716000093_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp3 any; var root_1002 any = A_arbace_repr_clojure_A_const_62.GetRawRoot__O(); var linked_1003 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1002, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1004 lang.IFn; if linked_1003 == nil { ifn_1004 = lang.IFn_Cast(root_1002) } else { ifn_1004 = nil }; var arg_1005 any; var t_ any = t.F_f; t.F_f = nil; arg_1005 = t_; if linked_1003 == nil { tmp3 = ifn_1004.Invoke_O__O(arg_1005) } else { tmp3 = linked_1003.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1002, arg_1005) }; var tmp4 any = tmp3; var tmp5 any; var root_1006 any = A_arbace_repr_clojure_A_const_87.GetRawRoot__O(); var linked_1007 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1006, aot_arbace_core.A_arbace_core_ex_message_A_fn_class); var ifn_1008 lang.IFn; if linked_1007 == nil { ifn_1008 = lang.IFn_Cast(root_1006) } else { ifn_1008 = nil }; var arg_1009 any; var t__2 any = t.F_e; t.F_e = nil; arg_1009 = t__2; if linked_1007 == nil { tmp5 = ifn_1008.Invoke_O__O(arg_1009) } else { tmp5 = linked_1007.(*aot_arbace_core.A_arbace_core_ex_message_A).Invoke_O_O__O(root_1006, arg_1009) }; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_101, tmp4, Lit_45, tmp5) }; return nil }(); var root_1010 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); var linked_1011 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1010, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1012 lang.IFn; if linked_1011 == nil { ifn_1012 = lang.IFn_Cast(root_1010) } else { ifn_1012 = nil }; if linked_1011 == nil { ifn_1012.Invoke__O() } else { linked_1011.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1010) }; if tmp6 != nil { panic(tmp6) }; return tmp1 }














func A_arbace_repr_clojure_tree_A_New() *A_arbace_repr_clojure_tree_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_tree_A{}; t.Ctor(); return t }
//line :214:1
func (t *A_arbace_repr_clojure_tree_A) Ctor() {}
//line :214:1
func (t *A_arbace_repr_clojure_tree_A) Invoke_O_O__O(self, sources__0 any) any {


	var root_1119 any = A_arbace_repr_clojure_A_const_100.GetRawRoot__O(); var linked_1120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1119, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1121 lang.IFn; if linked_1120 == nil { ifn_1121 = lang.IFn_Cast(root_1119) } else { ifn_1121 = nil }; var arg_1122 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_101.GetRawRoot__O()).Invoke__O(); var arg_1123 any; var iter__1927001039__auto____2 any; var fnbody__1235 any = A_arbace_repr_clojure_tree_iter__716000097__716000103_A_New(); var tmp1 *jrt.Class; var fncls__1234 *jrt.Class = A_arbace_repr_clojure_tree_iter__716000097__716000103_A_fn_class
	if fncls__1234 == nil { var fncls__1234d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_122, false, nil); A_arbace_repr_clojure_tree_iter__716000097__716000103_A_fn_class = fncls__1234d; tmp1 = fncls__1234d } else { tmp1 = fncls__1234 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1235, tmp1, nil); arg_1123 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(sources__0)
//line :217:1
	if linked_1120 == nil { return ifn_1121.Invoke_O_O__O(arg_1122, arg_1123) } else { return linked_1120.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1119, arg_1122, arg_1123) } }
func A_arbace_repr_clojure_tree_iter__716000097__716000103_A_New() *A_arbace_repr_clojure_tree_iter__716000097__716000103_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_tree_iter__716000097__716000103_A{}; t.Ctor(); return t }
//line :218:1
func (t *A_arbace_repr_clojure_tree_iter__716000097__716000103_A) Ctor() {}
//line :218:1
func (t *A_arbace_repr_clojure_tree_iter__716000097__716000103_A) Invoke_O_O__O(self, s__716000098__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1233 any = A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_A_New_O_O(self, s__716000098__1); var tmp2 *jrt.Class; var fncls__1232 *jrt.Class = A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_A_fn_class; if fncls__1232 == nil { var fncls__1232d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_123, false, fnbody__1233); A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_A_fn_class = fncls__1232d; tmp2 = fncls__1232d } else { tmp2 = fncls__1232 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1233, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :218:1
func A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_A{}; t.Ctor_O_O(p0, p1); return t }
//line :218:1
func (t *A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_A) Ctor_O_O(c__iter__716000097, c__s__716000098 any) { t.F_iter__716000097 = c__iter__716000097; t.F_s__716000098 = c__s__716000098 }
//line :218:1
func (t *A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_A) Invoke_O__O(self any) any { { var s__716000098__1 any; var t_ any = t.F_s__716000098; t.F_s__716000098 = nil; s__716000098__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1127 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_1128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1127, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1129 lang.IFn; if linked_1128 == nil { ifn_1129 = lang.IFn_Cast(root_1127) } else { ifn_1129 = nil }; var arg_1130 any = s__716000098__1; if linked_1128 == nil { temp__1927000414__auto____2 = ifn_1129.Invoke_O__O(arg_1130) } else { temp__1927000414__auto____2 = linked_1128.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1127, arg_1130) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var src__4 any; var root_1131 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_1132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1131, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1133 lang.IFn; if linked_1132 == nil { ifn_1133 = lang.IFn_Cast(root_1131) } else { ifn_1133 = nil }; var arg_1134 any = xs__1927001018__auto____3; if linked_1132 == nil { src__4 = ifn_1133.Invoke_O__O(arg_1134) } else { src__4 = linked_1132.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1131, arg_1134) }; var iterys__1927001035__auto____5 any; var fnbody__1206 any = A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_A_New(); var tmp1 *jrt.Class; var fncls__1205 *jrt.Class = A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_A_fn_class; if fncls__1205 == nil { var fncls__1205d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_124, false, nil); A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_A_fn_class = fncls__1205d; tmp1 = fncls__1205d } else { tmp1 = fncls__1205 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1206, tmp1, nil); var fs__1927001036__auto____6 any; var root_1207 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_1208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1207, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1209 lang.IFn; if linked_1208 == nil { ifn_1209 = lang.IFn_Cast(root_1207) } else { ifn_1209 = nil }; var arg_1210 any; var tmp2 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp3 any; var root_1211 any = A_arbace_repr_clojure_A_const_77.GetRawRoot__O(); var linked_1212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1211, A_arbace_repr_clojure_files_A_fn_class); var ifn_1213 lang.IFn; if linked_1212 == nil { ifn_1213 = lang.IFn_Cast(root_1211) } else { ifn_1213 = nil }; var arg_1214 any; var root_1215 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_1216 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1215, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_1217 lang.IFn; if linked_1216 == nil { ifn_1217 = lang.IFn_Cast(root_1215) } else { ifn_1217 = nil }; var arg_1218 any = src__4; if linked_1216 == nil { arg_1214 = ifn_1217.Invoke_O__O(arg_1218) } else { arg_1214 = linked_1216.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_1215, arg_1218) }; if linked_1212 == nil { tmp3 = ifn_1213.Invoke_O__O(arg_1214) } else { tmp3 = linked_1212.(*A_arbace_repr_clojure_files_A).Invoke_O_O__O(root_1211, arg_1214) }; arg_1210 = tmp2.Invoke_O__O(tmp3); if linked_1208 == nil { fs__1927001036__auto____6 = ifn_1209.Invoke_O__O(arg_1210) } else { fs__1927001036__auto____6 = linked_1208.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1207, arg_1210) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_1219 any = A_arbace_repr_clojure_A_const_102.GetRawRoot__O(); var linked_1220 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1219, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1221 lang.IFn; if linked_1220 == nil { ifn_1221 = lang.IFn_Cast(root_1219) } else { ifn_1221 = nil }; var arg_1222 any = fs__1927001036__auto____6; var arg_1223 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__716000097); var tmp5 any; var root_1224 any = A_arbace_repr_clojure_A_const_67.GetRawRoot__O(); var linked_1225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1224, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1226 lang.IFn; if linked_1225 == nil { ifn_1226 = lang.IFn_Cast(root_1224) } else { ifn_1226 = nil }; var arg_1227 any = s__716000098__1; if linked_1225 == nil { tmp5 = ifn_1226.Invoke_O__O(arg_1227) } else { tmp5 = linked_1225.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1224, arg_1227) }; arg_1223 = tmp4.Invoke_O__O(tmp5); if linked_1220 == nil { return ifn_1221.Invoke_O_O__O(arg_1222, arg_1223) } else { return linked_1220.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1219, arg_1222, arg_1223) } } else { var tmp6 any; var root_1228 any = A_arbace_repr_clojure_A_const_67.GetRawRoot__O(); var linked_1229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1228, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1230 lang.IFn; if linked_1229 == nil { ifn_1230 = lang.IFn_Cast(root_1228) } else { ifn_1230 = nil }; var arg_1231 any = s__716000098__1; if linked_1229 == nil { tmp6 = ifn_1230.Invoke_O__O(arg_1231) } else { tmp6 = linked_1229.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1228, arg_1231) }; s__716000098__1 = tmp6; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :218:1
func A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_A_New() *A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_A{}; t.Ctor(); return t }
//line :218:1
func (t *A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_A) Ctor() {}
//line :218:1
func (t *A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_A) Invoke_O_O__O(self, s__716000100__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1204 any = A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_A_New_O_O(self, s__716000100__1); var tmp2 *jrt.Class; var fncls__1203 *jrt.Class = A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_A_fn_class; if fncls__1203 == nil { var fncls__1203d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_125, false, fnbody__1204); A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_A_fn_class = fncls__1203d; tmp2 = fncls__1203d } else { tmp2 = fncls__1203 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1204, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :218:1
func A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_A{}; t.Ctor_O_O(p0, p1); return t }
//line :218:1
func (t *A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_A) Ctor_O_O(c__iter__716000099, c__s__716000100 any) { t.F_iter__716000099 = c__iter__716000099; t.F_s__716000100 = c__s__716000100 }
//line :218:1
func (t *A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_A) Invoke_O__O(self any) any { { var s__716000100__1 any; var t_ any = t.F_s__716000100; t.F_s__716000100 = nil; s__716000100__1 = t_; for { var temp__1927000414__auto____2 any; var root_1135 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_1136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1135, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1137 lang.IFn; if linked_1136 == nil { ifn_1137 = lang.IFn_Cast(root_1135) } else { ifn_1137 = nil }; var arg_1138 any = s__716000100__1; if linked_1136 == nil { temp__1927000414__auto____2 = ifn_1137.Invoke_O__O(arg_1138) } else { temp__1927000414__auto____2 = linked_1136.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1135, arg_1138) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__716000100__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1139 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_1140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1139, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1141 lang.IFn; if linked_1140 == nil { ifn_1141 = lang.IFn_Cast(root_1139) } else { ifn_1141 = nil }; var arg_1142 any = s__716000100__3; if linked_1140 == nil { tmp1 = ifn_1141.Invoke_O__O(arg_1142) } else { tmp1 = linked_1140.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1139, arg_1142) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1143 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_1144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1143, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1145 lang.IFn; if linked_1144 == nil { ifn_1145 = lang.IFn_Cast(root_1143) } else { ifn_1145 = nil }; var arg_1146 any = s__716000100__3; if linked_1144 == nil { c__1927001037__auto____4 = ifn_1145.Invoke_O__O(arg_1146) } else { c__1927001037__auto____4 = linked_1144.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1143, arg_1146) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__716000102__6 any; var root_1147 any = A_arbace_repr_clojure_A_const_60.GetRawRoot__O(); var linked_1148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1147, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1149 lang.IFn; if linked_1148 == nil { ifn_1149 = lang.IFn_Cast(root_1147) } else { ifn_1149 = nil }; var arg_1150 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1148 == nil { b__716000102__6 = ifn_1149.Invoke_O__O(arg_1150) } else { b__716000102__6 = linked_1148.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1147, arg_1150) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1162 any = A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_fn__716000107_A_New_O_I_O(b__716000102__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1161 *jrt.Class = A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_fn__716000107_A_fn_class; if fncls__1161 == nil { var fncls__1161d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_126, false, fnbody__1162); A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_fn__716000107_A_fn_class = fncls__1161d; tmp3 = fncls__1161d } else { tmp3 = fncls__1161 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1162, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1163 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_1164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1163, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1165 lang.IFn; if linked_1164 == nil { ifn_1165 = lang.IFn_Cast(root_1163) } else { ifn_1165 = nil }; var arg_1166 any; var root_1168 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_1169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1168, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1170 lang.IFn; if linked_1169 == nil { ifn_1170 = lang.IFn_Cast(root_1168) } else { ifn_1170 = nil }; var arg_1171 any = b__716000102__6; if linked_1169 == nil { arg_1166 = ifn_1170.Invoke_O__O(arg_1171) } else { arg_1166 = linked_1169.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1168, arg_1171) }; var arg_1167 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__716000099); var tmp5 any; var root_1172 any = A_arbace_repr_clojure_A_const_65.GetRawRoot__O(); var linked_1173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1172, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1174 lang.IFn; if linked_1173 == nil { ifn_1174 = lang.IFn_Cast(root_1172) } else { ifn_1174 = nil }; var arg_1175 any = s__716000100__3; if linked_1173 == nil { tmp5 = ifn_1174.Invoke_O__O(arg_1175) } else { tmp5 = linked_1173.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1172, arg_1175) }; arg_1167 = tmp4.Invoke_O__O(tmp5); if linked_1164 == nil { return ifn_1165.Invoke_O_O__O(arg_1166, arg_1167) } else { return linked_1164.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1163, arg_1166, arg_1167) } } else { var root_1176 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_1177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1176, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1178 lang.IFn; if linked_1177 == nil { ifn_1178 = lang.IFn_Cast(root_1176) } else { ifn_1178 = nil }; var arg_1179 any; var root_1181 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_1182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1181, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1183 lang.IFn; if linked_1182 == nil { ifn_1183 = lang.IFn_Cast(root_1181) } else { ifn_1183 = nil }; var arg_1184 any = b__716000102__6; if linked_1182 == nil { arg_1179 = ifn_1183.Invoke_O__O(arg_1184) } else { arg_1179 = linked_1182.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1181, arg_1184) }; var arg_1180 any; if linked_1177 == nil { return ifn_1178.Invoke_O_O__O(arg_1179, arg_1180) } else { return linked_1177.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1176, arg_1179, arg_1180) } } } else { var vec__716000112__4 any; var root_1185 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_1186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1185, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1187 lang.IFn; if linked_1186 == nil { ifn_1187 = lang.IFn_Cast(root_1185) } else { ifn_1187 = nil }; var arg_1188 any = s__716000100__3; if linked_1186 == nil { vec__716000112__4 = ifn_1187.Invoke_O__O(arg_1188) } else { vec__716000112__4 = linked_1186.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1185, arg_1188) }; var dir__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000112__4, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000112__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1189 any = A_arbace_repr_clojure_A_const_66.GetRawRoot__O(); var linked_1190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1189, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1191 lang.IFn; if linked_1190 == nil { ifn_1191 = lang.IFn_Cast(root_1189) } else { ifn_1191 = nil }; var arg_1192 any; var tmp6 any; var root_1194 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_1195 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1194, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_1196 lang.IFn; if linked_1195 == nil { ifn_1196 = lang.IFn_Cast(root_1194) } else { ifn_1196 = nil }; var arg_1197 any = dir__5; var arg_1198 any = rel__6; if linked_1195 == nil { tmp6 = ifn_1196.Invoke_O_O__O(arg_1197, arg_1198) } else { tmp6 = linked_1195.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_1194, arg_1197, arg_1198) }; arg_1192 = lang.Tuple_Create_O_O__IPersistentVector(rel__6, tmp6); var arg_1193 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__716000099); var tmp8 any; var root_1199 any = A_arbace_repr_clojure_A_const_67.GetRawRoot__O(); var linked_1200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1199, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1201 lang.IFn; if linked_1200 == nil { ifn_1201 = lang.IFn_Cast(root_1199) } else { ifn_1201 = nil }; var arg_1202 any = s__716000100__3; if linked_1200 == nil { tmp8 = ifn_1201.Invoke_O__O(arg_1202) } else { tmp8 = linked_1200.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1199, arg_1202) }; arg_1193 = tmp7.Invoke_O__O(tmp8); if linked_1190 == nil { return ifn_1191.Invoke_O_O__O(arg_1192, arg_1193) } else { return linked_1190.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1189, arg_1192, arg_1193) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :218:1
func A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_fn__716000107_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_fn__716000107_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_fn__716000107_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :218:1
func (t *A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_fn__716000107_A) Ctor_O_I_O(c__b__716000102 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__716000102 = c__b__716000102; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :218:1
func (t *A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_fn__716000107_A) Invoke_O__O(self any) any { { var i__716000101__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__716000101__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__716000108__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__716000101__1)); var dir__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000108__2, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000108__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1151 any = A_arbace_repr_clojure_A_const_61.GetRawRoot__O(); var linked_1152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1151, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1153 lang.IFn; if linked_1152 == nil { ifn_1153 = lang.IFn_Cast(root_1151) } else { ifn_1153 = nil }; var arg_1154 any = t.F_b__716000102; var arg_1155 any; var tmp2 any; var root_1156 any = A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_1157 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1156, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_1158 lang.IFn; if linked_1157 == nil { ifn_1158 = lang.IFn_Cast(root_1156) } else { ifn_1158 = nil }; var arg_1159 any = dir__3; var arg_1160 any = rel__4; if linked_1157 == nil { tmp2 = ifn_1158.Invoke_O_O__O(arg_1159, arg_1160) } else { tmp2 = linked_1157.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O_O__O(root_1156, arg_1159, arg_1160) }; arg_1155 = lang.Tuple_Create_O_O__IPersistentVector(rel__4, tmp2); if linked_1152 == nil { ifn_1153.Invoke_O_O__O(arg_1154, arg_1155) } else { linked_1152.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1151, arg_1154, arg_1155) }; i__716000101__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__716000101__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_repr_clojure_parent_of_A_New() *A_arbace_repr_clojure_parent_of_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_parent_of_A{}; t.Ctor(); return t }
//line :220:1
func (t *A_arbace_repr_clojure_parent_of_A) Ctor() {}
//line :220:1
func (t *A_arbace_repr_clojure_parent_of_A) Invoke_O_O__O(self, rel__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(rel__0)).LastIndexOf_String__I(Lit_29); if lang.Numbers_IsPos_J__Z_NoInit(int64(i__2)) { var root_1236 any = A_arbace_repr_clojure_A_const_12.GetRawRoot__O(); var linked_1237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1236, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1238 lang.IFn; if linked_1237 == nil { ifn_1238 = lang.IFn_Cast(root_1236) } else { ifn_1238 = nil }; var arg_1239 any = rel__0; var arg_1240 any = A_arbace_repr_clojure_A_const_13; var arg_1241 any = jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref(); if linked_1237 == nil { return ifn_1238.Invoke_O_O_O__O(arg_1239, arg_1240, arg_1241) } else { return linked_1237.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1236, arg_1239, arg_1240, arg_1241) } } else { return nil } }
func A_arbace_repr_clojure_name_of_A_New() *A_arbace_repr_clojure_name_of_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_name_of_A{}; t.Ctor(); return t }
//line :221:1
func (t *A_arbace_repr_clojure_name_of_A) Ctor() {}
//line :221:1
func (t *A_arbace_repr_clojure_name_of_A) Invoke_O_O__O(self, rel__0 any) any { var root_1242 any = A_arbace_repr_clojure_A_const_12.GetRawRoot__O(); var linked_1243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1242, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1244 lang.IFn; if linked_1243 == nil { ifn_1244 = lang.IFn_Cast(root_1242) } else { ifn_1244 = nil }; var arg_1245 any = rel__0; var arg_1246 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(jrt.NN(jrt.String_Cast(rel__0)).LastIndexOf_String__I(Lit_29)))).Ref(); if linked_1243 == nil { return ifn_1244.Invoke_O_O__O(arg_1245, arg_1246) } else { return linked_1243.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1242, arg_1245, arg_1246) } }
func A_arbace_repr_clojure_under_A_New() *A_arbace_repr_clojure_under_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_under_A{}; t.Ctor(); return t }
//line :222:1
func (t *A_arbace_repr_clojure_under_A) Ctor() {}
//line :222:1
func (t *A_arbace_repr_clojure_under_A) Invoke_O_O_O__O(self, d__0, n__1 any) any { if jrt.J2g_Truth(d__0) { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_29, nil), jrt.RefArrayOf(jrt.Object_class, d__0, nil, n__1)).Ref() } else { return n__1 } }

func A_arbace_repr_clojure_half_A_New() *A_arbace_repr_clojure_half_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_half_A{}; t.Ctor(); return t }
//line :224:1
func (t *A_arbace_repr_clojure_half_A) Ctor() {}
//line :224:1
func (t *A_arbace_repr_clojure_half_A) Invoke_O_O_O_O__O(self, verb__0, t__1, opts__2 any) any { var map__716000123__4 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_69.GetRawRoot__O()).Invoke_O__O(verb__0); var map__716000123__5 any; if






	lang.ISeq_InstanceOf(map__716000123__4) { var tmp1 any; var root_1247 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_1248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1247, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1249 lang.IFn; if linked_1248 == nil { ifn_1249 = lang.IFn_Cast(root_1247) } else { ifn_1249 = nil }; var arg_1250 any = map__716000123__4; if linked_1248 == nil { tmp1 = ifn_1249.Invoke_O__O(arg_1250) } else { tmp1 = linked_1248.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1247, arg_1250) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1251 any = A_arbace_repr_clojure_A_const_15.GetRawRoot__O(); var linked_1252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1251, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1253 lang.IFn; if linked_1252 == nil { ifn_1253 = lang.IFn_Cast(root_1251) } else { ifn_1253 = nil }; var arg_1254 any = map__716000123__4; if linked_1252 == nil { tmp2 = ifn_1253.Invoke_O__O(arg_1254) } else { tmp2 = linked_1252.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1251, arg_1254) }; map__716000123__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_1255 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_1256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1255, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1257 lang.IFn; if linked_1256 == nil { ifn_1257 = lang.IFn_Cast(root_1255) } else { ifn_1257 = nil }; var arg_1258 any = map__716000123__4; if linked_1256 == nil { tmp3 = ifn_1257.Invoke_O__O(arg_1258) } else { tmp3 = linked_1256.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1255, arg_1258) }; if jrt.J2g_Truth(tmp3) { var root_1259 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_1260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1259, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1261 lang.IFn; if linked_1260 == nil { ifn_1261 = lang.IFn_Cast(root_1259) } else { ifn_1261 = nil }; var arg_1262 any = map__716000123__4; if linked_1260 == nil { map__716000123__5 = ifn_1261.Invoke_O__O(arg_1262) } else { map__716000123__5 = linked_1260.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1259, arg_1262) } } else { map__716000123__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__716000123__5 = map__716000123__4 }; var plan__6 any = /*line :224:1*/lang.RT_Get_O_O__O_NoInit(map__716000123__5, A_arbace_repr_clojure_A_const_70); var translate_text__7 any = lang.RT_Get_O_O__O_NoInit(map__716000123__5, A_arbace_repr_clojure_A_const_19); var refine__8 any = lang.RT_Get_O_O__O_NoInit(map__716000123__5, A_arbace_repr_clojure_A_const_71); var dirs__9 any; var root_1263 any = A_arbace_repr_clojure_A_const_103.GetRawRoot__O(); var linked_1264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1263, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1265 lang.IFn; if







	linked_1264 == nil { ifn_1265 = lang.IFn_Cast(root_1263) } else { ifn_1265 = nil }; var arg_1266 any; var fnbody__1290 any = A_arbace_repr_clojure_half_fn__716000125_A_New(); var tmp4 *jrt.Class; var fncls__1289 *jrt.Class = A_arbace_repr_clojure_half_fn__716000125_A_fn_class; if fncls__1289 == nil { var fncls__1289d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_25, false, nil); A_arbace_repr_clojure_half_fn__716000125_A_fn_class = fncls__1289d; tmp4 = fncls__1289d } else { tmp4 = fncls__1289 }; arg_1266 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1290, tmp4, nil); var arg_1267 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1268 any; var root_1291 any = A_arbace_repr_clojure_A_const_107.GetRawRoot__O(); var linked_1292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1291, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_1293 lang.IFn; if linked_1292 == nil { ifn_1293 = lang.IFn_Cast(root_1291) } else { ifn_1293 = nil }; var arg_1294 any = t__1; if linked_1292 == nil { arg_1268 = ifn_1293.Invoke_O__O(arg_1294) } else { arg_1268 = linked_1292.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_1291, arg_1294) }; if linked_1264 == nil { dirs__9 = ifn_1265.Invoke_O_O_O__O(arg_1266, arg_1267, arg_1268) } else { dirs__9 = linked_1264.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1263, arg_1266, arg_1267, arg_1268) }; var root_1295 any =
	A_arbace_repr_clojure_A_const_103.GetRawRoot__O(); var linked_1296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1295, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1297 lang.IFn; if linked_1296 == nil { ifn_1297 = lang.IFn_Cast(root_1295) } else { ifn_1297 = nil }; var arg_1298 any; var fnbody__1345 any = A_arbace_repr_clojure_half_fn__716000128_A_New(); var tmp5 *jrt.Class; var fncls__1344 *jrt.Class = A_arbace_repr_clojure_half_fn__716000128_A_fn_class; if fncls__1344 == nil { var fncls__1344d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_26, false, nil); A_arbace_repr_clojure_half_fn__716000128_A_fn_class = fncls__1344d; tmp5 = fncls__1344d } else { tmp5 = fncls__1344 }; arg_1298 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1345, tmp5, nil); var tmp6 any = A_arbace_repr_clojure_A_const_109; var arg_1299 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, lang.IFn_Cast(A_arbace_repr_clojure_A_const_101.GetRawRoot__O()).Invoke__O(), A_arbace_repr_clojure_A_const_112, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_repr_clojure_A_const_113, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_repr_clojure_A_const_86, lang.PersistentArrayMap_EMPTY.Ref())); var arg_1300 any; var root_1349 any = A_arbace_repr_clojure_A_const_115.GetRawRoot__O(); var linked_1350 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1349, aot_arbace_core.A_arbace_core_pmap_A_fn_class); var ifn_1351 lang.IFn; if









	linked_1350 == nil { ifn_1351 = lang.IFn_Cast(root_1349) } else { ifn_1351 = nil }; var arg_1352 any; var fnbody__1381 any = A_arbace_repr_clojure_half_fn__716000134_A_New_O_O_O_O_O(plan__6, refine__8, translate_text__7, opts__2, dirs__9); var tmp7 *jrt.Class; var fncls__1380 *jrt.Class = A_arbace_repr_clojure_half_fn__716000134_A_fn_class; if fncls__1380 == nil { var fncls__1380d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, fnbody__1381); A_arbace_repr_clojure_half_fn__716000134_A_fn_class = fncls__1380d; tmp7 = fncls__1380d } else { tmp7 = fncls__1380 }; arg_1352 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1381, tmp7, nil); var arg_1353 any = t__1; if linked_1350 == nil { arg_1300 = ifn_1351.Invoke_O_O__O(arg_1352, arg_1353) } else { arg_1300 = linked_1350.(*aot_arbace_core.A_arbace_core_pmap_A).Invoke_O_O_O__O(root_1349, arg_1352, arg_1353) }; if /*line :233:1*/ linked_1296 == nil { return ifn_1297.Invoke_O_O_O__O(arg_1298, arg_1299, arg_1300) } else { return linked_1296.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1295, arg_1298, arg_1299, arg_1300) } }
//line :232:1
func A_arbace_repr_clojure_half_fn__716000125_A_New() *A_arbace_repr_clojure_half_fn__716000125_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_half_fn__716000125_A{}; t.Ctor(); return t }
//line :232:1
func (t *A_arbace_repr_clojure_half_fn__716000125_A) Ctor() {}
//line :232:1
func (t *A_arbace_repr_clojure_half_fn__716000125_A) Invoke_O_O_O__O(self, m__1, rel__2 any) any { var root_1269 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var linked_1270 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1269, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1271 lang.IFn; if linked_1270 == nil { ifn_1271 = lang.IFn_Cast(root_1269) } else { ifn_1271 = nil }; var arg_1272 any = m__1; var arg_1273 any; var root_1276 any = A_arbace_repr_clojure_A_const_104.GetRawRoot__O(); var linked_1277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1276, A_arbace_repr_clojure_parent_of_A_fn_class); var ifn_1278 lang.IFn; if linked_1277 == nil { ifn_1278 = lang.IFn_Cast(root_1276) } else { ifn_1278 = nil }; var arg_1279 any = rel__2; if linked_1277 == nil { arg_1273 = ifn_1278.Invoke_O__O(arg_1279) } else { arg_1273 = linked_1277.(*A_arbace_repr_clojure_parent_of_A).Invoke_O_O__O(root_1276, arg_1279) }; var arg_1274 any; var root_1280 any = A_arbace_repr_clojure_A_const_105.GetRawRoot__O(); var linked_1281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1280, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_1282 lang.IFn; if linked_1281 == nil { ifn_1282 = lang.IFn_Cast(root_1280) } else { ifn_1282 = nil }; var arg_1283 any = A_arbace_repr_clojure_A_const_10.GetRawRoot__O(); var arg_1284 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_1281 == nil { arg_1274 = ifn_1282.Invoke_O_O__O(arg_1283, arg_1284) } else { arg_1274 = linked_1281.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_1280, arg_1283, arg_1284) }; var arg_1275 any; var root_1285 any = A_arbace_repr_clojure_A_const_106.GetRawRoot__O(); var linked_1286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1285, A_arbace_repr_clojure_name_of_A_fn_class); var ifn_1287 lang.IFn; if linked_1286 == nil { ifn_1287 = lang.IFn_Cast(root_1285) } else { ifn_1287 = nil }; var arg_1288 any = rel__2; if linked_1286 == nil { arg_1275 = ifn_1287.Invoke_O__O(arg_1288) } else { arg_1275 = linked_1286.(*A_arbace_repr_clojure_name_of_A).Invoke_O_O__O(root_1285, arg_1288) }; if linked_1270 == nil { return ifn_1271.Invoke_O_O_O_O__O(arg_1272, arg_1273, arg_1274, arg_1275) } else { return linked_1270.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_1269, arg_1272, arg_1273, arg_1274, arg_1275) } }
func A_arbace_repr_clojure_half_fn__716000128_A_New() *A_arbace_repr_clojure_half_fn__716000128_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_half_fn__716000128_A{}; t.Ctor(); return t }
//line :233:1
func (t *A_arbace_repr_clojure_half_fn__716000128_A) Ctor() {}
//line :233:1
func (t *A_arbace_repr_clojure_half_fn__716000128_A) Invoke_O_O_O__O(self, acc__1, p__716000127__2 any) any { var vec__716000129__3 any = p__716000127__2; var rel__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000129__3, lang.RT_IntCast_J__I_NoInit(0), nil); var x__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000129__3, lang.RT_IntCast_J__I_NoInit(1), nil); var p__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000129__3, lang.RT_IntCast_J__I_NoInit(2), nil); var r__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000129__3, lang.RT_IntCast_J__I_NoInit(3), nil); if
														jrt.J2g_Truth(A_arbace_repr_clojure_A_const_33.Invoke_O__O(p__6)) { return acc__1 } else { if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_81.Invoke_O__O(p__6)) {
															var root_1301 any = A_arbace_repr_clojure_A_const_108.GetRawRoot__O(); var linked_1302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1301, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1303 lang.IFn; if linked_1302 == nil { ifn_1303 = lang.IFn_Cast(root_1301) } else { ifn_1303 = nil }; var arg_1304 any = acc__1; var arg_1305 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_clojure_A_const_109, rel__4); var arg_1306 any = x__5; if linked_1302 == nil { return ifn_1303.Invoke_O_O_O__O(arg_1304, arg_1305, arg_1306) } else { return linked_1302.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1301, arg_1304, arg_1305, arg_1306) } } else {
//line :234:1
			if A_arbace_repr_clojure_A_const_34 != nil { var out__8 any; var root_1307 any = A_arbace_repr_clojure_A_const_110.GetRawRoot__O(); var linked_1308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1307, A_arbace_repr_clojure_under_A_fn_class); var ifn_1309 lang.IFn

				if linked_1308 == nil { ifn_1309 = lang.IFn_Cast(root_1307) } else { ifn_1309 = nil }; var arg_1310 any; var root_1312 any = A_arbace_repr_clojure_A_const_104.GetRawRoot__O(); var linked_1313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1312, A_arbace_repr_clojure_parent_of_A_fn_class); var ifn_1314 lang.IFn; if linked_1313 == nil { ifn_1314 = lang.IFn_Cast(root_1312) } else { ifn_1314 = nil }; var arg_1315 any = rel__4; if linked_1313 == nil { arg_1310 = ifn_1314.Invoke_O__O(arg_1315) } else { arg_1310 = linked_1313.(*A_arbace_repr_clojure_parent_of_A).Invoke_O_O__O(root_1312, arg_1315) }; var arg_1311 any = A_arbace_repr_clojure_A_const_28.Invoke_O__O(p__6); if linked_1308 == nil { out__8 = ifn_1309.Invoke_O_O__O(arg_1310, arg_1311) } else { out__8 = linked_1308.(*A_arbace_repr_clojure_under_A).Invoke_O_O_O__O(root_1307, arg_1310, arg_1311) }
				var tmp1 any; var root_1316 any = A_arbace_repr_clojure_A_const_111.GetRawRoot__O(); var linked_1317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1316, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1318 lang.IFn; if linked_1317 == nil { ifn_1318 = lang.IFn_Cast(root_1316) } else { ifn_1318 = nil }; var arg_1319 any = r__7; if linked_1317 == nil { tmp1 = ifn_1318.Invoke_O__O(arg_1319) } else { tmp1 = linked_1317.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1316, arg_1319) }; if jrt.J2g_Truth(tmp1) {

					var root_1320 any = A_arbace_repr_clojure_A_const_108.GetRawRoot__O(); var linked_1321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1320, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1322 lang.IFn; if linked_1321 == nil { ifn_1322 = lang.IFn_Cast(root_1320) } else { ifn_1322 = nil }; var arg_1323 any; var root_1326 any = A_arbace_repr_clojure_A_const_108.GetRawRoot__O(); var linked_1327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1326, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1328 lang.IFn
//line :238:1
					if linked_1327 == nil { ifn_1328 = lang.IFn_Cast(root_1326) } else { ifn_1328 = nil }; var arg_1329 any; var root_1332 any = A_arbace_repr_clojure_A_const_108.GetRawRoot__O(); var linked_1333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1332, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1334 lang.IFn; if linked_1333 == nil { ifn_1334 = lang.IFn_Cast(root_1332) } else { ifn_1334 = nil }; var arg_1335 any = acc__1; var arg_1336 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_clojure_A_const_109, out__8); var arg_1337 any = r__7; if linked_1333 == nil { arg_1329 = ifn_1334.Invoke_O_O_O__O(arg_1335, arg_1336, arg_1337) } else { arg_1329 = linked_1333.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1332, arg_1335, arg_1336, arg_1337) }; var arg_1330 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_clojure_A_const_112, out__8); var arg_1331 any = rel__4; if linked_1327 == nil { arg_1323 = ifn_1328.Invoke_O_O_O__O(arg_1329, arg_1330, arg_1331) } else { arg_1323 = linked_1327.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1326, arg_1329, arg_1330, arg_1331) }
					var arg_1324 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_clojure_A_const_113, out__8); var arg_1325 any = p__6; if linked_1321 == nil { return ifn_1322.Invoke_O_O_O__O(arg_1323, arg_1324, arg_1325) } else { return linked_1321.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1320, arg_1323, arg_1324, arg_1325) } } else {
						var root_1338 any = A_arbace_repr_clojure_A_const_108.GetRawRoot__O(); var linked_1339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1338, aot_arbace_core.A_arbace_core_assoc_in_A_fn_class); var ifn_1340 lang.IFn; if linked_1339 == nil { ifn_1340 = lang.IFn_Cast(root_1338) } else { ifn_1340 = nil }; var arg_1341 any = acc__1; var arg_1342 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_clojure_A_const_86, rel__4); var arg_1343 any = A_arbace_repr_clojure_A_const_114.Invoke_O__O(r__7); if linked_1339 == nil { return ifn_1340.Invoke_O_O_O__O(arg_1341, arg_1342, arg_1343) } else { return linked_1339.(*aot_arbace_core.A_arbace_core_assoc_in_A).Invoke_O_O_O_O__O(root_1338, arg_1341, arg_1342, arg_1343) } } } else {
//line :234:1
							return nil } } } }








func A_arbace_repr_clojure_half_fn__716000134_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_repr_clojure_half_fn__716000134_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_half_fn__716000134_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :243:1
func (t *A_arbace_repr_clojure_half_fn__716000134_A) Ctor_O_O_O_O_O(c__plan, c__refine, c__translate_text, c__opts, c__dirs any) { t.F_plan = c__plan; t.F_refine = c__refine; t.F_translate_text = c__translate_text; t.F_opts = c__opts; t.F_dirs = c__dirs }
//line :243:1
func (t *A_arbace_repr_clojure_half_fn__716000134_A) Invoke_O_O__O(self, p__716000133__1 any) any { var vec__716000135__2 any = p__716000133__1; var rel__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000135__2, lang.RT_IntCast_J__I_NoInit(0), nil); var x__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000135__2, lang.RT_IntCast_J__I_NoInit(1), nil); var sibs__5 any; var tmp1 lang.IFn = lang.IFn_Cast(t.F_dirs); var tmp2 any; var root_1362 any = A_arbace_repr_clojure_A_const_104.GetRawRoot__O(); var linked_1363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1362, A_arbace_repr_clojure_parent_of_A_fn_class); var ifn_1364 lang.IFn; if
													linked_1363 == nil { ifn_1364 = lang.IFn_Cast(root_1362) } else { ifn_1364 = nil }; var arg_1365 any = rel__3; if linked_1363 == nil { tmp2 = ifn_1364.Invoke_O__O(arg_1365) } else { tmp2 = linked_1363.(*A_arbace_repr_clojure_parent_of_A).Invoke_O_O__O(root_1362, arg_1365) }; sibs__5 = tmp1.Invoke_O__O(tmp2); var p0__6 any; var tmp3 lang.IFn = /*line :243:1*/lang.IFn_Cast(t.F_plan); var tmp4 any; var root_1366 any = A_arbace_repr_clojure_A_const_106.GetRawRoot__O(); var linked_1367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1366, A_arbace_repr_clojure_name_of_A_fn_class); var ifn_1368 lang.IFn; if

	linked_1367 == nil { ifn_1368 = lang.IFn_Cast(root_1366) } else { ifn_1368 = nil }; var arg_1369 any = rel__3; if linked_1367 == nil { tmp4 = ifn_1368.Invoke_O__O(arg_1369) } else { tmp4 = linked_1367.(*A_arbace_repr_clojure_name_of_A).Invoke_O_O__O(root_1366, arg_1369) }; p0__6 = tmp3.Invoke_O_O_O__O(tmp4, sibs__5, t.F_opts); var s__7 any; if
	jrt.J2g_Truth(A_arbace_repr_clojure_A_const_24.Invoke_O__O(p0__6)) { var tmp5 any; var root_1354 any = A_arbace_repr_clojure_A_const_111.GetRawRoot__O(); var linked_1355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1354, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1356 lang.IFn; if linked_1355 == nil { ifn_1356 = lang.IFn_Cast(root_1354) } else { ifn_1356 = nil }; var arg_1357 any = x__4; if linked_1355 == nil { tmp5 = ifn_1356.Invoke_O__O(arg_1357) } else { tmp5 = linked_1355.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1354, arg_1357) }; if jrt.J2g_Truth(tmp5) { s__7 = x__4 } else { s__7 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_78.GetRawRoot__O()).Invoke_O__O(x__4) } } else { s__7 = nil }; var p__8 any; if
	jrt.J2g_Truth(s__7) { var tmp6 lang.IFn = lang.IFn_Cast(t.F_refine); var tmp7 any; var root_1370 any = A_arbace_repr_clojure_A_const_106.GetRawRoot__O(); var linked_1371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1370, A_arbace_repr_clojure_name_of_A_fn_class); var ifn_1372 lang.IFn; if linked_1371 == nil { ifn_1372 = lang.IFn_Cast(root_1370) } else { ifn_1372 = nil }; var arg_1373 any = rel__3; if linked_1371 == nil { tmp7 = ifn_1372.Invoke_O__O(arg_1373) } else { tmp7 = linked_1371.(*A_arbace_repr_clojure_name_of_A).Invoke_O_O__O(root_1370, arg_1373) }; p__8 = tmp6.Invoke_O_O_O_O__O(p0__6, tmp7, sibs__5, s__7) } else { p__8 = p0__6 }; var tmp8 any; if
	jrt.J2g_Truth(A_arbace_repr_clojure_A_const_24.Invoke_O__O(p__8)) {
		var tmp9 *lang.Compiler_AOTFn; var fnbody__1379 any = A_arbace_repr_clojure_half_fn__716000134_fn__716000138_A_New_O_O_O_O_O(p__8, s__7, rel__3, t.F_translate_text, t.F_opts); var tmp10 *jrt.Class; var fncls__1378 *jrt.Class = A_arbace_repr_clojure_half_fn__716000134_fn__716000138_A_fn_class; if fncls__1378 == nil { var fncls__1378d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_28, false, fnbody__1379); A_arbace_repr_clojure_half_fn__716000134_fn__716000138_A_fn_class = fncls__1378d; tmp10 = fncls__1378d } else { tmp10 = fncls__1378 }; tmp9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1379, tmp10, nil); tmp8 = Up_Compiler_AOTFn_IFn(tmp9).Invoke__O() } else {
//line :248:1
			tmp8 = nil }; return /*line :243:1*/ lang.Tuple_Create_O_O_O_O__IPersistentVector(rel__3, x__4, p__8, tmp8) }





func A_arbace_repr_clojure_half_fn__716000134_fn__716000138_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_repr_clojure_half_fn__716000134_fn__716000138_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_half_fn__716000134_fn__716000138_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :249:1
func (t *A_arbace_repr_clojure_half_fn__716000134_fn__716000138_A) Ctor_O_O_O_O_O(c__p, c__s, c__rel, c__translate_text, c__opts any) { t.F_p = c__p; t.F_s = c__s; t.F_rel = c__rel; t.F_translate_text = c__translate_text; t.F_opts = c__opts }
//line :249:1
func (t *A_arbace_repr_clojure_half_fn__716000134_fn__716000138_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 any; var t_ any = t.F_translate_text; t.F_translate_text = nil; tmp2 = t_; var tmp3 lang.IFn = lang.IFn_Cast(tmp2); var tmp4 any; var t__2 any = t.F_s; t.F_s = nil; tmp4 = t__2; var tmp5 any = tmp4; var tmp6 any; var t__3 any = t.F_p; t.F_p = nil; tmp6 = t__3; var tmp7 any = tmp6; var tmp8 any; var t__4 any = t.F_rel; t.F_rel = nil; tmp8 = t__4; var tmp9 any = tmp8; var tmp10 lang.IFn = A_arbace_repr_clojure_A_const_33; var tmp11 any; var t__5 any = t.F_opts; t.F_opts = nil; tmp11 = t__5; tmp1 = tmp3.Invoke_O_O_O_O__O(tmp5, tmp7, tmp9, tmp10.Invoke_O_O__O(tmp11, lang.PersistentHashSet_EMPTY.Ref())) }; return nil }(); if tmp12 != nil { if jrt.Exception_InstanceOf(tmp12) { var e__3 jrt.Exception_I = jrt.Exception_Cast(tmp12); var tmp13 any = A_arbace_repr_clojure_A_const_114; var tmp14 any; var root_1374 any = A_arbace_repr_clojure_A_const_87.GetRawRoot__O(); var linked_1375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1374, aot_arbace_core.A_arbace_core_ex_message_A_fn_class); var ifn_1376 lang.IFn
												if linked_1375 == nil { ifn_1376 = lang.IFn_Cast(root_1374) } else { ifn_1376 = nil }; var arg_1377 any = e__3; if linked_1375 == nil { tmp14 = ifn_1376.Invoke_O__O(arg_1377) } else { tmp14 = linked_1375.(*aot_arbace_core.A_arbace_core_ex_message_A).Invoke_O_O__O(root_1374, arg_1377) }
//line :249:1
	tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp14)) } else { panic(tmp12) } }; return tmp1 }



func A_arbace_repr_clojure_first_difference_A_New() *A_arbace_repr_clojure_first_difference_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_first_difference_A{}; t.Ctor(); return t }
//line :253:1
func (t *A_arbace_repr_clojure_first_difference_A) Ctor() {}
//line :253:1
func (t *A_arbace_repr_clojure_first_difference_A) Invoke_O_O_O__O(self, a__0, b__1 any) any { var n__3 int64 = lang.Numbers_Min_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(a__0)), int64(lang.RT_Count_O__I_NoInit(b__1))); var i__4 any; var tmp1 *lang.Compiler_AOTFn; var fnbody__1383 any = A_arbace_repr_clojure_first_difference_fn__716000143_A_New_O_O_J(a__0, b__1, n__3); var tmp2 *jrt.Class; var fncls__1382 *jrt.Class = A_arbace_repr_clojure_first_difference_fn__716000143_A_fn_class; if

	fncls__1382 == nil { var fncls__1382d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_18, false, fnbody__1383); A_arbace_repr_clojure_first_difference_fn__716000143_A_fn_class = fncls__1382d; tmp2 = fncls__1382d } else { tmp2 = fncls__1382 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1383, tmp2, nil); i__4 = Up_Compiler_AOTFn_IFn(tmp1).Invoke__O(); var line__5 int64; var tmp3 any; var root_1384 any = /*line :253:1*/A_arbace_repr_clojure_A_const_116.GetRawRoot__O(); var linked_1385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1384, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1386 lang.IFn; if


	linked_1385 == nil { ifn_1386 = lang.IFn_Cast(root_1384) } else { ifn_1386 = nil }; var arg_1387 any; var fnbody__1390 any = A_arbace_repr_clojure_first_difference_fn__716000145_A_New(); var tmp4 *jrt.Class; var fncls__1389 *jrt.Class = A_arbace_repr_clojure_first_difference_fn__716000145_A_fn_class; if fncls__1389 == nil { var fncls__1389d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, nil); A_arbace_repr_clojure_first_difference_fn__716000145_A_fn_class = fncls__1389d; tmp4 = fncls__1389d } else { tmp4 = fncls__1389 }; arg_1387 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1390, tmp4, nil); var arg_1388 any; var root_1391 any = A_arbace_repr_clojure_A_const_12.GetRawRoot__O(); var linked_1392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1391, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1393 lang.IFn; if linked_1392 == nil { ifn_1393 = lang.IFn_Cast(root_1391) } else { ifn_1393 = nil }; var arg_1394 any = a__0; var arg_1395 any = A_arbace_repr_clojure_A_const_13; var arg_1396 any = i__4; if linked_1392 == nil { arg_1388 = ifn_1393.Invoke_O_O_O__O(arg_1394, arg_1395, arg_1396) } else { arg_1388 = linked_1392.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1391, arg_1394, arg_1395, arg_1396) }; if linked_1385 == nil { tmp3 = ifn_1386.Invoke_O_O__O(arg_1387, arg_1388) } else { tmp3 = linked_1385.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1384, arg_1387, arg_1388) }; line__5 = lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(tmp3))); var ln__6 any; var fnbody__1406 any = /*line :253:1*/A_arbace_repr_clojure_first_difference_ln__716000147_A_New_O(i__4); var tmp5 *jrt.Class; var fncls__1405 *jrt.Class = A_arbace_repr_clojure_first_difference_ln__716000147_A_fn_class; if



	fncls__1405 == nil { var fncls__1405d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, fnbody__1406); A_arbace_repr_clojure_first_difference_ln__716000147_A_fn_class = fncls__1405d; tmp5 = fncls__1405d } else { tmp5 = fncls__1405 }; ln__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1406, tmp5, nil); return /*line :260:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_21, nil, Lit_22, nil, Lit_23, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Long_ValueOf_J__Long_NoInit(line__5).Ref(), nil, lang.IFn_Cast(A_arbace_repr_clojure_A_const_118.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(ln__6).Invoke_O__O(a__0)), nil, lang.IFn_Cast(A_arbace_repr_clojure_A_const_118.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(ln__6).Invoke_O__O(b__1)))).Ref() }
//line :255:1
func A_arbace_repr_clojure_first_difference_fn__716000143_A_New_O_O_J(p0, p1 any, p2 int64) *A_arbace_repr_clojure_first_difference_fn__716000143_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_first_difference_fn__716000143_A{}; t.Ctor_O_O_J(p0, p1, p2); return t }
//line :255:1
func (t *A_arbace_repr_clojure_first_difference_fn__716000143_A) Ctor_O_O_J(c__a, c__b any, c__n int64) { t.F_a = c__a; t.F_b = c__b; t.F_n = c__n }
//line :255:1
func (t *A_arbace_repr_clojure_first_difference_fn__716000143_A) Invoke_O__O(self any) any { { var i__1 int64 = 0; L1: for { var tmp1 bool; var and__1927000168__auto____2 bool = lang.Numbers_Lt_J_J__Z_NoInit(i__1, t.F_n); if and__1927000168__auto____2 { var tmp2 *jrt.String = jrt.String_Cast(t.F_a); var tmp3 *jrt.String = jrt.String_Cast(t.F_b); tmp1 = lang.Util_Equiv_C_C__Z_NoInit(jrt.NN(tmp2).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(i__1)), jrt.NN(tmp3).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(i__1))) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { i__1 = lang.Numbers_Inc_J__J_NoInit(i__1); continue L1 } else { return jrt.Long_ValueOf_J__Long_NoInit(i__1).Ref() } } }; panic("j2g: unreachable") }
func A_arbace_repr_clojure_first_difference_fn__716000145_A_New() *A_arbace_repr_clojure_first_difference_fn__716000145_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_first_difference_fn__716000145_A{}; t.Ctor(); return t }
//line :256:1
func (t *A_arbace_repr_clojure_first_difference_fn__716000145_A) Ctor() {}
//line :256:1
func (t *A_arbace_repr_clojure_first_difference_fn__716000145_A) Invoke_O_O__O(self, p1__716000142_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_repr_clojure_A_const_117, p1__716000142_SHARP___1)).Ref() }
func A_arbace_repr_clojure_first_difference_ln__716000147_A_New_O(p0 any) *A_arbace_repr_clojure_first_difference_ln__716000147_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_first_difference_ln__716000147_A{}; t.Ctor_O(p0); return t }
//line :257:1
func (t *A_arbace_repr_clojure_first_difference_ln__716000147_A) Ctor_O(c__i any) { t.F_i = c__i }
//line :257:1
func (t *A_arbace_repr_clojure_first_difference_ln__716000147_A) Invoke_O_O__O(self, s__1 any) any { var st__2 int64; var tmp1 *jrt.String = jrt.String_Cast(s__1); var tmp2 *jrt.String = Lit_24; var tmp3 jrt.Number_I; var na_1397 any = t.F_i; if jrt.Long_InstanceOf(na_1397) { var n0_1398 int64 = jrt.NN(jrt.Long_Cast(na_1397)).LongValue__J(); if n0_1398 == -9223372036854775808 { tmp3 = lang.Numbers_Dec_O__Number_NoInit(na_1397) } else { tmp3 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_1398 - 1)) } } else { if jrt.Double_InstanceOf(na_1397) { var n0_1398_2 float64 = jrt.NN(jrt.Double_Cast(na_1397)).DoubleValue__D(); tmp3 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_1398_2 - 1.0)) } else { tmp3 = lang.Numbers_Dec_O__Number_NoInit(na_1397) } }; st__2 = lang.Numbers_Inc_J__J_NoInit(int64(jrt.NN(tmp1).LastIndexOf_String_I__I(tmp2, lang.RT_IntCast_O__I_NoInit(lang.Numbers_Max_J_O__O_NoInit(0, tmp3))))); var e__3 int32 = jrt.NN(jrt.String_Cast(s__1)).IndexOf_String_I__I(Lit_24, lang.RT_IntCast_O__I_NoInit(t.F_i)); var root_1399 any = A_arbace_repr_clojure_A_const_12.GetRawRoot__O(); var linked_1400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1399, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1401 lang.IFn; if

	linked_1400 == nil { ifn_1401 = lang.IFn_Cast(root_1399) } else { ifn_1401 = nil }; var arg_1402 any = s__1; var arg_1403 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Min_J_J__J_NoInit(st__2, int64(lang.RT_Count_O__I_NoInit(s__1)))).Ref(); var arg_1404 any; if lang.Numbers_IsNeg_J__Z_NoInit(int64(e__3)) { arg_1404 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(s__1)).Ref() } else { arg_1404 = jrt.Integer_ValueOf_I__Integer_NoInit(e__3).Ref() }; if linked_1400 == nil { return ifn_1401.Invoke_O_O_O__O(arg_1402, arg_1403, arg_1404) } else { return linked_1400.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1399, arg_1402, arg_1403, arg_1404) } }


func A_arbace_repr_clojure_roundtrip_A_New() *A_arbace_repr_clojure_roundtrip_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_A{}; t.Ctor(); return t }
//line :262:1
func (t *A_arbace_repr_clojure_roundtrip_A) Ctor() {}
//line :262:1
func (t *A_arbace_repr_clojure_roundtrip_A) Invoke_O_O_O__O(self, sources__0, opts__1 any) any { var vec__716000150__3 any; var tmp1 any = A_arbace_repr_clojure_A_const_119; if










	lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_repr_clojure_A_const_112.Invoke_O__O(opts__1)) { vec__716000150__3 = A_arbace_repr_clojure_A_const_120 } else { vec__716000150__3 = A_arbace_repr_clojure_A_const_121 }; var v1__4 any = /*line :262:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__716000150__3, lang.RT_IntCast_J__I_NoInit(0), nil); var v2__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000150__3, lang.RT_IntCast_J__I_NoInit(1), nil); var t__6 any; var root_1415 any = A_arbace_repr_clojure_A_const_122.GetRawRoot__O(); var linked_1416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1415, A_arbace_repr_clojure_tree_A_fn_class); var ifn_1417 lang.IFn; if











	linked_1416 == nil { ifn_1417 = lang.IFn_Cast(root_1415) } else { ifn_1417 = nil }; var arg_1418 any = sources__0; if linked_1416 == nil { t__6 = ifn_1417.Invoke_O__O(arg_1418) } else { t__6 = linked_1416.(*A_arbace_repr_clojure_tree_A).Invoke_O_O__O(root_1415, arg_1418) }; var a__7 any; var root_1419 any = /*line :262:1*/A_arbace_repr_clojure_A_const_123.GetRawRoot__O(); var linked_1420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1419, A_arbace_repr_clojure_half_A_fn_class); var ifn_1421 lang.IFn; if












	linked_1420 == nil { ifn_1421 = lang.IFn_Cast(root_1419) } else { ifn_1421 = nil }; var arg_1422 any = v1__4; var arg_1423 any = t__6; var arg_1424 any = opts__1; if linked_1420 == nil { a__7 = ifn_1421.Invoke_O_O_O__O(arg_1422, arg_1423, arg_1424) } else { a__7 = linked_1420.(*A_arbace_repr_clojure_half_A).Invoke_O_O_O_O__O(root_1419, arg_1422, arg_1423, arg_1424) }; var b__8 any; var root_1425 any = /*line :262:1*/A_arbace_repr_clojure_A_const_123.GetRawRoot__O(); var linked_1426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1425, A_arbace_repr_clojure_half_A_fn_class); var ifn_1427 lang.IFn; if













	linked_1426 == nil { ifn_1427 = lang.IFn_Cast(root_1425) } else { ifn_1427 = nil }; var arg_1428 any = v2__5; var arg_1429 any = A_arbace_repr_clojure_A_const_109.Invoke_O__O(a__7); var arg_1430 any = opts__1; if linked_1426 == nil { b__8 = ifn_1427.Invoke_O_O_O__O(arg_1428, arg_1429, arg_1430) } else { b__8 = linked_1426.(*A_arbace_repr_clojure_half_A).Invoke_O_O_O_O__O(root_1425, arg_1428, arg_1429, arg_1430) }; var c__9 any; var tmp2 any = A_arbace_repr_clojure_A_const_119; if

	lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_repr_clojure_A_const_112.Invoke_O__O(opts__1)) { var root_1431 any = A_arbace_repr_clojure_A_const_123.GetRawRoot__O(); var linked_1432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1431, A_arbace_repr_clojure_half_A_fn_class); var ifn_1433 lang.IFn; if linked_1432 == nil { ifn_1433 = lang.IFn_Cast(root_1431) } else { ifn_1433 = nil }; var arg_1434 any = v1__4; var arg_1435 any = A_arbace_repr_clojure_A_const_109.Invoke_O__O(b__8); var arg_1436 any = opts__1; if linked_1432 == nil { c__9 = ifn_1433.Invoke_O_O_O__O(arg_1434, arg_1435, arg_1436) } else { c__9 = linked_1432.(*A_arbace_repr_clojure_half_A).Invoke_O_O_O_O__O(root_1431, arg_1434, arg_1435, arg_1436) } } else { c__9 = nil }; var back2__10 any; var root_1437 any = /*line :262:1*/A_arbace_repr_clojure_A_const_100.GetRawRoot__O(); var linked_1438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1437, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1439 lang.IFn; if
















	linked_1438 == nil { ifn_1439 = lang.IFn_Cast(root_1437) } else { ifn_1439 = nil }; var arg_1440 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1441 any; var iter__1927001039__auto____10 any; var fnbody__1503 any = A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_A_New(); var tmp3 *jrt.Class; var fncls__1502 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_A_fn_class; if fncls__1502 == nil { var fncls__1502d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_71, false, nil); A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_A_fn_class = fncls__1502d; tmp3 = fncls__1502d } else { tmp3 = fncls__1502 }; iter__1927001039__auto____10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1503, tmp3, nil); arg_1441 = lang.IFn_Cast(iter__1927001039__auto____10).Invoke_O__O(A_arbace_repr_clojure_A_const_112.Invoke_O__O(c__9)); if linked_1438 == nil { back2__10 = ifn_1439.Invoke_O_O__O(arg_1440, arg_1441) } else { back2__10 = linked_1438.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1437, arg_1440, arg_1441) }; var back__11 any; var root_1504 any = /*line :262:1*/A_arbace_repr_clojure_A_const_100.GetRawRoot__O(); var linked_1505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1504, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1506 lang.IFn; if


















	linked_1505 == nil { ifn_1506 = lang.IFn_Cast(root_1504) } else { ifn_1506 = nil }; var arg_1507 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1508 any; var iter__1927001039__auto____11 any; var fnbody__1570 any = A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_A_New(); var tmp4 *jrt.Class; var fncls__1569 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_A_fn_class; if fncls__1569 == nil { var fncls__1569d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_72, false, nil); A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_A_fn_class = fncls__1569d; tmp4 = fncls__1569d } else { tmp4 = fncls__1569 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1570, tmp4, nil); arg_1508 = lang.IFn_Cast(iter__1927001039__auto____11).Invoke_O__O(A_arbace_repr_clojure_A_const_112.Invoke_O__O(b__8)); if linked_1505 == nil { back__11 = ifn_1506.Invoke_O_O__O(arg_1507, arg_1508) } else { back__11 = linked_1505.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1504, arg_1507, arg_1508) }; var results__12 any; var iter__1927001039__auto____12 any; var fnbody__1834 any = /*line :262:1*/A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_A_New_O_O_O_O_O_O_O(back2__10, t__6, a__7, b__8, c__9, back__11, opts__1); var tmp5 *jrt.Class; var fncls__1833 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_A_fn_class; if



















	fncls__1833 == nil { var fncls__1833d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_73, false, fnbody__1834); A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_A_fn_class = fncls__1833d; tmp5 = fncls__1833d } else { tmp5 = fncls__1833 }; iter__1927001039__auto____12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1834, tmp5, nil); results__12 = lang.IFn_Cast(iter__1927001039__auto____12).Invoke_O__O(A_arbace_repr_clojure_A_const_112.Invoke_O__O(a__7)); var tmp6 any = A_arbace_repr_clojure_A_const_139; var tmp7 any = /*line :262:1*/jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Add_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(results__12)), int64(lang.RT_Count_O__I_NoInit(A_arbace_repr_clojure_A_const_86.Invoke_O__O(a__7))))).Ref(); var tmp8 any = A_arbace_repr_clojure_A_const_140; var tmp9 any; var root_1835 any = A_arbace_repr_clojure_A_const_141.GetRawRoot__O(); var linked_1836 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1835, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1837 lang.IFn; if














































	linked_1836 == nil { ifn_1837 = lang.IFn_Cast(root_1835) } else { ifn_1837 = nil }; var arg_1838 any = A_arbace_repr_clojure_A_const_57.GetRawRoot__O(); var arg_1839 any = results__12; if linked_1836 == nil { tmp9 = ifn_1837.Invoke_O_O__O(arg_1838, arg_1839) } else { tmp9 = linked_1836.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1835, arg_1838, arg_1839) }; var tmp10 any = /*line :262:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp9)).Ref(); var tmp11 any = A_arbace_repr_clojure_A_const_142; var tmp12 any; var root_1840 any = A_arbace_repr_clojure_A_const_100.GetRawRoot__O(); var linked_1841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1840, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1842 lang.IFn; if















































	linked_1841 == nil { ifn_1842 = lang.IFn_Cast(root_1840) } else { ifn_1842 = nil }; var arg_1843 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_101.GetRawRoot__O()).Invoke__O(); var arg_1844 any; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_102.GetRawRoot__O()); var tmp14 any; var root_1854 any = A_arbace_repr_clojure_A_const_116.GetRawRoot__O(); var linked_1855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1854, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1856 lang.IFn; if
	linked_1855 == nil { ifn_1856 = lang.IFn_Cast(root_1854) } else { ifn_1856 = nil }; var arg_1857 any = A_arbace_repr_clojure_A_const_57.GetRawRoot__O(); var arg_1858 any = results__12; if linked_1855 == nil { tmp14 = ifn_1856.Invoke_O_O__O(arg_1857, arg_1858) } else { tmp14 = linked_1855.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1854, arg_1857, arg_1858) }; var tmp15 any = tmp14; var tmp16 any; var iter__1927001039__auto____13 any; var fnbody__1920 any = A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_A_New(); var tmp17 *jrt.Class; var fncls__1919 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_A_fn_class; if
	fncls__1919 == nil { var fncls__1919d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_74, false, nil); A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_A_fn_class = fncls__1919d; tmp17 = fncls__1919d } else { tmp17 = fncls__1919 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1920, tmp17, nil); tmp16 = lang.IFn_Cast(iter__1927001039__auto____13).Invoke_O__O(A_arbace_repr_clojure_A_const_86.Invoke_O__O(a__7)); var tmp18 any = tmp16; var tmp19 any; var iter__1927001039__auto____13_2 any; var fnbody__1982 any = /*line :311:1*/A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_A_New_O(a__7); var tmp20 *jrt.Class; var fncls__1981 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_A_fn_class; if


	fncls__1981 == nil { var fncls__1981d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_75, false, fnbody__1982); A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_A_fn_class = fncls__1981d; tmp20 = fncls__1981d } else { tmp20 = fncls__1981 }; iter__1927001039__auto____13_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1982, tmp20, nil); tmp19 = lang.IFn_Cast(iter__1927001039__auto____13_2).Invoke_O__O(A_arbace_repr_clojure_A_const_86.Invoke_O__O(b__8)); arg_1844 = /*line :311:1*/tmp13.Invoke_O_O_O__O(tmp15, tmp18, tmp19); if /*line :310:1*/ linked_1841 == nil { tmp12 = ifn_1842.Invoke_O_O__O(arg_1843, arg_1844) } else { tmp12 = linked_1841.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1840, arg_1843, arg_1844) }; return /*line :262:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7, tmp8, tmp10, tmp11, tmp12)) }
















func A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_A_New() *A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_A{}; t.Ctor(); return t }
//line :279:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_A) Ctor() {}
//line :279:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_A) Invoke_O_O__O(self, s__716000154__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1501 any = A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_A_New_O_O(self, s__716000154__1); var tmp2 *jrt.Class; var fncls__1500 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_A_fn_class; if fncls__1500 == nil { var fncls__1500d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_76, false, fnbody__1501); A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_A_fn_class = fncls__1500d; tmp2 = fncls__1500d } else { tmp2 = fncls__1500 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1501, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :279:1
func A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_A{}; t.Ctor_O_O(p0, p1); return t }
//line :279:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_A) Ctor_O_O(c__iter__716000153, c__s__716000154 any) { t.F_iter__716000153 = c__iter__716000153; t.F_s__716000154 = c__s__716000154 }
//line :279:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_A) Invoke_O__O(self any) any { { var s__716000154__1 any; var t_ any = t.F_s__716000154; t.F_s__716000154 = nil; s__716000154__1 = t_; for { var temp__1927000414__auto____2 any; var root_1442 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_1443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1442, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1444 lang.IFn; if linked_1443 == nil { ifn_1444 = lang.IFn_Cast(root_1442) } else { ifn_1444 = nil }; var arg_1445 any = s__716000154__1; if linked_1443 == nil { temp__1927000414__auto____2 = ifn_1444.Invoke_O__O(arg_1445) } else { temp__1927000414__auto____2 = linked_1443.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1442, arg_1445) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__716000154__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1446 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_1447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1446, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1448 lang.IFn; if linked_1447 == nil { ifn_1448 = lang.IFn_Cast(root_1446) } else { ifn_1448 = nil }; var arg_1449 any = s__716000154__3; if linked_1447 == nil { tmp1 = ifn_1448.Invoke_O__O(arg_1449) } else { tmp1 = linked_1447.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1446, arg_1449) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1450 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_1451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1450, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1452 lang.IFn; if linked_1451 == nil { ifn_1452 = lang.IFn_Cast(root_1450) } else { ifn_1452 = nil }; var arg_1453 any = s__716000154__3; if linked_1451 == nil { c__1927001037__auto____4 = ifn_1452.Invoke_O__O(arg_1453) } else { c__1927001037__auto____4 = linked_1451.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1450, arg_1453) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__716000156__6 any; var root_1454 any = A_arbace_repr_clojure_A_const_60.GetRawRoot__O(); var linked_1455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1454, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1456 lang.IFn; if linked_1455 == nil { ifn_1456 = lang.IFn_Cast(root_1454) } else { ifn_1456 = nil }; var arg_1457 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1455 == nil { b__716000156__6 = ifn_1456.Invoke_O__O(arg_1457) } else { b__716000156__6 = linked_1455.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1454, arg_1457) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1464 any = A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_fn__716000159_A_New_O_I_O(b__716000156__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1463 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_fn__716000159_A_fn_class; if fncls__1463 == nil { var fncls__1463d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_77, false, fnbody__1464); A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_fn__716000159_A_fn_class = fncls__1463d; tmp3 = fncls__1463d } else { tmp3 = fncls__1463 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1464, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1465 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_1466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1465, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1467 lang.IFn; if linked_1466 == nil { ifn_1467 = lang.IFn_Cast(root_1465) } else { ifn_1467 = nil }; var arg_1468 any; var root_1470 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_1471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1470, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1472 lang.IFn; if linked_1471 == nil { ifn_1472 = lang.IFn_Cast(root_1470) } else { ifn_1472 = nil }; var arg_1473 any = b__716000156__6; if linked_1471 == nil { arg_1468 = ifn_1472.Invoke_O__O(arg_1473) } else { arg_1468 = linked_1471.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1470, arg_1473) }; var arg_1469 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__716000153); var tmp5 any; var root_1474 any = A_arbace_repr_clojure_A_const_65.GetRawRoot__O(); var linked_1475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1474, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1476 lang.IFn; if linked_1475 == nil { ifn_1476 = lang.IFn_Cast(root_1474) } else { ifn_1476 = nil }; var arg_1477 any = s__716000154__3; if linked_1475 == nil { tmp5 = ifn_1476.Invoke_O__O(arg_1477) } else { tmp5 = linked_1475.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1474, arg_1477) }; arg_1469 = tmp4.Invoke_O__O(tmp5); if linked_1466 == nil { return ifn_1467.Invoke_O_O__O(arg_1468, arg_1469) } else { return linked_1466.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1465, arg_1468, arg_1469) } } else { var root_1478 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_1479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1478, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1480 lang.IFn; if linked_1479 == nil { ifn_1480 = lang.IFn_Cast(root_1478) } else { ifn_1480 = nil }; var arg_1481 any; var root_1483 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_1484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1483, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1485 lang.IFn; if linked_1484 == nil { ifn_1485 = lang.IFn_Cast(root_1483) } else { ifn_1485 = nil }; var arg_1486 any = b__716000156__6; if linked_1484 == nil { arg_1481 = ifn_1485.Invoke_O__O(arg_1486) } else { arg_1481 = linked_1484.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1483, arg_1486) }; var arg_1482 any; if linked_1479 == nil { return ifn_1480.Invoke_O_O__O(arg_1481, arg_1482) } else { return linked_1479.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1478, arg_1481, arg_1482) } } } else { var vec__716000164__4 any; var root_1487 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_1488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1487, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1489 lang.IFn; if linked_1488 == nil { ifn_1489 = lang.IFn_Cast(root_1487) } else { ifn_1489 = nil }; var arg_1490 any = s__716000154__3; if linked_1488 == nil { vec__716000164__4 = ifn_1489.Invoke_O__O(arg_1490) } else { vec__716000164__4 = linked_1488.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1487, arg_1490) }; var out__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000164__4, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000164__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1491 any = A_arbace_repr_clojure_A_const_66.GetRawRoot__O(); var linked_1492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1491, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1493 lang.IFn; if linked_1492 == nil { ifn_1493 = lang.IFn_Cast(root_1491) } else { ifn_1493 = nil }; var arg_1494 any = lang.Tuple_Create_O_O__IPersistentVector(rel__6, out__5); var arg_1495 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__716000153); var tmp7 any; var root_1496 any = A_arbace_repr_clojure_A_const_67.GetRawRoot__O(); var linked_1497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1496, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1498 lang.IFn; if linked_1497 == nil { ifn_1498 = lang.IFn_Cast(root_1496) } else { ifn_1498 = nil }; var arg_1499 any = s__716000154__3; if linked_1497 == nil { tmp7 = ifn_1498.Invoke_O__O(arg_1499) } else { tmp7 = linked_1497.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1496, arg_1499) }; arg_1495 = tmp6.Invoke_O__O(tmp7); if linked_1492 == nil { return ifn_1493.Invoke_O_O__O(arg_1494, arg_1495) } else { return linked_1492.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1491, arg_1494, arg_1495) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :279:1
func A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_fn__716000159_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_fn__716000159_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_fn__716000159_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :279:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_fn__716000159_A) Ctor_O_I_O(c__b__716000156 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__716000156 = c__b__716000156; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :279:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_fn__716000159_A) Invoke_O__O(self any) any { { var i__716000155__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__716000155__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__716000160__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__716000155__1)); var out__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000160__2, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000160__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1458 any = A_arbace_repr_clojure_A_const_61.GetRawRoot__O(); var linked_1459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1458, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1460 lang.IFn; if linked_1459 == nil { ifn_1460 = lang.IFn_Cast(root_1458) } else { ifn_1460 = nil }; var arg_1461 any = t.F_b__716000156; var arg_1462 any = lang.Tuple_Create_O_O__IPersistentVector(rel__4, out__3); if linked_1459 == nil { ifn_1460.Invoke_O_O__O(arg_1461, arg_1462) } else { linked_1459.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1458, arg_1461, arg_1462) }; i__716000155__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__716000155__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_A_New() *A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_A{}; t.Ctor(); return t }
//line :281:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_A) Ctor() {}
//line :281:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_A) Invoke_O_O__O(self, s__716000170__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1568 any = A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_A_New_O_O(s__716000170__1, self); var tmp2 *jrt.Class; var fncls__1567 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_A_fn_class; if fncls__1567 == nil { var fncls__1567d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_78, false, fnbody__1568); A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_A_fn_class = fncls__1567d; tmp2 = fncls__1567d } else { tmp2 = fncls__1567 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1568, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :281:1
func A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_A{}; t.Ctor_O_O(p0, p1); return t }
//line :281:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_A) Ctor_O_O(c__s__716000170, c__iter__716000169 any) { t.F_s__716000170 = c__s__716000170; t.F_iter__716000169 = c__iter__716000169 }
//line :281:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_A) Invoke_O__O(self any) any { { var s__716000170__1 any; var t_ any = t.F_s__716000170; t.F_s__716000170 = nil; s__716000170__1 = t_; for { var temp__1927000414__auto____2 any; var root_1509 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_1510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1509, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1511 lang.IFn; if linked_1510 == nil { ifn_1511 = lang.IFn_Cast(root_1509) } else { ifn_1511 = nil }; var arg_1512 any = s__716000170__1; if linked_1510 == nil { temp__1927000414__auto____2 = ifn_1511.Invoke_O__O(arg_1512) } else { temp__1927000414__auto____2 = linked_1510.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1509, arg_1512) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__716000170__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1513 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_1514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1513, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1515 lang.IFn; if linked_1514 == nil { ifn_1515 = lang.IFn_Cast(root_1513) } else { ifn_1515 = nil }; var arg_1516 any = s__716000170__3; if linked_1514 == nil { tmp1 = ifn_1515.Invoke_O__O(arg_1516) } else { tmp1 = linked_1514.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1513, arg_1516) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1517 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_1518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1517, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1519 lang.IFn; if linked_1518 == nil { ifn_1519 = lang.IFn_Cast(root_1517) } else { ifn_1519 = nil }; var arg_1520 any = s__716000170__3; if linked_1518 == nil { c__1927001037__auto____4 = ifn_1519.Invoke_O__O(arg_1520) } else { c__1927001037__auto____4 = linked_1518.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1517, arg_1520) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__716000172__6 any; var root_1521 any = A_arbace_repr_clojure_A_const_60.GetRawRoot__O(); var linked_1522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1521, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1523 lang.IFn; if linked_1522 == nil { ifn_1523 = lang.IFn_Cast(root_1521) } else { ifn_1523 = nil }; var arg_1524 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1522 == nil { b__716000172__6 = ifn_1523.Invoke_O__O(arg_1524) } else { b__716000172__6 = linked_1522.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1521, arg_1524) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1531 any = A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_fn__716000175_A_New_O_I_O(b__716000172__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1530 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_fn__716000175_A_fn_class; if fncls__1530 == nil { var fncls__1530d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_79, false, fnbody__1531); A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_fn__716000175_A_fn_class = fncls__1530d; tmp3 = fncls__1530d } else { tmp3 = fncls__1530 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1531, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1532 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_1533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1532, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1534 lang.IFn; if linked_1533 == nil { ifn_1534 = lang.IFn_Cast(root_1532) } else { ifn_1534 = nil }; var arg_1535 any; var root_1537 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_1538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1537, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1539 lang.IFn; if linked_1538 == nil { ifn_1539 = lang.IFn_Cast(root_1537) } else { ifn_1539 = nil }; var arg_1540 any = b__716000172__6; if linked_1538 == nil { arg_1535 = ifn_1539.Invoke_O__O(arg_1540) } else { arg_1535 = linked_1538.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1537, arg_1540) }; var arg_1536 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__716000169); var tmp5 any; var root_1541 any = A_arbace_repr_clojure_A_const_65.GetRawRoot__O(); var linked_1542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1541, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1543 lang.IFn; if linked_1542 == nil { ifn_1543 = lang.IFn_Cast(root_1541) } else { ifn_1543 = nil }; var arg_1544 any = s__716000170__3; if linked_1542 == nil { tmp5 = ifn_1543.Invoke_O__O(arg_1544) } else { tmp5 = linked_1542.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1541, arg_1544) }; arg_1536 = tmp4.Invoke_O__O(tmp5); if linked_1533 == nil { return ifn_1534.Invoke_O_O__O(arg_1535, arg_1536) } else { return linked_1533.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1532, arg_1535, arg_1536) } } else { var root_1545 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_1546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1545, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1547 lang.IFn; if linked_1546 == nil { ifn_1547 = lang.IFn_Cast(root_1545) } else { ifn_1547 = nil }; var arg_1548 any; var root_1550 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_1551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1550, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1552 lang.IFn; if linked_1551 == nil { ifn_1552 = lang.IFn_Cast(root_1550) } else { ifn_1552 = nil }; var arg_1553 any = b__716000172__6; if linked_1551 == nil { arg_1548 = ifn_1552.Invoke_O__O(arg_1553) } else { arg_1548 = linked_1551.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1550, arg_1553) }; var arg_1549 any; if linked_1546 == nil { return ifn_1547.Invoke_O_O__O(arg_1548, arg_1549) } else { return linked_1546.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1545, arg_1548, arg_1549) } } } else { var vec__716000180__4 any; var root_1554 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_1555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1554, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1556 lang.IFn; if linked_1555 == nil { ifn_1556 = lang.IFn_Cast(root_1554) } else { ifn_1556 = nil }; var arg_1557 any = s__716000170__3; if linked_1555 == nil { vec__716000180__4 = ifn_1556.Invoke_O__O(arg_1557) } else { vec__716000180__4 = linked_1555.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1554, arg_1557) }; var out__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000180__4, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000180__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1558 any = A_arbace_repr_clojure_A_const_66.GetRawRoot__O(); var linked_1559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1558, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1560 lang.IFn; if linked_1559 == nil { ifn_1560 = lang.IFn_Cast(root_1558) } else { ifn_1560 = nil }; var arg_1561 any = lang.Tuple_Create_O_O__IPersistentVector(rel__6, out__5); var arg_1562 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__716000169); var tmp7 any; var root_1563 any = A_arbace_repr_clojure_A_const_67.GetRawRoot__O(); var linked_1564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1563, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1565 lang.IFn; if linked_1564 == nil { ifn_1565 = lang.IFn_Cast(root_1563) } else { ifn_1565 = nil }; var arg_1566 any = s__716000170__3; if linked_1564 == nil { tmp7 = ifn_1565.Invoke_O__O(arg_1566) } else { tmp7 = linked_1564.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1563, arg_1566) }; arg_1562 = tmp6.Invoke_O__O(tmp7); if linked_1559 == nil { return ifn_1560.Invoke_O_O__O(arg_1561, arg_1562) } else { return linked_1559.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1558, arg_1561, arg_1562) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :281:1
func A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_fn__716000175_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_fn__716000175_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_fn__716000175_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :281:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_fn__716000175_A) Ctor_O_I_O(c__b__716000172 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__716000172 = c__b__716000172; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :281:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_fn__716000175_A) Invoke_O__O(self any) any { { var i__716000171__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__716000171__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__716000176__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__716000171__1)); var out__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000176__2, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000176__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1525 any = A_arbace_repr_clojure_A_const_61.GetRawRoot__O(); var linked_1526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1525, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1527 lang.IFn; if linked_1526 == nil { ifn_1527 = lang.IFn_Cast(root_1525) } else { ifn_1527 = nil }; var arg_1528 any = t.F_b__716000172; var arg_1529 any = lang.Tuple_Create_O_O__IPersistentVector(rel__4, out__3); if linked_1526 == nil { ifn_1527.Invoke_O_O__O(arg_1528, arg_1529) } else { linked_1526.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1525, arg_1528, arg_1529) }; i__716000171__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__716000171__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_A_New_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6 any) *A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_A{}; t.Ctor_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :282:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_A) Ctor_O_O_O_O_O_O_O(c__back2, c__t, c__a, c__b, c__c, c__back, c__opts any) { t.F_back2 = c__back2; t.F_t = c__t; t.F_a = c__a; t.F_b = c__b; t.F_c = c__c; t.F_back = c__back; t.F_opts = c__opts }
//line :282:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_A) Invoke_O_O__O(self, s__716000186__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1832 any = A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_A_New_O_O_O_O_O_O_O_O_O(t.F_back2, self, s__716000186__1, t.F_t, t.F_a, t.F_b, t.F_c, t.F_back, t.F_opts); var tmp2 *jrt.Class; var fncls__1831 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_A_fn_class; if fncls__1831 == nil { var fncls__1831d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_80, false, fnbody__1832); A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_A_fn_class = fncls__1831d; tmp2 = fncls__1831d } else { tmp2 = fncls__1831 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1832, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :282:1
func A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_A_New_O_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7, p8 any) *A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_A{}; t.Ctor_O_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7, p8); return t }
//line :282:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_A) Ctor_O_O_O_O_O_O_O_O_O(c__back2, c__iter__716000185, c__s__716000186, c__t, c__a, c__b, c__c, c__back, c__opts any) { t.F_back2 = c__back2; t.F_iter__716000185 = c__iter__716000185; t.F_s__716000186 = c__s__716000186; t.F_t = c__t; t.F_a = c__a; t.F_b = c__b; t.F_c = c__c; t.F_back = c__back; t.F_opts = c__opts }
//line :282:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_A) Invoke_O__O(self any) any { { var s__716000186__1 any; var t_ any = t.F_s__716000186; t.F_s__716000186 = nil; s__716000186__1 = t_; for { var temp__1927000414__auto____2 any; var root_1571 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_1572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1571, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1573 lang.IFn; if linked_1572 == nil { ifn_1573 = lang.IFn_Cast(root_1571) } else { ifn_1573 = nil }; var arg_1574 any = s__716000186__1; if linked_1572 == nil { temp__1927000414__auto____2 = ifn_1573.Invoke_O__O(arg_1574) } else { temp__1927000414__auto____2 = linked_1572.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1571, arg_1574) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__716000186__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1575 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_1576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1575, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1577 lang.IFn; if linked_1576 == nil { ifn_1577 = lang.IFn_Cast(root_1575) } else { ifn_1577 = nil }; var arg_1578 any = s__716000186__3; if linked_1576 == nil { tmp1 = ifn_1577.Invoke_O__O(arg_1578) } else { tmp1 = linked_1576.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1575, arg_1578) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1579 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_1580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1579, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1581 lang.IFn; if linked_1580 == nil { ifn_1581 = lang.IFn_Cast(root_1579) } else { ifn_1581 = nil }; var arg_1582 any = s__716000186__3; if linked_1580 == nil { c__1927001037__auto____4 = ifn_1581.Invoke_O__O(arg_1582) } else { c__1927001037__auto____4 = linked_1580.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1579, arg_1582) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__716000188__6 any; var root_1583 any = A_arbace_repr_clojure_A_const_60.GetRawRoot__O(); var linked_1584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1583, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1585 lang.IFn; if linked_1584 == nil { ifn_1585 = lang.IFn_Cast(root_1583) } else { ifn_1585 = nil }; var arg_1586 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1584 == nil { b__716000188__6 = ifn_1585.Invoke_O__O(arg_1586) } else { b__716000188__6 = linked_1584.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1583, arg_1586) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1694 any = A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_fn__716000191_A_New_O_O_O_O_O_O_I_O_O_O(t.F_back2, t.F_t, b__716000188__6, t.F_a, t.F_b, t.F_c, size__1927001038__auto____5, t.F_back, t.F_opts, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1693 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_fn__716000191_A_fn_class; if fncls__1693 == nil { var fncls__1693d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_81, false, fnbody__1694); A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_fn__716000191_A_fn_class = fncls__1693d; tmp3 = fncls__1693d } else { tmp3 = fncls__1693 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1694, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1695 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_1696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1695, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1697 lang.IFn; if linked_1696 == nil { ifn_1697 = lang.IFn_Cast(root_1695) } else { ifn_1697 = nil }; var arg_1698 any; var root_1700 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_1701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1700, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1702 lang.IFn; if linked_1701 == nil { ifn_1702 = lang.IFn_Cast(root_1700) } else { ifn_1702 = nil }; var arg_1703 any = b__716000188__6; if linked_1701 == nil { arg_1698 = ifn_1702.Invoke_O__O(arg_1703) } else { arg_1698 = linked_1701.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1700, arg_1703) }; var arg_1699 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__716000185); var tmp5 any; var root_1704 any = A_arbace_repr_clojure_A_const_65.GetRawRoot__O(); var linked_1705 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1704, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1706 lang.IFn; if linked_1705 == nil { ifn_1706 = lang.IFn_Cast(root_1704) } else { ifn_1706 = nil }; var arg_1707 any = s__716000186__3; if linked_1705 == nil { tmp5 = ifn_1706.Invoke_O__O(arg_1707) } else { tmp5 = linked_1705.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1704, arg_1707) }; arg_1699 = tmp4.Invoke_O__O(tmp5); if linked_1696 == nil { return ifn_1697.Invoke_O_O__O(arg_1698, arg_1699) } else { return linked_1696.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1695, arg_1698, arg_1699) } } else { var root_1708 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_1709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1708, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1710 lang.IFn; if linked_1709 == nil { ifn_1710 = lang.IFn_Cast(root_1708) } else { ifn_1710 = nil }; var arg_1711 any; var root_1713 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_1714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1713, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1715 lang.IFn; if linked_1714 == nil { ifn_1715 = lang.IFn_Cast(root_1713) } else { ifn_1715 = nil }; var arg_1716 any = b__716000188__6; if linked_1714 == nil { arg_1711 = ifn_1715.Invoke_O__O(arg_1716) } else { arg_1711 = linked_1714.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1713, arg_1716) }; var arg_1712 any; if linked_1709 == nil { return ifn_1710.Invoke_O_O__O(arg_1711, arg_1712) } else { return linked_1709.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1708, arg_1711, arg_1712) } } } else { var vec__716000196__4 any; var root_1717 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_1718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1717, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1719 lang.IFn; if linked_1718 == nil { ifn_1719 = lang.IFn_Cast(root_1717) } else { ifn_1719 = nil }; var arg_1720 any = s__716000186__3; if linked_1718 == nil { vec__716000196__4 = ifn_1719.Invoke_O__O(arg_1720) } else { vec__716000196__4 = linked_1718.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1717, arg_1720) }; var out__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000196__4, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000196__4, lang.RT_IntCast_J__I_NoInit(1), nil); var orig__7 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_78.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_t).Invoke_O__O(rel__6)); var out2__8 any = lang.IFn_Cast(t.F_back).Invoke_O__O(out__5); var txt__9 any


	if jrt.J2g_Truth(out2__8) { var root_1725 any = A_arbace_repr_clojure_A_const_124.GetRawRoot__O(); var linked_1726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1725, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1727 lang.IFn; if linked_1726 == nil { ifn_1727 = lang.IFn_Cast(root_1725) } else { ifn_1727 = nil }; var arg_1728 any = t.F_b; var arg_1729 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_clojure_A_const_109, out2__8); if linked_1726 == nil { txt__9 = ifn_1727.Invoke_O_O__O(arg_1728, arg_1729) } else { txt__9 = linked_1726.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1725, arg_1728, arg_1729) } } else { txt__9 = nil }
//line :282:1
	var p__10 any; var root_1730 any = A_arbace_repr_clojure_A_const_124.GetRawRoot__O(); var linked_1731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1730, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1732 lang.IFn



	if linked_1731 == nil { ifn_1732 = lang.IFn_Cast(root_1730) } else { ifn_1732 = nil }; var arg_1733 any = t.F_a; var arg_1734 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_clojure_A_const_113, out__5); if linked_1731 == nil { p__10 = ifn_1732.Invoke_O_O__O(arg_1733, arg_1734) } else { p__10 = linked_1731.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1730, arg_1733, arg_1734) }
//line :282:1
	var root_1735 any = A_arbace_repr_clojure_A_const_66.GetRawRoot__O(); var linked_1736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1735, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1737 lang.IFn; if linked_1736 == nil { ifn_1737 = lang.IFn_Cast(root_1735) } else { ifn_1737 = nil }; var arg_1738 any; var tmp6 any




	if lang.Util_Identical_O_O__Z_NoInit(out2__8, nil) { tmp6 = A_arbace_repr_clojure_A_const_136 } else { var tmp7 any; var tmp8 any = A_arbace_repr_clojure_A_const_25; var and__1927000168__auto____11 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp8, A_arbace_repr_clojure_A_const_24.Invoke_O__O(p__10))

		if and__1927000168__auto____11 { var and__1927000168__auto____12 any = A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__10); if jrt.J2g_Truth(and__1927000168__auto____12) { var and__1927000168__auto____13 any; var root_1740 any = A_arbace_repr_clojure_A_const_41.GetRawRoot__O(); var linked_1741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1740, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1742 lang.IFn; if linked_1741 == nil { ifn_1742 = lang.IFn_Cast(root_1740) } else { ifn_1742 = nil }; var arg_1743 any = A_arbace_repr_clojure_A_const_20.Invoke_O__O(p__10); if linked_1741 == nil { and__1927000168__auto____13 = ifn_1742.Invoke_O__O(arg_1743) } else { and__1927000168__auto____13 = linked_1741.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1740, arg_1743) }; if jrt.J2g_Truth(and__1927000168__auto____13) {
			var root_1744 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_1745 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1744, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1746 lang.IFn; if linked_1745 == nil { ifn_1746 = lang.IFn_Cast(root_1744) } else { ifn_1746 = nil }; var arg_1747 any = A_arbace_repr_clojure_A_const_119; var arg_1748 any = A_arbace_repr_clojure_A_const_112.Invoke_O__O(t.F_opts); if linked_1745 == nil { tmp7 = ifn_1746.Invoke_O_O__O(arg_1747, arg_1748) } else { tmp7 = linked_1745.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1744, arg_1747, arg_1748) } } else {
//line :289:1
				tmp7 = and__1927000168__auto____13 } } else { tmp7 = and__1927000168__auto____12 } } else { tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11).Ref() }
//line :287:1
		if jrt.J2g_Truth(tmp7) { var want__11 any; var root_1749 any = A_arbace_repr_clojure_A_const_110.GetRawRoot__O(); var linked_1750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1749, A_arbace_repr_clojure_under_A_fn_class); var ifn_1751 lang.IFn



			if linked_1750 == nil { ifn_1751 = lang.IFn_Cast(root_1749) } else { ifn_1751 = nil }; var arg_1752 any; var root_1754 any = A_arbace_repr_clojure_A_const_104.GetRawRoot__O(); var linked_1755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1754, A_arbace_repr_clojure_parent_of_A_fn_class); var ifn_1756 lang.IFn; if linked_1755 == nil { ifn_1756 = lang.IFn_Cast(root_1754) } else { ifn_1756 = nil }; var arg_1757 any = rel__6; if linked_1755 == nil { arg_1752 = ifn_1756.Invoke_O__O(arg_1757) } else { arg_1752 = linked_1755.(*A_arbace_repr_clojure_parent_of_A).Invoke_O_O__O(root_1754, arg_1757) }; var arg_1753 any; var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_53); var tmp10 any; var root_1758 any = A_arbace_repr_clojure_A_const_32.GetRawRoot__O(); var linked_1759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1758, A_arbace_repr_clojure_base_A_fn_class); var ifn_1760 lang.IFn; if linked_1759 == nil { ifn_1760 = lang.IFn_Cast(root_1758) } else { ifn_1760 = nil }; var arg_1761 any; var root_1762 any = A_arbace_repr_clojure_A_const_106.GetRawRoot__O(); var linked_1763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1762, A_arbace_repr_clojure_name_of_A_fn_class); var ifn_1764 lang.IFn; if linked_1763 == nil { ifn_1764 = lang.IFn_Cast(root_1762) } else { ifn_1764 = nil }; var arg_1765 any = rel__6; if linked_1763 == nil { arg_1761 = ifn_1764.Invoke_O__O(arg_1765) } else { arg_1761 = linked_1763.(*A_arbace_repr_clojure_name_of_A).Invoke_O_O__O(root_1762, arg_1765) }; if linked_1759 == nil { tmp10 = ifn_1760.Invoke_O__O(arg_1761) } else { tmp10 = linked_1759.(*A_arbace_repr_clojure_base_A).Invoke_O_O__O(root_1758, arg_1761) }; arg_1753 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, tmp10, nil)).Ref(); if linked_1750 == nil { want__11 = ifn_1751.Invoke_O_O__O(arg_1752, arg_1753) } else { want__11 = linked_1750.(*A_arbace_repr_clojure_under_A).Invoke_O_O_O__O(root_1749, arg_1752, arg_1753) }
//line :287:1
			var resolved__12 any; var root_1766 any = A_arbace_repr_clojure_A_const_126.GetRawRoot__O(); var linked_1767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1766, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_resolve_conditionals_A_fn_class); var ifn_1768 lang.IFn




			if linked_1767 == nil { ifn_1768 = lang.IFn_Cast(root_1766) } else { ifn_1768 = nil }; var arg_1769 any = orig__7; var arg_1770 any = A_arbace_repr_clojure_A_const_137; if linked_1767 == nil { resolved__12 = ifn_1768.Invoke_O_O__O(arg_1769, arg_1770) } else { resolved__12 = linked_1767.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_resolve_conditionals_A).Invoke_O_O_O__O(root_1766, arg_1769, arg_1770) }
			var tmp11 any; var root_1771 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_1772 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1771, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1773 lang.IFn; if linked_1772 == nil { ifn_1773 = lang.IFn_Cast(root_1771) } else { ifn_1773 = nil }; var arg_1774 any = out2__8; var arg_1775 any = want__11; if linked_1772 == nil { tmp11 = ifn_1773.Invoke_O_O__O(arg_1774, arg_1775) } else { tmp11 = linked_1772.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1771, arg_1774, arg_1775) }; if jrt.J2g_Truth(tmp11) { tmp6 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_128, A_arbace_repr_clojure_A_const_129, A_arbace_repr_clojure_A_const_130, out2__8)) } else { var tmp12 any; var root_1776 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_1777 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1776, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1778 lang.IFn
				if linked_1777 == nil { ifn_1778 = lang.IFn_Cast(root_1776) } else { ifn_1778 = nil }; var arg_1779 any = txt__9; var arg_1780 any = resolved__12; if linked_1777 == nil { tmp12 = ifn_1778.Invoke_O_O__O(arg_1779, arg_1780) } else { tmp12 = linked_1777.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1776, arg_1779, arg_1780) }
//line :293:1
				if jrt.J2g_Truth(tmp12) { var tmp13 any = A_arbace_repr_clojure_A_const_128; var tmp14 any = A_arbace_repr_clojure_A_const_19; var tmp15 any = A_arbace_repr_clojure_A_const_131; var tmp16 any; var root_1781 any = A_arbace_repr_clojure_A_const_132.GetRawRoot__O(); var linked_1782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1781, A_arbace_repr_clojure_first_difference_A_fn_class); var ifn_1783 lang.IFn
					if linked_1782 == nil { ifn_1783 = lang.IFn_Cast(root_1781) } else { ifn_1783 = nil }; var arg_1784 any = resolved__12; var arg_1785 any = txt__9; if linked_1782 == nil { tmp16 = ifn_1783.Invoke_O_O__O(arg_1784, arg_1785) } else { tmp16 = linked_1782.(*A_arbace_repr_clojure_first_difference_A).Invoke_O_O_O__O(root_1781, arg_1784, arg_1785) }
//line :293:1
					tmp6 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp14, tmp15, tmp16)) } else { if A_arbace_repr_clojure_A_const_34 != nil { tmp6 = A_arbace_repr_clojure_A_const_138 } else { tmp6 = nil } } } } else {
//line :287:1
						var tmp17 any; var root_1786 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_1787 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1786, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1788 lang.IFn








						if linked_1787 == nil { ifn_1788 = lang.IFn_Cast(root_1786) } else { ifn_1788 = nil }; var arg_1789 any = out2__8; var arg_1790 any = rel__6; if linked_1787 == nil { tmp17 = ifn_1788.Invoke_O_O__O(arg_1789, arg_1790) } else { tmp17 = linked_1787.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1786, arg_1789, arg_1790) }
//line :287:1
						if jrt.J2g_Truth(tmp17) { tmp6 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_128, A_arbace_repr_clojure_A_const_129, A_arbace_repr_clojure_A_const_130, out2__8)) } else { if lang.Util_Equiv_O_O__Z_NoInit(txt__9, orig__7) { tmp6 = nil } else { var tmp18 any; var tmp19 any = A_arbace_repr_clojure_A_const_119; var and__1927000168__auto____11_2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp19, A_arbace_repr_clojure_A_const_112.Invoke_O__O(t.F_opts))












							if and__1927000168__auto____11_2 { var and__1927000168__auto____12_2 any; var p__12 any; var tmp20 *lang.Keyword = A_arbace_repr_clojure_A_const_70; var tmp21 lang.IFn = lang.IFn_Cast(tmp20.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_A_const_69.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_A_const_99))); var tmp22 any; var root_1823 any = A_arbace_repr_clojure_A_const_106.GetRawRoot__O(); var linked_1824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1823, A_arbace_repr_clojure_name_of_A_fn_class); var ifn_1825 lang.IFn
								if linked_1824 == nil { ifn_1825 = lang.IFn_Cast(root_1823) } else { ifn_1825 = nil }; var arg_1826 any = out__5; if linked_1824 == nil { tmp22 = ifn_1825.Invoke_O__O(arg_1826) } else { tmp22 = linked_1824.(*A_arbace_repr_clojure_name_of_A).Invoke_O_O__O(root_1823, arg_1826) }; p__12 = tmp21.Invoke_O_O_O__O(tmp22, lang.PersistentHashSet_EMPTY.Ref(), t.F_opts)
//line :300:1
								var and__1927000168__auto____13_2 any = A_arbace_repr_clojure_A_const_24.Invoke_O__O(p__12)

								if jrt.J2g_Truth(and__1927000168__auto____13_2) {
									var root_1791 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_1792 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1791, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1793 lang.IFn; if linked_1792 == nil { ifn_1793 = lang.IFn_Cast(root_1791) } else { ifn_1793 = nil }; var arg_1794 any = orig__7; var arg_1795 any; var root_1796 any = A_arbace_repr_clojure_A_const_134.GetRawRoot__O(); var linked_1797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1796, A_arbace_repr_clojure_translate_text_A_fn_class); var ifn_1798 lang.IFn; if linked_1797 == nil { ifn_1798 = lang.IFn_Cast(root_1796) } else { ifn_1798 = nil }; var arg_1799 any = orig__7; var arg_1800 any = p__12; var arg_1801 any = rel__6; var arg_1802 any = A_arbace_repr_clojure_A_const_33.Invoke_O_O__O(t.F_opts, lang.PersistentHashSet_EMPTY.Ref()); if linked_1797 == nil { arg_1795 = ifn_1798.Invoke_O_O_O_O__O(arg_1799, arg_1800, arg_1801, arg_1802) } else { arg_1795 = linked_1797.(*A_arbace_repr_clojure_translate_text_A).Invoke_O_O_O_O_O__O(root_1796, arg_1799, arg_1800, arg_1801, arg_1802) }; if linked_1792 == nil { and__1927000168__auto____12_2 = ifn_1793.Invoke_O_O__O(arg_1794, arg_1795) } else { and__1927000168__auto____12_2 = linked_1792.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1791, arg_1794, arg_1795) } } else {
//line :302:1
										and__1927000168__auto____12_2 = and__1927000168__auto____13_2 }
//line :300:1
								if jrt.J2g_Truth(and__1927000168__auto____12_2) {




									var tmp23 any; var root_1803 any = A_arbace_repr_clojure_A_const_124.GetRawRoot__O(); var linked_1804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1803, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1805 lang.IFn; if linked_1804 == nil { ifn_1805 = lang.IFn_Cast(root_1803) } else { ifn_1805 = nil }; var arg_1806 any = t.F_a; var arg_1807 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_clojure_A_const_109, out__5); if linked_1804 == nil { tmp23 = ifn_1805.Invoke_O_O__O(arg_1806, arg_1807) } else { tmp23 = linked_1804.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1803, arg_1806, arg_1807) }; var tmp24 any = tmp23; var tmp25 any; var root_1808 any = A_arbace_repr_clojure_A_const_124.GetRawRoot__O(); var linked_1809 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1808, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1810 lang.IFn; if linked_1809 == nil { ifn_1810 = lang.IFn_Cast(root_1808) } else { ifn_1810 = nil }; var arg_1811 any = t.F_c; var tmp26 any = A_arbace_repr_clojure_A_const_109; var arg_1812 any = lang.Tuple_Create_O_O__IPersistentVector(tmp26, lang.IFn_Cast(t.F_back2).Invoke_O__O(out2__8)); if linked_1809 == nil { tmp25 = ifn_1810.Invoke_O_O__O(arg_1811, arg_1812) } else { tmp25 = linked_1809.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1808, arg_1811, arg_1812) }; tmp18 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp24, tmp25)).Ref() } else {
//line :300:1
										tmp18 = and__1927000168__auto____12_2 } } else { tmp18 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11_2).Ref() }
//line :287:1
							if jrt.J2g_Truth(tmp18) { var tmp27 any = A_arbace_repr_clojure_A_const_128; var tmp28 any = A_arbace_repr_clojure_A_const_135; var tmp29 any = A_arbace_repr_clojure_A_const_131; var tmp30 any; var root_1813 any = A_arbace_repr_clojure_A_const_132.GetRawRoot__O(); var linked_1814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1813, A_arbace_repr_clojure_first_difference_A_fn_class); var ifn_1815 lang.IFn


















								if linked_1814 == nil { ifn_1815 = lang.IFn_Cast(root_1813) } else { ifn_1815 = nil }; var arg_1816 any = orig__7; var arg_1817 any = txt__9; if linked_1814 == nil { tmp30 = ifn_1815.Invoke_O_O__O(arg_1816, arg_1817) } else { tmp30 = linked_1814.(*A_arbace_repr_clojure_first_difference_A).Invoke_O_O_O__O(root_1813, arg_1816, arg_1817) }
//line :287:1
								tmp6 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp27, tmp28, tmp29, tmp30)) } else { if A_arbace_repr_clojure_A_const_34 != nil { var tmp31 any = A_arbace_repr_clojure_A_const_128; var tmp32 any = A_arbace_repr_clojure_A_const_19; var tmp33 any = A_arbace_repr_clojure_A_const_131; var tmp34 any; var root_1818 any = A_arbace_repr_clojure_A_const_132.GetRawRoot__O(); var linked_1819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1818, A_arbace_repr_clojure_first_difference_A_fn_class); var ifn_1820 lang.IFn



















									if linked_1819 == nil { ifn_1820 = lang.IFn_Cast(root_1818) } else { ifn_1820 = nil }; var arg_1821 any = orig__7; var arg_1822 any = txt__9; if linked_1819 == nil { tmp34 = ifn_1820.Invoke_O_O__O(arg_1821, arg_1822) } else { tmp34 = linked_1819.(*A_arbace_repr_clojure_first_difference_A).Invoke_O_O_O__O(root_1818, arg_1821, arg_1822) }
//line :287:1
									tmp6 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp31, tmp32, tmp33, tmp34)) } else { tmp6 = nil } } } } } }
//line :282:1
	arg_1738 = lang.Tuple_Create_O_O__IPersistentVector(rel__6, tmp6); var arg_1739 any; var tmp35 lang.IFn = lang.IFn_Cast(t.F_iter__716000185); var tmp36 any; var root_1827 any = A_arbace_repr_clojure_A_const_67.GetRawRoot__O(); var linked_1828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1827, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1829 lang.IFn; if linked_1828 == nil { ifn_1829 = lang.IFn_Cast(root_1827) } else { ifn_1829 = nil }; var arg_1830 any = s__716000186__3; if linked_1828 == nil { tmp36 = ifn_1829.Invoke_O__O(arg_1830) } else { tmp36 = linked_1828.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1827, arg_1830) }; arg_1739 = tmp35.Invoke_O__O(tmp36); if linked_1736 == nil { return ifn_1737.Invoke_O_O__O(arg_1738, arg_1739) } else { return linked_1736.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1735, arg_1738, arg_1739) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :282:1
func A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_fn__716000191_A_New_O_O_O_O_O_O_I_O_O_O(p0, p1, p2, p3, p4, p5 any, p6 int32, p7, p8, p9 any) *A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_fn__716000191_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_fn__716000191_A{}; t.Ctor_O_O_O_O_O_O_I_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9); return t }
//line :282:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_fn__716000191_A) Ctor_O_O_O_O_O_O_I_O_O_O(c__back2, c__t, c__b__716000188, c__a, c__b, c__c any, c__size__1927001038__auto__ int32, c__back, c__opts, c__c__1927001037__auto__ any) { t.F_back2 = c__back2; t.F_t = c__t; t.F_b__716000188 = c__b__716000188; t.F_a = c__a; t.F_b = c__b; t.F_c = c__c; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_back = c__back; t.F_opts = c__opts; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :282:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_fn__716000191_A) Invoke_O__O(self any) any { { var i__716000187__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__716000187__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__716000192__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__716000187__1)); var out__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000192__2, lang.RT_IntCast_J__I_NoInit(0), nil); var rel__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000192__2, lang.RT_IntCast_J__I_NoInit(1), nil); var orig__5 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_78.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_t).Invoke_O__O(rel__4)); var out2__6 any = lang.IFn_Cast(t.F_back).Invoke_O__O(out__3); var txt__7 any


	if jrt.J2g_Truth(out2__6) { var root_1591 any = A_arbace_repr_clojure_A_const_124.GetRawRoot__O(); var linked_1592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1591, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1593 lang.IFn; if linked_1592 == nil { ifn_1593 = lang.IFn_Cast(root_1591) } else { ifn_1593 = nil }; var arg_1594 any = t.F_b; var arg_1595 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_clojure_A_const_109, out2__6); if linked_1592 == nil { txt__7 = ifn_1593.Invoke_O_O__O(arg_1594, arg_1595) } else { txt__7 = linked_1592.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1591, arg_1594, arg_1595) } } else { txt__7 = nil }
//line :282:1
	var p__8 any; var root_1596 any = A_arbace_repr_clojure_A_const_124.GetRawRoot__O(); var linked_1597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1596, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1598 lang.IFn



	if linked_1597 == nil { ifn_1598 = lang.IFn_Cast(root_1596) } else { ifn_1598 = nil }; var arg_1599 any = t.F_a; var arg_1600 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_clojure_A_const_113, out__3); if linked_1597 == nil { p__8 = ifn_1598.Invoke_O_O__O(arg_1599, arg_1600) } else { p__8 = linked_1597.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1596, arg_1599, arg_1600) }
//line :282:1
	var root_1601 any = A_arbace_repr_clojure_A_const_61.GetRawRoot__O(); var linked_1602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1601, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1603 lang.IFn; if linked_1602 == nil { ifn_1603 = lang.IFn_Cast(root_1601) } else { ifn_1603 = nil }; var arg_1604 any = t.F_b__716000188; var arg_1605 any; var tmp2 any




	if lang.Util_Identical_O_O__Z_NoInit(out2__6, nil) { tmp2 = A_arbace_repr_clojure_A_const_125 } else { var tmp3 any; var tmp4 any = A_arbace_repr_clojure_A_const_25; var and__1927000168__auto____9 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp4, A_arbace_repr_clojure_A_const_24.Invoke_O__O(p__8))

		if and__1927000168__auto____9 { var and__1927000168__auto____10 any = A_arbace_repr_clojure_A_const_27.Invoke_O__O(p__8); if jrt.J2g_Truth(and__1927000168__auto____10) { var and__1927000168__auto____11 any; var root_1606 any = A_arbace_repr_clojure_A_const_41.GetRawRoot__O(); var linked_1607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1606, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1608 lang.IFn; if linked_1607 == nil { ifn_1608 = lang.IFn_Cast(root_1606) } else { ifn_1608 = nil }; var arg_1609 any = A_arbace_repr_clojure_A_const_20.Invoke_O__O(p__8); if linked_1607 == nil { and__1927000168__auto____11 = ifn_1608.Invoke_O__O(arg_1609) } else { and__1927000168__auto____11 = linked_1607.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1606, arg_1609) }; if jrt.J2g_Truth(and__1927000168__auto____11) {
			var root_1610 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_1611 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1610, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1612 lang.IFn; if linked_1611 == nil { ifn_1612 = lang.IFn_Cast(root_1610) } else { ifn_1612 = nil }; var arg_1613 any = A_arbace_repr_clojure_A_const_119; var arg_1614 any = A_arbace_repr_clojure_A_const_112.Invoke_O__O(t.F_opts); if linked_1611 == nil { tmp3 = ifn_1612.Invoke_O_O__O(arg_1613, arg_1614) } else { tmp3 = linked_1611.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1610, arg_1613, arg_1614) } } else {
//line :289:1
				tmp3 = and__1927000168__auto____11 } } else { tmp3 = and__1927000168__auto____10 } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____9).Ref() }
//line :287:1
		if jrt.J2g_Truth(tmp3) { var want__9 any; var root_1615 any = A_arbace_repr_clojure_A_const_110.GetRawRoot__O(); var linked_1616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1615, A_arbace_repr_clojure_under_A_fn_class); var ifn_1617 lang.IFn



			if linked_1616 == nil { ifn_1617 = lang.IFn_Cast(root_1615) } else { ifn_1617 = nil }; var arg_1618 any; var root_1620 any = A_arbace_repr_clojure_A_const_104.GetRawRoot__O(); var linked_1621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1620, A_arbace_repr_clojure_parent_of_A_fn_class); var ifn_1622 lang.IFn; if linked_1621 == nil { ifn_1622 = lang.IFn_Cast(root_1620) } else { ifn_1622 = nil }; var arg_1623 any = rel__4; if linked_1621 == nil { arg_1618 = ifn_1622.Invoke_O__O(arg_1623) } else { arg_1618 = linked_1621.(*A_arbace_repr_clojure_parent_of_A).Invoke_O_O__O(root_1620, arg_1623) }; var arg_1619 any; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_53); var tmp6 any; var root_1624 any = A_arbace_repr_clojure_A_const_32.GetRawRoot__O(); var linked_1625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1624, A_arbace_repr_clojure_base_A_fn_class); var ifn_1626 lang.IFn; if linked_1625 == nil { ifn_1626 = lang.IFn_Cast(root_1624) } else { ifn_1626 = nil }; var arg_1627 any; var root_1628 any = A_arbace_repr_clojure_A_const_106.GetRawRoot__O(); var linked_1629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1628, A_arbace_repr_clojure_name_of_A_fn_class); var ifn_1630 lang.IFn; if linked_1629 == nil { ifn_1630 = lang.IFn_Cast(root_1628) } else { ifn_1630 = nil }; var arg_1631 any = rel__4; if linked_1629 == nil { arg_1627 = ifn_1630.Invoke_O__O(arg_1631) } else { arg_1627 = linked_1629.(*A_arbace_repr_clojure_name_of_A).Invoke_O_O__O(root_1628, arg_1631) }; if linked_1625 == nil { tmp6 = ifn_1626.Invoke_O__O(arg_1627) } else { tmp6 = linked_1625.(*A_arbace_repr_clojure_base_A).Invoke_O_O__O(root_1624, arg_1627) }; arg_1619 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp6, nil)).Ref(); if linked_1616 == nil { want__9 = ifn_1617.Invoke_O_O__O(arg_1618, arg_1619) } else { want__9 = linked_1616.(*A_arbace_repr_clojure_under_A).Invoke_O_O_O__O(root_1615, arg_1618, arg_1619) }
//line :287:1
			var resolved__10 any; var root_1632 any = A_arbace_repr_clojure_A_const_126.GetRawRoot__O(); var linked_1633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1632, aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_resolve_conditionals_A_fn_class); var ifn_1634 lang.IFn




			if linked_1633 == nil { ifn_1634 = lang.IFn_Cast(root_1632) } else { ifn_1634 = nil }; var arg_1635 any = orig__5; var arg_1636 any = A_arbace_repr_clojure_A_const_127; if linked_1633 == nil { resolved__10 = ifn_1634.Invoke_O_O__O(arg_1635, arg_1636) } else { resolved__10 = linked_1633.(*aot_arbace_repr_clojure_text.A_arbace_repr_clojure_text_resolve_conditionals_A).Invoke_O_O_O__O(root_1632, arg_1635, arg_1636) }
			var tmp7 any; var root_1637 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_1638 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1637, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1639 lang.IFn; if linked_1638 == nil { ifn_1639 = lang.IFn_Cast(root_1637) } else { ifn_1639 = nil }; var arg_1640 any = out2__6; var arg_1641 any = want__9; if linked_1638 == nil { tmp7 = ifn_1639.Invoke_O_O__O(arg_1640, arg_1641) } else { tmp7 = linked_1638.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1637, arg_1640, arg_1641) }; if jrt.J2g_Truth(tmp7) { tmp2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_128, A_arbace_repr_clojure_A_const_129, A_arbace_repr_clojure_A_const_130, out2__6)) } else { var tmp8 any; var root_1642 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_1643 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1642, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1644 lang.IFn
				if linked_1643 == nil { ifn_1644 = lang.IFn_Cast(root_1642) } else { ifn_1644 = nil }; var arg_1645 any = txt__7; var arg_1646 any = resolved__10; if linked_1643 == nil { tmp8 = ifn_1644.Invoke_O_O__O(arg_1645, arg_1646) } else { tmp8 = linked_1643.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1642, arg_1645, arg_1646) }
//line :293:1
				if jrt.J2g_Truth(tmp8) { var tmp9 any = A_arbace_repr_clojure_A_const_128; var tmp10 any = A_arbace_repr_clojure_A_const_19; var tmp11 any = A_arbace_repr_clojure_A_const_131; var tmp12 any; var root_1647 any = A_arbace_repr_clojure_A_const_132.GetRawRoot__O(); var linked_1648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1647, A_arbace_repr_clojure_first_difference_A_fn_class); var ifn_1649 lang.IFn
					if linked_1648 == nil { ifn_1649 = lang.IFn_Cast(root_1647) } else { ifn_1649 = nil }; var arg_1650 any = resolved__10; var arg_1651 any = txt__7; if linked_1648 == nil { tmp12 = ifn_1649.Invoke_O_O__O(arg_1650, arg_1651) } else { tmp12 = linked_1648.(*A_arbace_repr_clojure_first_difference_A).Invoke_O_O_O__O(root_1647, arg_1650, arg_1651) }
//line :293:1
					tmp2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, tmp11, tmp12)) } else { if A_arbace_repr_clojure_A_const_34 != nil { tmp2 = A_arbace_repr_clojure_A_const_133 } else { tmp2 = nil } } } } else {
//line :287:1
						var tmp13 any; var root_1652 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_1653 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1652, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1654 lang.IFn








						if linked_1653 == nil { ifn_1654 = lang.IFn_Cast(root_1652) } else { ifn_1654 = nil }; var arg_1655 any = out2__6; var arg_1656 any = rel__4; if linked_1653 == nil { tmp13 = ifn_1654.Invoke_O_O__O(arg_1655, arg_1656) } else { tmp13 = linked_1653.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1652, arg_1655, arg_1656) }
//line :287:1
						if jrt.J2g_Truth(tmp13) { tmp2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_128, A_arbace_repr_clojure_A_const_129, A_arbace_repr_clojure_A_const_130, out2__6)) } else { if lang.Util_Equiv_O_O__Z_NoInit(txt__7, orig__5) { tmp2 = nil } else { var tmp14 any; var tmp15 any = A_arbace_repr_clojure_A_const_119; var and__1927000168__auto____9_2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp15, A_arbace_repr_clojure_A_const_112.Invoke_O__O(t.F_opts))












							if and__1927000168__auto____9_2 { var and__1927000168__auto____10_2 any; var p__10 any; var tmp16 *lang.Keyword = A_arbace_repr_clojure_A_const_70; var tmp17 lang.IFn = lang.IFn_Cast(tmp16.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_A_const_69.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_A_const_99))); var tmp18 any; var root_1689 any = A_arbace_repr_clojure_A_const_106.GetRawRoot__O(); var linked_1690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1689, A_arbace_repr_clojure_name_of_A_fn_class); var ifn_1691 lang.IFn
								if linked_1690 == nil { ifn_1691 = lang.IFn_Cast(root_1689) } else { ifn_1691 = nil }; var arg_1692 any = out__3; if linked_1690 == nil { tmp18 = ifn_1691.Invoke_O__O(arg_1692) } else { tmp18 = linked_1690.(*A_arbace_repr_clojure_name_of_A).Invoke_O_O__O(root_1689, arg_1692) }; p__10 = tmp17.Invoke_O_O_O__O(tmp18, lang.PersistentHashSet_EMPTY.Ref(), t.F_opts)
//line :300:1
								var and__1927000168__auto____11_2 any = A_arbace_repr_clojure_A_const_24.Invoke_O__O(p__10)

								if jrt.J2g_Truth(and__1927000168__auto____11_2) {
									var root_1657 any = A_arbace_repr_clojure_A_const_46.GetRawRoot__O(); var linked_1658 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1657, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1659 lang.IFn; if linked_1658 == nil { ifn_1659 = lang.IFn_Cast(root_1657) } else { ifn_1659 = nil }; var arg_1660 any = orig__5; var arg_1661 any; var root_1662 any = A_arbace_repr_clojure_A_const_134.GetRawRoot__O(); var linked_1663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1662, A_arbace_repr_clojure_translate_text_A_fn_class); var ifn_1664 lang.IFn; if linked_1663 == nil { ifn_1664 = lang.IFn_Cast(root_1662) } else { ifn_1664 = nil }; var arg_1665 any = orig__5; var arg_1666 any = p__10; var arg_1667 any = rel__4; var arg_1668 any = A_arbace_repr_clojure_A_const_33.Invoke_O_O__O(t.F_opts, lang.PersistentHashSet_EMPTY.Ref()); if linked_1663 == nil { arg_1661 = ifn_1664.Invoke_O_O_O_O__O(arg_1665, arg_1666, arg_1667, arg_1668) } else { arg_1661 = linked_1663.(*A_arbace_repr_clojure_translate_text_A).Invoke_O_O_O_O_O__O(root_1662, arg_1665, arg_1666, arg_1667, arg_1668) }; if linked_1658 == nil { and__1927000168__auto____10_2 = ifn_1659.Invoke_O_O__O(arg_1660, arg_1661) } else { and__1927000168__auto____10_2 = linked_1658.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1657, arg_1660, arg_1661) } } else {
//line :302:1
										and__1927000168__auto____10_2 = and__1927000168__auto____11_2 }
//line :300:1
								if jrt.J2g_Truth(and__1927000168__auto____10_2) {




									var tmp19 any; var root_1669 any = A_arbace_repr_clojure_A_const_124.GetRawRoot__O(); var linked_1670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1669, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1671 lang.IFn; if linked_1670 == nil { ifn_1671 = lang.IFn_Cast(root_1669) } else { ifn_1671 = nil }; var arg_1672 any = t.F_a; var arg_1673 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_clojure_A_const_109, out__3); if linked_1670 == nil { tmp19 = ifn_1671.Invoke_O_O__O(arg_1672, arg_1673) } else { tmp19 = linked_1670.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1669, arg_1672, arg_1673) }; var tmp20 any = tmp19; var tmp21 any; var root_1674 any = A_arbace_repr_clojure_A_const_124.GetRawRoot__O(); var linked_1675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1674, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1676 lang.IFn; if linked_1675 == nil { ifn_1676 = lang.IFn_Cast(root_1674) } else { ifn_1676 = nil }; var arg_1677 any = t.F_c; var tmp22 any = A_arbace_repr_clojure_A_const_109; var arg_1678 any = lang.Tuple_Create_O_O__IPersistentVector(tmp22, lang.IFn_Cast(t.F_back2).Invoke_O__O(out2__6)); if linked_1675 == nil { tmp21 = ifn_1676.Invoke_O_O__O(arg_1677, arg_1678) } else { tmp21 = linked_1675.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1674, arg_1677, arg_1678) }; tmp14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp20, tmp21)).Ref() } else {
//line :300:1
										tmp14 = and__1927000168__auto____10_2 } } else { tmp14 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____9_2).Ref() }
//line :287:1
							if jrt.J2g_Truth(tmp14) { var tmp23 any = A_arbace_repr_clojure_A_const_128; var tmp24 any = A_arbace_repr_clojure_A_const_135; var tmp25 any = A_arbace_repr_clojure_A_const_131; var tmp26 any; var root_1679 any = A_arbace_repr_clojure_A_const_132.GetRawRoot__O(); var linked_1680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1679, A_arbace_repr_clojure_first_difference_A_fn_class); var ifn_1681 lang.IFn


















								if linked_1680 == nil { ifn_1681 = lang.IFn_Cast(root_1679) } else { ifn_1681 = nil }; var arg_1682 any = orig__5; var arg_1683 any = txt__7; if linked_1680 == nil { tmp26 = ifn_1681.Invoke_O_O__O(arg_1682, arg_1683) } else { tmp26 = linked_1680.(*A_arbace_repr_clojure_first_difference_A).Invoke_O_O_O__O(root_1679, arg_1682, arg_1683) }
//line :287:1
								tmp2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp23, tmp24, tmp25, tmp26)) } else { if A_arbace_repr_clojure_A_const_34 != nil { var tmp27 any = A_arbace_repr_clojure_A_const_128; var tmp28 any = A_arbace_repr_clojure_A_const_19; var tmp29 any = A_arbace_repr_clojure_A_const_131; var tmp30 any; var root_1684 any = A_arbace_repr_clojure_A_const_132.GetRawRoot__O(); var linked_1685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1684, A_arbace_repr_clojure_first_difference_A_fn_class); var ifn_1686 lang.IFn



















									if linked_1685 == nil { ifn_1686 = lang.IFn_Cast(root_1684) } else { ifn_1686 = nil }; var arg_1687 any = orig__5; var arg_1688 any = txt__7; if linked_1685 == nil { tmp30 = ifn_1686.Invoke_O_O__O(arg_1687, arg_1688) } else { tmp30 = linked_1685.(*A_arbace_repr_clojure_first_difference_A).Invoke_O_O_O__O(root_1684, arg_1687, arg_1688) }
//line :287:1
									tmp2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp27, tmp28, tmp29, tmp30)) } else { tmp2 = nil } } } } } }
//line :282:1
	arg_1605 = lang.Tuple_Create_O_O__IPersistentVector(rel__4, tmp2); if linked_1602 == nil { ifn_1603.Invoke_O_O__O(arg_1604, arg_1605) } else { linked_1602.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1601, arg_1604, arg_1605) }; i__716000187__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__716000187__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





























func A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_A_New() *A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_A{}; t.Ctor(); return t }
//line :312:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_A) Ctor() {}
//line :312:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_A) Invoke_O_O__O(self, s__716000202__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1918 any = A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_A_New_O_O(self, s__716000202__1); var tmp2 *jrt.Class; var fncls__1917 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_A_fn_class; if fncls__1917 == nil { var fncls__1917d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_82, false, fnbody__1918); A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_A_fn_class = fncls__1917d; tmp2 = fncls__1917d } else { tmp2 = fncls__1917 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1918, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :312:1
func A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_A{}; t.Ctor_O_O(p0, p1); return t }
//line :312:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_A) Ctor_O_O(c__iter__716000201, c__s__716000202 any) { t.F_iter__716000201 = c__iter__716000201; t.F_s__716000202 = c__s__716000202 }
//line :312:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_A) Invoke_O__O(self any) any { { var s__716000202__1 any; var t_ any = t.F_s__716000202; t.F_s__716000202 = nil; s__716000202__1 = t_; for { var temp__1927000414__auto____2 any; var root_1859 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_1860 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1859, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1861 lang.IFn; if linked_1860 == nil { ifn_1861 = lang.IFn_Cast(root_1859) } else { ifn_1861 = nil }; var arg_1862 any = s__716000202__1; if linked_1860 == nil { temp__1927000414__auto____2 = ifn_1861.Invoke_O__O(arg_1862) } else { temp__1927000414__auto____2 = linked_1860.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1859, arg_1862) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__716000202__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1863 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_1864 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1863, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1865 lang.IFn; if linked_1864 == nil { ifn_1865 = lang.IFn_Cast(root_1863) } else { ifn_1865 = nil }; var arg_1866 any = s__716000202__3; if linked_1864 == nil { tmp1 = ifn_1865.Invoke_O__O(arg_1866) } else { tmp1 = linked_1864.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1863, arg_1866) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1867 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_1868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1867, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1869 lang.IFn; if linked_1868 == nil { ifn_1869 = lang.IFn_Cast(root_1867) } else { ifn_1869 = nil }; var arg_1870 any = s__716000202__3; if linked_1868 == nil { c__1927001037__auto____4 = ifn_1869.Invoke_O__O(arg_1870) } else { c__1927001037__auto____4 = linked_1868.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1867, arg_1870) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__716000204__6 any; var root_1871 any = A_arbace_repr_clojure_A_const_60.GetRawRoot__O(); var linked_1872 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1871, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1873 lang.IFn; if linked_1872 == nil { ifn_1873 = lang.IFn_Cast(root_1871) } else { ifn_1873 = nil }; var arg_1874 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1872 == nil { b__716000204__6 = ifn_1873.Invoke_O__O(arg_1874) } else { b__716000204__6 = linked_1872.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1871, arg_1874) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1881 any = A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_fn__716000207_A_New_O_I_O(b__716000204__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1880 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_fn__716000207_A_fn_class; if fncls__1880 == nil { var fncls__1880d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_83, false, fnbody__1881); A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_fn__716000207_A_fn_class = fncls__1880d; tmp3 = fncls__1880d } else { tmp3 = fncls__1880 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1881, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1882 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_1883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1882, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1884 lang.IFn; if linked_1883 == nil { ifn_1884 = lang.IFn_Cast(root_1882) } else { ifn_1884 = nil }; var arg_1885 any; var root_1887 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_1888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1887, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1889 lang.IFn; if linked_1888 == nil { ifn_1889 = lang.IFn_Cast(root_1887) } else { ifn_1889 = nil }; var arg_1890 any = b__716000204__6; if linked_1888 == nil { arg_1885 = ifn_1889.Invoke_O__O(arg_1890) } else { arg_1885 = linked_1888.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1887, arg_1890) }; var arg_1886 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__716000201); var tmp5 any; var root_1891 any = A_arbace_repr_clojure_A_const_65.GetRawRoot__O(); var linked_1892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1891, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1893 lang.IFn; if linked_1892 == nil { ifn_1893 = lang.IFn_Cast(root_1891) } else { ifn_1893 = nil }; var arg_1894 any = s__716000202__3; if linked_1892 == nil { tmp5 = ifn_1893.Invoke_O__O(arg_1894) } else { tmp5 = linked_1892.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1891, arg_1894) }; arg_1886 = tmp4.Invoke_O__O(tmp5); if linked_1883 == nil { return ifn_1884.Invoke_O_O__O(arg_1885, arg_1886) } else { return linked_1883.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1882, arg_1885, arg_1886) } } else { var root_1895 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_1896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1895, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1897 lang.IFn; if linked_1896 == nil { ifn_1897 = lang.IFn_Cast(root_1895) } else { ifn_1897 = nil }; var arg_1898 any; var root_1900 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_1901 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1900, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1902 lang.IFn; if linked_1901 == nil { ifn_1902 = lang.IFn_Cast(root_1900) } else { ifn_1902 = nil }; var arg_1903 any = b__716000204__6; if linked_1901 == nil { arg_1898 = ifn_1902.Invoke_O__O(arg_1903) } else { arg_1898 = linked_1901.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1900, arg_1903) }; var arg_1899 any; if linked_1896 == nil { return ifn_1897.Invoke_O_O__O(arg_1898, arg_1899) } else { return linked_1896.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1895, arg_1898, arg_1899) } } } else { var vec__716000212__4 any; var root_1904 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_1905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1904, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1906 lang.IFn; if linked_1905 == nil { ifn_1906 = lang.IFn_Cast(root_1904) } else { ifn_1906 = nil }; var arg_1907 any = s__716000202__3; if linked_1905 == nil { vec__716000212__4 = ifn_1906.Invoke_O__O(arg_1907) } else { vec__716000212__4 = linked_1905.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1904, arg_1907) }; var rel__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000212__4, lang.RT_IntCast_J__I_NoInit(0), nil); var m__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000212__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1908 any = A_arbace_repr_clojure_A_const_66.GetRawRoot__O(); var linked_1909 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1908, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1910 lang.IFn; if linked_1909 == nil { ifn_1910 = lang.IFn_Cast(root_1908) } else { ifn_1910 = nil }; var arg_1911 any = lang.Tuple_Create_O_O__IPersistentVector(rel__5, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_128, A_arbace_repr_clojure_A_const_114, A_arbace_repr_clojure_A_const_131, m__6))); var arg_1912 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__716000201); var tmp7 any; var root_1913 any = A_arbace_repr_clojure_A_const_67.GetRawRoot__O(); var linked_1914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1913, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1915 lang.IFn; if linked_1914 == nil { ifn_1915 = lang.IFn_Cast(root_1913) } else { ifn_1915 = nil }; var arg_1916 any = s__716000202__3; if linked_1914 == nil { tmp7 = ifn_1915.Invoke_O__O(arg_1916) } else { tmp7 = linked_1914.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1913, arg_1916) }; arg_1912 = tmp6.Invoke_O__O(tmp7); if linked_1909 == nil { return ifn_1910.Invoke_O_O__O(arg_1911, arg_1912) } else { return linked_1909.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1908, arg_1911, arg_1912) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :312:1
func A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_fn__716000207_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_fn__716000207_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_fn__716000207_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :312:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_fn__716000207_A) Ctor_O_I_O(c__b__716000204 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__716000204 = c__b__716000204; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :312:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_fn__716000207_A) Invoke_O__O(self any) any { { var i__716000203__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__716000203__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__716000208__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__716000203__1)); var rel__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000208__2, lang.RT_IntCast_J__I_NoInit(0), nil); var m__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000208__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1875 any = A_arbace_repr_clojure_A_const_61.GetRawRoot__O(); var linked_1876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1875, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1877 lang.IFn; if linked_1876 == nil { ifn_1877 = lang.IFn_Cast(root_1875) } else { ifn_1877 = nil }; var arg_1878 any = t.F_b__716000204; var arg_1879 any = lang.Tuple_Create_O_O__IPersistentVector(rel__3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_128, A_arbace_repr_clojure_A_const_114, A_arbace_repr_clojure_A_const_131, m__4))); if linked_1876 == nil { ifn_1877.Invoke_O_O__O(arg_1878, arg_1879) } else { linked_1876.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1875, arg_1878, arg_1879) }; i__716000203__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__716000203__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_A_New_O(p0 any) *A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_A{}; t.Ctor_O(p0); return t }
//line :314:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_A) Ctor_O(c__a any) { t.F_a = c__a }
//line :314:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_A) Invoke_O_O__O(self, s__716000218__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1980 any = A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_A_New_O_O_O(self, s__716000218__1, t.F_a); var tmp2 *jrt.Class; var fncls__1979 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_A_fn_class; if fncls__1979 == nil { var fncls__1979d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_84, false, fnbody__1980); A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_A_fn_class = fncls__1979d; tmp2 = fncls__1979d } else { tmp2 = fncls__1979 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1980, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :314:1
func A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :314:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_A) Ctor_O_O_O(c__iter__716000217, c__s__716000218, c__a any) { t.F_iter__716000217 = c__iter__716000217; t.F_s__716000218 = c__s__716000218; t.F_a = c__a }
//line :314:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_A) Invoke_O__O(self any) any { { var s__716000218__1 any; var t_ any = t.F_s__716000218; t.F_s__716000218 = nil; s__716000218__1 = t_; for { var temp__1927000414__auto____2 any; var root_1921 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_1922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1921, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1923 lang.IFn; if linked_1922 == nil { ifn_1923 = lang.IFn_Cast(root_1921) } else { ifn_1923 = nil }; var arg_1924 any = s__716000218__1; if linked_1922 == nil { temp__1927000414__auto____2 = ifn_1923.Invoke_O__O(arg_1924) } else { temp__1927000414__auto____2 = linked_1922.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1921, arg_1924) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__716000218__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1925 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_1926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1925, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1927 lang.IFn; if linked_1926 == nil { ifn_1927 = lang.IFn_Cast(root_1925) } else { ifn_1927 = nil }; var arg_1928 any = s__716000218__3; if linked_1926 == nil { tmp1 = ifn_1927.Invoke_O__O(arg_1928) } else { tmp1 = linked_1926.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1925, arg_1928) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1929 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_1930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1929, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1931 lang.IFn; if linked_1930 == nil { ifn_1931 = lang.IFn_Cast(root_1929) } else { ifn_1931 = nil }; var arg_1932 any = s__716000218__3; if linked_1930 == nil { c__1927001037__auto____4 = ifn_1931.Invoke_O__O(arg_1932) } else { c__1927001037__auto____4 = linked_1930.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1929, arg_1932) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__716000220__6 any; var root_1933 any = A_arbace_repr_clojure_A_const_60.GetRawRoot__O(); var linked_1934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1933, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1935 lang.IFn; if linked_1934 == nil { ifn_1935 = lang.IFn_Cast(root_1933) } else { ifn_1935 = nil }; var arg_1936 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1934 == nil { b__716000220__6 = ifn_1935.Invoke_O__O(arg_1936) } else { b__716000220__6 = linked_1934.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1933, arg_1936) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1943 any = A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_fn__716000223_A_New_O_O_I_O(b__716000220__6, t.F_a, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1942 *jrt.Class = A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_fn__716000223_A_fn_class; if fncls__1942 == nil { var fncls__1942d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_85, false, fnbody__1943); A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_fn__716000223_A_fn_class = fncls__1942d; tmp3 = fncls__1942d } else { tmp3 = fncls__1942 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1943, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1944 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_1945 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1944, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1946 lang.IFn; if linked_1945 == nil { ifn_1946 = lang.IFn_Cast(root_1944) } else { ifn_1946 = nil }; var arg_1947 any; var root_1949 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_1950 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1949, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1951 lang.IFn; if linked_1950 == nil { ifn_1951 = lang.IFn_Cast(root_1949) } else { ifn_1951 = nil }; var arg_1952 any = b__716000220__6; if linked_1950 == nil { arg_1947 = ifn_1951.Invoke_O__O(arg_1952) } else { arg_1947 = linked_1950.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1949, arg_1952) }; var arg_1948 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__716000217); var tmp5 any; var root_1953 any = A_arbace_repr_clojure_A_const_65.GetRawRoot__O(); var linked_1954 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1953, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1955 lang.IFn; if linked_1954 == nil { ifn_1955 = lang.IFn_Cast(root_1953) } else { ifn_1955 = nil }; var arg_1956 any = s__716000218__3; if linked_1954 == nil { tmp5 = ifn_1955.Invoke_O__O(arg_1956) } else { tmp5 = linked_1954.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1953, arg_1956) }; arg_1948 = tmp4.Invoke_O__O(tmp5); if linked_1945 == nil { return ifn_1946.Invoke_O_O__O(arg_1947, arg_1948) } else { return linked_1945.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1944, arg_1947, arg_1948) } } else { var root_1957 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_1958 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1957, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1959 lang.IFn; if linked_1958 == nil { ifn_1959 = lang.IFn_Cast(root_1957) } else { ifn_1959 = nil }; var arg_1960 any; var root_1962 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_1963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1962, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1964 lang.IFn; if linked_1963 == nil { ifn_1964 = lang.IFn_Cast(root_1962) } else { ifn_1964 = nil }; var arg_1965 any = b__716000220__6; if linked_1963 == nil { arg_1960 = ifn_1964.Invoke_O__O(arg_1965) } else { arg_1960 = linked_1963.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1962, arg_1965) }; var arg_1961 any; if linked_1958 == nil { return ifn_1959.Invoke_O_O__O(arg_1960, arg_1961) } else { return linked_1958.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1957, arg_1960, arg_1961) } } } else { var vec__716000228__4 any; var root_1966 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_1967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1966, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1968 lang.IFn; if linked_1967 == nil { ifn_1968 = lang.IFn_Cast(root_1966) } else { ifn_1968 = nil }; var arg_1969 any = s__716000218__3; if linked_1967 == nil { vec__716000228__4 = ifn_1968.Invoke_O__O(arg_1969) } else { vec__716000228__4 = linked_1967.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1966, arg_1969) }; var out__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000228__4, lang.RT_IntCast_J__I_NoInit(0), nil); var m__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000228__4, lang.RT_IntCast_J__I_NoInit(1), nil); var rel__7 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_112.Invoke_O__O(t.F_a)).Invoke_O__O(out__5); var root_1970 any = A_arbace_repr_clojure_A_const_66.GetRawRoot__O(); var linked_1971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1970, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1972 lang.IFn; if linked_1971 == nil { ifn_1972 = lang.IFn_Cast(root_1970) } else { ifn_1972 = nil }; var arg_1973 any = lang.Tuple_Create_O_O__IPersistentVector(rel__7, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_128, A_arbace_repr_clojure_A_const_114, A_arbace_repr_clojure_A_const_131, m__6))); var arg_1974 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__716000217); var tmp7 any; var root_1975 any = A_arbace_repr_clojure_A_const_67.GetRawRoot__O(); var linked_1976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1975, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1977 lang.IFn; if linked_1976 == nil { ifn_1977 = lang.IFn_Cast(root_1975) } else { ifn_1977 = nil }; var arg_1978 any = s__716000218__3; if linked_1976 == nil { tmp7 = ifn_1977.Invoke_O__O(arg_1978) } else { tmp7 = linked_1976.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1975, arg_1978) }; arg_1974 = tmp6.Invoke_O__O(tmp7); if linked_1971 == nil { return ifn_1972.Invoke_O_O__O(arg_1973, arg_1974) } else { return linked_1971.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1970, arg_1973, arg_1974) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :314:1
func A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_fn__716000223_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_fn__716000223_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_fn__716000223_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :314:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_fn__716000223_A) Ctor_O_O_I_O(c__b__716000220, c__a any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__716000220 = c__b__716000220; t.F_a = c__a; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :314:1
func (t *A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_fn__716000223_A) Invoke_O__O(self any) any { { var i__716000219__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__716000219__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__716000224__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__716000219__1)); var out__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000224__2, lang.RT_IntCast_J__I_NoInit(0), nil); var m__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000224__2, lang.RT_IntCast_J__I_NoInit(1), nil); var rel__5 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_112.Invoke_O__O(t.F_a)).Invoke_O__O(out__3); var root_1937 any = A_arbace_repr_clojure_A_const_61.GetRawRoot__O(); var linked_1938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1937, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1939 lang.IFn; if linked_1938 == nil { ifn_1939 = lang.IFn_Cast(root_1937) } else { ifn_1939 = nil }; var arg_1940 any = t.F_b__716000220; var arg_1941 any = lang.Tuple_Create_O_O__IPersistentVector(rel__5, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_128, A_arbace_repr_clojure_A_const_114, A_arbace_repr_clojure_A_const_131, m__4))); if linked_1938 == nil { ifn_1939.Invoke_O_O__O(arg_1940, arg_1941) } else { linked_1938.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1937, arg_1940, arg_1941) }; i__716000219__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__716000219__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_repr_clojure_parse_args_A_New() *A_arbace_repr_clojure_parse_args_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_parse_args_A{}; t.Ctor(); return t }
//line :317:1
func (t *A_arbace_repr_clojure_parse_args_A) Ctor() {}
//line :317:1
func (t *A_arbace_repr_clojure_parse_args_A) Invoke_O_O__O(self, args__0 any) any { { var G__716000237__2_ any = args__0; var vec__716000238__3 any = G__716000237__2_; var seq__716000239__4 any; var root_1983 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_1984 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1983, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1985 lang.IFn
											if linked_1984 == nil { ifn_1985 = lang.IFn_Cast(root_1983) } else { ifn_1985 = nil }; var arg_1986 any = vec__716000238__3; if linked_1984 == nil { seq__716000239__4 = ifn_1985.Invoke_O__O(arg_1986) } else { seq__716000239__4 = linked_1984.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1983, arg_1986) }
//line :317:1
	var first__716000240__5 any; var root_1987 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_1988 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1987, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1989 lang.IFn
	if linked_1988 == nil { ifn_1989 = lang.IFn_Cast(root_1987) } else { ifn_1989 = nil }; var arg_1990 any = seq__716000239__4; if linked_1988 == nil { first__716000240__5 = ifn_1989.Invoke_O__O(arg_1990) } else { first__716000240__5 = linked_1988.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1987, arg_1990) }
//line :317:1
	var seq__716000239__6 any; var root_1991 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_1992 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1991, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1993 lang.IFn
	if linked_1992 == nil { ifn_1993 = lang.IFn_Cast(root_1991) } else { ifn_1993 = nil }; var arg_1994 any = seq__716000239__4; if linked_1992 == nil { seq__716000239__6 = ifn_1993.Invoke_O__O(arg_1994) } else { seq__716000239__6 = linked_1992.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1991, arg_1994) }
//line :317:1
	var a__7 any = first__716000240__5; var more__8 any = seq__716000239__6; var args__9 any = vec__716000238__3; var o__10 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_clojure_A_const_143, lang.PersistentVector_EMPTY.Ref(), A_arbace_repr_clojure_A_const_19, lang.PersistentVector_EMPTY.Ref(), A_arbace_repr_clojure_A_const_33, lang.PersistentHashSet_EMPTY.Ref(), A_arbace_repr_clojure_A_const_24, A_arbace_repr_clojure_A_const_26)); var G__716000237__11_ any = G__716000237__2_; var o__12 any = o__10; _ = a__7; _ = more__8; _ = args__9; L1: for { var vec__716000241__13 any = G__716000237__11_; var seq__716000242__14 any; var root_1995 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_1996 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1995, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1997 lang.IFn
		if linked_1996 == nil { ifn_1997 = lang.IFn_Cast(root_1995) } else { ifn_1997 = nil }; var arg_1998 any = vec__716000241__13; if linked_1996 == nil { seq__716000242__14 = ifn_1997.Invoke_O__O(arg_1998) } else { seq__716000242__14 = linked_1996.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1995, arg_1998) }
//line :317:1
		var first__716000243__15 any; var root_1999 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2000 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1999, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2001 lang.IFn
		if linked_2000 == nil { ifn_2001 = lang.IFn_Cast(root_1999) } else { ifn_2001 = nil }; var arg_2002 any = seq__716000242__14; if linked_2000 == nil { first__716000243__15 = ifn_2001.Invoke_O__O(arg_2002) } else { first__716000243__15 = linked_2000.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1999, arg_2002) }
//line :317:1
		var seq__716000242__16 any; var root_2003 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_2004 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2003, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2005 lang.IFn
		if linked_2004 == nil { ifn_2005 = lang.IFn_Cast(root_2003) } else { ifn_2005 = nil }; var arg_2006 any = seq__716000242__14; if linked_2004 == nil { seq__716000242__16 = ifn_2005.Invoke_O__O(arg_2006) } else { seq__716000242__16 = linked_2004.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2003, arg_2006) }
//line :317:1
		var a__17 any = first__716000243__15; var more__18 any = seq__716000242__16; var args__19 any = vec__716000241__13; var o__20 any = o__12; var tmp1 any; var root_2007 any = A_arbace_repr_clojure_A_const_144.GetRawRoot__O(); var linked_2008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2007, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2009 lang.IFn


		if linked_2008 == nil { ifn_2009 = lang.IFn_Cast(root_2007) } else { ifn_2009 = nil }; var arg_2010 any = args__19; if linked_2008 == nil { tmp1 = ifn_2009.Invoke_O__O(arg_2010) } else { tmp1 = linked_2008.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2007, arg_2010) }
//line :319:1
		if jrt.J2g_Truth(tmp1) { return o__20 } else { if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_30) {

			var tmp2 any; var root_2021 any = A_arbace_repr_clojure_A_const_67.GetRawRoot__O(); var linked_2022 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2021, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2023 lang.IFn; if linked_2022 == nil { ifn_2023 = lang.IFn_Cast(root_2021) } else { ifn_2023 = nil }; var arg_2024 any = more__18; if linked_2022 == nil { tmp2 = ifn_2023.Invoke_O__O(arg_2024) } else { tmp2 = linked_2022.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2021, arg_2024) }; var tmp3 any = tmp2; var tmp4 any; var root_2025 any = A_arbace_repr_clojure_A_const_40.GetRawRoot__O(); var linked_2026 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2025, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2027 lang.IFn; if linked_2026 == nil { ifn_2027 = lang.IFn_Cast(root_2025) } else { ifn_2027 = nil }; var arg_2028 any = o__20; var arg_2029 any = A_arbace_repr_clojure_A_const_28; var arg_2030 any; var root_2031 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2031, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2033 lang.IFn; if linked_2032 == nil { ifn_2033 = lang.IFn_Cast(root_2031) } else { ifn_2033 = nil }; var arg_2034 any = more__18; if linked_2032 == nil { arg_2030 = ifn_2033.Invoke_O__O(arg_2034) } else { arg_2030 = linked_2032.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2031, arg_2034) }; if linked_2026 == nil { tmp4 = ifn_2027.Invoke_O_O_O__O(arg_2028, arg_2029, arg_2030) } else { tmp4 = linked_2026.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2025, arg_2028, arg_2029, arg_2030) }; G__716000237__11_, o__12 = tmp3, tmp4; continue L1 } else {
//line :319:1
				if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_31) {


					var tmp5 any; var root_2035 any = A_arbace_repr_clojure_A_const_40.GetRawRoot__O(); var linked_2036 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2035, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2037 lang.IFn; if linked_2036 == nil { ifn_2037 = lang.IFn_Cast(root_2035) } else { ifn_2037 = nil }; var arg_2038 any = o__20; var arg_2039 any = A_arbace_repr_clojure_A_const_147; var arg_2040 any = jrt.Boolean_TRUE.Ref(); if linked_2036 == nil { tmp5 = ifn_2037.Invoke_O_O_O__O(arg_2038, arg_2039, arg_2040) } else { tmp5 = linked_2036.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2035, arg_2038, arg_2039, arg_2040) }; G__716000237__11_, o__12 = more__18, tmp5; continue L1 } else {
//line :319:1
						if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_32) {



							var tmp6 any; var root_2041 any = A_arbace_repr_clojure_A_const_40.GetRawRoot__O(); var linked_2042 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2041, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2043 lang.IFn; if linked_2042 == nil { ifn_2043 = lang.IFn_Cast(root_2041) } else { ifn_2043 = nil }; var arg_2044 any = o__20; var arg_2045 any = A_arbace_repr_clojure_A_const_148; var arg_2046 any = jrt.Boolean_TRUE.Ref(); if linked_2042 == nil { tmp6 = ifn_2043.Invoke_O_O_O__O(arg_2044, arg_2045, arg_2046) } else { tmp6 = linked_2042.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2041, arg_2044, arg_2045, arg_2046) }; G__716000237__11_, o__12 = more__18, tmp6; continue L1 } else {
//line :319:1
								if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_33) {




									var tmp7 any; var root_2047 any = A_arbace_repr_clojure_A_const_40.GetRawRoot__O(); var linked_2048 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2047, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2049 lang.IFn; if linked_2048 == nil { ifn_2049 = lang.IFn_Cast(root_2047) } else { ifn_2049 = nil }; var arg_2050 any = o__20; var arg_2051 any = A_arbace_repr_clojure_A_const_149; var arg_2052 any = jrt.Boolean_TRUE.Ref(); if linked_2048 == nil { tmp7 = ifn_2049.Invoke_O_O_O__O(arg_2050, arg_2051, arg_2052) } else { tmp7 = linked_2048.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2047, arg_2050, arg_2051, arg_2052) }; G__716000237__11_, o__12 = more__18, tmp7; continue L1 } else {
//line :319:1
										if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_34) {





											var tmp8 any; var root_2053 any = A_arbace_repr_clojure_A_const_40.GetRawRoot__O(); var linked_2054 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2053, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2055 lang.IFn; if linked_2054 == nil { ifn_2055 = lang.IFn_Cast(root_2053) } else { ifn_2055 = nil }; var arg_2056 any = o__20; var arg_2057 any = A_arbace_repr_clojure_A_const_18; var arg_2058 any = jrt.Boolean_TRUE.Ref(); if linked_2054 == nil { tmp8 = ifn_2055.Invoke_O_O_O__O(arg_2056, arg_2057, arg_2058) } else { tmp8 = linked_2054.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2053, arg_2056, arg_2057, arg_2058) }; G__716000237__11_, o__12 = more__18, tmp8; continue L1 } else {
//line :319:1
												if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_35) {






													var tmp9 any; var root_2059 any = A_arbace_repr_clojure_A_const_40.GetRawRoot__O(); var linked_2060 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2059, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2061 lang.IFn; if linked_2060 == nil { ifn_2061 = lang.IFn_Cast(root_2059) } else { ifn_2061 = nil }; var arg_2062 any = o__20; var arg_2063 any = A_arbace_repr_clojure_A_const_20; var arg_2064 any = jrt.Boolean_TRUE.Ref(); if linked_2060 == nil { tmp9 = ifn_2061.Invoke_O_O_O__O(arg_2062, arg_2063, arg_2064) } else { tmp9 = linked_2060.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2059, arg_2062, arg_2063, arg_2064) }; G__716000237__11_, o__12 = more__18, tmp9; continue L1 } else {
//line :319:1
														if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_36) {







															var tmp10 any; var root_2065 any = A_arbace_repr_clojure_A_const_40.GetRawRoot__O(); var linked_2066 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2065, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2067 lang.IFn; if linked_2066 == nil { ifn_2067 = lang.IFn_Cast(root_2065) } else { ifn_2067 = nil }; var arg_2068 any = o__20; var arg_2069 any = A_arbace_repr_clojure_A_const_150; var arg_2070 any = jrt.Boolean_TRUE.Ref(); if linked_2066 == nil { tmp10 = ifn_2067.Invoke_O_O_O__O(arg_2068, arg_2069, arg_2070) } else { tmp10 = linked_2066.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2065, arg_2068, arg_2069, arg_2070) }; G__716000237__11_, o__12 = more__18, tmp10; continue L1 } else {
//line :319:1
																if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_37) {








																	var tmp11 any; var root_2071 any = A_arbace_repr_clojure_A_const_40.GetRawRoot__O(); var linked_2072 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2071, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2073 lang.IFn; if linked_2072 == nil { ifn_2073 = lang.IFn_Cast(root_2071) } else { ifn_2073 = nil }; var arg_2074 any = o__20; var arg_2075 any = A_arbace_repr_clojure_A_const_151; var arg_2076 any = jrt.Boolean_TRUE.Ref(); if linked_2072 == nil { tmp11 = ifn_2073.Invoke_O_O_O__O(arg_2074, arg_2075, arg_2076) } else { tmp11 = linked_2072.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2071, arg_2074, arg_2075, arg_2076) }; G__716000237__11_, o__12 = more__18, tmp11; continue L1 } else {
//line :319:1
																		if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_38) {









																			var tmp12 any; var root_2077 any = A_arbace_repr_clojure_A_const_40.GetRawRoot__O(); var linked_2078 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2077, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2079 lang.IFn; if linked_2078 == nil { ifn_2079 = lang.IFn_Cast(root_2077) } else { ifn_2079 = nil }; var arg_2080 any = o__20; var arg_2081 any = A_arbace_repr_clojure_A_const_152; var arg_2082 any = jrt.Boolean_TRUE.Ref(); if linked_2078 == nil { tmp12 = ifn_2079.Invoke_O_O_O__O(arg_2080, arg_2081, arg_2082) } else { tmp12 = linked_2078.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2077, arg_2080, arg_2081, arg_2082) }; G__716000237__11_, o__12 = more__18, tmp12; continue L1 } else {
//line :319:1
																				if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_39) {










																					var tmp13 any; var root_2083 any = A_arbace_repr_clojure_A_const_40.GetRawRoot__O(); var linked_2084 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2083, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2085 lang.IFn; if linked_2084 == nil { ifn_2085 = lang.IFn_Cast(root_2083) } else { ifn_2085 = nil }; var arg_2086 any = o__20; var arg_2087 any = A_arbace_repr_clojure_A_const_112; var arg_2088 any = A_arbace_repr_clojure_A_const_119; if linked_2084 == nil { tmp13 = ifn_2085.Invoke_O_O_O__O(arg_2086, arg_2087, arg_2088) } else { tmp13 = linked_2084.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2083, arg_2086, arg_2087, arg_2088) }; G__716000237__11_, o__12 = more__18, tmp13; continue L1 } else {
//line :319:1
																						if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_40) {











																							var tmp14 any; var root_2089 any = A_arbace_repr_clojure_A_const_67.GetRawRoot__O(); var linked_2090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2089, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2091 lang.IFn; if linked_2090 == nil { ifn_2091 = lang.IFn_Cast(root_2089) } else { ifn_2091 = nil }; var arg_2092 any = more__18; if linked_2090 == nil { tmp14 = ifn_2091.Invoke_O__O(arg_2092) } else { tmp14 = linked_2090.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2089, arg_2092) }; var tmp15 any = tmp14; var tmp16 any; var root_2093 any = A_arbace_repr_clojure_A_const_40.GetRawRoot__O(); var linked_2094 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2093, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2095 lang.IFn; if linked_2094 == nil { ifn_2095 = lang.IFn_Cast(root_2093) } else { ifn_2095 = nil }; var arg_2096 any = o__20; var arg_2097 any = A_arbace_repr_clojure_A_const_153; var arg_2098 any; var root_2099 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2099, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2101 lang.IFn; if linked_2100 == nil { ifn_2101 = lang.IFn_Cast(root_2099) } else { ifn_2101 = nil }; var arg_2102 any = more__18; if linked_2100 == nil { arg_2098 = ifn_2101.Invoke_O__O(arg_2102) } else { arg_2098 = linked_2100.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2099, arg_2102) }; if linked_2094 == nil { tmp16 = ifn_2095.Invoke_O_O_O__O(arg_2096, arg_2097, arg_2098) } else { tmp16 = linked_2094.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2093, arg_2096, arg_2097, arg_2098) }; G__716000237__11_, o__12 = tmp15, tmp16; continue L1 } else {
//line :319:1
																								if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_41) {












																									var tmp17 any; var root_2103 any = A_arbace_repr_clojure_A_const_67.GetRawRoot__O(); var linked_2104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2103, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2105 lang.IFn; if linked_2104 == nil { ifn_2105 = lang.IFn_Cast(root_2103) } else { ifn_2105 = nil }; var arg_2106 any = more__18; if linked_2104 == nil { tmp17 = ifn_2105.Invoke_O__O(arg_2106) } else { tmp17 = linked_2104.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2103, arg_2106) }; var tmp18 any = tmp17; var tmp19 any; var root_2107 any = A_arbace_repr_clojure_A_const_40.GetRawRoot__O(); var linked_2108 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2107, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2109 lang.IFn; if linked_2108 == nil { ifn_2109 = lang.IFn_Cast(root_2107) } else { ifn_2109 = nil }; var arg_2110 any = o__20; var arg_2111 any = A_arbace_repr_clojure_A_const_154; var arg_2112 any; var root_2113 any = A_arbace_repr_clojure_A_const_30.GetRawRoot__O(); var linked_2114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2113, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_2115 lang.IFn; if linked_2114 == nil { ifn_2115 = lang.IFn_Cast(root_2113) } else { ifn_2115 = nil }; var arg_2116 any; var root_2117 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2117, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2119 lang.IFn; if linked_2118 == nil { ifn_2119 = lang.IFn_Cast(root_2117) } else { ifn_2119 = nil }; var arg_2120 any = more__18; if linked_2118 == nil { arg_2116 = ifn_2119.Invoke_O__O(arg_2120) } else { arg_2116 = linked_2118.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2117, arg_2120) }; if linked_2114 == nil { arg_2112 = ifn_2115.Invoke_O__O(arg_2116) } else { arg_2112 = linked_2114.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_2113, arg_2116) }; if linked_2108 == nil { tmp19 = ifn_2109.Invoke_O_O_O__O(arg_2110, arg_2111, arg_2112) } else { tmp19 = linked_2108.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2107, arg_2110, arg_2111, arg_2112) }; G__716000237__11_, o__12 = tmp18, tmp19; continue L1 } else {
//line :319:1
																										if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_42) {













																											var tmp20 any; var root_2121 any = A_arbace_repr_clojure_A_const_67.GetRawRoot__O(); var linked_2122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2121, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2123 lang.IFn; if linked_2122 == nil { ifn_2123 = lang.IFn_Cast(root_2121) } else { ifn_2123 = nil }; var arg_2124 any = more__18; if linked_2122 == nil { tmp20 = ifn_2123.Invoke_O__O(arg_2124) } else { tmp20 = linked_2122.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2121, arg_2124) }; var tmp21 any = tmp20; var tmp22 any; var root_2125 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var linked_2126 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2125, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_2127 lang.IFn; if linked_2126 == nil { ifn_2127 = lang.IFn_Cast(root_2125) } else { ifn_2127 = nil }; var arg_2128 any = o__20; var arg_2129 any = A_arbace_repr_clojure_A_const_19; var arg_2130 any = A_arbace_repr_clojure_A_const_10.GetRawRoot__O(); var arg_2131 any; var root_2132 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2132, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2134 lang.IFn; if linked_2133 == nil { ifn_2134 = lang.IFn_Cast(root_2132) } else { ifn_2134 = nil }; var arg_2135 any = more__18; if linked_2133 == nil { arg_2131 = ifn_2134.Invoke_O__O(arg_2135) } else { arg_2131 = linked_2133.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2132, arg_2135) }; if linked_2126 == nil { tmp22 = ifn_2127.Invoke_O_O_O_O__O(arg_2128, arg_2129, arg_2130, arg_2131) } else { tmp22 = linked_2126.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_2125, arg_2128, arg_2129, arg_2130, arg_2131) }; G__716000237__11_, o__12 = tmp21, tmp22; continue L1 } else {
//line :319:1
																												if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_43) {














																													var tmp23 any; var root_2136 any = A_arbace_repr_clojure_A_const_67.GetRawRoot__O(); var linked_2137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2136, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2138 lang.IFn; if linked_2137 == nil { ifn_2138 = lang.IFn_Cast(root_2136) } else { ifn_2138 = nil }; var arg_2139 any = more__18; if linked_2137 == nil { tmp23 = ifn_2138.Invoke_O__O(arg_2139) } else { tmp23 = linked_2137.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2136, arg_2139) }; var tmp24 any = tmp23; var tmp25 any; var root_2140 any = A_arbace_repr_clojure_A_const_40.GetRawRoot__O(); var linked_2141 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2140, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2142 lang.IFn; if linked_2141 == nil { ifn_2142 = lang.IFn_Cast(root_2140) } else { ifn_2142 = nil }; var arg_2143 any = o__20; var arg_2144 any = A_arbace_repr_clojure_A_const_24; var arg_2145 any; var root_2146 any = A_arbace_repr_clojure_A_const_30.GetRawRoot__O(); var linked_2147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2146, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_2148 lang.IFn; if linked_2147 == nil { ifn_2148 = lang.IFn_Cast(root_2146) } else { ifn_2148 = nil }; var arg_2149 any; var root_2150 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2150, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2152 lang.IFn; if linked_2151 == nil { ifn_2152 = lang.IFn_Cast(root_2150) } else { ifn_2152 = nil }; var arg_2153 any = more__18; if linked_2151 == nil { arg_2149 = ifn_2152.Invoke_O__O(arg_2153) } else { arg_2149 = linked_2151.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2150, arg_2153) }; if linked_2147 == nil { arg_2145 = ifn_2148.Invoke_O__O(arg_2149) } else { arg_2145 = linked_2147.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_2146, arg_2149) }; if linked_2141 == nil { tmp25 = ifn_2142.Invoke_O_O_O__O(arg_2143, arg_2144, arg_2145) } else { tmp25 = linked_2141.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2140, arg_2143, arg_2144, arg_2145) }; G__716000237__11_, o__12 = tmp24, tmp25; continue L1 } else {
//line :319:1
																														if lang.Util_Equiv_O_O__Z_NoInit(a__17, Lit_44) {















																															var tmp26 any; var root_2154 any = A_arbace_repr_clojure_A_const_67.GetRawRoot__O(); var linked_2155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2154, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2156 lang.IFn; if linked_2155 == nil { ifn_2156 = lang.IFn_Cast(root_2154) } else { ifn_2156 = nil }; var arg_2157 any = more__18; if linked_2155 == nil { tmp26 = ifn_2156.Invoke_O__O(arg_2157) } else { tmp26 = linked_2155.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2154, arg_2157) }; var tmp27 any = tmp26; var tmp28 any; var root_2158 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var linked_2159 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2158, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_2160 lang.IFn; if linked_2159 == nil { ifn_2160 = lang.IFn_Cast(root_2158) } else { ifn_2160 = nil }; var arg_2161 any = o__20; var arg_2162 any = A_arbace_repr_clojure_A_const_33; var arg_2163 any = A_arbace_repr_clojure_A_const_100.GetRawRoot__O(); var arg_2164 any; var root_2165 any = A_arbace_repr_clojure_A_const_155.GetRawRoot__O(); var linked_2166 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2165, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2167 lang.IFn; if linked_2166 == nil { ifn_2167 = lang.IFn_Cast(root_2165) } else { ifn_2167 = nil }; var arg_2168 any = A_arbace_repr_clojure_A_const_30.GetRawRoot__O(); var arg_2169 any; var root_2170 any = A_arbace_repr_clojure_A_const_156.GetRawRoot__O(); var linked_2171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2170, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_2172 lang.IFn; if linked_2171 == nil { ifn_2172 = lang.IFn_Cast(root_2170) } else { ifn_2172 = nil }; var arg_2173 any; var root_2175 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2175, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2177 lang.IFn; if linked_2176 == nil { ifn_2177 = lang.IFn_Cast(root_2175) } else { ifn_2177 = nil }; var arg_2178 any = more__18; if linked_2176 == nil { arg_2173 = ifn_2177.Invoke_O__O(arg_2178) } else { arg_2173 = linked_2176.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2175, arg_2178) }; var arg_2174 any = A_arbace_repr_clojure_A_const_157; if linked_2171 == nil { arg_2169 = ifn_2172.Invoke_O_O__O(arg_2173, arg_2174) } else { arg_2169 = linked_2171.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_2170, arg_2173, arg_2174) }; if linked_2166 == nil { arg_2164 = ifn_2167.Invoke_O_O__O(arg_2168, arg_2169) } else { arg_2164 = linked_2166.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2165, arg_2168, arg_2169) }; if linked_2159 == nil { tmp28 = ifn_2160.Invoke_O_O_O_O__O(arg_2161, arg_2162, arg_2163, arg_2164) } else { tmp28 = linked_2159.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_2158, arg_2161, arg_2162, arg_2163, arg_2164) }; G__716000237__11_, o__12 = tmp27, tmp28; continue L1 } else {
//line :319:1
																																var tmp29 any; var root_2011 any = A_arbace_repr_clojure_A_const_145.GetRawRoot__O(); var linked_2012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2011, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_2013 lang.IFn
















																																if linked_2012 == nil { ifn_2013 = lang.IFn_Cast(root_2011) } else { ifn_2013 = nil }; var arg_2014 any = a__17; var arg_2015 any = Lit_45; if linked_2012 == nil { tmp29 = ifn_2013.Invoke_O_O__O(arg_2014, arg_2015) } else { tmp29 = linked_2012.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_2011, arg_2014, arg_2015) }
//line :319:1
																																if jrt.J2g_Truth(tmp29) { var tmp30 any; var root_2016 any = A_arbace_repr_clojure_A_const_146.GetRawRoot__O(); var linked_2017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2016, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2018 lang.IFn
















																																	if linked_2017 == nil { ifn_2018 = lang.IFn_Cast(root_2016) } else { ifn_2018 = nil }; var arg_2019 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_46, nil), jrt.RefArrayOf(jrt.Object_class, nil, a__17)).Ref(); var arg_2020 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_2017 == nil { tmp30 = ifn_2018.Invoke_O_O__O(arg_2019, arg_2020) } else { tmp30 = linked_2017.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_2016, arg_2019, arg_2020) }
//line :319:1
																																	panic(jrt.Thrown(jrt.Throwable_Cast(tmp30))) } else { if A_arbace_repr_clojure_A_const_34 != nil {

















																																		var tmp31 any; var root_2179 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var linked_2180 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2179, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_2181 lang.IFn; if linked_2180 == nil { ifn_2181 = lang.IFn_Cast(root_2179) } else { ifn_2181 = nil }; var arg_2182 any = o__20; var arg_2183 any = A_arbace_repr_clojure_A_const_143; var arg_2184 any = A_arbace_repr_clojure_A_const_10.GetRawRoot__O(); var arg_2185 any = a__17; if linked_2180 == nil { tmp31 = ifn_2181.Invoke_O_O_O_O__O(arg_2182, arg_2183, arg_2184, arg_2185) } else { tmp31 = linked_2180.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_2179, arg_2182, arg_2183, arg_2184, arg_2185) }; G__716000237__11_, o__12 = more__18, tmp31; continue L1 } else {
//line :319:1
																																			return nil } } } } } } } } } } } } } } } } } } } }; /*line :317:1*/panic("j2g: unreachable") }





















func A_arbace_repr_clojure_print_rules_A_New() *A_arbace_repr_clojure_print_rules_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_print_rules_A{}; t.Ctor(); return t }
//line :339:1
func (t *A_arbace_repr_clojure_print_rules_A) Ctor() {}
//line :339:1
func (t *A_arbace_repr_clojure_print_rules_A) Invoke_O__O(self any) any {
	lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()).Invoke_O__O(Lit_62)
//line :339:1
	{ var seq_716000245__1 any; var root_2210 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2210, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2212 lang.IFn

		if linked_2211 == nil { ifn_2212 = lang.IFn_Cast(root_2210) } else { ifn_2212 = nil }; var arg_2213 any = A_arbace_repr_clojure_A_const_159.GetRawRoot__O(); if linked_2211 == nil { seq_716000245__1 = ifn_2212.Invoke_O__O(arg_2213) } else { seq_716000245__1 = linked_2211.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2210, arg_2213) }
//line :339:1
		var chunk_716000246__2 any; var count_716000247__3 int64 = 0; var i_716000248__4 int64 = 0; L1: for {

			if lang.Numbers_Lt_J_J__Z_NoInit(i_716000248__4, count_716000247__3) { var r__5 any = lang.Indexed_Cast(chunk_716000246__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_716000248__4)); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_63, nil, Lit_64, nil, Lit_65, nil); var tmp3 any; var root_2248 any = A_arbace_repr_clojure_A_const_163.GetRawRoot__O(); var linked_2249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2248, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2250 lang.IFn
				if linked_2249 == nil { ifn_2250 = lang.IFn_Cast(root_2248) } else { ifn_2250 = nil }; var arg_2251 any = A_arbace_repr_clojure_A_const_164.Invoke_O__O(r__5); if linked_2249 == nil { tmp3 = ifn_2250.Invoke_O__O(arg_2251) } else { tmp3 = linked_2249.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2248, arg_2251) }; var tmp4 any = tmp3; var tmp5 any; var root_2252 any = A_arbace_repr_clojure_A_const_163.GetRawRoot__O(); var linked_2253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2252, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2254 lang.IFn; if linked_2253 == nil { ifn_2254 = lang.IFn_Cast(root_2252) } else { ifn_2254 = nil }; var arg_2255 any = A_arbace_repr_clojure_A_const_165.Invoke_O__O(r__5); if linked_2253 == nil { tmp5 = ifn_2254.Invoke_O__O(arg_2255) } else { tmp5 = linked_2253.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2252, arg_2255) }; var tmp6 any = tmp5; var tmp7 any; var root_2256 any = A_arbace_repr_clojure_A_const_160.GetRawRoot__O(); var linked_2257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2256, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2258 lang.IFn; if linked_2257 == nil { ifn_2258 = lang.IFn_Cast(root_2256) } else { ifn_2258 = nil }; var arg_2259 any = A_arbace_repr_clojure_A_const_166.Invoke_O__O(r__5); var arg_2260 any = A_arbace_repr_clojure_A_const_167; var arg_2261 any = Lit_66; if linked_2257 == nil { tmp7 = ifn_2258.Invoke_O_O_O__O(arg_2259, arg_2260, arg_2261) } else { tmp7 = linked_2257.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2256, arg_2259, arg_2260, arg_2261) }; tmp1.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp4, nil, tmp6, nil, tmp7)).Ref())
				var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_67, nil); var tmp10 any; var root_2238 any = A_arbace_repr_clojure_A_const_160.GetRawRoot__O(); var linked_2239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2238, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2240 lang.IFn; if linked_2239 == nil { ifn_2240 = lang.IFn_Cast(root_2238) } else { ifn_2240 = nil }; var arg_2241 any = A_arbace_repr_clojure_A_const_161.Invoke_O__O(r__5); var arg_2242 any = A_arbace_repr_clojure_A_const_162; var arg_2243 any = Lit_66; if linked_2239 == nil { tmp10 = ifn_2240.Invoke_O_O_O__O(arg_2241, arg_2242, arg_2243) } else { tmp10 = linked_2239.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2238, arg_2241, arg_2242, arg_2243) }; tmp8.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp10)).Ref())
//line :341:1
				seq_716000245__1, chunk_716000246__2, count_716000247__3, i_716000248__4 = seq_716000245__1, chunk_716000246__2, count_716000247__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_716000248__4); continue L1 } else { var temp__1927000414__auto____5 any; var root_2214 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2214, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2216 lang.IFn; if linked_2215 == nil { ifn_2216 = lang.IFn_Cast(root_2214) } else { ifn_2216 = nil }; var arg_2217 any = seq_716000245__1; if linked_2215 == nil { temp__1927000414__auto____5 = ifn_2216.Invoke_O__O(arg_2217) } else { temp__1927000414__auto____5 = linked_2215.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2214, arg_2217) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_716000245__6 any = temp__1927000414__auto____5; var tmp11 any; var root_2218 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_2219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2218, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2220 lang.IFn; if linked_2219 == nil { ifn_2220 = lang.IFn_Cast(root_2218) } else { ifn_2220 = nil }; var arg_2221 any = seq_716000245__6; if linked_2219 == nil { tmp11 = ifn_2220.Invoke_O__O(arg_2221) } else { tmp11 = linked_2219.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2218, arg_2221) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____7 any; var root_2222 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_2223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2222, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2224 lang.IFn; if linked_2223 == nil { ifn_2224 = lang.IFn_Cast(root_2222) } else { ifn_2224 = nil }; var arg_2225 any = seq_716000245__6; if linked_2223 == nil { c__1927000678__auto____7 = ifn_2224.Invoke_O__O(arg_2225) } else { c__1927000678__auto____7 = linked_2223.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2222, arg_2225) }; var tmp12 any; var root_2262 any = A_arbace_repr_clojure_A_const_65.GetRawRoot__O(); var linked_2263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2262, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2264 lang.IFn; if linked_2263 == nil { ifn_2264 = lang.IFn_Cast(root_2262) } else { ifn_2264 = nil }; var arg_2265 any = seq_716000245__6; if linked_2263 == nil { tmp12 = ifn_2264.Invoke_O__O(arg_2265) } else { tmp12 = linked_2263.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2262, arg_2265) }; seq_716000245__1, chunk_716000246__2, count_716000247__3, i_716000248__4 = tmp12, c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var r__7 any; var root_2226 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2226, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2228 lang.IFn; if linked_2227 == nil { ifn_2228 = lang.IFn_Cast(root_2226) } else { ifn_2228 = nil }; var arg_2229 any = seq_716000245__6; if linked_2227 == nil { r__7 = ifn_2228.Invoke_O__O(arg_2229) } else { r__7 = linked_2227.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2226, arg_2229) }
					var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp14 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_63, nil, Lit_64, nil, Lit_65, nil); var tmp15 any; var root_2280 any = A_arbace_repr_clojure_A_const_163.GetRawRoot__O(); var linked_2281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2280, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2282 lang.IFn; if linked_2281 == nil { ifn_2282 = lang.IFn_Cast(root_2280) } else { ifn_2282 = nil }; var arg_2283 any = A_arbace_repr_clojure_A_const_164.Invoke_O__O(r__7); if linked_2281 == nil { tmp15 = ifn_2282.Invoke_O__O(arg_2283) } else { tmp15 = linked_2281.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2280, arg_2283) }; var tmp16 any = tmp15; var tmp17 any; var root_2284 any = A_arbace_repr_clojure_A_const_163.GetRawRoot__O(); var linked_2285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2284, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2286 lang.IFn; if linked_2285 == nil { ifn_2286 = lang.IFn_Cast(root_2284) } else { ifn_2286 = nil }; var arg_2287 any = A_arbace_repr_clojure_A_const_165.Invoke_O__O(r__7); if linked_2285 == nil { tmp17 = ifn_2286.Invoke_O__O(arg_2287) } else { tmp17 = linked_2285.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2284, arg_2287) }; var tmp18 any = tmp17; var tmp19 any; var root_2288 any = A_arbace_repr_clojure_A_const_160.GetRawRoot__O(); var linked_2289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2288, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2290 lang.IFn; if linked_2289 == nil { ifn_2290 = lang.IFn_Cast(root_2288) } else { ifn_2290 = nil }; var arg_2291 any = A_arbace_repr_clojure_A_const_166.Invoke_O__O(r__7); var arg_2292 any = A_arbace_repr_clojure_A_const_167; var arg_2293 any = Lit_66; if linked_2289 == nil { tmp19 = ifn_2290.Invoke_O_O_O__O(arg_2291, arg_2292, arg_2293) } else { tmp19 = linked_2289.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2288, arg_2291, arg_2292, arg_2293) }; tmp13.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp14, jrt.RefArrayOf(jrt.Object_class, nil, tmp16, nil, tmp18, nil, tmp19)).Ref())
					var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp21 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_67, nil); var tmp22 any; var root_2270 any = A_arbace_repr_clojure_A_const_160.GetRawRoot__O(); var linked_2271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2270, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2272 lang.IFn; if linked_2271 == nil { ifn_2272 = lang.IFn_Cast(root_2270) } else { ifn_2272 = nil }; var arg_2273 any = A_arbace_repr_clojure_A_const_161.Invoke_O__O(r__7); var arg_2274 any = A_arbace_repr_clojure_A_const_162; var arg_2275 any = Lit_66; if linked_2271 == nil { tmp22 = ifn_2272.Invoke_O_O_O__O(arg_2273, arg_2274, arg_2275) } else { tmp22 = linked_2271.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2270, arg_2273, arg_2274, arg_2275) }; tmp20.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp21, jrt.RefArrayOf(jrt.Object_class, nil, tmp22)).Ref())
//line :341:1
					var tmp23 any; var root_2294 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_2295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2294, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2296 lang.IFn; if linked_2295 == nil { ifn_2296 = lang.IFn_Cast(root_2294) } else { ifn_2296 = nil }; var arg_2297 any = seq_716000245__6; if linked_2295 == nil { tmp23 = ifn_2296.Invoke_O__O(arg_2297) } else { tmp23 = linked_2295.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2294, arg_2297) }; seq_716000245__1, chunk_716000246__2, count_716000247__3, i_716000248__4 = tmp23, nil, 0, 0; continue L1 } } }
//line :339:1
			break L1
		}



		lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()).Invoke_O__O(Lit_68)
//line :339:1
		var seq_716000249__1 any; var root_2186 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2186, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2188 lang.IFn





		if linked_2187 == nil { ifn_2188 = lang.IFn_Cast(root_2186) } else { ifn_2188 = nil }; var arg_2189 any = A_arbace_repr_clojure_A_const_158.GetRawRoot__O(); if linked_2187 == nil { seq_716000249__1 = ifn_2188.Invoke_O__O(arg_2189) } else { seq_716000249__1 = linked_2187.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2186, arg_2189) }
//line :339:1
		var chunk_716000250__2 any; var count_716000251__3 int64 = 0; var i_716000252__4 int64 = 0; L2: for {





			if lang.Numbers_Lt_J_J__Z_NoInit(i_716000252__4, count_716000251__3) { var d__5 any = lang.Indexed_Cast(chunk_716000250__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_716000252__4)); var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp25 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_63, nil, Lit_22, nil, nil); var tmp26 any = A_arbace_repr_clojure_A_const_168.Invoke_O__O(d__5); var tmp27 any
				var tmp28 any = A_arbace_repr_clojure_A_const_169
				if lang.Util_Equiv_O_O__Z_NoInit(tmp28, A_arbace_repr_clojure_A_const_170.Invoke_O__O(d__5)) { tmp27 = Lit_69 } else { var root_2302 any = A_arbace_repr_clojure_A_const_163.GetRawRoot__O(); var linked_2303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2302, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2304 lang.IFn; if linked_2303 == nil { ifn_2304 = lang.IFn_Cast(root_2302) } else { ifn_2304 = nil }; var arg_2305 any = A_arbace_repr_clojure_A_const_170.Invoke_O__O(d__5); if linked_2303 == nil { tmp27 = ifn_2304.Invoke_O__O(arg_2305) } else { tmp27 = linked_2303.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2302, arg_2305) } }
//line :346:1
				var tmp29 any = tmp27; var tmp30 *jrt.String

				if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_128.Invoke_O__O(d__5)) { var tmp31 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_70, nil); var tmp32 any; var root_2306 any = A_arbace_repr_clojure_A_const_160.GetRawRoot__O(); var linked_2307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2306, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2308 lang.IFn; if linked_2307 == nil { ifn_2308 = lang.IFn_Cast(root_2306) } else { ifn_2308 = nil }; var arg_2309 any = A_arbace_repr_clojure_A_const_128.Invoke_O__O(d__5); var arg_2310 any = A_arbace_repr_clojure_A_const_171; var arg_2311 any = Lit_66; if linked_2307 == nil { tmp32 = ifn_2308.Invoke_O_O_O__O(arg_2309, arg_2310, arg_2311) } else { tmp32 = linked_2307.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2306, arg_2309, arg_2310, arg_2311) }; tmp30 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp31, jrt.RefArrayOf(jrt.Object_class, nil, tmp32)) } else { tmp30 = nil }
//line :346:1
				tmp24.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp25, jrt.RefArrayOf(jrt.Object_class, nil, tmp26, nil, tmp29, tmp30.Ref())).Ref())
//line :345:1
				seq_716000249__1, chunk_716000250__2, count_716000251__3, i_716000252__4 = seq_716000249__1, chunk_716000250__2, count_716000251__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_716000252__4); continue L2 } else { var temp__1927000414__auto____5_2 any; var root_2190 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2190, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2192 lang.IFn; if linked_2191 == nil { ifn_2192 = lang.IFn_Cast(root_2190) } else { ifn_2192 = nil }; var arg_2193 any = seq_716000249__1; if linked_2191 == nil { temp__1927000414__auto____5_2 = ifn_2192.Invoke_O__O(arg_2193) } else { temp__1927000414__auto____5_2 = linked_2191.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2190, arg_2193) }; if jrt.J2g_Truth(temp__1927000414__auto____5_2) { var seq_716000249__6 any = temp__1927000414__auto____5_2; var tmp33 any; var root_2194 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_2195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2194, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2196 lang.IFn; if linked_2195 == nil { ifn_2196 = lang.IFn_Cast(root_2194) } else { ifn_2196 = nil }; var arg_2197 any = seq_716000249__6; if linked_2195 == nil { tmp33 = ifn_2196.Invoke_O__O(arg_2197) } else { tmp33 = linked_2195.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2194, arg_2197) }; if jrt.J2g_Truth(tmp33) { var c__1927000678__auto____7_2 any; var root_2198 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_2199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2198, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2200 lang.IFn; if linked_2199 == nil { ifn_2200 = lang.IFn_Cast(root_2198) } else { ifn_2200 = nil }; var arg_2201 any = seq_716000249__6; if linked_2199 == nil { c__1927000678__auto____7_2 = ifn_2200.Invoke_O__O(arg_2201) } else { c__1927000678__auto____7_2 = linked_2199.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2198, arg_2201) }; var tmp34 any; var root_2312 any = A_arbace_repr_clojure_A_const_65.GetRawRoot__O(); var linked_2313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2312, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2314 lang.IFn; if linked_2313 == nil { ifn_2314 = lang.IFn_Cast(root_2312) } else { ifn_2314 = nil }; var arg_2315 any = seq_716000249__6; if linked_2313 == nil { tmp34 = ifn_2314.Invoke_O__O(arg_2315) } else { tmp34 = linked_2313.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2312, arg_2315) }; seq_716000249__1, chunk_716000250__2, count_716000251__3, i_716000252__4 = tmp34, c__1927000678__auto____7_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var d__7 any; var root_2202 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2202, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2204 lang.IFn; if linked_2203 == nil { ifn_2204 = lang.IFn_Cast(root_2202) } else { ifn_2204 = nil }; var arg_2205 any = seq_716000249__6; if linked_2203 == nil { d__7 = ifn_2204.Invoke_O__O(arg_2205) } else { d__7 = linked_2203.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2202, arg_2205) }
					var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp36 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_63, nil, Lit_22, nil, nil); var tmp37 any = A_arbace_repr_clojure_A_const_168.Invoke_O__O(d__7); var tmp38 any; var tmp39 any = A_arbace_repr_clojure_A_const_169
					if lang.Util_Equiv_O_O__Z_NoInit(tmp39, A_arbace_repr_clojure_A_const_170.Invoke_O__O(d__7)) { tmp38 = Lit_69 } else { var root_2320 any = A_arbace_repr_clojure_A_const_163.GetRawRoot__O(); var linked_2321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2320, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2322 lang.IFn; if linked_2321 == nil { ifn_2322 = lang.IFn_Cast(root_2320) } else { ifn_2322 = nil }; var arg_2323 any = A_arbace_repr_clojure_A_const_170.Invoke_O__O(d__7); if linked_2321 == nil { tmp38 = ifn_2322.Invoke_O__O(arg_2323) } else { tmp38 = linked_2321.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2320, arg_2323) } }
//line :346:1
					var tmp40 any = tmp38; var tmp41 *jrt.String

					if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_128.Invoke_O__O(d__7)) { var tmp42 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_70, nil); var tmp43 any; var root_2324 any = A_arbace_repr_clojure_A_const_160.GetRawRoot__O(); var linked_2325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2324, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2326 lang.IFn; if linked_2325 == nil { ifn_2326 = lang.IFn_Cast(root_2324) } else { ifn_2326 = nil }; var arg_2327 any = A_arbace_repr_clojure_A_const_128.Invoke_O__O(d__7); var arg_2328 any = A_arbace_repr_clojure_A_const_171; var arg_2329 any = Lit_66; if linked_2325 == nil { tmp43 = ifn_2326.Invoke_O_O_O__O(arg_2327, arg_2328, arg_2329) } else { tmp43 = linked_2325.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2324, arg_2327, arg_2328, arg_2329) }; tmp41 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp42, jrt.RefArrayOf(jrt.Object_class, nil, tmp43)) } else { tmp41 = nil }
//line :346:1
					tmp35.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp36, jrt.RefArrayOf(jrt.Object_class, nil, tmp37, nil, tmp40, tmp41.Ref())).Ref())
//line :345:1
					var tmp44 any; var root_2330 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_2331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2330, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2332 lang.IFn; if linked_2331 == nil { ifn_2332 = lang.IFn_Cast(root_2330) } else { ifn_2332 = nil }; var arg_2333 any = seq_716000249__6; if linked_2331 == nil { tmp44 = ifn_2332.Invoke_O__O(arg_2333) } else { tmp44 = linked_2331.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2330, arg_2333) }; seq_716000249__1, chunk_716000250__2, count_716000251__3, i_716000252__4 = tmp44, nil, 0, 0; continue L2 } } else { return nil } } } }
//line :339:1
	panic("j2g: unreachable")
}









func A_arbace_repr_clojure_usage_A_New() *A_arbace_repr_clojure_usage_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_usage_A{}; t.Ctor(); return t }
//line :350:1
func (t *A_arbace_repr_clojure_usage_A) Ctor() {}
//line :350:1
func (t *A_arbace_repr_clojure_usage_A) Invoke_O__O(self any) any {
	var root_2347 any = A_arbace_repr_clojure_A_const_88.GetRawRoot__O(); var linked_2348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2347, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2349 lang.IFn; if linked_2348 == nil { ifn_2349 = lang.IFn_Cast(root_2347) } else { ifn_2349 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_89.GetRawRoot__O()); var tmp2 any = A_arbace_repr_clojure_A_const_90; var arg_2350 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_repr_clojure_A_const_91.Get__O()); if linked_2348 == nil { ifn_2349.Invoke_O__O(arg_2350) } else { linked_2348.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2347, arg_2350) }; var tmp3 *lang.Compiler_AOTFn; var fnbody__2346 any = A_arbace_repr_clojure_usage_fn__716000254_A_New(); var tmp4 *jrt.Class; var fncls__2345 *jrt.Class = A_arbace_repr_clojure_usage_fn__716000254_A_fn_class; if fncls__2345 == nil { var fncls__2345d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_127, false, nil); A_arbace_repr_clojure_usage_fn__716000254_A_fn_class = fncls__2345d; tmp4 = fncls__2345d } else { tmp4 = fncls__2345 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2346, tmp4, nil); Up_Compiler_AOTFn_IFn(tmp3).Invoke__O()
	jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2)); return nil }
//line :351:1
func A_arbace_repr_clojure_usage_fn__716000254_A_New() *A_arbace_repr_clojure_usage_fn__716000254_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_usage_fn__716000254_A{}; t.Ctor(); return t }
//line :351:1
func (t *A_arbace_repr_clojure_usage_fn__716000254_A) Ctor() {}
//line :351:1
func (t *A_arbace_repr_clojure_usage_fn__716000254_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp3 *lang.Keyword = A_arbace_repr_clojure_A_const_166; var tmp4 any; var root_2338 any = A_arbace_repr_clojure_A_const_172.GetRawRoot__O(); var linked_2339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2338, aot_arbace_core.A_arbace_core_the_ns_A_fn_class); var ifn_2340 lang.IFn; if linked_2339 == nil { ifn_2340 = lang.IFn_Cast(root_2338) } else { ifn_2340 = nil }; var arg_2341 any = A_arbace_repr_clojure_A_const_173; if linked_2339 == nil { tmp4 = ifn_2340.Invoke_O__O(arg_2341) } else { tmp4 = linked_2339.(*aot_arbace_core.A_arbace_core_the_ns_A).Invoke_O_O__O(root_2338, arg_2341) }; tmp1 = tmp2.Invoke_O__O(tmp3.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(tmp4))) }; return nil }(); var root_2342 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); var linked_2343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2342, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2344 lang.IFn; if linked_2343 == nil { ifn_2344 = lang.IFn_Cast(root_2342) } else { ifn_2344 = nil }; if linked_2343 == nil { ifn_2344.Invoke__O() } else { linked_2343.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2342) }; if tmp5 != nil { panic(tmp5) }; return tmp1 }


func A_arbace_repr_clojure_roundtrips_A_New() *A_arbace_repr_clojure_roundtrips_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrips_A{}; t.Ctor(); return t }
//line :354:1
func (t *A_arbace_repr_clojure_roundtrips_A) Ctor() {}
//line :354:1
func (t *A_arbace_repr_clojure_roundtrips_A) Invoke_O_O_O__O(self, sources__0, opts__1 any) any {



	if lang.Numbers_Lt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(sources__0)), 2) {
		var root_2356 any = A_arbace_repr_clojure_A_const_174.GetRawRoot__O(); var linked_2357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2356, A_arbace_repr_clojure_roundtrip_A_fn_class); var ifn_2358 lang.IFn; if linked_2357 == nil { ifn_2358 = lang.IFn_Cast(root_2356) } else { ifn_2358 = nil }; var arg_2359 any = sources__0; var arg_2360 any = opts__1; if linked_2357 == nil { return ifn_2358.Invoke_O_O__O(arg_2359, arg_2360) } else { return linked_2357.(*A_arbace_repr_clojure_roundtrip_A).Invoke_O_O_O__O(root_2356, arg_2359, arg_2360) } } else {
			var root_2361 any = A_arbace_repr_clojure_A_const_103.GetRawRoot__O(); var linked_2362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2361, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_2363 lang.IFn; if linked_2362 == nil { ifn_2363 = lang.IFn_Cast(root_2361) } else { ifn_2363 = nil }; var arg_2364 any; var fnbody__2460 any = A_arbace_repr_clojure_roundtrips_fn__716000257_A_New_O(opts__1); var tmp1 *jrt.Class; var fncls__2459 *jrt.Class = A_arbace_repr_clojure_roundtrips_fn__716000257_A_fn_class; if fncls__2459 == nil { var fncls__2459d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_86, false, fnbody__2460); A_arbace_repr_clojure_roundtrips_fn__716000257_A_fn_class = fncls__2459d; tmp1 = fncls__2459d } else { tmp1 = fncls__2459 }; arg_2364 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2460, tmp1, nil); var tmp2 any = A_arbace_repr_clojure_A_const_139; var tmp3 any = A_arbace_repr_clojure_A_const_13; var tmp4 any = A_arbace_repr_clojure_A_const_140; var tmp5 any = A_arbace_repr_clojure_A_const_13; var tmp6 any = A_arbace_repr_clojure_A_const_142; var arg_2365 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, tmp5, tmp6, lang.IFn_Cast(A_arbace_repr_clojure_A_const_101.GetRawRoot__O()).Invoke__O())); var arg_2366 any = sources__0; if linked_2362 == nil { return ifn_2363.Invoke_O_O_O__O(arg_2364, arg_2365, arg_2366) } else { return linked_2362.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_2361, arg_2364, arg_2365, arg_2366) } } }
//line :360:1
func A_arbace_repr_clojure_roundtrips_fn__716000257_A_New_O(p0 any) *A_arbace_repr_clojure_roundtrips_fn__716000257_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrips_fn__716000257_A{}; t.Ctor_O(p0); return t }
//line :360:1
func (t *A_arbace_repr_clojure_roundtrips_fn__716000257_A) Ctor_O(c__opts any) { t.F_opts = c__opts }
//line :360:1
func (t *A_arbace_repr_clojure_roundtrips_fn__716000257_A) Invoke_O_O_O__O(self, acc__1, src__2 any) any { var r__3 any; var root_2367 any = A_arbace_repr_clojure_A_const_174.GetRawRoot__O(); var linked_2368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2367, A_arbace_repr_clojure_roundtrip_A_fn_class); var ifn_2369 lang.IFn; if
														linked_2368 == nil { ifn_2369 = lang.IFn_Cast(root_2367) } else { ifn_2369 = nil }; var arg_2370 any = lang.Tuple_Create_O__IPersistentVector(src__2); var arg_2371 any = t.F_opts; if linked_2368 == nil { r__3 = ifn_2369.Invoke_O_O__O(arg_2370, arg_2371) } else { r__3 = linked_2368.(*A_arbace_repr_clojure_roundtrip_A).Invoke_O_O_O__O(root_2367, arg_2370, arg_2371) }; var n__4 any; var tmp1 any; var root_2372 any = /*line :360:1*/A_arbace_repr_clojure_A_const_76.GetRawRoot__O(); var linked_2373 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2372, aot_arbace_java_io.A_arbace_java_io_file_A_fn_class); var ifn_2374 lang.IFn; if
														linked_2373 == nil { ifn_2374 = lang.IFn_Cast(root_2372) } else { ifn_2374 = nil }; var arg_2375 any = src__2; if linked_2373 == nil { tmp1 = ifn_2374.Invoke_O__O(arg_2375) } else { tmp1 = linked_2373.(*aot_arbace_java_io.A_arbace_java_io_file_A).Invoke_O_O__O(root_2372, arg_2375) }; n__4 = jrt.File_Cast(tmp1).GetName__String().Ref(); var root_2376 any =

	A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var linked_2377 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2376, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_2378 lang.IFn; if linked_2377 == nil { ifn_2378 = lang.IFn_Cast(root_2376) } else { ifn_2378 = nil }; var arg_2379 any; var root_2383 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var linked_2384 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2383, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_2385 lang.IFn; if /*line :362:1*/ linked_2384 == nil { ifn_2385 = lang.IFn_Cast(root_2383) } else { ifn_2385 = nil }; var arg_2386 any; var root_2390 any = A_arbace_repr_clojure_A_const_83.GetRawRoot__O(); var linked_2391 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2390, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_2392 lang.IFn; if linked_2391 == nil { ifn_2392 = lang.IFn_Cast(root_2390) } else { ifn_2392 = nil }; var arg_2393 any = acc__1; var arg_2394 any = A_arbace_repr_clojure_A_const_139; var arg_2395 any = A_arbace_repr_clojure_A_const_175.GetRawRoot__O(); var arg_2396 any = A_arbace_repr_clojure_A_const_139.Invoke_O__O(r__3); if linked_2391 == nil { arg_2386 = ifn_2392.Invoke_O_O_O_O__O(arg_2393, arg_2394, arg_2395, arg_2396) } else { arg_2386 = linked_2391.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_2390, arg_2393, arg_2394, arg_2395, arg_2396) }; var arg_2387 any = A_arbace_repr_clojure_A_const_140; var arg_2388 any = A_arbace_repr_clojure_A_const_175.GetRawRoot__O(); var arg_2389 any = A_arbace_repr_clojure_A_const_140.Invoke_O__O(r__3); if linked_2384 == nil { arg_2379 = ifn_2385.Invoke_O_O_O_O__O(arg_2386, arg_2387, arg_2388, arg_2389) } else { arg_2379 = linked_2384.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_2383, arg_2386, arg_2387, arg_2388, arg_2389) }; var arg_2380 any = A_arbace_repr_clojure_A_const_142; var arg_2381 any =
	A_arbace_repr_clojure_A_const_100.GetRawRoot__O(); var arg_2382 any; var iter__1927001039__auto____5 any; var fnbody__2458 any = A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_A_New_O(n__4); var tmp2 *jrt.Class; var fncls__2457 *jrt.Class = A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_A_fn_class; if fncls__2457 == nil { var fncls__2457d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_87, false, fnbody__2458); A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_A_fn_class = fncls__2457d; tmp2 = fncls__2457d } else { tmp2 = fncls__2457 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2458, tmp2, nil); arg_2382 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(A_arbace_repr_clojure_A_const_142.Invoke_O__O(r__3)); if linked_2377 == nil { return ifn_2378.Invoke_O_O_O_O__O(arg_2379, arg_2380, arg_2381, arg_2382) } else { return linked_2377.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_2376, arg_2379, arg_2380, arg_2381, arg_2382) } }
//line :363:1
func A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_A_New_O(p0 any) *A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_A{}; t.Ctor_O(p0); return t }
//line :363:1
func (t *A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :363:1
func (t *A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_A) Invoke_O_O__O(self, s__716000259__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2456 any = A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_A_New_O_O_O(self, t.F_n, s__716000259__1); var tmp2 *jrt.Class; var fncls__2455 *jrt.Class = A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_A_fn_class; if fncls__2455 == nil { var fncls__2455d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_88, false, fnbody__2456); A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_A_fn_class = fncls__2455d; tmp2 = fncls__2455d } else { tmp2 = fncls__2455 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2456, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :363:1
func A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :363:1
func (t *A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_A) Ctor_O_O_O(c__iter__716000258, c__n, c__s__716000259 any) { t.F_iter__716000258 = c__iter__716000258; t.F_n = c__n; t.F_s__716000259 = c__s__716000259 }
//line :363:1
func (t *A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_A) Invoke_O__O(self any) any { { var s__716000259__1 any; var t_ any = t.F_s__716000259; t.F_s__716000259 = nil; s__716000259__1 = t_; for { var temp__1927000414__auto____2 any; var root_2397 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2397, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2399 lang.IFn; if linked_2398 == nil { ifn_2399 = lang.IFn_Cast(root_2397) } else { ifn_2399 = nil }; var arg_2400 any = s__716000259__1; if linked_2398 == nil { temp__1927000414__auto____2 = ifn_2399.Invoke_O__O(arg_2400) } else { temp__1927000414__auto____2 = linked_2398.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2397, arg_2400) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__716000259__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2401 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_2402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2401, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2403 lang.IFn; if linked_2402 == nil { ifn_2403 = lang.IFn_Cast(root_2401) } else { ifn_2403 = nil }; var arg_2404 any = s__716000259__3; if linked_2402 == nil { tmp1 = ifn_2403.Invoke_O__O(arg_2404) } else { tmp1 = linked_2402.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2401, arg_2404) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2405 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_2406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2405, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2407 lang.IFn; if linked_2406 == nil { ifn_2407 = lang.IFn_Cast(root_2405) } else { ifn_2407 = nil }; var arg_2408 any = s__716000259__3; if linked_2406 == nil { c__1927001037__auto____4 = ifn_2407.Invoke_O__O(arg_2408) } else { c__1927001037__auto____4 = linked_2406.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2405, arg_2408) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__716000261__6 any; var root_2409 any = A_arbace_repr_clojure_A_const_60.GetRawRoot__O(); var linked_2410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2409, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2411 lang.IFn; if linked_2410 == nil { ifn_2411 = lang.IFn_Cast(root_2409) } else { ifn_2411 = nil }; var arg_2412 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2410 == nil { b__716000261__6 = ifn_2411.Invoke_O__O(arg_2412) } else { b__716000261__6 = linked_2410.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2409, arg_2412) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2419 any = A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_fn__716000264_A_New_O_O_I_O(t.F_n, b__716000261__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2418 *jrt.Class = A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_fn__716000264_A_fn_class; if fncls__2418 == nil { var fncls__2418d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_89, false, fnbody__2419); A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_fn__716000264_A_fn_class = fncls__2418d; tmp3 = fncls__2418d } else { tmp3 = fncls__2418 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2419, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2420 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_2421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2420, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2422 lang.IFn; if linked_2421 == nil { ifn_2422 = lang.IFn_Cast(root_2420) } else { ifn_2422 = nil }; var arg_2423 any; var root_2425 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_2426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2425, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2427 lang.IFn; if linked_2426 == nil { ifn_2427 = lang.IFn_Cast(root_2425) } else { ifn_2427 = nil }; var arg_2428 any = b__716000261__6; if linked_2426 == nil { arg_2423 = ifn_2427.Invoke_O__O(arg_2428) } else { arg_2423 = linked_2426.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2425, arg_2428) }; var arg_2424 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__716000258); var tmp5 any; var root_2429 any = A_arbace_repr_clojure_A_const_65.GetRawRoot__O(); var linked_2430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2429, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2431 lang.IFn; if linked_2430 == nil { ifn_2431 = lang.IFn_Cast(root_2429) } else { ifn_2431 = nil }; var arg_2432 any = s__716000259__3; if linked_2430 == nil { tmp5 = ifn_2431.Invoke_O__O(arg_2432) } else { tmp5 = linked_2430.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2429, arg_2432) }; arg_2424 = tmp4.Invoke_O__O(tmp5); if linked_2421 == nil { return ifn_2422.Invoke_O_O__O(arg_2423, arg_2424) } else { return linked_2421.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2420, arg_2423, arg_2424) } } else { var root_2433 any = A_arbace_repr_clojure_A_const_63.GetRawRoot__O(); var linked_2434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2433, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2435 lang.IFn; if linked_2434 == nil { ifn_2435 = lang.IFn_Cast(root_2433) } else { ifn_2435 = nil }; var arg_2436 any; var root_2438 any = A_arbace_repr_clojure_A_const_64.GetRawRoot__O(); var linked_2439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2438, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2440 lang.IFn; if linked_2439 == nil { ifn_2440 = lang.IFn_Cast(root_2438) } else { ifn_2440 = nil }; var arg_2441 any = b__716000261__6; if linked_2439 == nil { arg_2436 = ifn_2440.Invoke_O__O(arg_2441) } else { arg_2436 = linked_2439.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2438, arg_2441) }; var arg_2437 any; if linked_2434 == nil { return ifn_2435.Invoke_O_O__O(arg_2436, arg_2437) } else { return linked_2434.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2433, arg_2436, arg_2437) } } } else { var vec__716000269__4 any; var root_2442 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2442, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2444 lang.IFn; if linked_2443 == nil { ifn_2444 = lang.IFn_Cast(root_2442) } else { ifn_2444 = nil }; var arg_2445 any = s__716000259__3; if linked_2443 == nil { vec__716000269__4 = ifn_2444.Invoke_O__O(arg_2445) } else { vec__716000269__4 = linked_2443.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2442, arg_2445) }; var rel__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000269__4, lang.RT_IntCast_J__I_NoInit(0), nil); var d__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000269__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2446 any = A_arbace_repr_clojure_A_const_66.GetRawRoot__O(); var linked_2447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2446, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2448 lang.IFn; if linked_2447 == nil { ifn_2448 = lang.IFn_Cast(root_2446) } else { ifn_2448 = nil }; var arg_2449 any = lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_29, nil), jrt.RefArrayOf(jrt.Object_class, t.F_n, nil, rel__5)).Ref(), d__6); var arg_2450 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__716000258); var tmp7 any; var root_2451 any = A_arbace_repr_clojure_A_const_67.GetRawRoot__O(); var linked_2452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2451, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2453 lang.IFn; if linked_2452 == nil { ifn_2453 = lang.IFn_Cast(root_2451) } else { ifn_2453 = nil }; var arg_2454 any = s__716000259__3; if linked_2452 == nil { tmp7 = ifn_2453.Invoke_O__O(arg_2454) } else { tmp7 = linked_2452.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2451, arg_2454) }; arg_2450 = tmp6.Invoke_O__O(tmp7); if linked_2447 == nil { return ifn_2448.Invoke_O_O__O(arg_2449, arg_2450) } else { return linked_2447.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2446, arg_2449, arg_2450) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :363:1
func A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_fn__716000264_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_fn__716000264_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_fn__716000264_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :363:1
func (t *A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_fn__716000264_A) Ctor_O_O_I_O(c__n, c__b__716000261 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__716000261 = c__b__716000261; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :363:1
func (t *A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_fn__716000264_A) Invoke_O__O(self any) any { { var i__716000260__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__716000260__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__716000265__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__716000260__1)); var rel__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000265__2, lang.RT_IntCast_J__I_NoInit(0), nil); var d__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000265__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2413 any = A_arbace_repr_clojure_A_const_61.GetRawRoot__O(); var linked_2414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2413, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2415 lang.IFn; if linked_2414 == nil { ifn_2415 = lang.IFn_Cast(root_2413) } else { ifn_2415 = nil }; var arg_2416 any = t.F_b__716000261; var arg_2417 any = lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_29, nil), jrt.RefArrayOf(jrt.Object_class, t.F_n, nil, rel__3)).Ref(), d__4); if linked_2414 == nil { ifn_2415.Invoke_O_O__O(arg_2416, arg_2417) } else { linked_2414.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2413, arg_2416, arg_2417) }; i__716000260__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__716000260__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_repr_clojure_run_roundtrip_A_New() *A_arbace_repr_clojure_run_roundtrip_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_roundtrip_A{}; t.Ctor(); return t }
//line :366:1
func (t *A_arbace_repr_clojure_run_roundtrip_A) Ctor() {}
//line :366:1
func (t *A_arbace_repr_clojure_run_roundtrip_A) Invoke_O_O__O(self, o__0 any) any { var r__2 any; var root_2464 any = A_arbace_repr_clojure_A_const_176.GetRawRoot__O(); var linked_2465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2464, A_arbace_repr_clojure_roundtrips_A_fn_class); var ifn_2466 lang.IFn; if




	linked_2465 == nil { ifn_2466 = lang.IFn_Cast(root_2464) } else { ifn_2466 = nil }; var arg_2467 any = A_arbace_repr_clojure_A_const_143.Invoke_O__O(o__0); var arg_2468 any = o__0; if linked_2465 == nil { r__2 = ifn_2466.Invoke_O_O__O(arg_2467, arg_2468) } else { r__2 = linked_2465.(*A_arbace_repr_clojure_roundtrips_A).Invoke_O_O_O__O(root_2464, arg_2467, arg_2468) }; var known__3 any; if
	jrt.J2g_Truth(A_arbace_repr_clojure_A_const_153.Invoke_O__O(o__0)) { var tmp1 any; var root_2469 any = A_arbace_repr_clojure_A_const_177.GetRawRoot__O(); var linked_2470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2469, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_2471 lang.IFn; if linked_2470 == nil { ifn_2471 = lang.IFn_Cast(root_2469) } else { ifn_2471 = nil }; var arg_2472 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_78.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_A_const_153.Invoke_O__O(o__0)); if linked_2470 == nil { tmp1 = ifn_2471.Invoke_O__O(arg_2472) } else { tmp1 = linked_2470.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_2469, arg_2472) }; known__3 = lang.RT_Get_O_O_O__O_NoInit(tmp1, A_arbace_repr_clojure_A_const_154.Invoke_O__O(o__0), lang.PersistentArrayMap_EMPTY.Ref()) } else { known__3 = lang.PersistentArrayMap_EMPTY.Ref() }; var outside__4 any; var root_2477 any = /*line :366:1*/A_arbace_repr_clojure_A_const_100.GetRawRoot__O(); var linked_2478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2477, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2479 lang.IFn; if






	linked_2478 == nil { ifn_2479 = lang.IFn_Cast(root_2477) } else { ifn_2479 = nil }; var arg_2480 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_101.GetRawRoot__O()).Invoke__O(); var arg_2481 any; var root_2485 any = A_arbace_repr_clojure_A_const_116.GetRawRoot__O(); var linked_2486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2485, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_2487 lang.IFn; if linked_2486 == nil { ifn_2487 = lang.IFn_Cast(root_2485) } else { ifn_2487 = nil }; var arg_2488 any; var fnbody__2495 any = A_arbace_repr_clojure_run_roundtrip_fn__716000280_A_New(); var tmp2 *jrt.Class; var fncls__2494 *jrt.Class = A_arbace_repr_clojure_run_roundtrip_fn__716000280_A_fn_class; if fncls__2494 == nil { var fncls__2494d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_105, false, nil); A_arbace_repr_clojure_run_roundtrip_fn__716000280_A_fn_class = fncls__2494d; tmp2 = fncls__2494d } else { tmp2 = fncls__2494 }; arg_2488 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2495, tmp2, nil); var arg_2489 any = A_arbace_repr_clojure_A_const_142.Invoke_O__O(r__2); if linked_2486 == nil { arg_2481 = ifn_2487.Invoke_O_O__O(arg_2488, arg_2489) } else { arg_2481 = linked_2486.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_2485, arg_2488, arg_2489) }; if linked_2478 == nil { outside__4 = ifn_2479.Invoke_O_O__O(arg_2480, arg_2481) } else { outside__4 = linked_2478.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2477, arg_2480, arg_2481) }; var one_way__5 any; var root_2496 any = /*line :366:1*/A_arbace_repr_clojure_A_const_100.GetRawRoot__O(); var linked_2497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2496, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2498 lang.IFn; if







	linked_2497 == nil { ifn_2498 = lang.IFn_Cast(root_2496) } else { ifn_2498 = nil }; var arg_2499 any = lang.IFn_Cast(A_arbace_repr_clojure_A_const_101.GetRawRoot__O()).Invoke__O(); var arg_2500 any; var root_2504 any = A_arbace_repr_clojure_A_const_116.GetRawRoot__O(); var linked_2505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2504, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_2506 lang.IFn; if linked_2505 == nil { ifn_2506 = lang.IFn_Cast(root_2504) } else { ifn_2506 = nil }; var arg_2507 any; var fnbody__2514 any = A_arbace_repr_clojure_run_roundtrip_fn__716000282_A_New(); var tmp3 *jrt.Class; var fncls__2513 *jrt.Class = A_arbace_repr_clojure_run_roundtrip_fn__716000282_A_fn_class; if fncls__2513 == nil { var fncls__2513d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_106, false, nil); A_arbace_repr_clojure_run_roundtrip_fn__716000282_A_fn_class = fncls__2513d; tmp3 = fncls__2513d } else { tmp3 = fncls__2513 }; arg_2507 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2514, tmp3, nil); var arg_2508 any = A_arbace_repr_clojure_A_const_142.Invoke_O__O(r__2); if linked_2505 == nil { arg_2500 = ifn_2506.Invoke_O_O__O(arg_2507, arg_2508) } else { arg_2500 = linked_2505.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_2504, arg_2507, arg_2508) }; if linked_2497 == nil { one_way__5 = ifn_2498.Invoke_O_O__O(arg_2499, arg_2500) } else { one_way__5 = linked_2497.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2496, arg_2499, arg_2500) }; var diff__6 any; var root_2515 any = /*line :366:1*/A_arbace_repr_clojure_A_const_180.GetRawRoot__O(); var linked_2516 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2515, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2517 lang.IFn; if








	linked_2516 == nil { ifn_2517 = lang.IFn_Cast(root_2515) } else { ifn_2517 = nil }; var arg_2518 any = A_arbace_repr_clojure_A_const_181.GetRawRoot__O(); var arg_2519 any = A_arbace_repr_clojure_A_const_142.Invoke_O__O(r__2); var arg_2520 any; var root_2521 any = A_arbace_repr_clojure_A_const_102.GetRawRoot__O(); var linked_2522 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2521, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2523 lang.IFn; if linked_2522 == nil { ifn_2523 = lang.IFn_Cast(root_2521) } else { ifn_2523 = nil }; var arg_2524 any; var root_2526 any = A_arbace_repr_clojure_A_const_107.GetRawRoot__O(); var linked_2527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2526, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2528 lang.IFn; if linked_2527 == nil { ifn_2528 = lang.IFn_Cast(root_2526) } else { ifn_2528 = nil }; var arg_2529 any = outside__4; if linked_2527 == nil { arg_2524 = ifn_2528.Invoke_O__O(arg_2529) } else { arg_2524 = linked_2527.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2526, arg_2529) }; var arg_2525 any; var root_2530 any = A_arbace_repr_clojure_A_const_107.GetRawRoot__O(); var linked_2531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2530, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2532 lang.IFn; if linked_2531 == nil { ifn_2532 = lang.IFn_Cast(root_2530) } else { ifn_2532 = nil }; var arg_2533 any = one_way__5; if linked_2531 == nil { arg_2525 = ifn_2532.Invoke_O__O(arg_2533) } else { arg_2525 = linked_2531.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2530, arg_2533) }; if linked_2522 == nil { arg_2520 = ifn_2523.Invoke_O_O__O(arg_2524, arg_2525) } else { arg_2520 = linked_2522.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2521, arg_2524, arg_2525) }; if linked_2516 == nil { diff__6 = ifn_2517.Invoke_O_O_O__O(arg_2518, arg_2519, arg_2520) } else { diff__6 = linked_2516.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_2515, arg_2518, arg_2519, arg_2520) }; var new__7 any; var root_2534 any = /*line :366:1*/A_arbace_repr_clojure_A_const_141.GetRawRoot__O(); var linked_2535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2534, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_2536 lang.IFn; if









	linked_2535 == nil { ifn_2536 = lang.IFn_Cast(root_2534) } else { ifn_2536 = nil }; var arg_2537 any; var fnbody__2545 any = A_arbace_repr_clojure_run_roundtrip_fn__716000284_A_New_O(known__3); var tmp4 *jrt.Class; var fncls__2544 *jrt.Class = A_arbace_repr_clojure_run_roundtrip_fn__716000284_A_fn_class; if fncls__2544 == nil { var fncls__2544d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_107, false, fnbody__2545); A_arbace_repr_clojure_run_roundtrip_fn__716000284_A_fn_class = fncls__2544d; tmp4 = fncls__2544d } else { tmp4 = fncls__2544 }; arg_2537 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2545, tmp4, nil); var arg_2538 any; var root_2546 any = A_arbace_repr_clojure_A_const_107.GetRawRoot__O(); var linked_2547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2546, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2548 lang.IFn; if linked_2547 == nil { ifn_2548 = lang.IFn_Cast(root_2546) } else { ifn_2548 = nil }; var arg_2549 any = diff__6; if linked_2547 == nil { arg_2538 = ifn_2548.Invoke_O__O(arg_2549) } else { arg_2538 = linked_2547.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2546, arg_2549) }; if linked_2535 == nil { new__7 = ifn_2536.Invoke_O_O__O(arg_2537, arg_2538) } else { new__7 = linked_2535.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_2534, arg_2537, arg_2538) }; var stale__8 any; var root_2550 any = /*line :366:1*/A_arbace_repr_clojure_A_const_141.GetRawRoot__O(); var linked_2551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2550, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_2552 lang.IFn; if










	linked_2551 == nil { ifn_2552 = lang.IFn_Cast(root_2550) } else { ifn_2552 = nil }; var arg_2553 any; var fnbody__2561 any = A_arbace_repr_clojure_run_roundtrip_fn__716000286_A_New_O(diff__6); var tmp5 *jrt.Class; var fncls__2560 *jrt.Class = A_arbace_repr_clojure_run_roundtrip_fn__716000286_A_fn_class; if fncls__2560 == nil { var fncls__2560d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_108, false, fnbody__2561); A_arbace_repr_clojure_run_roundtrip_fn__716000286_A_fn_class = fncls__2560d; tmp5 = fncls__2560d } else { tmp5 = fncls__2560 }; arg_2553 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2561, tmp5, nil); var arg_2554 any; var root_2562 any = A_arbace_repr_clojure_A_const_107.GetRawRoot__O(); var linked_2563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2562, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2564 lang.IFn; if linked_2563 == nil { ifn_2564 = lang.IFn_Cast(root_2562) } else { ifn_2564 = nil }; var arg_2565 any = known__3; if linked_2563 == nil { arg_2554 = ifn_2564.Invoke_O__O(arg_2565) } else { arg_2554 = linked_2563.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2562, arg_2565) }; if linked_2551 == nil { stale__8 = ifn_2552.Invoke_O_O__O(arg_2553, arg_2554) } else { stale__8 = linked_2551.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_2550, arg_2553, arg_2554) }; var seq_716000288__9 any; var root_2574 any = /*line :366:1*/A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2574, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2576 lang.IFn; if











	linked_2575 == nil { ifn_2576 = lang.IFn_Cast(root_2574) } else { ifn_2576 = nil }; var arg_2577 any = diff__6; if linked_2575 == nil { seq_716000288__9 = ifn_2576.Invoke_O__O(arg_2577) } else { seq_716000288__9 = linked_2575.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2574, arg_2577) }; var chunk_716000289__10 any; var count_716000290__11 int64 = 0; var i_716000291__12 int64 = 0; L1:
//line :366:1
	for {











		if lang.Numbers_Lt_J_J__Z_NoInit(i_716000291__12, count_716000290__11) { var vec__716000292__13 any = lang.Indexed_Cast(chunk_716000289__10).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_716000291__12)); var rel__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000292__13, lang.RT_IntCast_J__I_NoInit(0), nil); var d__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000292__13, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_63, nil, nil, Lit_70, nil, nil, nil, nil); var tmp8 *jrt.String; var tmp9 any; var root_2672 any = A_arbace_repr_clojure_A_const_22.GetRawRoot__O(); var linked_2673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2672, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2674 lang.IFn
			if linked_2673 == nil { ifn_2674 = lang.IFn_Cast(root_2672) } else { ifn_2674 = nil }; var arg_2675 any = known__3; var arg_2676 any = rel__14; if linked_2673 == nil { tmp9 = ifn_2674.Invoke_O_O__O(arg_2675, arg_2676) } else { tmp9 = linked_2673.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2672, arg_2675, arg_2676) }; if jrt.J2g_Truth(tmp9) { tmp8 = Lit_109 } else { tmp8 = Lit_110 }; var tmp10 any = tmp8.Ref(); var tmp11 any; var root_2677 any = A_arbace_repr_clojure_A_const_163.GetRawRoot__O(); var linked_2678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2677, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2679 lang.IFn; if linked_2678 == nil { ifn_2679 = lang.IFn_Cast(root_2677) } else { ifn_2679 = nil }; var arg_2680 any = A_arbace_repr_clojure_A_const_128.Invoke_O__O(d__15); if linked_2678 == nil { tmp11 = ifn_2679.Invoke_O__O(arg_2680) } else { tmp11 = linked_2678.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2677, arg_2680) }; var tmp12 any = tmp11; var tmp13 *jrt.String
			if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_130.Invoke_O__O(d__15)) { tmp13 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_111, nil, Lit_112), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_repr_clojure_A_const_130.Invoke_O__O(d__15), nil)) } else { tmp13 = nil }
//line :379:1
			var tmp14 any = tmp13.Ref(); var tmp15 *jrt.String; var temp__1927000414__auto____24 any = lang.IFn_Cast(known__3).Invoke_O__O(rel__14)

			if jrt.J2g_Truth(temp__1927000414__auto____24) { var k__25 any = temp__1927000414__auto____24; tmp15 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_22, nil), jrt.RefArrayOf(jrt.Object_class, nil, k__25)) } else { tmp15 = nil }
//line :379:1
			var tmp16 any = tmp15.Ref(); var tmp17 *jrt.String; var tmp18 any; var and__1927000168__auto____24 any = A_arbace_repr_clojure_A_const_131.Invoke_O__O(d__15)


			if jrt.J2g_Truth(and__1927000168__auto____24) { var or__1927000174__auto____25 any = A_arbace_repr_clojure_A_const_152.Invoke_O__O(o__0); if jrt.J2g_Truth(or__1927000174__auto____25) { tmp18 = or__1927000174__auto____25 } else { var root_2681 any = A_arbace_repr_clojure_A_const_41.GetRawRoot__O(); var linked_2682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2681, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2683 lang.IFn; if linked_2682 == nil { ifn_2683 = lang.IFn_Cast(root_2681) } else { ifn_2683 = nil }; var arg_2684 any; var root_2685 any = A_arbace_repr_clojure_A_const_22.GetRawRoot__O(); var linked_2686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2685, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2687 lang.IFn; if linked_2686 == nil { ifn_2687 = lang.IFn_Cast(root_2685) } else { ifn_2687 = nil }; var arg_2688 any = known__3; var arg_2689 any = rel__14; if linked_2686 == nil { arg_2684 = ifn_2687.Invoke_O_O__O(arg_2688, arg_2689) } else { arg_2684 = linked_2686.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2685, arg_2688, arg_2689) }; if linked_2682 == nil { tmp18 = ifn_2683.Invoke_O__O(arg_2684) } else { tmp18 = linked_2682.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2681, arg_2684) } } } else { tmp18 = and__1927000168__auto____24 }; if jrt.J2g_Truth(tmp18) { tmp17 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_113, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_repr_clojure_A_const_131.Invoke_O__O(d__15))) } else { tmp17 = nil }
//line :379:1
			tmp6.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp10, rel__14, nil, tmp12, tmp14, tmp16, tmp17.Ref())).Ref())
//line :378:1
			seq_716000288__9, chunk_716000289__10, count_716000290__11, i_716000291__12 = seq_716000288__9, chunk_716000289__10, count_716000290__11, lang.Numbers_Unchecked_inc_J__J_NoInit(i_716000291__12); continue L1 } else { var temp__1927000414__auto____13 any; var root_2578 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2578, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2580 lang.IFn; if linked_2579 == nil { ifn_2580 = lang.IFn_Cast(root_2578) } else { ifn_2580 = nil }; var arg_2581 any = seq_716000288__9; if linked_2579 == nil { temp__1927000414__auto____13 = ifn_2580.Invoke_O__O(arg_2581) } else { temp__1927000414__auto____13 = linked_2579.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2578, arg_2581) }; if jrt.J2g_Truth(temp__1927000414__auto____13) { var seq_716000288__14 any = temp__1927000414__auto____13; var tmp19 any; var root_2582 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_2583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2582, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2584 lang.IFn; if linked_2583 == nil { ifn_2584 = lang.IFn_Cast(root_2582) } else { ifn_2584 = nil }; var arg_2585 any = seq_716000288__14; if linked_2583 == nil { tmp19 = ifn_2584.Invoke_O__O(arg_2585) } else { tmp19 = linked_2583.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2582, arg_2585) }; if jrt.J2g_Truth(tmp19) { var c__1927000678__auto____15 any; var root_2586 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_2587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2586, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2588 lang.IFn; if linked_2587 == nil { ifn_2588 = lang.IFn_Cast(root_2586) } else { ifn_2588 = nil }; var arg_2589 any = seq_716000288__14; if linked_2587 == nil { c__1927000678__auto____15 = ifn_2588.Invoke_O__O(arg_2589) } else { c__1927000678__auto____15 = linked_2587.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2586, arg_2589) }; var tmp20 any; var root_2690 any = A_arbace_repr_clojure_A_const_65.GetRawRoot__O(); var linked_2691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2690, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2692 lang.IFn; if linked_2691 == nil { ifn_2692 = lang.IFn_Cast(root_2690) } else { ifn_2692 = nil }; var arg_2693 any = seq_716000288__14; if linked_2691 == nil { tmp20 = ifn_2692.Invoke_O__O(arg_2693) } else { tmp20 = linked_2691.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2690, arg_2693) }; seq_716000288__9, chunk_716000289__10, count_716000290__11, i_716000291__12 = tmp20, c__1927000678__auto____15, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____15))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__716000295__15 any; var root_2590 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2590, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2592 lang.IFn; if linked_2591 == nil { ifn_2592 = lang.IFn_Cast(root_2590) } else { ifn_2592 = nil }; var arg_2593 any = seq_716000288__14; if linked_2591 == nil { vec__716000295__15 = ifn_2592.Invoke_O__O(arg_2593) } else { vec__716000295__15 = linked_2591.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2590, arg_2593) }; var rel__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000295__15, lang.RT_IntCast_J__I_NoInit(0), nil); var d__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000295__15, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp22 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_63, nil, nil, Lit_70, nil, nil, nil, nil); var tmp23 *jrt.String; var tmp24 any; var root_2698 any = A_arbace_repr_clojure_A_const_22.GetRawRoot__O(); var linked_2699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2698, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2700 lang.IFn
				if linked_2699 == nil { ifn_2700 = lang.IFn_Cast(root_2698) } else { ifn_2700 = nil }; var arg_2701 any = known__3; var arg_2702 any = rel__16; if linked_2699 == nil { tmp24 = ifn_2700.Invoke_O_O__O(arg_2701, arg_2702) } else { tmp24 = linked_2699.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2698, arg_2701, arg_2702) }; if jrt.J2g_Truth(tmp24) { tmp23 = Lit_109 } else { tmp23 = Lit_110 }; var tmp25 any = tmp23.Ref(); var tmp26 any; var root_2703 any = A_arbace_repr_clojure_A_const_163.GetRawRoot__O(); var linked_2704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2703, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2705 lang.IFn; if linked_2704 == nil { ifn_2705 = lang.IFn_Cast(root_2703) } else { ifn_2705 = nil }; var arg_2706 any = A_arbace_repr_clojure_A_const_128.Invoke_O__O(d__17); if linked_2704 == nil { tmp26 = ifn_2705.Invoke_O__O(arg_2706) } else { tmp26 = linked_2704.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2703, arg_2706) }; var tmp27 any = tmp26; var tmp28 *jrt.String
				if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_130.Invoke_O__O(d__17)) { tmp28 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_111, nil, Lit_112), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_repr_clojure_A_const_130.Invoke_O__O(d__17), nil)) } else { tmp28 = nil }
//line :379:1
				var tmp29 any = tmp28.Ref(); var tmp30 *jrt.String; var temp__1927000414__auto____26 any = lang.IFn_Cast(known__3).Invoke_O__O(rel__16)

				if jrt.J2g_Truth(temp__1927000414__auto____26) { var k__27 any = temp__1927000414__auto____26; tmp30 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_22, nil), jrt.RefArrayOf(jrt.Object_class, nil, k__27)) } else { tmp30 = nil }
//line :379:1
				var tmp31 any = tmp30.Ref(); var tmp32 *jrt.String; var tmp33 any; var and__1927000168__auto____26 any = A_arbace_repr_clojure_A_const_131.Invoke_O__O(d__17)


				if jrt.J2g_Truth(and__1927000168__auto____26) { var or__1927000174__auto____27 any = A_arbace_repr_clojure_A_const_152.Invoke_O__O(o__0); if jrt.J2g_Truth(or__1927000174__auto____27) { tmp33 = or__1927000174__auto____27 } else { var root_2707 any = A_arbace_repr_clojure_A_const_41.GetRawRoot__O(); var linked_2708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2707, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2709 lang.IFn; if linked_2708 == nil { ifn_2709 = lang.IFn_Cast(root_2707) } else { ifn_2709 = nil }; var arg_2710 any; var root_2711 any = A_arbace_repr_clojure_A_const_22.GetRawRoot__O(); var linked_2712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2711, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2713 lang.IFn; if linked_2712 == nil { ifn_2713 = lang.IFn_Cast(root_2711) } else { ifn_2713 = nil }; var arg_2714 any = known__3; var arg_2715 any = rel__16; if linked_2712 == nil { arg_2710 = ifn_2713.Invoke_O_O__O(arg_2714, arg_2715) } else { arg_2710 = linked_2712.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2711, arg_2714, arg_2715) }; if linked_2708 == nil { tmp33 = ifn_2709.Invoke_O__O(arg_2710) } else { tmp33 = linked_2708.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2707, arg_2710) } } } else { tmp33 = and__1927000168__auto____26 }; if jrt.J2g_Truth(tmp33) { tmp32 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_113, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_repr_clojure_A_const_131.Invoke_O__O(d__17))) } else { tmp32 = nil }
//line :379:1
				tmp21.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp22, jrt.RefArrayOf(jrt.Object_class, nil, tmp25, rel__16, nil, tmp27, tmp29, tmp31, tmp32.Ref())).Ref())
//line :378:1
				var tmp34 any; var root_2716 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_2717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2716, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2718 lang.IFn; if linked_2717 == nil { ifn_2718 = lang.IFn_Cast(root_2716) } else { ifn_2718 = nil }; var arg_2719 any = seq_716000288__14; if linked_2717 == nil { tmp34 = ifn_2718.Invoke_O__O(arg_2719) } else { tmp34 = linked_2717.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2716, arg_2719) }; seq_716000288__9, chunk_716000289__10, count_716000290__11, i_716000291__12 = tmp34, nil, 0, 0; continue L1 } } }
//line :366:1
		break L1 }; var seq_716000298__9 any; var root_2594 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2594, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2596 lang.IFn; if
















	linked_2595 == nil { ifn_2596 = lang.IFn_Cast(root_2594) } else { ifn_2596 = nil }; var arg_2597 any = stale__8; if linked_2595 == nil { seq_716000298__9 = ifn_2596.Invoke_O__O(arg_2597) } else { seq_716000298__9 = linked_2595.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2594, arg_2597) }; var chunk_716000299__10 any; var count_716000300__11 int64 = 0; var i_716000301__12 int64 = 0; L2:
//line :366:1
	for {
















		if lang.Numbers_Lt_J_J__Z_NoInit(i_716000301__12, count_716000300__11) { var rel__13 any = lang.Indexed_Cast(chunk_716000299__10).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_716000301__12)); lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_114, nil, Lit_115), jrt.RefArrayOf(jrt.Object_class, nil, rel__13, nil)).Ref()); seq_716000298__9, chunk_716000299__10, count_716000300__11, i_716000301__12 = seq_716000298__9, chunk_716000299__10, count_716000300__11, lang.Numbers_Unchecked_inc_J__J_NoInit(i_716000301__12); continue L2 } else { var temp__1927000414__auto____13_2 any; var root_2598 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2598, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2600 lang.IFn; if linked_2599 == nil { ifn_2600 = lang.IFn_Cast(root_2598) } else { ifn_2600 = nil }; var arg_2601 any = seq_716000298__9; if linked_2599 == nil { temp__1927000414__auto____13_2 = ifn_2600.Invoke_O__O(arg_2601) } else { temp__1927000414__auto____13_2 = linked_2599.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2598, arg_2601) }; if jrt.J2g_Truth(temp__1927000414__auto____13_2) { var seq_716000298__14 any = temp__1927000414__auto____13_2; var tmp35 any; var root_2602 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_2603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2602, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2604 lang.IFn; if linked_2603 == nil { ifn_2604 = lang.IFn_Cast(root_2602) } else { ifn_2604 = nil }; var arg_2605 any = seq_716000298__14; if linked_2603 == nil { tmp35 = ifn_2604.Invoke_O__O(arg_2605) } else { tmp35 = linked_2603.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2602, arg_2605) }; if jrt.J2g_Truth(tmp35) { var c__1927000678__auto____15_2 any; var root_2606 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_2607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2606, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2608 lang.IFn; if linked_2607 == nil { ifn_2608 = lang.IFn_Cast(root_2606) } else { ifn_2608 = nil }; var arg_2609 any = seq_716000298__14; if linked_2607 == nil { c__1927000678__auto____15_2 = ifn_2608.Invoke_O__O(arg_2609) } else { c__1927000678__auto____15_2 = linked_2607.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2606, arg_2609) }; var tmp36 any; var root_2724 any = A_arbace_repr_clojure_A_const_65.GetRawRoot__O(); var linked_2725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2724, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2726 lang.IFn; if linked_2725 == nil { ifn_2726 = lang.IFn_Cast(root_2724) } else { ifn_2726 = nil }; var arg_2727 any = seq_716000298__14; if linked_2725 == nil { tmp36 = ifn_2726.Invoke_O__O(arg_2727) } else { tmp36 = linked_2725.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2724, arg_2727) }; seq_716000298__9, chunk_716000299__10, count_716000300__11, i_716000301__12 = tmp36, c__1927000678__auto____15_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____15_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var rel__15 any; var root_2610 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2610, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2612 lang.IFn; if linked_2611 == nil { ifn_2612 = lang.IFn_Cast(root_2610) } else { ifn_2612 = nil }; var arg_2613 any = seq_716000298__14; if linked_2611 == nil { rel__15 = ifn_2612.Invoke_O__O(arg_2613) } else { rel__15 = linked_2611.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2610, arg_2613) }; lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_114, nil, Lit_115), jrt.RefArrayOf(jrt.Object_class, nil, rel__15, nil)).Ref()); var tmp37 any; var root_2732 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_2733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2732, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2734 lang.IFn; if linked_2733 == nil { ifn_2734 = lang.IFn_Cast(root_2732) } else { ifn_2734 = nil }; var arg_2735 any = seq_716000298__14; if linked_2733 == nil { tmp37 = ifn_2734.Invoke_O__O(arg_2735) } else { tmp37 = linked_2733.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2732, arg_2735) }; seq_716000298__9, chunk_716000299__10, count_716000300__11, i_716000301__12 = tmp37, nil, 0, 0; continue L2 } } }
//line :366:1
		break L2 }; if

















	jrt.J2g_Truth(A_arbace_repr_clojure_A_const_152.Invoke_O__O(o__0)) { var seq_716000302__9 any; var root_2614 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2614, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2616 lang.IFn
		if linked_2615 == nil { ifn_2616 = lang.IFn_Cast(root_2614) } else { ifn_2616 = nil }; var arg_2617 any = outside__4; if linked_2615 == nil { seq_716000302__9 = ifn_2616.Invoke_O__O(arg_2617) } else { seq_716000302__9 = linked_2615.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2614, arg_2617) }
//line :384:1
		var chunk_716000303__10 any; var count_716000304__11 int64 = 0; var i_716000305__12 int64 = 0; L3: for {
			if lang.Numbers_Lt_J_J__Z_NoInit(i_716000305__12, count_716000304__11) { var vec__716000306__13 any = lang.Indexed_Cast(chunk_716000303__10).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_716000305__12)); var rel__14_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000306__13, lang.RT_IntCast_J__I_NoInit(0), nil); var d__15_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000306__13, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_116, nil, Lit_113, nil), jrt.RefArrayOf(jrt.Object_class, nil, rel__14_2, nil, A_arbace_repr_clojure_A_const_131.Invoke_O__O(d__15_2))).Ref()); seq_716000302__9, chunk_716000303__10, count_716000304__11, i_716000305__12 = seq_716000302__9, chunk_716000303__10, count_716000304__11, lang.Numbers_Unchecked_inc_J__J_NoInit(i_716000305__12); continue L3 } else { var temp__1927000414__auto____13_3 any; var root_2618 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2618, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2620 lang.IFn; if linked_2619 == nil { ifn_2620 = lang.IFn_Cast(root_2618) } else { ifn_2620 = nil }; var arg_2621 any = seq_716000302__9; if linked_2619 == nil { temp__1927000414__auto____13_3 = ifn_2620.Invoke_O__O(arg_2621) } else { temp__1927000414__auto____13_3 = linked_2619.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2618, arg_2621) }; if jrt.J2g_Truth(temp__1927000414__auto____13_3) { var seq_716000302__14 any = temp__1927000414__auto____13_3; var tmp38 any; var root_2622 any = A_arbace_repr_clojure_A_const_58.GetRawRoot__O(); var linked_2623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2622, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2624 lang.IFn; if linked_2623 == nil { ifn_2624 = lang.IFn_Cast(root_2622) } else { ifn_2624 = nil }; var arg_2625 any = seq_716000302__14; if linked_2623 == nil { tmp38 = ifn_2624.Invoke_O__O(arg_2625) } else { tmp38 = linked_2623.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2622, arg_2625) }; if jrt.J2g_Truth(tmp38) { var c__1927000678__auto____15_3 any; var root_2626 any = A_arbace_repr_clojure_A_const_59.GetRawRoot__O(); var linked_2627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2626, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2628 lang.IFn; if linked_2627 == nil { ifn_2628 = lang.IFn_Cast(root_2626) } else { ifn_2628 = nil }; var arg_2629 any = seq_716000302__14; if linked_2627 == nil { c__1927000678__auto____15_3 = ifn_2628.Invoke_O__O(arg_2629) } else { c__1927000678__auto____15_3 = linked_2627.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2626, arg_2629) }; var tmp39 any; var root_2740 any = A_arbace_repr_clojure_A_const_65.GetRawRoot__O(); var linked_2741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2740, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2742 lang.IFn; if linked_2741 == nil { ifn_2742 = lang.IFn_Cast(root_2740) } else { ifn_2742 = nil }; var arg_2743 any = seq_716000302__14; if linked_2741 == nil { tmp39 = ifn_2742.Invoke_O__O(arg_2743) } else { tmp39 = linked_2741.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2740, arg_2743) }; seq_716000302__9, chunk_716000303__10, count_716000304__11, i_716000305__12 = tmp39, c__1927000678__auto____15_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____15_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__716000309__15 any; var root_2630 any = A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2630, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2632 lang.IFn; if linked_2631 == nil { ifn_2632 = lang.IFn_Cast(root_2630) } else { ifn_2632 = nil }; var arg_2633 any = seq_716000302__14; if linked_2631 == nil { vec__716000309__15 = ifn_2632.Invoke_O__O(arg_2633) } else { vec__716000309__15 = linked_2631.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2630, arg_2633) }; var rel__16_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000309__15, lang.RT_IntCast_J__I_NoInit(0), nil); var d__17_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__716000309__15, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_116, nil, Lit_113, nil), jrt.RefArrayOf(jrt.Object_class, nil, rel__16_2, nil, A_arbace_repr_clojure_A_const_131.Invoke_O__O(d__17_2))).Ref()); var tmp40 any; var root_2748 any = A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_2749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2748, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2750 lang.IFn; if linked_2749 == nil { ifn_2750 = lang.IFn_Cast(root_2748) } else { ifn_2750 = nil }; var arg_2751 any = seq_716000302__14; if linked_2749 == nil { tmp40 = ifn_2750.Invoke_O__O(arg_2751) } else { tmp40 = linked_2749.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2748, arg_2751) }; seq_716000302__9, chunk_716000303__10, count_716000304__11, i_716000305__12 = tmp40, nil, 0, 0; continue L3 } } }
//line :384:1
			break L3 } }; var tmp41 lang.IFn =

	lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp42 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_182.GetRawRoot__O()); var tmp43 *jrt.String; if
	jrt.J2g_Truth(A_arbace_repr_clojure_A_const_154.Invoke_O__O(o__0)) { var tmp44 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_66, nil); var tmp45 any; var root_2651 any = A_arbace_repr_clojure_A_const_163.GetRawRoot__O(); var linked_2652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2651, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2653 lang.IFn; if linked_2652 == nil { ifn_2653 = lang.IFn_Cast(root_2651) } else { ifn_2653 = nil }; var arg_2654 any = A_arbace_repr_clojure_A_const_154.Invoke_O__O(o__0); if linked_2652 == nil { tmp45 = ifn_2653.Invoke_O__O(arg_2654) } else { tmp45 = linked_2652.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2651, arg_2654) }; tmp43 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp44, jrt.RefArrayOf(jrt.Object_class, nil, tmp45)) } else { tmp43 = Lit_14 }; var tmp46 any = /*line :386:1*/tmp43.Ref(); var tmp47 *jrt.String; var tmp48 any = A_arbace_repr_clojure_A_const_119; if

	lang.Util_Equiv_O_O__Z_NoInit(tmp48, A_arbace_repr_clojure_A_const_112.Invoke_O__O(o__0)) { tmp47 = Lit_118 } else { tmp47 = Lit_119 }; var tmp49 any = /*line :386:1*/tmp47.Ref(); var tmp50 any = A_arbace_repr_clojure_A_const_139.Invoke_O__O(r__2); var tmp51 any = A_arbace_repr_clojure_A_const_140.Invoke_O__O(r__2); var tmp52 any; var tmp53 any = A_arbace_repr_clojure_A_const_119; if



	lang.Util_Equiv_O_O__Z_NoInit(tmp53, A_arbace_repr_clojure_A_const_112.Invoke_O__O(o__0)) {
		tmp52 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_182.GetRawRoot__O()).Invoke_O_O__O(Lit_120, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(outside__4)).Ref()) } else {
			tmp52 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_182.GetRawRoot__O()).Invoke_O_O__O(Lit_121, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(one_way__5)).Ref()) }; /*line :386:1*/tmp41.Invoke_O__O(tmp42.Invoke_O_O_O_O_O_O_O_O_O_O__O(Lit_117, tmp46, tmp49, tmp50, tmp51, tmp52, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(diff__6)).Ref(), jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(diff__6)), int64(lang.RT_Count_O__I_NoInit(new__7)))).Ref(), jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(new__7)).Ref(), jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(stale__8)).Ref())); var root_2665 any =







	A_arbace_repr_clojure_A_const_183.GetRawRoot__O(); var linked_2666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2665, aot_arbace_core.A_arbace_core_shutdown_agents_A_fn_class); var ifn_2667 lang.IFn; if linked_2666 == nil { ifn_2667 = lang.IFn_Cast(root_2665) } else { ifn_2667 = nil }; if linked_2666 == nil { ifn_2667.Invoke__O() } else { linked_2666.(*aot_arbace_core.A_arbace_core_shutdown_agents_A).Invoke_O__O(root_2665) }; var tmp54 any; var or__1927000174__auto____9 any; var root_2566 any =
	A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2566, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2568 lang.IFn; if linked_2567 == nil { ifn_2568 = lang.IFn_Cast(root_2566) } else { ifn_2568 = nil }; var arg_2569 any = new__7; if linked_2567 == nil { or__1927000174__auto____9 = ifn_2568.Invoke_O__O(arg_2569) } else { or__1927000174__auto____9 = linked_2567.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2566, arg_2569) }; if jrt.J2g_Truth(or__1927000174__auto____9) { tmp54 = or__1927000174__auto____9 } else { var root_2570 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2570, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2572 lang.IFn; if linked_2571 == nil { ifn_2572 = lang.IFn_Cast(root_2570) } else { ifn_2572 = nil }; var arg_2573 any = stale__8; if linked_2571 == nil { tmp54 = ifn_2572.Invoke_O__O(arg_2573) } else { tmp54 = linked_2571.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2570, arg_2573) } }; if jrt.J2g_Truth(tmp54) { jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(1)); return nil } else { return nil } }
//line :373:1
func A_arbace_repr_clojure_run_roundtrip_fn__716000280_A_New() *A_arbace_repr_clojure_run_roundtrip_fn__716000280_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_roundtrip_fn__716000280_A{}; t.Ctor(); return t }
//line :373:1
func (t *A_arbace_repr_clojure_run_roundtrip_fn__716000280_A) Ctor() {}
//line :373:1
func (t *A_arbace_repr_clojure_run_roundtrip_fn__716000280_A) Invoke_O_O__O(self, p1__716000276_SHARP___1 any) any { var tmp1 any = A_arbace_repr_clojure_A_const_135; var tmp2 *lang.Keyword = A_arbace_repr_clojure_A_const_128; var tmp3 any; var root_2490 any = A_arbace_repr_clojure_A_const_178.GetRawRoot__O(); var linked_2491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2490, aot_arbace_core.A_arbace_core_val_A_fn_class); var ifn_2492 lang.IFn; if linked_2491 == nil { ifn_2492 = lang.IFn_Cast(root_2490) } else { ifn_2492 = nil }; var arg_2493 any = p1__716000276_SHARP___1; if linked_2491 == nil { tmp3 = ifn_2492.Invoke_O__O(arg_2493) } else { tmp3 = linked_2491.(*aot_arbace_core.A_arbace_core_val_A).Invoke_O_O__O(root_2490, arg_2493) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2.Invoke_O__O(tmp3))).Ref() }
func A_arbace_repr_clojure_run_roundtrip_fn__716000282_A_New() *A_arbace_repr_clojure_run_roundtrip_fn__716000282_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_roundtrip_fn__716000282_A{}; t.Ctor(); return t }
//line :374:1
func (t *A_arbace_repr_clojure_run_roundtrip_fn__716000282_A) Ctor() {}
//line :374:1
func (t *A_arbace_repr_clojure_run_roundtrip_fn__716000282_A) Invoke_O_O__O(self, p1__716000277_SHARP___1 any) any { var tmp1 any = A_arbace_repr_clojure_A_const_179; var tmp2 *lang.Keyword = A_arbace_repr_clojure_A_const_128; var tmp3 any; var root_2509 any = A_arbace_repr_clojure_A_const_178.GetRawRoot__O(); var linked_2510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2509, aot_arbace_core.A_arbace_core_val_A_fn_class); var ifn_2511 lang.IFn; if linked_2510 == nil { ifn_2511 = lang.IFn_Cast(root_2509) } else { ifn_2511 = nil }; var arg_2512 any = p1__716000277_SHARP___1; if linked_2510 == nil { tmp3 = ifn_2511.Invoke_O__O(arg_2512) } else { tmp3 = linked_2510.(*aot_arbace_core.A_arbace_core_val_A).Invoke_O_O__O(root_2509, arg_2512) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2.Invoke_O__O(tmp3))).Ref() }

func A_arbace_repr_clojure_run_roundtrip_fn__716000284_A_New_O(p0 any) *A_arbace_repr_clojure_run_roundtrip_fn__716000284_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_roundtrip_fn__716000284_A{}; t.Ctor_O(p0); return t }
//line :376:1
func (t *A_arbace_repr_clojure_run_roundtrip_fn__716000284_A) Ctor_O(c__known any) { t.F_known = c__known }
//line :376:1
func (t *A_arbace_repr_clojure_run_roundtrip_fn__716000284_A) Invoke_O_O__O(self, p1__716000278_SHARP___1 any) any { var root_2539 any = A_arbace_repr_clojure_A_const_22.GetRawRoot__O(); var linked_2540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2539, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2541 lang.IFn; if linked_2540 == nil { ifn_2541 = lang.IFn_Cast(root_2539) } else { ifn_2541 = nil }; var arg_2542 any = t.F_known; var arg_2543 any = p1__716000278_SHARP___1; if linked_2540 == nil { return ifn_2541.Invoke_O_O__O(arg_2542, arg_2543) } else { return linked_2540.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2539, arg_2542, arg_2543) } }
func A_arbace_repr_clojure_run_roundtrip_fn__716000286_A_New_O(p0 any) *A_arbace_repr_clojure_run_roundtrip_fn__716000286_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_run_roundtrip_fn__716000286_A{}; t.Ctor_O(p0); return t }
//line :377:1
func (t *A_arbace_repr_clojure_run_roundtrip_fn__716000286_A) Ctor_O(c__diff any) { t.F_diff = c__diff }
//line :377:1
func (t *A_arbace_repr_clojure_run_roundtrip_fn__716000286_A) Invoke_O_O__O(self, p1__716000279_SHARP___1 any) any { var root_2555 any = A_arbace_repr_clojure_A_const_22.GetRawRoot__O(); var linked_2556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2555, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2557 lang.IFn; if linked_2556 == nil { ifn_2557 = lang.IFn_Cast(root_2555) } else { ifn_2557 = nil }; var arg_2558 any = t.F_diff; var arg_2559 any = p1__716000279_SHARP___1; if linked_2556 == nil { return ifn_2557.Invoke_O_O__O(arg_2558, arg_2559) } else { return linked_2556.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2555, arg_2558, arg_2559) } }



















func A_arbace_repr_clojure__main_A_New() *A_arbace_repr_clojure__main_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure__main_A{}; t.Ctor(); return t }
//line :397:1
func (t *A_arbace_repr_clojure__main_A) Ctor() {}
//line :397:1
func (t *A_arbace_repr_clojure__main_A) DoInvoke_O_O__O(self, args__0 any) any { var vec__716000313__2 any = args__0; var seq__716000314__3 any; var root_2752 any = A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2752, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2754 lang.IFn; if
										linked_2753 == nil { ifn_2754 = lang.IFn_Cast(root_2752) } else { ifn_2754 = nil }; var arg_2755 any = vec__716000313__2; if linked_2753 == nil { seq__716000314__3 = ifn_2754.Invoke_O__O(arg_2755) } else { seq__716000314__3 = linked_2753.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2752, arg_2755) }; var first__716000315__4 any; var root_2756 any = /*line :397:1*/A_arbace_repr_clojure_A_const_17.GetRawRoot__O(); var linked_2757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2756, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2758 lang.IFn; if
										linked_2757 == nil { ifn_2758 = lang.IFn_Cast(root_2756) } else { ifn_2758 = nil }; var arg_2759 any = seq__716000314__3; if linked_2757 == nil { first__716000315__4 = ifn_2758.Invoke_O__O(arg_2759) } else { first__716000315__4 = linked_2757.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2756, arg_2759) }; var seq__716000314__5 any; var root_2760 any = /*line :397:1*/A_arbace_repr_clojure_A_const_14.GetRawRoot__O(); var linked_2761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2760, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2762 lang.IFn; if
										linked_2761 == nil { ifn_2762 = lang.IFn_Cast(root_2760) } else { ifn_2762 = nil }; var arg_2763 any = seq__716000314__3; if linked_2761 == nil { seq__716000314__5 = ifn_2762.Invoke_O__O(arg_2763) } else { seq__716000314__5 = linked_2761.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2760, arg_2763) }; var cmd__6 any = first__716000315__4; var args__7 any = seq__716000314__5; var verb__8 any = /*line :397:1*/lang.RT_Get_O_O__O_NoInit(A_arbace_repr_clojure_A_const_184, cmd__6); var ___9 any; _ = ___9; if


	jrt.J2g_Truth(verb__8) { ___9 = nil } else { var root_2764 any = A_arbace_repr_clojure_A_const_185.GetRawRoot__O(); var linked_2765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2764, A_arbace_repr_clojure_usage_A_fn_class); var ifn_2766 lang.IFn; if linked_2765 == nil { ifn_2766 = lang.IFn_Cast(root_2764) } else { ifn_2766 = nil }; if linked_2765 == nil { ___9 = ifn_2766.Invoke__O() } else { ___9 = linked_2765.(*A_arbace_repr_clojure_usage_A).Invoke_O__O(root_2764) } }; var o__10 any; var root_2767 any = /*line :397:1*/A_arbace_repr_clojure_A_const_186.GetRawRoot__O(); var linked_2768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2767, A_arbace_repr_clojure_parse_args_A_fn_class); var ifn_2769 lang.IFn; if



	linked_2768 == nil { ifn_2769 = lang.IFn_Cast(root_2767) } else { ifn_2769 = nil }; var arg_2770 any = args__7; if linked_2768 == nil { o__10 = ifn_2769.Invoke_O__O(arg_2770) } else { o__10 = linked_2768.(*A_arbace_repr_clojure_parse_args_A).Invoke_O_O__O(root_2767, arg_2770) }; var known__11 any; var root_2771 any = /*line :397:1*/A_arbace_repr_clojure_A_const_73.GetRawRoot__O(); var linked_2772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2771, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2773 lang.IFn; if




	linked_2772 == nil { ifn_2773 = lang.IFn_Cast(root_2771) } else { ifn_2773 = nil }; var arg_2774 any; var root_2775 any = A_arbace_repr_clojure_A_const_155.GetRawRoot__O(); var linked_2776 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2775, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2777 lang.IFn; if linked_2776 == nil { ifn_2777 = lang.IFn_Cast(root_2775) } else { ifn_2777 = nil }; var arg_2778 any = A_arbace_repr_clojure_A_const_164; var arg_2779 any = A_arbace_repr_clojure_A_const_159.GetRawRoot__O(); if linked_2776 == nil { arg_2774 = ifn_2777.Invoke_O_O__O(arg_2778, arg_2779) } else { arg_2774 = linked_2776.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2775, arg_2778, arg_2779) }; if linked_2772 == nil { known__11 = ifn_2773.Invoke_O__O(arg_2774) } else { known__11 = linked_2772.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2771, arg_2774) }; var temp__1927000414__auto____12 any; var root_2810 any = /*line :397:1*/A_arbace_repr_clojure_A_const_16.GetRawRoot__O(); var linked_2811 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2810, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2812 lang.IFn; if





	linked_2811 == nil { ifn_2812 = lang.IFn_Cast(root_2810) } else { ifn_2812 = nil }; var arg_2813 any; var root_2814 any = A_arbace_repr_clojure_A_const_141.GetRawRoot__O(); var linked_2815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2814, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_2816 lang.IFn; if linked_2815 == nil { ifn_2816 = lang.IFn_Cast(root_2814) } else { ifn_2816 = nil }; var arg_2817 any = known__11; var arg_2818 any = A_arbace_repr_clojure_A_const_33.Invoke_O__O(o__10); if linked_2815 == nil { arg_2813 = ifn_2816.Invoke_O_O__O(arg_2817, arg_2818) } else { arg_2813 = linked_2815.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_2814, arg_2817, arg_2818) }; if linked_2811 == nil { temp__1927000414__auto____12 = ifn_2812.Invoke_O__O(arg_2813) } else { temp__1927000414__auto____12 = linked_2811.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2810, arg_2813) }; if jrt.J2g_Truth(temp__1927000414__auto____12) { var bad__13 any = temp__1927000414__auto____12; var tmp1 any; var root_2819 any = A_arbace_repr_clojure_A_const_146.GetRawRoot__O(); var linked_2820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2819, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_2821 lang.IFn
		if linked_2820 == nil { ifn_2821 = lang.IFn_Cast(root_2819) } else { ifn_2821 = nil }; var arg_2822 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_1, nil); var tmp3 any; var root_2824 any = A_arbace_repr_clojure_A_const_191.GetRawRoot__O(); var linked_2825 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2824, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_2826 lang.IFn; if linked_2825 == nil { ifn_2826 = lang.IFn_Cast(root_2824) } else { ifn_2826 = nil }; var arg_2827 any = Lit_2; var arg_2828 any; var root_2829 any = A_arbace_repr_clojure_A_const_155.GetRawRoot__O(); var linked_2830 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2829, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2831 lang.IFn; if linked_2830 == nil { ifn_2831 = lang.IFn_Cast(root_2829) } else { ifn_2831 = nil }; var arg_2832 any = A_arbace_repr_clojure_A_const_163.GetRawRoot__O(); var arg_2833 any = bad__13; if linked_2830 == nil { arg_2828 = ifn_2831.Invoke_O_O__O(arg_2832, arg_2833) } else { arg_2828 = linked_2830.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2829, arg_2832, arg_2833) }; if linked_2825 == nil { tmp3 = ifn_2826.Invoke_O_O__O(arg_2827, arg_2828) } else { tmp3 = linked_2825.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_2824, arg_2827, arg_2828) }; arg_2822 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref(); var arg_2823 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_2820 == nil { tmp1 = ifn_2821.Invoke_O_O__O(arg_2822, arg_2823) } else { tmp1 = linked_2820.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_2819, arg_2822, arg_2823) }
//line :403:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }; if

	jrt.J2g_Truth(A_arbace_repr_clojure_A_const_149.Invoke_O__O(o__10)) {
		var root_2780 any = A_arbace_repr_clojure_A_const_187.GetRawRoot__O(); var linked_2781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2780, A_arbace_repr_clojure_print_rules_A_fn_class); var ifn_2782 lang.IFn; if linked_2781 == nil { ifn_2782 = lang.IFn_Cast(root_2780) } else { ifn_2782 = nil }; if linked_2781 == nil { return ifn_2782.Invoke__O() } else { return linked_2781.(*A_arbace_repr_clojure_print_rules_A).Invoke_O__O(root_2780) } } else {
//line :405:1
			if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_148.Invoke_O__O(o__10)) { var p__12 any; var tmp4 any = A_arbace_repr_clojure_A_const_24; var tmp5 any = A_arbace_repr_clojure_A_const_24.Invoke_O__O(o__10); var tmp6 any = A_arbace_repr_clojure_A_const_27; var tmp7 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(A_arbace_repr_clojure_A_const_150.Invoke_O__O(o__10))).Ref(); var tmp8 any = A_arbace_repr_clojure_A_const_20; var tmp9 any; var and__1927000168__auto____12 any = A_arbace_repr_clojure_A_const_20.Invoke_O__O(o__10)


				if jrt.J2g_Truth(and__1927000168__auto____12) { var tmp10 any = A_arbace_repr_clojure_A_const_25; var and__1927000168__auto____13 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp10, A_arbace_repr_clojure_A_const_24.Invoke_O__O(o__10)); if and__1927000168__auto____13 { tmp9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(A_arbace_repr_clojure_A_const_150.Invoke_O__O(o__10))).Ref() } else { tmp9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____13).Ref() } } else { tmp9 = and__1927000168__auto____12 }
//line :405:1
				p__12 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9))



				var tmp11 *lang.Keyword = A_arbace_repr_clojure_A_const_19; lang.IFn_Cast(A_arbace_repr_clojure_A_const_192.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(tmp11.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_clojure_A_const_69.GetRawRoot__O()).Invoke_O__O(verb__8))).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_repr_clojure_A_const_78.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure_A_const_193.Get__O()), p__12, Lit_3, A_arbace_repr_clojure_A_const_33.Invoke_O__O(o__10)))
				var root_2783 any = A_arbace_repr_clojure_A_const_188.GetRawRoot__O(); var linked_2784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2783, aot_arbace_core.A_arbace_core_flush_A_fn_class); var ifn_2785 lang.IFn; if linked_2784 == nil { ifn_2785 = lang.IFn_Cast(root_2783) } else { ifn_2785 = nil }; if linked_2784 == nil { return ifn_2785.Invoke__O() } else { return linked_2784.(*aot_arbace_core.A_arbace_core_flush_A).Invoke_O__O(root_2783) } } else {
//line :405:1
					var tmp12 any; var root_2786 any = A_arbace_repr_clojure_A_const_144.GetRawRoot__O(); var linked_2787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2786, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2788 lang.IFn





					if linked_2787 == nil { ifn_2788 = lang.IFn_Cast(root_2786) } else { ifn_2788 = nil }; var arg_2789 any = A_arbace_repr_clojure_A_const_143.Invoke_O__O(o__10); if linked_2787 == nil { tmp12 = ifn_2788.Invoke_O__O(arg_2789) } else { tmp12 = linked_2787.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2786, arg_2789) }
//line :405:1
					if jrt.J2g_Truth(tmp12) {





						var root_2790 any = A_arbace_repr_clojure_A_const_185.GetRawRoot__O(); var linked_2791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2790, A_arbace_repr_clojure_usage_A_fn_class); var ifn_2792 lang.IFn; if linked_2791 == nil { ifn_2792 = lang.IFn_Cast(root_2790) } else { ifn_2792 = nil }; if linked_2791 == nil { return ifn_2792.Invoke__O() } else { return linked_2791.(*A_arbace_repr_clojure_usage_A).Invoke_O__O(root_2790) } } else {
//line :405:1
							if lang.Util_Equiv_O_O__Z_NoInit(verb__8, A_arbace_repr_clojure_A_const_189) {






								var root_2793 any = A_arbace_repr_clojure_A_const_190.GetRawRoot__O(); var linked_2794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2793, A_arbace_repr_clojure_run_roundtrip_A_fn_class); var ifn_2795 lang.IFn; if linked_2794 == nil { ifn_2795 = lang.IFn_Cast(root_2793) } else { ifn_2795 = nil }; var arg_2796 any = o__10; if linked_2794 == nil { return ifn_2795.Invoke_O__O(arg_2796) } else { return linked_2794.(*A_arbace_repr_clojure_run_roundtrip_A).Invoke_O_O__O(root_2793, arg_2796) } } else {
//line :405:1
									var tmp13 any; var root_2797 any = A_arbace_repr_clojure_A_const_41.GetRawRoot__O(); var linked_2798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2797, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2799 lang.IFn







									if linked_2798 == nil { ifn_2799 = lang.IFn_Cast(root_2797) } else { ifn_2799 = nil }; var arg_2800 any; var or__1927000174__auto____12 any = A_arbace_repr_clojure_A_const_28.Invoke_O__O(o__10); if jrt.J2g_Truth(or__1927000174__auto____12) { arg_2800 = or__1927000174__auto____12 } else { arg_2800 = A_arbace_repr_clojure_A_const_147.Invoke_O__O(o__10) }; if linked_2798 == nil { tmp13 = ifn_2799.Invoke_O__O(arg_2800) } else { tmp13 = linked_2798.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2797, arg_2800) }
//line :405:1
									if jrt.J2g_Truth(tmp13) {








										var root_2851 any = A_arbace_repr_clojure_A_const_88.GetRawRoot__O(); var linked_2852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2851, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2853 lang.IFn; if linked_2852 == nil { ifn_2853 = lang.IFn_Cast(root_2851) } else { ifn_2853 = nil }; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_89.GetRawRoot__O()); var tmp15 any = A_arbace_repr_clojure_A_const_90; var arg_2854 any = tmp14.Invoke_O_O__O(tmp15, A_arbace_repr_clojure_A_const_91.Get__O()); if linked_2852 == nil { ifn_2853.Invoke_O__O(arg_2854) } else { linked_2852.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2851, arg_2854) }; var tmp16 *lang.Compiler_AOTFn; var fnbody__2850 any = A_arbace_repr_clojure__main_fn__716000316_A_New(); var tmp17 *jrt.Class; var fncls__2849 *jrt.Class = A_arbace_repr_clojure__main_fn__716000316_A_fn_class; if fncls__2849 == nil { var fncls__2849d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, nil); A_arbace_repr_clojure__main_fn__716000316_A_fn_class = fncls__2849d; tmp17 = fncls__2849d } else { tmp17 = fncls__2849 }; tmp16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2850, tmp17, nil); Up_Compiler_AOTFn_IFn(tmp16).Invoke__O(); jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2)); return nil } else {
//line :405:1
											if A_arbace_repr_clojure_A_const_34 != nil { var s__12 any; var root_2801 any = A_arbace_repr_clojure_A_const_98.GetRawRoot__O(); var linked_2802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2801, A_arbace_repr_clojure_run_A_fn_class); var ifn_2803 lang.IFn










												if linked_2802 == nil { ifn_2803 = lang.IFn_Cast(root_2801) } else { ifn_2803 = nil }; var arg_2804 any = verb__8; var arg_2805 any = A_arbace_repr_clojure_A_const_143.Invoke_O__O(o__10); var arg_2806 any; if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_147.Invoke_O__O(o__10)) { arg_2806 = nil } else { arg_2806 = A_arbace_repr_clojure_A_const_28.Invoke_O__O(o__10) }; var arg_2807 any = o__10; if linked_2802 == nil { s__12 = ifn_2803.Invoke_O_O_O_O__O(arg_2804, arg_2805, arg_2806, arg_2807) } else { s__12 = linked_2802.(*A_arbace_repr_clojure_run_A).Invoke_O_O_O_O_O__O(root_2801, arg_2804, arg_2805, arg_2806, arg_2807) }
												if jrt.J2g_Truth(A_arbace_repr_clojure_A_const_151.Invoke_O__O(o__10)) { } else {
													var root_2881 any = A_arbace_repr_clojure_A_const_88.GetRawRoot__O(); var linked_2882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2881, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2883 lang.IFn; if linked_2882 == nil { ifn_2883 = lang.IFn_Cast(root_2881) } else { ifn_2883 = nil }; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_89.GetRawRoot__O()); var tmp19 any = A_arbace_repr_clojure_A_const_90; var arg_2884 any = tmp18.Invoke_O_O__O(tmp19, A_arbace_repr_clojure_A_const_91.Get__O()); if linked_2882 == nil { ifn_2883.Invoke_O__O(arg_2884) } else { linked_2882.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2881, arg_2884) }; var tmp20 *lang.Compiler_AOTFn; var fnbody__2880 any = A_arbace_repr_clojure__main_fn__716000318_A_New_O_O(s__12, verb__8); var tmp21 *jrt.Class; var fncls__2879 *jrt.Class = A_arbace_repr_clojure__main_fn__716000318_A_fn_class; if fncls__2879 == nil { var fncls__2879d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, fnbody__2880); A_arbace_repr_clojure__main_fn__716000318_A_fn_class = fncls__2879d; tmp21 = fncls__2879d } else { tmp21 = fncls__2879 }; tmp20 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2880, tmp21, nil); Up_Compiler_AOTFn_IFn(tmp20).Invoke__O()
												}



												var tmp22 bool; var na_2808 any = A_arbace_repr_clojure_A_const_86.Invoke_O__O(s__12); if jrt.Long_InstanceOf(na_2808) { var n0_2809 int64 = jrt.NN(jrt.Long_Cast(na_2808)).LongValue__J(); tmp22 = n0_2809 > 0 } else { if jrt.Double_InstanceOf(na_2808) { var n0_2809_2 float64 = jrt.NN(jrt.Double_Cast(na_2808)).DoubleValue__D(); tmp22 = n0_2809_2 > 0.0 } else { tmp22 = lang.Numbers_IsPos_O__Z_NoInit(na_2808) } }; if tmp22 { jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(1)); return nil } else { return nil } } else {
//line :405:1
													return nil } } } } } } }








func A_arbace_repr_clojure__main_fn__716000316_A_New() *A_arbace_repr_clojure__main_fn__716000316_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure__main_fn__716000316_A{}; t.Ctor(); return t }
//line :414:1
func (t *A_arbace_repr_clojure__main_fn__716000316_A) Ctor() {}
//line :414:1
func (t *A_arbace_repr_clojure__main_fn__716000316_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()).Invoke_O__O(Lit_6); return nil }(); var root_2846 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); var linked_2847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2846, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2848 lang.IFn; if linked_2847 == nil { ifn_2848 = lang.IFn_Cast(root_2846) } else { ifn_2848 = nil }; if linked_2847 == nil { ifn_2848.Invoke__O() } else { linked_2847.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2846) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }



func A_arbace_repr_clojure__main_fn__716000318_A_New_O_O(p0, p1 any) *A_arbace_repr_clojure__main_fn__716000318_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure__main_fn__716000318_A{}; t.Ctor_O_O(p0, p1); return t }
//line :418:1
func (t *A_arbace_repr_clojure__main_fn__716000318_A) Ctor_O_O(c__s, c__verb any) { t.F_s = c__s; t.F_verb = c__verb }
//line :418:1
func (t *A_arbace_repr_clojure__main_fn__716000318_A) Invoke_O__O(self any) any { var tmp1 any; tmp16 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_79.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_clojure_A_const_182.GetRawRoot__O()); var tmp4 any = A_arbace_repr_clojure_A_const_97.Invoke_O__O(t.F_s); var tmp5 *jrt.String
											if lang.Util_Equiv_O_O__Z_NoInit(t.F_verb, A_arbace_repr_clojure_A_const_194) { tmp5 = Lit_8 } else { tmp5 = Lit_9 }
//line :419:1
		var tmp6 any = tmp5.Ref(); var tmp7 any = A_arbace_repr_clojure_A_const_27.Invoke_O__O(t.F_s); var tmp8 *jrt.String; var tmp9 any; var t_ any = t.F_verb

		t.F_verb = nil; tmp9 = t_; if lang.Util_Equiv_O_O__Z_NoInit(tmp9, A_arbace_repr_clojure_A_const_194) { tmp8 = Lit_10 } else { tmp8 = Lit_11 }
//line :419:1
		var tmp10 any = tmp8.Ref(); var tmp11 any = A_arbace_repr_clojure_A_const_96.Invoke_O__O(t.F_s); var tmp12 any = A_arbace_repr_clojure_A_const_84.Invoke_O__O(t.F_s); var tmp13 any = A_arbace_repr_clojure_A_const_93.Invoke_O__O(t.F_s); var tmp14 *lang.Keyword = A_arbace_repr_clojure_A_const_86; var tmp15 any; var t__2 any = t.F_s


		t.F_s = nil; tmp15 = t__2
//line :419:1
		tmp1 = tmp2.Invoke_O__O(tmp3.Invoke_O_O_O_O_O_O_O_O_O__O(Lit_7, tmp4, tmp6, tmp7, tmp10, tmp11, tmp12, tmp13, tmp14.Invoke_O__O(tmp15))) }
//line :418:1
	return nil }(); var root_2876 any = A_arbace_repr_clojure_A_const_80.GetRawRoot__O(); var linked_2877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2876, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2878 lang.IFn; if linked_2877 == nil { ifn_2878 = lang.IFn_Cast(root_2876) } else { ifn_2878 = nil }; if linked_2877 == nil { ifn_2878.Invoke__O() } else { linked_2877.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2876) }; if tmp16 != nil { panic(tmp16) }; return tmp1 }



























































































































































type A_arbace_repr_clojure_A struct{ jrt.Object }

var A_arbace_repr_clojure_A_const_pool *jrt.RefArray

var A_arbace_repr_clojure_A_const_0 *lang.Var

var A_arbace_repr_clojure_A_const_1 any

var A_arbace_repr_clojure_A_const_2 *lang.Var

var A_arbace_repr_clojure_A_const_3 any

var A_arbace_repr_clojure_A_const_4 any

var A_arbace_repr_clojure_A_const_5 any

var A_arbace_repr_clojure_A_const_6 any

var A_arbace_repr_clojure_A_const_7 *lang.Var

var A_arbace_repr_clojure_A_const_8 *lang.Var

var A_arbace_repr_clojure_A_const_9 *lang.Var

var A_arbace_repr_clojure_A_const_10 *lang.Var

var A_arbace_repr_clojure_A_const_11 any

var A_arbace_repr_clojure_A_const_12 *lang.Var

var A_arbace_repr_clojure_A_const_13 any

var A_arbace_repr_clojure_A_const_14 *lang.Var

var A_arbace_repr_clojure_A_const_15 *lang.Var

var A_arbace_repr_clojure_A_const_16 *lang.Var

var A_arbace_repr_clojure_A_const_17 *lang.Var

var A_arbace_repr_clojure_A_const_18 *lang.Keyword

var A_arbace_repr_clojure_A_const_19 *lang.Keyword

var A_arbace_repr_clojure_A_const_20 *lang.Keyword

var A_arbace_repr_clojure_A_const_21 *lang.Var

var A_arbace_repr_clojure_A_const_22 *lang.Var

var A_arbace_repr_clojure_A_const_23 *lang.Var

var A_arbace_repr_clojure_A_const_24 *lang.Keyword

var A_arbace_repr_clojure_A_const_25 *lang.Keyword

var A_arbace_repr_clojure_A_const_26 *lang.Keyword

var A_arbace_repr_clojure_A_const_27 *lang.Keyword

var A_arbace_repr_clojure_A_const_28 *lang.Keyword

var A_arbace_repr_clojure_A_const_29 any

var A_arbace_repr_clojure_A_const_30 *lang.Var

var A_arbace_repr_clojure_A_const_31 any

var A_arbace_repr_clojure_A_const_32 *lang.Var

var A_arbace_repr_clojure_A_const_33 *lang.Keyword

var A_arbace_repr_clojure_A_const_34 *lang.Keyword

var A_arbace_repr_clojure_A_const_35 *lang.Keyword

var A_arbace_repr_clojure_A_const_36 *lang.Var

var A_arbace_repr_clojure_A_const_37 *lang.Var

var A_arbace_repr_clojure_A_const_38 any

var A_arbace_repr_clojure_A_const_39 any

var A_arbace_repr_clojure_A_const_40 *lang.Var

var A_arbace_repr_clojure_A_const_41 *lang.Var

var A_arbace_repr_clojure_A_const_42 any

var A_arbace_repr_clojure_A_const_43 any

var A_arbace_repr_clojure_A_const_44 any

var A_arbace_repr_clojure_A_const_45 any

var A_arbace_repr_clojure_A_const_46 *lang.Var

var A_arbace_repr_clojure_A_const_47 any

var A_arbace_repr_clojure_A_const_48 any

var A_arbace_repr_clojure_A_const_49 *lang.Var

var A_arbace_repr_clojure_A_const_50 *lang.Var

var A_arbace_repr_clojure_A_const_51 *lang.Keyword

var A_arbace_repr_clojure_A_const_52 any

var A_arbace_repr_clojure_A_const_53 *lang.Keyword

var A_arbace_repr_clojure_A_const_54 *lang.Var

var A_arbace_repr_clojure_A_const_55 any

var A_arbace_repr_clojure_A_const_56 *lang.Var

var A_arbace_repr_clojure_A_const_57 *lang.Var

var A_arbace_repr_clojure_A_const_58 *lang.Var

var A_arbace_repr_clojure_A_const_59 *lang.Var

var A_arbace_repr_clojure_A_const_60 *lang.Var

var A_arbace_repr_clojure_A_const_61 *lang.Var

var A_arbace_repr_clojure_A_const_62 *lang.Var

var A_arbace_repr_clojure_A_const_63 *lang.Var

var A_arbace_repr_clojure_A_const_64 *lang.Var

var A_arbace_repr_clojure_A_const_65 *lang.Var

var A_arbace_repr_clojure_A_const_66 *lang.Var

var A_arbace_repr_clojure_A_const_67 *lang.Var

var A_arbace_repr_clojure_A_const_68 *lang.Var

var A_arbace_repr_clojure_A_const_69 *lang.Var

var A_arbace_repr_clojure_A_const_70 *lang.Keyword

var A_arbace_repr_clojure_A_const_71 *lang.Keyword

var A_arbace_repr_clojure_A_const_72 *lang.Var

var A_arbace_repr_clojure_A_const_73 *lang.Var

var A_arbace_repr_clojure_A_const_74 *lang.Var

var A_arbace_repr_clojure_A_const_75 any

var A_arbace_repr_clojure_A_const_76 *lang.Var

var A_arbace_repr_clojure_A_const_77 *lang.Var

var A_arbace_repr_clojure_A_const_78 *lang.Var

var A_arbace_repr_clojure_A_const_79 *lang.Var

var A_arbace_repr_clojure_A_const_80 *lang.Var

var A_arbace_repr_clojure_A_const_81 *lang.Keyword

var A_arbace_repr_clojure_A_const_82 *lang.Var

var A_arbace_repr_clojure_A_const_83 *lang.Var

var A_arbace_repr_clojure_A_const_84 *lang.Keyword

var A_arbace_repr_clojure_A_const_85 *lang.Var

var A_arbace_repr_clojure_A_const_86 *lang.Keyword

var A_arbace_repr_clojure_A_const_87 *lang.Var

var A_arbace_repr_clojure_A_const_88 *lang.Var

var A_arbace_repr_clojure_A_const_89 *lang.Var

var A_arbace_repr_clojure_A_const_90 *lang.Var

var A_arbace_repr_clojure_A_const_91 *lang.Var

var A_arbace_repr_clojure_A_const_92 *lang.Var

var A_arbace_repr_clojure_A_const_93 *lang.Keyword

var A_arbace_repr_clojure_A_const_94 *lang.Var

var A_arbace_repr_clojure_A_const_95 *lang.Var

var A_arbace_repr_clojure_A_const_96 *lang.Keyword

var A_arbace_repr_clojure_A_const_97 *lang.Keyword

var A_arbace_repr_clojure_A_const_98 *lang.Var

var A_arbace_repr_clojure_A_const_99 *lang.Keyword

var A_arbace_repr_clojure_A_const_100 *lang.Var

var A_arbace_repr_clojure_A_const_101 *lang.Var

var A_arbace_repr_clojure_A_const_102 *lang.Var

var A_arbace_repr_clojure_A_const_103 *lang.Var

var A_arbace_repr_clojure_A_const_104 *lang.Var

var A_arbace_repr_clojure_A_const_105 *lang.Var

var A_arbace_repr_clojure_A_const_106 *lang.Var

var A_arbace_repr_clojure_A_const_107 *lang.Var

var A_arbace_repr_clojure_A_const_108 *lang.Var

var A_arbace_repr_clojure_A_const_109 *lang.Keyword

var A_arbace_repr_clojure_A_const_110 *lang.Var

var A_arbace_repr_clojure_A_const_111 *lang.Var

var A_arbace_repr_clojure_A_const_112 *lang.Keyword

var A_arbace_repr_clojure_A_const_113 *lang.Keyword

var A_arbace_repr_clojure_A_const_114 *lang.Keyword

var A_arbace_repr_clojure_A_const_115 *lang.Var

var A_arbace_repr_clojure_A_const_116 *lang.Var

var A_arbace_repr_clojure_A_const_117 any

var A_arbace_repr_clojure_A_const_118 *lang.Var

var A_arbace_repr_clojure_A_const_119 *lang.Keyword

var A_arbace_repr_clojure_A_const_120 any

var A_arbace_repr_clojure_A_const_121 any

var A_arbace_repr_clojure_A_const_122 *lang.Var

var A_arbace_repr_clojure_A_const_123 *lang.Var

var A_arbace_repr_clojure_A_const_124 *lang.Var

var A_arbace_repr_clojure_A_const_125 any

var A_arbace_repr_clojure_A_const_126 *lang.Var

var A_arbace_repr_clojure_A_const_127 any

var A_arbace_repr_clojure_A_const_128 *lang.Keyword

var A_arbace_repr_clojure_A_const_129 *lang.Keyword

var A_arbace_repr_clojure_A_const_130 *lang.Keyword

var A_arbace_repr_clojure_A_const_131 *lang.Keyword

var A_arbace_repr_clojure_A_const_132 *lang.Var

var A_arbace_repr_clojure_A_const_133 any

var A_arbace_repr_clojure_A_const_134 *lang.Var

var A_arbace_repr_clojure_A_const_135 *lang.Keyword

var A_arbace_repr_clojure_A_const_136 any

var A_arbace_repr_clojure_A_const_137 any

var A_arbace_repr_clojure_A_const_138 any

var A_arbace_repr_clojure_A_const_139 *lang.Keyword

var A_arbace_repr_clojure_A_const_140 *lang.Keyword

var A_arbace_repr_clojure_A_const_141 *lang.Var

var A_arbace_repr_clojure_A_const_142 *lang.Keyword

var A_arbace_repr_clojure_A_const_143 *lang.Keyword

var A_arbace_repr_clojure_A_const_144 *lang.Var

var A_arbace_repr_clojure_A_const_145 *lang.Var

var A_arbace_repr_clojure_A_const_146 *lang.Var

var A_arbace_repr_clojure_A_const_147 *lang.Keyword

var A_arbace_repr_clojure_A_const_148 *lang.Keyword

var A_arbace_repr_clojure_A_const_149 *lang.Keyword

var A_arbace_repr_clojure_A_const_150 *lang.Keyword

var A_arbace_repr_clojure_A_const_151 *lang.Keyword

var A_arbace_repr_clojure_A_const_152 *lang.Keyword

var A_arbace_repr_clojure_A_const_153 *lang.Keyword

var A_arbace_repr_clojure_A_const_154 *lang.Keyword

var A_arbace_repr_clojure_A_const_155 *lang.Var

var A_arbace_repr_clojure_A_const_156 *lang.Var

var A_arbace_repr_clojure_A_const_157 any

var A_arbace_repr_clojure_A_const_158 *lang.Var

var A_arbace_repr_clojure_A_const_159 *lang.Var

var A_arbace_repr_clojure_A_const_160 *lang.Var

var A_arbace_repr_clojure_A_const_161 *lang.Keyword

var A_arbace_repr_clojure_A_const_162 any

var A_arbace_repr_clojure_A_const_163 *lang.Var

var A_arbace_repr_clojure_A_const_164 *lang.Keyword

var A_arbace_repr_clojure_A_const_165 *lang.Keyword

var A_arbace_repr_clojure_A_const_166 *lang.Keyword

var A_arbace_repr_clojure_A_const_167 any

var A_arbace_repr_clojure_A_const_168 *lang.Keyword

var A_arbace_repr_clojure_A_const_169 *lang.Keyword

var A_arbace_repr_clojure_A_const_170 *lang.Keyword

var A_arbace_repr_clojure_A_const_171 any

var A_arbace_repr_clojure_A_const_172 *lang.Var

var A_arbace_repr_clojure_A_const_173 any

var A_arbace_repr_clojure_A_const_174 *lang.Var

var A_arbace_repr_clojure_A_const_175 *lang.Var

var A_arbace_repr_clojure_A_const_176 *lang.Var

var A_arbace_repr_clojure_A_const_177 *lang.Var

var A_arbace_repr_clojure_A_const_178 *lang.Var

var A_arbace_repr_clojure_A_const_179 *lang.Keyword

var A_arbace_repr_clojure_A_const_180 *lang.Var

var A_arbace_repr_clojure_A_const_181 *lang.Var

var A_arbace_repr_clojure_A_const_182 *lang.Var

var A_arbace_repr_clojure_A_const_183 *lang.Var

var A_arbace_repr_clojure_A_const_184 any

var A_arbace_repr_clojure_A_const_185 *lang.Var

var A_arbace_repr_clojure_A_const_186 *lang.Var

var A_arbace_repr_clojure_A_const_187 *lang.Var

var A_arbace_repr_clojure_A_const_188 *lang.Var

var A_arbace_repr_clojure_A_const_189 *lang.Keyword

var A_arbace_repr_clojure_A_const_190 *lang.Var

var A_arbace_repr_clojure_A_const_191 *lang.Var

var A_arbace_repr_clojure_A_const_192 *lang.Var

var A_arbace_repr_clojure_A_const_193 *lang.Var

var A_arbace_repr_clojure_A_const_194 *lang.Keyword

var A_arbace_repr_clojure_A_init jrt.ClassInit

func A_arbace_repr_clojure_A_Init() { if !A_arbace_repr_clojure_A_init.Done() { A_arbace_repr_clojure_A_init.Run(A_arbace_repr_clojure_A_clinit) } }

func A_arbace_repr_clojure_A_clinit() { A_arbace_repr_clojure_A_clinit_p0(); A_arbace_repr_clojure_A_clinit_p1(); A_arbace_repr_clojure_A_clinit_p2(); A_arbace_repr_clojure_A_clinit_p3(); A_arbace_repr_clojure_A_clinit_p4(); A_arbace_repr_clojure_A_clinit_p5(); A_arbace_repr_clojure_A_clinit_p6(); A_arbace_repr_clojure_A_clinit_p7(); A_arbace_repr_clojure_A_clinit_p8(); A_arbace_repr_clojure_A_clinit_p9(); A_arbace_repr_clojure_A_clinit_p10(); A_arbace_repr_clojure_A_clinit_p11(); A_arbace_repr_clojure_A_clinit_p12(); A_arbace_repr_clojure_A_clinit_p13(); A_arbace_repr_clojure_A_clinit_p14(); A_arbace_repr_clojure_A_clinit_p15(); A_arbace_repr_clojure_A_clinit_p16() }

func A_arbace_repr_clojure_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_clojure_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 260); A_arbace_repr_clojure_A_const_0 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[65]); A_arbace_repr_clojure_A_const_1 = A_arbace_repr_clojure_A_const_pool.A[66]; A_arbace_repr_clojure_A_const_2 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[67]); A_arbace_repr_clojure_A_const_3 = A_arbace_repr_clojure_A_const_pool.A[68]; A_arbace_repr_clojure_A_const_4 = A_arbace_repr_clojure_A_const_pool.A[69]; A_arbace_repr_clojure_A_const_5 = A_arbace_repr_clojure_A_const_pool.A[70]; A_arbace_repr_clojure_A_const_6 = A_arbace_repr_clojure_A_const_pool.A[71]; A_arbace_repr_clojure_A_const_7 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[72]); A_arbace_repr_clojure_A_const_8 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[73]); A_arbace_repr_clojure_A_const_9 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[74]); A_arbace_repr_clojure_A_const_10 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[75]); A_arbace_repr_clojure_A_const_11 = A_arbace_repr_clojure_A_const_pool.A[76] }

func A_arbace_repr_clojure_A_clinit_p1() { A_arbace_repr_clojure_A_const_12 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[77]); A_arbace_repr_clojure_A_const_13 = A_arbace_repr_clojure_A_const_pool.A[78]; A_arbace_repr_clojure_A_const_14 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[79]); A_arbace_repr_clojure_A_const_15 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[80]); A_arbace_repr_clojure_A_const_16 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[81]); A_arbace_repr_clojure_A_const_17 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[82]); A_arbace_repr_clojure_A_const_18 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[83]); A_arbace_repr_clojure_A_const_19 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[84]); A_arbace_repr_clojure_A_const_20 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[85]); A_arbace_repr_clojure_A_const_21 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[86]); A_arbace_repr_clojure_A_const_22 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[87]); A_arbace_repr_clojure_A_const_23 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[88]) }

func A_arbace_repr_clojure_A_clinit_p2() { A_arbace_repr_clojure_A_const_24 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[89]); A_arbace_repr_clojure_A_const_25 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[90]); A_arbace_repr_clojure_A_const_26 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[91]); A_arbace_repr_clojure_A_const_27 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[92]); A_arbace_repr_clojure_A_const_28 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[93]); A_arbace_repr_clojure_A_const_29 = A_arbace_repr_clojure_A_const_pool.A[94]; A_arbace_repr_clojure_A_const_30 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[95]); A_arbace_repr_clojure_A_const_31 = A_arbace_repr_clojure_A_const_pool.A[96]; A_arbace_repr_clojure_A_const_32 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[97]); A_arbace_repr_clojure_A_const_33 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[98]); A_arbace_repr_clojure_A_const_34 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[99]); A_arbace_repr_clojure_A_const_35 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[100]) }

func A_arbace_repr_clojure_A_clinit_p3() { A_arbace_repr_clojure_A_const_36 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[101]); A_arbace_repr_clojure_A_const_37 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[102]); A_arbace_repr_clojure_A_const_38 = A_arbace_repr_clojure_A_const_pool.A[103]; A_arbace_repr_clojure_A_const_39 = A_arbace_repr_clojure_A_const_pool.A[104]; A_arbace_repr_clojure_A_const_40 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[105]); A_arbace_repr_clojure_A_const_41 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[106]); A_arbace_repr_clojure_A_const_42 = A_arbace_repr_clojure_A_const_pool.A[107]; A_arbace_repr_clojure_A_const_43 = A_arbace_repr_clojure_A_const_pool.A[108]; A_arbace_repr_clojure_A_const_44 = A_arbace_repr_clojure_A_const_pool.A[109]; A_arbace_repr_clojure_A_const_45 = A_arbace_repr_clojure_A_const_pool.A[110]; A_arbace_repr_clojure_A_const_46 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[111]); A_arbace_repr_clojure_A_const_47 = A_arbace_repr_clojure_A_const_pool.A[112]; A_arbace_repr_clojure_A_const_48 = A_arbace_repr_clojure_A_const_pool.A[113]; A_arbace_repr_clojure_A_const_49 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[114]) }

func A_arbace_repr_clojure_A_clinit_p4() { A_arbace_repr_clojure_A_const_50 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[115]); A_arbace_repr_clojure_A_const_51 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[116]); A_arbace_repr_clojure_A_const_52 = A_arbace_repr_clojure_A_const_pool.A[117]; A_arbace_repr_clojure_A_const_53 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[118]); A_arbace_repr_clojure_A_const_54 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[119]); A_arbace_repr_clojure_A_const_55 = A_arbace_repr_clojure_A_const_pool.A[120]; A_arbace_repr_clojure_A_const_56 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[121]); A_arbace_repr_clojure_A_const_57 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[122]); A_arbace_repr_clojure_A_const_58 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[123]); A_arbace_repr_clojure_A_const_59 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[124]); A_arbace_repr_clojure_A_const_60 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[125]); A_arbace_repr_clojure_A_const_61 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[126]) }

func A_arbace_repr_clojure_A_clinit_p5() { A_arbace_repr_clojure_A_const_62 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[127]); A_arbace_repr_clojure_A_const_63 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[128]); A_arbace_repr_clojure_A_const_64 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[129]); A_arbace_repr_clojure_A_const_65 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[130]); A_arbace_repr_clojure_A_const_66 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[131]); A_arbace_repr_clojure_A_const_67 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[132]); A_arbace_repr_clojure_A_const_68 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[133]); A_arbace_repr_clojure_A_const_69 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[134]); A_arbace_repr_clojure_A_const_70 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[135]); A_arbace_repr_clojure_A_const_71 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[136]); A_arbace_repr_clojure_A_const_72 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[137]); A_arbace_repr_clojure_A_const_73 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[138]) }

func A_arbace_repr_clojure_A_clinit_p6() { A_arbace_repr_clojure_A_const_74 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[139]); A_arbace_repr_clojure_A_const_75 = A_arbace_repr_clojure_A_const_pool.A[140]; A_arbace_repr_clojure_A_const_76 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[141]); A_arbace_repr_clojure_A_const_77 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[142]); A_arbace_repr_clojure_A_const_78 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[143]); A_arbace_repr_clojure_A_const_79 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[144]); A_arbace_repr_clojure_A_const_80 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[145]); A_arbace_repr_clojure_A_const_81 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[146]); A_arbace_repr_clojure_A_const_82 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[147]); A_arbace_repr_clojure_A_const_83 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[148]); A_arbace_repr_clojure_A_const_84 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[149]); A_arbace_repr_clojure_A_const_85 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[150]) }

func A_arbace_repr_clojure_A_clinit_p7() { A_arbace_repr_clojure_A_const_86 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[151]); A_arbace_repr_clojure_A_const_87 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[152]); A_arbace_repr_clojure_A_const_88 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[153]); A_arbace_repr_clojure_A_const_89 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[154]); A_arbace_repr_clojure_A_const_90 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[155]); A_arbace_repr_clojure_A_const_91 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[156]); A_arbace_repr_clojure_A_const_92 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[157]); A_arbace_repr_clojure_A_const_93 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[158]); A_arbace_repr_clojure_A_const_94 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[159]); A_arbace_repr_clojure_A_const_95 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[160]); A_arbace_repr_clojure_A_const_96 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[161]); A_arbace_repr_clojure_A_const_97 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[162]) }

func A_arbace_repr_clojure_A_clinit_p8() { A_arbace_repr_clojure_A_const_98 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[163]); A_arbace_repr_clojure_A_const_99 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[164]); A_arbace_repr_clojure_A_const_100 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[165]); A_arbace_repr_clojure_A_const_101 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[166]); A_arbace_repr_clojure_A_const_102 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[167]); A_arbace_repr_clojure_A_const_103 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[168]); A_arbace_repr_clojure_A_const_104 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[169]); A_arbace_repr_clojure_A_const_105 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[170]); A_arbace_repr_clojure_A_const_106 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[171]); A_arbace_repr_clojure_A_const_107 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[172]); A_arbace_repr_clojure_A_const_108 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[173]); A_arbace_repr_clojure_A_const_109 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[174]) }

func A_arbace_repr_clojure_A_clinit_p9() { A_arbace_repr_clojure_A_const_110 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[175]); A_arbace_repr_clojure_A_const_111 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[176]); A_arbace_repr_clojure_A_const_112 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[177]); A_arbace_repr_clojure_A_const_113 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[178]); A_arbace_repr_clojure_A_const_114 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[179]); A_arbace_repr_clojure_A_const_115 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[180]); A_arbace_repr_clojure_A_const_116 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[181]); A_arbace_repr_clojure_A_const_117 = A_arbace_repr_clojure_A_const_pool.A[182]; A_arbace_repr_clojure_A_const_118 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[183]); A_arbace_repr_clojure_A_const_119 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[184]); A_arbace_repr_clojure_A_const_120 = A_arbace_repr_clojure_A_const_pool.A[185]; A_arbace_repr_clojure_A_const_121 = A_arbace_repr_clojure_A_const_pool.A[186] }

func A_arbace_repr_clojure_A_clinit_p10() { A_arbace_repr_clojure_A_const_122 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[187]); A_arbace_repr_clojure_A_const_123 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[188]); A_arbace_repr_clojure_A_const_124 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[189]); A_arbace_repr_clojure_A_const_125 = A_arbace_repr_clojure_A_const_pool.A[190]; A_arbace_repr_clojure_A_const_126 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[191]); A_arbace_repr_clojure_A_const_127 = A_arbace_repr_clojure_A_const_pool.A[192]; A_arbace_repr_clojure_A_const_128 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[193]); A_arbace_repr_clojure_A_const_129 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[194]); A_arbace_repr_clojure_A_const_130 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[195]); A_arbace_repr_clojure_A_const_131 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[196]); A_arbace_repr_clojure_A_const_132 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[197]); A_arbace_repr_clojure_A_const_133 = A_arbace_repr_clojure_A_const_pool.A[198] }

func A_arbace_repr_clojure_A_clinit_p11() { A_arbace_repr_clojure_A_const_134 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[199]); A_arbace_repr_clojure_A_const_135 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[200]); A_arbace_repr_clojure_A_const_136 = A_arbace_repr_clojure_A_const_pool.A[201]; A_arbace_repr_clojure_A_const_137 = A_arbace_repr_clojure_A_const_pool.A[202]; A_arbace_repr_clojure_A_const_138 = A_arbace_repr_clojure_A_const_pool.A[203]; A_arbace_repr_clojure_A_const_139 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[204]); A_arbace_repr_clojure_A_const_140 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[205]); A_arbace_repr_clojure_A_const_141 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[206]); A_arbace_repr_clojure_A_const_142 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[207]); A_arbace_repr_clojure_A_const_143 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[208]); A_arbace_repr_clojure_A_const_144 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[209]); A_arbace_repr_clojure_A_const_145 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[210]) }

func A_arbace_repr_clojure_A_clinit_p12() { A_arbace_repr_clojure_A_const_146 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[211]); A_arbace_repr_clojure_A_const_147 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[212]); A_arbace_repr_clojure_A_const_148 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[213]); A_arbace_repr_clojure_A_const_149 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[214]); A_arbace_repr_clojure_A_const_150 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[215]); A_arbace_repr_clojure_A_const_151 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[216]); A_arbace_repr_clojure_A_const_152 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[217]); A_arbace_repr_clojure_A_const_153 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[218]); A_arbace_repr_clojure_A_const_154 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[219]); A_arbace_repr_clojure_A_const_155 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[220]); A_arbace_repr_clojure_A_const_156 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[221]); A_arbace_repr_clojure_A_const_157 = A_arbace_repr_clojure_A_const_pool.A[222] }

func A_arbace_repr_clojure_A_clinit_p13() { A_arbace_repr_clojure_A_const_158 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[223]); A_arbace_repr_clojure_A_const_159 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[224]); A_arbace_repr_clojure_A_const_160 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[225]); A_arbace_repr_clojure_A_const_161 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[226]); A_arbace_repr_clojure_A_const_162 = A_arbace_repr_clojure_A_const_pool.A[227]; A_arbace_repr_clojure_A_const_163 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[228]); A_arbace_repr_clojure_A_const_164 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[229]); A_arbace_repr_clojure_A_const_165 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[230]); A_arbace_repr_clojure_A_const_166 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[231]); A_arbace_repr_clojure_A_const_167 = A_arbace_repr_clojure_A_const_pool.A[232]; A_arbace_repr_clojure_A_const_168 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[233]); A_arbace_repr_clojure_A_const_169 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[234]) }

func A_arbace_repr_clojure_A_clinit_p14() { A_arbace_repr_clojure_A_const_170 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[235]); A_arbace_repr_clojure_A_const_171 = A_arbace_repr_clojure_A_const_pool.A[236]; A_arbace_repr_clojure_A_const_172 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[237]); A_arbace_repr_clojure_A_const_173 = A_arbace_repr_clojure_A_const_pool.A[238]; A_arbace_repr_clojure_A_const_174 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[239]); A_arbace_repr_clojure_A_const_175 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[240]); A_arbace_repr_clojure_A_const_176 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[241]); A_arbace_repr_clojure_A_const_177 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[242]); A_arbace_repr_clojure_A_const_178 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[243]); A_arbace_repr_clojure_A_const_179 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[244]); A_arbace_repr_clojure_A_const_180 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[245]); A_arbace_repr_clojure_A_const_181 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[246]) }

func A_arbace_repr_clojure_A_clinit_p15() { A_arbace_repr_clojure_A_const_182 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[247]); A_arbace_repr_clojure_A_const_183 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[248]); A_arbace_repr_clojure_A_const_184 = A_arbace_repr_clojure_A_const_pool.A[249]; A_arbace_repr_clojure_A_const_185 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[250]); A_arbace_repr_clojure_A_const_186 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[251]); A_arbace_repr_clojure_A_const_187 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[252]); A_arbace_repr_clojure_A_const_188 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[253]); A_arbace_repr_clojure_A_const_189 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[254]); A_arbace_repr_clojure_A_const_190 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[255]); A_arbace_repr_clojure_A_const_191 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[256]); A_arbace_repr_clojure_A_const_192 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[257]); A_arbace_repr_clojure_A_const_193 = lang.Var_Cast(A_arbace_repr_clojure_A_const_pool.A[258]) }

func A_arbace_repr_clojure_A_clinit_p16() { A_arbace_repr_clojure_A_const_194 = lang.Keyword_Cast(A_arbace_repr_clojure_A_const_pool.A[259]) }

func A_arbace_repr_clojure_A_New() *A_arbace_repr_clojure_A { A_arbace_repr_clojure_A_Init(); t := &A_arbace_repr_clojure_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_A) Ctor() {}

func (t *A_arbace_repr_clojure_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_A_class }

func (t *A_arbace_repr_clojure_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_A); return ok }

func A_arbace_repr_clojure_A_Cast(x any) *A_arbace_repr_clojure_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_A_class)) }; return v }



type A_arbace_repr_clojure__main_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure__main_A_fn_class *jrt.Class



type A_arbace_repr_clojure__main_fn__716000316_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure__main_fn__716000316_A_fn_class *jrt.Class



type A_arbace_repr_clojure__main_fn__716000318_A struct{ j2g_header uint64; F_s, F_verb any }

var A_arbace_repr_clojure__main_fn__716000318_A_fn_class *jrt.Class



type A_arbace_repr_clojure_base_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_base_A_fn_class *jrt.Class



type A_arbace_repr_clojure_eval716000004_A struct{ jrt.Object }

func A_arbace_repr_clojure_eval716000004_A_New() *A_arbace_repr_clojure_eval716000004_A { t := &A_arbace_repr_clojure_eval716000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_eval716000004_A) Ctor() {}

func (t *A_arbace_repr_clojure_eval716000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_eval716000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_eval716000004_A_class }

func (t *A_arbace_repr_clojure_eval716000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_eval716000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_eval716000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_eval716000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_eval716000004_A); return ok }

func A_arbace_repr_clojure_eval716000004_A_Cast(x any) *A_arbace_repr_clojure_eval716000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_eval716000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_eval716000004_A_class)) }; return v }



type A_arbace_repr_clojure_eval716000004_loading__1927001464__auto____716000005_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_eval716000004_loading__1927001464__auto____716000005_A_fn_class *jrt.Class



type A_arbace_repr_clojure_eval716000008_A struct{ jrt.Object }

func A_arbace_repr_clojure_eval716000008_A_New() *A_arbace_repr_clojure_eval716000008_A { t := &A_arbace_repr_clojure_eval716000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure_eval716000008_A) Ctor() {}

func (t *A_arbace_repr_clojure_eval716000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure_eval716000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure_eval716000008_A_class }

func (t *A_arbace_repr_clojure_eval716000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure_eval716000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure_eval716000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure_eval716000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure_eval716000008_A); return ok }

func A_arbace_repr_clojure_eval716000008_A_Cast(x any) *A_arbace_repr_clojure_eval716000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure_eval716000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure_eval716000008_A_class)) }; return v }



type A_arbace_repr_clojure_eval716000008_fn__716000009_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_eval716000008_fn__716000009_A_fn_class *jrt.Class



type A_arbace_repr_clojure_ext_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_ext_A_fn_class *jrt.Class



type A_arbace_repr_clojure_files_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_files_A_fn_class *jrt.Class



type A_arbace_repr_clojure_files_iter__716000033__716000037_A struct{ j2g_header uint64; F_root, F_src any }

var A_arbace_repr_clojure_files_iter__716000033__716000037_A_fn_class *jrt.Class



type A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_A struct{ j2g_header uint64; F_root, F_src, F_iter__716000033, F_s__716000034 any }

var A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_A_fn_class *jrt.Class



type A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_fn__716000039_A struct{ j2g_header uint64; F_root, F_src, F_b__716000036 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_clojure_files_iter__716000033__716000037_fn__716000038_fn__716000039_A_fn_class *jrt.Class



type A_arbace_repr_clojure_first_difference_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_first_difference_A_fn_class *jrt.Class



type A_arbace_repr_clojure_first_difference_fn__716000143_A struct{ j2g_header uint64; F_a, F_b any; F_n int64 }

var A_arbace_repr_clojure_first_difference_fn__716000143_A_fn_class *jrt.Class



type A_arbace_repr_clojure_first_difference_fn__716000145_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_first_difference_fn__716000145_A_fn_class *jrt.Class



type A_arbace_repr_clojure_first_difference_ln__716000147_A struct{ j2g_header uint64; F_i any }

var A_arbace_repr_clojure_first_difference_ln__716000147_A_fn_class *jrt.Class



type A_arbace_repr_clojure_fn__716000031_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_fn__716000031_A_fn_class *jrt.Class



type A_arbace_repr_clojure_half_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_half_A_fn_class *jrt.Class



type A_arbace_repr_clojure_half_fn__716000125_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_half_fn__716000125_A_fn_class *jrt.Class



type A_arbace_repr_clojure_half_fn__716000128_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_half_fn__716000128_A_fn_class *jrt.Class



type A_arbace_repr_clojure_half_fn__716000134_A struct{ j2g_header uint64; F_plan, F_refine, F_translate_text, F_opts, F_dirs any }

var A_arbace_repr_clojure_half_fn__716000134_A_fn_class *jrt.Class



type A_arbace_repr_clojure_half_fn__716000134_fn__716000138_A struct{ j2g_header uint64; F_p, F_s, F_rel, F_translate_text, F_opts any }

var A_arbace_repr_clojure_half_fn__716000134_fn__716000138_A_fn_class *jrt.Class



type A_arbace_repr_clojure_name_of_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_name_of_A_fn_class *jrt.Class



type A_arbace_repr_clojure_parent_of_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_parent_of_A_fn_class *jrt.Class



type A_arbace_repr_clojure_parse_args_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_parse_args_A_fn_class *jrt.Class



type A_arbace_repr_clojure_plan_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_plan_A_fn_class *jrt.Class



type A_arbace_repr_clojure_plan_fn__716000018_A struct{ j2g_header uint64; F_name any }

var A_arbace_repr_clojure_plan_fn__716000018_A_fn_class *jrt.Class



type A_arbace_repr_clojure_print_plan_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_print_plan_A_fn_class *jrt.Class



type A_arbace_repr_clojure_print_plan_fn__716000025_A struct{ j2g_header uint64; F_name any }

var A_arbace_repr_clojure_print_plan_fn__716000025_A_fn_class *jrt.Class



type A_arbace_repr_clojure_print_refine_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_print_refine_A_fn_class *jrt.Class



type A_arbace_repr_clojure_print_rules_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_print_rules_A_fn_class *jrt.Class



type A_arbace_repr_clojure_print_text_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_print_text_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_roundtrip_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_A struct{ j2g_header uint64; F_iter__716000153, F_s__716000154 any }

var A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_fn__716000159_A struct{ j2g_header uint64; F_b__716000156 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_clojure_roundtrip_iter__716000153__716000157_fn__716000158_fn__716000159_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_A struct{ j2g_header uint64; F_s__716000170, F_iter__716000169 any }

var A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_fn__716000175_A struct{ j2g_header uint64; F_b__716000172 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_clojure_roundtrip_iter__716000169__716000173_fn__716000174_fn__716000175_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_A struct{ j2g_header uint64; F_back2, F_t, F_a, F_b, F_c, F_back, F_opts any }

var A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_A struct{ j2g_header uint64; F_back2, F_iter__716000185, F_s__716000186, F_t, F_a, F_b, F_c, F_back, F_opts any }

var A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_fn__716000191_A struct{ j2g_header uint64; F_back2, F_t, F_b__716000188, F_a, F_b, F_c any; F_size__1927001038__auto__ int32; F_back, F_opts, F_c__1927001037__auto__ any }

var A_arbace_repr_clojure_roundtrip_iter__716000185__716000189_fn__716000190_fn__716000191_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_A struct{ j2g_header uint64; F_iter__716000201, F_s__716000202 any }

var A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_fn__716000207_A struct{ j2g_header uint64; F_b__716000204 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_clojure_roundtrip_iter__716000201__716000205_fn__716000206_fn__716000207_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_A struct{ j2g_header uint64; F_a any }

var A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_A struct{ j2g_header uint64; F_iter__716000217, F_s__716000218, F_a any }

var A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_fn__716000223_A struct{ j2g_header uint64; F_b__716000220, F_a any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_clojure_roundtrip_iter__716000217__716000221_fn__716000222_fn__716000223_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrips_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_roundtrips_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrips_fn__716000257_A struct{ j2g_header uint64; F_opts any }

var A_arbace_repr_clojure_roundtrips_fn__716000257_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_A struct{ j2g_header uint64; F_n any }

var A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_A struct{ j2g_header uint64; F_iter__716000258, F_n, F_s__716000259 any }

var A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_A_fn_class *jrt.Class



type A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_fn__716000264_A struct{ j2g_header uint64; F_n, F_b__716000261 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_clojure_roundtrips_fn__716000257_iter__716000258__716000262_fn__716000263_fn__716000264_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_run_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000046_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_run_fn__716000046_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000063_A struct{ j2g_header uint64; F_f, F_p any }

var A_arbace_repr_clojure_run_fn__716000063_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000065_A struct{ j2g_header uint64; F_f, F_p, F_stats, F_s, F_translate_text, F_skip any }

var A_arbace_repr_clojure_run_fn__716000065_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000065_fn__716000066_A struct{ j2g_header uint64; F_e, F_f any }

var A_arbace_repr_clojure_run_fn__716000065_fn__716000066_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000072_A struct{ j2g_header uint64; F_f, F_p any }

var A_arbace_repr_clojure_run_fn__716000072_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000074_A struct{ j2g_header uint64; F_f, F_p, F_s, F_stats, F_translate_text, F_skip any }

var A_arbace_repr_clojure_run_fn__716000074_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000074_fn__716000075_A struct{ j2g_header uint64; F_e, F_f any }

var A_arbace_repr_clojure_run_fn__716000074_fn__716000075_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000081_A struct{ j2g_header uint64; F_f, F_p any }

var A_arbace_repr_clojure_run_fn__716000081_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000083_A struct{ j2g_header uint64; F_f, F_p, F_s, F_stats, F_translate_text, F_skip any }

var A_arbace_repr_clojure_run_fn__716000083_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000083_fn__716000084_A struct{ j2g_header uint64; F_e, F_f any }

var A_arbace_repr_clojure_run_fn__716000083_fn__716000084_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000090_A struct{ j2g_header uint64; F_f, F_p any }

var A_arbace_repr_clojure_run_fn__716000090_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000092_A struct{ j2g_header uint64; F_f, F_p, F_s, F_stats, F_translate_text, F_skip any }

var A_arbace_repr_clojure_run_fn__716000092_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_fn__716000092_fn__716000093_A struct{ j2g_header uint64; F_e, F_f any }

var A_arbace_repr_clojure_run_fn__716000092_fn__716000093_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_roundtrip_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_run_roundtrip_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_roundtrip_fn__716000280_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_run_roundtrip_fn__716000280_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_roundtrip_fn__716000282_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_run_roundtrip_fn__716000282_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_roundtrip_fn__716000284_A struct{ j2g_header uint64; F_known any }

var A_arbace_repr_clojure_run_roundtrip_fn__716000284_A_fn_class *jrt.Class



type A_arbace_repr_clojure_run_roundtrip_fn__716000286_A struct{ j2g_header uint64; F_diff any }

var A_arbace_repr_clojure_run_roundtrip_fn__716000286_A_fn_class *jrt.Class



type A_arbace_repr_clojure_translate_text_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_translate_text_A_fn_class *jrt.Class



type A_arbace_repr_clojure_tree_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_tree_A_fn_class *jrt.Class



type A_arbace_repr_clojure_tree_iter__716000097__716000103_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_tree_iter__716000097__716000103_A_fn_class *jrt.Class



type A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_A struct{ j2g_header uint64; F_iter__716000097, F_s__716000098 any }

var A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_A_fn_class *jrt.Class



type A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_A_fn_class *jrt.Class



type A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_A struct{ j2g_header uint64; F_iter__716000099, F_s__716000100 any }

var A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_A_fn_class *jrt.Class



type A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_fn__716000107_A struct{ j2g_header uint64; F_b__716000102 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_clojure_tree_iter__716000097__716000103_fn__716000104_iter__716000099__716000105_fn__716000106_fn__716000107_A_fn_class *jrt.Class



type A_arbace_repr_clojure_under_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_under_A_fn_class *jrt.Class



type A_arbace_repr_clojure_usage_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_usage_A_fn_class *jrt.Class



type A_arbace_repr_clojure_usage_fn__716000254_A struct{ j2g_header uint64 }

var A_arbace_repr_clojure_usage_fn__716000254_A_fn_class *jrt.Class
