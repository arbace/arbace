//line j2g_strings.ae:1
package aot_arbace_repr_clojure

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn25,arbace.repr.clojure.ruleskn2,asyn5,rulesyn24,arbace.repr.clojure.textyn4,textyn14,arbace.java.ioyn2,ioyn13,arbace.stringyn3,strkn3,dockn8,keep-extkn4,textkn4,fullkn4,kindkn4,cljckn3,cljkn5,to-aekn3,outkn4,skipkn4,elsekn4,javakn4,copykn8,featureskn4,pathkn4,plankn6,refinekn10,translatedkn6,copiedkn7,skippedkn9,unchangedkn6,errorskn4,readkn4,treekn4,fromkn5,planskn5,errorkn6,arbacekn5,printkn3,whykn7,missingkn4,namekn2,atkn7,one-waykn8,not-readkn5,fileskn5,equalkn6,differkn7,sourceskn8,in-placekn5,stdinkn5,ruleskn2,aekn5,quietkn7,verbosekn5,knownkn6,corpuskn4,losskn2,idkn3,waykn10,divergencekn4,nonekn4,ruleyn19,arbace.repr.clojurekn9,roundtripv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn19,arbace.repr.clojurem2,R10,s3844,repr/clojure, Clojure's bridge (doc/REPR-CLOJURE.md; c2a until 2026-10-17): read, Clojure\n  source files or trees rewritten into Arbace's by the rules of arbace.repr.clojure.rules, their\n  layout and comments kept; print, Arbace's back into Clojure's, each rule reversed (a text\n  round trip). bin/repr-clojure runs it.\n\n    read [OPTION...] -o OUT SRC...       translate files and trees into the directory OUT\n    read --in-place [OPTION...] SRC...   translate them where they are\n    read --stdin [--kind K] [--ae]       translate standard input to standard output\n    read --rules                         list the rules (and how print reverses each) and the\n                                         dialect divergences\n    print [OPTION...] -o OUT SRC...      print Arbace files and trees back as Clojure into OUT\n    print --in-place [OPTION...] SRC...  print them where they are (x.ae becomes x.clj)\n    print --stdin [--kind K] [--ae]      print standard input to standard output\n    roundtrip [OPTION...] SRC...         read then print each tree in memory (--from-arbace:\n                                         print then read), every file back byte for byte\n\n  A directory SRC is translated into OUT with its relative paths (its contents, not itself).\n  read: .clj and .cljc files become .ae files: a .cljc file's reader conditionals resolved for\n  Arbace's features (#{:clj}); a .clj and a .cljc of the same name give the .clj's .ae (the\n  reader prefers the .clj), and a .ae already there is kept as it is (the reader prefers it).\n  data_readers.clj/.cljc become data_readers.ae too (Arbace reads it first), but as Arbace reads\n  all three and merges them, one that would collide keeps its name: a data_readers.clj beside a\n  data_readers.ae, a data_readers.cljc beside either. project.clj keeps its name. .java files\n  are renamed as text and keep their names (repr/java reads them). With -o, other files are copied\n  as they are, but class files (AOT output cannot be translated: their sources are); in place,\n  they stay.\n  print: the same plan reversed (print-plan): .ae files become .clj files (data_readers.ae a\n  data_readers.cljc beside a data_readers.clj); .clj and .cljc files are printed keeping their\n  names, but one beside a .ae of its name is left out; .java and --text files as read's. What\n  print cannot restore (the one-way rules, :reader-conditionals and :security-manager) is\n  listed by read --rules; a .ae that read --full made from a .cljc (its conditionals recorded\n  in a comment block at its end) is printed as that .cljc, byte for byte.\n\n  Options:\n    --keep-ext       read: .clj and .cljc files keep their names (and so a .cljc its\n                     conditionals, which Arbace's reader resolves with the feature :clj), as\n                     bin/clojure-tests translates Clojure's test suite; roundtrip: read so\n    --full           read: a .cljc file becoming a .ae records its reader conditionals in a\n                     comment block at the .ae's end (the .ae reads as without it), from which\n                     print gives the .cljc back byte for byte; roundtrip: read so\n    --text EXT       files ending in EXT are renamed as text (rule :rename and the like) too,\n                     keeping their names (repeatable; e.g. --text .edn)\n    --skip ID,...    leave these rules out\n    --kind K         --stdin's kind: clj (default), cljc, java or text (the Clojure file's)\n    --ae             --stdin: the Clojure text is a .ae file's (a .cljc's conditionals resolved;\n                     print: a record of read --full's restored)\n    -q               quiet: no summary\n    roundtrip's: --from-arbace; --known EDN --corpus NAME, the known differences ({corpus {path\n    reason}}; exit status 1 on another, or on one that no longer differs); -v, each\n    difference's first differing linev11,arbace.core4,subsl0,v11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core3,seqv11,arbace.core5,firstR11,R12,R13,v19,arbace.repr.clojure3,extv11,arbace.core9,contains?v19,arbace.repr.clojure10,keep-namesR14,R15,R16,R17,R18,S2,s5,.cljcs4,.cljv11,arbace.core7,keywordl1,v19,arbace.repr.clojure4,baseR19,R20,R21,v11,arbace.core4,somev13,arbace.string10,ends-with?m2,R19,s46,a class file (AOT output) cannot be translatedm2,R22,Tv11,arbace.core5,assocv11,arbace.core3,notm6,R14,R16,R17,TR18,s16,data_readers.cljm6,R14,R16,R17,TR18,s17,data_readers.cljcm2,R19,s53,data_readers.clj and data_readers.cljc are both thereS2,s5,.cljcs4,.cljv11,arbace.core4,not=m2,R19,s30,a class file cannot be printedm2,R22,Tv25,arbace.repr.clojure.rules5,full?v25,arbace.repr.clojure.rules9,translateR23,S1,R16,R24,v25,arbace.repr.clojure.rules10,print-textS1,R16,v11,arbace.core7,sort-byv11,arbace.core6,secondv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core3,strv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv11,arbace.core4,restv11,arbace.core8,file-seqv19,arbace.repr.clojure5,verbsR25,R26,v11,arbace.core7,memoizev11,arbace.core3,setv11,arbace.core4,atomm12,R27,l0,R17,l0,R28,l0,R29,l0,R30,l0,R31,l0,v14,arbace.java.io4,filev19,arbace.repr.clojure5,filesv11,arbace.core5,slurpv11,arbace.core7,printlnv11,arbace.core19,pop-thread-bindingsR22,v11,arbace.core5,swap!v11,arbace.core6,updateR28,v11,arbace.core3,incR31,v11,arbace.core10,ex-messagev11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core5,*out*v11,arbace.core5,*err*v11,arbace.core4,spitR29,v14,arbace.java.io4,copyv14,arbace.java.io12,make-parentsR30,R27,v19,arbace.repr.clojure3,runR32,v11,arbace.core4,intov11,arbace.core10,sorted-mapv11,arbace.core6,concatv11,arbace.core6,reducev19,arbace.repr.clojure9,parent-ofv11,arbace.core4,fnilv19,arbace.repr.clojure7,name-ofv11,arbace.core4,keysv11,arbace.core8,assoc-inR33,v19,arbace.repr.clojure5,underv11,arbace.core7,string?R34,R35,R36,v11,arbace.core4,pmapv11,arbace.core6,filterc10,v11,arbace.core6,pr-strR37,V2,R38,R32,V2,R32,R38,v19,arbace.repr.clojure4,treev19,arbace.repr.clojure4,halfv11,arbace.core6,get-inm2,R39,R40,v24,arbace.repr.clojure.text20,resolve-conditionalsS1,R16,R39,R41,R2,R42,v19,arbace.repr.clojure16,first-differencem2,R39,R43,v19,arbace.repr.clojure14,translate-textR44,m2,R39,R40,S1,R16,m2,R39,R43,R45,R46,v11,arbace.core6,removeR47,R48,v11,arbace.core6,empty?v13,arbace.string12,starts-with?v11,arbace.core7,ex-infoR49,R50,R51,R52,R53,R54,R55,R56,v11,arbace.core3,mapv13,arbace.string5,splitp1,,v25,arbace.repr.clojure.rules11,divergencesv25,arbace.repr.clojure.rules5,rulesv13,arbace.string7,replaceR57,p3,\\s+v11,arbace.core4,nameR58,R59,R10,p3,\\s+R60,R61,R62,p3,\\s+v11,arbace.core6,the-nsR63,v19,arbace.repr.clojure9,roundtripv11,arbace.core1,+v19,arbace.repr.clojure10,roundtripsv11,arbace.core11,read-stringv11,arbace.core3,valR43,v11,arbace.core5,applyv11,arbace.core6,dissocv11,arbace.core6,formatv11,arbace.core15,shutdown-agentsm6,s4,readR32,s5,printR38,s9,roundtripR64,v19,arbace.repr.clojure5,usagev19,arbace.repr.clojure10,parse-argsv19,arbace.repr.clojure11,print-rulesv11,arbace.core5,flushR64,v19,arbace.repr.clojure13,run-roundtripv13,arbace.string4,joinv11,arbace.core5,printv11,arbace.core4,*in*R38,")

var Lit_1 *jrt.String = jrt.Intern("unknown rules: ")

var Lit_2 *jrt.String = jrt.Intern(", ")

var Lit_3 *jrt.String = jrt.Intern("<stdin>")

var Lit_4 *jrt.String = jrt.Intern("arbace.repr.clojure$_main$fn__716000316")

var Lit_5 *jrt.String = jrt.Intern("arbace.repr.clojure$_main$fn__716000318")

var Lit_6 *jrt.String = jrt.Intern("repr-clojure: give -o OUT or --in-place")

var Lit_7 *jrt.String = jrt.Intern("repr-clojure: %d %s (%d %s), %d unchanged, %d copied, %d skipped, %d errors")

var Lit_8 *jrt.String = jrt.Intern("printed")

var Lit_9 *jrt.String = jrt.Intern("translated")

var Lit_10 *jrt.String = jrt.Intern(".ae to .clj")

var Lit_11 *jrt.String = jrt.Intern("to .ae")

var Lit_12 *jrt.String = jrt.Intern(".")

var Lit_13 *jrt.String = jrt.Intern("java.io.File")

var Lit_14 *jrt.String = jrt.Intern("")

var Lit_15 *jrt.String = jrt.Intern("arbace.repr.clojure$files$iter__716000033__716000037")

var Lit_16 *jrt.String = jrt.Intern("arbace.repr.clojure$files$iter__716000033__716000037$fn__716000038")

var Lit_17 *jrt.String = jrt.Intern("arbace.repr.clojure$files$iter__716000033__716000037$fn__716000038$fn__716000039")

var Lit_18 *jrt.String = jrt.Intern("arbace.repr.clojure$first_difference$fn__716000143")

var Lit_19 *jrt.String = jrt.Intern("arbace.repr.clojure$first_difference$fn__716000145")

var Lit_20 *jrt.String = jrt.Intern("arbace.repr.clojure$first_difference$ln__716000147")

var Lit_21 *jrt.String = jrt.Intern("line ")

var Lit_22 *jrt.String = jrt.Intern(": ")

var Lit_23 *jrt.String = jrt.Intern(" / ")

var Lit_24 *jrt.String = jrt.Intern("\n")

var Lit_25 *jrt.String = jrt.Intern("arbace.repr.clojure$half$fn__716000125")

var Lit_26 *jrt.String = jrt.Intern("arbace.repr.clojure$half$fn__716000128")

var Lit_27 *jrt.String = jrt.Intern("arbace.repr.clojure$half$fn__716000134")

var Lit_28 *jrt.String = jrt.Intern("arbace.repr.clojure$half$fn__716000134$fn__716000138")

var Lit_29 *jrt.String = jrt.Intern("/")

var Lit_30 *jrt.String = jrt.Intern("-o")

var Lit_31 *jrt.String = jrt.Intern("--in-place")

var Lit_32 *jrt.String = jrt.Intern("--stdin")

var Lit_33 *jrt.String = jrt.Intern("--rules")

var Lit_34 *jrt.String = jrt.Intern("--keep-ext")

var Lit_35 *jrt.String = jrt.Intern("--full")

var Lit_36 *jrt.String = jrt.Intern("--ae")

var Lit_37 *jrt.String = jrt.Intern("-q")

var Lit_38 *jrt.String = jrt.Intern("-v")

var Lit_39 *jrt.String = jrt.Intern("--from-arbace")

var Lit_40 *jrt.String = jrt.Intern("--known")

var Lit_41 *jrt.String = jrt.Intern("--corpus")

var Lit_42 *jrt.String = jrt.Intern("--text")

var Lit_43 *jrt.String = jrt.Intern("--kind")

var Lit_44 *jrt.String = jrt.Intern("--skip")

var Lit_45 *jrt.String = jrt.Intern("-")

var Lit_46 *jrt.String = jrt.Intern("unknown option: ")

var Lit_47 *jrt.String = jrt.Intern(".cljc")

var Lit_48 *jrt.String = jrt.Intern("data_readers")

var Lit_49 *jrt.String = jrt.Intern("data_readers.ae")

var Lit_50 *jrt.String = jrt.Intern("data_readers.clj")

var Lit_51 *jrt.String = jrt.Intern(".ae")

var Lit_52 *jrt.String = jrt.Intern(".ae exists, which Arbace's reader prefers")

var Lit_53 *jrt.String = jrt.Intern(".clj")

var Lit_54 *jrt.String = jrt.Intern(".clj is translated instead, as the reader prefers it")

var Lit_55 *jrt.String = jrt.Intern(".java")

var Lit_56 *jrt.String = jrt.Intern("arbace.repr.clojure$plan$fn__716000018")

var Lit_57 *jrt.String = jrt.Intern(".class")

var Lit_58 *jrt.String = jrt.Intern("data_readers.cljc")

var Lit_59 *jrt.String = jrt.Intern(".ae is printed instead, as Arbace's loader prefers it")

var Lit_60 *jrt.String = jrt.Intern("arbace.repr.clojure$print_plan$fn__716000025")

var Lit_61 *jrt.String = jrt.Intern(" is there, which this .ae read with --full would be printed as")

var Lit_62 *jrt.String = jrt.Intern("Rules, in the order they apply (print reverses them in the reverse order):")

var Lit_63 *jrt.String = jrt.Intern("  ")

var Lit_64 *jrt.String = jrt.Intern(" (")

var Lit_65 *jrt.String = jrt.Intern("): ")

var Lit_66 *jrt.String = jrt.Intern(" ")

var Lit_67 *jrt.String = jrt.Intern("      lost by print: ")

var Lit_68 *jrt.String = jrt.Intern("Dialect divergences (doc/VENDOR-NOTES.md):")

var Lit_69 *jrt.String = jrt.Intern("no rule")

var Lit_70 *jrt.String = jrt.Intern(" - ")

var Lit_71 *jrt.String = jrt.Intern("arbace.repr.clojure$roundtrip$iter__716000153__716000157")

var Lit_72 *jrt.String = jrt.Intern("arbace.repr.clojure$roundtrip$iter__716000169__716000173")

var Lit_73 *jrt.String = jrt.Intern("arbace.repr.clojure$roundtrip$iter__716000185__716000189")

var Lit_74 *jrt.String = jrt.Intern("arbace.repr.clojure$roundtrip$iter__716000201__716000205")

var Lit_75 *jrt.String = jrt.Intern("arbace.repr.clojure$roundtrip$iter__716000217__716000221")

var Lit_76 *jrt.String = jrt.Intern("arbace.repr.clojure$roundtrip$iter__716000153__716000157$fn__716000158")

var Lit_77 *jrt.String = jrt.Intern("arbace.repr.clojure$roundtrip$iter__716000153__716000157$fn__716000158$fn__716000159")

var Lit_78 *jrt.String = jrt.Intern("arbace.repr.clojure$roundtrip$iter__716000169__716000173$fn__716000174")

var Lit_79 *jrt.String = jrt.Intern("arbace.repr.clojure$roundtrip$iter__716000169__716000173$fn__716000174$fn__716000175")

var Lit_80 *jrt.String = jrt.Intern("arbace.repr.clojure$roundtrip$iter__716000185__716000189$fn__716000190")

var Lit_81 *jrt.String = jrt.Intern("arbace.repr.clojure$roundtrip$iter__716000185__716000189$fn__716000190$fn__716000191")

var Lit_82 *jrt.String = jrt.Intern("arbace.repr.clojure$roundtrip$iter__716000201__716000205$fn__716000206")

var Lit_83 *jrt.String = jrt.Intern("arbace.repr.clojure$roundtrip$iter__716000201__716000205$fn__716000206$fn__716000207")

var Lit_84 *jrt.String = jrt.Intern("arbace.repr.clojure$roundtrip$iter__716000217__716000221$fn__716000222")

var Lit_85 *jrt.String = jrt.Intern("arbace.repr.clojure$roundtrip$iter__716000217__716000221$fn__716000222$fn__716000223")

var Lit_86 *jrt.String = jrt.Intern("arbace.repr.clojure$roundtrips$fn__716000257")

var Lit_87 *jrt.String = jrt.Intern("arbace.repr.clojure$roundtrips$fn__716000257$iter__716000258__716000262")

var Lit_88 *jrt.String = jrt.Intern("arbace.repr.clojure$roundtrips$fn__716000257$iter__716000258__716000262$fn__716000263")

var Lit_89 *jrt.String = jrt.Intern("arbace.repr.clojure$roundtrips$fn__716000257$iter__716000258__716000262$fn__716000263$fn__716000264")

var Lit_90 *jrt.String = jrt.Intern("arbace.repr.clojure$run$fn__716000046")

var Lit_91 *jrt.String = jrt.Intern("arbace.repr.clojure$run$fn__716000063")

var Lit_92 *jrt.String = jrt.Intern("arbace.repr.clojure$run$fn__716000065")

var Lit_93 *jrt.String = jrt.Intern("arbace.repr.clojure$run$fn__716000072")

var Lit_94 *jrt.String = jrt.Intern("arbace.repr.clojure$run$fn__716000074")

var Lit_95 *jrt.String = jrt.Intern("arbace.repr.clojure$run$fn__716000081")

var Lit_96 *jrt.String = jrt.Intern("arbace.repr.clojure$run$fn__716000083")

var Lit_97 *jrt.String = jrt.Intern("arbace.repr.clojure$run$fn__716000090")

var Lit_98 *jrt.String = jrt.Intern("arbace.repr.clojure$run$fn__716000092")

var Lit_99 *jrt.String = jrt.Intern("repr-clojure: skipped")

var Lit_100 *jrt.String = jrt.Intern("arbace.repr.clojure$run$fn__716000065$fn__716000066")

var Lit_101 *jrt.String = jrt.Intern("repr-clojure: error in")

var Lit_102 *jrt.String = jrt.Intern("arbace.repr.clojure$run$fn__716000074$fn__716000075")

var Lit_103 *jrt.String = jrt.Intern("arbace.repr.clojure$run$fn__716000083$fn__716000084")

var Lit_104 *jrt.String = jrt.Intern("arbace.repr.clojure$run$fn__716000092$fn__716000093")

var Lit_105 *jrt.String = jrt.Intern("arbace.repr.clojure$run_roundtrip$fn__716000280")

var Lit_106 *jrt.String = jrt.Intern("arbace.repr.clojure$run_roundtrip$fn__716000282")

var Lit_107 *jrt.String = jrt.Intern("arbace.repr.clojure$run_roundtrip$fn__716000284")

var Lit_108 *jrt.String = jrt.Intern("arbace.repr.clojure$run_roundtrip$fn__716000286")

var Lit_109 *jrt.String = jrt.Intern("known ")

var Lit_110 *jrt.String = jrt.Intern("NEW   ")

var Lit_111 *jrt.String = jrt.Intern(" (back as ")

var Lit_112 *jrt.String = jrt.Intern(")")

var Lit_113 *jrt.String = jrt.Intern("\n      ")

var Lit_114 *jrt.String = jrt.Intern("  STALE ")

var Lit_115 *jrt.String = jrt.Intern(" - known, but it comes back equal")

var Lit_116 *jrt.String = jrt.Intern("  outside ")

var Lit_117 *jrt.String = jrt.Intern("repr-clojure roundtrip%s (%s): %d files, %d equal, %s%d differ (%d known, %d new), %d stale")

var Lit_118 *jrt.String = jrt.Intern("Arbace -> Clojure -> Arbace")

var Lit_119 *jrt.String = jrt.Intern("Clojure -> Arbace -> Clojure")

var Lit_120 *jrt.String = jrt.Intern("%d outside read's image (texts read itself changes), ")

var Lit_121 *jrt.String = jrt.Intern("%d .cljc back as their :clj reading, ")

var Lit_122 *jrt.String = jrt.Intern("arbace.repr.clojure$tree$iter__716000097__716000103")

var Lit_123 *jrt.String = jrt.Intern("arbace.repr.clojure$tree$iter__716000097__716000103$fn__716000104")

var Lit_124 *jrt.String = jrt.Intern("arbace.repr.clojure$tree$iter__716000097__716000103$fn__716000104$iter__716000099__716000105")

var Lit_125 *jrt.String = jrt.Intern("arbace.repr.clojure$tree$iter__716000097__716000103$fn__716000104$iter__716000099__716000105$fn__716000106")

var Lit_126 *jrt.String = jrt.Intern("arbace.repr.clojure$tree$iter__716000097__716000103$fn__716000104$iter__716000099__716000105$fn__716000106$fn__716000107")

var Lit_127 *jrt.String = jrt.Intern("arbace.repr.clojure$usage$fn__716000254")

var Lit_128 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn4,linekn6,columnkn4,filekn7,privatekn8,arglistskn3,tagyn6,Stringyn8,siblingskn4,keysyn8,keep-extyn4,textyn4,fullyn1,pyn1,syn4,pathyn4,skipkn4,readkn4,plankn4,textkn6,refinekn5,printyn4,Fileyn7,sourcesyn3,outyn4,optsyn4,verbyn1,dyn1,nyn1,tyn4,argsyn1,oyn1,&v11,arbace.core5,in-nsMyn19,arbace.repr.clojurem2,R0,s3844,repr/clojure, Clojure's bridge (doc/REPR-CLOJURE.md; c2a until 2026-10-17): read, Clojure\n  source files or trees rewritten into Arbace's by the rules of arbace.repr.clojure.rules, their\n  layout and comments kept; print, Arbace's back into Clojure's, each rule reversed (a text\n  round trip). bin/repr-clojure runs it.\n\n    read [OPTION...] -o OUT SRC...       translate files and trees into the directory OUT\n    read --in-place [OPTION...] SRC...   translate them where they are\n    read --stdin [--kind K] [--ae]       translate standard input to standard output\n    read --rules                         list the rules (and how print reverses each) and the\n                                         dialect divergences\n    print [OPTION...] -o OUT SRC...      print Arbace files and trees back as Clojure into OUT\n    print --in-place [OPTION...] SRC...  print them where they are (x.ae becomes x.clj)\n    print --stdin [--kind K] [--ae]      print standard input to standard output\n    roundtrip [OPTION...] SRC...         read then print each tree in memory (--from-arbace:\n                                         print then read), every file back byte for byte\n\n  A directory SRC is translated into OUT with its relative paths (its contents, not itself).\n  read: .clj and .cljc files become .ae files: a .cljc file's reader conditionals resolved for\n  Arbace's features (#{:clj}); a .clj and a .cljc of the same name give the .clj's .ae (the\n  reader prefers the .clj), and a .ae already there is kept as it is (the reader prefers it).\n  data_readers.clj/.cljc become data_readers.ae too (Arbace reads it first), but as Arbace reads\n  all three and merges them, one that would collide keeps its name: a data_readers.clj beside a\n  data_readers.ae, a data_readers.cljc beside either. project.clj keeps its name. .java files\n  are renamed as text and keep their names (repr/java reads them). With -o, other files are copied\n  as they are, but class files (AOT output cannot be translated: their sources are); in place,\n  they stay.\n  print: the same plan reversed (print-plan): .ae files become .clj files (data_readers.ae a\n  data_readers.cljc beside a data_readers.clj); .clj and .cljc files are printed keeping their\n  names, but one beside a .ae of its name is left out; .java and --text files as read's. What\n  print cannot restore (the one-way rules, :reader-conditionals and :security-manager) is\n  listed by read --rules; a .ae that read --full made from a .cljc (its conditionals recorded\n  in a comment block at its end) is printed as that .cljc, byte for byte.\n\n  Options:\n    --keep-ext       read: .clj and .cljc files keep their names (and so a .cljc its\n                     conditionals, which Arbace's reader resolves with the feature :clj), as\n                     bin/clojure-tests translates Clojure's test suite; roundtrip: read so\n    --full           read: a .cljc file becoming a .ae records its reader conditionals in a\n                     comment block at the .ae's end (the .ae reads as without it), from which\n                     print gives the .cljc back byte for byte; roundtrip: read so\n    --text EXT       files ending in EXT are renamed as text (rule :rename and the like) too,\n                     keeping their names (repeatable; e.g. --text .edn)\n    --skip ID,...    leave these rules out\n    --kind K         --stdin's kind: clj (default), cljc, java or text (the Clojure file's)\n    --ae             --stdin: the Clojure text is a .ae file's (a .cljc's conditionals resolved;\n                     print: a record of read --full's restored)\n    -q               quiet: no summary\n    roundtrip's: --from-arbace; --known EDN --corpus NAME, the known differences ({corpus {path\n    reason}}; exit status 1 on another, or on one that no longer differs); -v, each\n    difference's first differing linem2,R0,s3844,repr/clojure, Clojure's bridge (doc/REPR-CLOJURE.md; c2a until 2026-10-17): read, Clojure\n  source files or trees rewritten into Arbace's by the rules of arbace.repr.clojure.rules, their\n  layout and comments kept; print, Arbace's back into Clojure's, each rule reversed (a text\n  round trip). bin/repr-clojure runs it.\n\n    read [OPTION...] -o OUT SRC...       translate files and trees into the directory OUT\n    read --in-place [OPTION...] SRC...   translate them where they are\n    read --stdin [--kind K] [--ae]       translate standard input to standard output\n    read --rules                         list the rules (and how print reverses each) and the\n                                         dialect divergences\n    print [OPTION...] -o OUT SRC...      print Arbace files and trees back as Clojure into OUT\n    print --in-place [OPTION...] SRC...  print them where they are (x.ae becomes x.clj)\n    print --stdin [--kind K] [--ae]      print standard input to standard output\n    roundtrip [OPTION...] SRC...         read then print each tree in memory (--from-arbace:\n                                         print then read), every file back byte for byte\n\n  A directory SRC is translated into OUT with its relative paths (its contents, not itself).\n  read: .clj and .cljc files become .ae files: a .cljc file's reader conditionals resolved for\n  Arbace's features (#{:clj}); a .clj and a .cljc of the same name give the .clj's .ae (the\n  reader prefers the .clj), and a .ae already there is kept as it is (the reader prefers it).\n  data_readers.clj/.cljc become data_readers.ae too (Arbace reads it first), but as Arbace reads\n  all three and merges them, one that would collide keeps its name: a data_readers.clj beside a\n  data_readers.ae, a data_readers.cljc beside either. project.clj keeps its name. .java files\n  are renamed as text and keep their names (repr/java reads them). With -o, other files are copied\n  as they are, but class files (AOT output cannot be translated: their sources are); in place,\n  they stay.\n  print: the same plan reversed (print-plan): .ae files become .clj files (data_readers.ae a\n  data_readers.cljc beside a data_readers.clj); .clj and .cljc files are printed keeping their\n  names, but one beside a .ae of its name is left out; .java and --text files as read's. What\n  print cannot restore (the one-way rules, :reader-conditionals and :security-manager) is\n  listed by read --rules; a .ae that read --full made from a .cljc (its conditionals recorded\n  in a comment block at its end) is printed as that .cljc, byte for byte.\n\n  Options:\n    --keep-ext       read: .clj and .cljc files keep their names (and so a .cljc its\n                     conditionals, which Arbace's reader resolves with the feature :clj), as\n                     bin/clojure-tests translates Clojure's test suite; roundtrip: read so\n    --full           read: a .cljc file becoming a .ae records its reader conditionals in a\n                     comment block at the .ae's end (the .ae reads as without it), from which\n                     print gives the .cljc back byte for byte; roundtrip: read so\n    --text EXT       files ending in EXT are renamed as text (rule :rename and the like) too,\n                     keeping their names (repeatable; e.g. --text .edn)\n    --skip ID,...    leave these rules out\n    --kind K         --stdin's kind: clj (default), cljc, java or text (the Clojure file's)\n    --ae             --stdin: the Clojure text is a .ae file's (a .cljc's conditionals resolved;\n                     print: a record of read --full's restored)\n    -q               quiet: no summary\n    roundtrip's: --from-arbace; --known EDN --corpus NAME, the known differences ({corpus {path\n    reason}}; exit status 1 on another, or on one that no longer differs); -v, each\n    difference's first differing lineR1,v19,arbace.repr.clojure10,keep-namesS1,s11,project.cljm6,R2,i58,R3,i1,R4,s22,arbace/repr/clojure.aev19,arbace.repr.clojure3,extm10,R5,TR6,L1,V1,Myn4,namem2,R7,R8,R2,i60,R3,i1,R4,s22,arbace/repr/clojure.aev19,arbace.repr.clojure4,basem10,R5,TR6,L1,V1,Myn4,namem2,R7,R8,R2,i63,R3,i1,R4,s22,arbace/repr/clojure.aev19,arbace.repr.clojure4,planm10,R6,L1,V3,Myn4,namem2,R7,R8,R9,m2,R10,V3,R11,R12,R13,R0,s318,What becomes of the file named name, among its siblings (a set of names), with the options:\n  {:kind K :to-ae BOOL :out NAME} for a file translated, {:copy true} for one copied (or left\n  in place), {:skip REASON} for one left out; :full true for a .cljc becoming a .ae under\n  read --full (its conditionals recorded).R2,i66,R3,i1,R4,s22,arbace/repr/clojure.aev19,arbace.repr.clojure10,print-planm10,R6,L1,V3,Myn4,namem2,R7,R8,R9,m2,R10,V1,R12,R0,s713,What becomes of the Arbace file named name when printed back as Clojure, among its siblings\n  (a set of names), with the options: read's plan reversed (doc/REPR-CLOJURE.md, \"Print\").\n  A .ae file becomes a .clj file, data_readers.ae a data_readers.clj (a data_readers.cljc when\n  a data_readers.clj is there, as Clojure merges them; left out when both are); its :kind and\n  :to-ae are those of the Clojure file read made it from, as far as print knows (a .clj). A\n  .clj or .cljc file keeps its name (read kept it), but one beside a .ae of the same name is\n  left out, as read left it (the .ae is printed instead). .java files and the --text files\n  keep their names; class files are left out; the rest is copied.R2,i97,R3,i1,R4,s22,arbace/repr/clojure.aev19,arbace.repr.clojure12,print-refinem10,R6,L1,V4,R14,Myn4,namem2,R7,R8,R9,Myn1,sm2,R7,R8,R0,s241,The print plan p of the Arbace file named name, among its siblings, once its text s is known:\n  a .ae ending with read --full's record becomes the .cljc it was read from (x.cljc,\n  data_readers.cljc), unless a file of that name is beside it.R2,i127,R3,i1,R4,s22,arbace/repr/clojure.aev19,arbace.repr.clojure14,translate-textm10,R6,L1,V4,R15,R14,R16,R17,R0,s42,Text s translated as a file of the plan p.R2,i139,R3,i1,R4,s22,arbace/repr/clojure.aev19,arbace.repr.clojure10,print-textm10,R6,L1,V4,R15,R14,R16,R17,R0,s69,Arbace text s printed back as Clojure, as a file of the print plan p.R2,i144,R3,i1,R4,s22,arbace/repr/clojure.aev19,arbace.repr.clojure5,verbsR18,R19,R20,R21,R22,m8,R5,TR2,i149,R3,i1,R4,s22,arbace/repr/clojure.aev19,arbace.repr.clojure5,filesm12,R5,TR6,L1,V1,Myn3,srcm2,R7,R23,R0,s86,[root-dir relative-path] of every file under src (a file: its directory and its name).R2,i153,R3,i1,R4,s22,arbace/repr/clojure.aev19,arbace.repr.clojure3,runm10,R6,L2,V3,R24,R25,R26,V4,R27,R24,R25,R26,R0,s412,Translates the sources (paths) into out (a directory path), or in place when out is nil:\n  read (Clojure to Arbace), or print with the verb :print (Arbace back to Clojure). Returns the\n  counts {:translated :to-ae :copied :skipped :unchanged} (:to-ae: the files renamed, .clj to\n  .ae or back) and prints what was skipped, and errors, to *err*. A directory's names are taken\n  before any of its files is renamed.R2,i163,R3,i1,R4,s22,arbace/repr/clojure.aev19,arbace.repr.clojure4,treem12,R5,TR6,L1,V1,R24,R0,s72,{relative-path File} of the files under the sources (as run walks them).R2,i214,R3,i1,R4,s22,arbace/repr/clojure.aev19,arbace.repr.clojure9,parent-ofm10,R5,TR6,L1,V1,Myn3,relm2,R7,R8,R2,i220,R3,i1,R4,s22,arbace/repr/clojure.aev19,arbace.repr.clojure7,name-ofm10,R5,TR6,L1,V1,Myn3,relm2,R7,R8,R2,i221,R3,i1,R4,s22,arbace/repr/clojure.aev19,arbace.repr.clojure5,underm10,R5,TR6,L1,V2,R28,R29,R2,i222,R3,i1,R4,s22,arbace/repr/clojure.aev19,arbace.repr.clojure4,halfm12,R5,TR6,L1,V3,R27,R30,R26,R0,s382,One half of a round trip over an in-memory tree {rel text-or-File}: each file planned by the\n  verb among its directory's names and translated. {:tree {rel text-or-File} :from {rel rel}}:\n  the tree the verb makes (copied files as they were) and, for each file translated, the\n  file it was made from and (:plans) its plan; :errors {rel message}, the files it could not\n  translate.R2,i224,R3,i1,R4,s22,arbace/repr/clojure.aev19,arbace.repr.clojure16,first-differencem10,R5,TR6,L1,V2,Myn1,am2,R7,R8,Myn1,bm2,R7,R8,R2,i253,R3,i1,R4,s22,arbace/repr/clojure.aev19,arbace.repr.clojure9,roundtripm10,R6,L1,V2,R24,R26,R0,s748,The round trip over the trees of the sources: read then print (from :clojure, the default:\n  Clojure -> Arbace -> Clojure), or print then read (from :arbace). Every file the first half\n  translates must come back, by the second, under its name with its text, byte for byte.\n  Returns {:files N :equal N :differ {rel {:why WHY :at TEXT}}}, WHY :name (back under another\n  name), :text, :missing, :error, :one-way (a .cljc read into a .ae, back as a .clj holding\n  exactly its :clj reading: the conditionals resolved, the rest as it was), or from Arbace\n  :not-read: a text read itself changes (one that names clojure.*, say), which no Clojure text\n  reads as, so print cannot give it back, but whose printed text makes the round trip from\n  Clojure.R2,i262,R3,i1,R4,s22,arbace/repr/clojure.aev19,arbace.repr.clojure10,parse-argsm10,R5,TR6,L1,V1,R31,R2,i317,R3,i1,R4,s22,arbace/repr/clojure.aev19,arbace.repr.clojure11,print-rulesm10,R5,TR6,L1,V0,R2,i339,R3,i1,R4,s22,arbace/repr/clojure.aev19,arbace.repr.clojure5,usagem10,R5,TR6,L1,V0,R2,i350,R3,i1,R4,s22,arbace/repr/clojure.aev19,arbace.repr.clojure10,roundtripsm10,R6,L1,V2,R24,R26,R0,s174,roundtrip over each of the sources apart, their results merged, each file's path prefixed by\n  its source's name (libraries whose trees share paths); one source: roundtrip's.R2,i354,R3,i1,R4,s22,arbace/repr/clojure.aev19,arbace.repr.clojure13,run-roundtripm12,R5,TR6,L1,V1,R32,R0,s229,roundtrip's command: the counts, each difference with its reason from the known ones (an\n  EDN map {corpus {rel reason}}, its section --corpus), and exit status 1 on a difference not\n  known or a known one that no longer differs.R2,i366,R3,i1,R4,s22,arbace/repr/clojure.aev19,arbace.repr.clojure5,-mainm8,R6,L1,V2,R33,R31,R2,i397,R3,i1,R4,s22,arbace/repr/clojure.ae")

var Lit_129 *jrt.String = jrt.Intern("arbace.repr.clojure$eval716000004$loading__1927001464__auto____716000005")

var Lit_130 *jrt.String = jrt.Intern("arbace.repr.clojure$eval716000008$fn__716000009")

var Lit_131 *jrt.String = jrt.Intern("arbace.repr.clojure$ext")

var Lit_132 *jrt.String = jrt.Intern("arbace.repr.clojure$base")

var Lit_133 *jrt.String = jrt.Intern("arbace.repr.clojure$plan")

var Lit_134 *jrt.String = jrt.Intern("arbace.repr.clojure$print_plan")

var Lit_135 *jrt.String = jrt.Intern("arbace.repr.clojure$print_refine")

var Lit_136 *jrt.String = jrt.Intern("arbace.repr.clojure$translate_text")

var Lit_137 *jrt.String = jrt.Intern("arbace.repr.clojure$print_text")

var Lit_138 *jrt.String = jrt.Intern("arbace.repr.clojure$fn__716000031")

var Lit_139 *jrt.String = jrt.Intern("arbace.repr.clojure$files")

var Lit_140 *jrt.String = jrt.Intern("arbace.repr.clojure$run")

var Lit_141 *jrt.String = jrt.Intern("arbace.repr.clojure$tree")

var Lit_142 *jrt.String = jrt.Intern("arbace.repr.clojure$parent_of")

var Lit_143 *jrt.String = jrt.Intern("arbace.repr.clojure$name_of")

var Lit_144 *jrt.String = jrt.Intern("arbace.repr.clojure$under")

var Lit_145 *jrt.String = jrt.Intern("arbace.repr.clojure$half")

var Lit_146 *jrt.String = jrt.Intern("arbace.repr.clojure$first_difference")

var Lit_147 *jrt.String = jrt.Intern("arbace.repr.clojure$roundtrip")

var Lit_148 *jrt.String = jrt.Intern("arbace.repr.clojure$parse_args")

var Lit_149 *jrt.String = jrt.Intern("arbace.repr.clojure$print_rules")

var Lit_150 *jrt.String = jrt.Intern("arbace.repr.clojure$usage")

var Lit_151 *jrt.String = jrt.Intern("arbace.repr.clojure$roundtrips")

var Lit_152 *jrt.String = jrt.Intern("arbace.repr.clojure$run_roundtrip")

var Lit_153 *jrt.String = jrt.Intern("arbace.repr.clojure$_main")
