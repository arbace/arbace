//line j2g_classes.ae:1
package aot_arbace_repr_clojure

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_repr_clojure__main_A_class, Name: "arbace.repr.clojure$_main", Modifiers: 25, Simple: "_main", Go: "arbace/aot_arbace_repr_clojure.A_arbace_repr_clojure__main_A", Source: "clojure.ae", Declaring: &A_arbace_repr_clojure_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_clojure__main_fn__716000105_A_class, Name: "arbace.repr.clojure$_main$fn__716000105", Modifiers: 25, Simple: "fn__716000105", Go: "arbace/aot_arbace_repr_clojure.A_arbace_repr_clojure__main_fn__716000105_A", Source: "clojure.ae", Declaring: &A_arbace_repr_clojure__main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_clojure__main_fn__716000107_A_class, Name: "arbace.repr.clojure$_main$fn__716000107", Modifiers: 25, Simple: "fn__716000107", Go: "arbace/aot_arbace_repr_clojure.A_arbace_repr_clojure__main_fn__716000107_A", Source: "clojure.ae", Declaring: &A_arbace_repr_clojure__main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_clojure__main_fn__716000109_A_class, Name: "arbace.repr.clojure$_main$fn__716000109", Modifiers: 25, Simple: "fn__716000109", Go: "arbace/aot_arbace_repr_clojure.A_arbace_repr_clojure__main_fn__716000109_A", Source: "clojure.ae", Declaring: &A_arbace_repr_clojure__main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_clojure__main_fn__716000111_A_class, Name: "arbace.repr.clojure$_main$fn__716000111", Modifiers: 25, Simple: "fn__716000111", Go: "arbace/aot_arbace_repr_clojure.A_arbace_repr_clojure__main_fn__716000111_A", Source: "clojure.ae", Declaring: &A_arbace_repr_clojure__main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_clojure_base_A_class, Name: "arbace.repr.clojure$base", Modifiers: 25, Simple: "base", Go: "arbace/aot_arbace_repr_clojure.A_arbace_repr_clojure_base_A", Source: "clojure.ae", Declaring: &A_arbace_repr_clojure_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_clojure_eval716000004_loading__1927001464__auto____716000005_A_class, Name: "arbace.repr.clojure$eval716000004$loading__1927001464__auto____716000005", Modifiers: 25, Simple: "loading__1927001464__auto____716000005", Go: "arbace/aot_arbace_repr_clojure.A_arbace_repr_clojure_eval716000004_loading__1927001464__auto____716000005_A", Source: "clojure.ae", Declaring: &A_arbace_repr_clojure_eval716000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_clojure_eval716000008_fn__716000009_A_class, Name: "arbace.repr.clojure$eval716000008$fn__716000009", Modifiers: 25, Simple: "fn__716000009", Go: "arbace/aot_arbace_repr_clojure.A_arbace_repr_clojure_eval716000008_fn__716000009_A", Source: "clojure.ae", Declaring: &A_arbace_repr_clojure_eval716000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_clojure_ext_A_class, Name: "arbace.repr.clojure$ext", Modifiers: 25, Simple: "ext", Go: "arbace/aot_arbace_repr_clojure.A_arbace_repr_clojure_ext_A", Source: "clojure.ae", Declaring: &A_arbace_repr_clojure_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_clojure_files_A_class, Name: "arbace.repr.clojure$files", Modifiers: 25, Simple: "files", Go: "arbace/aot_arbace_repr_clojure.A_arbace_repr_clojure_files_A", Source: "clojure.ae", Declaring: &A_arbace_repr_clojure_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_clojure_files_iter__716000022__716000026_A_class, Name: "arbace.repr.clojure$files$iter__716000022__716000026", Modifiers: 25, Simple: "iter__716000022__716000026", Go: "arbace/aot_arbace_repr_clojure.A_arbace_repr_clojure_files_iter__716000022__716000026_A", Source: "clojure.ae", Declaring: &A_arbace_repr_clojure_files_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_clojure_files_iter__716000022__716000026_fn__716000027_A_class, Name: "arbace.repr.clojure$files$iter__716000022__716000026$fn__716000027", Modifiers: 25, Simple: "fn__716000027", Go: "arbace/aot_arbace_repr_clojure.A_arbace_repr_clojure_files_iter__716000022__716000026_fn__716000027_A", Source: "clojure.ae", Declaring: &A_arbace_repr_clojure_files_iter__716000022__716000026_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_clojure_files_iter__716000022__716000026_fn__716000027_fn__716000028_A_class, Name: "arbace.repr.clojure$files$iter__716000022__716000026$fn__716000027$fn__716000028", Modifiers: 25, Simple: "fn__716000028", Go: "arbace/aot_arbace_repr_clojure.A_arbace_repr_clojure_files_iter__716000022__716000026_fn__716000027_fn__716000028_A", Source: "clojure.ae", Declaring: &A_arbace_repr_clojure_files_iter__716000022__716000026_fn__716000027_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_clojure_parse_args_A_class, Name: "arbace.repr.clojure$parse_args", Modifiers: 25, Simple: "parse_args", Go: "arbace/aot_arbace_repr_clojure.A_arbace_repr_clojure_parse_args_A", Source: "clojure.ae", Declaring: &A_arbace_repr_clojure_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_clojure_plan_A_class, Name: "arbace.repr.clojure$plan", Modifiers: 25, Simple: "plan", Go: "arbace/aot_arbace_repr_clojure.A_arbace_repr_clojure_plan_A", Source: "clojure.ae", Declaring: &A_arbace_repr_clojure_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_repr_clojure_plan_fn__716000018_A_class, Name: "arbace.repr.clojure$plan$fn__716000018", Modifiers: 25, Simple: "fn__716000018", Go: "arbace/aot_arbace_repr_clojure.A_arbace_repr_clojure_plan_fn__716000018_A", Source: "clojure.ae", Declaring: &A_arbace_repr_clojure_plan_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_repr_clojure_print_rules_A_class, Name: "arbace.repr.clojure$print_rules", Modifiers: 25, Simple: "print_rules", Go: "arbace/aot_arbace_repr_clojure.A_arbace_repr_clojure_print_rules_A", Source: "clojure.ae", Declaring: &A_arbace_repr_clojure_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_clojure_run_A_class, Name: "arbace.repr.clojure$run", Modifiers: 25, Simple: "run", Go: "arbace/aot_arbace_repr_clojure.A_arbace_repr_clojure_run_A", Source: "clojure.ae", Declaring: &A_arbace_repr_clojure_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_repr_clojure_run_fn__716000048_A_class, Name: "arbace.repr.clojure$run$fn__716000048", Modifiers: 25, Simple: "fn__716000048", Go: "arbace/aot_arbace_repr_clojure.A_arbace_repr_clojure_run_fn__716000048_A", Source: "clojure.ae", Declaring: &A_arbace_repr_clojure_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_clojure_run_fn__716000050_A_class, Name: "arbace.repr.clojure$run$fn__716000050", Modifiers: 25, Simple: "fn__716000050", Go: "arbace/aot_arbace_repr_clojure.A_arbace_repr_clojure_run_fn__716000050_A", Source: "clojure.ae", Declaring: &A_arbace_repr_clojure_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_clojure_run_fn__716000050_fn__716000051_A_class, Name: "arbace.repr.clojure$run$fn__716000050$fn__716000051", Modifiers: 25, Simple: "fn__716000051", Go: "arbace/aot_arbace_repr_clojure.A_arbace_repr_clojure_run_fn__716000050_fn__716000051_A", Source: "clojure.ae", Declaring: &A_arbace_repr_clojure_run_fn__716000050_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_clojure_run_fn__716000057_A_class, Name: "arbace.repr.clojure$run$fn__716000057", Modifiers: 25, Simple: "fn__716000057", Go: "arbace/aot_arbace_repr_clojure.A_arbace_repr_clojure_run_fn__716000057_A", Source: "clojure.ae", Declaring: &A_arbace_repr_clojure_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_clojure_run_fn__716000059_A_class, Name: "arbace.repr.clojure$run$fn__716000059", Modifiers: 25, Simple: "fn__716000059", Go: "arbace/aot_arbace_repr_clojure.A_arbace_repr_clojure_run_fn__716000059_A", Source: "clojure.ae", Declaring: &A_arbace_repr_clojure_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_clojure_run_fn__716000059_fn__716000060_A_class, Name: "arbace.repr.clojure$run$fn__716000059$fn__716000060", Modifiers: 25, Simple: "fn__716000060", Go: "arbace/aot_arbace_repr_clojure.A_arbace_repr_clojure_run_fn__716000059_fn__716000060_A", Source: "clojure.ae", Declaring: &A_arbace_repr_clojure_run_fn__716000059_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_clojure_run_fn__716000066_A_class, Name: "arbace.repr.clojure$run$fn__716000066", Modifiers: 25, Simple: "fn__716000066", Go: "arbace/aot_arbace_repr_clojure.A_arbace_repr_clojure_run_fn__716000066_A", Source: "clojure.ae", Declaring: &A_arbace_repr_clojure_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_clojure_run_fn__716000068_A_class, Name: "arbace.repr.clojure$run$fn__716000068", Modifiers: 25, Simple: "fn__716000068", Go: "arbace/aot_arbace_repr_clojure.A_arbace_repr_clojure_run_fn__716000068_A", Source: "clojure.ae", Declaring: &A_arbace_repr_clojure_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_clojure_run_fn__716000068_fn__716000069_A_class, Name: "arbace.repr.clojure$run$fn__716000068$fn__716000069", Modifiers: 25, Simple: "fn__716000069", Go: "arbace/aot_arbace_repr_clojure.A_arbace_repr_clojure_run_fn__716000068_fn__716000069_A", Source: "clojure.ae", Declaring: &A_arbace_repr_clojure_run_fn__716000068_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_clojure_run_fn__716000075_A_class, Name: "arbace.repr.clojure$run$fn__716000075", Modifiers: 25, Simple: "fn__716000075", Go: "arbace/aot_arbace_repr_clojure.A_arbace_repr_clojure_run_fn__716000075_A", Source: "clojure.ae", Declaring: &A_arbace_repr_clojure_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_clojure_run_fn__716000077_A_class, Name: "arbace.repr.clojure$run$fn__716000077", Modifiers: 25, Simple: "fn__716000077", Go: "arbace/aot_arbace_repr_clojure.A_arbace_repr_clojure_run_fn__716000077_A", Source: "clojure.ae", Declaring: &A_arbace_repr_clojure_run_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_clojure_run_fn__716000077_fn__716000078_A_class, Name: "arbace.repr.clojure$run$fn__716000077$fn__716000078", Modifiers: 25, Simple: "fn__716000078", Go: "arbace/aot_arbace_repr_clojure.A_arbace_repr_clojure_run_fn__716000077_fn__716000078_A", Source: "clojure.ae", Declaring: &A_arbace_repr_clojure_run_fn__716000077_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_repr_clojure_translate_text_A_class, Name: "arbace.repr.clojure$translate_text", Modifiers: 25, Simple: "translate_text", Go: "arbace/aot_arbace_repr_clojure.A_arbace_repr_clojure_translate_text_A", Source: "clojure.ae", Declaring: &A_arbace_repr_clojure_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_repr_clojure_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repr_clojure_A_New()}; return nil }

var A_arbace_repr_clojure_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_repr_clojure_A_new}

var A_arbace_repr_clojure_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repr.clojure", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_repr_clojure.A_arbace_repr_clojure_A"})

func init() { i := A_arbace_repr_clojure_A_class.Info(); i.IsInstance = A_arbace_repr_clojure_A_InstanceOf; i.Init = A_arbace_repr_clojure_A_Init; i.Table = A_arbace_repr_clojure_A_members }

var A_arbace_repr_clojure__main_A_class *jrt.Class

var A_arbace_repr_clojure__main_fn__716000105_A_class *jrt.Class

var A_arbace_repr_clojure__main_fn__716000107_A_class *jrt.Class

var A_arbace_repr_clojure__main_fn__716000109_A_class *jrt.Class

var A_arbace_repr_clojure__main_fn__716000111_A_class *jrt.Class

var A_arbace_repr_clojure_base_A_class *jrt.Class

func A_arbace_repr_clojure_eval716000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repr_clojure_eval716000004_A_New()}; return nil }

var A_arbace_repr_clojure_eval716000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_repr_clojure_eval716000004_A_new}

var A_arbace_repr_clojure_eval716000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repr.clojure$eval716000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_repr_clojure_A_class, Simple: "eval716000004", Go: "arbace/aot_arbace_repr_clojure.A_arbace_repr_clojure_eval716000004_A"})

func init() { i := A_arbace_repr_clojure_eval716000004_A_class.Info(); i.IsInstance = A_arbace_repr_clojure_eval716000004_A_InstanceOf; i.Table = A_arbace_repr_clojure_eval716000004_A_members }

var A_arbace_repr_clojure_eval716000004_loading__1927001464__auto____716000005_A_class *jrt.Class

func A_arbace_repr_clojure_eval716000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repr_clojure_eval716000008_A_New()}; return nil }

var A_arbace_repr_clojure_eval716000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_repr_clojure_eval716000008_A_new}

var A_arbace_repr_clojure_eval716000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repr.clojure$eval716000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_repr_clojure_A_class, Simple: "eval716000008", Go: "arbace/aot_arbace_repr_clojure.A_arbace_repr_clojure_eval716000008_A"})

func init() { i := A_arbace_repr_clojure_eval716000008_A_class.Info(); i.IsInstance = A_arbace_repr_clojure_eval716000008_A_InstanceOf; i.Table = A_arbace_repr_clojure_eval716000008_A_members }

var A_arbace_repr_clojure_eval716000008_fn__716000009_A_class *jrt.Class

var A_arbace_repr_clojure_ext_A_class *jrt.Class

var A_arbace_repr_clojure_files_A_class *jrt.Class

var A_arbace_repr_clojure_files_iter__716000022__716000026_A_class *jrt.Class

var A_arbace_repr_clojure_files_iter__716000022__716000026_fn__716000027_A_class *jrt.Class

var A_arbace_repr_clojure_files_iter__716000022__716000026_fn__716000027_fn__716000028_A_class *jrt.Class

var A_arbace_repr_clojure_parse_args_A_class *jrt.Class

var A_arbace_repr_clojure_plan_A_class *jrt.Class

var A_arbace_repr_clojure_plan_fn__716000018_A_class *jrt.Class

var A_arbace_repr_clojure_print_rules_A_class *jrt.Class

var A_arbace_repr_clojure_run_A_class *jrt.Class

var A_arbace_repr_clojure_run_fn__716000048_A_class *jrt.Class

var A_arbace_repr_clojure_run_fn__716000050_A_class *jrt.Class

var A_arbace_repr_clojure_run_fn__716000050_fn__716000051_A_class *jrt.Class

var A_arbace_repr_clojure_run_fn__716000057_A_class *jrt.Class

var A_arbace_repr_clojure_run_fn__716000059_A_class *jrt.Class

var A_arbace_repr_clojure_run_fn__716000059_fn__716000060_A_class *jrt.Class

var A_arbace_repr_clojure_run_fn__716000066_A_class *jrt.Class

var A_arbace_repr_clojure_run_fn__716000068_A_class *jrt.Class

var A_arbace_repr_clojure_run_fn__716000068_fn__716000069_A_class *jrt.Class

var A_arbace_repr_clojure_run_fn__716000075_A_class *jrt.Class

var A_arbace_repr_clojure_run_fn__716000077_A_class *jrt.Class

var A_arbace_repr_clojure_run_fn__716000077_fn__716000078_A_class *jrt.Class

var A_arbace_repr_clojure_translate_text_A_class *jrt.Class

func A_arbace_repr_clojure__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_repr_clojure__init_A_Load__O()}; return nil }

func A_arbace_repr_clojure__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_repr_clojure__init_A_New()}; return nil }

var A_arbace_repr_clojure__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_repr_clojure__init_A_invoke, New: A_arbace_repr_clojure__init_A_new}

var A_arbace_repr_clojure__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.repr.clojure__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_repr_clojure.A_arbace_repr_clojure__init_A", Source: "clojure.ae"})

func init() { i := A_arbace_repr_clojure__init_A_class.Info(); i.IsInstance = A_arbace_repr_clojure__init_A_InstanceOf; i.Init = A_arbace_repr_clojure__init_A_Init; i.Table = A_arbace_repr_clojure__init_A_members }
