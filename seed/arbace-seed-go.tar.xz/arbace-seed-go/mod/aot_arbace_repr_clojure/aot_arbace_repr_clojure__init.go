//line aot_arbace_repr_clojure__init.ae:1
package aot_arbace_repr_clojure

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_clojure__init_A_Unit0__O() any { A_arbace_repr_clojure__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_repr_clojure__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_clojure__init_A_const_1) }
//line :1:1
func A_arbace_repr_clojure__init_A_Unit1__O() any { A_arbace_repr_clojure__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_repr_clojure__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_repr_clojure__init_A_const_2)) }
//line :1:1
func A_arbace_repr_clojure__init_A_Unit2__O() any { A_arbace_repr_clojure__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_repr_clojure_eval716000004_loading__1927001464__auto____716000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_repr_clojure_eval716000004_loading__1927001464__auto____716000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_129, false, nil); A_arbace_repr_clojure_eval716000004_loading__1927001464__auto____716000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_repr_clojure__init_A_Unit3__O() any { A_arbace_repr_clojure__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_repr_clojure__init_A_const_1)).Equals_O__Z(A_arbace_repr_clojure__init_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_repr_clojure_eval716000008_fn__716000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_repr_clojure_eval716000008_fn__716000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_130, false, nil); A_arbace_repr_clojure_eval716000008_fn__716000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }



func A_arbace_repr_clojure__init_A_Load__O() any { A_arbace_repr_clojure__init_A_Init(); jrt.StartCheck(); A_arbace_repr_clojure__init_A_Unit0__O(); A_arbace_repr_clojure__init_A_Unit1__O(); A_arbace_repr_clojure__init_A_Unit2__O(); A_arbace_repr_clojure__init_A_Unit3__O(); A_arbace_repr_clojure__init_A_Unit4__O(); A_arbace_repr_clojure__init_A_Unit5__O(); A_arbace_repr_clojure__init_A_Unit6__O(); A_arbace_repr_clojure__init_A_Unit7__O(); A_arbace_repr_clojure__init_A_Unit8__O(); A_arbace_repr_clojure__init_A_Unit9__O(); A_arbace_repr_clojure__init_A_Unit10__O(); A_arbace_repr_clojure__init_A_Unit11__O(); A_arbace_repr_clojure__init_A_Unit12__O(); A_arbace_repr_clojure__init_A_Unit13__O(); A_arbace_repr_clojure__init_A_Unit14__O(); A_arbace_repr_clojure__init_A_Unit15__O(); A_arbace_repr_clojure__init_A_Unit16__O(); A_arbace_repr_clojure__init_A_Unit17__O(); A_arbace_repr_clojure__init_A_Unit18__O(); A_arbace_repr_clojure__init_A_Unit19__O(); A_arbace_repr_clojure__init_A_Unit20__O(); A_arbace_repr_clojure__init_A_Unit21__O(); A_arbace_repr_clojure__init_A_Unit22__O(); A_arbace_repr_clojure__init_A_Unit23__O(); A_arbace_repr_clojure__init_A_Unit24__O(); A_arbace_repr_clojure__init_A_Unit25__O(); A_arbace_repr_clojure__init_A_Unit26__O(); A_arbace_repr_clojure__init_A_Unit27__O(); return nil }




















































func A_arbace_repr_clojure__init_A_Unit4__O() any { A_arbace_repr_clojure__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(58, 1); A_arbace_repr_clojure__init_A_const_4.BindRoot_O__V(A_arbace_repr_clojure__init_A_const_5); var tmp1 *lang.Var = A_arbace_repr_clojure__init_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure__init_A_const_6)); return A_arbace_repr_clojure__init_A_const_4 }

func A_arbace_repr_clojure__init_A_Unit5__O() any { A_arbace_repr_clojure__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(60, 1); var tmp1 *lang.Var = A_arbace_repr_clojure__init_A_const_7; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_repr_clojure_ext_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_repr_clojure_ext_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_131, false, nil); A_arbace_repr_clojure_ext_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_clojure__init_A_const_7; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure__init_A_const_8)); return A_arbace_repr_clojure__init_A_const_7 }


func A_arbace_repr_clojure__init_A_Unit6__O() any { A_arbace_repr_clojure__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(63, 1); var tmp1 *lang.Var = A_arbace_repr_clojure__init_A_const_9; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_repr_clojure_base_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_repr_clojure_base_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_132, false, nil); A_arbace_repr_clojure_base_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_clojure__init_A_const_9; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure__init_A_const_10)); return A_arbace_repr_clojure__init_A_const_9 }


func A_arbace_repr_clojure__init_A_Unit7__O() any { A_arbace_repr_clojure__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(66, 1); var tmp1 *lang.Var = A_arbace_repr_clojure__init_A_const_11; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_repr_clojure_plan_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_repr_clojure_plan_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_133, false, nil); A_arbace_repr_clojure_plan_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_clojure__init_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure__init_A_const_12)); return A_arbace_repr_clojure__init_A_const_11 }






























func A_arbace_repr_clojure__init_A_Unit8__O() any { A_arbace_repr_clojure__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(97, 1); var tmp1 *lang.Var = A_arbace_repr_clojure__init_A_const_13; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_repr_clojure_print_plan_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_repr_clojure_print_plan_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_134, false, nil); A_arbace_repr_clojure_print_plan_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_clojure__init_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure__init_A_const_14)); return A_arbace_repr_clojure__init_A_const_13 }





























func A_arbace_repr_clojure__init_A_Unit9__O() any { A_arbace_repr_clojure__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(127, 1); var tmp1 *lang.Var = A_arbace_repr_clojure__init_A_const_15; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_repr_clojure_print_refine_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_repr_clojure_print_refine_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_135, false, nil); A_arbace_repr_clojure_print_refine_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_clojure__init_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure__init_A_const_16)); return A_arbace_repr_clojure__init_A_const_15 }











func A_arbace_repr_clojure__init_A_Unit10__O() any { A_arbace_repr_clojure__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(139, 1); var tmp1 *lang.Var = A_arbace_repr_clojure__init_A_const_17; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_repr_clojure_translate_text_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_repr_clojure_translate_text_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_136, false, nil); A_arbace_repr_clojure_translate_text_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_clojure__init_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure__init_A_const_18)); return A_arbace_repr_clojure__init_A_const_17 }




func A_arbace_repr_clojure__init_A_Unit11__O() any { A_arbace_repr_clojure__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(144, 1); var tmp1 *lang.Var = A_arbace_repr_clojure__init_A_const_19; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_repr_clojure_print_text_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_repr_clojure_print_text_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_137, false, nil); A_arbace_repr_clojure_print_text_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_clojure__init_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure__init_A_const_20)); return A_arbace_repr_clojure__init_A_const_19 }




func A_arbace_repr_clojure__init_A_Unit12__O() any { A_arbace_repr_clojure__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(149, 1); var tmp1 *lang.Var = A_arbace_repr_clojure__init_A_const_21; var tmp2 any = A_arbace_repr_clojure__init_A_const_22; var tmp3 any = A_arbace_repr_clojure__init_A_const_23; var tmp4 any = A_arbace_repr_clojure__init_A_const_11.GetRawRoot__O(); var tmp5 any = A_arbace_repr_clojure__init_A_const_24; var tmp6 any = A_arbace_repr_clojure__init_A_const_17.GetRawRoot__O(); var tmp7 any = A_arbace_repr_clojure__init_A_const_25; var tmp8 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_repr_clojure_fn__716000031_A_New(); var tmp9 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_repr_clojure_fn__716000031_A_fn_class; if
							fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_138, false, nil); A_arbace_repr_clojure_fn__716000031_A_fn_class = fncls__19d; tmp9 = fncls__19d } else { tmp9 = fncls__19 }; tmp8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp9, nil); var tmp10 any = /*line :149:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8.Ref())); var tmp11 any = A_arbace_repr_clojure__init_A_const_26; var tmp12 any = A_arbace_repr_clojure__init_A_const_23; var tmp13 any = A_arbace_repr_clojure__init_A_const_13.GetRawRoot__O(); var tmp14 any = A_arbace_repr_clojure__init_A_const_24; var tmp15 any = A_arbace_repr_clojure__init_A_const_19.GetRawRoot__O(); var tmp16 any = A_arbace_repr_clojure__init_A_const_25; tmp1.BindRoot_O__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp10, tmp11, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, tmp13, tmp14, tmp15, tmp16, A_arbace_repr_clojure__init_A_const_15.GetRawRoot__O()))))); var tmp17 *lang.Var = A_arbace_repr_clojure__init_A_const_21; tmp17.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure__init_A_const_27)); return A_arbace_repr_clojure__init_A_const_21 }



func A_arbace_repr_clojure__init_A_Unit13__O() any { A_arbace_repr_clojure__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(153, 1); var tmp1 *lang.Var = A_arbace_repr_clojure__init_A_const_28; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_repr_clojure_files_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_repr_clojure_files_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_139, false, nil); A_arbace_repr_clojure_files_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_clojure__init_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure__init_A_const_29)); return A_arbace_repr_clojure__init_A_const_28 }









func A_arbace_repr_clojure__init_A_Unit14__O() any { A_arbace_repr_clojure__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(163, 1); var tmp1 *lang.Var = A_arbace_repr_clojure__init_A_const_30; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_repr_clojure_run_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_repr_clojure_run_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_140, false, nil); A_arbace_repr_clojure_run_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_clojure__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure__init_A_const_31)); return A_arbace_repr_clojure__init_A_const_30 }


















































func A_arbace_repr_clojure__init_A_Unit15__O() any { A_arbace_repr_clojure__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(214, 1); var tmp1 *lang.Var = A_arbace_repr_clojure__init_A_const_32; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_repr_clojure_tree_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_repr_clojure_tree_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_141, false, nil); A_arbace_repr_clojure_tree_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_clojure__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure__init_A_const_33)); return A_arbace_repr_clojure__init_A_const_32 }





func A_arbace_repr_clojure__init_A_Unit16__O() any { A_arbace_repr_clojure__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(220, 1); var tmp1 *lang.Var = A_arbace_repr_clojure__init_A_const_34; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_repr_clojure_parent_of_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_repr_clojure_parent_of_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_142, false, nil); A_arbace_repr_clojure_parent_of_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_clojure__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure__init_A_const_35)); return A_arbace_repr_clojure__init_A_const_34 }
func A_arbace_repr_clojure__init_A_Unit17__O() any { A_arbace_repr_clojure__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(221, 1); var tmp1 *lang.Var = A_arbace_repr_clojure__init_A_const_36; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_repr_clojure_name_of_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_repr_clojure_name_of_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_143, false, nil); A_arbace_repr_clojure_name_of_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_clojure__init_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure__init_A_const_37)); return A_arbace_repr_clojure__init_A_const_36 }
func A_arbace_repr_clojure__init_A_Unit18__O() any { A_arbace_repr_clojure__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(222, 1); var tmp1 *lang.Var = A_arbace_repr_clojure__init_A_const_38; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_repr_clojure_under_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_repr_clojure_under_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_144, false, nil); A_arbace_repr_clojure_under_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_clojure__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure__init_A_const_39)); return A_arbace_repr_clojure__init_A_const_38 }

func A_arbace_repr_clojure__init_A_Unit19__O() any { A_arbace_repr_clojure__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(224, 1); var tmp1 *lang.Var = A_arbace_repr_clojure__init_A_const_40; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_repr_clojure_half_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_repr_clojure_half_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_145, false, nil); A_arbace_repr_clojure_half_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_clojure__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure__init_A_const_41)); return A_arbace_repr_clojure__init_A_const_40 }




























func A_arbace_repr_clojure__init_A_Unit20__O() any { A_arbace_repr_clojure__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(253, 1); var tmp1 *lang.Var = A_arbace_repr_clojure__init_A_const_42; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_repr_clojure_first_difference_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_repr_clojure_first_difference_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_146, false, nil); A_arbace_repr_clojure_first_difference_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_clojure__init_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure__init_A_const_43)); return A_arbace_repr_clojure__init_A_const_42 }








func A_arbace_repr_clojure__init_A_Unit21__O() any { A_arbace_repr_clojure__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(262, 1); var tmp1 *lang.Var = A_arbace_repr_clojure__init_A_const_44; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_repr_clojure_roundtrip_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_repr_clojure_roundtrip_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_147, false, nil); A_arbace_repr_clojure_roundtrip_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_clojure__init_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure__init_A_const_45)); return A_arbace_repr_clojure__init_A_const_44 }






















































func A_arbace_repr_clojure__init_A_Unit22__O() any { A_arbace_repr_clojure__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(317, 1); var tmp1 *lang.Var = A_arbace_repr_clojure__init_A_const_46; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_repr_clojure_parse_args_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_repr_clojure_parse_args_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_148, false, nil); A_arbace_repr_clojure_parse_args_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_clojure__init_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure__init_A_const_47)); return A_arbace_repr_clojure__init_A_const_46 }





















func A_arbace_repr_clojure__init_A_Unit23__O() any { A_arbace_repr_clojure__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(339, 1); var tmp1 *lang.Var = A_arbace_repr_clojure__init_A_const_48; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_repr_clojure_print_rules_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_repr_clojure_print_rules_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_149, false, nil); A_arbace_repr_clojure_print_rules_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_clojure__init_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure__init_A_const_49)); return A_arbace_repr_clojure__init_A_const_48 }










func A_arbace_repr_clojure__init_A_Unit24__O() any { A_arbace_repr_clojure__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(350, 1); var tmp1 *lang.Var = A_arbace_repr_clojure__init_A_const_50; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_repr_clojure_usage_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_repr_clojure_usage_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_150, false, nil); A_arbace_repr_clojure_usage_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_clojure__init_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure__init_A_const_51)); return A_arbace_repr_clojure__init_A_const_50 }



func A_arbace_repr_clojure__init_A_Unit25__O() any { A_arbace_repr_clojure__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(354, 1); var tmp1 *lang.Var = A_arbace_repr_clojure__init_A_const_52; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_repr_clojure_roundtrips_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_repr_clojure_roundtrips_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_151, false, nil); A_arbace_repr_clojure_roundtrips_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_clojure__init_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure__init_A_const_53)); return A_arbace_repr_clojure__init_A_const_52 }











func A_arbace_repr_clojure__init_A_Unit26__O() any { A_arbace_repr_clojure__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(366, 1); var tmp1 *lang.Var = A_arbace_repr_clojure__init_A_const_54; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_repr_clojure_run_roundtrip_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_repr_clojure_run_roundtrip_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_152, false, nil); A_arbace_repr_clojure_run_roundtrip_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_clojure__init_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure__init_A_const_55)); return A_arbace_repr_clojure__init_A_const_54 }






























func A_arbace_repr_clojure__init_A_Unit27__O() any { A_arbace_repr_clojure__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(397, 1); var tmp1 *lang.Var = A_arbace_repr_clojure__init_A_const_56; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__50 any = A_arbace_repr_clojure__main_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_repr_clojure__main_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_153, true, nil); A_arbace_repr_clojure__main_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__50, tmp3, nil, 0); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_clojure__init_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_clojure__init_A_const_57)); return A_arbace_repr_clojure__init_A_const_56 }



type A_arbace_repr_clojure__init_A struct{ jrt.Object }

var A_arbace_repr_clojure__init_A_const_pool *jrt.RefArray

var A_arbace_repr_clojure__init_A_const_0 *lang.Var

var A_arbace_repr_clojure__init_A_const_1 any

var A_arbace_repr_clojure__init_A_const_2 any

var A_arbace_repr_clojure__init_A_const_3 any

var A_arbace_repr_clojure__init_A_const_4 *lang.Var

var A_arbace_repr_clojure__init_A_const_5 any

var A_arbace_repr_clojure__init_A_const_6 any

var A_arbace_repr_clojure__init_A_const_7 *lang.Var

var A_arbace_repr_clojure__init_A_const_8 any

var A_arbace_repr_clojure__init_A_const_9 *lang.Var

var A_arbace_repr_clojure__init_A_const_10 any

var A_arbace_repr_clojure__init_A_const_11 *lang.Var

var A_arbace_repr_clojure__init_A_const_12 any

var A_arbace_repr_clojure__init_A_const_13 *lang.Var

var A_arbace_repr_clojure__init_A_const_14 any

var A_arbace_repr_clojure__init_A_const_15 *lang.Var

var A_arbace_repr_clojure__init_A_const_16 any

var A_arbace_repr_clojure__init_A_const_17 *lang.Var

var A_arbace_repr_clojure__init_A_const_18 any

var A_arbace_repr_clojure__init_A_const_19 *lang.Var

var A_arbace_repr_clojure__init_A_const_20 any

var A_arbace_repr_clojure__init_A_const_21 *lang.Var

var A_arbace_repr_clojure__init_A_const_22 *lang.Keyword

var A_arbace_repr_clojure__init_A_const_23 *lang.Keyword

var A_arbace_repr_clojure__init_A_const_24 *lang.Keyword

var A_arbace_repr_clojure__init_A_const_25 *lang.Keyword

var A_arbace_repr_clojure__init_A_const_26 *lang.Keyword

var A_arbace_repr_clojure__init_A_const_27 any

var A_arbace_repr_clojure__init_A_const_28 *lang.Var

var A_arbace_repr_clojure__init_A_const_29 any

var A_arbace_repr_clojure__init_A_const_30 *lang.Var

var A_arbace_repr_clojure__init_A_const_31 any

var A_arbace_repr_clojure__init_A_const_32 *lang.Var

var A_arbace_repr_clojure__init_A_const_33 any

var A_arbace_repr_clojure__init_A_const_34 *lang.Var

var A_arbace_repr_clojure__init_A_const_35 any

var A_arbace_repr_clojure__init_A_const_36 *lang.Var

var A_arbace_repr_clojure__init_A_const_37 any

var A_arbace_repr_clojure__init_A_const_38 *lang.Var

var A_arbace_repr_clojure__init_A_const_39 any

var A_arbace_repr_clojure__init_A_const_40 *lang.Var

var A_arbace_repr_clojure__init_A_const_41 any

var A_arbace_repr_clojure__init_A_const_42 *lang.Var

var A_arbace_repr_clojure__init_A_const_43 any

var A_arbace_repr_clojure__init_A_const_44 *lang.Var

var A_arbace_repr_clojure__init_A_const_45 any

var A_arbace_repr_clojure__init_A_const_46 *lang.Var

var A_arbace_repr_clojure__init_A_const_47 any

var A_arbace_repr_clojure__init_A_const_48 *lang.Var

var A_arbace_repr_clojure__init_A_const_49 any

var A_arbace_repr_clojure__init_A_const_50 *lang.Var

var A_arbace_repr_clojure__init_A_const_51 any

var A_arbace_repr_clojure__init_A_const_52 *lang.Var

var A_arbace_repr_clojure__init_A_const_53 any

var A_arbace_repr_clojure__init_A_const_54 *lang.Var

var A_arbace_repr_clojure__init_A_const_55 any

var A_arbace_repr_clojure__init_A_const_56 *lang.Var

var A_arbace_repr_clojure__init_A_const_57 any

var A_arbace_repr_clojure__init_A_init jrt.ClassInit

func A_arbace_repr_clojure__init_A_Init() { if !A_arbace_repr_clojure__init_A_init.Done() { A_arbace_repr_clojure__init_A_init.Run(A_arbace_repr_clojure__init_A_clinit) } }

func A_arbace_repr_clojure__init_A_clinit() { A_arbace_repr_clojure__init_A_clinit_p0(); A_arbace_repr_clojure__init_A_clinit_p1(); A_arbace_repr_clojure__init_A_clinit_p2(); A_arbace_repr_clojure__init_A_clinit_p3(); A_arbace_repr_clojure__init_A_clinit_p4() }

func A_arbace_repr_clojure__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_clojure__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_128, 92); A_arbace_repr_clojure__init_A_const_0 = lang.Var_Cast(A_arbace_repr_clojure__init_A_const_pool.A[34]); A_arbace_repr_clojure__init_A_const_1 = A_arbace_repr_clojure__init_A_const_pool.A[35]; A_arbace_repr_clojure__init_A_const_2 = A_arbace_repr_clojure__init_A_const_pool.A[36]; A_arbace_repr_clojure__init_A_const_3 = A_arbace_repr_clojure__init_A_const_pool.A[37]; A_arbace_repr_clojure__init_A_const_4 = lang.Var_Cast(A_arbace_repr_clojure__init_A_const_pool.A[38]); A_arbace_repr_clojure__init_A_const_5 = A_arbace_repr_clojure__init_A_const_pool.A[39]; A_arbace_repr_clojure__init_A_const_6 = A_arbace_repr_clojure__init_A_const_pool.A[40]; A_arbace_repr_clojure__init_A_const_7 = lang.Var_Cast(A_arbace_repr_clojure__init_A_const_pool.A[41]); A_arbace_repr_clojure__init_A_const_8 = A_arbace_repr_clojure__init_A_const_pool.A[42]; A_arbace_repr_clojure__init_A_const_9 = lang.Var_Cast(A_arbace_repr_clojure__init_A_const_pool.A[43]); A_arbace_repr_clojure__init_A_const_10 = A_arbace_repr_clojure__init_A_const_pool.A[44]; A_arbace_repr_clojure__init_A_const_11 = lang.Var_Cast(A_arbace_repr_clojure__init_A_const_pool.A[45]); A_arbace_repr_clojure__init_A_const_12 = A_arbace_repr_clojure__init_A_const_pool.A[46] }

func A_arbace_repr_clojure__init_A_clinit_p1() { A_arbace_repr_clojure__init_A_const_13 = lang.Var_Cast(A_arbace_repr_clojure__init_A_const_pool.A[47]); A_arbace_repr_clojure__init_A_const_14 = A_arbace_repr_clojure__init_A_const_pool.A[48]; A_arbace_repr_clojure__init_A_const_15 = lang.Var_Cast(A_arbace_repr_clojure__init_A_const_pool.A[49]); A_arbace_repr_clojure__init_A_const_16 = A_arbace_repr_clojure__init_A_const_pool.A[50]; A_arbace_repr_clojure__init_A_const_17 = lang.Var_Cast(A_arbace_repr_clojure__init_A_const_pool.A[51]); A_arbace_repr_clojure__init_A_const_18 = A_arbace_repr_clojure__init_A_const_pool.A[52]; A_arbace_repr_clojure__init_A_const_19 = lang.Var_Cast(A_arbace_repr_clojure__init_A_const_pool.A[53]); A_arbace_repr_clojure__init_A_const_20 = A_arbace_repr_clojure__init_A_const_pool.A[54]; A_arbace_repr_clojure__init_A_const_21 = lang.Var_Cast(A_arbace_repr_clojure__init_A_const_pool.A[55]); A_arbace_repr_clojure__init_A_const_22 = lang.Keyword_Cast(A_arbace_repr_clojure__init_A_const_pool.A[56]); A_arbace_repr_clojure__init_A_const_23 = lang.Keyword_Cast(A_arbace_repr_clojure__init_A_const_pool.A[57]); A_arbace_repr_clojure__init_A_const_24 = lang.Keyword_Cast(A_arbace_repr_clojure__init_A_const_pool.A[58]); A_arbace_repr_clojure__init_A_const_25 = lang.Keyword_Cast(A_arbace_repr_clojure__init_A_const_pool.A[59]) }

func A_arbace_repr_clojure__init_A_clinit_p2() { A_arbace_repr_clojure__init_A_const_26 = lang.Keyword_Cast(A_arbace_repr_clojure__init_A_const_pool.A[60]); A_arbace_repr_clojure__init_A_const_27 = A_arbace_repr_clojure__init_A_const_pool.A[61]; A_arbace_repr_clojure__init_A_const_28 = lang.Var_Cast(A_arbace_repr_clojure__init_A_const_pool.A[62]); A_arbace_repr_clojure__init_A_const_29 = A_arbace_repr_clojure__init_A_const_pool.A[63]; A_arbace_repr_clojure__init_A_const_30 = lang.Var_Cast(A_arbace_repr_clojure__init_A_const_pool.A[64]); A_arbace_repr_clojure__init_A_const_31 = A_arbace_repr_clojure__init_A_const_pool.A[65]; A_arbace_repr_clojure__init_A_const_32 = lang.Var_Cast(A_arbace_repr_clojure__init_A_const_pool.A[66]); A_arbace_repr_clojure__init_A_const_33 = A_arbace_repr_clojure__init_A_const_pool.A[67]; A_arbace_repr_clojure__init_A_const_34 = lang.Var_Cast(A_arbace_repr_clojure__init_A_const_pool.A[68]); A_arbace_repr_clojure__init_A_const_35 = A_arbace_repr_clojure__init_A_const_pool.A[69]; A_arbace_repr_clojure__init_A_const_36 = lang.Var_Cast(A_arbace_repr_clojure__init_A_const_pool.A[70]); A_arbace_repr_clojure__init_A_const_37 = A_arbace_repr_clojure__init_A_const_pool.A[71]; A_arbace_repr_clojure__init_A_const_38 = lang.Var_Cast(A_arbace_repr_clojure__init_A_const_pool.A[72]) }

func A_arbace_repr_clojure__init_A_clinit_p3() { A_arbace_repr_clojure__init_A_const_39 = A_arbace_repr_clojure__init_A_const_pool.A[73]; A_arbace_repr_clojure__init_A_const_40 = lang.Var_Cast(A_arbace_repr_clojure__init_A_const_pool.A[74]); A_arbace_repr_clojure__init_A_const_41 = A_arbace_repr_clojure__init_A_const_pool.A[75]; A_arbace_repr_clojure__init_A_const_42 = lang.Var_Cast(A_arbace_repr_clojure__init_A_const_pool.A[76]); A_arbace_repr_clojure__init_A_const_43 = A_arbace_repr_clojure__init_A_const_pool.A[77]; A_arbace_repr_clojure__init_A_const_44 = lang.Var_Cast(A_arbace_repr_clojure__init_A_const_pool.A[78]); A_arbace_repr_clojure__init_A_const_45 = A_arbace_repr_clojure__init_A_const_pool.A[79]; A_arbace_repr_clojure__init_A_const_46 = lang.Var_Cast(A_arbace_repr_clojure__init_A_const_pool.A[80]); A_arbace_repr_clojure__init_A_const_47 = A_arbace_repr_clojure__init_A_const_pool.A[81]; A_arbace_repr_clojure__init_A_const_48 = lang.Var_Cast(A_arbace_repr_clojure__init_A_const_pool.A[82]); A_arbace_repr_clojure__init_A_const_49 = A_arbace_repr_clojure__init_A_const_pool.A[83]; A_arbace_repr_clojure__init_A_const_50 = lang.Var_Cast(A_arbace_repr_clojure__init_A_const_pool.A[84]); A_arbace_repr_clojure__init_A_const_51 = A_arbace_repr_clojure__init_A_const_pool.A[85] }

func A_arbace_repr_clojure__init_A_clinit_p4() { A_arbace_repr_clojure__init_A_const_52 = lang.Var_Cast(A_arbace_repr_clojure__init_A_const_pool.A[86]); A_arbace_repr_clojure__init_A_const_53 = A_arbace_repr_clojure__init_A_const_pool.A[87]; A_arbace_repr_clojure__init_A_const_54 = lang.Var_Cast(A_arbace_repr_clojure__init_A_const_pool.A[88]); A_arbace_repr_clojure__init_A_const_55 = A_arbace_repr_clojure__init_A_const_pool.A[89]; A_arbace_repr_clojure__init_A_const_56 = lang.Var_Cast(A_arbace_repr_clojure__init_A_const_pool.A[90]); A_arbace_repr_clojure__init_A_const_57 = A_arbace_repr_clojure__init_A_const_pool.A[91] }

func A_arbace_repr_clojure__init_A_New() *A_arbace_repr_clojure__init_A { A_arbace_repr_clojure__init_A_Init(); t := &A_arbace_repr_clojure__init_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_clojure__init_A) Ctor() {}

func (t *A_arbace_repr_clojure__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_clojure__init_A) GetClass__Class() *jrt.Class { return A_arbace_repr_clojure__init_A_class }

func (t *A_arbace_repr_clojure__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_clojure__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_clojure__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_clojure__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_clojure__init_A); return ok }

func A_arbace_repr_clojure__init_A_Cast(x any) *A_arbace_repr_clojure__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_clojure__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_clojure__init_A_class)) }; return v }
