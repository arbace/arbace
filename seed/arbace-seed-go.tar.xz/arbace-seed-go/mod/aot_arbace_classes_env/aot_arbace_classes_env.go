//line aot_arbace_classes_env.ae:1
package aot_arbace_classes_env

import (
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_set"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_New() *A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_classes_env_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_env_A_const_1); lang.IFn_Cast(A_arbace_classes_env_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_classes_env_A_const_3, A_arbace_classes_env_A_const_4, A_arbace_classes_env_A_const_5, A_arbace_classes_env_A_const_6); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_14)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_15)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_16)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_17)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_classes_env_eval28000008_fn__28000009_A_New() *A_arbace_classes_env_eval28000008_fn__28000009_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_eval28000008_fn__28000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_env_eval28000008_fn__28000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_env_eval28000008_fn__28000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_7.GetRawRoot__O()); var tmp2 any; var root_18 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_19 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_18, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_20 lang.IFn; if linked_19 == nil { ifn_20 = lang.IFn_Cast(root_18) } else { ifn_20 = nil }; var arg_21 any = A_arbace_classes_env_A_const_9; if linked_19 == nil { tmp2 = ifn_20.Invoke_O__O(arg_21) } else { tmp2 = linked_19.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_18, arg_21) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_classes_env_A_const_10.GetRawRoot__O(), A_arbace_classes_env_A_const_11) }



























func A_arbace_classes_env_internal_A_New() *A_arbace_classes_env_internal_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_internal_A{}; t.Ctor(); return t }
//line :29:1
func (t *A_arbace_classes_env_internal_A) Ctor() {}
//line :29:1
func (t *A_arbace_classes_env_internal_A) Invoke_O_O__O(self, c__0 any) any { var root_22 any = A_arbace_classes_env_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref(); var arg_26 any = Lit_22; var arg_27 any = Lit_21; if linked_23 == nil { return ifn_24.Invoke_O_O_O__O(arg_25, arg_26, arg_27) } else { return linked_23.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_22, arg_25, arg_26, arg_27) } }







func A_arbace_classes_env_from_source_QMARK__A_New() *A_arbace_classes_env_from_source_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_from_source_QMARK__A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_classes_env_from_source_QMARK__A) Ctor() {}
//line :37:1
func (t *A_arbace_classes_env_from_source_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var tmp1 any; var and__1927000168__auto____2 any = A_arbace_classes_env_A_const_13.Get__O(); if jrt.J2g_Truth(and__1927000168__auto____2) { tmp1 = lang.IFn_Cast(A_arbace_classes_env_A_const_13.Get__O()).Invoke_O__O(n__0) } else { tmp1 = and__1927000168__auto____2 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() }


















func A_arbace_classes_env_record_BANG__A_New() *A_arbace_classes_env_record_BANG__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_record_BANG__A{}; t.Ctor(); return t }
//line :56:1
func (t *A_arbace_classes_env_record_BANG__A) Ctor() {}
//line :56:1
func (t *A_arbace_classes_env_record_BANG__A) Invoke_O_O_O_O__O(self, n__0, facet__1, v__2 any) any {


	if jrt.J2g_Truth(A_arbace_classes_env_A_const_14.Get__O()) { lang.IFn_Cast(A_arbace_classes_env_A_const_15.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_classes_env_A_const_14.Get__O(), A_arbace_classes_env_A_const_16.GetRawRoot__O(), n__0, A_arbace_classes_env_A_const_17.GetRawRoot__O(), facet__1, v__2) }
//line :56:1
	return v__2
}




func A_arbace_classes_env_load_class_A_New() *A_arbace_classes_env_load_class_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_load_class_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_classes_env_load_class_A) Ctor() {}
//line :62:1
func (t *A_arbace_classes_env_load_class_A) Invoke_O_O__O(self, n__0 any) any {



	var tmp1 any; var or__1927000174__auto____2 any; var root_37 any = A_arbace_classes_env_A_const_18.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_37, A_arbace_classes_env_from_source_QMARK__A_fn_class); var ifn_39 lang.IFn; if linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any = n__0; if linked_38 == nil { or__1927000174__auto____2 = ifn_39.Invoke_O__O(arg_40) } else { or__1927000174__auto____2 = linked_38.(*A_arbace_classes_env_from_source_QMARK__A).Invoke_O_O__O(root_37, arg_40) }; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { tmp1 = A_arbace_classes_env_A_const_19.Get__O() }; if jrt.J2g_Truth(tmp1) { return nil } else { var tmp2 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var cn__4 any; var tmp3 any; var root_41 any = A_arbace_classes_env_A_const_20.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_43 lang.IFn

		if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = n__0; var arg_45 any = Lit_11; if linked_42 == nil { tmp3 = ifn_43.Invoke_O_O__O(arg_44, arg_45) } else { tmp3 = linked_42.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_41, arg_44, arg_45) }; if jrt.J2g_Truth(tmp3) { var root_46 any = A_arbace_classes_env_A_const_12.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_48 lang.IFn; if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = n__0; var arg_50 any = Lit_21; var arg_51 any = Lit_22; if linked_47 == nil { cn__4 = ifn_48.Invoke_O_O_O__O(arg_49, arg_50, arg_51) } else { cn__4 = linked_47.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_46, arg_49, arg_50, arg_51) } } else { var root_52 any = A_arbace_classes_env_A_const_12.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_52, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_54 lang.IFn; if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any = n__0; var arg_56 any = Lit_21; var arg_57 any = Lit_22; if linked_53 == nil { cn__4 = ifn_54.Invoke_O_O_O__O(arg_55, arg_56, arg_57) } else { cn__4 = linked_53.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_52, arg_55, arg_56, arg_57) } }
//line :66:1
		var c__5 any = lang.RT_ClassForNameNonLoading_String__Class_NoInit(jrt.String_Cast(cn__4)).Ref(); var tmp4 any
		var and__1927000168__auto____6 any = c__5


		if jrt.J2g_Truth(and__1927000168__auto____6) { tmp4 = A_arbace_classes_env_A_const_14.Get__O() } else { tmp4 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp4) { var root_58 any = A_arbace_classes_env_A_const_21.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_58, A_arbace_classes_env_record_BANG__A_fn_class); var ifn_60 lang.IFn; if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = n__0; var arg_62 any = A_arbace_classes_env_A_const_22; var arg_63 any = jrt.Boolean_TRUE.Ref(); if linked_59 == nil { ifn_60.Invoke_O_O_O__O(arg_61, arg_62, arg_63) } else { linked_59.(*A_arbace_classes_env_record_BANG__A).Invoke_O_O_O_O__O(root_58, arg_61, arg_62, arg_63) } }
//line :66:1
		tmp2 = c__5 }; return nil }(); if tmp5 != nil { if jrt.ClassNotFoundException_InstanceOf(tmp5) { var ___4 *jrt.ClassNotFoundException = jrt.ClassNotFoundException_Cast(tmp5); _ = ___4; tmp2 = nil } else if jrt.NoClassDefFoundError_InstanceOf(tmp5) { var ___4_2 *jrt.NoClassDefFoundError = jrt.NoClassDefFoundError_Cast(tmp5); _ = ___4_2; tmp2 = nil } else { panic(tmp5) } }; return tmp2
	}
}






func A_arbace_classes_env_known_QMARK__A_New() *A_arbace_classes_env_known_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_known_QMARK__A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_classes_env_known_QMARK__A) Ctor() {}
//line :75:1
func (t *A_arbace_classes_env_known_QMARK__A) Invoke_O_O__O(self, n__0 any) any {





	if jrt.J2g_Truth(A_arbace_classes_env_A_const_19.Get__O()) { var and__1927000168__auto____2 any; var root_64 any = A_arbace_classes_env_A_const_23.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_66 lang.IFn; if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any = A_arbace_classes_env_A_const_19.Get__O(); var arg_68 any = n__0; if linked_65 == nil { and__1927000168__auto____2 = ifn_66.Invoke_O_O__O(arg_67, arg_68) } else { and__1927000168__auto____2 = linked_65.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_64, arg_67, arg_68) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_69 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_71 lang.IFn; if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any; var root_73 any = A_arbace_classes_env_A_const_18.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, A_arbace_classes_env_from_source_QMARK__A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = n__0; if linked_74 == nil { arg_72 = ifn_75.Invoke_O__O(arg_76) } else { arg_72 = linked_74.(*A_arbace_classes_env_from_source_QMARK__A).Invoke_O_O__O(root_73, arg_76) }; if linked_70 == nil { return ifn_71.Invoke_O__O(arg_72) } else { return linked_70.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_69, arg_72) } } else { return and__1927000168__auto____2 } } else { var root_77 any = A_arbace_classes_env_A_const_25.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_77, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_79 lang.IFn; if linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var arg_80 any; var root_81 any = A_arbace_classes_env_A_const_26.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, A_arbace_classes_env_load_class_A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = n__0; if linked_82 == nil { arg_80 = ifn_83.Invoke_O__O(arg_84) } else { arg_80 = linked_82.(*A_arbace_classes_env_load_class_A).Invoke_O_O__O(root_81, arg_84) }; if linked_78 == nil { return ifn_79.Invoke_O__O(arg_80) } else { return linked_78.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_77, arg_80)
	} } }
func A_arbace_classes_env_reflected_A_New() *A_arbace_classes_env_reflected_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflected_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_classes_env_reflected_A) Ctor() {}
//line :83:1
func (t *A_arbace_classes_env_reflected_A) Invoke_O_O_O_O__O(self, n__0, facet__1, f__2 any) any {




	if jrt.J2g_Truth(A_arbace_classes_env_A_const_19.Get__O()) { var temp__1927000414__auto____4 any = lang.RT_Get_O_O__O_NoInit(A_arbace_classes_env_A_const_19.Get__O(), n__0)
		if jrt.J2g_Truth(temp__1927000414__auto____4) { var d__5 any = temp__1927000414__auto____4; var temp__1927000408__auto____6 any; var root_85 any = A_arbace_classes_env_A_const_27.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_find_A_fn_class); var ifn_87 lang.IFn
			if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = d__5; var arg_89 any = facet__1; if linked_86 == nil { temp__1927000408__auto____6 = ifn_87.Invoke_O_O__O(arg_88, arg_89) } else { temp__1927000408__auto____6 = linked_86.(*aot_arbace_core.A_arbace_core_find_A).Invoke_O_O_O__O(root_85, arg_88, arg_89) }; if jrt.J2g_Truth(temp__1927000408__auto____6) { var e__7 any = temp__1927000408__auto____6; var root_90 any = A_arbace_classes_env_A_const_28.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_val_A_fn_class); var ifn_92 lang.IFn
				if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = e__7; if linked_91 == nil { return ifn_92.Invoke_O__O(arg_93) } else { return linked_91.(*aot_arbace_core.A_arbace_core_val_A).Invoke_O_O__O(root_90, arg_93) } } else {
//line :90:1
					var tmp1 any; var root_94 any = A_arbace_classes_env_A_const_29.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_96 lang.IFn

					if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_64, nil, Lit_65, nil, Lit_66); var tmp3 any; var root_99 any = A_arbace_classes_env_A_const_30.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_101 lang.IFn; if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any = facet__1; if linked_100 == nil { tmp3 = ifn_101.Invoke_O__O(arg_102) } else { tmp3 = linked_100.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_99, arg_102) }; var tmp4 any = tmp3; var tmp5 any; var root_103 any = A_arbace_classes_env_A_const_12.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_103, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_105 lang.IFn; if linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any; var root_109 any = A_arbace_classes_env_A_const_31.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_109, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_111 lang.IFn; if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any = n__0; if linked_110 == nil { arg_106 = ifn_111.Invoke_O__O(arg_112) } else { arg_106 = linked_110.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_109, arg_112) }; var arg_107 any = Lit_21; var arg_108 any = Lit_22; if linked_104 == nil { tmp5 = ifn_105.Invoke_O_O_O__O(arg_106, arg_107, arg_108) } else { tmp5 = linked_104.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_103, arg_106, arg_107, arg_108) }; arg_97 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp4, nil, tmp5, nil)).Ref(); var arg_98 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_env_A_const_32, n__0, A_arbace_classes_env_A_const_33, facet__1)); if linked_95 == nil { tmp1 = ifn_96.Invoke_O_O__O(arg_97, arg_98) } else { tmp1 = linked_95.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_94, arg_97, arg_98) }
//line :90:1
					panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) } } else {
//line :89:1
						return nil } } else {
//line :88:1
							var temp__1927000414__auto____4_2 any; var root_113 any = A_arbace_classes_env_A_const_26.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_113, A_arbace_classes_env_load_class_A_fn_class); var ifn_115 lang.IFn






							if linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any = n__0; if linked_114 == nil { temp__1927000414__auto____4_2 = ifn_115.Invoke_O__O(arg_116) } else { temp__1927000414__auto____4_2 = linked_114.(*A_arbace_classes_env_load_class_A).Invoke_O_O__O(root_113, arg_116) }; if jrt.J2g_Truth(temp__1927000414__auto____4_2) { var c__5 any = temp__1927000414__auto____4_2; var root_117 any = A_arbace_classes_env_A_const_21.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_117, A_arbace_classes_env_record_BANG__A_fn_class); var ifn_119 lang.IFn
								if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = n__0; var arg_121 any = facet__1; var arg_122 any = lang.IFn_Cast(f__2).Invoke_O__O(c__5); if linked_118 == nil { return ifn_119.Invoke_O_O_O__O(arg_120, arg_121, arg_122) } else { return linked_118.(*A_arbace_classes_env_record_BANG__A).Invoke_O_O_O_O__O(root_117, arg_120, arg_121, arg_122) } } else {
//line :95:1
									return nil
								}
						} }
func A_arbace_classes_env_class_file_QMARK__A_New() *A_arbace_classes_env_class_file_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_class_file_QMARK__A{}; t.Ctor(); return t }
//line :98:1
func (t *A_arbace_classes_env_class_file_QMARK__A) Ctor() {}
//line :98:1
func (t *A_arbace_classes_env_class_file_QMARK__A) Invoke_O_O__O(self, c__0 any) any { var ld__2 any; var or__1927000174__auto____2 any = jrt.NN(jrt.Class_Cast(c__0)).GetClassLoader__ClassLoader(); if





	jrt.J2g_Truth(or__1927000174__auto____2) { ld__2 = or__1927000174__auto____2 } else { ld__2 = jrt.ClassLoader_GetSystemClassLoader__ClassLoader() }; var temp__1927000414__auto____3 any; var tmp1 /*line :98:1*/*jrt.Class = A_arbace_classes_env_A_const_34; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_6); var tmp3 any; var root_123 any = A_arbace_classes_env_A_const_35.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, A_arbace_classes_env_internal_A_fn_class); var ifn_125 lang.IFn; if






	linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = c__0; if linked_124 == nil { tmp3 = ifn_125.Invoke_O__O(arg_126) } else { tmp3 = linked_124.(*A_arbace_classes_env_internal_A).Invoke_O_O__O(root_123, arg_126) }; temp__1927000414__auto____3 = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(ld__2, tmp1, Lit_5, jrt.RefArrayOf(jrt.Object_class, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil)).Ref())); if jrt.J2g_Truth(temp__1927000414__auto____3) { var in__4 any = temp__1927000414__auto____3
		jrt.InputStream_Cast(in__4).Close__V()
//line :105:1
		return jrt.Boolean_TRUE.Ref() } else { return nil } }



func A_arbace_classes_env_read_fields_A_New() *A_arbace_classes_env_read_fields_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_read_fields_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_classes_env_read_fields_A) Ctor() {}
//line :109:1
func (t *A_arbace_classes_env_read_fields_A) Invoke_O_O__O(self, c__0 any) any {




	var tmp1 any; var root_127 any = A_arbace_classes_env_A_const_36.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, A_arbace_classes_env_class_file_QMARK__A_fn_class); var ifn_129 lang.IFn; if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = c__0; if linked_128 == nil { tmp1 = ifn_129.Invoke_O__O(arg_130) } else { tmp1 = linked_128.(*A_arbace_classes_env_class_file_QMARK__A).Invoke_O_O__O(root_127, arg_130) }; if jrt.J2g_Truth(tmp1) {
		var tmp2 any; var root_131 any = A_arbace_classes_env_A_const_37.GetRawRoot__O(); var linked_132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_131, aot_arbace_core.A_arbace_core_requiring_resolve_A_fn_class); var ifn_133 lang.IFn; if linked_132 == nil { ifn_133 = lang.IFn_Cast(root_131) } else { ifn_133 = nil }; var arg_134 any = A_arbace_classes_env_A_const_38; if linked_132 == nil { tmp2 = ifn_133.Invoke_O__O(arg_134) } else { tmp2 = linked_132.(*aot_arbace_core.A_arbace_core_requiring_resolve_A).Invoke_O_O__O(root_131, arg_134) }; return lang.IFn_Cast(tmp2).Invoke_O__O(c__0) } else {
//line :114:1
			return nil
		}
}
func A_arbace_classes_env_read_method_annotations_A_New() *A_arbace_classes_env_read_method_annotations_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_read_method_annotations_A{}; t.Ctor(); return t }
//line :117:1
func (t *A_arbace_classes_env_read_method_annotations_A) Ctor() {}
//line :117:1
func (t *A_arbace_classes_env_read_method_annotations_A) Invoke_O_O__O(self, c__0 any) any {



	var tmp1 any; var root_135 any = A_arbace_classes_env_A_const_36.GetRawRoot__O(); var linked_136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_135, A_arbace_classes_env_class_file_QMARK__A_fn_class); var ifn_137 lang.IFn; if linked_136 == nil { ifn_137 = lang.IFn_Cast(root_135) } else { ifn_137 = nil }; var arg_138 any = c__0; if linked_136 == nil { tmp1 = ifn_137.Invoke_O__O(arg_138) } else { tmp1 = linked_136.(*A_arbace_classes_env_class_file_QMARK__A).Invoke_O_O__O(root_135, arg_138) }; if jrt.J2g_Truth(tmp1) {
		var tmp2 any; var root_139 any = A_arbace_classes_env_A_const_37.GetRawRoot__O(); var linked_140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_139, aot_arbace_core.A_arbace_core_requiring_resolve_A_fn_class); var ifn_141 lang.IFn; if linked_140 == nil { ifn_141 = lang.IFn_Cast(root_139) } else { ifn_141 = nil }; var arg_142 any = A_arbace_classes_env_A_const_39; if linked_140 == nil { tmp2 = ifn_141.Invoke_O__O(arg_142) } else { tmp2 = linked_140.(*aot_arbace_core.A_arbace_core_requiring_resolve_A).Invoke_O_O__O(root_139, arg_142) }; return lang.IFn_Cast(tmp2).Invoke_O__O(c__0) } else {
//line :121:1
			return lang.PersistentArrayMap_EMPTY.Ref()
		}
}

func A_arbace_classes_env_coerce_const_A_New() *A_arbace_classes_env_coerce_const_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_coerce_const_A{}; t.Ctor(); return t }
//line :125:1
func (t *A_arbace_classes_env_coerce_const_A) Ctor() {}
//line :125:1
func (t *A_arbace_classes_env_coerce_const_A) Invoke_O_O_O__O(self, desc__0, v__1 any) any { var G__28000023__3_ any = desc__0; switch
												lang.Util_Hash_O__I_NoInit(G__28000023__3_) { case 66: if lang.Util_Equiv_O_O__Z_NoInit(G__28000023__3_, Lit_7) {



		return jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_ByteCast_O__B_NoInit(v__1)).Ref() }
//line :126:1
	case 67: if lang.Util_Equiv_O_O__Z_NoInit(G__28000023__3_, Lit_8) {

		return jrt.Character_ValueOf_C__Character_NoInit(lang.RT_CharCast_I__C_NoInit(lang.RT_IntCast_O__I_NoInit(v__1))).Ref() }
//line :126:1
	case 83: if lang.Util_Equiv_O_O__Z_NoInit(G__28000023__3_, Lit_9) {


		return jrt.Short_ValueOf_S__Short_NoInit(lang.RT_ShortCast_O__S_NoInit(v__1)).Ref() }
//line :126:1
	case 90: if lang.Util_Equiv_O_O__Z_NoInit(G__28000023__3_, Lit_10) {
		var root_144 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_144, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_146 lang.IFn; if linked_145 == nil { ifn_146 = lang.IFn_Cast(root_144) } else { ifn_146 = nil }; var arg_147 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(v__1))).Ref(); if linked_145 == nil { return ifn_146.Invoke_O__O(arg_147) } else { return linked_145.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_144, arg_147) } }
//line :126:1
	default:}; return v__1 }












func A_arbace_classes_env_inner_member_QMARK__A_New() *A_arbace_classes_env_inner_member_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_inner_member_QMARK__A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_classes_env_inner_member_QMARK__A) Ctor() {}
//line :139:1
func (t *A_arbace_classes_env_inner_member_QMARK__A) Invoke_O_O__O(self, c__0 any) any {
	var tmp1 any; var and__1927000168__auto____2 any = jrt.NN(jrt.Class_Cast(c__0)).GetDeclaringClass__Class().Ref(); if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_148 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_148, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_150 lang.IFn; if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Modifier_IsStatic_I__Z(jrt.NN(jrt.Class_Cast(c__0)).GetModifiers__I())).Ref(); if linked_149 == nil { and__1927000168__auto____3 = ifn_150.Invoke_O__O(arg_151) } else { and__1927000168__auto____3 = linked_149.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_148, arg_151) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_152 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_154 lang.IFn
		if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(c__0)).IsInterface__Z()).Ref(); if linked_153 == nil { and__1927000168__auto____4 = ifn_154.Invoke_O__O(arg_155) } else { and__1927000168__auto____4 = linked_153.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_152, arg_155) }
//line :140:1
		if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_156 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_158 lang.IFn
			if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(c__0)).IsEnum__Z()).Ref(); if linked_157 == nil { and__1927000168__auto____5 = ifn_158.Invoke_O__O(arg_159) } else { and__1927000168__auto____5 = linked_157.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_156, arg_159) }
//line :140:1
			if jrt.J2g_Truth(and__1927000168__auto____5) {
				var root_160 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(c__0)).IsRecord__Z()).Ref(); if linked_161 == nil { tmp1 = ifn_162.Invoke_O__O(arg_163) } else { tmp1 = linked_161.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_160, arg_163) } } else {
//line :140:1
					tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}

func A_arbace_classes_env_reflect_info_A_New() *A_arbace_classes_env_reflect_info_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_A{}; t.Ctor(); return t }
//line :143:1
func (t *A_arbace_classes_env_reflect_info_A) Ctor() {}
//line :143:1
func (t *A_arbace_classes_env_reflect_info_A) Invoke_O_O__O(self, c__0 any) any { var or__1927000174__auto____2 any = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_40.GetRawRoot__O())).Get_O__O(c__0); if
										jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var lockee__1927000360__auto____3 any = A_arbace_classes_env_A_const_40.GetRawRoot__O(); var locklocal__1927000361__auto____6 any = lockee__1927000360__auto____3; lang.Compiler_Evaluator_MonitorEnter_O__V_NoInit(locklocal__1927000361__auto____6); var tmp1 any; tmp42 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var or__1927000174__auto____9 any = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_40.GetRawRoot__O())).Get_O__O(c__0)

		if jrt.J2g_Truth(or__1927000174__auto____9) { tmp1 = or__1927000174__auto____9 } else { var n__10 any; var root_164 any = A_arbace_classes_env_A_const_35.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, A_arbace_classes_env_internal_A_fn_class); var ifn_166 lang.IFn
			if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = c__0; if linked_165 == nil { n__10 = ifn_166.Invoke_O__O(arg_167) } else { n__10 = linked_165.(*A_arbace_classes_env_internal_A).Invoke_O_O__O(root_164, arg_167) }
//line :146:1
			var manns__11 any; var tmp2 *lang.Compiler_AOTFn; var fnbody__173 any = A_arbace_classes_env_reflect_info_fn__28000027_A_New_O(c__0); var tmp3 *jrt.Class
			var fncls__172 /*line :146:1*/*jrt.Class = A_arbace_classes_env_reflect_info_fn__28000027_A_fn_class

			if fncls__172 == nil { var fncls__172d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_31, false, fnbody__173); A_arbace_classes_env_reflect_info_fn__28000027_A_fn_class = fncls__172d; tmp3 = fncls__172d } else { tmp3 = fncls__172 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__173, tmp3, nil)
//line :146:1
			manns__11 = lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp2)); var info__12 any; var tmp4 any = A_arbace_classes_env_A_const_42; var tmp5 any = A_arbace_classes_env_A_const_43; var tmp6 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Class_Cast(c__0)).GetModifiers__I()).Ref(); var tmp7 any = A_arbace_classes_env_A_const_44; var tmp8 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(c__0)).IsInterface__Z()).Ref(); var tmp9 any = A_arbace_classes_env_A_const_45; var tmp10 any; var G__28000029__12_ any = jrt.NN(jrt.Class_Cast(c__0)).GetSuperclass__Class().Ref()





			if lang.Util_Identical_O_O__Z_NoInit(G__28000029__12_, nil) { tmp10 = nil } else { var root_174 any = A_arbace_classes_env_A_const_35.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, A_arbace_classes_env_internal_A_fn_class); var ifn_176 lang.IFn; if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any = G__28000029__12_; if linked_175 == nil { tmp10 = ifn_176.Invoke_O__O(arg_177) } else { tmp10 = linked_175.(*A_arbace_classes_env_internal_A).Invoke_O_O__O(root_174, arg_177) } }
//line :146:1
			var tmp11 any = tmp10; var tmp12 any = A_arbace_classes_env_A_const_46; var tmp13 any; var root_178 any = A_arbace_classes_env_A_const_47.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_178, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_180 lang.IFn






			if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any = A_arbace_classes_env_A_const_35.GetRawRoot__O(); var arg_182 any = jrt.NN(jrt.Class_Cast(c__0)).GetInterfaces__Class1().Ref(); if linked_179 == nil { tmp13 = ifn_180.Invoke_O_O__O(arg_181, arg_182) } else { tmp13 = linked_179.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_178, arg_181, arg_182) }
//line :146:1
			var tmp14 any = tmp13; var tmp15 any = A_arbace_classes_env_A_const_48; var tmp16 any; var root_183 any = A_arbace_classes_env_A_const_35.GetRawRoot__O(); var linked_184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_183, A_arbace_classes_env_internal_A_fn_class); var ifn_185 lang.IFn







			if linked_184 == nil { ifn_185 = lang.IFn_Cast(root_183) } else { ifn_185 = nil }; var arg_186 any = jrt.NN(jrt.Class_Cast(c__0)).GetNestHost__Class().Ref(); if linked_184 == nil { tmp16 = ifn_185.Invoke_O__O(arg_186) } else { tmp16 = linked_184.(*A_arbace_classes_env_internal_A).Invoke_O_O__O(root_183, arg_186) }
//line :146:1
			var tmp17 any = tmp16; var tmp18 any = A_arbace_classes_env_A_const_49; var tmp19 any; var G__28000030__12_ any = jrt.NN(jrt.Class_Cast(c__0)).GetDeclaringClass__Class().Ref()








			if lang.Util_Identical_O_O__Z_NoInit(G__28000030__12_, nil) { tmp19 = nil } else { var root_187 any = A_arbace_classes_env_A_const_35.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_187, A_arbace_classes_env_internal_A_fn_class); var ifn_189 lang.IFn; if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var arg_190 any = G__28000030__12_; if linked_188 == nil { tmp19 = ifn_189.Invoke_O__O(arg_190) } else { tmp19 = linked_188.(*A_arbace_classes_env_internal_A).Invoke_O_O__O(root_187, arg_190) } }
//line :146:1
			var tmp20 any = tmp19; var tmp21 any = A_arbace_classes_env_A_const_50; var tmp22 any; var temp__1927000408__auto____12 any; var root_191 any = A_arbace_classes_env_A_const_51.GetRawRoot__O(); var linked_192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_191, A_arbace_classes_env_read_fields_A_fn_class); var ifn_193 lang.IFn









			if linked_192 == nil { ifn_193 = lang.IFn_Cast(root_191) } else { ifn_193 = nil }; var arg_194 any = c__0; if linked_192 == nil { temp__1927000408__auto____12 = ifn_193.Invoke_O__O(arg_194) } else { temp__1927000408__auto____12 = linked_192.(*A_arbace_classes_env_read_fields_A).Invoke_O_O__O(root_191, arg_194) }; if jrt.J2g_Truth(temp__1927000408__auto____12) { var fs__13 any = temp__1927000408__auto____12; var root_195 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_197 lang.IFn
				if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any; var iter__1927001039__auto____14 any; var fnbody__318 any = A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_New_O(n__10); var tmp23 *jrt.Class; var fncls__317 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_fn_class; if fncls__317 == nil { var fncls__317d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, fnbody__318); A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_fn_class = fncls__317d; tmp23 = fncls__317d } else { tmp23 = fncls__317 }; iter__1927001039__auto____14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__318, tmp23, nil); arg_198 = lang.IFn_Cast(iter__1927001039__auto____14).Invoke_O__O(fs__13); if linked_196 == nil { tmp22 = ifn_197.Invoke_O__O(arg_198) } else { tmp22 = linked_196.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_195, arg_198) } } else {




					var root_319 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_319, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_321 lang.IFn; if linked_320 == nil { ifn_321 = lang.IFn_Cast(root_319) } else { ifn_321 = nil }; var arg_322 any; var iter__1927001039__auto____13 any; var fnbody__400 any = A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_New_O(n__10); var tmp24 *jrt.Class; var fncls__399 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_fn_class; if fncls__399 == nil { var fncls__399d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, fnbody__400); A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_fn_class = fncls__399d; tmp24 = fncls__399d } else { tmp24 = fncls__399 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__400, tmp24, nil); arg_322 = lang.IFn_Cast(iter__1927001039__auto____13).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetDeclaredFields__Field1().Ref()); if linked_320 == nil { tmp22 = ifn_321.Invoke_O__O(arg_322) } else { tmp22 = linked_320.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_319, arg_322) } }
//line :146:1
			var tmp25 any = tmp22; var tmp26 any = A_arbace_classes_env_A_const_75; var tmp27 any; var root_401 any = A_arbace_classes_env_A_const_76.GetRawRoot__O(); var linked_402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_401, A_arbace_classes_env_inner_member_QMARK__A_fn_class); var ifn_403 lang.IFn
























			if linked_402 == nil { ifn_403 = lang.IFn_Cast(root_401) } else { ifn_403 = nil }; var arg_404 any = c__0; if linked_402 == nil { tmp27 = ifn_403.Invoke_O__O(arg_404) } else { tmp27 = linked_402.(*A_arbace_classes_env_inner_member_QMARK__A).Invoke_O_O__O(root_401, arg_404) }
//line :146:1
			var tmp28 any = tmp27; var tmp29 any = A_arbace_classes_env_A_const_77; var tmp30 any; var root_405 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_405, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_407 lang.IFn

























			if linked_406 == nil { ifn_407 = lang.IFn_Cast(root_405) } else { ifn_407 = nil }; var arg_408 any; var root_409 any = A_arbace_classes_env_A_const_78.GetRawRoot__O(); var linked_410 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_409, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_411 lang.IFn; if linked_410 == nil { ifn_411 = lang.IFn_Cast(root_409) } else { ifn_411 = nil }; var arg_412 any; var iter__1927001039__auto____12 any; var fnbody__571 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_New_O_O(n__10, manns__11); var tmp31 *jrt.Class; var fncls__570 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_fn_class
			if fncls__570 == nil { var fncls__570d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_34, false, fnbody__571); A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_fn_class = fncls__570d; tmp31 = fncls__570d } else { tmp31 = fncls__570 }; iter__1927001039__auto____12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__571, tmp31, nil); arg_412 = lang.IFn_Cast(iter__1927001039__auto____12).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetDeclaredMethods__Method1().Ref())
//line :172:1
			var arg_413 any; var iter__1927001039__auto____12_2 any; var fnbody__687 any = A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_New_O_O(c__0, n__10); var tmp32 *jrt.Class
			var fncls__686 /*line :172:1*/*jrt.Class = A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_fn_class











			if fncls__686 == nil { var fncls__686d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, fnbody__687); A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_fn_class = fncls__686d; tmp32 = fncls__686d } else { tmp32 = fncls__686 }; iter__1927001039__auto____12_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__687, tmp32, nil); arg_413 = lang.IFn_Cast(iter__1927001039__auto____12_2).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetDeclaredConstructors__Constructor1().Ref())
//line :172:1
			if linked_410 == nil { arg_408 = ifn_411.Invoke_O_O__O(arg_412, arg_413) } else { arg_408 = linked_410.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_409, arg_412, arg_413) }; if linked_406 == nil { tmp30 = ifn_407.Invoke_O__O(arg_408) } else { tmp30 = linked_406.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_405, arg_408) }
//line :146:1
			info__12 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, n__10, tmp5, tmp6, tmp7, tmp8, tmp9, tmp11, tmp12, tmp14, tmp15, tmp17, tmp18, tmp20, tmp21, tmp25, tmp26, tmp28, tmp29, tmp30, A_arbace_classes_env_A_const_32, c__0)); var info__13 any; var temp__1927000408__auto____13 any; var and__1927000168__auto____13 any; var root_688 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_688, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_690 lang.IFn


















































			if linked_689 == nil { ifn_690 = lang.IFn_Cast(root_688) } else { ifn_690 = nil }; var arg_691 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(c__0)).IsInterface__Z()).Ref(); if linked_689 == nil { and__1927000168__auto____13 = ifn_690.Invoke_O__O(arg_691) } else { and__1927000168__auto____13 = linked_689.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_688, arg_691) }; if jrt.J2g_Truth(and__1927000168__auto____13) {
				var tmp33 any; var root_692 any = A_arbace_classes_env_A_const_37.GetRawRoot__O(); var linked_693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_692, aot_arbace_core.A_arbace_core_requiring_resolve_A_fn_class); var ifn_694 lang.IFn; if linked_693 == nil { ifn_694 = lang.IFn_Cast(root_692) } else { ifn_694 = nil }; var arg_695 any = A_arbace_classes_env_A_const_86; if linked_693 == nil { tmp33 = ifn_694.Invoke_O__O(arg_695) } else { tmp33 = linked_693.(*aot_arbace_core.A_arbace_core_requiring_resolve_A).Invoke_O_O__O(root_692, arg_695) }; temp__1927000408__auto____13 = lang.IFn_Cast(tmp33).Invoke_O__O(n__10) } else {
//line :197:1
					temp__1927000408__auto____13 = and__1927000168__auto____13 }; if jrt.J2g_Truth(temp__1927000408__auto____13) { var pm__14 any = temp__1927000408__auto____13; var have__15 any; var root_696 any = A_arbace_classes_env_A_const_87.GetRawRoot__O(); var linked_697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_696, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_698 lang.IFn

						if linked_697 == nil { ifn_698 = lang.IFn_Cast(root_696) } else { ifn_698 = nil }; var arg_699 any; var root_700 any = A_arbace_classes_env_A_const_80.GetRawRoot__O(); var linked_701 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_700, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_702 lang.IFn; if linked_701 == nil { ifn_702 = lang.IFn_Cast(root_700) } else { ifn_702 = nil }; var arg_703 any; var root_705 any = A_arbace_classes_env_A_const_88.GetRawRoot__O(); var linked_706 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_705, aot_arbace_core.A_arbace_core_juxt_A_fn_class); var ifn_707 lang.IFn; if linked_706 == nil { ifn_707 = lang.IFn_Cast(root_705) } else { ifn_707 = nil }; var arg_708 any = A_arbace_classes_env_A_const_42; var arg_709 any = A_arbace_classes_env_A_const_60; if linked_706 == nil { arg_703 = ifn_707.Invoke_O_O__O(arg_708, arg_709) } else { arg_703 = linked_706.(*aot_arbace_core.A_arbace_core_juxt_A).Invoke_O_O_O__O(root_705, arg_708, arg_709) }; var arg_704 any = A_arbace_classes_env_A_const_77.Invoke_O__O(info__12); if linked_701 == nil { arg_699 = ifn_702.Invoke_O_O__O(arg_703, arg_704) } else { arg_699 = linked_701.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_700, arg_703, arg_704) }; if linked_697 == nil { have__15 = ifn_698.Invoke_O__O(arg_699) } else { have__15 = linked_697.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_696, arg_699) }
//line :197:1
						var fhave__16 any; var root_710 any = A_arbace_classes_env_A_const_87.GetRawRoot__O(); var linked_711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_710, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_712 lang.IFn


						if linked_711 == nil { ifn_712 = lang.IFn_Cast(root_710) } else { ifn_712 = nil }; var arg_713 any; var root_714 any = A_arbace_classes_env_A_const_80.GetRawRoot__O(); var linked_715 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_714, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_716 lang.IFn; if linked_715 == nil { ifn_716 = lang.IFn_Cast(root_714) } else { ifn_716 = nil }; var arg_717 any = A_arbace_classes_env_A_const_42; var arg_718 any = A_arbace_classes_env_A_const_50.Invoke_O__O(info__12); if linked_715 == nil { arg_713 = ifn_716.Invoke_O_O__O(arg_717, arg_718) } else { arg_713 = linked_715.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_714, arg_717, arg_718) }; if linked_711 == nil { fhave__16 = ifn_712.Invoke_O__O(arg_713) } else { fhave__16 = linked_711.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_710, arg_713)
						}






						var root_719 any = A_arbace_classes_env_A_const_16.GetRawRoot__O(); var linked_720 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_719, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_721 lang.IFn; if linked_720 == nil { ifn_721 = lang.IFn_Cast(root_719) } else { ifn_721 = nil }; var arg_722 any; var root_726 any = A_arbace_classes_env_A_const_16.GetRawRoot__O(); var linked_727 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_726, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_728 lang.IFn
//line :202:1
						if linked_727 == nil { ifn_728 = lang.IFn_Cast(root_726) } else { ifn_728 = nil }; var arg_729 any = info__12; var arg_730 any = A_arbace_classes_env_A_const_77; var arg_731 any = A_arbace_classes_env_A_const_89.GetRawRoot__O(); var arg_732 any; var root_733 any = A_arbace_classes_env_A_const_78.GetRawRoot__O(); var linked_734 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_733, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_735 lang.IFn
						if linked_734 == nil { ifn_735 = lang.IFn_Cast(root_733) } else { ifn_735 = nil }; var arg_736 any; var iter__1927001039__auto____17 any; var fnbody__811 any = A_arbace_classes_env_reflect_info_iter__28000089__28000093_A_New_O_O(n__10, have__15); var tmp34 *jrt.Class; var fncls__810 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000089__28000093_A_fn_class
						if fncls__810 == nil { var fncls__810d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_36, false, fnbody__811); A_arbace_classes_env_reflect_info_iter__28000089__28000093_A_fn_class = fncls__810d; tmp34 = fncls__810d } else { tmp34 = fncls__810 }; iter__1927001039__auto____17 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__811, tmp34, nil); arg_736 = lang.IFn_Cast(iter__1927001039__auto____17).Invoke_O__O(A_arbace_classes_env_A_const_77.Invoke_O__O(pm__14))
//line :203:1
						var arg_737 any; var iter__1927001039__auto____17_2 any; var fnbody__885 any = A_arbace_classes_env_reflect_info_iter__28000105__28000109_A_New_O_O(n__10, have__15); var tmp35 *jrt.Class
						var fncls__884 /*line :203:1*/*jrt.Class = A_arbace_classes_env_reflect_info_iter__28000105__28000109_A_fn_class


						if fncls__884 == nil { var fncls__884d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_37, false, fnbody__885); A_arbace_classes_env_reflect_info_iter__28000105__28000109_A_fn_class = fncls__884d; tmp35 = fncls__884d } else { tmp35 = fncls__884 }; iter__1927001039__auto____17_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__885, tmp35, nil); arg_737 = lang.IFn_Cast(iter__1927001039__auto____17_2).Invoke_O__O(A_arbace_classes_env_A_const_90.Invoke_O__O(pm__14))
//line :203:1
						if linked_734 == nil { arg_732 = ifn_735.Invoke_O_O__O(arg_736, arg_737) } else { arg_732 = linked_734.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_733, arg_736, arg_737) }
//line :202:1
						if linked_727 == nil { arg_722 = ifn_728.Invoke_O_O_O_O__O(arg_729, arg_730, arg_731, arg_732) } else { arg_722 = linked_727.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_726, arg_729, arg_730, arg_731, arg_732)
						}




						var arg_723 any = A_arbace_classes_env_A_const_50; var arg_724 any = A_arbace_classes_env_A_const_89.GetRawRoot__O(); var arg_725 any; var iter__1927001039__auto____17_3 any; var fnbody__959 any = A_arbace_classes_env_reflect_info_iter__28000121__28000125_A_New_O_O(n__10, fhave__16); var tmp36 *jrt.Class; var fncls__958 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000121__28000125_A_fn_class
						if fncls__958 == nil { var fncls__958d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_38, false, fnbody__959); A_arbace_classes_env_reflect_info_iter__28000121__28000125_A_fn_class = fncls__958d; tmp36 = fncls__958d } else { tmp36 = fncls__958 }; iter__1927001039__auto____17_3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__959, tmp36, nil); arg_725 = lang.IFn_Cast(iter__1927001039__auto____17_3).Invoke_O__O(A_arbace_classes_env_A_const_50.Invoke_O__O(pm__14))
//line :208:1
						if linked_720 == nil { info__13 = ifn_721.Invoke_O_O_O_O__O(arg_722, arg_723, arg_724, arg_725) } else { info__13 = linked_720.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_719, arg_722, arg_723, arg_724, arg_725) } } else {
//line :197:1
							info__13 = info__12 }
//line :146:1
			var info__14 any; var tmp37 any; var and__1927000168__auto____14 any; var root_960 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_960, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_962 lang.IFn

































































			if linked_961 == nil { ifn_962 = lang.IFn_Cast(root_960) } else { ifn_962 = nil }; var arg_963 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(c__0)).IsInterface__Z()).Ref(); if linked_961 == nil { and__1927000168__auto____14 = ifn_962.Invoke_O__O(arg_963) } else { and__1927000168__auto____14 = linked_961.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_960, arg_963) }; if jrt.J2g_Truth(and__1927000168__auto____14) { var root_964 any = A_arbace_classes_env_A_const_91.GetRawRoot__O(); var linked_965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_964, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_966 lang.IFn; if linked_965 == nil { ifn_966 = lang.IFn_Cast(root_964) } else { ifn_966 = nil }; var arg_967 any; var root_968 any = A_arbace_classes_env_A_const_92.GetRawRoot__O(); var linked_969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_968, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_970 lang.IFn; if linked_969 == nil { ifn_970 = lang.IFn_Cast(root_968) } else { ifn_970 = nil }; var arg_971 any; var fnbody__974 any = A_arbace_classes_env_reflect_info_fn__28000137_A_New(); var tmp38 *jrt.Class; var fncls__973 *jrt.Class = A_arbace_classes_env_reflect_info_fn__28000137_A_fn_class; if fncls__973 == nil { var fncls__973d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_39, false, nil); A_arbace_classes_env_reflect_info_fn__28000137_A_fn_class = fncls__973d; tmp38 = fncls__973d } else { tmp38 = fncls__973 }; arg_971 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__974, tmp38, nil); var arg_972 any = A_arbace_classes_env_A_const_77.Invoke_O__O(info__13); if linked_969 == nil { arg_967 = ifn_970.Invoke_O_O__O(arg_971, arg_972) } else { arg_967 = linked_969.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_968, arg_971, arg_972) }; if linked_965 == nil { tmp37 = ifn_966.Invoke_O__O(arg_967) } else { tmp37 = linked_965.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_964, arg_967) } } else { tmp37 = and__1927000168__auto____14 }; if jrt.J2g_Truth(tmp37) {
				var root_975 any = A_arbace_classes_env_A_const_16.GetRawRoot__O(); var linked_976 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_975, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_977 lang.IFn; if linked_976 == nil { ifn_977 = lang.IFn_Cast(root_975) } else { ifn_977 = nil }; var arg_978 any = info__13; var arg_979 any = A_arbace_classes_env_A_const_77; var arg_980 any = A_arbace_classes_env_A_const_89.GetRawRoot__O(); var arg_981 any; var iter__1927001039__auto____14_2 any; var fnbody__1043 any = A_arbace_classes_env_reflect_info_iter__28000139__28000143_A_New_O(n__10); var tmp39 *jrt.Class; var fncls__1042 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000139__28000143_A_fn_class; if fncls__1042 == nil { var fncls__1042d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, fnbody__1043); A_arbace_classes_env_reflect_info_iter__28000139__28000143_A_fn_class = fncls__1042d; tmp39 = fncls__1042d } else { tmp39 = fncls__1042 }; iter__1927001039__auto____14_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1043, tmp39, nil); var tmp40 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____14_2); var tmp41 any; var root_1044 any = A_arbace_classes_env_A_const_37.GetRawRoot__O(); var linked_1045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1044, aot_arbace_core.A_arbace_core_requiring_resolve_A_fn_class); var ifn_1046 lang.IFn; if linked_1045 == nil { ifn_1046 = lang.IFn_Cast(root_1044) } else { ifn_1046 = nil }; var arg_1047 any = A_arbace_classes_env_A_const_93; if linked_1045 == nil { tmp41 = ifn_1046.Invoke_O__O(arg_1047) } else { tmp41 = linked_1045.(*aot_arbace_core.A_arbace_core_requiring_resolve_A).Invoke_O_O__O(root_1044, arg_1047) }; arg_981 = tmp40.Invoke_O__O(lang.IFn_Cast(tmp41).Invoke_O__O(n__10)); if linked_976 == nil { info__14 = ifn_977.Invoke_O_O_O_O__O(arg_978, arg_979, arg_980, arg_981) } else { info__14 = linked_976.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_975, arg_978, arg_979, arg_980, arg_981) } } else {
//line :212:1
					info__14 = info__13
				}


			jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_40.GetRawRoot__O())).Put_O_O__O(c__0, info__14)
//line :146:1
			tmp1 = info__14 } }; return nil }()
//line :144:1
		lang.Compiler_Evaluator_MonitorExit_O__V_NoInit(locklocal__1927000361__auto____6); if tmp42 != nil { panic(tmp42) }; return tmp1 } }



func A_arbace_classes_env_reflect_info_fn__28000027_A_New_O(p0 any) *A_arbace_classes_env_reflect_info_fn__28000027_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_fn__28000027_A{}; t.Ctor_O(p0); return t }
//line :148:1
func (t *A_arbace_classes_env_reflect_info_fn__28000027_A) Ctor_O(c__c any) { t.F_c = c__c }
//line :148:1
func (t *A_arbace_classes_env_reflect_info_fn__28000027_A) Invoke_O__O(self any) any { var root_168 any = A_arbace_classes_env_A_const_41.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, A_arbace_classes_env_read_method_annotations_A_fn_class); var ifn_170 lang.IFn; if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any; var t_ any = t.F_c; t.F_c = nil; arg_171 = t_; if linked_169 == nil { return ifn_170.Invoke_O__O(arg_171) } else { return linked_169.(*A_arbace_classes_env_read_method_annotations_A).Invoke_O_O__O(root_168, arg_171) } }








func A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_New_O(p0 any) *A_arbace_classes_env_reflect_info_iter__28000031__28000035_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000031__28000035_A{}; t.Ctor_O(p0); return t }
//line :157:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :157:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_A) Invoke_O_O__O(self, s__28000032__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__316 any = A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_New_O_O_O(t.F_n, s__28000032__1, self); var tmp2 *jrt.Class; var fncls__315 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_fn_class; if fncls__315 == nil { var fncls__315d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, fnbody__316); A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_fn_class = fncls__315d; tmp2 = fncls__315d } else { tmp2 = fncls__315 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__316, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :157:1
func A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :157:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A) Ctor_O_O_O(c__n, c__s__28000032, c__iter__28000031 any) { t.F_n = c__n; t.F_s__28000032 = c__s__28000032; t.F_iter__28000031 = c__iter__28000031 }
//line :157:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A) Invoke_O__O(self any) any { { var s__28000032__1 any; var t_ any = t.F_s__28000032; t.F_s__28000032 = nil; s__28000032__1 = t_; for { var temp__1927000414__auto____2 any; var root_199 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_201 lang.IFn; if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any = s__28000032__1; if linked_200 == nil { temp__1927000414__auto____2 = ifn_201.Invoke_O__O(arg_202) } else { temp__1927000414__auto____2 = linked_200.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_199, arg_202) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__28000032__3 any = temp__1927000414__auto____2; var tmp1 any; var root_203 any = A_arbace_classes_env_A_const_54.GetRawRoot__O(); var linked_204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_203, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_205 lang.IFn; if linked_204 == nil { ifn_205 = lang.IFn_Cast(root_203) } else { ifn_205 = nil }; var arg_206 any = s__28000032__3; if linked_204 == nil { tmp1 = ifn_205.Invoke_O__O(arg_206) } else { tmp1 = linked_204.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_203, arg_206) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_207 any = A_arbace_classes_env_A_const_55.GetRawRoot__O(); var linked_208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_207, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_209 lang.IFn; if linked_208 == nil { ifn_209 = lang.IFn_Cast(root_207) } else { ifn_209 = nil }; var arg_210 any = s__28000032__3; if linked_208 == nil { c__1927001037__auto____4 = ifn_209.Invoke_O__O(arg_210) } else { c__1927001037__auto____4 = linked_208.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_207, arg_210) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__28000034__6 any; var root_211 any = A_arbace_classes_env_A_const_56.GetRawRoot__O(); var linked_212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_211, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_213 lang.IFn; if linked_212 == nil { ifn_213 = lang.IFn_Cast(root_211) } else { ifn_213 = nil }; var arg_214 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_212 == nil { b__28000034__6 = ifn_213.Invoke_O__O(arg_214) } else { b__28000034__6 = linked_212.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_211, arg_214) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__250 any = A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_New_O_O_I_O(b__28000034__6, t.F_n, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__249 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_fn_class; if fncls__249 == nil { var fncls__249d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_42, false, fnbody__250); A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_fn_class = fncls__249d; tmp3 = fncls__249d } else { tmp3 = fncls__249 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__250, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_251 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_251, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_253 lang.IFn; if linked_252 == nil { ifn_253 = lang.IFn_Cast(root_251) } else { ifn_253 = nil }; var arg_254 any; var root_256 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_256, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_258 lang.IFn; if linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any = b__28000034__6; if linked_257 == nil { arg_254 = ifn_258.Invoke_O__O(arg_259) } else { arg_254 = linked_257.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_256, arg_259) }; var arg_255 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__28000031); var tmp5 any; var root_260 any = A_arbace_classes_env_A_const_70.GetRawRoot__O(); var linked_261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_260, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_262 lang.IFn; if linked_261 == nil { ifn_262 = lang.IFn_Cast(root_260) } else { ifn_262 = nil }; var arg_263 any = s__28000032__3; if linked_261 == nil { tmp5 = ifn_262.Invoke_O__O(arg_263) } else { tmp5 = linked_261.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_260, arg_263) }; arg_255 = tmp4.Invoke_O__O(tmp5); if linked_252 == nil { return ifn_253.Invoke_O_O__O(arg_254, arg_255) } else { return linked_252.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_251, arg_254, arg_255) } } else { var root_264 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_264, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_266 lang.IFn; if linked_265 == nil { ifn_266 = lang.IFn_Cast(root_264) } else { ifn_266 = nil }; var arg_267 any; var root_269 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_269, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_271 lang.IFn; if linked_270 == nil { ifn_271 = lang.IFn_Cast(root_269) } else { ifn_271 = nil }; var arg_272 any = b__28000034__6; if linked_270 == nil { arg_267 = ifn_271.Invoke_O__O(arg_272) } else { arg_267 = linked_270.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_269, arg_272) }; var arg_268 any; if linked_265 == nil { return ifn_266.Invoke_O_O__O(arg_267, arg_268) } else { return linked_265.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_264, arg_267, arg_268) } } } else { var map__28000041__4 any; var root_273 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_273, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_275 lang.IFn; if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = s__28000032__3; if linked_274 == nil { map__28000041__4 = ifn_275.Invoke_O__O(arg_276) } else { map__28000041__4 = linked_274.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_273, arg_276) }; var map__28000041__5 any; if lang.ISeq_InstanceOf(map__28000041__4) { var tmp6 any; var root_277 any = A_arbace_classes_env_A_const_57.GetRawRoot__O(); var linked_278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_277, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_279 lang.IFn; if linked_278 == nil { ifn_279 = lang.IFn_Cast(root_277) } else { ifn_279 = nil }; var arg_280 any = map__28000041__4; if linked_278 == nil { tmp6 = ifn_279.Invoke_O__O(arg_280) } else { tmp6 = linked_278.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_277, arg_280) }; if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_281 any = A_arbace_classes_env_A_const_58.GetRawRoot__O(); var linked_282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_281, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_283 lang.IFn; if linked_282 == nil { ifn_283 = lang.IFn_Cast(root_281) } else { ifn_283 = nil }; var arg_284 any = map__28000041__4; if linked_282 == nil { tmp7 = ifn_283.Invoke_O__O(arg_284) } else { tmp7 = linked_282.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_281, arg_284) }; map__28000041__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp7)).Ref() } else { var tmp8 any; var root_285 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_285, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_287 lang.IFn; if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any = map__28000041__4; if linked_286 == nil { tmp8 = ifn_287.Invoke_O__O(arg_288) } else { tmp8 = linked_286.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_285, arg_288) }; if jrt.J2g_Truth(tmp8) { var root_289 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_289, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_291 lang.IFn; if linked_290 == nil { ifn_291 = lang.IFn_Cast(root_289) } else { ifn_291 = nil }; var arg_292 any = map__28000041__4; if linked_290 == nil { map__28000041__5 = ifn_291.Invoke_O__O(arg_292) } else { map__28000041__5 = linked_290.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_289, arg_292) } } else { map__28000041__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__28000041__5 = map__28000041__4 }; var name__6 any = lang.RT_Get_O_O__O_NoInit(map__28000041__5, A_arbace_classes_env_A_const_42); var desc__7 any = lang.RT_Get_O_O__O_NoInit(map__28000041__5, A_arbace_classes_env_A_const_60); var flags__8 any = lang.RT_Get_O_O__O_NoInit(map__28000041__5, A_arbace_classes_env_A_const_43); var value__9 any = lang.RT_Get_O_O__O_NoInit(map__28000041__5, A_arbace_classes_env_A_const_61); var root_293 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_293, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_295 lang.IFn; if linked_294 == nil { ifn_295 = lang.IFn_Cast(root_293) } else { ifn_295 = nil }; var arg_296 any; var tmp9 any = A_arbace_classes_env_A_const_42; var tmp10 any = A_arbace_classes_env_A_const_60; var tmp11 any = A_arbace_classes_env_A_const_43; var tmp12 any = A_arbace_classes_env_A_const_63; var tmp13 any = t.F_n; var tmp14 any = A_arbace_classes_env_A_const_64; var tmp15 any; var tmp16 any; var and__1927000168__auto____10 bool = jrt.Modifier_IsFinal_I__Z(lang.RT_IntCast_O__I_NoInit(flags__8))

	if and__1927000168__auto____10 { var and__1927000168__auto____11 any; var root_298 any = A_arbace_classes_env_A_const_25.GetRawRoot__O(); var linked_299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_298, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_300 lang.IFn; if linked_299 == nil { ifn_300 = lang.IFn_Cast(root_298) } else { ifn_300 = nil }; var arg_301 any = value__9; if linked_299 == nil { and__1927000168__auto____11 = ifn_300.Invoke_O__O(arg_301) } else { and__1927000168__auto____11 = linked_299.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_298, arg_301) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var or__1927000174__auto____12 any; var root_302 any = A_arbace_classes_env_A_const_65.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_302, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_304 lang.IFn
		if linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any = desc__7; if linked_303 == nil { or__1927000174__auto____12 = ifn_304.Invoke_O__O(arg_305) } else { or__1927000174__auto____12 = linked_303.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_302, arg_305) }; if jrt.J2g_Truth(or__1927000174__auto____12) { tmp16 = or__1927000174__auto____12 } else { tmp16 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(desc__7, A_arbace_classes_env_A_const_66.GetRawRoot__O())).Ref() } } else {
//line :159:1
			tmp16 = and__1927000168__auto____11 } } else { tmp16 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10).Ref() }; if jrt.J2g_Truth(tmp16) {

				var root_306 any = A_arbace_classes_env_A_const_67.GetRawRoot__O(); var linked_307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_306, A_arbace_classes_env_coerce_const_A_fn_class); var ifn_308 lang.IFn; if linked_307 == nil { ifn_308 = lang.IFn_Cast(root_306) } else { ifn_308 = nil }; var arg_309 any = desc__7; var arg_310 any = value__9; if linked_307 == nil { tmp15 = ifn_308.Invoke_O_O__O(arg_309, arg_310) } else { tmp15 = linked_307.(*A_arbace_classes_env_coerce_const_A).Invoke_O_O_O__O(root_306, arg_309, arg_310) } } else {
//line :159:1
					tmp15 = nil }
//line :157:1
	arg_296 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, name__6, tmp10, desc__7, tmp11, flags__8, tmp12, tmp13, tmp14, tmp15)); var arg_297 any; var tmp17 lang.IFn = lang.IFn_Cast(t.F_iter__28000031); var tmp18 any; var root_311 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_311, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_313 lang.IFn; if linked_312 == nil { ifn_313 = lang.IFn_Cast(root_311) } else { ifn_313 = nil }; var arg_314 any = s__28000032__3; if linked_312 == nil { tmp18 = ifn_313.Invoke_O__O(arg_314) } else { tmp18 = linked_312.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_311, arg_314) }; arg_297 = tmp17.Invoke_O__O(tmp18); if linked_294 == nil { return ifn_295.Invoke_O_O__O(arg_296, arg_297) } else { return linked_294.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_293, arg_296, arg_297) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :157:1
func A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :157:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A) Ctor_O_O_I_O(c__b__28000034, c__n any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__28000034 = c__b__28000034; t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :157:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A) Invoke_O__O(self any) any { { var i__28000033__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__28000033__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var map__28000038__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__28000033__1)); var map__28000038__3 any; if lang.ISeq_InstanceOf(map__28000038__2) { var tmp2 any; var root_215 any = A_arbace_classes_env_A_const_57.GetRawRoot__O(); var linked_216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_215, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_217 lang.IFn; if linked_216 == nil { ifn_217 = lang.IFn_Cast(root_215) } else { ifn_217 = nil }; var arg_218 any = map__28000038__2; if linked_216 == nil { tmp2 = ifn_217.Invoke_O__O(arg_218) } else { tmp2 = linked_216.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_215, arg_218) }; if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_219 any = A_arbace_classes_env_A_const_58.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_219, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_221 lang.IFn; if linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any = map__28000038__2; if linked_220 == nil { tmp3 = ifn_221.Invoke_O__O(arg_222) } else { tmp3 = linked_220.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_219, arg_222) }; map__28000038__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp3)).Ref() } else { var tmp4 any; var root_223 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_223, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_225 lang.IFn; if linked_224 == nil { ifn_225 = lang.IFn_Cast(root_223) } else { ifn_225 = nil }; var arg_226 any = map__28000038__2; if linked_224 == nil { tmp4 = ifn_225.Invoke_O__O(arg_226) } else { tmp4 = linked_224.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_223, arg_226) }; if jrt.J2g_Truth(tmp4) { var root_227 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_229 lang.IFn; if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any = map__28000038__2; if linked_228 == nil { map__28000038__3 = ifn_229.Invoke_O__O(arg_230) } else { map__28000038__3 = linked_228.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_227, arg_230) } } else { map__28000038__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__28000038__3 = map__28000038__2 }; var name__4 any = lang.RT_Get_O_O__O_NoInit(map__28000038__3, A_arbace_classes_env_A_const_42); var desc__5 any = lang.RT_Get_O_O__O_NoInit(map__28000038__3, A_arbace_classes_env_A_const_60); var flags__6 any = lang.RT_Get_O_O__O_NoInit(map__28000038__3, A_arbace_classes_env_A_const_43); var value__7 any = lang.RT_Get_O_O__O_NoInit(map__28000038__3, A_arbace_classes_env_A_const_61); var root_231 any = A_arbace_classes_env_A_const_62.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_231, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_233 lang.IFn; if linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any = t.F_b__28000034; var arg_235 any; var tmp5 any = A_arbace_classes_env_A_const_42; var tmp6 any = A_arbace_classes_env_A_const_60; var tmp7 any = A_arbace_classes_env_A_const_43; var tmp8 any = A_arbace_classes_env_A_const_63; var tmp9 any = t.F_n; var tmp10 any = A_arbace_classes_env_A_const_64; var tmp11 any; var tmp12 any; var and__1927000168__auto____8 bool = jrt.Modifier_IsFinal_I__Z(lang.RT_IntCast_O__I_NoInit(flags__6))

	if and__1927000168__auto____8 { var and__1927000168__auto____9 any; var root_236 any = A_arbace_classes_env_A_const_25.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_236, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_238 lang.IFn; if linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any = value__7; if linked_237 == nil { and__1927000168__auto____9 = ifn_238.Invoke_O__O(arg_239) } else { and__1927000168__auto____9 = linked_237.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_236, arg_239) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var or__1927000174__auto____10 any; var root_240 any = A_arbace_classes_env_A_const_65.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_240, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_242 lang.IFn
		if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any = desc__5; if linked_241 == nil { or__1927000174__auto____10 = ifn_242.Invoke_O__O(arg_243) } else { or__1927000174__auto____10 = linked_241.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_240, arg_243) }; if jrt.J2g_Truth(or__1927000174__auto____10) { tmp12 = or__1927000174__auto____10 } else { tmp12 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(desc__5, A_arbace_classes_env_A_const_66.GetRawRoot__O())).Ref() } } else {
//line :159:1
			tmp12 = and__1927000168__auto____9 } } else { tmp12 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() }; if jrt.J2g_Truth(tmp12) {

				var root_244 any = A_arbace_classes_env_A_const_67.GetRawRoot__O(); var linked_245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_244, A_arbace_classes_env_coerce_const_A_fn_class); var ifn_246 lang.IFn; if linked_245 == nil { ifn_246 = lang.IFn_Cast(root_244) } else { ifn_246 = nil }; var arg_247 any = desc__5; var arg_248 any = value__7; if linked_245 == nil { tmp11 = ifn_246.Invoke_O_O__O(arg_247, arg_248) } else { tmp11 = linked_245.(*A_arbace_classes_env_coerce_const_A).Invoke_O_O_O__O(root_244, arg_247, arg_248) } } else {
//line :159:1
					tmp11 = nil }
//line :157:1
	arg_235 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, name__4, tmp6, desc__5, tmp7, flags__6, tmp8, tmp9, tmp10, tmp11)); if linked_232 == nil { ifn_233.Invoke_O_O__O(arg_234, arg_235) } else { linked_232.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_231, arg_234, arg_235) }; i__28000033__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000033__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_New_O(p0 any) *A_arbace_classes_env_reflect_info_iter__28000045__28000049_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000045__28000049_A{}; t.Ctor_O(p0); return t }
//line :162:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :162:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_A) Invoke_O_O__O(self, s__28000046__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__398 any = A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_New_O_O_O(t.F_n, s__28000046__1, self); var tmp2 *jrt.Class; var fncls__397 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_fn_class; if fncls__397 == nil { var fncls__397d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_43, false, fnbody__398); A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_fn_class = fncls__397d; tmp2 = fncls__397d } else { tmp2 = fncls__397 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__398, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :162:1
func A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :162:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A) Ctor_O_O_O(c__n, c__s__28000046, c__iter__28000045 any) { t.F_n = c__n; t.F_s__28000046 = c__s__28000046; t.F_iter__28000045 = c__iter__28000045 }
//line :162:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A) Invoke_O__O(self any) any { { var s__28000046__1 any; var t_ any = t.F_s__28000046; t.F_s__28000046 = nil; s__28000046__1 = t_; for { var temp__1927000414__auto____2 any; var root_323 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_323, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_325 lang.IFn; if linked_324 == nil { ifn_325 = lang.IFn_Cast(root_323) } else { ifn_325 = nil }; var arg_326 any = s__28000046__1; if linked_324 == nil { temp__1927000414__auto____2 = ifn_325.Invoke_O__O(arg_326) } else { temp__1927000414__auto____2 = linked_324.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_323, arg_326) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__28000046__3 any = temp__1927000414__auto____2; var tmp1 any; var root_327 any = A_arbace_classes_env_A_const_54.GetRawRoot__O(); var linked_328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_327, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_329 lang.IFn; if linked_328 == nil { ifn_329 = lang.IFn_Cast(root_327) } else { ifn_329 = nil }; var arg_330 any = s__28000046__3; if linked_328 == nil { tmp1 = ifn_329.Invoke_O__O(arg_330) } else { tmp1 = linked_328.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_327, arg_330) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_331 any = A_arbace_classes_env_A_const_55.GetRawRoot__O(); var linked_332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_331, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_333 lang.IFn; if linked_332 == nil { ifn_333 = lang.IFn_Cast(root_331) } else { ifn_333 = nil }; var arg_334 any = s__28000046__3; if linked_332 == nil { c__1927001037__auto____4 = ifn_333.Invoke_O__O(arg_334) } else { c__1927001037__auto____4 = linked_332.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_331, arg_334) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__28000048__6 any; var root_335 any = A_arbace_classes_env_A_const_56.GetRawRoot__O(); var linked_336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_335, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_337 lang.IFn; if linked_336 == nil { ifn_337 = lang.IFn_Cast(root_335) } else { ifn_337 = nil }; var arg_338 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_336 == nil { b__28000048__6 = ifn_337.Invoke_O__O(arg_338) } else { b__28000048__6 = linked_336.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_335, arg_338) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__353 any = A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_New_O_O_I_O(t.F_n, b__28000048__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__352 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_fn_class; if fncls__352 == nil { var fncls__352d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, fnbody__353); A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_fn_class = fncls__352d; tmp3 = fncls__352d } else { tmp3 = fncls__352 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__353, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_354 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_354, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_356 lang.IFn; if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any; var root_359 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_361 lang.IFn; if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any = b__28000048__6; if linked_360 == nil { arg_357 = ifn_361.Invoke_O__O(arg_362) } else { arg_357 = linked_360.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_359, arg_362) }; var arg_358 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__28000045); var tmp5 any; var root_363 any = A_arbace_classes_env_A_const_70.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_363, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_365 lang.IFn; if linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any = s__28000046__3; if linked_364 == nil { tmp5 = ifn_365.Invoke_O__O(arg_366) } else { tmp5 = linked_364.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_363, arg_366) }; arg_358 = tmp4.Invoke_O__O(tmp5); if linked_355 == nil { return ifn_356.Invoke_O_O__O(arg_357, arg_358) } else { return linked_355.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_354, arg_357, arg_358) } } else { var root_367 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_367, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_369 lang.IFn; if linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any; var root_372 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_372, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_374 lang.IFn; if linked_373 == nil { ifn_374 = lang.IFn_Cast(root_372) } else { ifn_374 = nil }; var arg_375 any = b__28000048__6; if linked_373 == nil { arg_370 = ifn_374.Invoke_O__O(arg_375) } else { arg_370 = linked_373.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_372, arg_375) }; var arg_371 any; if linked_368 == nil { return ifn_369.Invoke_O_O__O(arg_370, arg_371) } else { return linked_368.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_367, arg_370, arg_371) } } } else { var f__4 any; var root_376 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_376, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_378 lang.IFn; if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any = s__28000046__3; if linked_377 == nil { f__4 = ifn_378.Invoke_O__O(arg_379) } else { f__4 = linked_377.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_376, arg_379) }; var desc__5 any; var root_380 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_380, aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A_fn_class); var ifn_382 lang.IFn
														if linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any = jrt.NN(jrt.Field_Cast(f__4)).GetType__Class().Ref(); if linked_381 == nil { desc__5 = ifn_382.Invoke_O__O(arg_383) } else { desc__5 = linked_381.(*aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A).Invoke_O_O__O(root_380, arg_383) }
//line :162:1
	var flags__6 int32 = jrt.NN(jrt.Field_Cast(f__4)).GetModifiers__I(); var root_384 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_384, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_386 lang.IFn; if linked_385 == nil { ifn_386 = lang.IFn_Cast(root_384) } else { ifn_386 = nil }; var arg_387 any; var tmp6 any = A_arbace_classes_env_A_const_42; var tmp7 any = jrt.NN(jrt.Field_Cast(f__4)).GetName__String().Ref(); var tmp8 any = A_arbace_classes_env_A_const_60; var tmp9 any = A_arbace_classes_env_A_const_43; var tmp10 any = jrt.Integer_ValueOf_I__Integer_NoInit(flags__6).Ref(); var tmp11 any = A_arbace_classes_env_A_const_63; var tmp12 any = t.F_n; var tmp13 any = A_arbace_classes_env_A_const_64; var tmp14 any; var tmp15 bool; var and__1927000168__auto____7 bool = jrt.Modifier_IsStatic_I__Z(flags__6)





	if and__1927000168__auto____7 { tmp15 = jrt.Modifier_IsFinal_I__Z(flags__6) } else { tmp15 = and__1927000168__auto____7 }; if tmp15 {
		var tmp16 any; var root_389 any = A_arbace_classes_env_A_const_37.GetRawRoot__O(); var linked_390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_389, aot_arbace_core.A_arbace_core_requiring_resolve_A_fn_class); var ifn_391 lang.IFn; if linked_390 == nil { ifn_391 = lang.IFn_Cast(root_389) } else { ifn_391 = nil }; var arg_392 any = A_arbace_classes_env_A_const_74; if linked_390 == nil { tmp16 = ifn_391.Invoke_O__O(arg_392) } else { tmp16 = linked_390.(*aot_arbace_core.A_arbace_core_requiring_resolve_A).Invoke_O_O__O(root_389, arg_392) }; var tmp17 lang.IFn = lang.IFn_Cast(tmp16); var tmp18 any = t.F_n; tmp14 = tmp17.Invoke_O_O_O__O(tmp18, jrt.NN(jrt.Field_Cast(f__4)).GetName__String().Ref(), desc__5) } else {
//line :168:1
			tmp14 = nil }
//line :162:1
	arg_387 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7, tmp8, desc__5, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14)); var arg_388 any; var tmp19 lang.IFn = lang.IFn_Cast(t.F_iter__28000045); var tmp20 any; var root_393 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_393, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_395 lang.IFn; if linked_394 == nil { ifn_395 = lang.IFn_Cast(root_393) } else { ifn_395 = nil }; var arg_396 any = s__28000046__3; if linked_394 == nil { tmp20 = ifn_395.Invoke_O__O(arg_396) } else { tmp20 = linked_394.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_393, arg_396) }; arg_388 = tmp19.Invoke_O__O(tmp20); if linked_385 == nil { return ifn_386.Invoke_O_O__O(arg_387, arg_388) } else { return linked_385.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_384, arg_387, arg_388) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :162:1
func A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :162:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A) Ctor_O_O_I_O(c__n, c__b__28000048 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__28000048 = c__b__28000048; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :162:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A) Invoke_O__O(self any) any { { var i__28000047__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__28000047__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__28000047__1)); var desc__3 any; var root_339 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var linked_340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_339, aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A_fn_class); var ifn_341 lang.IFn
																if linked_340 == nil { ifn_341 = lang.IFn_Cast(root_339) } else { ifn_341 = nil }; var arg_342 any = jrt.NN(jrt.Field_Cast(f__2)).GetType__Class().Ref(); if linked_340 == nil { desc__3 = ifn_341.Invoke_O__O(arg_342) } else { desc__3 = linked_340.(*aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A).Invoke_O_O__O(root_339, arg_342) }
//line :162:1
	var flags__4 int32 = jrt.NN(jrt.Field_Cast(f__2)).GetModifiers__I(); var root_343 any = A_arbace_classes_env_A_const_62.GetRawRoot__O(); var linked_344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_343, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_345 lang.IFn; if linked_344 == nil { ifn_345 = lang.IFn_Cast(root_343) } else { ifn_345 = nil }; var arg_346 any = t.F_b__28000048; var arg_347 any; var tmp2 any = A_arbace_classes_env_A_const_42; var tmp3 any = jrt.NN(jrt.Field_Cast(f__2)).GetName__String().Ref(); var tmp4 any = A_arbace_classes_env_A_const_60; var tmp5 any = A_arbace_classes_env_A_const_43; var tmp6 any = jrt.Integer_ValueOf_I__Integer_NoInit(flags__4).Ref(); var tmp7 any = A_arbace_classes_env_A_const_63; var tmp8 any = t.F_n; var tmp9 any = A_arbace_classes_env_A_const_64; var tmp10 any; var tmp11 bool; var and__1927000168__auto____5 bool = jrt.Modifier_IsStatic_I__Z(flags__4)





	if and__1927000168__auto____5 { tmp11 = jrt.Modifier_IsFinal_I__Z(flags__4) } else { tmp11 = and__1927000168__auto____5 }; if tmp11 {
		var tmp12 any; var root_348 any = A_arbace_classes_env_A_const_37.GetRawRoot__O(); var linked_349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_348, aot_arbace_core.A_arbace_core_requiring_resolve_A_fn_class); var ifn_350 lang.IFn; if linked_349 == nil { ifn_350 = lang.IFn_Cast(root_348) } else { ifn_350 = nil }; var arg_351 any = A_arbace_classes_env_A_const_74; if linked_349 == nil { tmp12 = ifn_350.Invoke_O__O(arg_351) } else { tmp12 = linked_349.(*aot_arbace_core.A_arbace_core_requiring_resolve_A).Invoke_O_O__O(root_348, arg_351) }; var tmp13 lang.IFn = lang.IFn_Cast(tmp12); var tmp14 any = t.F_n; tmp10 = tmp13.Invoke_O_O_O__O(tmp14, jrt.NN(jrt.Field_Cast(f__2)).GetName__String().Ref(), desc__3) } else {
//line :168:1
			tmp10 = nil }
//line :162:1
	arg_347 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, desc__3, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10)); if linked_344 == nil { ifn_345.Invoke_O_O__O(arg_346, arg_347) } else { linked_344.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_343, arg_346, arg_347) }; i__28000047__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000047__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }










func A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_New_O_O(p0, p1 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_A{}; t.Ctor_O_O(p0, p1); return t }
//line :173:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_A) Ctor_O_O(c__n, c__manns any) { t.F_n = c__n; t.F_manns = c__manns }
//line :173:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_A) Invoke_O_O__O(self, s__28000056__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__569 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_New_O_O_O_O(t.F_n, t.F_manns, s__28000056__1, self); var tmp2 *jrt.Class; var fncls__568 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_fn_class; if fncls__568 == nil { var fncls__568d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_45, false, fnbody__569); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_fn_class = fncls__568d; tmp2 = fncls__568d } else { tmp2 = fncls__568 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__569, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :173:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :173:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A) Ctor_O_O_O_O(c__n, c__manns, c__s__28000056, c__iter__28000055 any) { t.F_n = c__n; t.F_manns = c__manns; t.F_s__28000056 = c__s__28000056; t.F_iter__28000055 = c__iter__28000055 }
//line :173:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A) Invoke_O__O(self any) any { { var s__28000056__1 any; var t_ any = t.F_s__28000056; t.F_s__28000056 = nil; s__28000056__1 = t_; for { var temp__1927000414__auto____2 any; var root_414 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_414, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_416 lang.IFn; if linked_415 == nil { ifn_416 = lang.IFn_Cast(root_414) } else { ifn_416 = nil }; var arg_417 any = s__28000056__1; if linked_415 == nil { temp__1927000414__auto____2 = ifn_416.Invoke_O__O(arg_417) } else { temp__1927000414__auto____2 = linked_415.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_414, arg_417) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__28000056__3 any = temp__1927000414__auto____2; var tmp1 any; var root_418 any = A_arbace_classes_env_A_const_54.GetRawRoot__O(); var linked_419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_418, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_420 lang.IFn; if linked_419 == nil { ifn_420 = lang.IFn_Cast(root_418) } else { ifn_420 = nil }; var arg_421 any = s__28000056__3; if linked_419 == nil { tmp1 = ifn_420.Invoke_O__O(arg_421) } else { tmp1 = linked_419.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_418, arg_421) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_422 any = A_arbace_classes_env_A_const_55.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_422, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_424 lang.IFn; if linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any = s__28000056__3; if linked_423 == nil { c__1927001037__auto____4 = ifn_424.Invoke_O__O(arg_425) } else { c__1927001037__auto____4 = linked_423.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_422, arg_425) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__28000058__6 any; var root_426 any = A_arbace_classes_env_A_const_56.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_426, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_428 lang.IFn; if linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_427 == nil { b__28000058__6 = ifn_428.Invoke_O__O(arg_429) } else { b__28000058__6 = linked_427.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_426, arg_429) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__484 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_New_O_O_O_I_O(t.F_n, b__28000058__6, t.F_manns, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__483 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_fn_class; if fncls__483 == nil { var fncls__483d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_46, false, fnbody__484); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_fn_class = fncls__483d; tmp3 = fncls__483d } else { tmp3 = fncls__483 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__484, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_485 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_485, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_487 lang.IFn; if linked_486 == nil { ifn_487 = lang.IFn_Cast(root_485) } else { ifn_487 = nil }; var arg_488 any; var root_490 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_490, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_492 lang.IFn; if linked_491 == nil { ifn_492 = lang.IFn_Cast(root_490) } else { ifn_492 = nil }; var arg_493 any = b__28000058__6; if linked_491 == nil { arg_488 = ifn_492.Invoke_O__O(arg_493) } else { arg_488 = linked_491.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_490, arg_493) }; var arg_489 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__28000055); var tmp5 any; var root_494 any = A_arbace_classes_env_A_const_70.GetRawRoot__O(); var linked_495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_494, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_496 lang.IFn; if linked_495 == nil { ifn_496 = lang.IFn_Cast(root_494) } else { ifn_496 = nil }; var arg_497 any = s__28000056__3; if linked_495 == nil { tmp5 = ifn_496.Invoke_O__O(arg_497) } else { tmp5 = linked_495.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_494, arg_497) }; arg_489 = tmp4.Invoke_O__O(tmp5); if linked_486 == nil { return ifn_487.Invoke_O_O__O(arg_488, arg_489) } else { return linked_486.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_485, arg_488, arg_489) } } else { var root_498 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any; var root_503 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any = b__28000058__6; if linked_504 == nil { arg_501 = ifn_505.Invoke_O__O(arg_506) } else { arg_501 = linked_504.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_503, arg_506) }; var arg_502 any; if linked_499 == nil { return ifn_500.Invoke_O_O__O(arg_501, arg_502) } else { return linked_499.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_498, arg_501, arg_502) } } } else { var m__4 any; var root_507 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = s__28000056__3; if linked_508 == nil { m__4 = ifn_509.Invoke_O__O(arg_510) } else { m__4 = linked_508.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_507, arg_510) }; var desc__5 any; var root_511 any = A_arbace_classes_env_A_const_79.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, aot_arbace_classes_types.A_arbace_classes_types_method_desc_A_fn_class); var ifn_513 lang.IFn
														if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any; var root_516 any = A_arbace_classes_env_A_const_80.GetRawRoot__O(); var linked_517 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_516, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_518 lang.IFn; if linked_517 == nil { ifn_518 = lang.IFn_Cast(root_516) } else { ifn_518 = nil }; var arg_519 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var arg_520 any = jrt.NN(jrt.Method_Cast(m__4)).GetParameterTypes__Class1().Ref(); if linked_517 == nil { arg_514 = ifn_518.Invoke_O_O__O(arg_519, arg_520) } else { arg_514 = linked_517.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_516, arg_519, arg_520) }; var arg_515 any; var root_521 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var linked_522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_521, aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A_fn_class); var ifn_523 lang.IFn
														if linked_522 == nil { ifn_523 = lang.IFn_Cast(root_521) } else { ifn_523 = nil }; var arg_524 any = jrt.NN(jrt.Method_Cast(m__4)).GetReturnType__Class().Ref(); if linked_522 == nil { arg_515 = ifn_523.Invoke_O__O(arg_524) } else { arg_515 = linked_522.(*aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A).Invoke_O_O__O(root_521, arg_524) }
//line :174:1
	if linked_512 == nil { desc__5 = ifn_513.Invoke_O_O__O(arg_514, arg_515) } else { desc__5 = linked_512.(*aot_arbace_classes_types.A_arbace_classes_types_method_desc_A).Invoke_O_O_O__O(root_511, arg_514, arg_515) }
//line :173:1
	var root_525 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_525, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_527 lang.IFn; if linked_526 == nil { ifn_527 = lang.IFn_Cast(root_525) } else { ifn_527 = nil }; var arg_528 any; var tmp6 any = A_arbace_classes_env_A_const_42; var tmp7 any = jrt.NN(jrt.Method_Cast(m__4)).GetName__String().Ref(); var tmp8 any = A_arbace_classes_env_A_const_60; var tmp9 any = A_arbace_classes_env_A_const_43; var tmp10 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Method_Cast(m__4)).GetModifiers__I()).Ref(); var tmp11 any = A_arbace_classes_env_A_const_63; var tmp12 any = t.F_n; var tmp13 any = A_arbace_classes_env_A_const_81; var tmp14 any; var root_530 any = A_arbace_classes_env_A_const_47.GetRawRoot__O(); var linked_531 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_530, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_532 lang.IFn





	if linked_531 == nil { ifn_532 = lang.IFn_Cast(root_530) } else { ifn_532 = nil }; var arg_533 any = A_arbace_classes_env_A_const_35.GetRawRoot__O(); var arg_534 any = jrt.NN(jrt.Method_Cast(m__4)).GetExceptionTypes__Class1().Ref(); if linked_531 == nil { tmp14 = ifn_532.Invoke_O_O__O(arg_533, arg_534) } else { tmp14 = linked_531.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_530, arg_533, arg_534) }
//line :173:1
	var tmp15 any = tmp14; var tmp16 any = A_arbace_classes_env_A_const_82; var tmp17 *lang.Compiler_AOTFn; var fnbody__545 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_New_O_O_O(m__4, desc__5, t.F_manns); var tmp18 *jrt.Class
	var fncls__544 /*line :173:1*/*jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_fn_class






	if fncls__544 == nil { var fncls__544d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_47, false, fnbody__545); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_fn_class = fncls__544d; tmp18 = fncls__544d } else { tmp18 = fncls__544 }; tmp17 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__545, tmp18, nil)
//line :173:1
	var tmp19 any = lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp17)); var tmp20 any = A_arbace_classes_env_A_const_84; var tmp21 any; var root_546 any = A_arbace_classes_env_A_const_85.GetRawRoot__O(); var linked_547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_546, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_548 lang.IFn







	if linked_547 == nil { ifn_548 = lang.IFn_Cast(root_546) } else { ifn_548 = nil }; var arg_549 any; var fnbody__563 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_New_O_O_O(m__4, desc__5, t.F_manns); var tmp22 *jrt.Class; var fncls__562 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_fn_class
	if fncls__562 == nil { var fncls__562d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_48, false, fnbody__563); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_fn_class = fncls__562d; tmp22 = fncls__562d } else { tmp22 = fncls__562 }; arg_549 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__563, tmp22, nil)
//line :181:1
	var arg_550 any = jrt.NN(jrt.Method_Cast(m__4)).GetParameterTypes__Class1().Ref(); if linked_547 == nil { tmp21 = ifn_548.Invoke_O_O__O(arg_549, arg_550) } else { tmp21 = linked_547.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_546, arg_549, arg_550) }
//line :173:1
	arg_528 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7, tmp8, desc__5, tmp9, tmp10, tmp11, tmp12, tmp13, tmp15, tmp16, tmp19, tmp20, tmp21)); var arg_529 any; var tmp23 lang.IFn = lang.IFn_Cast(t.F_iter__28000055); var tmp24 any; var root_564 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_564, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_566 lang.IFn; if linked_565 == nil { ifn_566 = lang.IFn_Cast(root_564) } else { ifn_566 = nil }; var arg_567 any = s__28000056__3; if linked_565 == nil { tmp24 = ifn_566.Invoke_O__O(arg_567) } else { tmp24 = linked_565.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_564, arg_567) }; arg_529 = tmp23.Invoke_O__O(tmp24); if linked_526 == nil { return ifn_527.Invoke_O_O__O(arg_528, arg_529) } else { return linked_526.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_525, arg_528, arg_529) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :173:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :173:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A) Ctor_O_O_O_I_O(c__n, c__b__28000058, c__manns any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__28000058 = c__b__28000058; t.F_manns = c__manns; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :173:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A) Invoke_O__O(self any) any { { var i__28000057__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__28000057__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__28000057__1)); var desc__3 any; var root_430 any = A_arbace_classes_env_A_const_79.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_430, aot_arbace_classes_types.A_arbace_classes_types_method_desc_A_fn_class); var ifn_432 lang.IFn
																if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any; var root_435 any = A_arbace_classes_env_A_const_80.GetRawRoot__O(); var linked_436 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_435, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_437 lang.IFn; if linked_436 == nil { ifn_437 = lang.IFn_Cast(root_435) } else { ifn_437 = nil }; var arg_438 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var arg_439 any = jrt.NN(jrt.Method_Cast(m__2)).GetParameterTypes__Class1().Ref(); if linked_436 == nil { arg_433 = ifn_437.Invoke_O_O__O(arg_438, arg_439) } else { arg_433 = linked_436.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_435, arg_438, arg_439) }; var arg_434 any; var root_440 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var linked_441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_440, aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A_fn_class); var ifn_442 lang.IFn
																if linked_441 == nil { ifn_442 = lang.IFn_Cast(root_440) } else { ifn_442 = nil }; var arg_443 any = jrt.NN(jrt.Method_Cast(m__2)).GetReturnType__Class().Ref(); if linked_441 == nil { arg_434 = ifn_442.Invoke_O__O(arg_443) } else { arg_434 = linked_441.(*aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A).Invoke_O_O__O(root_440, arg_443) }
//line :174:1
	if linked_431 == nil { desc__3 = ifn_432.Invoke_O_O__O(arg_433, arg_434) } else { desc__3 = linked_431.(*aot_arbace_classes_types.A_arbace_classes_types_method_desc_A).Invoke_O_O_O__O(root_430, arg_433, arg_434) }
//line :173:1
	var root_444 any = A_arbace_classes_env_A_const_62.GetRawRoot__O(); var linked_445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_444, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_446 lang.IFn; if linked_445 == nil { ifn_446 = lang.IFn_Cast(root_444) } else { ifn_446 = nil }; var arg_447 any = t.F_b__28000058; var arg_448 any; var tmp2 any = A_arbace_classes_env_A_const_42; var tmp3 any = jrt.NN(jrt.Method_Cast(m__2)).GetName__String().Ref(); var tmp4 any = A_arbace_classes_env_A_const_60; var tmp5 any = A_arbace_classes_env_A_const_43; var tmp6 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Method_Cast(m__2)).GetModifiers__I()).Ref(); var tmp7 any = A_arbace_classes_env_A_const_63; var tmp8 any = t.F_n; var tmp9 any = A_arbace_classes_env_A_const_81; var tmp10 any; var root_449 any = A_arbace_classes_env_A_const_47.GetRawRoot__O(); var linked_450 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_449, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_451 lang.IFn





	if linked_450 == nil { ifn_451 = lang.IFn_Cast(root_449) } else { ifn_451 = nil }; var arg_452 any = A_arbace_classes_env_A_const_35.GetRawRoot__O(); var arg_453 any = jrt.NN(jrt.Method_Cast(m__2)).GetExceptionTypes__Class1().Ref(); if linked_450 == nil { tmp10 = ifn_451.Invoke_O_O__O(arg_452, arg_453) } else { tmp10 = linked_450.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_449, arg_452, arg_453) }
//line :173:1
	var tmp11 any = tmp10; var tmp12 any = A_arbace_classes_env_A_const_82; var tmp13 *lang.Compiler_AOTFn; var fnbody__464 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_New_O_O_O(m__2, desc__3, t.F_manns); var tmp14 *jrt.Class
	var fncls__463 /*line :173:1*/*jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_fn_class






	if fncls__463 == nil { var fncls__463d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_49, false, fnbody__464); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_fn_class = fncls__463d; tmp14 = fncls__463d } else { tmp14 = fncls__463 }; tmp13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__464, tmp14, nil)
//line :173:1
	var tmp15 any = lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp13)); var tmp16 any = A_arbace_classes_env_A_const_84; var tmp17 any; var root_465 any = A_arbace_classes_env_A_const_85.GetRawRoot__O(); var linked_466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_465, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_467 lang.IFn







	if linked_466 == nil { ifn_467 = lang.IFn_Cast(root_465) } else { ifn_467 = nil }; var arg_468 any; var fnbody__482 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_New_O_O_O(m__2, desc__3, t.F_manns); var tmp18 *jrt.Class; var fncls__481 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_fn_class
	if fncls__481 == nil { var fncls__481d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_50, false, fnbody__482); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_fn_class = fncls__481d; tmp18 = fncls__481d } else { tmp18 = fncls__481 }; arg_468 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__482, tmp18, nil)
//line :181:1
	var arg_469 any = jrt.NN(jrt.Method_Cast(m__2)).GetParameterTypes__Class1().Ref(); if linked_466 == nil { tmp17 = ifn_467.Invoke_O_O__O(arg_468, arg_469) } else { tmp17 = linked_466.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_465, arg_468, arg_469) }
//line :173:1
	arg_448 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, desc__3, tmp5, tmp6, tmp7, tmp8, tmp9, tmp11, tmp12, tmp15, tmp16, tmp17)); if linked_445 == nil { ifn_446.Invoke_O_O__O(arg_447, arg_448) } else { linked_445.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_444, arg_447, arg_448) }; i__28000057__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000057__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :180:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A) Ctor_O_O_O(c__m, c__desc, c__manns any) { t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :180:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A) Invoke_O__O(self any) any { var root_454 any = A_arbace_classes_env_A_const_83.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_456 lang.IFn; if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any; var root_459 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_459, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_461 lang.IFn; if linked_460 == nil { ifn_461 = lang.IFn_Cast(root_459) } else { ifn_461 = nil }; var arg_462 any; var t_ any = t.F_manns; t.F_manns = nil; arg_462 = t_; if linked_460 == nil { arg_457 = ifn_461.Invoke_O__O(arg_462) } else { arg_457 = linked_460.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_459, arg_462) }; var arg_458 any; var tmp1 any; var t__2 any = t.F_m; t.F_m = nil; tmp1 = t__2; var tmp2 any = jrt.NN(jrt.Method_Cast(tmp1)).GetName__String().Ref(); var tmp3 any; var t__3 any = t.F_desc; t.F_desc = nil; tmp3 = t__3; arg_458 = lang.Tuple_Create_O_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3), A_arbace_classes_env_A_const_82); if linked_455 == nil { return ifn_456.Invoke_O_O__O(arg_457, arg_458) } else { return linked_455.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_454, arg_457, arg_458) } }
//line :180:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :180:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A) Ctor_O_O_O(c__m, c__desc, c__manns any) { t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :180:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A) Invoke_O__O(self any) any { var root_535 any = A_arbace_classes_env_A_const_83.GetRawRoot__O(); var linked_536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_535, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_537 lang.IFn; if linked_536 == nil { ifn_537 = lang.IFn_Cast(root_535) } else { ifn_537 = nil }; var arg_538 any; var root_540 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_540, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_542 lang.IFn; if linked_541 == nil { ifn_542 = lang.IFn_Cast(root_540) } else { ifn_542 = nil }; var arg_543 any; var t_ any = t.F_manns; t.F_manns = nil; arg_543 = t_; if linked_541 == nil { arg_538 = ifn_542.Invoke_O__O(arg_543) } else { arg_538 = linked_541.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_540, arg_543) }; var arg_539 any; var tmp1 any; var t__2 any = t.F_m; t.F_m = nil; tmp1 = t__2; var tmp2 any = jrt.NN(jrt.Method_Cast(tmp1)).GetName__String().Ref(); var tmp3 any; var t__3 any = t.F_desc; t.F_desc = nil; tmp3 = t__3; arg_539 = lang.Tuple_Create_O_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3), A_arbace_classes_env_A_const_82); if linked_536 == nil { return ifn_537.Invoke_O_O__O(arg_538, arg_539) } else { return linked_536.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_535, arg_538, arg_539) } }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :182:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A) Ctor_O_O_O(c__m, c__desc, c__manns any) { t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :182:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A) Invoke_O_O_O__O(self, i__1, ___2 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__480 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_New_O_O_O_O(i__1, t.F_m, t.F_desc, t.F_manns); var tmp2 *jrt.Class; var fncls__479 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_fn_class; if fncls__479 == nil { var fncls__479d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_51, false, fnbody__480); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_fn_class = fncls__479d; tmp2 = fncls__479d } else { tmp2 = fncls__479 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__480, tmp2, nil); return lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :182:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :182:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A) Ctor_O_O_O_O(c__i, c__m, c__desc, c__manns any) { t.F_i = c__i; t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :182:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A) Invoke_O__O(self any) any { var root_470 any = A_arbace_classes_env_A_const_83.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_472 lang.IFn; if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any; var root_475 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_477 lang.IFn; if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any; var t_ any = t.F_manns; t.F_manns = nil; arg_478 = t_; if linked_476 == nil { arg_473 = ifn_477.Invoke_O__O(arg_478) } else { arg_473 = linked_476.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_475, arg_478) }; var arg_474 any; var tmp1 any; var t__2 any = t.F_m; t.F_m = nil; tmp1 = t__2; var tmp2 any = jrt.NN(jrt.Method_Cast(tmp1)).GetName__String().Ref(); var tmp3 any; var t__3 any = t.F_desc; t.F_desc = nil; tmp3 = t__3; var tmp4 any = lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3); var tmp5 any = A_arbace_classes_env_A_const_84; var tmp6 any; var t__4 any = t.F_i; t.F_i = nil; tmp6 = t__4; arg_474 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp4, tmp5, tmp6); if linked_471 == nil { return ifn_472.Invoke_O_O__O(arg_473, arg_474) } else { return linked_471.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_470, arg_473, arg_474) } }
//line :182:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :182:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A) Ctor_O_O_O(c__m, c__desc, c__manns any) { t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :182:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A) Invoke_O_O_O__O(self, i__1, ___2 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__561 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_New_O_O_O_O(i__1, t.F_m, t.F_desc, t.F_manns); var tmp2 *jrt.Class; var fncls__560 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_fn_class; if fncls__560 == nil { var fncls__560d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_52, false, fnbody__561); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_fn_class = fncls__560d; tmp2 = fncls__560d } else { tmp2 = fncls__560 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__561, tmp2, nil); return lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :182:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :182:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A) Ctor_O_O_O_O(c__i, c__m, c__desc, c__manns any) { t.F_i = c__i; t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :182:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A) Invoke_O__O(self any) any { var root_551 any = A_arbace_classes_env_A_const_83.GetRawRoot__O(); var linked_552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_551, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_553 lang.IFn; if linked_552 == nil { ifn_553 = lang.IFn_Cast(root_551) } else { ifn_553 = nil }; var arg_554 any; var root_556 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_556, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_558 lang.IFn; if linked_557 == nil { ifn_558 = lang.IFn_Cast(root_556) } else { ifn_558 = nil }; var arg_559 any; var t_ any = t.F_manns; t.F_manns = nil; arg_559 = t_; if linked_557 == nil { arg_554 = ifn_558.Invoke_O__O(arg_559) } else { arg_554 = linked_557.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_556, arg_559) }; var arg_555 any; var tmp1 any; var t__2 any = t.F_m; t.F_m = nil; tmp1 = t__2; var tmp2 any = jrt.NN(jrt.Method_Cast(tmp1)).GetName__String().Ref(); var tmp3 any; var t__3 any = t.F_desc; t.F_desc = nil; tmp3 = t__3; var tmp4 any = lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3); var tmp5 any = A_arbace_classes_env_A_const_84; var tmp6 any; var t__4 any = t.F_i; t.F_i = nil; tmp6 = t__4; arg_555 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp4, tmp5, tmp6); if linked_552 == nil { return ifn_553.Invoke_O_O__O(arg_554, arg_555) } else { return linked_552.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_551, arg_554, arg_555) } }

func A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_New_O_O(p0, p1 any) *A_arbace_classes_env_reflect_info_iter__28000077__28000081_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000077__28000081_A{}; t.Ctor_O_O(p0, p1); return t }
//line :184:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_A) Ctor_O_O(c__c, c__n any) { t.F_c = c__c; t.F_n = c__n }
//line :184:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_A) Invoke_O_O__O(self, s__28000078__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__685 any = A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_New_O_O_O_O(t.F_c, t.F_n, s__28000078__1, self); var tmp2 *jrt.Class; var fncls__684 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_fn_class; if fncls__684 == nil { var fncls__684d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_53, false, fnbody__685); A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_fn_class = fncls__684d; tmp2 = fncls__684d } else { tmp2 = fncls__684 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__685, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :184:1
func A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :184:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A) Ctor_O_O_O_O(c__c, c__n, c__s__28000078, c__iter__28000077 any) { t.F_c = c__c; t.F_n = c__n; t.F_s__28000078 = c__s__28000078; t.F_iter__28000077 = c__iter__28000077 }
//line :184:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A) Invoke_O__O(self any) any { { var s__28000078__1 any; var t_ any = t.F_s__28000078; t.F_s__28000078 = nil; s__28000078__1 = t_; for { var temp__1927000414__auto____2 any; var root_572 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_572, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_574 lang.IFn; if linked_573 == nil { ifn_574 = lang.IFn_Cast(root_572) } else { ifn_574 = nil }; var arg_575 any = s__28000078__1; if linked_573 == nil { temp__1927000414__auto____2 = ifn_574.Invoke_O__O(arg_575) } else { temp__1927000414__auto____2 = linked_573.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_572, arg_575) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__28000078__3 any = temp__1927000414__auto____2; var tmp1 any; var root_576 any = A_arbace_classes_env_A_const_54.GetRawRoot__O(); var linked_577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_576, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_578 lang.IFn; if linked_577 == nil { ifn_578 = lang.IFn_Cast(root_576) } else { ifn_578 = nil }; var arg_579 any = s__28000078__3; if linked_577 == nil { tmp1 = ifn_578.Invoke_O__O(arg_579) } else { tmp1 = linked_577.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_576, arg_579) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_580 any = A_arbace_classes_env_A_const_55.GetRawRoot__O(); var linked_581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_580, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_582 lang.IFn; if linked_581 == nil { ifn_582 = lang.IFn_Cast(root_580) } else { ifn_582 = nil }; var arg_583 any = s__28000078__3; if linked_581 == nil { c__1927001037__auto____4 = ifn_582.Invoke_O__O(arg_583) } else { c__1927001037__auto____4 = linked_581.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_580, arg_583) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__28000080__6 any; var root_584 any = A_arbace_classes_env_A_const_56.GetRawRoot__O(); var linked_585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_584, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_586 lang.IFn; if linked_585 == nil { ifn_586 = lang.IFn_Cast(root_584) } else { ifn_586 = nil }; var arg_587 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_585 == nil { b__28000080__6 = ifn_586.Invoke_O__O(arg_587) } else { b__28000080__6 = linked_585.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_584, arg_587) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__621 any = A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_New_O_O_O_I_O(t.F_c, t.F_n, b__28000080__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__620 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_fn_class; if fncls__620 == nil { var fncls__620d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_54, false, fnbody__621); A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_fn_class = fncls__620d; tmp3 = fncls__620d } else { tmp3 = fncls__620 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__621, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_622 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_622, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_624 lang.IFn; if linked_623 == nil { ifn_624 = lang.IFn_Cast(root_622) } else { ifn_624 = nil }; var arg_625 any; var root_627 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_627, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_629 lang.IFn; if linked_628 == nil { ifn_629 = lang.IFn_Cast(root_627) } else { ifn_629 = nil }; var arg_630 any = b__28000080__6; if linked_628 == nil { arg_625 = ifn_629.Invoke_O__O(arg_630) } else { arg_625 = linked_628.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_627, arg_630) }; var arg_626 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__28000077); var tmp5 any; var root_631 any = A_arbace_classes_env_A_const_70.GetRawRoot__O(); var linked_632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_631, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_633 lang.IFn; if linked_632 == nil { ifn_633 = lang.IFn_Cast(root_631) } else { ifn_633 = nil }; var arg_634 any = s__28000078__3; if linked_632 == nil { tmp5 = ifn_633.Invoke_O__O(arg_634) } else { tmp5 = linked_632.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_631, arg_634) }; arg_626 = tmp4.Invoke_O__O(tmp5); if linked_623 == nil { return ifn_624.Invoke_O_O__O(arg_625, arg_626) } else { return linked_623.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_622, arg_625, arg_626) } } else { var root_635 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_635, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_637 lang.IFn; if linked_636 == nil { ifn_637 = lang.IFn_Cast(root_635) } else { ifn_637 = nil }; var arg_638 any; var root_640 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_640, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_642 lang.IFn; if linked_641 == nil { ifn_642 = lang.IFn_Cast(root_640) } else { ifn_642 = nil }; var arg_643 any = b__28000080__6; if linked_641 == nil { arg_638 = ifn_642.Invoke_O__O(arg_643) } else { arg_638 = linked_641.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_640, arg_643) }; var arg_639 any; if linked_636 == nil { return ifn_637.Invoke_O_O__O(arg_638, arg_639) } else { return linked_636.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_635, arg_638, arg_639) } } } else { var m__4 any; var root_644 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_644, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_646 lang.IFn; if linked_645 == nil { ifn_646 = lang.IFn_Cast(root_644) } else { ifn_646 = nil }; var arg_647 any = s__28000078__3; if linked_645 == nil { m__4 = ifn_646.Invoke_O__O(arg_647) } else { m__4 = linked_645.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_644, arg_647) }; var root_648 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_648, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_650 lang.IFn; if linked_649 == nil { ifn_650 = lang.IFn_Cast(root_648) } else { ifn_650 = nil }; var arg_651 any; var tmp6 any = A_arbace_classes_env_A_const_42; var tmp7 any = A_arbace_classes_env_A_const_60; var tmp8 any; var root_653 any = A_arbace_classes_env_A_const_79.GetRawRoot__O(); var linked_654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_653, aot_arbace_classes_types.A_arbace_classes_types_method_desc_A_fn_class); var ifn_655 lang.IFn

	if linked_654 == nil { ifn_655 = lang.IFn_Cast(root_653) } else { ifn_655 = nil }; var arg_656 any; var root_658 any = A_arbace_classes_env_A_const_80.GetRawRoot__O(); var linked_659 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_658, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_660 lang.IFn; if linked_659 == nil { ifn_660 = lang.IFn_Cast(root_658) } else { ifn_660 = nil }; var arg_661 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var arg_662 any; var G__28000086__5_ any; var root_663 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_663, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_665 lang.IFn; if linked_664 == nil { ifn_665 = lang.IFn_Cast(root_663) } else { ifn_665 = nil }; var arg_666 any = jrt.NN(jrt.Constructor_Cast(m__4)).GetParameterTypes__Class1().Ref(); if linked_664 == nil { G__28000086__5_ = ifn_665.Invoke_O__O(arg_666) } else { G__28000086__5_ = linked_664.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_663, arg_666) }; var tmp9 any; var root_667 any = A_arbace_classes_env_A_const_76.GetRawRoot__O(); var linked_668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_667, A_arbace_classes_env_inner_member_QMARK__A_fn_class); var ifn_669 lang.IFn
	if linked_668 == nil { ifn_669 = lang.IFn_Cast(root_667) } else { ifn_669 = nil }; var arg_670 any = t.F_c; if linked_668 == nil { tmp9 = ifn_669.Invoke_O__O(arg_670) } else { tmp9 = linked_668.(*A_arbace_classes_env_inner_member_QMARK__A).Invoke_O_O__O(root_667, arg_670) }
//line :186:1
	if jrt.J2g_Truth(tmp9) { var root_671 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_671, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_673 lang.IFn; if linked_672 == nil { ifn_673 = lang.IFn_Cast(root_671) } else { ifn_673 = nil }; var arg_674 any = G__28000086__5_; if linked_672 == nil { arg_662 = ifn_673.Invoke_O__O(arg_674) } else { arg_662 = linked_672.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_671, arg_674) } } else { arg_662 = G__28000086__5_ }; if linked_659 == nil { arg_656 = ifn_660.Invoke_O_O__O(arg_661, arg_662) } else { arg_656 = linked_659.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_658, arg_661, arg_662) }; var arg_657 any = Lit_55; if linked_654 == nil { tmp8 = ifn_655.Invoke_O_O__O(arg_656, arg_657) } else { tmp8 = linked_654.(*aot_arbace_classes_types.A_arbace_classes_types_method_desc_A).Invoke_O_O_O__O(root_653, arg_656, arg_657) }
//line :184:1
	var tmp10 any = tmp8; var tmp11 any = A_arbace_classes_env_A_const_43; var tmp12 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Constructor_Cast(m__4)).GetModifiers__I()).Ref(); var tmp13 any = A_arbace_classes_env_A_const_63; var tmp14 any = t.F_n; var tmp15 any = A_arbace_classes_env_A_const_81; var tmp16 any; var root_675 any = A_arbace_classes_env_A_const_47.GetRawRoot__O(); var linked_676 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_675, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_677 lang.IFn





	if linked_676 == nil { ifn_677 = lang.IFn_Cast(root_675) } else { ifn_677 = nil }; var arg_678 any = A_arbace_classes_env_A_const_35.GetRawRoot__O(); var arg_679 any = jrt.NN(jrt.Constructor_Cast(m__4)).GetExceptionTypes__Class1().Ref(); if linked_676 == nil { tmp16 = ifn_677.Invoke_O_O__O(arg_678, arg_679) } else { tmp16 = linked_676.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_675, arg_678, arg_679) }
//line :184:1
	arg_651 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, Lit_13, tmp7, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16)); var arg_652 any; var tmp17 lang.IFn = lang.IFn_Cast(t.F_iter__28000077); var tmp18 any; var root_680 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_680, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_682 lang.IFn; if linked_681 == nil { ifn_682 = lang.IFn_Cast(root_680) } else { ifn_682 = nil }; var arg_683 any = s__28000078__3; if linked_681 == nil { tmp18 = ifn_682.Invoke_O__O(arg_683) } else { tmp18 = linked_681.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_680, arg_683) }; arg_652 = tmp17.Invoke_O__O(tmp18); if linked_649 == nil { return ifn_650.Invoke_O_O__O(arg_651, arg_652) } else { return linked_649.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_648, arg_651, arg_652) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :184:1
func A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :184:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A) Ctor_O_O_O_I_O(c__c, c__n, c__b__28000080 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_c = c__c; t.F_n = c__n; t.F_b__28000080 = c__b__28000080; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :184:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A) Invoke_O__O(self any) any { { var i__28000079__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__28000079__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__28000079__1)); var root_588 any = A_arbace_classes_env_A_const_62.GetRawRoot__O(); var linked_589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_588, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_590 lang.IFn; if linked_589 == nil { ifn_590 = lang.IFn_Cast(root_588) } else { ifn_590 = nil }; var arg_591 any = t.F_b__28000080; var arg_592 any; var tmp2 any = A_arbace_classes_env_A_const_42; var tmp3 any = A_arbace_classes_env_A_const_60; var tmp4 any; var root_593 any = A_arbace_classes_env_A_const_79.GetRawRoot__O(); var linked_594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_593, aot_arbace_classes_types.A_arbace_classes_types_method_desc_A_fn_class); var ifn_595 lang.IFn

	if linked_594 == nil { ifn_595 = lang.IFn_Cast(root_593) } else { ifn_595 = nil }; var arg_596 any; var root_598 any = A_arbace_classes_env_A_const_80.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_598, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_600 lang.IFn; if linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var arg_602 any; var G__28000084__3_ any; var root_603 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_603, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_605 lang.IFn; if linked_604 == nil { ifn_605 = lang.IFn_Cast(root_603) } else { ifn_605 = nil }; var arg_606 any = jrt.NN(jrt.Constructor_Cast(m__2)).GetParameterTypes__Class1().Ref(); if linked_604 == nil { G__28000084__3_ = ifn_605.Invoke_O__O(arg_606) } else { G__28000084__3_ = linked_604.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_603, arg_606) }; var tmp5 any; var root_607 any = A_arbace_classes_env_A_const_76.GetRawRoot__O(); var linked_608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_607, A_arbace_classes_env_inner_member_QMARK__A_fn_class); var ifn_609 lang.IFn
	if linked_608 == nil { ifn_609 = lang.IFn_Cast(root_607) } else { ifn_609 = nil }; var arg_610 any = t.F_c; if linked_608 == nil { tmp5 = ifn_609.Invoke_O__O(arg_610) } else { tmp5 = linked_608.(*A_arbace_classes_env_inner_member_QMARK__A).Invoke_O_O__O(root_607, arg_610) }
//line :186:1
	if jrt.J2g_Truth(tmp5) { var root_611 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_611, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_613 lang.IFn; if linked_612 == nil { ifn_613 = lang.IFn_Cast(root_611) } else { ifn_613 = nil }; var arg_614 any = G__28000084__3_; if linked_612 == nil { arg_602 = ifn_613.Invoke_O__O(arg_614) } else { arg_602 = linked_612.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_611, arg_614) } } else { arg_602 = G__28000084__3_ }; if linked_599 == nil { arg_596 = ifn_600.Invoke_O_O__O(arg_601, arg_602) } else { arg_596 = linked_599.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_598, arg_601, arg_602) }; var arg_597 any = Lit_55; if linked_594 == nil { tmp4 = ifn_595.Invoke_O_O__O(arg_596, arg_597) } else { tmp4 = linked_594.(*aot_arbace_classes_types.A_arbace_classes_types_method_desc_A).Invoke_O_O_O__O(root_593, arg_596, arg_597) }
//line :184:1
	var tmp6 any = tmp4; var tmp7 any = A_arbace_classes_env_A_const_43; var tmp8 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Constructor_Cast(m__2)).GetModifiers__I()).Ref(); var tmp9 any = A_arbace_classes_env_A_const_63; var tmp10 any = t.F_n; var tmp11 any = A_arbace_classes_env_A_const_81; var tmp12 any; var root_615 any = A_arbace_classes_env_A_const_47.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_615, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_617 lang.IFn





	if linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any = A_arbace_classes_env_A_const_35.GetRawRoot__O(); var arg_619 any = jrt.NN(jrt.Constructor_Cast(m__2)).GetExceptionTypes__Class1().Ref(); if linked_616 == nil { tmp12 = ifn_617.Invoke_O_O__O(arg_618, arg_619) } else { tmp12 = linked_616.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_615, arg_618, arg_619) }
//line :184:1
	arg_592 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, Lit_13, tmp3, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12)); if linked_589 == nil { ifn_590.Invoke_O_O__O(arg_591, arg_592) } else { linked_589.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_588, arg_591, arg_592) }; i__28000079__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000079__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



















func A_arbace_classes_env_reflect_info_iter__28000089__28000093_A_New_O_O(p0, p1 any) *A_arbace_classes_env_reflect_info_iter__28000089__28000093_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000089__28000093_A{}; t.Ctor_O_O(p0, p1); return t }
//line :204:1
func (t *A_arbace_classes_env_reflect_info_iter__28000089__28000093_A) Ctor_O_O(c__n, c__have any) { t.F_n = c__n; t.F_have = c__have }
//line :204:1
func (t *A_arbace_classes_env_reflect_info_iter__28000089__28000093_A) Invoke_O_O__O(self, s__28000090__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__809 any = A_arbace_classes_env_reflect_info_iter__28000089__28000093_fn__28000094_A_New_O_O_O_O(t.F_n, s__28000090__1, t.F_have, self); var tmp2 *jrt.Class; var fncls__808 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000089__28000093_fn__28000094_A_fn_class; if fncls__808 == nil { var fncls__808d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_56, false, fnbody__809); A_arbace_classes_env_reflect_info_iter__28000089__28000093_fn__28000094_A_fn_class = fncls__808d; tmp2 = fncls__808d } else { tmp2 = fncls__808 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__809, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :204:1
func A_arbace_classes_env_reflect_info_iter__28000089__28000093_fn__28000094_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000089__28000093_fn__28000094_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000089__28000093_fn__28000094_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :204:1
func (t *A_arbace_classes_env_reflect_info_iter__28000089__28000093_fn__28000094_A) Ctor_O_O_O_O(c__n, c__s__28000090, c__have, c__iter__28000089 any) { t.F_n = c__n; t.F_s__28000090 = c__s__28000090; t.F_have = c__have; t.F_iter__28000089 = c__iter__28000089 }
//line :204:1
func (t *A_arbace_classes_env_reflect_info_iter__28000089__28000093_fn__28000094_A) Invoke_O__O(self any) any { { var s__28000090__1 any; var t_ any = t.F_s__28000090; t.F_s__28000090 = nil; s__28000090__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_738 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_738, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_740 lang.IFn; if linked_739 == nil { ifn_740 = lang.IFn_Cast(root_738) } else { ifn_740 = nil }; var arg_741 any = s__28000090__1; if linked_739 == nil { temp__1927000414__auto____2 = ifn_740.Invoke_O__O(arg_741) } else { temp__1927000414__auto____2 = linked_739.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_738, arg_741) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__28000090__3 any = temp__1927000414__auto____2; var tmp1 any; var root_742 any = A_arbace_classes_env_A_const_54.GetRawRoot__O(); var linked_743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_742, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_744 lang.IFn; if linked_743 == nil { ifn_744 = lang.IFn_Cast(root_742) } else { ifn_744 = nil }; var arg_745 any = s__28000090__3; if linked_743 == nil { tmp1 = ifn_744.Invoke_O__O(arg_745) } else { tmp1 = linked_743.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_742, arg_745) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_746 any = A_arbace_classes_env_A_const_55.GetRawRoot__O(); var linked_747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_746, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_748 lang.IFn; if linked_747 == nil { ifn_748 = lang.IFn_Cast(root_746) } else { ifn_748 = nil }; var arg_749 any = s__28000090__3; if linked_747 == nil { c__1927001037__auto____4 = ifn_748.Invoke_O__O(arg_749) } else { c__1927001037__auto____4 = linked_747.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_746, arg_749) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__28000092__6 any; var root_750 any = A_arbace_classes_env_A_const_56.GetRawRoot__O(); var linked_751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_750, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_752 lang.IFn; if linked_751 == nil { ifn_752 = lang.IFn_Cast(root_750) } else { ifn_752 = nil }; var arg_753 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_751 == nil { b__28000092__6 = ifn_752.Invoke_O__O(arg_753) } else { b__28000092__6 = linked_751.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_750, arg_753) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__764 any = A_arbace_classes_env_reflect_info_iter__28000089__28000093_fn__28000094_fn__28000095_A_New_O_O_O_I_O(t.F_n, t.F_have, b__28000092__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__763 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000089__28000093_fn__28000094_fn__28000095_A_fn_class; if fncls__763 == nil { var fncls__763d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_57, false, fnbody__764); A_arbace_classes_env_reflect_info_iter__28000089__28000093_fn__28000094_fn__28000095_A_fn_class = fncls__763d; tmp3 = fncls__763d } else { tmp3 = fncls__763 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__764, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_765 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_765, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_767 lang.IFn; if linked_766 == nil { ifn_767 = lang.IFn_Cast(root_765) } else { ifn_767 = nil }; var arg_768 any; var root_770 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_770, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_772 lang.IFn; if linked_771 == nil { ifn_772 = lang.IFn_Cast(root_770) } else { ifn_772 = nil }; var arg_773 any = b__28000092__6; if linked_771 == nil { arg_768 = ifn_772.Invoke_O__O(arg_773) } else { arg_768 = linked_771.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_770, arg_773) }; var arg_769 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__28000089); var tmp5 any; var root_774 any = A_arbace_classes_env_A_const_70.GetRawRoot__O(); var linked_775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_774, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_776 lang.IFn; if linked_775 == nil { ifn_776 = lang.IFn_Cast(root_774) } else { ifn_776 = nil }; var arg_777 any = s__28000090__3; if linked_775 == nil { tmp5 = ifn_776.Invoke_O__O(arg_777) } else { tmp5 = linked_775.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_774, arg_777) }; arg_769 = tmp4.Invoke_O__O(tmp5); if linked_766 == nil { return ifn_767.Invoke_O_O__O(arg_768, arg_769) } else { return linked_766.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_765, arg_768, arg_769) } } else { var root_778 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_778, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_780 lang.IFn; if linked_779 == nil { ifn_780 = lang.IFn_Cast(root_778) } else { ifn_780 = nil }; var arg_781 any; var root_783 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_783, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_785 lang.IFn; if linked_784 == nil { ifn_785 = lang.IFn_Cast(root_783) } else { ifn_785 = nil }; var arg_786 any = b__28000092__6; if linked_784 == nil { arg_781 = ifn_785.Invoke_O__O(arg_786) } else { arg_781 = linked_784.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_783, arg_786) }; var arg_782 any; if linked_779 == nil { return ifn_780.Invoke_O_O__O(arg_781, arg_782) } else { return linked_779.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_778, arg_781, arg_782) } } } else { var vec__28000100__4 any; var root_787 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_787, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_789 lang.IFn; if linked_788 == nil { ifn_789 = lang.IFn_Cast(root_787) } else { ifn_789 = nil }; var arg_790 any = s__28000090__3; if linked_788 == nil { vec__28000100__4 = ifn_789.Invoke_O__O(arg_790) } else { vec__28000100__4 = linked_788.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_787, arg_790) }; var nm__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__28000100__4, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__28000100__4, lang.RT_IntCast_J__I_NoInit(1), nil); var flags__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__28000100__4, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp6 any; var root_791 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_791, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_793 lang.IFn; if linked_792 == nil { ifn_793 = lang.IFn_Cast(root_791) } else { ifn_793 = nil }; var tmp7 lang.IFn = lang.IFn_Cast(t.F_have); var arg_794 any = tmp7.Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(nm__5, desc__6)); if linked_792 == nil { tmp6 = ifn_793.Invoke_O__O(arg_794) } else { tmp6 = linked_792.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_791, arg_794) }; if jrt.J2g_Truth(tmp6) { var root_795 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_795, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_797 lang.IFn; if linked_796 == nil { ifn_797 = lang.IFn_Cast(root_795) } else { ifn_797 = nil }; var arg_798 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_env_A_const_42, nm__5, A_arbace_classes_env_A_const_60, desc__6, A_arbace_classes_env_A_const_43, flags__7, A_arbace_classes_env_A_const_63, t.F_n, A_arbace_classes_env_A_const_81, lang.PersistentVector_EMPTY.Ref())); var arg_799 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__28000089); var tmp9 any; var root_800 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_800, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_802 lang.IFn; if linked_801 == nil { ifn_802 = lang.IFn_Cast(root_800) } else { ifn_802 = nil }; var arg_803 any = s__28000090__3; if linked_801 == nil { tmp9 = ifn_802.Invoke_O__O(arg_803) } else { tmp9 = linked_801.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_800, arg_803) }; arg_799 = tmp8.Invoke_O__O(tmp9); if linked_796 == nil { return ifn_797.Invoke_O_O__O(arg_798, arg_799) } else { return linked_796.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_795, arg_798, arg_799) } } else { var tmp10 any; var root_804 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_804, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_806 lang.IFn; if linked_805 == nil { ifn_806 = lang.IFn_Cast(root_804) } else { ifn_806 = nil }; var arg_807 any = s__28000090__3; if linked_805 == nil { tmp10 = ifn_806.Invoke_O__O(arg_807) } else { tmp10 = linked_805.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_804, arg_807) }; s__28000090__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :204:1
func A_arbace_classes_env_reflect_info_iter__28000089__28000093_fn__28000094_fn__28000095_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_classes_env_reflect_info_iter__28000089__28000093_fn__28000094_fn__28000095_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000089__28000093_fn__28000094_fn__28000095_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :204:1
func (t *A_arbace_classes_env_reflect_info_iter__28000089__28000093_fn__28000094_fn__28000095_A) Ctor_O_O_O_I_O(c__n, c__have, c__b__28000092 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_have = c__have; t.F_b__28000092 = c__b__28000092; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :204:1
func (t *A_arbace_classes_env_reflect_info_iter__28000089__28000093_fn__28000094_fn__28000095_A) Invoke_O__O(self any) any { { var i__28000091__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__28000091__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__28000096__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__28000091__1)); var nm__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__28000096__2, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__28000096__2, lang.RT_IntCast_J__I_NoInit(1), nil); var flags__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__28000096__2, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp2 any; var root_754 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_754, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_756 lang.IFn; if linked_755 == nil { ifn_756 = lang.IFn_Cast(root_754) } else { ifn_756 = nil }; var tmp3 lang.IFn = lang.IFn_Cast(t.F_have); var arg_757 any = tmp3.Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(nm__3, desc__4)); if linked_755 == nil { tmp2 = ifn_756.Invoke_O__O(arg_757) } else { tmp2 = linked_755.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_754, arg_757) }; if jrt.J2g_Truth(tmp2) { var root_758 any = A_arbace_classes_env_A_const_62.GetRawRoot__O(); var linked_759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_758, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_760 lang.IFn; if linked_759 == nil { ifn_760 = lang.IFn_Cast(root_758) } else { ifn_760 = nil }; var arg_761 any = t.F_b__28000092; var arg_762 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_env_A_const_42, nm__3, A_arbace_classes_env_A_const_60, desc__4, A_arbace_classes_env_A_const_43, flags__5, A_arbace_classes_env_A_const_63, t.F_n, A_arbace_classes_env_A_const_81, lang.PersistentVector_EMPTY.Ref())); if linked_759 == nil { ifn_760.Invoke_O_O__O(arg_761, arg_762) } else { linked_759.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_758, arg_761, arg_762) }; i__28000091__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000091__1); continue L1 } else { i__28000091__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000091__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_classes_env_reflect_info_iter__28000105__28000109_A_New_O_O(p0, p1 any) *A_arbace_classes_env_reflect_info_iter__28000105__28000109_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000105__28000109_A{}; t.Ctor_O_O(p0, p1); return t }
//line :206:1
func (t *A_arbace_classes_env_reflect_info_iter__28000105__28000109_A) Ctor_O_O(c__n, c__have any) { t.F_n = c__n; t.F_have = c__have }
//line :206:1
func (t *A_arbace_classes_env_reflect_info_iter__28000105__28000109_A) Invoke_O_O__O(self, s__28000106__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__883 any = A_arbace_classes_env_reflect_info_iter__28000105__28000109_fn__28000110_A_New_O_O_O_O(self, t.F_n, t.F_have, s__28000106__1); var tmp2 *jrt.Class; var fncls__882 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000105__28000109_fn__28000110_A_fn_class; if fncls__882 == nil { var fncls__882d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_58, false, fnbody__883); A_arbace_classes_env_reflect_info_iter__28000105__28000109_fn__28000110_A_fn_class = fncls__882d; tmp2 = fncls__882d } else { tmp2 = fncls__882 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__883, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :206:1
func A_arbace_classes_env_reflect_info_iter__28000105__28000109_fn__28000110_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000105__28000109_fn__28000110_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000105__28000109_fn__28000110_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :206:1
func (t *A_arbace_classes_env_reflect_info_iter__28000105__28000109_fn__28000110_A) Ctor_O_O_O_O(c__iter__28000105, c__n, c__have, c__s__28000106 any) { t.F_iter__28000105 = c__iter__28000105; t.F_n = c__n; t.F_have = c__have; t.F_s__28000106 = c__s__28000106 }
//line :206:1
func (t *A_arbace_classes_env_reflect_info_iter__28000105__28000109_fn__28000110_A) Invoke_O__O(self any) any { { var s__28000106__1 any; var t_ any = t.F_s__28000106; t.F_s__28000106 = nil; s__28000106__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_812 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_812, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_814 lang.IFn; if linked_813 == nil { ifn_814 = lang.IFn_Cast(root_812) } else { ifn_814 = nil }; var arg_815 any = s__28000106__1; if linked_813 == nil { temp__1927000414__auto____2 = ifn_814.Invoke_O__O(arg_815) } else { temp__1927000414__auto____2 = linked_813.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_812, arg_815) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__28000106__3 any = temp__1927000414__auto____2; var tmp1 any; var root_816 any = A_arbace_classes_env_A_const_54.GetRawRoot__O(); var linked_817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_816, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_818 lang.IFn; if linked_817 == nil { ifn_818 = lang.IFn_Cast(root_816) } else { ifn_818 = nil }; var arg_819 any = s__28000106__3; if linked_817 == nil { tmp1 = ifn_818.Invoke_O__O(arg_819) } else { tmp1 = linked_817.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_816, arg_819) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_820 any = A_arbace_classes_env_A_const_55.GetRawRoot__O(); var linked_821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_820, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_822 lang.IFn; if linked_821 == nil { ifn_822 = lang.IFn_Cast(root_820) } else { ifn_822 = nil }; var arg_823 any = s__28000106__3; if linked_821 == nil { c__1927001037__auto____4 = ifn_822.Invoke_O__O(arg_823) } else { c__1927001037__auto____4 = linked_821.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_820, arg_823) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__28000108__6 any; var root_824 any = A_arbace_classes_env_A_const_56.GetRawRoot__O(); var linked_825 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_824, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_826 lang.IFn; if linked_825 == nil { ifn_826 = lang.IFn_Cast(root_824) } else { ifn_826 = nil }; var arg_827 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_825 == nil { b__28000108__6 = ifn_826.Invoke_O__O(arg_827) } else { b__28000108__6 = linked_825.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_824, arg_827) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__838 any = A_arbace_classes_env_reflect_info_iter__28000105__28000109_fn__28000110_fn__28000111_A_New_O_O_O_I_O(t.F_n, b__28000108__6, t.F_have, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__837 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000105__28000109_fn__28000110_fn__28000111_A_fn_class; if fncls__837 == nil { var fncls__837d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_59, false, fnbody__838); A_arbace_classes_env_reflect_info_iter__28000105__28000109_fn__28000110_fn__28000111_A_fn_class = fncls__837d; tmp3 = fncls__837d } else { tmp3 = fncls__837 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__838, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_839 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_840 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_839, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_841 lang.IFn; if linked_840 == nil { ifn_841 = lang.IFn_Cast(root_839) } else { ifn_841 = nil }; var arg_842 any; var root_844 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_844, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_846 lang.IFn; if linked_845 == nil { ifn_846 = lang.IFn_Cast(root_844) } else { ifn_846 = nil }; var arg_847 any = b__28000108__6; if linked_845 == nil { arg_842 = ifn_846.Invoke_O__O(arg_847) } else { arg_842 = linked_845.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_844, arg_847) }; var arg_843 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__28000105); var tmp5 any; var root_848 any = A_arbace_classes_env_A_const_70.GetRawRoot__O(); var linked_849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_848, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_850 lang.IFn; if linked_849 == nil { ifn_850 = lang.IFn_Cast(root_848) } else { ifn_850 = nil }; var arg_851 any = s__28000106__3; if linked_849 == nil { tmp5 = ifn_850.Invoke_O__O(arg_851) } else { tmp5 = linked_849.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_848, arg_851) }; arg_843 = tmp4.Invoke_O__O(tmp5); if linked_840 == nil { return ifn_841.Invoke_O_O__O(arg_842, arg_843) } else { return linked_840.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_839, arg_842, arg_843) } } else { var root_852 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_852, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_854 lang.IFn; if linked_853 == nil { ifn_854 = lang.IFn_Cast(root_852) } else { ifn_854 = nil }; var arg_855 any; var root_857 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_857, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_859 lang.IFn; if linked_858 == nil { ifn_859 = lang.IFn_Cast(root_857) } else { ifn_859 = nil }; var arg_860 any = b__28000108__6; if linked_858 == nil { arg_855 = ifn_859.Invoke_O__O(arg_860) } else { arg_855 = linked_858.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_857, arg_860) }; var arg_856 any; if linked_853 == nil { return ifn_854.Invoke_O_O__O(arg_855, arg_856) } else { return linked_853.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_852, arg_855, arg_856) } } } else { var vec__28000116__4 any; var root_861 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_861, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_863 lang.IFn; if linked_862 == nil { ifn_863 = lang.IFn_Cast(root_861) } else { ifn_863 = nil }; var arg_864 any = s__28000106__3; if linked_862 == nil { vec__28000116__4 = ifn_863.Invoke_O__O(arg_864) } else { vec__28000116__4 = linked_862.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_861, arg_864) }; var desc__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__28000116__4, lang.RT_IntCast_J__I_NoInit(0), nil); var flags__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__28000116__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_865 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_865, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_867 lang.IFn; if linked_866 == nil { ifn_867 = lang.IFn_Cast(root_865) } else { ifn_867 = nil }; var tmp7 lang.IFn = lang.IFn_Cast(t.F_have); var arg_868 any = tmp7.Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(Lit_13, desc__5)); if linked_866 == nil { tmp6 = ifn_867.Invoke_O__O(arg_868) } else { tmp6 = linked_866.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_865, arg_868) }; if jrt.J2g_Truth(tmp6) { var root_869 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_869, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_871 lang.IFn; if linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_env_A_const_42, Lit_13, A_arbace_classes_env_A_const_60, desc__5, A_arbace_classes_env_A_const_43, flags__6, A_arbace_classes_env_A_const_63, t.F_n, A_arbace_classes_env_A_const_81, lang.PersistentVector_EMPTY.Ref())); var arg_873 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__28000105); var tmp9 any; var root_874 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_875 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_874, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_876 lang.IFn; if linked_875 == nil { ifn_876 = lang.IFn_Cast(root_874) } else { ifn_876 = nil }; var arg_877 any = s__28000106__3; if linked_875 == nil { tmp9 = ifn_876.Invoke_O__O(arg_877) } else { tmp9 = linked_875.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_874, arg_877) }; arg_873 = tmp8.Invoke_O__O(tmp9); if linked_870 == nil { return ifn_871.Invoke_O_O__O(arg_872, arg_873) } else { return linked_870.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_869, arg_872, arg_873) } } else { var tmp10 any; var root_878 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_878, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_880 lang.IFn; if linked_879 == nil { ifn_880 = lang.IFn_Cast(root_878) } else { ifn_880 = nil }; var arg_881 any = s__28000106__3; if linked_879 == nil { tmp10 = ifn_880.Invoke_O__O(arg_881) } else { tmp10 = linked_879.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_878, arg_881) }; s__28000106__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :206:1
func A_arbace_classes_env_reflect_info_iter__28000105__28000109_fn__28000110_fn__28000111_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_classes_env_reflect_info_iter__28000105__28000109_fn__28000110_fn__28000111_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000105__28000109_fn__28000110_fn__28000111_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :206:1
func (t *A_arbace_classes_env_reflect_info_iter__28000105__28000109_fn__28000110_fn__28000111_A) Ctor_O_O_O_I_O(c__n, c__b__28000108, c__have any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__28000108 = c__b__28000108; t.F_have = c__have; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :206:1
func (t *A_arbace_classes_env_reflect_info_iter__28000105__28000109_fn__28000110_fn__28000111_A) Invoke_O__O(self any) any { { var i__28000107__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__28000107__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__28000112__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__28000107__1)); var desc__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__28000112__2, lang.RT_IntCast_J__I_NoInit(0), nil); var flags__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__28000112__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_828 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_828, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_830 lang.IFn; if linked_829 == nil { ifn_830 = lang.IFn_Cast(root_828) } else { ifn_830 = nil }; var tmp3 lang.IFn = lang.IFn_Cast(t.F_have); var arg_831 any = tmp3.Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(Lit_13, desc__3)); if linked_829 == nil { tmp2 = ifn_830.Invoke_O__O(arg_831) } else { tmp2 = linked_829.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_828, arg_831) }; if jrt.J2g_Truth(tmp2) { var root_832 any = A_arbace_classes_env_A_const_62.GetRawRoot__O(); var linked_833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_832, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_834 lang.IFn; if linked_833 == nil { ifn_834 = lang.IFn_Cast(root_832) } else { ifn_834 = nil }; var arg_835 any = t.F_b__28000108; var arg_836 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_env_A_const_42, Lit_13, A_arbace_classes_env_A_const_60, desc__3, A_arbace_classes_env_A_const_43, flags__4, A_arbace_classes_env_A_const_63, t.F_n, A_arbace_classes_env_A_const_81, lang.PersistentVector_EMPTY.Ref())); if linked_833 == nil { ifn_834.Invoke_O_O__O(arg_835, arg_836) } else { linked_833.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_832, arg_835, arg_836) }; i__28000107__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000107__1); continue L1 } else { i__28000107__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000107__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_classes_env_reflect_info_iter__28000121__28000125_A_New_O_O(p0, p1 any) *A_arbace_classes_env_reflect_info_iter__28000121__28000125_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000121__28000125_A{}; t.Ctor_O_O(p0, p1); return t }
//line :209:1
func (t *A_arbace_classes_env_reflect_info_iter__28000121__28000125_A) Ctor_O_O(c__n, c__fhave any) { t.F_n = c__n; t.F_fhave = c__fhave }
//line :209:1
func (t *A_arbace_classes_env_reflect_info_iter__28000121__28000125_A) Invoke_O_O__O(self, s__28000122__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__957 any = A_arbace_classes_env_reflect_info_iter__28000121__28000125_fn__28000126_A_New_O_O_O_O(t.F_n, s__28000122__1, t.F_fhave, self); var tmp2 *jrt.Class; var fncls__956 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000121__28000125_fn__28000126_A_fn_class; if fncls__956 == nil { var fncls__956d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_60, false, fnbody__957); A_arbace_classes_env_reflect_info_iter__28000121__28000125_fn__28000126_A_fn_class = fncls__956d; tmp2 = fncls__956d } else { tmp2 = fncls__956 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__957, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :209:1
func A_arbace_classes_env_reflect_info_iter__28000121__28000125_fn__28000126_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000121__28000125_fn__28000126_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000121__28000125_fn__28000126_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :209:1
func (t *A_arbace_classes_env_reflect_info_iter__28000121__28000125_fn__28000126_A) Ctor_O_O_O_O(c__n, c__s__28000122, c__fhave, c__iter__28000121 any) { t.F_n = c__n; t.F_s__28000122 = c__s__28000122; t.F_fhave = c__fhave; t.F_iter__28000121 = c__iter__28000121 }
//line :209:1
func (t *A_arbace_classes_env_reflect_info_iter__28000121__28000125_fn__28000126_A) Invoke_O__O(self any) any { { var s__28000122__1 any; var t_ any = t.F_s__28000122; t.F_s__28000122 = nil; s__28000122__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_886 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_886, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_888 lang.IFn; if linked_887 == nil { ifn_888 = lang.IFn_Cast(root_886) } else { ifn_888 = nil }; var arg_889 any = s__28000122__1; if linked_887 == nil { temp__1927000414__auto____2 = ifn_888.Invoke_O__O(arg_889) } else { temp__1927000414__auto____2 = linked_887.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_886, arg_889) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__28000122__3 any = temp__1927000414__auto____2; var tmp1 any; var root_890 any = A_arbace_classes_env_A_const_54.GetRawRoot__O(); var linked_891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_890, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_892 lang.IFn; if linked_891 == nil { ifn_892 = lang.IFn_Cast(root_890) } else { ifn_892 = nil }; var arg_893 any = s__28000122__3; if linked_891 == nil { tmp1 = ifn_892.Invoke_O__O(arg_893) } else { tmp1 = linked_891.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_890, arg_893) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_894 any = A_arbace_classes_env_A_const_55.GetRawRoot__O(); var linked_895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_894, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_896 lang.IFn; if linked_895 == nil { ifn_896 = lang.IFn_Cast(root_894) } else { ifn_896 = nil }; var arg_897 any = s__28000122__3; if linked_895 == nil { c__1927001037__auto____4 = ifn_896.Invoke_O__O(arg_897) } else { c__1927001037__auto____4 = linked_895.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_894, arg_897) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__28000124__6 any; var root_898 any = A_arbace_classes_env_A_const_56.GetRawRoot__O(); var linked_899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_898, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_900 lang.IFn; if linked_899 == nil { ifn_900 = lang.IFn_Cast(root_898) } else { ifn_900 = nil }; var arg_901 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_899 == nil { b__28000124__6 = ifn_900.Invoke_O__O(arg_901) } else { b__28000124__6 = linked_899.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_898, arg_901) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__912 any = A_arbace_classes_env_reflect_info_iter__28000121__28000125_fn__28000126_fn__28000127_A_New_O_O_I_O_O(t.F_n, b__28000124__6, size__1927001038__auto____5, t.F_fhave, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__911 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000121__28000125_fn__28000126_fn__28000127_A_fn_class; if fncls__911 == nil { var fncls__911d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_61, false, fnbody__912); A_arbace_classes_env_reflect_info_iter__28000121__28000125_fn__28000126_fn__28000127_A_fn_class = fncls__911d; tmp3 = fncls__911d } else { tmp3 = fncls__911 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__912, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_913 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_913, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_915 lang.IFn; if linked_914 == nil { ifn_915 = lang.IFn_Cast(root_913) } else { ifn_915 = nil }; var arg_916 any; var root_918 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_918, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_920 lang.IFn; if linked_919 == nil { ifn_920 = lang.IFn_Cast(root_918) } else { ifn_920 = nil }; var arg_921 any = b__28000124__6; if linked_919 == nil { arg_916 = ifn_920.Invoke_O__O(arg_921) } else { arg_916 = linked_919.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_918, arg_921) }; var arg_917 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__28000121); var tmp5 any; var root_922 any = A_arbace_classes_env_A_const_70.GetRawRoot__O(); var linked_923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_922, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_924 lang.IFn; if linked_923 == nil { ifn_924 = lang.IFn_Cast(root_922) } else { ifn_924 = nil }; var arg_925 any = s__28000122__3; if linked_923 == nil { tmp5 = ifn_924.Invoke_O__O(arg_925) } else { tmp5 = linked_923.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_922, arg_925) }; arg_917 = tmp4.Invoke_O__O(tmp5); if linked_914 == nil { return ifn_915.Invoke_O_O__O(arg_916, arg_917) } else { return linked_914.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_913, arg_916, arg_917) } } else { var root_926 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_926, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_928 lang.IFn; if linked_927 == nil { ifn_928 = lang.IFn_Cast(root_926) } else { ifn_928 = nil }; var arg_929 any; var root_931 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_932 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_931, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_933 lang.IFn; if linked_932 == nil { ifn_933 = lang.IFn_Cast(root_931) } else { ifn_933 = nil }; var arg_934 any = b__28000124__6; if linked_932 == nil { arg_929 = ifn_933.Invoke_O__O(arg_934) } else { arg_929 = linked_932.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_931, arg_934) }; var arg_930 any; if linked_927 == nil { return ifn_928.Invoke_O_O__O(arg_929, arg_930) } else { return linked_927.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_926, arg_929, arg_930) } } } else { var vec__28000132__4 any; var root_935 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_936 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_935, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_937 lang.IFn; if linked_936 == nil { ifn_937 = lang.IFn_Cast(root_935) } else { ifn_937 = nil }; var arg_938 any = s__28000122__3; if linked_936 == nil { vec__28000132__4 = ifn_937.Invoke_O__O(arg_938) } else { vec__28000132__4 = linked_936.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_935, arg_938) }; var nm__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__28000132__4, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__28000132__4, lang.RT_IntCast_J__I_NoInit(1), nil); var flags__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__28000132__4, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp6 any; var root_939 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_940 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_939, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_941 lang.IFn; if linked_940 == nil { ifn_941 = lang.IFn_Cast(root_939) } else { ifn_941 = nil }; var arg_942 any = lang.IFn_Cast(t.F_fhave).Invoke_O__O(nm__5); if linked_940 == nil { tmp6 = ifn_941.Invoke_O__O(arg_942) } else { tmp6 = linked_940.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_939, arg_942) }; if jrt.J2g_Truth(tmp6) { var root_943 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_943, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_945 lang.IFn; if linked_944 == nil { ifn_945 = lang.IFn_Cast(root_943) } else { ifn_945 = nil }; var arg_946 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_env_A_const_42, nm__5, A_arbace_classes_env_A_const_60, desc__6, A_arbace_classes_env_A_const_43, flags__7, A_arbace_classes_env_A_const_63, t.F_n, A_arbace_classes_env_A_const_64, nil)); var arg_947 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__28000121); var tmp8 any; var root_948 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_948, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_950 lang.IFn; if linked_949 == nil { ifn_950 = lang.IFn_Cast(root_948) } else { ifn_950 = nil }; var arg_951 any = s__28000122__3; if linked_949 == nil { tmp8 = ifn_950.Invoke_O__O(arg_951) } else { tmp8 = linked_949.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_948, arg_951) }; arg_947 = tmp7.Invoke_O__O(tmp8); if linked_944 == nil { return ifn_945.Invoke_O_O__O(arg_946, arg_947) } else { return linked_944.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_943, arg_946, arg_947) } } else { var tmp9 any; var root_952 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_952, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_954 lang.IFn; if linked_953 == nil { ifn_954 = lang.IFn_Cast(root_952) } else { ifn_954 = nil }; var arg_955 any = s__28000122__3; if linked_953 == nil { tmp9 = ifn_954.Invoke_O__O(arg_955) } else { tmp9 = linked_953.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_952, arg_955) }; s__28000122__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :209:1
func A_arbace_classes_env_reflect_info_iter__28000121__28000125_fn__28000126_fn__28000127_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_classes_env_reflect_info_iter__28000121__28000125_fn__28000126_fn__28000127_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000121__28000125_fn__28000126_fn__28000127_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :209:1
func (t *A_arbace_classes_env_reflect_info_iter__28000121__28000125_fn__28000126_fn__28000127_A) Ctor_O_O_I_O_O(c__n, c__b__28000124 any, c__size__1927001038__auto__ int32, c__fhave, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__28000124 = c__b__28000124; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_fhave = c__fhave; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :209:1
func (t *A_arbace_classes_env_reflect_info_iter__28000121__28000125_fn__28000126_fn__28000127_A) Invoke_O__O(self any) any { { var i__28000123__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__28000123__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__28000128__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__28000123__1)); var nm__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__28000128__2, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__28000128__2, lang.RT_IntCast_J__I_NoInit(1), nil); var flags__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__28000128__2, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp2 any; var root_902 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_902, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_904 lang.IFn; if linked_903 == nil { ifn_904 = lang.IFn_Cast(root_902) } else { ifn_904 = nil }; var arg_905 any = lang.IFn_Cast(t.F_fhave).Invoke_O__O(nm__3); if linked_903 == nil { tmp2 = ifn_904.Invoke_O__O(arg_905) } else { tmp2 = linked_903.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_902, arg_905) }; if jrt.J2g_Truth(tmp2) { var root_906 any = A_arbace_classes_env_A_const_62.GetRawRoot__O(); var linked_907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_906, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_908 lang.IFn; if linked_907 == nil { ifn_908 = lang.IFn_Cast(root_906) } else { ifn_908 = nil }; var arg_909 any = t.F_b__28000124; var arg_910 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_env_A_const_42, nm__3, A_arbace_classes_env_A_const_60, desc__4, A_arbace_classes_env_A_const_43, flags__5, A_arbace_classes_env_A_const_63, t.F_n, A_arbace_classes_env_A_const_64, nil)); if linked_907 == nil { ifn_908.Invoke_O_O__O(arg_909, arg_910) } else { linked_907.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_906, arg_909, arg_910) }; i__28000123__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000123__1); continue L1 } else { i__28000123__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000123__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_classes_env_reflect_info_fn__28000137_A_New() *A_arbace_classes_env_reflect_info_fn__28000137_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_fn__28000137_A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_classes_env_reflect_info_fn__28000137_A) Ctor() {}
//line :212:1
func (t *A_arbace_classes_env_reflect_info_fn__28000137_A) Invoke_O_O__O(self, p1__28000026_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_13, A_arbace_classes_env_A_const_42.Invoke_O__O(p1__28000026_SHARP___1))).Ref() }
func A_arbace_classes_env_reflect_info_iter__28000139__28000143_A_New_O(p0 any) *A_arbace_classes_env_reflect_info_iter__28000139__28000143_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000139__28000143_A{}; t.Ctor_O(p0); return t }
//line :213:1
func (t *A_arbace_classes_env_reflect_info_iter__28000139__28000143_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :213:1
func (t *A_arbace_classes_env_reflect_info_iter__28000139__28000143_A) Invoke_O_O__O(self, s__28000140__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1041 any = A_arbace_classes_env_reflect_info_iter__28000139__28000143_fn__28000144_A_New_O_O_O(t.F_n, self, s__28000140__1); var tmp2 *jrt.Class; var fncls__1040 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000139__28000143_fn__28000144_A_fn_class; if fncls__1040 == nil { var fncls__1040d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_62, false, fnbody__1041); A_arbace_classes_env_reflect_info_iter__28000139__28000143_fn__28000144_A_fn_class = fncls__1040d; tmp2 = fncls__1040d } else { tmp2 = fncls__1040 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1041, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :213:1
func A_arbace_classes_env_reflect_info_iter__28000139__28000143_fn__28000144_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000139__28000143_fn__28000144_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000139__28000143_fn__28000144_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :213:1
func (t *A_arbace_classes_env_reflect_info_iter__28000139__28000143_fn__28000144_A) Ctor_O_O_O(c__n, c__iter__28000139, c__s__28000140 any) { t.F_n = c__n; t.F_iter__28000139 = c__iter__28000139; t.F_s__28000140 = c__s__28000140 }
//line :213:1
func (t *A_arbace_classes_env_reflect_info_iter__28000139__28000143_fn__28000144_A) Invoke_O__O(self any) any { { var s__28000140__1 any; var t_ any = t.F_s__28000140; t.F_s__28000140 = nil; s__28000140__1 = t_; for { var temp__1927000414__auto____2 any; var root_982 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_982, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_984 lang.IFn; if linked_983 == nil { ifn_984 = lang.IFn_Cast(root_982) } else { ifn_984 = nil }; var arg_985 any = s__28000140__1; if linked_983 == nil { temp__1927000414__auto____2 = ifn_984.Invoke_O__O(arg_985) } else { temp__1927000414__auto____2 = linked_983.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_982, arg_985) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__28000140__3 any = temp__1927000414__auto____2; var tmp1 any; var root_986 any = A_arbace_classes_env_A_const_54.GetRawRoot__O(); var linked_987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_986, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_988 lang.IFn; if linked_987 == nil { ifn_988 = lang.IFn_Cast(root_986) } else { ifn_988 = nil }; var arg_989 any = s__28000140__3; if linked_987 == nil { tmp1 = ifn_988.Invoke_O__O(arg_989) } else { tmp1 = linked_987.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_986, arg_989) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_990 any = A_arbace_classes_env_A_const_55.GetRawRoot__O(); var linked_991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_990, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_992 lang.IFn; if linked_991 == nil { ifn_992 = lang.IFn_Cast(root_990) } else { ifn_992 = nil }; var arg_993 any = s__28000140__3; if linked_991 == nil { c__1927001037__auto____4 = ifn_992.Invoke_O__O(arg_993) } else { c__1927001037__auto____4 = linked_991.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_990, arg_993) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__28000142__6 any; var root_994 any = A_arbace_classes_env_A_const_56.GetRawRoot__O(); var linked_995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_994, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_996 lang.IFn; if linked_995 == nil { ifn_996 = lang.IFn_Cast(root_994) } else { ifn_996 = nil }; var arg_997 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_995 == nil { b__28000142__6 = ifn_996.Invoke_O__O(arg_997) } else { b__28000142__6 = linked_995.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_994, arg_997) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1004 any = A_arbace_classes_env_reflect_info_iter__28000139__28000143_fn__28000144_fn__28000145_A_New_O_O_I_O(b__28000142__6, t.F_n, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1003 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000139__28000143_fn__28000144_fn__28000145_A_fn_class; if fncls__1003 == nil { var fncls__1003d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_63, false, fnbody__1004); A_arbace_classes_env_reflect_info_iter__28000139__28000143_fn__28000144_fn__28000145_A_fn_class = fncls__1003d; tmp3 = fncls__1003d } else { tmp3 = fncls__1003 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1004, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1005 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_1006 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1005, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1007 lang.IFn; if linked_1006 == nil { ifn_1007 = lang.IFn_Cast(root_1005) } else { ifn_1007 = nil }; var arg_1008 any; var root_1010 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_1011 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1010, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1012 lang.IFn; if linked_1011 == nil { ifn_1012 = lang.IFn_Cast(root_1010) } else { ifn_1012 = nil }; var arg_1013 any = b__28000142__6; if linked_1011 == nil { arg_1008 = ifn_1012.Invoke_O__O(arg_1013) } else { arg_1008 = linked_1011.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1010, arg_1013) }; var arg_1009 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__28000139); var tmp5 any; var root_1014 any = A_arbace_classes_env_A_const_70.GetRawRoot__O(); var linked_1015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1014, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1016 lang.IFn; if linked_1015 == nil { ifn_1016 = lang.IFn_Cast(root_1014) } else { ifn_1016 = nil }; var arg_1017 any = s__28000140__3; if linked_1015 == nil { tmp5 = ifn_1016.Invoke_O__O(arg_1017) } else { tmp5 = linked_1015.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1014, arg_1017) }; arg_1009 = tmp4.Invoke_O__O(tmp5); if linked_1006 == nil { return ifn_1007.Invoke_O_O__O(arg_1008, arg_1009) } else { return linked_1006.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1005, arg_1008, arg_1009) } } else { var root_1018 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_1019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1018, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1020 lang.IFn; if linked_1019 == nil { ifn_1020 = lang.IFn_Cast(root_1018) } else { ifn_1020 = nil }; var arg_1021 any; var root_1023 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_1024 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1023, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1025 lang.IFn; if linked_1024 == nil { ifn_1025 = lang.IFn_Cast(root_1023) } else { ifn_1025 = nil }; var arg_1026 any = b__28000142__6; if linked_1024 == nil { arg_1021 = ifn_1025.Invoke_O__O(arg_1026) } else { arg_1021 = linked_1024.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1023, arg_1026) }; var arg_1022 any; if linked_1019 == nil { return ifn_1020.Invoke_O_O__O(arg_1021, arg_1022) } else { return linked_1019.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1018, arg_1021, arg_1022) } } } else { var vec__28000150__4 any; var root_1027 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_1028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1027, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1029 lang.IFn; if linked_1028 == nil { ifn_1029 = lang.IFn_Cast(root_1027) } else { ifn_1029 = nil }; var arg_1030 any = s__28000140__3; if linked_1028 == nil { vec__28000150__4 = ifn_1029.Invoke_O__O(arg_1030) } else { vec__28000150__4 = linked_1028.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1027, arg_1030) }; var d__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__28000150__4, lang.RT_IntCast_J__I_NoInit(0), nil); var f__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__28000150__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1031 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_1032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1031, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1033 lang.IFn; if linked_1032 == nil { ifn_1033 = lang.IFn_Cast(root_1031) } else { ifn_1033 = nil }; var arg_1034 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_env_A_const_42, Lit_13, A_arbace_classes_env_A_const_60, d__5, A_arbace_classes_env_A_const_43, f__6, A_arbace_classes_env_A_const_63, t.F_n, A_arbace_classes_env_A_const_81, lang.PersistentVector_EMPTY.Ref())); var arg_1035 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__28000139); var tmp7 any; var root_1036 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_1037 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1036, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1038 lang.IFn; if linked_1037 == nil { ifn_1038 = lang.IFn_Cast(root_1036) } else { ifn_1038 = nil }; var arg_1039 any = s__28000140__3; if linked_1037 == nil { tmp7 = ifn_1038.Invoke_O__O(arg_1039) } else { tmp7 = linked_1037.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1036, arg_1039) }; arg_1035 = tmp6.Invoke_O__O(tmp7); if linked_1032 == nil { return ifn_1033.Invoke_O_O__O(arg_1034, arg_1035) } else { return linked_1032.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1031, arg_1034, arg_1035) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :213:1
func A_arbace_classes_env_reflect_info_iter__28000139__28000143_fn__28000144_fn__28000145_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_env_reflect_info_iter__28000139__28000143_fn__28000144_fn__28000145_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000139__28000143_fn__28000144_fn__28000145_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :213:1
func (t *A_arbace_classes_env_reflect_info_iter__28000139__28000143_fn__28000144_fn__28000145_A) Ctor_O_O_I_O(c__b__28000142, c__n any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__28000142 = c__b__28000142; t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :213:1
func (t *A_arbace_classes_env_reflect_info_iter__28000139__28000143_fn__28000144_fn__28000145_A) Invoke_O__O(self any) any { { var i__28000141__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__28000141__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__28000146__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__28000141__1)); var d__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__28000146__2, lang.RT_IntCast_J__I_NoInit(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__28000146__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_998 any = A_arbace_classes_env_A_const_62.GetRawRoot__O(); var linked_999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_998, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1000 lang.IFn; if linked_999 == nil { ifn_1000 = lang.IFn_Cast(root_998) } else { ifn_1000 = nil }; var arg_1001 any = t.F_b__28000142; var arg_1002 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_env_A_const_42, Lit_13, A_arbace_classes_env_A_const_60, d__3, A_arbace_classes_env_A_const_43, f__4, A_arbace_classes_env_A_const_63, t.F_n, A_arbace_classes_env_A_const_81, lang.PersistentVector_EMPTY.Ref())); if linked_999 == nil { ifn_1000.Invoke_O_O__O(arg_1001, arg_1002) } else { linked_999.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_998, arg_1001, arg_1002) }; i__28000141__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000141__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_classes_env_info_A_New() *A_arbace_classes_env_info_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_info_A{}; t.Ctor(); return t }
//line :222:1
func (t *A_arbace_classes_env_info_A) Ctor() {}
//line :222:1
func (t *A_arbace_classes_env_info_A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any = n__0; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_1048 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1048, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1050 lang.IFn; if linked_1049 == nil { ifn_1050 = lang.IFn_Cast(root_1048) } else { ifn_1050 = nil }; var arg_1051 any; var root_1052 any = A_arbace_classes_env_A_const_20.GetRawRoot__O(); var linked_1053 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1052, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1054 lang.IFn; if linked_1053 == nil { ifn_1054 = lang.IFn_Cast(root_1052) } else { ifn_1054 = nil }; var arg_1055 any = n__0; var arg_1056 any = Lit_11; if linked_1053 == nil { arg_1051 = ifn_1054.Invoke_O_O__O(arg_1055, arg_1056) } else { arg_1051 = linked_1053.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1052, arg_1055, arg_1056) }; if linked_1049 == nil { tmp1 = ifn_1050.Invoke_O__O(arg_1051) } else { tmp1 = linked_1049.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1048, arg_1051) } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var or__1927000174__auto____2 any; var G__28000156__2_ any = A_arbace_classes_env_A_const_94.Get__O(); var G__28000156__3_ any
		if lang.Util_Identical_O_O__Z_NoInit(G__28000156__2_, nil) { G__28000156__3_ = nil } else { var root_1057 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_1058 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1057, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1059 lang.IFn; if linked_1058 == nil { ifn_1059 = lang.IFn_Cast(root_1057) } else { ifn_1059 = nil }; var arg_1060 any = G__28000156__2_; if linked_1058 == nil { G__28000156__3_ = ifn_1059.Invoke_O__O(arg_1060) } else { G__28000156__3_ = linked_1058.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1057, arg_1060) } }; if lang.Util_Identical_O_O__Z_NoInit(G__28000156__3_, nil) { or__1927000174__auto____2 = nil } else { or__1927000174__auto____2 = lang.RT_Get_O_O__O_NoInit(G__28000156__3_, n__0) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else {
			if jrt.J2g_Truth(A_arbace_classes_env_A_const_19.Get__O()) {
				var tmp2 any; var root_1061 any = A_arbace_classes_env_A_const_18.GetRawRoot__O(); var linked_1062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1061, A_arbace_classes_env_from_source_QMARK__A_fn_class); var ifn_1063 lang.IFn; if linked_1062 == nil { ifn_1063 = lang.IFn_Cast(root_1061) } else { ifn_1063 = nil }; var arg_1064 any = n__0; if linked_1062 == nil { tmp2 = ifn_1063.Invoke_O__O(arg_1064) } else { tmp2 = linked_1062.(*A_arbace_classes_env_from_source_QMARK__A).Invoke_O_O__O(root_1061, arg_1064) }; if jrt.J2g_Truth(tmp2) { return nil } else { var tmp3 *lang.Keyword = A_arbace_classes_env_A_const_95; return tmp3.Invoke_O__O(lang.RT_Get_O_O__O_NoInit(A_arbace_classes_env_A_const_19.Get__O(), n__0)) } } else {
//line :227:1
					var temp__1927000414__auto____3 any; var root_1065 any = A_arbace_classes_env_A_const_26.GetRawRoot__O(); var linked_1066 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1065, A_arbace_classes_env_load_class_A_fn_class); var ifn_1067 lang.IFn

					if linked_1066 == nil { ifn_1067 = lang.IFn_Cast(root_1065) } else { ifn_1067 = nil }; var arg_1068 any = n__0; if linked_1066 == nil { temp__1927000414__auto____3 = ifn_1067.Invoke_O__O(arg_1068) } else { temp__1927000414__auto____3 = linked_1066.(*A_arbace_classes_env_load_class_A).Invoke_O_O__O(root_1065, arg_1068) }; if jrt.J2g_Truth(temp__1927000414__auto____3) { var c__4 any = temp__1927000414__auto____3; var d__5 any; var tmp4 any; var root_1069 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_1070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1069, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1071 lang.IFn
						if linked_1070 == nil { ifn_1071 = lang.IFn_Cast(root_1069) } else { ifn_1071 = nil }; var arg_1072 any = A_arbace_classes_env_A_const_96.GetRawRoot__O(); if linked_1070 == nil { tmp4 = ifn_1071.Invoke_O__O(arg_1072) } else { tmp4 = linked_1070.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1069, arg_1072) }; d__5 = lang.RT_Get_O_O__O_NoInit(tmp4, n__0)
						var tmp5 any; var and__1927000168__auto____6 any = d__5; if jrt.J2g_Truth(and__1927000168__auto____6) { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(A_arbace_classes_env_A_const_32.Invoke_O__O(d__5), c__4)).Ref() } else { tmp5 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp5) { return d__5 } else { var root_1073 any = A_arbace_classes_env_A_const_97.GetRawRoot__O(); var linked_1074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1073, A_arbace_classes_env_reflect_info_A_fn_class); var ifn_1075 lang.IFn; if linked_1074 == nil { ifn_1075 = lang.IFn_Cast(root_1073) } else { ifn_1075 = nil }; var arg_1076 any = c__4; if linked_1074 == nil { return ifn_1075.Invoke_O__O(arg_1076) } else { return linked_1074.(*A_arbace_classes_env_reflect_info_A).Invoke_O_O__O(root_1073, arg_1076) } } } else {
//line :229:1
							return nil } } } } else {
//line :225:1
								return nil
							}
}





func A_arbace_classes_env_info_BANG__A_New() *A_arbace_classes_env_info_BANG__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_info_BANG__A{}; t.Ctor(); return t }
//line :233:1
func (t *A_arbace_classes_env_info_BANG__A) Ctor() {}
//line :233:1
func (t *A_arbace_classes_env_info_BANG__A) Invoke_O_O__O(self, n__0 any) any { var or__1927000174__auto____2 any; var root_1077 any = A_arbace_classes_env_A_const_98.GetRawRoot__O(); var linked_1078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1077, A_arbace_classes_env_info_A_fn_class); var ifn_1079 lang.IFn; if
										linked_1078 == nil { ifn_1079 = lang.IFn_Cast(root_1077) } else { ifn_1079 = nil }; var arg_1080 any = n__0; if linked_1078 == nil { or__1927000174__auto____2 = ifn_1079.Invoke_O__O(arg_1080) } else { or__1927000174__auto____2 = linked_1078.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1077, arg_1080) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var tmp1 any; var root_1081 any = A_arbace_classes_env_A_const_29.GetRawRoot__O(); var linked_1082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1081, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1083 lang.IFn; if linked_1082 == nil { ifn_1083 = lang.IFn_Cast(root_1081) } else { ifn_1083 = nil }; var arg_1084 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_20, nil); var tmp3 any; var root_1086 any = A_arbace_classes_env_A_const_12.GetRawRoot__O(); var linked_1087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1086, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1088 lang.IFn; if linked_1087 == nil { ifn_1088 = lang.IFn_Cast(root_1086) } else { ifn_1088 = nil }; var arg_1089 any; var root_1092 any = A_arbace_classes_env_A_const_31.GetRawRoot__O(); var linked_1093 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1092, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1094 lang.IFn; if linked_1093 == nil { ifn_1094 = lang.IFn_Cast(root_1092) } else { ifn_1094 = nil }; var arg_1095 any = n__0; if linked_1093 == nil { arg_1089 = ifn_1094.Invoke_O__O(arg_1095) } else { arg_1089 = linked_1093.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1092, arg_1095) }; var arg_1090 any = Lit_21; var arg_1091 any = Lit_22; if linked_1087 == nil { tmp3 = ifn_1088.Invoke_O_O_O__O(arg_1089, arg_1090, arg_1091) } else { tmp3 = linked_1087.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1086, arg_1089, arg_1090, arg_1091) }; arg_1084 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref(); var arg_1085 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_env_A_const_32, n__0)); if linked_1082 == nil { tmp1 = ifn_1083.Invoke_O_O__O(arg_1084, arg_1085) } else { tmp1 = linked_1082.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1081, arg_1084, arg_1085) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) } }

func A_arbace_classes_env_interface_QMARK__A_New() *A_arbace_classes_env_interface_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_interface_QMARK__A{}; t.Ctor(); return t }
//line :236:1
func (t *A_arbace_classes_env_interface_QMARK__A) Ctor() {}
//line :236:1
func (t *A_arbace_classes_env_interface_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var i__2 any; var root_1096 any = A_arbace_classes_env_A_const_98.GetRawRoot__O(); var linked_1097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1096, A_arbace_classes_env_info_A_fn_class); var ifn_1098 lang.IFn; if
											linked_1097 == nil { ifn_1098 = lang.IFn_Cast(root_1096) } else { ifn_1098 = nil }; var arg_1099 any = n__0; if linked_1097 == nil { i__2 = ifn_1098.Invoke_O__O(arg_1099) } else { i__2 = linked_1097.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1096, arg_1099) }; var tmp1 any; var or__1927000174__auto____3 any = A_arbace_classes_env_A_const_44.Invoke_O__O(i__2); if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var G__28000159__4_ any = A_arbace_classes_env_A_const_43.Invoke_O__O(i__2); var G__28000159__5_ any; if lang.Util_Identical_O_O__Z_NoInit(G__28000159__4_, nil) { G__28000159__5_ = nil } else { var tmp2 int64; var na_1100 any = G__28000159__4_; var na_1101 int64 = 512; if jrt.Long_InstanceOf(na_1100) { var n0_1102 int64 = jrt.NN(jrt.Long_Cast(na_1100)).LongValue__J(); var n1_1103 int64 = na_1101; tmp2 = n0_1102 & n1_1103 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_1100, na_1101) }; G__28000159__5_ = jrt.Long_ValueOf_J__Long_NoInit(tmp2).Ref() }; if lang.Util_Identical_O_O__Z_NoInit(G__28000159__5_, nil) { tmp1 = nil } else { var tmp3 bool; var na_1105 any = G__28000159__5_; if jrt.Long_InstanceOf(na_1105) { var n0_1106 int64 = jrt.NN(jrt.Long_Cast(na_1105)).LongValue__J(); tmp3 = n0_1106 > 0 } else { if jrt.Double_InstanceOf(na_1105) { var n0_1106_2 float64 = jrt.NN(jrt.Double_Cast(na_1105)).DoubleValue__D(); tmp3 = n0_1106_2 > 0.0 } else { tmp3 = lang.Numbers_IsPos_O__Z_NoInit(na_1105) } }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp3).Ref() } }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() }

func A_arbace_classes_env_const_value_A_New() *A_arbace_classes_env_const_value_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_const_value_A{}; t.Ctor(); return t }
//line :239:1
func (t *A_arbace_classes_env_const_value_A) Ctor() {}
//line :239:1
func (t *A_arbace_classes_env_const_value_A) Invoke_O_O__O(self, field__0 any) any { var c__2 any = A_arbace_classes_env_A_const_64.Invoke_O__O(field__0); var tmp1 any; var root_1107 any = A_arbace_classes_env_A_const_99.GetRawRoot__O(); var linked_1108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1107, aot_arbace_core.A_arbace_core_delay_QMARK__A_fn_class); var ifn_1109 lang.IFn; if
											linked_1108 == nil { ifn_1109 = lang.IFn_Cast(root_1107) } else { ifn_1109 = nil }; var arg_1110 any = c__2; if linked_1108 == nil { tmp1 = ifn_1109.Invoke_O__O(arg_1110) } else { tmp1 = linked_1108.(*aot_arbace_core.A_arbace_core_delay_QMARK__A).Invoke_O_O__O(root_1107, arg_1110) }; if jrt.J2g_Truth(tmp1) { var root_1111 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_1112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1111, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1113 lang.IFn; if linked_1112 == nil { ifn_1113 = lang.IFn_Cast(root_1111) } else { ifn_1113 = nil }; var arg_1114 any = c__2; if linked_1112 == nil { return ifn_1113.Invoke_O__O(arg_1114) } else { return linked_1112.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1111, arg_1114) } } else { return c__2 } }

func A_arbace_classes_env_supertypes_A_New() *A_arbace_classes_env_supertypes_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_supertypes_A{}; t.Ctor(); return t }
//line :242:1
func (t *A_arbace_classes_env_supertypes_A) Ctor() {}
//line :242:1
func (t *A_arbace_classes_env_supertypes_A) Invoke_O_O__O(self, n__0 any) any { var i__2 any; var root_1115 any = A_arbace_classes_env_A_const_100.GetRawRoot__O(); var linked_1116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1115, A_arbace_classes_env_info_BANG__A_fn_class); var ifn_1117 lang.IFn; if


	linked_1116 == nil { ifn_1117 = lang.IFn_Cast(root_1115) } else { ifn_1117 = nil }; var arg_1118 any = n__0; if linked_1116 == nil { i__2 = ifn_1117.Invoke_O__O(arg_1118) } else { i__2 = linked_1116.(*A_arbace_classes_env_info_BANG__A).Invoke_O_O__O(root_1115, arg_1118) }; var G__28000162__3_ any; var root_1119 any = /*line :242:1*/A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_1120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1119, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1121 lang.IFn; if


	linked_1120 == nil { ifn_1121 = lang.IFn_Cast(root_1119) } else { ifn_1121 = nil }; var arg_1122 any = A_arbace_classes_env_A_const_46.Invoke_O__O(i__2); if linked_1120 == nil { G__28000162__3_ = ifn_1121.Invoke_O__O(arg_1122) } else { G__28000162__3_ = linked_1120.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1119, arg_1122) }; if jrt.J2g_Truth(A_arbace_classes_env_A_const_45.Invoke_O__O(i__2)) { var root_1123 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_1124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1123, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1125 lang.IFn; if linked_1124 == nil { ifn_1125 = lang.IFn_Cast(root_1123) } else { ifn_1125 = nil }; var arg_1126 any; var root_1127 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_1128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1127, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1129 lang.IFn; if linked_1128 == nil { ifn_1129 = lang.IFn_Cast(root_1127) } else { ifn_1129 = nil }; var arg_1130 any = A_arbace_classes_env_A_const_45.Invoke_O__O(i__2); var arg_1131 any = G__28000162__3_; if linked_1128 == nil { arg_1126 = ifn_1129.Invoke_O_O__O(arg_1130, arg_1131) } else { arg_1126 = linked_1128.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1127, arg_1130, arg_1131) }; if linked_1124 == nil { return ifn_1125.Invoke_O__O(arg_1126) } else { return linked_1124.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1123, arg_1126) } } else { return G__28000162__3_ } }

func A_arbace_classes_env_subclass_QMARK__A_New() *A_arbace_classes_env_subclass_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_subclass_QMARK__A{}; t.Ctor(); return t }
//line :247:1
func (t *A_arbace_classes_env_subclass_QMARK__A) Ctor() {}
//line :247:1
func (t *A_arbace_classes_env_subclass_QMARK__A) Invoke_O_O_O__O(self, a__0, b__1 any) any { var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(a__0, b__1); if or__1927000174__auto____3 {


	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var or__1927000174__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(b__1, Lit_4); if or__1927000174__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____4).Ref() } else {
		var tmp1 any; var root_1132 any = A_arbace_classes_env_A_const_101.GetRawRoot__O(); var linked_1133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1132, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1134 lang.IFn; if linked_1133 == nil { ifn_1134 = lang.IFn_Cast(root_1132) } else { ifn_1134 = nil }; var arg_1135 any; var fnbody__1143 any = A_arbace_classes_env_subclass_QMARK__fn__28000165_A_New_O(b__1); var tmp2 *jrt.Class; var fncls__1142 *jrt.Class = A_arbace_classes_env_subclass_QMARK__fn__28000165_A_fn_class; if fncls__1142 == nil { var fncls__1142d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_67, false, fnbody__1143); A_arbace_classes_env_subclass_QMARK__fn__28000165_A_fn_class = fncls__1142d; tmp2 = fncls__1142d } else { tmp2 = fncls__1142 }; arg_1135 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1143, tmp2, nil); var arg_1136 any; var temp__1927000414__auto____5 any; var root_1144 any = A_arbace_classes_env_A_const_98.GetRawRoot__O(); var linked_1145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1144, A_arbace_classes_env_info_A_fn_class); var ifn_1146 lang.IFn; if linked_1145 == nil { ifn_1146 = lang.IFn_Cast(root_1144) } else { ifn_1146 = nil }; var arg_1147 any = a__0; if linked_1145 == nil { temp__1927000414__auto____5 = ifn_1146.Invoke_O__O(arg_1147) } else { temp__1927000414__auto____5 = linked_1145.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1144, arg_1147) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var i__6 any = temp__1927000414__auto____5; var G__28000167__7_ any; var root_1148 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_1149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1148, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1150 lang.IFn
			if linked_1149 == nil { ifn_1150 = lang.IFn_Cast(root_1148) } else { ifn_1150 = nil }; var arg_1151 any = A_arbace_classes_env_A_const_46.Invoke_O__O(i__6); if linked_1149 == nil { G__28000167__7_ = ifn_1150.Invoke_O__O(arg_1151) } else { G__28000167__7_ = linked_1149.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1148, arg_1151) }; if jrt.J2g_Truth(A_arbace_classes_env_A_const_45.Invoke_O__O(i__6)) { var root_1152 any = A_arbace_classes_env_A_const_10.GetRawRoot__O(); var linked_1153 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1152, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1154 lang.IFn; if linked_1153 == nil { ifn_1154 = lang.IFn_Cast(root_1152) } else { ifn_1154 = nil }; var arg_1155 any = G__28000167__7_; var arg_1156 any = A_arbace_classes_env_A_const_45.Invoke_O__O(i__6); if linked_1153 == nil { arg_1136 = ifn_1154.Invoke_O_O__O(arg_1155, arg_1156) } else { arg_1136 = linked_1153.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1152, arg_1155, arg_1156) } } else { arg_1136 = G__28000167__7_ } } else {
//line :251:1
				arg_1136 = nil }; if linked_1133 == nil { tmp1 = ifn_1134.Invoke_O_O__O(arg_1135, arg_1136) } else { tmp1 = linked_1133.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1132, arg_1135, arg_1136) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() } } }
//line :251:1
func A_arbace_classes_env_subclass_QMARK__fn__28000165_A_New_O(p0 any) *A_arbace_classes_env_subclass_QMARK__fn__28000165_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_subclass_QMARK__fn__28000165_A{}; t.Ctor_O(p0); return t }
//line :251:1
func (t *A_arbace_classes_env_subclass_QMARK__fn__28000165_A) Ctor_O(c__b any) { t.F_b = c__b }
//line :251:1
func (t *A_arbace_classes_env_subclass_QMARK__fn__28000165_A) Invoke_O_O__O(self, p1__28000164_SHARP___1 any) any { var root_1137 any = A_arbace_classes_env_A_const_102.GetRawRoot__O(); var linked_1138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1137, A_arbace_classes_env_subclass_QMARK__A_fn_class); var ifn_1139 lang.IFn; if linked_1138 == nil { ifn_1139 = lang.IFn_Cast(root_1137) } else { ifn_1139 = nil }; var arg_1140 any = p1__28000164_SHARP___1; var arg_1141 any = t.F_b; if linked_1138 == nil { return ifn_1139.Invoke_O_O__O(arg_1140, arg_1141) } else { return linked_1138.(*A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(root_1137, arg_1140, arg_1141) } }


func A_arbace_classes_env_assignable_QMARK__A_New() *A_arbace_classes_env_assignable_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_assignable_QMARK__A{}; t.Ctor(); return t }
//line :254:1
func (t *A_arbace_classes_env_assignable_QMARK__A) Ctor() {}
//line :254:1
func (t *A_arbace_classes_env_assignable_QMARK__A) Invoke_O_O_O__O(self, from__0, to__1 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(from__0, to__1) { return jrt.Boolean_TRUE.Ref() } else { if lang.Util_Equiv_O_O__Z_NoInit(from__0, A_arbace_classes_env_A_const_103) {

		var root_1157 any = A_arbace_classes_env_A_const_104.GetRawRoot__O(); var linked_1158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1157, aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A_fn_class); var ifn_1159 lang.IFn; if linked_1158 == nil { ifn_1159 = lang.IFn_Cast(root_1157) } else { ifn_1159 = nil }; var arg_1160 any = to__1; if linked_1158 == nil { return ifn_1159.Invoke_O__O(arg_1160) } else { return linked_1158.(*aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A).Invoke_O_O__O(root_1157, arg_1160) } } else {
//line :257:1
			var tmp1 any; var root_1161 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1161, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1163 lang.IFn


			if linked_1162 == nil { ifn_1163 = lang.IFn_Cast(root_1161) } else { ifn_1163 = nil }; var arg_1164 any; var and__1927000168__auto____3 any; var root_1165 any = A_arbace_classes_env_A_const_104.GetRawRoot__O(); var linked_1166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1165, aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A_fn_class); var ifn_1167 lang.IFn; if linked_1166 == nil { ifn_1167 = lang.IFn_Cast(root_1165) } else { ifn_1167 = nil }; var arg_1168 any = from__0; if linked_1166 == nil { and__1927000168__auto____3 = ifn_1167.Invoke_O__O(arg_1168) } else { and__1927000168__auto____3 = linked_1166.(*aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A).Invoke_O_O__O(root_1165, arg_1168) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_1169 any = A_arbace_classes_env_A_const_104.GetRawRoot__O(); var linked_1170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1169, aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A_fn_class); var ifn_1171 lang.IFn; if linked_1170 == nil { ifn_1171 = lang.IFn_Cast(root_1169) } else { ifn_1171 = nil }; var arg_1172 any = to__1; if linked_1170 == nil { arg_1164 = ifn_1171.Invoke_O__O(arg_1172) } else { arg_1164 = linked_1170.(*aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A).Invoke_O_O__O(root_1169, arg_1172) } } else { arg_1164 = and__1927000168__auto____3 }; if linked_1162 == nil { tmp1 = ifn_1163.Invoke_O__O(arg_1164) } else { tmp1 = linked_1162.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1161, arg_1164) }
//line :257:1
			if jrt.J2g_Truth(tmp1) { return jrt.Boolean_FALSE.Ref() } else { if lang.Util_Equiv_O_O__Z_NoInit(to__1, A_arbace_classes_env_A_const_105.GetRawRoot__O()) { return jrt.Boolean_TRUE.Ref() } else { var tmp2 any; var root_1173 any = A_arbace_classes_env_A_const_106.GetRawRoot__O(); var linked_1174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1173, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_1175 lang.IFn




				if linked_1174 == nil { ifn_1175 = lang.IFn_Cast(root_1173) } else { ifn_1175 = nil }; var arg_1176 any = from__0; if linked_1174 == nil { tmp2 = ifn_1175.Invoke_O__O(arg_1176) } else { tmp2 = linked_1174.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_1173, arg_1176) }
//line :257:1
				if jrt.J2g_Truth(tmp2) {





					var tmp3 any; var root_1177 any = A_arbace_classes_env_A_const_106.GetRawRoot__O(); var linked_1178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1177, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_1179 lang.IFn; if linked_1178 == nil { ifn_1179 = lang.IFn_Cast(root_1177) } else { ifn_1179 = nil }; var arg_1180 any = to__1; if linked_1178 == nil { tmp3 = ifn_1179.Invoke_O__O(arg_1180) } else { tmp3 = linked_1178.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_1177, arg_1180) }; if jrt.J2g_Truth(tmp3) { var fe__3 any; var root_1181 any = A_arbace_classes_env_A_const_107.GetRawRoot__O(); var linked_1182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1181, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_1183 lang.IFn; if linked_1182 == nil { ifn_1183 = lang.IFn_Cast(root_1181) } else { ifn_1183 = nil }; var arg_1184 any = from__0; if linked_1182 == nil { fe__3 = ifn_1183.Invoke_O__O(arg_1184) } else { fe__3 = linked_1182.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_1181, arg_1184) }; var te__4 any; var root_1185 any = A_arbace_classes_env_A_const_107.GetRawRoot__O(); var linked_1186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1185, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_1187 lang.IFn; if linked_1186 == nil { ifn_1187 = lang.IFn_Cast(root_1185) } else { ifn_1187 = nil }; var arg_1188 any = to__1; if linked_1186 == nil { te__4 = ifn_1187.Invoke_O__O(arg_1188) } else { te__4 = linked_1186.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_1185, arg_1188) }; var and__1927000168__auto____5 any; var root_1189 any = A_arbace_classes_env_A_const_104.GetRawRoot__O(); var linked_1190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1189, aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A_fn_class); var ifn_1191 lang.IFn
						if linked_1190 == nil { ifn_1191 = lang.IFn_Cast(root_1189) } else { ifn_1191 = nil }; var arg_1192 any = fe__3; if linked_1190 == nil { and__1927000168__auto____5 = ifn_1191.Invoke_O__O(arg_1192) } else { and__1927000168__auto____5 = linked_1190.(*aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A).Invoke_O_O__O(root_1189, arg_1192) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_1193 any = A_arbace_classes_env_A_const_104.GetRawRoot__O(); var linked_1194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1193, aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A_fn_class); var ifn_1195 lang.IFn; if linked_1194 == nil { ifn_1195 = lang.IFn_Cast(root_1193) } else { ifn_1195 = nil }; var arg_1196 any = te__4; if linked_1194 == nil { and__1927000168__auto____6 = ifn_1195.Invoke_O__O(arg_1196) } else { and__1927000168__auto____6 = linked_1194.(*aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A).Invoke_O_O__O(root_1193, arg_1196) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_1197 any = A_arbace_classes_env_A_const_108.GetRawRoot__O(); var linked_1198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1197, A_arbace_classes_env_assignable_QMARK__A_fn_class); var ifn_1199 lang.IFn; if linked_1198 == nil { ifn_1199 = lang.IFn_Cast(root_1197) } else { ifn_1199 = nil }; var arg_1200 any = fe__3; var arg_1201 any = te__4; if linked_1198 == nil { return ifn_1199.Invoke_O_O__O(arg_1200, arg_1201) } else { return linked_1198.(*A_arbace_classes_env_assignable_QMARK__A).Invoke_O_O_O__O(root_1197, arg_1200, arg_1201) } } else { return and__1927000168__auto____6 } } else { return and__1927000168__auto____5 } } else {
//line :263:1
							if A_arbace_classes_env_A_const_109 != nil {

								var root_1202 any = A_arbace_classes_env_A_const_23.GetRawRoot__O(); var linked_1203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1202, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1204 lang.IFn; if linked_1203 == nil { ifn_1204 = lang.IFn_Cast(root_1202) } else { ifn_1204 = nil }; var arg_1205 any = A_arbace_classes_env_A_const_110; var arg_1206 any = to__1; if linked_1203 == nil { return ifn_1204.Invoke_O_O__O(arg_1205, arg_1206) } else { return linked_1203.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1202, arg_1205, arg_1206) } } else {
//line :263:1
									return nil } } } else {
//line :257:1
										var tmp4 any; var root_1207 any = A_arbace_classes_env_A_const_106.GetRawRoot__O(); var linked_1208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1207, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_1209 lang.IFn








										if linked_1208 == nil { ifn_1209 = lang.IFn_Cast(root_1207) } else { ifn_1209 = nil }; var arg_1210 any = to__1; if linked_1208 == nil { tmp4 = ifn_1209.Invoke_O__O(arg_1210) } else { tmp4 = linked_1208.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_1207, arg_1210) }
//line :257:1
										if jrt.J2g_Truth(tmp4) { return jrt.Boolean_FALSE.Ref() } else { if A_arbace_classes_env_A_const_109 != nil {









											var root_1211 any = A_arbace_classes_env_A_const_102.GetRawRoot__O(); var linked_1212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1211, A_arbace_classes_env_subclass_QMARK__A_fn_class); var ifn_1213 lang.IFn; if linked_1212 == nil { ifn_1213 = lang.IFn_Cast(root_1211) } else { ifn_1213 = nil }; var arg_1214 any; var root_1216 any = A_arbace_classes_env_A_const_111.GetRawRoot__O(); var linked_1217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1216, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_1218 lang.IFn; if linked_1217 == nil { ifn_1218 = lang.IFn_Cast(root_1216) } else { ifn_1218 = nil }; var arg_1219 any = from__0; if linked_1217 == nil { arg_1214 = ifn_1218.Invoke_O__O(arg_1219) } else { arg_1214 = linked_1217.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_1216, arg_1219) }; var arg_1215 any; var root_1220 any = A_arbace_classes_env_A_const_111.GetRawRoot__O(); var linked_1221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1220, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_1222 lang.IFn; if linked_1221 == nil { ifn_1222 = lang.IFn_Cast(root_1220) } else { ifn_1222 = nil }; var arg_1223 any = to__1; if linked_1221 == nil { arg_1215 = ifn_1222.Invoke_O__O(arg_1223) } else { arg_1215 = linked_1221.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_1220, arg_1223) }; if linked_1212 == nil { return ifn_1213.Invoke_O_O__O(arg_1214, arg_1215) } else { return linked_1212.(*A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(root_1211, arg_1214, arg_1215) } } else {
//line :257:1
												return nil
											}
										}
									}
			}
			}
		}
	}
}



func A_arbace_classes_env_superclass_chain_A_New() *A_arbace_classes_env_superclass_chain_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_superclass_chain_A{}; t.Ctor(); return t }
//line :269:1
func (t *A_arbace_classes_env_superclass_chain_A) Ctor() {}
//line :269:1
func (t *A_arbace_classes_env_superclass_chain_A) Invoke_O_O__O(self, n__0 any) any {
	var root_1224 any = A_arbace_classes_env_A_const_112.GetRawRoot__O(); var linked_1225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1224, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_1226 lang.IFn; if linked_1225 == nil { ifn_1226 = lang.IFn_Cast(root_1224) } else { ifn_1226 = nil }; var arg_1227 any = A_arbace_classes_env_A_const_25.GetRawRoot__O(); var arg_1228 any; var root_1229 any = A_arbace_classes_env_A_const_113.GetRawRoot__O(); var linked_1230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1229, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_1231 lang.IFn; if linked_1230 == nil { ifn_1231 = lang.IFn_Cast(root_1229) } else { ifn_1231 = nil }; var arg_1232 any; var fnbody__1239 any = A_arbace_classes_env_superclass_chain_fn__28000171_A_New(); var tmp1 *jrt.Class; var fncls__1238 *jrt.Class = A_arbace_classes_env_superclass_chain_fn__28000171_A_fn_class; if fncls__1238 == nil { var fncls__1238d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_68, false, nil); A_arbace_classes_env_superclass_chain_fn__28000171_A_fn_class = fncls__1238d; tmp1 = fncls__1238d } else { tmp1 = fncls__1238 }; arg_1232 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1239, tmp1, nil); var arg_1233 any = n__0; if linked_1230 == nil { arg_1228 = ifn_1231.Invoke_O_O__O(arg_1232, arg_1233) } else { arg_1228 = linked_1230.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_1229, arg_1232, arg_1233) }; if linked_1225 == nil { return ifn_1226.Invoke_O_O__O(arg_1227, arg_1228) } else { return linked_1225.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_1224, arg_1227, arg_1228) } }
//line :270:1
func A_arbace_classes_env_superclass_chain_fn__28000171_A_New() *A_arbace_classes_env_superclass_chain_fn__28000171_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_superclass_chain_fn__28000171_A{}; t.Ctor(); return t }
//line :270:1
func (t *A_arbace_classes_env_superclass_chain_fn__28000171_A) Ctor() {}
//line :270:1
func (t *A_arbace_classes_env_superclass_chain_fn__28000171_A) Invoke_O_O__O(self, p1__28000170_SHARP___1 any) any { var G__28000172__2_ any = p1__28000170_SHARP___1; var G__28000172__3_ any; if lang.Util_Identical_O_O__Z_NoInit(G__28000172__2_, nil) { G__28000172__3_ = nil } else { var root_1234 any = A_arbace_classes_env_A_const_98.GetRawRoot__O(); var linked_1235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1234, A_arbace_classes_env_info_A_fn_class); var ifn_1236 lang.IFn; if linked_1235 == nil { ifn_1236 = lang.IFn_Cast(root_1234) } else { ifn_1236 = nil }; var arg_1237 any = G__28000172__2_; if linked_1235 == nil { G__28000172__3_ = ifn_1236.Invoke_O__O(arg_1237) } else { G__28000172__3_ = linked_1235.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1234, arg_1237) } }; if lang.Util_Identical_O_O__Z_NoInit(G__28000172__3_, nil) { return nil } else { return A_arbace_classes_env_A_const_45.Invoke_O__O(G__28000172__3_) } }

func A_arbace_classes_env_common_super_A_New() *A_arbace_classes_env_common_super_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_common_super_A{}; t.Ctor(); return t }
//line :272:1
func (t *A_arbace_classes_env_common_super_A) Ctor() {}
//line :272:1
func (t *A_arbace_classes_env_common_super_A) Invoke_O_O_O__O(self, a__0, b__1 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(a__0, b__1) { return a__0 } else { var tmp1 any; var or__1927000174__auto____3 any; var root_1240 any = A_arbace_classes_env_A_const_20.GetRawRoot__O(); var linked_1241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1240, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1242 lang.IFn

		if linked_1241 == nil { ifn_1242 = lang.IFn_Cast(root_1240) } else { ifn_1242 = nil }; var arg_1243 any = a__0; var arg_1244 any = Lit_11; if linked_1241 == nil { or__1927000174__auto____3 = ifn_1242.Invoke_O_O__O(arg_1243, arg_1244) } else { or__1927000174__auto____3 = linked_1241.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1240, arg_1243, arg_1244) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var root_1245 any = A_arbace_classes_env_A_const_20.GetRawRoot__O(); var linked_1246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1245, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1247 lang.IFn; if linked_1246 == nil { ifn_1247 = lang.IFn_Cast(root_1245) } else { ifn_1247 = nil }; var arg_1248 any = b__1; var arg_1249 any = Lit_11; if linked_1246 == nil { tmp1 = ifn_1247.Invoke_O_O__O(arg_1248, arg_1249) } else { tmp1 = linked_1246.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1245, arg_1248, arg_1249) } }
//line :275:1
		if jrt.J2g_Truth(tmp1) { return Lit_4 } else { var tmp2 any; var root_1250 any = A_arbace_classes_env_A_const_102.GetRawRoot__O(); var linked_1251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1250, A_arbace_classes_env_subclass_QMARK__A_fn_class); var ifn_1252 lang.IFn


			if linked_1251 == nil { ifn_1252 = lang.IFn_Cast(root_1250) } else { ifn_1252 = nil }; var arg_1253 any = a__0; var arg_1254 any = b__1; if linked_1251 == nil { tmp2 = ifn_1252.Invoke_O_O__O(arg_1253, arg_1254) } else { tmp2 = linked_1251.(*A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(root_1250, arg_1253, arg_1254) }
//line :275:1
			if jrt.J2g_Truth(tmp2) {


				var tmp3 any; var root_1255 any = A_arbace_classes_env_A_const_114.GetRawRoot__O(); var linked_1256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1255, A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_1257 lang.IFn; if linked_1256 == nil { ifn_1257 = lang.IFn_Cast(root_1255) } else { ifn_1257 = nil }; var arg_1258 any = b__1; if linked_1256 == nil { tmp3 = ifn_1257.Invoke_O__O(arg_1258) } else { tmp3 = linked_1256.(*A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_1255, arg_1258) }; if jrt.J2g_Truth(tmp3) { return Lit_4 } else { return b__1 } } else {
//line :275:1
					var tmp4 any; var root_1259 any = A_arbace_classes_env_A_const_102.GetRawRoot__O(); var linked_1260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1259, A_arbace_classes_env_subclass_QMARK__A_fn_class); var ifn_1261 lang.IFn



					if linked_1260 == nil { ifn_1261 = lang.IFn_Cast(root_1259) } else { ifn_1261 = nil }; var arg_1262 any = b__1; var arg_1263 any = a__0; if linked_1260 == nil { tmp4 = ifn_1261.Invoke_O_O__O(arg_1262, arg_1263) } else { tmp4 = linked_1260.(*A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(root_1259, arg_1262, arg_1263) }
//line :275:1
					if jrt.J2g_Truth(tmp4) {



						var tmp5 any; var root_1264 any = A_arbace_classes_env_A_const_114.GetRawRoot__O(); var linked_1265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1264, A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_1266 lang.IFn; if linked_1265 == nil { ifn_1266 = lang.IFn_Cast(root_1264) } else { ifn_1266 = nil }; var arg_1267 any = a__0; if linked_1265 == nil { tmp5 = ifn_1266.Invoke_O__O(arg_1267) } else { tmp5 = linked_1265.(*A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_1264, arg_1267) }; if jrt.J2g_Truth(tmp5) { return Lit_4 } else { return a__0 } } else {
//line :275:1
							var tmp6 any; var or__1927000174__auto____3_2 any; var root_1268 any = A_arbace_classes_env_A_const_114.GetRawRoot__O(); var linked_1269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1268, A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_1270 lang.IFn




							if linked_1269 == nil { ifn_1270 = lang.IFn_Cast(root_1268) } else { ifn_1270 = nil }; var arg_1271 any = a__0; if linked_1269 == nil { or__1927000174__auto____3_2 = ifn_1270.Invoke_O__O(arg_1271) } else { or__1927000174__auto____3_2 = linked_1269.(*A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_1268, arg_1271) }; if jrt.J2g_Truth(or__1927000174__auto____3_2) { tmp6 = or__1927000174__auto____3_2 } else { var root_1272 any = A_arbace_classes_env_A_const_114.GetRawRoot__O(); var linked_1273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1272, A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_1274 lang.IFn; if linked_1273 == nil { ifn_1274 = lang.IFn_Cast(root_1272) } else { ifn_1274 = nil }; var arg_1275 any = b__1; if linked_1273 == nil { tmp6 = ifn_1274.Invoke_O__O(arg_1275) } else { tmp6 = linked_1273.(*A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_1272, arg_1275) } }
//line :275:1
							if jrt.J2g_Truth(tmp6) { return Lit_4 } else { if A_arbace_classes_env_A_const_109 != nil { var bs__3 any; var root_1276 any = A_arbace_classes_env_A_const_87.GetRawRoot__O(); var linked_1277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1276, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_1278 lang.IFn





								if linked_1277 == nil { ifn_1278 = lang.IFn_Cast(root_1276) } else { ifn_1278 = nil }; var arg_1279 any; var root_1280 any = A_arbace_classes_env_A_const_115.GetRawRoot__O(); var linked_1281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1280, A_arbace_classes_env_superclass_chain_A_fn_class); var ifn_1282 lang.IFn; if linked_1281 == nil { ifn_1282 = lang.IFn_Cast(root_1280) } else { ifn_1282 = nil }; var arg_1283 any = b__1; if linked_1281 == nil { arg_1279 = ifn_1282.Invoke_O__O(arg_1283) } else { arg_1279 = linked_1281.(*A_arbace_classes_env_superclass_chain_A).Invoke_O_O__O(root_1280, arg_1283) }; if linked_1277 == nil { bs__3 = ifn_1278.Invoke_O__O(arg_1279) } else { bs__3 = linked_1277.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1276, arg_1279) }
//line :275:1
								var or__1927000174__auto____4 any; var root_1284 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_1285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1284, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1286 lang.IFn






								if linked_1285 == nil { ifn_1286 = lang.IFn_Cast(root_1284) } else { ifn_1286 = nil }; var arg_1287 any; var root_1288 any = A_arbace_classes_env_A_const_92.GetRawRoot__O(); var linked_1289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1288, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1290 lang.IFn; if linked_1289 == nil { ifn_1290 = lang.IFn_Cast(root_1288) } else { ifn_1290 = nil }; var arg_1291 any = bs__3; var arg_1292 any; var root_1293 any = A_arbace_classes_env_A_const_115.GetRawRoot__O(); var linked_1294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1293, A_arbace_classes_env_superclass_chain_A_fn_class); var ifn_1295 lang.IFn; if linked_1294 == nil { ifn_1295 = lang.IFn_Cast(root_1293) } else { ifn_1295 = nil }; var arg_1296 any = a__0; if linked_1294 == nil { arg_1292 = ifn_1295.Invoke_O__O(arg_1296) } else { arg_1292 = linked_1294.(*A_arbace_classes_env_superclass_chain_A).Invoke_O_O__O(root_1293, arg_1296) }; if linked_1289 == nil { arg_1287 = ifn_1290.Invoke_O_O__O(arg_1291, arg_1292) } else { arg_1287 = linked_1289.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1288, arg_1291, arg_1292) }; if linked_1285 == nil { or__1927000174__auto____4 = ifn_1286.Invoke_O__O(arg_1287) } else { or__1927000174__auto____4 = linked_1285.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1284, arg_1287) }; if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { return Lit_4 } } else {
//line :275:1
									return nil
								}
							}
						}
				}
		}
	}
}

func A_arbace_classes_env_lub_A_New() *A_arbace_classes_env_lub_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_lub_A{}; t.Ctor(); return t }
//line :284:1
func (t *A_arbace_classes_env_lub_A) Ctor() {}
//line :284:1
func (t *A_arbace_classes_env_lub_A) Invoke_O_O_O__O(self, a__0, b__1 any) any {



	if lang.Util_Equiv_O_O__Z_NoInit(a__0, b__1) { return a__0 } else { if lang.Util_Equiv_O_O__Z_NoInit(a__0, A_arbace_classes_env_A_const_103) { return b__1 } else { if lang.Util_Equiv_O_O__Z_NoInit(b__1, A_arbace_classes_env_A_const_103) { return a__0 } else { var tmp1 any; var root_1297 any = A_arbace_classes_env_A_const_108.GetRawRoot__O(); var linked_1298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1297, A_arbace_classes_env_assignable_QMARK__A_fn_class); var ifn_1299 lang.IFn


		if linked_1298 == nil { ifn_1299 = lang.IFn_Cast(root_1297) } else { ifn_1299 = nil }; var arg_1300 any = a__0; var arg_1301 any = b__1; if linked_1298 == nil { tmp1 = ifn_1299.Invoke_O_O__O(arg_1300, arg_1301) } else { tmp1 = linked_1298.(*A_arbace_classes_env_assignable_QMARK__A).Invoke_O_O_O__O(root_1297, arg_1300, arg_1301) }
//line :288:1
		if jrt.J2g_Truth(tmp1) { return b__1 } else { var tmp2 any; var root_1302 any = A_arbace_classes_env_A_const_108.GetRawRoot__O(); var linked_1303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1302, A_arbace_classes_env_assignable_QMARK__A_fn_class); var ifn_1304 lang.IFn



			if linked_1303 == nil { ifn_1304 = lang.IFn_Cast(root_1302) } else { ifn_1304 = nil }; var arg_1305 any = b__1; var arg_1306 any = a__0; if linked_1303 == nil { tmp2 = ifn_1304.Invoke_O_O__O(arg_1305, arg_1306) } else { tmp2 = linked_1303.(*A_arbace_classes_env_assignable_QMARK__A).Invoke_O_O_O__O(root_1302, arg_1305, arg_1306) }
//line :288:1
			if jrt.J2g_Truth(tmp2) { return a__0 } else { var tmp3 any; var and__1927000168__auto____3 any; var root_1307 any = A_arbace_classes_env_A_const_116.GetRawRoot__O(); var linked_1308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1307, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_1309 lang.IFn




				if linked_1308 == nil { ifn_1309 = lang.IFn_Cast(root_1307) } else { ifn_1309 = nil }; var arg_1310 any = a__0; if linked_1308 == nil { and__1927000168__auto____3 = ifn_1309.Invoke_O__O(arg_1310) } else { and__1927000168__auto____3 = linked_1308.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_1307, arg_1310) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_1311 any = A_arbace_classes_env_A_const_116.GetRawRoot__O(); var linked_1312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1311, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_1313 lang.IFn; if linked_1312 == nil { ifn_1313 = lang.IFn_Cast(root_1311) } else { ifn_1313 = nil }; var arg_1314 any = b__1; if linked_1312 == nil { tmp3 = ifn_1313.Invoke_O__O(arg_1314) } else { tmp3 = linked_1312.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_1311, arg_1314) } } else { tmp3 = and__1927000168__auto____3 }
//line :288:1
				if jrt.J2g_Truth(tmp3) { var c__3 any; var root_1315 any = A_arbace_classes_env_A_const_117.GetRawRoot__O(); var linked_1316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1315, A_arbace_classes_env_common_super_A_fn_class); var ifn_1317 lang.IFn





					if linked_1316 == nil { ifn_1317 = lang.IFn_Cast(root_1315) } else { ifn_1317 = nil }; var arg_1318 any; var root_1320 any = A_arbace_classes_env_A_const_111.GetRawRoot__O(); var linked_1321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1320, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_1322 lang.IFn; if linked_1321 == nil { ifn_1322 = lang.IFn_Cast(root_1320) } else { ifn_1322 = nil }; var arg_1323 any = a__0; if linked_1321 == nil { arg_1318 = ifn_1322.Invoke_O__O(arg_1323) } else { arg_1318 = linked_1321.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_1320, arg_1323) }; var arg_1319 any; var root_1324 any = A_arbace_classes_env_A_const_111.GetRawRoot__O(); var linked_1325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1324, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_1326 lang.IFn; if linked_1325 == nil { ifn_1326 = lang.IFn_Cast(root_1324) } else { ifn_1326 = nil }; var arg_1327 any = b__1; if linked_1325 == nil { arg_1319 = ifn_1326.Invoke_O__O(arg_1327) } else { arg_1319 = linked_1325.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_1324, arg_1327) }; if linked_1316 == nil { c__3 = ifn_1317.Invoke_O_O__O(arg_1318, arg_1319) } else { c__3 = linked_1316.(*A_arbace_classes_env_common_super_A).Invoke_O_O_O__O(root_1315, arg_1318, arg_1319) }
					if lang.Util_Equiv_O_O__Z_NoInit(c__3, Lit_4) { var sups__4 any; var fnbody__1354 any = A_arbace_classes_env_lub_sups__28000177_A_New(); var tmp4 *jrt.Class
						var fncls__1353 /*line :295:1*/*jrt.Class = A_arbace_classes_env_lub_sups__28000177_A_fn_class

						if fncls__1353 == nil { var fncls__1353d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, nil); A_arbace_classes_env_lub_sups__28000177_A_fn_class = fncls__1353d; tmp4 = fncls__1353d } else { tmp4 = fncls__1353 }; sups__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1354, tmp4, nil)
//line :295:1
						var common__5 any; var root_1355 any = A_arbace_classes_env_A_const_92.GetRawRoot__O(); var linked_1356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1355, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1357 lang.IFn




						if linked_1356 == nil { ifn_1357 = lang.IFn_Cast(root_1355) } else { ifn_1357 = nil }; var arg_1358 any = A_arbace_classes_env_A_const_114.GetRawRoot__O(); var arg_1359 any; var root_1360 any = A_arbace_classes_env_A_const_119.GetRawRoot__O(); var linked_1361 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1360, aot_arbace_set.A_arbace_set_intersection_A_fn_class); var ifn_1362 lang.IFn; if linked_1361 == nil { ifn_1362 = lang.IFn_Cast(root_1360) } else { ifn_1362 = nil }; var arg_1363 any; var tmp5 lang.IFn = lang.IFn_Cast(sups__4); var tmp6 any; var root_1365 any = A_arbace_classes_env_A_const_111.GetRawRoot__O(); var linked_1366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1365, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_1367 lang.IFn; if linked_1366 == nil { ifn_1367 = lang.IFn_Cast(root_1365) } else { ifn_1367 = nil }; var arg_1368 any = a__0; if linked_1366 == nil { tmp6 = ifn_1367.Invoke_O__O(arg_1368) } else { tmp6 = linked_1366.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_1365, arg_1368) }; arg_1363 = tmp5.Invoke_O__O(tmp6); var arg_1364 any; var tmp7 lang.IFn = lang.IFn_Cast(sups__4); var tmp8 any; var root_1369 any = A_arbace_classes_env_A_const_111.GetRawRoot__O(); var linked_1370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1369, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_1371 lang.IFn
						if linked_1370 == nil { ifn_1371 = lang.IFn_Cast(root_1369) } else { ifn_1371 = nil }; var arg_1372 any = b__1; if linked_1370 == nil { tmp8 = ifn_1371.Invoke_O__O(arg_1372) } else { tmp8 = linked_1370.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_1369, arg_1372) }; arg_1364 = tmp7.Invoke_O__O(tmp8)
//line :300:1
						if linked_1361 == nil { arg_1359 = ifn_1362.Invoke_O_O__O(arg_1363, arg_1364) } else { arg_1359 = linked_1361.(*aot_arbace_set.A_arbace_set_intersection_A).Invoke_O_O_O__O(root_1360, arg_1363, arg_1364) }; if linked_1356 == nil { common__5 = ifn_1357.Invoke_O_O__O(arg_1358, arg_1359) } else { common__5 = linked_1356.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1355, arg_1358, arg_1359) }
//line :295:1
						var minimal__6 any; var root_1373 any = A_arbace_classes_env_A_const_120.GetRawRoot__O(); var linked_1374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1373, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1375 lang.IFn






						if linked_1374 == nil { ifn_1375 = lang.IFn_Cast(root_1373) } else { ifn_1375 = nil }; var arg_1376 any; var fnbody__1396 any = A_arbace_classes_env_lub_fn__28000182_A_New_O(common__5); var tmp9 *jrt.Class; var fncls__1395 *jrt.Class = A_arbace_classes_env_lub_fn__28000182_A_fn_class; if fncls__1395 == nil { var fncls__1395d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_24, false, fnbody__1396); A_arbace_classes_env_lub_fn__28000182_A_fn_class = fncls__1395d; tmp9 = fncls__1395d } else { tmp9 = fncls__1395 }; arg_1376 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1396, tmp9, nil); var arg_1377 any = common__5; if linked_1374 == nil { minimal__6 = ifn_1375.Invoke_O_O__O(arg_1376, arg_1377) } else { minimal__6 = linked_1374.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1373, arg_1376, arg_1377) }
						if lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(minimal__6))) { var root_1397 any = A_arbace_classes_env_A_const_122.GetRawRoot__O(); var linked_1398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1397, aot_arbace_classes_types.A_arbace_classes_types_internal__GT_desc_A_fn_class); var ifn_1399 lang.IFn; if linked_1398 == nil { ifn_1399 = lang.IFn_Cast(root_1397) } else { ifn_1399 = nil }; var arg_1400 any; var root_1401 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_1402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1401, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1403 lang.IFn; if linked_1402 == nil { ifn_1403 = lang.IFn_Cast(root_1401) } else { ifn_1403 = nil }; var arg_1404 any = minimal__6; if linked_1402 == nil { arg_1400 = ifn_1403.Invoke_O__O(arg_1404) } else { arg_1400 = linked_1402.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1401, arg_1404) }; if linked_1398 == nil { return ifn_1399.Invoke_O__O(arg_1400) } else { return linked_1398.(*aot_arbace_classes_types.A_arbace_classes_types_internal__GT_desc_A).Invoke_O_O__O(root_1397, arg_1400) } } else { return A_arbace_classes_env_A_const_105.GetRawRoot__O() } } else {
							var root_1405 any = A_arbace_classes_env_A_const_122.GetRawRoot__O(); var linked_1406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1405, aot_arbace_classes_types.A_arbace_classes_types_internal__GT_desc_A_fn_class); var ifn_1407 lang.IFn; if linked_1406 == nil { ifn_1407 = lang.IFn_Cast(root_1405) } else { ifn_1407 = nil }; var arg_1408 any = c__3; if linked_1406 == nil { return ifn_1407.Invoke_O__O(arg_1408) } else { return linked_1406.(*aot_arbace_classes_types.A_arbace_classes_types_internal__GT_desc_A).Invoke_O_O__O(root_1405, arg_1408) } } } else {
//line :288:1
								if A_arbace_classes_env_A_const_109 != nil { return A_arbace_classes_env_A_const_105.GetRawRoot__O() } else { return nil
								}
							}
			}
		}
	}
	}
	}
}
func A_arbace_classes_env_lub_sups__28000177_A_New() *A_arbace_classes_env_lub_sups__28000177_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_lub_sups__28000177_A{}; t.Ctor(); return t }
//line :297:1
func (t *A_arbace_classes_env_lub_sups__28000177_A) Ctor() {}
//line :297:1
func (t *A_arbace_classes_env_lub_sups__28000177_A) Invoke_O_O__O(self, n__1 any) any { var root_1328 any = A_arbace_classes_env_A_const_87.GetRawRoot__O(); var linked_1329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1328, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_1330 lang.IFn; if linked_1329 == nil { ifn_1330 = lang.IFn_Cast(root_1328) } else { ifn_1330 = nil }; var arg_1331 any; var root_1332 any = A_arbace_classes_env_A_const_118.GetRawRoot__O(); var linked_1333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1332, aot_arbace_core.A_arbace_core_tree_seq_A_fn_class); var ifn_1334 lang.IFn; if linked_1333 == nil { ifn_1334 = lang.IFn_Cast(root_1332) } else { ifn_1334 = nil }; var arg_1335 any = A_arbace_classes_env_A_const_25.GetRawRoot__O(); var arg_1336 any; var fnbody__1352 any = A_arbace_classes_env_lub_sups__28000177_fn__28000178_A_New(); var tmp1 *jrt.Class; var fncls__1351 *jrt.Class = A_arbace_classes_env_lub_sups__28000177_fn__28000178_A_fn_class; if fncls__1351 == nil { var fncls__1351d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_26, false, nil); A_arbace_classes_env_lub_sups__28000177_fn__28000178_A_fn_class = fncls__1351d; tmp1 = fncls__1351d } else { tmp1 = fncls__1351 }; arg_1336 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1352, tmp1, nil); var arg_1337 any = n__1; if linked_1333 == nil { arg_1331 = ifn_1334.Invoke_O_O_O__O(arg_1335, arg_1336, arg_1337) } else { arg_1331 = linked_1333.(*aot_arbace_core.A_arbace_core_tree_seq_A).Invoke_O_O_O_O__O(root_1332, arg_1335, arg_1336, arg_1337) }; if linked_1329 == nil { return ifn_1330.Invoke_O__O(arg_1331) } else { return linked_1329.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1328, arg_1331) } }
//line :297:1
func A_arbace_classes_env_lub_sups__28000177_fn__28000178_A_New() *A_arbace_classes_env_lub_sups__28000177_fn__28000178_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_lub_sups__28000177_fn__28000178_A{}; t.Ctor(); return t }
//line :297:1
func (t *A_arbace_classes_env_lub_sups__28000177_fn__28000178_A) Ctor() {}
//line :297:1
func (t *A_arbace_classes_env_lub_sups__28000177_fn__28000178_A) Invoke_O_O__O(self, x__1 any) any { var temp__1927000414__auto____2 any; var root_1338 any = A_arbace_classes_env_A_const_98.GetRawRoot__O(); var linked_1339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1338, A_arbace_classes_env_info_A_fn_class); var ifn_1340 lang.IFn; if linked_1339 == nil { ifn_1340 = lang.IFn_Cast(root_1338) } else { ifn_1340 = nil }; var arg_1341 any = x__1; if linked_1339 == nil { temp__1927000414__auto____2 = ifn_1340.Invoke_O__O(arg_1341) } else { temp__1927000414__auto____2 = linked_1339.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1338, arg_1341) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var i__3 any = temp__1927000414__auto____2; var G__28000179__4_ any; var root_1342 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_1343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1342, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1344 lang.IFn
													if linked_1343 == nil { ifn_1344 = lang.IFn_Cast(root_1342) } else { ifn_1344 = nil }; var arg_1345 any = A_arbace_classes_env_A_const_46.Invoke_O__O(i__3); if linked_1343 == nil { G__28000179__4_ = ifn_1344.Invoke_O__O(arg_1345) } else { G__28000179__4_ = linked_1343.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1342, arg_1345) }; if jrt.J2g_Truth(A_arbace_classes_env_A_const_45.Invoke_O__O(i__3)) { var root_1346 any = A_arbace_classes_env_A_const_10.GetRawRoot__O(); var linked_1347 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1346, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1348 lang.IFn; if linked_1347 == nil { ifn_1348 = lang.IFn_Cast(root_1346) } else { ifn_1348 = nil }; var arg_1349 any = G__28000179__4_; var arg_1350 any = A_arbace_classes_env_A_const_45.Invoke_O__O(i__3); if linked_1347 == nil { return ifn_1348.Invoke_O_O__O(arg_1349, arg_1350) } else { return linked_1347.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1346, arg_1349, arg_1350) } } else { return G__28000179__4_ } } else {
//line :297:1
		return nil } }




func A_arbace_classes_env_lub_fn__28000182_A_New_O(p0 any) *A_arbace_classes_env_lub_fn__28000182_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_lub_fn__28000182_A{}; t.Ctor_O(p0); return t }
//line :302:1
func (t *A_arbace_classes_env_lub_fn__28000182_A) Ctor_O(c__common any) { t.F_common = c__common }
//line :302:1
func (t *A_arbace_classes_env_lub_fn__28000182_A) Invoke_O_O__O(self, i__1 any) any { var root_1378 any = A_arbace_classes_env_A_const_101.GetRawRoot__O(); var linked_1379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1378, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1380 lang.IFn; if linked_1379 == nil { ifn_1380 = lang.IFn_Cast(root_1378) } else { ifn_1380 = nil }; var arg_1381 any; var fnbody__1394 any = A_arbace_classes_env_lub_fn__28000182_fn__28000183_A_New_O(i__1); var tmp1 *jrt.Class; var fncls__1393 *jrt.Class = A_arbace_classes_env_lub_fn__28000182_fn__28000183_A_fn_class; if fncls__1393 == nil { var fncls__1393d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_25, false, fnbody__1394); A_arbace_classes_env_lub_fn__28000182_fn__28000183_A_fn_class = fncls__1393d; tmp1 = fncls__1393d } else { tmp1 = fncls__1393 }; arg_1381 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1394, tmp1, nil); var arg_1382 any = t.F_common; if linked_1379 == nil { return ifn_1380.Invoke_O_O__O(arg_1381, arg_1382) } else { return linked_1379.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1378, arg_1381, arg_1382) } }
//line :302:1
func A_arbace_classes_env_lub_fn__28000182_fn__28000183_A_New_O(p0 any) *A_arbace_classes_env_lub_fn__28000182_fn__28000183_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_lub_fn__28000182_fn__28000183_A{}; t.Ctor_O(p0); return t }
//line :302:1
func (t *A_arbace_classes_env_lub_fn__28000182_fn__28000183_A) Ctor_O(c__i any) { t.F_i = c__i }
//line :302:1
func (t *A_arbace_classes_env_lub_fn__28000182_fn__28000183_A) Invoke_O_O__O(self, p1__28000176_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_1383 any = A_arbace_classes_env_A_const_121.GetRawRoot__O(); var linked_1384 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1383, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1385 lang.IFn; if linked_1384 == nil { ifn_1385 = lang.IFn_Cast(root_1383) } else { ifn_1385 = nil }; var arg_1386 any = p1__28000176_SHARP___1; var arg_1387 any = t.F_i; if linked_1384 == nil { and__1927000168__auto____2 = ifn_1385.Invoke_O_O__O(arg_1386, arg_1387) } else { and__1927000168__auto____2 = linked_1384.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1383, arg_1386, arg_1387) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_1388 any = A_arbace_classes_env_A_const_102.GetRawRoot__O(); var linked_1389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1388, A_arbace_classes_env_subclass_QMARK__A_fn_class); var ifn_1390 lang.IFn; if linked_1389 == nil { ifn_1390 = lang.IFn_Cast(root_1388) } else { ifn_1390 = nil }; var arg_1391 any = p1__28000176_SHARP___1; var arg_1392 any = t.F_i; if linked_1389 == nil { return ifn_1390.Invoke_O_O__O(arg_1391, arg_1392) } else { return linked_1389.(*A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(root_1388, arg_1391, arg_1392) } } else { return and__1927000168__auto____2 } }






func A_arbace_classes_env_nest_host_A_New() *A_arbace_classes_env_nest_host_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_nest_host_A{}; t.Ctor(); return t }
//line :309:1
func (t *A_arbace_classes_env_nest_host_A) Ctor() {}
//line :309:1
func (t *A_arbace_classes_env_nest_host_A) Invoke_O_O__O(self, n__0 any) any { var i__2 any; var root_1409 any = A_arbace_classes_env_A_const_98.GetRawRoot__O(); var linked_1410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1409, A_arbace_classes_env_info_A_fn_class); var ifn_1411 lang.IFn; if
										linked_1410 == nil { ifn_1411 = lang.IFn_Cast(root_1409) } else { ifn_1411 = nil }; var arg_1412 any = n__0; if linked_1410 == nil { i__2 = ifn_1411.Invoke_O__O(arg_1412) } else { i__2 = linked_1410.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1409, arg_1412) }; var or__1927000174__auto____3 any = /*line :309:1*/A_arbace_classes_env_A_const_48.Invoke_O__O(i__2); if

	jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var temp__1927000408__auto____4 any = A_arbace_classes_env_A_const_49.Invoke_O__O(i__2)
		if jrt.J2g_Truth(temp__1927000408__auto____4) { var o__5 any = temp__1927000408__auto____4; var root_1413 any = A_arbace_classes_env_A_const_123.GetRawRoot__O(); var linked_1414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1413, A_arbace_classes_env_nest_host_A_fn_class); var ifn_1415 lang.IFn; if linked_1414 == nil { ifn_1415 = lang.IFn_Cast(root_1413) } else { ifn_1415 = nil }; var arg_1416 any = o__5; if linked_1414 == nil { return ifn_1415.Invoke_O__O(arg_1416) } else { return linked_1414.(*A_arbace_classes_env_nest_host_A).Invoke_O_O__O(root_1413, arg_1416) } } else { return n__0 } } }

func A_arbace_classes_env_flag_QMARK__A_New() *A_arbace_classes_env_flag_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_flag_QMARK__A{}; t.Ctor(); return t }
//line :314:1
func (t *A_arbace_classes_env_flag_QMARK__A) Ctor() {}
//line :314:1
func (t *A_arbace_classes_env_flag_QMARK__A) Invoke_O_O_O__O(self, flags__0, f__1 any) any { var root_1417 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1417, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1419 lang.IFn; if linked_1418 == nil { ifn_1419 = lang.IFn_Cast(root_1417) } else { ifn_1419 = nil }; var arg_1420 any; var tmp1 int64; var na_1421 any = flags__0; var na_1422 any = f__1; var tmp2 bool; var tmp3 bool; tmp3 = jrt.Long_InstanceOf(na_1421); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_1422) }; tmp2 = tmp3; if tmp2 { var n0_1423 int64 = jrt.NN(jrt.Long_Cast(na_1421)).LongValue__J(); var n1_1424 int64 = jrt.NN(jrt.Long_Cast(na_1422)).LongValue__J(); tmp1 = n0_1423 & n1_1424 } else { tmp1 = lang.Numbers_And_O_O__J_NoInit(na_1421, na_1422) }; arg_1420 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(tmp1)).Ref(); if linked_1418 == nil { return ifn_1419.Invoke_O__O(arg_1420) } else { return linked_1418.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1417, arg_1420) } }

func A_arbace_classes_env_accessible_QMARK__A_New() *A_arbace_classes_env_accessible_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_accessible_QMARK__A{}; t.Ctor(); return t }
//line :316:1
func (t *A_arbace_classes_env_accessible_QMARK__A) Ctor() {}
//line :316:1
func (t *A_arbace_classes_env_accessible_QMARK__A) Invoke_O_O_O__O(self, from__0, m__1 any) any { var fl__3 any = A_arbace_classes_env_A_const_43.Invoke_O__O(m__1); var owner__4 any = A_arbace_classes_env_A_const_63.Invoke_O__O(m__1); var tmp1 any; var root_1426 any = A_arbace_classes_env_A_const_124.GetRawRoot__O(); var linked_1427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1426, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1428 lang.IFn; if




	linked_1427 == nil { ifn_1428 = lang.IFn_Cast(root_1426) } else { ifn_1428 = nil }; var arg_1429 any = fl__3; var arg_1430 any = A_arbace_classes_env_A_const_125; if linked_1427 == nil { tmp1 = ifn_1428.Invoke_O_O__O(arg_1429, arg_1430) } else { tmp1 = linked_1427.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1426, arg_1429, arg_1430) }; if /*line :320:1*/ jrt.J2g_Truth(tmp1) { return jrt.Boolean_TRUE.Ref() } else { var tmp2 any; var root_1431 any = A_arbace_classes_env_A_const_124.GetRawRoot__O(); var linked_1432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1431, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1433 lang.IFn

		if linked_1432 == nil { ifn_1433 = lang.IFn_Cast(root_1431) } else { ifn_1433 = nil }; var arg_1434 any = fl__3; var arg_1435 any = A_arbace_classes_env_A_const_126; if linked_1432 == nil { tmp2 = ifn_1433.Invoke_O_O__O(arg_1434, arg_1435) } else { tmp2 = linked_1432.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1431, arg_1434, arg_1435) }
//line :320:1
		if jrt.J2g_Truth(tmp2) {

			var tmp3 any; var root_1436 any = A_arbace_classes_env_A_const_123.GetRawRoot__O(); var linked_1437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1436, A_arbace_classes_env_nest_host_A_fn_class); var ifn_1438 lang.IFn; if linked_1437 == nil { ifn_1438 = lang.IFn_Cast(root_1436) } else { ifn_1438 = nil }; var arg_1439 any = from__0; if linked_1437 == nil { tmp3 = ifn_1438.Invoke_O__O(arg_1439) } else { tmp3 = linked_1437.(*A_arbace_classes_env_nest_host_A).Invoke_O_O__O(root_1436, arg_1439) }; var tmp4 any = tmp3; var tmp5 any; var root_1440 any = A_arbace_classes_env_A_const_123.GetRawRoot__O(); var linked_1441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1440, A_arbace_classes_env_nest_host_A_fn_class); var ifn_1442 lang.IFn; if linked_1441 == nil { ifn_1442 = lang.IFn_Cast(root_1440) } else { ifn_1442 = nil }; var arg_1443 any = owner__4; if linked_1441 == nil { tmp5 = ifn_1442.Invoke_O__O(arg_1443) } else { tmp5 = linked_1441.(*A_arbace_classes_env_nest_host_A).Invoke_O_O__O(root_1440, arg_1443) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5)).Ref() } else {
//line :320:1
				var tmp6 any; var root_1444 any = A_arbace_classes_env_A_const_127.GetRawRoot__O(); var linked_1445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1444, aot_arbace_classes_types.A_arbace_classes_types_package_of_A_fn_class); var ifn_1446 lang.IFn


				if linked_1445 == nil { ifn_1446 = lang.IFn_Cast(root_1444) } else { ifn_1446 = nil }; var arg_1447 any = from__0; if linked_1445 == nil { tmp6 = ifn_1446.Invoke_O__O(arg_1447) } else { tmp6 = linked_1445.(*aot_arbace_classes_types.A_arbace_classes_types_package_of_A).Invoke_O_O__O(root_1444, arg_1447) }
//line :320:1
				var tmp7 any = tmp6; var tmp8 any; var root_1448 any = A_arbace_classes_env_A_const_127.GetRawRoot__O(); var linked_1449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1448, aot_arbace_classes_types.A_arbace_classes_types_package_of_A_fn_class); var ifn_1450 lang.IFn


				if linked_1449 == nil { ifn_1450 = lang.IFn_Cast(root_1448) } else { ifn_1450 = nil }; var arg_1451 any = owner__4; if linked_1449 == nil { tmp8 = ifn_1450.Invoke_O__O(arg_1451) } else { tmp8 = linked_1449.(*aot_arbace_classes_types.A_arbace_classes_types_package_of_A).Invoke_O_O__O(root_1448, arg_1451) }
//line :320:1
				if lang.Util_Equiv_O_O__Z_NoInit(tmp7, tmp8) { return jrt.Boolean_TRUE.Ref() } else { var tmp9 any; var root_1452 any = A_arbace_classes_env_A_const_124.GetRawRoot__O(); var linked_1453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1452, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1454 lang.IFn



					if linked_1453 == nil { ifn_1454 = lang.IFn_Cast(root_1452) } else { ifn_1454 = nil }; var arg_1455 any = fl__3; var arg_1456 any = A_arbace_classes_env_A_const_128; if linked_1453 == nil { tmp9 = ifn_1454.Invoke_O_O__O(arg_1455, arg_1456) } else { tmp9 = linked_1453.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1452, arg_1455, arg_1456) }
//line :320:1
					if jrt.J2g_Truth(tmp9) {




						var tmp10 any; var root_1457 any = A_arbace_classes_env_A_const_101.GetRawRoot__O(); var linked_1458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1457, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1459 lang.IFn; if linked_1458 == nil { ifn_1459 = lang.IFn_Cast(root_1457) } else { ifn_1459 = nil }; var arg_1460 any; var fnbody__1468 any = A_arbace_classes_env_accessible_QMARK__fn__28000191_A_New_O(owner__4); var tmp11 *jrt.Class; var fncls__1467 *jrt.Class = A_arbace_classes_env_accessible_QMARK__fn__28000191_A_fn_class; if fncls__1467 == nil { var fncls__1467d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1, false, fnbody__1468); A_arbace_classes_env_accessible_QMARK__fn__28000191_A_fn_class = fncls__1467d; tmp11 = fncls__1467d } else { tmp11 = fncls__1467 }; arg_1460 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1468, tmp11, nil); var arg_1461 any; var root_1469 any = A_arbace_classes_env_A_const_112.GetRawRoot__O(); var linked_1470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1469, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_1471 lang.IFn
						if linked_1470 == nil { ifn_1471 = lang.IFn_Cast(root_1469) } else { ifn_1471 = nil }; var arg_1472 any = A_arbace_classes_env_A_const_25.GetRawRoot__O(); var arg_1473 any; var root_1474 any = A_arbace_classes_env_A_const_113.GetRawRoot__O(); var linked_1475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1474, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_1476 lang.IFn; if linked_1475 == nil { ifn_1476 = lang.IFn_Cast(root_1474) } else { ifn_1476 = nil }; var arg_1477 any; var fnbody__1484 any = A_arbace_classes_env_accessible_QMARK__fn__28000193_A_New(); var tmp12 *jrt.Class; var fncls__1483 *jrt.Class = A_arbace_classes_env_accessible_QMARK__fn__28000193_A_fn_class; if fncls__1483 == nil { var fncls__1483d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, nil); A_arbace_classes_env_accessible_QMARK__fn__28000193_A_fn_class = fncls__1483d; tmp12 = fncls__1483d } else { tmp12 = fncls__1483 }; arg_1477 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1484, tmp12, nil); var arg_1478 any = from__0; if linked_1475 == nil { arg_1473 = ifn_1476.Invoke_O_O__O(arg_1477, arg_1478) } else { arg_1473 = linked_1475.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_1474, arg_1477, arg_1478) }; if linked_1470 == nil { arg_1461 = ifn_1471.Invoke_O_O__O(arg_1472, arg_1473) } else { arg_1461 = linked_1470.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_1469, arg_1472, arg_1473) }
//line :325:1
						if linked_1458 == nil { tmp10 = ifn_1459.Invoke_O_O__O(arg_1460, arg_1461) } else { tmp10 = linked_1458.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1457, arg_1460, arg_1461) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp10)).Ref() } else {
//line :320:1
							if A_arbace_classes_env_A_const_109 != nil { return jrt.Boolean_FALSE.Ref() } else { return nil } } } } } }




func A_arbace_classes_env_accessible_QMARK__fn__28000191_A_New_O(p0 any) *A_arbace_classes_env_accessible_QMARK__fn__28000191_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_accessible_QMARK__fn__28000191_A{}; t.Ctor_O(p0); return t }
//line :325:1
func (t *A_arbace_classes_env_accessible_QMARK__fn__28000191_A) Ctor_O(c__owner any) { t.F_owner = c__owner }
//line :325:1
func (t *A_arbace_classes_env_accessible_QMARK__fn__28000191_A) Invoke_O_O__O(self, p1__28000189_SHARP___1 any) any { var root_1462 any = A_arbace_classes_env_A_const_102.GetRawRoot__O(); var linked_1463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1462, A_arbace_classes_env_subclass_QMARK__A_fn_class); var ifn_1464 lang.IFn; if linked_1463 == nil { ifn_1464 = lang.IFn_Cast(root_1462) } else { ifn_1464 = nil }; var arg_1465 any = p1__28000189_SHARP___1; var arg_1466 any = t.F_owner; if linked_1463 == nil { return ifn_1464.Invoke_O_O__O(arg_1465, arg_1466) } else { return linked_1463.(*A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(root_1462, arg_1465, arg_1466) } }
func A_arbace_classes_env_accessible_QMARK__fn__28000193_A_New() *A_arbace_classes_env_accessible_QMARK__fn__28000193_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_accessible_QMARK__fn__28000193_A{}; t.Ctor(); return t }
//line :326:1
func (t *A_arbace_classes_env_accessible_QMARK__fn__28000193_A) Ctor() {}
//line :326:1
func (t *A_arbace_classes_env_accessible_QMARK__fn__28000193_A) Invoke_O_O__O(self, p1__28000190_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_classes_env_A_const_49; var tmp2 any; var root_1479 any = A_arbace_classes_env_A_const_98.GetRawRoot__O(); var linked_1480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1479, A_arbace_classes_env_info_A_fn_class); var ifn_1481 lang.IFn; if linked_1480 == nil { ifn_1481 = lang.IFn_Cast(root_1479) } else { ifn_1481 = nil }; var arg_1482 any = p1__28000190_SHARP___1; if linked_1480 == nil { tmp2 = ifn_1481.Invoke_O__O(arg_1482) } else { tmp2 = linked_1480.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1479, arg_1482) }; return tmp1.Invoke_O__O(tmp2) }


func A_arbace_classes_env_find_field_A_New() *A_arbace_classes_env_find_field_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_find_field_A{}; t.Ctor(); return t }
//line :329:1
func (t *A_arbace_classes_env_find_field_A) Ctor() {}
//line :329:1
func (t *A_arbace_classes_env_find_field_A) Invoke_O_O_O__O(self, n__0, name__1 any) any { var temp__1927000414__auto____3 any; var root_1485 any = A_arbace_classes_env_A_const_98.GetRawRoot__O(); var linked_1486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1485, A_arbace_classes_env_info_A_fn_class); var ifn_1487 lang.IFn; if



	linked_1486 == nil { ifn_1487 = lang.IFn_Cast(root_1485) } else { ifn_1487 = nil }; var arg_1488 any = n__0; if linked_1486 == nil { temp__1927000414__auto____3 = ifn_1487.Invoke_O__O(arg_1488) } else { temp__1927000414__auto____3 = linked_1486.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1485, arg_1488) }; if jrt.J2g_Truth(temp__1927000414__auto____3) { var i__4 any = temp__1927000414__auto____3; var or__1927000174__auto____5 any; var root_1489 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_1490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1489, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1491 lang.IFn
		if linked_1490 == nil { ifn_1491 = lang.IFn_Cast(root_1489) } else { ifn_1491 = nil }; var arg_1492 any; var root_1493 any = A_arbace_classes_env_A_const_92.GetRawRoot__O(); var linked_1494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1493, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1495 lang.IFn; if linked_1494 == nil { ifn_1495 = lang.IFn_Cast(root_1493) } else { ifn_1495 = nil }; var arg_1496 any; var fnbody__1499 any = A_arbace_classes_env_find_field_fn__28000198_A_New_O(name__1); var tmp1 *jrt.Class; var fncls__1498 *jrt.Class = A_arbace_classes_env_find_field_fn__28000198_A_fn_class; if fncls__1498 == nil { var fncls__1498d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_18, false, fnbody__1499); A_arbace_classes_env_find_field_fn__28000198_A_fn_class = fncls__1498d; tmp1 = fncls__1498d } else { tmp1 = fncls__1498 }; arg_1496 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1499, tmp1, nil); var arg_1497 any = A_arbace_classes_env_A_const_50.Invoke_O__O(i__4); if linked_1494 == nil { arg_1492 = ifn_1495.Invoke_O_O__O(arg_1496, arg_1497) } else { arg_1492 = linked_1494.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1493, arg_1496, arg_1497) }; if linked_1490 == nil { or__1927000174__auto____5 = ifn_1491.Invoke_O__O(arg_1492) } else { or__1927000174__auto____5 = linked_1490.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1489, arg_1492) }; if jrt.J2g_Truth(or__1927000174__auto____5) { return or__1927000174__auto____5 } else { var or__1927000174__auto____6 any; var root_1500 any = A_arbace_classes_env_A_const_101.GetRawRoot__O(); var linked_1501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1500, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1502 lang.IFn
			if linked_1501 == nil { ifn_1502 = lang.IFn_Cast(root_1500) } else { ifn_1502 = nil }; var arg_1503 any; var fnbody__1511 any = A_arbace_classes_env_find_field_fn__28000200_A_New_O(name__1); var tmp2 *jrt.Class; var fncls__1510 *jrt.Class = A_arbace_classes_env_find_field_fn__28000200_A_fn_class; if fncls__1510 == nil { var fncls__1510d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, fnbody__1511); A_arbace_classes_env_find_field_fn__28000200_A_fn_class = fncls__1510d; tmp2 = fncls__1510d } else { tmp2 = fncls__1510 }; arg_1503 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1511, tmp2, nil); var arg_1504 any = A_arbace_classes_env_A_const_46.Invoke_O__O(i__4); if linked_1501 == nil { or__1927000174__auto____6 = ifn_1502.Invoke_O_O__O(arg_1503, arg_1504) } else { or__1927000174__auto____6 = linked_1501.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1500, arg_1503, arg_1504) }
//line :334:1
			if jrt.J2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else { var G__28000202__7_ any = A_arbace_classes_env_A_const_45.Invoke_O__O(i__4)

				if lang.Util_Identical_O_O__Z_NoInit(G__28000202__7_, nil) { return nil } else { var root_1512 any = A_arbace_classes_env_A_const_129.GetRawRoot__O(); var linked_1513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1512, A_arbace_classes_env_find_field_A_fn_class); var ifn_1514 lang.IFn; if linked_1513 == nil { ifn_1514 = lang.IFn_Cast(root_1512) } else { ifn_1514 = nil }; var arg_1515 any = G__28000202__7_; var arg_1516 any = name__1; if linked_1513 == nil { return ifn_1514.Invoke_O_O__O(arg_1515, arg_1516) } else { return linked_1513.(*A_arbace_classes_env_find_field_A).Invoke_O_O_O__O(root_1512, arg_1515, arg_1516) } } } } } else {
//line :333:1
					return nil } }
func A_arbace_classes_env_find_field_fn__28000198_A_New_O(p0 any) *A_arbace_classes_env_find_field_fn__28000198_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_find_field_fn__28000198_A{}; t.Ctor_O(p0); return t }
//line :334:1
func (t *A_arbace_classes_env_find_field_fn__28000198_A) Ctor_O(c__name any) { t.F_name = c__name }
//line :334:1
func (t *A_arbace_classes_env_find_field_fn__28000198_A) Invoke_O_O__O(self, p1__28000196_SHARP___1 any) any { var tmp1 any = t.F_name; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_classes_env_A_const_42.Invoke_O__O(p1__28000196_SHARP___1))).Ref() }
func A_arbace_classes_env_find_field_fn__28000200_A_New_O(p0 any) *A_arbace_classes_env_find_field_fn__28000200_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_find_field_fn__28000200_A{}; t.Ctor_O(p0); return t }
//line :335:1
func (t *A_arbace_classes_env_find_field_fn__28000200_A) Ctor_O(c__name any) { t.F_name = c__name }
//line :335:1
func (t *A_arbace_classes_env_find_field_fn__28000200_A) Invoke_O_O__O(self, p1__28000197_SHARP___1 any) any { var root_1505 any = A_arbace_classes_env_A_const_129.GetRawRoot__O(); var linked_1506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1505, A_arbace_classes_env_find_field_A_fn_class); var ifn_1507 lang.IFn; if linked_1506 == nil { ifn_1507 = lang.IFn_Cast(root_1505) } else { ifn_1507 = nil }; var arg_1508 any = p1__28000197_SHARP___1; var arg_1509 any = t.F_name; if linked_1506 == nil { return ifn_1507.Invoke_O_O__O(arg_1508, arg_1509) } else { return linked_1506.(*A_arbace_classes_env_find_field_A).Invoke_O_O_O__O(root_1505, arg_1508, arg_1509) } }


func A_arbace_classes_env_same_infos_QMARK__A_New() *A_arbace_classes_env_same_infos_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_same_infos_QMARK__A{}; t.Ctor(); return t }
//line :338:1
func (t *A_arbace_classes_env_same_infos_QMARK__A) Ctor() {}
//line :338:1
func (t *A_arbace_classes_env_same_infos_QMARK__A) Invoke_O_O_O__O(self, names__0, infos__1 any) any { { var n__3 int32 = lang.RT_Count_O__I_NoInit(names__0); var cs__4 any; var G__28000204__4_ any = A_arbace_classes_env_A_const_94.Get__O()



	if lang.Util_Identical_O_O__Z_NoInit(G__28000204__4_, nil) { cs__4 = nil } else { var root_1517 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_1518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1517, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1519 lang.IFn; if linked_1518 == nil { ifn_1519 = lang.IFn_Cast(root_1517) } else { ifn_1519 = nil }; var arg_1520 any = G__28000204__4_; if linked_1518 == nil { cs__4 = ifn_1519.Invoke_O__O(arg_1520) } else { cs__4 = linked_1518.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1517, arg_1520) } }
//line :338:1
	var i__5 int64 = 0; L1: for { var or__1927000174__auto____6 bool = lang.Util_Equiv_J_J__Z_NoInit(i__5, int64(n__3))





		if or__1927000174__auto____6 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____6).Ref() } else { var and__1927000168__auto____7 any; var c__7 any = lang.RT_Nth_O_I__O_NoInit(names__0, lang.RT_IntCast_J__I_NoInit(i__5)); var x__8 any = lang.RT_Aget_O1_I__O_NoInit(jrt.ObjectArray_Cast(infos__1), lang.RT_IntCast_J__I_NoInit(i__5)); var or__1927000174__auto____9 any; var and__1927000168__auto____9 any; var root_1521 any = A_arbace_classes_env_A_const_25.GetRawRoot__O(); var linked_1522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1521, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_1523 lang.IFn



			if linked_1522 == nil { ifn_1523 = lang.IFn_Cast(root_1521) } else { ifn_1523 = nil }; var arg_1524 any = x__8; if linked_1522 == nil { and__1927000168__auto____9 = ifn_1523.Invoke_O__O(arg_1524) } else { and__1927000168__auto____9 = linked_1522.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_1521, arg_1524) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 any; var root_1525 any = A_arbace_classes_env_A_const_25.GetRawRoot__O(); var linked_1526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1525, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_1527 lang.IFn; if linked_1526 == nil { ifn_1527 = lang.IFn_Cast(root_1525) } else { ifn_1527 = nil }; var arg_1528 any = cs__4; if linked_1526 == nil { and__1927000168__auto____10 = ifn_1527.Invoke_O__O(arg_1528) } else { and__1927000168__auto____10 = linked_1526.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_1525, arg_1528) }; if jrt.J2g_Truth(and__1927000168__auto____10) { var and__1927000168__auto____11 bool = lang.Util_Identical_O_O__Z_NoInit(x__8, lang.RT_Get_O_O__O_NoInit(cs__4, c__7)); if and__1927000168__auto____11 { var root_1529 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1529, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1531 lang.IFn; if linked_1530 == nil { ifn_1531 = lang.IFn_Cast(root_1529) } else { ifn_1531 = nil }; var arg_1532 any; var root_1533 any = A_arbace_classes_env_A_const_20.GetRawRoot__O(); var linked_1534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1533, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1535 lang.IFn; if linked_1534 == nil { ifn_1535 = lang.IFn_Cast(root_1533) } else { ifn_1535 = nil }; var arg_1536 any = c__7; var arg_1537 any = Lit_11; if linked_1534 == nil { arg_1532 = ifn_1535.Invoke_O_O__O(arg_1536, arg_1537) } else { arg_1532 = linked_1534.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1533, arg_1536, arg_1537) }; if linked_1530 == nil { or__1927000174__auto____9 = ifn_1531.Invoke_O__O(arg_1532) } else { or__1927000174__auto____9 = linked_1530.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1529, arg_1532) } } else { or__1927000174__auto____9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11).Ref() } } else { or__1927000174__auto____9 = and__1927000168__auto____10 } } else { or__1927000174__auto____9 = and__1927000168__auto____9 }; if jrt.J2g_Truth(or__1927000174__auto____9) { and__1927000168__auto____7 = or__1927000174__auto____9 } else {
				var tmp1 any; var root_1538 any = A_arbace_classes_env_A_const_98.GetRawRoot__O(); var linked_1539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1538, A_arbace_classes_env_info_A_fn_class); var ifn_1540 lang.IFn; if linked_1539 == nil { ifn_1540 = lang.IFn_Cast(root_1538) } else { ifn_1540 = nil }; var arg_1541 any = c__7; if linked_1539 == nil { tmp1 = ifn_1540.Invoke_O__O(arg_1541) } else { tmp1 = linked_1539.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1538, arg_1541) }; and__1927000168__auto____7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp1, x__8)).Ref() }
//line :345:1
			if jrt.J2g_Truth(and__1927000168__auto____7) {




				i__5 = lang.Numbers_Inc_J__J_NoInit(i__5); continue L1 } else {
//line :345:1
					return and__1927000168__auto____7 } } } }; /*line :338:1*/panic("j2g: unreachable") }













func A_arbace_classes_env_infos_now_A_New() *A_arbace_classes_env_infos_now_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_infos_now_A{}; t.Ctor(); return t }
//line :352:1
func (t *A_arbace_classes_env_infos_now_A) Ctor() {}
//line :352:1
func (t *A_arbace_classes_env_infos_now_A) Invoke_O_O__O(self, names__0 any) any { var a__2 any = lang.RT_Object_array_O__O1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(names__0)).Ref()).Ref(); var n__1927000701__auto____3 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_Count_O__I_NoInit(names__0)); var i__4 int64 = 0; L1: for {

	if lang.Numbers_Lt_J_J__Z_NoInit(i__4, n__1927000701__auto____3) { var tmp1 *jrt.RefArray = jrt.ObjectArray_Cast(a__2); var tmp2 int32 = lang.RT_IntCast_J__I_NoInit(i__4); var tmp3 any; var root_1542 any = A_arbace_classes_env_A_const_98.GetRawRoot__O(); var linked_1543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1542, A_arbace_classes_env_info_A_fn_class); var ifn_1544 lang.IFn; if linked_1543 == nil { ifn_1544 = lang.IFn_Cast(root_1542) } else { ifn_1544 = nil }; var arg_1545 any = lang.RT_Nth_O_I__O_NoInit(names__0, lang.RT_IntCast_J__I_NoInit(i__4)); if linked_1543 == nil { tmp3 = ifn_1544.Invoke_O__O(arg_1545) } else { tmp3 = linked_1543.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1542, arg_1545) }; lang.RT_Aset_O1_I_O__O_NoInit(tmp1, tmp2, tmp3); i__4 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__4); continue L1 }
//line :352:1
	break L1 }; return a__2 }
















func A_arbace_classes_env_all_supertypes_STAR__A_New() *A_arbace_classes_env_all_supertypes_STAR__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_all_supertypes_STAR__A{}; t.Ctor(); return t }
//line :369:1
func (t *A_arbace_classes_env_all_supertypes_STAR__A) Ctor() {}
//line :369:1
func (t *A_arbace_classes_env_all_supertypes_STAR__A) Invoke_O_O__O(self, n__0 any) any { { var chain__2 any; var root_1546 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_1547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1546, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1548 lang.IFn

	if linked_1547 == nil { ifn_1548 = lang.IFn_Cast(root_1546) } else { ifn_1548 = nil }; var arg_1549 any; var root_1550 any = A_arbace_classes_env_A_const_115.GetRawRoot__O(); var linked_1551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1550, A_arbace_classes_env_superclass_chain_A_fn_class); var ifn_1552 lang.IFn; if linked_1551 == nil { ifn_1552 = lang.IFn_Cast(root_1550) } else { ifn_1552 = nil }; var arg_1553 any = n__0; if linked_1551 == nil { arg_1549 = ifn_1552.Invoke_O__O(arg_1553) } else { arg_1549 = linked_1551.(*A_arbace_classes_env_superclass_chain_A).Invoke_O_O__O(root_1550, arg_1553) }; if linked_1547 == nil { chain__2 = ifn_1548.Invoke_O__O(arg_1549) } else { chain__2 = linked_1547.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1546, arg_1549) }
//line :369:1
	var out__3 any = chain__2; var seen__4 any; var root_1554 any = A_arbace_classes_env_A_const_87.GetRawRoot__O(); var linked_1555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1554, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_1556 lang.IFn


	if linked_1555 == nil { ifn_1556 = lang.IFn_Cast(root_1554) } else { ifn_1556 = nil }; var arg_1557 any = chain__2; if linked_1555 == nil { seen__4 = ifn_1556.Invoke_O__O(arg_1557) } else { seen__4 = linked_1555.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1554, arg_1557) }
//line :369:1
	var queue__5 any; var root_1558 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_1559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1558, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1560 lang.IFn


	if linked_1559 == nil { ifn_1560 = lang.IFn_Cast(root_1558) } else { ifn_1560 = nil }; var arg_1561 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_130.GetRawRoot__O()); var tmp2 *lang.Compiler_AOTFn; var fnbody__1572 any = A_arbace_classes_env_all_supertypes_STAR__fn__28000208_A_New(); var tmp3 *jrt.Class; var fncls__1571 *jrt.Class = A_arbace_classes_env_all_supertypes_STAR__fn__28000208_A_fn_class; if fncls__1571 == nil { var fncls__1571d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, nil); A_arbace_classes_env_all_supertypes_STAR__fn__28000208_A_fn_class = fncls__1571d; tmp3 = fncls__1571d } else { tmp3 = fncls__1571 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1572, tmp3, nil); arg_1561 = tmp1.Invoke_O_O__O(tmp2.Ref(), chain__2); if linked_1559 == nil { queue__5 = ifn_1560.Invoke_O__O(arg_1561) } else { queue__5 = linked_1559.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1558, arg_1561) }
//line :369:1
L1: for { var temp__1927000408__auto____6 any; var root_1573 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_1574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1573, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1575 lang.IFn



	if linked_1574 == nil { ifn_1575 = lang.IFn_Cast(root_1573) } else { ifn_1575 = nil }; var arg_1576 any = queue__5; if linked_1574 == nil { temp__1927000408__auto____6 = ifn_1575.Invoke_O__O(arg_1576) } else { temp__1927000408__auto____6 = linked_1574.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1573, arg_1576) }; if jrt.J2g_Truth(temp__1927000408__auto____6) { var vec__28000210__7 any = temp__1927000408__auto____6; var seq__28000211__8 any; var root_1577 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_1578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1577, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1579 lang.IFn; if linked_1578 == nil { ifn_1579 = lang.IFn_Cast(root_1577) } else { ifn_1579 = nil }; var arg_1580 any = vec__28000210__7; if linked_1578 == nil { seq__28000211__8 = ifn_1579.Invoke_O__O(arg_1580) } else { seq__28000211__8 = linked_1578.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1577, arg_1580) }; var first__28000212__9 any; var root_1581 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_1582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1581, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1583 lang.IFn; if linked_1582 == nil { ifn_1583 = lang.IFn_Cast(root_1581) } else { ifn_1583 = nil }; var arg_1584 any = seq__28000211__8; if linked_1582 == nil { first__28000212__9 = ifn_1583.Invoke_O__O(arg_1584) } else { first__28000212__9 = linked_1582.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1581, arg_1584) }; var seq__28000211__10 any; var root_1585 any = A_arbace_classes_env_A_const_57.GetRawRoot__O(); var linked_1586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1585, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1587 lang.IFn; if linked_1586 == nil { ifn_1587 = lang.IFn_Cast(root_1585) } else { ifn_1587 = nil }; var arg_1588 any = seq__28000211__8; if linked_1586 == nil { seq__28000211__10 = ifn_1587.Invoke_O__O(arg_1588) } else { seq__28000211__10 = linked_1586.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1585, arg_1588) }; var q__11 any = first__28000212__9; var more__12 any = seq__28000211__10
		if jrt.J2g_Truth(lang.IFn_Cast(seen__4).Invoke_O__O(q__11)) {
			var tmp4 any; var root_1602 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_1603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1602, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1604 lang.IFn; if linked_1603 == nil { ifn_1604 = lang.IFn_Cast(root_1602) } else { ifn_1604 = nil }; var arg_1605 any = more__12; if linked_1603 == nil { tmp4 = ifn_1604.Invoke_O__O(arg_1605) } else { tmp4 = linked_1603.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1602, arg_1605) }; out__3, seen__4, queue__5 = out__3, seen__4, tmp4; continue L1 } else {
				var tmp5 any; var root_1606 any = A_arbace_classes_env_A_const_10.GetRawRoot__O(); var linked_1607 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1606, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1608 lang.IFn; if linked_1607 == nil { ifn_1608 = lang.IFn_Cast(root_1606) } else { ifn_1608 = nil }; var arg_1609 any = out__3; var arg_1610 any = q__11; if linked_1607 == nil { tmp5 = ifn_1608.Invoke_O_O__O(arg_1609, arg_1610) } else { tmp5 = linked_1607.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1606, arg_1609, arg_1610) }; var tmp6 any = tmp5; var tmp7 any; var root_1611 any = A_arbace_classes_env_A_const_10.GetRawRoot__O(); var linked_1612 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1611, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1613 lang.IFn; if linked_1612 == nil { ifn_1613 = lang.IFn_Cast(root_1611) } else { ifn_1613 = nil }; var arg_1614 any = seen__4; var arg_1615 any = q__11; if linked_1612 == nil { tmp7 = ifn_1613.Invoke_O_O__O(arg_1614, arg_1615) } else { tmp7 = linked_1612.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1611, arg_1614, arg_1615) }; var tmp8 any = tmp7; var tmp9 any; var root_1616 any = A_arbace_classes_env_A_const_89.GetRawRoot__O(); var linked_1617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1616, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1618 lang.IFn; if linked_1617 == nil { ifn_1618 = lang.IFn_Cast(root_1616) } else { ifn_1618 = nil }; var arg_1619 any; var root_1621 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_1622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1621, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1623 lang.IFn; if linked_1622 == nil { ifn_1623 = lang.IFn_Cast(root_1621) } else { ifn_1623 = nil }; var arg_1624 any = more__12; if linked_1622 == nil { arg_1619 = ifn_1623.Invoke_O__O(arg_1624) } else { arg_1619 = linked_1622.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1621, arg_1624) }; var arg_1620 any; var tmp10 *lang.Keyword = A_arbace_classes_env_A_const_46; var tmp11 any; var root_1625 any = A_arbace_classes_env_A_const_98.GetRawRoot__O(); var linked_1626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1625, A_arbace_classes_env_info_A_fn_class); var ifn_1627 lang.IFn; if linked_1626 == nil { ifn_1627 = lang.IFn_Cast(root_1625) } else { ifn_1627 = nil }; var arg_1628 any = q__11; if linked_1626 == nil { tmp11 = ifn_1627.Invoke_O__O(arg_1628) } else { tmp11 = linked_1626.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1625, arg_1628) }; arg_1620 = tmp10.Invoke_O__O(tmp11); if linked_1617 == nil { tmp9 = ifn_1618.Invoke_O_O__O(arg_1619, arg_1620) } else { tmp9 = linked_1617.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1616, arg_1619, arg_1620) }; out__3, seen__4, queue__5 = tmp6, tmp8, tmp9; continue L1 } } else {
//line :373:1
					var G__28000213__7_ any = out__3; var tmp12 any; var and__1927000168__auto____8 any; var root_1589 any = A_arbace_classes_env_A_const_114.GetRawRoot__O(); var linked_1590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1589, A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_1591 lang.IFn



					if linked_1590 == nil { ifn_1591 = lang.IFn_Cast(root_1589) } else { ifn_1591 = nil }; var arg_1592 any = n__0; if linked_1590 == nil { and__1927000168__auto____8 = ifn_1591.Invoke_O__O(arg_1592) } else { and__1927000168__auto____8 = linked_1590.(*A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_1589, arg_1592) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_1593 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1593, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1595 lang.IFn; if linked_1594 == nil { ifn_1595 = lang.IFn_Cast(root_1593) } else { ifn_1595 = nil }; var arg_1596 any = lang.IFn_Cast(seen__4).Invoke_O__O(Lit_4); if linked_1594 == nil { tmp12 = ifn_1595.Invoke_O__O(arg_1596) } else { tmp12 = linked_1594.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1593, arg_1596) } } else { tmp12 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp12) { var root_1597 any = A_arbace_classes_env_A_const_10.GetRawRoot__O(); var linked_1598 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1597, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1599 lang.IFn; if linked_1598 == nil { ifn_1599 = lang.IFn_Cast(root_1597) } else { ifn_1599 = nil }; var arg_1600 any = G__28000213__7_; var arg_1601 any = Lit_4; if linked_1598 == nil { return ifn_1599.Invoke_O_O__O(arg_1600, arg_1601) } else { return linked_1598.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1597, arg_1600, arg_1601) } } else { return G__28000213__7_ } } } }; /*line :369:1*/panic("j2g: unreachable") }


func A_arbace_classes_env_all_supertypes_STAR__fn__28000208_A_New() *A_arbace_classes_env_all_supertypes_STAR__fn__28000208_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_all_supertypes_STAR__fn__28000208_A{}; t.Ctor(); return t }
//line :372:1
func (t *A_arbace_classes_env_all_supertypes_STAR__fn__28000208_A) Ctor() {}
//line :372:1
func (t *A_arbace_classes_env_all_supertypes_STAR__fn__28000208_A) Invoke_O_O__O(self, p1__28000207_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_classes_env_A_const_46; var tmp2 any; var root_1567 any = A_arbace_classes_env_A_const_98.GetRawRoot__O(); var linked_1568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1567, A_arbace_classes_env_info_A_fn_class); var ifn_1569 lang.IFn; if linked_1568 == nil { ifn_1569 = lang.IFn_Cast(root_1567) } else { ifn_1569 = nil }; var arg_1570 any = p1__28000207_SHARP___1; if linked_1568 == nil { tmp2 = ifn_1569.Invoke_O__O(arg_1570) } else { tmp2 = linked_1568.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1567, arg_1570) }; return tmp1.Invoke_O__O(tmp2) }






func A_arbace_classes_env_all_supertypes_A_New() *A_arbace_classes_env_all_supertypes_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_all_supertypes_A{}; t.Ctor(); return t }
//line :379:1
func (t *A_arbace_classes_env_all_supertypes_A) Ctor() {}
//line :379:1
func (t *A_arbace_classes_env_all_supertypes_A) Invoke_O_O__O(self, n__0 any) any { var e__2 any; if


	jrt.J2g_Truth(n__0) { e__2 = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_131.GetRawRoot__O())).Get_O__O(n__0) } else { e__2 = nil }; var tmp1 any; var and__1927000168__auto____3 any = e__2; if
	jrt.J2g_Truth(and__1927000168__auto____3) { var root_1629 any = A_arbace_classes_env_A_const_132.GetRawRoot__O(); var linked_1630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1629, A_arbace_classes_env_same_infos_QMARK__A_fn_class); var ifn_1631 lang.IFn; if linked_1630 == nil { ifn_1631 = lang.IFn_Cast(root_1629) } else { ifn_1631 = nil }; var arg_1632 any = lang.RT_Aget_O1_I__O_NoInit(jrt.ObjectArray_Cast(e__2), lang.RT_IntCast_J__I_NoInit(0)); var arg_1633 any = lang.RT_Aget_O1_I__O_NoInit(jrt.ObjectArray_Cast(e__2), lang.RT_IntCast_J__I_NoInit(1)); if linked_1630 == nil { tmp1 = ifn_1631.Invoke_O_O__O(arg_1632, arg_1633) } else { tmp1 = linked_1630.(*A_arbace_classes_env_same_infos_QMARK__A).Invoke_O_O_O__O(root_1629, arg_1632, arg_1633) } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		return lang.RT_Aget_O1_I__O_NoInit(jrt.ObjectArray_Cast(e__2), lang.RT_IntCast_J__I_NoInit(0)) } else {
//line :383:1
			var r__3 any; var root_1634 any = A_arbace_classes_env_A_const_133.GetRawRoot__O(); var linked_1635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1634, A_arbace_classes_env_all_supertypes_STAR__A_fn_class); var ifn_1636 lang.IFn

			if linked_1635 == nil { ifn_1636 = lang.IFn_Cast(root_1634) } else { ifn_1636 = nil }; var arg_1637 any = n__0; if linked_1635 == nil { r__3 = ifn_1636.Invoke_O__O(arg_1637) } else { r__3 = linked_1635.(*A_arbace_classes_env_all_supertypes_STAR__A).Invoke_O_O__O(root_1634, arg_1637) }
//line :383:1
			var infos__4 any; var root_1638 any = A_arbace_classes_env_A_const_134.GetRawRoot__O(); var linked_1639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1638, A_arbace_classes_env_infos_now_A_fn_class); var ifn_1640 lang.IFn


			if linked_1639 == nil { ifn_1640 = lang.IFn_Cast(root_1638) } else { ifn_1640 = nil }; var arg_1641 any = r__3; if linked_1639 == nil { infos__4 = ifn_1640.Invoke_O__O(arg_1641) } else { infos__4 = linked_1639.(*A_arbace_classes_env_infos_now_A).Invoke_O_O__O(root_1638, arg_1641)
			}
			var tmp2 any; var and__1927000168__auto____5 any = n__0; if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp3 any; var root_1642 any = A_arbace_classes_env_A_const_133.GetRawRoot__O(); var linked_1643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1642, A_arbace_classes_env_all_supertypes_STAR__A_fn_class); var ifn_1644 lang.IFn; if linked_1643 == nil { ifn_1644 = lang.IFn_Cast(root_1642) } else { ifn_1644 = nil }; var arg_1645 any = n__0; if linked_1643 == nil { tmp3 = ifn_1644.Invoke_O__O(arg_1645) } else { tmp3 = linked_1643.(*A_arbace_classes_env_all_supertypes_STAR__A).Invoke_O_O__O(root_1642, arg_1645) }; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(r__3, tmp3)).Ref() } else { tmp2 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp2) {
				jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_131.GetRawRoot__O())).Put_O_O__O(n__0, lang.RT_Object_array_O__O1_NoInit(lang.Tuple_Create_O_O__IPersistentVector(r__3, infos__4)).Ref()) }
//line :383:1
			return r__3 } }








func A_arbace_classes_env_params_key_A_New() *A_arbace_classes_env_params_key_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_params_key_A{}; t.Ctor(); return t }
//line :392:1
func (t *A_arbace_classes_env_params_key_A) Ctor() {}
//line :392:1
func (t *A_arbace_classes_env_params_key_A) Invoke_O_O__O(self, desc__0 any) any { var root_1646 any = A_arbace_classes_env_A_const_135.GetRawRoot__O(); var linked_1647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1646, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1648 lang.IFn; if linked_1647 == nil { ifn_1648 = lang.IFn_Cast(root_1646) } else { ifn_1648 = nil }; var arg_1649 any = desc__0; var arg_1650 any = A_arbace_classes_env_A_const_136; var arg_1651 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(jrt.NN(jrt.String_Cast(desc__0)).IndexOf_String__I(Lit_30)))).Ref(); if linked_1647 == nil { return ifn_1648.Invoke_O_O_O__O(arg_1649, arg_1650, arg_1651) } else { return linked_1647.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1646, arg_1649, arg_1650, arg_1651) } }

func A_arbace_classes_env_member_methods_STAR__A_New() *A_arbace_classes_env_member_methods_STAR__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_member_methods_STAR__A{}; t.Ctor(); return t }
//line :394:1
func (t *A_arbace_classes_env_member_methods_STAR__A) Ctor() {}
//line :394:1
func (t *A_arbace_classes_env_member_methods_STAR__A) Invoke_O_O_O_O__O(self, n__0, name__1, sups__2 any) any { { var G__28000220__4_ any = sups__2; var vec__28000221__5 any = G__28000220__4_; var seq__28000222__6 any; var root_1652 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_1653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1652, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1654 lang.IFn

	if linked_1653 == nil { ifn_1654 = lang.IFn_Cast(root_1652) } else { ifn_1654 = nil }; var arg_1655 any = vec__28000221__5; if linked_1653 == nil { seq__28000222__6 = ifn_1654.Invoke_O__O(arg_1655) } else { seq__28000222__6 = linked_1653.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1652, arg_1655) }
//line :394:1
	var first__28000223__7 any; var root_1656 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_1657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1656, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1658 lang.IFn

	if linked_1657 == nil { ifn_1658 = lang.IFn_Cast(root_1656) } else { ifn_1658 = nil }; var arg_1659 any = seq__28000222__6; if linked_1657 == nil { first__28000223__7 = ifn_1658.Invoke_O__O(arg_1659) } else { first__28000223__7 = linked_1657.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1656, arg_1659) }
//line :394:1
	var seq__28000222__8 any; var root_1660 any = A_arbace_classes_env_A_const_57.GetRawRoot__O(); var linked_1661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1660, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1662 lang.IFn

	if linked_1661 == nil { ifn_1662 = lang.IFn_Cast(root_1660) } else { ifn_1662 = nil }; var arg_1663 any = seq__28000222__6; if linked_1661 == nil { seq__28000222__8 = ifn_1662.Invoke_O__O(arg_1663) } else { seq__28000222__8 = linked_1661.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1660, arg_1663) }
//line :394:1
	var c__9 any = first__28000223__7; var more__10 any = seq__28000222__8; var seen__11 any = lang.PersistentHashSet_EMPTY.Ref(); var out__12 any = lang.PersistentVector_EMPTY.Ref(); var G__28000220__13_ any = G__28000220__4_; var seen__14 any = seen__11; var out__15 any = out__12; _ = c__9; _ = more__10; L1: for { var vec__28000224__16 any = G__28000220__13_; var seq__28000225__17 any; var root_1664 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_1665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1664, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1666 lang.IFn

		if linked_1665 == nil { ifn_1666 = lang.IFn_Cast(root_1664) } else { ifn_1666 = nil }; var arg_1667 any = vec__28000224__16; if linked_1665 == nil { seq__28000225__17 = ifn_1666.Invoke_O__O(arg_1667) } else { seq__28000225__17 = linked_1665.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1664, arg_1667) }
//line :394:1
		var first__28000226__18 any; var root_1668 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_1669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1668, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1670 lang.IFn

		if linked_1669 == nil { ifn_1670 = lang.IFn_Cast(root_1668) } else { ifn_1670 = nil }; var arg_1671 any = seq__28000225__17; if linked_1669 == nil { first__28000226__18 = ifn_1670.Invoke_O__O(arg_1671) } else { first__28000226__18 = linked_1669.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1668, arg_1671) }
//line :394:1
		var seq__28000225__19 any; var root_1672 any = A_arbace_classes_env_A_const_57.GetRawRoot__O(); var linked_1673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1672, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1674 lang.IFn

		if linked_1673 == nil { ifn_1674 = lang.IFn_Cast(root_1672) } else { ifn_1674 = nil }; var arg_1675 any = seq__28000225__17; if linked_1673 == nil { seq__28000225__19 = ifn_1674.Invoke_O__O(arg_1675) } else { seq__28000225__19 = linked_1673.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1672, arg_1675) }
//line :394:1
		var c__20 any = first__28000226__18; var more__21 any = seq__28000225__19; var seen__22 any = seen__14; var out__23 any = out__15; var tmp1 any; var root_1676 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1676, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1678 lang.IFn


		if linked_1677 == nil { ifn_1678 = lang.IFn_Cast(root_1676) } else { ifn_1678 = nil }; var arg_1679 any = c__20; if linked_1677 == nil { tmp1 = ifn_1678.Invoke_O__O(arg_1679) } else { tmp1 = linked_1677.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1676, arg_1679) }; if jrt.J2g_Truth(tmp1) { return out__23 } else { var ms__24 any; var iter__1927001039__auto____24 any; var fnbody__1847 any = A_arbace_classes_env_member_methods_STAR__iter__28000227__28000231_A_New_O_O_O_O(seen__22, name__1, n__0, c__20); var tmp2 *jrt.Class
			var fncls__1846 /*line :397:1*/*jrt.Class = A_arbace_classes_env_member_methods_STAR__iter__28000227__28000231_A_fn_class

			if fncls__1846 == nil { var fncls__1846d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, fnbody__1847); A_arbace_classes_env_member_methods_STAR__iter__28000227__28000231_A_fn_class = fncls__1846d; tmp2 = fncls__1846d } else { tmp2 = fncls__1846 }; iter__1927001039__auto____24 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1847, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____24); var tmp4 *lang.Keyword = A_arbace_classes_env_A_const_77; var tmp5 any; var root_1848 any = A_arbace_classes_env_A_const_100.GetRawRoot__O(); var linked_1849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1848, A_arbace_classes_env_info_BANG__A_fn_class); var ifn_1850 lang.IFn; if linked_1849 == nil { ifn_1850 = lang.IFn_Cast(root_1848) } else { ifn_1850 = nil }; var arg_1851 any = c__20; if linked_1849 == nil { tmp5 = ifn_1850.Invoke_O__O(arg_1851) } else { tmp5 = linked_1849.(*A_arbace_classes_env_info_BANG__A).Invoke_O_O__O(root_1848, arg_1851) }; ms__24 = tmp3.Invoke_O__O(tmp4.Invoke_O__O(tmp5))






			var tmp6 any; var root_1852 any = A_arbace_classes_env_A_const_89.GetRawRoot__O(); var linked_1853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1852, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1854 lang.IFn; if linked_1853 == nil { ifn_1854 = lang.IFn_Cast(root_1852) } else { ifn_1854 = nil }; var arg_1855 any = seen__22; var arg_1856 any; var root_1857 any = A_arbace_classes_env_A_const_80.GetRawRoot__O(); var linked_1858 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1857, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1859 lang.IFn; if linked_1858 == nil { ifn_1859 = lang.IFn_Cast(root_1857) } else { ifn_1859 = nil }; var arg_1860 any; var root_1862 any = A_arbace_classes_env_A_const_140.GetRawRoot__O(); var linked_1863 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1862, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_1864 lang.IFn; if linked_1863 == nil { ifn_1864 = lang.IFn_Cast(root_1862) } else { ifn_1864 = nil }; var arg_1865 any = A_arbace_classes_env_A_const_139.GetRawRoot__O(); var arg_1866 any = A_arbace_classes_env_A_const_60; if linked_1863 == nil { arg_1860 = ifn_1864.Invoke_O_O__O(arg_1865, arg_1866) } else { arg_1860 = linked_1863.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_1862, arg_1865, arg_1866) }; var arg_1861 any = ms__24; if linked_1858 == nil { arg_1856 = ifn_1859.Invoke_O_O__O(arg_1860, arg_1861) } else { arg_1856 = linked_1858.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1857, arg_1860, arg_1861) }; if linked_1853 == nil { tmp6 = ifn_1854.Invoke_O_O__O(arg_1855, arg_1856) } else { tmp6 = linked_1853.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1852, arg_1855, arg_1856) }; var tmp7 any = tmp6; var tmp8 any; var root_1867 any = A_arbace_classes_env_A_const_89.GetRawRoot__O(); var linked_1868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1867, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1869 lang.IFn; if linked_1868 == nil { ifn_1869 = lang.IFn_Cast(root_1867) } else { ifn_1869 = nil }; var arg_1870 any = out__23; var arg_1871 any = ms__24; if linked_1868 == nil { tmp8 = ifn_1869.Invoke_O_O__O(arg_1870, arg_1871) } else { tmp8 = linked_1868.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1867, arg_1870, arg_1871) }; G__28000220__13_, seen__14, out__15 = more__21, tmp7, tmp8; continue L1 } } }; /*line :394:1*/panic("j2g: unreachable") }




func A_arbace_classes_env_member_methods_STAR__iter__28000227__28000231_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_member_methods_STAR__iter__28000227__28000231_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_member_methods_STAR__iter__28000227__28000231_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :399:1
func (t *A_arbace_classes_env_member_methods_STAR__iter__28000227__28000231_A) Ctor_O_O_O_O(c__seen, c__name, c__n, c__c any) { t.F_seen = c__seen; t.F_name = c__name; t.F_n = c__n; t.F_c = c__c }
//line :399:1
func (t *A_arbace_classes_env_member_methods_STAR__iter__28000227__28000231_A) Invoke_O_O__O(self, s__28000228__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1845 any = A_arbace_classes_env_member_methods_STAR__iter__28000227__28000231_fn__28000232_A_New_O_O_O_O_O_O(s__28000228__1, self, t.F_seen, t.F_name, t.F_n, t.F_c); var tmp2 *jrt.Class; var fncls__1844 *jrt.Class = A_arbace_classes_env_member_methods_STAR__iter__28000227__28000231_fn__28000232_A_fn_class; if fncls__1844 == nil { var fncls__1844d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_28, false, fnbody__1845); A_arbace_classes_env_member_methods_STAR__iter__28000227__28000231_fn__28000232_A_fn_class = fncls__1844d; tmp2 = fncls__1844d } else { tmp2 = fncls__1844 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1845, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :399:1
func A_arbace_classes_env_member_methods_STAR__iter__28000227__28000231_fn__28000232_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_classes_env_member_methods_STAR__iter__28000227__28000231_fn__28000232_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_member_methods_STAR__iter__28000227__28000231_fn__28000232_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :399:1
func (t *A_arbace_classes_env_member_methods_STAR__iter__28000227__28000231_fn__28000232_A) Ctor_O_O_O_O_O_O(c__s__28000228, c__iter__28000227, c__seen, c__name, c__n, c__c any) { t.F_s__28000228 = c__s__28000228; t.F_iter__28000227 = c__iter__28000227; t.F_seen = c__seen; t.F_name = c__name; t.F_n = c__n; t.F_c = c__c }
//line :399:1
func (t *A_arbace_classes_env_member_methods_STAR__iter__28000227__28000231_fn__28000232_A) Invoke_O__O(self any) any { { var s__28000228__1 any; var t_ any = t.F_s__28000228; t.F_s__28000228 = nil; s__28000228__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1680 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_1681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1680, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1682 lang.IFn; if linked_1681 == nil { ifn_1682 = lang.IFn_Cast(root_1680) } else { ifn_1682 = nil }; var arg_1683 any = s__28000228__1; if linked_1681 == nil { temp__1927000414__auto____2 = ifn_1682.Invoke_O__O(arg_1683) } else { temp__1927000414__auto____2 = linked_1681.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1680, arg_1683) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__28000228__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1684 any = A_arbace_classes_env_A_const_54.GetRawRoot__O(); var linked_1685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1684, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1686 lang.IFn; if linked_1685 == nil { ifn_1686 = lang.IFn_Cast(root_1684) } else { ifn_1686 = nil }; var arg_1687 any = s__28000228__3; if linked_1685 == nil { tmp1 = ifn_1686.Invoke_O__O(arg_1687) } else { tmp1 = linked_1685.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1684, arg_1687) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1688 any = A_arbace_classes_env_A_const_55.GetRawRoot__O(); var linked_1689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1688, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1690 lang.IFn; if linked_1689 == nil { ifn_1690 = lang.IFn_Cast(root_1688) } else { ifn_1690 = nil }; var arg_1691 any = s__28000228__3; if linked_1689 == nil { c__1927001037__auto____4 = ifn_1690.Invoke_O__O(arg_1691) } else { c__1927001037__auto____4 = linked_1689.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1688, arg_1691) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__28000230__6 any; var root_1692 any = A_arbace_classes_env_A_const_56.GetRawRoot__O(); var linked_1693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1692, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1694 lang.IFn; if linked_1693 == nil { ifn_1694 = lang.IFn_Cast(root_1692) } else { ifn_1694 = nil }; var arg_1695 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1693 == nil { b__28000230__6 = ifn_1694.Invoke_O__O(arg_1695) } else { b__28000230__6 = linked_1693.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1692, arg_1695) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1745 any = A_arbace_classes_env_member_methods_STAR__iter__28000227__28000231_fn__28000232_fn__28000233_A_New_O_O_O_O_O_I_O(b__28000230__6, t.F_seen, t.F_name, t.F_n, t.F_c, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1744 *jrt.Class = A_arbace_classes_env_member_methods_STAR__iter__28000227__28000231_fn__28000232_fn__28000233_A_fn_class; if fncls__1744 == nil { var fncls__1744d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, fnbody__1745); A_arbace_classes_env_member_methods_STAR__iter__28000227__28000231_fn__28000232_fn__28000233_A_fn_class = fncls__1744d; tmp3 = fncls__1744d } else { tmp3 = fncls__1744 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1745, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1746 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_1747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1746, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1748 lang.IFn; if linked_1747 == nil { ifn_1748 = lang.IFn_Cast(root_1746) } else { ifn_1748 = nil }; var arg_1749 any; var root_1751 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_1752 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1751, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1753 lang.IFn; if linked_1752 == nil { ifn_1753 = lang.IFn_Cast(root_1751) } else { ifn_1753 = nil }; var arg_1754 any = b__28000230__6; if linked_1752 == nil { arg_1749 = ifn_1753.Invoke_O__O(arg_1754) } else { arg_1749 = linked_1752.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1751, arg_1754) }; var arg_1750 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__28000227); var tmp5 any; var root_1755 any = A_arbace_classes_env_A_const_70.GetRawRoot__O(); var linked_1756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1755, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1757 lang.IFn; if linked_1756 == nil { ifn_1757 = lang.IFn_Cast(root_1755) } else { ifn_1757 = nil }; var arg_1758 any = s__28000228__3; if linked_1756 == nil { tmp5 = ifn_1757.Invoke_O__O(arg_1758) } else { tmp5 = linked_1756.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1755, arg_1758) }; arg_1750 = tmp4.Invoke_O__O(tmp5); if linked_1747 == nil { return ifn_1748.Invoke_O_O__O(arg_1749, arg_1750) } else { return linked_1747.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1746, arg_1749, arg_1750) } } else { var root_1759 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_1760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1759, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1761 lang.IFn; if linked_1760 == nil { ifn_1761 = lang.IFn_Cast(root_1759) } else { ifn_1761 = nil }; var arg_1762 any; var root_1764 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_1765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1764, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1766 lang.IFn; if linked_1765 == nil { ifn_1766 = lang.IFn_Cast(root_1764) } else { ifn_1766 = nil }; var arg_1767 any = b__28000230__6; if linked_1765 == nil { arg_1762 = ifn_1766.Invoke_O__O(arg_1767) } else { arg_1762 = linked_1765.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1764, arg_1767) }; var arg_1763 any; if linked_1760 == nil { return ifn_1761.Invoke_O_O__O(arg_1762, arg_1763) } else { return linked_1760.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1759, arg_1762, arg_1763) } } } else { var m__4 any; var root_1768 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_1769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1768, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1770 lang.IFn; if linked_1769 == nil { ifn_1770 = lang.IFn_Cast(root_1768) } else { ifn_1770 = nil }; var arg_1771 any = s__28000228__3; if linked_1769 == nil { m__4 = ifn_1770.Invoke_O__O(arg_1771) } else { m__4 = linked_1769.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1768, arg_1771) }; var tmp6 any = t.F_name; if lang.Util_Equiv_O_O__Z_NoInit(tmp6, A_arbace_classes_env_A_const_42.Invoke_O__O(m__4)) { var tmp7 any; var root_1772 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1772, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1774 lang.IFn

	if linked_1773 == nil { ifn_1774 = lang.IFn_Cast(root_1772) } else { ifn_1774 = nil }; var arg_1775 any; var root_1776 any = A_arbace_classes_env_A_const_124.GetRawRoot__O(); var linked_1777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1776, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1778 lang.IFn; if linked_1777 == nil { ifn_1778 = lang.IFn_Cast(root_1776) } else { ifn_1778 = nil }; var arg_1779 any = A_arbace_classes_env_A_const_43.Invoke_O__O(m__4); var arg_1780 any = A_arbace_classes_env_A_const_137; if linked_1777 == nil { arg_1775 = ifn_1778.Invoke_O_O__O(arg_1779, arg_1780) } else { arg_1775 = linked_1777.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1776, arg_1779, arg_1780) }; if linked_1773 == nil { tmp7 = ifn_1774.Invoke_O__O(arg_1775) } else { tmp7 = linked_1773.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1772, arg_1775) }
//line :399:1
	if jrt.J2g_Truth(tmp7) { var tmp8 any; var or__1927000174__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(t.F_c, t.F_n)


		if or__1927000174__auto____5 { tmp8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var root_1781 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1781, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1783 lang.IFn; if linked_1782 == nil { ifn_1783 = lang.IFn_Cast(root_1781) } else { ifn_1783 = nil }; var arg_1784 any; var root_1785 any = A_arbace_classes_env_A_const_124.GetRawRoot__O(); var linked_1786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1785, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1787 lang.IFn; if linked_1786 == nil { ifn_1787 = lang.IFn_Cast(root_1785) } else { ifn_1787 = nil }; var arg_1788 any = A_arbace_classes_env_A_const_43.Invoke_O__O(m__4); var arg_1789 any = A_arbace_classes_env_A_const_126; if linked_1786 == nil { arg_1784 = ifn_1787.Invoke_O_O__O(arg_1788, arg_1789) } else { arg_1784 = linked_1786.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1785, arg_1788, arg_1789) }; if linked_1782 == nil { tmp8 = ifn_1783.Invoke_O__O(arg_1784) } else { tmp8 = linked_1782.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1781, arg_1784) } }
//line :399:1
		if jrt.J2g_Truth(tmp8) { var tmp9 any; var or__1927000174__auto____5_2 bool = lang.Util_Equiv_O_O__Z_NoInit(t.F_c, t.F_n)



			if or__1927000174__auto____5_2 { tmp9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5_2).Ref() } else { var or__1927000174__auto____6 any; var root_1790 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1790, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1792 lang.IFn; if linked_1791 == nil { ifn_1792 = lang.IFn_Cast(root_1790) } else { ifn_1792 = nil }; var arg_1793 any; var root_1794 any = A_arbace_classes_env_A_const_114.GetRawRoot__O(); var linked_1795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1794, A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_1796 lang.IFn; if linked_1795 == nil { ifn_1796 = lang.IFn_Cast(root_1794) } else { ifn_1796 = nil }; var arg_1797 any = t.F_c; if linked_1795 == nil { arg_1793 = ifn_1796.Invoke_O__O(arg_1797) } else { arg_1793 = linked_1795.(*A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_1794, arg_1797) }; if linked_1791 == nil { or__1927000174__auto____6 = ifn_1792.Invoke_O__O(arg_1793) } else { or__1927000174__auto____6 = linked_1791.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1790, arg_1793) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp9 = or__1927000174__auto____6 } else { var root_1798 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1798, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1800 lang.IFn; if linked_1799 == nil { ifn_1800 = lang.IFn_Cast(root_1798) } else { ifn_1800 = nil }; var arg_1801 any; var root_1802 any = A_arbace_classes_env_A_const_124.GetRawRoot__O(); var linked_1803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1802, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1804 lang.IFn; if linked_1803 == nil { ifn_1804 = lang.IFn_Cast(root_1802) } else { ifn_1804 = nil }; var arg_1805 any = A_arbace_classes_env_A_const_43.Invoke_O__O(m__4); var arg_1806 any = A_arbace_classes_env_A_const_138; if linked_1803 == nil { arg_1801 = ifn_1804.Invoke_O_O__O(arg_1805, arg_1806) } else { arg_1801 = linked_1803.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1802, arg_1805, arg_1806) }; if linked_1799 == nil { tmp9 = ifn_1800.Invoke_O__O(arg_1801) } else { tmp9 = linked_1799.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1798, arg_1801) } } }
//line :399:1
			if jrt.J2g_Truth(tmp9) { var tmp10 any; var root_1807 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1807, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1809 lang.IFn




				if linked_1808 == nil { ifn_1809 = lang.IFn_Cast(root_1807) } else { ifn_1809 = nil }; var arg_1810 any; var tmp11 lang.IFn = lang.IFn_Cast(t.F_seen); var tmp12 any; var root_1811 any = A_arbace_classes_env_A_const_139.GetRawRoot__O(); var linked_1812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1811, A_arbace_classes_env_params_key_A_fn_class); var ifn_1813 lang.IFn; if linked_1812 == nil { ifn_1813 = lang.IFn_Cast(root_1811) } else { ifn_1813 = nil }; var arg_1814 any = A_arbace_classes_env_A_const_60.Invoke_O__O(m__4); if linked_1812 == nil { tmp12 = ifn_1813.Invoke_O__O(arg_1814) } else { tmp12 = linked_1812.(*A_arbace_classes_env_params_key_A).Invoke_O_O__O(root_1811, arg_1814) }; arg_1810 = tmp11.Invoke_O__O(tmp12); if linked_1808 == nil { tmp10 = ifn_1809.Invoke_O__O(arg_1810) } else { tmp10 = linked_1808.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1807, arg_1810) }
//line :399:1
				if jrt.J2g_Truth(tmp10) { var root_1815 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_1816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1815, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1817 lang.IFn; if linked_1816 == nil { ifn_1817 = lang.IFn_Cast(root_1815) } else { ifn_1817 = nil }; var arg_1818 any = m__4; var arg_1819 any; var tmp13 lang.IFn = lang.IFn_Cast(t.F_iter__28000227); var tmp14 any; var root_1820 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_1821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1820, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1822 lang.IFn; if linked_1821 == nil { ifn_1822 = lang.IFn_Cast(root_1820) } else { ifn_1822 = nil }; var arg_1823 any = s__28000228__3; if linked_1821 == nil { tmp14 = ifn_1822.Invoke_O__O(arg_1823) } else { tmp14 = linked_1821.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1820, arg_1823) }; arg_1819 = tmp13.Invoke_O__O(tmp14); if linked_1816 == nil { return ifn_1817.Invoke_O_O__O(arg_1818, arg_1819) } else { return linked_1816.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1815, arg_1818, arg_1819) } } else { var tmp15 any; var root_1824 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_1825 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1824, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1826 lang.IFn; if linked_1825 == nil { ifn_1826 = lang.IFn_Cast(root_1824) } else { ifn_1826 = nil }; var arg_1827 any = s__28000228__3; if linked_1825 == nil { tmp15 = ifn_1826.Invoke_O__O(arg_1827) } else { tmp15 = linked_1825.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1824, arg_1827) }; s__28000228__1 = tmp15; continue L1 } } else { var tmp16 any; var root_1828 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_1829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1828, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1830 lang.IFn; if linked_1829 == nil { ifn_1830 = lang.IFn_Cast(root_1828) } else { ifn_1830 = nil }; var arg_1831 any = s__28000228__3; if linked_1829 == nil { tmp16 = ifn_1830.Invoke_O__O(arg_1831) } else { tmp16 = linked_1829.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1828, arg_1831) }; s__28000228__1 = tmp16; continue L1 } } else { var tmp17 any; var root_1832 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_1833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1832, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1834 lang.IFn; if linked_1833 == nil { ifn_1834 = lang.IFn_Cast(root_1832) } else { ifn_1834 = nil }; var arg_1835 any = s__28000228__3; if linked_1833 == nil { tmp17 = ifn_1834.Invoke_O__O(arg_1835) } else { tmp17 = linked_1833.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1832, arg_1835) }; s__28000228__1 = tmp17; continue L1 } } else { var tmp18 any; var root_1836 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_1837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1836, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1838 lang.IFn; if linked_1837 == nil { ifn_1838 = lang.IFn_Cast(root_1836) } else { ifn_1838 = nil }; var arg_1839 any = s__28000228__3; if linked_1837 == nil { tmp18 = ifn_1838.Invoke_O__O(arg_1839) } else { tmp18 = linked_1837.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1836, arg_1839) }; s__28000228__1 = tmp18; continue L1 } } else { var tmp19 any; var root_1840 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_1841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1840, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1842 lang.IFn; if linked_1841 == nil { ifn_1842 = lang.IFn_Cast(root_1840) } else { ifn_1842 = nil }; var arg_1843 any = s__28000228__3; if linked_1841 == nil { tmp19 = ifn_1842.Invoke_O__O(arg_1843) } else { tmp19 = linked_1841.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1840, arg_1843) }; s__28000228__1 = tmp19; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :399:1
func A_arbace_classes_env_member_methods_STAR__iter__28000227__28000231_fn__28000232_fn__28000233_A_New_O_O_O_O_O_I_O(p0, p1, p2, p3, p4 any, p5 int32, p6 any) *A_arbace_classes_env_member_methods_STAR__iter__28000227__28000231_fn__28000232_fn__28000233_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_member_methods_STAR__iter__28000227__28000231_fn__28000232_fn__28000233_A{}; t.Ctor_O_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :399:1
func (t *A_arbace_classes_env_member_methods_STAR__iter__28000227__28000231_fn__28000232_fn__28000233_A) Ctor_O_O_O_O_O_I_O(c__b__28000230, c__seen, c__name, c__n, c__c any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__28000230 = c__b__28000230; t.F_seen = c__seen; t.F_name = c__name; t.F_n = c__n; t.F_c = c__c; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :399:1
func (t *A_arbace_classes_env_member_methods_STAR__iter__28000227__28000231_fn__28000232_fn__28000233_A) Invoke_O__O(self any) any { { var i__28000229__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__28000229__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__28000229__1)); var tmp2 any = t.F_name; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_classes_env_A_const_42.Invoke_O__O(m__2)) { var tmp3 any; var root_1696 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1696, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1698 lang.IFn

	if linked_1697 == nil { ifn_1698 = lang.IFn_Cast(root_1696) } else { ifn_1698 = nil }; var arg_1699 any; var root_1700 any = A_arbace_classes_env_A_const_124.GetRawRoot__O(); var linked_1701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1700, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1702 lang.IFn; if linked_1701 == nil { ifn_1702 = lang.IFn_Cast(root_1700) } else { ifn_1702 = nil }; var arg_1703 any = A_arbace_classes_env_A_const_43.Invoke_O__O(m__2); var arg_1704 any = A_arbace_classes_env_A_const_137; if linked_1701 == nil { arg_1699 = ifn_1702.Invoke_O_O__O(arg_1703, arg_1704) } else { arg_1699 = linked_1701.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1700, arg_1703, arg_1704) }; if linked_1697 == nil { tmp3 = ifn_1698.Invoke_O__O(arg_1699) } else { tmp3 = linked_1697.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1696, arg_1699) }
//line :399:1
	if jrt.J2g_Truth(tmp3) { var tmp4 any; var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(t.F_c, t.F_n)


		if or__1927000174__auto____3 { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var root_1705 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1705, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1707 lang.IFn; if linked_1706 == nil { ifn_1707 = lang.IFn_Cast(root_1705) } else { ifn_1707 = nil }; var arg_1708 any; var root_1709 any = A_arbace_classes_env_A_const_124.GetRawRoot__O(); var linked_1710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1709, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1711 lang.IFn; if linked_1710 == nil { ifn_1711 = lang.IFn_Cast(root_1709) } else { ifn_1711 = nil }; var arg_1712 any = A_arbace_classes_env_A_const_43.Invoke_O__O(m__2); var arg_1713 any = A_arbace_classes_env_A_const_126; if linked_1710 == nil { arg_1708 = ifn_1711.Invoke_O_O__O(arg_1712, arg_1713) } else { arg_1708 = linked_1710.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1709, arg_1712, arg_1713) }; if linked_1706 == nil { tmp4 = ifn_1707.Invoke_O__O(arg_1708) } else { tmp4 = linked_1706.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1705, arg_1708) } }
//line :399:1
		if jrt.J2g_Truth(tmp4) { var tmp5 any; var or__1927000174__auto____3_2 bool = lang.Util_Equiv_O_O__Z_NoInit(t.F_c, t.F_n)



			if or__1927000174__auto____3_2 { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3_2).Ref() } else { var or__1927000174__auto____4 any; var root_1714 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1714, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1716 lang.IFn; if linked_1715 == nil { ifn_1716 = lang.IFn_Cast(root_1714) } else { ifn_1716 = nil }; var arg_1717 any; var root_1718 any = A_arbace_classes_env_A_const_114.GetRawRoot__O(); var linked_1719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1718, A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_1720 lang.IFn; if linked_1719 == nil { ifn_1720 = lang.IFn_Cast(root_1718) } else { ifn_1720 = nil }; var arg_1721 any = t.F_c; if linked_1719 == nil { arg_1717 = ifn_1720.Invoke_O__O(arg_1721) } else { arg_1717 = linked_1719.(*A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_1718, arg_1721) }; if linked_1715 == nil { or__1927000174__auto____4 = ifn_1716.Invoke_O__O(arg_1717) } else { or__1927000174__auto____4 = linked_1715.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1714, arg_1717) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp5 = or__1927000174__auto____4 } else { var root_1722 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1723 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1722, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1724 lang.IFn; if linked_1723 == nil { ifn_1724 = lang.IFn_Cast(root_1722) } else { ifn_1724 = nil }; var arg_1725 any; var root_1726 any = A_arbace_classes_env_A_const_124.GetRawRoot__O(); var linked_1727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1726, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1728 lang.IFn; if linked_1727 == nil { ifn_1728 = lang.IFn_Cast(root_1726) } else { ifn_1728 = nil }; var arg_1729 any = A_arbace_classes_env_A_const_43.Invoke_O__O(m__2); var arg_1730 any = A_arbace_classes_env_A_const_138; if linked_1727 == nil { arg_1725 = ifn_1728.Invoke_O_O__O(arg_1729, arg_1730) } else { arg_1725 = linked_1727.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1726, arg_1729, arg_1730) }; if linked_1723 == nil { tmp5 = ifn_1724.Invoke_O__O(arg_1725) } else { tmp5 = linked_1723.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1722, arg_1725) } } }
//line :399:1
			if jrt.J2g_Truth(tmp5) { var tmp6 any; var root_1731 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1731, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1733 lang.IFn




				if linked_1732 == nil { ifn_1733 = lang.IFn_Cast(root_1731) } else { ifn_1733 = nil }; var arg_1734 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_seen); var tmp8 any; var root_1735 any = A_arbace_classes_env_A_const_139.GetRawRoot__O(); var linked_1736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1735, A_arbace_classes_env_params_key_A_fn_class); var ifn_1737 lang.IFn; if linked_1736 == nil { ifn_1737 = lang.IFn_Cast(root_1735) } else { ifn_1737 = nil }; var arg_1738 any = A_arbace_classes_env_A_const_60.Invoke_O__O(m__2); if linked_1736 == nil { tmp8 = ifn_1737.Invoke_O__O(arg_1738) } else { tmp8 = linked_1736.(*A_arbace_classes_env_params_key_A).Invoke_O_O__O(root_1735, arg_1738) }; arg_1734 = tmp7.Invoke_O__O(tmp8); if linked_1732 == nil { tmp6 = ifn_1733.Invoke_O__O(arg_1734) } else { tmp6 = linked_1732.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1731, arg_1734) }
//line :399:1
				if jrt.J2g_Truth(tmp6) { var root_1739 any = A_arbace_classes_env_A_const_62.GetRawRoot__O(); var linked_1740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1739, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1741 lang.IFn; if linked_1740 == nil { ifn_1741 = lang.IFn_Cast(root_1739) } else { ifn_1741 = nil }; var arg_1742 any = t.F_b__28000230; var arg_1743 any = m__2; if linked_1740 == nil { ifn_1741.Invoke_O_O__O(arg_1742, arg_1743) } else { linked_1740.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1739, arg_1742, arg_1743) }; i__28000229__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000229__1); continue L1 } else { i__28000229__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000229__1); continue L1 } } else { i__28000229__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000229__1); continue L1 } } else { i__28000229__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000229__1); continue L1 } } else { i__28000229__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000229__1); continue L1 } } else { i__28000229__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000229__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_classes_env_member_methods_A_New() *A_arbace_classes_env_member_methods_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_member_methods_A{}; t.Ctor(); return t }
//line :408:1
func (t *A_arbace_classes_env_member_methods_A) Ctor() {}
//line :408:1
func (t *A_arbace_classes_env_member_methods_A) Invoke_O_O_O__O(self, n__0, name__1 any) any {



	var tmp1 any; var root_1872 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1872, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1874 lang.IFn; if linked_1873 == nil { ifn_1874 = lang.IFn_Cast(root_1872) } else { ifn_1874 = nil }; var arg_1875 any; var and__1927000168__auto____3 any; var root_1876 any = A_arbace_classes_env_A_const_141.GetRawRoot__O(); var linked_1877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1876, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1878 lang.IFn; if linked_1877 == nil { ifn_1878 = lang.IFn_Cast(root_1876) } else { ifn_1878 = nil }; var arg_1879 any = n__0; if linked_1877 == nil { and__1927000168__auto____3 = ifn_1878.Invoke_O__O(arg_1879) } else { and__1927000168__auto____3 = linked_1877.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1876, arg_1879) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_1880 any = A_arbace_classes_env_A_const_141.GetRawRoot__O(); var linked_1881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1880, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1882 lang.IFn; if linked_1881 == nil { ifn_1882 = lang.IFn_Cast(root_1880) } else { ifn_1882 = nil }; var arg_1883 any = name__1; if linked_1881 == nil { arg_1875 = ifn_1882.Invoke_O__O(arg_1883) } else { arg_1875 = linked_1881.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1880, arg_1883) } } else { arg_1875 = and__1927000168__auto____3 }; if linked_1873 == nil { tmp1 = ifn_1874.Invoke_O__O(arg_1875) } else { tmp1 = linked_1873.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1872, arg_1875) }; if jrt.J2g_Truth(tmp1) {
		var root_1884 any = A_arbace_classes_env_A_const_142.GetRawRoot__O(); var linked_1885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1884, A_arbace_classes_env_member_methods_STAR__A_fn_class); var ifn_1886 lang.IFn; if linked_1885 == nil { ifn_1886 = lang.IFn_Cast(root_1884) } else { ifn_1886 = nil }; var arg_1887 any = n__0; var arg_1888 any = name__1; var arg_1889 any; var root_1890 any = A_arbace_classes_env_A_const_143.GetRawRoot__O(); var linked_1891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1890, A_arbace_classes_env_all_supertypes_A_fn_class); var ifn_1892 lang.IFn; if linked_1891 == nil { ifn_1892 = lang.IFn_Cast(root_1890) } else { ifn_1892 = nil }; var arg_1893 any = n__0; if linked_1891 == nil { arg_1889 = ifn_1892.Invoke_O__O(arg_1893) } else { arg_1889 = linked_1891.(*A_arbace_classes_env_all_supertypes_A).Invoke_O_O__O(root_1890, arg_1893) }; if linked_1885 == nil { return ifn_1886.Invoke_O_O_O__O(arg_1887, arg_1888, arg_1889) } else { return linked_1885.(*A_arbace_classes_env_member_methods_STAR__A).Invoke_O_O_O_O__O(root_1884, arg_1887, arg_1888, arg_1889) } } else {
//line :412:1
			var by_name__3 any; var or__1927000174__auto____3 any = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_144.GetRawRoot__O())).Get_O__O(n__0)


			if jrt.J2g_Truth(or__1927000174__auto____3) { by_name__3 = or__1927000174__auto____3 } else {
				jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_144.GetRawRoot__O())).PutIfAbsent_O_O__O(n__0, jrt.ConcurrentHashMap_New())
				by_name__3 = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_144.GetRawRoot__O())).Get_O__O(n__0) }
//line :412:1
			var e__4 any = jrt.NN(jrt.ConcurrentHashMap_Cast(by_name__3)).Get_O__O(name__1); var tmp2 any
			var and__1927000168__auto____5 any = e__4





			if jrt.J2g_Truth(and__1927000168__auto____5) { var root_1894 any = A_arbace_classes_env_A_const_132.GetRawRoot__O(); var linked_1895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1894, A_arbace_classes_env_same_infos_QMARK__A_fn_class); var ifn_1896 lang.IFn; if linked_1895 == nil { ifn_1896 = lang.IFn_Cast(root_1894) } else { ifn_1896 = nil }; var arg_1897 any = lang.RT_Aget_O1_I__O_NoInit(jrt.ObjectArray_Cast(e__4), lang.RT_IntCast_J__I_NoInit(1)); var arg_1898 any = lang.RT_Aget_O1_I__O_NoInit(jrt.ObjectArray_Cast(e__4), lang.RT_IntCast_J__I_NoInit(2)); if linked_1895 == nil { tmp2 = ifn_1896.Invoke_O_O__O(arg_1897, arg_1898) } else { tmp2 = linked_1895.(*A_arbace_classes_env_same_infos_QMARK__A).Invoke_O_O_O__O(root_1894, arg_1897, arg_1898) } } else { tmp2 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp2) {
				return lang.RT_Aget_O1_I__O_NoInit(jrt.ObjectArray_Cast(e__4), lang.RT_IntCast_J__I_NoInit(0)) } else {
//line :419:1
					var sups__5 any; var root_1899 any = A_arbace_classes_env_A_const_143.GetRawRoot__O(); var linked_1900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1899, A_arbace_classes_env_all_supertypes_A_fn_class); var ifn_1901 lang.IFn

					if linked_1900 == nil { ifn_1901 = lang.IFn_Cast(root_1899) } else { ifn_1901 = nil }; var arg_1902 any = n__0; if linked_1900 == nil { sups__5 = ifn_1901.Invoke_O__O(arg_1902) } else { sups__5 = linked_1900.(*A_arbace_classes_env_all_supertypes_A).Invoke_O_O__O(root_1899, arg_1902) }
//line :419:1
					var infos__6 any; var root_1903 any = A_arbace_classes_env_A_const_134.GetRawRoot__O(); var linked_1904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1903, A_arbace_classes_env_infos_now_A_fn_class); var ifn_1905 lang.IFn


					if linked_1904 == nil { ifn_1905 = lang.IFn_Cast(root_1903) } else { ifn_1905 = nil }; var arg_1906 any = sups__5; if linked_1904 == nil { infos__6 = ifn_1905.Invoke_O__O(arg_1906) } else { infos__6 = linked_1904.(*A_arbace_classes_env_infos_now_A).Invoke_O_O__O(root_1903, arg_1906) }
//line :419:1
					var r__7 any; var root_1907 any = A_arbace_classes_env_A_const_142.GetRawRoot__O(); var linked_1908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1907, A_arbace_classes_env_member_methods_STAR__A_fn_class); var ifn_1909 lang.IFn



					if linked_1908 == nil { ifn_1909 = lang.IFn_Cast(root_1907) } else { ifn_1909 = nil }; var arg_1910 any = n__0; var arg_1911 any = name__1; var arg_1912 any = sups__5; if linked_1908 == nil { r__7 = ifn_1909.Invoke_O_O_O__O(arg_1910, arg_1911, arg_1912) } else { r__7 = linked_1908.(*A_arbace_classes_env_member_methods_STAR__A).Invoke_O_O_O_O__O(root_1907, arg_1910, arg_1911, arg_1912)
					}
					var tmp3 any; var and__1927000168__auto____8 bool; var tmp4 any; var root_1913 any = A_arbace_classes_env_A_const_143.GetRawRoot__O(); var linked_1914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1913, A_arbace_classes_env_all_supertypes_A_fn_class); var ifn_1915 lang.IFn; if linked_1914 == nil { ifn_1915 = lang.IFn_Cast(root_1913) } else { ifn_1915 = nil }; var arg_1916 any = n__0; if linked_1914 == nil { tmp4 = ifn_1915.Invoke_O__O(arg_1916) } else { tmp4 = linked_1914.(*A_arbace_classes_env_all_supertypes_A).Invoke_O_O__O(root_1913, arg_1916) }; and__1927000168__auto____8 = lang.Util_Equiv_O_O__Z_NoInit(sups__5, tmp4); if and__1927000168__auto____8 { var root_1917 any = A_arbace_classes_env_A_const_132.GetRawRoot__O(); var linked_1918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1917, A_arbace_classes_env_same_infos_QMARK__A_fn_class); var ifn_1919 lang.IFn; if linked_1918 == nil { ifn_1919 = lang.IFn_Cast(root_1917) } else { ifn_1919 = nil }; var arg_1920 any = sups__5; var arg_1921 any = infos__6; if linked_1918 == nil { tmp3 = ifn_1919.Invoke_O_O__O(arg_1920, arg_1921) } else { tmp3 = linked_1918.(*A_arbace_classes_env_same_infos_QMARK__A).Invoke_O_O_O__O(root_1917, arg_1920, arg_1921) } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() }; if jrt.J2g_Truth(tmp3) {
						jrt.NN(jrt.ConcurrentHashMap_Cast(by_name__3)).Put_O_O__O(name__1, lang.RT_Object_array_O__O1_NoInit(lang.Tuple_Create_O_O_O__IPersistentVector(r__7, sups__5, infos__6)).Ref()) }
//line :419:1
					return r__7
				}
		}
}






func A_arbace_classes_env_constructors_A_New() *A_arbace_classes_env_constructors_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_constructors_A{}; t.Ctor(); return t }
//line :429:1
func (t *A_arbace_classes_env_constructors_A) Ctor() {}
//line :429:1
func (t *A_arbace_classes_env_constructors_A) Invoke_O_O__O(self, n__0 any) any {
	var root_1922 any = A_arbace_classes_env_A_const_92.GetRawRoot__O(); var linked_1923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1922, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1924 lang.IFn; if linked_1923 == nil { ifn_1924 = lang.IFn_Cast(root_1922) } else { ifn_1924 = nil }; var arg_1925 any; var fnbody__1928 any = A_arbace_classes_env_constructors_fn__28000240_A_New(); var tmp1 *jrt.Class; var fncls__1927 *jrt.Class = A_arbace_classes_env_constructors_fn__28000240_A_fn_class; if fncls__1927 == nil { var fncls__1927d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, false, nil); A_arbace_classes_env_constructors_fn__28000240_A_fn_class = fncls__1927d; tmp1 = fncls__1927d } else { tmp1 = fncls__1927 }; arg_1925 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1928, tmp1, nil); var arg_1926 any; var tmp2 *lang.Keyword = A_arbace_classes_env_A_const_77; var tmp3 any; var root_1929 any = A_arbace_classes_env_A_const_100.GetRawRoot__O(); var linked_1930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1929, A_arbace_classes_env_info_BANG__A_fn_class); var ifn_1931 lang.IFn; if linked_1930 == nil { ifn_1931 = lang.IFn_Cast(root_1929) } else { ifn_1931 = nil }; var arg_1932 any = n__0; if linked_1930 == nil { tmp3 = ifn_1931.Invoke_O__O(arg_1932) } else { tmp3 = linked_1930.(*A_arbace_classes_env_info_BANG__A).Invoke_O_O__O(root_1929, arg_1932) }; arg_1926 = tmp2.Invoke_O__O(tmp3); if linked_1923 == nil { return ifn_1924.Invoke_O_O__O(arg_1925, arg_1926) } else { return linked_1923.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1922, arg_1925, arg_1926) } }
//line :430:1
func A_arbace_classes_env_constructors_fn__28000240_A_New() *A_arbace_classes_env_constructors_fn__28000240_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_constructors_fn__28000240_A{}; t.Ctor(); return t }
//line :430:1
func (t *A_arbace_classes_env_constructors_fn__28000240_A) Ctor() {}
//line :430:1
func (t *A_arbace_classes_env_constructors_fn__28000240_A) Invoke_O_O__O(self, p1__28000239_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_13, A_arbace_classes_env_A_const_42.Invoke_O__O(p1__28000239_SHARP___1))).Ref() }








































































































































type A_arbace_classes_env_A struct{ jrt.Object }

var A_arbace_classes_env_A_const_pool *jrt.RefArray

var A_arbace_classes_env_A_const_0 *lang.Var

var A_arbace_classes_env_A_const_1 any

var A_arbace_classes_env_A_const_2 *lang.Var

var A_arbace_classes_env_A_const_3 any

var A_arbace_classes_env_A_const_4 any

var A_arbace_classes_env_A_const_5 any

var A_arbace_classes_env_A_const_6 any

var A_arbace_classes_env_A_const_7 *lang.Var

var A_arbace_classes_env_A_const_8 *lang.Var

var A_arbace_classes_env_A_const_9 *lang.Var

var A_arbace_classes_env_A_const_10 *lang.Var

var A_arbace_classes_env_A_const_11 any

var A_arbace_classes_env_A_const_12 *lang.Var

var A_arbace_classes_env_A_const_13 *lang.Var

var A_arbace_classes_env_A_const_14 *lang.Var

var A_arbace_classes_env_A_const_15 *lang.Var

var A_arbace_classes_env_A_const_16 *lang.Var

var A_arbace_classes_env_A_const_17 *lang.Var

var A_arbace_classes_env_A_const_18 *lang.Var

var A_arbace_classes_env_A_const_19 *lang.Var

var A_arbace_classes_env_A_const_20 *lang.Var

var A_arbace_classes_env_A_const_21 *lang.Var

var A_arbace_classes_env_A_const_22 *lang.Keyword

var A_arbace_classes_env_A_const_23 *lang.Var

var A_arbace_classes_env_A_const_24 *lang.Var

var A_arbace_classes_env_A_const_25 *lang.Var

var A_arbace_classes_env_A_const_26 *lang.Var

var A_arbace_classes_env_A_const_27 *lang.Var

var A_arbace_classes_env_A_const_28 *lang.Var

var A_arbace_classes_env_A_const_29 *lang.Var

var A_arbace_classes_env_A_const_30 *lang.Var

var A_arbace_classes_env_A_const_31 *lang.Var

var A_arbace_classes_env_A_const_32 *lang.Keyword

var A_arbace_classes_env_A_const_33 *lang.Keyword

var A_arbace_classes_env_A_const_34 *jrt.Class

var A_arbace_classes_env_A_const_35 *lang.Var

var A_arbace_classes_env_A_const_36 *lang.Var

var A_arbace_classes_env_A_const_37 *lang.Var

var A_arbace_classes_env_A_const_38 any

var A_arbace_classes_env_A_const_39 any

var A_arbace_classes_env_A_const_40 *lang.Var

var A_arbace_classes_env_A_const_41 *lang.Var

var A_arbace_classes_env_A_const_42 *lang.Keyword

var A_arbace_classes_env_A_const_43 *lang.Keyword

var A_arbace_classes_env_A_const_44 *lang.Keyword

var A_arbace_classes_env_A_const_45 *lang.Keyword

var A_arbace_classes_env_A_const_46 *lang.Keyword

var A_arbace_classes_env_A_const_47 *lang.Var

var A_arbace_classes_env_A_const_48 *lang.Keyword

var A_arbace_classes_env_A_const_49 *lang.Keyword

var A_arbace_classes_env_A_const_50 *lang.Keyword

var A_arbace_classes_env_A_const_51 *lang.Var

var A_arbace_classes_env_A_const_52 *lang.Var

var A_arbace_classes_env_A_const_53 *lang.Var

var A_arbace_classes_env_A_const_54 *lang.Var

var A_arbace_classes_env_A_const_55 *lang.Var

var A_arbace_classes_env_A_const_56 *lang.Var

var A_arbace_classes_env_A_const_57 *lang.Var

var A_arbace_classes_env_A_const_58 *lang.Var

var A_arbace_classes_env_A_const_59 *lang.Var

var A_arbace_classes_env_A_const_60 *lang.Keyword

var A_arbace_classes_env_A_const_61 *lang.Keyword

var A_arbace_classes_env_A_const_62 *lang.Var

var A_arbace_classes_env_A_const_63 *lang.Keyword

var A_arbace_classes_env_A_const_64 *lang.Keyword

var A_arbace_classes_env_A_const_65 *lang.Var

var A_arbace_classes_env_A_const_66 *lang.Var

var A_arbace_classes_env_A_const_67 *lang.Var

var A_arbace_classes_env_A_const_68 *lang.Var

var A_arbace_classes_env_A_const_69 *lang.Var

var A_arbace_classes_env_A_const_70 *lang.Var

var A_arbace_classes_env_A_const_71 *lang.Var

var A_arbace_classes_env_A_const_72 *lang.Var

var A_arbace_classes_env_A_const_73 *lang.Var

var A_arbace_classes_env_A_const_74 any

var A_arbace_classes_env_A_const_75 *lang.Keyword

var A_arbace_classes_env_A_const_76 *lang.Var

var A_arbace_classes_env_A_const_77 *lang.Keyword

var A_arbace_classes_env_A_const_78 *lang.Var

var A_arbace_classes_env_A_const_79 *lang.Var

var A_arbace_classes_env_A_const_80 *lang.Var

var A_arbace_classes_env_A_const_81 *lang.Keyword

var A_arbace_classes_env_A_const_82 *lang.Keyword

var A_arbace_classes_env_A_const_83 *lang.Var

var A_arbace_classes_env_A_const_84 *lang.Keyword

var A_arbace_classes_env_A_const_85 *lang.Var

var A_arbace_classes_env_A_const_86 any

var A_arbace_classes_env_A_const_87 *lang.Var

var A_arbace_classes_env_A_const_88 *lang.Var

var A_arbace_classes_env_A_const_89 *lang.Var

var A_arbace_classes_env_A_const_90 *lang.Keyword

var A_arbace_classes_env_A_const_91 *lang.Var

var A_arbace_classes_env_A_const_92 *lang.Var

var A_arbace_classes_env_A_const_93 any

var A_arbace_classes_env_A_const_94 *lang.Var

var A_arbace_classes_env_A_const_95 *lang.Keyword

var A_arbace_classes_env_A_const_96 *lang.Var

var A_arbace_classes_env_A_const_97 *lang.Var

var A_arbace_classes_env_A_const_98 *lang.Var

var A_arbace_classes_env_A_const_99 *lang.Var

var A_arbace_classes_env_A_const_100 *lang.Var

var A_arbace_classes_env_A_const_101 *lang.Var

var A_arbace_classes_env_A_const_102 *lang.Var

var A_arbace_classes_env_A_const_103 *lang.Keyword

var A_arbace_classes_env_A_const_104 *lang.Var

var A_arbace_classes_env_A_const_105 *lang.Var

var A_arbace_classes_env_A_const_106 *lang.Var

var A_arbace_classes_env_A_const_107 *lang.Var

var A_arbace_classes_env_A_const_108 *lang.Var

var A_arbace_classes_env_A_const_109 *lang.Keyword

var A_arbace_classes_env_A_const_110 any

var A_arbace_classes_env_A_const_111 *lang.Var

var A_arbace_classes_env_A_const_112 *lang.Var

var A_arbace_classes_env_A_const_113 *lang.Var

var A_arbace_classes_env_A_const_114 *lang.Var

var A_arbace_classes_env_A_const_115 *lang.Var

var A_arbace_classes_env_A_const_116 *lang.Var

var A_arbace_classes_env_A_const_117 *lang.Var

var A_arbace_classes_env_A_const_118 *lang.Var

var A_arbace_classes_env_A_const_119 *lang.Var

var A_arbace_classes_env_A_const_120 *lang.Var

var A_arbace_classes_env_A_const_121 *lang.Var

var A_arbace_classes_env_A_const_122 *lang.Var

var A_arbace_classes_env_A_const_123 *lang.Var

var A_arbace_classes_env_A_const_124 *lang.Var

var A_arbace_classes_env_A_const_125 any

var A_arbace_classes_env_A_const_126 any

var A_arbace_classes_env_A_const_127 *lang.Var

var A_arbace_classes_env_A_const_128 any

var A_arbace_classes_env_A_const_129 *lang.Var

var A_arbace_classes_env_A_const_130 *lang.Var

var A_arbace_classes_env_A_const_131 *lang.Var

var A_arbace_classes_env_A_const_132 *lang.Var

var A_arbace_classes_env_A_const_133 *lang.Var

var A_arbace_classes_env_A_const_134 *lang.Var

var A_arbace_classes_env_A_const_135 *lang.Var

var A_arbace_classes_env_A_const_136 any

var A_arbace_classes_env_A_const_137 any

var A_arbace_classes_env_A_const_138 any

var A_arbace_classes_env_A_const_139 *lang.Var

var A_arbace_classes_env_A_const_140 *lang.Var

var A_arbace_classes_env_A_const_141 *lang.Var

var A_arbace_classes_env_A_const_142 *lang.Var

var A_arbace_classes_env_A_const_143 *lang.Var

var A_arbace_classes_env_A_const_144 *lang.Var

var A_arbace_classes_env_A_init jrt.ClassInit

func A_arbace_classes_env_A_Init() { if !A_arbace_classes_env_A_init.Done() { A_arbace_classes_env_A_init.Run(A_arbace_classes_env_A_clinit) } }

func A_arbace_classes_env_A_clinit() { A_arbace_classes_env_A_clinit_p0(); A_arbace_classes_env_A_clinit_p1(); A_arbace_classes_env_A_clinit_p2(); A_arbace_classes_env_A_clinit_p3(); A_arbace_classes_env_A_clinit_p4(); A_arbace_classes_env_A_clinit_p5(); A_arbace_classes_env_A_clinit_p6(); A_arbace_classes_env_A_clinit_p7(); A_arbace_classes_env_A_clinit_p8(); A_arbace_classes_env_A_clinit_p9(); A_arbace_classes_env_A_clinit_p10(); A_arbace_classes_env_A_clinit_p11(); A_arbace_classes_env_A_clinit_p12() }

func A_arbace_classes_env_A_clinit_p0() { jrt.StartCheck(); A_arbace_classes_env_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 184); A_arbace_classes_env_A_const_0 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[39]); A_arbace_classes_env_A_const_1 = A_arbace_classes_env_A_const_pool.A[40]; A_arbace_classes_env_A_const_2 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[41]); A_arbace_classes_env_A_const_3 = A_arbace_classes_env_A_const_pool.A[42]; A_arbace_classes_env_A_const_4 = A_arbace_classes_env_A_const_pool.A[43]; A_arbace_classes_env_A_const_5 = A_arbace_classes_env_A_const_pool.A[44]; A_arbace_classes_env_A_const_6 = A_arbace_classes_env_A_const_pool.A[45]; A_arbace_classes_env_A_const_7 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[46]); A_arbace_classes_env_A_const_8 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[47]); A_arbace_classes_env_A_const_9 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[48]); A_arbace_classes_env_A_const_10 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[49]); A_arbace_classes_env_A_const_11 = A_arbace_classes_env_A_const_pool.A[50] }

func A_arbace_classes_env_A_clinit_p1() { A_arbace_classes_env_A_const_12 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[51]); A_arbace_classes_env_A_const_13 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[52]); A_arbace_classes_env_A_const_14 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[53]); A_arbace_classes_env_A_const_15 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[54]); A_arbace_classes_env_A_const_16 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[55]); A_arbace_classes_env_A_const_17 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[56]); A_arbace_classes_env_A_const_18 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[57]); A_arbace_classes_env_A_const_19 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[58]); A_arbace_classes_env_A_const_20 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[59]); A_arbace_classes_env_A_const_21 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[60]); A_arbace_classes_env_A_const_22 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[61]); A_arbace_classes_env_A_const_23 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[62]) }

func A_arbace_classes_env_A_clinit_p2() { A_arbace_classes_env_A_const_24 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[63]); A_arbace_classes_env_A_const_25 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[64]); A_arbace_classes_env_A_const_26 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[65]); A_arbace_classes_env_A_const_27 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[66]); A_arbace_classes_env_A_const_28 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[67]); A_arbace_classes_env_A_const_29 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[68]); A_arbace_classes_env_A_const_30 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[69]); A_arbace_classes_env_A_const_31 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[70]); A_arbace_classes_env_A_const_32 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[71]); A_arbace_classes_env_A_const_33 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[72]); A_arbace_classes_env_A_const_34 = jrt.Class_Cast(A_arbace_classes_env_A_const_pool.A[73]); A_arbace_classes_env_A_const_35 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[74]) }

func A_arbace_classes_env_A_clinit_p3() { A_arbace_classes_env_A_const_36 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[75]); A_arbace_classes_env_A_const_37 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[76]); A_arbace_classes_env_A_const_38 = A_arbace_classes_env_A_const_pool.A[77]; A_arbace_classes_env_A_const_39 = A_arbace_classes_env_A_const_pool.A[78]; A_arbace_classes_env_A_const_40 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[79]); A_arbace_classes_env_A_const_41 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[80]); A_arbace_classes_env_A_const_42 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[81]); A_arbace_classes_env_A_const_43 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[82]); A_arbace_classes_env_A_const_44 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[83]); A_arbace_classes_env_A_const_45 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[84]); A_arbace_classes_env_A_const_46 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[85]); A_arbace_classes_env_A_const_47 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[86]) }

func A_arbace_classes_env_A_clinit_p4() { A_arbace_classes_env_A_const_48 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[87]); A_arbace_classes_env_A_const_49 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[88]); A_arbace_classes_env_A_const_50 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[89]); A_arbace_classes_env_A_const_51 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[90]); A_arbace_classes_env_A_const_52 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[91]); A_arbace_classes_env_A_const_53 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[92]); A_arbace_classes_env_A_const_54 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[93]); A_arbace_classes_env_A_const_55 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[94]); A_arbace_classes_env_A_const_56 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[95]); A_arbace_classes_env_A_const_57 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[96]); A_arbace_classes_env_A_const_58 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[97]); A_arbace_classes_env_A_const_59 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[98]) }

func A_arbace_classes_env_A_clinit_p5() { A_arbace_classes_env_A_const_60 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[99]); A_arbace_classes_env_A_const_61 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[100]); A_arbace_classes_env_A_const_62 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[101]); A_arbace_classes_env_A_const_63 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[102]); A_arbace_classes_env_A_const_64 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[103]); A_arbace_classes_env_A_const_65 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[104]); A_arbace_classes_env_A_const_66 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[105]); A_arbace_classes_env_A_const_67 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[106]); A_arbace_classes_env_A_const_68 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[107]); A_arbace_classes_env_A_const_69 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[108]); A_arbace_classes_env_A_const_70 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[109]); A_arbace_classes_env_A_const_71 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[110]) }

func A_arbace_classes_env_A_clinit_p6() { A_arbace_classes_env_A_const_72 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[111]); A_arbace_classes_env_A_const_73 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[112]); A_arbace_classes_env_A_const_74 = A_arbace_classes_env_A_const_pool.A[113]; A_arbace_classes_env_A_const_75 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[114]); A_arbace_classes_env_A_const_76 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[115]); A_arbace_classes_env_A_const_77 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[116]); A_arbace_classes_env_A_const_78 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[117]); A_arbace_classes_env_A_const_79 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[118]); A_arbace_classes_env_A_const_80 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[119]); A_arbace_classes_env_A_const_81 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[120]); A_arbace_classes_env_A_const_82 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[121]); A_arbace_classes_env_A_const_83 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[122]) }

func A_arbace_classes_env_A_clinit_p7() { A_arbace_classes_env_A_const_84 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[123]); A_arbace_classes_env_A_const_85 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[124]); A_arbace_classes_env_A_const_86 = A_arbace_classes_env_A_const_pool.A[125]; A_arbace_classes_env_A_const_87 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[126]); A_arbace_classes_env_A_const_88 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[127]); A_arbace_classes_env_A_const_89 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[128]); A_arbace_classes_env_A_const_90 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[129]); A_arbace_classes_env_A_const_91 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[130]); A_arbace_classes_env_A_const_92 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[131]); A_arbace_classes_env_A_const_93 = A_arbace_classes_env_A_const_pool.A[132]; A_arbace_classes_env_A_const_94 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[133]); A_arbace_classes_env_A_const_95 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[134]) }

func A_arbace_classes_env_A_clinit_p8() { A_arbace_classes_env_A_const_96 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[135]); A_arbace_classes_env_A_const_97 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[136]); A_arbace_classes_env_A_const_98 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[137]); A_arbace_classes_env_A_const_99 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[138]); A_arbace_classes_env_A_const_100 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[139]); A_arbace_classes_env_A_const_101 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[140]); A_arbace_classes_env_A_const_102 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[141]); A_arbace_classes_env_A_const_103 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[142]); A_arbace_classes_env_A_const_104 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[143]); A_arbace_classes_env_A_const_105 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[144]); A_arbace_classes_env_A_const_106 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[145]); A_arbace_classes_env_A_const_107 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[146]) }

func A_arbace_classes_env_A_clinit_p9() { A_arbace_classes_env_A_const_108 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[147]); A_arbace_classes_env_A_const_109 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[148]); A_arbace_classes_env_A_const_110 = A_arbace_classes_env_A_const_pool.A[149]; A_arbace_classes_env_A_const_111 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[150]); A_arbace_classes_env_A_const_112 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[151]); A_arbace_classes_env_A_const_113 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[152]); A_arbace_classes_env_A_const_114 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[153]); A_arbace_classes_env_A_const_115 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[154]); A_arbace_classes_env_A_const_116 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[155]); A_arbace_classes_env_A_const_117 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[156]); A_arbace_classes_env_A_const_118 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[157]); A_arbace_classes_env_A_const_119 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[158]) }

func A_arbace_classes_env_A_clinit_p10() { A_arbace_classes_env_A_const_120 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[159]); A_arbace_classes_env_A_const_121 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[160]); A_arbace_classes_env_A_const_122 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[161]); A_arbace_classes_env_A_const_123 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[162]); A_arbace_classes_env_A_const_124 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[163]); A_arbace_classes_env_A_const_125 = A_arbace_classes_env_A_const_pool.A[164]; A_arbace_classes_env_A_const_126 = A_arbace_classes_env_A_const_pool.A[165]; A_arbace_classes_env_A_const_127 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[166]); A_arbace_classes_env_A_const_128 = A_arbace_classes_env_A_const_pool.A[167]; A_arbace_classes_env_A_const_129 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[168]); A_arbace_classes_env_A_const_130 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[169]); A_arbace_classes_env_A_const_131 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[170]) }

func A_arbace_classes_env_A_clinit_p11() { A_arbace_classes_env_A_const_132 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[171]); A_arbace_classes_env_A_const_133 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[172]); A_arbace_classes_env_A_const_134 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[173]); A_arbace_classes_env_A_const_135 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[174]); A_arbace_classes_env_A_const_136 = A_arbace_classes_env_A_const_pool.A[175]; A_arbace_classes_env_A_const_137 = A_arbace_classes_env_A_const_pool.A[176]; A_arbace_classes_env_A_const_138 = A_arbace_classes_env_A_const_pool.A[177]; A_arbace_classes_env_A_const_139 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[178]); A_arbace_classes_env_A_const_140 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[179]); A_arbace_classes_env_A_const_141 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[180]); A_arbace_classes_env_A_const_142 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[181]); A_arbace_classes_env_A_const_143 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[182]) }

func A_arbace_classes_env_A_clinit_p12() { A_arbace_classes_env_A_const_144 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[183]) }

func A_arbace_classes_env_A_New() *A_arbace_classes_env_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_env_A) Ctor() {}

func (t *A_arbace_classes_env_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_A_class }

func (t *A_arbace_classes_env_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_env_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_A); return ok }

func A_arbace_classes_env_A_Cast(x any) *A_arbace_classes_env_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_A_class)) }; return v }



type A_arbace_classes_env_accessible_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_accessible_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_accessible_QMARK__fn__28000191_A struct{ j2g_header uint64; F_owner any }

var A_arbace_classes_env_accessible_QMARK__fn__28000191_A_fn_class *jrt.Class



type A_arbace_classes_env_accessible_QMARK__fn__28000193_A struct{ j2g_header uint64 }

var A_arbace_classes_env_accessible_QMARK__fn__28000193_A_fn_class *jrt.Class



type A_arbace_classes_env_all_supertypes_A struct{ j2g_header uint64 }

var A_arbace_classes_env_all_supertypes_A_fn_class *jrt.Class



type A_arbace_classes_env_all_supertypes_STAR__A struct{ j2g_header uint64 }

var A_arbace_classes_env_all_supertypes_STAR__A_fn_class *jrt.Class



type A_arbace_classes_env_all_supertypes_STAR__fn__28000208_A struct{ j2g_header uint64 }

var A_arbace_classes_env_all_supertypes_STAR__fn__28000208_A_fn_class *jrt.Class



type A_arbace_classes_env_assignable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_assignable_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_class_file_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_class_file_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_coerce_const_A struct{ j2g_header uint64 }

var A_arbace_classes_env_coerce_const_A_fn_class *jrt.Class



type A_arbace_classes_env_common_super_A struct{ j2g_header uint64 }

var A_arbace_classes_env_common_super_A_fn_class *jrt.Class



type A_arbace_classes_env_const_value_A struct{ j2g_header uint64 }

var A_arbace_classes_env_const_value_A_fn_class *jrt.Class



type A_arbace_classes_env_constructors_A struct{ j2g_header uint64 }

var A_arbace_classes_env_constructors_A_fn_class *jrt.Class



type A_arbace_classes_env_constructors_fn__28000240_A struct{ j2g_header uint64 }

var A_arbace_classes_env_constructors_fn__28000240_A_fn_class *jrt.Class



type A_arbace_classes_env_eval28000004_A struct{ jrt.Object }

func A_arbace_classes_env_eval28000004_A_New() *A_arbace_classes_env_eval28000004_A { t := &A_arbace_classes_env_eval28000004_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_env_eval28000004_A) Ctor() {}

func (t *A_arbace_classes_env_eval28000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_eval28000004_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_eval28000004_A_class }

func (t *A_arbace_classes_env_eval28000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_eval28000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_env_eval28000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_eval28000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_eval28000004_A); return ok }

func A_arbace_classes_env_eval28000004_A_Cast(x any) *A_arbace_classes_env_eval28000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_eval28000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_eval28000004_A_class)) }; return v }



type A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A struct{ j2g_header uint64 }

var A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_fn_class *jrt.Class



type A_arbace_classes_env_eval28000008_A struct{ jrt.Object }

func A_arbace_classes_env_eval28000008_A_New() *A_arbace_classes_env_eval28000008_A { t := &A_arbace_classes_env_eval28000008_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_env_eval28000008_A) Ctor() {}

func (t *A_arbace_classes_env_eval28000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_eval28000008_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_eval28000008_A_class }

func (t *A_arbace_classes_env_eval28000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_eval28000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_env_eval28000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_eval28000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_eval28000008_A); return ok }

func A_arbace_classes_env_eval28000008_A_Cast(x any) *A_arbace_classes_env_eval28000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_eval28000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_eval28000008_A_class)) }; return v }



type A_arbace_classes_env_eval28000008_fn__28000009_A struct{ j2g_header uint64 }

var A_arbace_classes_env_eval28000008_fn__28000009_A_fn_class *jrt.Class



type A_arbace_classes_env_find_field_A struct{ j2g_header uint64 }

var A_arbace_classes_env_find_field_A_fn_class *jrt.Class



type A_arbace_classes_env_find_field_fn__28000198_A struct{ j2g_header uint64; F_name any }

var A_arbace_classes_env_find_field_fn__28000198_A_fn_class *jrt.Class



type A_arbace_classes_env_find_field_fn__28000200_A struct{ j2g_header uint64; F_name any }

var A_arbace_classes_env_find_field_fn__28000200_A_fn_class *jrt.Class



type A_arbace_classes_env_flag_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_flag_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_from_source_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_from_source_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_info_A struct{ j2g_header uint64 }

var A_arbace_classes_env_info_A_fn_class *jrt.Class



type A_arbace_classes_env_info_BANG__A struct{ j2g_header uint64 }

var A_arbace_classes_env_info_BANG__A_fn_class *jrt.Class



type A_arbace_classes_env_infos_now_A struct{ j2g_header uint64 }

var A_arbace_classes_env_infos_now_A_fn_class *jrt.Class



type A_arbace_classes_env_inner_member_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_inner_member_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_interface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_interface_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_internal_A struct{ j2g_header uint64 }

var A_arbace_classes_env_internal_A_fn_class *jrt.Class



type A_arbace_classes_env_known_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_known_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_load_class_A struct{ j2g_header uint64 }

var A_arbace_classes_env_load_class_A_fn_class *jrt.Class



type A_arbace_classes_env_lub_A struct{ j2g_header uint64 }

var A_arbace_classes_env_lub_A_fn_class *jrt.Class



type A_arbace_classes_env_lub_fn__28000182_A struct{ j2g_header uint64; F_common any }

var A_arbace_classes_env_lub_fn__28000182_A_fn_class *jrt.Class



type A_arbace_classes_env_lub_fn__28000182_fn__28000183_A struct{ j2g_header uint64; F_i any }

var A_arbace_classes_env_lub_fn__28000182_fn__28000183_A_fn_class *jrt.Class



type A_arbace_classes_env_lub_sups__28000177_A struct{ j2g_header uint64 }

var A_arbace_classes_env_lub_sups__28000177_A_fn_class *jrt.Class



type A_arbace_classes_env_lub_sups__28000177_fn__28000178_A struct{ j2g_header uint64 }

var A_arbace_classes_env_lub_sups__28000177_fn__28000178_A_fn_class *jrt.Class



type A_arbace_classes_env_member_methods_A struct{ j2g_header uint64 }

var A_arbace_classes_env_member_methods_A_fn_class *jrt.Class



type A_arbace_classes_env_member_methods_STAR__A struct{ j2g_header uint64 }

var A_arbace_classes_env_member_methods_STAR__A_fn_class *jrt.Class



type A_arbace_classes_env_member_methods_STAR__iter__28000227__28000231_A struct{ j2g_header uint64; F_seen, F_name, F_n, F_c any }

var A_arbace_classes_env_member_methods_STAR__iter__28000227__28000231_A_fn_class *jrt.Class



type A_arbace_classes_env_member_methods_STAR__iter__28000227__28000231_fn__28000232_A struct{ j2g_header uint64; F_s__28000228, F_iter__28000227, F_seen, F_name, F_n, F_c any }

var A_arbace_classes_env_member_methods_STAR__iter__28000227__28000231_fn__28000232_A_fn_class *jrt.Class



type A_arbace_classes_env_member_methods_STAR__iter__28000227__28000231_fn__28000232_fn__28000233_A struct{ j2g_header uint64; F_b__28000230, F_seen, F_name, F_n, F_c any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_env_member_methods_STAR__iter__28000227__28000231_fn__28000232_fn__28000233_A_fn_class *jrt.Class



type A_arbace_classes_env_nest_host_A struct{ j2g_header uint64 }

var A_arbace_classes_env_nest_host_A_fn_class *jrt.Class



type A_arbace_classes_env_params_key_A struct{ j2g_header uint64 }

var A_arbace_classes_env_params_key_A_fn_class *jrt.Class



type A_arbace_classes_env_read_fields_A struct{ j2g_header uint64 }

var A_arbace_classes_env_read_fields_A_fn_class *jrt.Class



type A_arbace_classes_env_read_method_annotations_A struct{ j2g_header uint64 }

var A_arbace_classes_env_read_method_annotations_A_fn_class *jrt.Class



type A_arbace_classes_env_record_BANG__A struct{ j2g_header uint64 }

var A_arbace_classes_env_record_BANG__A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_A struct{ j2g_header uint64 }

var A_arbace_classes_env_reflect_info_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_fn__28000027_A struct{ j2g_header uint64; F_c any }

var A_arbace_classes_env_reflect_info_fn__28000027_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_fn__28000137_A struct{ j2g_header uint64 }

var A_arbace_classes_env_reflect_info_fn__28000137_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000031__28000035_A struct{ j2g_header uint64; F_n any }

var A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A struct{ j2g_header uint64; F_n, F_s__28000032, F_iter__28000031 any }

var A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A struct{ j2g_header uint64; F_b__28000034, F_n any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000045__28000049_A struct{ j2g_header uint64; F_n any }

var A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A struct{ j2g_header uint64; F_n, F_s__28000046, F_iter__28000045 any }

var A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A struct{ j2g_header uint64; F_n, F_b__28000048 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_A struct{ j2g_header uint64; F_n, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A struct{ j2g_header uint64; F_n, F_manns, F_s__28000056, F_iter__28000055 any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A struct{ j2g_header uint64; F_n, F_b__28000058, F_manns any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A struct{ j2g_header uint64; F_m, F_desc, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A struct{ j2g_header uint64; F_m, F_desc, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A struct{ j2g_header uint64; F_i, F_m, F_desc, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A struct{ j2g_header uint64; F_m, F_desc, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A struct{ j2g_header uint64; F_m, F_desc, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A struct{ j2g_header uint64; F_i, F_m, F_desc, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000077__28000081_A struct{ j2g_header uint64; F_c, F_n any }

var A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A struct{ j2g_header uint64; F_c, F_n, F_s__28000078, F_iter__28000077 any }

var A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A struct{ j2g_header uint64; F_c, F_n, F_b__28000080 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000089__28000093_A struct{ j2g_header uint64; F_n, F_have any }

var A_arbace_classes_env_reflect_info_iter__28000089__28000093_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000089__28000093_fn__28000094_A struct{ j2g_header uint64; F_n, F_s__28000090, F_have, F_iter__28000089 any }

var A_arbace_classes_env_reflect_info_iter__28000089__28000093_fn__28000094_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000089__28000093_fn__28000094_fn__28000095_A struct{ j2g_header uint64; F_n, F_have, F_b__28000092 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_env_reflect_info_iter__28000089__28000093_fn__28000094_fn__28000095_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000105__28000109_A struct{ j2g_header uint64; F_n, F_have any }

var A_arbace_classes_env_reflect_info_iter__28000105__28000109_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000105__28000109_fn__28000110_A struct{ j2g_header uint64; F_iter__28000105, F_n, F_have, F_s__28000106 any }

var A_arbace_classes_env_reflect_info_iter__28000105__28000109_fn__28000110_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000105__28000109_fn__28000110_fn__28000111_A struct{ j2g_header uint64; F_n, F_b__28000108, F_have any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_env_reflect_info_iter__28000105__28000109_fn__28000110_fn__28000111_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000121__28000125_A struct{ j2g_header uint64; F_n, F_fhave any }

var A_arbace_classes_env_reflect_info_iter__28000121__28000125_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000121__28000125_fn__28000126_A struct{ j2g_header uint64; F_n, F_s__28000122, F_fhave, F_iter__28000121 any }

var A_arbace_classes_env_reflect_info_iter__28000121__28000125_fn__28000126_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000121__28000125_fn__28000126_fn__28000127_A struct{ j2g_header uint64; F_n, F_b__28000124 any; F_size__1927001038__auto__ int32; F_fhave, F_c__1927001037__auto__ any }

var A_arbace_classes_env_reflect_info_iter__28000121__28000125_fn__28000126_fn__28000127_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000139__28000143_A struct{ j2g_header uint64; F_n any }

var A_arbace_classes_env_reflect_info_iter__28000139__28000143_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000139__28000143_fn__28000144_A struct{ j2g_header uint64; F_n, F_iter__28000139, F_s__28000140 any }

var A_arbace_classes_env_reflect_info_iter__28000139__28000143_fn__28000144_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000139__28000143_fn__28000144_fn__28000145_A struct{ j2g_header uint64; F_b__28000142, F_n any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_env_reflect_info_iter__28000139__28000143_fn__28000144_fn__28000145_A_fn_class *jrt.Class



type A_arbace_classes_env_reflected_A struct{ j2g_header uint64 }

var A_arbace_classes_env_reflected_A_fn_class *jrt.Class



type A_arbace_classes_env_same_infos_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_same_infos_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_subclass_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_subclass_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_subclass_QMARK__fn__28000165_A struct{ j2g_header uint64; F_b any }

var A_arbace_classes_env_subclass_QMARK__fn__28000165_A_fn_class *jrt.Class



type A_arbace_classes_env_superclass_chain_A struct{ j2g_header uint64 }

var A_arbace_classes_env_superclass_chain_A_fn_class *jrt.Class



type A_arbace_classes_env_superclass_chain_fn__28000171_A struct{ j2g_header uint64 }

var A_arbace_classes_env_superclass_chain_fn__28000171_A_fn_class *jrt.Class



type A_arbace_classes_env_supertypes_A struct{ j2g_header uint64 }

var A_arbace_classes_env_supertypes_A_fn_class *jrt.Class
