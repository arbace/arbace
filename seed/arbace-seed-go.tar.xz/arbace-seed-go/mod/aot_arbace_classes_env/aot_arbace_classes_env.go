//line aot_arbace_classes_env.ae:1
package aot_arbace_classes_env

import (
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_set"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_New() *A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_classes_env_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_env_A_const_1); lang.IFn_Cast(A_arbace_classes_env_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_classes_env_A_const_3, A_arbace_classes_env_A_const_4, A_arbace_classes_env_A_const_5, A_arbace_classes_env_A_const_6); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_14)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_15)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_16)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_17)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_classes_env_eval28000008_fn__28000009_A_New() *A_arbace_classes_env_eval28000008_fn__28000009_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_eval28000008_fn__28000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_env_eval28000008_fn__28000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_env_eval28000008_fn__28000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_7.GetRawRoot__O()); var tmp2 any; var root_18 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_19 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_18, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_20 lang.IFn; if linked_19 == nil { ifn_20 = lang.IFn_Cast(root_18) } else { ifn_20 = nil }; var arg_21 any = A_arbace_classes_env_A_const_9; if linked_19 == nil { tmp2 = ifn_20.Invoke_O__O(arg_21) } else { tmp2 = linked_19.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_18, arg_21) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_classes_env_A_const_10.GetRawRoot__O(), A_arbace_classes_env_A_const_11) }



























func A_arbace_classes_env_internal_A_New() *A_arbace_classes_env_internal_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_internal_A{}; t.Ctor(); return t }
//line :29:1
func (t *A_arbace_classes_env_internal_A) Ctor() {}
//line :29:1
func (t *A_arbace_classes_env_internal_A) Invoke_O_O__O(self, c__0 any) any { var root_22 any = A_arbace_classes_env_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref(); var arg_26 any = Lit_22; var arg_27 any = Lit_21; if linked_23 == nil { return ifn_24.Invoke_O_O_O__O(arg_25, arg_26, arg_27) } else { return linked_23.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_22, arg_25, arg_26, arg_27) } }







func A_arbace_classes_env_from_source_QMARK__A_New() *A_arbace_classes_env_from_source_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_from_source_QMARK__A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_classes_env_from_source_QMARK__A) Ctor() {}
//line :37:1
func (t *A_arbace_classes_env_from_source_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var tmp1 any; var and__1927000168__auto____2 any = A_arbace_classes_env_A_const_13.Get__O(); if jrt.J2g_Truth(and__1927000168__auto____2) { tmp1 = lang.IFn_Cast(A_arbace_classes_env_A_const_13.Get__O()).Invoke_O__O(n__0) } else { tmp1 = and__1927000168__auto____2 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() }


















func A_arbace_classes_env_record_BANG__A_New() *A_arbace_classes_env_record_BANG__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_record_BANG__A{}; t.Ctor(); return t }
//line :56:1
func (t *A_arbace_classes_env_record_BANG__A) Ctor() {}
//line :56:1
func (t *A_arbace_classes_env_record_BANG__A) Invoke_O_O_O_O__O(self, n__0, facet__1, v__2 any) any {


	if jrt.J2g_Truth(A_arbace_classes_env_A_const_14.Get__O()) { lang.IFn_Cast(A_arbace_classes_env_A_const_15.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_classes_env_A_const_14.Get__O(), A_arbace_classes_env_A_const_16.GetRawRoot__O(), n__0, A_arbace_classes_env_A_const_17.GetRawRoot__O(), facet__1, v__2) }
//line :56:1
	return v__2
}




func A_arbace_classes_env_load_class_A_New() *A_arbace_classes_env_load_class_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_load_class_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_classes_env_load_class_A) Ctor() {}
//line :62:1
func (t *A_arbace_classes_env_load_class_A) Invoke_O_O__O(self, n__0 any) any {



	var tmp1 any; var or__1927000174__auto____2 any; var root_37 any = A_arbace_classes_env_A_const_18.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_37, A_arbace_classes_env_from_source_QMARK__A_fn_class); var ifn_39 lang.IFn; if linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any = n__0; if linked_38 == nil { or__1927000174__auto____2 = ifn_39.Invoke_O__O(arg_40) } else { or__1927000174__auto____2 = linked_38.(*A_arbace_classes_env_from_source_QMARK__A).Invoke_O_O__O(root_37, arg_40) }; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { tmp1 = A_arbace_classes_env_A_const_19.Get__O() }; if jrt.J2g_Truth(tmp1) { return nil } else { var tmp2 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var cn__4 any; var tmp3 any; var root_41 any = A_arbace_classes_env_A_const_20.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_43 lang.IFn

		if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = n__0; var arg_45 any = Lit_11; if linked_42 == nil { tmp3 = ifn_43.Invoke_O_O__O(arg_44, arg_45) } else { tmp3 = linked_42.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_41, arg_44, arg_45) }; if jrt.J2g_Truth(tmp3) { var root_46 any = A_arbace_classes_env_A_const_12.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_48 lang.IFn; if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = n__0; var arg_50 any = Lit_21; var arg_51 any = Lit_22; if linked_47 == nil { cn__4 = ifn_48.Invoke_O_O_O__O(arg_49, arg_50, arg_51) } else { cn__4 = linked_47.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_46, arg_49, arg_50, arg_51) } } else { var root_52 any = A_arbace_classes_env_A_const_12.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_52, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_54 lang.IFn; if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any = n__0; var arg_56 any = Lit_21; var arg_57 any = Lit_22; if linked_53 == nil { cn__4 = ifn_54.Invoke_O_O_O__O(arg_55, arg_56, arg_57) } else { cn__4 = linked_53.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_52, arg_55, arg_56, arg_57) } }
//line :66:1
		var c__5 any = lang.RT_ClassForNameNonLoading_String__Class_NoInit(jrt.String_Cast(cn__4)).Ref(); var tmp4 any
		var and__1927000168__auto____6 any = c__5


		if jrt.J2g_Truth(and__1927000168__auto____6) { tmp4 = A_arbace_classes_env_A_const_14.Get__O() } else { tmp4 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp4) { var root_58 any = A_arbace_classes_env_A_const_21.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_58, A_arbace_classes_env_record_BANG__A_fn_class); var ifn_60 lang.IFn; if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = n__0; var arg_62 any = A_arbace_classes_env_A_const_22; var arg_63 any = jrt.Boolean_TRUE.Ref(); if linked_59 == nil { ifn_60.Invoke_O_O_O__O(arg_61, arg_62, arg_63) } else { linked_59.(*A_arbace_classes_env_record_BANG__A).Invoke_O_O_O_O__O(root_58, arg_61, arg_62, arg_63) } }
//line :66:1
		tmp2 = c__5 }; return nil }(); if tmp5 != nil { if jrt.ClassNotFoundException_InstanceOf(tmp5) { var ___4 *jrt.ClassNotFoundException = jrt.ClassNotFoundException_Cast(tmp5); _ = ___4; tmp2 = nil } else if jrt.NoClassDefFoundError_InstanceOf(tmp5) { var ___4_2 *jrt.NoClassDefFoundError = jrt.NoClassDefFoundError_Cast(tmp5); _ = ___4_2; tmp2 = nil } else { panic(tmp5) } }; return tmp2
	}
}






func A_arbace_classes_env_known_QMARK__A_New() *A_arbace_classes_env_known_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_known_QMARK__A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_classes_env_known_QMARK__A) Ctor() {}
//line :75:1
func (t *A_arbace_classes_env_known_QMARK__A) Invoke_O_O__O(self, n__0 any) any {


	if jrt.J2g_Truth(A_arbace_classes_env_A_const_19.Get__O()) { var root_64 any = A_arbace_classes_env_A_const_23.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_66 lang.IFn; if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any = A_arbace_classes_env_A_const_19.Get__O(); var arg_68 any = n__0; if linked_65 == nil { return ifn_66.Invoke_O_O__O(arg_67, arg_68) } else { return linked_65.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_64, arg_67, arg_68) } } else { var root_69 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_71 lang.IFn; if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any; var root_73 any = A_arbace_classes_env_A_const_25.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, A_arbace_classes_env_load_class_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = n__0; if linked_74 == nil { arg_72 = ifn_75.Invoke_O__O(arg_76) } else { arg_72 = linked_74.(*A_arbace_classes_env_load_class_A).Invoke_O_O__O(root_73, arg_76) }; if linked_70 == nil { return ifn_71.Invoke_O__O(arg_72) } else { return linked_70.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_69, arg_72)
	} } }
func A_arbace_classes_env_reflected_A_New() *A_arbace_classes_env_reflected_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflected_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_classes_env_reflected_A) Ctor() {}
//line :80:1
func (t *A_arbace_classes_env_reflected_A) Invoke_O_O_O_O__O(self, n__0, facet__1, f__2 any) any {




	if jrt.J2g_Truth(A_arbace_classes_env_A_const_19.Get__O()) { var temp__1927000414__auto____4 any = lang.RT_Get_O_O__O_NoInit(A_arbace_classes_env_A_const_19.Get__O(), n__0)
		if jrt.J2g_Truth(temp__1927000414__auto____4) { var d__5 any = temp__1927000414__auto____4; var temp__1927000408__auto____6 any; var root_77 any = A_arbace_classes_env_A_const_26.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_77, aot_arbace_core.A_arbace_core_find_A_fn_class); var ifn_79 lang.IFn
			if linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var arg_80 any = d__5; var arg_81 any = facet__1; if linked_78 == nil { temp__1927000408__auto____6 = ifn_79.Invoke_O_O__O(arg_80, arg_81) } else { temp__1927000408__auto____6 = linked_78.(*aot_arbace_core.A_arbace_core_find_A).Invoke_O_O_O__O(root_77, arg_80, arg_81) }; if jrt.J2g_Truth(temp__1927000408__auto____6) { var e__7 any = temp__1927000408__auto____6; var root_82 any = A_arbace_classes_env_A_const_27.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, aot_arbace_core.A_arbace_core_val_A_fn_class); var ifn_84 lang.IFn
				if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = e__7; if linked_83 == nil { return ifn_84.Invoke_O__O(arg_85) } else { return linked_83.(*aot_arbace_core.A_arbace_core_val_A).Invoke_O_O__O(root_82, arg_85) } } else {
//line :87:1
					var tmp1 any; var root_86 any = A_arbace_classes_env_A_const_28.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_88 lang.IFn

					if linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_55, nil, Lit_56, nil, Lit_57); var tmp3 any; var root_91 any = A_arbace_classes_env_A_const_29.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = facet__1; if linked_92 == nil { tmp3 = ifn_93.Invoke_O__O(arg_94) } else { tmp3 = linked_92.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_91, arg_94) }; var tmp4 any = tmp3; var tmp5 any; var root_95 any = A_arbace_classes_env_A_const_12.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_97 lang.IFn; if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any; var root_101 any = A_arbace_classes_env_A_const_30.GetRawRoot__O(); var linked_102 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_101, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_103 lang.IFn; if linked_102 == nil { ifn_103 = lang.IFn_Cast(root_101) } else { ifn_103 = nil }; var arg_104 any = n__0; if linked_102 == nil { arg_98 = ifn_103.Invoke_O__O(arg_104) } else { arg_98 = linked_102.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_101, arg_104) }; var arg_99 any = Lit_21; var arg_100 any = Lit_22; if linked_96 == nil { tmp5 = ifn_97.Invoke_O_O_O__O(arg_98, arg_99, arg_100) } else { tmp5 = linked_96.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_95, arg_98, arg_99, arg_100) }; arg_89 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp4, nil, tmp5, nil)).Ref(); var arg_90 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_env_A_const_31, n__0, A_arbace_classes_env_A_const_32, facet__1)); if linked_87 == nil { tmp1 = ifn_88.Invoke_O_O__O(arg_89, arg_90) } else { tmp1 = linked_87.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_86, arg_89, arg_90) }
//line :87:1
					panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) } } else {
//line :86:1
						return nil } } else {
//line :85:1
							var temp__1927000414__auto____4_2 any; var root_105 any = A_arbace_classes_env_A_const_25.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, A_arbace_classes_env_load_class_A_fn_class); var ifn_107 lang.IFn






							if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = n__0; if linked_106 == nil { temp__1927000414__auto____4_2 = ifn_107.Invoke_O__O(arg_108) } else { temp__1927000414__auto____4_2 = linked_106.(*A_arbace_classes_env_load_class_A).Invoke_O_O__O(root_105, arg_108) }; if jrt.J2g_Truth(temp__1927000414__auto____4_2) { var c__5 any = temp__1927000414__auto____4_2; var root_109 any = A_arbace_classes_env_A_const_21.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, A_arbace_classes_env_record_BANG__A_fn_class); var ifn_111 lang.IFn
								if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any = n__0; var arg_113 any = facet__1; var arg_114 any = lang.IFn_Cast(f__2).Invoke_O__O(c__5); if linked_110 == nil { return ifn_111.Invoke_O_O_O__O(arg_112, arg_113, arg_114) } else { return linked_110.(*A_arbace_classes_env_record_BANG__A).Invoke_O_O_O_O__O(root_109, arg_112, arg_113, arg_114) } } else {
//line :92:1
									return nil
								}
						} }
func A_arbace_classes_env_class_file_QMARK__A_New() *A_arbace_classes_env_class_file_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_class_file_QMARK__A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_classes_env_class_file_QMARK__A) Ctor() {}
//line :95:1
func (t *A_arbace_classes_env_class_file_QMARK__A) Invoke_O_O__O(self, c__0 any) any { var ld__2 any; var or__1927000174__auto____2 any = jrt.NN(jrt.Class_Cast(c__0)).GetClassLoader__ClassLoader(); if





	jrt.J2g_Truth(or__1927000174__auto____2) { ld__2 = or__1927000174__auto____2 } else { ld__2 = jrt.ClassLoader_GetSystemClassLoader__ClassLoader() }; var temp__1927000414__auto____3 any; var tmp1 /*line :95:1*/*jrt.Class = A_arbace_classes_env_A_const_33; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_6); var tmp3 any; var root_115 any = A_arbace_classes_env_A_const_34.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, A_arbace_classes_env_internal_A_fn_class); var ifn_117 lang.IFn; if






	linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = c__0; if linked_116 == nil { tmp3 = ifn_117.Invoke_O__O(arg_118) } else { tmp3 = linked_116.(*A_arbace_classes_env_internal_A).Invoke_O_O__O(root_115, arg_118) }; temp__1927000414__auto____3 = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(ld__2, tmp1, Lit_5, jrt.RefArrayOf(jrt.Object_class, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil)).Ref())); if jrt.J2g_Truth(temp__1927000414__auto____3) { var in__4 any = temp__1927000414__auto____3
		jrt.InputStream_Cast(in__4).Close__V()
//line :102:1
		return jrt.Boolean_TRUE.Ref() } else { return nil } }



func A_arbace_classes_env_read_fields_A_New() *A_arbace_classes_env_read_fields_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_read_fields_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_classes_env_read_fields_A) Ctor() {}
//line :106:1
func (t *A_arbace_classes_env_read_fields_A) Invoke_O_O__O(self, c__0 any) any {




	var tmp1 any; var root_119 any = A_arbace_classes_env_A_const_35.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, A_arbace_classes_env_class_file_QMARK__A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = c__0; if linked_120 == nil { tmp1 = ifn_121.Invoke_O__O(arg_122) } else { tmp1 = linked_120.(*A_arbace_classes_env_class_file_QMARK__A).Invoke_O_O__O(root_119, arg_122) }; if jrt.J2g_Truth(tmp1) {
		var tmp2 any; var root_123 any = A_arbace_classes_env_A_const_36.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_requiring_resolve_A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = A_arbace_classes_env_A_const_37; if linked_124 == nil { tmp2 = ifn_125.Invoke_O__O(arg_126) } else { tmp2 = linked_124.(*aot_arbace_core.A_arbace_core_requiring_resolve_A).Invoke_O_O__O(root_123, arg_126) }; return lang.IFn_Cast(tmp2).Invoke_O__O(c__0) } else {
//line :111:1
			return nil
		}
}
func A_arbace_classes_env_read_method_annotations_A_New() *A_arbace_classes_env_read_method_annotations_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_read_method_annotations_A{}; t.Ctor(); return t }
//line :114:1
func (t *A_arbace_classes_env_read_method_annotations_A) Ctor() {}
//line :114:1
func (t *A_arbace_classes_env_read_method_annotations_A) Invoke_O_O__O(self, c__0 any) any {



	var tmp1 any; var root_127 any = A_arbace_classes_env_A_const_35.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, A_arbace_classes_env_class_file_QMARK__A_fn_class); var ifn_129 lang.IFn; if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = c__0; if linked_128 == nil { tmp1 = ifn_129.Invoke_O__O(arg_130) } else { tmp1 = linked_128.(*A_arbace_classes_env_class_file_QMARK__A).Invoke_O_O__O(root_127, arg_130) }; if jrt.J2g_Truth(tmp1) {
		var tmp2 any; var root_131 any = A_arbace_classes_env_A_const_36.GetRawRoot__O(); var linked_132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_131, aot_arbace_core.A_arbace_core_requiring_resolve_A_fn_class); var ifn_133 lang.IFn; if linked_132 == nil { ifn_133 = lang.IFn_Cast(root_131) } else { ifn_133 = nil }; var arg_134 any = A_arbace_classes_env_A_const_38; if linked_132 == nil { tmp2 = ifn_133.Invoke_O__O(arg_134) } else { tmp2 = linked_132.(*aot_arbace_core.A_arbace_core_requiring_resolve_A).Invoke_O_O__O(root_131, arg_134) }; return lang.IFn_Cast(tmp2).Invoke_O__O(c__0) } else {
//line :118:1
			return lang.PersistentArrayMap_EMPTY.Ref()
		}
}

func A_arbace_classes_env_coerce_const_A_New() *A_arbace_classes_env_coerce_const_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_coerce_const_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_classes_env_coerce_const_A) Ctor() {}
//line :122:1
func (t *A_arbace_classes_env_coerce_const_A) Invoke_O_O_O__O(self, desc__0, v__1 any) any { var G__28000023__3_ any = desc__0; switch
												lang.Util_Hash_O__I_NoInit(G__28000023__3_) { case 66: if lang.Util_Equiv_O_O__Z_NoInit(G__28000023__3_, Lit_7) {



		return jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_ByteCast_O__B_NoInit(v__1)).Ref() }
//line :123:1
	case 67: if lang.Util_Equiv_O_O__Z_NoInit(G__28000023__3_, Lit_8) {

		return jrt.Character_ValueOf_C__Character_NoInit(lang.RT_CharCast_I__C_NoInit(lang.RT_IntCast_O__I_NoInit(v__1))).Ref() }
//line :123:1
	case 83: if lang.Util_Equiv_O_O__Z_NoInit(G__28000023__3_, Lit_9) {


		return jrt.Short_ValueOf_S__Short_NoInit(lang.RT_ShortCast_O__S_NoInit(v__1)).Ref() }
//line :123:1
	case 90: if lang.Util_Equiv_O_O__Z_NoInit(G__28000023__3_, Lit_10) {
		var root_136 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(v__1))).Ref(); if linked_137 == nil { return ifn_138.Invoke_O__O(arg_139) } else { return linked_137.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_136, arg_139) } }
//line :123:1
	default:}; return v__1 }












func A_arbace_classes_env_inner_member_QMARK__A_New() *A_arbace_classes_env_inner_member_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_inner_member_QMARK__A{}; t.Ctor(); return t }
//line :136:1
func (t *A_arbace_classes_env_inner_member_QMARK__A) Ctor() {}
//line :136:1
func (t *A_arbace_classes_env_inner_member_QMARK__A) Invoke_O_O__O(self, c__0 any) any {
	var tmp1 any; var and__1927000168__auto____2 any = jrt.NN(jrt.Class_Cast(c__0)).GetDeclaringClass__Class().Ref(); if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_140 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_140, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_142 lang.IFn; if linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var arg_143 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Modifier_IsStatic_I__Z(jrt.NN(jrt.Class_Cast(c__0)).GetModifiers__I())).Ref(); if linked_141 == nil { and__1927000168__auto____3 = ifn_142.Invoke_O__O(arg_143) } else { and__1927000168__auto____3 = linked_141.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_140, arg_143) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_144 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_144, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_146 lang.IFn
		if linked_145 == nil { ifn_146 = lang.IFn_Cast(root_144) } else { ifn_146 = nil }; var arg_147 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(c__0)).IsInterface__Z()).Ref(); if linked_145 == nil { and__1927000168__auto____4 = ifn_146.Invoke_O__O(arg_147) } else { and__1927000168__auto____4 = linked_145.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_144, arg_147) }
//line :137:1
		if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_148 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_148, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_150 lang.IFn
			if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(c__0)).IsEnum__Z()).Ref(); if linked_149 == nil { and__1927000168__auto____5 = ifn_150.Invoke_O__O(arg_151) } else { and__1927000168__auto____5 = linked_149.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_148, arg_151) }
//line :137:1
			if jrt.J2g_Truth(and__1927000168__auto____5) {
				var root_152 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_154 lang.IFn; if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(c__0)).IsRecord__Z()).Ref(); if linked_153 == nil { tmp1 = ifn_154.Invoke_O__O(arg_155) } else { tmp1 = linked_153.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_152, arg_155) } } else {
//line :137:1
					tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}

func A_arbace_classes_env_reflect_info_A_New() *A_arbace_classes_env_reflect_info_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_A{}; t.Ctor(); return t }
//line :140:1
func (t *A_arbace_classes_env_reflect_info_A) Ctor() {}
//line :140:1
func (t *A_arbace_classes_env_reflect_info_A) Invoke_O_O__O(self, c__0 any) any { var or__1927000174__auto____2 any = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_40.GetRawRoot__O())).Get_O__O(c__0); if
										jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var lockee__1927000360__auto____3 any = A_arbace_classes_env_A_const_40.GetRawRoot__O(); var locklocal__1927000361__auto____6 any = lockee__1927000360__auto____3; lang.Compiler_Evaluator_MonitorEnter_O__V_NoInit(locklocal__1927000361__auto____6); var tmp1 any; tmp44 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var or__1927000174__auto____9 any = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_40.GetRawRoot__O())).Get_O__O(c__0)

		if jrt.J2g_Truth(or__1927000174__auto____9) { tmp1 = or__1927000174__auto____9 } else { var n__10 any; var root_156 any = A_arbace_classes_env_A_const_34.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, A_arbace_classes_env_internal_A_fn_class); var ifn_158 lang.IFn
			if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = c__0; if linked_157 == nil { n__10 = ifn_158.Invoke_O__O(arg_159) } else { n__10 = linked_157.(*A_arbace_classes_env_internal_A).Invoke_O_O__O(root_156, arg_159) }
//line :143:1
			var manns__11 any; var tmp2 any = A_arbace_classes_env_reflect_info_fn__28000027_A_New_O(c__0); var tmp3 *jrt.Class
			var fncls__164 /*line :143:1*/*jrt.Class = A_arbace_classes_env_reflect_info_fn__28000027_A_fn_class

			if fncls__164 == nil { var fncls__164d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_classes_env_reflect_info_fn__28000027_A_fn_class = fncls__164d; tmp3 = fncls__164d } else { tmp3 = fncls__164 }
//line :143:1
			manns__11 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var info__12 any; var tmp4 any = A_arbace_classes_env_A_const_42; var tmp5 any = A_arbace_classes_env_A_const_43; var tmp6 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Class_Cast(c__0)).GetModifiers__I()).Ref(); var tmp7 any = A_arbace_classes_env_A_const_44; var tmp8 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(c__0)).IsInterface__Z()).Ref(); var tmp9 any = A_arbace_classes_env_A_const_45; var tmp10 any; var G__28000029__12_ any = jrt.NN(jrt.Class_Cast(c__0)).GetSuperclass__Class().Ref()





			if lang.Util_Identical_O_O__Z_NoInit(G__28000029__12_, nil) { tmp10 = nil } else { var root_165 any = A_arbace_classes_env_A_const_34.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, A_arbace_classes_env_internal_A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = G__28000029__12_; if linked_166 == nil { tmp10 = ifn_167.Invoke_O__O(arg_168) } else { tmp10 = linked_166.(*A_arbace_classes_env_internal_A).Invoke_O_O__O(root_165, arg_168) } }
//line :143:1
			var tmp11 any = tmp10; var tmp12 any = A_arbace_classes_env_A_const_46; var tmp13 any; var root_169 any = A_arbace_classes_env_A_const_47.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_169, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_171 lang.IFn






			if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = A_arbace_classes_env_A_const_34.GetRawRoot__O(); var arg_173 any = jrt.NN(jrt.Class_Cast(c__0)).GetInterfaces__Class1().Ref(); if linked_170 == nil { tmp13 = ifn_171.Invoke_O_O__O(arg_172, arg_173) } else { tmp13 = linked_170.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_169, arg_172, arg_173) }
//line :143:1
			var tmp14 any = tmp13; var tmp15 any = A_arbace_classes_env_A_const_48; var tmp16 any; var root_174 any = A_arbace_classes_env_A_const_34.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, A_arbace_classes_env_internal_A_fn_class); var ifn_176 lang.IFn







			if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any = jrt.NN(jrt.Class_Cast(c__0)).GetNestHost__Class().Ref(); if linked_175 == nil { tmp16 = ifn_176.Invoke_O__O(arg_177) } else { tmp16 = linked_175.(*A_arbace_classes_env_internal_A).Invoke_O_O__O(root_174, arg_177) }
//line :143:1
			var tmp17 any = tmp16; var tmp18 any = A_arbace_classes_env_A_const_49; var tmp19 any; var G__28000030__12_ any = jrt.NN(jrt.Class_Cast(c__0)).GetDeclaringClass__Class().Ref()








			if lang.Util_Identical_O_O__Z_NoInit(G__28000030__12_, nil) { tmp19 = nil } else { var root_178 any = A_arbace_classes_env_A_const_34.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, A_arbace_classes_env_internal_A_fn_class); var ifn_180 lang.IFn; if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any = G__28000030__12_; if linked_179 == nil { tmp19 = ifn_180.Invoke_O__O(arg_181) } else { tmp19 = linked_179.(*A_arbace_classes_env_internal_A).Invoke_O_O__O(root_178, arg_181) } }
//line :143:1
			var tmp20 any = tmp19; var tmp21 any = A_arbace_classes_env_A_const_50; var tmp22 any; var temp__1927000408__auto____12 any; var root_182 any = A_arbace_classes_env_A_const_51.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, A_arbace_classes_env_read_fields_A_fn_class); var ifn_184 lang.IFn









			if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = c__0; if linked_183 == nil { temp__1927000408__auto____12 = ifn_184.Invoke_O__O(arg_185) } else { temp__1927000408__auto____12 = linked_183.(*A_arbace_classes_env_read_fields_A).Invoke_O_O__O(root_182, arg_185) }; if jrt.J2g_Truth(temp__1927000408__auto____12) { var fs__13 any = temp__1927000408__auto____12; var root_186 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_188 lang.IFn
				if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any; var iter__1927001039__auto____14 any; var tmp23 any = A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_New_O(n__10); var tmp24 *jrt.Class; var fncls__306 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_fn_class; if fncls__306 == nil { var fncls__306d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_fn_class = fncls__306d; tmp24 = fncls__306d } else { tmp24 = fncls__306 }; iter__1927001039__auto____14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil); arg_189 = lang.IFn_Cast(iter__1927001039__auto____14).Invoke_O__O(fs__13); if linked_187 == nil { tmp22 = ifn_188.Invoke_O__O(arg_189) } else { tmp22 = linked_187.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_186, arg_189) } } else {




					var root_307 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_307, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_309 lang.IFn; if linked_308 == nil { ifn_309 = lang.IFn_Cast(root_307) } else { ifn_309 = nil }; var arg_310 any; var iter__1927001039__auto____13 any; var tmp25 any = A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_New_O(n__10); var tmp26 *jrt.Class; var fncls__377 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_fn_class; if fncls__377 == nil { var fncls__377d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_fn_class = fncls__377d; tmp26 = fncls__377d } else { tmp26 = fncls__377 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil); arg_310 = lang.IFn_Cast(iter__1927001039__auto____13).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetDeclaredFields__Field1().Ref()); if linked_308 == nil { tmp22 = ifn_309.Invoke_O__O(arg_310) } else { tmp22 = linked_308.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_307, arg_310) } }
//line :143:1
			var tmp27 any = tmp22; var tmp28 any = A_arbace_classes_env_A_const_74; var tmp29 any; var root_378 any = A_arbace_classes_env_A_const_75.GetRawRoot__O(); var linked_379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_378, A_arbace_classes_env_inner_member_QMARK__A_fn_class); var ifn_380 lang.IFn



















			if linked_379 == nil { ifn_380 = lang.IFn_Cast(root_378) } else { ifn_380 = nil }; var arg_381 any = c__0; if linked_379 == nil { tmp29 = ifn_380.Invoke_O__O(arg_381) } else { tmp29 = linked_379.(*A_arbace_classes_env_inner_member_QMARK__A).Invoke_O_O__O(root_378, arg_381) }
//line :143:1
			var tmp30 any = tmp29; var tmp31 any = A_arbace_classes_env_A_const_76; var tmp32 any; var root_382 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_382, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_384 lang.IFn




















			if linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; var arg_385 any; var root_386 any = A_arbace_classes_env_A_const_77.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_386, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_388 lang.IFn; if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any; var iter__1927001039__auto____12 any; var tmp33 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_New_O_O(n__10, manns__11); var tmp34 *jrt.Class; var fncls__539 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_fn_class
			if fncls__539 == nil { var fncls__539d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_fn_class = fncls__539d; tmp34 = fncls__539d } else { tmp34 = fncls__539 }; iter__1927001039__auto____12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil); arg_389 = lang.IFn_Cast(iter__1927001039__auto____12).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetDeclaredMethods__Method1().Ref())
//line :164:1
			var arg_390 any; var iter__1927001039__auto____12_2 any; var tmp35 any = A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_New_O_O(c__0, n__10); var tmp36 *jrt.Class
			var fncls__652 /*line :164:1*/*jrt.Class = A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_fn_class











			if fncls__652 == nil { var fncls__652d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_fn_class = fncls__652d; tmp36 = fncls__652d } else { tmp36 = fncls__652 }; iter__1927001039__auto____12_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp35, tmp36, nil); arg_390 = lang.IFn_Cast(iter__1927001039__auto____12_2).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetDeclaredConstructors__Constructor1().Ref())
//line :164:1
			if linked_387 == nil { arg_385 = ifn_388.Invoke_O_O__O(arg_389, arg_390) } else { arg_385 = linked_387.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_386, arg_389, arg_390) }; if linked_383 == nil { tmp32 = ifn_384.Invoke_O__O(arg_385) } else { tmp32 = linked_383.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_382, arg_385) }
//line :143:1
			info__12 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, n__10, tmp5, tmp6, tmp7, tmp8, tmp9, tmp11, tmp12, tmp14, tmp15, tmp17, tmp18, tmp20, tmp21, tmp27, tmp28, tmp30, tmp31, tmp32, A_arbace_classes_env_A_const_31, c__0)); var info__13 any; var tmp37 any; var and__1927000168__auto____13 any; var root_653 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_653, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_655 lang.IFn











































			if linked_654 == nil { ifn_655 = lang.IFn_Cast(root_653) } else { ifn_655 = nil }; var arg_656 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(c__0)).IsInterface__Z()).Ref(); if linked_654 == nil { and__1927000168__auto____13 = ifn_655.Invoke_O__O(arg_656) } else { and__1927000168__auto____13 = linked_654.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_653, arg_656) }; if jrt.J2g_Truth(and__1927000168__auto____13) { var root_657 any = A_arbace_classes_env_A_const_85.GetRawRoot__O(); var linked_658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_657, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_659 lang.IFn; if linked_658 == nil { ifn_659 = lang.IFn_Cast(root_657) } else { ifn_659 = nil }; var arg_660 any; var root_661 any = A_arbace_classes_env_A_const_86.GetRawRoot__O(); var linked_662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_661, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_663 lang.IFn; if linked_662 == nil { ifn_663 = lang.IFn_Cast(root_661) } else { ifn_663 = nil }; var arg_664 any; var tmp38 any = A_arbace_classes_env_reflect_info_fn__28000089_A_New(); var tmp39 *jrt.Class; var fncls__666 *jrt.Class = A_arbace_classes_env_reflect_info_fn__28000089_A_fn_class; if fncls__666 == nil { var fncls__666d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_classes_env_reflect_info_fn__28000089_A_fn_class = fncls__666d; tmp39 = fncls__666d } else { tmp39 = fncls__666 }; arg_664 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp38, tmp39, nil); var arg_665 any = A_arbace_classes_env_A_const_76.Invoke_O__O(info__12); if linked_662 == nil { arg_660 = ifn_663.Invoke_O_O__O(arg_664, arg_665) } else { arg_660 = linked_662.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_661, arg_664, arg_665) }; if linked_658 == nil { tmp37 = ifn_659.Invoke_O__O(arg_660) } else { tmp37 = linked_658.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_657, arg_660) } } else { tmp37 = and__1927000168__auto____13 }; if jrt.J2g_Truth(tmp37) {
				var root_667 any = A_arbace_classes_env_A_const_16.GetRawRoot__O(); var linked_668 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_667, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_669 lang.IFn; if linked_668 == nil { ifn_669 = lang.IFn_Cast(root_667) } else { ifn_669 = nil }; var arg_670 any = info__12; var arg_671 any = A_arbace_classes_env_A_const_76; var arg_672 any = A_arbace_classes_env_A_const_87.GetRawRoot__O(); var arg_673 any; var iter__1927001039__auto____13_2 any; var tmp40 any = A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_New_O(n__10); var tmp41 *jrt.Class; var fncls__732 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_fn_class; if fncls__732 == nil { var fncls__732d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_fn_class = fncls__732d; tmp41 = fncls__732d } else { tmp41 = fncls__732 }; iter__1927001039__auto____13_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp40, tmp41, nil); var tmp42 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____13_2); var tmp43 any; var root_733 any = A_arbace_classes_env_A_const_36.GetRawRoot__O(); var linked_734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_733, aot_arbace_core.A_arbace_core_requiring_resolve_A_fn_class); var ifn_735 lang.IFn; if linked_734 == nil { ifn_735 = lang.IFn_Cast(root_733) } else { ifn_735 = nil }; var arg_736 any = A_arbace_classes_env_A_const_88; if linked_734 == nil { tmp43 = ifn_735.Invoke_O__O(arg_736) } else { tmp43 = linked_734.(*aot_arbace_core.A_arbace_core_requiring_resolve_A).Invoke_O_O__O(root_733, arg_736) }; arg_673 = tmp42.Invoke_O__O(lang.IFn_Cast(tmp43).Invoke_O__O(n__10)); if linked_668 == nil { info__13 = ifn_669.Invoke_O_O_O_O__O(arg_670, arg_671, arg_672, arg_673) } else { info__13 = linked_668.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_667, arg_670, arg_671, arg_672, arg_673) } } else {
//line :187:1
					info__13 = info__12
				}


			jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_40.GetRawRoot__O())).Put_O_O__O(c__0, info__13)
//line :143:1
			tmp1 = info__13 } }; return nil }()
//line :141:1
		lang.Compiler_Evaluator_MonitorExit_O__V_NoInit(locklocal__1927000361__auto____6); if tmp44 != nil { panic(tmp44) }; return tmp1 } }



func A_arbace_classes_env_reflect_info_fn__28000027_A_New_O(p0 any) *A_arbace_classes_env_reflect_info_fn__28000027_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_fn__28000027_A{}; t.Ctor_O(p0); return t }
//line :145:1
func (t *A_arbace_classes_env_reflect_info_fn__28000027_A) Ctor_O(c__c any) { t.F_c = c__c }
//line :145:1
func (t *A_arbace_classes_env_reflect_info_fn__28000027_A) Invoke_O__O(self any) any { var root_160 any = A_arbace_classes_env_A_const_41.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, A_arbace_classes_env_read_method_annotations_A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any; var t_ any = t.F_c; t.F_c = nil; arg_163 = t_; if linked_161 == nil { return ifn_162.Invoke_O__O(arg_163) } else { return linked_161.(*A_arbace_classes_env_read_method_annotations_A).Invoke_O_O__O(root_160, arg_163) } }








func A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_New_O(p0 any) *A_arbace_classes_env_reflect_info_iter__28000031__28000035_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000031__28000035_A{}; t.Ctor_O(p0); return t }
//line :154:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :154:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_A) Invoke_O_O__O(self, s__28000032__1 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_New_O_O_O(t.F_n, s__28000032__1, self); var tmp2 *jrt.Class; var fncls__305 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_fn_class; if fncls__305 == nil { var fncls__305d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_fn_class = fncls__305d; tmp2 = fncls__305d } else { tmp2 = fncls__305 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :154:1
func A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :154:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A) Ctor_O_O_O(c__n, c__s__28000032, c__iter__28000031 any) { t.F_n = c__n; t.F_s__28000032 = c__s__28000032; t.F_iter__28000031 = c__iter__28000031 }
//line :154:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A) Invoke_O__O(self any) any { { var s__28000032__1 any; var t_ any = t.F_s__28000032; t.F_s__28000032 = nil; s__28000032__1 = t_; for { var temp__1927000414__auto____2 any; var root_190 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = s__28000032__1; if linked_191 == nil { temp__1927000414__auto____2 = ifn_192.Invoke_O__O(arg_193) } else { temp__1927000414__auto____2 = linked_191.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_190, arg_193) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__28000032__3 any = temp__1927000414__auto____2; var tmp1 any; var root_194 any = A_arbace_classes_env_A_const_54.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_194, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_196 lang.IFn; if linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any = s__28000032__3; if linked_195 == nil { tmp1 = ifn_196.Invoke_O__O(arg_197) } else { tmp1 = linked_195.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_194, arg_197) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_198 any = A_arbace_classes_env_A_const_55.GetRawRoot__O(); var linked_199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_198, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_200 lang.IFn; if linked_199 == nil { ifn_200 = lang.IFn_Cast(root_198) } else { ifn_200 = nil }; var arg_201 any = s__28000032__3; if linked_199 == nil { c__1927001037__auto____4 = ifn_200.Invoke_O__O(arg_201) } else { c__1927001037__auto____4 = linked_199.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_198, arg_201) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__28000034__6 any; var root_202 any = A_arbace_classes_env_A_const_56.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_204 lang.IFn; if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_203 == nil { b__28000034__6 = ifn_204.Invoke_O__O(arg_205) } else { b__28000034__6 = linked_203.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_202, arg_205) }; var tmp2 any = A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_New_O_O_I_O(b__28000034__6, t.F_n, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__240 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_fn_class; if fncls__240 == nil { var fncls__240d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_fn_class = fncls__240d; tmp3 = fncls__240d } else { tmp3 = fncls__240 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_241 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_241, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_243 lang.IFn; if linked_242 == nil { ifn_243 = lang.IFn_Cast(root_241) } else { ifn_243 = nil }; var arg_244 any; var root_246 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_248 lang.IFn; if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = b__28000034__6; if linked_247 == nil { arg_244 = ifn_248.Invoke_O__O(arg_249) } else { arg_244 = linked_247.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_246, arg_249) }; var arg_245 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__28000031); var tmp5 any; var root_250 any = A_arbace_classes_env_A_const_70.GetRawRoot__O(); var linked_251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_250, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_252 lang.IFn; if linked_251 == nil { ifn_252 = lang.IFn_Cast(root_250) } else { ifn_252 = nil }; var arg_253 any = s__28000032__3; if linked_251 == nil { tmp5 = ifn_252.Invoke_O__O(arg_253) } else { tmp5 = linked_251.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_250, arg_253) }; arg_245 = tmp4.Invoke_O__O(tmp5); if linked_242 == nil { return ifn_243.Invoke_O_O__O(arg_244, arg_245) } else { return linked_242.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_241, arg_244, arg_245) } } else { var root_254 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_256 lang.IFn; if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any; var root_259 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_259, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_261 lang.IFn; if linked_260 == nil { ifn_261 = lang.IFn_Cast(root_259) } else { ifn_261 = nil }; var arg_262 any = b__28000034__6; if linked_260 == nil { arg_257 = ifn_261.Invoke_O__O(arg_262) } else { arg_257 = linked_260.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_259, arg_262) }; var arg_258 any; if linked_255 == nil { return ifn_256.Invoke_O_O__O(arg_257, arg_258) } else { return linked_255.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_254, arg_257, arg_258) } } } else { var map__28000041__4 any; var root_263 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_263, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_265 lang.IFn; if linked_264 == nil { ifn_265 = lang.IFn_Cast(root_263) } else { ifn_265 = nil }; var arg_266 any = s__28000032__3; if linked_264 == nil { map__28000041__4 = ifn_265.Invoke_O__O(arg_266) } else { map__28000041__4 = linked_264.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_263, arg_266) }; var map__28000041__5 any; if lang.ISeq_InstanceOf(map__28000041__4) { var tmp6 any; var root_267 any = A_arbace_classes_env_A_const_57.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_267, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_269 lang.IFn; if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any = map__28000041__4; if linked_268 == nil { tmp6 = ifn_269.Invoke_O__O(arg_270) } else { tmp6 = linked_268.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_267, arg_270) }; if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_271 any = A_arbace_classes_env_A_const_58.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_273 lang.IFn; if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = map__28000041__4; if linked_272 == nil { tmp7 = ifn_273.Invoke_O__O(arg_274) } else { tmp7 = linked_272.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_271, arg_274) }; map__28000041__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp7, jrt.Object_class.ArrayClass())).Ref() } else { var tmp8 any; var root_275 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_275, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_277 lang.IFn; if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any = map__28000041__4; if linked_276 == nil { tmp8 = ifn_277.Invoke_O__O(arg_278) } else { tmp8 = linked_276.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_275, arg_278) }; if jrt.J2g_Truth(tmp8) { var root_279 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = map__28000041__4; if linked_280 == nil { map__28000041__5 = ifn_281.Invoke_O__O(arg_282) } else { map__28000041__5 = linked_280.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_279, arg_282) } } else { map__28000041__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__28000041__5 = map__28000041__4 }; var name__6 any = lang.RT_Get_O_O__O_NoInit(map__28000041__5, A_arbace_classes_env_A_const_42); var desc__7 any = lang.RT_Get_O_O__O_NoInit(map__28000041__5, A_arbace_classes_env_A_const_60); var flags__8 any = lang.RT_Get_O_O__O_NoInit(map__28000041__5, A_arbace_classes_env_A_const_43); var value__9 any = lang.RT_Get_O_O__O_NoInit(map__28000041__5, A_arbace_classes_env_A_const_61); var root_283 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_283, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_285 lang.IFn; if linked_284 == nil { ifn_285 = lang.IFn_Cast(root_283) } else { ifn_285 = nil }; var arg_286 any; var tmp9 any = A_arbace_classes_env_A_const_42; var tmp10 any = A_arbace_classes_env_A_const_60; var tmp11 any = A_arbace_classes_env_A_const_43; var tmp12 any = A_arbace_classes_env_A_const_63; var tmp13 any = t.F_n; var tmp14 any = A_arbace_classes_env_A_const_64; var tmp15 any; var tmp16 any; var and__1927000168__auto____10 bool = jrt.Modifier_IsFinal_I__Z(lang.RT_IntCast_O__I_NoInit(flags__8))

	if and__1927000168__auto____10 { var and__1927000168__auto____11 any; var root_288 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_288, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_290 lang.IFn; if linked_289 == nil { ifn_290 = lang.IFn_Cast(root_288) } else { ifn_290 = nil }; var arg_291 any = value__9; if linked_289 == nil { and__1927000168__auto____11 = ifn_290.Invoke_O__O(arg_291) } else { and__1927000168__auto____11 = linked_289.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_288, arg_291) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var or__1927000174__auto____12 any; var root_292 any = A_arbace_classes_env_A_const_65.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_292, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_294 lang.IFn
		if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any = desc__7; if linked_293 == nil { or__1927000174__auto____12 = ifn_294.Invoke_O__O(arg_295) } else { or__1927000174__auto____12 = linked_293.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_292, arg_295) }; if jrt.J2g_Truth(or__1927000174__auto____12) { tmp16 = or__1927000174__auto____12 } else { tmp16 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(desc__7, A_arbace_classes_env_A_const_66.GetRawRoot__O())).Ref() } } else {
//line :156:1
			tmp16 = and__1927000168__auto____11 } } else { tmp16 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10).Ref() }; if jrt.J2g_Truth(tmp16) {

				var root_296 any = A_arbace_classes_env_A_const_67.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, A_arbace_classes_env_coerce_const_A_fn_class); var ifn_298 lang.IFn; if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = desc__7; var arg_300 any = value__9; if linked_297 == nil { tmp15 = ifn_298.Invoke_O_O__O(arg_299, arg_300) } else { tmp15 = linked_297.(*A_arbace_classes_env_coerce_const_A).Invoke_O_O_O__O(root_296, arg_299, arg_300) } } else {
//line :156:1
					tmp15 = nil }
//line :154:1
	arg_286 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, name__6, tmp10, desc__7, tmp11, flags__8, tmp12, tmp13, tmp14, tmp15)); var arg_287 any; var tmp17 lang.IFn = lang.IFn_Cast(t.F_iter__28000031); var tmp18 any; var root_301 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_301, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_303 lang.IFn; if linked_302 == nil { ifn_303 = lang.IFn_Cast(root_301) } else { ifn_303 = nil }; var arg_304 any = s__28000032__3; if linked_302 == nil { tmp18 = ifn_303.Invoke_O__O(arg_304) } else { tmp18 = linked_302.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_301, arg_304) }; arg_287 = tmp17.Invoke_O__O(tmp18); if linked_284 == nil { return ifn_285.Invoke_O_O__O(arg_286, arg_287) } else { return linked_284.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_283, arg_286, arg_287) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :154:1
func A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :154:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A) Ctor_O_O_I_O(c__b__28000034, c__n any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__28000034 = c__b__28000034; t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :154:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A) Invoke_O__O(self any) any { { var i__28000033__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__28000033__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var map__28000038__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__28000033__1)); var map__28000038__3 any; if lang.ISeq_InstanceOf(map__28000038__2) { var tmp2 any; var root_206 any = A_arbace_classes_env_A_const_57.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_208 lang.IFn; if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any = map__28000038__2; if linked_207 == nil { tmp2 = ifn_208.Invoke_O__O(arg_209) } else { tmp2 = linked_207.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_206, arg_209) }; if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_210 any = A_arbace_classes_env_A_const_58.GetRawRoot__O(); var linked_211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_210, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_212 lang.IFn; if linked_211 == nil { ifn_212 = lang.IFn_Cast(root_210) } else { ifn_212 = nil }; var arg_213 any = map__28000038__2; if linked_211 == nil { tmp3 = ifn_212.Invoke_O__O(arg_213) } else { tmp3 = linked_211.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_210, arg_213) }; map__28000038__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp3, jrt.Object_class.ArrayClass())).Ref() } else { var tmp4 any; var root_214 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_214, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_216 lang.IFn; if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = map__28000038__2; if linked_215 == nil { tmp4 = ifn_216.Invoke_O__O(arg_217) } else { tmp4 = linked_215.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_214, arg_217) }; if jrt.J2g_Truth(tmp4) { var root_218 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_218, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_220 lang.IFn; if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any = map__28000038__2; if linked_219 == nil { map__28000038__3 = ifn_220.Invoke_O__O(arg_221) } else { map__28000038__3 = linked_219.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_218, arg_221) } } else { map__28000038__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__28000038__3 = map__28000038__2 }; var name__4 any = lang.RT_Get_O_O__O_NoInit(map__28000038__3, A_arbace_classes_env_A_const_42); var desc__5 any = lang.RT_Get_O_O__O_NoInit(map__28000038__3, A_arbace_classes_env_A_const_60); var flags__6 any = lang.RT_Get_O_O__O_NoInit(map__28000038__3, A_arbace_classes_env_A_const_43); var value__7 any = lang.RT_Get_O_O__O_NoInit(map__28000038__3, A_arbace_classes_env_A_const_61); var root_222 any = A_arbace_classes_env_A_const_62.GetRawRoot__O(); var linked_223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_222, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_224 lang.IFn; if linked_223 == nil { ifn_224 = lang.IFn_Cast(root_222) } else { ifn_224 = nil }; var arg_225 any = t.F_b__28000034; var arg_226 any; var tmp5 any = A_arbace_classes_env_A_const_42; var tmp6 any = A_arbace_classes_env_A_const_60; var tmp7 any = A_arbace_classes_env_A_const_43; var tmp8 any = A_arbace_classes_env_A_const_63; var tmp9 any = t.F_n; var tmp10 any = A_arbace_classes_env_A_const_64; var tmp11 any; var tmp12 any; var and__1927000168__auto____8 bool = jrt.Modifier_IsFinal_I__Z(lang.RT_IntCast_O__I_NoInit(flags__6))

	if and__1927000168__auto____8 { var and__1927000168__auto____9 any; var root_227 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_229 lang.IFn; if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any = value__7; if linked_228 == nil { and__1927000168__auto____9 = ifn_229.Invoke_O__O(arg_230) } else { and__1927000168__auto____9 = linked_228.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_227, arg_230) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var or__1927000174__auto____10 any; var root_231 any = A_arbace_classes_env_A_const_65.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_231, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_233 lang.IFn
		if linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any = desc__5; if linked_232 == nil { or__1927000174__auto____10 = ifn_233.Invoke_O__O(arg_234) } else { or__1927000174__auto____10 = linked_232.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_231, arg_234) }; if jrt.J2g_Truth(or__1927000174__auto____10) { tmp12 = or__1927000174__auto____10 } else { tmp12 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(desc__5, A_arbace_classes_env_A_const_66.GetRawRoot__O())).Ref() } } else {
//line :156:1
			tmp12 = and__1927000168__auto____9 } } else { tmp12 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() }; if jrt.J2g_Truth(tmp12) {

				var root_235 any = A_arbace_classes_env_A_const_67.GetRawRoot__O(); var linked_236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_235, A_arbace_classes_env_coerce_const_A_fn_class); var ifn_237 lang.IFn; if linked_236 == nil { ifn_237 = lang.IFn_Cast(root_235) } else { ifn_237 = nil }; var arg_238 any = desc__5; var arg_239 any = value__7; if linked_236 == nil { tmp11 = ifn_237.Invoke_O_O__O(arg_238, arg_239) } else { tmp11 = linked_236.(*A_arbace_classes_env_coerce_const_A).Invoke_O_O_O__O(root_235, arg_238, arg_239) } } else {
//line :156:1
					tmp11 = nil }
//line :154:1
	arg_226 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, name__4, tmp6, desc__5, tmp7, flags__6, tmp8, tmp9, tmp10, tmp11)); if linked_223 == nil { ifn_224.Invoke_O_O__O(arg_225, arg_226) } else { linked_223.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_222, arg_225, arg_226) }; i__28000033__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000033__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_New_O(p0 any) *A_arbace_classes_env_reflect_info_iter__28000045__28000049_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000045__28000049_A{}; t.Ctor_O(p0); return t }
//line :159:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :159:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_A) Invoke_O_O__O(self, s__28000046__1 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_New_O_O_O(t.F_n, s__28000046__1, self); var tmp2 *jrt.Class; var fncls__376 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_fn_class; if fncls__376 == nil { var fncls__376d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_fn_class = fncls__376d; tmp2 = fncls__376d } else { tmp2 = fncls__376 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :159:1
func A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :159:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A) Ctor_O_O_O(c__n, c__s__28000046, c__iter__28000045 any) { t.F_n = c__n; t.F_s__28000046 = c__s__28000046; t.F_iter__28000045 = c__iter__28000045 }
//line :159:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A) Invoke_O__O(self any) any { { var s__28000046__1 any; var t_ any = t.F_s__28000046; t.F_s__28000046 = nil; s__28000046__1 = t_; for { var temp__1927000414__auto____2 any; var root_311 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_311, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_313 lang.IFn; if linked_312 == nil { ifn_313 = lang.IFn_Cast(root_311) } else { ifn_313 = nil }; var arg_314 any = s__28000046__1; if linked_312 == nil { temp__1927000414__auto____2 = ifn_313.Invoke_O__O(arg_314) } else { temp__1927000414__auto____2 = linked_312.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_311, arg_314) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__28000046__3 any = temp__1927000414__auto____2; var tmp1 any; var root_315 any = A_arbace_classes_env_A_const_54.GetRawRoot__O(); var linked_316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_315, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_317 lang.IFn; if linked_316 == nil { ifn_317 = lang.IFn_Cast(root_315) } else { ifn_317 = nil }; var arg_318 any = s__28000046__3; if linked_316 == nil { tmp1 = ifn_317.Invoke_O__O(arg_318) } else { tmp1 = linked_316.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_315, arg_318) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_319 any = A_arbace_classes_env_A_const_55.GetRawRoot__O(); var linked_320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_319, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_321 lang.IFn; if linked_320 == nil { ifn_321 = lang.IFn_Cast(root_319) } else { ifn_321 = nil }; var arg_322 any = s__28000046__3; if linked_320 == nil { c__1927001037__auto____4 = ifn_321.Invoke_O__O(arg_322) } else { c__1927001037__auto____4 = linked_320.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_319, arg_322) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__28000048__6 any; var root_323 any = A_arbace_classes_env_A_const_56.GetRawRoot__O(); var linked_324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_323, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_325 lang.IFn; if linked_324 == nil { ifn_325 = lang.IFn_Cast(root_323) } else { ifn_325 = nil }; var arg_326 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_324 == nil { b__28000048__6 = ifn_325.Invoke_O__O(arg_326) } else { b__28000048__6 = linked_324.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_323, arg_326) }; var tmp2 any = A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_New_O_O_I_O(t.F_n, b__28000048__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__336 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_fn_class; if fncls__336 == nil { var fncls__336d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_fn_class = fncls__336d; tmp3 = fncls__336d } else { tmp3 = fncls__336 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_337 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_337, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_339 lang.IFn; if linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any; var root_342 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = b__28000048__6; if linked_343 == nil { arg_340 = ifn_344.Invoke_O__O(arg_345) } else { arg_340 = linked_343.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_342, arg_345) }; var arg_341 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__28000045); var tmp5 any; var root_346 any = A_arbace_classes_env_A_const_70.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_346, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_348 lang.IFn; if linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any = s__28000046__3; if linked_347 == nil { tmp5 = ifn_348.Invoke_O__O(arg_349) } else { tmp5 = linked_347.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_346, arg_349) }; arg_341 = tmp4.Invoke_O__O(tmp5); if linked_338 == nil { return ifn_339.Invoke_O_O__O(arg_340, arg_341) } else { return linked_338.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_337, arg_340, arg_341) } } else { var root_350 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any; var root_355 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_355, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_357 lang.IFn; if linked_356 == nil { ifn_357 = lang.IFn_Cast(root_355) } else { ifn_357 = nil }; var arg_358 any = b__28000048__6; if linked_356 == nil { arg_353 = ifn_357.Invoke_O__O(arg_358) } else { arg_353 = linked_356.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_355, arg_358) }; var arg_354 any; if linked_351 == nil { return ifn_352.Invoke_O_O__O(arg_353, arg_354) } else { return linked_351.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_350, arg_353, arg_354) } } } else { var f__4 any; var root_359 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_361 lang.IFn; if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any = s__28000046__3; if linked_360 == nil { f__4 = ifn_361.Invoke_O__O(arg_362) } else { f__4 = linked_360.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_359, arg_362) }; var root_363 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_363, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_365 lang.IFn; if linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any; var tmp6 any = A_arbace_classes_env_A_const_42; var tmp7 any = jrt.NN(jrt.Field_Cast(f__4)).GetName__String().Ref(); var tmp8 any = A_arbace_classes_env_A_const_60; var tmp9 any; var root_368 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var linked_369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_368, aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A_fn_class); var ifn_370 lang.IFn
														if linked_369 == nil { ifn_370 = lang.IFn_Cast(root_368) } else { ifn_370 = nil }; var arg_371 any = jrt.NN(jrt.Field_Cast(f__4)).GetType__Class().Ref(); if linked_369 == nil { tmp9 = ifn_370.Invoke_O__O(arg_371) } else { tmp9 = linked_369.(*aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A).Invoke_O_O__O(root_368, arg_371) }
//line :159:1
	var tmp10 any = tmp9; var tmp11 any = A_arbace_classes_env_A_const_43; arg_366 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7, tmp8, tmp10, tmp11, jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Field_Cast(f__4)).GetModifiers__I()).Ref(), A_arbace_classes_env_A_const_63, t.F_n, A_arbace_classes_env_A_const_64, nil)); var arg_367 any; var tmp12 lang.IFn = lang.IFn_Cast(t.F_iter__28000045); var tmp13 any; var root_372 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_372, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_374 lang.IFn; if linked_373 == nil { ifn_374 = lang.IFn_Cast(root_372) } else { ifn_374 = nil }; var arg_375 any = s__28000046__3; if linked_373 == nil { tmp13 = ifn_374.Invoke_O__O(arg_375) } else { tmp13 = linked_373.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_372, arg_375) }; arg_367 = tmp12.Invoke_O__O(tmp13); if linked_364 == nil { return ifn_365.Invoke_O_O__O(arg_366, arg_367) } else { return linked_364.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_363, arg_366, arg_367) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :159:1
func A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :159:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A) Ctor_O_O_I_O(c__n, c__b__28000048 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__28000048 = c__b__28000048; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :159:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A) Invoke_O__O(self any) any { { var i__28000047__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__28000047__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__28000047__1)); var root_327 any = A_arbace_classes_env_A_const_62.GetRawRoot__O(); var linked_328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_327, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_329 lang.IFn; if linked_328 == nil { ifn_329 = lang.IFn_Cast(root_327) } else { ifn_329 = nil }; var arg_330 any = t.F_b__28000048; var arg_331 any; var tmp2 any = A_arbace_classes_env_A_const_42; var tmp3 any = jrt.NN(jrt.Field_Cast(f__2)).GetName__String().Ref(); var tmp4 any = A_arbace_classes_env_A_const_60; var tmp5 any; var root_332 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var linked_333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_332, aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A_fn_class); var ifn_334 lang.IFn
																if linked_333 == nil { ifn_334 = lang.IFn_Cast(root_332) } else { ifn_334 = nil }; var arg_335 any = jrt.NN(jrt.Field_Cast(f__2)).GetType__Class().Ref(); if linked_333 == nil { tmp5 = ifn_334.Invoke_O__O(arg_335) } else { tmp5 = linked_333.(*aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A).Invoke_O_O__O(root_332, arg_335) }
//line :159:1
	var tmp6 any = tmp5; var tmp7 any = A_arbace_classes_env_A_const_43; arg_331 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, tmp6, tmp7, jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Field_Cast(f__2)).GetModifiers__I()).Ref(), A_arbace_classes_env_A_const_63, t.F_n, A_arbace_classes_env_A_const_64, nil)); if linked_328 == nil { ifn_329.Invoke_O_O__O(arg_330, arg_331) } else { linked_328.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_327, arg_330, arg_331) }; i__28000047__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000047__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_New_O_O(p0, p1 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_A{}; t.Ctor_O_O(p0, p1); return t }
//line :165:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_A) Ctor_O_O(c__n, c__manns any) { t.F_n = c__n; t.F_manns = c__manns }
//line :165:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_A) Invoke_O_O__O(self, s__28000056__1 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_New_O_O_O_O(t.F_n, t.F_manns, s__28000056__1, self); var tmp2 *jrt.Class; var fncls__538 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_fn_class; if fncls__538 == nil { var fncls__538d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_fn_class = fncls__538d; tmp2 = fncls__538d } else { tmp2 = fncls__538 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :165:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :165:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A) Ctor_O_O_O_O(c__n, c__manns, c__s__28000056, c__iter__28000055 any) { t.F_n = c__n; t.F_manns = c__manns; t.F_s__28000056 = c__s__28000056; t.F_iter__28000055 = c__iter__28000055 }
//line :165:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A) Invoke_O__O(self any) any { { var s__28000056__1 any; var t_ any = t.F_s__28000056; t.F_s__28000056 = nil; s__28000056__1 = t_; for { var temp__1927000414__auto____2 any; var root_391 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_391, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_393 lang.IFn; if linked_392 == nil { ifn_393 = lang.IFn_Cast(root_391) } else { ifn_393 = nil }; var arg_394 any = s__28000056__1; if linked_392 == nil { temp__1927000414__auto____2 = ifn_393.Invoke_O__O(arg_394) } else { temp__1927000414__auto____2 = linked_392.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_391, arg_394) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__28000056__3 any = temp__1927000414__auto____2; var tmp1 any; var root_395 any = A_arbace_classes_env_A_const_54.GetRawRoot__O(); var linked_396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_395, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_397 lang.IFn; if linked_396 == nil { ifn_397 = lang.IFn_Cast(root_395) } else { ifn_397 = nil }; var arg_398 any = s__28000056__3; if linked_396 == nil { tmp1 = ifn_397.Invoke_O__O(arg_398) } else { tmp1 = linked_396.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_395, arg_398) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_399 any = A_arbace_classes_env_A_const_55.GetRawRoot__O(); var linked_400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_399, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_401 lang.IFn; if linked_400 == nil { ifn_401 = lang.IFn_Cast(root_399) } else { ifn_401 = nil }; var arg_402 any = s__28000056__3; if linked_400 == nil { c__1927001037__auto____4 = ifn_401.Invoke_O__O(arg_402) } else { c__1927001037__auto____4 = linked_400.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_399, arg_402) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__28000058__6 any; var root_403 any = A_arbace_classes_env_A_const_56.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_403, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_405 lang.IFn; if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_404 == nil { b__28000058__6 = ifn_405.Invoke_O__O(arg_406) } else { b__28000058__6 = linked_404.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_403, arg_406) }; var tmp2 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_New_O_O_O_I_O(t.F_n, b__28000058__6, t.F_manns, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__457 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_fn_class; if fncls__457 == nil { var fncls__457d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_fn_class = fncls__457d; tmp3 = fncls__457d } else { tmp3 = fncls__457 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_458 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any; var root_463 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_463, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_465 lang.IFn; if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any = b__28000058__6; if linked_464 == nil { arg_461 = ifn_465.Invoke_O__O(arg_466) } else { arg_461 = linked_464.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_463, arg_466) }; var arg_462 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__28000055); var tmp5 any; var root_467 any = A_arbace_classes_env_A_const_70.GetRawRoot__O(); var linked_468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_467, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_469 lang.IFn; if linked_468 == nil { ifn_469 = lang.IFn_Cast(root_467) } else { ifn_469 = nil }; var arg_470 any = s__28000056__3; if linked_468 == nil { tmp5 = ifn_469.Invoke_O__O(arg_470) } else { tmp5 = linked_468.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_467, arg_470) }; arg_462 = tmp4.Invoke_O__O(tmp5); if linked_459 == nil { return ifn_460.Invoke_O_O__O(arg_461, arg_462) } else { return linked_459.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_458, arg_461, arg_462) } } else { var root_471 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_471, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_473 lang.IFn; if linked_472 == nil { ifn_473 = lang.IFn_Cast(root_471) } else { ifn_473 = nil }; var arg_474 any; var root_476 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_476, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_478 lang.IFn; if linked_477 == nil { ifn_478 = lang.IFn_Cast(root_476) } else { ifn_478 = nil }; var arg_479 any = b__28000058__6; if linked_477 == nil { arg_474 = ifn_478.Invoke_O__O(arg_479) } else { arg_474 = linked_477.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_476, arg_479) }; var arg_475 any; if linked_472 == nil { return ifn_473.Invoke_O_O__O(arg_474, arg_475) } else { return linked_472.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_471, arg_474, arg_475) } } } else { var m__4 any; var root_480 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_480, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_482 lang.IFn; if linked_481 == nil { ifn_482 = lang.IFn_Cast(root_480) } else { ifn_482 = nil }; var arg_483 any = s__28000056__3; if linked_481 == nil { m__4 = ifn_482.Invoke_O__O(arg_483) } else { m__4 = linked_481.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_480, arg_483) }; var desc__5 any; var root_484 any = A_arbace_classes_env_A_const_78.GetRawRoot__O(); var linked_485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_484, aot_arbace_classes_types.A_arbace_classes_types_method_desc_A_fn_class); var ifn_486 lang.IFn
														if linked_485 == nil { ifn_486 = lang.IFn_Cast(root_484) } else { ifn_486 = nil }; var arg_487 any; var root_489 any = A_arbace_classes_env_A_const_79.GetRawRoot__O(); var linked_490 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_489, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_491 lang.IFn; if linked_490 == nil { ifn_491 = lang.IFn_Cast(root_489) } else { ifn_491 = nil }; var arg_492 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var arg_493 any = jrt.NN(jrt.Method_Cast(m__4)).GetParameterTypes__Class1().Ref(); if linked_490 == nil { arg_487 = ifn_491.Invoke_O_O__O(arg_492, arg_493) } else { arg_487 = linked_490.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_489, arg_492, arg_493) }; var arg_488 any; var root_494 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var linked_495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_494, aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A_fn_class); var ifn_496 lang.IFn
														if linked_495 == nil { ifn_496 = lang.IFn_Cast(root_494) } else { ifn_496 = nil }; var arg_497 any = jrt.NN(jrt.Method_Cast(m__4)).GetReturnType__Class().Ref(); if linked_495 == nil { arg_488 = ifn_496.Invoke_O__O(arg_497) } else { arg_488 = linked_495.(*aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A).Invoke_O_O__O(root_494, arg_497) }
//line :166:1
	if linked_485 == nil { desc__5 = ifn_486.Invoke_O_O__O(arg_487, arg_488) } else { desc__5 = linked_485.(*aot_arbace_classes_types.A_arbace_classes_types_method_desc_A).Invoke_O_O_O__O(root_484, arg_487, arg_488) }
//line :165:1
	var root_498 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any; var tmp6 any = A_arbace_classes_env_A_const_42; var tmp7 any = jrt.NN(jrt.Method_Cast(m__4)).GetName__String().Ref(); var tmp8 any = A_arbace_classes_env_A_const_60; var tmp9 any = A_arbace_classes_env_A_const_43; var tmp10 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Method_Cast(m__4)).GetModifiers__I()).Ref(); var tmp11 any = A_arbace_classes_env_A_const_63; var tmp12 any = t.F_n; var tmp13 any = A_arbace_classes_env_A_const_80; var tmp14 any; var root_503 any = A_arbace_classes_env_A_const_47.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_505 lang.IFn





	if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any = A_arbace_classes_env_A_const_34.GetRawRoot__O(); var arg_507 any = jrt.NN(jrt.Method_Cast(m__4)).GetExceptionTypes__Class1().Ref(); if linked_504 == nil { tmp14 = ifn_505.Invoke_O_O__O(arg_506, arg_507) } else { tmp14 = linked_504.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_503, arg_506, arg_507) }
//line :165:1
	var tmp15 any = tmp14; var tmp16 any = A_arbace_classes_env_A_const_81; var tmp17 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_New_O_O_O(m__4, desc__5, t.F_manns); var tmp18 *jrt.Class
	var fncls__517 /*line :165:1*/*jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_fn_class






	if fncls__517 == nil { var fncls__517d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_fn_class = fncls__517d; tmp18 = fncls__517d } else { tmp18 = fncls__517 }
//line :165:1
	var tmp19 any = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil)); var tmp20 any = A_arbace_classes_env_A_const_83; var tmp21 any; var root_518 any = A_arbace_classes_env_A_const_84.GetRawRoot__O(); var linked_519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_518, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_520 lang.IFn







	if linked_519 == nil { ifn_520 = lang.IFn_Cast(root_518) } else { ifn_520 = nil }; var arg_521 any; var tmp22 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_New_O_O_O(m__4, desc__5, t.F_manns); var tmp23 *jrt.Class; var fncls__533 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_fn_class
	if fncls__533 == nil { var fncls__533d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_fn_class = fncls__533d; tmp23 = fncls__533d } else { tmp23 = fncls__533 }; arg_521 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil)
//line :173:1
	var arg_522 any = jrt.NN(jrt.Method_Cast(m__4)).GetParameterTypes__Class1().Ref(); if linked_519 == nil { tmp21 = ifn_520.Invoke_O_O__O(arg_521, arg_522) } else { tmp21 = linked_519.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_518, arg_521, arg_522) }
//line :165:1
	arg_501 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7, tmp8, desc__5, tmp9, tmp10, tmp11, tmp12, tmp13, tmp15, tmp16, tmp19, tmp20, tmp21)); var arg_502 any; var tmp24 lang.IFn = lang.IFn_Cast(t.F_iter__28000055); var tmp25 any; var root_534 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_534, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_536 lang.IFn; if linked_535 == nil { ifn_536 = lang.IFn_Cast(root_534) } else { ifn_536 = nil }; var arg_537 any = s__28000056__3; if linked_535 == nil { tmp25 = ifn_536.Invoke_O__O(arg_537) } else { tmp25 = linked_535.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_534, arg_537) }; arg_502 = tmp24.Invoke_O__O(tmp25); if linked_499 == nil { return ifn_500.Invoke_O_O__O(arg_501, arg_502) } else { return linked_499.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_498, arg_501, arg_502) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :165:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :165:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A) Ctor_O_O_O_I_O(c__n, c__b__28000058, c__manns any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__28000058 = c__b__28000058; t.F_manns = c__manns; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :165:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A) Invoke_O__O(self any) any { { var i__28000057__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__28000057__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__28000057__1)); var desc__3 any; var root_407 any = A_arbace_classes_env_A_const_78.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_407, aot_arbace_classes_types.A_arbace_classes_types_method_desc_A_fn_class); var ifn_409 lang.IFn
																if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any; var root_412 any = A_arbace_classes_env_A_const_79.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_414 lang.IFn; if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var arg_416 any = jrt.NN(jrt.Method_Cast(m__2)).GetParameterTypes__Class1().Ref(); if linked_413 == nil { arg_410 = ifn_414.Invoke_O_O__O(arg_415, arg_416) } else { arg_410 = linked_413.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_412, arg_415, arg_416) }; var arg_411 any; var root_417 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var linked_418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_417, aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A_fn_class); var ifn_419 lang.IFn
																if linked_418 == nil { ifn_419 = lang.IFn_Cast(root_417) } else { ifn_419 = nil }; var arg_420 any = jrt.NN(jrt.Method_Cast(m__2)).GetReturnType__Class().Ref(); if linked_418 == nil { arg_411 = ifn_419.Invoke_O__O(arg_420) } else { arg_411 = linked_418.(*aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A).Invoke_O_O__O(root_417, arg_420) }
//line :166:1
	if linked_408 == nil { desc__3 = ifn_409.Invoke_O_O__O(arg_410, arg_411) } else { desc__3 = linked_408.(*aot_arbace_classes_types.A_arbace_classes_types_method_desc_A).Invoke_O_O_O__O(root_407, arg_410, arg_411) }
//line :165:1
	var root_421 any = A_arbace_classes_env_A_const_62.GetRawRoot__O(); var linked_422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_421, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_423 lang.IFn; if linked_422 == nil { ifn_423 = lang.IFn_Cast(root_421) } else { ifn_423 = nil }; var arg_424 any = t.F_b__28000058; var arg_425 any; var tmp2 any = A_arbace_classes_env_A_const_42; var tmp3 any = jrt.NN(jrt.Method_Cast(m__2)).GetName__String().Ref(); var tmp4 any = A_arbace_classes_env_A_const_60; var tmp5 any = A_arbace_classes_env_A_const_43; var tmp6 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Method_Cast(m__2)).GetModifiers__I()).Ref(); var tmp7 any = A_arbace_classes_env_A_const_63; var tmp8 any = t.F_n; var tmp9 any = A_arbace_classes_env_A_const_80; var tmp10 any; var root_426 any = A_arbace_classes_env_A_const_47.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_426, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_428 lang.IFn





	if linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any = A_arbace_classes_env_A_const_34.GetRawRoot__O(); var arg_430 any = jrt.NN(jrt.Method_Cast(m__2)).GetExceptionTypes__Class1().Ref(); if linked_427 == nil { tmp10 = ifn_428.Invoke_O_O__O(arg_429, arg_430) } else { tmp10 = linked_427.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_426, arg_429, arg_430) }
//line :165:1
	var tmp11 any = tmp10; var tmp12 any = A_arbace_classes_env_A_const_81; var tmp13 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_New_O_O_O(m__2, desc__3, t.F_manns); var tmp14 *jrt.Class
	var fncls__440 /*line :165:1*/*jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_fn_class






	if fncls__440 == nil { var fncls__440d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_fn_class = fncls__440d; tmp14 = fncls__440d } else { tmp14 = fncls__440 }
//line :165:1
	var tmp15 any = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil)); var tmp16 any = A_arbace_classes_env_A_const_83; var tmp17 any; var root_441 any = A_arbace_classes_env_A_const_84.GetRawRoot__O(); var linked_442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_441, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_443 lang.IFn







	if linked_442 == nil { ifn_443 = lang.IFn_Cast(root_441) } else { ifn_443 = nil }; var arg_444 any; var tmp18 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_New_O_O_O(m__2, desc__3, t.F_manns); var tmp19 *jrt.Class; var fncls__456 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_fn_class
	if fncls__456 == nil { var fncls__456d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_fn_class = fncls__456d; tmp19 = fncls__456d } else { tmp19 = fncls__456 }; arg_444 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil)
//line :173:1
	var arg_445 any = jrt.NN(jrt.Method_Cast(m__2)).GetParameterTypes__Class1().Ref(); if linked_442 == nil { tmp17 = ifn_443.Invoke_O_O__O(arg_444, arg_445) } else { tmp17 = linked_442.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_441, arg_444, arg_445) }
//line :165:1
	arg_425 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, desc__3, tmp5, tmp6, tmp7, tmp8, tmp9, tmp11, tmp12, tmp15, tmp16, tmp17)); if linked_422 == nil { ifn_423.Invoke_O_O__O(arg_424, arg_425) } else { linked_422.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_421, arg_424, arg_425) }; i__28000057__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000057__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :172:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A) Ctor_O_O_O(c__m, c__desc, c__manns any) { t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :172:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A) Invoke_O__O(self any) any { var root_431 any = A_arbace_classes_env_A_const_82.GetRawRoot__O(); var linked_432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_431, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_433 lang.IFn; if linked_432 == nil { ifn_433 = lang.IFn_Cast(root_431) } else { ifn_433 = nil }; var arg_434 any; var root_436 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_436, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_438 lang.IFn; if linked_437 == nil { ifn_438 = lang.IFn_Cast(root_436) } else { ifn_438 = nil }; var arg_439 any; var t_ any = t.F_manns; t.F_manns = nil; arg_439 = t_; if linked_437 == nil { arg_434 = ifn_438.Invoke_O__O(arg_439) } else { arg_434 = linked_437.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_436, arg_439) }; var arg_435 any; var tmp1 any; var t__2 any = t.F_m; t.F_m = nil; tmp1 = t__2; var tmp2 any = jrt.NN(jrt.Method_Cast(tmp1)).GetName__String().Ref(); var tmp3 any; var t__3 any = t.F_desc; t.F_desc = nil; tmp3 = t__3; arg_435 = lang.Tuple_Create_O_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3), A_arbace_classes_env_A_const_81); if linked_432 == nil { return ifn_433.Invoke_O_O__O(arg_434, arg_435) } else { return linked_432.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_431, arg_434, arg_435) } }
//line :172:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :172:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A) Ctor_O_O_O(c__m, c__desc, c__manns any) { t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :172:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A) Invoke_O__O(self any) any { var root_508 any = A_arbace_classes_env_A_const_82.GetRawRoot__O(); var linked_509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_508, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_510 lang.IFn; if linked_509 == nil { ifn_510 = lang.IFn_Cast(root_508) } else { ifn_510 = nil }; var arg_511 any; var root_513 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_513, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_515 lang.IFn; if linked_514 == nil { ifn_515 = lang.IFn_Cast(root_513) } else { ifn_515 = nil }; var arg_516 any; var t_ any = t.F_manns; t.F_manns = nil; arg_516 = t_; if linked_514 == nil { arg_511 = ifn_515.Invoke_O__O(arg_516) } else { arg_511 = linked_514.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_513, arg_516) }; var arg_512 any; var tmp1 any; var t__2 any = t.F_m; t.F_m = nil; tmp1 = t__2; var tmp2 any = jrt.NN(jrt.Method_Cast(tmp1)).GetName__String().Ref(); var tmp3 any; var t__3 any = t.F_desc; t.F_desc = nil; tmp3 = t__3; arg_512 = lang.Tuple_Create_O_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3), A_arbace_classes_env_A_const_81); if linked_509 == nil { return ifn_510.Invoke_O_O__O(arg_511, arg_512) } else { return linked_509.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_508, arg_511, arg_512) } }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :174:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A) Ctor_O_O_O(c__m, c__desc, c__manns any) { t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :174:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A) Invoke_O_O_O__O(self, i__1, ___2 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_New_O_O_O_O(i__1, t.F_m, t.F_desc, t.F_manns); var tmp2 *jrt.Class; var fncls__455 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_fn_class; if fncls__455 == nil { var fncls__455d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_fn_class = fncls__455d; tmp2 = fncls__455d } else { tmp2 = fncls__455 }; return lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :174:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :174:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A) Ctor_O_O_O_O(c__i, c__m, c__desc, c__manns any) { t.F_i = c__i; t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :174:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A) Invoke_O__O(self any) any { var root_446 any = A_arbace_classes_env_A_const_82.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_448 lang.IFn; if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any; var root_451 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_451, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_453 lang.IFn; if linked_452 == nil { ifn_453 = lang.IFn_Cast(root_451) } else { ifn_453 = nil }; var arg_454 any; var t_ any = t.F_manns; t.F_manns = nil; arg_454 = t_; if linked_452 == nil { arg_449 = ifn_453.Invoke_O__O(arg_454) } else { arg_449 = linked_452.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_451, arg_454) }; var arg_450 any; var tmp1 any; var t__2 any = t.F_m; t.F_m = nil; tmp1 = t__2; var tmp2 any = jrt.NN(jrt.Method_Cast(tmp1)).GetName__String().Ref(); var tmp3 any; var t__3 any = t.F_desc; t.F_desc = nil; tmp3 = t__3; var tmp4 any = lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3); var tmp5 any = A_arbace_classes_env_A_const_83; var tmp6 any; var t__4 any = t.F_i; t.F_i = nil; tmp6 = t__4; arg_450 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp4, tmp5, tmp6); if linked_447 == nil { return ifn_448.Invoke_O_O__O(arg_449, arg_450) } else { return linked_447.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_446, arg_449, arg_450) } }
//line :174:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :174:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A) Ctor_O_O_O(c__m, c__desc, c__manns any) { t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :174:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A) Invoke_O_O_O__O(self, i__1, ___2 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_New_O_O_O_O(i__1, t.F_m, t.F_desc, t.F_manns); var tmp2 *jrt.Class; var fncls__532 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_fn_class; if fncls__532 == nil { var fncls__532d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_fn_class = fncls__532d; tmp2 = fncls__532d } else { tmp2 = fncls__532 }; return lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :174:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :174:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A) Ctor_O_O_O_O(c__i, c__m, c__desc, c__manns any) { t.F_i = c__i; t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :174:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A) Invoke_O__O(self any) any { var root_523 any = A_arbace_classes_env_A_const_82.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_523, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_525 lang.IFn; if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any; var root_528 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_528, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_530 lang.IFn; if linked_529 == nil { ifn_530 = lang.IFn_Cast(root_528) } else { ifn_530 = nil }; var arg_531 any; var t_ any = t.F_manns; t.F_manns = nil; arg_531 = t_; if linked_529 == nil { arg_526 = ifn_530.Invoke_O__O(arg_531) } else { arg_526 = linked_529.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_528, arg_531) }; var arg_527 any; var tmp1 any; var t__2 any = t.F_m; t.F_m = nil; tmp1 = t__2; var tmp2 any = jrt.NN(jrt.Method_Cast(tmp1)).GetName__String().Ref(); var tmp3 any; var t__3 any = t.F_desc; t.F_desc = nil; tmp3 = t__3; var tmp4 any = lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3); var tmp5 any = A_arbace_classes_env_A_const_83; var tmp6 any; var t__4 any = t.F_i; t.F_i = nil; tmp6 = t__4; arg_527 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp4, tmp5, tmp6); if linked_524 == nil { return ifn_525.Invoke_O_O__O(arg_526, arg_527) } else { return linked_524.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_523, arg_526, arg_527) } }

func A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_New_O_O(p0, p1 any) *A_arbace_classes_env_reflect_info_iter__28000077__28000081_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000077__28000081_A{}; t.Ctor_O_O(p0, p1); return t }
//line :176:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_A) Ctor_O_O(c__c, c__n any) { t.F_c = c__c; t.F_n = c__n }
//line :176:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_A) Invoke_O_O__O(self, s__28000078__1 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_New_O_O_O_O(t.F_c, t.F_n, s__28000078__1, self); var tmp2 *jrt.Class; var fncls__651 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_fn_class; if fncls__651 == nil { var fncls__651d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_fn_class = fncls__651d; tmp2 = fncls__651d } else { tmp2 = fncls__651 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :176:1
func A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :176:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A) Ctor_O_O_O_O(c__c, c__n, c__s__28000078, c__iter__28000077 any) { t.F_c = c__c; t.F_n = c__n; t.F_s__28000078 = c__s__28000078; t.F_iter__28000077 = c__iter__28000077 }
//line :176:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A) Invoke_O__O(self any) any { { var s__28000078__1 any; var t_ any = t.F_s__28000078; t.F_s__28000078 = nil; s__28000078__1 = t_; for { var temp__1927000414__auto____2 any; var root_540 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_540, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_542 lang.IFn; if linked_541 == nil { ifn_542 = lang.IFn_Cast(root_540) } else { ifn_542 = nil }; var arg_543 any = s__28000078__1; if linked_541 == nil { temp__1927000414__auto____2 = ifn_542.Invoke_O__O(arg_543) } else { temp__1927000414__auto____2 = linked_541.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_540, arg_543) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__28000078__3 any = temp__1927000414__auto____2; var tmp1 any; var root_544 any = A_arbace_classes_env_A_const_54.GetRawRoot__O(); var linked_545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_544, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_546 lang.IFn; if linked_545 == nil { ifn_546 = lang.IFn_Cast(root_544) } else { ifn_546 = nil }; var arg_547 any = s__28000078__3; if linked_545 == nil { tmp1 = ifn_546.Invoke_O__O(arg_547) } else { tmp1 = linked_545.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_544, arg_547) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_548 any = A_arbace_classes_env_A_const_55.GetRawRoot__O(); var linked_549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_548, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_550 lang.IFn; if linked_549 == nil { ifn_550 = lang.IFn_Cast(root_548) } else { ifn_550 = nil }; var arg_551 any = s__28000078__3; if linked_549 == nil { c__1927001037__auto____4 = ifn_550.Invoke_O__O(arg_551) } else { c__1927001037__auto____4 = linked_549.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_548, arg_551) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__28000080__6 any; var root_552 any = A_arbace_classes_env_A_const_56.GetRawRoot__O(); var linked_553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_552, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_554 lang.IFn; if linked_553 == nil { ifn_554 = lang.IFn_Cast(root_552) } else { ifn_554 = nil }; var arg_555 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_553 == nil { b__28000080__6 = ifn_554.Invoke_O__O(arg_555) } else { b__28000080__6 = linked_553.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_552, arg_555) }; var tmp2 any = A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_New_O_O_O_I_O(t.F_c, t.F_n, b__28000080__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__588 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_fn_class; if fncls__588 == nil { var fncls__588d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_fn_class = fncls__588d; tmp3 = fncls__588d } else { tmp3 = fncls__588 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_589 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_589, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_591 lang.IFn; if linked_590 == nil { ifn_591 = lang.IFn_Cast(root_589) } else { ifn_591 = nil }; var arg_592 any; var root_594 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_594, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_596 lang.IFn; if linked_595 == nil { ifn_596 = lang.IFn_Cast(root_594) } else { ifn_596 = nil }; var arg_597 any = b__28000080__6; if linked_595 == nil { arg_592 = ifn_596.Invoke_O__O(arg_597) } else { arg_592 = linked_595.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_594, arg_597) }; var arg_593 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__28000077); var tmp5 any; var root_598 any = A_arbace_classes_env_A_const_70.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_600 lang.IFn; if linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any = s__28000078__3; if linked_599 == nil { tmp5 = ifn_600.Invoke_O__O(arg_601) } else { tmp5 = linked_599.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_598, arg_601) }; arg_593 = tmp4.Invoke_O__O(tmp5); if linked_590 == nil { return ifn_591.Invoke_O_O__O(arg_592, arg_593) } else { return linked_590.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_589, arg_592, arg_593) } } else { var root_602 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_604 lang.IFn; if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any; var root_607 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_607, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_609 lang.IFn; if linked_608 == nil { ifn_609 = lang.IFn_Cast(root_607) } else { ifn_609 = nil }; var arg_610 any = b__28000080__6; if linked_608 == nil { arg_605 = ifn_609.Invoke_O__O(arg_610) } else { arg_605 = linked_608.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_607, arg_610) }; var arg_606 any; if linked_603 == nil { return ifn_604.Invoke_O_O__O(arg_605, arg_606) } else { return linked_603.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_602, arg_605, arg_606) } } } else { var m__4 any; var root_611 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_611, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_613 lang.IFn; if linked_612 == nil { ifn_613 = lang.IFn_Cast(root_611) } else { ifn_613 = nil }; var arg_614 any = s__28000078__3; if linked_612 == nil { m__4 = ifn_613.Invoke_O__O(arg_614) } else { m__4 = linked_612.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_611, arg_614) }; var root_615 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_615, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_617 lang.IFn; if linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any; var tmp6 any = A_arbace_classes_env_A_const_42; var tmp7 any = A_arbace_classes_env_A_const_60; var tmp8 any; var root_620 any = A_arbace_classes_env_A_const_78.GetRawRoot__O(); var linked_621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_620, aot_arbace_classes_types.A_arbace_classes_types_method_desc_A_fn_class); var ifn_622 lang.IFn

	if linked_621 == nil { ifn_622 = lang.IFn_Cast(root_620) } else { ifn_622 = nil }; var arg_623 any; var root_625 any = A_arbace_classes_env_A_const_79.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_625, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_627 lang.IFn; if linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var arg_629 any; var G__28000086__5_ any; var root_630 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_630, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_632 lang.IFn; if linked_631 == nil { ifn_632 = lang.IFn_Cast(root_630) } else { ifn_632 = nil }; var arg_633 any = jrt.NN(jrt.Constructor_Cast(m__4)).GetParameterTypes__Class1().Ref(); if linked_631 == nil { G__28000086__5_ = ifn_632.Invoke_O__O(arg_633) } else { G__28000086__5_ = linked_631.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_630, arg_633) }; var tmp9 any; var root_634 any = A_arbace_classes_env_A_const_75.GetRawRoot__O(); var linked_635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_634, A_arbace_classes_env_inner_member_QMARK__A_fn_class); var ifn_636 lang.IFn
	if linked_635 == nil { ifn_636 = lang.IFn_Cast(root_634) } else { ifn_636 = nil }; var arg_637 any = t.F_c; if linked_635 == nil { tmp9 = ifn_636.Invoke_O__O(arg_637) } else { tmp9 = linked_635.(*A_arbace_classes_env_inner_member_QMARK__A).Invoke_O_O__O(root_634, arg_637) }
//line :178:1
	if jrt.J2g_Truth(tmp9) { var root_638 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_638, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_640 lang.IFn; if linked_639 == nil { ifn_640 = lang.IFn_Cast(root_638) } else { ifn_640 = nil }; var arg_641 any = G__28000086__5_; if linked_639 == nil { arg_629 = ifn_640.Invoke_O__O(arg_641) } else { arg_629 = linked_639.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_638, arg_641) } } else { arg_629 = G__28000086__5_ }; if linked_626 == nil { arg_623 = ifn_627.Invoke_O_O__O(arg_628, arg_629) } else { arg_623 = linked_626.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_625, arg_628, arg_629) }; var arg_624 any = Lit_52; if linked_621 == nil { tmp8 = ifn_622.Invoke_O_O__O(arg_623, arg_624) } else { tmp8 = linked_621.(*aot_arbace_classes_types.A_arbace_classes_types_method_desc_A).Invoke_O_O_O__O(root_620, arg_623, arg_624) }
//line :176:1
	var tmp10 any = tmp8; var tmp11 any = A_arbace_classes_env_A_const_43; var tmp12 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Constructor_Cast(m__4)).GetModifiers__I()).Ref(); var tmp13 any = A_arbace_classes_env_A_const_63; var tmp14 any = t.F_n; var tmp15 any = A_arbace_classes_env_A_const_80; var tmp16 any; var root_642 any = A_arbace_classes_env_A_const_47.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_642, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_644 lang.IFn





	if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = A_arbace_classes_env_A_const_34.GetRawRoot__O(); var arg_646 any = jrt.NN(jrt.Constructor_Cast(m__4)).GetExceptionTypes__Class1().Ref(); if linked_643 == nil { tmp16 = ifn_644.Invoke_O_O__O(arg_645, arg_646) } else { tmp16 = linked_643.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_642, arg_645, arg_646) }
//line :176:1
	arg_618 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, Lit_13, tmp7, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16)); var arg_619 any; var tmp17 lang.IFn = lang.IFn_Cast(t.F_iter__28000077); var tmp18 any; var root_647 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_647, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_649 lang.IFn; if linked_648 == nil { ifn_649 = lang.IFn_Cast(root_647) } else { ifn_649 = nil }; var arg_650 any = s__28000078__3; if linked_648 == nil { tmp18 = ifn_649.Invoke_O__O(arg_650) } else { tmp18 = linked_648.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_647, arg_650) }; arg_619 = tmp17.Invoke_O__O(tmp18); if linked_616 == nil { return ifn_617.Invoke_O_O__O(arg_618, arg_619) } else { return linked_616.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_615, arg_618, arg_619) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :176:1
func A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :176:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A) Ctor_O_O_O_I_O(c__c, c__n, c__b__28000080 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_c = c__c; t.F_n = c__n; t.F_b__28000080 = c__b__28000080; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :176:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A) Invoke_O__O(self any) any { { var i__28000079__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__28000079__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__28000079__1)); var root_556 any = A_arbace_classes_env_A_const_62.GetRawRoot__O(); var linked_557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_556, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_558 lang.IFn; if linked_557 == nil { ifn_558 = lang.IFn_Cast(root_556) } else { ifn_558 = nil }; var arg_559 any = t.F_b__28000080; var arg_560 any; var tmp2 any = A_arbace_classes_env_A_const_42; var tmp3 any = A_arbace_classes_env_A_const_60; var tmp4 any; var root_561 any = A_arbace_classes_env_A_const_78.GetRawRoot__O(); var linked_562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_561, aot_arbace_classes_types.A_arbace_classes_types_method_desc_A_fn_class); var ifn_563 lang.IFn

	if linked_562 == nil { ifn_563 = lang.IFn_Cast(root_561) } else { ifn_563 = nil }; var arg_564 any; var root_566 any = A_arbace_classes_env_A_const_79.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_566, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_568 lang.IFn; if linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var arg_570 any; var G__28000084__3_ any; var root_571 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_571, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_573 lang.IFn; if linked_572 == nil { ifn_573 = lang.IFn_Cast(root_571) } else { ifn_573 = nil }; var arg_574 any = jrt.NN(jrt.Constructor_Cast(m__2)).GetParameterTypes__Class1().Ref(); if linked_572 == nil { G__28000084__3_ = ifn_573.Invoke_O__O(arg_574) } else { G__28000084__3_ = linked_572.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_571, arg_574) }; var tmp5 any; var root_575 any = A_arbace_classes_env_A_const_75.GetRawRoot__O(); var linked_576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_575, A_arbace_classes_env_inner_member_QMARK__A_fn_class); var ifn_577 lang.IFn
	if linked_576 == nil { ifn_577 = lang.IFn_Cast(root_575) } else { ifn_577 = nil }; var arg_578 any = t.F_c; if linked_576 == nil { tmp5 = ifn_577.Invoke_O__O(arg_578) } else { tmp5 = linked_576.(*A_arbace_classes_env_inner_member_QMARK__A).Invoke_O_O__O(root_575, arg_578) }
//line :178:1
	if jrt.J2g_Truth(tmp5) { var root_579 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_579, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_581 lang.IFn; if linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any = G__28000084__3_; if linked_580 == nil { arg_570 = ifn_581.Invoke_O__O(arg_582) } else { arg_570 = linked_580.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_579, arg_582) } } else { arg_570 = G__28000084__3_ }; if linked_567 == nil { arg_564 = ifn_568.Invoke_O_O__O(arg_569, arg_570) } else { arg_564 = linked_567.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_566, arg_569, arg_570) }; var arg_565 any = Lit_52; if linked_562 == nil { tmp4 = ifn_563.Invoke_O_O__O(arg_564, arg_565) } else { tmp4 = linked_562.(*aot_arbace_classes_types.A_arbace_classes_types_method_desc_A).Invoke_O_O_O__O(root_561, arg_564, arg_565) }
//line :176:1
	var tmp6 any = tmp4; var tmp7 any = A_arbace_classes_env_A_const_43; var tmp8 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Constructor_Cast(m__2)).GetModifiers__I()).Ref(); var tmp9 any = A_arbace_classes_env_A_const_63; var tmp10 any = t.F_n; var tmp11 any = A_arbace_classes_env_A_const_80; var tmp12 any; var root_583 any = A_arbace_classes_env_A_const_47.GetRawRoot__O(); var linked_584 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_583, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_585 lang.IFn





	if linked_584 == nil { ifn_585 = lang.IFn_Cast(root_583) } else { ifn_585 = nil }; var arg_586 any = A_arbace_classes_env_A_const_34.GetRawRoot__O(); var arg_587 any = jrt.NN(jrt.Constructor_Cast(m__2)).GetExceptionTypes__Class1().Ref(); if linked_584 == nil { tmp12 = ifn_585.Invoke_O_O__O(arg_586, arg_587) } else { tmp12 = linked_584.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_583, arg_586, arg_587) }
//line :176:1
	arg_560 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, Lit_13, tmp3, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12)); if linked_557 == nil { ifn_558.Invoke_O_O__O(arg_559, arg_560) } else { linked_557.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_556, arg_559, arg_560) }; i__28000079__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000079__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }










func A_arbace_classes_env_reflect_info_fn__28000089_A_New() *A_arbace_classes_env_reflect_info_fn__28000089_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_fn__28000089_A{}; t.Ctor(); return t }
//line :187:1
func (t *A_arbace_classes_env_reflect_info_fn__28000089_A) Ctor() {}
//line :187:1
func (t *A_arbace_classes_env_reflect_info_fn__28000089_A) Invoke_O_O__O(self, p1__28000026_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_13, A_arbace_classes_env_A_const_42.Invoke_O__O(p1__28000026_SHARP___1))).Ref() }
func A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_New_O(p0 any) *A_arbace_classes_env_reflect_info_iter__28000091__28000095_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000091__28000095_A{}; t.Ctor_O(p0); return t }
//line :188:1
func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :188:1
func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_A) Invoke_O_O__O(self, s__28000092__1 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_New_O_O_O(t.F_n, s__28000092__1, self); var tmp2 *jrt.Class; var fncls__731 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_fn_class; if fncls__731 == nil { var fncls__731d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_fn_class = fncls__731d; tmp2 = fncls__731d } else { tmp2 = fncls__731 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :188:1
func A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :188:1
func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A) Ctor_O_O_O(c__n, c__s__28000092, c__iter__28000091 any) { t.F_n = c__n; t.F_s__28000092 = c__s__28000092; t.F_iter__28000091 = c__iter__28000091 }
//line :188:1
func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A) Invoke_O__O(self any) any { { var s__28000092__1 any; var t_ any = t.F_s__28000092; t.F_s__28000092 = nil; s__28000092__1 = t_; for { var temp__1927000414__auto____2 any; var root_674 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_674, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_676 lang.IFn; if linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any = s__28000092__1; if linked_675 == nil { temp__1927000414__auto____2 = ifn_676.Invoke_O__O(arg_677) } else { temp__1927000414__auto____2 = linked_675.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_674, arg_677) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__28000092__3 any = temp__1927000414__auto____2; var tmp1 any; var root_678 any = A_arbace_classes_env_A_const_54.GetRawRoot__O(); var linked_679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_678, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_680 lang.IFn; if linked_679 == nil { ifn_680 = lang.IFn_Cast(root_678) } else { ifn_680 = nil }; var arg_681 any = s__28000092__3; if linked_679 == nil { tmp1 = ifn_680.Invoke_O__O(arg_681) } else { tmp1 = linked_679.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_678, arg_681) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_682 any = A_arbace_classes_env_A_const_55.GetRawRoot__O(); var linked_683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_682, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_684 lang.IFn; if linked_683 == nil { ifn_684 = lang.IFn_Cast(root_682) } else { ifn_684 = nil }; var arg_685 any = s__28000092__3; if linked_683 == nil { c__1927001037__auto____4 = ifn_684.Invoke_O__O(arg_685) } else { c__1927001037__auto____4 = linked_683.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_682, arg_685) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__28000094__6 any; var root_686 any = A_arbace_classes_env_A_const_56.GetRawRoot__O(); var linked_687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_686, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_688 lang.IFn; if linked_687 == nil { ifn_688 = lang.IFn_Cast(root_686) } else { ifn_688 = nil }; var arg_689 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_687 == nil { b__28000094__6 = ifn_688.Invoke_O__O(arg_689) } else { b__28000094__6 = linked_687.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_686, arg_689) }; var tmp2 any = A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_New_O_I_O_O(t.F_n, size__1927001038__auto____5, b__28000094__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__695 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_fn_class; if fncls__695 == nil { var fncls__695d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_fn_class = fncls__695d; tmp3 = fncls__695d } else { tmp3 = fncls__695 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_696 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_696, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_698 lang.IFn; if linked_697 == nil { ifn_698 = lang.IFn_Cast(root_696) } else { ifn_698 = nil }; var arg_699 any; var root_701 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_701, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_703 lang.IFn; if linked_702 == nil { ifn_703 = lang.IFn_Cast(root_701) } else { ifn_703 = nil }; var arg_704 any = b__28000094__6; if linked_702 == nil { arg_699 = ifn_703.Invoke_O__O(arg_704) } else { arg_699 = linked_702.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_701, arg_704) }; var arg_700 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__28000091); var tmp5 any; var root_705 any = A_arbace_classes_env_A_const_70.GetRawRoot__O(); var linked_706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_705, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_707 lang.IFn; if linked_706 == nil { ifn_707 = lang.IFn_Cast(root_705) } else { ifn_707 = nil }; var arg_708 any = s__28000092__3; if linked_706 == nil { tmp5 = ifn_707.Invoke_O__O(arg_708) } else { tmp5 = linked_706.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_705, arg_708) }; arg_700 = tmp4.Invoke_O__O(tmp5); if linked_697 == nil { return ifn_698.Invoke_O_O__O(arg_699, arg_700) } else { return linked_697.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_696, arg_699, arg_700) } } else { var root_709 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_709, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_711 lang.IFn; if linked_710 == nil { ifn_711 = lang.IFn_Cast(root_709) } else { ifn_711 = nil }; var arg_712 any; var root_714 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_714, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_716 lang.IFn; if linked_715 == nil { ifn_716 = lang.IFn_Cast(root_714) } else { ifn_716 = nil }; var arg_717 any = b__28000094__6; if linked_715 == nil { arg_712 = ifn_716.Invoke_O__O(arg_717) } else { arg_712 = linked_715.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_714, arg_717) }; var arg_713 any; if linked_710 == nil { return ifn_711.Invoke_O_O__O(arg_712, arg_713) } else { return linked_710.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_709, arg_712, arg_713) } } } else { var vec__28000102__4 any; var root_718 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_718, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_720 lang.IFn; if linked_719 == nil { ifn_720 = lang.IFn_Cast(root_718) } else { ifn_720 = nil }; var arg_721 any = s__28000092__3; if linked_719 == nil { vec__28000102__4 = ifn_720.Invoke_O__O(arg_721) } else { vec__28000102__4 = linked_719.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_718, arg_721) }; var d__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__28000102__4, lang.RT_IntCast_J__I_NoInit(0), nil); var f__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__28000102__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_722 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_723 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_722, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_724 lang.IFn; if linked_723 == nil { ifn_724 = lang.IFn_Cast(root_722) } else { ifn_724 = nil }; var arg_725 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_env_A_const_42, Lit_13, A_arbace_classes_env_A_const_60, d__5, A_arbace_classes_env_A_const_43, f__6, A_arbace_classes_env_A_const_63, t.F_n, A_arbace_classes_env_A_const_80, lang.PersistentVector_EMPTY.Ref())); var arg_726 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__28000091); var tmp7 any; var root_727 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_727, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_729 lang.IFn; if linked_728 == nil { ifn_729 = lang.IFn_Cast(root_727) } else { ifn_729 = nil }; var arg_730 any = s__28000092__3; if linked_728 == nil { tmp7 = ifn_729.Invoke_O__O(arg_730) } else { tmp7 = linked_728.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_727, arg_730) }; arg_726 = tmp6.Invoke_O__O(tmp7); if linked_723 == nil { return ifn_724.Invoke_O_O__O(arg_725, arg_726) } else { return linked_723.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_722, arg_725, arg_726) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :188:1
func A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :188:1
func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A) Ctor_O_I_O_O(c__n any, c__size__1927001038__auto__ int32, c__b__28000094, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__28000094 = c__b__28000094; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :188:1
func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A) Invoke_O__O(self any) any { { var i__28000093__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__28000093__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__28000098__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__28000093__1)); var d__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__28000098__2, lang.RT_IntCast_J__I_NoInit(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__28000098__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_690 any = A_arbace_classes_env_A_const_62.GetRawRoot__O(); var linked_691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_690, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_692 lang.IFn; if linked_691 == nil { ifn_692 = lang.IFn_Cast(root_690) } else { ifn_692 = nil }; var arg_693 any = t.F_b__28000094; var arg_694 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_env_A_const_42, Lit_13, A_arbace_classes_env_A_const_60, d__3, A_arbace_classes_env_A_const_43, f__4, A_arbace_classes_env_A_const_63, t.F_n, A_arbace_classes_env_A_const_80, lang.PersistentVector_EMPTY.Ref())); if linked_691 == nil { ifn_692.Invoke_O_O__O(arg_693, arg_694) } else { linked_691.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_690, arg_693, arg_694) }; i__28000093__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000093__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_classes_env_info_A_New() *A_arbace_classes_env_info_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_info_A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_classes_env_info_A) Ctor() {}
//line :197:1
func (t *A_arbace_classes_env_info_A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any = n__0; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_737 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_737, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_739 lang.IFn; if linked_738 == nil { ifn_739 = lang.IFn_Cast(root_737) } else { ifn_739 = nil }; var arg_740 any; var root_741 any = A_arbace_classes_env_A_const_20.GetRawRoot__O(); var linked_742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_741, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_743 lang.IFn; if linked_742 == nil { ifn_743 = lang.IFn_Cast(root_741) } else { ifn_743 = nil }; var arg_744 any = n__0; var arg_745 any = Lit_11; if linked_742 == nil { arg_740 = ifn_743.Invoke_O_O__O(arg_744, arg_745) } else { arg_740 = linked_742.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_741, arg_744, arg_745) }; if linked_738 == nil { tmp1 = ifn_739.Invoke_O__O(arg_740) } else { tmp1 = linked_738.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_737, arg_740) } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var or__1927000174__auto____2 any; var G__28000108__2_ any = A_arbace_classes_env_A_const_89.Get__O(); var G__28000108__3_ any
		if lang.Util_Identical_O_O__Z_NoInit(G__28000108__2_, nil) { G__28000108__3_ = nil } else { var root_746 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_746, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_748 lang.IFn; if linked_747 == nil { ifn_748 = lang.IFn_Cast(root_746) } else { ifn_748 = nil }; var arg_749 any = G__28000108__2_; if linked_747 == nil { G__28000108__3_ = ifn_748.Invoke_O__O(arg_749) } else { G__28000108__3_ = linked_747.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_746, arg_749) } }; if lang.Util_Identical_O_O__Z_NoInit(G__28000108__3_, nil) { or__1927000174__auto____2 = nil } else { or__1927000174__auto____2 = lang.RT_Get_O_O__O_NoInit(G__28000108__3_, n__0) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else {
			if jrt.J2g_Truth(A_arbace_classes_env_A_const_19.Get__O()) {
				var tmp2 any; var root_750 any = A_arbace_classes_env_A_const_18.GetRawRoot__O(); var linked_751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_750, A_arbace_classes_env_from_source_QMARK__A_fn_class); var ifn_752 lang.IFn; if linked_751 == nil { ifn_752 = lang.IFn_Cast(root_750) } else { ifn_752 = nil }; var arg_753 any = n__0; if linked_751 == nil { tmp2 = ifn_752.Invoke_O__O(arg_753) } else { tmp2 = linked_751.(*A_arbace_classes_env_from_source_QMARK__A).Invoke_O_O__O(root_750, arg_753) }; if jrt.J2g_Truth(tmp2) { return nil } else { var tmp3 *lang.Keyword = A_arbace_classes_env_A_const_90; return tmp3.Invoke_O__O(lang.RT_Get_O_O__O_NoInit(A_arbace_classes_env_A_const_19.Get__O(), n__0)) } } else {
//line :202:1
					var temp__1927000414__auto____3 any; var root_754 any = A_arbace_classes_env_A_const_25.GetRawRoot__O(); var linked_755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_754, A_arbace_classes_env_load_class_A_fn_class); var ifn_756 lang.IFn

					if linked_755 == nil { ifn_756 = lang.IFn_Cast(root_754) } else { ifn_756 = nil }; var arg_757 any = n__0; if linked_755 == nil { temp__1927000414__auto____3 = ifn_756.Invoke_O__O(arg_757) } else { temp__1927000414__auto____3 = linked_755.(*A_arbace_classes_env_load_class_A).Invoke_O_O__O(root_754, arg_757) }; if jrt.J2g_Truth(temp__1927000414__auto____3) { var c__4 any = temp__1927000414__auto____3; var d__5 any; var tmp4 any; var root_758 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_758, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_760 lang.IFn
						if linked_759 == nil { ifn_760 = lang.IFn_Cast(root_758) } else { ifn_760 = nil }; var arg_761 any = A_arbace_classes_env_A_const_91.GetRawRoot__O(); if linked_759 == nil { tmp4 = ifn_760.Invoke_O__O(arg_761) } else { tmp4 = linked_759.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_758, arg_761) }; d__5 = lang.RT_Get_O_O__O_NoInit(tmp4, n__0)
						var tmp5 any; var and__1927000168__auto____6 any = d__5; if jrt.J2g_Truth(and__1927000168__auto____6) { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(A_arbace_classes_env_A_const_31.Invoke_O__O(d__5), c__4)).Ref() } else { tmp5 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp5) { return d__5 } else { var root_762 any = A_arbace_classes_env_A_const_92.GetRawRoot__O(); var linked_763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_762, A_arbace_classes_env_reflect_info_A_fn_class); var ifn_764 lang.IFn; if linked_763 == nil { ifn_764 = lang.IFn_Cast(root_762) } else { ifn_764 = nil }; var arg_765 any = c__4; if linked_763 == nil { return ifn_764.Invoke_O__O(arg_765) } else { return linked_763.(*A_arbace_classes_env_reflect_info_A).Invoke_O_O__O(root_762, arg_765) } } } else {
//line :204:1
							return nil } } } } else {
//line :200:1
								return nil
							}
}





func A_arbace_classes_env_info_BANG__A_New() *A_arbace_classes_env_info_BANG__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_info_BANG__A{}; t.Ctor(); return t }
//line :208:1
func (t *A_arbace_classes_env_info_BANG__A) Ctor() {}
//line :208:1
func (t *A_arbace_classes_env_info_BANG__A) Invoke_O_O__O(self, n__0 any) any { var or__1927000174__auto____2 any; var root_766 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_766, A_arbace_classes_env_info_A_fn_class); var ifn_768 lang.IFn; if
										linked_767 == nil { ifn_768 = lang.IFn_Cast(root_766) } else { ifn_768 = nil }; var arg_769 any = n__0; if linked_767 == nil { or__1927000174__auto____2 = ifn_768.Invoke_O__O(arg_769) } else { or__1927000174__auto____2 = linked_767.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_766, arg_769) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var tmp1 any; var root_770 any = A_arbace_classes_env_A_const_28.GetRawRoot__O(); var linked_771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_770, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_772 lang.IFn; if linked_771 == nil { ifn_772 = lang.IFn_Cast(root_770) } else { ifn_772 = nil }; var arg_773 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_20, nil); var tmp3 any; var root_775 any = A_arbace_classes_env_A_const_12.GetRawRoot__O(); var linked_776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_775, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_777 lang.IFn; if linked_776 == nil { ifn_777 = lang.IFn_Cast(root_775) } else { ifn_777 = nil }; var arg_778 any; var root_781 any = A_arbace_classes_env_A_const_30.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_781, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_783 lang.IFn; if linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any = n__0; if linked_782 == nil { arg_778 = ifn_783.Invoke_O__O(arg_784) } else { arg_778 = linked_782.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_781, arg_784) }; var arg_779 any = Lit_21; var arg_780 any = Lit_22; if linked_776 == nil { tmp3 = ifn_777.Invoke_O_O_O__O(arg_778, arg_779, arg_780) } else { tmp3 = linked_776.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_775, arg_778, arg_779, arg_780) }; arg_773 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref(); var arg_774 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_env_A_const_31, n__0)); if linked_771 == nil { tmp1 = ifn_772.Invoke_O_O__O(arg_773, arg_774) } else { tmp1 = linked_771.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_770, arg_773, arg_774) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) } }

func A_arbace_classes_env_interface_QMARK__A_New() *A_arbace_classes_env_interface_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_interface_QMARK__A{}; t.Ctor(); return t }
//line :211:1
func (t *A_arbace_classes_env_interface_QMARK__A) Ctor() {}
//line :211:1
func (t *A_arbace_classes_env_interface_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var i__2 any; var root_785 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_785, A_arbace_classes_env_info_A_fn_class); var ifn_787 lang.IFn; if
											linked_786 == nil { ifn_787 = lang.IFn_Cast(root_785) } else { ifn_787 = nil }; var arg_788 any = n__0; if linked_786 == nil { i__2 = ifn_787.Invoke_O__O(arg_788) } else { i__2 = linked_786.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_785, arg_788) }; var tmp1 any; var or__1927000174__auto____3 any = A_arbace_classes_env_A_const_44.Invoke_O__O(i__2); if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var G__28000111__4_ any = A_arbace_classes_env_A_const_43.Invoke_O__O(i__2); var G__28000111__5_ any; if lang.Util_Identical_O_O__Z_NoInit(G__28000111__4_, nil) { G__28000111__5_ = nil } else { var tmp2 int64; var na_789 any = G__28000111__4_; var na_790 int64 = 512; if jrt.Long_InstanceOf(na_789) { var n0_791 int64 = jrt.NN(jrt.Long_Cast(na_789)).LongValue__J(); var n1_792 int64 = na_790; tmp2 = n0_791 & n1_792 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_789, na_790) }; G__28000111__5_ = jrt.Long_ValueOf_J__Long_NoInit(tmp2).Ref() }; if lang.Util_Identical_O_O__Z_NoInit(G__28000111__5_, nil) { tmp1 = nil } else { var tmp3 bool; var na_794 any = G__28000111__5_; if jrt.Long_InstanceOf(na_794) { var n0_795 int64 = jrt.NN(jrt.Long_Cast(na_794)).LongValue__J(); tmp3 = n0_795 > 0 } else { if jrt.Double_InstanceOf(na_794) { var n0_795_2 float64 = jrt.NN(jrt.Double_Cast(na_794)).DoubleValue__D(); tmp3 = n0_795_2 > 0.0 } else { tmp3 = lang.Numbers_IsPos_O__Z_NoInit(na_794) } }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp3).Ref() } }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() }

func A_arbace_classes_env_const_value_A_New() *A_arbace_classes_env_const_value_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_const_value_A{}; t.Ctor(); return t }
//line :214:1
func (t *A_arbace_classes_env_const_value_A) Ctor() {}
//line :214:1
func (t *A_arbace_classes_env_const_value_A) Invoke_O_O__O(self, field__0 any) any { var c__2 any = A_arbace_classes_env_A_const_64.Invoke_O__O(field__0); var tmp1 any; var root_796 any = A_arbace_classes_env_A_const_94.GetRawRoot__O(); var linked_797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_796, aot_arbace_core.A_arbace_core_delay_QMARK__A_fn_class); var ifn_798 lang.IFn; if
											linked_797 == nil { ifn_798 = lang.IFn_Cast(root_796) } else { ifn_798 = nil }; var arg_799 any = c__2; if linked_797 == nil { tmp1 = ifn_798.Invoke_O__O(arg_799) } else { tmp1 = linked_797.(*aot_arbace_core.A_arbace_core_delay_QMARK__A).Invoke_O_O__O(root_796, arg_799) }; if jrt.J2g_Truth(tmp1) { var root_800 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_800, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_802 lang.IFn; if linked_801 == nil { ifn_802 = lang.IFn_Cast(root_800) } else { ifn_802 = nil }; var arg_803 any = c__2; if linked_801 == nil { return ifn_802.Invoke_O__O(arg_803) } else { return linked_801.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_800, arg_803) } } else { return c__2 } }

func A_arbace_classes_env_supertypes_A_New() *A_arbace_classes_env_supertypes_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_supertypes_A{}; t.Ctor(); return t }
//line :217:1
func (t *A_arbace_classes_env_supertypes_A) Ctor() {}
//line :217:1
func (t *A_arbace_classes_env_supertypes_A) Invoke_O_O__O(self, n__0 any) any { var i__2 any; var root_804 any = A_arbace_classes_env_A_const_95.GetRawRoot__O(); var linked_805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_804, A_arbace_classes_env_info_BANG__A_fn_class); var ifn_806 lang.IFn; if


	linked_805 == nil { ifn_806 = lang.IFn_Cast(root_804) } else { ifn_806 = nil }; var arg_807 any = n__0; if linked_805 == nil { i__2 = ifn_806.Invoke_O__O(arg_807) } else { i__2 = linked_805.(*A_arbace_classes_env_info_BANG__A).Invoke_O_O__O(root_804, arg_807) }; var G__28000114__3_ any; var root_808 any = /*line :217:1*/A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_809 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_808, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_810 lang.IFn; if


	linked_809 == nil { ifn_810 = lang.IFn_Cast(root_808) } else { ifn_810 = nil }; var arg_811 any = A_arbace_classes_env_A_const_46.Invoke_O__O(i__2); if linked_809 == nil { G__28000114__3_ = ifn_810.Invoke_O__O(arg_811) } else { G__28000114__3_ = linked_809.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_808, arg_811) }; if jrt.J2g_Truth(A_arbace_classes_env_A_const_45.Invoke_O__O(i__2)) { var root_812 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_812, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_814 lang.IFn; if linked_813 == nil { ifn_814 = lang.IFn_Cast(root_812) } else { ifn_814 = nil }; var arg_815 any; var root_816 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_816, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_818 lang.IFn; if linked_817 == nil { ifn_818 = lang.IFn_Cast(root_816) } else { ifn_818 = nil }; var arg_819 any = A_arbace_classes_env_A_const_45.Invoke_O__O(i__2); var arg_820 any = G__28000114__3_; if linked_817 == nil { arg_815 = ifn_818.Invoke_O_O__O(arg_819, arg_820) } else { arg_815 = linked_817.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_816, arg_819, arg_820) }; if linked_813 == nil { return ifn_814.Invoke_O__O(arg_815) } else { return linked_813.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_812, arg_815) } } else { return G__28000114__3_ } }

func A_arbace_classes_env_subclass_QMARK__A_New() *A_arbace_classes_env_subclass_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_subclass_QMARK__A{}; t.Ctor(); return t }
//line :222:1
func (t *A_arbace_classes_env_subclass_QMARK__A) Ctor() {}
//line :222:1
func (t *A_arbace_classes_env_subclass_QMARK__A) Invoke_O_O_O__O(self, a__0, b__1 any) any { var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(a__0, b__1); if or__1927000174__auto____3 {


	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var or__1927000174__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(b__1, Lit_4); if or__1927000174__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____4).Ref() } else {
		var tmp1 any; var root_821 any = A_arbace_classes_env_A_const_96.GetRawRoot__O(); var linked_822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_821, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_823 lang.IFn; if linked_822 == nil { ifn_823 = lang.IFn_Cast(root_821) } else { ifn_823 = nil }; var arg_824 any; var tmp2 any = A_arbace_classes_env_subclass_QMARK__fn__28000117_A_New_O(b__1); var tmp3 *jrt.Class; var fncls__831 *jrt.Class = A_arbace_classes_env_subclass_QMARK__fn__28000117_A_fn_class; if fncls__831 == nil { var fncls__831d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); A_arbace_classes_env_subclass_QMARK__fn__28000117_A_fn_class = fncls__831d; tmp3 = fncls__831d } else { tmp3 = fncls__831 }; arg_824 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_825 any; var temp__1927000414__auto____5 any; var root_832 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_832, A_arbace_classes_env_info_A_fn_class); var ifn_834 lang.IFn; if linked_833 == nil { ifn_834 = lang.IFn_Cast(root_832) } else { ifn_834 = nil }; var arg_835 any = a__0; if linked_833 == nil { temp__1927000414__auto____5 = ifn_834.Invoke_O__O(arg_835) } else { temp__1927000414__auto____5 = linked_833.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_832, arg_835) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var i__6 any = temp__1927000414__auto____5; var G__28000119__7_ any; var root_836 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_836, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_838 lang.IFn
			if linked_837 == nil { ifn_838 = lang.IFn_Cast(root_836) } else { ifn_838 = nil }; var arg_839 any = A_arbace_classes_env_A_const_46.Invoke_O__O(i__6); if linked_837 == nil { G__28000119__7_ = ifn_838.Invoke_O__O(arg_839) } else { G__28000119__7_ = linked_837.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_836, arg_839) }; if jrt.J2g_Truth(A_arbace_classes_env_A_const_45.Invoke_O__O(i__6)) { var root_840 any = A_arbace_classes_env_A_const_10.GetRawRoot__O(); var linked_841 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_840, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_842 lang.IFn; if linked_841 == nil { ifn_842 = lang.IFn_Cast(root_840) } else { ifn_842 = nil }; var arg_843 any = G__28000119__7_; var arg_844 any = A_arbace_classes_env_A_const_45.Invoke_O__O(i__6); if linked_841 == nil { arg_825 = ifn_842.Invoke_O_O__O(arg_843, arg_844) } else { arg_825 = linked_841.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_840, arg_843, arg_844) } } else { arg_825 = G__28000119__7_ } } else {
//line :226:1
				arg_825 = nil }; if linked_822 == nil { tmp1 = ifn_823.Invoke_O_O__O(arg_824, arg_825) } else { tmp1 = linked_822.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_821, arg_824, arg_825) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() } } }
//line :226:1
func A_arbace_classes_env_subclass_QMARK__fn__28000117_A_New_O(p0 any) *A_arbace_classes_env_subclass_QMARK__fn__28000117_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_subclass_QMARK__fn__28000117_A{}; t.Ctor_O(p0); return t }
//line :226:1
func (t *A_arbace_classes_env_subclass_QMARK__fn__28000117_A) Ctor_O(c__b any) { t.F_b = c__b }
//line :226:1
func (t *A_arbace_classes_env_subclass_QMARK__fn__28000117_A) Invoke_O_O__O(self, p1__28000116_SHARP___1 any) any { var root_826 any = A_arbace_classes_env_A_const_97.GetRawRoot__O(); var linked_827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_826, A_arbace_classes_env_subclass_QMARK__A_fn_class); var ifn_828 lang.IFn; if linked_827 == nil { ifn_828 = lang.IFn_Cast(root_826) } else { ifn_828 = nil }; var arg_829 any = p1__28000116_SHARP___1; var arg_830 any = t.F_b; if linked_827 == nil { return ifn_828.Invoke_O_O__O(arg_829, arg_830) } else { return linked_827.(*A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(root_826, arg_829, arg_830) } }


func A_arbace_classes_env_assignable_QMARK__A_New() *A_arbace_classes_env_assignable_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_assignable_QMARK__A{}; t.Ctor(); return t }
//line :229:1
func (t *A_arbace_classes_env_assignable_QMARK__A) Ctor() {}
//line :229:1
func (t *A_arbace_classes_env_assignable_QMARK__A) Invoke_O_O_O__O(self, from__0, to__1 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(from__0, to__1) { return jrt.Boolean_TRUE.Ref() } else { if lang.Util_Equiv_O_O__Z_NoInit(from__0, A_arbace_classes_env_A_const_98) {

		var root_845 any = A_arbace_classes_env_A_const_99.GetRawRoot__O(); var linked_846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_845, aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A_fn_class); var ifn_847 lang.IFn; if linked_846 == nil { ifn_847 = lang.IFn_Cast(root_845) } else { ifn_847 = nil }; var arg_848 any = to__1; if linked_846 == nil { return ifn_847.Invoke_O__O(arg_848) } else { return linked_846.(*aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A).Invoke_O_O__O(root_845, arg_848) } } else {
//line :232:1
			var tmp1 any; var root_849 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_850 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_849, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_851 lang.IFn


			if linked_850 == nil { ifn_851 = lang.IFn_Cast(root_849) } else { ifn_851 = nil }; var arg_852 any; var and__1927000168__auto____3 any; var root_853 any = A_arbace_classes_env_A_const_99.GetRawRoot__O(); var linked_854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_853, aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A_fn_class); var ifn_855 lang.IFn; if linked_854 == nil { ifn_855 = lang.IFn_Cast(root_853) } else { ifn_855 = nil }; var arg_856 any = from__0; if linked_854 == nil { and__1927000168__auto____3 = ifn_855.Invoke_O__O(arg_856) } else { and__1927000168__auto____3 = linked_854.(*aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A).Invoke_O_O__O(root_853, arg_856) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_857 any = A_arbace_classes_env_A_const_99.GetRawRoot__O(); var linked_858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_857, aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A_fn_class); var ifn_859 lang.IFn; if linked_858 == nil { ifn_859 = lang.IFn_Cast(root_857) } else { ifn_859 = nil }; var arg_860 any = to__1; if linked_858 == nil { arg_852 = ifn_859.Invoke_O__O(arg_860) } else { arg_852 = linked_858.(*aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A).Invoke_O_O__O(root_857, arg_860) } } else { arg_852 = and__1927000168__auto____3 }; if linked_850 == nil { tmp1 = ifn_851.Invoke_O__O(arg_852) } else { tmp1 = linked_850.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_849, arg_852) }
//line :232:1
			if jrt.J2g_Truth(tmp1) { return jrt.Boolean_FALSE.Ref() } else { if lang.Util_Equiv_O_O__Z_NoInit(to__1, A_arbace_classes_env_A_const_100.GetRawRoot__O()) { return jrt.Boolean_TRUE.Ref() } else { var tmp2 any; var root_861 any = A_arbace_classes_env_A_const_101.GetRawRoot__O(); var linked_862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_861, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_863 lang.IFn




				if linked_862 == nil { ifn_863 = lang.IFn_Cast(root_861) } else { ifn_863 = nil }; var arg_864 any = from__0; if linked_862 == nil { tmp2 = ifn_863.Invoke_O__O(arg_864) } else { tmp2 = linked_862.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_861, arg_864) }
//line :232:1
				if jrt.J2g_Truth(tmp2) {





					var tmp3 any; var root_865 any = A_arbace_classes_env_A_const_101.GetRawRoot__O(); var linked_866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_865, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_867 lang.IFn; if linked_866 == nil { ifn_867 = lang.IFn_Cast(root_865) } else { ifn_867 = nil }; var arg_868 any = to__1; if linked_866 == nil { tmp3 = ifn_867.Invoke_O__O(arg_868) } else { tmp3 = linked_866.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_865, arg_868) }; if jrt.J2g_Truth(tmp3) { var fe__3 any; var root_869 any = A_arbace_classes_env_A_const_102.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_869, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_871 lang.IFn; if linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any = from__0; if linked_870 == nil { fe__3 = ifn_871.Invoke_O__O(arg_872) } else { fe__3 = linked_870.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_869, arg_872) }; var te__4 any; var root_873 any = A_arbace_classes_env_A_const_102.GetRawRoot__O(); var linked_874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_873, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_875 lang.IFn; if linked_874 == nil { ifn_875 = lang.IFn_Cast(root_873) } else { ifn_875 = nil }; var arg_876 any = to__1; if linked_874 == nil { te__4 = ifn_875.Invoke_O__O(arg_876) } else { te__4 = linked_874.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_873, arg_876) }; var and__1927000168__auto____5 any; var root_877 any = A_arbace_classes_env_A_const_99.GetRawRoot__O(); var linked_878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_877, aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A_fn_class); var ifn_879 lang.IFn
						if linked_878 == nil { ifn_879 = lang.IFn_Cast(root_877) } else { ifn_879 = nil }; var arg_880 any = fe__3; if linked_878 == nil { and__1927000168__auto____5 = ifn_879.Invoke_O__O(arg_880) } else { and__1927000168__auto____5 = linked_878.(*aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A).Invoke_O_O__O(root_877, arg_880) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_881 any = A_arbace_classes_env_A_const_99.GetRawRoot__O(); var linked_882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_881, aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A_fn_class); var ifn_883 lang.IFn; if linked_882 == nil { ifn_883 = lang.IFn_Cast(root_881) } else { ifn_883 = nil }; var arg_884 any = te__4; if linked_882 == nil { and__1927000168__auto____6 = ifn_883.Invoke_O__O(arg_884) } else { and__1927000168__auto____6 = linked_882.(*aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A).Invoke_O_O__O(root_881, arg_884) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_885 any = A_arbace_classes_env_A_const_103.GetRawRoot__O(); var linked_886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_885, A_arbace_classes_env_assignable_QMARK__A_fn_class); var ifn_887 lang.IFn; if linked_886 == nil { ifn_887 = lang.IFn_Cast(root_885) } else { ifn_887 = nil }; var arg_888 any = fe__3; var arg_889 any = te__4; if linked_886 == nil { return ifn_887.Invoke_O_O__O(arg_888, arg_889) } else { return linked_886.(*A_arbace_classes_env_assignable_QMARK__A).Invoke_O_O_O__O(root_885, arg_888, arg_889) } } else { return and__1927000168__auto____6 } } else { return and__1927000168__auto____5 } } else {
//line :238:1
							if A_arbace_classes_env_A_const_104 != nil {

								var root_890 any = A_arbace_classes_env_A_const_23.GetRawRoot__O(); var linked_891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_890, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_892 lang.IFn; if linked_891 == nil { ifn_892 = lang.IFn_Cast(root_890) } else { ifn_892 = nil }; var arg_893 any = A_arbace_classes_env_A_const_105; var arg_894 any = to__1; if linked_891 == nil { return ifn_892.Invoke_O_O__O(arg_893, arg_894) } else { return linked_891.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_890, arg_893, arg_894) } } else {
//line :238:1
									return nil } } } else {
//line :232:1
										var tmp4 any; var root_895 any = A_arbace_classes_env_A_const_101.GetRawRoot__O(); var linked_896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_895, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_897 lang.IFn








										if linked_896 == nil { ifn_897 = lang.IFn_Cast(root_895) } else { ifn_897 = nil }; var arg_898 any = to__1; if linked_896 == nil { tmp4 = ifn_897.Invoke_O__O(arg_898) } else { tmp4 = linked_896.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_895, arg_898) }
//line :232:1
										if jrt.J2g_Truth(tmp4) { return jrt.Boolean_FALSE.Ref() } else { if A_arbace_classes_env_A_const_104 != nil {









											var root_899 any = A_arbace_classes_env_A_const_97.GetRawRoot__O(); var linked_900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_899, A_arbace_classes_env_subclass_QMARK__A_fn_class); var ifn_901 lang.IFn; if linked_900 == nil { ifn_901 = lang.IFn_Cast(root_899) } else { ifn_901 = nil }; var arg_902 any; var root_904 any = A_arbace_classes_env_A_const_106.GetRawRoot__O(); var linked_905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_904, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_906 lang.IFn; if linked_905 == nil { ifn_906 = lang.IFn_Cast(root_904) } else { ifn_906 = nil }; var arg_907 any = from__0; if linked_905 == nil { arg_902 = ifn_906.Invoke_O__O(arg_907) } else { arg_902 = linked_905.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_904, arg_907) }; var arg_903 any; var root_908 any = A_arbace_classes_env_A_const_106.GetRawRoot__O(); var linked_909 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_908, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_910 lang.IFn; if linked_909 == nil { ifn_910 = lang.IFn_Cast(root_908) } else { ifn_910 = nil }; var arg_911 any = to__1; if linked_909 == nil { arg_903 = ifn_910.Invoke_O__O(arg_911) } else { arg_903 = linked_909.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_908, arg_911) }; if linked_900 == nil { return ifn_901.Invoke_O_O__O(arg_902, arg_903) } else { return linked_900.(*A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(root_899, arg_902, arg_903) } } else {
//line :232:1
												return nil
											}
										}
									}
			}
			}
		}
	}
}



func A_arbace_classes_env_superclass_chain_A_New() *A_arbace_classes_env_superclass_chain_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_superclass_chain_A{}; t.Ctor(); return t }
//line :244:1
func (t *A_arbace_classes_env_superclass_chain_A) Ctor() {}
//line :244:1
func (t *A_arbace_classes_env_superclass_chain_A) Invoke_O_O__O(self, n__0 any) any {
	var root_912 any = A_arbace_classes_env_A_const_107.GetRawRoot__O(); var linked_913 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_912, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_914 lang.IFn; if linked_913 == nil { ifn_914 = lang.IFn_Cast(root_912) } else { ifn_914 = nil }; var arg_915 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var arg_916 any; var root_917 any = A_arbace_classes_env_A_const_108.GetRawRoot__O(); var linked_918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_917, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_919 lang.IFn; if linked_918 == nil { ifn_919 = lang.IFn_Cast(root_917) } else { ifn_919 = nil }; var arg_920 any; var tmp1 any = A_arbace_classes_env_superclass_chain_fn__28000123_A_New(); var tmp2 *jrt.Class; var fncls__926 *jrt.Class = A_arbace_classes_env_superclass_chain_fn__28000123_A_fn_class; if fncls__926 == nil { var fncls__926d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_classes_env_superclass_chain_fn__28000123_A_fn_class = fncls__926d; tmp2 = fncls__926d } else { tmp2 = fncls__926 }; arg_920 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_921 any = n__0; if linked_918 == nil { arg_916 = ifn_919.Invoke_O_O__O(arg_920, arg_921) } else { arg_916 = linked_918.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_917, arg_920, arg_921) }; if linked_913 == nil { return ifn_914.Invoke_O_O__O(arg_915, arg_916) } else { return linked_913.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_912, arg_915, arg_916) } }
//line :245:1
func A_arbace_classes_env_superclass_chain_fn__28000123_A_New() *A_arbace_classes_env_superclass_chain_fn__28000123_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_superclass_chain_fn__28000123_A{}; t.Ctor(); return t }
//line :245:1
func (t *A_arbace_classes_env_superclass_chain_fn__28000123_A) Ctor() {}
//line :245:1
func (t *A_arbace_classes_env_superclass_chain_fn__28000123_A) Invoke_O_O__O(self, p1__28000122_SHARP___1 any) any { var G__28000124__2_ any = p1__28000122_SHARP___1; var G__28000124__3_ any; if lang.Util_Identical_O_O__Z_NoInit(G__28000124__2_, nil) { G__28000124__3_ = nil } else { var root_922 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_922, A_arbace_classes_env_info_A_fn_class); var ifn_924 lang.IFn; if linked_923 == nil { ifn_924 = lang.IFn_Cast(root_922) } else { ifn_924 = nil }; var arg_925 any = G__28000124__2_; if linked_923 == nil { G__28000124__3_ = ifn_924.Invoke_O__O(arg_925) } else { G__28000124__3_ = linked_923.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_922, arg_925) } }; if lang.Util_Identical_O_O__Z_NoInit(G__28000124__3_, nil) { return nil } else { return A_arbace_classes_env_A_const_45.Invoke_O__O(G__28000124__3_) } }

func A_arbace_classes_env_common_super_A_New() *A_arbace_classes_env_common_super_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_common_super_A{}; t.Ctor(); return t }
//line :247:1
func (t *A_arbace_classes_env_common_super_A) Ctor() {}
//line :247:1
func (t *A_arbace_classes_env_common_super_A) Invoke_O_O_O__O(self, a__0, b__1 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(a__0, b__1) { return a__0 } else { var tmp1 any; var or__1927000174__auto____3 any; var root_927 any = A_arbace_classes_env_A_const_20.GetRawRoot__O(); var linked_928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_927, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_929 lang.IFn

		if linked_928 == nil { ifn_929 = lang.IFn_Cast(root_927) } else { ifn_929 = nil }; var arg_930 any = a__0; var arg_931 any = Lit_11; if linked_928 == nil { or__1927000174__auto____3 = ifn_929.Invoke_O_O__O(arg_930, arg_931) } else { or__1927000174__auto____3 = linked_928.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_927, arg_930, arg_931) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var root_932 any = A_arbace_classes_env_A_const_20.GetRawRoot__O(); var linked_933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_932, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_934 lang.IFn; if linked_933 == nil { ifn_934 = lang.IFn_Cast(root_932) } else { ifn_934 = nil }; var arg_935 any = b__1; var arg_936 any = Lit_11; if linked_933 == nil { tmp1 = ifn_934.Invoke_O_O__O(arg_935, arg_936) } else { tmp1 = linked_933.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_932, arg_935, arg_936) } }
//line :250:1
		if jrt.J2g_Truth(tmp1) { return Lit_4 } else { var tmp2 any; var root_937 any = A_arbace_classes_env_A_const_97.GetRawRoot__O(); var linked_938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_937, A_arbace_classes_env_subclass_QMARK__A_fn_class); var ifn_939 lang.IFn


			if linked_938 == nil { ifn_939 = lang.IFn_Cast(root_937) } else { ifn_939 = nil }; var arg_940 any = a__0; var arg_941 any = b__1; if linked_938 == nil { tmp2 = ifn_939.Invoke_O_O__O(arg_940, arg_941) } else { tmp2 = linked_938.(*A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(root_937, arg_940, arg_941) }
//line :250:1
			if jrt.J2g_Truth(tmp2) {


				var tmp3 any; var root_942 any = A_arbace_classes_env_A_const_109.GetRawRoot__O(); var linked_943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_942, A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_944 lang.IFn; if linked_943 == nil { ifn_944 = lang.IFn_Cast(root_942) } else { ifn_944 = nil }; var arg_945 any = b__1; if linked_943 == nil { tmp3 = ifn_944.Invoke_O__O(arg_945) } else { tmp3 = linked_943.(*A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_942, arg_945) }; if jrt.J2g_Truth(tmp3) { return Lit_4 } else { return b__1 } } else {
//line :250:1
					var tmp4 any; var root_946 any = A_arbace_classes_env_A_const_97.GetRawRoot__O(); var linked_947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_946, A_arbace_classes_env_subclass_QMARK__A_fn_class); var ifn_948 lang.IFn



					if linked_947 == nil { ifn_948 = lang.IFn_Cast(root_946) } else { ifn_948 = nil }; var arg_949 any = b__1; var arg_950 any = a__0; if linked_947 == nil { tmp4 = ifn_948.Invoke_O_O__O(arg_949, arg_950) } else { tmp4 = linked_947.(*A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(root_946, arg_949, arg_950) }
//line :250:1
					if jrt.J2g_Truth(tmp4) {



						var tmp5 any; var root_951 any = A_arbace_classes_env_A_const_109.GetRawRoot__O(); var linked_952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_951, A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_953 lang.IFn; if linked_952 == nil { ifn_953 = lang.IFn_Cast(root_951) } else { ifn_953 = nil }; var arg_954 any = a__0; if linked_952 == nil { tmp5 = ifn_953.Invoke_O__O(arg_954) } else { tmp5 = linked_952.(*A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_951, arg_954) }; if jrt.J2g_Truth(tmp5) { return Lit_4 } else { return a__0 } } else {
//line :250:1
							var tmp6 any; var or__1927000174__auto____3_2 any; var root_955 any = A_arbace_classes_env_A_const_109.GetRawRoot__O(); var linked_956 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_955, A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_957 lang.IFn




							if linked_956 == nil { ifn_957 = lang.IFn_Cast(root_955) } else { ifn_957 = nil }; var arg_958 any = a__0; if linked_956 == nil { or__1927000174__auto____3_2 = ifn_957.Invoke_O__O(arg_958) } else { or__1927000174__auto____3_2 = linked_956.(*A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_955, arg_958) }; if jrt.J2g_Truth(or__1927000174__auto____3_2) { tmp6 = or__1927000174__auto____3_2 } else { var root_959 any = A_arbace_classes_env_A_const_109.GetRawRoot__O(); var linked_960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_959, A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_961 lang.IFn; if linked_960 == nil { ifn_961 = lang.IFn_Cast(root_959) } else { ifn_961 = nil }; var arg_962 any = b__1; if linked_960 == nil { tmp6 = ifn_961.Invoke_O__O(arg_962) } else { tmp6 = linked_960.(*A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_959, arg_962) } }
//line :250:1
							if jrt.J2g_Truth(tmp6) { return Lit_4 } else { if A_arbace_classes_env_A_const_104 != nil { var bs__3 any; var root_963 any = A_arbace_classes_env_A_const_110.GetRawRoot__O(); var linked_964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_963, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_965 lang.IFn





								if linked_964 == nil { ifn_965 = lang.IFn_Cast(root_963) } else { ifn_965 = nil }; var arg_966 any; var root_967 any = A_arbace_classes_env_A_const_111.GetRawRoot__O(); var linked_968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_967, A_arbace_classes_env_superclass_chain_A_fn_class); var ifn_969 lang.IFn; if linked_968 == nil { ifn_969 = lang.IFn_Cast(root_967) } else { ifn_969 = nil }; var arg_970 any = b__1; if linked_968 == nil { arg_966 = ifn_969.Invoke_O__O(arg_970) } else { arg_966 = linked_968.(*A_arbace_classes_env_superclass_chain_A).Invoke_O_O__O(root_967, arg_970) }; if linked_964 == nil { bs__3 = ifn_965.Invoke_O__O(arg_966) } else { bs__3 = linked_964.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_963, arg_966) }
//line :250:1
								var or__1927000174__auto____4 any; var root_971 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_971, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_973 lang.IFn






								if linked_972 == nil { ifn_973 = lang.IFn_Cast(root_971) } else { ifn_973 = nil }; var arg_974 any; var root_975 any = A_arbace_classes_env_A_const_86.GetRawRoot__O(); var linked_976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_975, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_977 lang.IFn; if linked_976 == nil { ifn_977 = lang.IFn_Cast(root_975) } else { ifn_977 = nil }; var arg_978 any = bs__3; var arg_979 any; var root_980 any = A_arbace_classes_env_A_const_111.GetRawRoot__O(); var linked_981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_980, A_arbace_classes_env_superclass_chain_A_fn_class); var ifn_982 lang.IFn; if linked_981 == nil { ifn_982 = lang.IFn_Cast(root_980) } else { ifn_982 = nil }; var arg_983 any = a__0; if linked_981 == nil { arg_979 = ifn_982.Invoke_O__O(arg_983) } else { arg_979 = linked_981.(*A_arbace_classes_env_superclass_chain_A).Invoke_O_O__O(root_980, arg_983) }; if linked_976 == nil { arg_974 = ifn_977.Invoke_O_O__O(arg_978, arg_979) } else { arg_974 = linked_976.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_975, arg_978, arg_979) }; if linked_972 == nil { or__1927000174__auto____4 = ifn_973.Invoke_O__O(arg_974) } else { or__1927000174__auto____4 = linked_972.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_971, arg_974) }; if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { return Lit_4 } } else {
//line :250:1
									return nil
								}
							}
						}
				}
		}
	}
}

func A_arbace_classes_env_lub_A_New() *A_arbace_classes_env_lub_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_lub_A{}; t.Ctor(); return t }
//line :259:1
func (t *A_arbace_classes_env_lub_A) Ctor() {}
//line :259:1
func (t *A_arbace_classes_env_lub_A) Invoke_O_O_O__O(self, a__0, b__1 any) any {



	if lang.Util_Equiv_O_O__Z_NoInit(a__0, b__1) { return a__0 } else { if lang.Util_Equiv_O_O__Z_NoInit(a__0, A_arbace_classes_env_A_const_98) { return b__1 } else { if lang.Util_Equiv_O_O__Z_NoInit(b__1, A_arbace_classes_env_A_const_98) { return a__0 } else { var tmp1 any; var root_984 any = A_arbace_classes_env_A_const_103.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_984, A_arbace_classes_env_assignable_QMARK__A_fn_class); var ifn_986 lang.IFn


		if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any = a__0; var arg_988 any = b__1; if linked_985 == nil { tmp1 = ifn_986.Invoke_O_O__O(arg_987, arg_988) } else { tmp1 = linked_985.(*A_arbace_classes_env_assignable_QMARK__A).Invoke_O_O_O__O(root_984, arg_987, arg_988) }
//line :263:1
		if jrt.J2g_Truth(tmp1) { return b__1 } else { var tmp2 any; var root_989 any = A_arbace_classes_env_A_const_103.GetRawRoot__O(); var linked_990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_989, A_arbace_classes_env_assignable_QMARK__A_fn_class); var ifn_991 lang.IFn



			if linked_990 == nil { ifn_991 = lang.IFn_Cast(root_989) } else { ifn_991 = nil }; var arg_992 any = b__1; var arg_993 any = a__0; if linked_990 == nil { tmp2 = ifn_991.Invoke_O_O__O(arg_992, arg_993) } else { tmp2 = linked_990.(*A_arbace_classes_env_assignable_QMARK__A).Invoke_O_O_O__O(root_989, arg_992, arg_993) }
//line :263:1
			if jrt.J2g_Truth(tmp2) { return a__0 } else { var tmp3 any; var and__1927000168__auto____3 any; var root_994 any = A_arbace_classes_env_A_const_112.GetRawRoot__O(); var linked_995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_994, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_996 lang.IFn




				if linked_995 == nil { ifn_996 = lang.IFn_Cast(root_994) } else { ifn_996 = nil }; var arg_997 any = a__0; if linked_995 == nil { and__1927000168__auto____3 = ifn_996.Invoke_O__O(arg_997) } else { and__1927000168__auto____3 = linked_995.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_994, arg_997) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_998 any = A_arbace_classes_env_A_const_112.GetRawRoot__O(); var linked_999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_998, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_1000 lang.IFn; if linked_999 == nil { ifn_1000 = lang.IFn_Cast(root_998) } else { ifn_1000 = nil }; var arg_1001 any = b__1; if linked_999 == nil { tmp3 = ifn_1000.Invoke_O__O(arg_1001) } else { tmp3 = linked_999.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_998, arg_1001) } } else { tmp3 = and__1927000168__auto____3 }
//line :263:1
				if jrt.J2g_Truth(tmp3) { var c__3 any; var root_1002 any = A_arbace_classes_env_A_const_113.GetRawRoot__O(); var linked_1003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1002, A_arbace_classes_env_common_super_A_fn_class); var ifn_1004 lang.IFn





					if linked_1003 == nil { ifn_1004 = lang.IFn_Cast(root_1002) } else { ifn_1004 = nil }; var arg_1005 any; var root_1007 any = A_arbace_classes_env_A_const_106.GetRawRoot__O(); var linked_1008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1007, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_1009 lang.IFn; if linked_1008 == nil { ifn_1009 = lang.IFn_Cast(root_1007) } else { ifn_1009 = nil }; var arg_1010 any = a__0; if linked_1008 == nil { arg_1005 = ifn_1009.Invoke_O__O(arg_1010) } else { arg_1005 = linked_1008.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_1007, arg_1010) }; var arg_1006 any; var root_1011 any = A_arbace_classes_env_A_const_106.GetRawRoot__O(); var linked_1012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1011, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_1013 lang.IFn; if linked_1012 == nil { ifn_1013 = lang.IFn_Cast(root_1011) } else { ifn_1013 = nil }; var arg_1014 any = b__1; if linked_1012 == nil { arg_1006 = ifn_1013.Invoke_O__O(arg_1014) } else { arg_1006 = linked_1012.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_1011, arg_1014) }; if linked_1003 == nil { c__3 = ifn_1004.Invoke_O_O__O(arg_1005, arg_1006) } else { c__3 = linked_1003.(*A_arbace_classes_env_common_super_A).Invoke_O_O_O__O(root_1002, arg_1005, arg_1006) }
					if lang.Util_Equiv_O_O__Z_NoInit(c__3, Lit_4) { var sups__4 any; var tmp4 any = A_arbace_classes_env_lub_sups__28000129_A_New(); var tmp5 *jrt.Class
						var fncls__1039 /*line :270:1*/*jrt.Class = A_arbace_classes_env_lub_sups__28000129_A_fn_class

						if fncls__1039 == nil { var fncls__1039d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_classes_env_lub_sups__28000129_A_fn_class = fncls__1039d; tmp5 = fncls__1039d } else { tmp5 = fncls__1039 }; sups__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)
//line :270:1
						var common__5 any; var root_1040 any = A_arbace_classes_env_A_const_86.GetRawRoot__O(); var linked_1041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1040, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1042 lang.IFn




						if linked_1041 == nil { ifn_1042 = lang.IFn_Cast(root_1040) } else { ifn_1042 = nil }; var arg_1043 any = A_arbace_classes_env_A_const_109.GetRawRoot__O(); var arg_1044 any; var root_1045 any = A_arbace_classes_env_A_const_115.GetRawRoot__O(); var linked_1046 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1045, aot_arbace_set.A_arbace_set_intersection_A_fn_class); var ifn_1047 lang.IFn; if linked_1046 == nil { ifn_1047 = lang.IFn_Cast(root_1045) } else { ifn_1047 = nil }; var arg_1048 any; var tmp6 lang.IFn = lang.IFn_Cast(sups__4); var tmp7 any; var root_1050 any = A_arbace_classes_env_A_const_106.GetRawRoot__O(); var linked_1051 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1050, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_1052 lang.IFn; if linked_1051 == nil { ifn_1052 = lang.IFn_Cast(root_1050) } else { ifn_1052 = nil }; var arg_1053 any = a__0; if linked_1051 == nil { tmp7 = ifn_1052.Invoke_O__O(arg_1053) } else { tmp7 = linked_1051.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_1050, arg_1053) }; arg_1048 = tmp6.Invoke_O__O(tmp7); var arg_1049 any; var tmp8 lang.IFn = lang.IFn_Cast(sups__4); var tmp9 any; var root_1054 any = A_arbace_classes_env_A_const_106.GetRawRoot__O(); var linked_1055 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1054, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_1056 lang.IFn
						if linked_1055 == nil { ifn_1056 = lang.IFn_Cast(root_1054) } else { ifn_1056 = nil }; var arg_1057 any = b__1; if linked_1055 == nil { tmp9 = ifn_1056.Invoke_O__O(arg_1057) } else { tmp9 = linked_1055.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_1054, arg_1057) }; arg_1049 = tmp8.Invoke_O__O(tmp9)
//line :275:1
						if linked_1046 == nil { arg_1044 = ifn_1047.Invoke_O_O__O(arg_1048, arg_1049) } else { arg_1044 = linked_1046.(*aot_arbace_set.A_arbace_set_intersection_A).Invoke_O_O_O__O(root_1045, arg_1048, arg_1049) }; if linked_1041 == nil { common__5 = ifn_1042.Invoke_O_O__O(arg_1043, arg_1044) } else { common__5 = linked_1041.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1040, arg_1043, arg_1044) }
//line :270:1
						var minimal__6 any; var root_1058 any = A_arbace_classes_env_A_const_116.GetRawRoot__O(); var linked_1059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1058, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1060 lang.IFn






						if linked_1059 == nil { ifn_1060 = lang.IFn_Cast(root_1058) } else { ifn_1060 = nil }; var arg_1061 any; var tmp10 any = A_arbace_classes_env_lub_fn__28000134_A_New_O(common__5); var tmp11 *jrt.Class; var fncls__1079 *jrt.Class = A_arbace_classes_env_lub_fn__28000134_A_fn_class; if fncls__1079 == nil { var fncls__1079d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_classes_env_lub_fn__28000134_A_fn_class = fncls__1079d; tmp11 = fncls__1079d } else { tmp11 = fncls__1079 }; arg_1061 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var arg_1062 any = common__5; if linked_1059 == nil { minimal__6 = ifn_1060.Invoke_O_O__O(arg_1061, arg_1062) } else { minimal__6 = linked_1059.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1058, arg_1061, arg_1062) }
						if lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(minimal__6))) { var root_1080 any = A_arbace_classes_env_A_const_118.GetRawRoot__O(); var linked_1081 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1080, aot_arbace_classes_types.A_arbace_classes_types_internal__GT_desc_A_fn_class); var ifn_1082 lang.IFn; if linked_1081 == nil { ifn_1082 = lang.IFn_Cast(root_1080) } else { ifn_1082 = nil }; var arg_1083 any; var root_1084 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_1085 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1084, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1086 lang.IFn; if linked_1085 == nil { ifn_1086 = lang.IFn_Cast(root_1084) } else { ifn_1086 = nil }; var arg_1087 any = minimal__6; if linked_1085 == nil { arg_1083 = ifn_1086.Invoke_O__O(arg_1087) } else { arg_1083 = linked_1085.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1084, arg_1087) }; if linked_1081 == nil { return ifn_1082.Invoke_O__O(arg_1083) } else { return linked_1081.(*aot_arbace_classes_types.A_arbace_classes_types_internal__GT_desc_A).Invoke_O_O__O(root_1080, arg_1083) } } else { return A_arbace_classes_env_A_const_100.GetRawRoot__O() } } else {
							var root_1088 any = A_arbace_classes_env_A_const_118.GetRawRoot__O(); var linked_1089 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1088, aot_arbace_classes_types.A_arbace_classes_types_internal__GT_desc_A_fn_class); var ifn_1090 lang.IFn; if linked_1089 == nil { ifn_1090 = lang.IFn_Cast(root_1088) } else { ifn_1090 = nil }; var arg_1091 any = c__3; if linked_1089 == nil { return ifn_1090.Invoke_O__O(arg_1091) } else { return linked_1089.(*aot_arbace_classes_types.A_arbace_classes_types_internal__GT_desc_A).Invoke_O_O__O(root_1088, arg_1091) } } } else {
//line :263:1
								if A_arbace_classes_env_A_const_104 != nil { return A_arbace_classes_env_A_const_100.GetRawRoot__O() } else { return nil
								}
							}
			}
		}
	}
	}
	}
}
func A_arbace_classes_env_lub_sups__28000129_A_New() *A_arbace_classes_env_lub_sups__28000129_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_lub_sups__28000129_A{}; t.Ctor(); return t }
//line :272:1
func (t *A_arbace_classes_env_lub_sups__28000129_A) Ctor() {}
//line :272:1
func (t *A_arbace_classes_env_lub_sups__28000129_A) Invoke_O_O__O(self, n__1 any) any { var root_1015 any = A_arbace_classes_env_A_const_110.GetRawRoot__O(); var linked_1016 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1015, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_1017 lang.IFn; if linked_1016 == nil { ifn_1017 = lang.IFn_Cast(root_1015) } else { ifn_1017 = nil }; var arg_1018 any; var root_1019 any = A_arbace_classes_env_A_const_114.GetRawRoot__O(); var linked_1020 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1019, aot_arbace_core.A_arbace_core_tree_seq_A_fn_class); var ifn_1021 lang.IFn; if linked_1020 == nil { ifn_1021 = lang.IFn_Cast(root_1019) } else { ifn_1021 = nil }; var arg_1022 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var arg_1023 any; var tmp1 any = A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_New(); var tmp2 *jrt.Class; var fncls__1038 *jrt.Class = A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_fn_class; if fncls__1038 == nil { var fncls__1038d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_fn_class = fncls__1038d; tmp2 = fncls__1038d } else { tmp2 = fncls__1038 }; arg_1023 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1024 any = n__1; if linked_1020 == nil { arg_1018 = ifn_1021.Invoke_O_O_O__O(arg_1022, arg_1023, arg_1024) } else { arg_1018 = linked_1020.(*aot_arbace_core.A_arbace_core_tree_seq_A).Invoke_O_O_O_O__O(root_1019, arg_1022, arg_1023, arg_1024) }; if linked_1016 == nil { return ifn_1017.Invoke_O__O(arg_1018) } else { return linked_1016.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1015, arg_1018) } }
//line :272:1
func A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_New() *A_arbace_classes_env_lub_sups__28000129_fn__28000130_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_lub_sups__28000129_fn__28000130_A{}; t.Ctor(); return t }
//line :272:1
func (t *A_arbace_classes_env_lub_sups__28000129_fn__28000130_A) Ctor() {}
//line :272:1
func (t *A_arbace_classes_env_lub_sups__28000129_fn__28000130_A) Invoke_O_O__O(self, x__1 any) any { var temp__1927000414__auto____2 any; var root_1025 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_1026 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1025, A_arbace_classes_env_info_A_fn_class); var ifn_1027 lang.IFn; if linked_1026 == nil { ifn_1027 = lang.IFn_Cast(root_1025) } else { ifn_1027 = nil }; var arg_1028 any = x__1; if linked_1026 == nil { temp__1927000414__auto____2 = ifn_1027.Invoke_O__O(arg_1028) } else { temp__1927000414__auto____2 = linked_1026.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1025, arg_1028) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var i__3 any = temp__1927000414__auto____2; var G__28000131__4_ any; var root_1029 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_1030 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1029, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1031 lang.IFn
													if linked_1030 == nil { ifn_1031 = lang.IFn_Cast(root_1029) } else { ifn_1031 = nil }; var arg_1032 any = A_arbace_classes_env_A_const_46.Invoke_O__O(i__3); if linked_1030 == nil { G__28000131__4_ = ifn_1031.Invoke_O__O(arg_1032) } else { G__28000131__4_ = linked_1030.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1029, arg_1032) }; if jrt.J2g_Truth(A_arbace_classes_env_A_const_45.Invoke_O__O(i__3)) { var root_1033 any = A_arbace_classes_env_A_const_10.GetRawRoot__O(); var linked_1034 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1033, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1035 lang.IFn; if linked_1034 == nil { ifn_1035 = lang.IFn_Cast(root_1033) } else { ifn_1035 = nil }; var arg_1036 any = G__28000131__4_; var arg_1037 any = A_arbace_classes_env_A_const_45.Invoke_O__O(i__3); if linked_1034 == nil { return ifn_1035.Invoke_O_O__O(arg_1036, arg_1037) } else { return linked_1034.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1033, arg_1036, arg_1037) } } else { return G__28000131__4_ } } else {
//line :272:1
		return nil } }




func A_arbace_classes_env_lub_fn__28000134_A_New_O(p0 any) *A_arbace_classes_env_lub_fn__28000134_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_lub_fn__28000134_A{}; t.Ctor_O(p0); return t }
//line :277:1
func (t *A_arbace_classes_env_lub_fn__28000134_A) Ctor_O(c__common any) { t.F_common = c__common }
//line :277:1
func (t *A_arbace_classes_env_lub_fn__28000134_A) Invoke_O_O__O(self, i__1 any) any { var root_1063 any = A_arbace_classes_env_A_const_96.GetRawRoot__O(); var linked_1064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1063, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1065 lang.IFn; if linked_1064 == nil { ifn_1065 = lang.IFn_Cast(root_1063) } else { ifn_1065 = nil }; var arg_1066 any; var tmp1 any = A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_New_O(i__1); var tmp2 *jrt.Class; var fncls__1078 *jrt.Class = A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_fn_class; if fncls__1078 == nil { var fncls__1078d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_fn_class = fncls__1078d; tmp2 = fncls__1078d } else { tmp2 = fncls__1078 }; arg_1066 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1067 any = t.F_common; if linked_1064 == nil { return ifn_1065.Invoke_O_O__O(arg_1066, arg_1067) } else { return linked_1064.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1063, arg_1066, arg_1067) } }
//line :277:1
func A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_New_O(p0 any) *A_arbace_classes_env_lub_fn__28000134_fn__28000135_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_lub_fn__28000134_fn__28000135_A{}; t.Ctor_O(p0); return t }
//line :277:1
func (t *A_arbace_classes_env_lub_fn__28000134_fn__28000135_A) Ctor_O(c__i any) { t.F_i = c__i }
//line :277:1
func (t *A_arbace_classes_env_lub_fn__28000134_fn__28000135_A) Invoke_O_O__O(self, p1__28000128_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_1068 any = A_arbace_classes_env_A_const_117.GetRawRoot__O(); var linked_1069 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1068, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1070 lang.IFn; if linked_1069 == nil { ifn_1070 = lang.IFn_Cast(root_1068) } else { ifn_1070 = nil }; var arg_1071 any = p1__28000128_SHARP___1; var arg_1072 any = t.F_i; if linked_1069 == nil { and__1927000168__auto____2 = ifn_1070.Invoke_O_O__O(arg_1071, arg_1072) } else { and__1927000168__auto____2 = linked_1069.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1068, arg_1071, arg_1072) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_1073 any = A_arbace_classes_env_A_const_97.GetRawRoot__O(); var linked_1074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1073, A_arbace_classes_env_subclass_QMARK__A_fn_class); var ifn_1075 lang.IFn; if linked_1074 == nil { ifn_1075 = lang.IFn_Cast(root_1073) } else { ifn_1075 = nil }; var arg_1076 any = p1__28000128_SHARP___1; var arg_1077 any = t.F_i; if linked_1074 == nil { return ifn_1075.Invoke_O_O__O(arg_1076, arg_1077) } else { return linked_1074.(*A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(root_1073, arg_1076, arg_1077) } } else { return and__1927000168__auto____2 } }






func A_arbace_classes_env_nest_host_A_New() *A_arbace_classes_env_nest_host_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_nest_host_A{}; t.Ctor(); return t }
//line :284:1
func (t *A_arbace_classes_env_nest_host_A) Ctor() {}
//line :284:1
func (t *A_arbace_classes_env_nest_host_A) Invoke_O_O__O(self, n__0 any) any { var i__2 any; var root_1092 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_1093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1092, A_arbace_classes_env_info_A_fn_class); var ifn_1094 lang.IFn; if
										linked_1093 == nil { ifn_1094 = lang.IFn_Cast(root_1092) } else { ifn_1094 = nil }; var arg_1095 any = n__0; if linked_1093 == nil { i__2 = ifn_1094.Invoke_O__O(arg_1095) } else { i__2 = linked_1093.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1092, arg_1095) }; var or__1927000174__auto____3 any = /*line :284:1*/A_arbace_classes_env_A_const_48.Invoke_O__O(i__2); if

	jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var temp__1927000408__auto____4 any = A_arbace_classes_env_A_const_49.Invoke_O__O(i__2)
		if jrt.J2g_Truth(temp__1927000408__auto____4) { var o__5 any = temp__1927000408__auto____4; var root_1096 any = A_arbace_classes_env_A_const_119.GetRawRoot__O(); var linked_1097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1096, A_arbace_classes_env_nest_host_A_fn_class); var ifn_1098 lang.IFn; if linked_1097 == nil { ifn_1098 = lang.IFn_Cast(root_1096) } else { ifn_1098 = nil }; var arg_1099 any = o__5; if linked_1097 == nil { return ifn_1098.Invoke_O__O(arg_1099) } else { return linked_1097.(*A_arbace_classes_env_nest_host_A).Invoke_O_O__O(root_1096, arg_1099) } } else { return n__0 } } }

func A_arbace_classes_env_flag_QMARK__A_New() *A_arbace_classes_env_flag_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_flag_QMARK__A{}; t.Ctor(); return t }
//line :289:1
func (t *A_arbace_classes_env_flag_QMARK__A) Ctor() {}
//line :289:1
func (t *A_arbace_classes_env_flag_QMARK__A) Invoke_O_O_O__O(self, flags__0, f__1 any) any { var root_1100 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_1101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1100, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1102 lang.IFn; if linked_1101 == nil { ifn_1102 = lang.IFn_Cast(root_1100) } else { ifn_1102 = nil }; var arg_1103 any; var tmp1 int64; var na_1104 any = flags__0; var na_1105 any = f__1; var tmp2 bool; var tmp3 bool; tmp3 = jrt.Long_InstanceOf(na_1104); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_1105) }; tmp2 = tmp3; if tmp2 { var n0_1106 int64 = jrt.NN(jrt.Long_Cast(na_1104)).LongValue__J(); var n1_1107 int64 = jrt.NN(jrt.Long_Cast(na_1105)).LongValue__J(); tmp1 = n0_1106 & n1_1107 } else { tmp1 = lang.Numbers_And_O_O__J_NoInit(na_1104, na_1105) }; arg_1103 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(tmp1)).Ref(); if linked_1101 == nil { return ifn_1102.Invoke_O__O(arg_1103) } else { return linked_1101.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1100, arg_1103) } }

func A_arbace_classes_env_accessible_QMARK__A_New() *A_arbace_classes_env_accessible_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_accessible_QMARK__A{}; t.Ctor(); return t }
//line :291:1
func (t *A_arbace_classes_env_accessible_QMARK__A) Ctor() {}
//line :291:1
func (t *A_arbace_classes_env_accessible_QMARK__A) Invoke_O_O_O__O(self, from__0, m__1 any) any { var fl__3 any = A_arbace_classes_env_A_const_43.Invoke_O__O(m__1); var owner__4 any = A_arbace_classes_env_A_const_63.Invoke_O__O(m__1); var tmp1 any; var root_1109 any = A_arbace_classes_env_A_const_120.GetRawRoot__O(); var linked_1110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1109, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1111 lang.IFn; if




	linked_1110 == nil { ifn_1111 = lang.IFn_Cast(root_1109) } else { ifn_1111 = nil }; var arg_1112 any = fl__3; var arg_1113 any = A_arbace_classes_env_A_const_121; if linked_1110 == nil { tmp1 = ifn_1111.Invoke_O_O__O(arg_1112, arg_1113) } else { tmp1 = linked_1110.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1109, arg_1112, arg_1113) }; if /*line :295:1*/ jrt.J2g_Truth(tmp1) { return jrt.Boolean_TRUE.Ref() } else { var tmp2 any; var root_1114 any = A_arbace_classes_env_A_const_120.GetRawRoot__O(); var linked_1115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1114, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1116 lang.IFn

		if linked_1115 == nil { ifn_1116 = lang.IFn_Cast(root_1114) } else { ifn_1116 = nil }; var arg_1117 any = fl__3; var arg_1118 any = A_arbace_classes_env_A_const_122; if linked_1115 == nil { tmp2 = ifn_1116.Invoke_O_O__O(arg_1117, arg_1118) } else { tmp2 = linked_1115.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1114, arg_1117, arg_1118) }
//line :295:1
		if jrt.J2g_Truth(tmp2) {

			var tmp3 any; var root_1119 any = A_arbace_classes_env_A_const_119.GetRawRoot__O(); var linked_1120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1119, A_arbace_classes_env_nest_host_A_fn_class); var ifn_1121 lang.IFn; if linked_1120 == nil { ifn_1121 = lang.IFn_Cast(root_1119) } else { ifn_1121 = nil }; var arg_1122 any = from__0; if linked_1120 == nil { tmp3 = ifn_1121.Invoke_O__O(arg_1122) } else { tmp3 = linked_1120.(*A_arbace_classes_env_nest_host_A).Invoke_O_O__O(root_1119, arg_1122) }; var tmp4 any = tmp3; var tmp5 any; var root_1123 any = A_arbace_classes_env_A_const_119.GetRawRoot__O(); var linked_1124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1123, A_arbace_classes_env_nest_host_A_fn_class); var ifn_1125 lang.IFn; if linked_1124 == nil { ifn_1125 = lang.IFn_Cast(root_1123) } else { ifn_1125 = nil }; var arg_1126 any = owner__4; if linked_1124 == nil { tmp5 = ifn_1125.Invoke_O__O(arg_1126) } else { tmp5 = linked_1124.(*A_arbace_classes_env_nest_host_A).Invoke_O_O__O(root_1123, arg_1126) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5)).Ref() } else {
//line :295:1
				var tmp6 any; var root_1127 any = A_arbace_classes_env_A_const_123.GetRawRoot__O(); var linked_1128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1127, aot_arbace_classes_types.A_arbace_classes_types_package_of_A_fn_class); var ifn_1129 lang.IFn


				if linked_1128 == nil { ifn_1129 = lang.IFn_Cast(root_1127) } else { ifn_1129 = nil }; var arg_1130 any = from__0; if linked_1128 == nil { tmp6 = ifn_1129.Invoke_O__O(arg_1130) } else { tmp6 = linked_1128.(*aot_arbace_classes_types.A_arbace_classes_types_package_of_A).Invoke_O_O__O(root_1127, arg_1130) }
//line :295:1
				var tmp7 any = tmp6; var tmp8 any; var root_1131 any = A_arbace_classes_env_A_const_123.GetRawRoot__O(); var linked_1132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1131, aot_arbace_classes_types.A_arbace_classes_types_package_of_A_fn_class); var ifn_1133 lang.IFn


				if linked_1132 == nil { ifn_1133 = lang.IFn_Cast(root_1131) } else { ifn_1133 = nil }; var arg_1134 any = owner__4; if linked_1132 == nil { tmp8 = ifn_1133.Invoke_O__O(arg_1134) } else { tmp8 = linked_1132.(*aot_arbace_classes_types.A_arbace_classes_types_package_of_A).Invoke_O_O__O(root_1131, arg_1134) }
//line :295:1
				if lang.Util_Equiv_O_O__Z_NoInit(tmp7, tmp8) { return jrt.Boolean_TRUE.Ref() } else { var tmp9 any; var root_1135 any = A_arbace_classes_env_A_const_120.GetRawRoot__O(); var linked_1136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1135, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1137 lang.IFn



					if linked_1136 == nil { ifn_1137 = lang.IFn_Cast(root_1135) } else { ifn_1137 = nil }; var arg_1138 any = fl__3; var arg_1139 any = A_arbace_classes_env_A_const_124; if linked_1136 == nil { tmp9 = ifn_1137.Invoke_O_O__O(arg_1138, arg_1139) } else { tmp9 = linked_1136.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1135, arg_1138, arg_1139) }
//line :295:1
					if jrt.J2g_Truth(tmp9) {




						var tmp10 any; var root_1140 any = A_arbace_classes_env_A_const_96.GetRawRoot__O(); var linked_1141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1140, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1142 lang.IFn; if linked_1141 == nil { ifn_1142 = lang.IFn_Cast(root_1140) } else { ifn_1142 = nil }; var arg_1143 any; var tmp11 any = A_arbace_classes_env_accessible_QMARK__fn__28000143_A_New_O(owner__4); var tmp12 *jrt.Class; var fncls__1150 *jrt.Class = A_arbace_classes_env_accessible_QMARK__fn__28000143_A_fn_class; if fncls__1150 == nil { var fncls__1150d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_classes_env_accessible_QMARK__fn__28000143_A_fn_class = fncls__1150d; tmp12 = fncls__1150d } else { tmp12 = fncls__1150 }; arg_1143 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var arg_1144 any; var root_1151 any = A_arbace_classes_env_A_const_107.GetRawRoot__O(); var linked_1152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1151, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_1153 lang.IFn
						if linked_1152 == nil { ifn_1153 = lang.IFn_Cast(root_1151) } else { ifn_1153 = nil }; var arg_1154 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var arg_1155 any; var root_1156 any = A_arbace_classes_env_A_const_108.GetRawRoot__O(); var linked_1157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1156, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_1158 lang.IFn; if linked_1157 == nil { ifn_1158 = lang.IFn_Cast(root_1156) } else { ifn_1158 = nil }; var arg_1159 any; var tmp13 any = A_arbace_classes_env_accessible_QMARK__fn__28000145_A_New(); var tmp14 *jrt.Class; var fncls__1165 *jrt.Class = A_arbace_classes_env_accessible_QMARK__fn__28000145_A_fn_class; if fncls__1165 == nil { var fncls__1165d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_classes_env_accessible_QMARK__fn__28000145_A_fn_class = fncls__1165d; tmp14 = fncls__1165d } else { tmp14 = fncls__1165 }; arg_1159 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); var arg_1160 any = from__0; if linked_1157 == nil { arg_1155 = ifn_1158.Invoke_O_O__O(arg_1159, arg_1160) } else { arg_1155 = linked_1157.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_1156, arg_1159, arg_1160) }; if linked_1152 == nil { arg_1144 = ifn_1153.Invoke_O_O__O(arg_1154, arg_1155) } else { arg_1144 = linked_1152.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_1151, arg_1154, arg_1155) }
//line :300:1
						if linked_1141 == nil { tmp10 = ifn_1142.Invoke_O_O__O(arg_1143, arg_1144) } else { tmp10 = linked_1141.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1140, arg_1143, arg_1144) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp10)).Ref() } else {
//line :295:1
							if A_arbace_classes_env_A_const_104 != nil { return jrt.Boolean_FALSE.Ref() } else { return nil } } } } } }




func A_arbace_classes_env_accessible_QMARK__fn__28000143_A_New_O(p0 any) *A_arbace_classes_env_accessible_QMARK__fn__28000143_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_accessible_QMARK__fn__28000143_A{}; t.Ctor_O(p0); return t }
//line :300:1
func (t *A_arbace_classes_env_accessible_QMARK__fn__28000143_A) Ctor_O(c__owner any) { t.F_owner = c__owner }
//line :300:1
func (t *A_arbace_classes_env_accessible_QMARK__fn__28000143_A) Invoke_O_O__O(self, p1__28000141_SHARP___1 any) any { var root_1145 any = A_arbace_classes_env_A_const_97.GetRawRoot__O(); var linked_1146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1145, A_arbace_classes_env_subclass_QMARK__A_fn_class); var ifn_1147 lang.IFn; if linked_1146 == nil { ifn_1147 = lang.IFn_Cast(root_1145) } else { ifn_1147 = nil }; var arg_1148 any = p1__28000141_SHARP___1; var arg_1149 any = t.F_owner; if linked_1146 == nil { return ifn_1147.Invoke_O_O__O(arg_1148, arg_1149) } else { return linked_1146.(*A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(root_1145, arg_1148, arg_1149) } }
func A_arbace_classes_env_accessible_QMARK__fn__28000145_A_New() *A_arbace_classes_env_accessible_QMARK__fn__28000145_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_accessible_QMARK__fn__28000145_A{}; t.Ctor(); return t }
//line :301:1
func (t *A_arbace_classes_env_accessible_QMARK__fn__28000145_A) Ctor() {}
//line :301:1
func (t *A_arbace_classes_env_accessible_QMARK__fn__28000145_A) Invoke_O_O__O(self, p1__28000142_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_classes_env_A_const_49; var tmp2 any; var root_1161 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_1162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1161, A_arbace_classes_env_info_A_fn_class); var ifn_1163 lang.IFn; if linked_1162 == nil { ifn_1163 = lang.IFn_Cast(root_1161) } else { ifn_1163 = nil }; var arg_1164 any = p1__28000142_SHARP___1; if linked_1162 == nil { tmp2 = ifn_1163.Invoke_O__O(arg_1164) } else { tmp2 = linked_1162.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1161, arg_1164) }; return tmp1.Invoke_O__O(tmp2) }


func A_arbace_classes_env_find_field_A_New() *A_arbace_classes_env_find_field_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_find_field_A{}; t.Ctor(); return t }
//line :304:1
func (t *A_arbace_classes_env_find_field_A) Ctor() {}
//line :304:1
func (t *A_arbace_classes_env_find_field_A) Invoke_O_O_O__O(self, n__0, name__1 any) any { var temp__1927000414__auto____3 any; var root_1166 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_1167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1166, A_arbace_classes_env_info_A_fn_class); var ifn_1168 lang.IFn; if



	linked_1167 == nil { ifn_1168 = lang.IFn_Cast(root_1166) } else { ifn_1168 = nil }; var arg_1169 any = n__0; if linked_1167 == nil { temp__1927000414__auto____3 = ifn_1168.Invoke_O__O(arg_1169) } else { temp__1927000414__auto____3 = linked_1167.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1166, arg_1169) }; if jrt.J2g_Truth(temp__1927000414__auto____3) { var i__4 any = temp__1927000414__auto____3; var or__1927000174__auto____5 any; var root_1170 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_1171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1170, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1172 lang.IFn
		if linked_1171 == nil { ifn_1172 = lang.IFn_Cast(root_1170) } else { ifn_1172 = nil }; var arg_1173 any; var root_1174 any = A_arbace_classes_env_A_const_86.GetRawRoot__O(); var linked_1175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1174, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1176 lang.IFn; if linked_1175 == nil { ifn_1176 = lang.IFn_Cast(root_1174) } else { ifn_1176 = nil }; var arg_1177 any; var tmp1 any = A_arbace_classes_env_find_field_fn__28000150_A_New_O(name__1); var tmp2 *jrt.Class; var fncls__1179 *jrt.Class = A_arbace_classes_env_find_field_fn__28000150_A_fn_class; if fncls__1179 == nil { var fncls__1179d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_classes_env_find_field_fn__28000150_A_fn_class = fncls__1179d; tmp2 = fncls__1179d } else { tmp2 = fncls__1179 }; arg_1177 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1178 any = A_arbace_classes_env_A_const_50.Invoke_O__O(i__4); if linked_1175 == nil { arg_1173 = ifn_1176.Invoke_O_O__O(arg_1177, arg_1178) } else { arg_1173 = linked_1175.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1174, arg_1177, arg_1178) }; if linked_1171 == nil { or__1927000174__auto____5 = ifn_1172.Invoke_O__O(arg_1173) } else { or__1927000174__auto____5 = linked_1171.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1170, arg_1173) }; if jrt.J2g_Truth(or__1927000174__auto____5) { return or__1927000174__auto____5 } else { var or__1927000174__auto____6 any; var root_1180 any = A_arbace_classes_env_A_const_96.GetRawRoot__O(); var linked_1181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1180, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1182 lang.IFn
			if linked_1181 == nil { ifn_1182 = lang.IFn_Cast(root_1180) } else { ifn_1182 = nil }; var arg_1183 any; var tmp3 any = A_arbace_classes_env_find_field_fn__28000152_A_New_O(name__1); var tmp4 *jrt.Class; var fncls__1190 *jrt.Class = A_arbace_classes_env_find_field_fn__28000152_A_fn_class; if fncls__1190 == nil { var fncls__1190d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_classes_env_find_field_fn__28000152_A_fn_class = fncls__1190d; tmp4 = fncls__1190d } else { tmp4 = fncls__1190 }; arg_1183 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_1184 any = A_arbace_classes_env_A_const_46.Invoke_O__O(i__4); if linked_1181 == nil { or__1927000174__auto____6 = ifn_1182.Invoke_O_O__O(arg_1183, arg_1184) } else { or__1927000174__auto____6 = linked_1181.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1180, arg_1183, arg_1184) }
//line :309:1
			if jrt.J2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else { var G__28000154__7_ any = A_arbace_classes_env_A_const_45.Invoke_O__O(i__4)

				if lang.Util_Identical_O_O__Z_NoInit(G__28000154__7_, nil) { return nil } else { var root_1191 any = A_arbace_classes_env_A_const_125.GetRawRoot__O(); var linked_1192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1191, A_arbace_classes_env_find_field_A_fn_class); var ifn_1193 lang.IFn; if linked_1192 == nil { ifn_1193 = lang.IFn_Cast(root_1191) } else { ifn_1193 = nil }; var arg_1194 any = G__28000154__7_; var arg_1195 any = name__1; if linked_1192 == nil { return ifn_1193.Invoke_O_O__O(arg_1194, arg_1195) } else { return linked_1192.(*A_arbace_classes_env_find_field_A).Invoke_O_O_O__O(root_1191, arg_1194, arg_1195) } } } } } else {
//line :308:1
					return nil } }
func A_arbace_classes_env_find_field_fn__28000150_A_New_O(p0 any) *A_arbace_classes_env_find_field_fn__28000150_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_find_field_fn__28000150_A{}; t.Ctor_O(p0); return t }
//line :309:1
func (t *A_arbace_classes_env_find_field_fn__28000150_A) Ctor_O(c__name any) { t.F_name = c__name }
//line :309:1
func (t *A_arbace_classes_env_find_field_fn__28000150_A) Invoke_O_O__O(self, p1__28000148_SHARP___1 any) any { var tmp1 any = t.F_name; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_classes_env_A_const_42.Invoke_O__O(p1__28000148_SHARP___1))).Ref() }
func A_arbace_classes_env_find_field_fn__28000152_A_New_O(p0 any) *A_arbace_classes_env_find_field_fn__28000152_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_find_field_fn__28000152_A{}; t.Ctor_O(p0); return t }
//line :310:1
func (t *A_arbace_classes_env_find_field_fn__28000152_A) Ctor_O(c__name any) { t.F_name = c__name }
//line :310:1
func (t *A_arbace_classes_env_find_field_fn__28000152_A) Invoke_O_O__O(self, p1__28000149_SHARP___1 any) any { var root_1185 any = A_arbace_classes_env_A_const_125.GetRawRoot__O(); var linked_1186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1185, A_arbace_classes_env_find_field_A_fn_class); var ifn_1187 lang.IFn; if linked_1186 == nil { ifn_1187 = lang.IFn_Cast(root_1185) } else { ifn_1187 = nil }; var arg_1188 any = p1__28000149_SHARP___1; var arg_1189 any = t.F_name; if linked_1186 == nil { return ifn_1187.Invoke_O_O__O(arg_1188, arg_1189) } else { return linked_1186.(*A_arbace_classes_env_find_field_A).Invoke_O_O_O__O(root_1185, arg_1188, arg_1189) } }


func A_arbace_classes_env_same_infos_QMARK__A_New() *A_arbace_classes_env_same_infos_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_same_infos_QMARK__A{}; t.Ctor(); return t }
//line :313:1
func (t *A_arbace_classes_env_same_infos_QMARK__A) Ctor() {}
//line :313:1
func (t *A_arbace_classes_env_same_infos_QMARK__A) Invoke_O_O_O__O(self, names__0, infos__1 any) any { { var n__3 int32 = lang.RT_Count_O__I_NoInit(names__0); var cs__4 any; var G__28000156__4_ any = A_arbace_classes_env_A_const_89.Get__O()



	if lang.Util_Identical_O_O__Z_NoInit(G__28000156__4_, nil) { cs__4 = nil } else { var root_1196 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_1197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1196, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1198 lang.IFn; if linked_1197 == nil { ifn_1198 = lang.IFn_Cast(root_1196) } else { ifn_1198 = nil }; var arg_1199 any = G__28000156__4_; if linked_1197 == nil { cs__4 = ifn_1198.Invoke_O__O(arg_1199) } else { cs__4 = linked_1197.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1196, arg_1199) } }
//line :313:1
	var i__5 int64 = 0; L1: for { var or__1927000174__auto____6 bool = lang.Util_Equiv_J_J__Z_NoInit(i__5, int64(n__3))





		if or__1927000174__auto____6 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____6).Ref() } else { var and__1927000168__auto____7 any; var c__7 any = lang.RT_Nth_O_I__O_NoInit(names__0, lang.RT_IntCast_J__I_NoInit(i__5)); var x__8 any = lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](infos__1, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(i__5)); var or__1927000174__auto____9 any; var and__1927000168__auto____9 any; var root_1200 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1200, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_1202 lang.IFn



			if linked_1201 == nil { ifn_1202 = lang.IFn_Cast(root_1200) } else { ifn_1202 = nil }; var arg_1203 any = x__8; if linked_1201 == nil { and__1927000168__auto____9 = ifn_1202.Invoke_O__O(arg_1203) } else { and__1927000168__auto____9 = linked_1201.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_1200, arg_1203) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 any; var root_1204 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1204, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_1206 lang.IFn; if linked_1205 == nil { ifn_1206 = lang.IFn_Cast(root_1204) } else { ifn_1206 = nil }; var arg_1207 any = cs__4; if linked_1205 == nil { and__1927000168__auto____10 = ifn_1206.Invoke_O__O(arg_1207) } else { and__1927000168__auto____10 = linked_1205.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_1204, arg_1207) }; if jrt.J2g_Truth(and__1927000168__auto____10) { var and__1927000168__auto____11 bool = lang.Util_Identical_O_O__Z_NoInit(x__8, lang.RT_Get_O_O__O_NoInit(cs__4, c__7)); if and__1927000168__auto____11 { var root_1208 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_1209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1208, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1210 lang.IFn; if linked_1209 == nil { ifn_1210 = lang.IFn_Cast(root_1208) } else { ifn_1210 = nil }; var arg_1211 any; var root_1212 any = A_arbace_classes_env_A_const_20.GetRawRoot__O(); var linked_1213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1212, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1214 lang.IFn; if linked_1213 == nil { ifn_1214 = lang.IFn_Cast(root_1212) } else { ifn_1214 = nil }; var arg_1215 any = c__7; var arg_1216 any = Lit_11; if linked_1213 == nil { arg_1211 = ifn_1214.Invoke_O_O__O(arg_1215, arg_1216) } else { arg_1211 = linked_1213.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1212, arg_1215, arg_1216) }; if linked_1209 == nil { or__1927000174__auto____9 = ifn_1210.Invoke_O__O(arg_1211) } else { or__1927000174__auto____9 = linked_1209.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1208, arg_1211) } } else { or__1927000174__auto____9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11).Ref() } } else { or__1927000174__auto____9 = and__1927000168__auto____10 } } else { or__1927000174__auto____9 = and__1927000168__auto____9 }; if jrt.J2g_Truth(or__1927000174__auto____9) { and__1927000168__auto____7 = or__1927000174__auto____9 } else {
				var tmp1 any; var root_1217 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_1218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1217, A_arbace_classes_env_info_A_fn_class); var ifn_1219 lang.IFn; if linked_1218 == nil { ifn_1219 = lang.IFn_Cast(root_1217) } else { ifn_1219 = nil }; var arg_1220 any = c__7; if linked_1218 == nil { tmp1 = ifn_1219.Invoke_O__O(arg_1220) } else { tmp1 = linked_1218.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1217, arg_1220) }; and__1927000168__auto____7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp1, x__8)).Ref() }
//line :320:1
			if jrt.J2g_Truth(and__1927000168__auto____7) {




				i__5 = lang.Numbers_Inc_J__J_NoInit(i__5); continue L1 } else {
//line :320:1
					return and__1927000168__auto____7 } } } }; /*line :313:1*/panic("j2g: unreachable") }













func A_arbace_classes_env_infos_now_A_New() *A_arbace_classes_env_infos_now_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_infos_now_A{}; t.Ctor(); return t }
//line :327:1
func (t *A_arbace_classes_env_infos_now_A) Ctor() {}
//line :327:1
func (t *A_arbace_classes_env_infos_now_A) Invoke_O_O__O(self, names__0 any) any { var a__2 any = lang.RT_Object_array_O__O1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(names__0)).Ref()).Ref(); var n__1927000701__auto____3 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_Count_O__I_NoInit(names__0)); var i__4 int64 = 0; L1: for {

	if lang.Numbers_Lt_J_J__Z_NoInit(i__4, n__1927000701__auto____3) { var tmp1 *jrt.RefArray = jrt.J2g_CastArray[*jrt.RefArray](a__2, jrt.Object_class.ArrayClass()); var tmp2 int32 = lang.RT_IntCast_J__I_NoInit(i__4); var tmp3 any; var root_1221 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_1222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1221, A_arbace_classes_env_info_A_fn_class); var ifn_1223 lang.IFn; if linked_1222 == nil { ifn_1223 = lang.IFn_Cast(root_1221) } else { ifn_1223 = nil }; var arg_1224 any = lang.RT_Nth_O_I__O_NoInit(names__0, lang.RT_IntCast_J__I_NoInit(i__4)); if linked_1222 == nil { tmp3 = ifn_1223.Invoke_O__O(arg_1224) } else { tmp3 = linked_1222.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1221, arg_1224) }; lang.RT_Aset_O1_I_O__O_NoInit(tmp1, tmp2, tmp3); i__4 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__4); continue L1 }
//line :327:1
	break L1 }; return a__2 }
















func A_arbace_classes_env_all_supertypes_STAR__A_New() *A_arbace_classes_env_all_supertypes_STAR__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_all_supertypes_STAR__A{}; t.Ctor(); return t }
//line :344:1
func (t *A_arbace_classes_env_all_supertypes_STAR__A) Ctor() {}
//line :344:1
func (t *A_arbace_classes_env_all_supertypes_STAR__A) Invoke_O_O__O(self, n__0 any) any { { var chain__2 any; var root_1225 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_1226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1225, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1227 lang.IFn

	if linked_1226 == nil { ifn_1227 = lang.IFn_Cast(root_1225) } else { ifn_1227 = nil }; var arg_1228 any; var root_1229 any = A_arbace_classes_env_A_const_111.GetRawRoot__O(); var linked_1230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1229, A_arbace_classes_env_superclass_chain_A_fn_class); var ifn_1231 lang.IFn; if linked_1230 == nil { ifn_1231 = lang.IFn_Cast(root_1229) } else { ifn_1231 = nil }; var arg_1232 any = n__0; if linked_1230 == nil { arg_1228 = ifn_1231.Invoke_O__O(arg_1232) } else { arg_1228 = linked_1230.(*A_arbace_classes_env_superclass_chain_A).Invoke_O_O__O(root_1229, arg_1232) }; if linked_1226 == nil { chain__2 = ifn_1227.Invoke_O__O(arg_1228) } else { chain__2 = linked_1226.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1225, arg_1228) }
//line :344:1
	var out__3 any = chain__2; var seen__4 any; var root_1233 any = A_arbace_classes_env_A_const_110.GetRawRoot__O(); var linked_1234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1233, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_1235 lang.IFn


	if linked_1234 == nil { ifn_1235 = lang.IFn_Cast(root_1233) } else { ifn_1235 = nil }; var arg_1236 any = chain__2; if linked_1234 == nil { seen__4 = ifn_1235.Invoke_O__O(arg_1236) } else { seen__4 = linked_1234.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1233, arg_1236) }
//line :344:1
	var queue__5 any; var root_1237 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_1238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1237, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1239 lang.IFn


	if linked_1238 == nil { ifn_1239 = lang.IFn_Cast(root_1237) } else { ifn_1239 = nil }; var arg_1240 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_126.GetRawRoot__O()); var tmp2 any = A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A_New(); var tmp3 *jrt.Class; var fncls__1250 *jrt.Class = A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A_fn_class; if fncls__1250 == nil { var fncls__1250d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A_fn_class = fncls__1250d; tmp3 = fncls__1250d } else { tmp3 = fncls__1250 }; arg_1240 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), chain__2); if linked_1238 == nil { queue__5 = ifn_1239.Invoke_O__O(arg_1240) } else { queue__5 = linked_1238.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1237, arg_1240) }
//line :344:1
L1: for { var temp__1927000408__auto____6 any; var root_1251 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_1252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1251, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1253 lang.IFn



	if linked_1252 == nil { ifn_1253 = lang.IFn_Cast(root_1251) } else { ifn_1253 = nil }; var arg_1254 any = queue__5; if linked_1252 == nil { temp__1927000408__auto____6 = ifn_1253.Invoke_O__O(arg_1254) } else { temp__1927000408__auto____6 = linked_1252.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1251, arg_1254) }; if jrt.J2g_Truth(temp__1927000408__auto____6) { var vec__28000162__7 any = temp__1927000408__auto____6; var seq__28000163__8 any; var root_1255 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_1256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1255, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1257 lang.IFn; if linked_1256 == nil { ifn_1257 = lang.IFn_Cast(root_1255) } else { ifn_1257 = nil }; var arg_1258 any = vec__28000162__7; if linked_1256 == nil { seq__28000163__8 = ifn_1257.Invoke_O__O(arg_1258) } else { seq__28000163__8 = linked_1256.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1255, arg_1258) }; var first__28000164__9 any; var root_1259 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_1260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1259, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1261 lang.IFn; if linked_1260 == nil { ifn_1261 = lang.IFn_Cast(root_1259) } else { ifn_1261 = nil }; var arg_1262 any = seq__28000163__8; if linked_1260 == nil { first__28000164__9 = ifn_1261.Invoke_O__O(arg_1262) } else { first__28000164__9 = linked_1260.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1259, arg_1262) }; var seq__28000163__10 any; var root_1263 any = A_arbace_classes_env_A_const_57.GetRawRoot__O(); var linked_1264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1263, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1265 lang.IFn; if linked_1264 == nil { ifn_1265 = lang.IFn_Cast(root_1263) } else { ifn_1265 = nil }; var arg_1266 any = seq__28000163__8; if linked_1264 == nil { seq__28000163__10 = ifn_1265.Invoke_O__O(arg_1266) } else { seq__28000163__10 = linked_1264.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1263, arg_1266) }; var q__11 any = first__28000164__9; var more__12 any = seq__28000163__10
		if jrt.J2g_Truth(lang.IFn_Cast(seen__4).Invoke_O__O(q__11)) {
			var tmp4 any; var root_1280 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_1281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1280, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1282 lang.IFn; if linked_1281 == nil { ifn_1282 = lang.IFn_Cast(root_1280) } else { ifn_1282 = nil }; var arg_1283 any = more__12; if linked_1281 == nil { tmp4 = ifn_1282.Invoke_O__O(arg_1283) } else { tmp4 = linked_1281.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1280, arg_1283) }; out__3, seen__4, queue__5 = out__3, seen__4, tmp4; continue L1 } else {
				var tmp5 any; var root_1284 any = A_arbace_classes_env_A_const_10.GetRawRoot__O(); var linked_1285 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1284, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1286 lang.IFn; if linked_1285 == nil { ifn_1286 = lang.IFn_Cast(root_1284) } else { ifn_1286 = nil }; var arg_1287 any = out__3; var arg_1288 any = q__11; if linked_1285 == nil { tmp5 = ifn_1286.Invoke_O_O__O(arg_1287, arg_1288) } else { tmp5 = linked_1285.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1284, arg_1287, arg_1288) }; var tmp6 any = tmp5; var tmp7 any; var root_1289 any = A_arbace_classes_env_A_const_10.GetRawRoot__O(); var linked_1290 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1289, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1291 lang.IFn; if linked_1290 == nil { ifn_1291 = lang.IFn_Cast(root_1289) } else { ifn_1291 = nil }; var arg_1292 any = seen__4; var arg_1293 any = q__11; if linked_1290 == nil { tmp7 = ifn_1291.Invoke_O_O__O(arg_1292, arg_1293) } else { tmp7 = linked_1290.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1289, arg_1292, arg_1293) }; var tmp8 any = tmp7; var tmp9 any; var root_1294 any = A_arbace_classes_env_A_const_87.GetRawRoot__O(); var linked_1295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1294, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1296 lang.IFn; if linked_1295 == nil { ifn_1296 = lang.IFn_Cast(root_1294) } else { ifn_1296 = nil }; var arg_1297 any; var root_1299 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_1300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1299, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1301 lang.IFn; if linked_1300 == nil { ifn_1301 = lang.IFn_Cast(root_1299) } else { ifn_1301 = nil }; var arg_1302 any = more__12; if linked_1300 == nil { arg_1297 = ifn_1301.Invoke_O__O(arg_1302) } else { arg_1297 = linked_1300.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1299, arg_1302) }; var arg_1298 any; var tmp10 *lang.Keyword = A_arbace_classes_env_A_const_46; var tmp11 any; var root_1303 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_1304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1303, A_arbace_classes_env_info_A_fn_class); var ifn_1305 lang.IFn; if linked_1304 == nil { ifn_1305 = lang.IFn_Cast(root_1303) } else { ifn_1305 = nil }; var arg_1306 any = q__11; if linked_1304 == nil { tmp11 = ifn_1305.Invoke_O__O(arg_1306) } else { tmp11 = linked_1304.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1303, arg_1306) }; arg_1298 = tmp10.Invoke_O__O(tmp11); if linked_1295 == nil { tmp9 = ifn_1296.Invoke_O_O__O(arg_1297, arg_1298) } else { tmp9 = linked_1295.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1294, arg_1297, arg_1298) }; out__3, seen__4, queue__5 = tmp6, tmp8, tmp9; continue L1 } } else {
//line :348:1
					var G__28000165__7_ any = out__3; var tmp12 any; var and__1927000168__auto____8 any; var root_1267 any = A_arbace_classes_env_A_const_109.GetRawRoot__O(); var linked_1268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1267, A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_1269 lang.IFn



					if linked_1268 == nil { ifn_1269 = lang.IFn_Cast(root_1267) } else { ifn_1269 = nil }; var arg_1270 any = n__0; if linked_1268 == nil { and__1927000168__auto____8 = ifn_1269.Invoke_O__O(arg_1270) } else { and__1927000168__auto____8 = linked_1268.(*A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_1267, arg_1270) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_1271 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_1272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1271, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1273 lang.IFn; if linked_1272 == nil { ifn_1273 = lang.IFn_Cast(root_1271) } else { ifn_1273 = nil }; var arg_1274 any = lang.IFn_Cast(seen__4).Invoke_O__O(Lit_4); if linked_1272 == nil { tmp12 = ifn_1273.Invoke_O__O(arg_1274) } else { tmp12 = linked_1272.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1271, arg_1274) } } else { tmp12 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp12) { var root_1275 any = A_arbace_classes_env_A_const_10.GetRawRoot__O(); var linked_1276 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1275, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1277 lang.IFn; if linked_1276 == nil { ifn_1277 = lang.IFn_Cast(root_1275) } else { ifn_1277 = nil }; var arg_1278 any = G__28000165__7_; var arg_1279 any = Lit_4; if linked_1276 == nil { return ifn_1277.Invoke_O_O__O(arg_1278, arg_1279) } else { return linked_1276.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1275, arg_1278, arg_1279) } } else { return G__28000165__7_ } } } }; /*line :344:1*/panic("j2g: unreachable") }


func A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A_New() *A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A{}; t.Ctor(); return t }
//line :347:1
func (t *A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A) Ctor() {}
//line :347:1
func (t *A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A) Invoke_O_O__O(self, p1__28000159_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_classes_env_A_const_46; var tmp2 any; var root_1246 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_1247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1246, A_arbace_classes_env_info_A_fn_class); var ifn_1248 lang.IFn; if linked_1247 == nil { ifn_1248 = lang.IFn_Cast(root_1246) } else { ifn_1248 = nil }; var arg_1249 any = p1__28000159_SHARP___1; if linked_1247 == nil { tmp2 = ifn_1248.Invoke_O__O(arg_1249) } else { tmp2 = linked_1247.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1246, arg_1249) }; return tmp1.Invoke_O__O(tmp2) }






func A_arbace_classes_env_all_supertypes_A_New() *A_arbace_classes_env_all_supertypes_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_all_supertypes_A{}; t.Ctor(); return t }
//line :354:1
func (t *A_arbace_classes_env_all_supertypes_A) Ctor() {}
//line :354:1
func (t *A_arbace_classes_env_all_supertypes_A) Invoke_O_O__O(self, n__0 any) any { var e__2 any; if


	jrt.J2g_Truth(n__0) { e__2 = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_127.GetRawRoot__O())).Get_O__O(n__0) } else { e__2 = nil }; var tmp1 any; var and__1927000168__auto____3 any = e__2; if
	jrt.J2g_Truth(and__1927000168__auto____3) { var root_1307 any = A_arbace_classes_env_A_const_128.GetRawRoot__O(); var linked_1308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1307, A_arbace_classes_env_same_infos_QMARK__A_fn_class); var ifn_1309 lang.IFn; if linked_1308 == nil { ifn_1309 = lang.IFn_Cast(root_1307) } else { ifn_1309 = nil }; var arg_1310 any = lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](e__2, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0)); var arg_1311 any = lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](e__2, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(1)); if linked_1308 == nil { tmp1 = ifn_1309.Invoke_O_O__O(arg_1310, arg_1311) } else { tmp1 = linked_1308.(*A_arbace_classes_env_same_infos_QMARK__A).Invoke_O_O_O__O(root_1307, arg_1310, arg_1311) } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		return lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](e__2, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0)) } else {
//line :358:1
			var r__3 any; var root_1312 any = A_arbace_classes_env_A_const_129.GetRawRoot__O(); var linked_1313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1312, A_arbace_classes_env_all_supertypes_STAR__A_fn_class); var ifn_1314 lang.IFn

			if linked_1313 == nil { ifn_1314 = lang.IFn_Cast(root_1312) } else { ifn_1314 = nil }; var arg_1315 any = n__0; if linked_1313 == nil { r__3 = ifn_1314.Invoke_O__O(arg_1315) } else { r__3 = linked_1313.(*A_arbace_classes_env_all_supertypes_STAR__A).Invoke_O_O__O(root_1312, arg_1315) }
//line :358:1
			var infos__4 any; var root_1316 any = A_arbace_classes_env_A_const_130.GetRawRoot__O(); var linked_1317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1316, A_arbace_classes_env_infos_now_A_fn_class); var ifn_1318 lang.IFn


			if linked_1317 == nil { ifn_1318 = lang.IFn_Cast(root_1316) } else { ifn_1318 = nil }; var arg_1319 any = r__3; if linked_1317 == nil { infos__4 = ifn_1318.Invoke_O__O(arg_1319) } else { infos__4 = linked_1317.(*A_arbace_classes_env_infos_now_A).Invoke_O_O__O(root_1316, arg_1319)
			}
			var tmp2 any; var and__1927000168__auto____5 any = n__0; if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp3 any; var root_1320 any = A_arbace_classes_env_A_const_129.GetRawRoot__O(); var linked_1321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1320, A_arbace_classes_env_all_supertypes_STAR__A_fn_class); var ifn_1322 lang.IFn; if linked_1321 == nil { ifn_1322 = lang.IFn_Cast(root_1320) } else { ifn_1322 = nil }; var arg_1323 any = n__0; if linked_1321 == nil { tmp3 = ifn_1322.Invoke_O__O(arg_1323) } else { tmp3 = linked_1321.(*A_arbace_classes_env_all_supertypes_STAR__A).Invoke_O_O__O(root_1320, arg_1323) }; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(r__3, tmp3)).Ref() } else { tmp2 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp2) {
				jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_127.GetRawRoot__O())).Put_O_O__O(n__0, lang.RT_Object_array_O__O1_NoInit(lang.Tuple_Create_O_O__IPersistentVector(r__3, infos__4)).Ref()) }
//line :358:1
			return r__3 } }








func A_arbace_classes_env_params_key_A_New() *A_arbace_classes_env_params_key_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_params_key_A{}; t.Ctor(); return t }
//line :367:1
func (t *A_arbace_classes_env_params_key_A) Ctor() {}
//line :367:1
func (t *A_arbace_classes_env_params_key_A) Invoke_O_O__O(self, desc__0 any) any { var root_1324 any = A_arbace_classes_env_A_const_131.GetRawRoot__O(); var linked_1325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1324, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1326 lang.IFn; if linked_1325 == nil { ifn_1326 = lang.IFn_Cast(root_1324) } else { ifn_1326 = nil }; var arg_1327 any = desc__0; var arg_1328 any = A_arbace_classes_env_A_const_132; var arg_1329 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(jrt.NN(jrt.String_Cast(desc__0)).IndexOf_String__I(Lit_30)))).Ref(); if linked_1325 == nil { return ifn_1326.Invoke_O_O_O__O(arg_1327, arg_1328, arg_1329) } else { return linked_1325.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1324, arg_1327, arg_1328, arg_1329) } }

func A_arbace_classes_env_member_methods_STAR__A_New() *A_arbace_classes_env_member_methods_STAR__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_member_methods_STAR__A{}; t.Ctor(); return t }
//line :369:1
func (t *A_arbace_classes_env_member_methods_STAR__A) Ctor() {}
//line :369:1
func (t *A_arbace_classes_env_member_methods_STAR__A) Invoke_O_O_O_O__O(self, n__0, name__1, sups__2 any) any { { var G__28000172__4_ any = sups__2; var vec__28000173__5 any = G__28000172__4_; var seq__28000174__6 any; var root_1330 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_1331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1330, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1332 lang.IFn

	if linked_1331 == nil { ifn_1332 = lang.IFn_Cast(root_1330) } else { ifn_1332 = nil }; var arg_1333 any = vec__28000173__5; if linked_1331 == nil { seq__28000174__6 = ifn_1332.Invoke_O__O(arg_1333) } else { seq__28000174__6 = linked_1331.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1330, arg_1333) }
//line :369:1
	var first__28000175__7 any; var root_1334 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_1335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1334, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1336 lang.IFn

	if linked_1335 == nil { ifn_1336 = lang.IFn_Cast(root_1334) } else { ifn_1336 = nil }; var arg_1337 any = seq__28000174__6; if linked_1335 == nil { first__28000175__7 = ifn_1336.Invoke_O__O(arg_1337) } else { first__28000175__7 = linked_1335.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1334, arg_1337) }
//line :369:1
	var seq__28000174__8 any; var root_1338 any = A_arbace_classes_env_A_const_57.GetRawRoot__O(); var linked_1339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1338, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1340 lang.IFn

	if linked_1339 == nil { ifn_1340 = lang.IFn_Cast(root_1338) } else { ifn_1340 = nil }; var arg_1341 any = seq__28000174__6; if linked_1339 == nil { seq__28000174__8 = ifn_1340.Invoke_O__O(arg_1341) } else { seq__28000174__8 = linked_1339.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1338, arg_1341) }
//line :369:1
	var c__9 any = first__28000175__7; var more__10 any = seq__28000174__8; var seen__11 any = lang.PersistentHashSet_EMPTY.Ref(); var out__12 any = lang.PersistentVector_EMPTY.Ref(); var G__28000172__13_ any = G__28000172__4_; var seen__14 any = seen__11; var out__15 any = out__12; _ = c__9; _ = more__10; L1: for { var vec__28000176__16 any = G__28000172__13_; var seq__28000177__17 any; var root_1342 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_1343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1342, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1344 lang.IFn

		if linked_1343 == nil { ifn_1344 = lang.IFn_Cast(root_1342) } else { ifn_1344 = nil }; var arg_1345 any = vec__28000176__16; if linked_1343 == nil { seq__28000177__17 = ifn_1344.Invoke_O__O(arg_1345) } else { seq__28000177__17 = linked_1343.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1342, arg_1345) }
//line :369:1
		var first__28000178__18 any; var root_1346 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_1347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1346, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1348 lang.IFn

		if linked_1347 == nil { ifn_1348 = lang.IFn_Cast(root_1346) } else { ifn_1348 = nil }; var arg_1349 any = seq__28000177__17; if linked_1347 == nil { first__28000178__18 = ifn_1348.Invoke_O__O(arg_1349) } else { first__28000178__18 = linked_1347.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1346, arg_1349) }
//line :369:1
		var seq__28000177__19 any; var root_1350 any = A_arbace_classes_env_A_const_57.GetRawRoot__O(); var linked_1351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1350, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1352 lang.IFn

		if linked_1351 == nil { ifn_1352 = lang.IFn_Cast(root_1350) } else { ifn_1352 = nil }; var arg_1353 any = seq__28000177__17; if linked_1351 == nil { seq__28000177__19 = ifn_1352.Invoke_O__O(arg_1353) } else { seq__28000177__19 = linked_1351.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1350, arg_1353) }
//line :369:1
		var c__20 any = first__28000178__18; var more__21 any = seq__28000177__19; var seen__22 any = seen__14; var out__23 any = out__15; var tmp1 any; var root_1354 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_1355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1354, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1356 lang.IFn


		if linked_1355 == nil { ifn_1356 = lang.IFn_Cast(root_1354) } else { ifn_1356 = nil }; var arg_1357 any = c__20; if linked_1355 == nil { tmp1 = ifn_1356.Invoke_O__O(arg_1357) } else { tmp1 = linked_1355.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1354, arg_1357) }; if jrt.J2g_Truth(tmp1) { return out__23 } else { var ms__24 any; var iter__1927001039__auto____24 any; var tmp2 any = A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A_New_O_O_O_O(seen__22, name__1, n__0, c__20); var tmp3 *jrt.Class
			var fncls__1522 /*line :372:1*/*jrt.Class = A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A_fn_class

			if fncls__1522 == nil { var fncls__1522d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A_fn_class = fncls__1522d; tmp3 = fncls__1522d } else { tmp3 = fncls__1522 }; iter__1927001039__auto____24 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp4 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____24); var tmp5 *lang.Keyword = A_arbace_classes_env_A_const_76; var tmp6 any; var root_1523 any = A_arbace_classes_env_A_const_95.GetRawRoot__O(); var linked_1524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1523, A_arbace_classes_env_info_BANG__A_fn_class); var ifn_1525 lang.IFn; if linked_1524 == nil { ifn_1525 = lang.IFn_Cast(root_1523) } else { ifn_1525 = nil }; var arg_1526 any = c__20; if linked_1524 == nil { tmp6 = ifn_1525.Invoke_O__O(arg_1526) } else { tmp6 = linked_1524.(*A_arbace_classes_env_info_BANG__A).Invoke_O_O__O(root_1523, arg_1526) }; ms__24 = tmp4.Invoke_O__O(tmp5.Invoke_O__O(tmp6))






			var tmp7 any; var root_1527 any = A_arbace_classes_env_A_const_87.GetRawRoot__O(); var linked_1528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1527, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1529 lang.IFn; if linked_1528 == nil { ifn_1529 = lang.IFn_Cast(root_1527) } else { ifn_1529 = nil }; var arg_1530 any = seen__22; var arg_1531 any; var root_1532 any = A_arbace_classes_env_A_const_79.GetRawRoot__O(); var linked_1533 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1532, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1534 lang.IFn; if linked_1533 == nil { ifn_1534 = lang.IFn_Cast(root_1532) } else { ifn_1534 = nil }; var arg_1535 any; var root_1537 any = A_arbace_classes_env_A_const_136.GetRawRoot__O(); var linked_1538 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1537, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_1539 lang.IFn; if linked_1538 == nil { ifn_1539 = lang.IFn_Cast(root_1537) } else { ifn_1539 = nil }; var arg_1540 any = A_arbace_classes_env_A_const_135.GetRawRoot__O(); var arg_1541 any = A_arbace_classes_env_A_const_60; if linked_1538 == nil { arg_1535 = ifn_1539.Invoke_O_O__O(arg_1540, arg_1541) } else { arg_1535 = linked_1538.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_1537, arg_1540, arg_1541) }; var arg_1536 any = ms__24; if linked_1533 == nil { arg_1531 = ifn_1534.Invoke_O_O__O(arg_1535, arg_1536) } else { arg_1531 = linked_1533.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1532, arg_1535, arg_1536) }; if linked_1528 == nil { tmp7 = ifn_1529.Invoke_O_O__O(arg_1530, arg_1531) } else { tmp7 = linked_1528.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1527, arg_1530, arg_1531) }; var tmp8 any = tmp7; var tmp9 any; var root_1542 any = A_arbace_classes_env_A_const_87.GetRawRoot__O(); var linked_1543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1542, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1544 lang.IFn; if linked_1543 == nil { ifn_1544 = lang.IFn_Cast(root_1542) } else { ifn_1544 = nil }; var arg_1545 any = out__23; var arg_1546 any = ms__24; if linked_1543 == nil { tmp9 = ifn_1544.Invoke_O_O__O(arg_1545, arg_1546) } else { tmp9 = linked_1543.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1542, arg_1545, arg_1546) }; G__28000172__13_, seen__14, out__15 = more__21, tmp8, tmp9; continue L1 } } }; /*line :369:1*/panic("j2g: unreachable") }




func A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :374:1
func (t *A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A) Ctor_O_O_O_O(c__seen, c__name, c__n, c__c any) { t.F_seen = c__seen; t.F_name = c__name; t.F_n = c__n; t.F_c = c__c }
//line :374:1
func (t *A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A) Invoke_O_O__O(self, s__28000180__1 any) any { var tmp1 any = A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A_New_O_O_O_O_O_O(self, t.F_seen, t.F_name, t.F_n, t.F_c, s__28000180__1); var tmp2 *jrt.Class; var fncls__1521 *jrt.Class = A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A_fn_class; if fncls__1521 == nil { var fncls__1521d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A_fn_class = fncls__1521d; tmp2 = fncls__1521d } else { tmp2 = fncls__1521 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :374:1
func A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :374:1
func (t *A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A) Ctor_O_O_O_O_O_O(c__iter__28000179, c__seen, c__name, c__n, c__c, c__s__28000180 any) { t.F_iter__28000179 = c__iter__28000179; t.F_seen = c__seen; t.F_name = c__name; t.F_n = c__n; t.F_c = c__c; t.F_s__28000180 = c__s__28000180 }
//line :374:1
func (t *A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A) Invoke_O__O(self any) any { { var s__28000180__1 any; var t_ any = t.F_s__28000180; t.F_s__28000180 = nil; s__28000180__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1358 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_1359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1358, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1360 lang.IFn; if linked_1359 == nil { ifn_1360 = lang.IFn_Cast(root_1358) } else { ifn_1360 = nil }; var arg_1361 any = s__28000180__1; if linked_1359 == nil { temp__1927000414__auto____2 = ifn_1360.Invoke_O__O(arg_1361) } else { temp__1927000414__auto____2 = linked_1359.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1358, arg_1361) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__28000180__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1362 any = A_arbace_classes_env_A_const_54.GetRawRoot__O(); var linked_1363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1362, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1364 lang.IFn; if linked_1363 == nil { ifn_1364 = lang.IFn_Cast(root_1362) } else { ifn_1364 = nil }; var arg_1365 any = s__28000180__3; if linked_1363 == nil { tmp1 = ifn_1364.Invoke_O__O(arg_1365) } else { tmp1 = linked_1363.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1362, arg_1365) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1366 any = A_arbace_classes_env_A_const_55.GetRawRoot__O(); var linked_1367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1366, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1368 lang.IFn; if linked_1367 == nil { ifn_1368 = lang.IFn_Cast(root_1366) } else { ifn_1368 = nil }; var arg_1369 any = s__28000180__3; if linked_1367 == nil { c__1927001037__auto____4 = ifn_1368.Invoke_O__O(arg_1369) } else { c__1927001037__auto____4 = linked_1367.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1366, arg_1369) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__28000182__6 any; var root_1370 any = A_arbace_classes_env_A_const_56.GetRawRoot__O(); var linked_1371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1370, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1372 lang.IFn; if linked_1371 == nil { ifn_1372 = lang.IFn_Cast(root_1370) } else { ifn_1372 = nil }; var arg_1373 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1371 == nil { b__28000182__6 = ifn_1372.Invoke_O__O(arg_1373) } else { b__28000182__6 = linked_1371.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1370, arg_1373) }; var tmp2 any = A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A_New_O_O_O_O_I_O_O(t.F_seen, t.F_name, t.F_n, t.F_c, size__1927001038__auto____5, b__28000182__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1422 *jrt.Class = A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A_fn_class; if fncls__1422 == nil { var fncls__1422d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A_fn_class = fncls__1422d; tmp3 = fncls__1422d } else { tmp3 = fncls__1422 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1423 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_1424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1423, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1425 lang.IFn; if linked_1424 == nil { ifn_1425 = lang.IFn_Cast(root_1423) } else { ifn_1425 = nil }; var arg_1426 any; var root_1428 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_1429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1428, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1430 lang.IFn; if linked_1429 == nil { ifn_1430 = lang.IFn_Cast(root_1428) } else { ifn_1430 = nil }; var arg_1431 any = b__28000182__6; if linked_1429 == nil { arg_1426 = ifn_1430.Invoke_O__O(arg_1431) } else { arg_1426 = linked_1429.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1428, arg_1431) }; var arg_1427 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__28000179); var tmp5 any; var root_1432 any = A_arbace_classes_env_A_const_70.GetRawRoot__O(); var linked_1433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1432, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1434 lang.IFn; if linked_1433 == nil { ifn_1434 = lang.IFn_Cast(root_1432) } else { ifn_1434 = nil }; var arg_1435 any = s__28000180__3; if linked_1433 == nil { tmp5 = ifn_1434.Invoke_O__O(arg_1435) } else { tmp5 = linked_1433.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1432, arg_1435) }; arg_1427 = tmp4.Invoke_O__O(tmp5); if linked_1424 == nil { return ifn_1425.Invoke_O_O__O(arg_1426, arg_1427) } else { return linked_1424.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1423, arg_1426, arg_1427) } } else { var root_1436 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_1437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1436, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1438 lang.IFn; if linked_1437 == nil { ifn_1438 = lang.IFn_Cast(root_1436) } else { ifn_1438 = nil }; var arg_1439 any; var root_1441 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_1442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1441, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1443 lang.IFn; if linked_1442 == nil { ifn_1443 = lang.IFn_Cast(root_1441) } else { ifn_1443 = nil }; var arg_1444 any = b__28000182__6; if linked_1442 == nil { arg_1439 = ifn_1443.Invoke_O__O(arg_1444) } else { arg_1439 = linked_1442.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1441, arg_1444) }; var arg_1440 any; if linked_1437 == nil { return ifn_1438.Invoke_O_O__O(arg_1439, arg_1440) } else { return linked_1437.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1436, arg_1439, arg_1440) } } } else { var m__4 any; var root_1445 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_1446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1445, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1447 lang.IFn; if linked_1446 == nil { ifn_1447 = lang.IFn_Cast(root_1445) } else { ifn_1447 = nil }; var arg_1448 any = s__28000180__3; if linked_1446 == nil { m__4 = ifn_1447.Invoke_O__O(arg_1448) } else { m__4 = linked_1446.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1445, arg_1448) }; var tmp6 any = t.F_name; if lang.Util_Equiv_O_O__Z_NoInit(tmp6, A_arbace_classes_env_A_const_42.Invoke_O__O(m__4)) { var tmp7 any; var root_1449 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_1450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1449, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1451 lang.IFn

	if linked_1450 == nil { ifn_1451 = lang.IFn_Cast(root_1449) } else { ifn_1451 = nil }; var arg_1452 any; var root_1453 any = A_arbace_classes_env_A_const_120.GetRawRoot__O(); var linked_1454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1453, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1455 lang.IFn; if linked_1454 == nil { ifn_1455 = lang.IFn_Cast(root_1453) } else { ifn_1455 = nil }; var arg_1456 any = A_arbace_classes_env_A_const_43.Invoke_O__O(m__4); var arg_1457 any = A_arbace_classes_env_A_const_133; if linked_1454 == nil { arg_1452 = ifn_1455.Invoke_O_O__O(arg_1456, arg_1457) } else { arg_1452 = linked_1454.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1453, arg_1456, arg_1457) }; if linked_1450 == nil { tmp7 = ifn_1451.Invoke_O__O(arg_1452) } else { tmp7 = linked_1450.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1449, arg_1452) }
//line :374:1
	if jrt.J2g_Truth(tmp7) { var tmp8 any; var or__1927000174__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(t.F_c, t.F_n)


		if or__1927000174__auto____5 { tmp8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var root_1458 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_1459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1458, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1460 lang.IFn; if linked_1459 == nil { ifn_1460 = lang.IFn_Cast(root_1458) } else { ifn_1460 = nil }; var arg_1461 any; var root_1462 any = A_arbace_classes_env_A_const_120.GetRawRoot__O(); var linked_1463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1462, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1464 lang.IFn; if linked_1463 == nil { ifn_1464 = lang.IFn_Cast(root_1462) } else { ifn_1464 = nil }; var arg_1465 any = A_arbace_classes_env_A_const_43.Invoke_O__O(m__4); var arg_1466 any = A_arbace_classes_env_A_const_122; if linked_1463 == nil { arg_1461 = ifn_1464.Invoke_O_O__O(arg_1465, arg_1466) } else { arg_1461 = linked_1463.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1462, arg_1465, arg_1466) }; if linked_1459 == nil { tmp8 = ifn_1460.Invoke_O__O(arg_1461) } else { tmp8 = linked_1459.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1458, arg_1461) } }
//line :374:1
		if jrt.J2g_Truth(tmp8) { var tmp9 any; var or__1927000174__auto____5_2 bool = lang.Util_Equiv_O_O__Z_NoInit(t.F_c, t.F_n)



			if or__1927000174__auto____5_2 { tmp9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5_2).Ref() } else { var or__1927000174__auto____6 any; var root_1467 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_1468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1467, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1469 lang.IFn; if linked_1468 == nil { ifn_1469 = lang.IFn_Cast(root_1467) } else { ifn_1469 = nil }; var arg_1470 any; var root_1471 any = A_arbace_classes_env_A_const_109.GetRawRoot__O(); var linked_1472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1471, A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_1473 lang.IFn; if linked_1472 == nil { ifn_1473 = lang.IFn_Cast(root_1471) } else { ifn_1473 = nil }; var arg_1474 any = t.F_c; if linked_1472 == nil { arg_1470 = ifn_1473.Invoke_O__O(arg_1474) } else { arg_1470 = linked_1472.(*A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_1471, arg_1474) }; if linked_1468 == nil { or__1927000174__auto____6 = ifn_1469.Invoke_O__O(arg_1470) } else { or__1927000174__auto____6 = linked_1468.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1467, arg_1470) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp9 = or__1927000174__auto____6 } else { var root_1475 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_1476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1475, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1477 lang.IFn; if linked_1476 == nil { ifn_1477 = lang.IFn_Cast(root_1475) } else { ifn_1477 = nil }; var arg_1478 any; var root_1479 any = A_arbace_classes_env_A_const_120.GetRawRoot__O(); var linked_1480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1479, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1481 lang.IFn; if linked_1480 == nil { ifn_1481 = lang.IFn_Cast(root_1479) } else { ifn_1481 = nil }; var arg_1482 any = A_arbace_classes_env_A_const_43.Invoke_O__O(m__4); var arg_1483 any = A_arbace_classes_env_A_const_134; if linked_1480 == nil { arg_1478 = ifn_1481.Invoke_O_O__O(arg_1482, arg_1483) } else { arg_1478 = linked_1480.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1479, arg_1482, arg_1483) }; if linked_1476 == nil { tmp9 = ifn_1477.Invoke_O__O(arg_1478) } else { tmp9 = linked_1476.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1475, arg_1478) } } }
//line :374:1
			if jrt.J2g_Truth(tmp9) { var tmp10 any; var root_1484 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_1485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1484, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1486 lang.IFn




				if linked_1485 == nil { ifn_1486 = lang.IFn_Cast(root_1484) } else { ifn_1486 = nil }; var arg_1487 any; var tmp11 lang.IFn = lang.IFn_Cast(t.F_seen); var tmp12 any; var root_1488 any = A_arbace_classes_env_A_const_135.GetRawRoot__O(); var linked_1489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1488, A_arbace_classes_env_params_key_A_fn_class); var ifn_1490 lang.IFn; if linked_1489 == nil { ifn_1490 = lang.IFn_Cast(root_1488) } else { ifn_1490 = nil }; var arg_1491 any = A_arbace_classes_env_A_const_60.Invoke_O__O(m__4); if linked_1489 == nil { tmp12 = ifn_1490.Invoke_O__O(arg_1491) } else { tmp12 = linked_1489.(*A_arbace_classes_env_params_key_A).Invoke_O_O__O(root_1488, arg_1491) }; arg_1487 = tmp11.Invoke_O__O(tmp12); if linked_1485 == nil { tmp10 = ifn_1486.Invoke_O__O(arg_1487) } else { tmp10 = linked_1485.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1484, arg_1487) }
//line :374:1
				if jrt.J2g_Truth(tmp10) { var root_1492 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_1493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1492, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1494 lang.IFn; if linked_1493 == nil { ifn_1494 = lang.IFn_Cast(root_1492) } else { ifn_1494 = nil }; var arg_1495 any = m__4; var arg_1496 any; var tmp13 lang.IFn = lang.IFn_Cast(t.F_iter__28000179); var tmp14 any; var root_1497 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_1498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1497, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1499 lang.IFn; if linked_1498 == nil { ifn_1499 = lang.IFn_Cast(root_1497) } else { ifn_1499 = nil }; var arg_1500 any = s__28000180__3; if linked_1498 == nil { tmp14 = ifn_1499.Invoke_O__O(arg_1500) } else { tmp14 = linked_1498.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1497, arg_1500) }; arg_1496 = tmp13.Invoke_O__O(tmp14); if linked_1493 == nil { return ifn_1494.Invoke_O_O__O(arg_1495, arg_1496) } else { return linked_1493.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1492, arg_1495, arg_1496) } } else { var tmp15 any; var root_1501 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_1502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1501, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1503 lang.IFn; if linked_1502 == nil { ifn_1503 = lang.IFn_Cast(root_1501) } else { ifn_1503 = nil }; var arg_1504 any = s__28000180__3; if linked_1502 == nil { tmp15 = ifn_1503.Invoke_O__O(arg_1504) } else { tmp15 = linked_1502.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1501, arg_1504) }; s__28000180__1 = tmp15; continue L1 } } else { var tmp16 any; var root_1505 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_1506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1505, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1507 lang.IFn; if linked_1506 == nil { ifn_1507 = lang.IFn_Cast(root_1505) } else { ifn_1507 = nil }; var arg_1508 any = s__28000180__3; if linked_1506 == nil { tmp16 = ifn_1507.Invoke_O__O(arg_1508) } else { tmp16 = linked_1506.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1505, arg_1508) }; s__28000180__1 = tmp16; continue L1 } } else { var tmp17 any; var root_1509 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_1510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1509, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1511 lang.IFn; if linked_1510 == nil { ifn_1511 = lang.IFn_Cast(root_1509) } else { ifn_1511 = nil }; var arg_1512 any = s__28000180__3; if linked_1510 == nil { tmp17 = ifn_1511.Invoke_O__O(arg_1512) } else { tmp17 = linked_1510.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1509, arg_1512) }; s__28000180__1 = tmp17; continue L1 } } else { var tmp18 any; var root_1513 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_1514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1513, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1515 lang.IFn; if linked_1514 == nil { ifn_1515 = lang.IFn_Cast(root_1513) } else { ifn_1515 = nil }; var arg_1516 any = s__28000180__3; if linked_1514 == nil { tmp18 = ifn_1515.Invoke_O__O(arg_1516) } else { tmp18 = linked_1514.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1513, arg_1516) }; s__28000180__1 = tmp18; continue L1 } } else { var tmp19 any; var root_1517 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_1518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1517, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1519 lang.IFn; if linked_1518 == nil { ifn_1519 = lang.IFn_Cast(root_1517) } else { ifn_1519 = nil }; var arg_1520 any = s__28000180__3; if linked_1518 == nil { tmp19 = ifn_1519.Invoke_O__O(arg_1520) } else { tmp19 = linked_1518.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1517, arg_1520) }; s__28000180__1 = tmp19; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :374:1
func A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A_New_O_O_O_O_I_O_O(p0, p1, p2, p3 any, p4 int32, p5, p6 any) *A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A{}; t.Ctor_O_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :374:1
func (t *A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A) Ctor_O_O_O_O_I_O_O(c__seen, c__name, c__n, c__c any, c__size__1927001038__auto__ int32, c__b__28000182, c__c__1927001037__auto__ any) { t.F_seen = c__seen; t.F_name = c__name; t.F_n = c__n; t.F_c = c__c; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__28000182 = c__b__28000182; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :374:1
func (t *A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A) Invoke_O__O(self any) any { { var i__28000181__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__28000181__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__28000181__1)); var tmp2 any = t.F_name; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_classes_env_A_const_42.Invoke_O__O(m__2)) { var tmp3 any; var root_1374 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_1375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1374, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1376 lang.IFn

	if linked_1375 == nil { ifn_1376 = lang.IFn_Cast(root_1374) } else { ifn_1376 = nil }; var arg_1377 any; var root_1378 any = A_arbace_classes_env_A_const_120.GetRawRoot__O(); var linked_1379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1378, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1380 lang.IFn; if linked_1379 == nil { ifn_1380 = lang.IFn_Cast(root_1378) } else { ifn_1380 = nil }; var arg_1381 any = A_arbace_classes_env_A_const_43.Invoke_O__O(m__2); var arg_1382 any = A_arbace_classes_env_A_const_133; if linked_1379 == nil { arg_1377 = ifn_1380.Invoke_O_O__O(arg_1381, arg_1382) } else { arg_1377 = linked_1379.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1378, arg_1381, arg_1382) }; if linked_1375 == nil { tmp3 = ifn_1376.Invoke_O__O(arg_1377) } else { tmp3 = linked_1375.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1374, arg_1377) }
//line :374:1
	if jrt.J2g_Truth(tmp3) { var tmp4 any; var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(t.F_c, t.F_n)


		if or__1927000174__auto____3 { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var root_1383 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_1384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1383, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1385 lang.IFn; if linked_1384 == nil { ifn_1385 = lang.IFn_Cast(root_1383) } else { ifn_1385 = nil }; var arg_1386 any; var root_1387 any = A_arbace_classes_env_A_const_120.GetRawRoot__O(); var linked_1388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1387, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1389 lang.IFn; if linked_1388 == nil { ifn_1389 = lang.IFn_Cast(root_1387) } else { ifn_1389 = nil }; var arg_1390 any = A_arbace_classes_env_A_const_43.Invoke_O__O(m__2); var arg_1391 any = A_arbace_classes_env_A_const_122; if linked_1388 == nil { arg_1386 = ifn_1389.Invoke_O_O__O(arg_1390, arg_1391) } else { arg_1386 = linked_1388.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1387, arg_1390, arg_1391) }; if linked_1384 == nil { tmp4 = ifn_1385.Invoke_O__O(arg_1386) } else { tmp4 = linked_1384.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1383, arg_1386) } }
//line :374:1
		if jrt.J2g_Truth(tmp4) { var tmp5 any; var or__1927000174__auto____3_2 bool = lang.Util_Equiv_O_O__Z_NoInit(t.F_c, t.F_n)



			if or__1927000174__auto____3_2 { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3_2).Ref() } else { var or__1927000174__auto____4 any; var root_1392 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_1393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1392, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1394 lang.IFn; if linked_1393 == nil { ifn_1394 = lang.IFn_Cast(root_1392) } else { ifn_1394 = nil }; var arg_1395 any; var root_1396 any = A_arbace_classes_env_A_const_109.GetRawRoot__O(); var linked_1397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1396, A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_1398 lang.IFn; if linked_1397 == nil { ifn_1398 = lang.IFn_Cast(root_1396) } else { ifn_1398 = nil }; var arg_1399 any = t.F_c; if linked_1397 == nil { arg_1395 = ifn_1398.Invoke_O__O(arg_1399) } else { arg_1395 = linked_1397.(*A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_1396, arg_1399) }; if linked_1393 == nil { or__1927000174__auto____4 = ifn_1394.Invoke_O__O(arg_1395) } else { or__1927000174__auto____4 = linked_1393.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1392, arg_1395) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp5 = or__1927000174__auto____4 } else { var root_1400 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_1401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1400, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1402 lang.IFn; if linked_1401 == nil { ifn_1402 = lang.IFn_Cast(root_1400) } else { ifn_1402 = nil }; var arg_1403 any; var root_1404 any = A_arbace_classes_env_A_const_120.GetRawRoot__O(); var linked_1405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1404, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1406 lang.IFn; if linked_1405 == nil { ifn_1406 = lang.IFn_Cast(root_1404) } else { ifn_1406 = nil }; var arg_1407 any = A_arbace_classes_env_A_const_43.Invoke_O__O(m__2); var arg_1408 any = A_arbace_classes_env_A_const_134; if linked_1405 == nil { arg_1403 = ifn_1406.Invoke_O_O__O(arg_1407, arg_1408) } else { arg_1403 = linked_1405.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1404, arg_1407, arg_1408) }; if linked_1401 == nil { tmp5 = ifn_1402.Invoke_O__O(arg_1403) } else { tmp5 = linked_1401.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1400, arg_1403) } } }
//line :374:1
			if jrt.J2g_Truth(tmp5) { var tmp6 any; var root_1409 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_1410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1409, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1411 lang.IFn




				if linked_1410 == nil { ifn_1411 = lang.IFn_Cast(root_1409) } else { ifn_1411 = nil }; var arg_1412 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_seen); var tmp8 any; var root_1413 any = A_arbace_classes_env_A_const_135.GetRawRoot__O(); var linked_1414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1413, A_arbace_classes_env_params_key_A_fn_class); var ifn_1415 lang.IFn; if linked_1414 == nil { ifn_1415 = lang.IFn_Cast(root_1413) } else { ifn_1415 = nil }; var arg_1416 any = A_arbace_classes_env_A_const_60.Invoke_O__O(m__2); if linked_1414 == nil { tmp8 = ifn_1415.Invoke_O__O(arg_1416) } else { tmp8 = linked_1414.(*A_arbace_classes_env_params_key_A).Invoke_O_O__O(root_1413, arg_1416) }; arg_1412 = tmp7.Invoke_O__O(tmp8); if linked_1410 == nil { tmp6 = ifn_1411.Invoke_O__O(arg_1412) } else { tmp6 = linked_1410.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1409, arg_1412) }
//line :374:1
				if jrt.J2g_Truth(tmp6) { var root_1417 any = A_arbace_classes_env_A_const_62.GetRawRoot__O(); var linked_1418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1417, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1419 lang.IFn; if linked_1418 == nil { ifn_1419 = lang.IFn_Cast(root_1417) } else { ifn_1419 = nil }; var arg_1420 any = t.F_b__28000182; var arg_1421 any = m__2; if linked_1418 == nil { ifn_1419.Invoke_O_O__O(arg_1420, arg_1421) } else { linked_1418.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1417, arg_1420, arg_1421) }; i__28000181__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000181__1); continue L1 } else { i__28000181__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000181__1); continue L1 } } else { i__28000181__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000181__1); continue L1 } } else { i__28000181__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000181__1); continue L1 } } else { i__28000181__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000181__1); continue L1 } } else { i__28000181__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000181__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_classes_env_member_methods_A_New() *A_arbace_classes_env_member_methods_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_member_methods_A{}; t.Ctor(); return t }
//line :383:1
func (t *A_arbace_classes_env_member_methods_A) Ctor() {}
//line :383:1
func (t *A_arbace_classes_env_member_methods_A) Invoke_O_O_O__O(self, n__0, name__1 any) any {



	var tmp1 any; var root_1547 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_1548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1547, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1549 lang.IFn; if linked_1548 == nil { ifn_1549 = lang.IFn_Cast(root_1547) } else { ifn_1549 = nil }; var arg_1550 any; var and__1927000168__auto____3 any; var root_1551 any = A_arbace_classes_env_A_const_137.GetRawRoot__O(); var linked_1552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1551, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1553 lang.IFn; if linked_1552 == nil { ifn_1553 = lang.IFn_Cast(root_1551) } else { ifn_1553 = nil }; var arg_1554 any = n__0; if linked_1552 == nil { and__1927000168__auto____3 = ifn_1553.Invoke_O__O(arg_1554) } else { and__1927000168__auto____3 = linked_1552.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1551, arg_1554) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_1555 any = A_arbace_classes_env_A_const_137.GetRawRoot__O(); var linked_1556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1555, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1557 lang.IFn; if linked_1556 == nil { ifn_1557 = lang.IFn_Cast(root_1555) } else { ifn_1557 = nil }; var arg_1558 any = name__1; if linked_1556 == nil { arg_1550 = ifn_1557.Invoke_O__O(arg_1558) } else { arg_1550 = linked_1556.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1555, arg_1558) } } else { arg_1550 = and__1927000168__auto____3 }; if linked_1548 == nil { tmp1 = ifn_1549.Invoke_O__O(arg_1550) } else { tmp1 = linked_1548.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1547, arg_1550) }; if jrt.J2g_Truth(tmp1) {
		var root_1559 any = A_arbace_classes_env_A_const_138.GetRawRoot__O(); var linked_1560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1559, A_arbace_classes_env_member_methods_STAR__A_fn_class); var ifn_1561 lang.IFn; if linked_1560 == nil { ifn_1561 = lang.IFn_Cast(root_1559) } else { ifn_1561 = nil }; var arg_1562 any = n__0; var arg_1563 any = name__1; var arg_1564 any; var root_1565 any = A_arbace_classes_env_A_const_139.GetRawRoot__O(); var linked_1566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1565, A_arbace_classes_env_all_supertypes_A_fn_class); var ifn_1567 lang.IFn; if linked_1566 == nil { ifn_1567 = lang.IFn_Cast(root_1565) } else { ifn_1567 = nil }; var arg_1568 any = n__0; if linked_1566 == nil { arg_1564 = ifn_1567.Invoke_O__O(arg_1568) } else { arg_1564 = linked_1566.(*A_arbace_classes_env_all_supertypes_A).Invoke_O_O__O(root_1565, arg_1568) }; if linked_1560 == nil { return ifn_1561.Invoke_O_O_O__O(arg_1562, arg_1563, arg_1564) } else { return linked_1560.(*A_arbace_classes_env_member_methods_STAR__A).Invoke_O_O_O_O__O(root_1559, arg_1562, arg_1563, arg_1564) } } else {
//line :387:1
			var by_name__3 any; var or__1927000174__auto____3 any = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_140.GetRawRoot__O())).Get_O__O(n__0)


			if jrt.J2g_Truth(or__1927000174__auto____3) { by_name__3 = or__1927000174__auto____3 } else {
				jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_140.GetRawRoot__O())).PutIfAbsent_O_O__O(n__0, jrt.ConcurrentHashMap_New())
				by_name__3 = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_140.GetRawRoot__O())).Get_O__O(n__0) }
//line :387:1
			var e__4 any = jrt.NN(jrt.ConcurrentHashMap_Cast(by_name__3)).Get_O__O(name__1); var tmp2 any
			var and__1927000168__auto____5 any = e__4





			if jrt.J2g_Truth(and__1927000168__auto____5) { var root_1569 any = A_arbace_classes_env_A_const_128.GetRawRoot__O(); var linked_1570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1569, A_arbace_classes_env_same_infos_QMARK__A_fn_class); var ifn_1571 lang.IFn; if linked_1570 == nil { ifn_1571 = lang.IFn_Cast(root_1569) } else { ifn_1571 = nil }; var arg_1572 any = lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](e__4, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(1)); var arg_1573 any = lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](e__4, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(2)); if linked_1570 == nil { tmp2 = ifn_1571.Invoke_O_O__O(arg_1572, arg_1573) } else { tmp2 = linked_1570.(*A_arbace_classes_env_same_infos_QMARK__A).Invoke_O_O_O__O(root_1569, arg_1572, arg_1573) } } else { tmp2 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp2) {
				return lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](e__4, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0)) } else {
//line :394:1
					var sups__5 any; var root_1574 any = A_arbace_classes_env_A_const_139.GetRawRoot__O(); var linked_1575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1574, A_arbace_classes_env_all_supertypes_A_fn_class); var ifn_1576 lang.IFn

					if linked_1575 == nil { ifn_1576 = lang.IFn_Cast(root_1574) } else { ifn_1576 = nil }; var arg_1577 any = n__0; if linked_1575 == nil { sups__5 = ifn_1576.Invoke_O__O(arg_1577) } else { sups__5 = linked_1575.(*A_arbace_classes_env_all_supertypes_A).Invoke_O_O__O(root_1574, arg_1577) }
//line :394:1
					var infos__6 any; var root_1578 any = A_arbace_classes_env_A_const_130.GetRawRoot__O(); var linked_1579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1578, A_arbace_classes_env_infos_now_A_fn_class); var ifn_1580 lang.IFn


					if linked_1579 == nil { ifn_1580 = lang.IFn_Cast(root_1578) } else { ifn_1580 = nil }; var arg_1581 any = sups__5; if linked_1579 == nil { infos__6 = ifn_1580.Invoke_O__O(arg_1581) } else { infos__6 = linked_1579.(*A_arbace_classes_env_infos_now_A).Invoke_O_O__O(root_1578, arg_1581) }
//line :394:1
					var r__7 any; var root_1582 any = A_arbace_classes_env_A_const_138.GetRawRoot__O(); var linked_1583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1582, A_arbace_classes_env_member_methods_STAR__A_fn_class); var ifn_1584 lang.IFn



					if linked_1583 == nil { ifn_1584 = lang.IFn_Cast(root_1582) } else { ifn_1584 = nil }; var arg_1585 any = n__0; var arg_1586 any = name__1; var arg_1587 any = sups__5; if linked_1583 == nil { r__7 = ifn_1584.Invoke_O_O_O__O(arg_1585, arg_1586, arg_1587) } else { r__7 = linked_1583.(*A_arbace_classes_env_member_methods_STAR__A).Invoke_O_O_O_O__O(root_1582, arg_1585, arg_1586, arg_1587)
					}
					var tmp3 any; var and__1927000168__auto____8 bool; var tmp4 any; var root_1588 any = A_arbace_classes_env_A_const_139.GetRawRoot__O(); var linked_1589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1588, A_arbace_classes_env_all_supertypes_A_fn_class); var ifn_1590 lang.IFn; if linked_1589 == nil { ifn_1590 = lang.IFn_Cast(root_1588) } else { ifn_1590 = nil }; var arg_1591 any = n__0; if linked_1589 == nil { tmp4 = ifn_1590.Invoke_O__O(arg_1591) } else { tmp4 = linked_1589.(*A_arbace_classes_env_all_supertypes_A).Invoke_O_O__O(root_1588, arg_1591) }; and__1927000168__auto____8 = lang.Util_Equiv_O_O__Z_NoInit(sups__5, tmp4); if and__1927000168__auto____8 { var root_1592 any = A_arbace_classes_env_A_const_128.GetRawRoot__O(); var linked_1593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1592, A_arbace_classes_env_same_infos_QMARK__A_fn_class); var ifn_1594 lang.IFn; if linked_1593 == nil { ifn_1594 = lang.IFn_Cast(root_1592) } else { ifn_1594 = nil }; var arg_1595 any = sups__5; var arg_1596 any = infos__6; if linked_1593 == nil { tmp3 = ifn_1594.Invoke_O_O__O(arg_1595, arg_1596) } else { tmp3 = linked_1593.(*A_arbace_classes_env_same_infos_QMARK__A).Invoke_O_O_O__O(root_1592, arg_1595, arg_1596) } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() }; if jrt.J2g_Truth(tmp3) {
						jrt.NN(jrt.ConcurrentHashMap_Cast(by_name__3)).Put_O_O__O(name__1, lang.RT_Object_array_O__O1_NoInit(lang.Tuple_Create_O_O_O__IPersistentVector(r__7, sups__5, infos__6)).Ref()) }
//line :394:1
					return r__7
				}
		}
}






func A_arbace_classes_env_constructors_A_New() *A_arbace_classes_env_constructors_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_constructors_A{}; t.Ctor(); return t }
//line :404:1
func (t *A_arbace_classes_env_constructors_A) Ctor() {}
//line :404:1
func (t *A_arbace_classes_env_constructors_A) Invoke_O_O__O(self, n__0 any) any {
	var root_1597 any = A_arbace_classes_env_A_const_86.GetRawRoot__O(); var linked_1598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1597, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1599 lang.IFn; if linked_1598 == nil { ifn_1599 = lang.IFn_Cast(root_1597) } else { ifn_1599 = nil }; var arg_1600 any; var tmp1 any = A_arbace_classes_env_constructors_fn__28000192_A_New(); var tmp2 *jrt.Class; var fncls__1602 *jrt.Class = A_arbace_classes_env_constructors_fn__28000192_A_fn_class; if fncls__1602 == nil { var fncls__1602d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_classes_env_constructors_fn__28000192_A_fn_class = fncls__1602d; tmp2 = fncls__1602d } else { tmp2 = fncls__1602 }; arg_1600 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1601 any; var tmp3 *lang.Keyword = A_arbace_classes_env_A_const_76; var tmp4 any; var root_1603 any = A_arbace_classes_env_A_const_95.GetRawRoot__O(); var linked_1604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1603, A_arbace_classes_env_info_BANG__A_fn_class); var ifn_1605 lang.IFn; if linked_1604 == nil { ifn_1605 = lang.IFn_Cast(root_1603) } else { ifn_1605 = nil }; var arg_1606 any = n__0; if linked_1604 == nil { tmp4 = ifn_1605.Invoke_O__O(arg_1606) } else { tmp4 = linked_1604.(*A_arbace_classes_env_info_BANG__A).Invoke_O_O__O(root_1603, arg_1606) }; arg_1601 = tmp3.Invoke_O__O(tmp4); if linked_1598 == nil { return ifn_1599.Invoke_O_O__O(arg_1600, arg_1601) } else { return linked_1598.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1597, arg_1600, arg_1601) } }
//line :405:1
func A_arbace_classes_env_constructors_fn__28000192_A_New() *A_arbace_classes_env_constructors_fn__28000192_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_constructors_fn__28000192_A{}; t.Ctor(); return t }
//line :405:1
func (t *A_arbace_classes_env_constructors_fn__28000192_A) Ctor() {}
//line :405:1
func (t *A_arbace_classes_env_constructors_fn__28000192_A) Invoke_O_O__O(self, p1__28000191_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_13, A_arbace_classes_env_A_const_42.Invoke_O__O(p1__28000191_SHARP___1))).Ref() }








































































































type A_arbace_classes_env_A struct{ jrt.Object }

var A_arbace_classes_env_A_const_pool *jrt.RefArray

var A_arbace_classes_env_A_const_0 *lang.Var

var A_arbace_classes_env_A_const_1 any

var A_arbace_classes_env_A_const_2 *lang.Var

var A_arbace_classes_env_A_const_3 any

var A_arbace_classes_env_A_const_4 any

var A_arbace_classes_env_A_const_5 any

var A_arbace_classes_env_A_const_6 any

var A_arbace_classes_env_A_const_7 *lang.Var

var A_arbace_classes_env_A_const_8 *lang.Var

var A_arbace_classes_env_A_const_9 *lang.Var

var A_arbace_classes_env_A_const_10 *lang.Var

var A_arbace_classes_env_A_const_11 any

var A_arbace_classes_env_A_const_12 *lang.Var

var A_arbace_classes_env_A_const_13 *lang.Var

var A_arbace_classes_env_A_const_14 *lang.Var

var A_arbace_classes_env_A_const_15 *lang.Var

var A_arbace_classes_env_A_const_16 *lang.Var

var A_arbace_classes_env_A_const_17 *lang.Var

var A_arbace_classes_env_A_const_18 *lang.Var

var A_arbace_classes_env_A_const_19 *lang.Var

var A_arbace_classes_env_A_const_20 *lang.Var

var A_arbace_classes_env_A_const_21 *lang.Var

var A_arbace_classes_env_A_const_22 *lang.Keyword

var A_arbace_classes_env_A_const_23 *lang.Var

var A_arbace_classes_env_A_const_24 *lang.Var

var A_arbace_classes_env_A_const_25 *lang.Var

var A_arbace_classes_env_A_const_26 *lang.Var

var A_arbace_classes_env_A_const_27 *lang.Var

var A_arbace_classes_env_A_const_28 *lang.Var

var A_arbace_classes_env_A_const_29 *lang.Var

var A_arbace_classes_env_A_const_30 *lang.Var

var A_arbace_classes_env_A_const_31 *lang.Keyword

var A_arbace_classes_env_A_const_32 *lang.Keyword

var A_arbace_classes_env_A_const_33 *jrt.Class

var A_arbace_classes_env_A_const_34 *lang.Var

var A_arbace_classes_env_A_const_35 *lang.Var

var A_arbace_classes_env_A_const_36 *lang.Var

var A_arbace_classes_env_A_const_37 any

var A_arbace_classes_env_A_const_38 any

var A_arbace_classes_env_A_const_39 *lang.Var

var A_arbace_classes_env_A_const_40 *lang.Var

var A_arbace_classes_env_A_const_41 *lang.Var

var A_arbace_classes_env_A_const_42 *lang.Keyword

var A_arbace_classes_env_A_const_43 *lang.Keyword

var A_arbace_classes_env_A_const_44 *lang.Keyword

var A_arbace_classes_env_A_const_45 *lang.Keyword

var A_arbace_classes_env_A_const_46 *lang.Keyword

var A_arbace_classes_env_A_const_47 *lang.Var

var A_arbace_classes_env_A_const_48 *lang.Keyword

var A_arbace_classes_env_A_const_49 *lang.Keyword

var A_arbace_classes_env_A_const_50 *lang.Keyword

var A_arbace_classes_env_A_const_51 *lang.Var

var A_arbace_classes_env_A_const_52 *lang.Var

var A_arbace_classes_env_A_const_53 *lang.Var

var A_arbace_classes_env_A_const_54 *lang.Var

var A_arbace_classes_env_A_const_55 *lang.Var

var A_arbace_classes_env_A_const_56 *lang.Var

var A_arbace_classes_env_A_const_57 *lang.Var

var A_arbace_classes_env_A_const_58 *lang.Var

var A_arbace_classes_env_A_const_59 *lang.Var

var A_arbace_classes_env_A_const_60 *lang.Keyword

var A_arbace_classes_env_A_const_61 *lang.Keyword

var A_arbace_classes_env_A_const_62 *lang.Var

var A_arbace_classes_env_A_const_63 *lang.Keyword

var A_arbace_classes_env_A_const_64 *lang.Keyword

var A_arbace_classes_env_A_const_65 *lang.Var

var A_arbace_classes_env_A_const_66 *lang.Var

var A_arbace_classes_env_A_const_67 *lang.Var

var A_arbace_classes_env_A_const_68 *lang.Var

var A_arbace_classes_env_A_const_69 *lang.Var

var A_arbace_classes_env_A_const_70 *lang.Var

var A_arbace_classes_env_A_const_71 *lang.Var

var A_arbace_classes_env_A_const_72 *lang.Var

var A_arbace_classes_env_A_const_73 *lang.Var

var A_arbace_classes_env_A_const_74 *lang.Keyword

var A_arbace_classes_env_A_const_75 *lang.Var

var A_arbace_classes_env_A_const_76 *lang.Keyword

var A_arbace_classes_env_A_const_77 *lang.Var

var A_arbace_classes_env_A_const_78 *lang.Var

var A_arbace_classes_env_A_const_79 *lang.Var

var A_arbace_classes_env_A_const_80 *lang.Keyword

var A_arbace_classes_env_A_const_81 *lang.Keyword

var A_arbace_classes_env_A_const_82 *lang.Var

var A_arbace_classes_env_A_const_83 *lang.Keyword

var A_arbace_classes_env_A_const_84 *lang.Var

var A_arbace_classes_env_A_const_85 *lang.Var

var A_arbace_classes_env_A_const_86 *lang.Var

var A_arbace_classes_env_A_const_87 *lang.Var

var A_arbace_classes_env_A_const_88 any

var A_arbace_classes_env_A_const_89 *lang.Var

var A_arbace_classes_env_A_const_90 *lang.Keyword

var A_arbace_classes_env_A_const_91 *lang.Var

var A_arbace_classes_env_A_const_92 *lang.Var

var A_arbace_classes_env_A_const_93 *lang.Var

var A_arbace_classes_env_A_const_94 *lang.Var

var A_arbace_classes_env_A_const_95 *lang.Var

var A_arbace_classes_env_A_const_96 *lang.Var

var A_arbace_classes_env_A_const_97 *lang.Var

var A_arbace_classes_env_A_const_98 *lang.Keyword

var A_arbace_classes_env_A_const_99 *lang.Var

var A_arbace_classes_env_A_const_100 *lang.Var

var A_arbace_classes_env_A_const_101 *lang.Var

var A_arbace_classes_env_A_const_102 *lang.Var

var A_arbace_classes_env_A_const_103 *lang.Var

var A_arbace_classes_env_A_const_104 *lang.Keyword

var A_arbace_classes_env_A_const_105 any

var A_arbace_classes_env_A_const_106 *lang.Var

var A_arbace_classes_env_A_const_107 *lang.Var

var A_arbace_classes_env_A_const_108 *lang.Var

var A_arbace_classes_env_A_const_109 *lang.Var

var A_arbace_classes_env_A_const_110 *lang.Var

var A_arbace_classes_env_A_const_111 *lang.Var

var A_arbace_classes_env_A_const_112 *lang.Var

var A_arbace_classes_env_A_const_113 *lang.Var

var A_arbace_classes_env_A_const_114 *lang.Var

var A_arbace_classes_env_A_const_115 *lang.Var

var A_arbace_classes_env_A_const_116 *lang.Var

var A_arbace_classes_env_A_const_117 *lang.Var

var A_arbace_classes_env_A_const_118 *lang.Var

var A_arbace_classes_env_A_const_119 *lang.Var

var A_arbace_classes_env_A_const_120 *lang.Var

var A_arbace_classes_env_A_const_121 any

var A_arbace_classes_env_A_const_122 any

var A_arbace_classes_env_A_const_123 *lang.Var

var A_arbace_classes_env_A_const_124 any

var A_arbace_classes_env_A_const_125 *lang.Var

var A_arbace_classes_env_A_const_126 *lang.Var

var A_arbace_classes_env_A_const_127 *lang.Var

var A_arbace_classes_env_A_const_128 *lang.Var

var A_arbace_classes_env_A_const_129 *lang.Var

var A_arbace_classes_env_A_const_130 *lang.Var

var A_arbace_classes_env_A_const_131 *lang.Var

var A_arbace_classes_env_A_const_132 any

var A_arbace_classes_env_A_const_133 any

var A_arbace_classes_env_A_const_134 any

var A_arbace_classes_env_A_const_135 *lang.Var

var A_arbace_classes_env_A_const_136 *lang.Var

var A_arbace_classes_env_A_const_137 *lang.Var

var A_arbace_classes_env_A_const_138 *lang.Var

var A_arbace_classes_env_A_const_139 *lang.Var

var A_arbace_classes_env_A_const_140 *lang.Var

var A_arbace_classes_env_A_init jrt.ClassInit

func A_arbace_classes_env_A_Init() { if !A_arbace_classes_env_A_init.Done() { A_arbace_classes_env_A_init.Run(A_arbace_classes_env_A_clinit) } }

func A_arbace_classes_env_A_clinit() { A_arbace_classes_env_A_clinit_p0(); A_arbace_classes_env_A_clinit_p1(); A_arbace_classes_env_A_clinit_p2(); A_arbace_classes_env_A_clinit_p3(); A_arbace_classes_env_A_clinit_p4(); A_arbace_classes_env_A_clinit_p5(); A_arbace_classes_env_A_clinit_p6(); A_arbace_classes_env_A_clinit_p7(); A_arbace_classes_env_A_clinit_p8(); A_arbace_classes_env_A_clinit_p9(); A_arbace_classes_env_A_clinit_p10(); A_arbace_classes_env_A_clinit_p11() }

func A_arbace_classes_env_A_clinit_p0() { jrt.StartCheck(); A_arbace_classes_env_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 177); A_arbace_classes_env_A_const_0 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[36]); A_arbace_classes_env_A_const_1 = A_arbace_classes_env_A_const_pool.A[37]; A_arbace_classes_env_A_const_2 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[38]); A_arbace_classes_env_A_const_3 = A_arbace_classes_env_A_const_pool.A[39]; A_arbace_classes_env_A_const_4 = A_arbace_classes_env_A_const_pool.A[40]; A_arbace_classes_env_A_const_5 = A_arbace_classes_env_A_const_pool.A[41]; A_arbace_classes_env_A_const_6 = A_arbace_classes_env_A_const_pool.A[42]; A_arbace_classes_env_A_const_7 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[43]); A_arbace_classes_env_A_const_8 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[44]); A_arbace_classes_env_A_const_9 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[45]); A_arbace_classes_env_A_const_10 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[46]); A_arbace_classes_env_A_const_11 = A_arbace_classes_env_A_const_pool.A[47] }

func A_arbace_classes_env_A_clinit_p1() { A_arbace_classes_env_A_const_12 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[48]); A_arbace_classes_env_A_const_13 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[49]); A_arbace_classes_env_A_const_14 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[50]); A_arbace_classes_env_A_const_15 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[51]); A_arbace_classes_env_A_const_16 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[52]); A_arbace_classes_env_A_const_17 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[53]); A_arbace_classes_env_A_const_18 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[54]); A_arbace_classes_env_A_const_19 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[55]); A_arbace_classes_env_A_const_20 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[56]); A_arbace_classes_env_A_const_21 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[57]); A_arbace_classes_env_A_const_22 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[58]); A_arbace_classes_env_A_const_23 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[59]) }

func A_arbace_classes_env_A_clinit_p2() { A_arbace_classes_env_A_const_24 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[60]); A_arbace_classes_env_A_const_25 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[61]); A_arbace_classes_env_A_const_26 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[62]); A_arbace_classes_env_A_const_27 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[63]); A_arbace_classes_env_A_const_28 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[64]); A_arbace_classes_env_A_const_29 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[65]); A_arbace_classes_env_A_const_30 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[66]); A_arbace_classes_env_A_const_31 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[67]); A_arbace_classes_env_A_const_32 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[68]); A_arbace_classes_env_A_const_33 = jrt.Class_Cast(A_arbace_classes_env_A_const_pool.A[69]); A_arbace_classes_env_A_const_34 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[70]); A_arbace_classes_env_A_const_35 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[71]) }

func A_arbace_classes_env_A_clinit_p3() { A_arbace_classes_env_A_const_36 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[72]); A_arbace_classes_env_A_const_37 = A_arbace_classes_env_A_const_pool.A[73]; A_arbace_classes_env_A_const_38 = A_arbace_classes_env_A_const_pool.A[74]; A_arbace_classes_env_A_const_39 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[75]); A_arbace_classes_env_A_const_40 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[76]); A_arbace_classes_env_A_const_41 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[77]); A_arbace_classes_env_A_const_42 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[78]); A_arbace_classes_env_A_const_43 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[79]); A_arbace_classes_env_A_const_44 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[80]); A_arbace_classes_env_A_const_45 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[81]); A_arbace_classes_env_A_const_46 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[82]); A_arbace_classes_env_A_const_47 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[83]) }

func A_arbace_classes_env_A_clinit_p4() { A_arbace_classes_env_A_const_48 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[84]); A_arbace_classes_env_A_const_49 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[85]); A_arbace_classes_env_A_const_50 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[86]); A_arbace_classes_env_A_const_51 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[87]); A_arbace_classes_env_A_const_52 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[88]); A_arbace_classes_env_A_const_53 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[89]); A_arbace_classes_env_A_const_54 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[90]); A_arbace_classes_env_A_const_55 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[91]); A_arbace_classes_env_A_const_56 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[92]); A_arbace_classes_env_A_const_57 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[93]); A_arbace_classes_env_A_const_58 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[94]); A_arbace_classes_env_A_const_59 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[95]) }

func A_arbace_classes_env_A_clinit_p5() { A_arbace_classes_env_A_const_60 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[96]); A_arbace_classes_env_A_const_61 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[97]); A_arbace_classes_env_A_const_62 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[98]); A_arbace_classes_env_A_const_63 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[99]); A_arbace_classes_env_A_const_64 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[100]); A_arbace_classes_env_A_const_65 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[101]); A_arbace_classes_env_A_const_66 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[102]); A_arbace_classes_env_A_const_67 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[103]); A_arbace_classes_env_A_const_68 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[104]); A_arbace_classes_env_A_const_69 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[105]); A_arbace_classes_env_A_const_70 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[106]); A_arbace_classes_env_A_const_71 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[107]) }

func A_arbace_classes_env_A_clinit_p6() { A_arbace_classes_env_A_const_72 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[108]); A_arbace_classes_env_A_const_73 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[109]); A_arbace_classes_env_A_const_74 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[110]); A_arbace_classes_env_A_const_75 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[111]); A_arbace_classes_env_A_const_76 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[112]); A_arbace_classes_env_A_const_77 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[113]); A_arbace_classes_env_A_const_78 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[114]); A_arbace_classes_env_A_const_79 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[115]); A_arbace_classes_env_A_const_80 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[116]); A_arbace_classes_env_A_const_81 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[117]); A_arbace_classes_env_A_const_82 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[118]); A_arbace_classes_env_A_const_83 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[119]) }

func A_arbace_classes_env_A_clinit_p7() { A_arbace_classes_env_A_const_84 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[120]); A_arbace_classes_env_A_const_85 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[121]); A_arbace_classes_env_A_const_86 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[122]); A_arbace_classes_env_A_const_87 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[123]); A_arbace_classes_env_A_const_88 = A_arbace_classes_env_A_const_pool.A[124]; A_arbace_classes_env_A_const_89 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[125]); A_arbace_classes_env_A_const_90 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[126]); A_arbace_classes_env_A_const_91 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[127]); A_arbace_classes_env_A_const_92 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[128]); A_arbace_classes_env_A_const_93 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[129]); A_arbace_classes_env_A_const_94 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[130]); A_arbace_classes_env_A_const_95 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[131]) }

func A_arbace_classes_env_A_clinit_p8() { A_arbace_classes_env_A_const_96 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[132]); A_arbace_classes_env_A_const_97 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[133]); A_arbace_classes_env_A_const_98 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[134]); A_arbace_classes_env_A_const_99 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[135]); A_arbace_classes_env_A_const_100 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[136]); A_arbace_classes_env_A_const_101 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[137]); A_arbace_classes_env_A_const_102 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[138]); A_arbace_classes_env_A_const_103 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[139]); A_arbace_classes_env_A_const_104 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[140]); A_arbace_classes_env_A_const_105 = A_arbace_classes_env_A_const_pool.A[141]; A_arbace_classes_env_A_const_106 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[142]); A_arbace_classes_env_A_const_107 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[143]) }

func A_arbace_classes_env_A_clinit_p9() { A_arbace_classes_env_A_const_108 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[144]); A_arbace_classes_env_A_const_109 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[145]); A_arbace_classes_env_A_const_110 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[146]); A_arbace_classes_env_A_const_111 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[147]); A_arbace_classes_env_A_const_112 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[148]); A_arbace_classes_env_A_const_113 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[149]); A_arbace_classes_env_A_const_114 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[150]); A_arbace_classes_env_A_const_115 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[151]); A_arbace_classes_env_A_const_116 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[152]); A_arbace_classes_env_A_const_117 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[153]); A_arbace_classes_env_A_const_118 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[154]); A_arbace_classes_env_A_const_119 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[155]) }

func A_arbace_classes_env_A_clinit_p10() { A_arbace_classes_env_A_const_120 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[156]); A_arbace_classes_env_A_const_121 = A_arbace_classes_env_A_const_pool.A[157]; A_arbace_classes_env_A_const_122 = A_arbace_classes_env_A_const_pool.A[158]; A_arbace_classes_env_A_const_123 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[159]); A_arbace_classes_env_A_const_124 = A_arbace_classes_env_A_const_pool.A[160]; A_arbace_classes_env_A_const_125 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[161]); A_arbace_classes_env_A_const_126 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[162]); A_arbace_classes_env_A_const_127 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[163]); A_arbace_classes_env_A_const_128 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[164]); A_arbace_classes_env_A_const_129 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[165]); A_arbace_classes_env_A_const_130 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[166]); A_arbace_classes_env_A_const_131 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[167]); A_arbace_classes_env_A_const_132 = A_arbace_classes_env_A_const_pool.A[168] }

func A_arbace_classes_env_A_clinit_p11() { A_arbace_classes_env_A_const_133 = A_arbace_classes_env_A_const_pool.A[169]; A_arbace_classes_env_A_const_134 = A_arbace_classes_env_A_const_pool.A[170]; A_arbace_classes_env_A_const_135 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[171]); A_arbace_classes_env_A_const_136 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[172]); A_arbace_classes_env_A_const_137 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[173]); A_arbace_classes_env_A_const_138 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[174]); A_arbace_classes_env_A_const_139 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[175]); A_arbace_classes_env_A_const_140 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[176]) }

func A_arbace_classes_env_A_New() *A_arbace_classes_env_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_env_A) Ctor() {}

func (t *A_arbace_classes_env_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_A_class }

func (t *A_arbace_classes_env_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_env_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_A); return ok }

func A_arbace_classes_env_A_Cast(x any) *A_arbace_classes_env_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_A_class)) }; return v }



type A_arbace_classes_env_accessible_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_accessible_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_accessible_QMARK__fn__28000143_A struct{ j2g_header uint64; F_owner any }

var A_arbace_classes_env_accessible_QMARK__fn__28000143_A_fn_class *jrt.Class



type A_arbace_classes_env_accessible_QMARK__fn__28000145_A struct{ j2g_header uint64 }

var A_arbace_classes_env_accessible_QMARK__fn__28000145_A_fn_class *jrt.Class



type A_arbace_classes_env_all_supertypes_A struct{ j2g_header uint64 }

var A_arbace_classes_env_all_supertypes_A_fn_class *jrt.Class



type A_arbace_classes_env_all_supertypes_STAR__A struct{ j2g_header uint64 }

var A_arbace_classes_env_all_supertypes_STAR__A_fn_class *jrt.Class



type A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A struct{ j2g_header uint64 }

var A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A_fn_class *jrt.Class



type A_arbace_classes_env_assignable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_assignable_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_class_file_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_class_file_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_coerce_const_A struct{ j2g_header uint64 }

var A_arbace_classes_env_coerce_const_A_fn_class *jrt.Class



type A_arbace_classes_env_common_super_A struct{ j2g_header uint64 }

var A_arbace_classes_env_common_super_A_fn_class *jrt.Class



type A_arbace_classes_env_const_value_A struct{ j2g_header uint64 }

var A_arbace_classes_env_const_value_A_fn_class *jrt.Class



type A_arbace_classes_env_constructors_A struct{ j2g_header uint64 }

var A_arbace_classes_env_constructors_A_fn_class *jrt.Class



type A_arbace_classes_env_constructors_fn__28000192_A struct{ j2g_header uint64 }

var A_arbace_classes_env_constructors_fn__28000192_A_fn_class *jrt.Class



type A_arbace_classes_env_eval28000004_A struct{ jrt.Object }

func A_arbace_classes_env_eval28000004_A_New() *A_arbace_classes_env_eval28000004_A { t := &A_arbace_classes_env_eval28000004_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_env_eval28000004_A) Ctor() {}

func (t *A_arbace_classes_env_eval28000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_eval28000004_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_eval28000004_A_class }

func (t *A_arbace_classes_env_eval28000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_eval28000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_env_eval28000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_eval28000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_eval28000004_A); return ok }

func A_arbace_classes_env_eval28000004_A_Cast(x any) *A_arbace_classes_env_eval28000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_eval28000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_eval28000004_A_class)) }; return v }



type A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A struct{ j2g_header uint64 }

var A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_fn_class *jrt.Class



type A_arbace_classes_env_eval28000008_A struct{ jrt.Object }

func A_arbace_classes_env_eval28000008_A_New() *A_arbace_classes_env_eval28000008_A { t := &A_arbace_classes_env_eval28000008_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_env_eval28000008_A) Ctor() {}

func (t *A_arbace_classes_env_eval28000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_eval28000008_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_eval28000008_A_class }

func (t *A_arbace_classes_env_eval28000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_eval28000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_env_eval28000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_eval28000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_eval28000008_A); return ok }

func A_arbace_classes_env_eval28000008_A_Cast(x any) *A_arbace_classes_env_eval28000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_eval28000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_eval28000008_A_class)) }; return v }



type A_arbace_classes_env_eval28000008_fn__28000009_A struct{ j2g_header uint64 }

var A_arbace_classes_env_eval28000008_fn__28000009_A_fn_class *jrt.Class



type A_arbace_classes_env_find_field_A struct{ j2g_header uint64 }

var A_arbace_classes_env_find_field_A_fn_class *jrt.Class



type A_arbace_classes_env_find_field_fn__28000150_A struct{ j2g_header uint64; F_name any }

var A_arbace_classes_env_find_field_fn__28000150_A_fn_class *jrt.Class



type A_arbace_classes_env_find_field_fn__28000152_A struct{ j2g_header uint64; F_name any }

var A_arbace_classes_env_find_field_fn__28000152_A_fn_class *jrt.Class



type A_arbace_classes_env_flag_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_flag_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_from_source_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_from_source_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_info_A struct{ j2g_header uint64 }

var A_arbace_classes_env_info_A_fn_class *jrt.Class



type A_arbace_classes_env_info_BANG__A struct{ j2g_header uint64 }

var A_arbace_classes_env_info_BANG__A_fn_class *jrt.Class



type A_arbace_classes_env_infos_now_A struct{ j2g_header uint64 }

var A_arbace_classes_env_infos_now_A_fn_class *jrt.Class



type A_arbace_classes_env_inner_member_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_inner_member_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_interface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_interface_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_internal_A struct{ j2g_header uint64 }

var A_arbace_classes_env_internal_A_fn_class *jrt.Class



type A_arbace_classes_env_known_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_known_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_load_class_A struct{ j2g_header uint64 }

var A_arbace_classes_env_load_class_A_fn_class *jrt.Class



type A_arbace_classes_env_lub_A struct{ j2g_header uint64 }

var A_arbace_classes_env_lub_A_fn_class *jrt.Class



type A_arbace_classes_env_lub_fn__28000134_A struct{ j2g_header uint64; F_common any }

var A_arbace_classes_env_lub_fn__28000134_A_fn_class *jrt.Class



type A_arbace_classes_env_lub_fn__28000134_fn__28000135_A struct{ j2g_header uint64; F_i any }

var A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_fn_class *jrt.Class



type A_arbace_classes_env_lub_sups__28000129_A struct{ j2g_header uint64 }

var A_arbace_classes_env_lub_sups__28000129_A_fn_class *jrt.Class



type A_arbace_classes_env_lub_sups__28000129_fn__28000130_A struct{ j2g_header uint64 }

var A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_fn_class *jrt.Class



type A_arbace_classes_env_member_methods_A struct{ j2g_header uint64 }

var A_arbace_classes_env_member_methods_A_fn_class *jrt.Class



type A_arbace_classes_env_member_methods_STAR__A struct{ j2g_header uint64 }

var A_arbace_classes_env_member_methods_STAR__A_fn_class *jrt.Class



type A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A struct{ j2g_header uint64; F_seen, F_name, F_n, F_c any }

var A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A_fn_class *jrt.Class



type A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A struct{ j2g_header uint64; F_iter__28000179, F_seen, F_name, F_n, F_c, F_s__28000180 any }

var A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A_fn_class *jrt.Class



type A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A struct{ j2g_header uint64; F_seen, F_name, F_n, F_c any; F_size__1927001038__auto__ int32; F_b__28000182, F_c__1927001037__auto__ any }

var A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A_fn_class *jrt.Class



type A_arbace_classes_env_nest_host_A struct{ j2g_header uint64 }

var A_arbace_classes_env_nest_host_A_fn_class *jrt.Class



type A_arbace_classes_env_params_key_A struct{ j2g_header uint64 }

var A_arbace_classes_env_params_key_A_fn_class *jrt.Class



type A_arbace_classes_env_read_fields_A struct{ j2g_header uint64 }

var A_arbace_classes_env_read_fields_A_fn_class *jrt.Class



type A_arbace_classes_env_read_method_annotations_A struct{ j2g_header uint64 }

var A_arbace_classes_env_read_method_annotations_A_fn_class *jrt.Class



type A_arbace_classes_env_record_BANG__A struct{ j2g_header uint64 }

var A_arbace_classes_env_record_BANG__A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_A struct{ j2g_header uint64 }

var A_arbace_classes_env_reflect_info_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_fn__28000027_A struct{ j2g_header uint64; F_c any }

var A_arbace_classes_env_reflect_info_fn__28000027_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_fn__28000089_A struct{ j2g_header uint64 }

var A_arbace_classes_env_reflect_info_fn__28000089_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000031__28000035_A struct{ j2g_header uint64; F_n any }

var A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A struct{ j2g_header uint64; F_n, F_s__28000032, F_iter__28000031 any }

var A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A struct{ j2g_header uint64; F_b__28000034, F_n any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000045__28000049_A struct{ j2g_header uint64; F_n any }

var A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A struct{ j2g_header uint64; F_n, F_s__28000046, F_iter__28000045 any }

var A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A struct{ j2g_header uint64; F_n, F_b__28000048 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_A struct{ j2g_header uint64; F_n, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A struct{ j2g_header uint64; F_n, F_manns, F_s__28000056, F_iter__28000055 any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A struct{ j2g_header uint64; F_n, F_b__28000058, F_manns any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A struct{ j2g_header uint64; F_m, F_desc, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A struct{ j2g_header uint64; F_m, F_desc, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A struct{ j2g_header uint64; F_i, F_m, F_desc, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A struct{ j2g_header uint64; F_m, F_desc, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A struct{ j2g_header uint64; F_m, F_desc, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A struct{ j2g_header uint64; F_i, F_m, F_desc, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000077__28000081_A struct{ j2g_header uint64; F_c, F_n any }

var A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A struct{ j2g_header uint64; F_c, F_n, F_s__28000078, F_iter__28000077 any }

var A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A struct{ j2g_header uint64; F_c, F_n, F_b__28000080 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000091__28000095_A struct{ j2g_header uint64; F_n any }

var A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A struct{ j2g_header uint64; F_n, F_s__28000092, F_iter__28000091 any }

var A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A struct{ j2g_header uint64; F_n any; F_size__1927001038__auto__ int32; F_b__28000094, F_c__1927001037__auto__ any }

var A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_fn_class *jrt.Class



type A_arbace_classes_env_reflected_A struct{ j2g_header uint64 }

var A_arbace_classes_env_reflected_A_fn_class *jrt.Class



type A_arbace_classes_env_same_infos_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_same_infos_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_subclass_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_subclass_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_subclass_QMARK__fn__28000117_A struct{ j2g_header uint64; F_b any }

var A_arbace_classes_env_subclass_QMARK__fn__28000117_A_fn_class *jrt.Class



type A_arbace_classes_env_superclass_chain_A struct{ j2g_header uint64 }

var A_arbace_classes_env_superclass_chain_A_fn_class *jrt.Class



type A_arbace_classes_env_superclass_chain_fn__28000123_A struct{ j2g_header uint64 }

var A_arbace_classes_env_superclass_chain_fn__28000123_A_fn_class *jrt.Class



type A_arbace_classes_env_supertypes_A struct{ j2g_header uint64 }

var A_arbace_classes_env_supertypes_A_fn_class *jrt.Class
