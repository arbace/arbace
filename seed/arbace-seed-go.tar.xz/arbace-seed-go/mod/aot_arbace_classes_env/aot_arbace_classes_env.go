//line aot_arbace_classes_env.ae:1
package aot_arbace_classes_env

import (
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_set"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_New() *A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_classes_env_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_env_A_const_1); lang.IFn_Cast(A_arbace_classes_env_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_classes_env_A_const_3, A_arbace_classes_env_A_const_4, A_arbace_classes_env_A_const_5, A_arbace_classes_env_A_const_6); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_14)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_15)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_16)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_17)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_classes_env_eval28000008_fn__28000009_A_New() *A_arbace_classes_env_eval28000008_fn__28000009_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_eval28000008_fn__28000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_env_eval28000008_fn__28000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_env_eval28000008_fn__28000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_7.GetRawRoot__O()); var tmp2 any; var root_12 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_13 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_12, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_14 lang.IFn; if linked_13 == nil { ifn_14 = lang.IFn_Cast(root_12) } else { ifn_14 = nil }; var arg_15 any = A_arbace_classes_env_A_const_9; if linked_13 == nil { tmp2 = ifn_14.Invoke_O__O(arg_15) } else { tmp2 = linked_13.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_12, arg_15) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_classes_env_A_const_10.GetRawRoot__O(), A_arbace_classes_env_A_const_11) }



























func A_arbace_classes_env_internal_A_New() *A_arbace_classes_env_internal_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_internal_A{}; t.Ctor(); return t }
//line :29:1
func (t *A_arbace_classes_env_internal_A) Ctor() {}
//line :29:1
func (t *A_arbace_classes_env_internal_A) Invoke_O_O__O(self, c__0 any) any { var root_22 any = A_arbace_classes_env_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref(); var arg_26 any = Lit_22; var arg_27 any = Lit_21; if linked_23 == nil { return ifn_24.Invoke_O_O_O__O(arg_25, arg_26, arg_27) } else { return linked_23.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_22, arg_25, arg_26, arg_27) } }







func A_arbace_classes_env_from_source_QMARK__A_New() *A_arbace_classes_env_from_source_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_from_source_QMARK__A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_classes_env_from_source_QMARK__A) Ctor() {}
//line :37:1
func (t *A_arbace_classes_env_from_source_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var tmp1 any; var and__1927000168__auto____2 any = A_arbace_classes_env_A_const_13.Get__O(); if jrt.J2g_Truth(and__1927000168__auto____2) { tmp1 = lang.IFn_Cast(A_arbace_classes_env_A_const_13.Get__O()).Invoke_O__O(n__0) } else { tmp1 = and__1927000168__auto____2 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() }


















func A_arbace_classes_env_record_BANG__A_New() *A_arbace_classes_env_record_BANG__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_record_BANG__A{}; t.Ctor(); return t }
//line :56:1
func (t *A_arbace_classes_env_record_BANG__A) Ctor() {}
//line :56:1
func (t *A_arbace_classes_env_record_BANG__A) Invoke_O_O_O_O__O(self, n__0, facet__1, v__2 any) any {


	if jrt.J2g_Truth(A_arbace_classes_env_A_const_14.Get__O()) { lang.IFn_Cast(A_arbace_classes_env_A_const_15.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_classes_env_A_const_14.Get__O(), A_arbace_classes_env_A_const_16.GetRawRoot__O(), n__0, A_arbace_classes_env_A_const_17.GetRawRoot__O(), facet__1, v__2) }
//line :56:1
	return v__2
}




func A_arbace_classes_env_load_class_A_New() *A_arbace_classes_env_load_class_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_load_class_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_classes_env_load_class_A) Ctor() {}
//line :62:1
func (t *A_arbace_classes_env_load_class_A) Invoke_O_O__O(self, n__0 any) any {



	var tmp1 any; var or__1927000174__auto____2 any; var root_37 any = A_arbace_classes_env_A_const_18.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_37, A_arbace_classes_env_from_source_QMARK__A_fn_class); var ifn_39 lang.IFn; if linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any = n__0; if linked_38 == nil { or__1927000174__auto____2 = ifn_39.Invoke_O__O(arg_40) } else { or__1927000174__auto____2 = linked_38.(*A_arbace_classes_env_from_source_QMARK__A).Invoke_O_O__O(root_37, arg_40) }; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { tmp1 = A_arbace_classes_env_A_const_19.Get__O() }; if jrt.J2g_Truth(tmp1) { return nil } else { var tmp2 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var cn__4 any; var tmp3 any; var root_41 any = A_arbace_classes_env_A_const_20.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_43 lang.IFn

		if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = n__0; var arg_45 any = Lit_11; if linked_42 == nil { tmp3 = ifn_43.Invoke_O_O__O(arg_44, arg_45) } else { tmp3 = linked_42.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_41, arg_44, arg_45) }; if jrt.J2g_Truth(tmp3) { var root_46 any = A_arbace_classes_env_A_const_12.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_48 lang.IFn; if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = n__0; var arg_50 any = Lit_21; var arg_51 any = Lit_22; if linked_47 == nil { cn__4 = ifn_48.Invoke_O_O_O__O(arg_49, arg_50, arg_51) } else { cn__4 = linked_47.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_46, arg_49, arg_50, arg_51) } } else { var root_52 any = A_arbace_classes_env_A_const_12.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_52, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_54 lang.IFn; if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any = n__0; var arg_56 any = Lit_21; var arg_57 any = Lit_22; if linked_53 == nil { cn__4 = ifn_54.Invoke_O_O_O__O(arg_55, arg_56, arg_57) } else { cn__4 = linked_53.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_52, arg_55, arg_56, arg_57) } }
//line :66:1
		var c__5 any = lang.RT_ClassForNameNonLoading_String__Class_NoInit(jrt.String_Cast(cn__4)).Ref(); var tmp4 any
		var and__1927000168__auto____6 any = c__5


		if jrt.J2g_Truth(and__1927000168__auto____6) { tmp4 = A_arbace_classes_env_A_const_14.Get__O() } else { tmp4 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp4) { var root_58 any = A_arbace_classes_env_A_const_21.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_58, A_arbace_classes_env_record_BANG__A_fn_class); var ifn_60 lang.IFn; if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = n__0; var arg_62 any = A_arbace_classes_env_A_const_22; var arg_63 any = jrt.Boolean_TRUE.Ref(); if linked_59 == nil { ifn_60.Invoke_O_O_O__O(arg_61, arg_62, arg_63) } else { linked_59.(*A_arbace_classes_env_record_BANG__A).Invoke_O_O_O_O__O(root_58, arg_61, arg_62, arg_63) } }
//line :66:1
		tmp2 = c__5 }; return nil }(); if tmp5 != nil { if jrt.ClassNotFoundException_InstanceOf(tmp5) { var ___4 *jrt.ClassNotFoundException = jrt.ClassNotFoundException_Cast(tmp5); _ = ___4; tmp2 = nil } else if jrt.NoClassDefFoundError_InstanceOf(tmp5) { var ___4_2 *jrt.NoClassDefFoundError = jrt.NoClassDefFoundError_Cast(tmp5); _ = ___4_2; tmp2 = nil } else { panic(tmp5) } }; return tmp2
	}
}






func A_arbace_classes_env_known_QMARK__A_New() *A_arbace_classes_env_known_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_known_QMARK__A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_classes_env_known_QMARK__A) Ctor() {}
//line :75:1
func (t *A_arbace_classes_env_known_QMARK__A) Invoke_O_O__O(self, n__0 any) any {


	if jrt.J2g_Truth(A_arbace_classes_env_A_const_19.Get__O()) { var root_64 any = A_arbace_classes_env_A_const_23.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_66 lang.IFn; if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any = A_arbace_classes_env_A_const_19.Get__O(); var arg_68 any = n__0; if linked_65 == nil { return ifn_66.Invoke_O_O__O(arg_67, arg_68) } else { return linked_65.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_64, arg_67, arg_68) } } else { var root_73 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any; var root_69 any = A_arbace_classes_env_A_const_25.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, A_arbace_classes_env_load_class_A_fn_class); var ifn_71 lang.IFn; if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any = n__0; if linked_70 == nil { arg_76 = ifn_71.Invoke_O__O(arg_72) } else { arg_76 = linked_70.(*A_arbace_classes_env_load_class_A).Invoke_O_O__O(root_69, arg_72) }; if linked_74 == nil { return ifn_75.Invoke_O__O(arg_76) } else { return linked_74.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_73, arg_76)
	} } }
func A_arbace_classes_env_reflected_A_New() *A_arbace_classes_env_reflected_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflected_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_classes_env_reflected_A) Ctor() {}
//line :80:1
func (t *A_arbace_classes_env_reflected_A) Invoke_O_O_O_O__O(self, n__0, facet__1, f__2 any) any {




	if jrt.J2g_Truth(A_arbace_classes_env_A_const_19.Get__O()) { var temp__1927000414__auto____4 any = lang.RT_Get_O_O__O_NoInit(A_arbace_classes_env_A_const_19.Get__O(), n__0)
		if jrt.J2g_Truth(temp__1927000414__auto____4) { var d__5 any = temp__1927000414__auto____4; var temp__1927000408__auto____6 any; var root_77 any = A_arbace_classes_env_A_const_26.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_77, aot_arbace_core.A_arbace_core_find_A_fn_class); var ifn_79 lang.IFn
			if linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var arg_80 any = d__5; var arg_81 any = facet__1; if linked_78 == nil { temp__1927000408__auto____6 = ifn_79.Invoke_O_O__O(arg_80, arg_81) } else { temp__1927000408__auto____6 = linked_78.(*aot_arbace_core.A_arbace_core_find_A).Invoke_O_O_O__O(root_77, arg_80, arg_81) }; if jrt.J2g_Truth(temp__1927000408__auto____6) { var e__7 any = temp__1927000408__auto____6; var root_82 any = A_arbace_classes_env_A_const_27.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, aot_arbace_core.A_arbace_core_val_A_fn_class); var ifn_84 lang.IFn
				if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = e__7; if linked_83 == nil { return ifn_84.Invoke_O__O(arg_85) } else { return linked_83.(*aot_arbace_core.A_arbace_core_val_A).Invoke_O_O__O(root_82, arg_85) } } else {
//line :87:1
					var tmp1 any; var root_100 any = A_arbace_classes_env_A_const_28.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_102 lang.IFn

					if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_55, nil, Lit_56, nil, Lit_57); var tmp3 any; var root_86 any = A_arbace_classes_env_A_const_29.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_88 lang.IFn; if linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any = facet__1; if linked_87 == nil { tmp3 = ifn_88.Invoke_O__O(arg_89) } else { tmp3 = linked_87.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_86, arg_89) }; var tmp4 any = tmp3; var tmp5 any; var root_94 any = A_arbace_classes_env_A_const_12.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any; var root_90 any = A_arbace_classes_env_A_const_30.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_92 lang.IFn; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = n__0; if linked_91 == nil { arg_97 = ifn_92.Invoke_O__O(arg_93) } else { arg_97 = linked_91.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_90, arg_93) }; var arg_98 any = Lit_21; var arg_99 any = Lit_22; if linked_95 == nil { tmp5 = ifn_96.Invoke_O_O_O__O(arg_97, arg_98, arg_99) } else { tmp5 = linked_95.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_94, arg_97, arg_98, arg_99) }; arg_103 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp4, nil, tmp5, nil)).Ref(); var arg_104 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_env_A_const_31, n__0, A_arbace_classes_env_A_const_32, facet__1)); if linked_101 == nil { tmp1 = ifn_102.Invoke_O_O__O(arg_103, arg_104) } else { tmp1 = linked_101.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_100, arg_103, arg_104) }
//line :87:1
					panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) } } else {
//line :86:1
						return nil } } else {
//line :85:1
							var temp__1927000414__auto____4_2 any; var root_105 any = A_arbace_classes_env_A_const_25.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, A_arbace_classes_env_load_class_A_fn_class); var ifn_107 lang.IFn






							if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = n__0; if linked_106 == nil { temp__1927000414__auto____4_2 = ifn_107.Invoke_O__O(arg_108) } else { temp__1927000414__auto____4_2 = linked_106.(*A_arbace_classes_env_load_class_A).Invoke_O_O__O(root_105, arg_108) }; if jrt.J2g_Truth(temp__1927000414__auto____4_2) { var c__5 any = temp__1927000414__auto____4_2; var root_109 any = A_arbace_classes_env_A_const_21.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, A_arbace_classes_env_record_BANG__A_fn_class); var ifn_111 lang.IFn
								if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any = n__0; var arg_113 any = facet__1; var arg_114 any = lang.IFn_Cast(f__2).Invoke_O__O(c__5); if linked_110 == nil { return ifn_111.Invoke_O_O_O__O(arg_112, arg_113, arg_114) } else { return linked_110.(*A_arbace_classes_env_record_BANG__A).Invoke_O_O_O_O__O(root_109, arg_112, arg_113, arg_114) } } else {
//line :92:1
									return nil
								}
						} }
func A_arbace_classes_env_class_file_QMARK__A_New() *A_arbace_classes_env_class_file_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_class_file_QMARK__A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_classes_env_class_file_QMARK__A) Ctor() {}
//line :95:1
func (t *A_arbace_classes_env_class_file_QMARK__A) Invoke_O_O__O(self, c__0 any) any { var ld__2 any; var or__1927000174__auto____2 any = jrt.NN(jrt.Class_Cast(c__0)).GetClassLoader__ClassLoader(); if





	jrt.J2g_Truth(or__1927000174__auto____2) { ld__2 = or__1927000174__auto____2 } else { ld__2 = jrt.ClassLoader_GetSystemClassLoader__ClassLoader() }; var temp__1927000414__auto____3 any; var tmp1 /*line :95:1*/*jrt.Class = A_arbace_classes_env_A_const_33; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_6); var tmp3 any; var root_115 any = A_arbace_classes_env_A_const_34.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, A_arbace_classes_env_internal_A_fn_class); var ifn_117 lang.IFn; if






	linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = c__0; if linked_116 == nil { tmp3 = ifn_117.Invoke_O__O(arg_118) } else { tmp3 = linked_116.(*A_arbace_classes_env_internal_A).Invoke_O_O__O(root_115, arg_118) }; temp__1927000414__auto____3 = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(ld__2, tmp1, Lit_5, jrt.RefArrayOf(jrt.Object_class, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil)).Ref())); if jrt.J2g_Truth(temp__1927000414__auto____3) { var in__4 any = temp__1927000414__auto____3
		jrt.InputStream_Cast(in__4).Close__V()
//line :102:1
		return jrt.Boolean_TRUE.Ref() } else { return nil } }



func A_arbace_classes_env_read_fields_A_New() *A_arbace_classes_env_read_fields_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_read_fields_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_classes_env_read_fields_A) Ctor() {}
//line :106:1
func (t *A_arbace_classes_env_read_fields_A) Invoke_O_O__O(self, c__0 any) any {




	var tmp1 any; var root_119 any = A_arbace_classes_env_A_const_35.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, A_arbace_classes_env_class_file_QMARK__A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = c__0; if linked_120 == nil { tmp1 = ifn_121.Invoke_O__O(arg_122) } else { tmp1 = linked_120.(*A_arbace_classes_env_class_file_QMARK__A).Invoke_O_O__O(root_119, arg_122) }; if jrt.J2g_Truth(tmp1) {
		var tmp2 any; var root_123 any = A_arbace_classes_env_A_const_36.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_requiring_resolve_A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = A_arbace_classes_env_A_const_37; if linked_124 == nil { tmp2 = ifn_125.Invoke_O__O(arg_126) } else { tmp2 = linked_124.(*aot_arbace_core.A_arbace_core_requiring_resolve_A).Invoke_O_O__O(root_123, arg_126) }; return lang.IFn_Cast(tmp2).Invoke_O__O(c__0) } else {
//line :111:1
			return nil
		}
}
func A_arbace_classes_env_read_method_annotations_A_New() *A_arbace_classes_env_read_method_annotations_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_read_method_annotations_A{}; t.Ctor(); return t }
//line :114:1
func (t *A_arbace_classes_env_read_method_annotations_A) Ctor() {}
//line :114:1
func (t *A_arbace_classes_env_read_method_annotations_A) Invoke_O_O__O(self, c__0 any) any {



	var tmp1 any; var root_127 any = A_arbace_classes_env_A_const_35.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, A_arbace_classes_env_class_file_QMARK__A_fn_class); var ifn_129 lang.IFn; if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = c__0; if linked_128 == nil { tmp1 = ifn_129.Invoke_O__O(arg_130) } else { tmp1 = linked_128.(*A_arbace_classes_env_class_file_QMARK__A).Invoke_O_O__O(root_127, arg_130) }; if jrt.J2g_Truth(tmp1) {
		var tmp2 any; var root_131 any = A_arbace_classes_env_A_const_36.GetRawRoot__O(); var linked_132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_131, aot_arbace_core.A_arbace_core_requiring_resolve_A_fn_class); var ifn_133 lang.IFn; if linked_132 == nil { ifn_133 = lang.IFn_Cast(root_131) } else { ifn_133 = nil }; var arg_134 any = A_arbace_classes_env_A_const_38; if linked_132 == nil { tmp2 = ifn_133.Invoke_O__O(arg_134) } else { tmp2 = linked_132.(*aot_arbace_core.A_arbace_core_requiring_resolve_A).Invoke_O_O__O(root_131, arg_134) }; return lang.IFn_Cast(tmp2).Invoke_O__O(c__0) } else {
//line :118:1
			return lang.PersistentArrayMap_EMPTY.Ref()
		}
}

func A_arbace_classes_env_coerce_const_A_New() *A_arbace_classes_env_coerce_const_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_coerce_const_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_classes_env_coerce_const_A) Ctor() {}
//line :122:1
func (t *A_arbace_classes_env_coerce_const_A) Invoke_O_O_O__O(self, desc__0, v__1 any) any { var G__28000023__3_ any = desc__0; switch
												lang.Util_Hash_O__I_NoInit(G__28000023__3_) { case 66: if lang.Util_Equiv_O_O__Z_NoInit(G__28000023__3_, Lit_7) {



		return jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_ByteCast_O__B_NoInit(v__1)).Ref() }
//line :123:1
	case 67: if lang.Util_Equiv_O_O__Z_NoInit(G__28000023__3_, Lit_8) {

		return jrt.Character_ValueOf_C__Character_NoInit(lang.RT_CharCast_I__C_NoInit(lang.RT_IntCast_O__I_NoInit(v__1))).Ref() }
//line :123:1
	case 83: if lang.Util_Equiv_O_O__Z_NoInit(G__28000023__3_, Lit_9) {


		return jrt.Short_ValueOf_S__Short_NoInit(lang.RT_ShortCast_O__S_NoInit(v__1)).Ref() }
//line :123:1
	case 90: if lang.Util_Equiv_O_O__Z_NoInit(G__28000023__3_, Lit_10) {
		var root_136 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(v__1))).Ref(); if linked_137 == nil { return ifn_138.Invoke_O__O(arg_139) } else { return linked_137.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_136, arg_139) } }
//line :123:1
	default:}; return v__1 }












func A_arbace_classes_env_inner_member_QMARK__A_New() *A_arbace_classes_env_inner_member_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_inner_member_QMARK__A{}; t.Ctor(); return t }
//line :136:1
func (t *A_arbace_classes_env_inner_member_QMARK__A) Ctor() {}
//line :136:1
func (t *A_arbace_classes_env_inner_member_QMARK__A) Invoke_O_O__O(self, c__0 any) any {
	var tmp1 any; var and__1927000168__auto____2 any = jrt.NN(jrt.Class_Cast(c__0)).GetDeclaringClass__Class().Ref(); if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_140 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_140, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_142 lang.IFn; if linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var arg_143 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Modifier_IsStatic_I__Z(jrt.NN(jrt.Class_Cast(c__0)).GetModifiers__I())).Ref(); if linked_141 == nil { and__1927000168__auto____3 = ifn_142.Invoke_O__O(arg_143) } else { and__1927000168__auto____3 = linked_141.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_140, arg_143) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_144 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_144, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_146 lang.IFn
		if linked_145 == nil { ifn_146 = lang.IFn_Cast(root_144) } else { ifn_146 = nil }; var arg_147 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(c__0)).IsInterface__Z()).Ref(); if linked_145 == nil { and__1927000168__auto____4 = ifn_146.Invoke_O__O(arg_147) } else { and__1927000168__auto____4 = linked_145.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_144, arg_147) }
//line :137:1
		if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_148 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_148, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_150 lang.IFn
			if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(c__0)).IsEnum__Z()).Ref(); if linked_149 == nil { and__1927000168__auto____5 = ifn_150.Invoke_O__O(arg_151) } else { and__1927000168__auto____5 = linked_149.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_148, arg_151) }
//line :137:1
			if jrt.J2g_Truth(and__1927000168__auto____5) {
				var root_152 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_154 lang.IFn; if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(c__0)).IsRecord__Z()).Ref(); if linked_153 == nil { tmp1 = ifn_154.Invoke_O__O(arg_155) } else { tmp1 = linked_153.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_152, arg_155) } } else {
//line :137:1
					tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}

func A_arbace_classes_env_reflect_info_A_New() *A_arbace_classes_env_reflect_info_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_A{}; t.Ctor(); return t }
//line :140:1
func (t *A_arbace_classes_env_reflect_info_A) Ctor() {}
//line :140:1
func (t *A_arbace_classes_env_reflect_info_A) Invoke_O_O__O(self, c__0 any) any { var or__1927000174__auto____2 any = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_40.GetRawRoot__O())).Get_O__O(c__0); if
										jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var lockee__1927000360__auto____3 any = A_arbace_classes_env_A_const_40.GetRawRoot__O(); var locklocal__1927000361__auto____6 any = lockee__1927000360__auto____3; lang.Compiler_Evaluator_MonitorEnter_O__V_NoInit(locklocal__1927000361__auto____6); var tmp1 any; tmp44 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var or__1927000174__auto____9 any = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_40.GetRawRoot__O())).Get_O__O(c__0)

		if jrt.J2g_Truth(or__1927000174__auto____9) { tmp1 = or__1927000174__auto____9 } else { var n__10 any; var root_156 any = A_arbace_classes_env_A_const_34.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, A_arbace_classes_env_internal_A_fn_class); var ifn_158 lang.IFn
			if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = c__0; if linked_157 == nil { n__10 = ifn_158.Invoke_O__O(arg_159) } else { n__10 = linked_157.(*A_arbace_classes_env_internal_A).Invoke_O_O__O(root_156, arg_159) }
//line :143:1
			var manns__11 any; var tmp2 any = A_arbace_classes_env_reflect_info_fn__28000027_A_New_O(c__0); var tmp3 *jrt.Class
			var fncls__164 /*line :143:1*/*jrt.Class = A_arbace_classes_env_reflect_info_fn__28000027_A_fn_class

			if fncls__164 == nil { var fncls__164d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_classes_env_reflect_info_fn__28000027_A_fn_class = fncls__164d; tmp3 = fncls__164d } else { tmp3 = fncls__164 }
//line :143:1
			manns__11 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var info__12 any; var tmp4 any = A_arbace_classes_env_A_const_42; var tmp5 any = A_arbace_classes_env_A_const_43; var tmp6 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Class_Cast(c__0)).GetModifiers__I()).Ref(); var tmp7 any = A_arbace_classes_env_A_const_44; var tmp8 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(c__0)).IsInterface__Z()).Ref(); var tmp9 any = A_arbace_classes_env_A_const_45; var tmp10 any; var G__28000029__12_ any = jrt.NN(jrt.Class_Cast(c__0)).GetSuperclass__Class().Ref()





			if lang.Util_Identical_O_O__Z_NoInit(G__28000029__12_, nil) { tmp10 = nil } else { var root_165 any = A_arbace_classes_env_A_const_34.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, A_arbace_classes_env_internal_A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = G__28000029__12_; if linked_166 == nil { tmp10 = ifn_167.Invoke_O__O(arg_168) } else { tmp10 = linked_166.(*A_arbace_classes_env_internal_A).Invoke_O_O__O(root_165, arg_168) } }
//line :143:1
			var tmp11 any = tmp10; var tmp12 any = A_arbace_classes_env_A_const_46; var tmp13 any; var root_169 any = A_arbace_classes_env_A_const_47.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_169, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_171 lang.IFn






			if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = A_arbace_classes_env_A_const_34.GetRawRoot__O(); var arg_173 any = jrt.NN(jrt.Class_Cast(c__0)).GetInterfaces__Class1().Ref(); if linked_170 == nil { tmp13 = ifn_171.Invoke_O_O__O(arg_172, arg_173) } else { tmp13 = linked_170.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_169, arg_172, arg_173) }
//line :143:1
			var tmp14 any = tmp13; var tmp15 any = A_arbace_classes_env_A_const_48; var tmp16 any; var root_174 any = A_arbace_classes_env_A_const_34.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, A_arbace_classes_env_internal_A_fn_class); var ifn_176 lang.IFn







			if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any = jrt.NN(jrt.Class_Cast(c__0)).GetNestHost__Class().Ref(); if linked_175 == nil { tmp16 = ifn_176.Invoke_O__O(arg_177) } else { tmp16 = linked_175.(*A_arbace_classes_env_internal_A).Invoke_O_O__O(root_174, arg_177) }
//line :143:1
			var tmp17 any = tmp16; var tmp18 any = A_arbace_classes_env_A_const_49; var tmp19 any; var G__28000030__12_ any = jrt.NN(jrt.Class_Cast(c__0)).GetDeclaringClass__Class().Ref()








			if lang.Util_Identical_O_O__Z_NoInit(G__28000030__12_, nil) { tmp19 = nil } else { var root_178 any = A_arbace_classes_env_A_const_34.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, A_arbace_classes_env_internal_A_fn_class); var ifn_180 lang.IFn; if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any = G__28000030__12_; if linked_179 == nil { tmp19 = ifn_180.Invoke_O__O(arg_181) } else { tmp19 = linked_179.(*A_arbace_classes_env_internal_A).Invoke_O_O__O(root_178, arg_181) } }
//line :143:1
			var tmp20 any = tmp19; var tmp21 any = A_arbace_classes_env_A_const_50; var tmp22 any; var temp__1927000408__auto____12 any; var root_182 any = A_arbace_classes_env_A_const_51.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, A_arbace_classes_env_read_fields_A_fn_class); var ifn_184 lang.IFn









			if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = c__0; if linked_183 == nil { temp__1927000408__auto____12 = ifn_184.Invoke_O__O(arg_185) } else { temp__1927000408__auto____12 = linked_183.(*A_arbace_classes_env_read_fields_A).Invoke_O_O__O(root_182, arg_185) }; if jrt.J2g_Truth(temp__1927000408__auto____12) { var fs__13 any = temp__1927000408__auto____12; var root_303 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_303, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_305 lang.IFn
				if linked_304 == nil { ifn_305 = lang.IFn_Cast(root_303) } else { ifn_305 = nil }; var arg_306 any; var iter__1927001039__auto____14 any; var tmp23 any = A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_New_O(n__10); var tmp24 *jrt.Class; var fncls__302 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_fn_class; if fncls__302 == nil { var fncls__302d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_fn_class = fncls__302d; tmp24 = fncls__302d } else { tmp24 = fncls__302 }; iter__1927001039__auto____14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil); arg_306 = lang.IFn_Cast(iter__1927001039__auto____14).Invoke_O__O(fs__13); if linked_304 == nil { tmp22 = ifn_305.Invoke_O__O(arg_306) } else { tmp22 = linked_304.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_303, arg_306) } } else {




					var root_374 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_374, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_376 lang.IFn; if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any; var iter__1927001039__auto____13 any; var tmp25 any = A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_New_O(n__10); var tmp26 *jrt.Class; var fncls__373 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_fn_class; if fncls__373 == nil { var fncls__373d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_fn_class = fncls__373d; tmp26 = fncls__373d } else { tmp26 = fncls__373 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil); arg_377 = lang.IFn_Cast(iter__1927001039__auto____13).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetDeclaredFields__Field1().Ref()); if linked_375 == nil { tmp22 = ifn_376.Invoke_O__O(arg_377) } else { tmp22 = linked_375.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_374, arg_377) } }
//line :143:1
			var tmp27 any = tmp22; var tmp28 any = A_arbace_classes_env_A_const_74; var tmp29 any; var root_378 any = A_arbace_classes_env_A_const_75.GetRawRoot__O(); var linked_379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_378, A_arbace_classes_env_inner_member_QMARK__A_fn_class); var ifn_380 lang.IFn



















			if linked_379 == nil { ifn_380 = lang.IFn_Cast(root_378) } else { ifn_380 = nil }; var arg_381 any = c__0; if linked_379 == nil { tmp29 = ifn_380.Invoke_O__O(arg_381) } else { tmp29 = linked_379.(*A_arbace_classes_env_inner_member_QMARK__A).Invoke_O_O__O(root_378, arg_381) }
//line :143:1
			var tmp30 any = tmp29; var tmp31 any = A_arbace_classes_env_A_const_76; var tmp32 any; var root_649 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_649, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_651 lang.IFn




















			if linked_650 == nil { ifn_651 = lang.IFn_Cast(root_649) } else { ifn_651 = nil }; var arg_652 any; var root_644 any = A_arbace_classes_env_A_const_77.GetRawRoot__O(); var linked_645 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_644, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_646 lang.IFn; if linked_645 == nil { ifn_646 = lang.IFn_Cast(root_644) } else { ifn_646 = nil }; var arg_647 any; var iter__1927001039__auto____12 any; var tmp33 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_New_O_O(n__10, manns__11); var tmp34 *jrt.Class; var fncls__530 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_fn_class
			if fncls__530 == nil { var fncls__530d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_fn_class = fncls__530d; tmp34 = fncls__530d } else { tmp34 = fncls__530 }; iter__1927001039__auto____12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil); arg_647 = lang.IFn_Cast(iter__1927001039__auto____12).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetDeclaredMethods__Method1().Ref())
//line :164:1
			var arg_648 any; var iter__1927001039__auto____12_2 any; var tmp35 any = A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_New_O_O(c__0, n__10); var tmp36 *jrt.Class
			var fncls__643 /*line :164:1*/*jrt.Class = A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_fn_class











			if fncls__643 == nil { var fncls__643d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_fn_class = fncls__643d; tmp36 = fncls__643d } else { tmp36 = fncls__643 }; iter__1927001039__auto____12_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp35, tmp36, nil); arg_648 = lang.IFn_Cast(iter__1927001039__auto____12_2).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetDeclaredConstructors__Constructor1().Ref())
//line :164:1
			if linked_645 == nil { arg_652 = ifn_646.Invoke_O_O__O(arg_647, arg_648) } else { arg_652 = linked_645.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_644, arg_647, arg_648) }; if linked_650 == nil { tmp32 = ifn_651.Invoke_O__O(arg_652) } else { tmp32 = linked_650.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_649, arg_652) }
//line :143:1
			info__12 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, n__10, tmp5, tmp6, tmp7, tmp8, tmp9, tmp11, tmp12, tmp14, tmp15, tmp17, tmp18, tmp20, tmp21, tmp27, tmp28, tmp30, tmp31, tmp32, A_arbace_classes_env_A_const_31, c__0)); var info__13 any; var tmp37 any; var and__1927000168__auto____13 any; var root_653 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_653, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_655 lang.IFn











































			if linked_654 == nil { ifn_655 = lang.IFn_Cast(root_653) } else { ifn_655 = nil }; var arg_656 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(c__0)).IsInterface__Z()).Ref(); if linked_654 == nil { and__1927000168__auto____13 = ifn_655.Invoke_O__O(arg_656) } else { and__1927000168__auto____13 = linked_654.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_653, arg_656) }; if jrt.J2g_Truth(and__1927000168__auto____13) { var root_663 any = A_arbace_classes_env_A_const_85.GetRawRoot__O(); var linked_664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_663, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_665 lang.IFn; if linked_664 == nil { ifn_665 = lang.IFn_Cast(root_663) } else { ifn_665 = nil }; var arg_666 any; var root_658 any = A_arbace_classes_env_A_const_86.GetRawRoot__O(); var linked_659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_658, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_660 lang.IFn; if linked_659 == nil { ifn_660 = lang.IFn_Cast(root_658) } else { ifn_660 = nil }; var arg_661 any; var tmp38 any = A_arbace_classes_env_reflect_info_fn__28000089_A_New(); var tmp39 *jrt.Class; var fncls__657 *jrt.Class = A_arbace_classes_env_reflect_info_fn__28000089_A_fn_class; if fncls__657 == nil { var fncls__657d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_classes_env_reflect_info_fn__28000089_A_fn_class = fncls__657d; tmp39 = fncls__657d } else { tmp39 = fncls__657 }; arg_661 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp38, tmp39, nil); var arg_662 any = A_arbace_classes_env_A_const_76.Invoke_O__O(info__12); if linked_659 == nil { arg_666 = ifn_660.Invoke_O_O__O(arg_661, arg_662) } else { arg_666 = linked_659.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_658, arg_661, arg_662) }; if linked_664 == nil { tmp37 = ifn_665.Invoke_O__O(arg_666) } else { tmp37 = linked_664.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_663, arg_666) } } else { tmp37 = and__1927000168__auto____13 }; if jrt.J2g_Truth(tmp37) {
				var root_730 any = A_arbace_classes_env_A_const_16.GetRawRoot__O(); var linked_731 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_730, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_732 lang.IFn; if linked_731 == nil { ifn_732 = lang.IFn_Cast(root_730) } else { ifn_732 = nil }; var arg_733 any = info__12; var arg_734 any = A_arbace_classes_env_A_const_76; var arg_735 any = A_arbace_classes_env_A_const_87.GetRawRoot__O(); var arg_736 any; var iter__1927001039__auto____13_2 any; var tmp40 any = A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_New_O(n__10); var tmp41 *jrt.Class; var fncls__725 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_fn_class; if fncls__725 == nil { var fncls__725d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_fn_class = fncls__725d; tmp41 = fncls__725d } else { tmp41 = fncls__725 }; iter__1927001039__auto____13_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp40, tmp41, nil); var tmp42 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____13_2); var tmp43 any; var root_726 any = A_arbace_classes_env_A_const_36.GetRawRoot__O(); var linked_727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_726, aot_arbace_core.A_arbace_core_requiring_resolve_A_fn_class); var ifn_728 lang.IFn; if linked_727 == nil { ifn_728 = lang.IFn_Cast(root_726) } else { ifn_728 = nil }; var arg_729 any = A_arbace_classes_env_A_const_88; if linked_727 == nil { tmp43 = ifn_728.Invoke_O__O(arg_729) } else { tmp43 = linked_727.(*aot_arbace_core.A_arbace_core_requiring_resolve_A).Invoke_O_O__O(root_726, arg_729) }; arg_736 = tmp42.Invoke_O__O(lang.IFn_Cast(tmp43).Invoke_O__O(n__10)); if linked_731 == nil { info__13 = ifn_732.Invoke_O_O_O_O__O(arg_733, arg_734, arg_735, arg_736) } else { info__13 = linked_731.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_730, arg_733, arg_734, arg_735, arg_736) } } else {
//line :187:1
					info__13 = info__12
				}


			jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_40.GetRawRoot__O())).Put_O_O__O(c__0, info__13)
//line :143:1
			tmp1 = info__13 } }; return nil }()
//line :141:1
		lang.Compiler_Evaluator_MonitorExit_O__V_NoInit(locklocal__1927000361__auto____6); if tmp44 != nil { panic(tmp44) }; return tmp1 } }



func A_arbace_classes_env_reflect_info_fn__28000027_A_New_O(p0 any) *A_arbace_classes_env_reflect_info_fn__28000027_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_fn__28000027_A{}; t.Ctor_O(p0); return t }
//line :145:1
func (t *A_arbace_classes_env_reflect_info_fn__28000027_A) Ctor_O(c__c any) { t.F_c = c__c }
//line :145:1
func (t *A_arbace_classes_env_reflect_info_fn__28000027_A) Invoke_O__O(self any) any { var root_160 any = A_arbace_classes_env_A_const_41.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, A_arbace_classes_env_read_method_annotations_A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any; var t_ any = t.F_c; t.F_c = nil; arg_163 = t_; if linked_161 == nil { return ifn_162.Invoke_O__O(arg_163) } else { return linked_161.(*A_arbace_classes_env_read_method_annotations_A).Invoke_O_O__O(root_160, arg_163) } }








func A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_New_O(p0 any) *A_arbace_classes_env_reflect_info_iter__28000031__28000035_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000031__28000035_A{}; t.Ctor_O(p0); return t }
//line :154:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :154:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_A) Invoke_O_O__O(self, s__28000032__1 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_New_O_O_O(t.F_n, s__28000032__1, self); var tmp2 *jrt.Class; var fncls__301 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_fn_class; if fncls__301 == nil { var fncls__301d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_fn_class = fncls__301d; tmp2 = fncls__301d } else { tmp2 = fncls__301 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :154:1
func A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :154:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A) Ctor_O_O_O(c__n, c__s__28000032, c__iter__28000031 any) { t.F_n = c__n; t.F_s__28000032 = c__s__28000032; t.F_iter__28000031 = c__iter__28000031 }
//line :154:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A) Invoke_O__O(self any) any { { var s__28000032__1 any; var t_ any = t.F_s__28000032; t.F_s__28000032 = nil; s__28000032__1 = t_; for { var temp__1927000414__auto____2 any; var root_186 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_188 lang.IFn; if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any = s__28000032__1; if linked_187 == nil { temp__1927000414__auto____2 = ifn_188.Invoke_O__O(arg_189) } else { temp__1927000414__auto____2 = linked_187.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_186, arg_189) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__28000032__3 any = temp__1927000414__auto____2; var tmp1 any; var root_190 any = A_arbace_classes_env_A_const_54.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = s__28000032__3; if linked_191 == nil { tmp1 = ifn_192.Invoke_O__O(arg_193) } else { tmp1 = linked_191.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_190, arg_193) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_194 any = A_arbace_classes_env_A_const_55.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_194, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_196 lang.IFn; if linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any = s__28000032__3; if linked_195 == nil { c__1927001037__auto____4 = ifn_196.Invoke_O__O(arg_197) } else { c__1927001037__auto____4 = linked_195.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_194, arg_197) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__28000034__6 any; var root_198 any = A_arbace_classes_env_A_const_56.GetRawRoot__O(); var linked_199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_198, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_200 lang.IFn; if linked_199 == nil { ifn_200 = lang.IFn_Cast(root_198) } else { ifn_200 = nil }; var arg_201 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_199 == nil { b__28000034__6 = ifn_200.Invoke_O__O(arg_201) } else { b__28000034__6 = linked_199.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_198, arg_201) }; var tmp2 any = A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_New_O_O_I_O(b__28000034__6, t.F_n, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__236 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_fn_class; if fncls__236 == nil { var fncls__236d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_fn_class = fncls__236d; tmp3 = fncls__236d } else { tmp3 = fncls__236 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_245 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_247 lang.IFn; if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any; var root_237 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_237, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_239 lang.IFn; if linked_238 == nil { ifn_239 = lang.IFn_Cast(root_237) } else { ifn_239 = nil }; var arg_240 any = b__28000034__6; if linked_238 == nil { arg_248 = ifn_239.Invoke_O__O(arg_240) } else { arg_248 = linked_238.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_237, arg_240) }; var arg_249 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__28000031); var tmp5 any; var root_241 any = A_arbace_classes_env_A_const_70.GetRawRoot__O(); var linked_242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_241, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_243 lang.IFn; if linked_242 == nil { ifn_243 = lang.IFn_Cast(root_241) } else { ifn_243 = nil }; var arg_244 any = s__28000032__3; if linked_242 == nil { tmp5 = ifn_243.Invoke_O__O(arg_244) } else { tmp5 = linked_242.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_241, arg_244) }; arg_249 = tmp4.Invoke_O__O(tmp5); if linked_246 == nil { return ifn_247.Invoke_O_O__O(arg_248, arg_249) } else { return linked_246.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_245, arg_248, arg_249) } } else { var root_254 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_256 lang.IFn; if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any; var root_250 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_250, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_252 lang.IFn; if linked_251 == nil { ifn_252 = lang.IFn_Cast(root_250) } else { ifn_252 = nil }; var arg_253 any = b__28000034__6; if linked_251 == nil { arg_257 = ifn_252.Invoke_O__O(arg_253) } else { arg_257 = linked_251.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_250, arg_253) }; var arg_258 any; if linked_255 == nil { return ifn_256.Invoke_O_O__O(arg_257, arg_258) } else { return linked_255.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_254, arg_257, arg_258) } } } else { var map__28000041__4 any; var root_259 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_259, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_261 lang.IFn; if linked_260 == nil { ifn_261 = lang.IFn_Cast(root_259) } else { ifn_261 = nil }; var arg_262 any = s__28000032__3; if linked_260 == nil { map__28000041__4 = ifn_261.Invoke_O__O(arg_262) } else { map__28000041__4 = linked_260.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_259, arg_262) }; var map__28000041__5 any; if lang.ISeq_InstanceOf(map__28000041__4) { var tmp6 any; var root_263 any = A_arbace_classes_env_A_const_57.GetRawRoot__O(); var linked_264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_263, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_265 lang.IFn; if linked_264 == nil { ifn_265 = lang.IFn_Cast(root_263) } else { ifn_265 = nil }; var arg_266 any = map__28000041__4; if linked_264 == nil { tmp6 = ifn_265.Invoke_O__O(arg_266) } else { tmp6 = linked_264.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_263, arg_266) }; if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_267 any = A_arbace_classes_env_A_const_58.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_267, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_269 lang.IFn; if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any = map__28000041__4; if linked_268 == nil { tmp7 = ifn_269.Invoke_O__O(arg_270) } else { tmp7 = linked_268.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_267, arg_270) }; map__28000041__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp7, jrt.Object_class.ArrayClass())).Ref() } else { var tmp8 any; var root_271 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_273 lang.IFn; if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = map__28000041__4; if linked_272 == nil { tmp8 = ifn_273.Invoke_O__O(arg_274) } else { tmp8 = linked_272.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_271, arg_274) }; if jrt.J2g_Truth(tmp8) { var root_275 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_275, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_277 lang.IFn; if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any = map__28000041__4; if linked_276 == nil { map__28000041__5 = ifn_277.Invoke_O__O(arg_278) } else { map__28000041__5 = linked_276.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_275, arg_278) } } else { map__28000041__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__28000041__5 = map__28000041__4 }; var name__6 any = lang.RT_Get_O_O__O_NoInit(map__28000041__5, A_arbace_classes_env_A_const_42); var desc__7 any = lang.RT_Get_O_O__O_NoInit(map__28000041__5, A_arbace_classes_env_A_const_60); var flags__8 any = lang.RT_Get_O_O__O_NoInit(map__28000041__5, A_arbace_classes_env_A_const_43); var value__9 any = lang.RT_Get_O_O__O_NoInit(map__28000041__5, A_arbace_classes_env_A_const_61); var root_296 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_298 lang.IFn; if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any; var tmp9 any = A_arbace_classes_env_A_const_42; var tmp10 any = A_arbace_classes_env_A_const_60; var tmp11 any = A_arbace_classes_env_A_const_43; var tmp12 any = A_arbace_classes_env_A_const_63; var tmp13 any = t.F_n; var tmp14 any = A_arbace_classes_env_A_const_64; var tmp15 any; var tmp16 any; var and__1927000168__auto____10 bool = jrt.Modifier_IsFinal_I__Z(lang.RT_IntCast_O__I_NoInit(flags__8))

	if and__1927000168__auto____10 { var and__1927000168__auto____11 any; var root_279 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = value__9; if linked_280 == nil { and__1927000168__auto____11 = ifn_281.Invoke_O__O(arg_282) } else { and__1927000168__auto____11 = linked_280.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_279, arg_282) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var or__1927000174__auto____12 any; var root_283 any = A_arbace_classes_env_A_const_65.GetRawRoot__O(); var linked_284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_283, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_285 lang.IFn
		if linked_284 == nil { ifn_285 = lang.IFn_Cast(root_283) } else { ifn_285 = nil }; var arg_286 any = desc__7; if linked_284 == nil { or__1927000174__auto____12 = ifn_285.Invoke_O__O(arg_286) } else { or__1927000174__auto____12 = linked_284.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_283, arg_286) }; if jrt.J2g_Truth(or__1927000174__auto____12) { tmp16 = or__1927000174__auto____12 } else { tmp16 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(desc__7, A_arbace_classes_env_A_const_66.GetRawRoot__O())).Ref() } } else {
//line :156:1
			tmp16 = and__1927000168__auto____11 } } else { tmp16 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10).Ref() }; if jrt.J2g_Truth(tmp16) {

				var root_287 any = A_arbace_classes_env_A_const_67.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, A_arbace_classes_env_coerce_const_A_fn_class); var ifn_289 lang.IFn; if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any = desc__7; var arg_291 any = value__9; if linked_288 == nil { tmp15 = ifn_289.Invoke_O_O__O(arg_290, arg_291) } else { tmp15 = linked_288.(*A_arbace_classes_env_coerce_const_A).Invoke_O_O_O__O(root_287, arg_290, arg_291) } } else {
//line :156:1
					tmp15 = nil }
//line :154:1
	arg_299 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, name__6, tmp10, desc__7, tmp11, flags__8, tmp12, tmp13, tmp14, tmp15)); var arg_300 any; var tmp17 lang.IFn = lang.IFn_Cast(t.F_iter__28000031); var tmp18 any; var root_292 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_292, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_294 lang.IFn; if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any = s__28000032__3; if linked_293 == nil { tmp18 = ifn_294.Invoke_O__O(arg_295) } else { tmp18 = linked_293.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_292, arg_295) }; arg_300 = tmp17.Invoke_O__O(tmp18); if linked_297 == nil { return ifn_298.Invoke_O_O__O(arg_299, arg_300) } else { return linked_297.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_296, arg_299, arg_300) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :154:1
func A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :154:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A) Ctor_O_O_I_O(c__b__28000034, c__n any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__28000034 = c__b__28000034; t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :154:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A) Invoke_O__O(self any) any { { var i__28000033__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__28000033__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var map__28000038__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__28000033__1)); var map__28000038__3 any; if lang.ISeq_InstanceOf(map__28000038__2) { var tmp2 any; var root_202 any = A_arbace_classes_env_A_const_57.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_204 lang.IFn; if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any = map__28000038__2; if linked_203 == nil { tmp2 = ifn_204.Invoke_O__O(arg_205) } else { tmp2 = linked_203.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_202, arg_205) }; if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_206 any = A_arbace_classes_env_A_const_58.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_208 lang.IFn; if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any = map__28000038__2; if linked_207 == nil { tmp3 = ifn_208.Invoke_O__O(arg_209) } else { tmp3 = linked_207.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_206, arg_209) }; map__28000038__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp3, jrt.Object_class.ArrayClass())).Ref() } else { var tmp4 any; var root_210 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_210, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_212 lang.IFn; if linked_211 == nil { ifn_212 = lang.IFn_Cast(root_210) } else { ifn_212 = nil }; var arg_213 any = map__28000038__2; if linked_211 == nil { tmp4 = ifn_212.Invoke_O__O(arg_213) } else { tmp4 = linked_211.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_210, arg_213) }; if jrt.J2g_Truth(tmp4) { var root_214 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_214, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_216 lang.IFn; if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = map__28000038__2; if linked_215 == nil { map__28000038__3 = ifn_216.Invoke_O__O(arg_217) } else { map__28000038__3 = linked_215.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_214, arg_217) } } else { map__28000038__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__28000038__3 = map__28000038__2 }; var name__4 any = lang.RT_Get_O_O__O_NoInit(map__28000038__3, A_arbace_classes_env_A_const_42); var desc__5 any = lang.RT_Get_O_O__O_NoInit(map__28000038__3, A_arbace_classes_env_A_const_60); var flags__6 any = lang.RT_Get_O_O__O_NoInit(map__28000038__3, A_arbace_classes_env_A_const_43); var value__7 any = lang.RT_Get_O_O__O_NoInit(map__28000038__3, A_arbace_classes_env_A_const_61); var root_231 any = A_arbace_classes_env_A_const_62.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_231, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_233 lang.IFn; if linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any = t.F_b__28000034; var arg_235 any; var tmp5 any = A_arbace_classes_env_A_const_42; var tmp6 any = A_arbace_classes_env_A_const_60; var tmp7 any = A_arbace_classes_env_A_const_43; var tmp8 any = A_arbace_classes_env_A_const_63; var tmp9 any = t.F_n; var tmp10 any = A_arbace_classes_env_A_const_64; var tmp11 any; var tmp12 any; var and__1927000168__auto____8 bool = jrt.Modifier_IsFinal_I__Z(lang.RT_IntCast_O__I_NoInit(flags__6))

	if and__1927000168__auto____8 { var and__1927000168__auto____9 any; var root_218 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_218, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_220 lang.IFn; if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any = value__7; if linked_219 == nil { and__1927000168__auto____9 = ifn_220.Invoke_O__O(arg_221) } else { and__1927000168__auto____9 = linked_219.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_218, arg_221) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var or__1927000174__auto____10 any; var root_222 any = A_arbace_classes_env_A_const_65.GetRawRoot__O(); var linked_223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_222, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_224 lang.IFn
		if linked_223 == nil { ifn_224 = lang.IFn_Cast(root_222) } else { ifn_224 = nil }; var arg_225 any = desc__5; if linked_223 == nil { or__1927000174__auto____10 = ifn_224.Invoke_O__O(arg_225) } else { or__1927000174__auto____10 = linked_223.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_222, arg_225) }; if jrt.J2g_Truth(or__1927000174__auto____10) { tmp12 = or__1927000174__auto____10 } else { tmp12 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(desc__5, A_arbace_classes_env_A_const_66.GetRawRoot__O())).Ref() } } else {
//line :156:1
			tmp12 = and__1927000168__auto____9 } } else { tmp12 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() }; if jrt.J2g_Truth(tmp12) {

				var root_226 any = A_arbace_classes_env_A_const_67.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_226, A_arbace_classes_env_coerce_const_A_fn_class); var ifn_228 lang.IFn; if linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var arg_229 any = desc__5; var arg_230 any = value__7; if linked_227 == nil { tmp11 = ifn_228.Invoke_O_O__O(arg_229, arg_230) } else { tmp11 = linked_227.(*A_arbace_classes_env_coerce_const_A).Invoke_O_O_O__O(root_226, arg_229, arg_230) } } else {
//line :156:1
					tmp11 = nil }
//line :154:1
	arg_235 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, name__4, tmp6, desc__5, tmp7, flags__6, tmp8, tmp9, tmp10, tmp11)); if linked_232 == nil { ifn_233.Invoke_O_O__O(arg_234, arg_235) } else { linked_232.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_231, arg_234, arg_235) }; i__28000033__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000033__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_New_O(p0 any) *A_arbace_classes_env_reflect_info_iter__28000045__28000049_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000045__28000049_A{}; t.Ctor_O(p0); return t }
//line :159:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :159:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_A) Invoke_O_O__O(self, s__28000046__1 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_New_O_O_O(t.F_n, s__28000046__1, self); var tmp2 *jrt.Class; var fncls__372 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_fn_class; if fncls__372 == nil { var fncls__372d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_fn_class = fncls__372d; tmp2 = fncls__372d } else { tmp2 = fncls__372 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :159:1
func A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :159:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A) Ctor_O_O_O(c__n, c__s__28000046, c__iter__28000045 any) { t.F_n = c__n; t.F_s__28000046 = c__s__28000046; t.F_iter__28000045 = c__iter__28000045 }
//line :159:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A) Invoke_O__O(self any) any { { var s__28000046__1 any; var t_ any = t.F_s__28000046; t.F_s__28000046 = nil; s__28000046__1 = t_; for { var temp__1927000414__auto____2 any; var root_307 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_307, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_309 lang.IFn; if linked_308 == nil { ifn_309 = lang.IFn_Cast(root_307) } else { ifn_309 = nil }; var arg_310 any = s__28000046__1; if linked_308 == nil { temp__1927000414__auto____2 = ifn_309.Invoke_O__O(arg_310) } else { temp__1927000414__auto____2 = linked_308.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_307, arg_310) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__28000046__3 any = temp__1927000414__auto____2; var tmp1 any; var root_311 any = A_arbace_classes_env_A_const_54.GetRawRoot__O(); var linked_312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_311, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_313 lang.IFn; if linked_312 == nil { ifn_313 = lang.IFn_Cast(root_311) } else { ifn_313 = nil }; var arg_314 any = s__28000046__3; if linked_312 == nil { tmp1 = ifn_313.Invoke_O__O(arg_314) } else { tmp1 = linked_312.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_311, arg_314) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_315 any = A_arbace_classes_env_A_const_55.GetRawRoot__O(); var linked_316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_315, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_317 lang.IFn; if linked_316 == nil { ifn_317 = lang.IFn_Cast(root_315) } else { ifn_317 = nil }; var arg_318 any = s__28000046__3; if linked_316 == nil { c__1927001037__auto____4 = ifn_317.Invoke_O__O(arg_318) } else { c__1927001037__auto____4 = linked_316.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_315, arg_318) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__28000048__6 any; var root_319 any = A_arbace_classes_env_A_const_56.GetRawRoot__O(); var linked_320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_319, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_321 lang.IFn; if linked_320 == nil { ifn_321 = lang.IFn_Cast(root_319) } else { ifn_321 = nil }; var arg_322 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_320 == nil { b__28000048__6 = ifn_321.Invoke_O__O(arg_322) } else { b__28000048__6 = linked_320.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_319, arg_322) }; var tmp2 any = A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_New_O_O_I_O(t.F_n, b__28000048__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__332 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_fn_class; if fncls__332 == nil { var fncls__332d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_fn_class = fncls__332d; tmp3 = fncls__332d } else { tmp3 = fncls__332 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_341 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_341, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_343 lang.IFn; if linked_342 == nil { ifn_343 = lang.IFn_Cast(root_341) } else { ifn_343 = nil }; var arg_344 any; var root_333 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_333, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_335 lang.IFn; if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any = b__28000048__6; if linked_334 == nil { arg_344 = ifn_335.Invoke_O__O(arg_336) } else { arg_344 = linked_334.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_333, arg_336) }; var arg_345 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__28000045); var tmp5 any; var root_337 any = A_arbace_classes_env_A_const_70.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_337, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_339 lang.IFn; if linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any = s__28000046__3; if linked_338 == nil { tmp5 = ifn_339.Invoke_O__O(arg_340) } else { tmp5 = linked_338.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_337, arg_340) }; arg_345 = tmp4.Invoke_O__O(tmp5); if linked_342 == nil { return ifn_343.Invoke_O_O__O(arg_344, arg_345) } else { return linked_342.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_341, arg_344, arg_345) } } else { var root_350 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any; var root_346 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_346, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_348 lang.IFn; if linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any = b__28000048__6; if linked_347 == nil { arg_353 = ifn_348.Invoke_O__O(arg_349) } else { arg_353 = linked_347.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_346, arg_349) }; var arg_354 any; if linked_351 == nil { return ifn_352.Invoke_O_O__O(arg_353, arg_354) } else { return linked_351.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_350, arg_353, arg_354) } } } else { var f__4 any; var root_355 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_355, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_357 lang.IFn; if linked_356 == nil { ifn_357 = lang.IFn_Cast(root_355) } else { ifn_357 = nil }; var arg_358 any = s__28000046__3; if linked_356 == nil { f__4 = ifn_357.Invoke_O__O(arg_358) } else { f__4 = linked_356.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_355, arg_358) }; var root_367 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_367, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_369 lang.IFn; if linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any; var tmp6 any = A_arbace_classes_env_A_const_42; var tmp7 any = jrt.NN(jrt.Field_Cast(f__4)).GetName__String().Ref(); var tmp8 any = A_arbace_classes_env_A_const_60; var tmp9 any; var root_359 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A_fn_class); var ifn_361 lang.IFn
														if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any = jrt.NN(jrt.Field_Cast(f__4)).GetType__Class().Ref(); if linked_360 == nil { tmp9 = ifn_361.Invoke_O__O(arg_362) } else { tmp9 = linked_360.(*aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A).Invoke_O_O__O(root_359, arg_362) }
//line :159:1
	var tmp10 any = tmp9; var tmp11 any = A_arbace_classes_env_A_const_43; arg_370 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7, tmp8, tmp10, tmp11, jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Field_Cast(f__4)).GetModifiers__I()).Ref(), A_arbace_classes_env_A_const_63, t.F_n, A_arbace_classes_env_A_const_64, nil)); var arg_371 any; var tmp12 lang.IFn = lang.IFn_Cast(t.F_iter__28000045); var tmp13 any; var root_363 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_363, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_365 lang.IFn; if linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any = s__28000046__3; if linked_364 == nil { tmp13 = ifn_365.Invoke_O__O(arg_366) } else { tmp13 = linked_364.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_363, arg_366) }; arg_371 = tmp12.Invoke_O__O(tmp13); if linked_368 == nil { return ifn_369.Invoke_O_O__O(arg_370, arg_371) } else { return linked_368.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_367, arg_370, arg_371) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :159:1
func A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :159:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A) Ctor_O_O_I_O(c__n, c__b__28000048 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__28000048 = c__b__28000048; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :159:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A) Invoke_O__O(self any) any { { var i__28000047__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__28000047__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__28000047__1)); var root_327 any = A_arbace_classes_env_A_const_62.GetRawRoot__O(); var linked_328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_327, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_329 lang.IFn; if linked_328 == nil { ifn_329 = lang.IFn_Cast(root_327) } else { ifn_329 = nil }; var arg_330 any = t.F_b__28000048; var arg_331 any; var tmp2 any = A_arbace_classes_env_A_const_42; var tmp3 any = jrt.NN(jrt.Field_Cast(f__2)).GetName__String().Ref(); var tmp4 any = A_arbace_classes_env_A_const_60; var tmp5 any; var root_323 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var linked_324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_323, aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A_fn_class); var ifn_325 lang.IFn
																if linked_324 == nil { ifn_325 = lang.IFn_Cast(root_323) } else { ifn_325 = nil }; var arg_326 any = jrt.NN(jrt.Field_Cast(f__2)).GetType__Class().Ref(); if linked_324 == nil { tmp5 = ifn_325.Invoke_O__O(arg_326) } else { tmp5 = linked_324.(*aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A).Invoke_O_O__O(root_323, arg_326) }
//line :159:1
	var tmp6 any = tmp5; var tmp7 any = A_arbace_classes_env_A_const_43; arg_331 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, tmp6, tmp7, jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Field_Cast(f__2)).GetModifiers__I()).Ref(), A_arbace_classes_env_A_const_63, t.F_n, A_arbace_classes_env_A_const_64, nil)); if linked_328 == nil { ifn_329.Invoke_O_O__O(arg_330, arg_331) } else { linked_328.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_327, arg_330, arg_331) }; i__28000047__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000047__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_New_O_O(p0, p1 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_A{}; t.Ctor_O_O(p0, p1); return t }
//line :165:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_A) Ctor_O_O(c__n, c__manns any) { t.F_n = c__n; t.F_manns = c__manns }
//line :165:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_A) Invoke_O_O__O(self, s__28000056__1 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_New_O_O_O_O(t.F_n, t.F_manns, s__28000056__1, self); var tmp2 *jrt.Class; var fncls__529 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_fn_class; if fncls__529 == nil { var fncls__529d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_fn_class = fncls__529d; tmp2 = fncls__529d } else { tmp2 = fncls__529 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :165:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :165:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A) Ctor_O_O_O_O(c__n, c__manns, c__s__28000056, c__iter__28000055 any) { t.F_n = c__n; t.F_manns = c__manns; t.F_s__28000056 = c__s__28000056; t.F_iter__28000055 = c__iter__28000055 }
//line :165:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A) Invoke_O__O(self any) any { { var s__28000056__1 any; var t_ any = t.F_s__28000056; t.F_s__28000056 = nil; s__28000056__1 = t_; for { var temp__1927000414__auto____2 any; var root_382 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_382, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_384 lang.IFn; if linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; var arg_385 any = s__28000056__1; if linked_383 == nil { temp__1927000414__auto____2 = ifn_384.Invoke_O__O(arg_385) } else { temp__1927000414__auto____2 = linked_383.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_382, arg_385) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__28000056__3 any = temp__1927000414__auto____2; var tmp1 any; var root_386 any = A_arbace_classes_env_A_const_54.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_386, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_388 lang.IFn; if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any = s__28000056__3; if linked_387 == nil { tmp1 = ifn_388.Invoke_O__O(arg_389) } else { tmp1 = linked_387.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_386, arg_389) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_390 any = A_arbace_classes_env_A_const_55.GetRawRoot__O(); var linked_391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_390, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_392 lang.IFn; if linked_391 == nil { ifn_392 = lang.IFn_Cast(root_390) } else { ifn_392 = nil }; var arg_393 any = s__28000056__3; if linked_391 == nil { c__1927001037__auto____4 = ifn_392.Invoke_O__O(arg_393) } else { c__1927001037__auto____4 = linked_391.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_390, arg_393) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__28000058__6 any; var root_394 any = A_arbace_classes_env_A_const_56.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_396 lang.IFn; if linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_395 == nil { b__28000058__6 = ifn_396.Invoke_O__O(arg_397) } else { b__28000058__6 = linked_395.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_394, arg_397) }; var tmp2 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_New_O_O_O_I_O(t.F_n, b__28000058__6, t.F_manns, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__448 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_fn_class; if fncls__448 == nil { var fncls__448d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_fn_class = fncls__448d; tmp3 = fncls__448d } else { tmp3 = fncls__448 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_457 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_457, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_459 lang.IFn; if linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; var arg_460 any; var root_449 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_449, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_451 lang.IFn; if linked_450 == nil { ifn_451 = lang.IFn_Cast(root_449) } else { ifn_451 = nil }; var arg_452 any = b__28000058__6; if linked_450 == nil { arg_460 = ifn_451.Invoke_O__O(arg_452) } else { arg_460 = linked_450.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_449, arg_452) }; var arg_461 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__28000055); var tmp5 any; var root_453 any = A_arbace_classes_env_A_const_70.GetRawRoot__O(); var linked_454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_453, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_455 lang.IFn; if linked_454 == nil { ifn_455 = lang.IFn_Cast(root_453) } else { ifn_455 = nil }; var arg_456 any = s__28000056__3; if linked_454 == nil { tmp5 = ifn_455.Invoke_O__O(arg_456) } else { tmp5 = linked_454.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_453, arg_456) }; arg_461 = tmp4.Invoke_O__O(tmp5); if linked_458 == nil { return ifn_459.Invoke_O_O__O(arg_460, arg_461) } else { return linked_458.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_457, arg_460, arg_461) } } else { var root_466 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_468 lang.IFn; if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any; var root_462 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_462, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_464 lang.IFn; if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any = b__28000058__6; if linked_463 == nil { arg_469 = ifn_464.Invoke_O__O(arg_465) } else { arg_469 = linked_463.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_462, arg_465) }; var arg_470 any; if linked_467 == nil { return ifn_468.Invoke_O_O__O(arg_469, arg_470) } else { return linked_467.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_466, arg_469, arg_470) } } } else { var m__4 any; var root_471 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_471, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_473 lang.IFn; if linked_472 == nil { ifn_473 = lang.IFn_Cast(root_471) } else { ifn_473 = nil }; var arg_474 any = s__28000056__3; if linked_472 == nil { m__4 = ifn_473.Invoke_O__O(arg_474) } else { m__4 = linked_472.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_471, arg_474) }; var desc__5 any; var root_484 any = A_arbace_classes_env_A_const_78.GetRawRoot__O(); var linked_485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_484, aot_arbace_classes_types.A_arbace_classes_types_method_desc_A_fn_class); var ifn_486 lang.IFn
														if linked_485 == nil { ifn_486 = lang.IFn_Cast(root_484) } else { ifn_486 = nil }; var arg_487 any; var root_475 any = A_arbace_classes_env_A_const_79.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_475, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_477 lang.IFn; if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var arg_479 any = jrt.NN(jrt.Method_Cast(m__4)).GetParameterTypes__Class1().Ref(); if linked_476 == nil { arg_487 = ifn_477.Invoke_O_O__O(arg_478, arg_479) } else { arg_487 = linked_476.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_475, arg_478, arg_479) }; var arg_488 any; var root_480 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var linked_481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_480, aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A_fn_class); var ifn_482 lang.IFn
														if linked_481 == nil { ifn_482 = lang.IFn_Cast(root_480) } else { ifn_482 = nil }; var arg_483 any = jrt.NN(jrt.Method_Cast(m__4)).GetReturnType__Class().Ref(); if linked_481 == nil { arg_488 = ifn_482.Invoke_O__O(arg_483) } else { arg_488 = linked_481.(*aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A).Invoke_O_O__O(root_480, arg_483) }
//line :166:1
	if linked_485 == nil { desc__5 = ifn_486.Invoke_O_O__O(arg_487, arg_488) } else { desc__5 = linked_485.(*aot_arbace_classes_types.A_arbace_classes_types_method_desc_A).Invoke_O_O_O__O(root_484, arg_487, arg_488) }
//line :165:1
	var root_524 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_524, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_526 lang.IFn; if linked_525 == nil { ifn_526 = lang.IFn_Cast(root_524) } else { ifn_526 = nil }; var arg_527 any; var tmp6 any = A_arbace_classes_env_A_const_42; var tmp7 any = jrt.NN(jrt.Method_Cast(m__4)).GetName__String().Ref(); var tmp8 any = A_arbace_classes_env_A_const_60; var tmp9 any = A_arbace_classes_env_A_const_43; var tmp10 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Method_Cast(m__4)).GetModifiers__I()).Ref(); var tmp11 any = A_arbace_classes_env_A_const_63; var tmp12 any = t.F_n; var tmp13 any = A_arbace_classes_env_A_const_80; var tmp14 any; var root_489 any = A_arbace_classes_env_A_const_47.GetRawRoot__O(); var linked_490 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_489, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_491 lang.IFn





	if linked_490 == nil { ifn_491 = lang.IFn_Cast(root_489) } else { ifn_491 = nil }; var arg_492 any = A_arbace_classes_env_A_const_34.GetRawRoot__O(); var arg_493 any = jrt.NN(jrt.Method_Cast(m__4)).GetExceptionTypes__Class1().Ref(); if linked_490 == nil { tmp14 = ifn_491.Invoke_O_O__O(arg_492, arg_493) } else { tmp14 = linked_490.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_489, arg_492, arg_493) }
//line :165:1
	var tmp15 any = tmp14; var tmp16 any = A_arbace_classes_env_A_const_81; var tmp17 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_New_O_O_O(m__4, desc__5, t.F_manns); var tmp18 *jrt.Class
	var fncls__503 /*line :165:1*/*jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_fn_class






	if fncls__503 == nil { var fncls__503d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_fn_class = fncls__503d; tmp18 = fncls__503d } else { tmp18 = fncls__503 }
//line :165:1
	var tmp19 any = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil)); var tmp20 any = A_arbace_classes_env_A_const_83; var tmp21 any; var root_515 any = A_arbace_classes_env_A_const_84.GetRawRoot__O(); var linked_516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_515, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_517 lang.IFn







	if linked_516 == nil { ifn_517 = lang.IFn_Cast(root_515) } else { ifn_517 = nil }; var arg_518 any; var tmp22 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_New_O_O_O(m__4, desc__5, t.F_manns); var tmp23 *jrt.Class; var fncls__514 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_fn_class
	if fncls__514 == nil { var fncls__514d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_fn_class = fncls__514d; tmp23 = fncls__514d } else { tmp23 = fncls__514 }; arg_518 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil)
//line :173:1
	var arg_519 any = jrt.NN(jrt.Method_Cast(m__4)).GetParameterTypes__Class1().Ref(); if linked_516 == nil { tmp21 = ifn_517.Invoke_O_O__O(arg_518, arg_519) } else { tmp21 = linked_516.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_515, arg_518, arg_519) }
//line :165:1
	arg_527 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7, tmp8, desc__5, tmp9, tmp10, tmp11, tmp12, tmp13, tmp15, tmp16, tmp19, tmp20, tmp21)); var arg_528 any; var tmp24 lang.IFn = lang.IFn_Cast(t.F_iter__28000055); var tmp25 any; var root_520 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_520, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_522 lang.IFn; if linked_521 == nil { ifn_522 = lang.IFn_Cast(root_520) } else { ifn_522 = nil }; var arg_523 any = s__28000056__3; if linked_521 == nil { tmp25 = ifn_522.Invoke_O__O(arg_523) } else { tmp25 = linked_521.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_520, arg_523) }; arg_528 = tmp24.Invoke_O__O(tmp25); if linked_525 == nil { return ifn_526.Invoke_O_O__O(arg_527, arg_528) } else { return linked_525.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_524, arg_527, arg_528) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :165:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :165:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A) Ctor_O_O_O_I_O(c__n, c__b__28000058, c__manns any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__28000058 = c__b__28000058; t.F_manns = c__manns; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :165:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A) Invoke_O__O(self any) any { { var i__28000057__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__28000057__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__28000057__1)); var desc__3 any; var root_407 any = A_arbace_classes_env_A_const_78.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_407, aot_arbace_classes_types.A_arbace_classes_types_method_desc_A_fn_class); var ifn_409 lang.IFn
																if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any; var root_398 any = A_arbace_classes_env_A_const_79.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_398, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var arg_402 any = jrt.NN(jrt.Method_Cast(m__2)).GetParameterTypes__Class1().Ref(); if linked_399 == nil { arg_410 = ifn_400.Invoke_O_O__O(arg_401, arg_402) } else { arg_410 = linked_399.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_398, arg_401, arg_402) }; var arg_411 any; var root_403 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_403, aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A_fn_class); var ifn_405 lang.IFn
																if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any = jrt.NN(jrt.Method_Cast(m__2)).GetReturnType__Class().Ref(); if linked_404 == nil { arg_411 = ifn_405.Invoke_O__O(arg_406) } else { arg_411 = linked_404.(*aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A).Invoke_O_O__O(root_403, arg_406) }
//line :166:1
	if linked_408 == nil { desc__3 = ifn_409.Invoke_O_O__O(arg_410, arg_411) } else { desc__3 = linked_408.(*aot_arbace_classes_types.A_arbace_classes_types_method_desc_A).Invoke_O_O_O__O(root_407, arg_410, arg_411) }
//line :165:1
	var root_443 any = A_arbace_classes_env_A_const_62.GetRawRoot__O(); var linked_444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_443, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_445 lang.IFn; if linked_444 == nil { ifn_445 = lang.IFn_Cast(root_443) } else { ifn_445 = nil }; var arg_446 any = t.F_b__28000058; var arg_447 any; var tmp2 any = A_arbace_classes_env_A_const_42; var tmp3 any = jrt.NN(jrt.Method_Cast(m__2)).GetName__String().Ref(); var tmp4 any = A_arbace_classes_env_A_const_60; var tmp5 any = A_arbace_classes_env_A_const_43; var tmp6 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Method_Cast(m__2)).GetModifiers__I()).Ref(); var tmp7 any = A_arbace_classes_env_A_const_63; var tmp8 any = t.F_n; var tmp9 any = A_arbace_classes_env_A_const_80; var tmp10 any; var root_412 any = A_arbace_classes_env_A_const_47.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_414 lang.IFn





	if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = A_arbace_classes_env_A_const_34.GetRawRoot__O(); var arg_416 any = jrt.NN(jrt.Method_Cast(m__2)).GetExceptionTypes__Class1().Ref(); if linked_413 == nil { tmp10 = ifn_414.Invoke_O_O__O(arg_415, arg_416) } else { tmp10 = linked_413.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_412, arg_415, arg_416) }
//line :165:1
	var tmp11 any = tmp10; var tmp12 any = A_arbace_classes_env_A_const_81; var tmp13 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_New_O_O_O(m__2, desc__3, t.F_manns); var tmp14 *jrt.Class
	var fncls__426 /*line :165:1*/*jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_fn_class






	if fncls__426 == nil { var fncls__426d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_fn_class = fncls__426d; tmp14 = fncls__426d } else { tmp14 = fncls__426 }
//line :165:1
	var tmp15 any = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil)); var tmp16 any = A_arbace_classes_env_A_const_83; var tmp17 any; var root_438 any = A_arbace_classes_env_A_const_84.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_438, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_440 lang.IFn







	if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any; var tmp18 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_New_O_O_O(m__2, desc__3, t.F_manns); var tmp19 *jrt.Class; var fncls__437 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_fn_class
	if fncls__437 == nil { var fncls__437d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_fn_class = fncls__437d; tmp19 = fncls__437d } else { tmp19 = fncls__437 }; arg_441 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil)
//line :173:1
	var arg_442 any = jrt.NN(jrt.Method_Cast(m__2)).GetParameterTypes__Class1().Ref(); if linked_439 == nil { tmp17 = ifn_440.Invoke_O_O__O(arg_441, arg_442) } else { tmp17 = linked_439.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_438, arg_441, arg_442) }
//line :165:1
	arg_447 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, desc__3, tmp5, tmp6, tmp7, tmp8, tmp9, tmp11, tmp12, tmp15, tmp16, tmp17)); if linked_444 == nil { ifn_445.Invoke_O_O__O(arg_446, arg_447) } else { linked_444.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_443, arg_446, arg_447) }; i__28000057__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000057__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :172:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A) Ctor_O_O_O(c__m, c__desc, c__manns any) { t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :172:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A) Invoke_O__O(self any) any { var root_421 any = A_arbace_classes_env_A_const_82.GetRawRoot__O(); var linked_422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_421, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_423 lang.IFn; if linked_422 == nil { ifn_423 = lang.IFn_Cast(root_421) } else { ifn_423 = nil }; var arg_424 any; var root_417 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_417, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_419 lang.IFn; if linked_418 == nil { ifn_419 = lang.IFn_Cast(root_417) } else { ifn_419 = nil }; var arg_420 any; var t_ any = t.F_manns; t.F_manns = nil; arg_420 = t_; if linked_418 == nil { arg_424 = ifn_419.Invoke_O__O(arg_420) } else { arg_424 = linked_418.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_417, arg_420) }; var arg_425 any; var tmp1 any; var t__2 any = t.F_m; t.F_m = nil; tmp1 = t__2; var tmp2 any = jrt.NN(jrt.Method_Cast(tmp1)).GetName__String().Ref(); var tmp3 any; var t__3 any = t.F_desc; t.F_desc = nil; tmp3 = t__3; arg_425 = lang.Tuple_Create_O_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3), A_arbace_classes_env_A_const_81); if linked_422 == nil { return ifn_423.Invoke_O_O__O(arg_424, arg_425) } else { return linked_422.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_421, arg_424, arg_425) } }
//line :172:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :172:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A) Ctor_O_O_O(c__m, c__desc, c__manns any) { t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :172:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A) Invoke_O__O(self any) any { var root_498 any = A_arbace_classes_env_A_const_82.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any; var root_494 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_494, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_496 lang.IFn; if linked_495 == nil { ifn_496 = lang.IFn_Cast(root_494) } else { ifn_496 = nil }; var arg_497 any; var t_ any = t.F_manns; t.F_manns = nil; arg_497 = t_; if linked_495 == nil { arg_501 = ifn_496.Invoke_O__O(arg_497) } else { arg_501 = linked_495.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_494, arg_497) }; var arg_502 any; var tmp1 any; var t__2 any = t.F_m; t.F_m = nil; tmp1 = t__2; var tmp2 any = jrt.NN(jrt.Method_Cast(tmp1)).GetName__String().Ref(); var tmp3 any; var t__3 any = t.F_desc; t.F_desc = nil; tmp3 = t__3; arg_502 = lang.Tuple_Create_O_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3), A_arbace_classes_env_A_const_81); if linked_499 == nil { return ifn_500.Invoke_O_O__O(arg_501, arg_502) } else { return linked_499.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_498, arg_501, arg_502) } }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :174:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A) Ctor_O_O_O(c__m, c__desc, c__manns any) { t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :174:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A) Invoke_O_O_O__O(self, i__1, ___2 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_New_O_O_O_O(i__1, t.F_m, t.F_desc, t.F_manns); var tmp2 *jrt.Class; var fncls__436 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_fn_class; if fncls__436 == nil { var fncls__436d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_fn_class = fncls__436d; tmp2 = fncls__436d } else { tmp2 = fncls__436 }; return lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :174:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :174:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A) Ctor_O_O_O_O(c__i, c__m, c__desc, c__manns any) { t.F_i = c__i; t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :174:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A) Invoke_O__O(self any) any { var root_431 any = A_arbace_classes_env_A_const_82.GetRawRoot__O(); var linked_432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_431, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_433 lang.IFn; if linked_432 == nil { ifn_433 = lang.IFn_Cast(root_431) } else { ifn_433 = nil }; var arg_434 any; var root_427 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_427, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_429 lang.IFn; if linked_428 == nil { ifn_429 = lang.IFn_Cast(root_427) } else { ifn_429 = nil }; var arg_430 any; var t_ any = t.F_manns; t.F_manns = nil; arg_430 = t_; if linked_428 == nil { arg_434 = ifn_429.Invoke_O__O(arg_430) } else { arg_434 = linked_428.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_427, arg_430) }; var arg_435 any; var tmp1 any; var t__2 any = t.F_m; t.F_m = nil; tmp1 = t__2; var tmp2 any = jrt.NN(jrt.Method_Cast(tmp1)).GetName__String().Ref(); var tmp3 any; var t__3 any = t.F_desc; t.F_desc = nil; tmp3 = t__3; var tmp4 any = lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3); var tmp5 any = A_arbace_classes_env_A_const_83; var tmp6 any; var t__4 any = t.F_i; t.F_i = nil; tmp6 = t__4; arg_435 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp4, tmp5, tmp6); if linked_432 == nil { return ifn_433.Invoke_O_O__O(arg_434, arg_435) } else { return linked_432.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_431, arg_434, arg_435) } }
//line :174:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :174:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A) Ctor_O_O_O(c__m, c__desc, c__manns any) { t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :174:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A) Invoke_O_O_O__O(self, i__1, ___2 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_New_O_O_O_O(i__1, t.F_m, t.F_desc, t.F_manns); var tmp2 *jrt.Class; var fncls__513 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_fn_class; if fncls__513 == nil { var fncls__513d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_fn_class = fncls__513d; tmp2 = fncls__513d } else { tmp2 = fncls__513 }; return lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :174:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :174:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A) Ctor_O_O_O_O(c__i, c__m, c__desc, c__manns any) { t.F_i = c__i; t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :174:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A) Invoke_O__O(self any) any { var root_508 any = A_arbace_classes_env_A_const_82.GetRawRoot__O(); var linked_509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_508, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_510 lang.IFn; if linked_509 == nil { ifn_510 = lang.IFn_Cast(root_508) } else { ifn_510 = nil }; var arg_511 any; var root_504 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_504, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_506 lang.IFn; if linked_505 == nil { ifn_506 = lang.IFn_Cast(root_504) } else { ifn_506 = nil }; var arg_507 any; var t_ any = t.F_manns; t.F_manns = nil; arg_507 = t_; if linked_505 == nil { arg_511 = ifn_506.Invoke_O__O(arg_507) } else { arg_511 = linked_505.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_504, arg_507) }; var arg_512 any; var tmp1 any; var t__2 any = t.F_m; t.F_m = nil; tmp1 = t__2; var tmp2 any = jrt.NN(jrt.Method_Cast(tmp1)).GetName__String().Ref(); var tmp3 any; var t__3 any = t.F_desc; t.F_desc = nil; tmp3 = t__3; var tmp4 any = lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3); var tmp5 any = A_arbace_classes_env_A_const_83; var tmp6 any; var t__4 any = t.F_i; t.F_i = nil; tmp6 = t__4; arg_512 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp4, tmp5, tmp6); if linked_509 == nil { return ifn_510.Invoke_O_O__O(arg_511, arg_512) } else { return linked_509.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_508, arg_511, arg_512) } }

func A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_New_O_O(p0, p1 any) *A_arbace_classes_env_reflect_info_iter__28000077__28000081_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000077__28000081_A{}; t.Ctor_O_O(p0, p1); return t }
//line :176:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_A) Ctor_O_O(c__c, c__n any) { t.F_c = c__c; t.F_n = c__n }
//line :176:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_A) Invoke_O_O__O(self, s__28000078__1 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_New_O_O_O_O(t.F_c, t.F_n, s__28000078__1, self); var tmp2 *jrt.Class; var fncls__642 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_fn_class; if fncls__642 == nil { var fncls__642d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_fn_class = fncls__642d; tmp2 = fncls__642d } else { tmp2 = fncls__642 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :176:1
func A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :176:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A) Ctor_O_O_O_O(c__c, c__n, c__s__28000078, c__iter__28000077 any) { t.F_c = c__c; t.F_n = c__n; t.F_s__28000078 = c__s__28000078; t.F_iter__28000077 = c__iter__28000077 }
//line :176:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A) Invoke_O__O(self any) any { { var s__28000078__1 any; var t_ any = t.F_s__28000078; t.F_s__28000078 = nil; s__28000078__1 = t_; for { var temp__1927000414__auto____2 any; var root_531 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_531, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_533 lang.IFn; if linked_532 == nil { ifn_533 = lang.IFn_Cast(root_531) } else { ifn_533 = nil }; var arg_534 any = s__28000078__1; if linked_532 == nil { temp__1927000414__auto____2 = ifn_533.Invoke_O__O(arg_534) } else { temp__1927000414__auto____2 = linked_532.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_531, arg_534) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__28000078__3 any = temp__1927000414__auto____2; var tmp1 any; var root_535 any = A_arbace_classes_env_A_const_54.GetRawRoot__O(); var linked_536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_535, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_537 lang.IFn; if linked_536 == nil { ifn_537 = lang.IFn_Cast(root_535) } else { ifn_537 = nil }; var arg_538 any = s__28000078__3; if linked_536 == nil { tmp1 = ifn_537.Invoke_O__O(arg_538) } else { tmp1 = linked_536.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_535, arg_538) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_539 any = A_arbace_classes_env_A_const_55.GetRawRoot__O(); var linked_540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_539, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_541 lang.IFn; if linked_540 == nil { ifn_541 = lang.IFn_Cast(root_539) } else { ifn_541 = nil }; var arg_542 any = s__28000078__3; if linked_540 == nil { c__1927001037__auto____4 = ifn_541.Invoke_O__O(arg_542) } else { c__1927001037__auto____4 = linked_540.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_539, arg_542) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__28000080__6 any; var root_543 any = A_arbace_classes_env_A_const_56.GetRawRoot__O(); var linked_544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_543, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_545 lang.IFn; if linked_544 == nil { ifn_545 = lang.IFn_Cast(root_543) } else { ifn_545 = nil }; var arg_546 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_544 == nil { b__28000080__6 = ifn_545.Invoke_O__O(arg_546) } else { b__28000080__6 = linked_544.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_543, arg_546) }; var tmp2 any = A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_New_O_O_O_I_O(t.F_c, t.F_n, b__28000080__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__579 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_fn_class; if fncls__579 == nil { var fncls__579d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_fn_class = fncls__579d; tmp3 = fncls__579d } else { tmp3 = fncls__579 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_588 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_588, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_590 lang.IFn; if linked_589 == nil { ifn_590 = lang.IFn_Cast(root_588) } else { ifn_590 = nil }; var arg_591 any; var root_580 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_580, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_582 lang.IFn; if linked_581 == nil { ifn_582 = lang.IFn_Cast(root_580) } else { ifn_582 = nil }; var arg_583 any = b__28000080__6; if linked_581 == nil { arg_591 = ifn_582.Invoke_O__O(arg_583) } else { arg_591 = linked_581.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_580, arg_583) }; var arg_592 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__28000077); var tmp5 any; var root_584 any = A_arbace_classes_env_A_const_70.GetRawRoot__O(); var linked_585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_584, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_586 lang.IFn; if linked_585 == nil { ifn_586 = lang.IFn_Cast(root_584) } else { ifn_586 = nil }; var arg_587 any = s__28000078__3; if linked_585 == nil { tmp5 = ifn_586.Invoke_O__O(arg_587) } else { tmp5 = linked_585.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_584, arg_587) }; arg_592 = tmp4.Invoke_O__O(tmp5); if linked_589 == nil { return ifn_590.Invoke_O_O__O(arg_591, arg_592) } else { return linked_589.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_588, arg_591, arg_592) } } else { var root_597 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_597, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_599 lang.IFn; if linked_598 == nil { ifn_599 = lang.IFn_Cast(root_597) } else { ifn_599 = nil }; var arg_600 any; var root_593 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_593, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_595 lang.IFn; if linked_594 == nil { ifn_595 = lang.IFn_Cast(root_593) } else { ifn_595 = nil }; var arg_596 any = b__28000080__6; if linked_594 == nil { arg_600 = ifn_595.Invoke_O__O(arg_596) } else { arg_600 = linked_594.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_593, arg_596) }; var arg_601 any; if linked_598 == nil { return ifn_599.Invoke_O_O__O(arg_600, arg_601) } else { return linked_598.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_597, arg_600, arg_601) } } } else { var m__4 any; var root_602 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_604 lang.IFn; if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = s__28000078__3; if linked_603 == nil { m__4 = ifn_604.Invoke_O__O(arg_605) } else { m__4 = linked_603.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_602, arg_605) }; var root_637 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_637, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_639 lang.IFn; if linked_638 == nil { ifn_639 = lang.IFn_Cast(root_637) } else { ifn_639 = nil }; var arg_640 any; var tmp6 any = A_arbace_classes_env_A_const_42; var tmp7 any = A_arbace_classes_env_A_const_60; var tmp8 any; var root_623 any = A_arbace_classes_env_A_const_78.GetRawRoot__O(); var linked_624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_623, aot_arbace_classes_types.A_arbace_classes_types_method_desc_A_fn_class); var ifn_625 lang.IFn

	if linked_624 == nil { ifn_625 = lang.IFn_Cast(root_623) } else { ifn_625 = nil }; var arg_626 any; var root_618 any = A_arbace_classes_env_A_const_79.GetRawRoot__O(); var linked_619 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_618, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_620 lang.IFn; if linked_619 == nil { ifn_620 = lang.IFn_Cast(root_618) } else { ifn_620 = nil }; var arg_621 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var arg_622 any; var G__28000086__5_ any; var root_606 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = jrt.NN(jrt.Constructor_Cast(m__4)).GetParameterTypes__Class1().Ref(); if linked_607 == nil { G__28000086__5_ = ifn_608.Invoke_O__O(arg_609) } else { G__28000086__5_ = linked_607.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_606, arg_609) }; var tmp9 any; var root_610 any = A_arbace_classes_env_A_const_75.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, A_arbace_classes_env_inner_member_QMARK__A_fn_class); var ifn_612 lang.IFn
	if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any = t.F_c; if linked_611 == nil { tmp9 = ifn_612.Invoke_O__O(arg_613) } else { tmp9 = linked_611.(*A_arbace_classes_env_inner_member_QMARK__A).Invoke_O_O__O(root_610, arg_613) }
//line :178:1
	if jrt.J2g_Truth(tmp9) { var root_614 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_614, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_616 lang.IFn; if linked_615 == nil { ifn_616 = lang.IFn_Cast(root_614) } else { ifn_616 = nil }; var arg_617 any = G__28000086__5_; if linked_615 == nil { arg_622 = ifn_616.Invoke_O__O(arg_617) } else { arg_622 = linked_615.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_614, arg_617) } } else { arg_622 = G__28000086__5_ }; if linked_619 == nil { arg_626 = ifn_620.Invoke_O_O__O(arg_621, arg_622) } else { arg_626 = linked_619.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_618, arg_621, arg_622) }; var arg_627 any = Lit_52; if linked_624 == nil { tmp8 = ifn_625.Invoke_O_O__O(arg_626, arg_627) } else { tmp8 = linked_624.(*aot_arbace_classes_types.A_arbace_classes_types_method_desc_A).Invoke_O_O_O__O(root_623, arg_626, arg_627) }
//line :176:1
	var tmp10 any = tmp8; var tmp11 any = A_arbace_classes_env_A_const_43; var tmp12 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Constructor_Cast(m__4)).GetModifiers__I()).Ref(); var tmp13 any = A_arbace_classes_env_A_const_63; var tmp14 any = t.F_n; var tmp15 any = A_arbace_classes_env_A_const_80; var tmp16 any; var root_628 any = A_arbace_classes_env_A_const_47.GetRawRoot__O(); var linked_629 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_628, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_630 lang.IFn





	if linked_629 == nil { ifn_630 = lang.IFn_Cast(root_628) } else { ifn_630 = nil }; var arg_631 any = A_arbace_classes_env_A_const_34.GetRawRoot__O(); var arg_632 any = jrt.NN(jrt.Constructor_Cast(m__4)).GetExceptionTypes__Class1().Ref(); if linked_629 == nil { tmp16 = ifn_630.Invoke_O_O__O(arg_631, arg_632) } else { tmp16 = linked_629.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_628, arg_631, arg_632) }
//line :176:1
	arg_640 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, Lit_13, tmp7, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16)); var arg_641 any; var tmp17 lang.IFn = lang.IFn_Cast(t.F_iter__28000077); var tmp18 any; var root_633 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_633, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_635 lang.IFn; if linked_634 == nil { ifn_635 = lang.IFn_Cast(root_633) } else { ifn_635 = nil }; var arg_636 any = s__28000078__3; if linked_634 == nil { tmp18 = ifn_635.Invoke_O__O(arg_636) } else { tmp18 = linked_634.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_633, arg_636) }; arg_641 = tmp17.Invoke_O__O(tmp18); if linked_638 == nil { return ifn_639.Invoke_O_O__O(arg_640, arg_641) } else { return linked_638.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_637, arg_640, arg_641) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :176:1
func A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :176:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A) Ctor_O_O_O_I_O(c__c, c__n, c__b__28000080 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_c = c__c; t.F_n = c__n; t.F_b__28000080 = c__b__28000080; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :176:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A) Invoke_O__O(self any) any { { var i__28000079__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__28000079__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__28000079__1)); var root_574 any = A_arbace_classes_env_A_const_62.GetRawRoot__O(); var linked_575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_574, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_576 lang.IFn; if linked_575 == nil { ifn_576 = lang.IFn_Cast(root_574) } else { ifn_576 = nil }; var arg_577 any = t.F_b__28000080; var arg_578 any; var tmp2 any = A_arbace_classes_env_A_const_42; var tmp3 any = A_arbace_classes_env_A_const_60; var tmp4 any; var root_564 any = A_arbace_classes_env_A_const_78.GetRawRoot__O(); var linked_565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_564, aot_arbace_classes_types.A_arbace_classes_types_method_desc_A_fn_class); var ifn_566 lang.IFn

	if linked_565 == nil { ifn_566 = lang.IFn_Cast(root_564) } else { ifn_566 = nil }; var arg_567 any; var root_559 any = A_arbace_classes_env_A_const_79.GetRawRoot__O(); var linked_560 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_559, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_561 lang.IFn; if linked_560 == nil { ifn_561 = lang.IFn_Cast(root_559) } else { ifn_561 = nil }; var arg_562 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var arg_563 any; var G__28000084__3_ any; var root_547 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_547, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_549 lang.IFn; if linked_548 == nil { ifn_549 = lang.IFn_Cast(root_547) } else { ifn_549 = nil }; var arg_550 any = jrt.NN(jrt.Constructor_Cast(m__2)).GetParameterTypes__Class1().Ref(); if linked_548 == nil { G__28000084__3_ = ifn_549.Invoke_O__O(arg_550) } else { G__28000084__3_ = linked_548.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_547, arg_550) }; var tmp5 any; var root_551 any = A_arbace_classes_env_A_const_75.GetRawRoot__O(); var linked_552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_551, A_arbace_classes_env_inner_member_QMARK__A_fn_class); var ifn_553 lang.IFn
	if linked_552 == nil { ifn_553 = lang.IFn_Cast(root_551) } else { ifn_553 = nil }; var arg_554 any = t.F_c; if linked_552 == nil { tmp5 = ifn_553.Invoke_O__O(arg_554) } else { tmp5 = linked_552.(*A_arbace_classes_env_inner_member_QMARK__A).Invoke_O_O__O(root_551, arg_554) }
//line :178:1
	if jrt.J2g_Truth(tmp5) { var root_555 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_555, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_557 lang.IFn; if linked_556 == nil { ifn_557 = lang.IFn_Cast(root_555) } else { ifn_557 = nil }; var arg_558 any = G__28000084__3_; if linked_556 == nil { arg_563 = ifn_557.Invoke_O__O(arg_558) } else { arg_563 = linked_556.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_555, arg_558) } } else { arg_563 = G__28000084__3_ }; if linked_560 == nil { arg_567 = ifn_561.Invoke_O_O__O(arg_562, arg_563) } else { arg_567 = linked_560.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_559, arg_562, arg_563) }; var arg_568 any = Lit_52; if linked_565 == nil { tmp4 = ifn_566.Invoke_O_O__O(arg_567, arg_568) } else { tmp4 = linked_565.(*aot_arbace_classes_types.A_arbace_classes_types_method_desc_A).Invoke_O_O_O__O(root_564, arg_567, arg_568) }
//line :176:1
	var tmp6 any = tmp4; var tmp7 any = A_arbace_classes_env_A_const_43; var tmp8 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Constructor_Cast(m__2)).GetModifiers__I()).Ref(); var tmp9 any = A_arbace_classes_env_A_const_63; var tmp10 any = t.F_n; var tmp11 any = A_arbace_classes_env_A_const_80; var tmp12 any; var root_569 any = A_arbace_classes_env_A_const_47.GetRawRoot__O(); var linked_570 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_569, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_571 lang.IFn





	if linked_570 == nil { ifn_571 = lang.IFn_Cast(root_569) } else { ifn_571 = nil }; var arg_572 any = A_arbace_classes_env_A_const_34.GetRawRoot__O(); var arg_573 any = jrt.NN(jrt.Constructor_Cast(m__2)).GetExceptionTypes__Class1().Ref(); if linked_570 == nil { tmp12 = ifn_571.Invoke_O_O__O(arg_572, arg_573) } else { tmp12 = linked_570.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_569, arg_572, arg_573) }
//line :176:1
	arg_578 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, Lit_13, tmp3, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12)); if linked_575 == nil { ifn_576.Invoke_O_O__O(arg_577, arg_578) } else { linked_575.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_574, arg_577, arg_578) }; i__28000079__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000079__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }










func A_arbace_classes_env_reflect_info_fn__28000089_A_New() *A_arbace_classes_env_reflect_info_fn__28000089_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_fn__28000089_A{}; t.Ctor(); return t }
//line :187:1
func (t *A_arbace_classes_env_reflect_info_fn__28000089_A) Ctor() {}
//line :187:1
func (t *A_arbace_classes_env_reflect_info_fn__28000089_A) Invoke_O_O__O(self, p1__28000026_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_13, A_arbace_classes_env_A_const_42.Invoke_O__O(p1__28000026_SHARP___1))).Ref() }
func A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_New_O(p0 any) *A_arbace_classes_env_reflect_info_iter__28000091__28000095_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000091__28000095_A{}; t.Ctor_O(p0); return t }
//line :188:1
func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :188:1
func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_A) Invoke_O_O__O(self, s__28000092__1 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_New_O_O_O(t.F_n, s__28000092__1, self); var tmp2 *jrt.Class; var fncls__724 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_fn_class; if fncls__724 == nil { var fncls__724d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_fn_class = fncls__724d; tmp2 = fncls__724d } else { tmp2 = fncls__724 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :188:1
func A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :188:1
func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A) Ctor_O_O_O(c__n, c__s__28000092, c__iter__28000091 any) { t.F_n = c__n; t.F_s__28000092 = c__s__28000092; t.F_iter__28000091 = c__iter__28000091 }
//line :188:1
func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A) Invoke_O__O(self any) any { { var s__28000092__1 any; var t_ any = t.F_s__28000092; t.F_s__28000092 = nil; s__28000092__1 = t_; for { var temp__1927000414__auto____2 any; var root_667 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_667, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_669 lang.IFn; if linked_668 == nil { ifn_669 = lang.IFn_Cast(root_667) } else { ifn_669 = nil }; var arg_670 any = s__28000092__1; if linked_668 == nil { temp__1927000414__auto____2 = ifn_669.Invoke_O__O(arg_670) } else { temp__1927000414__auto____2 = linked_668.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_667, arg_670) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__28000092__3 any = temp__1927000414__auto____2; var tmp1 any; var root_671 any = A_arbace_classes_env_A_const_54.GetRawRoot__O(); var linked_672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_671, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_673 lang.IFn; if linked_672 == nil { ifn_673 = lang.IFn_Cast(root_671) } else { ifn_673 = nil }; var arg_674 any = s__28000092__3; if linked_672 == nil { tmp1 = ifn_673.Invoke_O__O(arg_674) } else { tmp1 = linked_672.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_671, arg_674) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_675 any = A_arbace_classes_env_A_const_55.GetRawRoot__O(); var linked_676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_675, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_677 lang.IFn; if linked_676 == nil { ifn_677 = lang.IFn_Cast(root_675) } else { ifn_677 = nil }; var arg_678 any = s__28000092__3; if linked_676 == nil { c__1927001037__auto____4 = ifn_677.Invoke_O__O(arg_678) } else { c__1927001037__auto____4 = linked_676.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_675, arg_678) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__28000094__6 any; var root_679 any = A_arbace_classes_env_A_const_56.GetRawRoot__O(); var linked_680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_679, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_681 lang.IFn; if linked_680 == nil { ifn_681 = lang.IFn_Cast(root_679) } else { ifn_681 = nil }; var arg_682 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_680 == nil { b__28000094__6 = ifn_681.Invoke_O__O(arg_682) } else { b__28000094__6 = linked_680.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_679, arg_682) }; var tmp2 any = A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_New_O_I_O_O(t.F_n, size__1927001038__auto____5, b__28000094__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__688 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_fn_class; if fncls__688 == nil { var fncls__688d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_fn_class = fncls__688d; tmp3 = fncls__688d } else { tmp3 = fncls__688 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_697 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_697, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_699 lang.IFn; if linked_698 == nil { ifn_699 = lang.IFn_Cast(root_697) } else { ifn_699 = nil }; var arg_700 any; var root_689 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_689, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_691 lang.IFn; if linked_690 == nil { ifn_691 = lang.IFn_Cast(root_689) } else { ifn_691 = nil }; var arg_692 any = b__28000094__6; if linked_690 == nil { arg_700 = ifn_691.Invoke_O__O(arg_692) } else { arg_700 = linked_690.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_689, arg_692) }; var arg_701 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__28000091); var tmp5 any; var root_693 any = A_arbace_classes_env_A_const_70.GetRawRoot__O(); var linked_694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_693, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_695 lang.IFn; if linked_694 == nil { ifn_695 = lang.IFn_Cast(root_693) } else { ifn_695 = nil }; var arg_696 any = s__28000092__3; if linked_694 == nil { tmp5 = ifn_695.Invoke_O__O(arg_696) } else { tmp5 = linked_694.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_693, arg_696) }; arg_701 = tmp4.Invoke_O__O(tmp5); if linked_698 == nil { return ifn_699.Invoke_O_O__O(arg_700, arg_701) } else { return linked_698.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_697, arg_700, arg_701) } } else { var root_706 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_707 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_706, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_708 lang.IFn; if linked_707 == nil { ifn_708 = lang.IFn_Cast(root_706) } else { ifn_708 = nil }; var arg_709 any; var root_702 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_702, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_704 lang.IFn; if linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any = b__28000094__6; if linked_703 == nil { arg_709 = ifn_704.Invoke_O__O(arg_705) } else { arg_709 = linked_703.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_702, arg_705) }; var arg_710 any; if linked_707 == nil { return ifn_708.Invoke_O_O__O(arg_709, arg_710) } else { return linked_707.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_706, arg_709, arg_710) } } } else { var vec__28000102__4 any; var root_711 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_711, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_713 lang.IFn; if linked_712 == nil { ifn_713 = lang.IFn_Cast(root_711) } else { ifn_713 = nil }; var arg_714 any = s__28000092__3; if linked_712 == nil { vec__28000102__4 = ifn_713.Invoke_O__O(arg_714) } else { vec__28000102__4 = linked_712.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_711, arg_714) }; var d__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__28000102__4, lang.RT_IntCast_J__I_NoInit(0), nil); var f__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__28000102__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_719 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_719, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_721 lang.IFn; if linked_720 == nil { ifn_721 = lang.IFn_Cast(root_719) } else { ifn_721 = nil }; var arg_722 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_env_A_const_42, Lit_13, A_arbace_classes_env_A_const_60, d__5, A_arbace_classes_env_A_const_43, f__6, A_arbace_classes_env_A_const_63, t.F_n, A_arbace_classes_env_A_const_80, lang.PersistentVector_EMPTY.Ref())); var arg_723 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__28000091); var tmp7 any; var root_715 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_715, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_717 lang.IFn; if linked_716 == nil { ifn_717 = lang.IFn_Cast(root_715) } else { ifn_717 = nil }; var arg_718 any = s__28000092__3; if linked_716 == nil { tmp7 = ifn_717.Invoke_O__O(arg_718) } else { tmp7 = linked_716.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_715, arg_718) }; arg_723 = tmp6.Invoke_O__O(tmp7); if linked_720 == nil { return ifn_721.Invoke_O_O__O(arg_722, arg_723) } else { return linked_720.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_719, arg_722, arg_723) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :188:1
func A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :188:1
func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A) Ctor_O_I_O_O(c__n any, c__size__1927001038__auto__ int32, c__b__28000094, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__28000094 = c__b__28000094; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :188:1
func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A) Invoke_O__O(self any) any { { var i__28000093__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__28000093__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__28000098__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__28000093__1)); var d__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__28000098__2, lang.RT_IntCast_J__I_NoInit(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__28000098__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_683 any = A_arbace_classes_env_A_const_62.GetRawRoot__O(); var linked_684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_683, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_685 lang.IFn; if linked_684 == nil { ifn_685 = lang.IFn_Cast(root_683) } else { ifn_685 = nil }; var arg_686 any = t.F_b__28000094; var arg_687 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_env_A_const_42, Lit_13, A_arbace_classes_env_A_const_60, d__3, A_arbace_classes_env_A_const_43, f__4, A_arbace_classes_env_A_const_63, t.F_n, A_arbace_classes_env_A_const_80, lang.PersistentVector_EMPTY.Ref())); if linked_684 == nil { ifn_685.Invoke_O_O__O(arg_686, arg_687) } else { linked_684.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_683, arg_686, arg_687) }; i__28000093__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000093__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_classes_env_info_A_New() *A_arbace_classes_env_info_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_info_A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_classes_env_info_A) Ctor() {}
//line :197:1
func (t *A_arbace_classes_env_info_A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any = n__0; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_742 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_742, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_744 lang.IFn; if linked_743 == nil { ifn_744 = lang.IFn_Cast(root_742) } else { ifn_744 = nil }; var arg_745 any; var root_737 any = A_arbace_classes_env_A_const_20.GetRawRoot__O(); var linked_738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_737, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_739 lang.IFn; if linked_738 == nil { ifn_739 = lang.IFn_Cast(root_737) } else { ifn_739 = nil }; var arg_740 any = n__0; var arg_741 any = Lit_11; if linked_738 == nil { arg_745 = ifn_739.Invoke_O_O__O(arg_740, arg_741) } else { arg_745 = linked_738.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_737, arg_740, arg_741) }; if linked_743 == nil { tmp1 = ifn_744.Invoke_O__O(arg_745) } else { tmp1 = linked_743.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_742, arg_745) } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var or__1927000174__auto____2 any; var G__28000108__2_ any = A_arbace_classes_env_A_const_89.Get__O(); var G__28000108__3_ any
		if lang.Util_Identical_O_O__Z_NoInit(G__28000108__2_, nil) { G__28000108__3_ = nil } else { var root_746 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_746, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_748 lang.IFn; if linked_747 == nil { ifn_748 = lang.IFn_Cast(root_746) } else { ifn_748 = nil }; var arg_749 any = G__28000108__2_; if linked_747 == nil { G__28000108__3_ = ifn_748.Invoke_O__O(arg_749) } else { G__28000108__3_ = linked_747.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_746, arg_749) } }; if lang.Util_Identical_O_O__Z_NoInit(G__28000108__3_, nil) { or__1927000174__auto____2 = nil } else { or__1927000174__auto____2 = lang.RT_Get_O_O__O_NoInit(G__28000108__3_, n__0) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else {
			if jrt.J2g_Truth(A_arbace_classes_env_A_const_19.Get__O()) {
				var tmp2 any; var root_750 any = A_arbace_classes_env_A_const_18.GetRawRoot__O(); var linked_751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_750, A_arbace_classes_env_from_source_QMARK__A_fn_class); var ifn_752 lang.IFn; if linked_751 == nil { ifn_752 = lang.IFn_Cast(root_750) } else { ifn_752 = nil }; var arg_753 any = n__0; if linked_751 == nil { tmp2 = ifn_752.Invoke_O__O(arg_753) } else { tmp2 = linked_751.(*A_arbace_classes_env_from_source_QMARK__A).Invoke_O_O__O(root_750, arg_753) }; if jrt.J2g_Truth(tmp2) { return nil } else { var tmp3 *lang.Keyword = A_arbace_classes_env_A_const_90; return tmp3.Invoke_O__O(lang.RT_Get_O_O__O_NoInit(A_arbace_classes_env_A_const_19.Get__O(), n__0)) } } else {
//line :202:1
					var temp__1927000414__auto____3 any; var root_754 any = A_arbace_classes_env_A_const_25.GetRawRoot__O(); var linked_755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_754, A_arbace_classes_env_load_class_A_fn_class); var ifn_756 lang.IFn

					if linked_755 == nil { ifn_756 = lang.IFn_Cast(root_754) } else { ifn_756 = nil }; var arg_757 any = n__0; if linked_755 == nil { temp__1927000414__auto____3 = ifn_756.Invoke_O__O(arg_757) } else { temp__1927000414__auto____3 = linked_755.(*A_arbace_classes_env_load_class_A).Invoke_O_O__O(root_754, arg_757) }; if jrt.J2g_Truth(temp__1927000414__auto____3) { var c__4 any = temp__1927000414__auto____3; var d__5 any; var tmp4 any; var root_758 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_758, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_760 lang.IFn
						if linked_759 == nil { ifn_760 = lang.IFn_Cast(root_758) } else { ifn_760 = nil }; var arg_761 any = A_arbace_classes_env_A_const_91.GetRawRoot__O(); if linked_759 == nil { tmp4 = ifn_760.Invoke_O__O(arg_761) } else { tmp4 = linked_759.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_758, arg_761) }; d__5 = lang.RT_Get_O_O__O_NoInit(tmp4, n__0)
						var tmp5 any; var and__1927000168__auto____6 any = d__5; if jrt.J2g_Truth(and__1927000168__auto____6) { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(A_arbace_classes_env_A_const_31.Invoke_O__O(d__5), c__4)).Ref() } else { tmp5 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp5) { return d__5 } else { var root_762 any = A_arbace_classes_env_A_const_92.GetRawRoot__O(); var linked_763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_762, A_arbace_classes_env_reflect_info_A_fn_class); var ifn_764 lang.IFn; if linked_763 == nil { ifn_764 = lang.IFn_Cast(root_762) } else { ifn_764 = nil }; var arg_765 any = c__4; if linked_763 == nil { return ifn_764.Invoke_O__O(arg_765) } else { return linked_763.(*A_arbace_classes_env_reflect_info_A).Invoke_O_O__O(root_762, arg_765) } } } else {
//line :204:1
							return nil } } } } else {
//line :200:1
								return nil
							}
}





func A_arbace_classes_env_info_BANG__A_New() *A_arbace_classes_env_info_BANG__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_info_BANG__A{}; t.Ctor(); return t }
//line :208:1
func (t *A_arbace_classes_env_info_BANG__A) Ctor() {}
//line :208:1
func (t *A_arbace_classes_env_info_BANG__A) Invoke_O_O__O(self, n__0 any) any { var or__1927000174__auto____2 any; var root_766 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_766, A_arbace_classes_env_info_A_fn_class); var ifn_768 lang.IFn; if
										linked_767 == nil { ifn_768 = lang.IFn_Cast(root_766) } else { ifn_768 = nil }; var arg_769 any = n__0; if linked_767 == nil { or__1927000174__auto____2 = ifn_768.Invoke_O__O(arg_769) } else { or__1927000174__auto____2 = linked_767.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_766, arg_769) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var tmp1 any; var root_780 any = A_arbace_classes_env_A_const_28.GetRawRoot__O(); var linked_781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_780, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_782 lang.IFn; if linked_781 == nil { ifn_782 = lang.IFn_Cast(root_780) } else { ifn_782 = nil }; var arg_783 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_20, nil); var tmp3 any; var root_774 any = A_arbace_classes_env_A_const_12.GetRawRoot__O(); var linked_775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_774, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_776 lang.IFn; if linked_775 == nil { ifn_776 = lang.IFn_Cast(root_774) } else { ifn_776 = nil }; var arg_777 any; var root_770 any = A_arbace_classes_env_A_const_30.GetRawRoot__O(); var linked_771 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_770, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_772 lang.IFn; if linked_771 == nil { ifn_772 = lang.IFn_Cast(root_770) } else { ifn_772 = nil }; var arg_773 any = n__0; if linked_771 == nil { arg_777 = ifn_772.Invoke_O__O(arg_773) } else { arg_777 = linked_771.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_770, arg_773) }; var arg_778 any = Lit_21; var arg_779 any = Lit_22; if linked_775 == nil { tmp3 = ifn_776.Invoke_O_O_O__O(arg_777, arg_778, arg_779) } else { tmp3 = linked_775.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_774, arg_777, arg_778, arg_779) }; arg_783 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref(); var arg_784 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_env_A_const_31, n__0)); if linked_781 == nil { tmp1 = ifn_782.Invoke_O_O__O(arg_783, arg_784) } else { tmp1 = linked_781.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_780, arg_783, arg_784) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) } }

func A_arbace_classes_env_interface_QMARK__A_New() *A_arbace_classes_env_interface_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_interface_QMARK__A{}; t.Ctor(); return t }
//line :211:1
func (t *A_arbace_classes_env_interface_QMARK__A) Ctor() {}
//line :211:1
func (t *A_arbace_classes_env_interface_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var i__2 any; var root_785 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_785, A_arbace_classes_env_info_A_fn_class); var ifn_787 lang.IFn; if
											linked_786 == nil { ifn_787 = lang.IFn_Cast(root_785) } else { ifn_787 = nil }; var arg_788 any = n__0; if linked_786 == nil { i__2 = ifn_787.Invoke_O__O(arg_788) } else { i__2 = linked_786.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_785, arg_788) }; var tmp1 any; var or__1927000174__auto____3 any = A_arbace_classes_env_A_const_44.Invoke_O__O(i__2); if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var G__28000111__4_ any = A_arbace_classes_env_A_const_43.Invoke_O__O(i__2); var G__28000111__5_ any; if lang.Util_Identical_O_O__Z_NoInit(G__28000111__4_, nil) { G__28000111__5_ = nil } else { var tmp2 int64; var na_789 any = G__28000111__4_; var na_790 int64 = 512; if jrt.Long_InstanceOf(na_789) { var n0_791 int64 = jrt.NN(jrt.Long_Cast(na_789)).LongValue__J(); var n1_792 int64 = na_790; tmp2 = n0_791 & n1_792 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_789, na_790) }; G__28000111__5_ = jrt.Long_ValueOf_J__Long_NoInit(tmp2).Ref() }; if lang.Util_Identical_O_O__Z_NoInit(G__28000111__5_, nil) { tmp1 = nil } else { var tmp3 bool; var na_794 any = G__28000111__5_; if jrt.Long_InstanceOf(na_794) { var n0_795 int64 = jrt.NN(jrt.Long_Cast(na_794)).LongValue__J(); tmp3 = n0_795 > 0 } else { if jrt.Double_InstanceOf(na_794) { var n0_795_2 float64 = jrt.NN(jrt.Double_Cast(na_794)).DoubleValue__D(); tmp3 = n0_795_2 > 0.0 } else { tmp3 = lang.Numbers_IsPos_O__Z_NoInit(na_794) } }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp3).Ref() } }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() }

func A_arbace_classes_env_const_value_A_New() *A_arbace_classes_env_const_value_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_const_value_A{}; t.Ctor(); return t }
//line :214:1
func (t *A_arbace_classes_env_const_value_A) Ctor() {}
//line :214:1
func (t *A_arbace_classes_env_const_value_A) Invoke_O_O__O(self, field__0 any) any { var c__2 any = A_arbace_classes_env_A_const_64.Invoke_O__O(field__0); var tmp1 any; var root_796 any = A_arbace_classes_env_A_const_94.GetRawRoot__O(); var linked_797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_796, aot_arbace_core.A_arbace_core_delay_QMARK__A_fn_class); var ifn_798 lang.IFn; if
											linked_797 == nil { ifn_798 = lang.IFn_Cast(root_796) } else { ifn_798 = nil }; var arg_799 any = c__2; if linked_797 == nil { tmp1 = ifn_798.Invoke_O__O(arg_799) } else { tmp1 = linked_797.(*aot_arbace_core.A_arbace_core_delay_QMARK__A).Invoke_O_O__O(root_796, arg_799) }; if jrt.J2g_Truth(tmp1) { var root_800 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_800, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_802 lang.IFn; if linked_801 == nil { ifn_802 = lang.IFn_Cast(root_800) } else { ifn_802 = nil }; var arg_803 any = c__2; if linked_801 == nil { return ifn_802.Invoke_O__O(arg_803) } else { return linked_801.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_800, arg_803) } } else { return c__2 } }

func A_arbace_classes_env_supertypes_A_New() *A_arbace_classes_env_supertypes_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_supertypes_A{}; t.Ctor(); return t }
//line :217:1
func (t *A_arbace_classes_env_supertypes_A) Ctor() {}
//line :217:1
func (t *A_arbace_classes_env_supertypes_A) Invoke_O_O__O(self, n__0 any) any { var i__2 any; var root_804 any = A_arbace_classes_env_A_const_95.GetRawRoot__O(); var linked_805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_804, A_arbace_classes_env_info_BANG__A_fn_class); var ifn_806 lang.IFn; if


	linked_805 == nil { ifn_806 = lang.IFn_Cast(root_804) } else { ifn_806 = nil }; var arg_807 any = n__0; if linked_805 == nil { i__2 = ifn_806.Invoke_O__O(arg_807) } else { i__2 = linked_805.(*A_arbace_classes_env_info_BANG__A).Invoke_O_O__O(root_804, arg_807) }; var G__28000114__3_ any; var root_808 any = /*line :217:1*/A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_809 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_808, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_810 lang.IFn; if


	linked_809 == nil { ifn_810 = lang.IFn_Cast(root_808) } else { ifn_810 = nil }; var arg_811 any = A_arbace_classes_env_A_const_46.Invoke_O__O(i__2); if linked_809 == nil { G__28000114__3_ = ifn_810.Invoke_O__O(arg_811) } else { G__28000114__3_ = linked_809.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_808, arg_811) }; if jrt.J2g_Truth(A_arbace_classes_env_A_const_45.Invoke_O__O(i__2)) { var root_817 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_817, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_819 lang.IFn; if linked_818 == nil { ifn_819 = lang.IFn_Cast(root_817) } else { ifn_819 = nil }; var arg_820 any; var root_812 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_812, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_814 lang.IFn; if linked_813 == nil { ifn_814 = lang.IFn_Cast(root_812) } else { ifn_814 = nil }; var arg_815 any = A_arbace_classes_env_A_const_45.Invoke_O__O(i__2); var arg_816 any = G__28000114__3_; if linked_813 == nil { arg_820 = ifn_814.Invoke_O_O__O(arg_815, arg_816) } else { arg_820 = linked_813.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_812, arg_815, arg_816) }; if linked_818 == nil { return ifn_819.Invoke_O__O(arg_820) } else { return linked_818.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_817, arg_820) } } else { return G__28000114__3_ } }

func A_arbace_classes_env_subclass_QMARK__A_New() *A_arbace_classes_env_subclass_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_subclass_QMARK__A{}; t.Ctor(); return t }
//line :222:1
func (t *A_arbace_classes_env_subclass_QMARK__A) Ctor() {}
//line :222:1
func (t *A_arbace_classes_env_subclass_QMARK__A) Invoke_O_O_O__O(self, a__0, b__1 any) any { var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(a__0, b__1); if or__1927000174__auto____3 {


	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var or__1927000174__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(b__1, Lit_4); if or__1927000174__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____4).Ref() } else {
		var tmp1 any; var root_840 any = A_arbace_classes_env_A_const_96.GetRawRoot__O(); var linked_841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_840, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_842 lang.IFn; if linked_841 == nil { ifn_842 = lang.IFn_Cast(root_840) } else { ifn_842 = nil }; var arg_843 any; var tmp2 any = A_arbace_classes_env_subclass_QMARK__fn__28000117_A_New_O(b__1); var tmp3 *jrt.Class; var fncls__826 *jrt.Class = A_arbace_classes_env_subclass_QMARK__fn__28000117_A_fn_class; if fncls__826 == nil { var fncls__826d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); A_arbace_classes_env_subclass_QMARK__fn__28000117_A_fn_class = fncls__826d; tmp3 = fncls__826d } else { tmp3 = fncls__826 }; arg_843 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_844 any; var temp__1927000414__auto____5 any; var root_827 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_827, A_arbace_classes_env_info_A_fn_class); var ifn_829 lang.IFn; if linked_828 == nil { ifn_829 = lang.IFn_Cast(root_827) } else { ifn_829 = nil }; var arg_830 any = a__0; if linked_828 == nil { temp__1927000414__auto____5 = ifn_829.Invoke_O__O(arg_830) } else { temp__1927000414__auto____5 = linked_828.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_827, arg_830) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var i__6 any = temp__1927000414__auto____5; var G__28000119__7_ any; var root_831 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_831, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_833 lang.IFn
			if linked_832 == nil { ifn_833 = lang.IFn_Cast(root_831) } else { ifn_833 = nil }; var arg_834 any = A_arbace_classes_env_A_const_46.Invoke_O__O(i__6); if linked_832 == nil { G__28000119__7_ = ifn_833.Invoke_O__O(arg_834) } else { G__28000119__7_ = linked_832.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_831, arg_834) }; if jrt.J2g_Truth(A_arbace_classes_env_A_const_45.Invoke_O__O(i__6)) { var root_835 any = A_arbace_classes_env_A_const_10.GetRawRoot__O(); var linked_836 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_835, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_837 lang.IFn; if linked_836 == nil { ifn_837 = lang.IFn_Cast(root_835) } else { ifn_837 = nil }; var arg_838 any = G__28000119__7_; var arg_839 any = A_arbace_classes_env_A_const_45.Invoke_O__O(i__6); if linked_836 == nil { arg_844 = ifn_837.Invoke_O_O__O(arg_838, arg_839) } else { arg_844 = linked_836.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_835, arg_838, arg_839) } } else { arg_844 = G__28000119__7_ } } else {
//line :226:1
				arg_844 = nil }; if linked_841 == nil { tmp1 = ifn_842.Invoke_O_O__O(arg_843, arg_844) } else { tmp1 = linked_841.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_840, arg_843, arg_844) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() } } }
//line :226:1
func A_arbace_classes_env_subclass_QMARK__fn__28000117_A_New_O(p0 any) *A_arbace_classes_env_subclass_QMARK__fn__28000117_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_subclass_QMARK__fn__28000117_A{}; t.Ctor_O(p0); return t }
//line :226:1
func (t *A_arbace_classes_env_subclass_QMARK__fn__28000117_A) Ctor_O(c__b any) { t.F_b = c__b }
//line :226:1
func (t *A_arbace_classes_env_subclass_QMARK__fn__28000117_A) Invoke_O_O__O(self, p1__28000116_SHARP___1 any) any { var root_821 any = A_arbace_classes_env_A_const_97.GetRawRoot__O(); var linked_822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_821, A_arbace_classes_env_subclass_QMARK__A_fn_class); var ifn_823 lang.IFn; if linked_822 == nil { ifn_823 = lang.IFn_Cast(root_821) } else { ifn_823 = nil }; var arg_824 any = p1__28000116_SHARP___1; var arg_825 any = t.F_b; if linked_822 == nil { return ifn_823.Invoke_O_O__O(arg_824, arg_825) } else { return linked_822.(*A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(root_821, arg_824, arg_825) } }


func A_arbace_classes_env_assignable_QMARK__A_New() *A_arbace_classes_env_assignable_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_assignable_QMARK__A{}; t.Ctor(); return t }
//line :229:1
func (t *A_arbace_classes_env_assignable_QMARK__A) Ctor() {}
//line :229:1
func (t *A_arbace_classes_env_assignable_QMARK__A) Invoke_O_O_O__O(self, from__0, to__1 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(from__0, to__1) { return jrt.Boolean_TRUE.Ref() } else { if lang.Util_Equiv_O_O__Z_NoInit(from__0, A_arbace_classes_env_A_const_98) {

		var root_845 any = A_arbace_classes_env_A_const_99.GetRawRoot__O(); var linked_846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_845, aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A_fn_class); var ifn_847 lang.IFn; if linked_846 == nil { ifn_847 = lang.IFn_Cast(root_845) } else { ifn_847 = nil }; var arg_848 any = to__1; if linked_846 == nil { return ifn_847.Invoke_O__O(arg_848) } else { return linked_846.(*aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A).Invoke_O_O__O(root_845, arg_848) } } else {
//line :232:1
			var tmp1 any; var root_857 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_857, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_859 lang.IFn


			if linked_858 == nil { ifn_859 = lang.IFn_Cast(root_857) } else { ifn_859 = nil }; var arg_860 any; var and__1927000168__auto____3 any; var root_849 any = A_arbace_classes_env_A_const_99.GetRawRoot__O(); var linked_850 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_849, aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A_fn_class); var ifn_851 lang.IFn; if linked_850 == nil { ifn_851 = lang.IFn_Cast(root_849) } else { ifn_851 = nil }; var arg_852 any = from__0; if linked_850 == nil { and__1927000168__auto____3 = ifn_851.Invoke_O__O(arg_852) } else { and__1927000168__auto____3 = linked_850.(*aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A).Invoke_O_O__O(root_849, arg_852) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_853 any = A_arbace_classes_env_A_const_99.GetRawRoot__O(); var linked_854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_853, aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A_fn_class); var ifn_855 lang.IFn; if linked_854 == nil { ifn_855 = lang.IFn_Cast(root_853) } else { ifn_855 = nil }; var arg_856 any = to__1; if linked_854 == nil { arg_860 = ifn_855.Invoke_O__O(arg_856) } else { arg_860 = linked_854.(*aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A).Invoke_O_O__O(root_853, arg_856) } } else { arg_860 = and__1927000168__auto____3 }; if linked_858 == nil { tmp1 = ifn_859.Invoke_O__O(arg_860) } else { tmp1 = linked_858.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_857, arg_860) }
//line :232:1
			if jrt.J2g_Truth(tmp1) { return jrt.Boolean_FALSE.Ref() } else { if lang.Util_Equiv_O_O__Z_NoInit(to__1, A_arbace_classes_env_A_const_100.GetRawRoot__O()) { return jrt.Boolean_TRUE.Ref() } else { var tmp2 any; var root_861 any = A_arbace_classes_env_A_const_101.GetRawRoot__O(); var linked_862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_861, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_863 lang.IFn




				if linked_862 == nil { ifn_863 = lang.IFn_Cast(root_861) } else { ifn_863 = nil }; var arg_864 any = from__0; if linked_862 == nil { tmp2 = ifn_863.Invoke_O__O(arg_864) } else { tmp2 = linked_862.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_861, arg_864) }
//line :232:1
				if jrt.J2g_Truth(tmp2) {





					var tmp3 any; var root_865 any = A_arbace_classes_env_A_const_101.GetRawRoot__O(); var linked_866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_865, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_867 lang.IFn; if linked_866 == nil { ifn_867 = lang.IFn_Cast(root_865) } else { ifn_867 = nil }; var arg_868 any = to__1; if linked_866 == nil { tmp3 = ifn_867.Invoke_O__O(arg_868) } else { tmp3 = linked_866.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_865, arg_868) }; if jrt.J2g_Truth(tmp3) { var fe__3 any; var root_869 any = A_arbace_classes_env_A_const_102.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_869, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_871 lang.IFn; if linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any = from__0; if linked_870 == nil { fe__3 = ifn_871.Invoke_O__O(arg_872) } else { fe__3 = linked_870.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_869, arg_872) }; var te__4 any; var root_873 any = A_arbace_classes_env_A_const_102.GetRawRoot__O(); var linked_874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_873, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_875 lang.IFn; if linked_874 == nil { ifn_875 = lang.IFn_Cast(root_873) } else { ifn_875 = nil }; var arg_876 any = to__1; if linked_874 == nil { te__4 = ifn_875.Invoke_O__O(arg_876) } else { te__4 = linked_874.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_873, arg_876) }; var and__1927000168__auto____5 any; var root_877 any = A_arbace_classes_env_A_const_99.GetRawRoot__O(); var linked_878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_877, aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A_fn_class); var ifn_879 lang.IFn
						if linked_878 == nil { ifn_879 = lang.IFn_Cast(root_877) } else { ifn_879 = nil }; var arg_880 any = fe__3; if linked_878 == nil { and__1927000168__auto____5 = ifn_879.Invoke_O__O(arg_880) } else { and__1927000168__auto____5 = linked_878.(*aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A).Invoke_O_O__O(root_877, arg_880) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_881 any = A_arbace_classes_env_A_const_99.GetRawRoot__O(); var linked_882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_881, aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A_fn_class); var ifn_883 lang.IFn; if linked_882 == nil { ifn_883 = lang.IFn_Cast(root_881) } else { ifn_883 = nil }; var arg_884 any = te__4; if linked_882 == nil { and__1927000168__auto____6 = ifn_883.Invoke_O__O(arg_884) } else { and__1927000168__auto____6 = linked_882.(*aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A).Invoke_O_O__O(root_881, arg_884) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_885 any = A_arbace_classes_env_A_const_103.GetRawRoot__O(); var linked_886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_885, A_arbace_classes_env_assignable_QMARK__A_fn_class); var ifn_887 lang.IFn; if linked_886 == nil { ifn_887 = lang.IFn_Cast(root_885) } else { ifn_887 = nil }; var arg_888 any = fe__3; var arg_889 any = te__4; if linked_886 == nil { return ifn_887.Invoke_O_O__O(arg_888, arg_889) } else { return linked_886.(*A_arbace_classes_env_assignable_QMARK__A).Invoke_O_O_O__O(root_885, arg_888, arg_889) } } else { return and__1927000168__auto____6 } } else { return and__1927000168__auto____5 } } else {
//line :238:1
							if A_arbace_classes_env_A_const_104 != nil {

								var root_890 any = A_arbace_classes_env_A_const_23.GetRawRoot__O(); var linked_891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_890, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_892 lang.IFn; if linked_891 == nil { ifn_892 = lang.IFn_Cast(root_890) } else { ifn_892 = nil }; var arg_893 any = A_arbace_classes_env_A_const_105; var arg_894 any = to__1; if linked_891 == nil { return ifn_892.Invoke_O_O__O(arg_893, arg_894) } else { return linked_891.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_890, arg_893, arg_894) } } else {
//line :238:1
									return nil } } } else {
//line :232:1
										var tmp4 any; var root_895 any = A_arbace_classes_env_A_const_101.GetRawRoot__O(); var linked_896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_895, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_897 lang.IFn








										if linked_896 == nil { ifn_897 = lang.IFn_Cast(root_895) } else { ifn_897 = nil }; var arg_898 any = to__1; if linked_896 == nil { tmp4 = ifn_897.Invoke_O__O(arg_898) } else { tmp4 = linked_896.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_895, arg_898) }
//line :232:1
										if jrt.J2g_Truth(tmp4) { return jrt.Boolean_FALSE.Ref() } else { if A_arbace_classes_env_A_const_104 != nil {









											var root_907 any = A_arbace_classes_env_A_const_97.GetRawRoot__O(); var linked_908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_907, A_arbace_classes_env_subclass_QMARK__A_fn_class); var ifn_909 lang.IFn; if linked_908 == nil { ifn_909 = lang.IFn_Cast(root_907) } else { ifn_909 = nil }; var arg_910 any; var root_899 any = A_arbace_classes_env_A_const_106.GetRawRoot__O(); var linked_900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_899, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_901 lang.IFn; if linked_900 == nil { ifn_901 = lang.IFn_Cast(root_899) } else { ifn_901 = nil }; var arg_902 any = from__0; if linked_900 == nil { arg_910 = ifn_901.Invoke_O__O(arg_902) } else { arg_910 = linked_900.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_899, arg_902) }; var arg_911 any; var root_903 any = A_arbace_classes_env_A_const_106.GetRawRoot__O(); var linked_904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_903, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_905 lang.IFn; if linked_904 == nil { ifn_905 = lang.IFn_Cast(root_903) } else { ifn_905 = nil }; var arg_906 any = to__1; if linked_904 == nil { arg_911 = ifn_905.Invoke_O__O(arg_906) } else { arg_911 = linked_904.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_903, arg_906) }; if linked_908 == nil { return ifn_909.Invoke_O_O__O(arg_910, arg_911) } else { return linked_908.(*A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(root_907, arg_910, arg_911) } } else {
//line :232:1
												return nil
											}
										}
									}
			}
			}
		}
	}
}



func A_arbace_classes_env_superclass_chain_A_New() *A_arbace_classes_env_superclass_chain_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_superclass_chain_A{}; t.Ctor(); return t }
//line :244:1
func (t *A_arbace_classes_env_superclass_chain_A) Ctor() {}
//line :244:1
func (t *A_arbace_classes_env_superclass_chain_A) Invoke_O_O__O(self, n__0 any) any {
	var root_922 any = A_arbace_classes_env_A_const_107.GetRawRoot__O(); var linked_923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_922, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_924 lang.IFn; if linked_923 == nil { ifn_924 = lang.IFn_Cast(root_922) } else { ifn_924 = nil }; var arg_925 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var arg_926 any; var root_917 any = A_arbace_classes_env_A_const_108.GetRawRoot__O(); var linked_918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_917, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_919 lang.IFn; if linked_918 == nil { ifn_919 = lang.IFn_Cast(root_917) } else { ifn_919 = nil }; var arg_920 any; var tmp1 any = A_arbace_classes_env_superclass_chain_fn__28000123_A_New(); var tmp2 *jrt.Class; var fncls__916 *jrt.Class = A_arbace_classes_env_superclass_chain_fn__28000123_A_fn_class; if fncls__916 == nil { var fncls__916d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_classes_env_superclass_chain_fn__28000123_A_fn_class = fncls__916d; tmp2 = fncls__916d } else { tmp2 = fncls__916 }; arg_920 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_921 any = n__0; if linked_918 == nil { arg_926 = ifn_919.Invoke_O_O__O(arg_920, arg_921) } else { arg_926 = linked_918.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_917, arg_920, arg_921) }; if linked_923 == nil { return ifn_924.Invoke_O_O__O(arg_925, arg_926) } else { return linked_923.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_922, arg_925, arg_926) } }
//line :245:1
func A_arbace_classes_env_superclass_chain_fn__28000123_A_New() *A_arbace_classes_env_superclass_chain_fn__28000123_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_superclass_chain_fn__28000123_A{}; t.Ctor(); return t }
//line :245:1
func (t *A_arbace_classes_env_superclass_chain_fn__28000123_A) Ctor() {}
//line :245:1
func (t *A_arbace_classes_env_superclass_chain_fn__28000123_A) Invoke_O_O__O(self, p1__28000122_SHARP___1 any) any { var G__28000124__2_ any = p1__28000122_SHARP___1; var G__28000124__3_ any; if lang.Util_Identical_O_O__Z_NoInit(G__28000124__2_, nil) { G__28000124__3_ = nil } else { var root_912 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_913 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_912, A_arbace_classes_env_info_A_fn_class); var ifn_914 lang.IFn; if linked_913 == nil { ifn_914 = lang.IFn_Cast(root_912) } else { ifn_914 = nil }; var arg_915 any = G__28000124__2_; if linked_913 == nil { G__28000124__3_ = ifn_914.Invoke_O__O(arg_915) } else { G__28000124__3_ = linked_913.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_912, arg_915) } }; if lang.Util_Identical_O_O__Z_NoInit(G__28000124__3_, nil) { return nil } else { return A_arbace_classes_env_A_const_45.Invoke_O__O(G__28000124__3_) } }

func A_arbace_classes_env_common_super_A_New() *A_arbace_classes_env_common_super_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_common_super_A{}; t.Ctor(); return t }
//line :247:1
func (t *A_arbace_classes_env_common_super_A) Ctor() {}
//line :247:1
func (t *A_arbace_classes_env_common_super_A) Invoke_O_O_O__O(self, a__0, b__1 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(a__0, b__1) { return a__0 } else { var tmp1 any; var or__1927000174__auto____3 any; var root_927 any = A_arbace_classes_env_A_const_20.GetRawRoot__O(); var linked_928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_927, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_929 lang.IFn

		if linked_928 == nil { ifn_929 = lang.IFn_Cast(root_927) } else { ifn_929 = nil }; var arg_930 any = a__0; var arg_931 any = Lit_11; if linked_928 == nil { or__1927000174__auto____3 = ifn_929.Invoke_O_O__O(arg_930, arg_931) } else { or__1927000174__auto____3 = linked_928.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_927, arg_930, arg_931) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var root_932 any = A_arbace_classes_env_A_const_20.GetRawRoot__O(); var linked_933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_932, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_934 lang.IFn; if linked_933 == nil { ifn_934 = lang.IFn_Cast(root_932) } else { ifn_934 = nil }; var arg_935 any = b__1; var arg_936 any = Lit_11; if linked_933 == nil { tmp1 = ifn_934.Invoke_O_O__O(arg_935, arg_936) } else { tmp1 = linked_933.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_932, arg_935, arg_936) } }
//line :250:1
		if jrt.J2g_Truth(tmp1) { return Lit_4 } else { var tmp2 any; var root_937 any = A_arbace_classes_env_A_const_97.GetRawRoot__O(); var linked_938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_937, A_arbace_classes_env_subclass_QMARK__A_fn_class); var ifn_939 lang.IFn


			if linked_938 == nil { ifn_939 = lang.IFn_Cast(root_937) } else { ifn_939 = nil }; var arg_940 any = a__0; var arg_941 any = b__1; if linked_938 == nil { tmp2 = ifn_939.Invoke_O_O__O(arg_940, arg_941) } else { tmp2 = linked_938.(*A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(root_937, arg_940, arg_941) }
//line :250:1
			if jrt.J2g_Truth(tmp2) {


				var tmp3 any; var root_942 any = A_arbace_classes_env_A_const_109.GetRawRoot__O(); var linked_943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_942, A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_944 lang.IFn; if linked_943 == nil { ifn_944 = lang.IFn_Cast(root_942) } else { ifn_944 = nil }; var arg_945 any = b__1; if linked_943 == nil { tmp3 = ifn_944.Invoke_O__O(arg_945) } else { tmp3 = linked_943.(*A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_942, arg_945) }; if jrt.J2g_Truth(tmp3) { return Lit_4 } else { return b__1 } } else {
//line :250:1
					var tmp4 any; var root_946 any = A_arbace_classes_env_A_const_97.GetRawRoot__O(); var linked_947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_946, A_arbace_classes_env_subclass_QMARK__A_fn_class); var ifn_948 lang.IFn



					if linked_947 == nil { ifn_948 = lang.IFn_Cast(root_946) } else { ifn_948 = nil }; var arg_949 any = b__1; var arg_950 any = a__0; if linked_947 == nil { tmp4 = ifn_948.Invoke_O_O__O(arg_949, arg_950) } else { tmp4 = linked_947.(*A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(root_946, arg_949, arg_950) }
//line :250:1
					if jrt.J2g_Truth(tmp4) {



						var tmp5 any; var root_951 any = A_arbace_classes_env_A_const_109.GetRawRoot__O(); var linked_952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_951, A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_953 lang.IFn; if linked_952 == nil { ifn_953 = lang.IFn_Cast(root_951) } else { ifn_953 = nil }; var arg_954 any = a__0; if linked_952 == nil { tmp5 = ifn_953.Invoke_O__O(arg_954) } else { tmp5 = linked_952.(*A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_951, arg_954) }; if jrt.J2g_Truth(tmp5) { return Lit_4 } else { return a__0 } } else {
//line :250:1
							var tmp6 any; var or__1927000174__auto____3_2 any; var root_955 any = A_arbace_classes_env_A_const_109.GetRawRoot__O(); var linked_956 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_955, A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_957 lang.IFn




							if linked_956 == nil { ifn_957 = lang.IFn_Cast(root_955) } else { ifn_957 = nil }; var arg_958 any = a__0; if linked_956 == nil { or__1927000174__auto____3_2 = ifn_957.Invoke_O__O(arg_958) } else { or__1927000174__auto____3_2 = linked_956.(*A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_955, arg_958) }; if jrt.J2g_Truth(or__1927000174__auto____3_2) { tmp6 = or__1927000174__auto____3_2 } else { var root_959 any = A_arbace_classes_env_A_const_109.GetRawRoot__O(); var linked_960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_959, A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_961 lang.IFn; if linked_960 == nil { ifn_961 = lang.IFn_Cast(root_959) } else { ifn_961 = nil }; var arg_962 any = b__1; if linked_960 == nil { tmp6 = ifn_961.Invoke_O__O(arg_962) } else { tmp6 = linked_960.(*A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_959, arg_962) } }
//line :250:1
							if jrt.J2g_Truth(tmp6) { return Lit_4 } else { if A_arbace_classes_env_A_const_104 != nil { var bs__3 any; var root_967 any = A_arbace_classes_env_A_const_110.GetRawRoot__O(); var linked_968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_967, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_969 lang.IFn





								if linked_968 == nil { ifn_969 = lang.IFn_Cast(root_967) } else { ifn_969 = nil }; var arg_970 any; var root_963 any = A_arbace_classes_env_A_const_111.GetRawRoot__O(); var linked_964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_963, A_arbace_classes_env_superclass_chain_A_fn_class); var ifn_965 lang.IFn; if linked_964 == nil { ifn_965 = lang.IFn_Cast(root_963) } else { ifn_965 = nil }; var arg_966 any = b__1; if linked_964 == nil { arg_970 = ifn_965.Invoke_O__O(arg_966) } else { arg_970 = linked_964.(*A_arbace_classes_env_superclass_chain_A).Invoke_O_O__O(root_963, arg_966) }; if linked_968 == nil { bs__3 = ifn_969.Invoke_O__O(arg_970) } else { bs__3 = linked_968.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_967, arg_970) }
//line :250:1
								var or__1927000174__auto____4 any; var root_980 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_980, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_982 lang.IFn






								if linked_981 == nil { ifn_982 = lang.IFn_Cast(root_980) } else { ifn_982 = nil }; var arg_983 any; var root_975 any = A_arbace_classes_env_A_const_86.GetRawRoot__O(); var linked_976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_975, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_977 lang.IFn; if linked_976 == nil { ifn_977 = lang.IFn_Cast(root_975) } else { ifn_977 = nil }; var arg_978 any = bs__3; var arg_979 any; var root_971 any = A_arbace_classes_env_A_const_111.GetRawRoot__O(); var linked_972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_971, A_arbace_classes_env_superclass_chain_A_fn_class); var ifn_973 lang.IFn; if linked_972 == nil { ifn_973 = lang.IFn_Cast(root_971) } else { ifn_973 = nil }; var arg_974 any = a__0; if linked_972 == nil { arg_979 = ifn_973.Invoke_O__O(arg_974) } else { arg_979 = linked_972.(*A_arbace_classes_env_superclass_chain_A).Invoke_O_O__O(root_971, arg_974) }; if linked_976 == nil { arg_983 = ifn_977.Invoke_O_O__O(arg_978, arg_979) } else { arg_983 = linked_976.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_975, arg_978, arg_979) }; if linked_981 == nil { or__1927000174__auto____4 = ifn_982.Invoke_O__O(arg_983) } else { or__1927000174__auto____4 = linked_981.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_980, arg_983) }; if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { return Lit_4 } } else {
//line :250:1
									return nil
								}
							}
						}
				}
		}
	}
}

func A_arbace_classes_env_lub_A_New() *A_arbace_classes_env_lub_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_lub_A{}; t.Ctor(); return t }
//line :259:1
func (t *A_arbace_classes_env_lub_A) Ctor() {}
//line :259:1
func (t *A_arbace_classes_env_lub_A) Invoke_O_O_O__O(self, a__0, b__1 any) any {



	if lang.Util_Equiv_O_O__Z_NoInit(a__0, b__1) { return a__0 } else { if lang.Util_Equiv_O_O__Z_NoInit(a__0, A_arbace_classes_env_A_const_98) { return b__1 } else { if lang.Util_Equiv_O_O__Z_NoInit(b__1, A_arbace_classes_env_A_const_98) { return a__0 } else { var tmp1 any; var root_984 any = A_arbace_classes_env_A_const_103.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_984, A_arbace_classes_env_assignable_QMARK__A_fn_class); var ifn_986 lang.IFn


		if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any = a__0; var arg_988 any = b__1; if linked_985 == nil { tmp1 = ifn_986.Invoke_O_O__O(arg_987, arg_988) } else { tmp1 = linked_985.(*A_arbace_classes_env_assignable_QMARK__A).Invoke_O_O_O__O(root_984, arg_987, arg_988) }
//line :263:1
		if jrt.J2g_Truth(tmp1) { return b__1 } else { var tmp2 any; var root_989 any = A_arbace_classes_env_A_const_103.GetRawRoot__O(); var linked_990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_989, A_arbace_classes_env_assignable_QMARK__A_fn_class); var ifn_991 lang.IFn



			if linked_990 == nil { ifn_991 = lang.IFn_Cast(root_989) } else { ifn_991 = nil }; var arg_992 any = b__1; var arg_993 any = a__0; if linked_990 == nil { tmp2 = ifn_991.Invoke_O_O__O(arg_992, arg_993) } else { tmp2 = linked_990.(*A_arbace_classes_env_assignable_QMARK__A).Invoke_O_O_O__O(root_989, arg_992, arg_993) }
//line :263:1
			if jrt.J2g_Truth(tmp2) { return a__0 } else { var tmp3 any; var and__1927000168__auto____3 any; var root_994 any = A_arbace_classes_env_A_const_112.GetRawRoot__O(); var linked_995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_994, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_996 lang.IFn




				if linked_995 == nil { ifn_996 = lang.IFn_Cast(root_994) } else { ifn_996 = nil }; var arg_997 any = a__0; if linked_995 == nil { and__1927000168__auto____3 = ifn_996.Invoke_O__O(arg_997) } else { and__1927000168__auto____3 = linked_995.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_994, arg_997) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_998 any = A_arbace_classes_env_A_const_112.GetRawRoot__O(); var linked_999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_998, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_1000 lang.IFn; if linked_999 == nil { ifn_1000 = lang.IFn_Cast(root_998) } else { ifn_1000 = nil }; var arg_1001 any = b__1; if linked_999 == nil { tmp3 = ifn_1000.Invoke_O__O(arg_1001) } else { tmp3 = linked_999.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_998, arg_1001) } } else { tmp3 = and__1927000168__auto____3 }
//line :263:1
				if jrt.J2g_Truth(tmp3) { var c__3 any; var root_1010 any = A_arbace_classes_env_A_const_113.GetRawRoot__O(); var linked_1011 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1010, A_arbace_classes_env_common_super_A_fn_class); var ifn_1012 lang.IFn





					if linked_1011 == nil { ifn_1012 = lang.IFn_Cast(root_1010) } else { ifn_1012 = nil }; var arg_1013 any; var root_1002 any = A_arbace_classes_env_A_const_106.GetRawRoot__O(); var linked_1003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1002, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_1004 lang.IFn; if linked_1003 == nil { ifn_1004 = lang.IFn_Cast(root_1002) } else { ifn_1004 = nil }; var arg_1005 any = a__0; if linked_1003 == nil { arg_1013 = ifn_1004.Invoke_O__O(arg_1005) } else { arg_1013 = linked_1003.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_1002, arg_1005) }; var arg_1014 any; var root_1006 any = A_arbace_classes_env_A_const_106.GetRawRoot__O(); var linked_1007 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1006, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_1008 lang.IFn; if linked_1007 == nil { ifn_1008 = lang.IFn_Cast(root_1006) } else { ifn_1008 = nil }; var arg_1009 any = b__1; if linked_1007 == nil { arg_1014 = ifn_1008.Invoke_O__O(arg_1009) } else { arg_1014 = linked_1007.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_1006, arg_1009) }; if linked_1011 == nil { c__3 = ifn_1012.Invoke_O_O__O(arg_1013, arg_1014) } else { c__3 = linked_1011.(*A_arbace_classes_env_common_super_A).Invoke_O_O_O__O(root_1010, arg_1013, arg_1014) }
					if lang.Util_Equiv_O_O__Z_NoInit(c__3, Lit_4) { var sups__4 any; var tmp4 any = A_arbace_classes_env_lub_sups__28000129_A_New(); var tmp5 *jrt.Class
						var fncls__1039 /*line :270:1*/*jrt.Class = A_arbace_classes_env_lub_sups__28000129_A_fn_class

						if fncls__1039 == nil { var fncls__1039d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_classes_env_lub_sups__28000129_A_fn_class = fncls__1039d; tmp5 = fncls__1039d } else { tmp5 = fncls__1039 }; sups__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)
//line :270:1
						var common__5 any; var root_1053 any = A_arbace_classes_env_A_const_86.GetRawRoot__O(); var linked_1054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1053, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1055 lang.IFn




						if linked_1054 == nil { ifn_1055 = lang.IFn_Cast(root_1053) } else { ifn_1055 = nil }; var arg_1056 any = A_arbace_classes_env_A_const_109.GetRawRoot__O(); var arg_1057 any; var root_1048 any = A_arbace_classes_env_A_const_115.GetRawRoot__O(); var linked_1049 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1048, aot_arbace_set.A_arbace_set_intersection_A_fn_class); var ifn_1050 lang.IFn; if linked_1049 == nil { ifn_1050 = lang.IFn_Cast(root_1048) } else { ifn_1050 = nil }; var arg_1051 any; var tmp6 lang.IFn = lang.IFn_Cast(sups__4); var tmp7 any; var root_1040 any = A_arbace_classes_env_A_const_106.GetRawRoot__O(); var linked_1041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1040, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_1042 lang.IFn; if linked_1041 == nil { ifn_1042 = lang.IFn_Cast(root_1040) } else { ifn_1042 = nil }; var arg_1043 any = a__0; if linked_1041 == nil { tmp7 = ifn_1042.Invoke_O__O(arg_1043) } else { tmp7 = linked_1041.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_1040, arg_1043) }; arg_1051 = tmp6.Invoke_O__O(tmp7); var arg_1052 any; var tmp8 lang.IFn = lang.IFn_Cast(sups__4); var tmp9 any; var root_1044 any = A_arbace_classes_env_A_const_106.GetRawRoot__O(); var linked_1045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1044, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_1046 lang.IFn
						if linked_1045 == nil { ifn_1046 = lang.IFn_Cast(root_1044) } else { ifn_1046 = nil }; var arg_1047 any = b__1; if linked_1045 == nil { tmp9 = ifn_1046.Invoke_O__O(arg_1047) } else { tmp9 = linked_1045.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_1044, arg_1047) }; arg_1052 = tmp8.Invoke_O__O(tmp9)
//line :275:1
						if linked_1049 == nil { arg_1057 = ifn_1050.Invoke_O_O__O(arg_1051, arg_1052) } else { arg_1057 = linked_1049.(*aot_arbace_set.A_arbace_set_intersection_A).Invoke_O_O_O__O(root_1048, arg_1051, arg_1052) }; if linked_1054 == nil { common__5 = ifn_1055.Invoke_O_O__O(arg_1056, arg_1057) } else { common__5 = linked_1054.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1053, arg_1056, arg_1057) }
//line :270:1
						var minimal__6 any; var root_1075 any = A_arbace_classes_env_A_const_116.GetRawRoot__O(); var linked_1076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1075, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1077 lang.IFn






						if linked_1076 == nil { ifn_1077 = lang.IFn_Cast(root_1075) } else { ifn_1077 = nil }; var arg_1078 any; var tmp10 any = A_arbace_classes_env_lub_fn__28000134_A_New_O(common__5); var tmp11 *jrt.Class; var fncls__1074 *jrt.Class = A_arbace_classes_env_lub_fn__28000134_A_fn_class; if fncls__1074 == nil { var fncls__1074d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_classes_env_lub_fn__28000134_A_fn_class = fncls__1074d; tmp11 = fncls__1074d } else { tmp11 = fncls__1074 }; arg_1078 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var arg_1079 any = common__5; if linked_1076 == nil { minimal__6 = ifn_1077.Invoke_O_O__O(arg_1078, arg_1079) } else { minimal__6 = linked_1076.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1075, arg_1078, arg_1079) }
						if lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(minimal__6))) { var root_1084 any = A_arbace_classes_env_A_const_118.GetRawRoot__O(); var linked_1085 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1084, aot_arbace_classes_types.A_arbace_classes_types_internal__GT_desc_A_fn_class); var ifn_1086 lang.IFn; if linked_1085 == nil { ifn_1086 = lang.IFn_Cast(root_1084) } else { ifn_1086 = nil }; var arg_1087 any; var root_1080 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_1081 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1080, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1082 lang.IFn; if linked_1081 == nil { ifn_1082 = lang.IFn_Cast(root_1080) } else { ifn_1082 = nil }; var arg_1083 any = minimal__6; if linked_1081 == nil { arg_1087 = ifn_1082.Invoke_O__O(arg_1083) } else { arg_1087 = linked_1081.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1080, arg_1083) }; if linked_1085 == nil { return ifn_1086.Invoke_O__O(arg_1087) } else { return linked_1085.(*aot_arbace_classes_types.A_arbace_classes_types_internal__GT_desc_A).Invoke_O_O__O(root_1084, arg_1087) } } else { return A_arbace_classes_env_A_const_100.GetRawRoot__O() } } else {
							var root_1088 any = A_arbace_classes_env_A_const_118.GetRawRoot__O(); var linked_1089 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1088, aot_arbace_classes_types.A_arbace_classes_types_internal__GT_desc_A_fn_class); var ifn_1090 lang.IFn; if linked_1089 == nil { ifn_1090 = lang.IFn_Cast(root_1088) } else { ifn_1090 = nil }; var arg_1091 any = c__3; if linked_1089 == nil { return ifn_1090.Invoke_O__O(arg_1091) } else { return linked_1089.(*aot_arbace_classes_types.A_arbace_classes_types_internal__GT_desc_A).Invoke_O_O__O(root_1088, arg_1091) } } } else {
//line :263:1
								if A_arbace_classes_env_A_const_104 != nil { return A_arbace_classes_env_A_const_100.GetRawRoot__O() } else { return nil
								}
							}
			}
		}
	}
	}
	}
}
func A_arbace_classes_env_lub_sups__28000129_A_New() *A_arbace_classes_env_lub_sups__28000129_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_lub_sups__28000129_A{}; t.Ctor(); return t }
//line :272:1
func (t *A_arbace_classes_env_lub_sups__28000129_A) Ctor() {}
//line :272:1
func (t *A_arbace_classes_env_lub_sups__28000129_A) Invoke_O_O__O(self, n__1 any) any { var root_1035 any = A_arbace_classes_env_A_const_110.GetRawRoot__O(); var linked_1036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1035, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_1037 lang.IFn; if linked_1036 == nil { ifn_1037 = lang.IFn_Cast(root_1035) } else { ifn_1037 = nil }; var arg_1038 any; var root_1029 any = A_arbace_classes_env_A_const_114.GetRawRoot__O(); var linked_1030 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1029, aot_arbace_core.A_arbace_core_tree_seq_A_fn_class); var ifn_1031 lang.IFn; if linked_1030 == nil { ifn_1031 = lang.IFn_Cast(root_1029) } else { ifn_1031 = nil }; var arg_1032 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var arg_1033 any; var tmp1 any = A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_New(); var tmp2 *jrt.Class; var fncls__1028 *jrt.Class = A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_fn_class; if fncls__1028 == nil { var fncls__1028d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_fn_class = fncls__1028d; tmp2 = fncls__1028d } else { tmp2 = fncls__1028 }; arg_1033 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1034 any = n__1; if linked_1030 == nil { arg_1038 = ifn_1031.Invoke_O_O_O__O(arg_1032, arg_1033, arg_1034) } else { arg_1038 = linked_1030.(*aot_arbace_core.A_arbace_core_tree_seq_A).Invoke_O_O_O_O__O(root_1029, arg_1032, arg_1033, arg_1034) }; if linked_1036 == nil { return ifn_1037.Invoke_O__O(arg_1038) } else { return linked_1036.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1035, arg_1038) } }
//line :272:1
func A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_New() *A_arbace_classes_env_lub_sups__28000129_fn__28000130_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_lub_sups__28000129_fn__28000130_A{}; t.Ctor(); return t }
//line :272:1
func (t *A_arbace_classes_env_lub_sups__28000129_fn__28000130_A) Ctor() {}
//line :272:1
func (t *A_arbace_classes_env_lub_sups__28000129_fn__28000130_A) Invoke_O_O__O(self, x__1 any) any { var temp__1927000414__auto____2 any; var root_1015 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_1016 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1015, A_arbace_classes_env_info_A_fn_class); var ifn_1017 lang.IFn; if linked_1016 == nil { ifn_1017 = lang.IFn_Cast(root_1015) } else { ifn_1017 = nil }; var arg_1018 any = x__1; if linked_1016 == nil { temp__1927000414__auto____2 = ifn_1017.Invoke_O__O(arg_1018) } else { temp__1927000414__auto____2 = linked_1016.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1015, arg_1018) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var i__3 any = temp__1927000414__auto____2; var G__28000131__4_ any; var root_1019 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_1020 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1019, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1021 lang.IFn
													if linked_1020 == nil { ifn_1021 = lang.IFn_Cast(root_1019) } else { ifn_1021 = nil }; var arg_1022 any = A_arbace_classes_env_A_const_46.Invoke_O__O(i__3); if linked_1020 == nil { G__28000131__4_ = ifn_1021.Invoke_O__O(arg_1022) } else { G__28000131__4_ = linked_1020.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1019, arg_1022) }; if jrt.J2g_Truth(A_arbace_classes_env_A_const_45.Invoke_O__O(i__3)) { var root_1023 any = A_arbace_classes_env_A_const_10.GetRawRoot__O(); var linked_1024 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1023, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1025 lang.IFn; if linked_1024 == nil { ifn_1025 = lang.IFn_Cast(root_1023) } else { ifn_1025 = nil }; var arg_1026 any = G__28000131__4_; var arg_1027 any = A_arbace_classes_env_A_const_45.Invoke_O__O(i__3); if linked_1024 == nil { return ifn_1025.Invoke_O_O__O(arg_1026, arg_1027) } else { return linked_1024.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1023, arg_1026, arg_1027) } } else { return G__28000131__4_ } } else {
//line :272:1
		return nil } }




func A_arbace_classes_env_lub_fn__28000134_A_New_O(p0 any) *A_arbace_classes_env_lub_fn__28000134_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_lub_fn__28000134_A{}; t.Ctor_O(p0); return t }
//line :277:1
func (t *A_arbace_classes_env_lub_fn__28000134_A) Ctor_O(c__common any) { t.F_common = c__common }
//line :277:1
func (t *A_arbace_classes_env_lub_fn__28000134_A) Invoke_O_O__O(self, i__1 any) any { var root_1069 any = A_arbace_classes_env_A_const_96.GetRawRoot__O(); var linked_1070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1069, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1071 lang.IFn; if linked_1070 == nil { ifn_1071 = lang.IFn_Cast(root_1069) } else { ifn_1071 = nil }; var arg_1072 any; var tmp1 any = A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_New_O(i__1); var tmp2 *jrt.Class; var fncls__1068 *jrt.Class = A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_fn_class; if fncls__1068 == nil { var fncls__1068d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_fn_class = fncls__1068d; tmp2 = fncls__1068d } else { tmp2 = fncls__1068 }; arg_1072 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1073 any = t.F_common; if linked_1070 == nil { return ifn_1071.Invoke_O_O__O(arg_1072, arg_1073) } else { return linked_1070.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1069, arg_1072, arg_1073) } }
//line :277:1
func A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_New_O(p0 any) *A_arbace_classes_env_lub_fn__28000134_fn__28000135_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_lub_fn__28000134_fn__28000135_A{}; t.Ctor_O(p0); return t }
//line :277:1
func (t *A_arbace_classes_env_lub_fn__28000134_fn__28000135_A) Ctor_O(c__i any) { t.F_i = c__i }
//line :277:1
func (t *A_arbace_classes_env_lub_fn__28000134_fn__28000135_A) Invoke_O_O__O(self, p1__28000128_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_1058 any = A_arbace_classes_env_A_const_117.GetRawRoot__O(); var linked_1059 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1058, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1060 lang.IFn; if linked_1059 == nil { ifn_1060 = lang.IFn_Cast(root_1058) } else { ifn_1060 = nil }; var arg_1061 any = p1__28000128_SHARP___1; var arg_1062 any = t.F_i; if linked_1059 == nil { and__1927000168__auto____2 = ifn_1060.Invoke_O_O__O(arg_1061, arg_1062) } else { and__1927000168__auto____2 = linked_1059.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1058, arg_1061, arg_1062) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_1063 any = A_arbace_classes_env_A_const_97.GetRawRoot__O(); var linked_1064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1063, A_arbace_classes_env_subclass_QMARK__A_fn_class); var ifn_1065 lang.IFn; if linked_1064 == nil { ifn_1065 = lang.IFn_Cast(root_1063) } else { ifn_1065 = nil }; var arg_1066 any = p1__28000128_SHARP___1; var arg_1067 any = t.F_i; if linked_1064 == nil { return ifn_1065.Invoke_O_O__O(arg_1066, arg_1067) } else { return linked_1064.(*A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(root_1063, arg_1066, arg_1067) } } else { return and__1927000168__auto____2 } }






func A_arbace_classes_env_nest_host_A_New() *A_arbace_classes_env_nest_host_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_nest_host_A{}; t.Ctor(); return t }
//line :284:1
func (t *A_arbace_classes_env_nest_host_A) Ctor() {}
//line :284:1
func (t *A_arbace_classes_env_nest_host_A) Invoke_O_O__O(self, n__0 any) any { var i__2 any; var root_1092 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_1093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1092, A_arbace_classes_env_info_A_fn_class); var ifn_1094 lang.IFn; if
										linked_1093 == nil { ifn_1094 = lang.IFn_Cast(root_1092) } else { ifn_1094 = nil }; var arg_1095 any = n__0; if linked_1093 == nil { i__2 = ifn_1094.Invoke_O__O(arg_1095) } else { i__2 = linked_1093.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1092, arg_1095) }; var or__1927000174__auto____3 any = /*line :284:1*/A_arbace_classes_env_A_const_48.Invoke_O__O(i__2); if

	jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var temp__1927000408__auto____4 any = A_arbace_classes_env_A_const_49.Invoke_O__O(i__2)
		if jrt.J2g_Truth(temp__1927000408__auto____4) { var o__5 any = temp__1927000408__auto____4; var root_1096 any = A_arbace_classes_env_A_const_119.GetRawRoot__O(); var linked_1097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1096, A_arbace_classes_env_nest_host_A_fn_class); var ifn_1098 lang.IFn; if linked_1097 == nil { ifn_1098 = lang.IFn_Cast(root_1096) } else { ifn_1098 = nil }; var arg_1099 any = o__5; if linked_1097 == nil { return ifn_1098.Invoke_O__O(arg_1099) } else { return linked_1097.(*A_arbace_classes_env_nest_host_A).Invoke_O_O__O(root_1096, arg_1099) } } else { return n__0 } } }

func A_arbace_classes_env_flag_QMARK__A_New() *A_arbace_classes_env_flag_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_flag_QMARK__A{}; t.Ctor(); return t }
//line :289:1
func (t *A_arbace_classes_env_flag_QMARK__A) Ctor() {}
//line :289:1
func (t *A_arbace_classes_env_flag_QMARK__A) Invoke_O_O_O__O(self, flags__0, f__1 any) any { var root_1105 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_1106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1105, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1107 lang.IFn; if linked_1106 == nil { ifn_1107 = lang.IFn_Cast(root_1105) } else { ifn_1107 = nil }; var arg_1108 any; var tmp1 int64; var na_1100 any = flags__0; var na_1101 any = f__1; var tmp2 bool; var tmp3 bool; tmp3 = jrt.Long_InstanceOf(na_1100); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_1101) }; tmp2 = tmp3; if tmp2 { var n0_1102 int64 = jrt.NN(jrt.Long_Cast(na_1100)).LongValue__J(); var n1_1103 int64 = jrt.NN(jrt.Long_Cast(na_1101)).LongValue__J(); tmp1 = n0_1102 & n1_1103 } else { tmp1 = lang.Numbers_And_O_O__J_NoInit(na_1100, na_1101) }; arg_1108 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(tmp1)).Ref(); if linked_1106 == nil { return ifn_1107.Invoke_O__O(arg_1108) } else { return linked_1106.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1105, arg_1108) } }

func A_arbace_classes_env_accessible_QMARK__A_New() *A_arbace_classes_env_accessible_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_accessible_QMARK__A{}; t.Ctor(); return t }
//line :291:1
func (t *A_arbace_classes_env_accessible_QMARK__A) Ctor() {}
//line :291:1
func (t *A_arbace_classes_env_accessible_QMARK__A) Invoke_O_O_O__O(self, from__0, m__1 any) any { var fl__3 any = A_arbace_classes_env_A_const_43.Invoke_O__O(m__1); var owner__4 any = A_arbace_classes_env_A_const_63.Invoke_O__O(m__1); var tmp1 any; var root_1109 any = A_arbace_classes_env_A_const_120.GetRawRoot__O(); var linked_1110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1109, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1111 lang.IFn; if




	linked_1110 == nil { ifn_1111 = lang.IFn_Cast(root_1109) } else { ifn_1111 = nil }; var arg_1112 any = fl__3; var arg_1113 any = A_arbace_classes_env_A_const_121; if linked_1110 == nil { tmp1 = ifn_1111.Invoke_O_O__O(arg_1112, arg_1113) } else { tmp1 = linked_1110.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1109, arg_1112, arg_1113) }; if /*line :295:1*/ jrt.J2g_Truth(tmp1) { return jrt.Boolean_TRUE.Ref() } else { var tmp2 any; var root_1114 any = A_arbace_classes_env_A_const_120.GetRawRoot__O(); var linked_1115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1114, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1116 lang.IFn

		if linked_1115 == nil { ifn_1116 = lang.IFn_Cast(root_1114) } else { ifn_1116 = nil }; var arg_1117 any = fl__3; var arg_1118 any = A_arbace_classes_env_A_const_122; if linked_1115 == nil { tmp2 = ifn_1116.Invoke_O_O__O(arg_1117, arg_1118) } else { tmp2 = linked_1115.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1114, arg_1117, arg_1118) }
//line :295:1
		if jrt.J2g_Truth(tmp2) {

			var tmp3 any; var root_1119 any = A_arbace_classes_env_A_const_119.GetRawRoot__O(); var linked_1120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1119, A_arbace_classes_env_nest_host_A_fn_class); var ifn_1121 lang.IFn; if linked_1120 == nil { ifn_1121 = lang.IFn_Cast(root_1119) } else { ifn_1121 = nil }; var arg_1122 any = from__0; if linked_1120 == nil { tmp3 = ifn_1121.Invoke_O__O(arg_1122) } else { tmp3 = linked_1120.(*A_arbace_classes_env_nest_host_A).Invoke_O_O__O(root_1119, arg_1122) }; var tmp4 any = tmp3; var tmp5 any; var root_1123 any = A_arbace_classes_env_A_const_119.GetRawRoot__O(); var linked_1124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1123, A_arbace_classes_env_nest_host_A_fn_class); var ifn_1125 lang.IFn; if linked_1124 == nil { ifn_1125 = lang.IFn_Cast(root_1123) } else { ifn_1125 = nil }; var arg_1126 any = owner__4; if linked_1124 == nil { tmp5 = ifn_1125.Invoke_O__O(arg_1126) } else { tmp5 = linked_1124.(*A_arbace_classes_env_nest_host_A).Invoke_O_O__O(root_1123, arg_1126) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5)).Ref() } else {
//line :295:1
				var tmp6 any; var root_1127 any = A_arbace_classes_env_A_const_123.GetRawRoot__O(); var linked_1128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1127, aot_arbace_classes_types.A_arbace_classes_types_package_of_A_fn_class); var ifn_1129 lang.IFn


				if linked_1128 == nil { ifn_1129 = lang.IFn_Cast(root_1127) } else { ifn_1129 = nil }; var arg_1130 any = from__0; if linked_1128 == nil { tmp6 = ifn_1129.Invoke_O__O(arg_1130) } else { tmp6 = linked_1128.(*aot_arbace_classes_types.A_arbace_classes_types_package_of_A).Invoke_O_O__O(root_1127, arg_1130) }
//line :295:1
				var tmp7 any = tmp6; var tmp8 any; var root_1131 any = A_arbace_classes_env_A_const_123.GetRawRoot__O(); var linked_1132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1131, aot_arbace_classes_types.A_arbace_classes_types_package_of_A_fn_class); var ifn_1133 lang.IFn


				if linked_1132 == nil { ifn_1133 = lang.IFn_Cast(root_1131) } else { ifn_1133 = nil }; var arg_1134 any = owner__4; if linked_1132 == nil { tmp8 = ifn_1133.Invoke_O__O(arg_1134) } else { tmp8 = linked_1132.(*aot_arbace_classes_types.A_arbace_classes_types_package_of_A).Invoke_O_O__O(root_1131, arg_1134) }
//line :295:1
				if lang.Util_Equiv_O_O__Z_NoInit(tmp7, tmp8) { return jrt.Boolean_TRUE.Ref() } else { var tmp9 any; var root_1135 any = A_arbace_classes_env_A_const_120.GetRawRoot__O(); var linked_1136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1135, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1137 lang.IFn



					if linked_1136 == nil { ifn_1137 = lang.IFn_Cast(root_1135) } else { ifn_1137 = nil }; var arg_1138 any = fl__3; var arg_1139 any = A_arbace_classes_env_A_const_124; if linked_1136 == nil { tmp9 = ifn_1137.Invoke_O_O__O(arg_1138, arg_1139) } else { tmp9 = linked_1136.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1135, arg_1138, arg_1139) }
//line :295:1
					if jrt.J2g_Truth(tmp9) {




						var tmp10 any; var root_1161 any = A_arbace_classes_env_A_const_96.GetRawRoot__O(); var linked_1162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1161, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1163 lang.IFn; if linked_1162 == nil { ifn_1163 = lang.IFn_Cast(root_1161) } else { ifn_1163 = nil }; var arg_1164 any; var tmp11 any = A_arbace_classes_env_accessible_QMARK__fn__28000143_A_New_O(owner__4); var tmp12 *jrt.Class; var fncls__1145 *jrt.Class = A_arbace_classes_env_accessible_QMARK__fn__28000143_A_fn_class; if fncls__1145 == nil { var fncls__1145d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_classes_env_accessible_QMARK__fn__28000143_A_fn_class = fncls__1145d; tmp12 = fncls__1145d } else { tmp12 = fncls__1145 }; arg_1164 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var arg_1165 any; var root_1156 any = A_arbace_classes_env_A_const_107.GetRawRoot__O(); var linked_1157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1156, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_1158 lang.IFn
						if linked_1157 == nil { ifn_1158 = lang.IFn_Cast(root_1156) } else { ifn_1158 = nil }; var arg_1159 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var arg_1160 any; var root_1151 any = A_arbace_classes_env_A_const_108.GetRawRoot__O(); var linked_1152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1151, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_1153 lang.IFn; if linked_1152 == nil { ifn_1153 = lang.IFn_Cast(root_1151) } else { ifn_1153 = nil }; var arg_1154 any; var tmp13 any = A_arbace_classes_env_accessible_QMARK__fn__28000145_A_New(); var tmp14 *jrt.Class; var fncls__1150 *jrt.Class = A_arbace_classes_env_accessible_QMARK__fn__28000145_A_fn_class; if fncls__1150 == nil { var fncls__1150d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_classes_env_accessible_QMARK__fn__28000145_A_fn_class = fncls__1150d; tmp14 = fncls__1150d } else { tmp14 = fncls__1150 }; arg_1154 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); var arg_1155 any = from__0; if linked_1152 == nil { arg_1160 = ifn_1153.Invoke_O_O__O(arg_1154, arg_1155) } else { arg_1160 = linked_1152.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_1151, arg_1154, arg_1155) }; if linked_1157 == nil { arg_1165 = ifn_1158.Invoke_O_O__O(arg_1159, arg_1160) } else { arg_1165 = linked_1157.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_1156, arg_1159, arg_1160) }
//line :300:1
						if linked_1162 == nil { tmp10 = ifn_1163.Invoke_O_O__O(arg_1164, arg_1165) } else { tmp10 = linked_1162.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1161, arg_1164, arg_1165) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp10)).Ref() } else {
//line :295:1
							if A_arbace_classes_env_A_const_104 != nil { return jrt.Boolean_FALSE.Ref() } else { return nil } } } } } }




func A_arbace_classes_env_accessible_QMARK__fn__28000143_A_New_O(p0 any) *A_arbace_classes_env_accessible_QMARK__fn__28000143_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_accessible_QMARK__fn__28000143_A{}; t.Ctor_O(p0); return t }
//line :300:1
func (t *A_arbace_classes_env_accessible_QMARK__fn__28000143_A) Ctor_O(c__owner any) { t.F_owner = c__owner }
//line :300:1
func (t *A_arbace_classes_env_accessible_QMARK__fn__28000143_A) Invoke_O_O__O(self, p1__28000141_SHARP___1 any) any { var root_1140 any = A_arbace_classes_env_A_const_97.GetRawRoot__O(); var linked_1141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1140, A_arbace_classes_env_subclass_QMARK__A_fn_class); var ifn_1142 lang.IFn; if linked_1141 == nil { ifn_1142 = lang.IFn_Cast(root_1140) } else { ifn_1142 = nil }; var arg_1143 any = p1__28000141_SHARP___1; var arg_1144 any = t.F_owner; if linked_1141 == nil { return ifn_1142.Invoke_O_O__O(arg_1143, arg_1144) } else { return linked_1141.(*A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(root_1140, arg_1143, arg_1144) } }
func A_arbace_classes_env_accessible_QMARK__fn__28000145_A_New() *A_arbace_classes_env_accessible_QMARK__fn__28000145_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_accessible_QMARK__fn__28000145_A{}; t.Ctor(); return t }
//line :301:1
func (t *A_arbace_classes_env_accessible_QMARK__fn__28000145_A) Ctor() {}
//line :301:1
func (t *A_arbace_classes_env_accessible_QMARK__fn__28000145_A) Invoke_O_O__O(self, p1__28000142_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_classes_env_A_const_49; var tmp2 any; var root_1146 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_1147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1146, A_arbace_classes_env_info_A_fn_class); var ifn_1148 lang.IFn; if linked_1147 == nil { ifn_1148 = lang.IFn_Cast(root_1146) } else { ifn_1148 = nil }; var arg_1149 any = p1__28000142_SHARP___1; if linked_1147 == nil { tmp2 = ifn_1148.Invoke_O__O(arg_1149) } else { tmp2 = linked_1147.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1146, arg_1149) }; return tmp1.Invoke_O__O(tmp2) }


func A_arbace_classes_env_find_field_A_New() *A_arbace_classes_env_find_field_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_find_field_A{}; t.Ctor(); return t }
//line :304:1
func (t *A_arbace_classes_env_find_field_A) Ctor() {}
//line :304:1
func (t *A_arbace_classes_env_find_field_A) Invoke_O_O_O__O(self, n__0, name__1 any) any { var temp__1927000414__auto____3 any; var root_1166 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_1167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1166, A_arbace_classes_env_info_A_fn_class); var ifn_1168 lang.IFn; if



	linked_1167 == nil { ifn_1168 = lang.IFn_Cast(root_1166) } else { ifn_1168 = nil }; var arg_1169 any = n__0; if linked_1167 == nil { temp__1927000414__auto____3 = ifn_1168.Invoke_O__O(arg_1169) } else { temp__1927000414__auto____3 = linked_1167.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1166, arg_1169) }; if jrt.J2g_Truth(temp__1927000414__auto____3) { var i__4 any = temp__1927000414__auto____3; var or__1927000174__auto____5 any; var root_1176 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_1177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1176, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1178 lang.IFn
		if linked_1177 == nil { ifn_1178 = lang.IFn_Cast(root_1176) } else { ifn_1178 = nil }; var arg_1179 any; var root_1171 any = A_arbace_classes_env_A_const_86.GetRawRoot__O(); var linked_1172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1171, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1173 lang.IFn; if linked_1172 == nil { ifn_1173 = lang.IFn_Cast(root_1171) } else { ifn_1173 = nil }; var arg_1174 any; var tmp1 any = A_arbace_classes_env_find_field_fn__28000150_A_New_O(name__1); var tmp2 *jrt.Class; var fncls__1170 *jrt.Class = A_arbace_classes_env_find_field_fn__28000150_A_fn_class; if fncls__1170 == nil { var fncls__1170d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_classes_env_find_field_fn__28000150_A_fn_class = fncls__1170d; tmp2 = fncls__1170d } else { tmp2 = fncls__1170 }; arg_1174 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1175 any = A_arbace_classes_env_A_const_50.Invoke_O__O(i__4); if linked_1172 == nil { arg_1179 = ifn_1173.Invoke_O_O__O(arg_1174, arg_1175) } else { arg_1179 = linked_1172.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1171, arg_1174, arg_1175) }; if linked_1177 == nil { or__1927000174__auto____5 = ifn_1178.Invoke_O__O(arg_1179) } else { or__1927000174__auto____5 = linked_1177.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1176, arg_1179) }; if jrt.J2g_Truth(or__1927000174__auto____5) { return or__1927000174__auto____5 } else { var or__1927000174__auto____6 any; var root_1186 any = A_arbace_classes_env_A_const_96.GetRawRoot__O(); var linked_1187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1186, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1188 lang.IFn
			if linked_1187 == nil { ifn_1188 = lang.IFn_Cast(root_1186) } else { ifn_1188 = nil }; var arg_1189 any; var tmp3 any = A_arbace_classes_env_find_field_fn__28000152_A_New_O(name__1); var tmp4 *jrt.Class; var fncls__1185 *jrt.Class = A_arbace_classes_env_find_field_fn__28000152_A_fn_class; if fncls__1185 == nil { var fncls__1185d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_classes_env_find_field_fn__28000152_A_fn_class = fncls__1185d; tmp4 = fncls__1185d } else { tmp4 = fncls__1185 }; arg_1189 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_1190 any = A_arbace_classes_env_A_const_46.Invoke_O__O(i__4); if linked_1187 == nil { or__1927000174__auto____6 = ifn_1188.Invoke_O_O__O(arg_1189, arg_1190) } else { or__1927000174__auto____6 = linked_1187.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1186, arg_1189, arg_1190) }
//line :309:1
			if jrt.J2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else { var G__28000154__7_ any = A_arbace_classes_env_A_const_45.Invoke_O__O(i__4)

				if lang.Util_Identical_O_O__Z_NoInit(G__28000154__7_, nil) { return nil } else { var root_1191 any = A_arbace_classes_env_A_const_125.GetRawRoot__O(); var linked_1192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1191, A_arbace_classes_env_find_field_A_fn_class); var ifn_1193 lang.IFn; if linked_1192 == nil { ifn_1193 = lang.IFn_Cast(root_1191) } else { ifn_1193 = nil }; var arg_1194 any = G__28000154__7_; var arg_1195 any = name__1; if linked_1192 == nil { return ifn_1193.Invoke_O_O__O(arg_1194, arg_1195) } else { return linked_1192.(*A_arbace_classes_env_find_field_A).Invoke_O_O_O__O(root_1191, arg_1194, arg_1195) } } } } } else {
//line :308:1
					return nil } }
func A_arbace_classes_env_find_field_fn__28000150_A_New_O(p0 any) *A_arbace_classes_env_find_field_fn__28000150_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_find_field_fn__28000150_A{}; t.Ctor_O(p0); return t }
//line :309:1
func (t *A_arbace_classes_env_find_field_fn__28000150_A) Ctor_O(c__name any) { t.F_name = c__name }
//line :309:1
func (t *A_arbace_classes_env_find_field_fn__28000150_A) Invoke_O_O__O(self, p1__28000148_SHARP___1 any) any { var tmp1 any = t.F_name; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_classes_env_A_const_42.Invoke_O__O(p1__28000148_SHARP___1))).Ref() }
func A_arbace_classes_env_find_field_fn__28000152_A_New_O(p0 any) *A_arbace_classes_env_find_field_fn__28000152_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_find_field_fn__28000152_A{}; t.Ctor_O(p0); return t }
//line :310:1
func (t *A_arbace_classes_env_find_field_fn__28000152_A) Ctor_O(c__name any) { t.F_name = c__name }
//line :310:1
func (t *A_arbace_classes_env_find_field_fn__28000152_A) Invoke_O_O__O(self, p1__28000149_SHARP___1 any) any { var root_1180 any = A_arbace_classes_env_A_const_125.GetRawRoot__O(); var linked_1181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1180, A_arbace_classes_env_find_field_A_fn_class); var ifn_1182 lang.IFn; if linked_1181 == nil { ifn_1182 = lang.IFn_Cast(root_1180) } else { ifn_1182 = nil }; var arg_1183 any = p1__28000149_SHARP___1; var arg_1184 any = t.F_name; if linked_1181 == nil { return ifn_1182.Invoke_O_O__O(arg_1183, arg_1184) } else { return linked_1181.(*A_arbace_classes_env_find_field_A).Invoke_O_O_O__O(root_1180, arg_1183, arg_1184) } }


func A_arbace_classes_env_same_infos_QMARK__A_New() *A_arbace_classes_env_same_infos_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_same_infos_QMARK__A{}; t.Ctor(); return t }
//line :313:1
func (t *A_arbace_classes_env_same_infos_QMARK__A) Ctor() {}
//line :313:1
func (t *A_arbace_classes_env_same_infos_QMARK__A) Invoke_O_O_O__O(self, names__0, infos__1 any) any { { var n__3 int32 = lang.RT_Count_O__I_NoInit(names__0); var cs__4 any; var G__28000156__4_ any = A_arbace_classes_env_A_const_89.Get__O()



	if lang.Util_Identical_O_O__Z_NoInit(G__28000156__4_, nil) { cs__4 = nil } else { var root_1196 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_1197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1196, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1198 lang.IFn; if linked_1197 == nil { ifn_1198 = lang.IFn_Cast(root_1196) } else { ifn_1198 = nil }; var arg_1199 any = G__28000156__4_; if linked_1197 == nil { cs__4 = ifn_1198.Invoke_O__O(arg_1199) } else { cs__4 = linked_1197.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1196, arg_1199) } }
//line :313:1
	var i__5 int64 = 0; L1: for { var or__1927000174__auto____6 bool = lang.Util_Equiv_J_J__Z_NoInit(i__5, int64(n__3))





		if or__1927000174__auto____6 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____6).Ref() } else { var and__1927000168__auto____7 any; var c__7 any = lang.RT_Nth_O_I__O_NoInit(names__0, lang.RT_IntCast_J__I_NoInit(i__5)); var x__8 any = lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](infos__1, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(i__5)); var or__1927000174__auto____9 any; var and__1927000168__auto____9 any; var root_1200 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1200, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_1202 lang.IFn



			if linked_1201 == nil { ifn_1202 = lang.IFn_Cast(root_1200) } else { ifn_1202 = nil }; var arg_1203 any = x__8; if linked_1201 == nil { and__1927000168__auto____9 = ifn_1202.Invoke_O__O(arg_1203) } else { and__1927000168__auto____9 = linked_1201.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_1200, arg_1203) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 any; var root_1204 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1204, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_1206 lang.IFn; if linked_1205 == nil { ifn_1206 = lang.IFn_Cast(root_1204) } else { ifn_1206 = nil }; var arg_1207 any = cs__4; if linked_1205 == nil { and__1927000168__auto____10 = ifn_1206.Invoke_O__O(arg_1207) } else { and__1927000168__auto____10 = linked_1205.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_1204, arg_1207) }; if jrt.J2g_Truth(and__1927000168__auto____10) { var and__1927000168__auto____11 bool = lang.Util_Identical_O_O__Z_NoInit(x__8, lang.RT_Get_O_O__O_NoInit(cs__4, c__7)); if and__1927000168__auto____11 { var root_1213 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_1214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1213, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1215 lang.IFn; if linked_1214 == nil { ifn_1215 = lang.IFn_Cast(root_1213) } else { ifn_1215 = nil }; var arg_1216 any; var root_1208 any = A_arbace_classes_env_A_const_20.GetRawRoot__O(); var linked_1209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1208, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1210 lang.IFn; if linked_1209 == nil { ifn_1210 = lang.IFn_Cast(root_1208) } else { ifn_1210 = nil }; var arg_1211 any = c__7; var arg_1212 any = Lit_11; if linked_1209 == nil { arg_1216 = ifn_1210.Invoke_O_O__O(arg_1211, arg_1212) } else { arg_1216 = linked_1209.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1208, arg_1211, arg_1212) }; if linked_1214 == nil { or__1927000174__auto____9 = ifn_1215.Invoke_O__O(arg_1216) } else { or__1927000174__auto____9 = linked_1214.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1213, arg_1216) } } else { or__1927000174__auto____9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11).Ref() } } else { or__1927000174__auto____9 = and__1927000168__auto____10 } } else { or__1927000174__auto____9 = and__1927000168__auto____9 }; if jrt.J2g_Truth(or__1927000174__auto____9) { and__1927000168__auto____7 = or__1927000174__auto____9 } else {
				var tmp1 any; var root_1217 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_1218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1217, A_arbace_classes_env_info_A_fn_class); var ifn_1219 lang.IFn; if linked_1218 == nil { ifn_1219 = lang.IFn_Cast(root_1217) } else { ifn_1219 = nil }; var arg_1220 any = c__7; if linked_1218 == nil { tmp1 = ifn_1219.Invoke_O__O(arg_1220) } else { tmp1 = linked_1218.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1217, arg_1220) }; and__1927000168__auto____7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp1, x__8)).Ref() }
//line :320:1
			if jrt.J2g_Truth(and__1927000168__auto____7) {




				i__5 = lang.Numbers_Inc_J__J_NoInit(i__5); continue L1 } else {
//line :320:1
					return and__1927000168__auto____7 } } } }; /*line :313:1*/panic("j2g: unreachable") }













func A_arbace_classes_env_infos_now_A_New() *A_arbace_classes_env_infos_now_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_infos_now_A{}; t.Ctor(); return t }
//line :327:1
func (t *A_arbace_classes_env_infos_now_A) Ctor() {}
//line :327:1
func (t *A_arbace_classes_env_infos_now_A) Invoke_O_O__O(self, names__0 any) any { var a__2 any = lang.RT_Object_array_O__O1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(names__0)).Ref()).Ref(); var n__1927000701__auto____3 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_Count_O__I_NoInit(names__0)); var i__4 int64 = 0; L1: for {

	if lang.Numbers_Lt_J_J__Z_NoInit(i__4, n__1927000701__auto____3) { var tmp1 *jrt.RefArray = jrt.J2g_CastArray[*jrt.RefArray](a__2, jrt.Object_class.ArrayClass()); var tmp2 int32 = lang.RT_IntCast_J__I_NoInit(i__4); var tmp3 any; var root_1221 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_1222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1221, A_arbace_classes_env_info_A_fn_class); var ifn_1223 lang.IFn; if linked_1222 == nil { ifn_1223 = lang.IFn_Cast(root_1221) } else { ifn_1223 = nil }; var arg_1224 any = lang.RT_Nth_O_I__O_NoInit(names__0, lang.RT_IntCast_J__I_NoInit(i__4)); if linked_1222 == nil { tmp3 = ifn_1223.Invoke_O__O(arg_1224) } else { tmp3 = linked_1222.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1221, arg_1224) }; lang.RT_Aset_O1_I_O__O_NoInit(tmp1, tmp2, tmp3); i__4 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__4); continue L1 }
//line :327:1
	break L1 }; return a__2 }
















func A_arbace_classes_env_all_supertypes_STAR__A_New() *A_arbace_classes_env_all_supertypes_STAR__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_all_supertypes_STAR__A{}; t.Ctor(); return t }
//line :344:1
func (t *A_arbace_classes_env_all_supertypes_STAR__A) Ctor() {}
//line :344:1
func (t *A_arbace_classes_env_all_supertypes_STAR__A) Invoke_O_O__O(self, n__0 any) any { { var chain__2 any; var root_1229 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_1230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1229, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1231 lang.IFn

	if linked_1230 == nil { ifn_1231 = lang.IFn_Cast(root_1229) } else { ifn_1231 = nil }; var arg_1232 any; var root_1225 any = A_arbace_classes_env_A_const_111.GetRawRoot__O(); var linked_1226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1225, A_arbace_classes_env_superclass_chain_A_fn_class); var ifn_1227 lang.IFn; if linked_1226 == nil { ifn_1227 = lang.IFn_Cast(root_1225) } else { ifn_1227 = nil }; var arg_1228 any = n__0; if linked_1226 == nil { arg_1232 = ifn_1227.Invoke_O__O(arg_1228) } else { arg_1232 = linked_1226.(*A_arbace_classes_env_superclass_chain_A).Invoke_O_O__O(root_1225, arg_1228) }; if linked_1230 == nil { chain__2 = ifn_1231.Invoke_O__O(arg_1232) } else { chain__2 = linked_1230.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1229, arg_1232) }
//line :344:1
	var out__3 any = chain__2; var seen__4 any; var root_1233 any = A_arbace_classes_env_A_const_110.GetRawRoot__O(); var linked_1234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1233, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_1235 lang.IFn


	if linked_1234 == nil { ifn_1235 = lang.IFn_Cast(root_1233) } else { ifn_1235 = nil }; var arg_1236 any = chain__2; if linked_1234 == nil { seen__4 = ifn_1235.Invoke_O__O(arg_1236) } else { seen__4 = linked_1234.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1233, arg_1236) }
//line :344:1
	var queue__5 any; var root_1247 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_1248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1247, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1249 lang.IFn


	if linked_1248 == nil { ifn_1249 = lang.IFn_Cast(root_1247) } else { ifn_1249 = nil }; var arg_1250 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_126.GetRawRoot__O()); var tmp2 any = A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A_New(); var tmp3 *jrt.Class; var fncls__1241 *jrt.Class = A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A_fn_class; if fncls__1241 == nil { var fncls__1241d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A_fn_class = fncls__1241d; tmp3 = fncls__1241d } else { tmp3 = fncls__1241 }; arg_1250 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), chain__2); if linked_1248 == nil { queue__5 = ifn_1249.Invoke_O__O(arg_1250) } else { queue__5 = linked_1248.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1247, arg_1250) }
//line :344:1
L1: for { var temp__1927000408__auto____6 any; var root_1251 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_1252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1251, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1253 lang.IFn



	if linked_1252 == nil { ifn_1253 = lang.IFn_Cast(root_1251) } else { ifn_1253 = nil }; var arg_1254 any = queue__5; if linked_1252 == nil { temp__1927000408__auto____6 = ifn_1253.Invoke_O__O(arg_1254) } else { temp__1927000408__auto____6 = linked_1252.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1251, arg_1254) }; if jrt.J2g_Truth(temp__1927000408__auto____6) { var vec__28000162__7 any = temp__1927000408__auto____6; var seq__28000163__8 any; var root_1255 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_1256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1255, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1257 lang.IFn; if linked_1256 == nil { ifn_1257 = lang.IFn_Cast(root_1255) } else { ifn_1257 = nil }; var arg_1258 any = vec__28000162__7; if linked_1256 == nil { seq__28000163__8 = ifn_1257.Invoke_O__O(arg_1258) } else { seq__28000163__8 = linked_1256.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1255, arg_1258) }; var first__28000164__9 any; var root_1259 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_1260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1259, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1261 lang.IFn; if linked_1260 == nil { ifn_1261 = lang.IFn_Cast(root_1259) } else { ifn_1261 = nil }; var arg_1262 any = seq__28000163__8; if linked_1260 == nil { first__28000164__9 = ifn_1261.Invoke_O__O(arg_1262) } else { first__28000164__9 = linked_1260.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1259, arg_1262) }; var seq__28000163__10 any; var root_1263 any = A_arbace_classes_env_A_const_57.GetRawRoot__O(); var linked_1264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1263, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1265 lang.IFn; if linked_1264 == nil { ifn_1265 = lang.IFn_Cast(root_1263) } else { ifn_1265 = nil }; var arg_1266 any = seq__28000163__8; if linked_1264 == nil { seq__28000163__10 = ifn_1265.Invoke_O__O(arg_1266) } else { seq__28000163__10 = linked_1264.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1263, arg_1266) }; var q__11 any = first__28000164__9; var more__12 any = seq__28000163__10
		if jrt.J2g_Truth(lang.IFn_Cast(seen__4).Invoke_O__O(q__11)) {
			var tmp4 any; var root_1280 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_1281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1280, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1282 lang.IFn; if linked_1281 == nil { ifn_1282 = lang.IFn_Cast(root_1280) } else { ifn_1282 = nil }; var arg_1283 any = more__12; if linked_1281 == nil { tmp4 = ifn_1282.Invoke_O__O(arg_1283) } else { tmp4 = linked_1281.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1280, arg_1283) }; out__3, seen__4, queue__5 = out__3, seen__4, tmp4; continue L1 } else {
				var tmp5 any; var root_1284 any = A_arbace_classes_env_A_const_10.GetRawRoot__O(); var linked_1285 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1284, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1286 lang.IFn; if linked_1285 == nil { ifn_1286 = lang.IFn_Cast(root_1284) } else { ifn_1286 = nil }; var arg_1287 any = out__3; var arg_1288 any = q__11; if linked_1285 == nil { tmp5 = ifn_1286.Invoke_O_O__O(arg_1287, arg_1288) } else { tmp5 = linked_1285.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1284, arg_1287, arg_1288) }; var tmp6 any = tmp5; var tmp7 any; var root_1289 any = A_arbace_classes_env_A_const_10.GetRawRoot__O(); var linked_1290 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1289, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1291 lang.IFn; if linked_1290 == nil { ifn_1291 = lang.IFn_Cast(root_1289) } else { ifn_1291 = nil }; var arg_1292 any = seen__4; var arg_1293 any = q__11; if linked_1290 == nil { tmp7 = ifn_1291.Invoke_O_O__O(arg_1292, arg_1293) } else { tmp7 = linked_1290.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1289, arg_1292, arg_1293) }; var tmp8 any = tmp7; var tmp9 any; var root_1302 any = A_arbace_classes_env_A_const_87.GetRawRoot__O(); var linked_1303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1302, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1304 lang.IFn; if linked_1303 == nil { ifn_1304 = lang.IFn_Cast(root_1302) } else { ifn_1304 = nil }; var arg_1305 any; var root_1294 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_1295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1294, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1296 lang.IFn; if linked_1295 == nil { ifn_1296 = lang.IFn_Cast(root_1294) } else { ifn_1296 = nil }; var arg_1297 any = more__12; if linked_1295 == nil { arg_1305 = ifn_1296.Invoke_O__O(arg_1297) } else { arg_1305 = linked_1295.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1294, arg_1297) }; var arg_1306 any; var tmp10 *lang.Keyword = A_arbace_classes_env_A_const_46; var tmp11 any; var root_1298 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_1299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1298, A_arbace_classes_env_info_A_fn_class); var ifn_1300 lang.IFn; if linked_1299 == nil { ifn_1300 = lang.IFn_Cast(root_1298) } else { ifn_1300 = nil }; var arg_1301 any = q__11; if linked_1299 == nil { tmp11 = ifn_1300.Invoke_O__O(arg_1301) } else { tmp11 = linked_1299.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1298, arg_1301) }; arg_1306 = tmp10.Invoke_O__O(tmp11); if linked_1303 == nil { tmp9 = ifn_1304.Invoke_O_O__O(arg_1305, arg_1306) } else { tmp9 = linked_1303.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1302, arg_1305, arg_1306) }; out__3, seen__4, queue__5 = tmp6, tmp8, tmp9; continue L1 } } else {
//line :348:1
					var G__28000165__7_ any = out__3; var tmp12 any; var and__1927000168__auto____8 any; var root_1267 any = A_arbace_classes_env_A_const_109.GetRawRoot__O(); var linked_1268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1267, A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_1269 lang.IFn



					if linked_1268 == nil { ifn_1269 = lang.IFn_Cast(root_1267) } else { ifn_1269 = nil }; var arg_1270 any = n__0; if linked_1268 == nil { and__1927000168__auto____8 = ifn_1269.Invoke_O__O(arg_1270) } else { and__1927000168__auto____8 = linked_1268.(*A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_1267, arg_1270) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_1271 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_1272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1271, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1273 lang.IFn; if linked_1272 == nil { ifn_1273 = lang.IFn_Cast(root_1271) } else { ifn_1273 = nil }; var arg_1274 any = lang.IFn_Cast(seen__4).Invoke_O__O(Lit_4); if linked_1272 == nil { tmp12 = ifn_1273.Invoke_O__O(arg_1274) } else { tmp12 = linked_1272.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1271, arg_1274) } } else { tmp12 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp12) { var root_1275 any = A_arbace_classes_env_A_const_10.GetRawRoot__O(); var linked_1276 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1275, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1277 lang.IFn; if linked_1276 == nil { ifn_1277 = lang.IFn_Cast(root_1275) } else { ifn_1277 = nil }; var arg_1278 any = G__28000165__7_; var arg_1279 any = Lit_4; if linked_1276 == nil { return ifn_1277.Invoke_O_O__O(arg_1278, arg_1279) } else { return linked_1276.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1275, arg_1278, arg_1279) } } else { return G__28000165__7_ } } } }; /*line :344:1*/panic("j2g: unreachable") }


func A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A_New() *A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A{}; t.Ctor(); return t }
//line :347:1
func (t *A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A) Ctor() {}
//line :347:1
func (t *A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A) Invoke_O_O__O(self, p1__28000159_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_classes_env_A_const_46; var tmp2 any; var root_1237 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_1238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1237, A_arbace_classes_env_info_A_fn_class); var ifn_1239 lang.IFn; if linked_1238 == nil { ifn_1239 = lang.IFn_Cast(root_1237) } else { ifn_1239 = nil }; var arg_1240 any = p1__28000159_SHARP___1; if linked_1238 == nil { tmp2 = ifn_1239.Invoke_O__O(arg_1240) } else { tmp2 = linked_1238.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1237, arg_1240) }; return tmp1.Invoke_O__O(tmp2) }






func A_arbace_classes_env_all_supertypes_A_New() *A_arbace_classes_env_all_supertypes_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_all_supertypes_A{}; t.Ctor(); return t }
//line :354:1
func (t *A_arbace_classes_env_all_supertypes_A) Ctor() {}
//line :354:1
func (t *A_arbace_classes_env_all_supertypes_A) Invoke_O_O__O(self, n__0 any) any { var e__2 any; if


	jrt.J2g_Truth(n__0) { e__2 = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_127.GetRawRoot__O())).Get_O__O(n__0) } else { e__2 = nil }; var tmp1 any; var and__1927000168__auto____3 any = e__2; if
	jrt.J2g_Truth(and__1927000168__auto____3) { var root_1307 any = A_arbace_classes_env_A_const_128.GetRawRoot__O(); var linked_1308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1307, A_arbace_classes_env_same_infos_QMARK__A_fn_class); var ifn_1309 lang.IFn; if linked_1308 == nil { ifn_1309 = lang.IFn_Cast(root_1307) } else { ifn_1309 = nil }; var arg_1310 any = lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](e__2, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0)); var arg_1311 any = lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](e__2, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(1)); if linked_1308 == nil { tmp1 = ifn_1309.Invoke_O_O__O(arg_1310, arg_1311) } else { tmp1 = linked_1308.(*A_arbace_classes_env_same_infos_QMARK__A).Invoke_O_O_O__O(root_1307, arg_1310, arg_1311) } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		return lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](e__2, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0)) } else {
//line :358:1
			var r__3 any; var root_1312 any = A_arbace_classes_env_A_const_129.GetRawRoot__O(); var linked_1313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1312, A_arbace_classes_env_all_supertypes_STAR__A_fn_class); var ifn_1314 lang.IFn

			if linked_1313 == nil { ifn_1314 = lang.IFn_Cast(root_1312) } else { ifn_1314 = nil }; var arg_1315 any = n__0; if linked_1313 == nil { r__3 = ifn_1314.Invoke_O__O(arg_1315) } else { r__3 = linked_1313.(*A_arbace_classes_env_all_supertypes_STAR__A).Invoke_O_O__O(root_1312, arg_1315) }
//line :358:1
			var infos__4 any; var root_1316 any = A_arbace_classes_env_A_const_130.GetRawRoot__O(); var linked_1317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1316, A_arbace_classes_env_infos_now_A_fn_class); var ifn_1318 lang.IFn


			if linked_1317 == nil { ifn_1318 = lang.IFn_Cast(root_1316) } else { ifn_1318 = nil }; var arg_1319 any = r__3; if linked_1317 == nil { infos__4 = ifn_1318.Invoke_O__O(arg_1319) } else { infos__4 = linked_1317.(*A_arbace_classes_env_infos_now_A).Invoke_O_O__O(root_1316, arg_1319)
			}
			var tmp2 any; var and__1927000168__auto____5 any = n__0; if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp3 any; var root_1320 any = A_arbace_classes_env_A_const_129.GetRawRoot__O(); var linked_1321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1320, A_arbace_classes_env_all_supertypes_STAR__A_fn_class); var ifn_1322 lang.IFn; if linked_1321 == nil { ifn_1322 = lang.IFn_Cast(root_1320) } else { ifn_1322 = nil }; var arg_1323 any = n__0; if linked_1321 == nil { tmp3 = ifn_1322.Invoke_O__O(arg_1323) } else { tmp3 = linked_1321.(*A_arbace_classes_env_all_supertypes_STAR__A).Invoke_O_O__O(root_1320, arg_1323) }; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(r__3, tmp3)).Ref() } else { tmp2 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp2) {
				jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_127.GetRawRoot__O())).Put_O_O__O(n__0, lang.RT_Object_array_O__O1_NoInit(lang.Tuple_Create_O_O__IPersistentVector(r__3, infos__4)).Ref()) }
//line :358:1
			return r__3 } }








func A_arbace_classes_env_params_key_A_New() *A_arbace_classes_env_params_key_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_params_key_A{}; t.Ctor(); return t }
//line :367:1
func (t *A_arbace_classes_env_params_key_A) Ctor() {}
//line :367:1
func (t *A_arbace_classes_env_params_key_A) Invoke_O_O__O(self, desc__0 any) any { var root_1324 any = A_arbace_classes_env_A_const_131.GetRawRoot__O(); var linked_1325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1324, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1326 lang.IFn; if linked_1325 == nil { ifn_1326 = lang.IFn_Cast(root_1324) } else { ifn_1326 = nil }; var arg_1327 any = desc__0; var arg_1328 any = A_arbace_classes_env_A_const_132; var arg_1329 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(jrt.NN(jrt.String_Cast(desc__0)).IndexOf_String__I(Lit_30)))).Ref(); if linked_1325 == nil { return ifn_1326.Invoke_O_O_O__O(arg_1327, arg_1328, arg_1329) } else { return linked_1325.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1324, arg_1327, arg_1328, arg_1329) } }

func A_arbace_classes_env_member_methods_STAR__A_New() *A_arbace_classes_env_member_methods_STAR__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_member_methods_STAR__A{}; t.Ctor(); return t }
//line :369:1
func (t *A_arbace_classes_env_member_methods_STAR__A) Ctor() {}
//line :369:1
func (t *A_arbace_classes_env_member_methods_STAR__A) Invoke_O_O_O_O__O(self, n__0, name__1, sups__2 any) any { { var G__28000172__4_ any = sups__2; var vec__28000173__5 any = G__28000172__4_; var seq__28000174__6 any; var root_1330 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_1331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1330, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1332 lang.IFn

	if linked_1331 == nil { ifn_1332 = lang.IFn_Cast(root_1330) } else { ifn_1332 = nil }; var arg_1333 any = vec__28000173__5; if linked_1331 == nil { seq__28000174__6 = ifn_1332.Invoke_O__O(arg_1333) } else { seq__28000174__6 = linked_1331.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1330, arg_1333) }
//line :369:1
	var first__28000175__7 any; var root_1334 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_1335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1334, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1336 lang.IFn

	if linked_1335 == nil { ifn_1336 = lang.IFn_Cast(root_1334) } else { ifn_1336 = nil }; var arg_1337 any = seq__28000174__6; if linked_1335 == nil { first__28000175__7 = ifn_1336.Invoke_O__O(arg_1337) } else { first__28000175__7 = linked_1335.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1334, arg_1337) }
//line :369:1
	var seq__28000174__8 any; var root_1338 any = A_arbace_classes_env_A_const_57.GetRawRoot__O(); var linked_1339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1338, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1340 lang.IFn

	if linked_1339 == nil { ifn_1340 = lang.IFn_Cast(root_1338) } else { ifn_1340 = nil }; var arg_1341 any = seq__28000174__6; if linked_1339 == nil { seq__28000174__8 = ifn_1340.Invoke_O__O(arg_1341) } else { seq__28000174__8 = linked_1339.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1338, arg_1341) }
//line :369:1
	var c__9 any = first__28000175__7; var more__10 any = seq__28000174__8; var seen__11 any = lang.PersistentHashSet_EMPTY.Ref(); var out__12 any = lang.PersistentVector_EMPTY.Ref(); var G__28000172__13_ any = G__28000172__4_; var seen__14 any = seen__11; var out__15 any = out__12; _ = c__9; _ = more__10; L1: for { var vec__28000176__16 any = G__28000172__13_; var seq__28000177__17 any; var root_1342 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_1343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1342, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1344 lang.IFn

		if linked_1343 == nil { ifn_1344 = lang.IFn_Cast(root_1342) } else { ifn_1344 = nil }; var arg_1345 any = vec__28000176__16; if linked_1343 == nil { seq__28000177__17 = ifn_1344.Invoke_O__O(arg_1345) } else { seq__28000177__17 = linked_1343.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1342, arg_1345) }
//line :369:1
		var first__28000178__18 any; var root_1346 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_1347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1346, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1348 lang.IFn

		if linked_1347 == nil { ifn_1348 = lang.IFn_Cast(root_1346) } else { ifn_1348 = nil }; var arg_1349 any = seq__28000177__17; if linked_1347 == nil { first__28000178__18 = ifn_1348.Invoke_O__O(arg_1349) } else { first__28000178__18 = linked_1347.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1346, arg_1349) }
//line :369:1
		var seq__28000177__19 any; var root_1350 any = A_arbace_classes_env_A_const_57.GetRawRoot__O(); var linked_1351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1350, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1352 lang.IFn

		if linked_1351 == nil { ifn_1352 = lang.IFn_Cast(root_1350) } else { ifn_1352 = nil }; var arg_1353 any = seq__28000177__17; if linked_1351 == nil { seq__28000177__19 = ifn_1352.Invoke_O__O(arg_1353) } else { seq__28000177__19 = linked_1351.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1350, arg_1353) }
//line :369:1
		var c__20 any = first__28000178__18; var more__21 any = seq__28000177__19; var seen__22 any = seen__14; var out__23 any = out__15; var tmp1 any; var root_1354 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_1355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1354, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1356 lang.IFn


		if linked_1355 == nil { ifn_1356 = lang.IFn_Cast(root_1354) } else { ifn_1356 = nil }; var arg_1357 any = c__20; if linked_1355 == nil { tmp1 = ifn_1356.Invoke_O__O(arg_1357) } else { tmp1 = linked_1355.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1354, arg_1357) }; if jrt.J2g_Truth(tmp1) { return out__23 } else { var ms__24 any; var iter__1927001039__auto____24 any; var tmp2 any = A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A_New_O_O_O_O(seen__22, name__1, n__0, c__20); var tmp3 *jrt.Class
			var fncls__1522 /*line :372:1*/*jrt.Class = A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A_fn_class

			if fncls__1522 == nil { var fncls__1522d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A_fn_class = fncls__1522d; tmp3 = fncls__1522d } else { tmp3 = fncls__1522 }; iter__1927001039__auto____24 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp4 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____24); var tmp5 *lang.Keyword = A_arbace_classes_env_A_const_76; var tmp6 any; var root_1523 any = A_arbace_classes_env_A_const_95.GetRawRoot__O(); var linked_1524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1523, A_arbace_classes_env_info_BANG__A_fn_class); var ifn_1525 lang.IFn; if linked_1524 == nil { ifn_1525 = lang.IFn_Cast(root_1523) } else { ifn_1525 = nil }; var arg_1526 any = c__20; if linked_1524 == nil { tmp6 = ifn_1525.Invoke_O__O(arg_1526) } else { tmp6 = linked_1524.(*A_arbace_classes_env_info_BANG__A).Invoke_O_O__O(root_1523, arg_1526) }; ms__24 = tmp4.Invoke_O__O(tmp5.Invoke_O__O(tmp6))






			var tmp7 any; var root_1537 any = A_arbace_classes_env_A_const_87.GetRawRoot__O(); var linked_1538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1537, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1539 lang.IFn; if linked_1538 == nil { ifn_1539 = lang.IFn_Cast(root_1537) } else { ifn_1539 = nil }; var arg_1540 any = seen__22; var arg_1541 any; var root_1532 any = A_arbace_classes_env_A_const_79.GetRawRoot__O(); var linked_1533 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1532, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1534 lang.IFn; if linked_1533 == nil { ifn_1534 = lang.IFn_Cast(root_1532) } else { ifn_1534 = nil }; var arg_1535 any; var root_1527 any = A_arbace_classes_env_A_const_136.GetRawRoot__O(); var linked_1528 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1527, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_1529 lang.IFn; if linked_1528 == nil { ifn_1529 = lang.IFn_Cast(root_1527) } else { ifn_1529 = nil }; var arg_1530 any = A_arbace_classes_env_A_const_135.GetRawRoot__O(); var arg_1531 any = A_arbace_classes_env_A_const_60; if linked_1528 == nil { arg_1535 = ifn_1529.Invoke_O_O__O(arg_1530, arg_1531) } else { arg_1535 = linked_1528.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_1527, arg_1530, arg_1531) }; var arg_1536 any = ms__24; if linked_1533 == nil { arg_1541 = ifn_1534.Invoke_O_O__O(arg_1535, arg_1536) } else { arg_1541 = linked_1533.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1532, arg_1535, arg_1536) }; if linked_1538 == nil { tmp7 = ifn_1539.Invoke_O_O__O(arg_1540, arg_1541) } else { tmp7 = linked_1538.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1537, arg_1540, arg_1541) }; var tmp8 any = tmp7; var tmp9 any; var root_1542 any = A_arbace_classes_env_A_const_87.GetRawRoot__O(); var linked_1543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1542, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1544 lang.IFn; if linked_1543 == nil { ifn_1544 = lang.IFn_Cast(root_1542) } else { ifn_1544 = nil }; var arg_1545 any = out__23; var arg_1546 any = ms__24; if linked_1543 == nil { tmp9 = ifn_1544.Invoke_O_O__O(arg_1545, arg_1546) } else { tmp9 = linked_1543.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1542, arg_1545, arg_1546) }; G__28000172__13_, seen__14, out__15 = more__21, tmp8, tmp9; continue L1 } } }; /*line :369:1*/panic("j2g: unreachable") }




func A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :374:1
func (t *A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A) Ctor_O_O_O_O(c__seen, c__name, c__n, c__c any) { t.F_seen = c__seen; t.F_name = c__name; t.F_n = c__n; t.F_c = c__c }
//line :374:1
func (t *A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A) Invoke_O_O__O(self, s__28000180__1 any) any { var tmp1 any = A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A_New_O_O_O_O_O_O(self, t.F_seen, t.F_name, t.F_n, t.F_c, s__28000180__1); var tmp2 *jrt.Class; var fncls__1521 *jrt.Class = A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A_fn_class; if fncls__1521 == nil { var fncls__1521d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A_fn_class = fncls__1521d; tmp2 = fncls__1521d } else { tmp2 = fncls__1521 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :374:1
func A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :374:1
func (t *A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A) Ctor_O_O_O_O_O_O(c__iter__28000179, c__seen, c__name, c__n, c__c, c__s__28000180 any) { t.F_iter__28000179 = c__iter__28000179; t.F_seen = c__seen; t.F_name = c__name; t.F_n = c__n; t.F_c = c__c; t.F_s__28000180 = c__s__28000180 }
//line :374:1
func (t *A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A) Invoke_O__O(self any) any { { var s__28000180__1 any; var t_ any = t.F_s__28000180; t.F_s__28000180 = nil; s__28000180__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1358 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_1359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1358, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1360 lang.IFn; if linked_1359 == nil { ifn_1360 = lang.IFn_Cast(root_1358) } else { ifn_1360 = nil }; var arg_1361 any = s__28000180__1; if linked_1359 == nil { temp__1927000414__auto____2 = ifn_1360.Invoke_O__O(arg_1361) } else { temp__1927000414__auto____2 = linked_1359.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1358, arg_1361) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__28000180__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1362 any = A_arbace_classes_env_A_const_54.GetRawRoot__O(); var linked_1363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1362, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1364 lang.IFn; if linked_1363 == nil { ifn_1364 = lang.IFn_Cast(root_1362) } else { ifn_1364 = nil }; var arg_1365 any = s__28000180__3; if linked_1363 == nil { tmp1 = ifn_1364.Invoke_O__O(arg_1365) } else { tmp1 = linked_1363.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1362, arg_1365) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1366 any = A_arbace_classes_env_A_const_55.GetRawRoot__O(); var linked_1367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1366, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1368 lang.IFn; if linked_1367 == nil { ifn_1368 = lang.IFn_Cast(root_1366) } else { ifn_1368 = nil }; var arg_1369 any = s__28000180__3; if linked_1367 == nil { c__1927001037__auto____4 = ifn_1368.Invoke_O__O(arg_1369) } else { c__1927001037__auto____4 = linked_1367.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1366, arg_1369) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__28000182__6 any; var root_1370 any = A_arbace_classes_env_A_const_56.GetRawRoot__O(); var linked_1371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1370, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1372 lang.IFn; if linked_1371 == nil { ifn_1372 = lang.IFn_Cast(root_1370) } else { ifn_1372 = nil }; var arg_1373 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1371 == nil { b__28000182__6 = ifn_1372.Invoke_O__O(arg_1373) } else { b__28000182__6 = linked_1371.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1370, arg_1373) }; var tmp2 any = A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A_New_O_O_O_O_I_O_O(t.F_seen, t.F_name, t.F_n, t.F_c, size__1927001038__auto____5, b__28000182__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1422 *jrt.Class = A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A_fn_class; if fncls__1422 == nil { var fncls__1422d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A_fn_class = fncls__1422d; tmp3 = fncls__1422d } else { tmp3 = fncls__1422 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1431 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_1432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1431, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1433 lang.IFn; if linked_1432 == nil { ifn_1433 = lang.IFn_Cast(root_1431) } else { ifn_1433 = nil }; var arg_1434 any; var root_1423 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_1424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1423, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1425 lang.IFn; if linked_1424 == nil { ifn_1425 = lang.IFn_Cast(root_1423) } else { ifn_1425 = nil }; var arg_1426 any = b__28000182__6; if linked_1424 == nil { arg_1434 = ifn_1425.Invoke_O__O(arg_1426) } else { arg_1434 = linked_1424.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1423, arg_1426) }; var arg_1435 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__28000179); var tmp5 any; var root_1427 any = A_arbace_classes_env_A_const_70.GetRawRoot__O(); var linked_1428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1427, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1429 lang.IFn; if linked_1428 == nil { ifn_1429 = lang.IFn_Cast(root_1427) } else { ifn_1429 = nil }; var arg_1430 any = s__28000180__3; if linked_1428 == nil { tmp5 = ifn_1429.Invoke_O__O(arg_1430) } else { tmp5 = linked_1428.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1427, arg_1430) }; arg_1435 = tmp4.Invoke_O__O(tmp5); if linked_1432 == nil { return ifn_1433.Invoke_O_O__O(arg_1434, arg_1435) } else { return linked_1432.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1431, arg_1434, arg_1435) } } else { var root_1440 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_1441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1440, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1442 lang.IFn; if linked_1441 == nil { ifn_1442 = lang.IFn_Cast(root_1440) } else { ifn_1442 = nil }; var arg_1443 any; var root_1436 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_1437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1436, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1438 lang.IFn; if linked_1437 == nil { ifn_1438 = lang.IFn_Cast(root_1436) } else { ifn_1438 = nil }; var arg_1439 any = b__28000182__6; if linked_1437 == nil { arg_1443 = ifn_1438.Invoke_O__O(arg_1439) } else { arg_1443 = linked_1437.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1436, arg_1439) }; var arg_1444 any; if linked_1441 == nil { return ifn_1442.Invoke_O_O__O(arg_1443, arg_1444) } else { return linked_1441.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1440, arg_1443, arg_1444) } } } else { var m__4 any; var root_1445 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_1446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1445, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1447 lang.IFn; if linked_1446 == nil { ifn_1447 = lang.IFn_Cast(root_1445) } else { ifn_1447 = nil }; var arg_1448 any = s__28000180__3; if linked_1446 == nil { m__4 = ifn_1447.Invoke_O__O(arg_1448) } else { m__4 = linked_1446.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1445, arg_1448) }; var tmp6 any = t.F_name; if lang.Util_Equiv_O_O__Z_NoInit(tmp6, A_arbace_classes_env_A_const_42.Invoke_O__O(m__4)) { var tmp7 any; var root_1454 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_1455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1454, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1456 lang.IFn

	if linked_1455 == nil { ifn_1456 = lang.IFn_Cast(root_1454) } else { ifn_1456 = nil }; var arg_1457 any; var root_1449 any = A_arbace_classes_env_A_const_120.GetRawRoot__O(); var linked_1450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1449, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1451 lang.IFn; if linked_1450 == nil { ifn_1451 = lang.IFn_Cast(root_1449) } else { ifn_1451 = nil }; var arg_1452 any = A_arbace_classes_env_A_const_43.Invoke_O__O(m__4); var arg_1453 any = A_arbace_classes_env_A_const_133; if linked_1450 == nil { arg_1457 = ifn_1451.Invoke_O_O__O(arg_1452, arg_1453) } else { arg_1457 = linked_1450.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1449, arg_1452, arg_1453) }; if linked_1455 == nil { tmp7 = ifn_1456.Invoke_O__O(arg_1457) } else { tmp7 = linked_1455.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1454, arg_1457) }
//line :374:1
	if jrt.J2g_Truth(tmp7) { var tmp8 any; var or__1927000174__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(t.F_c, t.F_n)


		if or__1927000174__auto____5 { tmp8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var root_1463 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_1464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1463, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1465 lang.IFn; if linked_1464 == nil { ifn_1465 = lang.IFn_Cast(root_1463) } else { ifn_1465 = nil }; var arg_1466 any; var root_1458 any = A_arbace_classes_env_A_const_120.GetRawRoot__O(); var linked_1459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1458, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1460 lang.IFn; if linked_1459 == nil { ifn_1460 = lang.IFn_Cast(root_1458) } else { ifn_1460 = nil }; var arg_1461 any = A_arbace_classes_env_A_const_43.Invoke_O__O(m__4); var arg_1462 any = A_arbace_classes_env_A_const_122; if linked_1459 == nil { arg_1466 = ifn_1460.Invoke_O_O__O(arg_1461, arg_1462) } else { arg_1466 = linked_1459.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1458, arg_1461, arg_1462) }; if linked_1464 == nil { tmp8 = ifn_1465.Invoke_O__O(arg_1466) } else { tmp8 = linked_1464.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1463, arg_1466) } }
//line :374:1
		if jrt.J2g_Truth(tmp8) { var tmp9 any; var or__1927000174__auto____5_2 bool = lang.Util_Equiv_O_O__Z_NoInit(t.F_c, t.F_n)



			if or__1927000174__auto____5_2 { tmp9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5_2).Ref() } else { var or__1927000174__auto____6 any; var root_1471 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_1472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1471, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1473 lang.IFn; if linked_1472 == nil { ifn_1473 = lang.IFn_Cast(root_1471) } else { ifn_1473 = nil }; var arg_1474 any; var root_1467 any = A_arbace_classes_env_A_const_109.GetRawRoot__O(); var linked_1468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1467, A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_1469 lang.IFn; if linked_1468 == nil { ifn_1469 = lang.IFn_Cast(root_1467) } else { ifn_1469 = nil }; var arg_1470 any = t.F_c; if linked_1468 == nil { arg_1474 = ifn_1469.Invoke_O__O(arg_1470) } else { arg_1474 = linked_1468.(*A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_1467, arg_1470) }; if linked_1472 == nil { or__1927000174__auto____6 = ifn_1473.Invoke_O__O(arg_1474) } else { or__1927000174__auto____6 = linked_1472.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1471, arg_1474) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp9 = or__1927000174__auto____6 } else { var root_1480 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_1481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1480, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1482 lang.IFn; if linked_1481 == nil { ifn_1482 = lang.IFn_Cast(root_1480) } else { ifn_1482 = nil }; var arg_1483 any; var root_1475 any = A_arbace_classes_env_A_const_120.GetRawRoot__O(); var linked_1476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1475, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1477 lang.IFn; if linked_1476 == nil { ifn_1477 = lang.IFn_Cast(root_1475) } else { ifn_1477 = nil }; var arg_1478 any = A_arbace_classes_env_A_const_43.Invoke_O__O(m__4); var arg_1479 any = A_arbace_classes_env_A_const_134; if linked_1476 == nil { arg_1483 = ifn_1477.Invoke_O_O__O(arg_1478, arg_1479) } else { arg_1483 = linked_1476.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1475, arg_1478, arg_1479) }; if linked_1481 == nil { tmp9 = ifn_1482.Invoke_O__O(arg_1483) } else { tmp9 = linked_1481.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1480, arg_1483) } } }
//line :374:1
			if jrt.J2g_Truth(tmp9) { var tmp10 any; var root_1488 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_1489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1488, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1490 lang.IFn




				if linked_1489 == nil { ifn_1490 = lang.IFn_Cast(root_1488) } else { ifn_1490 = nil }; var arg_1491 any; var tmp11 lang.IFn = lang.IFn_Cast(t.F_seen); var tmp12 any; var root_1484 any = A_arbace_classes_env_A_const_135.GetRawRoot__O(); var linked_1485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1484, A_arbace_classes_env_params_key_A_fn_class); var ifn_1486 lang.IFn; if linked_1485 == nil { ifn_1486 = lang.IFn_Cast(root_1484) } else { ifn_1486 = nil }; var arg_1487 any = A_arbace_classes_env_A_const_60.Invoke_O__O(m__4); if linked_1485 == nil { tmp12 = ifn_1486.Invoke_O__O(arg_1487) } else { tmp12 = linked_1485.(*A_arbace_classes_env_params_key_A).Invoke_O_O__O(root_1484, arg_1487) }; arg_1491 = tmp11.Invoke_O__O(tmp12); if linked_1489 == nil { tmp10 = ifn_1490.Invoke_O__O(arg_1491) } else { tmp10 = linked_1489.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1488, arg_1491) }
//line :374:1
				if jrt.J2g_Truth(tmp10) { var root_1496 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_1497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1496, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1498 lang.IFn; if linked_1497 == nil { ifn_1498 = lang.IFn_Cast(root_1496) } else { ifn_1498 = nil }; var arg_1499 any = m__4; var arg_1500 any; var tmp13 lang.IFn = lang.IFn_Cast(t.F_iter__28000179); var tmp14 any; var root_1492 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_1493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1492, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1494 lang.IFn; if linked_1493 == nil { ifn_1494 = lang.IFn_Cast(root_1492) } else { ifn_1494 = nil }; var arg_1495 any = s__28000180__3; if linked_1493 == nil { tmp14 = ifn_1494.Invoke_O__O(arg_1495) } else { tmp14 = linked_1493.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1492, arg_1495) }; arg_1500 = tmp13.Invoke_O__O(tmp14); if linked_1497 == nil { return ifn_1498.Invoke_O_O__O(arg_1499, arg_1500) } else { return linked_1497.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1496, arg_1499, arg_1500) } } else { var tmp15 any; var root_1501 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_1502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1501, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1503 lang.IFn; if linked_1502 == nil { ifn_1503 = lang.IFn_Cast(root_1501) } else { ifn_1503 = nil }; var arg_1504 any = s__28000180__3; if linked_1502 == nil { tmp15 = ifn_1503.Invoke_O__O(arg_1504) } else { tmp15 = linked_1502.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1501, arg_1504) }; s__28000180__1 = tmp15; continue L1 } } else { var tmp16 any; var root_1505 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_1506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1505, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1507 lang.IFn; if linked_1506 == nil { ifn_1507 = lang.IFn_Cast(root_1505) } else { ifn_1507 = nil }; var arg_1508 any = s__28000180__3; if linked_1506 == nil { tmp16 = ifn_1507.Invoke_O__O(arg_1508) } else { tmp16 = linked_1506.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1505, arg_1508) }; s__28000180__1 = tmp16; continue L1 } } else { var tmp17 any; var root_1509 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_1510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1509, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1511 lang.IFn; if linked_1510 == nil { ifn_1511 = lang.IFn_Cast(root_1509) } else { ifn_1511 = nil }; var arg_1512 any = s__28000180__3; if linked_1510 == nil { tmp17 = ifn_1511.Invoke_O__O(arg_1512) } else { tmp17 = linked_1510.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1509, arg_1512) }; s__28000180__1 = tmp17; continue L1 } } else { var tmp18 any; var root_1513 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_1514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1513, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1515 lang.IFn; if linked_1514 == nil { ifn_1515 = lang.IFn_Cast(root_1513) } else { ifn_1515 = nil }; var arg_1516 any = s__28000180__3; if linked_1514 == nil { tmp18 = ifn_1515.Invoke_O__O(arg_1516) } else { tmp18 = linked_1514.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1513, arg_1516) }; s__28000180__1 = tmp18; continue L1 } } else { var tmp19 any; var root_1517 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_1518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1517, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1519 lang.IFn; if linked_1518 == nil { ifn_1519 = lang.IFn_Cast(root_1517) } else { ifn_1519 = nil }; var arg_1520 any = s__28000180__3; if linked_1518 == nil { tmp19 = ifn_1519.Invoke_O__O(arg_1520) } else { tmp19 = linked_1518.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1517, arg_1520) }; s__28000180__1 = tmp19; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :374:1
func A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A_New_O_O_O_O_I_O_O(p0, p1, p2, p3 any, p4 int32, p5, p6 any) *A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A{}; t.Ctor_O_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :374:1
func (t *A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A) Ctor_O_O_O_O_I_O_O(c__seen, c__name, c__n, c__c any, c__size__1927001038__auto__ int32, c__b__28000182, c__c__1927001037__auto__ any) { t.F_seen = c__seen; t.F_name = c__name; t.F_n = c__n; t.F_c = c__c; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__28000182 = c__b__28000182; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :374:1
func (t *A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A) Invoke_O__O(self any) any { { var i__28000181__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__28000181__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__28000181__1)); var tmp2 any = t.F_name; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_classes_env_A_const_42.Invoke_O__O(m__2)) { var tmp3 any; var root_1379 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_1380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1379, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1381 lang.IFn

	if linked_1380 == nil { ifn_1381 = lang.IFn_Cast(root_1379) } else { ifn_1381 = nil }; var arg_1382 any; var root_1374 any = A_arbace_classes_env_A_const_120.GetRawRoot__O(); var linked_1375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1374, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1376 lang.IFn; if linked_1375 == nil { ifn_1376 = lang.IFn_Cast(root_1374) } else { ifn_1376 = nil }; var arg_1377 any = A_arbace_classes_env_A_const_43.Invoke_O__O(m__2); var arg_1378 any = A_arbace_classes_env_A_const_133; if linked_1375 == nil { arg_1382 = ifn_1376.Invoke_O_O__O(arg_1377, arg_1378) } else { arg_1382 = linked_1375.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1374, arg_1377, arg_1378) }; if linked_1380 == nil { tmp3 = ifn_1381.Invoke_O__O(arg_1382) } else { tmp3 = linked_1380.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1379, arg_1382) }
//line :374:1
	if jrt.J2g_Truth(tmp3) { var tmp4 any; var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(t.F_c, t.F_n)


		if or__1927000174__auto____3 { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var root_1388 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_1389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1388, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1390 lang.IFn; if linked_1389 == nil { ifn_1390 = lang.IFn_Cast(root_1388) } else { ifn_1390 = nil }; var arg_1391 any; var root_1383 any = A_arbace_classes_env_A_const_120.GetRawRoot__O(); var linked_1384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1383, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1385 lang.IFn; if linked_1384 == nil { ifn_1385 = lang.IFn_Cast(root_1383) } else { ifn_1385 = nil }; var arg_1386 any = A_arbace_classes_env_A_const_43.Invoke_O__O(m__2); var arg_1387 any = A_arbace_classes_env_A_const_122; if linked_1384 == nil { arg_1391 = ifn_1385.Invoke_O_O__O(arg_1386, arg_1387) } else { arg_1391 = linked_1384.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1383, arg_1386, arg_1387) }; if linked_1389 == nil { tmp4 = ifn_1390.Invoke_O__O(arg_1391) } else { tmp4 = linked_1389.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1388, arg_1391) } }
//line :374:1
		if jrt.J2g_Truth(tmp4) { var tmp5 any; var or__1927000174__auto____3_2 bool = lang.Util_Equiv_O_O__Z_NoInit(t.F_c, t.F_n)



			if or__1927000174__auto____3_2 { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3_2).Ref() } else { var or__1927000174__auto____4 any; var root_1396 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_1397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1396, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1398 lang.IFn; if linked_1397 == nil { ifn_1398 = lang.IFn_Cast(root_1396) } else { ifn_1398 = nil }; var arg_1399 any; var root_1392 any = A_arbace_classes_env_A_const_109.GetRawRoot__O(); var linked_1393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1392, A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_1394 lang.IFn; if linked_1393 == nil { ifn_1394 = lang.IFn_Cast(root_1392) } else { ifn_1394 = nil }; var arg_1395 any = t.F_c; if linked_1393 == nil { arg_1399 = ifn_1394.Invoke_O__O(arg_1395) } else { arg_1399 = linked_1393.(*A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_1392, arg_1395) }; if linked_1397 == nil { or__1927000174__auto____4 = ifn_1398.Invoke_O__O(arg_1399) } else { or__1927000174__auto____4 = linked_1397.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1396, arg_1399) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp5 = or__1927000174__auto____4 } else { var root_1405 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_1406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1405, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1407 lang.IFn; if linked_1406 == nil { ifn_1407 = lang.IFn_Cast(root_1405) } else { ifn_1407 = nil }; var arg_1408 any; var root_1400 any = A_arbace_classes_env_A_const_120.GetRawRoot__O(); var linked_1401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1400, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1402 lang.IFn; if linked_1401 == nil { ifn_1402 = lang.IFn_Cast(root_1400) } else { ifn_1402 = nil }; var arg_1403 any = A_arbace_classes_env_A_const_43.Invoke_O__O(m__2); var arg_1404 any = A_arbace_classes_env_A_const_134; if linked_1401 == nil { arg_1408 = ifn_1402.Invoke_O_O__O(arg_1403, arg_1404) } else { arg_1408 = linked_1401.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1400, arg_1403, arg_1404) }; if linked_1406 == nil { tmp5 = ifn_1407.Invoke_O__O(arg_1408) } else { tmp5 = linked_1406.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1405, arg_1408) } } }
//line :374:1
			if jrt.J2g_Truth(tmp5) { var tmp6 any; var root_1413 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_1414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1413, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1415 lang.IFn




				if linked_1414 == nil { ifn_1415 = lang.IFn_Cast(root_1413) } else { ifn_1415 = nil }; var arg_1416 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_seen); var tmp8 any; var root_1409 any = A_arbace_classes_env_A_const_135.GetRawRoot__O(); var linked_1410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1409, A_arbace_classes_env_params_key_A_fn_class); var ifn_1411 lang.IFn; if linked_1410 == nil { ifn_1411 = lang.IFn_Cast(root_1409) } else { ifn_1411 = nil }; var arg_1412 any = A_arbace_classes_env_A_const_60.Invoke_O__O(m__2); if linked_1410 == nil { tmp8 = ifn_1411.Invoke_O__O(arg_1412) } else { tmp8 = linked_1410.(*A_arbace_classes_env_params_key_A).Invoke_O_O__O(root_1409, arg_1412) }; arg_1416 = tmp7.Invoke_O__O(tmp8); if linked_1414 == nil { tmp6 = ifn_1415.Invoke_O__O(arg_1416) } else { tmp6 = linked_1414.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1413, arg_1416) }
//line :374:1
				if jrt.J2g_Truth(tmp6) { var root_1417 any = A_arbace_classes_env_A_const_62.GetRawRoot__O(); var linked_1418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1417, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1419 lang.IFn; if linked_1418 == nil { ifn_1419 = lang.IFn_Cast(root_1417) } else { ifn_1419 = nil }; var arg_1420 any = t.F_b__28000182; var arg_1421 any = m__2; if linked_1418 == nil { ifn_1419.Invoke_O_O__O(arg_1420, arg_1421) } else { linked_1418.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1417, arg_1420, arg_1421) }; i__28000181__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000181__1); continue L1 } else { i__28000181__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000181__1); continue L1 } } else { i__28000181__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000181__1); continue L1 } } else { i__28000181__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000181__1); continue L1 } } else { i__28000181__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000181__1); continue L1 } } else { i__28000181__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000181__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_classes_env_member_methods_A_New() *A_arbace_classes_env_member_methods_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_member_methods_A{}; t.Ctor(); return t }
//line :383:1
func (t *A_arbace_classes_env_member_methods_A) Ctor() {}
//line :383:1
func (t *A_arbace_classes_env_member_methods_A) Invoke_O_O_O__O(self, n__0, name__1 any) any {



	var tmp1 any; var root_1555 any = A_arbace_classes_env_A_const_39.GetRawRoot__O(); var linked_1556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1555, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1557 lang.IFn; if linked_1556 == nil { ifn_1557 = lang.IFn_Cast(root_1555) } else { ifn_1557 = nil }; var arg_1558 any; var and__1927000168__auto____3 any; var root_1547 any = A_arbace_classes_env_A_const_137.GetRawRoot__O(); var linked_1548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1547, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1549 lang.IFn; if linked_1548 == nil { ifn_1549 = lang.IFn_Cast(root_1547) } else { ifn_1549 = nil }; var arg_1550 any = n__0; if linked_1548 == nil { and__1927000168__auto____3 = ifn_1549.Invoke_O__O(arg_1550) } else { and__1927000168__auto____3 = linked_1548.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1547, arg_1550) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_1551 any = A_arbace_classes_env_A_const_137.GetRawRoot__O(); var linked_1552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1551, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1553 lang.IFn; if linked_1552 == nil { ifn_1553 = lang.IFn_Cast(root_1551) } else { ifn_1553 = nil }; var arg_1554 any = name__1; if linked_1552 == nil { arg_1558 = ifn_1553.Invoke_O__O(arg_1554) } else { arg_1558 = linked_1552.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1551, arg_1554) } } else { arg_1558 = and__1927000168__auto____3 }; if linked_1556 == nil { tmp1 = ifn_1557.Invoke_O__O(arg_1558) } else { tmp1 = linked_1556.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1555, arg_1558) }; if jrt.J2g_Truth(tmp1) {
		var root_1563 any = A_arbace_classes_env_A_const_138.GetRawRoot__O(); var linked_1564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1563, A_arbace_classes_env_member_methods_STAR__A_fn_class); var ifn_1565 lang.IFn; if linked_1564 == nil { ifn_1565 = lang.IFn_Cast(root_1563) } else { ifn_1565 = nil }; var arg_1566 any = n__0; var arg_1567 any = name__1; var arg_1568 any; var root_1559 any = A_arbace_classes_env_A_const_139.GetRawRoot__O(); var linked_1560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1559, A_arbace_classes_env_all_supertypes_A_fn_class); var ifn_1561 lang.IFn; if linked_1560 == nil { ifn_1561 = lang.IFn_Cast(root_1559) } else { ifn_1561 = nil }; var arg_1562 any = n__0; if linked_1560 == nil { arg_1568 = ifn_1561.Invoke_O__O(arg_1562) } else { arg_1568 = linked_1560.(*A_arbace_classes_env_all_supertypes_A).Invoke_O_O__O(root_1559, arg_1562) }; if linked_1564 == nil { return ifn_1565.Invoke_O_O_O__O(arg_1566, arg_1567, arg_1568) } else { return linked_1564.(*A_arbace_classes_env_member_methods_STAR__A).Invoke_O_O_O_O__O(root_1563, arg_1566, arg_1567, arg_1568) } } else {
//line :387:1
			var by_name__3 any; var or__1927000174__auto____3 any = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_140.GetRawRoot__O())).Get_O__O(n__0)


			if jrt.J2g_Truth(or__1927000174__auto____3) { by_name__3 = or__1927000174__auto____3 } else {
				jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_140.GetRawRoot__O())).PutIfAbsent_O_O__O(n__0, jrt.ConcurrentHashMap_New())
				by_name__3 = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_140.GetRawRoot__O())).Get_O__O(n__0) }
//line :387:1
			var e__4 any = jrt.NN(jrt.ConcurrentHashMap_Cast(by_name__3)).Get_O__O(name__1); var tmp2 any
			var and__1927000168__auto____5 any = e__4





			if jrt.J2g_Truth(and__1927000168__auto____5) { var root_1569 any = A_arbace_classes_env_A_const_128.GetRawRoot__O(); var linked_1570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1569, A_arbace_classes_env_same_infos_QMARK__A_fn_class); var ifn_1571 lang.IFn; if linked_1570 == nil { ifn_1571 = lang.IFn_Cast(root_1569) } else { ifn_1571 = nil }; var arg_1572 any = lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](e__4, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(1)); var arg_1573 any = lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](e__4, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(2)); if linked_1570 == nil { tmp2 = ifn_1571.Invoke_O_O__O(arg_1572, arg_1573) } else { tmp2 = linked_1570.(*A_arbace_classes_env_same_infos_QMARK__A).Invoke_O_O_O__O(root_1569, arg_1572, arg_1573) } } else { tmp2 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp2) {
				return lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](e__4, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0)) } else {
//line :394:1
					var sups__5 any; var root_1574 any = A_arbace_classes_env_A_const_139.GetRawRoot__O(); var linked_1575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1574, A_arbace_classes_env_all_supertypes_A_fn_class); var ifn_1576 lang.IFn

					if linked_1575 == nil { ifn_1576 = lang.IFn_Cast(root_1574) } else { ifn_1576 = nil }; var arg_1577 any = n__0; if linked_1575 == nil { sups__5 = ifn_1576.Invoke_O__O(arg_1577) } else { sups__5 = linked_1575.(*A_arbace_classes_env_all_supertypes_A).Invoke_O_O__O(root_1574, arg_1577) }
//line :394:1
					var infos__6 any; var root_1578 any = A_arbace_classes_env_A_const_130.GetRawRoot__O(); var linked_1579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1578, A_arbace_classes_env_infos_now_A_fn_class); var ifn_1580 lang.IFn


					if linked_1579 == nil { ifn_1580 = lang.IFn_Cast(root_1578) } else { ifn_1580 = nil }; var arg_1581 any = sups__5; if linked_1579 == nil { infos__6 = ifn_1580.Invoke_O__O(arg_1581) } else { infos__6 = linked_1579.(*A_arbace_classes_env_infos_now_A).Invoke_O_O__O(root_1578, arg_1581) }
//line :394:1
					var r__7 any; var root_1582 any = A_arbace_classes_env_A_const_138.GetRawRoot__O(); var linked_1583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1582, A_arbace_classes_env_member_methods_STAR__A_fn_class); var ifn_1584 lang.IFn



					if linked_1583 == nil { ifn_1584 = lang.IFn_Cast(root_1582) } else { ifn_1584 = nil }; var arg_1585 any = n__0; var arg_1586 any = name__1; var arg_1587 any = sups__5; if linked_1583 == nil { r__7 = ifn_1584.Invoke_O_O_O__O(arg_1585, arg_1586, arg_1587) } else { r__7 = linked_1583.(*A_arbace_classes_env_member_methods_STAR__A).Invoke_O_O_O_O__O(root_1582, arg_1585, arg_1586, arg_1587)
					}
					var tmp3 any; var and__1927000168__auto____8 bool; var tmp4 any; var root_1588 any = A_arbace_classes_env_A_const_139.GetRawRoot__O(); var linked_1589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1588, A_arbace_classes_env_all_supertypes_A_fn_class); var ifn_1590 lang.IFn; if linked_1589 == nil { ifn_1590 = lang.IFn_Cast(root_1588) } else { ifn_1590 = nil }; var arg_1591 any = n__0; if linked_1589 == nil { tmp4 = ifn_1590.Invoke_O__O(arg_1591) } else { tmp4 = linked_1589.(*A_arbace_classes_env_all_supertypes_A).Invoke_O_O__O(root_1588, arg_1591) }; and__1927000168__auto____8 = lang.Util_Equiv_O_O__Z_NoInit(sups__5, tmp4); if and__1927000168__auto____8 { var root_1592 any = A_arbace_classes_env_A_const_128.GetRawRoot__O(); var linked_1593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1592, A_arbace_classes_env_same_infos_QMARK__A_fn_class); var ifn_1594 lang.IFn; if linked_1593 == nil { ifn_1594 = lang.IFn_Cast(root_1592) } else { ifn_1594 = nil }; var arg_1595 any = sups__5; var arg_1596 any = infos__6; if linked_1593 == nil { tmp3 = ifn_1594.Invoke_O_O__O(arg_1595, arg_1596) } else { tmp3 = linked_1593.(*A_arbace_classes_env_same_infos_QMARK__A).Invoke_O_O_O__O(root_1592, arg_1595, arg_1596) } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() }; if jrt.J2g_Truth(tmp3) {
						jrt.NN(jrt.ConcurrentHashMap_Cast(by_name__3)).Put_O_O__O(name__1, lang.RT_Object_array_O__O1_NoInit(lang.Tuple_Create_O_O_O__IPersistentVector(r__7, sups__5, infos__6)).Ref()) }
//line :394:1
					return r__7
				}
		}
}






func A_arbace_classes_env_constructors_A_New() *A_arbace_classes_env_constructors_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_constructors_A{}; t.Ctor(); return t }
//line :404:1
func (t *A_arbace_classes_env_constructors_A) Ctor() {}
//line :404:1
func (t *A_arbace_classes_env_constructors_A) Invoke_O_O__O(self, n__0 any) any {
	var root_1602 any = A_arbace_classes_env_A_const_86.GetRawRoot__O(); var linked_1603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1602, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1604 lang.IFn; if linked_1603 == nil { ifn_1604 = lang.IFn_Cast(root_1602) } else { ifn_1604 = nil }; var arg_1605 any; var tmp1 any = A_arbace_classes_env_constructors_fn__28000192_A_New(); var tmp2 *jrt.Class; var fncls__1597 *jrt.Class = A_arbace_classes_env_constructors_fn__28000192_A_fn_class; if fncls__1597 == nil { var fncls__1597d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_classes_env_constructors_fn__28000192_A_fn_class = fncls__1597d; tmp2 = fncls__1597d } else { tmp2 = fncls__1597 }; arg_1605 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1606 any; var tmp3 *lang.Keyword = A_arbace_classes_env_A_const_76; var tmp4 any; var root_1598 any = A_arbace_classes_env_A_const_95.GetRawRoot__O(); var linked_1599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1598, A_arbace_classes_env_info_BANG__A_fn_class); var ifn_1600 lang.IFn; if linked_1599 == nil { ifn_1600 = lang.IFn_Cast(root_1598) } else { ifn_1600 = nil }; var arg_1601 any = n__0; if linked_1599 == nil { tmp4 = ifn_1600.Invoke_O__O(arg_1601) } else { tmp4 = linked_1599.(*A_arbace_classes_env_info_BANG__A).Invoke_O_O__O(root_1598, arg_1601) }; arg_1606 = tmp3.Invoke_O__O(tmp4); if linked_1603 == nil { return ifn_1604.Invoke_O_O__O(arg_1605, arg_1606) } else { return linked_1603.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1602, arg_1605, arg_1606) } }
//line :405:1
func A_arbace_classes_env_constructors_fn__28000192_A_New() *A_arbace_classes_env_constructors_fn__28000192_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_constructors_fn__28000192_A{}; t.Ctor(); return t }
//line :405:1
func (t *A_arbace_classes_env_constructors_fn__28000192_A) Ctor() {}
//line :405:1
func (t *A_arbace_classes_env_constructors_fn__28000192_A) Invoke_O_O__O(self, p1__28000191_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_13, A_arbace_classes_env_A_const_42.Invoke_O__O(p1__28000191_SHARP___1))).Ref() }








































































































type A_arbace_classes_env_A struct{ jrt.Object }

var A_arbace_classes_env_A_const_pool *jrt.RefArray

var A_arbace_classes_env_A_const_0 *lang.Var

var A_arbace_classes_env_A_const_1 any

var A_arbace_classes_env_A_const_2 *lang.Var

var A_arbace_classes_env_A_const_3 any

var A_arbace_classes_env_A_const_4 any

var A_arbace_classes_env_A_const_5 any

var A_arbace_classes_env_A_const_6 any

var A_arbace_classes_env_A_const_7 *lang.Var

var A_arbace_classes_env_A_const_8 *lang.Var

var A_arbace_classes_env_A_const_9 *lang.Var

var A_arbace_classes_env_A_const_10 *lang.Var

var A_arbace_classes_env_A_const_11 any

var A_arbace_classes_env_A_const_12 *lang.Var

var A_arbace_classes_env_A_const_13 *lang.Var

var A_arbace_classes_env_A_const_14 *lang.Var

var A_arbace_classes_env_A_const_15 *lang.Var

var A_arbace_classes_env_A_const_16 *lang.Var

var A_arbace_classes_env_A_const_17 *lang.Var

var A_arbace_classes_env_A_const_18 *lang.Var

var A_arbace_classes_env_A_const_19 *lang.Var

var A_arbace_classes_env_A_const_20 *lang.Var

var A_arbace_classes_env_A_const_21 *lang.Var

var A_arbace_classes_env_A_const_22 *lang.Keyword

var A_arbace_classes_env_A_const_23 *lang.Var

var A_arbace_classes_env_A_const_24 *lang.Var

var A_arbace_classes_env_A_const_25 *lang.Var

var A_arbace_classes_env_A_const_26 *lang.Var

var A_arbace_classes_env_A_const_27 *lang.Var

var A_arbace_classes_env_A_const_28 *lang.Var

var A_arbace_classes_env_A_const_29 *lang.Var

var A_arbace_classes_env_A_const_30 *lang.Var

var A_arbace_classes_env_A_const_31 *lang.Keyword

var A_arbace_classes_env_A_const_32 *lang.Keyword

var A_arbace_classes_env_A_const_33 *jrt.Class

var A_arbace_classes_env_A_const_34 *lang.Var

var A_arbace_classes_env_A_const_35 *lang.Var

var A_arbace_classes_env_A_const_36 *lang.Var

var A_arbace_classes_env_A_const_37 any

var A_arbace_classes_env_A_const_38 any

var A_arbace_classes_env_A_const_39 *lang.Var

var A_arbace_classes_env_A_const_40 *lang.Var

var A_arbace_classes_env_A_const_41 *lang.Var

var A_arbace_classes_env_A_const_42 *lang.Keyword

var A_arbace_classes_env_A_const_43 *lang.Keyword

var A_arbace_classes_env_A_const_44 *lang.Keyword

var A_arbace_classes_env_A_const_45 *lang.Keyword

var A_arbace_classes_env_A_const_46 *lang.Keyword

var A_arbace_classes_env_A_const_47 *lang.Var

var A_arbace_classes_env_A_const_48 *lang.Keyword

var A_arbace_classes_env_A_const_49 *lang.Keyword

var A_arbace_classes_env_A_const_50 *lang.Keyword

var A_arbace_classes_env_A_const_51 *lang.Var

var A_arbace_classes_env_A_const_52 *lang.Var

var A_arbace_classes_env_A_const_53 *lang.Var

var A_arbace_classes_env_A_const_54 *lang.Var

var A_arbace_classes_env_A_const_55 *lang.Var

var A_arbace_classes_env_A_const_56 *lang.Var

var A_arbace_classes_env_A_const_57 *lang.Var

var A_arbace_classes_env_A_const_58 *lang.Var

var A_arbace_classes_env_A_const_59 *lang.Var

var A_arbace_classes_env_A_const_60 *lang.Keyword

var A_arbace_classes_env_A_const_61 *lang.Keyword

var A_arbace_classes_env_A_const_62 *lang.Var

var A_arbace_classes_env_A_const_63 *lang.Keyword

var A_arbace_classes_env_A_const_64 *lang.Keyword

var A_arbace_classes_env_A_const_65 *lang.Var

var A_arbace_classes_env_A_const_66 *lang.Var

var A_arbace_classes_env_A_const_67 *lang.Var

var A_arbace_classes_env_A_const_68 *lang.Var

var A_arbace_classes_env_A_const_69 *lang.Var

var A_arbace_classes_env_A_const_70 *lang.Var

var A_arbace_classes_env_A_const_71 *lang.Var

var A_arbace_classes_env_A_const_72 *lang.Var

var A_arbace_classes_env_A_const_73 *lang.Var

var A_arbace_classes_env_A_const_74 *lang.Keyword

var A_arbace_classes_env_A_const_75 *lang.Var

var A_arbace_classes_env_A_const_76 *lang.Keyword

var A_arbace_classes_env_A_const_77 *lang.Var

var A_arbace_classes_env_A_const_78 *lang.Var

var A_arbace_classes_env_A_const_79 *lang.Var

var A_arbace_classes_env_A_const_80 *lang.Keyword

var A_arbace_classes_env_A_const_81 *lang.Keyword

var A_arbace_classes_env_A_const_82 *lang.Var

var A_arbace_classes_env_A_const_83 *lang.Keyword

var A_arbace_classes_env_A_const_84 *lang.Var

var A_arbace_classes_env_A_const_85 *lang.Var

var A_arbace_classes_env_A_const_86 *lang.Var

var A_arbace_classes_env_A_const_87 *lang.Var

var A_arbace_classes_env_A_const_88 any

var A_arbace_classes_env_A_const_89 *lang.Var

var A_arbace_classes_env_A_const_90 *lang.Keyword

var A_arbace_classes_env_A_const_91 *lang.Var

var A_arbace_classes_env_A_const_92 *lang.Var

var A_arbace_classes_env_A_const_93 *lang.Var

var A_arbace_classes_env_A_const_94 *lang.Var

var A_arbace_classes_env_A_const_95 *lang.Var

var A_arbace_classes_env_A_const_96 *lang.Var

var A_arbace_classes_env_A_const_97 *lang.Var

var A_arbace_classes_env_A_const_98 *lang.Keyword

var A_arbace_classes_env_A_const_99 *lang.Var

var A_arbace_classes_env_A_const_100 *lang.Var

var A_arbace_classes_env_A_const_101 *lang.Var

var A_arbace_classes_env_A_const_102 *lang.Var

var A_arbace_classes_env_A_const_103 *lang.Var

var A_arbace_classes_env_A_const_104 *lang.Keyword

var A_arbace_classes_env_A_const_105 any

var A_arbace_classes_env_A_const_106 *lang.Var

var A_arbace_classes_env_A_const_107 *lang.Var

var A_arbace_classes_env_A_const_108 *lang.Var

var A_arbace_classes_env_A_const_109 *lang.Var

var A_arbace_classes_env_A_const_110 *lang.Var

var A_arbace_classes_env_A_const_111 *lang.Var

var A_arbace_classes_env_A_const_112 *lang.Var

var A_arbace_classes_env_A_const_113 *lang.Var

var A_arbace_classes_env_A_const_114 *lang.Var

var A_arbace_classes_env_A_const_115 *lang.Var

var A_arbace_classes_env_A_const_116 *lang.Var

var A_arbace_classes_env_A_const_117 *lang.Var

var A_arbace_classes_env_A_const_118 *lang.Var

var A_arbace_classes_env_A_const_119 *lang.Var

var A_arbace_classes_env_A_const_120 *lang.Var

var A_arbace_classes_env_A_const_121 any

var A_arbace_classes_env_A_const_122 any

var A_arbace_classes_env_A_const_123 *lang.Var

var A_arbace_classes_env_A_const_124 any

var A_arbace_classes_env_A_const_125 *lang.Var

var A_arbace_classes_env_A_const_126 *lang.Var

var A_arbace_classes_env_A_const_127 *lang.Var

var A_arbace_classes_env_A_const_128 *lang.Var

var A_arbace_classes_env_A_const_129 *lang.Var

var A_arbace_classes_env_A_const_130 *lang.Var

var A_arbace_classes_env_A_const_131 *lang.Var

var A_arbace_classes_env_A_const_132 any

var A_arbace_classes_env_A_const_133 any

var A_arbace_classes_env_A_const_134 any

var A_arbace_classes_env_A_const_135 *lang.Var

var A_arbace_classes_env_A_const_136 *lang.Var

var A_arbace_classes_env_A_const_137 *lang.Var

var A_arbace_classes_env_A_const_138 *lang.Var

var A_arbace_classes_env_A_const_139 *lang.Var

var A_arbace_classes_env_A_const_140 *lang.Var

var A_arbace_classes_env_A_init jrt.ClassInit

func A_arbace_classes_env_A_Init() { if !A_arbace_classes_env_A_init.Done() { A_arbace_classes_env_A_init.Run(A_arbace_classes_env_A_clinit) } }

func A_arbace_classes_env_A_clinit() { A_arbace_classes_env_A_clinit_p0(); A_arbace_classes_env_A_clinit_p1(); A_arbace_classes_env_A_clinit_p2(); A_arbace_classes_env_A_clinit_p3(); A_arbace_classes_env_A_clinit_p4(); A_arbace_classes_env_A_clinit_p5(); A_arbace_classes_env_A_clinit_p6(); A_arbace_classes_env_A_clinit_p7(); A_arbace_classes_env_A_clinit_p8(); A_arbace_classes_env_A_clinit_p9(); A_arbace_classes_env_A_clinit_p10(); A_arbace_classes_env_A_clinit_p11() }

func A_arbace_classes_env_A_clinit_p0() { jrt.StartCheck(); A_arbace_classes_env_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 177); A_arbace_classes_env_A_const_0 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[36]); A_arbace_classes_env_A_const_1 = A_arbace_classes_env_A_const_pool.A[37]; A_arbace_classes_env_A_const_2 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[38]); A_arbace_classes_env_A_const_3 = A_arbace_classes_env_A_const_pool.A[39]; A_arbace_classes_env_A_const_4 = A_arbace_classes_env_A_const_pool.A[40]; A_arbace_classes_env_A_const_5 = A_arbace_classes_env_A_const_pool.A[41]; A_arbace_classes_env_A_const_6 = A_arbace_classes_env_A_const_pool.A[42]; A_arbace_classes_env_A_const_7 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[43]); A_arbace_classes_env_A_const_8 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[44]); A_arbace_classes_env_A_const_9 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[45]); A_arbace_classes_env_A_const_10 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[46]); A_arbace_classes_env_A_const_11 = A_arbace_classes_env_A_const_pool.A[47] }

func A_arbace_classes_env_A_clinit_p1() { A_arbace_classes_env_A_const_12 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[48]); A_arbace_classes_env_A_const_13 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[49]); A_arbace_classes_env_A_const_14 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[50]); A_arbace_classes_env_A_const_15 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[51]); A_arbace_classes_env_A_const_16 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[52]); A_arbace_classes_env_A_const_17 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[53]); A_arbace_classes_env_A_const_18 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[54]); A_arbace_classes_env_A_const_19 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[55]); A_arbace_classes_env_A_const_20 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[56]); A_arbace_classes_env_A_const_21 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[57]); A_arbace_classes_env_A_const_22 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[58]); A_arbace_classes_env_A_const_23 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[59]) }

func A_arbace_classes_env_A_clinit_p2() { A_arbace_classes_env_A_const_24 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[60]); A_arbace_classes_env_A_const_25 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[61]); A_arbace_classes_env_A_const_26 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[62]); A_arbace_classes_env_A_const_27 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[63]); A_arbace_classes_env_A_const_28 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[64]); A_arbace_classes_env_A_const_29 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[65]); A_arbace_classes_env_A_const_30 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[66]); A_arbace_classes_env_A_const_31 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[67]); A_arbace_classes_env_A_const_32 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[68]); A_arbace_classes_env_A_const_33 = jrt.Class_Cast(A_arbace_classes_env_A_const_pool.A[69]); A_arbace_classes_env_A_const_34 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[70]); A_arbace_classes_env_A_const_35 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[71]) }

func A_arbace_classes_env_A_clinit_p3() { A_arbace_classes_env_A_const_36 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[72]); A_arbace_classes_env_A_const_37 = A_arbace_classes_env_A_const_pool.A[73]; A_arbace_classes_env_A_const_38 = A_arbace_classes_env_A_const_pool.A[74]; A_arbace_classes_env_A_const_39 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[75]); A_arbace_classes_env_A_const_40 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[76]); A_arbace_classes_env_A_const_41 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[77]); A_arbace_classes_env_A_const_42 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[78]); A_arbace_classes_env_A_const_43 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[79]); A_arbace_classes_env_A_const_44 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[80]); A_arbace_classes_env_A_const_45 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[81]); A_arbace_classes_env_A_const_46 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[82]); A_arbace_classes_env_A_const_47 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[83]) }

func A_arbace_classes_env_A_clinit_p4() { A_arbace_classes_env_A_const_48 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[84]); A_arbace_classes_env_A_const_49 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[85]); A_arbace_classes_env_A_const_50 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[86]); A_arbace_classes_env_A_const_51 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[87]); A_arbace_classes_env_A_const_52 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[88]); A_arbace_classes_env_A_const_53 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[89]); A_arbace_classes_env_A_const_54 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[90]); A_arbace_classes_env_A_const_55 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[91]); A_arbace_classes_env_A_const_56 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[92]); A_arbace_classes_env_A_const_57 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[93]); A_arbace_classes_env_A_const_58 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[94]); A_arbace_classes_env_A_const_59 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[95]) }

func A_arbace_classes_env_A_clinit_p5() { A_arbace_classes_env_A_const_60 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[96]); A_arbace_classes_env_A_const_61 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[97]); A_arbace_classes_env_A_const_62 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[98]); A_arbace_classes_env_A_const_63 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[99]); A_arbace_classes_env_A_const_64 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[100]); A_arbace_classes_env_A_const_65 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[101]); A_arbace_classes_env_A_const_66 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[102]); A_arbace_classes_env_A_const_67 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[103]); A_arbace_classes_env_A_const_68 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[104]); A_arbace_classes_env_A_const_69 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[105]); A_arbace_classes_env_A_const_70 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[106]); A_arbace_classes_env_A_const_71 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[107]) }

func A_arbace_classes_env_A_clinit_p6() { A_arbace_classes_env_A_const_72 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[108]); A_arbace_classes_env_A_const_73 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[109]); A_arbace_classes_env_A_const_74 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[110]); A_arbace_classes_env_A_const_75 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[111]); A_arbace_classes_env_A_const_76 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[112]); A_arbace_classes_env_A_const_77 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[113]); A_arbace_classes_env_A_const_78 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[114]); A_arbace_classes_env_A_const_79 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[115]); A_arbace_classes_env_A_const_80 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[116]); A_arbace_classes_env_A_const_81 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[117]); A_arbace_classes_env_A_const_82 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[118]); A_arbace_classes_env_A_const_83 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[119]) }

func A_arbace_classes_env_A_clinit_p7() { A_arbace_classes_env_A_const_84 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[120]); A_arbace_classes_env_A_const_85 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[121]); A_arbace_classes_env_A_const_86 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[122]); A_arbace_classes_env_A_const_87 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[123]); A_arbace_classes_env_A_const_88 = A_arbace_classes_env_A_const_pool.A[124]; A_arbace_classes_env_A_const_89 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[125]); A_arbace_classes_env_A_const_90 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[126]); A_arbace_classes_env_A_const_91 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[127]); A_arbace_classes_env_A_const_92 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[128]); A_arbace_classes_env_A_const_93 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[129]); A_arbace_classes_env_A_const_94 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[130]); A_arbace_classes_env_A_const_95 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[131]) }

func A_arbace_classes_env_A_clinit_p8() { A_arbace_classes_env_A_const_96 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[132]); A_arbace_classes_env_A_const_97 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[133]); A_arbace_classes_env_A_const_98 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[134]); A_arbace_classes_env_A_const_99 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[135]); A_arbace_classes_env_A_const_100 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[136]); A_arbace_classes_env_A_const_101 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[137]); A_arbace_classes_env_A_const_102 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[138]); A_arbace_classes_env_A_const_103 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[139]); A_arbace_classes_env_A_const_104 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[140]); A_arbace_classes_env_A_const_105 = A_arbace_classes_env_A_const_pool.A[141]; A_arbace_classes_env_A_const_106 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[142]); A_arbace_classes_env_A_const_107 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[143]) }

func A_arbace_classes_env_A_clinit_p9() { A_arbace_classes_env_A_const_108 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[144]); A_arbace_classes_env_A_const_109 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[145]); A_arbace_classes_env_A_const_110 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[146]); A_arbace_classes_env_A_const_111 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[147]); A_arbace_classes_env_A_const_112 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[148]); A_arbace_classes_env_A_const_113 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[149]); A_arbace_classes_env_A_const_114 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[150]); A_arbace_classes_env_A_const_115 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[151]); A_arbace_classes_env_A_const_116 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[152]); A_arbace_classes_env_A_const_117 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[153]); A_arbace_classes_env_A_const_118 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[154]); A_arbace_classes_env_A_const_119 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[155]) }

func A_arbace_classes_env_A_clinit_p10() { A_arbace_classes_env_A_const_120 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[156]); A_arbace_classes_env_A_const_121 = A_arbace_classes_env_A_const_pool.A[157]; A_arbace_classes_env_A_const_122 = A_arbace_classes_env_A_const_pool.A[158]; A_arbace_classes_env_A_const_123 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[159]); A_arbace_classes_env_A_const_124 = A_arbace_classes_env_A_const_pool.A[160]; A_arbace_classes_env_A_const_125 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[161]); A_arbace_classes_env_A_const_126 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[162]); A_arbace_classes_env_A_const_127 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[163]); A_arbace_classes_env_A_const_128 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[164]); A_arbace_classes_env_A_const_129 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[165]); A_arbace_classes_env_A_const_130 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[166]); A_arbace_classes_env_A_const_131 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[167]); A_arbace_classes_env_A_const_132 = A_arbace_classes_env_A_const_pool.A[168] }

func A_arbace_classes_env_A_clinit_p11() { A_arbace_classes_env_A_const_133 = A_arbace_classes_env_A_const_pool.A[169]; A_arbace_classes_env_A_const_134 = A_arbace_classes_env_A_const_pool.A[170]; A_arbace_classes_env_A_const_135 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[171]); A_arbace_classes_env_A_const_136 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[172]); A_arbace_classes_env_A_const_137 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[173]); A_arbace_classes_env_A_const_138 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[174]); A_arbace_classes_env_A_const_139 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[175]); A_arbace_classes_env_A_const_140 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[176]) }

func A_arbace_classes_env_A_New() *A_arbace_classes_env_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_env_A) Ctor() {}

func (t *A_arbace_classes_env_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_A_class }

func (t *A_arbace_classes_env_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_env_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_A); return ok }

func A_arbace_classes_env_A_Cast(x any) *A_arbace_classes_env_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_A_class)) }; return v }



type A_arbace_classes_env_accessible_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_accessible_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_accessible_QMARK__fn__28000143_A struct{ j2g_header uint64; F_owner any }

var A_arbace_classes_env_accessible_QMARK__fn__28000143_A_fn_class *jrt.Class



type A_arbace_classes_env_accessible_QMARK__fn__28000145_A struct{ j2g_header uint64 }

var A_arbace_classes_env_accessible_QMARK__fn__28000145_A_fn_class *jrt.Class



type A_arbace_classes_env_all_supertypes_A struct{ j2g_header uint64 }

var A_arbace_classes_env_all_supertypes_A_fn_class *jrt.Class



type A_arbace_classes_env_all_supertypes_STAR__A struct{ j2g_header uint64 }

var A_arbace_classes_env_all_supertypes_STAR__A_fn_class *jrt.Class



type A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A struct{ j2g_header uint64 }

var A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A_fn_class *jrt.Class



type A_arbace_classes_env_assignable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_assignable_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_class_file_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_class_file_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_coerce_const_A struct{ j2g_header uint64 }

var A_arbace_classes_env_coerce_const_A_fn_class *jrt.Class



type A_arbace_classes_env_common_super_A struct{ j2g_header uint64 }

var A_arbace_classes_env_common_super_A_fn_class *jrt.Class



type A_arbace_classes_env_const_value_A struct{ j2g_header uint64 }

var A_arbace_classes_env_const_value_A_fn_class *jrt.Class



type A_arbace_classes_env_constructors_A struct{ j2g_header uint64 }

var A_arbace_classes_env_constructors_A_fn_class *jrt.Class



type A_arbace_classes_env_constructors_fn__28000192_A struct{ j2g_header uint64 }

var A_arbace_classes_env_constructors_fn__28000192_A_fn_class *jrt.Class



type A_arbace_classes_env_eval28000004_A struct{ jrt.Object }

func A_arbace_classes_env_eval28000004_A_New() *A_arbace_classes_env_eval28000004_A { t := &A_arbace_classes_env_eval28000004_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_env_eval28000004_A) Ctor() {}

func (t *A_arbace_classes_env_eval28000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_eval28000004_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_eval28000004_A_class }

func (t *A_arbace_classes_env_eval28000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_eval28000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_env_eval28000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_eval28000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_eval28000004_A); return ok }

func A_arbace_classes_env_eval28000004_A_Cast(x any) *A_arbace_classes_env_eval28000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_eval28000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_eval28000004_A_class)) }; return v }



type A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A struct{ j2g_header uint64 }

var A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_fn_class *jrt.Class



type A_arbace_classes_env_eval28000008_A struct{ jrt.Object }

func A_arbace_classes_env_eval28000008_A_New() *A_arbace_classes_env_eval28000008_A { t := &A_arbace_classes_env_eval28000008_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_env_eval28000008_A) Ctor() {}

func (t *A_arbace_classes_env_eval28000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_eval28000008_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_eval28000008_A_class }

func (t *A_arbace_classes_env_eval28000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_eval28000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_env_eval28000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_eval28000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_eval28000008_A); return ok }

func A_arbace_classes_env_eval28000008_A_Cast(x any) *A_arbace_classes_env_eval28000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_eval28000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_eval28000008_A_class)) }; return v }



type A_arbace_classes_env_eval28000008_fn__28000009_A struct{ j2g_header uint64 }

var A_arbace_classes_env_eval28000008_fn__28000009_A_fn_class *jrt.Class



type A_arbace_classes_env_find_field_A struct{ j2g_header uint64 }

var A_arbace_classes_env_find_field_A_fn_class *jrt.Class



type A_arbace_classes_env_find_field_fn__28000150_A struct{ j2g_header uint64; F_name any }

var A_arbace_classes_env_find_field_fn__28000150_A_fn_class *jrt.Class



type A_arbace_classes_env_find_field_fn__28000152_A struct{ j2g_header uint64; F_name any }

var A_arbace_classes_env_find_field_fn__28000152_A_fn_class *jrt.Class



type A_arbace_classes_env_flag_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_flag_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_from_source_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_from_source_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_info_A struct{ j2g_header uint64 }

var A_arbace_classes_env_info_A_fn_class *jrt.Class



type A_arbace_classes_env_info_BANG__A struct{ j2g_header uint64 }

var A_arbace_classes_env_info_BANG__A_fn_class *jrt.Class



type A_arbace_classes_env_infos_now_A struct{ j2g_header uint64 }

var A_arbace_classes_env_infos_now_A_fn_class *jrt.Class



type A_arbace_classes_env_inner_member_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_inner_member_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_interface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_interface_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_internal_A struct{ j2g_header uint64 }

var A_arbace_classes_env_internal_A_fn_class *jrt.Class



type A_arbace_classes_env_known_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_known_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_load_class_A struct{ j2g_header uint64 }

var A_arbace_classes_env_load_class_A_fn_class *jrt.Class



type A_arbace_classes_env_lub_A struct{ j2g_header uint64 }

var A_arbace_classes_env_lub_A_fn_class *jrt.Class



type A_arbace_classes_env_lub_fn__28000134_A struct{ j2g_header uint64; F_common any }

var A_arbace_classes_env_lub_fn__28000134_A_fn_class *jrt.Class



type A_arbace_classes_env_lub_fn__28000134_fn__28000135_A struct{ j2g_header uint64; F_i any }

var A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_fn_class *jrt.Class



type A_arbace_classes_env_lub_sups__28000129_A struct{ j2g_header uint64 }

var A_arbace_classes_env_lub_sups__28000129_A_fn_class *jrt.Class



type A_arbace_classes_env_lub_sups__28000129_fn__28000130_A struct{ j2g_header uint64 }

var A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_fn_class *jrt.Class



type A_arbace_classes_env_member_methods_A struct{ j2g_header uint64 }

var A_arbace_classes_env_member_methods_A_fn_class *jrt.Class



type A_arbace_classes_env_member_methods_STAR__A struct{ j2g_header uint64 }

var A_arbace_classes_env_member_methods_STAR__A_fn_class *jrt.Class



type A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A struct{ j2g_header uint64; F_seen, F_name, F_n, F_c any }

var A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A_fn_class *jrt.Class



type A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A struct{ j2g_header uint64; F_iter__28000179, F_seen, F_name, F_n, F_c, F_s__28000180 any }

var A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A_fn_class *jrt.Class



type A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A struct{ j2g_header uint64; F_seen, F_name, F_n, F_c any; F_size__1927001038__auto__ int32; F_b__28000182, F_c__1927001037__auto__ any }

var A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A_fn_class *jrt.Class



type A_arbace_classes_env_nest_host_A struct{ j2g_header uint64 }

var A_arbace_classes_env_nest_host_A_fn_class *jrt.Class



type A_arbace_classes_env_params_key_A struct{ j2g_header uint64 }

var A_arbace_classes_env_params_key_A_fn_class *jrt.Class



type A_arbace_classes_env_read_fields_A struct{ j2g_header uint64 }

var A_arbace_classes_env_read_fields_A_fn_class *jrt.Class



type A_arbace_classes_env_read_method_annotations_A struct{ j2g_header uint64 }

var A_arbace_classes_env_read_method_annotations_A_fn_class *jrt.Class



type A_arbace_classes_env_record_BANG__A struct{ j2g_header uint64 }

var A_arbace_classes_env_record_BANG__A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_A struct{ j2g_header uint64 }

var A_arbace_classes_env_reflect_info_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_fn__28000027_A struct{ j2g_header uint64; F_c any }

var A_arbace_classes_env_reflect_info_fn__28000027_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_fn__28000089_A struct{ j2g_header uint64 }

var A_arbace_classes_env_reflect_info_fn__28000089_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000031__28000035_A struct{ j2g_header uint64; F_n any }

var A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A struct{ j2g_header uint64; F_n, F_s__28000032, F_iter__28000031 any }

var A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A struct{ j2g_header uint64; F_b__28000034, F_n any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000045__28000049_A struct{ j2g_header uint64; F_n any }

var A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A struct{ j2g_header uint64; F_n, F_s__28000046, F_iter__28000045 any }

var A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A struct{ j2g_header uint64; F_n, F_b__28000048 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_A struct{ j2g_header uint64; F_n, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A struct{ j2g_header uint64; F_n, F_manns, F_s__28000056, F_iter__28000055 any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A struct{ j2g_header uint64; F_n, F_b__28000058, F_manns any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A struct{ j2g_header uint64; F_m, F_desc, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A struct{ j2g_header uint64; F_m, F_desc, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A struct{ j2g_header uint64; F_i, F_m, F_desc, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A struct{ j2g_header uint64; F_m, F_desc, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A struct{ j2g_header uint64; F_m, F_desc, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A struct{ j2g_header uint64; F_i, F_m, F_desc, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000077__28000081_A struct{ j2g_header uint64; F_c, F_n any }

var A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A struct{ j2g_header uint64; F_c, F_n, F_s__28000078, F_iter__28000077 any }

var A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A struct{ j2g_header uint64; F_c, F_n, F_b__28000080 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000091__28000095_A struct{ j2g_header uint64; F_n any }

var A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A struct{ j2g_header uint64; F_n, F_s__28000092, F_iter__28000091 any }

var A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A struct{ j2g_header uint64; F_n any; F_size__1927001038__auto__ int32; F_b__28000094, F_c__1927001037__auto__ any }

var A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_fn_class *jrt.Class



type A_arbace_classes_env_reflected_A struct{ j2g_header uint64 }

var A_arbace_classes_env_reflected_A_fn_class *jrt.Class



type A_arbace_classes_env_same_infos_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_same_infos_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_subclass_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_subclass_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_subclass_QMARK__fn__28000117_A struct{ j2g_header uint64; F_b any }

var A_arbace_classes_env_subclass_QMARK__fn__28000117_A_fn_class *jrt.Class



type A_arbace_classes_env_superclass_chain_A struct{ j2g_header uint64 }

var A_arbace_classes_env_superclass_chain_A_fn_class *jrt.Class



type A_arbace_classes_env_superclass_chain_fn__28000123_A struct{ j2g_header uint64 }

var A_arbace_classes_env_superclass_chain_fn__28000123_A_fn_class *jrt.Class



type A_arbace_classes_env_supertypes_A struct{ j2g_header uint64 }

var A_arbace_classes_env_supertypes_A_fn_class *jrt.Class
