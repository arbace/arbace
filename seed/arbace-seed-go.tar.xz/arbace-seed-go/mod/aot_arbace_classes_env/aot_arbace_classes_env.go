//line aot_arbace_classes_env.ae:1
package aot_arbace_classes_env

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_New() *A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A { A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_Init(); t := &A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp20 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_classes_env_A_Init(); tmp4 = A_arbace_classes_env_A_const_0; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_classes_env_A_Init(); tmp6 = A_arbace_classes_env_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_classes_env_A_Init(); tmp7 = A_arbace_classes_env_A_const_1; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_classes_env_A_Init(); tmp9 = A_arbace_classes_env_A_const_3; var tmp10 any = tmp9; var tmp11 any; A_arbace_classes_env_A_Init(); tmp11 = A_arbace_classes_env_A_const_4; var tmp12 any = tmp11; var tmp13 any; A_arbace_classes_env_A_Init(); tmp13 = A_arbace_classes_env_A_const_5; var tmp14 any = tmp13; var tmp15 any; A_arbace_classes_env_A_Init(); tmp15 = A_arbace_classes_env_A_const_6; tmp8.Invoke_O_O_O_O__O(tmp10, tmp12, tmp14, tmp15); var tmp16 *lang.Var; lang.RT_Init(); tmp16 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp16).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_152)); var tmp17 *lang.Var; lang.RT_Init(); tmp17 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp17).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_153)); var tmp18 *lang.Var; lang.RT_Init(); tmp18 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp18).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_154)); var tmp19 *lang.Var; lang.RT_Init(); tmp19 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp19).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_155)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp20 != nil { panic(tmp20) }; return tmp3 }
//line :1:1
func A_arbace_classes_env_eval28000008_fn__28000009_A_New() *A_arbace_classes_env_eval28000008_fn__28000009_A { A_arbace_classes_env_eval28000008_fn__28000009_A_Init(); t := &A_arbace_classes_env_eval28000008_fn__28000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_env_eval28000008_fn__28000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_env_eval28000008_fn__28000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_classes_env_A_Init(); tmp3 = A_arbace_classes_env_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_classes_env_A_Init(); tmp5 = A_arbace_classes_env_A_const_11; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_classes_env_A_Init(); tmp7 = A_arbace_classes_env_A_const_9; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_classes_env_A_Init(); tmp9 = A_arbace_classes_env_A_const_10; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }



























func A_arbace_classes_env_internal_A_New() *A_arbace_classes_env_internal_A { A_arbace_classes_env_internal_A_Init(); t := &A_arbace_classes_env_internal_A{}; t.Ctor(); return t }
//line :29:1
func (t *A_arbace_classes_env_internal_A) Ctor() {}
//line :29:1
func (t *A_arbace_classes_env_internal_A) Invoke_O_O__O(self, c__0 any) any { var tmp1 *lang.Var; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_12; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref(), Lit_166, Lit_165) }







func A_arbace_classes_env_from_source_QMARK__A_New() *A_arbace_classes_env_from_source_QMARK__A { A_arbace_classes_env_from_source_QMARK__A_Init(); t := &A_arbace_classes_env_from_source_QMARK__A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_classes_env_from_source_QMARK__A) Ctor() {}
//line :37:1
func (t *A_arbace_classes_env_from_source_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var tmp1 any; var and__1927000168__auto____2 any; var tmp2 *lang.Var; A_arbace_classes_env_A_Init(); tmp2 = A_arbace_classes_env_A_const_13; and__1927000168__auto____2 = jrt.NN(tmp2).Get__O(); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp3 *lang.Var; A_arbace_classes_env_A_Init(); tmp3 = A_arbace_classes_env_A_const_13; tmp1 = lang.IFn_Cast(jrt.NN(tmp3).Get__O()).Invoke_O__O(n__0) } else { tmp1 = and__1927000168__auto____2 }; return jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(tmp1)).Ref() }


















func A_arbace_classes_env_record_BANG__A_New() *A_arbace_classes_env_record_BANG__A { A_arbace_classes_env_record_BANG__A_Init(); t := &A_arbace_classes_env_record_BANG__A{}; t.Ctor(); return t }
//line :56:1
func (t *A_arbace_classes_env_record_BANG__A) Ctor() {}
//line :56:1
func (t *A_arbace_classes_env_record_BANG__A) Invoke_O_O_O_O__O(self, n__0, facet__1, v__2 any) any {


	var tmp1 *lang.Var; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_14; if jrt.A2g_Truth(jrt.NN(tmp1).Get__O()) { var tmp2 *lang.Var; A_arbace_classes_env_A_Init(); tmp2 = A_arbace_classes_env_A_const_15; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_classes_env_A_Init(); tmp4 = A_arbace_classes_env_A_const_14; var tmp5 any = jrt.NN(tmp4).Get__O(); var tmp6 *lang.Var; A_arbace_classes_env_A_Init(); tmp6 = A_arbace_classes_env_A_const_16; var tmp7 any = jrt.NN(tmp6).GetRawRoot__O(); var tmp8 *lang.Var; A_arbace_classes_env_A_Init(); tmp8 = A_arbace_classes_env_A_const_17; tmp3.Invoke_O_O_O_O_O_O__O(tmp5, tmp7, n__0, jrt.NN(tmp8).GetRawRoot__O(), facet__1, v__2) }
//line :56:1
	return v__2
}




func A_arbace_classes_env_load_class_A_New() *A_arbace_classes_env_load_class_A { A_arbace_classes_env_load_class_A_Init(); t := &A_arbace_classes_env_load_class_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_classes_env_load_class_A) Ctor() {}
//line :62:1
func (t *A_arbace_classes_env_load_class_A) Invoke_O_O__O(self, n__0 any) any {



	var tmp1 any; var or__1927000174__auto____2 any; var tmp2 *lang.Var; A_arbace_classes_env_A_Init(); tmp2 = A_arbace_classes_env_A_const_18; or__1927000174__auto____2 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(n__0); if jrt.A2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { var tmp3 *lang.Var; A_arbace_classes_env_A_Init(); tmp3 = A_arbace_classes_env_A_const_19; tmp1 = jrt.NN(tmp3).Get__O() }; if jrt.A2g_Truth(tmp1) { return nil } else { var tmp4 any; tmp15 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var cn__4 any; var tmp5 *lang.Var

		A_arbace_classes_env_A_Init(); tmp5 = A_arbace_classes_env_A_const_20; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O_O__O(n__0, Lit_146)) { var tmp6 *lang.Var; A_arbace_classes_env_A_Init(); tmp6 = A_arbace_classes_env_A_const_12; cn__4 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O_O_O__O(n__0, Lit_165, Lit_166) } else { var tmp7 *lang.Var; A_arbace_classes_env_A_Init(); tmp7 = A_arbace_classes_env_A_const_12; cn__4 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O_O_O__O(n__0, Lit_165, Lit_166) }
//line :66:1
		var c__5 any = lang.RT_ClassForNameNonLoading_String__Class(jrt.String_Cast(cn__4)).Ref(); var tmp8 any
		var and__1927000168__auto____6 any = c__5


		if jrt.A2g_Truth(and__1927000168__auto____6) { var tmp9 *lang.Var; A_arbace_classes_env_A_Init(); tmp9 = A_arbace_classes_env_A_const_14; tmp8 = jrt.NN(tmp9).Get__O() } else { tmp8 = and__1927000168__auto____6 }; if jrt.A2g_Truth(tmp8) { var tmp10 *lang.Var; A_arbace_classes_env_A_Init(); tmp10 = A_arbace_classes_env_A_const_21; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp12 = A_arbace_classes_env_A_const_22; var tmp13 any = tmp12.Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; tmp11.Invoke_O_O_O__O(n__0, tmp13, tmp14.Ref()) }
//line :66:1
		tmp4 = c__5 }; return nil }(); if tmp15 != nil { if jrt.ClassNotFoundException_InstanceOf(tmp15) { var ___4 *jrt.ClassNotFoundException = jrt.ClassNotFoundException_Cast(tmp15); _ = ___4; tmp4 = nil } else if jrt.NoClassDefFoundError_InstanceOf(tmp15) { var ___4_2 *jrt.NoClassDefFoundError = jrt.NoClassDefFoundError_Cast(tmp15); _ = ___4_2; tmp4 = nil } else { panic(tmp15) } }; return tmp4
	}
}






func A_arbace_classes_env_known_QMARK__A_New() *A_arbace_classes_env_known_QMARK__A { A_arbace_classes_env_known_QMARK__A_Init(); t := &A_arbace_classes_env_known_QMARK__A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_classes_env_known_QMARK__A) Ctor() {}
//line :75:1
func (t *A_arbace_classes_env_known_QMARK__A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 *lang.Var; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_19; if jrt.A2g_Truth(jrt.NN(tmp1).Get__O()) { var tmp2 *lang.Var; A_arbace_classes_env_A_Init(); tmp2 = A_arbace_classes_env_A_const_23; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_classes_env_A_Init(); tmp4 = A_arbace_classes_env_A_const_19; return tmp3.Invoke_O_O__O(jrt.NN(tmp4).Get__O(), n__0) } else { var tmp5 *lang.Var; A_arbace_classes_env_A_Init(); tmp5 = A_arbace_classes_env_A_const_24; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_classes_env_A_Init(); tmp7 = A_arbace_classes_env_A_const_25; return tmp6.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(n__0))
	} }
func A_arbace_classes_env_reflected_A_New() *A_arbace_classes_env_reflected_A { A_arbace_classes_env_reflected_A_Init(); t := &A_arbace_classes_env_reflected_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_classes_env_reflected_A) Ctor() {}
//line :80:1
func (t *A_arbace_classes_env_reflected_A) Invoke_O_O_O_O__O(self, n__0, facet__1, f__2 any) any {




	var tmp1 *lang.Var; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_19; if jrt.A2g_Truth(jrt.NN(tmp1).Get__O()) { var temp__1927000414__auto____4 any; var tmp2 *lang.Var
		A_arbace_classes_env_A_Init(); tmp2 = A_arbace_classes_env_A_const_19; temp__1927000414__auto____4 = lang.RT_Get_O_O__O(jrt.NN(tmp2).Get__O(), n__0); if jrt.A2g_Truth(temp__1927000414__auto____4) { var d__5 any = temp__1927000414__auto____4; var temp__1927000408__auto____6 any; var tmp3 *lang.Var
			A_arbace_classes_env_A_Init(); tmp3 = A_arbace_classes_env_A_const_26; temp__1927000408__auto____6 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(d__5, facet__1); if jrt.A2g_Truth(temp__1927000408__auto____6) { var e__7 any = temp__1927000408__auto____6; var tmp4 *lang.Var
				A_arbace_classes_env_A_Init(); tmp4 = A_arbace_classes_env_A_const_27; return lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(e__7) } else {
//line :87:1
					var tmp5 *lang.Var; A_arbace_classes_env_A_Init(); tmp5 = A_arbace_classes_env_A_const_28; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_215, nil, Lit_216, nil, Lit_217); var tmp8 *lang.Var; A_arbace_classes_env_A_Init(); tmp8 = A_arbace_classes_env_A_const_29; var tmp9 any = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(facet__1); var tmp10 *lang.Var; A_arbace_classes_env_A_Init(); tmp10 = A_arbace_classes_env_A_const_12; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Var; A_arbace_classes_env_A_Init(); tmp12 = A_arbace_classes_env_A_const_32; var tmp13 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp9, nil, tmp11.Invoke_O_O_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(n__0), Lit_165, Lit_166), nil)).Ref(); var tmp14 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp14 = A_arbace_classes_env_A_const_30; var tmp15 any = tmp14.Ref(); var tmp16 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp16 = A_arbace_classes_env_A_const_31; panic(jrt.Thrown(jrt.Throwable_Cast(tmp6.Invoke_O_O__O(tmp13, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp15, n__0, tmp16.Ref(), facet__1)))))) } } else {
//line :86:1
						return nil } } else {
//line :85:1
							var temp__1927000414__auto____4_2 any; var tmp17 *lang.Var






							A_arbace_classes_env_A_Init(); tmp17 = A_arbace_classes_env_A_const_25; temp__1927000414__auto____4_2 = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(n__0); if jrt.A2g_Truth(temp__1927000414__auto____4_2) { var c__5 any = temp__1927000414__auto____4_2; var tmp18 *lang.Var
								A_arbace_classes_env_A_Init(); tmp18 = A_arbace_classes_env_A_const_21; return lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O_O_O__O(n__0, facet__1, lang.IFn_Cast(f__2).Invoke_O__O(c__5)) } else {
//line :92:1
									return nil
								}
						} }
func A_arbace_classes_env_class_file_QMARK__A_New() *A_arbace_classes_env_class_file_QMARK__A { A_arbace_classes_env_class_file_QMARK__A_Init(); t := &A_arbace_classes_env_class_file_QMARK__A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_classes_env_class_file_QMARK__A) Ctor() {}
//line :95:1
func (t *A_arbace_classes_env_class_file_QMARK__A) Invoke_O_O__O(self, c__0 any) any { var ld__2 any; var or__1927000174__auto____2 any = jrt.NN(jrt.Class_Cast(c__0)).GetClassLoader__ClassLoader(); if





	jrt.A2g_Truth(or__1927000174__auto____2) { ld__2 = or__1927000174__auto____2 } else { ld__2 = jrt.ClassLoader_GetSystemClassLoader__ClassLoader() }; var temp__1927000414__auto____3 any; var tmp1 /*line :95:1*/*jrt.Class;






	A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_33; var tmp2 *jrt.Class = tmp1; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_139); var tmp4 *lang.Var; A_arbace_classes_env_A_Init(); tmp4 = A_arbace_classes_env_A_const_34; temp__1927000414__auto____3 = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(ld__2, tmp2, Lit_138, jrt.RefArrayOf(jrt.Object_class, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp3, jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(c__0), nil)).Ref())); if jrt.A2g_Truth(temp__1927000414__auto____3) { var in__4 any = temp__1927000414__auto____3
		jrt.InputStream_Cast(in__4).Close__V()
//line :102:1
		jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { return nil } }



func A_arbace_classes_env_read_fields_A_New() *A_arbace_classes_env_read_fields_A { A_arbace_classes_env_read_fields_A_Init(); t := &A_arbace_classes_env_read_fields_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_classes_env_read_fields_A) Ctor() {}
//line :106:1
func (t *A_arbace_classes_env_read_fields_A) Invoke_O_O__O(self, c__0 any) any {




	var tmp1 *lang.Var; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_35; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(c__0)) {
		var tmp2 *lang.Var; A_arbace_classes_env_A_Init(); tmp2 = A_arbace_classes_env_A_const_36; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; A_arbace_classes_env_A_Init(); tmp4 = A_arbace_classes_env_A_const_37; return lang.IFn_Cast(tmp3.Invoke_O__O(tmp4)).Invoke_O__O(c__0) } else {
//line :111:1
			return nil
		}
}
func A_arbace_classes_env_read_method_annotations_A_New() *A_arbace_classes_env_read_method_annotations_A { A_arbace_classes_env_read_method_annotations_A_Init(); t := &A_arbace_classes_env_read_method_annotations_A{}; t.Ctor(); return t }
//line :114:1
func (t *A_arbace_classes_env_read_method_annotations_A) Ctor() {}
//line :114:1
func (t *A_arbace_classes_env_read_method_annotations_A) Invoke_O_O__O(self, c__0 any) any {



	var tmp1 *lang.Var; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_35; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(c__0)) {
		var tmp2 *lang.Var; A_arbace_classes_env_A_Init(); tmp2 = A_arbace_classes_env_A_const_36; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; A_arbace_classes_env_A_Init(); tmp4 = A_arbace_classes_env_A_const_38; return lang.IFn_Cast(tmp3.Invoke_O__O(tmp4)).Invoke_O__O(c__0) } else {
//line :118:1
			lang.PersistentArrayMap_Init(); return lang.PersistentArrayMap_EMPTY.Ref()
		}
}

func A_arbace_classes_env_coerce_const_A_New() *A_arbace_classes_env_coerce_const_A { A_arbace_classes_env_coerce_const_A_Init(); t := &A_arbace_classes_env_coerce_const_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_classes_env_coerce_const_A) Ctor() {}
//line :122:1
func (t *A_arbace_classes_env_coerce_const_A) Invoke_O_O_O__O(self, desc__0, v__1 any) any { var G__28000023__3_ any = desc__0; switch
												lang.Util_Hash_O__I(G__28000023__3_) { case 66: if lang.Util_Equiv_O_O__Z(G__28000023__3_, Lit_141) {



		return jrt.Byte_ValueOf_B__Byte(lang.RT_ByteCast_O__B(v__1)).Ref() }
//line :123:1
	case 67: if lang.Util_Equiv_O_O__Z(G__28000023__3_, Lit_142) {

		return jrt.Character_ValueOf_C__Character(lang.RT_CharCast_I__C(lang.RT_IntCast_O__I(v__1))).Ref() }
//line :123:1
	case 83: if lang.Util_Equiv_O_O__Z(G__28000023__3_, Lit_143) {


		return jrt.Short_ValueOf_S__Short(lang.RT_ShortCast_O__S(v__1)).Ref() }
//line :123:1
	case 90: if lang.Util_Equiv_O_O__Z(G__28000023__3_, Lit_144) {
		var tmp1 *lang.Var; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_39; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsZero_J__Z(lang.RT_LongCast_O__J(v__1))).Ref()) }
//line :123:1
	default:}; return v__1 }











func A_arbace_classes_env_inner_member_QMARK__A_New() *A_arbace_classes_env_inner_member_QMARK__A { A_arbace_classes_env_inner_member_QMARK__A_Init(); t := &A_arbace_classes_env_inner_member_QMARK__A{}; t.Ctor(); return t }
//line :135:1
func (t *A_arbace_classes_env_inner_member_QMARK__A) Ctor() {}
//line :135:1
func (t *A_arbace_classes_env_inner_member_QMARK__A) Invoke_O_O__O(self, c__0 any) any {
	var tmp1 any; var and__1927000168__auto____2 any = jrt.NN(jrt.Class_Cast(c__0)).GetDeclaringClass__Class().Ref(); if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var tmp2 *lang.Var; A_arbace_classes_env_A_Init(); tmp2 = A_arbace_classes_env_A_const_39; and__1927000168__auto____3 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(jrt.Modifier_IsStatic_I__Z(jrt.NN(jrt.Class_Cast(c__0)).GetModifiers__I())).Ref()); if jrt.A2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var tmp3 *lang.Var
		A_arbace_classes_env_A_Init(); tmp3 = A_arbace_classes_env_A_const_39; and__1927000168__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.Class_Cast(c__0)).IsInterface__Z()).Ref())
//line :136:1
		if jrt.A2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var tmp4 *lang.Var
			A_arbace_classes_env_A_Init(); tmp4 = A_arbace_classes_env_A_const_39; and__1927000168__auto____5 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.Class_Cast(c__0)).IsEnum__Z()).Ref())
//line :136:1
			if jrt.A2g_Truth(and__1927000168__auto____5) {
				var tmp5 *lang.Var; A_arbace_classes_env_A_Init(); tmp5 = A_arbace_classes_env_A_const_39; tmp1 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.Class_Cast(c__0)).IsRecord__Z()).Ref()) } else {
//line :136:1
					tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; return jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(tmp1)).Ref()
}

func A_arbace_classes_env_reflect_info_A_New() *A_arbace_classes_env_reflect_info_A { A_arbace_classes_env_reflect_info_A_Init(); t := &A_arbace_classes_env_reflect_info_A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_classes_env_reflect_info_A) Ctor() {}
//line :139:1
func (t *A_arbace_classes_env_reflect_info_A) Invoke_O_O__O(self, c__0 any) any { var lockee__1927000360__auto____2 any; var tmp1 *lang.Var; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_40; lockee__1927000360__auto____2 = jrt.NN(tmp1).GetRawRoot__O(); var locklocal__1927000361__auto____5 any = lockee__1927000360__auto____2; lang.Compiler_Evaluator_MonitorEnter_O__V(locklocal__1927000361__auto____5); var tmp2 any; tmp93 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var or__1927000174__auto____8 any; var tmp3 *lang.Var

	A_arbace_classes_env_A_Init(); tmp3 = A_arbace_classes_env_A_const_40; or__1927000174__auto____8 = lang.Reflector_InvokeInstanceMethod_O_String_O1__O(jrt.NN(tmp3).GetRawRoot__O(), Lit_188, jrt.RefArrayOf(jrt.Object_class, c__0)); if jrt.A2g_Truth(or__1927000174__auto____8) { tmp2 = or__1927000174__auto____8 } else { var n__9 any; var tmp4 *lang.Var
		A_arbace_classes_env_A_Init(); tmp4 = A_arbace_classes_env_A_const_34; n__9 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(c__0)
//line :141:1
		var manns__10 any; var tmp5 any = A_arbace_classes_env_reflect_info_fn__28000027_A_New_O(c__0); var tmp6 *jrt.Class; A_arbace_classes_env_reflect_info_fn__28000027_A_Init(); tmp6 = A_arbace_classes_env_reflect_info_fn__28000027_A_fn_class; manns__10 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)); var info__11 any; var tmp7 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp7 = A_arbace_classes_env_A_const_42; var tmp8 any = tmp7.Ref(); var tmp9 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp9 = A_arbace_classes_env_A_const_43; var tmp10 any = tmp9.Ref(); var tmp11 any = jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.Class_Cast(c__0)).GetModifiers__I()).Ref(); var tmp12 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp12 = A_arbace_classes_env_A_const_44; var tmp13 any = tmp12.Ref(); var tmp14 any = jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.Class_Cast(c__0)).IsInterface__Z()).Ref(); var tmp15 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp15 = A_arbace_classes_env_A_const_45; var tmp16 any = tmp15.Ref(); var tmp17 any; var G__28000029__11_ any = jrt.NN(jrt.Class_Cast(c__0)).GetSuperclass__Class().Ref()





		if lang.Util_Identical_O_O__Z(G__28000029__11_, nil) { tmp17 = nil } else { var tmp18 *lang.Var; A_arbace_classes_env_A_Init(); tmp18 = A_arbace_classes_env_A_const_34; tmp17 = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(G__28000029__11_) }
//line :141:1
		var tmp19 any = tmp17; var tmp20 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp20 = A_arbace_classes_env_A_const_46; var tmp21 any = tmp20.Ref(); var tmp22 *lang.Var; A_arbace_classes_env_A_Init(); tmp22 = A_arbace_classes_env_A_const_47; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Var; A_arbace_classes_env_A_Init(); tmp24 = A_arbace_classes_env_A_const_34; var tmp25 any = tmp23.Invoke_O_O__O(jrt.NN(tmp24).GetRawRoot__O(), jrt.NN(jrt.Class_Cast(c__0)).GetInterfaces__Class1().Ref()); var tmp26 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp26 = A_arbace_classes_env_A_const_48; var tmp27 any = tmp26.Ref(); var tmp28 *lang.Var; A_arbace_classes_env_A_Init(); tmp28 = A_arbace_classes_env_A_const_34; var tmp29 any = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetNestHost__Class().Ref()); var tmp30 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp30 = A_arbace_classes_env_A_const_49; var tmp31 any = tmp30.Ref(); var tmp32 any; var G__28000030__11_ any = jrt.NN(jrt.Class_Cast(c__0)).GetDeclaringClass__Class().Ref()








		if lang.Util_Identical_O_O__Z(G__28000030__11_, nil) { tmp32 = nil } else { var tmp33 *lang.Var; A_arbace_classes_env_A_Init(); tmp33 = A_arbace_classes_env_A_const_34; tmp32 = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()).Invoke_O__O(G__28000030__11_) }
//line :141:1
		var tmp34 any = tmp32; var tmp35 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp35 = A_arbace_classes_env_A_const_50; var tmp36 any = tmp35.Ref(); var tmp37 any; var temp__1927000408__auto____11 any; var tmp38 *lang.Var









		A_arbace_classes_env_A_Init(); tmp38 = A_arbace_classes_env_A_const_51; temp__1927000408__auto____11 = lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()).Invoke_O__O(c__0); if jrt.A2g_Truth(temp__1927000408__auto____11) { var fs__12 any = temp__1927000408__auto____11; var tmp39 *lang.Var
			A_arbace_classes_env_A_Init(); tmp39 = A_arbace_classes_env_A_const_52; var tmp40 lang.IFn = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()); var tmp41 any; var iter__1927001039__auto____13 any; var tmp42 any = A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_New_O(n__9); var tmp43 *jrt.Class; A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_Init(); tmp43 = A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_fn_class; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp42, tmp43, nil); tmp41 = lang.IFn_Cast(iter__1927001039__auto____13).Invoke_O__O(fs__12); tmp37 = tmp40.Invoke_O__O(tmp41) } else {




				var tmp44 *lang.Var; A_arbace_classes_env_A_Init(); tmp44 = A_arbace_classes_env_A_const_52; var tmp45 lang.IFn = lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()); var tmp46 any; var iter__1927001039__auto____12 any; var tmp47 any = A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_New_O(n__9); var tmp48 *jrt.Class; A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_Init(); tmp48 = A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_fn_class; iter__1927001039__auto____12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp47, tmp48, nil); tmp46 = lang.IFn_Cast(iter__1927001039__auto____12).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetDeclaredFields__Field1().Ref()); tmp37 = tmp45.Invoke_O__O(tmp46) }
//line :141:1
		var tmp49 any = tmp37; var tmp50 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp50 = A_arbace_classes_env_A_const_53; var tmp51 any = tmp50.Ref(); var tmp52 *lang.Var; A_arbace_classes_env_A_Init(); tmp52 = A_arbace_classes_env_A_const_54; var tmp53 any = lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()).Invoke_O__O(c__0); var tmp54 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp54 = A_arbace_classes_env_A_const_55; var tmp55 any = tmp54.Ref(); var tmp56 *lang.Var; A_arbace_classes_env_A_Init(); tmp56 = A_arbace_classes_env_A_const_52; var tmp57 lang.IFn = lang.IFn_Cast(jrt.NN(tmp56).GetRawRoot__O()); var tmp58 *lang.Var; A_arbace_classes_env_A_Init(); tmp58 = A_arbace_classes_env_A_const_78; var tmp59 lang.IFn = lang.IFn_Cast(jrt.NN(tmp58).GetRawRoot__O()); var tmp60 any; var iter__1927001039__auto____11 any; var tmp61 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_New_O_O(n__9, manns__10); var tmp62 *jrt.Class





















		A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_Init(); tmp62 = A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_fn_class; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp61, tmp62, nil); tmp60 = lang.IFn_Cast(iter__1927001039__auto____11).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetDeclaredMethods__Method1().Ref())
//line :141:1
		var tmp63 any = tmp60; var tmp64 any; var iter__1927001039__auto____11_2 any; var tmp65 any = A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_New_O_O(c__0, n__9); var tmp66 *jrt.Class
































		A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_Init(); tmp66 = A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_fn_class; iter__1927001039__auto____11_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp65, tmp66, nil); tmp64 = lang.IFn_Cast(iter__1927001039__auto____11_2).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetDeclaredConstructors__Constructor1().Ref())
//line :141:1
		var tmp67 any = tmp57.Invoke_O__O(tmp59.Invoke_O_O__O(tmp63, tmp64)); var tmp68 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp68 = A_arbace_classes_env_A_const_30; info__11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp8, n__9, tmp10, tmp11, tmp13, tmp14, tmp16, tmp19, tmp21, tmp25, tmp27, tmp29, tmp31, tmp34, tmp36, tmp49, tmp51, tmp53, tmp55, tmp67, tmp68.Ref(), c__0)); var info__12 any; var tmp69 any; var and__1927000168__auto____12 any; var tmp70 *lang.Var











































		A_arbace_classes_env_A_Init(); tmp70 = A_arbace_classes_env_A_const_39; and__1927000168__auto____12 = lang.IFn_Cast(jrt.NN(tmp70).GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.Class_Cast(c__0)).IsInterface__Z()).Ref()); if jrt.A2g_Truth(and__1927000168__auto____12) { var tmp71 *lang.Var; A_arbace_classes_env_A_Init(); tmp71 = A_arbace_classes_env_A_const_56; var tmp72 lang.IFn = lang.IFn_Cast(jrt.NN(tmp71).GetRawRoot__O()); var tmp73 *lang.Var; A_arbace_classes_env_A_Init(); tmp73 = A_arbace_classes_env_A_const_86; var tmp74 lang.IFn = lang.IFn_Cast(jrt.NN(tmp73).GetRawRoot__O()); var tmp75 any = A_arbace_classes_env_reflect_info_fn__28000089_A_New(); var tmp76 *jrt.Class; A_arbace_classes_env_reflect_info_fn__28000089_A_Init(); tmp76 = A_arbace_classes_env_reflect_info_fn__28000089_A_fn_class; var tmp77 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp75, tmp76, nil); var tmp78 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp78 = A_arbace_classes_env_A_const_55; tmp69 = tmp72.Invoke_O__O(tmp74.Invoke_O_O__O(tmp77, jrt.NN(tmp78).Invoke_O__O(info__11))) } else { tmp69 = and__1927000168__auto____12 }; if jrt.A2g_Truth(tmp69) {
			var tmp79 *lang.Var; A_arbace_classes_env_A_Init(); tmp79 = A_arbace_classes_env_A_const_16; var tmp80 lang.IFn = lang.IFn_Cast(jrt.NN(tmp79).GetRawRoot__O()); var tmp81 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp81 = A_arbace_classes_env_A_const_55; var tmp82 any = tmp81.Ref(); var tmp83 *lang.Var; A_arbace_classes_env_A_Init(); tmp83 = A_arbace_classes_env_A_const_87; var tmp84 any = jrt.NN(tmp83).GetRawRoot__O(); var tmp85 any; var iter__1927001039__auto____12_2 any; var tmp86 any = A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_New_O(n__9); var tmp87 *jrt.Class; A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_Init(); tmp87 = A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_fn_class; iter__1927001039__auto____12_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp86, tmp87, nil); var tmp88 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____12_2); var tmp89 *lang.Var; A_arbace_classes_env_A_Init(); tmp89 = A_arbace_classes_env_A_const_36; var tmp90 lang.IFn = lang.IFn_Cast(jrt.NN(tmp89).GetRawRoot__O()); var tmp91 any; A_arbace_classes_env_A_Init(); tmp91 = A_arbace_classes_env_A_const_88; tmp85 = tmp88.Invoke_O__O(lang.IFn_Cast(tmp90.Invoke_O__O(tmp91)).Invoke_O__O(n__9)); info__12 = tmp80.Invoke_O_O_O_O__O(info__11, tmp82, tmp84, tmp85) } else {
//line :185:1
				info__12 = info__11
			}


		var tmp92 *lang.Var; A_arbace_classes_env_A_Init(); tmp92 = A_arbace_classes_env_A_const_40; lang.Reflector_InvokeInstanceMethod_O_String_O1__O(jrt.NN(tmp92).GetRawRoot__O(), Lit_189, jrt.RefArrayOf(jrt.Object_class, c__0, info__12))
//line :141:1
		tmp2 = info__12 } }; return nil }(); /*line :139:1*/lang.Compiler_Evaluator_MonitorExit_O__V(locklocal__1927000361__auto____5); if tmp93 != nil { panic(tmp93) }; return tmp2 }



func A_arbace_classes_env_reflect_info_fn__28000027_A_New_O(p0 any) *A_arbace_classes_env_reflect_info_fn__28000027_A { A_arbace_classes_env_reflect_info_fn__28000027_A_Init(); t := &A_arbace_classes_env_reflect_info_fn__28000027_A{}; t.Ctor_O(p0); return t }
//line :143:1
func (t *A_arbace_classes_env_reflect_info_fn__28000027_A) Ctor_O(c__c any) { t.F_c = c__c }
//line :143:1
func (t *A_arbace_classes_env_reflect_info_fn__28000027_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_41; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; var t_ any = t.F_c; t.F_c = nil; tmp3 = t_; return tmp2.Invoke_O__O(tmp3) }








func A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_New_O(p0 any) *A_arbace_classes_env_reflect_info_iter__28000031__28000035_A { A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000031__28000035_A{}; t.Ctor_O(p0); return t }
//line :152:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :152:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_A) Invoke_O_O__O(self, s__28000032__1 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_New_O_O_O(t.F_n, s__28000032__1, self); var tmp2 *jrt.Class; A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_Init(); tmp2 = A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :152:1
func A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A { A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :152:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A) Ctor_O_O_O(c__n, c__s__28000032, c__iter__28000031 any) { t.F_n = c__n; t.F_s__28000032 = c__s__28000032; t.F_iter__28000031 = c__iter__28000031 }
//line :152:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A) Invoke_O__O(self any) any { { var s__28000032__1 any; var t_ any = t.F_s__28000032; t.F_s__28000032 = nil; s__28000032__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_57; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__28000032__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__28000032__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_classes_env_A_Init(); tmp2 = A_arbace_classes_env_A_const_58; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__28000032__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_classes_env_A_Init(); tmp3 = A_arbace_classes_env_A_const_59; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__28000032__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__28000034__6 any; var tmp4 *lang.Var; A_arbace_classes_env_A_Init(); tmp4 = A_arbace_classes_env_A_const_60; b__28000034__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_New_O_O_I_O(b__28000034__6, t.F_n, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_Init(); tmp6 = A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_classes_env_A_Init(); tmp7 = A_arbace_classes_env_A_const_72; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_classes_env_A_Init(); tmp9 = A_arbace_classes_env_A_const_74; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__28000034__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__28000031); var tmp12 *lang.Var; A_arbace_classes_env_A_Init(); tmp12 = A_arbace_classes_env_A_const_75; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__28000032__3))) } else { var tmp13 *lang.Var; A_arbace_classes_env_A_Init(); tmp13 = A_arbace_classes_env_A_const_72; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_classes_env_A_Init(); tmp15 = A_arbace_classes_env_A_const_74; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__28000034__6), nil) } } else { var map__28000041__4 any; var tmp16 *lang.Var; A_arbace_classes_env_A_Init(); tmp16 = A_arbace_classes_env_A_const_63; map__28000041__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__28000032__3); var map__28000041__5 any; if lang.ISeq_InstanceOf(map__28000041__4) { var tmp17 *lang.Var; A_arbace_classes_env_A_Init(); tmp17 = A_arbace_classes_env_A_const_61; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(map__28000041__4)) { var tmp18 *lang.Var; A_arbace_classes_env_A_Init(); tmp18 = A_arbace_classes_env_A_const_62; map__28000041__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(map__28000041__4), jrt.Object_class.ArrayClass())).Ref() } else { var tmp19 *lang.Var; A_arbace_classes_env_A_Init(); tmp19 = A_arbace_classes_env_A_const_57; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(map__28000041__4)) { var tmp20 *lang.Var; A_arbace_classes_env_A_Init(); tmp20 = A_arbace_classes_env_A_const_63; map__28000041__5 = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(map__28000041__4) } else { lang.PersistentArrayMap_Init(); map__28000041__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__28000041__5 = map__28000041__4 }; var name__6 any; var tmp21 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp21 = A_arbace_classes_env_A_const_42; name__6 = lang.RT_Get_O_O__O(map__28000041__5, tmp21.Ref()); var desc__7 any; var tmp22 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp22 = A_arbace_classes_env_A_const_64; desc__7 = lang.RT_Get_O_O__O(map__28000041__5, tmp22.Ref()); var flags__8 any; var tmp23 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp23 = A_arbace_classes_env_A_const_43; flags__8 = lang.RT_Get_O_O__O(map__28000041__5, tmp23.Ref()); var value__9 any; var tmp24 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp24 = A_arbace_classes_env_A_const_65; value__9 = lang.RT_Get_O_O__O(map__28000041__5, tmp24.Ref()); var tmp25 *lang.Var; A_arbace_classes_env_A_Init(); tmp25 = A_arbace_classes_env_A_const_73; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp27 = A_arbace_classes_env_A_const_42; var tmp28 any = tmp27.Ref(); var tmp29 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp29 = A_arbace_classes_env_A_const_64; var tmp30 any = tmp29.Ref(); var tmp31 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp31 = A_arbace_classes_env_A_const_43; var tmp32 any = tmp31.Ref(); var tmp33 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp33 = A_arbace_classes_env_A_const_67; var tmp34 any = tmp33.Ref(); var tmp35 any = t.F_n; var tmp36 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp36 = A_arbace_classes_env_A_const_68; var tmp37 any = tmp36.Ref(); var tmp38 any; var tmp39 any; var and__1927000168__auto____10 bool = jrt.Modifier_IsFinal_I__Z(lang.RT_IntCast_O__I(flags__8))

	if and__1927000168__auto____10 { var and__1927000168__auto____11 any; var tmp40 *lang.Var; A_arbace_classes_env_A_Init(); tmp40 = A_arbace_classes_env_A_const_24; and__1927000168__auto____11 = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()).Invoke_O__O(value__9); if jrt.A2g_Truth(and__1927000168__auto____11) { var or__1927000174__auto____12 any; var tmp41 *lang.Var
		A_arbace_classes_env_A_Init(); tmp41 = A_arbace_classes_env_A_const_69; or__1927000174__auto____12 = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()).Invoke_O__O(desc__7); if jrt.A2g_Truth(or__1927000174__auto____12) { tmp39 = or__1927000174__auto____12 } else { var tmp42 *lang.Var; A_arbace_classes_env_A_Init(); tmp42 = A_arbace_classes_env_A_const_70; tmp39 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(desc__7, jrt.NN(tmp42).GetRawRoot__O())).Ref() } } else {
//line :154:1
			tmp39 = and__1927000168__auto____11 } } else { tmp39 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____10).Ref() }; if jrt.A2g_Truth(tmp39) {

				var tmp43 *lang.Var; A_arbace_classes_env_A_Init(); tmp43 = A_arbace_classes_env_A_const_71; tmp38 = lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()).Invoke_O_O__O(desc__7, value__9) } else {
//line :154:1
					tmp38 = nil }
//line :152:1
	var tmp44 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp28, name__6, tmp30, desc__7, tmp32, flags__8, tmp34, tmp35, tmp37, tmp38)); var tmp45 lang.IFn = lang.IFn_Cast(t.F_iter__28000031); var tmp46 *lang.Var; A_arbace_classes_env_A_Init(); tmp46 = A_arbace_classes_env_A_const_76; return tmp26.Invoke_O_O__O(tmp44, tmp45.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()).Invoke_O__O(s__28000032__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :152:1
func A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A { A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :152:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A) Ctor_O_O_I_O(c__b__28000034, c__n any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__28000034 = c__b__28000034; t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :152:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A) Invoke_O__O(self any) any { { var i__28000033__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__28000033__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var map__28000038__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__28000033__1)); var map__28000038__3 any; if lang.ISeq_InstanceOf(map__28000038__2) { var tmp2 *lang.Var; A_arbace_classes_env_A_Init(); tmp2 = A_arbace_classes_env_A_const_61; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__28000038__2)) { var tmp3 *lang.Var; A_arbace_classes_env_A_Init(); tmp3 = A_arbace_classes_env_A_const_62; map__28000038__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__28000038__2), jrt.Object_class.ArrayClass())).Ref() } else { var tmp4 *lang.Var; A_arbace_classes_env_A_Init(); tmp4 = A_arbace_classes_env_A_const_57; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__28000038__2)) { var tmp5 *lang.Var; A_arbace_classes_env_A_Init(); tmp5 = A_arbace_classes_env_A_const_63; map__28000038__3 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(map__28000038__2) } else { lang.PersistentArrayMap_Init(); map__28000038__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__28000038__3 = map__28000038__2 }; var name__4 any; var tmp6 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp6 = A_arbace_classes_env_A_const_42; name__4 = lang.RT_Get_O_O__O(map__28000038__3, tmp6.Ref()); var desc__5 any; var tmp7 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp7 = A_arbace_classes_env_A_const_64; desc__5 = lang.RT_Get_O_O__O(map__28000038__3, tmp7.Ref()); var flags__6 any; var tmp8 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp8 = A_arbace_classes_env_A_const_43; flags__6 = lang.RT_Get_O_O__O(map__28000038__3, tmp8.Ref()); var value__7 any; var tmp9 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp9 = A_arbace_classes_env_A_const_65; value__7 = lang.RT_Get_O_O__O(map__28000038__3, tmp9.Ref()); var tmp10 *lang.Var; A_arbace_classes_env_A_Init(); tmp10 = A_arbace_classes_env_A_const_66; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 any = t.F_b__28000034; var tmp13 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp13 = A_arbace_classes_env_A_const_42; var tmp14 any = tmp13.Ref(); var tmp15 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp15 = A_arbace_classes_env_A_const_64; var tmp16 any = tmp15.Ref(); var tmp17 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp17 = A_arbace_classes_env_A_const_43; var tmp18 any = tmp17.Ref(); var tmp19 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp19 = A_arbace_classes_env_A_const_67; var tmp20 any = tmp19.Ref(); var tmp21 any = t.F_n; var tmp22 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp22 = A_arbace_classes_env_A_const_68; var tmp23 any = tmp22.Ref(); var tmp24 any; var tmp25 any; var and__1927000168__auto____8 bool = jrt.Modifier_IsFinal_I__Z(lang.RT_IntCast_O__I(flags__6))

	if and__1927000168__auto____8 { var and__1927000168__auto____9 any; var tmp26 *lang.Var; A_arbace_classes_env_A_Init(); tmp26 = A_arbace_classes_env_A_const_24; and__1927000168__auto____9 = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(value__7); if jrt.A2g_Truth(and__1927000168__auto____9) { var or__1927000174__auto____10 any; var tmp27 *lang.Var
		A_arbace_classes_env_A_Init(); tmp27 = A_arbace_classes_env_A_const_69; or__1927000174__auto____10 = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(desc__5); if jrt.A2g_Truth(or__1927000174__auto____10) { tmp25 = or__1927000174__auto____10 } else { var tmp28 *lang.Var; A_arbace_classes_env_A_Init(); tmp28 = A_arbace_classes_env_A_const_70; tmp25 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(desc__5, jrt.NN(tmp28).GetRawRoot__O())).Ref() } } else {
//line :154:1
			tmp25 = and__1927000168__auto____9 } } else { tmp25 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____8).Ref() }; if jrt.A2g_Truth(tmp25) {

				var tmp29 *lang.Var; A_arbace_classes_env_A_Init(); tmp29 = A_arbace_classes_env_A_const_71; tmp24 = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O_O__O(desc__5, value__7) } else {
//line :154:1
					tmp24 = nil }
//line :152:1
	tmp11.Invoke_O_O__O(tmp12, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp14, name__4, tmp16, desc__5, tmp18, flags__6, tmp20, tmp21, tmp23, tmp24))); i__28000033__1 = lang.Numbers_Unchecked_inc_J__J(i__28000033__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }




func A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_New_O(p0 any) *A_arbace_classes_env_reflect_info_iter__28000045__28000049_A { A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000045__28000049_A{}; t.Ctor_O(p0); return t }
//line :157:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :157:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_A) Invoke_O_O__O(self, s__28000046__1 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_New_O_O_O(t.F_n, s__28000046__1, self); var tmp2 *jrt.Class; A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_Init(); tmp2 = A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :157:1
func A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A { A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :157:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A) Ctor_O_O_O(c__n, c__s__28000046, c__iter__28000045 any) { t.F_n = c__n; t.F_s__28000046 = c__s__28000046; t.F_iter__28000045 = c__iter__28000045 }
//line :157:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A) Invoke_O__O(self any) any { { var s__28000046__1 any; var t_ any = t.F_s__28000046; t.F_s__28000046 = nil; s__28000046__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_57; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__28000046__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__28000046__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_classes_env_A_Init(); tmp2 = A_arbace_classes_env_A_const_58; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__28000046__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_classes_env_A_Init(); tmp3 = A_arbace_classes_env_A_const_59; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__28000046__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__28000048__6 any; var tmp4 *lang.Var; A_arbace_classes_env_A_Init(); tmp4 = A_arbace_classes_env_A_const_60; b__28000048__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_New_O_O_I_O(t.F_n, b__28000048__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_Init(); tmp6 = A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_classes_env_A_Init(); tmp7 = A_arbace_classes_env_A_const_72; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_classes_env_A_Init(); tmp9 = A_arbace_classes_env_A_const_74; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__28000048__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__28000045); var tmp12 *lang.Var; A_arbace_classes_env_A_Init(); tmp12 = A_arbace_classes_env_A_const_75; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__28000046__3))) } else { var tmp13 *lang.Var; A_arbace_classes_env_A_Init(); tmp13 = A_arbace_classes_env_A_const_72; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_classes_env_A_Init(); tmp15 = A_arbace_classes_env_A_const_74; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__28000048__6), nil) } } else { var f__4 any; var tmp16 *lang.Var; A_arbace_classes_env_A_Init(); tmp16 = A_arbace_classes_env_A_const_63; f__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__28000046__3); var tmp17 *lang.Var; A_arbace_classes_env_A_Init(); tmp17 = A_arbace_classes_env_A_const_73; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp19 = A_arbace_classes_env_A_const_42; var tmp20 any = tmp19.Ref(); var tmp21 any = jrt.NN(jrt.Field_Cast(f__4)).GetName__String().Ref(); var tmp22 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp22 = A_arbace_classes_env_A_const_64; var tmp23 any = tmp22.Ref(); var tmp24 *lang.Var; A_arbace_classes_env_A_Init(); tmp24 = A_arbace_classes_env_A_const_77; var tmp25 any = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Field_Cast(f__4)).GetType__Class().Ref()); var tmp26 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp26 = A_arbace_classes_env_A_const_43; var tmp27 any = tmp26.Ref(); var tmp28 any = jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.Field_Cast(f__4)).GetModifiers__I()).Ref(); var tmp29 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp29 = A_arbace_classes_env_A_const_67; var tmp30 any = tmp29.Ref(); var tmp31 any = t.F_n; var tmp32 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp32 = A_arbace_classes_env_A_const_68; var tmp33 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp20, tmp21, tmp23, tmp25, tmp27, tmp28, tmp30, tmp31, tmp32.Ref(), nil)); var tmp34 lang.IFn = lang.IFn_Cast(t.F_iter__28000045); var tmp35 *lang.Var; A_arbace_classes_env_A_Init(); tmp35 = A_arbace_classes_env_A_const_76; return tmp18.Invoke_O_O__O(tmp33, tmp34.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()).Invoke_O__O(s__28000046__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :157:1
func A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A { A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :157:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A) Ctor_O_O_I_O(c__n, c__b__28000048 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__28000048 = c__b__28000048; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :157:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A) Invoke_O__O(self any) any { { var i__28000047__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__28000047__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__28000047__1)); var tmp2 *lang.Var; A_arbace_classes_env_A_Init(); tmp2 = A_arbace_classes_env_A_const_66; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__28000048; var tmp5 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp5 = A_arbace_classes_env_A_const_42; var tmp6 any = tmp5.Ref(); var tmp7 any = jrt.NN(jrt.Field_Cast(f__2)).GetName__String().Ref(); var tmp8 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp8 = A_arbace_classes_env_A_const_64; var tmp9 any = tmp8.Ref(); var tmp10 *lang.Var; A_arbace_classes_env_A_Init(); tmp10 = A_arbace_classes_env_A_const_77; var tmp11 any = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Field_Cast(f__2)).GetType__Class().Ref()); var tmp12 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp12 = A_arbace_classes_env_A_const_43; var tmp13 any = tmp12.Ref(); var tmp14 any = jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.Field_Cast(f__2)).GetModifiers__I()).Ref(); var tmp15 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp15 = A_arbace_classes_env_A_const_67; var tmp16 any = tmp15.Ref(); var tmp17 any = t.F_n; var tmp18 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp18 = A_arbace_classes_env_A_const_68; tmp3.Invoke_O_O__O(tmp4, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7, tmp9, tmp11, tmp13, tmp14, tmp16, tmp17, tmp18.Ref(), nil))); i__28000047__1 = lang.Numbers_Unchecked_inc_J__J(i__28000047__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }





func A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_New_O_O(p0, p1 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_A { A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_A{}; t.Ctor_O_O(p0, p1); return t }
//line :163:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_A) Ctor_O_O(c__n, c__manns any) { t.F_n = c__n; t.F_manns = c__manns }
//line :163:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_A) Invoke_O_O__O(self, s__28000056__1 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_New_O_O_O_O(t.F_n, t.F_manns, s__28000056__1, self); var tmp2 *jrt.Class; A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_Init(); tmp2 = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :163:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A { A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :163:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A) Ctor_O_O_O_O(c__n, c__manns, c__s__28000056, c__iter__28000055 any) { t.F_n = c__n; t.F_manns = c__manns; t.F_s__28000056 = c__s__28000056; t.F_iter__28000055 = c__iter__28000055 }
//line :163:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A) Invoke_O__O(self any) any { { var s__28000056__1 any; var t_ any = t.F_s__28000056; t.F_s__28000056 = nil; s__28000056__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_57; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__28000056__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__28000056__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_classes_env_A_Init(); tmp2 = A_arbace_classes_env_A_const_58; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__28000056__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_classes_env_A_Init(); tmp3 = A_arbace_classes_env_A_const_59; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__28000056__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__28000058__6 any; var tmp4 *lang.Var; A_arbace_classes_env_A_Init(); tmp4 = A_arbace_classes_env_A_const_60; b__28000058__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_New_O_O_O_I_O(t.F_n, b__28000058__6, t.F_manns, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_Init(); tmp6 = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_classes_env_A_Init(); tmp7 = A_arbace_classes_env_A_const_72; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_classes_env_A_Init(); tmp9 = A_arbace_classes_env_A_const_74; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__28000058__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__28000055); var tmp12 *lang.Var; A_arbace_classes_env_A_Init(); tmp12 = A_arbace_classes_env_A_const_75; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__28000056__3))) } else { var tmp13 *lang.Var; A_arbace_classes_env_A_Init(); tmp13 = A_arbace_classes_env_A_const_72; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_classes_env_A_Init(); tmp15 = A_arbace_classes_env_A_const_74; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__28000058__6), nil) } } else { var m__4 any; var tmp16 *lang.Var; A_arbace_classes_env_A_Init(); tmp16 = A_arbace_classes_env_A_const_63; m__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__28000056__3); var desc__5 any; var tmp17 *lang.Var
														A_arbace_classes_env_A_Init(); tmp17 = A_arbace_classes_env_A_const_79; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_classes_env_A_Init(); tmp19 = A_arbace_classes_env_A_const_80; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_classes_env_A_Init(); tmp21 = A_arbace_classes_env_A_const_77; var tmp22 any = tmp20.Invoke_O_O__O(jrt.NN(tmp21).GetRawRoot__O(), jrt.NN(jrt.Method_Cast(m__4)).GetParameterTypes__Class1().Ref()); var tmp23 *lang.Var; A_arbace_classes_env_A_Init(); tmp23 = A_arbace_classes_env_A_const_77; desc__5 = tmp18.Invoke_O_O__O(tmp22, lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Method_Cast(m__4)).GetReturnType__Class().Ref()))
//line :163:1
	var tmp24 *lang.Var; A_arbace_classes_env_A_Init(); tmp24 = A_arbace_classes_env_A_const_73; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp26 = A_arbace_classes_env_A_const_42; var tmp27 any = tmp26.Ref(); var tmp28 any = jrt.NN(jrt.Method_Cast(m__4)).GetName__String().Ref(); var tmp29 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp29 = A_arbace_classes_env_A_const_64; var tmp30 any = tmp29.Ref(); var tmp31 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp31 = A_arbace_classes_env_A_const_43; var tmp32 any = tmp31.Ref(); var tmp33 any = jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.Method_Cast(m__4)).GetModifiers__I()).Ref(); var tmp34 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp34 = A_arbace_classes_env_A_const_67; var tmp35 any = tmp34.Ref(); var tmp36 any = t.F_n; var tmp37 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp37 = A_arbace_classes_env_A_const_81; var tmp38 any = tmp37.Ref(); var tmp39 *lang.Var; A_arbace_classes_env_A_Init(); tmp39 = A_arbace_classes_env_A_const_47; var tmp40 lang.IFn = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()); var tmp41 *lang.Var; A_arbace_classes_env_A_Init(); tmp41 = A_arbace_classes_env_A_const_34; var tmp42 any = tmp40.Invoke_O_O__O(jrt.NN(tmp41).GetRawRoot__O(), jrt.NN(jrt.Method_Cast(m__4)).GetExceptionTypes__Class1().Ref()); var tmp43 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp43 = A_arbace_classes_env_A_const_82; var tmp44 any = tmp43.Ref(); var tmp45 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_New_O_O_O(m__4, desc__5, t.F_manns); var tmp46 *jrt.Class; A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_Init(); tmp46 = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_fn_class; var tmp47 any = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp45, tmp46, nil)); var tmp48 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp48 = A_arbace_classes_env_A_const_84; var tmp49 any = tmp48.Ref(); var tmp50 *lang.Var; A_arbace_classes_env_A_Init(); tmp50 = A_arbace_classes_env_A_const_85; var tmp51 lang.IFn = lang.IFn_Cast(jrt.NN(tmp50).GetRawRoot__O()); var tmp52 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_New_O_O_O(m__4, desc__5, t.F_manns); var tmp53 *jrt.Class; A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_Init(); tmp53 = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_fn_class; var tmp54 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp27, tmp28, tmp30, desc__5, tmp32, tmp33, tmp35, tmp36, tmp38, tmp42, tmp44, tmp47, tmp49, tmp51.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp52, tmp53, nil), jrt.NN(jrt.Method_Cast(m__4)).GetParameterTypes__Class1().Ref()))); var tmp55 lang.IFn = lang.IFn_Cast(t.F_iter__28000055); var tmp56 *lang.Var; A_arbace_classes_env_A_Init(); tmp56 = A_arbace_classes_env_A_const_76; return tmp25.Invoke_O_O__O(tmp54, tmp55.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp56).GetRawRoot__O()).Invoke_O__O(s__28000056__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :163:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A { A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :163:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A) Ctor_O_O_O_I_O(c__n, c__b__28000058, c__manns any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__28000058 = c__b__28000058; t.F_manns = c__manns; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :163:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A) Invoke_O__O(self any) any { { var i__28000057__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__28000057__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__28000057__1)); var desc__3 any; var tmp2 *lang.Var
																A_arbace_classes_env_A_Init(); tmp2 = A_arbace_classes_env_A_const_79; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_classes_env_A_Init(); tmp4 = A_arbace_classes_env_A_const_80; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_classes_env_A_Init(); tmp6 = A_arbace_classes_env_A_const_77; var tmp7 any = tmp5.Invoke_O_O__O(jrt.NN(tmp6).GetRawRoot__O(), jrt.NN(jrt.Method_Cast(m__2)).GetParameterTypes__Class1().Ref()); var tmp8 *lang.Var; A_arbace_classes_env_A_Init(); tmp8 = A_arbace_classes_env_A_const_77; desc__3 = tmp3.Invoke_O_O__O(tmp7, lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Method_Cast(m__2)).GetReturnType__Class().Ref()))
//line :163:1
	var tmp9 *lang.Var; A_arbace_classes_env_A_Init(); tmp9 = A_arbace_classes_env_A_const_66; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 any = t.F_b__28000058; var tmp12 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp12 = A_arbace_classes_env_A_const_42; var tmp13 any = tmp12.Ref(); var tmp14 any = jrt.NN(jrt.Method_Cast(m__2)).GetName__String().Ref(); var tmp15 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp15 = A_arbace_classes_env_A_const_64; var tmp16 any = tmp15.Ref(); var tmp17 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp17 = A_arbace_classes_env_A_const_43; var tmp18 any = tmp17.Ref(); var tmp19 any = jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.Method_Cast(m__2)).GetModifiers__I()).Ref(); var tmp20 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp20 = A_arbace_classes_env_A_const_67; var tmp21 any = tmp20.Ref(); var tmp22 any = t.F_n; var tmp23 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp23 = A_arbace_classes_env_A_const_81; var tmp24 any = tmp23.Ref(); var tmp25 *lang.Var; A_arbace_classes_env_A_Init(); tmp25 = A_arbace_classes_env_A_const_47; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Var; A_arbace_classes_env_A_Init(); tmp27 = A_arbace_classes_env_A_const_34; var tmp28 any = tmp26.Invoke_O_O__O(jrt.NN(tmp27).GetRawRoot__O(), jrt.NN(jrt.Method_Cast(m__2)).GetExceptionTypes__Class1().Ref()); var tmp29 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp29 = A_arbace_classes_env_A_const_82; var tmp30 any = tmp29.Ref(); var tmp31 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_New_O_O_O(m__2, desc__3, t.F_manns); var tmp32 *jrt.Class; A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_Init(); tmp32 = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_fn_class; var tmp33 any = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil)); var tmp34 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp34 = A_arbace_classes_env_A_const_84; var tmp35 any = tmp34.Ref(); var tmp36 *lang.Var; A_arbace_classes_env_A_Init(); tmp36 = A_arbace_classes_env_A_const_85; var tmp37 lang.IFn = lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()); var tmp38 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_New_O_O_O(m__2, desc__3, t.F_manns); var tmp39 *jrt.Class; A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_Init(); tmp39 = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_fn_class; tmp10.Invoke_O_O__O(tmp11, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp14, tmp16, desc__3, tmp18, tmp19, tmp21, tmp22, tmp24, tmp28, tmp30, tmp33, tmp35, tmp37.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp38, tmp39, nil), jrt.NN(jrt.Method_Cast(m__2)).GetParameterTypes__Class1().Ref())))); i__28000057__1 = lang.Numbers_Unchecked_inc_J__J(i__28000057__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }






func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A { A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :170:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A) Ctor_O_O_O(c__m, c__desc, c__manns any) { t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :170:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_83; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_classes_env_A_Init(); tmp3 = A_arbace_classes_env_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any; var t_ any = t.F_manns; t.F_manns = nil; tmp5 = t_; var tmp6 any = tmp4.Invoke_O__O(tmp5); var tmp7 any; var t__2 any = t.F_m; t.F_m = nil; tmp7 = t__2; var tmp8 any = jrt.NN(jrt.Method_Cast(tmp7)).GetName__String().Ref(); var tmp9 any; var t__3 any = t.F_desc; t.F_desc = nil; tmp9 = t__3; var tmp10 any = lang.Tuple_Create_O_O__IPersistentVector(tmp8, tmp9); var tmp11 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp11 = A_arbace_classes_env_A_const_82; return tmp2.Invoke_O_O__O(tmp6, lang.Tuple_Create_O_O__IPersistentVector(tmp10, tmp11.Ref())) }
//line :170:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A { A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :170:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A) Ctor_O_O_O(c__m, c__desc, c__manns any) { t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :170:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_83; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_classes_env_A_Init(); tmp3 = A_arbace_classes_env_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any; var t_ any = t.F_manns; t.F_manns = nil; tmp5 = t_; var tmp6 any = tmp4.Invoke_O__O(tmp5); var tmp7 any; var t__2 any = t.F_m; t.F_m = nil; tmp7 = t__2; var tmp8 any = jrt.NN(jrt.Method_Cast(tmp7)).GetName__String().Ref(); var tmp9 any; var t__3 any = t.F_desc; t.F_desc = nil; tmp9 = t__3; var tmp10 any = lang.Tuple_Create_O_O__IPersistentVector(tmp8, tmp9); var tmp11 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp11 = A_arbace_classes_env_A_const_82; return tmp2.Invoke_O_O__O(tmp6, lang.Tuple_Create_O_O__IPersistentVector(tmp10, tmp11.Ref())) }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A { A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :172:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A) Ctor_O_O_O(c__m, c__desc, c__manns any) { t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :172:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A) Invoke_O_O_O__O(self, i__1, ___2 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_New_O_O_O_O(i__1, t.F_m, t.F_desc, t.F_manns); var tmp2 *jrt.Class; A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_Init(); tmp2 = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_fn_class; return lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :172:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A { A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :172:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A) Ctor_O_O_O_O(c__i, c__m, c__desc, c__manns any) { t.F_i = c__i; t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :172:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_83; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_classes_env_A_Init(); tmp3 = A_arbace_classes_env_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any; var t_ any = t.F_manns; t.F_manns = nil; tmp5 = t_; var tmp6 any = tmp4.Invoke_O__O(tmp5); var tmp7 any; var t__2 any = t.F_m; t.F_m = nil; tmp7 = t__2; var tmp8 any = jrt.NN(jrt.Method_Cast(tmp7)).GetName__String().Ref(); var tmp9 any; var t__3 any = t.F_desc; t.F_desc = nil; tmp9 = t__3; var tmp10 any = lang.Tuple_Create_O_O__IPersistentVector(tmp8, tmp9); var tmp11 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp11 = A_arbace_classes_env_A_const_84; var tmp12 any = tmp11.Ref(); var tmp13 any; var t__4 any = t.F_i; t.F_i = nil; tmp13 = t__4; return tmp2.Invoke_O_O__O(tmp6, lang.Tuple_Create_O_O_O__IPersistentVector(tmp10, tmp12, tmp13)) }
//line :172:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A { A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :172:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A) Ctor_O_O_O(c__m, c__desc, c__manns any) { t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :172:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A) Invoke_O_O_O__O(self, i__1, ___2 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_New_O_O_O_O(i__1, t.F_m, t.F_desc, t.F_manns); var tmp2 *jrt.Class; A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_Init(); tmp2 = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_fn_class; return lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :172:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A { A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :172:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A) Ctor_O_O_O_O(c__i, c__m, c__desc, c__manns any) { t.F_i = c__i; t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :172:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_83; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_classes_env_A_Init(); tmp3 = A_arbace_classes_env_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any; var t_ any = t.F_manns; t.F_manns = nil; tmp5 = t_; var tmp6 any = tmp4.Invoke_O__O(tmp5); var tmp7 any; var t__2 any = t.F_m; t.F_m = nil; tmp7 = t__2; var tmp8 any = jrt.NN(jrt.Method_Cast(tmp7)).GetName__String().Ref(); var tmp9 any; var t__3 any = t.F_desc; t.F_desc = nil; tmp9 = t__3; var tmp10 any = lang.Tuple_Create_O_O__IPersistentVector(tmp8, tmp9); var tmp11 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp11 = A_arbace_classes_env_A_const_84; var tmp12 any = tmp11.Ref(); var tmp13 any; var t__4 any = t.F_i; t.F_i = nil; tmp13 = t__4; return tmp2.Invoke_O_O__O(tmp6, lang.Tuple_Create_O_O_O__IPersistentVector(tmp10, tmp12, tmp13)) }

func A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_New_O_O(p0, p1 any) *A_arbace_classes_env_reflect_info_iter__28000077__28000081_A { A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000077__28000081_A{}; t.Ctor_O_O(p0, p1); return t }
//line :174:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_A) Ctor_O_O(c__c, c__n any) { t.F_c = c__c; t.F_n = c__n }
//line :174:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_A) Invoke_O_O__O(self, s__28000078__1 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_New_O_O_O_O(t.F_c, t.F_n, s__28000078__1, self); var tmp2 *jrt.Class; A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_Init(); tmp2 = A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :174:1
func A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A { A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :174:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A) Ctor_O_O_O_O(c__c, c__n, c__s__28000078, c__iter__28000077 any) { t.F_c = c__c; t.F_n = c__n; t.F_s__28000078 = c__s__28000078; t.F_iter__28000077 = c__iter__28000077 }
//line :174:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A) Invoke_O__O(self any) any { { var s__28000078__1 any; var t_ any = t.F_s__28000078; t.F_s__28000078 = nil; s__28000078__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_57; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__28000078__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__28000078__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_classes_env_A_Init(); tmp2 = A_arbace_classes_env_A_const_58; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__28000078__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_classes_env_A_Init(); tmp3 = A_arbace_classes_env_A_const_59; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__28000078__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__28000080__6 any; var tmp4 *lang.Var; A_arbace_classes_env_A_Init(); tmp4 = A_arbace_classes_env_A_const_60; b__28000080__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_New_O_O_O_I_O(t.F_c, t.F_n, b__28000080__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_Init(); tmp6 = A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_classes_env_A_Init(); tmp7 = A_arbace_classes_env_A_const_72; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_classes_env_A_Init(); tmp9 = A_arbace_classes_env_A_const_74; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__28000080__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__28000077); var tmp12 *lang.Var; A_arbace_classes_env_A_Init(); tmp12 = A_arbace_classes_env_A_const_75; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__28000078__3))) } else { var tmp13 *lang.Var; A_arbace_classes_env_A_Init(); tmp13 = A_arbace_classes_env_A_const_72; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_classes_env_A_Init(); tmp15 = A_arbace_classes_env_A_const_74; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__28000080__6), nil) } } else { var m__4 any; var tmp16 *lang.Var; A_arbace_classes_env_A_Init(); tmp16 = A_arbace_classes_env_A_const_63; m__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__28000078__3); var tmp17 *lang.Var; A_arbace_classes_env_A_Init(); tmp17 = A_arbace_classes_env_A_const_73; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp19 = A_arbace_classes_env_A_const_42; var tmp20 any = tmp19.Ref(); var tmp21 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp21 = A_arbace_classes_env_A_const_64; var tmp22 any = tmp21.Ref(); var tmp23 *lang.Var; A_arbace_classes_env_A_Init(); tmp23 = A_arbace_classes_env_A_const_79; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_classes_env_A_Init(); tmp25 = A_arbace_classes_env_A_const_80; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Var; A_arbace_classes_env_A_Init(); tmp27 = A_arbace_classes_env_A_const_77; var tmp28 any = jrt.NN(tmp27).GetRawRoot__O(); var tmp29 any; var G__28000086__5_ any; var tmp30 *lang.Var

	A_arbace_classes_env_A_Init(); tmp30 = A_arbace_classes_env_A_const_57; G__28000086__5_ = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Constructor_Cast(m__4)).GetParameterTypes__Class1().Ref()); var tmp31 *lang.Var; A_arbace_classes_env_A_Init(); tmp31 = A_arbace_classes_env_A_const_54; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(t.F_c)) { var tmp32 *lang.Var; A_arbace_classes_env_A_Init(); tmp32 = A_arbace_classes_env_A_const_76; tmp29 = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()).Invoke_O__O(G__28000086__5_) } else { tmp29 = G__28000086__5_ }
//line :174:1
	var tmp33 any = tmp24.Invoke_O_O__O(tmp26.Invoke_O_O__O(tmp28, tmp29), Lit_209); var tmp34 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp34 = A_arbace_classes_env_A_const_43; var tmp35 any = tmp34.Ref(); var tmp36 any = jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.Constructor_Cast(m__4)).GetModifiers__I()).Ref(); var tmp37 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp37 = A_arbace_classes_env_A_const_67; var tmp38 any = tmp37.Ref(); var tmp39 any = t.F_n; var tmp40 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp40 = A_arbace_classes_env_A_const_81; var tmp41 any = tmp40.Ref(); var tmp42 *lang.Var; A_arbace_classes_env_A_Init(); tmp42 = A_arbace_classes_env_A_const_47; var tmp43 lang.IFn = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()); var tmp44 *lang.Var; A_arbace_classes_env_A_Init(); tmp44 = A_arbace_classes_env_A_const_34; var tmp45 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp20, Lit_150, tmp22, tmp33, tmp35, tmp36, tmp38, tmp39, tmp41, tmp43.Invoke_O_O__O(jrt.NN(tmp44).GetRawRoot__O(), jrt.NN(jrt.Constructor_Cast(m__4)).GetExceptionTypes__Class1().Ref()))); var tmp46 lang.IFn = lang.IFn_Cast(t.F_iter__28000077); var tmp47 *lang.Var; A_arbace_classes_env_A_Init(); tmp47 = A_arbace_classes_env_A_const_76; return tmp18.Invoke_O_O__O(tmp45, tmp46.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()).Invoke_O__O(s__28000078__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :174:1
func A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A { A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :174:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A) Ctor_O_O_O_I_O(c__c, c__n, c__b__28000080 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_c = c__c; t.F_n = c__n; t.F_b__28000080 = c__b__28000080; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :174:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A) Invoke_O__O(self any) any { { var i__28000079__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__28000079__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__28000079__1)); var tmp2 *lang.Var; A_arbace_classes_env_A_Init(); tmp2 = A_arbace_classes_env_A_const_66; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__28000080; var tmp5 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp5 = A_arbace_classes_env_A_const_42; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp7 = A_arbace_classes_env_A_const_64; var tmp8 any = tmp7.Ref(); var tmp9 *lang.Var; A_arbace_classes_env_A_Init(); tmp9 = A_arbace_classes_env_A_const_79; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_classes_env_A_Init(); tmp11 = A_arbace_classes_env_A_const_80; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_classes_env_A_Init(); tmp13 = A_arbace_classes_env_A_const_77; var tmp14 any = jrt.NN(tmp13).GetRawRoot__O(); var tmp15 any; var G__28000084__3_ any; var tmp16 *lang.Var

	A_arbace_classes_env_A_Init(); tmp16 = A_arbace_classes_env_A_const_57; G__28000084__3_ = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Constructor_Cast(m__2)).GetParameterTypes__Class1().Ref()); var tmp17 *lang.Var; A_arbace_classes_env_A_Init(); tmp17 = A_arbace_classes_env_A_const_54; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(t.F_c)) { var tmp18 *lang.Var; A_arbace_classes_env_A_Init(); tmp18 = A_arbace_classes_env_A_const_76; tmp15 = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(G__28000084__3_) } else { tmp15 = G__28000084__3_ }
//line :174:1
	var tmp19 any = tmp10.Invoke_O_O__O(tmp12.Invoke_O_O__O(tmp14, tmp15), Lit_209); var tmp20 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp20 = A_arbace_classes_env_A_const_43; var tmp21 any = tmp20.Ref(); var tmp22 any = jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.Constructor_Cast(m__2)).GetModifiers__I()).Ref(); var tmp23 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp23 = A_arbace_classes_env_A_const_67; var tmp24 any = tmp23.Ref(); var tmp25 any = t.F_n; var tmp26 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp26 = A_arbace_classes_env_A_const_81; var tmp27 any = tmp26.Ref(); var tmp28 *lang.Var; A_arbace_classes_env_A_Init(); tmp28 = A_arbace_classes_env_A_const_47; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 *lang.Var; A_arbace_classes_env_A_Init(); tmp30 = A_arbace_classes_env_A_const_34; tmp3.Invoke_O_O__O(tmp4, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, Lit_150, tmp8, tmp19, tmp21, tmp22, tmp24, tmp25, tmp27, tmp29.Invoke_O_O__O(jrt.NN(tmp30).GetRawRoot__O(), jrt.NN(jrt.Constructor_Cast(m__2)).GetExceptionTypes__Class1().Ref())))); i__28000079__1 = lang.Numbers_Unchecked_inc_J__J(i__28000079__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }










func A_arbace_classes_env_reflect_info_fn__28000089_A_New() *A_arbace_classes_env_reflect_info_fn__28000089_A { A_arbace_classes_env_reflect_info_fn__28000089_A_Init(); t := &A_arbace_classes_env_reflect_info_fn__28000089_A{}; t.Ctor(); return t }
//line :185:1
func (t *A_arbace_classes_env_reflect_info_fn__28000089_A) Ctor() {}
//line :185:1
func (t *A_arbace_classes_env_reflect_info_fn__28000089_A) Invoke_O_O__O(self, p1__28000026_SHARP___1 any) any { var tmp1 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_42; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_150, jrt.NN(tmp1).Invoke_O__O(p1__28000026_SHARP___1))).Ref() }
func A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_New_O(p0 any) *A_arbace_classes_env_reflect_info_iter__28000091__28000095_A { A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000091__28000095_A{}; t.Ctor_O(p0); return t }
//line :186:1
func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :186:1
func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_A) Invoke_O_O__O(self, s__28000092__1 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_New_O_O_O(t.F_n, s__28000092__1, self); var tmp2 *jrt.Class; A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_Init(); tmp2 = A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :186:1
func A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A { A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :186:1
func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A) Ctor_O_O_O(c__n, c__s__28000092, c__iter__28000091 any) { t.F_n = c__n; t.F_s__28000092 = c__s__28000092; t.F_iter__28000091 = c__iter__28000091 }
//line :186:1
func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A) Invoke_O__O(self any) any { { var s__28000092__1 any; var t_ any = t.F_s__28000092; t.F_s__28000092 = nil; s__28000092__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_57; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__28000092__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__28000092__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_classes_env_A_Init(); tmp2 = A_arbace_classes_env_A_const_58; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__28000092__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_classes_env_A_Init(); tmp3 = A_arbace_classes_env_A_const_59; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__28000092__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__28000094__6 any; var tmp4 *lang.Var; A_arbace_classes_env_A_Init(); tmp4 = A_arbace_classes_env_A_const_60; b__28000094__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_New_O_I_O_O(t.F_n, size__1927001038__auto____5, b__28000094__6, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_Init(); tmp6 = A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_classes_env_A_Init(); tmp7 = A_arbace_classes_env_A_const_72; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_classes_env_A_Init(); tmp9 = A_arbace_classes_env_A_const_74; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__28000094__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__28000091); var tmp12 *lang.Var; A_arbace_classes_env_A_Init(); tmp12 = A_arbace_classes_env_A_const_75; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__28000092__3))) } else { var tmp13 *lang.Var; A_arbace_classes_env_A_Init(); tmp13 = A_arbace_classes_env_A_const_72; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_classes_env_A_Init(); tmp15 = A_arbace_classes_env_A_const_74; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__28000094__6), nil) } } else { var vec__28000102__4 any; var tmp16 *lang.Var; A_arbace_classes_env_A_Init(); tmp16 = A_arbace_classes_env_A_const_63; vec__28000102__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__28000092__3); var d__5 any = lang.RT_Nth_O_I_O__O(vec__28000102__4, lang.RT_IntCast_J__I(0), nil); var f__6 any = lang.RT_Nth_O_I_O__O(vec__28000102__4, lang.RT_IntCast_J__I(1), nil); var tmp17 *lang.Var; A_arbace_classes_env_A_Init(); tmp17 = A_arbace_classes_env_A_const_73; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp19 = A_arbace_classes_env_A_const_42; var tmp20 any = tmp19.Ref(); var tmp21 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp21 = A_arbace_classes_env_A_const_64; var tmp22 any = tmp21.Ref(); var tmp23 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp23 = A_arbace_classes_env_A_const_43; var tmp24 any = tmp23.Ref(); var tmp25 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp25 = A_arbace_classes_env_A_const_67; var tmp26 any = tmp25.Ref(); var tmp27 any = t.F_n; var tmp28 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp28 = A_arbace_classes_env_A_const_81; var tmp29 any = tmp28.Ref(); var tmp30 *lang.PersistentVector; lang.PersistentVector_Init(); tmp30 = lang.PersistentVector_EMPTY; var tmp31 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp20, Lit_150, tmp22, d__5, tmp24, f__6, tmp26, tmp27, tmp29, tmp30.Ref())); var tmp32 lang.IFn = lang.IFn_Cast(t.F_iter__28000091); var tmp33 *lang.Var; A_arbace_classes_env_A_Init(); tmp33 = A_arbace_classes_env_A_const_76; return tmp18.Invoke_O_O__O(tmp31, tmp32.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()).Invoke_O__O(s__28000092__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :186:1
func A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A { A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :186:1
func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A) Ctor_O_I_O_O(c__n any, c__size__1927001038__auto__ int32, c__b__28000094, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__28000094 = c__b__28000094; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :186:1
func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A) Invoke_O__O(self any) any { { var i__28000093__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__28000093__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__28000098__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__28000093__1)); var d__3 any = lang.RT_Nth_O_I_O__O(vec__28000098__2, lang.RT_IntCast_J__I(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O(vec__28000098__2, lang.RT_IntCast_J__I(1), nil); var tmp2 *lang.Var; A_arbace_classes_env_A_Init(); tmp2 = A_arbace_classes_env_A_const_66; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_b__28000094; var tmp5 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp5 = A_arbace_classes_env_A_const_42; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp7 = A_arbace_classes_env_A_const_64; var tmp8 any = tmp7.Ref(); var tmp9 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp9 = A_arbace_classes_env_A_const_43; var tmp10 any = tmp9.Ref(); var tmp11 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp11 = A_arbace_classes_env_A_const_67; var tmp12 any = tmp11.Ref(); var tmp13 any = t.F_n; var tmp14 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp14 = A_arbace_classes_env_A_const_81; var tmp15 any = tmp14.Ref(); var tmp16 *lang.PersistentVector; lang.PersistentVector_Init(); tmp16 = lang.PersistentVector_EMPTY; tmp3.Invoke_O_O__O(tmp4, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, Lit_150, tmp8, d__3, tmp10, f__4, tmp12, tmp13, tmp15, tmp16.Ref()))); i__28000093__1 = lang.Numbers_Unchecked_inc_J__J(i__28000093__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }








func A_arbace_classes_env_info_A_New() *A_arbace_classes_env_info_A { A_arbace_classes_env_info_A_Init(); t := &A_arbace_classes_env_info_A{}; t.Ctor(); return t }
//line :195:1
func (t *A_arbace_classes_env_info_A) Ctor() {}
//line :195:1
func (t *A_arbace_classes_env_info_A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any = n__0; if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp2 *lang.Var; A_arbace_classes_env_A_Init(); tmp2 = A_arbace_classes_env_A_const_39; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_classes_env_A_Init(); tmp4 = A_arbace_classes_env_A_const_20; tmp1 = tmp3.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O__O(n__0, Lit_146)) } else { tmp1 = and__1927000168__auto____2 }; if jrt.A2g_Truth(tmp1) { var or__1927000174__auto____2 any; var G__28000108__2_ any; var tmp5 *lang.Var; A_arbace_classes_env_A_Init(); tmp5 = A_arbace_classes_env_A_const_89; G__28000108__2_ = jrt.NN(tmp5).Get__O(); var G__28000108__3_ any
		if lang.Util_Identical_O_O__Z(G__28000108__2_, nil) { G__28000108__3_ = nil } else { var tmp6 *lang.Var; A_arbace_classes_env_A_Init(); tmp6 = A_arbace_classes_env_A_const_8; G__28000108__3_ = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(G__28000108__2_) }; if lang.Util_Identical_O_O__Z(G__28000108__3_, nil) { or__1927000174__auto____2 = nil } else { or__1927000174__auto____2 = lang.RT_Get_O_O__O(G__28000108__3_, n__0) }; if jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else {
			var tmp7 *lang.Var; A_arbace_classes_env_A_Init(); tmp7 = A_arbace_classes_env_A_const_19; if jrt.A2g_Truth(jrt.NN(tmp7).Get__O()) {
				var tmp8 *lang.Var; A_arbace_classes_env_A_Init(); tmp8 = A_arbace_classes_env_A_const_18; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(n__0)) { return nil } else { var tmp9 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp9 = A_arbace_classes_env_A_const_90; var tmp10 *lang.Keyword = tmp9; var tmp11 *lang.Var; A_arbace_classes_env_A_Init(); tmp11 = A_arbace_classes_env_A_const_19; return jrt.NN(tmp10).Invoke_O__O(lang.RT_Get_O_O__O(jrt.NN(tmp11).Get__O(), n__0)) } } else {
//line :200:1
					var temp__1927000414__auto____3 any; var tmp12 *lang.Var

					A_arbace_classes_env_A_Init(); tmp12 = A_arbace_classes_env_A_const_25; temp__1927000414__auto____3 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(n__0); if jrt.A2g_Truth(temp__1927000414__auto____3) { var c__4 any = temp__1927000414__auto____3; var d__5 any; var tmp13 *lang.Var
						A_arbace_classes_env_A_Init(); tmp13 = A_arbace_classes_env_A_const_8; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_classes_env_A_Init(); tmp15 = A_arbace_classes_env_A_const_92; d__5 = lang.RT_Get_O_O__O(tmp14.Invoke_O__O(jrt.NN(tmp15).GetRawRoot__O()), n__0)
						var tmp16 any; var and__1927000168__auto____6 any = d__5; if jrt.A2g_Truth(and__1927000168__auto____6) { var tmp17 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp17 = A_arbace_classes_env_A_const_30; tmp16 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Identical_O_O__Z(jrt.NN(tmp17).Invoke_O__O(d__5), c__4)).Ref() } else { tmp16 = and__1927000168__auto____6 }; if jrt.A2g_Truth(tmp16) { return d__5 } else { var tmp18 *lang.Var; A_arbace_classes_env_A_Init(); tmp18 = A_arbace_classes_env_A_const_91; return lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(c__4) } } else {
//line :202:1
							return nil } } } } else {
//line :198:1
								return nil
							}
}





func A_arbace_classes_env_info_BANG__A_New() *A_arbace_classes_env_info_BANG__A { A_arbace_classes_env_info_BANG__A_Init(); t := &A_arbace_classes_env_info_BANG__A{}; t.Ctor(); return t }
//line :206:1
func (t *A_arbace_classes_env_info_BANG__A) Ctor() {}
//line :206:1
func (t *A_arbace_classes_env_info_BANG__A) Invoke_O_O__O(self, n__0 any) any { var or__1927000174__auto____2 any; var tmp1 *lang.Var;
										A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_93; or__1927000174__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(n__0); if jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var tmp2 *lang.Var; A_arbace_classes_env_A_Init(); tmp2 = A_arbace_classes_env_A_const_28; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_164, nil); var tmp5 *lang.Var; A_arbace_classes_env_A_Init(); tmp5 = A_arbace_classes_env_A_const_12; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_classes_env_A_Init(); tmp7 = A_arbace_classes_env_A_const_32; var tmp8 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp6.Invoke_O_O_O__O(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(n__0), Lit_165, Lit_166))).Ref(); var tmp9 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp9 = A_arbace_classes_env_A_const_30; panic(jrt.Thrown(jrt.Throwable_Cast(tmp3.Invoke_O_O__O(tmp8, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp9.Ref(), n__0)))))) } }

func A_arbace_classes_env_interface_QMARK__A_New() *A_arbace_classes_env_interface_QMARK__A { A_arbace_classes_env_interface_QMARK__A_Init(); t := &A_arbace_classes_env_interface_QMARK__A{}; t.Ctor(); return t }
//line :209:1
func (t *A_arbace_classes_env_interface_QMARK__A) Ctor() {}
//line :209:1
func (t *A_arbace_classes_env_interface_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var i__2 any; var tmp1 *lang.Var;
											A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_93; i__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(n__0); var tmp2 any; var or__1927000174__auto____3 any; var tmp3 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp3 = A_arbace_classes_env_A_const_44; or__1927000174__auto____3 = jrt.NN(tmp3).Invoke_O__O(i__2); if jrt.A2g_Truth(or__1927000174__auto____3) { tmp2 = or__1927000174__auto____3 } else { var G__28000111__4_ any; var tmp4 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp4 = A_arbace_classes_env_A_const_43; G__28000111__4_ = jrt.NN(tmp4).Invoke_O__O(i__2); var G__28000111__5_ any; if lang.Util_Identical_O_O__Z(G__28000111__4_, nil) { G__28000111__5_ = nil } else { G__28000111__5_ = jrt.Long_ValueOf_J__Long(lang.Numbers_And_O_J__J(G__28000111__4_, 512)).Ref() }; if lang.Util_Identical_O_O__Z(G__28000111__5_, nil) { tmp2 = nil } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsPos_O__Z(G__28000111__5_)).Ref() } }; return jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(tmp2)).Ref() }

func A_arbace_classes_env_const_value_A_New() *A_arbace_classes_env_const_value_A { A_arbace_classes_env_const_value_A_Init(); t := &A_arbace_classes_env_const_value_A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_classes_env_const_value_A) Ctor() {}
//line :212:1
func (t *A_arbace_classes_env_const_value_A) Invoke_O_O__O(self, field__0 any) any { var c__2 any; var tmp1 *lang.Keyword;
											A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_68; c__2 = jrt.NN(tmp1).Invoke_O__O(field__0); var tmp2 *lang.Var; A_arbace_classes_env_A_Init(); tmp2 = A_arbace_classes_env_A_const_94; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(c__2)) { var tmp3 *lang.Var; A_arbace_classes_env_A_Init(); tmp3 = A_arbace_classes_env_A_const_8; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(c__2) } else { return c__2 } }

func A_arbace_classes_env_supertypes_A_New() *A_arbace_classes_env_supertypes_A { A_arbace_classes_env_supertypes_A_Init(); t := &A_arbace_classes_env_supertypes_A{}; t.Ctor(); return t }
//line :215:1
func (t *A_arbace_classes_env_supertypes_A) Ctor() {}
//line :215:1
func (t *A_arbace_classes_env_supertypes_A) Invoke_O_O__O(self, n__0 any) any { var i__2 any; var tmp1 *lang.Var;


	A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_95; i__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(n__0); var G__28000114__3_ any; var tmp2 /*line :215:1*/*lang.Var;


	A_arbace_classes_env_A_Init(); tmp2 = A_arbace_classes_env_A_const_52; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp4 = A_arbace_classes_env_A_const_46; G__28000114__3_ = tmp3.Invoke_O__O(jrt.NN(tmp4).Invoke_O__O(i__2)); var tmp5 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp5 = A_arbace_classes_env_A_const_45; if jrt.A2g_Truth(jrt.NN(tmp5).Invoke_O__O(i__2)) { var tmp6 *lang.Var; A_arbace_classes_env_A_Init(); tmp6 = A_arbace_classes_env_A_const_52; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_classes_env_A_Init(); tmp8 = A_arbace_classes_env_A_const_73; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp10 = A_arbace_classes_env_A_const_45; return tmp7.Invoke_O__O(tmp9.Invoke_O_O__O(jrt.NN(tmp10).Invoke_O__O(i__2), G__28000114__3_)) } else { return G__28000114__3_ } }

func A_arbace_classes_env_subclass_QMARK__A_New() *A_arbace_classes_env_subclass_QMARK__A { A_arbace_classes_env_subclass_QMARK__A_Init(); t := &A_arbace_classes_env_subclass_QMARK__A{}; t.Ctor(); return t }
//line :220:1
func (t *A_arbace_classes_env_subclass_QMARK__A) Ctor() {}
//line :220:1
func (t *A_arbace_classes_env_subclass_QMARK__A) Invoke_O_O_O__O(self, a__0, b__1 any) any { var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z(a__0, b__1); if or__1927000174__auto____3 {


	return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____3).Ref() } else { var or__1927000174__auto____4 bool = lang.Util_Equiv_O_O__Z(b__1, Lit_134); if or__1927000174__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____4).Ref() } else {
		var tmp1 *lang.Var; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_96; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_classes_env_subclass_QMARK__fn__28000117_A_New_O(b__1); var tmp4 *jrt.Class; A_arbace_classes_env_subclass_QMARK__fn__28000117_A_Init(); tmp4 = A_arbace_classes_env_subclass_QMARK__fn__28000117_A_fn_class; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 any; var temp__1927000414__auto____5 any; var tmp7 *lang.Var; A_arbace_classes_env_A_Init(); tmp7 = A_arbace_classes_env_A_const_93; temp__1927000414__auto____5 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(a__0); if jrt.A2g_Truth(temp__1927000414__auto____5) { var i__6 any = temp__1927000414__auto____5; var G__28000119__7_ any; var tmp8 *lang.Var
			A_arbace_classes_env_A_Init(); tmp8 = A_arbace_classes_env_A_const_52; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp10 = A_arbace_classes_env_A_const_46; G__28000119__7_ = tmp9.Invoke_O__O(jrt.NN(tmp10).Invoke_O__O(i__6)); var tmp11 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp11 = A_arbace_classes_env_A_const_45; if jrt.A2g_Truth(jrt.NN(tmp11).Invoke_O__O(i__6)) { var tmp12 *lang.Var; A_arbace_classes_env_A_Init(); tmp12 = A_arbace_classes_env_A_const_9; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp14 = A_arbace_classes_env_A_const_45; tmp6 = tmp13.Invoke_O_O__O(G__28000119__7_, jrt.NN(tmp14).Invoke_O__O(i__6)) } else { tmp6 = G__28000119__7_ } } else {
//line :224:1
				tmp6 = nil }; return jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(tmp2.Invoke_O_O__O(tmp5, tmp6))).Ref() } } }
//line :224:1
func A_arbace_classes_env_subclass_QMARK__fn__28000117_A_New_O(p0 any) *A_arbace_classes_env_subclass_QMARK__fn__28000117_A { A_arbace_classes_env_subclass_QMARK__fn__28000117_A_Init(); t := &A_arbace_classes_env_subclass_QMARK__fn__28000117_A{}; t.Ctor_O(p0); return t }
//line :224:1
func (t *A_arbace_classes_env_subclass_QMARK__fn__28000117_A) Ctor_O(c__b any) { t.F_b = c__b }
//line :224:1
func (t *A_arbace_classes_env_subclass_QMARK__fn__28000117_A) Invoke_O_O__O(self, p1__28000116_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_97; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(p1__28000116_SHARP___1, t.F_b) }


func A_arbace_classes_env_assignable_QMARK__A_New() *A_arbace_classes_env_assignable_QMARK__A { A_arbace_classes_env_assignable_QMARK__A_Init(); t := &A_arbace_classes_env_assignable_QMARK__A{}; t.Ctor(); return t }
//line :227:1
func (t *A_arbace_classes_env_assignable_QMARK__A) Ctor() {}
//line :227:1
func (t *A_arbace_classes_env_assignable_QMARK__A) Invoke_O_O_O__O(self, from__0, to__1 any) any {


	if lang.Util_Equiv_O_O__Z(from__0, to__1) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { var tmp1 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_98; if lang.Util_Equiv_O_O__Z(from__0, tmp1.Ref()) {

		var tmp2 *lang.Var; A_arbace_classes_env_A_Init(); tmp2 = A_arbace_classes_env_A_const_99; return lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(to__1) } else {
//line :230:1
			var tmp3 *lang.Var; A_arbace_classes_env_A_Init(); tmp3 = A_arbace_classes_env_A_const_39; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any; var and__1927000168__auto____3 any; var tmp6 *lang.Var


			A_arbace_classes_env_A_Init(); tmp6 = A_arbace_classes_env_A_const_99; and__1927000168__auto____3 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(from__0); if jrt.A2g_Truth(and__1927000168__auto____3) { var tmp7 *lang.Var; A_arbace_classes_env_A_Init(); tmp7 = A_arbace_classes_env_A_const_99; tmp5 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(to__1) } else { tmp5 = and__1927000168__auto____3 }
//line :230:1
			if jrt.A2g_Truth(tmp4.Invoke_O__O(tmp5)) { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { var tmp8 *lang.Var; A_arbace_classes_env_A_Init(); tmp8 = A_arbace_classes_env_A_const_100; if lang.Util_Equiv_O_O__Z(to__1, jrt.NN(tmp8).GetRawRoot__O()) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { var tmp9 *lang.Var; A_arbace_classes_env_A_Init(); tmp9 = A_arbace_classes_env_A_const_101; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(from__0)) {





				var tmp10 *lang.Var; A_arbace_classes_env_A_Init(); tmp10 = A_arbace_classes_env_A_const_101; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(to__1)) { var fe__3 any; var tmp11 *lang.Var; A_arbace_classes_env_A_Init(); tmp11 = A_arbace_classes_env_A_const_102; fe__3 = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(from__0); var te__4 any; var tmp12 *lang.Var; A_arbace_classes_env_A_Init(); tmp12 = A_arbace_classes_env_A_const_102; te__4 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(to__1); var and__1927000168__auto____5 any; var tmp13 *lang.Var
					A_arbace_classes_env_A_Init(); tmp13 = A_arbace_classes_env_A_const_99; and__1927000168__auto____5 = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(fe__3); if jrt.A2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var tmp14 *lang.Var; A_arbace_classes_env_A_Init(); tmp14 = A_arbace_classes_env_A_const_99; and__1927000168__auto____6 = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(te__4); if jrt.A2g_Truth(and__1927000168__auto____6) { var tmp15 *lang.Var; A_arbace_classes_env_A_Init(); tmp15 = A_arbace_classes_env_A_const_103; return lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O_O__O(fe__3, te__4) } else { return and__1927000168__auto____6 } } else { return and__1927000168__auto____5 } } else {
//line :236:1
						var tmp16 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp16 = A_arbace_classes_env_A_const_104; if tmp16 != nil {

							var tmp17 *lang.Var; A_arbace_classes_env_A_Init(); tmp17 = A_arbace_classes_env_A_const_23; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any; A_arbace_classes_env_A_Init(); tmp19 = A_arbace_classes_env_A_const_105; return tmp18.Invoke_O_O__O(tmp19, to__1) } else {
//line :236:1
								return nil } } } else {
//line :230:1
									var tmp20 *lang.Var; A_arbace_classes_env_A_Init(); tmp20 = A_arbace_classes_env_A_const_101; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(to__1)) { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { var tmp21 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp21 = A_arbace_classes_env_A_const_104; if tmp21 != nil {









										var tmp22 *lang.Var; A_arbace_classes_env_A_Init(); tmp22 = A_arbace_classes_env_A_const_97; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Var; A_arbace_classes_env_A_Init(); tmp24 = A_arbace_classes_env_A_const_106; var tmp25 any = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(from__0); var tmp26 *lang.Var; A_arbace_classes_env_A_Init(); tmp26 = A_arbace_classes_env_A_const_106; return tmp23.Invoke_O_O__O(tmp25, lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(to__1)) } else {
//line :230:1
											return nil
										}
									}
								}
			}
			}
		}
	}
}



func A_arbace_classes_env_superclass_chain_A_New() *A_arbace_classes_env_superclass_chain_A { A_arbace_classes_env_superclass_chain_A_Init(); t := &A_arbace_classes_env_superclass_chain_A{}; t.Ctor(); return t }
//line :242:1
func (t *A_arbace_classes_env_superclass_chain_A) Ctor() {}
//line :242:1
func (t *A_arbace_classes_env_superclass_chain_A) Invoke_O_O__O(self, n__0 any) any {
	var tmp1 *lang.Var; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_107; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_classes_env_A_Init(); tmp3 = A_arbace_classes_env_A_const_24; var tmp4 any = jrt.NN(tmp3).GetRawRoot__O(); var tmp5 *lang.Var; A_arbace_classes_env_A_Init(); tmp5 = A_arbace_classes_env_A_const_108; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any = A_arbace_classes_env_superclass_chain_fn__28000123_A_New(); var tmp8 *jrt.Class; A_arbace_classes_env_superclass_chain_fn__28000123_A_Init(); tmp8 = A_arbace_classes_env_superclass_chain_fn__28000123_A_fn_class; return tmp2.Invoke_O_O__O(tmp4, tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), n__0)) }
//line :243:1
func A_arbace_classes_env_superclass_chain_fn__28000123_A_New() *A_arbace_classes_env_superclass_chain_fn__28000123_A { A_arbace_classes_env_superclass_chain_fn__28000123_A_Init(); t := &A_arbace_classes_env_superclass_chain_fn__28000123_A{}; t.Ctor(); return t }
//line :243:1
func (t *A_arbace_classes_env_superclass_chain_fn__28000123_A) Ctor() {}
//line :243:1
func (t *A_arbace_classes_env_superclass_chain_fn__28000123_A) Invoke_O_O__O(self, p1__28000122_SHARP___1 any) any { var G__28000124__2_ any = p1__28000122_SHARP___1; var G__28000124__3_ any; if lang.Util_Identical_O_O__Z(G__28000124__2_, nil) { G__28000124__3_ = nil } else { var tmp1 *lang.Var; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_93; G__28000124__3_ = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(G__28000124__2_) }; if lang.Util_Identical_O_O__Z(G__28000124__3_, nil) { return nil } else { var tmp2 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp2 = A_arbace_classes_env_A_const_45; return jrt.NN(tmp2).Invoke_O__O(G__28000124__3_) } }

func A_arbace_classes_env_common_super_A_New() *A_arbace_classes_env_common_super_A { A_arbace_classes_env_common_super_A_Init(); t := &A_arbace_classes_env_common_super_A{}; t.Ctor(); return t }
//line :245:1
func (t *A_arbace_classes_env_common_super_A) Ctor() {}
//line :245:1
func (t *A_arbace_classes_env_common_super_A) Invoke_O_O_O__O(self, a__0, b__1 any) any {


	if lang.Util_Equiv_O_O__Z(a__0, b__1) { return a__0 } else { var tmp1 any; var or__1927000174__auto____3 any; var tmp2 *lang.Var

		A_arbace_classes_env_A_Init(); tmp2 = A_arbace_classes_env_A_const_20; or__1927000174__auto____3 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(a__0, Lit_146); if jrt.A2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var tmp3 *lang.Var; A_arbace_classes_env_A_Init(); tmp3 = A_arbace_classes_env_A_const_20; tmp1 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(b__1, Lit_146) }
//line :248:1
		if jrt.A2g_Truth(tmp1) { return Lit_134 } else { var tmp4 *lang.Var; A_arbace_classes_env_A_Init(); tmp4 = A_arbace_classes_env_A_const_97; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O__O(a__0, b__1)) {


			var tmp5 *lang.Var; A_arbace_classes_env_A_Init(); tmp5 = A_arbace_classes_env_A_const_109; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(b__1)) { return Lit_134 } else { return b__1 } } else {
//line :248:1
				var tmp6 *lang.Var; A_arbace_classes_env_A_Init(); tmp6 = A_arbace_classes_env_A_const_97; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O_O__O(b__1, a__0)) {



					var tmp7 *lang.Var; A_arbace_classes_env_A_Init(); tmp7 = A_arbace_classes_env_A_const_109; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(a__0)) { return Lit_134 } else { return a__0 } } else {
//line :248:1
						var tmp8 any; var or__1927000174__auto____3_2 any; var tmp9 *lang.Var




						A_arbace_classes_env_A_Init(); tmp9 = A_arbace_classes_env_A_const_109; or__1927000174__auto____3_2 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(a__0); if jrt.A2g_Truth(or__1927000174__auto____3_2) { tmp8 = or__1927000174__auto____3_2 } else { var tmp10 *lang.Var; A_arbace_classes_env_A_Init(); tmp10 = A_arbace_classes_env_A_const_109; tmp8 = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(b__1) }
//line :248:1
						if jrt.A2g_Truth(tmp8) { return Lit_134 } else { var tmp11 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp11 = A_arbace_classes_env_A_const_104; if tmp11 != nil { var bs__3 any; var tmp12 *lang.Var





							A_arbace_classes_env_A_Init(); tmp12 = A_arbace_classes_env_A_const_110; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_classes_env_A_Init(); tmp14 = A_arbace_classes_env_A_const_111; bs__3 = tmp13.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(b__1))
//line :248:1
							var or__1927000174__auto____4 any; var tmp15 *lang.Var






							A_arbace_classes_env_A_Init(); tmp15 = A_arbace_classes_env_A_const_63; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_classes_env_A_Init(); tmp17 = A_arbace_classes_env_A_const_86; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_classes_env_A_Init(); tmp19 = A_arbace_classes_env_A_const_111; or__1927000174__auto____4 = tmp16.Invoke_O__O(tmp18.Invoke_O_O__O(bs__3, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(a__0))); if jrt.A2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { return Lit_134 } } else {
//line :248:1
								return nil
							}
						}
					}
			}
		}
	}
}

func A_arbace_classes_env_lub_A_New() *A_arbace_classes_env_lub_A { A_arbace_classes_env_lub_A_Init(); t := &A_arbace_classes_env_lub_A{}; t.Ctor(); return t }
//line :257:1
func (t *A_arbace_classes_env_lub_A) Ctor() {}
//line :257:1
func (t *A_arbace_classes_env_lub_A) Invoke_O_O_O__O(self, a__0, b__1 any) any {



	if lang.Util_Equiv_O_O__Z(a__0, b__1) { return a__0 } else { var tmp1 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_98; if lang.Util_Equiv_O_O__Z(a__0, tmp1.Ref()) { return b__1 } else { var tmp2 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp2 = A_arbace_classes_env_A_const_98; if lang.Util_Equiv_O_O__Z(b__1, tmp2.Ref()) { return a__0 } else { var tmp3 *lang.Var; A_arbace_classes_env_A_Init(); tmp3 = A_arbace_classes_env_A_const_103; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(a__0, b__1)) { return b__1 } else { var tmp4 *lang.Var; A_arbace_classes_env_A_Init(); tmp4 = A_arbace_classes_env_A_const_103; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O__O(b__1, a__0)) { return a__0 } else { var tmp5 any; var and__1927000168__auto____3 any; var tmp6 *lang.Var




		A_arbace_classes_env_A_Init(); tmp6 = A_arbace_classes_env_A_const_112; and__1927000168__auto____3 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(a__0); if jrt.A2g_Truth(and__1927000168__auto____3) { var tmp7 *lang.Var; A_arbace_classes_env_A_Init(); tmp7 = A_arbace_classes_env_A_const_112; tmp5 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(b__1) } else { tmp5 = and__1927000168__auto____3 }
//line :261:1
		if jrt.A2g_Truth(tmp5) { var c__3 any; var tmp8 *lang.Var





			A_arbace_classes_env_A_Init(); tmp8 = A_arbace_classes_env_A_const_113; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_classes_env_A_Init(); tmp10 = A_arbace_classes_env_A_const_106; var tmp11 any = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(a__0); var tmp12 *lang.Var; A_arbace_classes_env_A_Init(); tmp12 = A_arbace_classes_env_A_const_106; c__3 = tmp9.Invoke_O_O__O(tmp11, lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(b__1))
			if lang.Util_Equiv_O_O__Z(c__3, Lit_134) { var sups__4 any; var tmp13 any = A_arbace_classes_env_lub_sups__28000129_A_New(); var tmp14 *jrt.Class

				A_arbace_classes_env_lub_sups__28000129_A_Init(); tmp14 = A_arbace_classes_env_lub_sups__28000129_A_fn_class; sups__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil)
//line :268:1
				var common__5 any; var tmp15 *lang.Var




				A_arbace_classes_env_A_Init(); tmp15 = A_arbace_classes_env_A_const_86; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_classes_env_A_Init(); tmp17 = A_arbace_classes_env_A_const_109; var tmp18 any = jrt.NN(tmp17).GetRawRoot__O(); var tmp19 *lang.Var; A_arbace_classes_env_A_Init(); tmp19 = A_arbace_classes_env_A_const_117; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 lang.IFn = lang.IFn_Cast(sups__4); var tmp22 *lang.Var; A_arbace_classes_env_A_Init(); tmp22 = A_arbace_classes_env_A_const_106; var tmp23 any = tmp21.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(a__0)); var tmp24 lang.IFn = lang.IFn_Cast(sups__4); var tmp25 *lang.Var; A_arbace_classes_env_A_Init(); tmp25 = A_arbace_classes_env_A_const_106; common__5 = tmp16.Invoke_O_O__O(tmp18, tmp20.Invoke_O_O__O(tmp23, tmp24.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(b__1))))
//line :268:1
				var minimal__6 any; var tmp26 *lang.Var






				A_arbace_classes_env_A_Init(); tmp26 = A_arbace_classes_env_A_const_115; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 any = A_arbace_classes_env_lub_fn__28000134_A_New_O(common__5); var tmp29 *jrt.Class; A_arbace_classes_env_lub_fn__28000134_A_Init(); tmp29 = A_arbace_classes_env_lub_fn__28000134_A_fn_class; minimal__6 = tmp27.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil), common__5)
				if lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(minimal__6))) { var tmp30 *lang.Var; A_arbace_classes_env_A_Init(); tmp30 = A_arbace_classes_env_A_const_116; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *lang.Var; A_arbace_classes_env_A_Init(); tmp32 = A_arbace_classes_env_A_const_63; return tmp31.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()).Invoke_O__O(minimal__6)) } else { var tmp33 *lang.Var; A_arbace_classes_env_A_Init(); tmp33 = A_arbace_classes_env_A_const_100; return jrt.NN(tmp33).GetRawRoot__O() } } else {
					var tmp34 *lang.Var; A_arbace_classes_env_A_Init(); tmp34 = A_arbace_classes_env_A_const_116; return lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()).Invoke_O__O(c__3) } } else {
//line :261:1
						var tmp35 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp35 = A_arbace_classes_env_A_const_104; if tmp35 != nil { var tmp36 *lang.Var; A_arbace_classes_env_A_Init(); tmp36 = A_arbace_classes_env_A_const_100; return jrt.NN(tmp36).GetRawRoot__O() } else { return nil
						}
					}
	}
	}
	}
	}
	}
}
func A_arbace_classes_env_lub_sups__28000129_A_New() *A_arbace_classes_env_lub_sups__28000129_A { A_arbace_classes_env_lub_sups__28000129_A_Init(); t := &A_arbace_classes_env_lub_sups__28000129_A{}; t.Ctor(); return t }
//line :270:1
func (t *A_arbace_classes_env_lub_sups__28000129_A) Ctor() {}
//line :270:1
func (t *A_arbace_classes_env_lub_sups__28000129_A) Invoke_O_O__O(self, n__1 any) any { var tmp1 *lang.Var; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_110; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_classes_env_A_Init(); tmp3 = A_arbace_classes_env_A_const_114; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_classes_env_A_Init(); tmp5 = A_arbace_classes_env_A_const_24; var tmp6 any = jrt.NN(tmp5).GetRawRoot__O(); var tmp7 any = A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_New(); var tmp8 *jrt.Class; A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_Init(); tmp8 = A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_fn_class; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp6, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), n__1)) }
//line :270:1
func A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_New() *A_arbace_classes_env_lub_sups__28000129_fn__28000130_A { A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_Init(); t := &A_arbace_classes_env_lub_sups__28000129_fn__28000130_A{}; t.Ctor(); return t }
//line :270:1
func (t *A_arbace_classes_env_lub_sups__28000129_fn__28000130_A) Ctor() {}
//line :270:1
func (t *A_arbace_classes_env_lub_sups__28000129_fn__28000130_A) Invoke_O_O__O(self, x__1 any) any { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_93; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(x__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var i__3 any = temp__1927000414__auto____2; var G__28000131__4_ any; var tmp2 *lang.Var
													A_arbace_classes_env_A_Init(); tmp2 = A_arbace_classes_env_A_const_52; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp4 = A_arbace_classes_env_A_const_46; G__28000131__4_ = tmp3.Invoke_O__O(jrt.NN(tmp4).Invoke_O__O(i__3)); var tmp5 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp5 = A_arbace_classes_env_A_const_45; if jrt.A2g_Truth(jrt.NN(tmp5).Invoke_O__O(i__3)) { var tmp6 *lang.Var; A_arbace_classes_env_A_Init(); tmp6 = A_arbace_classes_env_A_const_9; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp8 = A_arbace_classes_env_A_const_45; return tmp7.Invoke_O_O__O(G__28000131__4_, jrt.NN(tmp8).Invoke_O__O(i__3)) } else { return G__28000131__4_ } } else {
//line :270:1
		return nil } }




func A_arbace_classes_env_lub_fn__28000134_A_New_O(p0 any) *A_arbace_classes_env_lub_fn__28000134_A { A_arbace_classes_env_lub_fn__28000134_A_Init(); t := &A_arbace_classes_env_lub_fn__28000134_A{}; t.Ctor_O(p0); return t }
//line :275:1
func (t *A_arbace_classes_env_lub_fn__28000134_A) Ctor_O(c__common any) { t.F_common = c__common }
//line :275:1
func (t *A_arbace_classes_env_lub_fn__28000134_A) Invoke_O_O__O(self, i__1 any) any { var tmp1 *lang.Var; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_96; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_New_O(i__1); var tmp4 *jrt.Class; A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_Init(); tmp4 = A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_fn_class; return tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), t.F_common) }
//line :275:1
func A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_New_O(p0 any) *A_arbace_classes_env_lub_fn__28000134_fn__28000135_A { A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_Init(); t := &A_arbace_classes_env_lub_fn__28000134_fn__28000135_A{}; t.Ctor_O(p0); return t }
//line :275:1
func (t *A_arbace_classes_env_lub_fn__28000134_fn__28000135_A) Ctor_O(c__i any) { t.F_i = c__i }
//line :275:1
func (t *A_arbace_classes_env_lub_fn__28000134_fn__28000135_A) Invoke_O_O__O(self, p1__28000128_SHARP___1 any) any { var and__1927000168__auto____2 any; var tmp1 *lang.Var; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_118; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(p1__28000128_SHARP___1, t.F_i); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp2 *lang.Var; A_arbace_classes_env_A_Init(); tmp2 = A_arbace_classes_env_A_const_97; return lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(p1__28000128_SHARP___1, t.F_i) } else { return and__1927000168__auto____2 } }






func A_arbace_classes_env_nest_host_A_New() *A_arbace_classes_env_nest_host_A { A_arbace_classes_env_nest_host_A_Init(); t := &A_arbace_classes_env_nest_host_A{}; t.Ctor(); return t }
//line :282:1
func (t *A_arbace_classes_env_nest_host_A) Ctor() {}
//line :282:1
func (t *A_arbace_classes_env_nest_host_A) Invoke_O_O__O(self, n__0 any) any { var i__2 any; var tmp1 *lang.Var;
										A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_93; i__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(n__0); var or__1927000174__auto____3 any; var tmp2 /*line :282:1*/*lang.Keyword;

	A_arbace_classes_env_A_Init(); tmp2 = A_arbace_classes_env_A_const_48; or__1927000174__auto____3 = jrt.NN(tmp2).Invoke_O__O(i__2); if jrt.A2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var temp__1927000408__auto____4 any; var tmp3 *lang.Keyword
		A_arbace_classes_env_A_Init(); tmp3 = A_arbace_classes_env_A_const_49; temp__1927000408__auto____4 = jrt.NN(tmp3).Invoke_O__O(i__2); if jrt.A2g_Truth(temp__1927000408__auto____4) { var o__5 any = temp__1927000408__auto____4; var tmp4 *lang.Var; A_arbace_classes_env_A_Init(); tmp4 = A_arbace_classes_env_A_const_119; return lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(o__5) } else { return n__0 } } }

func A_arbace_classes_env_flag_QMARK__A_New() *A_arbace_classes_env_flag_QMARK__A { A_arbace_classes_env_flag_QMARK__A_Init(); t := &A_arbace_classes_env_flag_QMARK__A{}; t.Ctor(); return t }
//line :287:1
func (t *A_arbace_classes_env_flag_QMARK__A) Ctor() {}
//line :287:1
func (t *A_arbace_classes_env_flag_QMARK__A) Invoke_O_O_O__O(self, flags__0, f__1 any) any { var tmp1 *lang.Var; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_39; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsZero_J__Z(lang.Numbers_And_O_O__J(flags__0, f__1))).Ref()) }

func A_arbace_classes_env_accessible_QMARK__A_New() *A_arbace_classes_env_accessible_QMARK__A { A_arbace_classes_env_accessible_QMARK__A_Init(); t := &A_arbace_classes_env_accessible_QMARK__A{}; t.Ctor(); return t }
//line :289:1
func (t *A_arbace_classes_env_accessible_QMARK__A) Ctor() {}
//line :289:1
func (t *A_arbace_classes_env_accessible_QMARK__A) Invoke_O_O_O__O(self, from__0, m__1 any) any { var fl__3 any; var tmp1 *lang.Keyword;


	A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_43; fl__3 = jrt.NN(tmp1).Invoke_O__O(m__1); var owner__4 any; var tmp2 /*line :289:1*/*lang.Keyword;


	A_arbace_classes_env_A_Init(); tmp2 = A_arbace_classes_env_A_const_67; owner__4 = jrt.NN(tmp2).Invoke_O__O(m__1); var tmp3 /*line :293:1*/*lang.Var; A_arbace_classes_env_A_Init(); tmp3 = A_arbace_classes_env_A_const_120; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any; A_arbace_classes_env_A_Init(); tmp5 = A_arbace_classes_env_A_const_122; if jrt.A2g_Truth(tmp4.Invoke_O_O__O(fl__3, tmp5)) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { var tmp6 *lang.Var; A_arbace_classes_env_A_Init(); tmp6 = A_arbace_classes_env_A_const_120; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 any; A_arbace_classes_env_A_Init(); tmp8 = A_arbace_classes_env_A_const_123; if jrt.A2g_Truth(tmp7.Invoke_O_O__O(fl__3, tmp8)) {

		var tmp9 *lang.Var; A_arbace_classes_env_A_Init(); tmp9 = A_arbace_classes_env_A_const_119; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(from__0); var tmp11 *lang.Var; A_arbace_classes_env_A_Init(); tmp11 = A_arbace_classes_env_A_const_119; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp10, lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(owner__4))).Ref() } else {
//line :293:1
			var tmp12 *lang.Var; A_arbace_classes_env_A_Init(); tmp12 = A_arbace_classes_env_A_const_121; var tmp13 any = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(from__0); var tmp14 *lang.Var; A_arbace_classes_env_A_Init(); tmp14 = A_arbace_classes_env_A_const_121; if lang.Util_Equiv_O_O__Z(tmp13, lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(owner__4)) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { var tmp15 *lang.Var; A_arbace_classes_env_A_Init(); tmp15 = A_arbace_classes_env_A_const_120; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_classes_env_A_Init(); tmp17 = A_arbace_classes_env_A_const_124; if jrt.A2g_Truth(tmp16.Invoke_O_O__O(fl__3, tmp17)) {




				var tmp18 *lang.Var; A_arbace_classes_env_A_Init(); tmp18 = A_arbace_classes_env_A_const_96; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 any = A_arbace_classes_env_accessible_QMARK__fn__28000143_A_New_O(owner__4); var tmp21 *jrt.Class; A_arbace_classes_env_accessible_QMARK__fn__28000143_A_Init(); tmp21 = A_arbace_classes_env_accessible_QMARK__fn__28000143_A_fn_class; var tmp22 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil); var tmp23 *lang.Var; A_arbace_classes_env_A_Init(); tmp23 = A_arbace_classes_env_A_const_107; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_classes_env_A_Init(); tmp25 = A_arbace_classes_env_A_const_24; var tmp26 any = jrt.NN(tmp25).GetRawRoot__O(); var tmp27 *lang.Var; A_arbace_classes_env_A_Init(); tmp27 = A_arbace_classes_env_A_const_108; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 any = A_arbace_classes_env_accessible_QMARK__fn__28000145_A_New(); var tmp30 *jrt.Class; A_arbace_classes_env_accessible_QMARK__fn__28000145_A_Init(); tmp30 = A_arbace_classes_env_accessible_QMARK__fn__28000145_A_fn_class; return jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(tmp19.Invoke_O_O__O(tmp22, tmp24.Invoke_O_O__O(tmp26, tmp28.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp29, tmp30, nil), from__0))))).Ref() } else {
//line :293:1
					var tmp31 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp31 = A_arbace_classes_env_A_const_104; if tmp31 != nil { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { return nil } } } } } }




func A_arbace_classes_env_accessible_QMARK__fn__28000143_A_New_O(p0 any) *A_arbace_classes_env_accessible_QMARK__fn__28000143_A { A_arbace_classes_env_accessible_QMARK__fn__28000143_A_Init(); t := &A_arbace_classes_env_accessible_QMARK__fn__28000143_A{}; t.Ctor_O(p0); return t }
//line :298:1
func (t *A_arbace_classes_env_accessible_QMARK__fn__28000143_A) Ctor_O(c__owner any) { t.F_owner = c__owner }
//line :298:1
func (t *A_arbace_classes_env_accessible_QMARK__fn__28000143_A) Invoke_O_O__O(self, p1__28000141_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_97; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(p1__28000141_SHARP___1, t.F_owner) }
func A_arbace_classes_env_accessible_QMARK__fn__28000145_A_New() *A_arbace_classes_env_accessible_QMARK__fn__28000145_A { A_arbace_classes_env_accessible_QMARK__fn__28000145_A_Init(); t := &A_arbace_classes_env_accessible_QMARK__fn__28000145_A{}; t.Ctor(); return t }
//line :299:1
func (t *A_arbace_classes_env_accessible_QMARK__fn__28000145_A) Ctor() {}
//line :299:1
func (t *A_arbace_classes_env_accessible_QMARK__fn__28000145_A) Invoke_O_O__O(self, p1__28000142_SHARP___1 any) any { var tmp1 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_49; var tmp2 *lang.Keyword = tmp1; var tmp3 *lang.Var; A_arbace_classes_env_A_Init(); tmp3 = A_arbace_classes_env_A_const_93; return jrt.NN(tmp2).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(p1__28000142_SHARP___1)) }


func A_arbace_classes_env_find_field_A_New() *A_arbace_classes_env_find_field_A { A_arbace_classes_env_find_field_A_Init(); t := &A_arbace_classes_env_find_field_A{}; t.Ctor(); return t }
//line :302:1
func (t *A_arbace_classes_env_find_field_A) Ctor() {}
//line :302:1
func (t *A_arbace_classes_env_find_field_A) Invoke_O_O_O__O(self, n__0, name__1 any) any { var temp__1927000414__auto____3 any; var tmp1 *lang.Var;



	A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_93; temp__1927000414__auto____3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(n__0); if jrt.A2g_Truth(temp__1927000414__auto____3) { var i__4 any = temp__1927000414__auto____3; var or__1927000174__auto____5 any; var tmp2 *lang.Var
		A_arbace_classes_env_A_Init(); tmp2 = A_arbace_classes_env_A_const_63; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_classes_env_A_Init(); tmp4 = A_arbace_classes_env_A_const_86; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any = A_arbace_classes_env_find_field_fn__28000150_A_New_O(name__1); var tmp7 *jrt.Class; A_arbace_classes_env_find_field_fn__28000150_A_Init(); tmp7 = A_arbace_classes_env_find_field_fn__28000150_A_fn_class; var tmp8 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp9 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp9 = A_arbace_classes_env_A_const_50; or__1927000174__auto____5 = tmp3.Invoke_O__O(tmp5.Invoke_O_O__O(tmp8, jrt.NN(tmp9).Invoke_O__O(i__4))); if jrt.A2g_Truth(or__1927000174__auto____5) { return or__1927000174__auto____5 } else { var or__1927000174__auto____6 any; var tmp10 *lang.Var
			A_arbace_classes_env_A_Init(); tmp10 = A_arbace_classes_env_A_const_96; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 any = A_arbace_classes_env_find_field_fn__28000152_A_New_O(name__1); var tmp13 *jrt.Class; A_arbace_classes_env_find_field_fn__28000152_A_Init(); tmp13 = A_arbace_classes_env_find_field_fn__28000152_A_fn_class; var tmp14 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); var tmp15 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp15 = A_arbace_classes_env_A_const_46; or__1927000174__auto____6 = tmp11.Invoke_O_O__O(tmp14, jrt.NN(tmp15).Invoke_O__O(i__4))
//line :307:1
			if jrt.A2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else { var G__28000154__7_ any; var tmp16 *lang.Keyword

				A_arbace_classes_env_A_Init(); tmp16 = A_arbace_classes_env_A_const_45; G__28000154__7_ = jrt.NN(tmp16).Invoke_O__O(i__4); if lang.Util_Identical_O_O__Z(G__28000154__7_, nil) { return nil } else { var tmp17 *lang.Var; A_arbace_classes_env_A_Init(); tmp17 = A_arbace_classes_env_A_const_125; return lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O_O__O(G__28000154__7_, name__1) } } } } else {
//line :306:1
					return nil } }
func A_arbace_classes_env_find_field_fn__28000150_A_New_O(p0 any) *A_arbace_classes_env_find_field_fn__28000150_A { A_arbace_classes_env_find_field_fn__28000150_A_Init(); t := &A_arbace_classes_env_find_field_fn__28000150_A{}; t.Ctor_O(p0); return t }
//line :307:1
func (t *A_arbace_classes_env_find_field_fn__28000150_A) Ctor_O(c__name any) { t.F_name = c__name }
//line :307:1
func (t *A_arbace_classes_env_find_field_fn__28000150_A) Invoke_O_O__O(self, p1__28000148_SHARP___1 any) any { var tmp1 any = t.F_name; var tmp2 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp2 = A_arbace_classes_env_A_const_42; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp1, jrt.NN(tmp2).Invoke_O__O(p1__28000148_SHARP___1))).Ref() }
func A_arbace_classes_env_find_field_fn__28000152_A_New_O(p0 any) *A_arbace_classes_env_find_field_fn__28000152_A { A_arbace_classes_env_find_field_fn__28000152_A_Init(); t := &A_arbace_classes_env_find_field_fn__28000152_A{}; t.Ctor_O(p0); return t }
//line :308:1
func (t *A_arbace_classes_env_find_field_fn__28000152_A) Ctor_O(c__name any) { t.F_name = c__name }
//line :308:1
func (t *A_arbace_classes_env_find_field_fn__28000152_A) Invoke_O_O__O(self, p1__28000149_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_125; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(p1__28000149_SHARP___1, t.F_name) }


func A_arbace_classes_env_all_supertypes_A_New() *A_arbace_classes_env_all_supertypes_A { A_arbace_classes_env_all_supertypes_A_Init(); t := &A_arbace_classes_env_all_supertypes_A{}; t.Ctor(); return t }
//line :311:1
func (t *A_arbace_classes_env_all_supertypes_A) Ctor() {}
//line :311:1
func (t *A_arbace_classes_env_all_supertypes_A) Invoke_O_O__O(self, n__0 any) any { { var chain__2 any; var tmp1 *lang.Var


	A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_52; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_classes_env_A_Init(); tmp3 = A_arbace_classes_env_A_const_111; chain__2 = tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(n__0))
//line :311:1
	var out__3 any = chain__2; var seen__4 any; var tmp4 *lang.Var



	A_arbace_classes_env_A_Init(); tmp4 = A_arbace_classes_env_A_const_110; seen__4 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(chain__2)
//line :311:1
	var queue__5 any; var tmp5 *lang.Var



	A_arbace_classes_env_A_Init(); tmp5 = A_arbace_classes_env_A_const_52; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_classes_env_A_Init(); tmp7 = A_arbace_classes_env_A_const_126; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any = A_arbace_classes_env_all_supertypes_fn__28000157_A_New(); var tmp10 *jrt.Class; A_arbace_classes_env_all_supertypes_fn__28000157_A_Init(); tmp10 = A_arbace_classes_env_all_supertypes_fn__28000157_A_fn_class; queue__5 = tmp6.Invoke_O__O(tmp8.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), chain__2))
//line :311:1
L1: for { var temp__1927000408__auto____6 any; var tmp11 *lang.Var




	A_arbace_classes_env_A_Init(); tmp11 = A_arbace_classes_env_A_const_57; temp__1927000408__auto____6 = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(queue__5); if jrt.A2g_Truth(temp__1927000408__auto____6) { var vec__28000159__7 any = temp__1927000408__auto____6; var seq__28000160__8 any; var tmp12 *lang.Var; A_arbace_classes_env_A_Init(); tmp12 = A_arbace_classes_env_A_const_57; seq__28000160__8 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(vec__28000159__7); var first__28000161__9 any; var tmp13 *lang.Var; A_arbace_classes_env_A_Init(); tmp13 = A_arbace_classes_env_A_const_63; first__28000161__9 = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(seq__28000160__8); var seq__28000160__10 any; var tmp14 *lang.Var; A_arbace_classes_env_A_Init(); tmp14 = A_arbace_classes_env_A_const_61; seq__28000160__10 = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(seq__28000160__8); var q__11 any = first__28000161__9; var more__12 any = seq__28000160__10
		if jrt.A2g_Truth(lang.IFn_Cast(seen__4).Invoke_O__O(q__11)) {
			var tmp15 *lang.Var; A_arbace_classes_env_A_Init(); tmp15 = A_arbace_classes_env_A_const_52; out__3, seen__4, queue__5 = out__3, seen__4, lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(more__12); continue L1 } else {
				var tmp16 *lang.Var; A_arbace_classes_env_A_Init(); tmp16 = A_arbace_classes_env_A_const_9; var tmp17 any = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O_O__O(out__3, q__11); var tmp18 *lang.Var; A_arbace_classes_env_A_Init(); tmp18 = A_arbace_classes_env_A_const_9; var tmp19 any = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O_O__O(seen__4, q__11); var tmp20 *lang.Var; A_arbace_classes_env_A_Init(); tmp20 = A_arbace_classes_env_A_const_87; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Var; A_arbace_classes_env_A_Init(); tmp22 = A_arbace_classes_env_A_const_52; var tmp23 any = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(more__12); var tmp24 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp24 = A_arbace_classes_env_A_const_46; var tmp25 *lang.Keyword = tmp24; var tmp26 *lang.Var; A_arbace_classes_env_A_Init(); tmp26 = A_arbace_classes_env_A_const_93; out__3, seen__4, queue__5 = tmp17, tmp19, tmp21.Invoke_O_O__O(tmp23, jrt.NN(tmp25).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(q__11))); continue L1 } } else {
//line :316:1
					var G__28000162__7_ any = out__3; var tmp27 any; var and__1927000168__auto____8 any; var tmp28 *lang.Var



					A_arbace_classes_env_A_Init(); tmp28 = A_arbace_classes_env_A_const_109; and__1927000168__auto____8 = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(n__0); if jrt.A2g_Truth(and__1927000168__auto____8) { var tmp29 *lang.Var; A_arbace_classes_env_A_Init(); tmp29 = A_arbace_classes_env_A_const_39; tmp27 = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(seen__4).Invoke_O__O(Lit_134)) } else { tmp27 = and__1927000168__auto____8 }; if jrt.A2g_Truth(tmp27) { var tmp30 *lang.Var; A_arbace_classes_env_A_Init(); tmp30 = A_arbace_classes_env_A_const_9; return lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O_O__O(G__28000162__7_, Lit_134) } else { return G__28000162__7_ } } } }; /*line :311:1*/panic("a2g: unreachable") }



func A_arbace_classes_env_all_supertypes_fn__28000157_A_New() *A_arbace_classes_env_all_supertypes_fn__28000157_A { A_arbace_classes_env_all_supertypes_fn__28000157_A_Init(); t := &A_arbace_classes_env_all_supertypes_fn__28000157_A{}; t.Ctor(); return t }
//line :315:1
func (t *A_arbace_classes_env_all_supertypes_fn__28000157_A) Ctor() {}
//line :315:1
func (t *A_arbace_classes_env_all_supertypes_fn__28000157_A) Invoke_O_O__O(self, p1__28000156_SHARP___1 any) any { var tmp1 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_46; var tmp2 *lang.Keyword = tmp1; var tmp3 *lang.Var; A_arbace_classes_env_A_Init(); tmp3 = A_arbace_classes_env_A_const_93; return jrt.NN(tmp2).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(p1__28000156_SHARP___1)) }






func A_arbace_classes_env_params_key_A_New() *A_arbace_classes_env_params_key_A { A_arbace_classes_env_params_key_A_Init(); t := &A_arbace_classes_env_params_key_A{}; t.Ctor(); return t }
//line :322:1
func (t *A_arbace_classes_env_params_key_A) Ctor() {}
//line :322:1
func (t *A_arbace_classes_env_params_key_A) Invoke_O_O__O(self, desc__0 any) any { var tmp1 *lang.Var; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_127; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_classes_env_A_Init(); tmp3 = A_arbace_classes_env_A_const_128; var tmp4 any = tmp3; return tmp2.Invoke_O_O_O__O(desc__0, tmp4, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(jrt.NN(jrt.String_Cast(desc__0)).IndexOf_String__I(Lit_183)))).Ref()) }

func A_arbace_classes_env_member_methods_A_New() *A_arbace_classes_env_member_methods_A { A_arbace_classes_env_member_methods_A_Init(); t := &A_arbace_classes_env_member_methods_A{}; t.Ctor(); return t }
//line :324:1
func (t *A_arbace_classes_env_member_methods_A) Ctor() {}
//line :324:1
func (t *A_arbace_classes_env_member_methods_A) Invoke_O_O_O__O(self, n__0, name__1 any) any { { var G__28000168__3_ any; var tmp1 *lang.Var



	A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_129; G__28000168__3_ = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(n__0)
//line :324:1
	var vec__28000169__4 any = G__28000168__3_; var seq__28000170__5 any; var tmp2 *lang.Var



	A_arbace_classes_env_A_Init(); tmp2 = A_arbace_classes_env_A_const_57; seq__28000170__5 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(vec__28000169__4)
//line :324:1
	var first__28000171__6 any; var tmp3 *lang.Var



	A_arbace_classes_env_A_Init(); tmp3 = A_arbace_classes_env_A_const_63; first__28000171__6 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(seq__28000170__5)
//line :324:1
	var seq__28000170__7 any; var tmp4 *lang.Var



	A_arbace_classes_env_A_Init(); tmp4 = A_arbace_classes_env_A_const_61; seq__28000170__7 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(seq__28000170__5)
//line :324:1
	var c__8 any = first__28000171__6; var more__9 any = seq__28000170__7; var seen__10 any; _ = c__8; _ = more__9; lang.PersistentHashSet_Init(); seen__10 = lang.PersistentHashSet_EMPTY.Ref(); var out__11 any; lang.PersistentVector_Init(); out__11 = lang.PersistentVector_EMPTY.Ref(); var G__28000168__12_ any = G__28000168__3_; var seen__13 any = seen__10; var out__14 any = out__11; L1: for { var vec__28000172__15 any = G__28000168__12_; var seq__28000173__16 any; var tmp5 *lang.Var



		A_arbace_classes_env_A_Init(); tmp5 = A_arbace_classes_env_A_const_57; seq__28000173__16 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(vec__28000172__15)
//line :324:1
		var first__28000174__17 any; var tmp6 *lang.Var



		A_arbace_classes_env_A_Init(); tmp6 = A_arbace_classes_env_A_const_63; first__28000174__17 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(seq__28000173__16)
//line :324:1
		var seq__28000173__18 any; var tmp7 *lang.Var



		A_arbace_classes_env_A_Init(); tmp7 = A_arbace_classes_env_A_const_61; seq__28000173__18 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(seq__28000173__16)
//line :324:1
		var c__19 any = first__28000174__17; var more__20 any = seq__28000173__18; var seen__21 any = seen__13; var out__22 any = out__14; var tmp8 *lang.Var




		A_arbace_classes_env_A_Init(); tmp8 = A_arbace_classes_env_A_const_39; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(c__19)) { return out__22 } else { var ms__23 any; var iter__1927001039__auto____23 any; var tmp9 any = A_arbace_classes_env_member_methods_iter__28000175__28000179_A_New_O_O_O_O(seen__21, name__1, n__0, c__19); var tmp10 *jrt.Class

			A_arbace_classes_env_member_methods_iter__28000175__28000179_A_Init(); tmp10 = A_arbace_classes_env_member_methods_iter__28000175__28000179_A_fn_class; iter__1927001039__auto____23 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var tmp11 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____23); var tmp12 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp12 = A_arbace_classes_env_A_const_55; var tmp13 *lang.Keyword = tmp12; var tmp14 *lang.Var; A_arbace_classes_env_A_Init(); tmp14 = A_arbace_classes_env_A_const_95; ms__23 = tmp11.Invoke_O__O(jrt.NN(tmp13).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(c__19)))






			var tmp15 *lang.Var; A_arbace_classes_env_A_Init(); tmp15 = A_arbace_classes_env_A_const_87; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_classes_env_A_Init(); tmp17 = A_arbace_classes_env_A_const_80; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_classes_env_A_Init(); tmp19 = A_arbace_classes_env_A_const_133; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_classes_env_A_Init(); tmp21 = A_arbace_classes_env_A_const_132; var tmp22 any = jrt.NN(tmp21).GetRawRoot__O(); var tmp23 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp23 = A_arbace_classes_env_A_const_64; var tmp24 any = tmp16.Invoke_O_O__O(seen__21, tmp18.Invoke_O_O__O(tmp20.Invoke_O_O__O(tmp22, tmp23.Ref()), ms__23)); var tmp25 *lang.Var; A_arbace_classes_env_A_Init(); tmp25 = A_arbace_classes_env_A_const_87; G__28000168__12_, seen__13, out__14 = more__20, tmp24, lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O_O__O(out__22, ms__23); continue L1 } } }; /*line :324:1*/panic("a2g: unreachable") }






func A_arbace_classes_env_member_methods_iter__28000175__28000179_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_member_methods_iter__28000175__28000179_A { A_arbace_classes_env_member_methods_iter__28000175__28000179_A_Init(); t := &A_arbace_classes_env_member_methods_iter__28000175__28000179_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :331:1
func (t *A_arbace_classes_env_member_methods_iter__28000175__28000179_A) Ctor_O_O_O_O(c__seen, c__name, c__n, c__c any) { t.F_seen = c__seen; t.F_name = c__name; t.F_n = c__n; t.F_c = c__c }
//line :331:1
func (t *A_arbace_classes_env_member_methods_iter__28000175__28000179_A) Invoke_O_O__O(self, s__28000176__1 any) any { var tmp1 any = A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_New_O_O_O_O_O_O(t.F_seen, t.F_name, t.F_n, t.F_c, s__28000176__1, self); var tmp2 *jrt.Class; A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_Init(); tmp2 = A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :331:1
func A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A { A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_Init(); t := &A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :331:1
func (t *A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A) Ctor_O_O_O_O_O_O(c__seen, c__name, c__n, c__c, c__s__28000176, c__iter__28000175 any) { t.F_seen = c__seen; t.F_name = c__name; t.F_n = c__n; t.F_c = c__c; t.F_s__28000176 = c__s__28000176; t.F_iter__28000175 = c__iter__28000175 }
//line :331:1
func (t *A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A) Invoke_O__O(self any) any { { var s__28000176__1 any; var t_ any = t.F_s__28000176; t.F_s__28000176 = nil; s__28000176__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_57; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__28000176__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__28000176__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_classes_env_A_Init(); tmp2 = A_arbace_classes_env_A_const_58; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__28000176__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_classes_env_A_Init(); tmp3 = A_arbace_classes_env_A_const_59; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__28000176__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__28000178__6 any; var tmp4 *lang.Var; A_arbace_classes_env_A_Init(); tmp4 = A_arbace_classes_env_A_const_60; b__28000178__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_New_O_O_O_O_O_I_O(b__28000178__6, t.F_seen, t.F_name, t.F_n, t.F_c, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_Init(); tmp6 = A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_classes_env_A_Init(); tmp7 = A_arbace_classes_env_A_const_72; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_classes_env_A_Init(); tmp9 = A_arbace_classes_env_A_const_74; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__28000178__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__28000175); var tmp12 *lang.Var; A_arbace_classes_env_A_Init(); tmp12 = A_arbace_classes_env_A_const_75; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__28000176__3))) } else { var tmp13 *lang.Var; A_arbace_classes_env_A_Init(); tmp13 = A_arbace_classes_env_A_const_72; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_classes_env_A_Init(); tmp15 = A_arbace_classes_env_A_const_74; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__28000178__6), nil) } } else { var m__4 any; var tmp16 *lang.Var; A_arbace_classes_env_A_Init(); tmp16 = A_arbace_classes_env_A_const_63; m__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__28000176__3); var tmp17 any = t.F_name; var tmp18 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp18 = A_arbace_classes_env_A_const_42; if lang.Util_Equiv_O_O__Z(tmp17, jrt.NN(tmp18).Invoke_O__O(m__4)) { var tmp19 *lang.Var; A_arbace_classes_env_A_Init(); tmp19 = A_arbace_classes_env_A_const_39; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_classes_env_A_Init(); tmp21 = A_arbace_classes_env_A_const_120; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp23 = A_arbace_classes_env_A_const_43; var tmp24 any = jrt.NN(tmp23).Invoke_O__O(m__4); var tmp25 any; A_arbace_classes_env_A_Init(); tmp25 = A_arbace_classes_env_A_const_130; if jrt.A2g_Truth(tmp20.Invoke_O__O(tmp22.Invoke_O_O__O(tmp24, tmp25))) { var tmp26 any; var or__1927000174__auto____5 bool = lang.Util_Equiv_O_O__Z(t.F_c, t.F_n)


	if or__1927000174__auto____5 { tmp26 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____5).Ref() } else { var tmp27 *lang.Var; A_arbace_classes_env_A_Init(); tmp27 = A_arbace_classes_env_A_const_39; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Var; A_arbace_classes_env_A_Init(); tmp29 = A_arbace_classes_env_A_const_120; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp31 = A_arbace_classes_env_A_const_43; var tmp32 any = jrt.NN(tmp31).Invoke_O__O(m__4); var tmp33 any; A_arbace_classes_env_A_Init(); tmp33 = A_arbace_classes_env_A_const_123; tmp26 = tmp28.Invoke_O__O(tmp30.Invoke_O_O__O(tmp32, tmp33)) }
//line :331:1
	if jrt.A2g_Truth(tmp26) { var tmp34 any; var or__1927000174__auto____5_2 bool = lang.Util_Equiv_O_O__Z(t.F_c, t.F_n)



		if or__1927000174__auto____5_2 { tmp34 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____5_2).Ref() } else { var or__1927000174__auto____6 any; var tmp35 *lang.Var; A_arbace_classes_env_A_Init(); tmp35 = A_arbace_classes_env_A_const_39; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 *lang.Var; A_arbace_classes_env_A_Init(); tmp37 = A_arbace_classes_env_A_const_109; or__1927000174__auto____6 = tmp36.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()).Invoke_O__O(t.F_c)); if jrt.A2g_Truth(or__1927000174__auto____6) { tmp34 = or__1927000174__auto____6 } else { var tmp38 *lang.Var; A_arbace_classes_env_A_Init(); tmp38 = A_arbace_classes_env_A_const_39; var tmp39 lang.IFn = lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()); var tmp40 *lang.Var; A_arbace_classes_env_A_Init(); tmp40 = A_arbace_classes_env_A_const_120; var tmp41 lang.IFn = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()); var tmp42 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp42 = A_arbace_classes_env_A_const_43; var tmp43 any = jrt.NN(tmp42).Invoke_O__O(m__4); var tmp44 any; A_arbace_classes_env_A_Init(); tmp44 = A_arbace_classes_env_A_const_131; tmp34 = tmp39.Invoke_O__O(tmp41.Invoke_O_O__O(tmp43, tmp44)) } }
//line :331:1
		if jrt.A2g_Truth(tmp34) { var tmp45 *lang.Var; A_arbace_classes_env_A_Init(); tmp45 = A_arbace_classes_env_A_const_39; var tmp46 lang.IFn = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()); var tmp47 lang.IFn = lang.IFn_Cast(t.F_seen); var tmp48 *lang.Var; A_arbace_classes_env_A_Init(); tmp48 = A_arbace_classes_env_A_const_132; var tmp49 lang.IFn = lang.IFn_Cast(jrt.NN(tmp48).GetRawRoot__O()); var tmp50 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp50 = A_arbace_classes_env_A_const_64; if jrt.A2g_Truth(tmp46.Invoke_O__O(tmp47.Invoke_O__O(tmp49.Invoke_O__O(jrt.NN(tmp50).Invoke_O__O(m__4))))) { var tmp51 *lang.Var; A_arbace_classes_env_A_Init(); tmp51 = A_arbace_classes_env_A_const_73; var tmp52 lang.IFn = lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()); var tmp53 lang.IFn = lang.IFn_Cast(t.F_iter__28000175); var tmp54 *lang.Var; A_arbace_classes_env_A_Init(); tmp54 = A_arbace_classes_env_A_const_76; return tmp52.Invoke_O_O__O(m__4, tmp53.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp54).GetRawRoot__O()).Invoke_O__O(s__28000176__3))) } else { var tmp55 *lang.Var; A_arbace_classes_env_A_Init(); tmp55 = A_arbace_classes_env_A_const_76; s__28000176__1 = lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()).Invoke_O__O(s__28000176__3); continue L1 } } else { var tmp56 *lang.Var; A_arbace_classes_env_A_Init(); tmp56 = A_arbace_classes_env_A_const_76; s__28000176__1 = lang.IFn_Cast(jrt.NN(tmp56).GetRawRoot__O()).Invoke_O__O(s__28000176__3); continue L1 } } else { var tmp57 *lang.Var; A_arbace_classes_env_A_Init(); tmp57 = A_arbace_classes_env_A_const_76; s__28000176__1 = lang.IFn_Cast(jrt.NN(tmp57).GetRawRoot__O()).Invoke_O__O(s__28000176__3); continue L1 } } else { var tmp58 *lang.Var; A_arbace_classes_env_A_Init(); tmp58 = A_arbace_classes_env_A_const_76; s__28000176__1 = lang.IFn_Cast(jrt.NN(tmp58).GetRawRoot__O()).Invoke_O__O(s__28000176__3); continue L1 } } else { var tmp59 *lang.Var; A_arbace_classes_env_A_Init(); tmp59 = A_arbace_classes_env_A_const_76; s__28000176__1 = lang.IFn_Cast(jrt.NN(tmp59).GetRawRoot__O()).Invoke_O__O(s__28000176__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :331:1
func A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_New_O_O_O_O_O_I_O(p0, p1, p2, p3, p4 any, p5 int32, p6 any) *A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A { A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_Init(); t := &A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A{}; t.Ctor_O_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :331:1
func (t *A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A) Ctor_O_O_O_O_O_I_O(c__b__28000178, c__seen, c__name, c__n, c__c any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__28000178 = c__b__28000178; t.F_seen = c__seen; t.F_name = c__name; t.F_n = c__n; t.F_c = c__c; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :331:1
func (t *A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A) Invoke_O__O(self any) any { { var i__28000177__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__28000177__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__28000177__1)); var tmp2 any = t.F_name; var tmp3 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp3 = A_arbace_classes_env_A_const_42; if lang.Util_Equiv_O_O__Z(tmp2, jrt.NN(tmp3).Invoke_O__O(m__2)) { var tmp4 *lang.Var; A_arbace_classes_env_A_Init(); tmp4 = A_arbace_classes_env_A_const_39; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_classes_env_A_Init(); tmp6 = A_arbace_classes_env_A_const_120; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp8 = A_arbace_classes_env_A_const_43; var tmp9 any = jrt.NN(tmp8).Invoke_O__O(m__2); var tmp10 any; A_arbace_classes_env_A_Init(); tmp10 = A_arbace_classes_env_A_const_130; if jrt.A2g_Truth(tmp5.Invoke_O__O(tmp7.Invoke_O_O__O(tmp9, tmp10))) { var tmp11 any; var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z(t.F_c, t.F_n)


	if or__1927000174__auto____3 { tmp11 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____3).Ref() } else { var tmp12 *lang.Var; A_arbace_classes_env_A_Init(); tmp12 = A_arbace_classes_env_A_const_39; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_classes_env_A_Init(); tmp14 = A_arbace_classes_env_A_const_120; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp16 = A_arbace_classes_env_A_const_43; var tmp17 any = jrt.NN(tmp16).Invoke_O__O(m__2); var tmp18 any; A_arbace_classes_env_A_Init(); tmp18 = A_arbace_classes_env_A_const_123; tmp11 = tmp13.Invoke_O__O(tmp15.Invoke_O_O__O(tmp17, tmp18)) }
//line :331:1
	if jrt.A2g_Truth(tmp11) { var tmp19 any; var or__1927000174__auto____3_2 bool = lang.Util_Equiv_O_O__Z(t.F_c, t.F_n)



		if or__1927000174__auto____3_2 { tmp19 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____3_2).Ref() } else { var or__1927000174__auto____4 any; var tmp20 *lang.Var; A_arbace_classes_env_A_Init(); tmp20 = A_arbace_classes_env_A_const_39; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Var; A_arbace_classes_env_A_Init(); tmp22 = A_arbace_classes_env_A_const_109; or__1927000174__auto____4 = tmp21.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(t.F_c)); if jrt.A2g_Truth(or__1927000174__auto____4) { tmp19 = or__1927000174__auto____4 } else { var tmp23 *lang.Var; A_arbace_classes_env_A_Init(); tmp23 = A_arbace_classes_env_A_const_39; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_classes_env_A_Init(); tmp25 = A_arbace_classes_env_A_const_120; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp27 = A_arbace_classes_env_A_const_43; var tmp28 any = jrt.NN(tmp27).Invoke_O__O(m__2); var tmp29 any; A_arbace_classes_env_A_Init(); tmp29 = A_arbace_classes_env_A_const_131; tmp19 = tmp24.Invoke_O__O(tmp26.Invoke_O_O__O(tmp28, tmp29)) } }
//line :331:1
		if jrt.A2g_Truth(tmp19) { var tmp30 *lang.Var; A_arbace_classes_env_A_Init(); tmp30 = A_arbace_classes_env_A_const_39; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 lang.IFn = lang.IFn_Cast(t.F_seen); var tmp33 *lang.Var; A_arbace_classes_env_A_Init(); tmp33 = A_arbace_classes_env_A_const_132; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp35 = A_arbace_classes_env_A_const_64; if jrt.A2g_Truth(tmp31.Invoke_O__O(tmp32.Invoke_O__O(tmp34.Invoke_O__O(jrt.NN(tmp35).Invoke_O__O(m__2))))) { var tmp36 *lang.Var; A_arbace_classes_env_A_Init(); tmp36 = A_arbace_classes_env_A_const_66; lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()).Invoke_O_O__O(t.F_b__28000178, m__2); i__28000177__1 = lang.Numbers_Unchecked_inc_J__J(i__28000177__1); continue L1 } else { i__28000177__1 = lang.Numbers_Unchecked_inc_J__J(i__28000177__1); continue L1 } } else { i__28000177__1 = lang.Numbers_Unchecked_inc_J__J(i__28000177__1); continue L1 } } else { i__28000177__1 = lang.Numbers_Unchecked_inc_J__J(i__28000177__1); continue L1 } } else { i__28000177__1 = lang.Numbers_Unchecked_inc_J__J(i__28000177__1); continue L1 } } else { i__28000177__1 = lang.Numbers_Unchecked_inc_J__J(i__28000177__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }








func A_arbace_classes_env_constructors_A_New() *A_arbace_classes_env_constructors_A { A_arbace_classes_env_constructors_A_Init(); t := &A_arbace_classes_env_constructors_A{}; t.Ctor(); return t }
//line :340:1
func (t *A_arbace_classes_env_constructors_A) Ctor() {}
//line :340:1
func (t *A_arbace_classes_env_constructors_A) Invoke_O_O__O(self, n__0 any) any {
	var tmp1 *lang.Var; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_86; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_classes_env_constructors_fn__28000187_A_New(); var tmp4 *jrt.Class; A_arbace_classes_env_constructors_fn__28000187_A_Init(); tmp4 = A_arbace_classes_env_constructors_fn__28000187_A_fn_class; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp6 = A_arbace_classes_env_A_const_55; var tmp7 *lang.Keyword = tmp6; var tmp8 *lang.Var; A_arbace_classes_env_A_Init(); tmp8 = A_arbace_classes_env_A_const_95; return tmp2.Invoke_O_O__O(tmp5, jrt.NN(tmp7).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(n__0))) }
//line :341:1
func A_arbace_classes_env_constructors_fn__28000187_A_New() *A_arbace_classes_env_constructors_fn__28000187_A { A_arbace_classes_env_constructors_fn__28000187_A_Init(); t := &A_arbace_classes_env_constructors_fn__28000187_A{}; t.Ctor(); return t }
//line :341:1
func (t *A_arbace_classes_env_constructors_fn__28000187_A) Ctor() {}
//line :341:1
func (t *A_arbace_classes_env_constructors_fn__28000187_A) Invoke_O_O__O(self, p1__28000186_SHARP___1 any) any { var tmp1 *lang.Keyword; A_arbace_classes_env_A_Init(); tmp1 = A_arbace_classes_env_A_const_42; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_150, jrt.NN(tmp1).Invoke_O__O(p1__28000186_SHARP___1))).Ref() }














































































































































type A_arbace_classes_env_A struct{ jrt.Object }

var A_arbace_classes_env_A_const_0 *lang.Var

var A_arbace_classes_env_A_const_1 *lang.Var

var A_arbace_classes_env_A_const_2 any

var A_arbace_classes_env_A_const_3 any

var A_arbace_classes_env_A_const_4 any

var A_arbace_classes_env_A_const_5 any

var A_arbace_classes_env_A_const_6 any

var A_arbace_classes_env_A_const_7 *lang.Var

var A_arbace_classes_env_A_const_8 *lang.Var

var A_arbace_classes_env_A_const_9 *lang.Var

var A_arbace_classes_env_A_const_10 any

var A_arbace_classes_env_A_const_11 *lang.Var

var A_arbace_classes_env_A_const_12 *lang.Var

var A_arbace_classes_env_A_const_13 *lang.Var

var A_arbace_classes_env_A_const_14 *lang.Var

var A_arbace_classes_env_A_const_15 *lang.Var

var A_arbace_classes_env_A_const_16 *lang.Var

var A_arbace_classes_env_A_const_17 *lang.Var

var A_arbace_classes_env_A_const_18 *lang.Var

var A_arbace_classes_env_A_const_19 *lang.Var

var A_arbace_classes_env_A_const_20 *lang.Var

var A_arbace_classes_env_A_const_21 *lang.Var

var A_arbace_classes_env_A_const_22 *lang.Keyword

var A_arbace_classes_env_A_const_23 *lang.Var

var A_arbace_classes_env_A_const_24 *lang.Var

var A_arbace_classes_env_A_const_25 *lang.Var

var A_arbace_classes_env_A_const_26 *lang.Var

var A_arbace_classes_env_A_const_27 *lang.Var

var A_arbace_classes_env_A_const_28 *lang.Var

var A_arbace_classes_env_A_const_29 *lang.Var

var A_arbace_classes_env_A_const_30 *lang.Keyword

var A_arbace_classes_env_A_const_31 *lang.Keyword

var A_arbace_classes_env_A_const_32 *lang.Var

var A_arbace_classes_env_A_const_33 *jrt.Class

var A_arbace_classes_env_A_const_34 *lang.Var

var A_arbace_classes_env_A_const_35 *lang.Var

var A_arbace_classes_env_A_const_36 *lang.Var

var A_arbace_classes_env_A_const_37 any

var A_arbace_classes_env_A_const_38 any

var A_arbace_classes_env_A_const_39 *lang.Var

var A_arbace_classes_env_A_const_40 *lang.Var

var A_arbace_classes_env_A_const_41 *lang.Var

var A_arbace_classes_env_A_const_42 *lang.Keyword

var A_arbace_classes_env_A_const_43 *lang.Keyword

var A_arbace_classes_env_A_const_44 *lang.Keyword

var A_arbace_classes_env_A_const_45 *lang.Keyword

var A_arbace_classes_env_A_const_46 *lang.Keyword

var A_arbace_classes_env_A_const_47 *lang.Var

var A_arbace_classes_env_A_const_48 *lang.Keyword

var A_arbace_classes_env_A_const_49 *lang.Keyword

var A_arbace_classes_env_A_const_50 *lang.Keyword

var A_arbace_classes_env_A_const_51 *lang.Var

var A_arbace_classes_env_A_const_52 *lang.Var

var A_arbace_classes_env_A_const_53 *lang.Keyword

var A_arbace_classes_env_A_const_54 *lang.Var

var A_arbace_classes_env_A_const_55 *lang.Keyword

var A_arbace_classes_env_A_const_56 *lang.Var

var A_arbace_classes_env_A_const_57 *lang.Var

var A_arbace_classes_env_A_const_58 *lang.Var

var A_arbace_classes_env_A_const_59 *lang.Var

var A_arbace_classes_env_A_const_60 *lang.Var

var A_arbace_classes_env_A_const_61 *lang.Var

var A_arbace_classes_env_A_const_62 *lang.Var

var A_arbace_classes_env_A_const_63 *lang.Var

var A_arbace_classes_env_A_const_64 *lang.Keyword

var A_arbace_classes_env_A_const_65 *lang.Keyword

var A_arbace_classes_env_A_const_66 *lang.Var

var A_arbace_classes_env_A_const_67 *lang.Keyword

var A_arbace_classes_env_A_const_68 *lang.Keyword

var A_arbace_classes_env_A_const_69 *lang.Var

var A_arbace_classes_env_A_const_70 *lang.Var

var A_arbace_classes_env_A_const_71 *lang.Var

var A_arbace_classes_env_A_const_72 *lang.Var

var A_arbace_classes_env_A_const_73 *lang.Var

var A_arbace_classes_env_A_const_74 *lang.Var

var A_arbace_classes_env_A_const_75 *lang.Var

var A_arbace_classes_env_A_const_76 *lang.Var

var A_arbace_classes_env_A_const_77 *lang.Var

var A_arbace_classes_env_A_const_78 *lang.Var

var A_arbace_classes_env_A_const_79 *lang.Var

var A_arbace_classes_env_A_const_80 *lang.Var

var A_arbace_classes_env_A_const_81 *lang.Keyword

var A_arbace_classes_env_A_const_82 *lang.Keyword

var A_arbace_classes_env_A_const_83 *lang.Var

var A_arbace_classes_env_A_const_84 *lang.Keyword

var A_arbace_classes_env_A_const_85 *lang.Var

var A_arbace_classes_env_A_const_86 *lang.Var

var A_arbace_classes_env_A_const_87 *lang.Var

var A_arbace_classes_env_A_const_88 any

var A_arbace_classes_env_A_const_89 *lang.Var

var A_arbace_classes_env_A_const_90 *lang.Keyword

var A_arbace_classes_env_A_const_91 *lang.Var

var A_arbace_classes_env_A_const_92 *lang.Var

var A_arbace_classes_env_A_const_93 *lang.Var

var A_arbace_classes_env_A_const_94 *lang.Var

var A_arbace_classes_env_A_const_95 *lang.Var

var A_arbace_classes_env_A_const_96 *lang.Var

var A_arbace_classes_env_A_const_97 *lang.Var

var A_arbace_classes_env_A_const_98 *lang.Keyword

var A_arbace_classes_env_A_const_99 *lang.Var

var A_arbace_classes_env_A_const_100 *lang.Var

var A_arbace_classes_env_A_const_101 *lang.Var

var A_arbace_classes_env_A_const_102 *lang.Var

var A_arbace_classes_env_A_const_103 *lang.Var

var A_arbace_classes_env_A_const_104 *lang.Keyword

var A_arbace_classes_env_A_const_105 any

var A_arbace_classes_env_A_const_106 *lang.Var

var A_arbace_classes_env_A_const_107 *lang.Var

var A_arbace_classes_env_A_const_108 *lang.Var

var A_arbace_classes_env_A_const_109 *lang.Var

var A_arbace_classes_env_A_const_110 *lang.Var

var A_arbace_classes_env_A_const_111 *lang.Var

var A_arbace_classes_env_A_const_112 *lang.Var

var A_arbace_classes_env_A_const_113 *lang.Var

var A_arbace_classes_env_A_const_114 *lang.Var

var A_arbace_classes_env_A_const_115 *lang.Var

var A_arbace_classes_env_A_const_116 *lang.Var

var A_arbace_classes_env_A_const_117 *lang.Var

var A_arbace_classes_env_A_const_118 *lang.Var

var A_arbace_classes_env_A_const_119 *lang.Var

var A_arbace_classes_env_A_const_120 *lang.Var

var A_arbace_classes_env_A_const_121 *lang.Var

var A_arbace_classes_env_A_const_122 any

var A_arbace_classes_env_A_const_123 any

var A_arbace_classes_env_A_const_124 any

var A_arbace_classes_env_A_const_125 *lang.Var

var A_arbace_classes_env_A_const_126 *lang.Var

var A_arbace_classes_env_A_const_127 *lang.Var

var A_arbace_classes_env_A_const_128 any

var A_arbace_classes_env_A_const_129 *lang.Var

var A_arbace_classes_env_A_const_130 any

var A_arbace_classes_env_A_const_131 any

var A_arbace_classes_env_A_const_132 *lang.Var

var A_arbace_classes_env_A_const_133 *lang.Var

var A_arbace_classes_env_A_init jrt.ClassInit

func A_arbace_classes_env_A_Init() { if !A_arbace_classes_env_A_init.Done() { A_arbace_classes_env_A_init.Run(A_arbace_classes_env_A_clinit) } }

func A_arbace_classes_env_A_clinit() { A_arbace_classes_env_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_classes_env_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_classes_env_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_classes_env_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_classes_env_A_const_4 = lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref()); A_arbace_classes_env_A_const_5 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_8).Ref()); A_arbace_classes_env_A_const_6 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_9).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_10).Ref()); A_arbace_classes_env_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_11); A_arbace_classes_env_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_12); A_arbace_classes_env_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_13); A_arbace_classes_env_A_const_10 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_14)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16))); A_arbace_classes_env_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_17); A_arbace_classes_env_A_const_12 = lang.RT_Var_String_String__Var(Lit_3, Lit_18); A_arbace_classes_env_A_const_13 = lang.RT_Var_String_String__Var(Lit_14, Lit_19); A_arbace_classes_env_A_const_14 = lang.RT_Var_String_String__Var(Lit_14, Lit_20); A_arbace_classes_env_A_const_15 = lang.RT_Var_String_String__Var(Lit_0, Lit_21); A_arbace_classes_env_A_const_16 = lang.RT_Var_String_String__Var(Lit_0, Lit_22); A_arbace_classes_env_A_const_17 = lang.RT_Var_String_String__Var(Lit_0, Lit_23); A_arbace_classes_env_A_const_18 = lang.RT_Var_String_String__Var(Lit_14, Lit_24); A_arbace_classes_env_A_const_19 = lang.RT_Var_String_String__Var(Lit_14, Lit_25); A_arbace_classes_env_A_const_20 = lang.RT_Var_String_String__Var(Lit_3, Lit_26); A_arbace_classes_env_A_const_21 = lang.RT_Var_String_String__Var(Lit_14, Lit_27); A_arbace_classes_env_A_const_22 = lang.RT_Keyword_String_String__Keyword(nil, Lit_28); A_arbace_classes_env_A_const_23 = lang.RT_Var_String_String__Var(Lit_0, Lit_29); A_arbace_classes_env_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_30); A_arbace_classes_env_A_const_25 = lang.RT_Var_String_String__Var(Lit_14, Lit_31); A_arbace_classes_env_A_const_26 = lang.RT_Var_String_String__Var(Lit_0, Lit_32); A_arbace_classes_env_A_const_27 = lang.RT_Var_String_String__Var(Lit_0, Lit_33); A_arbace_classes_env_A_const_28 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_classes_env_A_const_29 = lang.RT_Var_String_String__Var(Lit_0, Lit_35); A_arbace_classes_env_A_const_30 = lang.RT_Keyword_String_String__Keyword(nil, Lit_36); A_arbace_classes_env_A_const_31 = lang.RT_Keyword_String_String__Keyword(nil, Lit_37); A_arbace_classes_env_A_const_32 = lang.RT_Var_String_String__Var(Lit_0, Lit_5); A_arbace_classes_env_A_const_33 = lang.RT_ClassForNameNonLoading_String__Class(Lit_38); A_arbace_classes_env_A_const_34 = lang.RT_Var_String_String__Var(Lit_14, Lit_39); A_arbace_classes_env_A_const_35 = lang.RT_Var_String_String__Var(Lit_14, Lit_40); A_arbace_classes_env_A_const_36 = lang.RT_Var_String_String__Var(Lit_0, Lit_41); A_arbace_classes_env_A_const_37 = lang.Symbol_Intern_String_String__Symbol(Lit_42, Lit_43).Ref(); A_arbace_classes_env_A_const_38 = lang.Symbol_Intern_String_String__Symbol(Lit_42, Lit_44).Ref(); A_arbace_classes_env_A_const_39 = lang.RT_Var_String_String__Var(Lit_0, Lit_45); A_arbace_classes_env_A_const_40 = lang.RT_Var_String_String__Var(Lit_14, Lit_46); A_arbace_classes_env_A_const_41 = lang.RT_Var_String_String__Var(Lit_14, Lit_44); A_arbace_classes_env_A_const_42 = lang.RT_Keyword_String_String__Keyword(nil, Lit_35); A_arbace_classes_env_A_const_43 = lang.RT_Keyword_String_String__Keyword(nil, Lit_47); A_arbace_classes_env_A_const_44 = lang.RT_Keyword_String_String__Keyword(nil, Lit_48); A_arbace_classes_env_A_const_45 = lang.RT_Keyword_String_String__Keyword(nil, Lit_49); A_arbace_classes_env_A_const_46 = lang.RT_Keyword_String_String__Keyword(nil, Lit_50); A_arbace_classes_env_A_const_47 = lang.RT_Var_String_String__Var(Lit_0, Lit_51); A_arbace_classes_env_A_const_48 = lang.RT_Keyword_String_String__Keyword(nil, Lit_52); A_arbace_classes_env_A_const_49 = lang.RT_Keyword_String_String__Keyword(nil, Lit_53); A_arbace_classes_env_A_const_50 = lang.RT_Keyword_String_String__Keyword(nil, Lit_54); A_arbace_classes_env_A_const_51 = lang.RT_Var_String_String__Var(Lit_14, Lit_43); A_arbace_classes_env_A_const_52 = lang.RT_Var_String_String__Var(Lit_0, Lit_55); A_arbace_classes_env_A_const_53 = lang.RT_Keyword_String_String__Keyword(nil, Lit_56); A_arbace_classes_env_A_const_54 = lang.RT_Var_String_String__Var(Lit_14, Lit_57); A_arbace_classes_env_A_const_55 = lang.RT_Keyword_String_String__Keyword(nil, Lit_58); A_arbace_classes_env_A_const_56 = lang.RT_Var_String_String__Var(Lit_0, Lit_59); A_arbace_classes_env_A_const_57 = lang.RT_Var_String_String__Var(Lit_0, Lit_60); A_arbace_classes_env_A_const_58 = lang.RT_Var_String_String__Var(Lit_0, Lit_61); A_arbace_classes_env_A_const_59 = lang.RT_Var_String_String__Var(Lit_0, Lit_62); A_arbace_classes_env_A_const_60 = lang.RT_Var_String_String__Var(Lit_0, Lit_63); A_arbace_classes_env_A_const_61 = lang.RT_Var_String_String__Var(Lit_0, Lit_64); A_arbace_classes_env_A_const_62 = lang.RT_Var_String_String__Var(Lit_0, Lit_65); A_arbace_classes_env_A_const_63 = lang.RT_Var_String_String__Var(Lit_0, Lit_66); A_arbace_classes_env_A_const_64 = lang.RT_Keyword_String_String__Keyword(nil, Lit_67); A_arbace_classes_env_A_const_65 = lang.RT_Keyword_String_String__Keyword(nil, Lit_68); A_arbace_classes_env_A_const_66 = lang.RT_Var_String_String__Var(Lit_0, Lit_69); A_arbace_classes_env_A_const_67 = lang.RT_Keyword_String_String__Keyword(nil, Lit_70); A_arbace_classes_env_A_const_68 = lang.RT_Keyword_String_String__Keyword(nil, Lit_71); A_arbace_classes_env_A_const_69 = lang.RT_Var_String_String__Var(Lit_7, Lit_72); A_arbace_classes_env_A_const_70 = lang.RT_Var_String_String__Var(Lit_7, Lit_73); A_arbace_classes_env_A_const_71 = lang.RT_Var_String_String__Var(Lit_14, Lit_74); A_arbace_classes_env_A_const_72 = lang.RT_Var_String_String__Var(Lit_0, Lit_75); A_arbace_classes_env_A_const_73 = lang.RT_Var_String_String__Var(Lit_0, Lit_76); A_arbace_classes_env_A_const_74 = lang.RT_Var_String_String__Var(Lit_0, Lit_77); A_arbace_classes_env_A_const_75 = lang.RT_Var_String_String__Var(Lit_0, Lit_78); A_arbace_classes_env_A_const_76 = lang.RT_Var_String_String__Var(Lit_0, Lit_79); A_arbace_classes_env_A_const_77 = lang.RT_Var_String_String__Var(Lit_7, Lit_80); A_arbace_classes_env_A_const_78 = lang.RT_Var_String_String__Var(Lit_0, Lit_81); A_arbace_classes_env_A_const_79 = lang.RT_Var_String_String__Var(Lit_7, Lit_82); A_arbace_classes_env_A_const_80 = lang.RT_Var_String_String__Var(Lit_0, Lit_83); A_arbace_classes_env_A_const_81 = lang.RT_Keyword_String_String__Keyword(nil, Lit_84); A_arbace_classes_env_A_const_82 = lang.RT_Keyword_String_String__Keyword(nil, Lit_85); A_arbace_classes_env_A_const_83 = lang.RT_Var_String_String__Var(Lit_0, Lit_86); A_arbace_classes_env_A_const_84 = lang.RT_Keyword_String_String__Keyword(nil, Lit_87); A_arbace_classes_env_A_const_85 = lang.RT_Var_String_String__Var(Lit_0, Lit_88); A_arbace_classes_env_A_const_86 = lang.RT_Var_String_String__Var(Lit_0, Lit_89); A_arbace_classes_env_A_const_87 = lang.RT_Var_String_String__Var(Lit_0, Lit_90); A_arbace_classes_env_A_const_88 = lang.Symbol_Intern_String_String__Symbol(Lit_91, Lit_92).Ref(); A_arbace_classes_env_A_const_89 = lang.RT_Var_String_String__Var(Lit_14, Lit_93); A_arbace_classes_env_A_const_90 = lang.RT_Keyword_String_String__Keyword(nil, Lit_94); A_arbace_classes_env_A_const_91 = lang.RT_Var_String_String__Var(Lit_14, Lit_95); A_arbace_classes_env_A_const_92 = lang.RT_Var_String_String__Var(Lit_14, Lit_96); A_arbace_classes_env_A_const_93 = lang.RT_Var_String_String__Var(Lit_14, Lit_94); A_arbace_classes_env_A_const_94 = lang.RT_Var_String_String__Var(Lit_0, Lit_97); A_arbace_classes_env_A_const_95 = lang.RT_Var_String_String__Var(Lit_14, Lit_98); A_arbace_classes_env_A_const_96 = lang.RT_Var_String_String__Var(Lit_0, Lit_99); A_arbace_classes_env_A_const_97 = lang.RT_Var_String_String__Var(Lit_14, Lit_100); A_arbace_classes_env_A_const_98 = lang.RT_Keyword_String_String__Keyword(nil, Lit_101); A_arbace_classes_env_A_const_99 = lang.RT_Var_String_String__Var(Lit_7, Lit_102); A_arbace_classes_env_A_const_100 = lang.RT_Var_String_String__Var(Lit_7, Lit_103); A_arbace_classes_env_A_const_101 = lang.RT_Var_String_String__Var(Lit_7, Lit_104); A_arbace_classes_env_A_const_102 = lang.RT_Var_String_String__Var(Lit_7, Lit_105); A_arbace_classes_env_A_const_103 = lang.RT_Var_String_String__Var(Lit_14, Lit_106); A_arbace_classes_env_A_const_104 = lang.RT_Keyword_String_String__Keyword(nil, Lit_107); A_arbace_classes_env_A_const_105 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_108, Lit_109)).Ref(); A_arbace_classes_env_A_const_106 = lang.RT_Var_String_String__Var(Lit_7, Lit_110); A_arbace_classes_env_A_const_107 = lang.RT_Var_String_String__Var(Lit_0, Lit_111); A_arbace_classes_env_A_const_108 = lang.RT_Var_String_String__Var(Lit_0, Lit_112); A_arbace_classes_env_A_const_109 = lang.RT_Var_String_String__Var(Lit_14, Lit_48); A_arbace_classes_env_A_const_110 = lang.RT_Var_String_String__Var(Lit_0, Lit_113); A_arbace_classes_env_A_const_111 = lang.RT_Var_String_String__Var(Lit_14, Lit_114); A_arbace_classes_env_A_const_112 = lang.RT_Var_String_String__Var(Lit_7, Lit_115); A_arbace_classes_env_A_const_113 = lang.RT_Var_String_String__Var(Lit_14, Lit_116); A_arbace_classes_env_A_const_114 = lang.RT_Var_String_String__Var(Lit_0, Lit_117); A_arbace_classes_env_A_const_115 = lang.RT_Var_String_String__Var(Lit_0, Lit_118); A_arbace_classes_env_A_const_116 = lang.RT_Var_String_String__Var(Lit_7, Lit_119); A_arbace_classes_env_A_const_117 = lang.RT_Var_String_String__Var(Lit_6, Lit_120); A_arbace_classes_env_A_const_118 = lang.RT_Var_String_String__Var(Lit_0, Lit_121); A_arbace_classes_env_A_const_119 = lang.RT_Var_String_String__Var(Lit_14, Lit_52); A_arbace_classes_env_A_const_120 = lang.RT_Var_String_String__Var(Lit_14, Lit_122); A_arbace_classes_env_A_const_121 = lang.RT_Var_String_String__Var(Lit_7, Lit_123); A_arbace_classes_env_A_const_122 = jrt.Integer_ValueOf_I__Integer(1).Ref(); A_arbace_classes_env_A_const_123 = jrt.Integer_ValueOf_I__Integer(2).Ref(); A_arbace_classes_env_A_const_124 = jrt.Integer_ValueOf_I__Integer(4).Ref(); A_arbace_classes_env_A_const_125 = lang.RT_Var_String_String__Var(Lit_14, Lit_124); A_arbace_classes_env_A_const_126 = lang.RT_Var_String_String__Var(Lit_0, Lit_125); A_arbace_classes_env_A_const_127 = lang.RT_Var_String_String__Var(Lit_0, Lit_126); A_arbace_classes_env_A_const_128 = jrt.Long_ValueOf_J__Long(0).Ref(); A_arbace_classes_env_A_const_129 = lang.RT_Var_String_String__Var(Lit_14, Lit_127); A_arbace_classes_env_A_const_130 = jrt.Integer_ValueOf_I__Integer(4096).Ref(); A_arbace_classes_env_A_const_131 = jrt.Integer_ValueOf_I__Integer(8).Ref(); A_arbace_classes_env_A_const_132 = lang.RT_Var_String_String__Var(Lit_14, Lit_128); A_arbace_classes_env_A_const_133 = lang.RT_Var_String_String__Var(Lit_0, Lit_129) }

func A_arbace_classes_env_A_New() *A_arbace_classes_env_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_env_A) Ctor() {}

func (t *A_arbace_classes_env_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_A_class }

func (t *A_arbace_classes_env_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_A); return ok }

func A_arbace_classes_env_A_Cast(x any) *A_arbace_classes_env_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_A_class)) }; return v }



type A_arbace_classes_env_accessible_QMARK__A struct{ jrt.Object }

func (t *A_arbace_classes_env_accessible_QMARK__A) Is_Compiler_AOTF2() {}

var A_arbace_classes_env_accessible_QMARK__A_fn_class *jrt.Class

var A_arbace_classes_env_accessible_QMARK__A_init jrt.ClassInit

func A_arbace_classes_env_accessible_QMARK__A_Init() { if !A_arbace_classes_env_accessible_QMARK__A_init.Done() { A_arbace_classes_env_accessible_QMARK__A_init.Run(A_arbace_classes_env_accessible_QMARK__A_clinit) } }

func A_arbace_classes_env_accessible_QMARK__A_clinit() { A_arbace_classes_env_accessible_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_130, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_accessible_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_accessible_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_accessible_QMARK__A_class }

func (t *A_arbace_classes_env_accessible_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_accessible_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_accessible_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_accessible_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_accessible_QMARK__A); return ok }

func A_arbace_classes_env_accessible_QMARK__A_Cast(x any) *A_arbace_classes_env_accessible_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_accessible_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_accessible_QMARK__A_class)) }; return v }



type A_arbace_classes_env_accessible_QMARK__fn__28000143_A struct{ jrt.Object; F_owner any }

func (t *A_arbace_classes_env_accessible_QMARK__fn__28000143_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_accessible_QMARK__fn__28000143_A_fn_class *jrt.Class

var A_arbace_classes_env_accessible_QMARK__fn__28000143_A_init jrt.ClassInit

func A_arbace_classes_env_accessible_QMARK__fn__28000143_A_Init() { if !A_arbace_classes_env_accessible_QMARK__fn__28000143_A_init.Done() { A_arbace_classes_env_accessible_QMARK__fn__28000143_A_init.Run(A_arbace_classes_env_accessible_QMARK__fn__28000143_A_clinit) } }

func A_arbace_classes_env_accessible_QMARK__fn__28000143_A_clinit() { A_arbace_classes_env_accessible_QMARK__fn__28000143_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_131, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_accessible_QMARK__fn__28000143_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_accessible_QMARK__fn__28000143_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_accessible_QMARK__fn__28000143_A_class }

func (t *A_arbace_classes_env_accessible_QMARK__fn__28000143_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_accessible_QMARK__fn__28000143_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_accessible_QMARK__fn__28000143_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_accessible_QMARK__fn__28000143_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_accessible_QMARK__fn__28000143_A); return ok }

func A_arbace_classes_env_accessible_QMARK__fn__28000143_A_Cast(x any) *A_arbace_classes_env_accessible_QMARK__fn__28000143_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_accessible_QMARK__fn__28000143_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_accessible_QMARK__fn__28000143_A_class)) }; return v }



type A_arbace_classes_env_accessible_QMARK__fn__28000145_A struct{ jrt.Object }

func (t *A_arbace_classes_env_accessible_QMARK__fn__28000145_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_accessible_QMARK__fn__28000145_A_fn_class *jrt.Class

var A_arbace_classes_env_accessible_QMARK__fn__28000145_A_init jrt.ClassInit

func A_arbace_classes_env_accessible_QMARK__fn__28000145_A_Init() { if !A_arbace_classes_env_accessible_QMARK__fn__28000145_A_init.Done() { A_arbace_classes_env_accessible_QMARK__fn__28000145_A_init.Run(A_arbace_classes_env_accessible_QMARK__fn__28000145_A_clinit) } }

func A_arbace_classes_env_accessible_QMARK__fn__28000145_A_clinit() { A_arbace_classes_env_accessible_QMARK__fn__28000145_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_132, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_accessible_QMARK__fn__28000145_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_accessible_QMARK__fn__28000145_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_accessible_QMARK__fn__28000145_A_class }

func (t *A_arbace_classes_env_accessible_QMARK__fn__28000145_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_accessible_QMARK__fn__28000145_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_accessible_QMARK__fn__28000145_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_accessible_QMARK__fn__28000145_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_accessible_QMARK__fn__28000145_A); return ok }

func A_arbace_classes_env_accessible_QMARK__fn__28000145_A_Cast(x any) *A_arbace_classes_env_accessible_QMARK__fn__28000145_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_accessible_QMARK__fn__28000145_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_accessible_QMARK__fn__28000145_A_class)) }; return v }



type A_arbace_classes_env_all_supertypes_A struct{ jrt.Object }

func (t *A_arbace_classes_env_all_supertypes_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_all_supertypes_A_fn_class *jrt.Class

var A_arbace_classes_env_all_supertypes_A_init jrt.ClassInit

func A_arbace_classes_env_all_supertypes_A_Init() { if !A_arbace_classes_env_all_supertypes_A_init.Done() { A_arbace_classes_env_all_supertypes_A_init.Run(A_arbace_classes_env_all_supertypes_A_clinit) } }

func A_arbace_classes_env_all_supertypes_A_clinit() { A_arbace_classes_env_all_supertypes_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_133, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_all_supertypes_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_all_supertypes_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_all_supertypes_A_class }

func (t *A_arbace_classes_env_all_supertypes_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_all_supertypes_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_all_supertypes_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_all_supertypes_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_all_supertypes_A); return ok }

func A_arbace_classes_env_all_supertypes_A_Cast(x any) *A_arbace_classes_env_all_supertypes_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_all_supertypes_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_all_supertypes_A_class)) }; return v }



type A_arbace_classes_env_all_supertypes_fn__28000157_A struct{ jrt.Object }

func (t *A_arbace_classes_env_all_supertypes_fn__28000157_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_all_supertypes_fn__28000157_A_fn_class *jrt.Class

var A_arbace_classes_env_all_supertypes_fn__28000157_A_init jrt.ClassInit

func A_arbace_classes_env_all_supertypes_fn__28000157_A_Init() { if !A_arbace_classes_env_all_supertypes_fn__28000157_A_init.Done() { A_arbace_classes_env_all_supertypes_fn__28000157_A_init.Run(A_arbace_classes_env_all_supertypes_fn__28000157_A_clinit) } }

func A_arbace_classes_env_all_supertypes_fn__28000157_A_clinit() { A_arbace_classes_env_all_supertypes_fn__28000157_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_135, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_all_supertypes_fn__28000157_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_all_supertypes_fn__28000157_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_all_supertypes_fn__28000157_A_class }

func (t *A_arbace_classes_env_all_supertypes_fn__28000157_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_all_supertypes_fn__28000157_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_all_supertypes_fn__28000157_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_all_supertypes_fn__28000157_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_all_supertypes_fn__28000157_A); return ok }

func A_arbace_classes_env_all_supertypes_fn__28000157_A_Cast(x any) *A_arbace_classes_env_all_supertypes_fn__28000157_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_all_supertypes_fn__28000157_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_all_supertypes_fn__28000157_A_class)) }; return v }



type A_arbace_classes_env_assignable_QMARK__A struct{ jrt.Object }

func (t *A_arbace_classes_env_assignable_QMARK__A) Is_Compiler_AOTF2() {}

var A_arbace_classes_env_assignable_QMARK__A_fn_class *jrt.Class

var A_arbace_classes_env_assignable_QMARK__A_init jrt.ClassInit

func A_arbace_classes_env_assignable_QMARK__A_Init() { if !A_arbace_classes_env_assignable_QMARK__A_init.Done() { A_arbace_classes_env_assignable_QMARK__A_init.Run(A_arbace_classes_env_assignable_QMARK__A_clinit) } }

func A_arbace_classes_env_assignable_QMARK__A_clinit() { A_arbace_classes_env_assignable_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_136, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_assignable_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_assignable_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_assignable_QMARK__A_class }

func (t *A_arbace_classes_env_assignable_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_assignable_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_assignable_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_assignable_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_assignable_QMARK__A); return ok }

func A_arbace_classes_env_assignable_QMARK__A_Cast(x any) *A_arbace_classes_env_assignable_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_assignable_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_assignable_QMARK__A_class)) }; return v }



type A_arbace_classes_env_class_file_QMARK__A struct{ jrt.Object }

func (t *A_arbace_classes_env_class_file_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_class_file_QMARK__A_fn_class *jrt.Class

var A_arbace_classes_env_class_file_QMARK__A_init jrt.ClassInit

func A_arbace_classes_env_class_file_QMARK__A_Init() { if !A_arbace_classes_env_class_file_QMARK__A_init.Done() { A_arbace_classes_env_class_file_QMARK__A_init.Run(A_arbace_classes_env_class_file_QMARK__A_clinit) } }

func A_arbace_classes_env_class_file_QMARK__A_clinit() { A_arbace_classes_env_class_file_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_137, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_class_file_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_class_file_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_class_file_QMARK__A_class }

func (t *A_arbace_classes_env_class_file_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_class_file_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_class_file_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_class_file_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_class_file_QMARK__A); return ok }

func A_arbace_classes_env_class_file_QMARK__A_Cast(x any) *A_arbace_classes_env_class_file_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_class_file_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_class_file_QMARK__A_class)) }; return v }



type A_arbace_classes_env_coerce_const_A struct{ jrt.Object }

func (t *A_arbace_classes_env_coerce_const_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_env_coerce_const_A_fn_class *jrt.Class

var A_arbace_classes_env_coerce_const_A_init jrt.ClassInit

func A_arbace_classes_env_coerce_const_A_Init() { if !A_arbace_classes_env_coerce_const_A_init.Done() { A_arbace_classes_env_coerce_const_A_init.Run(A_arbace_classes_env_coerce_const_A_clinit) } }

func A_arbace_classes_env_coerce_const_A_clinit() { A_arbace_classes_env_coerce_const_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_140, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_coerce_const_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_coerce_const_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_coerce_const_A_class }

func (t *A_arbace_classes_env_coerce_const_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_coerce_const_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_coerce_const_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_coerce_const_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_coerce_const_A); return ok }

func A_arbace_classes_env_coerce_const_A_Cast(x any) *A_arbace_classes_env_coerce_const_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_coerce_const_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_coerce_const_A_class)) }; return v }



type A_arbace_classes_env_common_super_A struct{ jrt.Object }

func (t *A_arbace_classes_env_common_super_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_env_common_super_A_fn_class *jrt.Class

var A_arbace_classes_env_common_super_A_init jrt.ClassInit

func A_arbace_classes_env_common_super_A_Init() { if !A_arbace_classes_env_common_super_A_init.Done() { A_arbace_classes_env_common_super_A_init.Run(A_arbace_classes_env_common_super_A_clinit) } }

func A_arbace_classes_env_common_super_A_clinit() { A_arbace_classes_env_common_super_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_145, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_common_super_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_common_super_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_common_super_A_class }

func (t *A_arbace_classes_env_common_super_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_common_super_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_common_super_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_common_super_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_common_super_A); return ok }

func A_arbace_classes_env_common_super_A_Cast(x any) *A_arbace_classes_env_common_super_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_common_super_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_common_super_A_class)) }; return v }



type A_arbace_classes_env_const_value_A struct{ jrt.Object }

func (t *A_arbace_classes_env_const_value_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_const_value_A_fn_class *jrt.Class

var A_arbace_classes_env_const_value_A_init jrt.ClassInit

func A_arbace_classes_env_const_value_A_Init() { if !A_arbace_classes_env_const_value_A_init.Done() { A_arbace_classes_env_const_value_A_init.Run(A_arbace_classes_env_const_value_A_clinit) } }

func A_arbace_classes_env_const_value_A_clinit() { A_arbace_classes_env_const_value_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_147, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_const_value_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_const_value_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_const_value_A_class }

func (t *A_arbace_classes_env_const_value_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_const_value_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_const_value_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_const_value_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_const_value_A); return ok }

func A_arbace_classes_env_const_value_A_Cast(x any) *A_arbace_classes_env_const_value_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_const_value_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_const_value_A_class)) }; return v }



type A_arbace_classes_env_constructors_A struct{ jrt.Object }

func (t *A_arbace_classes_env_constructors_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_constructors_A_fn_class *jrt.Class

var A_arbace_classes_env_constructors_A_init jrt.ClassInit

func A_arbace_classes_env_constructors_A_Init() { if !A_arbace_classes_env_constructors_A_init.Done() { A_arbace_classes_env_constructors_A_init.Run(A_arbace_classes_env_constructors_A_clinit) } }

func A_arbace_classes_env_constructors_A_clinit() { A_arbace_classes_env_constructors_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_148, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_constructors_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_constructors_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_constructors_A_class }

func (t *A_arbace_classes_env_constructors_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_constructors_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_constructors_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_constructors_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_constructors_A); return ok }

func A_arbace_classes_env_constructors_A_Cast(x any) *A_arbace_classes_env_constructors_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_constructors_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_constructors_A_class)) }; return v }



type A_arbace_classes_env_constructors_fn__28000187_A struct{ jrt.Object }

func (t *A_arbace_classes_env_constructors_fn__28000187_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_constructors_fn__28000187_A_fn_class *jrt.Class

var A_arbace_classes_env_constructors_fn__28000187_A_init jrt.ClassInit

func A_arbace_classes_env_constructors_fn__28000187_A_Init() { if !A_arbace_classes_env_constructors_fn__28000187_A_init.Done() { A_arbace_classes_env_constructors_fn__28000187_A_init.Run(A_arbace_classes_env_constructors_fn__28000187_A_clinit) } }

func A_arbace_classes_env_constructors_fn__28000187_A_clinit() { A_arbace_classes_env_constructors_fn__28000187_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_149, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_constructors_fn__28000187_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_constructors_fn__28000187_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_constructors_fn__28000187_A_class }

func (t *A_arbace_classes_env_constructors_fn__28000187_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_constructors_fn__28000187_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_constructors_fn__28000187_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_constructors_fn__28000187_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_constructors_fn__28000187_A); return ok }

func A_arbace_classes_env_constructors_fn__28000187_A_Cast(x any) *A_arbace_classes_env_constructors_fn__28000187_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_constructors_fn__28000187_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_constructors_fn__28000187_A_class)) }; return v }



type A_arbace_classes_env_eval28000004_A struct{ jrt.Object }

func A_arbace_classes_env_eval28000004_A_New() *A_arbace_classes_env_eval28000004_A { t := &A_arbace_classes_env_eval28000004_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_env_eval28000004_A) Ctor() {}

func (t *A_arbace_classes_env_eval28000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_eval28000004_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_eval28000004_A_class }

func (t *A_arbace_classes_env_eval28000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_eval28000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_eval28000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_eval28000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_eval28000004_A); return ok }

func A_arbace_classes_env_eval28000004_A_Cast(x any) *A_arbace_classes_env_eval28000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_eval28000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_eval28000004_A_class)) }; return v }



type A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A struct{ jrt.Object }

func (t *A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_fn_class *jrt.Class

var A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_init jrt.ClassInit

func A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_Init() { if !A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_init.Done() { A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_init.Run(A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_clinit) } }

func A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_clinit() { A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_151, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_class }

func (t *A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A); return ok }

func A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_Cast(x any) *A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_class)) }; return v }



type A_arbace_classes_env_eval28000008_A struct{ jrt.Object }

func A_arbace_classes_env_eval28000008_A_New() *A_arbace_classes_env_eval28000008_A { t := &A_arbace_classes_env_eval28000008_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_env_eval28000008_A) Ctor() {}

func (t *A_arbace_classes_env_eval28000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_eval28000008_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_eval28000008_A_class }

func (t *A_arbace_classes_env_eval28000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_eval28000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_eval28000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_eval28000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_eval28000008_A); return ok }

func A_arbace_classes_env_eval28000008_A_Cast(x any) *A_arbace_classes_env_eval28000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_eval28000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_eval28000008_A_class)) }; return v }



type A_arbace_classes_env_eval28000008_fn__28000009_A struct{ jrt.Object }

func (t *A_arbace_classes_env_eval28000008_fn__28000009_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_env_eval28000008_fn__28000009_A_fn_class *jrt.Class

var A_arbace_classes_env_eval28000008_fn__28000009_A_init jrt.ClassInit

func A_arbace_classes_env_eval28000008_fn__28000009_A_Init() { if !A_arbace_classes_env_eval28000008_fn__28000009_A_init.Done() { A_arbace_classes_env_eval28000008_fn__28000009_A_init.Run(A_arbace_classes_env_eval28000008_fn__28000009_A_clinit) } }

func A_arbace_classes_env_eval28000008_fn__28000009_A_clinit() { A_arbace_classes_env_eval28000008_fn__28000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_156, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_eval28000008_fn__28000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_eval28000008_fn__28000009_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_eval28000008_fn__28000009_A_class }

func (t *A_arbace_classes_env_eval28000008_fn__28000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_eval28000008_fn__28000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_eval28000008_fn__28000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_eval28000008_fn__28000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_eval28000008_fn__28000009_A); return ok }

func A_arbace_classes_env_eval28000008_fn__28000009_A_Cast(x any) *A_arbace_classes_env_eval28000008_fn__28000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_eval28000008_fn__28000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_eval28000008_fn__28000009_A_class)) }; return v }



type A_arbace_classes_env_find_field_A struct{ jrt.Object }

func (t *A_arbace_classes_env_find_field_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_env_find_field_A_fn_class *jrt.Class

var A_arbace_classes_env_find_field_A_init jrt.ClassInit

func A_arbace_classes_env_find_field_A_Init() { if !A_arbace_classes_env_find_field_A_init.Done() { A_arbace_classes_env_find_field_A_init.Run(A_arbace_classes_env_find_field_A_clinit) } }

func A_arbace_classes_env_find_field_A_clinit() { A_arbace_classes_env_find_field_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_157, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_find_field_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_find_field_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_find_field_A_class }

func (t *A_arbace_classes_env_find_field_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_find_field_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_find_field_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_find_field_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_find_field_A); return ok }

func A_arbace_classes_env_find_field_A_Cast(x any) *A_arbace_classes_env_find_field_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_find_field_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_find_field_A_class)) }; return v }



type A_arbace_classes_env_find_field_fn__28000150_A struct{ jrt.Object; F_name any }

func (t *A_arbace_classes_env_find_field_fn__28000150_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_find_field_fn__28000150_A_fn_class *jrt.Class

var A_arbace_classes_env_find_field_fn__28000150_A_init jrt.ClassInit

func A_arbace_classes_env_find_field_fn__28000150_A_Init() { if !A_arbace_classes_env_find_field_fn__28000150_A_init.Done() { A_arbace_classes_env_find_field_fn__28000150_A_init.Run(A_arbace_classes_env_find_field_fn__28000150_A_clinit) } }

func A_arbace_classes_env_find_field_fn__28000150_A_clinit() { A_arbace_classes_env_find_field_fn__28000150_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_158, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_find_field_fn__28000150_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_find_field_fn__28000150_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_find_field_fn__28000150_A_class }

func (t *A_arbace_classes_env_find_field_fn__28000150_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_find_field_fn__28000150_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_find_field_fn__28000150_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_find_field_fn__28000150_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_find_field_fn__28000150_A); return ok }

func A_arbace_classes_env_find_field_fn__28000150_A_Cast(x any) *A_arbace_classes_env_find_field_fn__28000150_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_find_field_fn__28000150_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_find_field_fn__28000150_A_class)) }; return v }



type A_arbace_classes_env_find_field_fn__28000152_A struct{ jrt.Object; F_name any }

func (t *A_arbace_classes_env_find_field_fn__28000152_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_find_field_fn__28000152_A_fn_class *jrt.Class

var A_arbace_classes_env_find_field_fn__28000152_A_init jrt.ClassInit

func A_arbace_classes_env_find_field_fn__28000152_A_Init() { if !A_arbace_classes_env_find_field_fn__28000152_A_init.Done() { A_arbace_classes_env_find_field_fn__28000152_A_init.Run(A_arbace_classes_env_find_field_fn__28000152_A_clinit) } }

func A_arbace_classes_env_find_field_fn__28000152_A_clinit() { A_arbace_classes_env_find_field_fn__28000152_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_159, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_find_field_fn__28000152_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_find_field_fn__28000152_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_find_field_fn__28000152_A_class }

func (t *A_arbace_classes_env_find_field_fn__28000152_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_find_field_fn__28000152_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_find_field_fn__28000152_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_find_field_fn__28000152_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_find_field_fn__28000152_A); return ok }

func A_arbace_classes_env_find_field_fn__28000152_A_Cast(x any) *A_arbace_classes_env_find_field_fn__28000152_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_find_field_fn__28000152_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_find_field_fn__28000152_A_class)) }; return v }



type A_arbace_classes_env_flag_QMARK__A struct{ jrt.Object }

func (t *A_arbace_classes_env_flag_QMARK__A) Is_Compiler_AOTF2() {}

var A_arbace_classes_env_flag_QMARK__A_fn_class *jrt.Class

var A_arbace_classes_env_flag_QMARK__A_init jrt.ClassInit

func A_arbace_classes_env_flag_QMARK__A_Init() { if !A_arbace_classes_env_flag_QMARK__A_init.Done() { A_arbace_classes_env_flag_QMARK__A_init.Run(A_arbace_classes_env_flag_QMARK__A_clinit) } }

func A_arbace_classes_env_flag_QMARK__A_clinit() { A_arbace_classes_env_flag_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_160, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_flag_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_flag_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_flag_QMARK__A_class }

func (t *A_arbace_classes_env_flag_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_flag_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_flag_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_flag_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_flag_QMARK__A); return ok }

func A_arbace_classes_env_flag_QMARK__A_Cast(x any) *A_arbace_classes_env_flag_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_flag_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_flag_QMARK__A_class)) }; return v }



type A_arbace_classes_env_from_source_QMARK__A struct{ jrt.Object }

func (t *A_arbace_classes_env_from_source_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_from_source_QMARK__A_fn_class *jrt.Class

var A_arbace_classes_env_from_source_QMARK__A_init jrt.ClassInit

func A_arbace_classes_env_from_source_QMARK__A_Init() { if !A_arbace_classes_env_from_source_QMARK__A_init.Done() { A_arbace_classes_env_from_source_QMARK__A_init.Run(A_arbace_classes_env_from_source_QMARK__A_clinit) } }

func A_arbace_classes_env_from_source_QMARK__A_clinit() { A_arbace_classes_env_from_source_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_161, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_from_source_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_from_source_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_from_source_QMARK__A_class }

func (t *A_arbace_classes_env_from_source_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_from_source_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_from_source_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_from_source_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_from_source_QMARK__A); return ok }

func A_arbace_classes_env_from_source_QMARK__A_Cast(x any) *A_arbace_classes_env_from_source_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_from_source_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_from_source_QMARK__A_class)) }; return v }



type A_arbace_classes_env_info_A struct{ jrt.Object }

func (t *A_arbace_classes_env_info_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_info_A_fn_class *jrt.Class

var A_arbace_classes_env_info_A_init jrt.ClassInit

func A_arbace_classes_env_info_A_Init() { if !A_arbace_classes_env_info_A_init.Done() { A_arbace_classes_env_info_A_init.Run(A_arbace_classes_env_info_A_clinit) } }

func A_arbace_classes_env_info_A_clinit() { A_arbace_classes_env_info_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_162, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_info_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_info_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_info_A_class }

func (t *A_arbace_classes_env_info_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_info_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_info_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_info_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_info_A); return ok }

func A_arbace_classes_env_info_A_Cast(x any) *A_arbace_classes_env_info_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_info_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_info_A_class)) }; return v }



type A_arbace_classes_env_info_BANG__A struct{ jrt.Object }

func (t *A_arbace_classes_env_info_BANG__A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_info_BANG__A_fn_class *jrt.Class

var A_arbace_classes_env_info_BANG__A_init jrt.ClassInit

func A_arbace_classes_env_info_BANG__A_Init() { if !A_arbace_classes_env_info_BANG__A_init.Done() { A_arbace_classes_env_info_BANG__A_init.Run(A_arbace_classes_env_info_BANG__A_clinit) } }

func A_arbace_classes_env_info_BANG__A_clinit() { A_arbace_classes_env_info_BANG__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_163, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_info_BANG__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_info_BANG__A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_info_BANG__A_class }

func (t *A_arbace_classes_env_info_BANG__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_info_BANG__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_info_BANG__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_info_BANG__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_info_BANG__A); return ok }

func A_arbace_classes_env_info_BANG__A_Cast(x any) *A_arbace_classes_env_info_BANG__A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_info_BANG__A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_info_BANG__A_class)) }; return v }



type A_arbace_classes_env_inner_member_QMARK__A struct{ jrt.Object }

func (t *A_arbace_classes_env_inner_member_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_inner_member_QMARK__A_fn_class *jrt.Class

var A_arbace_classes_env_inner_member_QMARK__A_init jrt.ClassInit

func A_arbace_classes_env_inner_member_QMARK__A_Init() { if !A_arbace_classes_env_inner_member_QMARK__A_init.Done() { A_arbace_classes_env_inner_member_QMARK__A_init.Run(A_arbace_classes_env_inner_member_QMARK__A_clinit) } }

func A_arbace_classes_env_inner_member_QMARK__A_clinit() { A_arbace_classes_env_inner_member_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_167, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_inner_member_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_inner_member_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_inner_member_QMARK__A_class }

func (t *A_arbace_classes_env_inner_member_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_inner_member_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_inner_member_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_inner_member_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_inner_member_QMARK__A); return ok }

func A_arbace_classes_env_inner_member_QMARK__A_Cast(x any) *A_arbace_classes_env_inner_member_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_inner_member_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_inner_member_QMARK__A_class)) }; return v }



type A_arbace_classes_env_interface_QMARK__A struct{ jrt.Object }

func (t *A_arbace_classes_env_interface_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_interface_QMARK__A_fn_class *jrt.Class

var A_arbace_classes_env_interface_QMARK__A_init jrt.ClassInit

func A_arbace_classes_env_interface_QMARK__A_Init() { if !A_arbace_classes_env_interface_QMARK__A_init.Done() { A_arbace_classes_env_interface_QMARK__A_init.Run(A_arbace_classes_env_interface_QMARK__A_clinit) } }

func A_arbace_classes_env_interface_QMARK__A_clinit() { A_arbace_classes_env_interface_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_168, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_interface_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_interface_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_interface_QMARK__A_class }

func (t *A_arbace_classes_env_interface_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_interface_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_interface_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_interface_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_interface_QMARK__A); return ok }

func A_arbace_classes_env_interface_QMARK__A_Cast(x any) *A_arbace_classes_env_interface_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_interface_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_interface_QMARK__A_class)) }; return v }



type A_arbace_classes_env_internal_A struct{ jrt.Object }

func (t *A_arbace_classes_env_internal_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_internal_A_fn_class *jrt.Class

var A_arbace_classes_env_internal_A_init jrt.ClassInit

func A_arbace_classes_env_internal_A_Init() { if !A_arbace_classes_env_internal_A_init.Done() { A_arbace_classes_env_internal_A_init.Run(A_arbace_classes_env_internal_A_clinit) } }

func A_arbace_classes_env_internal_A_clinit() { A_arbace_classes_env_internal_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_169, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_internal_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_internal_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_internal_A_class }

func (t *A_arbace_classes_env_internal_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_internal_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_internal_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_internal_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_internal_A); return ok }

func A_arbace_classes_env_internal_A_Cast(x any) *A_arbace_classes_env_internal_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_internal_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_internal_A_class)) }; return v }



type A_arbace_classes_env_known_QMARK__A struct{ jrt.Object }

func (t *A_arbace_classes_env_known_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_known_QMARK__A_fn_class *jrt.Class

var A_arbace_classes_env_known_QMARK__A_init jrt.ClassInit

func A_arbace_classes_env_known_QMARK__A_Init() { if !A_arbace_classes_env_known_QMARK__A_init.Done() { A_arbace_classes_env_known_QMARK__A_init.Run(A_arbace_classes_env_known_QMARK__A_clinit) } }

func A_arbace_classes_env_known_QMARK__A_clinit() { A_arbace_classes_env_known_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_170, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_known_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_known_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_known_QMARK__A_class }

func (t *A_arbace_classes_env_known_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_known_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_known_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_known_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_known_QMARK__A); return ok }

func A_arbace_classes_env_known_QMARK__A_Cast(x any) *A_arbace_classes_env_known_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_known_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_known_QMARK__A_class)) }; return v }



type A_arbace_classes_env_load_class_A struct{ jrt.Object }

func (t *A_arbace_classes_env_load_class_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_load_class_A_fn_class *jrt.Class

var A_arbace_classes_env_load_class_A_init jrt.ClassInit

func A_arbace_classes_env_load_class_A_Init() { if !A_arbace_classes_env_load_class_A_init.Done() { A_arbace_classes_env_load_class_A_init.Run(A_arbace_classes_env_load_class_A_clinit) } }

func A_arbace_classes_env_load_class_A_clinit() { A_arbace_classes_env_load_class_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_171, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_load_class_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_load_class_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_load_class_A_class }

func (t *A_arbace_classes_env_load_class_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_load_class_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_load_class_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_load_class_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_load_class_A); return ok }

func A_arbace_classes_env_load_class_A_Cast(x any) *A_arbace_classes_env_load_class_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_load_class_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_load_class_A_class)) }; return v }



type A_arbace_classes_env_lub_A struct{ jrt.Object }

func (t *A_arbace_classes_env_lub_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_env_lub_A_fn_class *jrt.Class

var A_arbace_classes_env_lub_A_init jrt.ClassInit

func A_arbace_classes_env_lub_A_Init() { if !A_arbace_classes_env_lub_A_init.Done() { A_arbace_classes_env_lub_A_init.Run(A_arbace_classes_env_lub_A_clinit) } }

func A_arbace_classes_env_lub_A_clinit() { A_arbace_classes_env_lub_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_172, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_lub_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_lub_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_lub_A_class }

func (t *A_arbace_classes_env_lub_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_lub_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_lub_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_lub_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_lub_A); return ok }

func A_arbace_classes_env_lub_A_Cast(x any) *A_arbace_classes_env_lub_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_lub_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_lub_A_class)) }; return v }



type A_arbace_classes_env_lub_fn__28000134_A struct{ jrt.Object; F_common any }

func (t *A_arbace_classes_env_lub_fn__28000134_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_lub_fn__28000134_A_fn_class *jrt.Class

var A_arbace_classes_env_lub_fn__28000134_A_init jrt.ClassInit

func A_arbace_classes_env_lub_fn__28000134_A_Init() { if !A_arbace_classes_env_lub_fn__28000134_A_init.Done() { A_arbace_classes_env_lub_fn__28000134_A_init.Run(A_arbace_classes_env_lub_fn__28000134_A_clinit) } }

func A_arbace_classes_env_lub_fn__28000134_A_clinit() { A_arbace_classes_env_lub_fn__28000134_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_173, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_lub_fn__28000134_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_lub_fn__28000134_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_lub_fn__28000134_A_class }

func (t *A_arbace_classes_env_lub_fn__28000134_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_lub_fn__28000134_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_lub_fn__28000134_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_lub_fn__28000134_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_lub_fn__28000134_A); return ok }

func A_arbace_classes_env_lub_fn__28000134_A_Cast(x any) *A_arbace_classes_env_lub_fn__28000134_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_lub_fn__28000134_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_lub_fn__28000134_A_class)) }; return v }



type A_arbace_classes_env_lub_fn__28000134_fn__28000135_A struct{ jrt.Object; F_i any }

func (t *A_arbace_classes_env_lub_fn__28000134_fn__28000135_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_fn_class *jrt.Class

var A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_init jrt.ClassInit

func A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_Init() { if !A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_init.Done() { A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_init.Run(A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_clinit) } }

func A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_clinit() { A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_174, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_lub_fn__28000134_fn__28000135_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_lub_fn__28000134_fn__28000135_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_class }

func (t *A_arbace_classes_env_lub_fn__28000134_fn__28000135_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_lub_fn__28000134_fn__28000135_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_lub_fn__28000134_fn__28000135_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_lub_fn__28000134_fn__28000135_A); return ok }

func A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_Cast(x any) *A_arbace_classes_env_lub_fn__28000134_fn__28000135_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_lub_fn__28000134_fn__28000135_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_class)) }; return v }



type A_arbace_classes_env_lub_sups__28000129_A struct{ jrt.Object }

func (t *A_arbace_classes_env_lub_sups__28000129_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_lub_sups__28000129_A_fn_class *jrt.Class

var A_arbace_classes_env_lub_sups__28000129_A_init jrt.ClassInit

func A_arbace_classes_env_lub_sups__28000129_A_Init() { if !A_arbace_classes_env_lub_sups__28000129_A_init.Done() { A_arbace_classes_env_lub_sups__28000129_A_init.Run(A_arbace_classes_env_lub_sups__28000129_A_clinit) } }

func A_arbace_classes_env_lub_sups__28000129_A_clinit() { A_arbace_classes_env_lub_sups__28000129_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_175, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_lub_sups__28000129_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_lub_sups__28000129_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_lub_sups__28000129_A_class }

func (t *A_arbace_classes_env_lub_sups__28000129_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_lub_sups__28000129_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_lub_sups__28000129_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_lub_sups__28000129_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_lub_sups__28000129_A); return ok }

func A_arbace_classes_env_lub_sups__28000129_A_Cast(x any) *A_arbace_classes_env_lub_sups__28000129_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_lub_sups__28000129_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_lub_sups__28000129_A_class)) }; return v }



type A_arbace_classes_env_lub_sups__28000129_fn__28000130_A struct{ jrt.Object }

func (t *A_arbace_classes_env_lub_sups__28000129_fn__28000130_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_fn_class *jrt.Class

var A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_init jrt.ClassInit

func A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_Init() { if !A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_init.Done() { A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_init.Run(A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_clinit) } }

func A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_clinit() { A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_176, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_lub_sups__28000129_fn__28000130_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_lub_sups__28000129_fn__28000130_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_class }

func (t *A_arbace_classes_env_lub_sups__28000129_fn__28000130_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_lub_sups__28000129_fn__28000130_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_lub_sups__28000129_fn__28000130_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_lub_sups__28000129_fn__28000130_A); return ok }

func A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_Cast(x any) *A_arbace_classes_env_lub_sups__28000129_fn__28000130_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_lub_sups__28000129_fn__28000130_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_class)) }; return v }



type A_arbace_classes_env_member_methods_A struct{ jrt.Object }

func (t *A_arbace_classes_env_member_methods_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_env_member_methods_A_fn_class *jrt.Class

var A_arbace_classes_env_member_methods_A_init jrt.ClassInit

func A_arbace_classes_env_member_methods_A_Init() { if !A_arbace_classes_env_member_methods_A_init.Done() { A_arbace_classes_env_member_methods_A_init.Run(A_arbace_classes_env_member_methods_A_clinit) } }

func A_arbace_classes_env_member_methods_A_clinit() { A_arbace_classes_env_member_methods_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_177, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_member_methods_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_member_methods_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_member_methods_A_class }

func (t *A_arbace_classes_env_member_methods_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_member_methods_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_member_methods_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_member_methods_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_member_methods_A); return ok }

func A_arbace_classes_env_member_methods_A_Cast(x any) *A_arbace_classes_env_member_methods_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_member_methods_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_member_methods_A_class)) }; return v }



type A_arbace_classes_env_member_methods_iter__28000175__28000179_A struct{ jrt.Object; F_seen, F_name, F_n, F_c any }

func (t *A_arbace_classes_env_member_methods_iter__28000175__28000179_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_member_methods_iter__28000175__28000179_A_fn_class *jrt.Class

var A_arbace_classes_env_member_methods_iter__28000175__28000179_A_init jrt.ClassInit

func A_arbace_classes_env_member_methods_iter__28000175__28000179_A_Init() { if !A_arbace_classes_env_member_methods_iter__28000175__28000179_A_init.Done() { A_arbace_classes_env_member_methods_iter__28000175__28000179_A_init.Run(A_arbace_classes_env_member_methods_iter__28000175__28000179_A_clinit) } }

func A_arbace_classes_env_member_methods_iter__28000175__28000179_A_clinit() { A_arbace_classes_env_member_methods_iter__28000175__28000179_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_178, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_member_methods_iter__28000175__28000179_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_member_methods_iter__28000175__28000179_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_member_methods_iter__28000175__28000179_A_class }

func (t *A_arbace_classes_env_member_methods_iter__28000175__28000179_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_member_methods_iter__28000175__28000179_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_member_methods_iter__28000175__28000179_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_member_methods_iter__28000175__28000179_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_member_methods_iter__28000175__28000179_A); return ok }

func A_arbace_classes_env_member_methods_iter__28000175__28000179_A_Cast(x any) *A_arbace_classes_env_member_methods_iter__28000175__28000179_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_member_methods_iter__28000175__28000179_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_member_methods_iter__28000175__28000179_A_class)) }; return v }



type A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A struct{ jrt.Object; F_seen, F_name, F_n, F_c, F_s__28000176, F_iter__28000175 any }

func (t *A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_fn_class *jrt.Class

var A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_init jrt.ClassInit

func A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_Init() { if !A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_init.Done() { A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_init.Run(A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_clinit) } }

func A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_clinit() { A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_179, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_class }

func (t *A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A); return ok }

func A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_Cast(x any) *A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_class)) }; return v }



type A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A struct{ jrt.Object; F_b__28000178, F_seen, F_name, F_n, F_c any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_fn_class *jrt.Class

var A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_init jrt.ClassInit

func A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_Init() { if !A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_init.Done() { A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_init.Run(A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_clinit) } }

func A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_clinit() { A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_180, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_class }

func (t *A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A); return ok }

func A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_Cast(x any) *A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_class)) }; return v }



type A_arbace_classes_env_nest_host_A struct{ jrt.Object }

func (t *A_arbace_classes_env_nest_host_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_nest_host_A_fn_class *jrt.Class

var A_arbace_classes_env_nest_host_A_init jrt.ClassInit

func A_arbace_classes_env_nest_host_A_Init() { if !A_arbace_classes_env_nest_host_A_init.Done() { A_arbace_classes_env_nest_host_A_init.Run(A_arbace_classes_env_nest_host_A_clinit) } }

func A_arbace_classes_env_nest_host_A_clinit() { A_arbace_classes_env_nest_host_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_181, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_nest_host_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_nest_host_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_nest_host_A_class }

func (t *A_arbace_classes_env_nest_host_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_nest_host_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_nest_host_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_nest_host_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_nest_host_A); return ok }

func A_arbace_classes_env_nest_host_A_Cast(x any) *A_arbace_classes_env_nest_host_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_nest_host_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_nest_host_A_class)) }; return v }



type A_arbace_classes_env_params_key_A struct{ jrt.Object }

func (t *A_arbace_classes_env_params_key_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_params_key_A_fn_class *jrt.Class

var A_arbace_classes_env_params_key_A_init jrt.ClassInit

func A_arbace_classes_env_params_key_A_Init() { if !A_arbace_classes_env_params_key_A_init.Done() { A_arbace_classes_env_params_key_A_init.Run(A_arbace_classes_env_params_key_A_clinit) } }

func A_arbace_classes_env_params_key_A_clinit() { A_arbace_classes_env_params_key_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_182, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_params_key_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_params_key_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_params_key_A_class }

func (t *A_arbace_classes_env_params_key_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_params_key_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_params_key_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_params_key_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_params_key_A); return ok }

func A_arbace_classes_env_params_key_A_Cast(x any) *A_arbace_classes_env_params_key_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_params_key_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_params_key_A_class)) }; return v }



type A_arbace_classes_env_read_fields_A struct{ jrt.Object }

func (t *A_arbace_classes_env_read_fields_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_read_fields_A_fn_class *jrt.Class

var A_arbace_classes_env_read_fields_A_init jrt.ClassInit

func A_arbace_classes_env_read_fields_A_Init() { if !A_arbace_classes_env_read_fields_A_init.Done() { A_arbace_classes_env_read_fields_A_init.Run(A_arbace_classes_env_read_fields_A_clinit) } }

func A_arbace_classes_env_read_fields_A_clinit() { A_arbace_classes_env_read_fields_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_184, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_read_fields_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_read_fields_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_read_fields_A_class }

func (t *A_arbace_classes_env_read_fields_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_read_fields_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_read_fields_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_read_fields_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_read_fields_A); return ok }

func A_arbace_classes_env_read_fields_A_Cast(x any) *A_arbace_classes_env_read_fields_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_read_fields_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_read_fields_A_class)) }; return v }



type A_arbace_classes_env_read_method_annotations_A struct{ jrt.Object }

func (t *A_arbace_classes_env_read_method_annotations_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_read_method_annotations_A_fn_class *jrt.Class

var A_arbace_classes_env_read_method_annotations_A_init jrt.ClassInit

func A_arbace_classes_env_read_method_annotations_A_Init() { if !A_arbace_classes_env_read_method_annotations_A_init.Done() { A_arbace_classes_env_read_method_annotations_A_init.Run(A_arbace_classes_env_read_method_annotations_A_clinit) } }

func A_arbace_classes_env_read_method_annotations_A_clinit() { A_arbace_classes_env_read_method_annotations_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_185, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_read_method_annotations_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_read_method_annotations_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_read_method_annotations_A_class }

func (t *A_arbace_classes_env_read_method_annotations_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_read_method_annotations_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_read_method_annotations_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_read_method_annotations_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_read_method_annotations_A); return ok }

func A_arbace_classes_env_read_method_annotations_A_Cast(x any) *A_arbace_classes_env_read_method_annotations_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_read_method_annotations_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_read_method_annotations_A_class)) }; return v }



type A_arbace_classes_env_record_BANG__A struct{ jrt.Object }

func (t *A_arbace_classes_env_record_BANG__A) Is_Compiler_AOTF3() {}

var A_arbace_classes_env_record_BANG__A_fn_class *jrt.Class

var A_arbace_classes_env_record_BANG__A_init jrt.ClassInit

func A_arbace_classes_env_record_BANG__A_Init() { if !A_arbace_classes_env_record_BANG__A_init.Done() { A_arbace_classes_env_record_BANG__A_init.Run(A_arbace_classes_env_record_BANG__A_clinit) } }

func A_arbace_classes_env_record_BANG__A_clinit() { A_arbace_classes_env_record_BANG__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_186, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_record_BANG__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_record_BANG__A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_record_BANG__A_class }

func (t *A_arbace_classes_env_record_BANG__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_record_BANG__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_record_BANG__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_record_BANG__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_record_BANG__A); return ok }

func A_arbace_classes_env_record_BANG__A_Cast(x any) *A_arbace_classes_env_record_BANG__A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_record_BANG__A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_record_BANG__A_class)) }; return v }



type A_arbace_classes_env_reflect_info_A struct{ jrt.Object }

func (t *A_arbace_classes_env_reflect_info_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_reflect_info_A_fn_class *jrt.Class

var A_arbace_classes_env_reflect_info_A_init jrt.ClassInit

func A_arbace_classes_env_reflect_info_A_Init() { if !A_arbace_classes_env_reflect_info_A_init.Done() { A_arbace_classes_env_reflect_info_A_init.Run(A_arbace_classes_env_reflect_info_A_clinit) } }

func A_arbace_classes_env_reflect_info_A_clinit() { A_arbace_classes_env_reflect_info_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_187, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_reflect_info_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_reflect_info_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_reflect_info_A_class }

func (t *A_arbace_classes_env_reflect_info_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_reflect_info_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_reflect_info_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_reflect_info_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_reflect_info_A); return ok }

func A_arbace_classes_env_reflect_info_A_Cast(x any) *A_arbace_classes_env_reflect_info_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_reflect_info_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_reflect_info_A_class)) }; return v }



type A_arbace_classes_env_reflect_info_fn__28000027_A struct{ jrt.Object; F_c any }

func (t *A_arbace_classes_env_reflect_info_fn__28000027_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_env_reflect_info_fn__28000027_A_fn_class *jrt.Class

var A_arbace_classes_env_reflect_info_fn__28000027_A_init jrt.ClassInit

func A_arbace_classes_env_reflect_info_fn__28000027_A_Init() { if !A_arbace_classes_env_reflect_info_fn__28000027_A_init.Done() { A_arbace_classes_env_reflect_info_fn__28000027_A_init.Run(A_arbace_classes_env_reflect_info_fn__28000027_A_clinit) } }

func A_arbace_classes_env_reflect_info_fn__28000027_A_clinit() { A_arbace_classes_env_reflect_info_fn__28000027_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_190, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_reflect_info_fn__28000027_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_reflect_info_fn__28000027_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_reflect_info_fn__28000027_A_class }

func (t *A_arbace_classes_env_reflect_info_fn__28000027_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_reflect_info_fn__28000027_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_reflect_info_fn__28000027_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_reflect_info_fn__28000027_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_reflect_info_fn__28000027_A); return ok }

func A_arbace_classes_env_reflect_info_fn__28000027_A_Cast(x any) *A_arbace_classes_env_reflect_info_fn__28000027_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_reflect_info_fn__28000027_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_reflect_info_fn__28000027_A_class)) }; return v }



type A_arbace_classes_env_reflect_info_fn__28000089_A struct{ jrt.Object }

func (t *A_arbace_classes_env_reflect_info_fn__28000089_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_reflect_info_fn__28000089_A_fn_class *jrt.Class

var A_arbace_classes_env_reflect_info_fn__28000089_A_init jrt.ClassInit

func A_arbace_classes_env_reflect_info_fn__28000089_A_Init() { if !A_arbace_classes_env_reflect_info_fn__28000089_A_init.Done() { A_arbace_classes_env_reflect_info_fn__28000089_A_init.Run(A_arbace_classes_env_reflect_info_fn__28000089_A_clinit) } }

func A_arbace_classes_env_reflect_info_fn__28000089_A_clinit() { A_arbace_classes_env_reflect_info_fn__28000089_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_191, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_reflect_info_fn__28000089_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_reflect_info_fn__28000089_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_reflect_info_fn__28000089_A_class }

func (t *A_arbace_classes_env_reflect_info_fn__28000089_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_reflect_info_fn__28000089_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_reflect_info_fn__28000089_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_reflect_info_fn__28000089_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_reflect_info_fn__28000089_A); return ok }

func A_arbace_classes_env_reflect_info_fn__28000089_A_Cast(x any) *A_arbace_classes_env_reflect_info_fn__28000089_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_reflect_info_fn__28000089_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_reflect_info_fn__28000089_A_class)) }; return v }



type A_arbace_classes_env_reflect_info_iter__28000031__28000035_A struct{ jrt.Object; F_n any }

func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_fn_class *jrt.Class

var A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_init jrt.ClassInit

func A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_Init() { if !A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_init.Done() { A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_init.Run(A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_clinit) } }

func A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_clinit() { A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_192, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_class }

func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000031__28000035_A); return ok }

func A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_Cast(x any) *A_arbace_classes_env_reflect_info_iter__28000031__28000035_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000031__28000035_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_class)) }; return v }



type A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A struct{ jrt.Object; F_n, F_s__28000032, F_iter__28000031 any }

func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_fn_class *jrt.Class

var A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_init jrt.ClassInit

func A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_Init() { if !A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_init.Done() { A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_init.Run(A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_clinit) } }

func A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_clinit() { A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_193, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_class }

func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A); return ok }

func A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_Cast(x any) *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_class)) }; return v }



type A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A struct{ jrt.Object; F_b__28000034, F_n any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_fn_class *jrt.Class

var A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_init jrt.ClassInit

func A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_Init() { if !A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_init.Done() { A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_init.Run(A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_clinit) } }

func A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_clinit() { A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_194, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_class }

func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A); return ok }

func A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_Cast(x any) *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_class)) }; return v }



type A_arbace_classes_env_reflect_info_iter__28000045__28000049_A struct{ jrt.Object; F_n any }

func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_fn_class *jrt.Class

var A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_init jrt.ClassInit

func A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_Init() { if !A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_init.Done() { A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_init.Run(A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_clinit) } }

func A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_clinit() { A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_195, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_class }

func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000045__28000049_A); return ok }

func A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_Cast(x any) *A_arbace_classes_env_reflect_info_iter__28000045__28000049_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000045__28000049_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_class)) }; return v }



type A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A struct{ jrt.Object; F_n, F_s__28000046, F_iter__28000045 any }

func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_fn_class *jrt.Class

var A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_init jrt.ClassInit

func A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_Init() { if !A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_init.Done() { A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_init.Run(A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_clinit) } }

func A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_clinit() { A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_196, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_class }

func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A); return ok }

func A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_Cast(x any) *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_class)) }; return v }



type A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A struct{ jrt.Object; F_n, F_b__28000048 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_fn_class *jrt.Class

var A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_init jrt.ClassInit

func A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_Init() { if !A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_init.Done() { A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_init.Run(A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_clinit) } }

func A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_clinit() { A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_197, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_class }

func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A); return ok }

func A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_Cast(x any) *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_class)) }; return v }



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_A struct{ jrt.Object; F_n, F_manns any }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_fn_class *jrt.Class

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_init jrt.ClassInit

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_Init() { if !A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_init.Done() { A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_init.Run(A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_clinit) } }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_clinit() { A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_198, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_class }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000055__28000059_A); return ok }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_Cast(x any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000055__28000059_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_class)) }; return v }



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A struct{ jrt.Object; F_n, F_manns, F_s__28000056, F_iter__28000055 any }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_fn_class *jrt.Class

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_init jrt.ClassInit

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_Init() { if !A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_init.Done() { A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_init.Run(A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_clinit) } }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_clinit() { A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_199, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_class }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A); return ok }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_Cast(x any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_class)) }; return v }



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A struct{ jrt.Object; F_n, F_b__28000058, F_manns any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_fn_class *jrt.Class

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_init jrt.ClassInit

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_Init() { if !A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_init.Done() { A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_init.Run(A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_clinit) } }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_clinit() { A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_200, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_class }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A); return ok }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_Cast(x any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_class)) }; return v }



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A struct{ jrt.Object; F_m, F_desc, F_manns any }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_fn_class *jrt.Class

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_init jrt.ClassInit

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_Init() { if !A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_init.Done() { A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_init.Run(A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_clinit) } }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_clinit() { A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_201, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_class }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A); return ok }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_Cast(x any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_class)) }; return v }



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A struct{ jrt.Object; F_m, F_desc, F_manns any }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_fn_class *jrt.Class

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_init jrt.ClassInit

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_Init() { if !A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_init.Done() { A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_init.Run(A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_clinit) } }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_clinit() { A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_202, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_class }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A); return ok }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_Cast(x any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_class)) }; return v }



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A struct{ jrt.Object; F_i, F_m, F_desc, F_manns any }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_fn_class *jrt.Class

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_init jrt.ClassInit

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_Init() { if !A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_init.Done() { A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_init.Run(A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_clinit) } }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_clinit() { A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_203, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_class }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A); return ok }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_Cast(x any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_class)) }; return v }



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A struct{ jrt.Object; F_m, F_desc, F_manns any }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_fn_class *jrt.Class

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_init jrt.ClassInit

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_Init() { if !A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_init.Done() { A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_init.Run(A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_clinit) } }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_clinit() { A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_204, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_class }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A); return ok }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_Cast(x any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_class)) }; return v }



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A struct{ jrt.Object; F_m, F_desc, F_manns any }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_fn_class *jrt.Class

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_init jrt.ClassInit

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_Init() { if !A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_init.Done() { A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_init.Run(A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_clinit) } }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_clinit() { A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_205, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_class }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A); return ok }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_Cast(x any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_class)) }; return v }



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A struct{ jrt.Object; F_i, F_m, F_desc, F_manns any }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_fn_class *jrt.Class

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_init jrt.ClassInit

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_Init() { if !A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_init.Done() { A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_init.Run(A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_clinit) } }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_clinit() { A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_206, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_class }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A); return ok }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_Cast(x any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_class)) }; return v }



type A_arbace_classes_env_reflect_info_iter__28000077__28000081_A struct{ jrt.Object; F_c, F_n any }

func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_fn_class *jrt.Class

var A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_init jrt.ClassInit

func A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_Init() { if !A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_init.Done() { A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_init.Run(A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_clinit) } }

func A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_clinit() { A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_207, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_class }

func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000077__28000081_A); return ok }

func A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_Cast(x any) *A_arbace_classes_env_reflect_info_iter__28000077__28000081_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000077__28000081_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_class)) }; return v }



type A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A struct{ jrt.Object; F_c, F_n, F_s__28000078, F_iter__28000077 any }

func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_fn_class *jrt.Class

var A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_init jrt.ClassInit

func A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_Init() { if !A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_init.Done() { A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_init.Run(A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_clinit) } }

func A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_clinit() { A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_208, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_class }

func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A); return ok }

func A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_Cast(x any) *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_class)) }; return v }



type A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A struct{ jrt.Object; F_c, F_n, F_b__28000080 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_fn_class *jrt.Class

var A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_init jrt.ClassInit

func A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_Init() { if !A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_init.Done() { A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_init.Run(A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_clinit) } }

func A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_clinit() { A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_210, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_class }

func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A); return ok }

func A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_Cast(x any) *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_class)) }; return v }



type A_arbace_classes_env_reflect_info_iter__28000091__28000095_A struct{ jrt.Object; F_n any }

func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_fn_class *jrt.Class

var A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_init jrt.ClassInit

func A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_Init() { if !A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_init.Done() { A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_init.Run(A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_clinit) } }

func A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_clinit() { A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_211, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_class }

func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000091__28000095_A); return ok }

func A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_Cast(x any) *A_arbace_classes_env_reflect_info_iter__28000091__28000095_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000091__28000095_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_class)) }; return v }



type A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A struct{ jrt.Object; F_n, F_s__28000092, F_iter__28000091 any }

func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_fn_class *jrt.Class

var A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_init jrt.ClassInit

func A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_Init() { if !A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_init.Done() { A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_init.Run(A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_clinit) } }

func A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_clinit() { A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_212, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_class }

func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A); return ok }

func A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_Cast(x any) *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_class)) }; return v }



type A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A struct{ jrt.Object; F_n any; F_size__1927001038__auto__ int32; F_b__28000094, F_c__1927001037__auto__ any }

func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_fn_class *jrt.Class

var A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_init jrt.ClassInit

func A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_Init() { if !A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_init.Done() { A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_init.Run(A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_clinit) } }

func A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_clinit() { A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_213, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_class }

func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A); return ok }

func A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_Cast(x any) *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_class)) }; return v }



type A_arbace_classes_env_reflected_A struct{ jrt.Object }

func (t *A_arbace_classes_env_reflected_A) Is_Compiler_AOTF3() {}

var A_arbace_classes_env_reflected_A_fn_class *jrt.Class

var A_arbace_classes_env_reflected_A_init jrt.ClassInit

func A_arbace_classes_env_reflected_A_Init() { if !A_arbace_classes_env_reflected_A_init.Done() { A_arbace_classes_env_reflected_A_init.Run(A_arbace_classes_env_reflected_A_clinit) } }

func A_arbace_classes_env_reflected_A_clinit() { A_arbace_classes_env_reflected_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_214, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_reflected_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_reflected_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_reflected_A_class }

func (t *A_arbace_classes_env_reflected_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_reflected_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_reflected_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_reflected_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_reflected_A); return ok }

func A_arbace_classes_env_reflected_A_Cast(x any) *A_arbace_classes_env_reflected_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_reflected_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_reflected_A_class)) }; return v }



type A_arbace_classes_env_subclass_QMARK__A struct{ jrt.Object }

func (t *A_arbace_classes_env_subclass_QMARK__A) Is_Compiler_AOTF2() {}

var A_arbace_classes_env_subclass_QMARK__A_fn_class *jrt.Class

var A_arbace_classes_env_subclass_QMARK__A_init jrt.ClassInit

func A_arbace_classes_env_subclass_QMARK__A_Init() { if !A_arbace_classes_env_subclass_QMARK__A_init.Done() { A_arbace_classes_env_subclass_QMARK__A_init.Run(A_arbace_classes_env_subclass_QMARK__A_clinit) } }

func A_arbace_classes_env_subclass_QMARK__A_clinit() { A_arbace_classes_env_subclass_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_218, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_subclass_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_subclass_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_subclass_QMARK__A_class }

func (t *A_arbace_classes_env_subclass_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_subclass_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_subclass_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_subclass_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_subclass_QMARK__A); return ok }

func A_arbace_classes_env_subclass_QMARK__A_Cast(x any) *A_arbace_classes_env_subclass_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_subclass_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_subclass_QMARK__A_class)) }; return v }



type A_arbace_classes_env_subclass_QMARK__fn__28000117_A struct{ jrt.Object; F_b any }

func (t *A_arbace_classes_env_subclass_QMARK__fn__28000117_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_subclass_QMARK__fn__28000117_A_fn_class *jrt.Class

var A_arbace_classes_env_subclass_QMARK__fn__28000117_A_init jrt.ClassInit

func A_arbace_classes_env_subclass_QMARK__fn__28000117_A_Init() { if !A_arbace_classes_env_subclass_QMARK__fn__28000117_A_init.Done() { A_arbace_classes_env_subclass_QMARK__fn__28000117_A_init.Run(A_arbace_classes_env_subclass_QMARK__fn__28000117_A_clinit) } }

func A_arbace_classes_env_subclass_QMARK__fn__28000117_A_clinit() { A_arbace_classes_env_subclass_QMARK__fn__28000117_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_219, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_subclass_QMARK__fn__28000117_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_subclass_QMARK__fn__28000117_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_subclass_QMARK__fn__28000117_A_class }

func (t *A_arbace_classes_env_subclass_QMARK__fn__28000117_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_subclass_QMARK__fn__28000117_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_subclass_QMARK__fn__28000117_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_subclass_QMARK__fn__28000117_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_subclass_QMARK__fn__28000117_A); return ok }

func A_arbace_classes_env_subclass_QMARK__fn__28000117_A_Cast(x any) *A_arbace_classes_env_subclass_QMARK__fn__28000117_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_subclass_QMARK__fn__28000117_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_subclass_QMARK__fn__28000117_A_class)) }; return v }



type A_arbace_classes_env_superclass_chain_A struct{ jrt.Object }

func (t *A_arbace_classes_env_superclass_chain_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_superclass_chain_A_fn_class *jrt.Class

var A_arbace_classes_env_superclass_chain_A_init jrt.ClassInit

func A_arbace_classes_env_superclass_chain_A_Init() { if !A_arbace_classes_env_superclass_chain_A_init.Done() { A_arbace_classes_env_superclass_chain_A_init.Run(A_arbace_classes_env_superclass_chain_A_clinit) } }

func A_arbace_classes_env_superclass_chain_A_clinit() { A_arbace_classes_env_superclass_chain_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_220, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_superclass_chain_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_superclass_chain_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_superclass_chain_A_class }

func (t *A_arbace_classes_env_superclass_chain_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_superclass_chain_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_superclass_chain_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_superclass_chain_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_superclass_chain_A); return ok }

func A_arbace_classes_env_superclass_chain_A_Cast(x any) *A_arbace_classes_env_superclass_chain_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_superclass_chain_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_superclass_chain_A_class)) }; return v }



type A_arbace_classes_env_superclass_chain_fn__28000123_A struct{ jrt.Object }

func (t *A_arbace_classes_env_superclass_chain_fn__28000123_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_superclass_chain_fn__28000123_A_fn_class *jrt.Class

var A_arbace_classes_env_superclass_chain_fn__28000123_A_init jrt.ClassInit

func A_arbace_classes_env_superclass_chain_fn__28000123_A_Init() { if !A_arbace_classes_env_superclass_chain_fn__28000123_A_init.Done() { A_arbace_classes_env_superclass_chain_fn__28000123_A_init.Run(A_arbace_classes_env_superclass_chain_fn__28000123_A_clinit) } }

func A_arbace_classes_env_superclass_chain_fn__28000123_A_clinit() { A_arbace_classes_env_superclass_chain_fn__28000123_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_221, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_superclass_chain_fn__28000123_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_superclass_chain_fn__28000123_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_superclass_chain_fn__28000123_A_class }

func (t *A_arbace_classes_env_superclass_chain_fn__28000123_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_superclass_chain_fn__28000123_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_superclass_chain_fn__28000123_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_superclass_chain_fn__28000123_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_superclass_chain_fn__28000123_A); return ok }

func A_arbace_classes_env_superclass_chain_fn__28000123_A_Cast(x any) *A_arbace_classes_env_superclass_chain_fn__28000123_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_superclass_chain_fn__28000123_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_superclass_chain_fn__28000123_A_class)) }; return v }



type A_arbace_classes_env_supertypes_A struct{ jrt.Object }

func (t *A_arbace_classes_env_supertypes_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_env_supertypes_A_fn_class *jrt.Class

var A_arbace_classes_env_supertypes_A_init jrt.ClassInit

func A_arbace_classes_env_supertypes_A_Init() { if !A_arbace_classes_env_supertypes_A_init.Done() { A_arbace_classes_env_supertypes_A_init.Run(A_arbace_classes_env_supertypes_A_clinit) } }

func A_arbace_classes_env_supertypes_A_clinit() { A_arbace_classes_env_supertypes_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_222, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_env_supertypes_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_supertypes_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_supertypes_A_class }

func (t *A_arbace_classes_env_supertypes_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_supertypes_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_supertypes_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_supertypes_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_supertypes_A); return ok }

func A_arbace_classes_env_supertypes_A_Cast(x any) *A_arbace_classes_env_supertypes_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_supertypes_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_supertypes_A_class)) }; return v }
