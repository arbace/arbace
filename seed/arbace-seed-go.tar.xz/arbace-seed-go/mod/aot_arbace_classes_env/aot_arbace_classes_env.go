//line aot_arbace_classes_env.ae:1
package aot_arbace_classes_env

import (
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_set"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_New() *A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_classes_env_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_env_A_const_1); lang.IFn_Cast(A_arbace_classes_env_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_classes_env_A_const_3, A_arbace_classes_env_A_const_4, A_arbace_classes_env_A_const_5, A_arbace_classes_env_A_const_6); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_14)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_15)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_16)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_17)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_classes_env_eval28000008_fn__28000009_A_New() *A_arbace_classes_env_eval28000008_fn__28000009_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_eval28000008_fn__28000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_env_eval28000008_fn__28000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_env_eval28000008_fn__28000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_7.GetRawRoot__O()); var tmp2 any; var root_18 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_19 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_18, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_20 lang.IFn; if linked_19 == nil { ifn_20 = lang.IFn_Cast(root_18) } else { ifn_20 = nil }; var arg_21 any = A_arbace_classes_env_A_const_9; if linked_19 == nil { tmp2 = ifn_20.Invoke_O__O(arg_21) } else { tmp2 = linked_19.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_18, arg_21) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_classes_env_A_const_10.GetRawRoot__O(), A_arbace_classes_env_A_const_11) }



























func A_arbace_classes_env_internal_A_New() *A_arbace_classes_env_internal_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_internal_A{}; t.Ctor(); return t }
//line :29:1
func (t *A_arbace_classes_env_internal_A) Ctor() {}
//line :29:1
func (t *A_arbace_classes_env_internal_A) Invoke_O_O__O(self, c__0 any) any { var root_22 any = A_arbace_classes_env_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref(); var arg_26 any = Lit_22; var arg_27 any = Lit_21; if linked_23 == nil { return ifn_24.Invoke_O_O_O__O(arg_25, arg_26, arg_27) } else { return linked_23.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_22, arg_25, arg_26, arg_27) } }







func A_arbace_classes_env_from_source_QMARK__A_New() *A_arbace_classes_env_from_source_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_from_source_QMARK__A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_classes_env_from_source_QMARK__A) Ctor() {}
//line :37:1
func (t *A_arbace_classes_env_from_source_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var tmp1 any; var and__1927000168__auto____2 any = A_arbace_classes_env_A_const_13.Get__O(); if jrt.J2g_Truth(and__1927000168__auto____2) { tmp1 = lang.IFn_Cast(A_arbace_classes_env_A_const_13.Get__O()).Invoke_O__O(n__0) } else { tmp1 = and__1927000168__auto____2 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() }


















func A_arbace_classes_env_record_BANG__A_New() *A_arbace_classes_env_record_BANG__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_record_BANG__A{}; t.Ctor(); return t }
//line :56:1
func (t *A_arbace_classes_env_record_BANG__A) Ctor() {}
//line :56:1
func (t *A_arbace_classes_env_record_BANG__A) Invoke_O_O_O_O__O(self, n__0, facet__1, v__2 any) any {


	if jrt.J2g_Truth(A_arbace_classes_env_A_const_14.Get__O()) { lang.IFn_Cast(A_arbace_classes_env_A_const_15.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_classes_env_A_const_14.Get__O(), A_arbace_classes_env_A_const_16.GetRawRoot__O(), n__0, A_arbace_classes_env_A_const_17.GetRawRoot__O(), facet__1, v__2) }
//line :56:1
	return v__2
}




func A_arbace_classes_env_load_class_A_New() *A_arbace_classes_env_load_class_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_load_class_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_classes_env_load_class_A) Ctor() {}
//line :62:1
func (t *A_arbace_classes_env_load_class_A) Invoke_O_O__O(self, n__0 any) any {



	var tmp1 any; var or__1927000174__auto____2 any; var root_37 any = A_arbace_classes_env_A_const_18.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_37, A_arbace_classes_env_from_source_QMARK__A_fn_class); var ifn_39 lang.IFn; if linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any = n__0; if linked_38 == nil { or__1927000174__auto____2 = ifn_39.Invoke_O__O(arg_40) } else { or__1927000174__auto____2 = linked_38.(*A_arbace_classes_env_from_source_QMARK__A).Invoke_O_O__O(root_37, arg_40) }; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { tmp1 = A_arbace_classes_env_A_const_19.Get__O() }; if jrt.J2g_Truth(tmp1) { return nil } else { var tmp2 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var cn__4 any; var tmp3 any; var root_41 any = A_arbace_classes_env_A_const_20.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_43 lang.IFn

		if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = n__0; var arg_45 any = Lit_11; if linked_42 == nil { tmp3 = ifn_43.Invoke_O_O__O(arg_44, arg_45) } else { tmp3 = linked_42.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_41, arg_44, arg_45) }; if jrt.J2g_Truth(tmp3) { var root_46 any = A_arbace_classes_env_A_const_12.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_48 lang.IFn; if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = n__0; var arg_50 any = Lit_21; var arg_51 any = Lit_22; if linked_47 == nil { cn__4 = ifn_48.Invoke_O_O_O__O(arg_49, arg_50, arg_51) } else { cn__4 = linked_47.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_46, arg_49, arg_50, arg_51) } } else { var root_52 any = A_arbace_classes_env_A_const_12.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_52, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_54 lang.IFn; if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any = n__0; var arg_56 any = Lit_21; var arg_57 any = Lit_22; if linked_53 == nil { cn__4 = ifn_54.Invoke_O_O_O__O(arg_55, arg_56, arg_57) } else { cn__4 = linked_53.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_52, arg_55, arg_56, arg_57) } }
//line :66:1
		var c__5 any = lang.RT_ClassForNameNonLoading_String__Class_NoInit(jrt.String_Cast(cn__4)).Ref(); var tmp4 any
		var and__1927000168__auto____6 any = c__5


		if jrt.J2g_Truth(and__1927000168__auto____6) { tmp4 = A_arbace_classes_env_A_const_14.Get__O() } else { tmp4 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp4) { var root_58 any = A_arbace_classes_env_A_const_21.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_58, A_arbace_classes_env_record_BANG__A_fn_class); var ifn_60 lang.IFn; if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = n__0; var arg_62 any = A_arbace_classes_env_A_const_22; var arg_63 any = jrt.Boolean_TRUE.Ref(); if linked_59 == nil { ifn_60.Invoke_O_O_O__O(arg_61, arg_62, arg_63) } else { linked_59.(*A_arbace_classes_env_record_BANG__A).Invoke_O_O_O_O__O(root_58, arg_61, arg_62, arg_63) } }
//line :66:1
		tmp2 = c__5 }; return nil }(); if tmp5 != nil { if jrt.ClassNotFoundException_InstanceOf(tmp5) { var ___4 *jrt.ClassNotFoundException = jrt.ClassNotFoundException_Cast(tmp5); _ = ___4; tmp2 = nil } else if jrt.NoClassDefFoundError_InstanceOf(tmp5) { var ___4_2 *jrt.NoClassDefFoundError = jrt.NoClassDefFoundError_Cast(tmp5); _ = ___4_2; tmp2 = nil } else { panic(tmp5) } }; return tmp2
	}
}






func A_arbace_classes_env_known_QMARK__A_New() *A_arbace_classes_env_known_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_known_QMARK__A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_classes_env_known_QMARK__A) Ctor() {}
//line :75:1
func (t *A_arbace_classes_env_known_QMARK__A) Invoke_O_O__O(self, n__0 any) any {





	if jrt.J2g_Truth(A_arbace_classes_env_A_const_19.Get__O()) { var and__1927000168__auto____2 any; var root_64 any = A_arbace_classes_env_A_const_23.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_66 lang.IFn; if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any = A_arbace_classes_env_A_const_19.Get__O(); var arg_68 any = n__0; if linked_65 == nil { and__1927000168__auto____2 = ifn_66.Invoke_O_O__O(arg_67, arg_68) } else { and__1927000168__auto____2 = linked_65.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_64, arg_67, arg_68) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_69 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_71 lang.IFn; if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any; var root_73 any = A_arbace_classes_env_A_const_18.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, A_arbace_classes_env_from_source_QMARK__A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = n__0; if linked_74 == nil { arg_72 = ifn_75.Invoke_O__O(arg_76) } else { arg_72 = linked_74.(*A_arbace_classes_env_from_source_QMARK__A).Invoke_O_O__O(root_73, arg_76) }; if linked_70 == nil { return ifn_71.Invoke_O__O(arg_72) } else { return linked_70.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_69, arg_72) } } else { return and__1927000168__auto____2 } } else { var root_77 any = A_arbace_classes_env_A_const_25.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_77, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_79 lang.IFn; if linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var arg_80 any; var root_81 any = A_arbace_classes_env_A_const_26.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, A_arbace_classes_env_load_class_A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = n__0; if linked_82 == nil { arg_80 = ifn_83.Invoke_O__O(arg_84) } else { arg_80 = linked_82.(*A_arbace_classes_env_load_class_A).Invoke_O_O__O(root_81, arg_84) }; if linked_78 == nil { return ifn_79.Invoke_O__O(arg_80) } else { return linked_78.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_77, arg_80)
	} } }
func A_arbace_classes_env_reflected_A_New() *A_arbace_classes_env_reflected_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflected_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_classes_env_reflected_A) Ctor() {}
//line :83:1
func (t *A_arbace_classes_env_reflected_A) Invoke_O_O_O_O__O(self, n__0, facet__1, f__2 any) any {




	if jrt.J2g_Truth(A_arbace_classes_env_A_const_19.Get__O()) { var temp__1927000414__auto____4 any = lang.RT_Get_O_O__O_NoInit(A_arbace_classes_env_A_const_19.Get__O(), n__0)
		if jrt.J2g_Truth(temp__1927000414__auto____4) { var d__5 any = temp__1927000414__auto____4; var temp__1927000408__auto____6 any; var root_85 any = A_arbace_classes_env_A_const_27.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_find_A_fn_class); var ifn_87 lang.IFn
			if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = d__5; var arg_89 any = facet__1; if linked_86 == nil { temp__1927000408__auto____6 = ifn_87.Invoke_O_O__O(arg_88, arg_89) } else { temp__1927000408__auto____6 = linked_86.(*aot_arbace_core.A_arbace_core_find_A).Invoke_O_O_O__O(root_85, arg_88, arg_89) }; if jrt.J2g_Truth(temp__1927000408__auto____6) { var e__7 any = temp__1927000408__auto____6; var root_90 any = A_arbace_classes_env_A_const_28.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_val_A_fn_class); var ifn_92 lang.IFn
				if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = e__7; if linked_91 == nil { return ifn_92.Invoke_O__O(arg_93) } else { return linked_91.(*aot_arbace_core.A_arbace_core_val_A).Invoke_O_O__O(root_90, arg_93) } } else {
//line :90:1
					var tmp1 any; var root_94 any = A_arbace_classes_env_A_const_29.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_96 lang.IFn

					if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_55, nil, Lit_56, nil, Lit_57); var tmp3 any; var root_99 any = A_arbace_classes_env_A_const_30.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_101 lang.IFn; if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any = facet__1; if linked_100 == nil { tmp3 = ifn_101.Invoke_O__O(arg_102) } else { tmp3 = linked_100.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_99, arg_102) }; var tmp4 any = tmp3; var tmp5 any; var root_103 any = A_arbace_classes_env_A_const_12.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_103, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_105 lang.IFn; if linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any; var root_109 any = A_arbace_classes_env_A_const_31.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_109, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_111 lang.IFn; if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any = n__0; if linked_110 == nil { arg_106 = ifn_111.Invoke_O__O(arg_112) } else { arg_106 = linked_110.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_109, arg_112) }; var arg_107 any = Lit_21; var arg_108 any = Lit_22; if linked_104 == nil { tmp5 = ifn_105.Invoke_O_O_O__O(arg_106, arg_107, arg_108) } else { tmp5 = linked_104.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_103, arg_106, arg_107, arg_108) }; arg_97 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp4, nil, tmp5, nil)).Ref(); var arg_98 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_env_A_const_32, n__0, A_arbace_classes_env_A_const_33, facet__1)); if linked_95 == nil { tmp1 = ifn_96.Invoke_O_O__O(arg_97, arg_98) } else { tmp1 = linked_95.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_94, arg_97, arg_98) }
//line :90:1
					panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) } } else {
//line :89:1
						return nil } } else {
//line :88:1
							var temp__1927000414__auto____4_2 any; var root_113 any = A_arbace_classes_env_A_const_26.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_113, A_arbace_classes_env_load_class_A_fn_class); var ifn_115 lang.IFn






							if linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any = n__0; if linked_114 == nil { temp__1927000414__auto____4_2 = ifn_115.Invoke_O__O(arg_116) } else { temp__1927000414__auto____4_2 = linked_114.(*A_arbace_classes_env_load_class_A).Invoke_O_O__O(root_113, arg_116) }; if jrt.J2g_Truth(temp__1927000414__auto____4_2) { var c__5 any = temp__1927000414__auto____4_2; var root_117 any = A_arbace_classes_env_A_const_21.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_117, A_arbace_classes_env_record_BANG__A_fn_class); var ifn_119 lang.IFn
								if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = n__0; var arg_121 any = facet__1; var arg_122 any = lang.IFn_Cast(f__2).Invoke_O__O(c__5); if linked_118 == nil { return ifn_119.Invoke_O_O_O__O(arg_120, arg_121, arg_122) } else { return linked_118.(*A_arbace_classes_env_record_BANG__A).Invoke_O_O_O_O__O(root_117, arg_120, arg_121, arg_122) } } else {
//line :95:1
									return nil
								}
						} }
func A_arbace_classes_env_class_file_QMARK__A_New() *A_arbace_classes_env_class_file_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_class_file_QMARK__A{}; t.Ctor(); return t }
//line :98:1
func (t *A_arbace_classes_env_class_file_QMARK__A) Ctor() {}
//line :98:1
func (t *A_arbace_classes_env_class_file_QMARK__A) Invoke_O_O__O(self, c__0 any) any { var ld__2 any; var or__1927000174__auto____2 any = jrt.NN(jrt.Class_Cast(c__0)).GetClassLoader__ClassLoader(); if





	jrt.J2g_Truth(or__1927000174__auto____2) { ld__2 = or__1927000174__auto____2 } else { ld__2 = jrt.ClassLoader_GetSystemClassLoader__ClassLoader() }; var temp__1927000414__auto____3 any; var tmp1 /*line :98:1*/*jrt.Class = A_arbace_classes_env_A_const_34; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_6); var tmp3 any; var root_123 any = A_arbace_classes_env_A_const_35.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, A_arbace_classes_env_internal_A_fn_class); var ifn_125 lang.IFn; if






	linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = c__0; if linked_124 == nil { tmp3 = ifn_125.Invoke_O__O(arg_126) } else { tmp3 = linked_124.(*A_arbace_classes_env_internal_A).Invoke_O_O__O(root_123, arg_126) }; temp__1927000414__auto____3 = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(ld__2, tmp1, Lit_5, jrt.RefArrayOf(jrt.Object_class, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil)).Ref())); if jrt.J2g_Truth(temp__1927000414__auto____3) { var in__4 any = temp__1927000414__auto____3
		jrt.InputStream_Cast(in__4).Close__V()
//line :105:1
		return jrt.Boolean_TRUE.Ref() } else { return nil } }



func A_arbace_classes_env_read_fields_A_New() *A_arbace_classes_env_read_fields_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_read_fields_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_classes_env_read_fields_A) Ctor() {}
//line :109:1
func (t *A_arbace_classes_env_read_fields_A) Invoke_O_O__O(self, c__0 any) any {




	var tmp1 any; var root_127 any = A_arbace_classes_env_A_const_36.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, A_arbace_classes_env_class_file_QMARK__A_fn_class); var ifn_129 lang.IFn; if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = c__0; if linked_128 == nil { tmp1 = ifn_129.Invoke_O__O(arg_130) } else { tmp1 = linked_128.(*A_arbace_classes_env_class_file_QMARK__A).Invoke_O_O__O(root_127, arg_130) }; if jrt.J2g_Truth(tmp1) {
		var tmp2 any; var root_131 any = A_arbace_classes_env_A_const_37.GetRawRoot__O(); var linked_132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_131, aot_arbace_core.A_arbace_core_requiring_resolve_A_fn_class); var ifn_133 lang.IFn; if linked_132 == nil { ifn_133 = lang.IFn_Cast(root_131) } else { ifn_133 = nil }; var arg_134 any = A_arbace_classes_env_A_const_38; if linked_132 == nil { tmp2 = ifn_133.Invoke_O__O(arg_134) } else { tmp2 = linked_132.(*aot_arbace_core.A_arbace_core_requiring_resolve_A).Invoke_O_O__O(root_131, arg_134) }; return lang.IFn_Cast(tmp2).Invoke_O__O(c__0) } else {
//line :114:1
			return nil
		}
}
func A_arbace_classes_env_read_method_annotations_A_New() *A_arbace_classes_env_read_method_annotations_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_read_method_annotations_A{}; t.Ctor(); return t }
//line :117:1
func (t *A_arbace_classes_env_read_method_annotations_A) Ctor() {}
//line :117:1
func (t *A_arbace_classes_env_read_method_annotations_A) Invoke_O_O__O(self, c__0 any) any {



	var tmp1 any; var root_135 any = A_arbace_classes_env_A_const_36.GetRawRoot__O(); var linked_136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_135, A_arbace_classes_env_class_file_QMARK__A_fn_class); var ifn_137 lang.IFn; if linked_136 == nil { ifn_137 = lang.IFn_Cast(root_135) } else { ifn_137 = nil }; var arg_138 any = c__0; if linked_136 == nil { tmp1 = ifn_137.Invoke_O__O(arg_138) } else { tmp1 = linked_136.(*A_arbace_classes_env_class_file_QMARK__A).Invoke_O_O__O(root_135, arg_138) }; if jrt.J2g_Truth(tmp1) {
		var tmp2 any; var root_139 any = A_arbace_classes_env_A_const_37.GetRawRoot__O(); var linked_140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_139, aot_arbace_core.A_arbace_core_requiring_resolve_A_fn_class); var ifn_141 lang.IFn; if linked_140 == nil { ifn_141 = lang.IFn_Cast(root_139) } else { ifn_141 = nil }; var arg_142 any = A_arbace_classes_env_A_const_39; if linked_140 == nil { tmp2 = ifn_141.Invoke_O__O(arg_142) } else { tmp2 = linked_140.(*aot_arbace_core.A_arbace_core_requiring_resolve_A).Invoke_O_O__O(root_139, arg_142) }; return lang.IFn_Cast(tmp2).Invoke_O__O(c__0) } else {
//line :121:1
			return lang.PersistentArrayMap_EMPTY.Ref()
		}
}

func A_arbace_classes_env_coerce_const_A_New() *A_arbace_classes_env_coerce_const_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_coerce_const_A{}; t.Ctor(); return t }
//line :125:1
func (t *A_arbace_classes_env_coerce_const_A) Ctor() {}
//line :125:1
func (t *A_arbace_classes_env_coerce_const_A) Invoke_O_O_O__O(self, desc__0, v__1 any) any { var G__28000023__3_ any = desc__0; switch
												lang.Util_Hash_O__I_NoInit(G__28000023__3_) { case 66: if lang.Util_Equiv_O_O__Z_NoInit(G__28000023__3_, Lit_7) {



		return jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_ByteCast_O__B_NoInit(v__1)).Ref() }
//line :126:1
	case 67: if lang.Util_Equiv_O_O__Z_NoInit(G__28000023__3_, Lit_8) {

		return jrt.Character_ValueOf_C__Character_NoInit(lang.RT_CharCast_I__C_NoInit(lang.RT_IntCast_O__I_NoInit(v__1))).Ref() }
//line :126:1
	case 83: if lang.Util_Equiv_O_O__Z_NoInit(G__28000023__3_, Lit_9) {


		return jrt.Short_ValueOf_S__Short_NoInit(lang.RT_ShortCast_O__S_NoInit(v__1)).Ref() }
//line :126:1
	case 90: if lang.Util_Equiv_O_O__Z_NoInit(G__28000023__3_, Lit_10) {
		var root_144 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_144, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_146 lang.IFn; if linked_145 == nil { ifn_146 = lang.IFn_Cast(root_144) } else { ifn_146 = nil }; var arg_147 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(v__1))).Ref(); if linked_145 == nil { return ifn_146.Invoke_O__O(arg_147) } else { return linked_145.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_144, arg_147) } }
//line :126:1
	default:}; return v__1 }












func A_arbace_classes_env_inner_member_QMARK__A_New() *A_arbace_classes_env_inner_member_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_inner_member_QMARK__A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_classes_env_inner_member_QMARK__A) Ctor() {}
//line :139:1
func (t *A_arbace_classes_env_inner_member_QMARK__A) Invoke_O_O__O(self, c__0 any) any {
	var tmp1 any; var and__1927000168__auto____2 any = jrt.NN(jrt.Class_Cast(c__0)).GetDeclaringClass__Class().Ref(); if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_148 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_148, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_150 lang.IFn; if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Modifier_IsStatic_I__Z(jrt.NN(jrt.Class_Cast(c__0)).GetModifiers__I())).Ref(); if linked_149 == nil { and__1927000168__auto____3 = ifn_150.Invoke_O__O(arg_151) } else { and__1927000168__auto____3 = linked_149.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_148, arg_151) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_152 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_154 lang.IFn
		if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(c__0)).IsInterface__Z()).Ref(); if linked_153 == nil { and__1927000168__auto____4 = ifn_154.Invoke_O__O(arg_155) } else { and__1927000168__auto____4 = linked_153.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_152, arg_155) }
//line :140:1
		if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_156 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_158 lang.IFn
			if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(c__0)).IsEnum__Z()).Ref(); if linked_157 == nil { and__1927000168__auto____5 = ifn_158.Invoke_O__O(arg_159) } else { and__1927000168__auto____5 = linked_157.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_156, arg_159) }
//line :140:1
			if jrt.J2g_Truth(and__1927000168__auto____5) {
				var root_160 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(c__0)).IsRecord__Z()).Ref(); if linked_161 == nil { tmp1 = ifn_162.Invoke_O__O(arg_163) } else { tmp1 = linked_161.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_160, arg_163) } } else {
//line :140:1
					tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}

func A_arbace_classes_env_reflect_info_A_New() *A_arbace_classes_env_reflect_info_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_A{}; t.Ctor(); return t }
//line :143:1
func (t *A_arbace_classes_env_reflect_info_A) Ctor() {}
//line :143:1
func (t *A_arbace_classes_env_reflect_info_A) Invoke_O_O__O(self, c__0 any) any { var or__1927000174__auto____2 any = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_40.GetRawRoot__O())).Get_O__O(c__0); if
										jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var lockee__1927000360__auto____3 any = A_arbace_classes_env_A_const_40.GetRawRoot__O(); var locklocal__1927000361__auto____6 any = lockee__1927000360__auto____3; lang.Compiler_Evaluator_MonitorEnter_O__V_NoInit(locklocal__1927000361__auto____6); var tmp1 any; tmp44 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var or__1927000174__auto____9 any = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_40.GetRawRoot__O())).Get_O__O(c__0)

		if jrt.J2g_Truth(or__1927000174__auto____9) { tmp1 = or__1927000174__auto____9 } else { var n__10 any; var root_164 any = A_arbace_classes_env_A_const_35.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, A_arbace_classes_env_internal_A_fn_class); var ifn_166 lang.IFn
			if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = c__0; if linked_165 == nil { n__10 = ifn_166.Invoke_O__O(arg_167) } else { n__10 = linked_165.(*A_arbace_classes_env_internal_A).Invoke_O_O__O(root_164, arg_167) }
//line :146:1
			var manns__11 any; var tmp2 any = A_arbace_classes_env_reflect_info_fn__28000027_A_New_O(c__0); var tmp3 *jrt.Class
			var fncls__172 /*line :146:1*/*jrt.Class = A_arbace_classes_env_reflect_info_fn__28000027_A_fn_class

			if fncls__172 == nil { var fncls__172d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_classes_env_reflect_info_fn__28000027_A_fn_class = fncls__172d; tmp3 = fncls__172d } else { tmp3 = fncls__172 }
//line :146:1
			manns__11 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var info__12 any; var tmp4 any = A_arbace_classes_env_A_const_42; var tmp5 any = A_arbace_classes_env_A_const_43; var tmp6 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Class_Cast(c__0)).GetModifiers__I()).Ref(); var tmp7 any = A_arbace_classes_env_A_const_44; var tmp8 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(c__0)).IsInterface__Z()).Ref(); var tmp9 any = A_arbace_classes_env_A_const_45; var tmp10 any; var G__28000029__12_ any = jrt.NN(jrt.Class_Cast(c__0)).GetSuperclass__Class().Ref()





			if lang.Util_Identical_O_O__Z_NoInit(G__28000029__12_, nil) { tmp10 = nil } else { var root_173 any = A_arbace_classes_env_A_const_35.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, A_arbace_classes_env_internal_A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any = G__28000029__12_; if linked_174 == nil { tmp10 = ifn_175.Invoke_O__O(arg_176) } else { tmp10 = linked_174.(*A_arbace_classes_env_internal_A).Invoke_O_O__O(root_173, arg_176) } }
//line :146:1
			var tmp11 any = tmp10; var tmp12 any = A_arbace_classes_env_A_const_46; var tmp13 any; var root_177 any = A_arbace_classes_env_A_const_47.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_177, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_179 lang.IFn






			if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any = A_arbace_classes_env_A_const_35.GetRawRoot__O(); var arg_181 any = jrt.NN(jrt.Class_Cast(c__0)).GetInterfaces__Class1().Ref(); if linked_178 == nil { tmp13 = ifn_179.Invoke_O_O__O(arg_180, arg_181) } else { tmp13 = linked_178.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_177, arg_180, arg_181) }
//line :146:1
			var tmp14 any = tmp13; var tmp15 any = A_arbace_classes_env_A_const_48; var tmp16 any; var root_182 any = A_arbace_classes_env_A_const_35.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, A_arbace_classes_env_internal_A_fn_class); var ifn_184 lang.IFn







			if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = jrt.NN(jrt.Class_Cast(c__0)).GetNestHost__Class().Ref(); if linked_183 == nil { tmp16 = ifn_184.Invoke_O__O(arg_185) } else { tmp16 = linked_183.(*A_arbace_classes_env_internal_A).Invoke_O_O__O(root_182, arg_185) }
//line :146:1
			var tmp17 any = tmp16; var tmp18 any = A_arbace_classes_env_A_const_49; var tmp19 any; var G__28000030__12_ any = jrt.NN(jrt.Class_Cast(c__0)).GetDeclaringClass__Class().Ref()








			if lang.Util_Identical_O_O__Z_NoInit(G__28000030__12_, nil) { tmp19 = nil } else { var root_186 any = A_arbace_classes_env_A_const_35.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, A_arbace_classes_env_internal_A_fn_class); var ifn_188 lang.IFn; if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any = G__28000030__12_; if linked_187 == nil { tmp19 = ifn_188.Invoke_O__O(arg_189) } else { tmp19 = linked_187.(*A_arbace_classes_env_internal_A).Invoke_O_O__O(root_186, arg_189) } }
//line :146:1
			var tmp20 any = tmp19; var tmp21 any = A_arbace_classes_env_A_const_50; var tmp22 any; var temp__1927000408__auto____12 any; var root_190 any = A_arbace_classes_env_A_const_51.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, A_arbace_classes_env_read_fields_A_fn_class); var ifn_192 lang.IFn









			if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = c__0; if linked_191 == nil { temp__1927000408__auto____12 = ifn_192.Invoke_O__O(arg_193) } else { temp__1927000408__auto____12 = linked_191.(*A_arbace_classes_env_read_fields_A).Invoke_O_O__O(root_190, arg_193) }; if jrt.J2g_Truth(temp__1927000408__auto____12) { var fs__13 any = temp__1927000408__auto____12; var root_194 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_194, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_196 lang.IFn
				if linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any; var iter__1927001039__auto____14 any; var tmp23 any = A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_New_O(n__10); var tmp24 *jrt.Class; var fncls__314 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_fn_class; if fncls__314 == nil { var fncls__314d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_fn_class = fncls__314d; tmp24 = fncls__314d } else { tmp24 = fncls__314 }; iter__1927001039__auto____14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil); arg_197 = lang.IFn_Cast(iter__1927001039__auto____14).Invoke_O__O(fs__13); if linked_195 == nil { tmp22 = ifn_196.Invoke_O__O(arg_197) } else { tmp22 = linked_195.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_194, arg_197) } } else {




					var root_315 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_315, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_317 lang.IFn; if linked_316 == nil { ifn_317 = lang.IFn_Cast(root_315) } else { ifn_317 = nil }; var arg_318 any; var iter__1927001039__auto____13 any; var tmp25 any = A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_New_O(n__10); var tmp26 *jrt.Class; var fncls__393 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_fn_class; if fncls__393 == nil { var fncls__393d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_fn_class = fncls__393d; tmp26 = fncls__393d } else { tmp26 = fncls__393 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil); arg_318 = lang.IFn_Cast(iter__1927001039__auto____13).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetDeclaredFields__Field1().Ref()); if linked_316 == nil { tmp22 = ifn_317.Invoke_O__O(arg_318) } else { tmp22 = linked_316.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_315, arg_318) } }
//line :146:1
			var tmp27 any = tmp22; var tmp28 any = A_arbace_classes_env_A_const_75; var tmp29 any; var root_394 any = A_arbace_classes_env_A_const_76.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, A_arbace_classes_env_inner_member_QMARK__A_fn_class); var ifn_396 lang.IFn
























			if linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any = c__0; if linked_395 == nil { tmp29 = ifn_396.Invoke_O__O(arg_397) } else { tmp29 = linked_395.(*A_arbace_classes_env_inner_member_QMARK__A).Invoke_O_O__O(root_394, arg_397) }
//line :146:1
			var tmp30 any = tmp29; var tmp31 any = A_arbace_classes_env_A_const_77; var tmp32 any; var root_398 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_400 lang.IFn

























			if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any; var root_402 any = A_arbace_classes_env_A_const_78.GetRawRoot__O(); var linked_403 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_402, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_404 lang.IFn; if linked_403 == nil { ifn_404 = lang.IFn_Cast(root_402) } else { ifn_404 = nil }; var arg_405 any; var iter__1927001039__auto____12 any; var tmp33 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_New_O_O(n__10, manns__11); var tmp34 *jrt.Class; var fncls__555 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_fn_class
			if fncls__555 == nil { var fncls__555d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_fn_class = fncls__555d; tmp34 = fncls__555d } else { tmp34 = fncls__555 }; iter__1927001039__auto____12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil); arg_405 = lang.IFn_Cast(iter__1927001039__auto____12).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetDeclaredMethods__Method1().Ref())
//line :172:1
			var arg_406 any; var iter__1927001039__auto____12_2 any; var tmp35 any = A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_New_O_O(c__0, n__10); var tmp36 *jrt.Class
			var fncls__668 /*line :172:1*/*jrt.Class = A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_fn_class











			if fncls__668 == nil { var fncls__668d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_fn_class = fncls__668d; tmp36 = fncls__668d } else { tmp36 = fncls__668 }; iter__1927001039__auto____12_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp35, tmp36, nil); arg_406 = lang.IFn_Cast(iter__1927001039__auto____12_2).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetDeclaredConstructors__Constructor1().Ref())
//line :172:1
			if linked_403 == nil { arg_401 = ifn_404.Invoke_O_O__O(arg_405, arg_406) } else { arg_401 = linked_403.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_402, arg_405, arg_406) }; if linked_399 == nil { tmp32 = ifn_400.Invoke_O__O(arg_401) } else { tmp32 = linked_399.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_398, arg_401) }
//line :146:1
			info__12 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, n__10, tmp5, tmp6, tmp7, tmp8, tmp9, tmp11, tmp12, tmp14, tmp15, tmp17, tmp18, tmp20, tmp21, tmp27, tmp28, tmp30, tmp31, tmp32, A_arbace_classes_env_A_const_32, c__0)); var info__13 any; var tmp37 any; var and__1927000168__auto____13 any; var root_669 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_669, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_671 lang.IFn
















































			if linked_670 == nil { ifn_671 = lang.IFn_Cast(root_669) } else { ifn_671 = nil }; var arg_672 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(c__0)).IsInterface__Z()).Ref(); if linked_670 == nil { and__1927000168__auto____13 = ifn_671.Invoke_O__O(arg_672) } else { and__1927000168__auto____13 = linked_670.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_669, arg_672) }; if jrt.J2g_Truth(and__1927000168__auto____13) { var root_673 any = A_arbace_classes_env_A_const_86.GetRawRoot__O(); var linked_674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_673, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_675 lang.IFn; if linked_674 == nil { ifn_675 = lang.IFn_Cast(root_673) } else { ifn_675 = nil }; var arg_676 any; var root_677 any = A_arbace_classes_env_A_const_87.GetRawRoot__O(); var linked_678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_677, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_679 lang.IFn; if linked_678 == nil { ifn_679 = lang.IFn_Cast(root_677) } else { ifn_679 = nil }; var arg_680 any; var tmp38 any = A_arbace_classes_env_reflect_info_fn__28000089_A_New(); var tmp39 *jrt.Class; var fncls__682 *jrt.Class = A_arbace_classes_env_reflect_info_fn__28000089_A_fn_class; if fncls__682 == nil { var fncls__682d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_classes_env_reflect_info_fn__28000089_A_fn_class = fncls__682d; tmp39 = fncls__682d } else { tmp39 = fncls__682 }; arg_680 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp38, tmp39, nil); var arg_681 any = A_arbace_classes_env_A_const_77.Invoke_O__O(info__12); if linked_678 == nil { arg_676 = ifn_679.Invoke_O_O__O(arg_680, arg_681) } else { arg_676 = linked_678.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_677, arg_680, arg_681) }; if linked_674 == nil { tmp37 = ifn_675.Invoke_O__O(arg_676) } else { tmp37 = linked_674.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_673, arg_676) } } else { tmp37 = and__1927000168__auto____13 }; if jrt.J2g_Truth(tmp37) {
				var root_683 any = A_arbace_classes_env_A_const_16.GetRawRoot__O(); var linked_684 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_683, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_685 lang.IFn; if linked_684 == nil { ifn_685 = lang.IFn_Cast(root_683) } else { ifn_685 = nil }; var arg_686 any = info__12; var arg_687 any = A_arbace_classes_env_A_const_77; var arg_688 any = A_arbace_classes_env_A_const_88.GetRawRoot__O(); var arg_689 any; var iter__1927001039__auto____13_2 any; var tmp40 any = A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_New_O(n__10); var tmp41 *jrt.Class; var fncls__748 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_fn_class; if fncls__748 == nil { var fncls__748d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_fn_class = fncls__748d; tmp41 = fncls__748d } else { tmp41 = fncls__748 }; iter__1927001039__auto____13_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp40, tmp41, nil); var tmp42 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____13_2); var tmp43 any; var root_749 any = A_arbace_classes_env_A_const_37.GetRawRoot__O(); var linked_750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_749, aot_arbace_core.A_arbace_core_requiring_resolve_A_fn_class); var ifn_751 lang.IFn; if linked_750 == nil { ifn_751 = lang.IFn_Cast(root_749) } else { ifn_751 = nil }; var arg_752 any = A_arbace_classes_env_A_const_89; if linked_750 == nil { tmp43 = ifn_751.Invoke_O__O(arg_752) } else { tmp43 = linked_750.(*aot_arbace_core.A_arbace_core_requiring_resolve_A).Invoke_O_O__O(root_749, arg_752) }; arg_689 = tmp42.Invoke_O__O(lang.IFn_Cast(tmp43).Invoke_O__O(n__10)); if linked_684 == nil { info__13 = ifn_685.Invoke_O_O_O_O__O(arg_686, arg_687, arg_688, arg_689) } else { info__13 = linked_684.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_683, arg_686, arg_687, arg_688, arg_689) } } else {
//line :195:1
					info__13 = info__12
				}


			jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_40.GetRawRoot__O())).Put_O_O__O(c__0, info__13)
//line :146:1
			tmp1 = info__13 } }; return nil }()
//line :144:1
		lang.Compiler_Evaluator_MonitorExit_O__V_NoInit(locklocal__1927000361__auto____6); if tmp44 != nil { panic(tmp44) }; return tmp1 } }



func A_arbace_classes_env_reflect_info_fn__28000027_A_New_O(p0 any) *A_arbace_classes_env_reflect_info_fn__28000027_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_fn__28000027_A{}; t.Ctor_O(p0); return t }
//line :148:1
func (t *A_arbace_classes_env_reflect_info_fn__28000027_A) Ctor_O(c__c any) { t.F_c = c__c }
//line :148:1
func (t *A_arbace_classes_env_reflect_info_fn__28000027_A) Invoke_O__O(self any) any { var root_168 any = A_arbace_classes_env_A_const_41.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, A_arbace_classes_env_read_method_annotations_A_fn_class); var ifn_170 lang.IFn; if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any; var t_ any = t.F_c; t.F_c = nil; arg_171 = t_; if linked_169 == nil { return ifn_170.Invoke_O__O(arg_171) } else { return linked_169.(*A_arbace_classes_env_read_method_annotations_A).Invoke_O_O__O(root_168, arg_171) } }








func A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_New_O(p0 any) *A_arbace_classes_env_reflect_info_iter__28000031__28000035_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000031__28000035_A{}; t.Ctor_O(p0); return t }
//line :157:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :157:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_A) Invoke_O_O__O(self, s__28000032__1 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_New_O_O_O(t.F_n, s__28000032__1, self); var tmp2 *jrt.Class; var fncls__313 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_fn_class; if fncls__313 == nil { var fncls__313d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_fn_class = fncls__313d; tmp2 = fncls__313d } else { tmp2 = fncls__313 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :157:1
func A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :157:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A) Ctor_O_O_O(c__n, c__s__28000032, c__iter__28000031 any) { t.F_n = c__n; t.F_s__28000032 = c__s__28000032; t.F_iter__28000031 = c__iter__28000031 }
//line :157:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A) Invoke_O__O(self any) any { { var s__28000032__1 any; var t_ any = t.F_s__28000032; t.F_s__28000032 = nil; s__28000032__1 = t_; for { var temp__1927000414__auto____2 any; var root_198 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_198, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_200 lang.IFn; if linked_199 == nil { ifn_200 = lang.IFn_Cast(root_198) } else { ifn_200 = nil }; var arg_201 any = s__28000032__1; if linked_199 == nil { temp__1927000414__auto____2 = ifn_200.Invoke_O__O(arg_201) } else { temp__1927000414__auto____2 = linked_199.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_198, arg_201) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__28000032__3 any = temp__1927000414__auto____2; var tmp1 any; var root_202 any = A_arbace_classes_env_A_const_54.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_204 lang.IFn; if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any = s__28000032__3; if linked_203 == nil { tmp1 = ifn_204.Invoke_O__O(arg_205) } else { tmp1 = linked_203.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_202, arg_205) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_206 any = A_arbace_classes_env_A_const_55.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_208 lang.IFn; if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any = s__28000032__3; if linked_207 == nil { c__1927001037__auto____4 = ifn_208.Invoke_O__O(arg_209) } else { c__1927001037__auto____4 = linked_207.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_206, arg_209) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__28000034__6 any; var root_210 any = A_arbace_classes_env_A_const_56.GetRawRoot__O(); var linked_211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_210, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_212 lang.IFn; if linked_211 == nil { ifn_212 = lang.IFn_Cast(root_210) } else { ifn_212 = nil }; var arg_213 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_211 == nil { b__28000034__6 = ifn_212.Invoke_O__O(arg_213) } else { b__28000034__6 = linked_211.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_210, arg_213) }; var tmp2 any = A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_New_O_O_I_O(b__28000034__6, t.F_n, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__248 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_fn_class; if fncls__248 == nil { var fncls__248d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_fn_class = fncls__248d; tmp3 = fncls__248d } else { tmp3 = fncls__248 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_249 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_251 lang.IFn; if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any; var root_254 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_256 lang.IFn; if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any = b__28000034__6; if linked_255 == nil { arg_252 = ifn_256.Invoke_O__O(arg_257) } else { arg_252 = linked_255.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_254, arg_257) }; var arg_253 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__28000031); var tmp5 any; var root_258 any = A_arbace_classes_env_A_const_70.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = s__28000032__3; if linked_259 == nil { tmp5 = ifn_260.Invoke_O__O(arg_261) } else { tmp5 = linked_259.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_258, arg_261) }; arg_253 = tmp4.Invoke_O__O(tmp5); if linked_250 == nil { return ifn_251.Invoke_O_O__O(arg_252, arg_253) } else { return linked_250.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_249, arg_252, arg_253) } } else { var root_262 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_264 lang.IFn; if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any; var root_267 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_267, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_269 lang.IFn; if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any = b__28000034__6; if linked_268 == nil { arg_265 = ifn_269.Invoke_O__O(arg_270) } else { arg_265 = linked_268.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_267, arg_270) }; var arg_266 any; if linked_263 == nil { return ifn_264.Invoke_O_O__O(arg_265, arg_266) } else { return linked_263.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_262, arg_265, arg_266) } } } else { var map__28000041__4 any; var root_271 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_273 lang.IFn; if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = s__28000032__3; if linked_272 == nil { map__28000041__4 = ifn_273.Invoke_O__O(arg_274) } else { map__28000041__4 = linked_272.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_271, arg_274) }; var map__28000041__5 any; if lang.ISeq_InstanceOf(map__28000041__4) { var tmp6 any; var root_275 any = A_arbace_classes_env_A_const_57.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_275, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_277 lang.IFn; if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any = map__28000041__4; if linked_276 == nil { tmp6 = ifn_277.Invoke_O__O(arg_278) } else { tmp6 = linked_276.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_275, arg_278) }; if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_279 any = A_arbace_classes_env_A_const_58.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = map__28000041__4; if linked_280 == nil { tmp7 = ifn_281.Invoke_O__O(arg_282) } else { tmp7 = linked_280.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_279, arg_282) }; map__28000041__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp7)).Ref() } else { var tmp8 any; var root_283 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_283, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_285 lang.IFn; if linked_284 == nil { ifn_285 = lang.IFn_Cast(root_283) } else { ifn_285 = nil }; var arg_286 any = map__28000041__4; if linked_284 == nil { tmp8 = ifn_285.Invoke_O__O(arg_286) } else { tmp8 = linked_284.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_283, arg_286) }; if jrt.J2g_Truth(tmp8) { var root_287 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_289 lang.IFn; if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any = map__28000041__4; if linked_288 == nil { map__28000041__5 = ifn_289.Invoke_O__O(arg_290) } else { map__28000041__5 = linked_288.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_287, arg_290) } } else { map__28000041__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__28000041__5 = map__28000041__4 }; var name__6 any = lang.RT_Get_O_O__O_NoInit(map__28000041__5, A_arbace_classes_env_A_const_42); var desc__7 any = lang.RT_Get_O_O__O_NoInit(map__28000041__5, A_arbace_classes_env_A_const_60); var flags__8 any = lang.RT_Get_O_O__O_NoInit(map__28000041__5, A_arbace_classes_env_A_const_43); var value__9 any = lang.RT_Get_O_O__O_NoInit(map__28000041__5, A_arbace_classes_env_A_const_61); var root_291 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_293 lang.IFn; if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any; var tmp9 any = A_arbace_classes_env_A_const_42; var tmp10 any = A_arbace_classes_env_A_const_60; var tmp11 any = A_arbace_classes_env_A_const_43; var tmp12 any = A_arbace_classes_env_A_const_63; var tmp13 any = t.F_n; var tmp14 any = A_arbace_classes_env_A_const_64; var tmp15 any; var tmp16 any; var and__1927000168__auto____10 bool = jrt.Modifier_IsFinal_I__Z(lang.RT_IntCast_O__I_NoInit(flags__8))

	if and__1927000168__auto____10 { var and__1927000168__auto____11 any; var root_296 any = A_arbace_classes_env_A_const_25.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_298 lang.IFn; if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = value__9; if linked_297 == nil { and__1927000168__auto____11 = ifn_298.Invoke_O__O(arg_299) } else { and__1927000168__auto____11 = linked_297.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_296, arg_299) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var or__1927000174__auto____12 any; var root_300 any = A_arbace_classes_env_A_const_65.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_302 lang.IFn
		if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = desc__7; if linked_301 == nil { or__1927000174__auto____12 = ifn_302.Invoke_O__O(arg_303) } else { or__1927000174__auto____12 = linked_301.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_300, arg_303) }; if jrt.J2g_Truth(or__1927000174__auto____12) { tmp16 = or__1927000174__auto____12 } else { tmp16 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(desc__7, A_arbace_classes_env_A_const_66.GetRawRoot__O())).Ref() } } else {
//line :159:1
			tmp16 = and__1927000168__auto____11 } } else { tmp16 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10).Ref() }; if jrt.J2g_Truth(tmp16) {

				var root_304 any = A_arbace_classes_env_A_const_67.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_304, A_arbace_classes_env_coerce_const_A_fn_class); var ifn_306 lang.IFn; if linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any = desc__7; var arg_308 any = value__9; if linked_305 == nil { tmp15 = ifn_306.Invoke_O_O__O(arg_307, arg_308) } else { tmp15 = linked_305.(*A_arbace_classes_env_coerce_const_A).Invoke_O_O_O__O(root_304, arg_307, arg_308) } } else {
//line :159:1
					tmp15 = nil }
//line :157:1
	arg_294 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, name__6, tmp10, desc__7, tmp11, flags__8, tmp12, tmp13, tmp14, tmp15)); var arg_295 any; var tmp17 lang.IFn = lang.IFn_Cast(t.F_iter__28000031); var tmp18 any; var root_309 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_309, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_311 lang.IFn; if linked_310 == nil { ifn_311 = lang.IFn_Cast(root_309) } else { ifn_311 = nil }; var arg_312 any = s__28000032__3; if linked_310 == nil { tmp18 = ifn_311.Invoke_O__O(arg_312) } else { tmp18 = linked_310.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_309, arg_312) }; arg_295 = tmp17.Invoke_O__O(tmp18); if linked_292 == nil { return ifn_293.Invoke_O_O__O(arg_294, arg_295) } else { return linked_292.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_291, arg_294, arg_295) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :157:1
func A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :157:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A) Ctor_O_O_I_O(c__b__28000034, c__n any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__28000034 = c__b__28000034; t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :157:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A) Invoke_O__O(self any) any { { var i__28000033__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__28000033__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var map__28000038__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__28000033__1)); var map__28000038__3 any; if lang.ISeq_InstanceOf(map__28000038__2) { var tmp2 any; var root_214 any = A_arbace_classes_env_A_const_57.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_214, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_216 lang.IFn; if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = map__28000038__2; if linked_215 == nil { tmp2 = ifn_216.Invoke_O__O(arg_217) } else { tmp2 = linked_215.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_214, arg_217) }; if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_218 any = A_arbace_classes_env_A_const_58.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_218, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_220 lang.IFn; if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any = map__28000038__2; if linked_219 == nil { tmp3 = ifn_220.Invoke_O__O(arg_221) } else { tmp3 = linked_219.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_218, arg_221) }; map__28000038__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp3)).Ref() } else { var tmp4 any; var root_222 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_222, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_224 lang.IFn; if linked_223 == nil { ifn_224 = lang.IFn_Cast(root_222) } else { ifn_224 = nil }; var arg_225 any = map__28000038__2; if linked_223 == nil { tmp4 = ifn_224.Invoke_O__O(arg_225) } else { tmp4 = linked_223.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_222, arg_225) }; if jrt.J2g_Truth(tmp4) { var root_226 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_226, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_228 lang.IFn; if linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var arg_229 any = map__28000038__2; if linked_227 == nil { map__28000038__3 = ifn_228.Invoke_O__O(arg_229) } else { map__28000038__3 = linked_227.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_226, arg_229) } } else { map__28000038__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__28000038__3 = map__28000038__2 }; var name__4 any = lang.RT_Get_O_O__O_NoInit(map__28000038__3, A_arbace_classes_env_A_const_42); var desc__5 any = lang.RT_Get_O_O__O_NoInit(map__28000038__3, A_arbace_classes_env_A_const_60); var flags__6 any = lang.RT_Get_O_O__O_NoInit(map__28000038__3, A_arbace_classes_env_A_const_43); var value__7 any = lang.RT_Get_O_O__O_NoInit(map__28000038__3, A_arbace_classes_env_A_const_61); var root_230 any = A_arbace_classes_env_A_const_62.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_230, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_232 lang.IFn; if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = t.F_b__28000034; var arg_234 any; var tmp5 any = A_arbace_classes_env_A_const_42; var tmp6 any = A_arbace_classes_env_A_const_60; var tmp7 any = A_arbace_classes_env_A_const_43; var tmp8 any = A_arbace_classes_env_A_const_63; var tmp9 any = t.F_n; var tmp10 any = A_arbace_classes_env_A_const_64; var tmp11 any; var tmp12 any; var and__1927000168__auto____8 bool = jrt.Modifier_IsFinal_I__Z(lang.RT_IntCast_O__I_NoInit(flags__6))

	if and__1927000168__auto____8 { var and__1927000168__auto____9 any; var root_235 any = A_arbace_classes_env_A_const_25.GetRawRoot__O(); var linked_236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_235, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_237 lang.IFn; if linked_236 == nil { ifn_237 = lang.IFn_Cast(root_235) } else { ifn_237 = nil }; var arg_238 any = value__7; if linked_236 == nil { and__1927000168__auto____9 = ifn_237.Invoke_O__O(arg_238) } else { and__1927000168__auto____9 = linked_236.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_235, arg_238) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var or__1927000174__auto____10 any; var root_239 any = A_arbace_classes_env_A_const_65.GetRawRoot__O(); var linked_240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_239, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_241 lang.IFn
		if linked_240 == nil { ifn_241 = lang.IFn_Cast(root_239) } else { ifn_241 = nil }; var arg_242 any = desc__5; if linked_240 == nil { or__1927000174__auto____10 = ifn_241.Invoke_O__O(arg_242) } else { or__1927000174__auto____10 = linked_240.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_239, arg_242) }; if jrt.J2g_Truth(or__1927000174__auto____10) { tmp12 = or__1927000174__auto____10 } else { tmp12 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(desc__5, A_arbace_classes_env_A_const_66.GetRawRoot__O())).Ref() } } else {
//line :159:1
			tmp12 = and__1927000168__auto____9 } } else { tmp12 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() }; if jrt.J2g_Truth(tmp12) {

				var root_243 any = A_arbace_classes_env_A_const_67.GetRawRoot__O(); var linked_244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_243, A_arbace_classes_env_coerce_const_A_fn_class); var ifn_245 lang.IFn; if linked_244 == nil { ifn_245 = lang.IFn_Cast(root_243) } else { ifn_245 = nil }; var arg_246 any = desc__5; var arg_247 any = value__7; if linked_244 == nil { tmp11 = ifn_245.Invoke_O_O__O(arg_246, arg_247) } else { tmp11 = linked_244.(*A_arbace_classes_env_coerce_const_A).Invoke_O_O_O__O(root_243, arg_246, arg_247) } } else {
//line :159:1
					tmp11 = nil }
//line :157:1
	arg_234 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, name__4, tmp6, desc__5, tmp7, flags__6, tmp8, tmp9, tmp10, tmp11)); if linked_231 == nil { ifn_232.Invoke_O_O__O(arg_233, arg_234) } else { linked_231.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_230, arg_233, arg_234) }; i__28000033__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000033__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_New_O(p0 any) *A_arbace_classes_env_reflect_info_iter__28000045__28000049_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000045__28000049_A{}; t.Ctor_O(p0); return t }
//line :162:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :162:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_A) Invoke_O_O__O(self, s__28000046__1 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_New_O_O_O(t.F_n, s__28000046__1, self); var tmp2 *jrt.Class; var fncls__392 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_fn_class; if fncls__392 == nil { var fncls__392d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_fn_class = fncls__392d; tmp2 = fncls__392d } else { tmp2 = fncls__392 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :162:1
func A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :162:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A) Ctor_O_O_O(c__n, c__s__28000046, c__iter__28000045 any) { t.F_n = c__n; t.F_s__28000046 = c__s__28000046; t.F_iter__28000045 = c__iter__28000045 }
//line :162:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A) Invoke_O__O(self any) any { { var s__28000046__1 any; var t_ any = t.F_s__28000046; t.F_s__28000046 = nil; s__28000046__1 = t_; for { var temp__1927000414__auto____2 any; var root_319 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_319, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_321 lang.IFn; if linked_320 == nil { ifn_321 = lang.IFn_Cast(root_319) } else { ifn_321 = nil }; var arg_322 any = s__28000046__1; if linked_320 == nil { temp__1927000414__auto____2 = ifn_321.Invoke_O__O(arg_322) } else { temp__1927000414__auto____2 = linked_320.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_319, arg_322) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__28000046__3 any = temp__1927000414__auto____2; var tmp1 any; var root_323 any = A_arbace_classes_env_A_const_54.GetRawRoot__O(); var linked_324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_323, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_325 lang.IFn; if linked_324 == nil { ifn_325 = lang.IFn_Cast(root_323) } else { ifn_325 = nil }; var arg_326 any = s__28000046__3; if linked_324 == nil { tmp1 = ifn_325.Invoke_O__O(arg_326) } else { tmp1 = linked_324.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_323, arg_326) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_327 any = A_arbace_classes_env_A_const_55.GetRawRoot__O(); var linked_328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_327, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_329 lang.IFn; if linked_328 == nil { ifn_329 = lang.IFn_Cast(root_327) } else { ifn_329 = nil }; var arg_330 any = s__28000046__3; if linked_328 == nil { c__1927001037__auto____4 = ifn_329.Invoke_O__O(arg_330) } else { c__1927001037__auto____4 = linked_328.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_327, arg_330) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__28000048__6 any; var root_331 any = A_arbace_classes_env_A_const_56.GetRawRoot__O(); var linked_332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_331, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_333 lang.IFn; if linked_332 == nil { ifn_333 = lang.IFn_Cast(root_331) } else { ifn_333 = nil }; var arg_334 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_332 == nil { b__28000048__6 = ifn_333.Invoke_O__O(arg_334) } else { b__28000048__6 = linked_332.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_331, arg_334) }; var tmp2 any = A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_New_O_O_I_O(t.F_n, b__28000048__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__348 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_fn_class; if fncls__348 == nil { var fncls__348d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_fn_class = fncls__348d; tmp3 = fncls__348d } else { tmp3 = fncls__348 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_349 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_349, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_351 lang.IFn; if linked_350 == nil { ifn_351 = lang.IFn_Cast(root_349) } else { ifn_351 = nil }; var arg_352 any; var root_354 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_354, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_356 lang.IFn; if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any = b__28000048__6; if linked_355 == nil { arg_352 = ifn_356.Invoke_O__O(arg_357) } else { arg_352 = linked_355.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_354, arg_357) }; var arg_353 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__28000045); var tmp5 any; var root_358 any = A_arbace_classes_env_A_const_70.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_360 lang.IFn; if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = s__28000046__3; if linked_359 == nil { tmp5 = ifn_360.Invoke_O__O(arg_361) } else { tmp5 = linked_359.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_358, arg_361) }; arg_353 = tmp4.Invoke_O__O(tmp5); if linked_350 == nil { return ifn_351.Invoke_O_O__O(arg_352, arg_353) } else { return linked_350.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_349, arg_352, arg_353) } } else { var root_362 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_362, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_364 lang.IFn; if linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any; var root_367 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_367, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_369 lang.IFn; if linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any = b__28000048__6; if linked_368 == nil { arg_365 = ifn_369.Invoke_O__O(arg_370) } else { arg_365 = linked_368.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_367, arg_370) }; var arg_366 any; if linked_363 == nil { return ifn_364.Invoke_O_O__O(arg_365, arg_366) } else { return linked_363.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_362, arg_365, arg_366) } } } else { var f__4 any; var root_371 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_371, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_373 lang.IFn; if linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any = s__28000046__3; if linked_372 == nil { f__4 = ifn_373.Invoke_O__O(arg_374) } else { f__4 = linked_372.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_371, arg_374) }; var desc__5 any; var root_375 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_375, aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A_fn_class); var ifn_377 lang.IFn
														if linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any = jrt.NN(jrt.Field_Cast(f__4)).GetType__Class().Ref(); if linked_376 == nil { desc__5 = ifn_377.Invoke_O__O(arg_378) } else { desc__5 = linked_376.(*aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A).Invoke_O_O__O(root_375, arg_378) }
//line :162:1
	var flags__6 int32 = jrt.NN(jrt.Field_Cast(f__4)).GetModifiers__I(); var root_379 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_379, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_381 lang.IFn; if linked_380 == nil { ifn_381 = lang.IFn_Cast(root_379) } else { ifn_381 = nil }; var arg_382 any; var tmp6 any = A_arbace_classes_env_A_const_42; var tmp7 any = jrt.NN(jrt.Field_Cast(f__4)).GetName__String().Ref(); var tmp8 any = A_arbace_classes_env_A_const_60; var tmp9 any = A_arbace_classes_env_A_const_43; var tmp10 any = jrt.Integer_ValueOf_I__Integer_NoInit(flags__6).Ref(); var tmp11 any = A_arbace_classes_env_A_const_63; var tmp12 any = t.F_n; var tmp13 any = A_arbace_classes_env_A_const_64; var tmp14 any; var tmp15 bool; var and__1927000168__auto____7 bool = jrt.Modifier_IsStatic_I__Z(flags__6)





	if and__1927000168__auto____7 { tmp15 = jrt.Modifier_IsFinal_I__Z(flags__6) } else { tmp15 = and__1927000168__auto____7 }; if tmp15 {
		var tmp16 any; var root_384 any = A_arbace_classes_env_A_const_37.GetRawRoot__O(); var linked_385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_384, aot_arbace_core.A_arbace_core_requiring_resolve_A_fn_class); var ifn_386 lang.IFn; if linked_385 == nil { ifn_386 = lang.IFn_Cast(root_384) } else { ifn_386 = nil }; var arg_387 any = A_arbace_classes_env_A_const_74; if linked_385 == nil { tmp16 = ifn_386.Invoke_O__O(arg_387) } else { tmp16 = linked_385.(*aot_arbace_core.A_arbace_core_requiring_resolve_A).Invoke_O_O__O(root_384, arg_387) }; var tmp17 lang.IFn = lang.IFn_Cast(tmp16); var tmp18 any = t.F_n; tmp14 = tmp17.Invoke_O_O_O__O(tmp18, jrt.NN(jrt.Field_Cast(f__4)).GetName__String().Ref(), desc__5) } else {
//line :168:1
			tmp14 = nil }
//line :162:1
	arg_382 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7, tmp8, desc__5, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14)); var arg_383 any; var tmp19 lang.IFn = lang.IFn_Cast(t.F_iter__28000045); var tmp20 any; var root_388 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_388, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_390 lang.IFn; if linked_389 == nil { ifn_390 = lang.IFn_Cast(root_388) } else { ifn_390 = nil }; var arg_391 any = s__28000046__3; if linked_389 == nil { tmp20 = ifn_390.Invoke_O__O(arg_391) } else { tmp20 = linked_389.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_388, arg_391) }; arg_383 = tmp19.Invoke_O__O(tmp20); if linked_380 == nil { return ifn_381.Invoke_O_O__O(arg_382, arg_383) } else { return linked_380.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_379, arg_382, arg_383) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :162:1
func A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :162:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A) Ctor_O_O_I_O(c__n, c__b__28000048 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__28000048 = c__b__28000048; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :162:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A) Invoke_O__O(self any) any { { var i__28000047__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__28000047__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__28000047__1)); var desc__3 any; var root_335 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var linked_336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_335, aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A_fn_class); var ifn_337 lang.IFn
																if linked_336 == nil { ifn_337 = lang.IFn_Cast(root_335) } else { ifn_337 = nil }; var arg_338 any = jrt.NN(jrt.Field_Cast(f__2)).GetType__Class().Ref(); if linked_336 == nil { desc__3 = ifn_337.Invoke_O__O(arg_338) } else { desc__3 = linked_336.(*aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A).Invoke_O_O__O(root_335, arg_338) }
//line :162:1
	var flags__4 int32 = jrt.NN(jrt.Field_Cast(f__2)).GetModifiers__I(); var root_339 any = A_arbace_classes_env_A_const_62.GetRawRoot__O(); var linked_340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_339, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_341 lang.IFn; if linked_340 == nil { ifn_341 = lang.IFn_Cast(root_339) } else { ifn_341 = nil }; var arg_342 any = t.F_b__28000048; var arg_343 any; var tmp2 any = A_arbace_classes_env_A_const_42; var tmp3 any = jrt.NN(jrt.Field_Cast(f__2)).GetName__String().Ref(); var tmp4 any = A_arbace_classes_env_A_const_60; var tmp5 any = A_arbace_classes_env_A_const_43; var tmp6 any = jrt.Integer_ValueOf_I__Integer_NoInit(flags__4).Ref(); var tmp7 any = A_arbace_classes_env_A_const_63; var tmp8 any = t.F_n; var tmp9 any = A_arbace_classes_env_A_const_64; var tmp10 any; var tmp11 bool; var and__1927000168__auto____5 bool = jrt.Modifier_IsStatic_I__Z(flags__4)





	if and__1927000168__auto____5 { tmp11 = jrt.Modifier_IsFinal_I__Z(flags__4) } else { tmp11 = and__1927000168__auto____5 }; if tmp11 {
		var tmp12 any; var root_344 any = A_arbace_classes_env_A_const_37.GetRawRoot__O(); var linked_345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_344, aot_arbace_core.A_arbace_core_requiring_resolve_A_fn_class); var ifn_346 lang.IFn; if linked_345 == nil { ifn_346 = lang.IFn_Cast(root_344) } else { ifn_346 = nil }; var arg_347 any = A_arbace_classes_env_A_const_74; if linked_345 == nil { tmp12 = ifn_346.Invoke_O__O(arg_347) } else { tmp12 = linked_345.(*aot_arbace_core.A_arbace_core_requiring_resolve_A).Invoke_O_O__O(root_344, arg_347) }; var tmp13 lang.IFn = lang.IFn_Cast(tmp12); var tmp14 any = t.F_n; tmp10 = tmp13.Invoke_O_O_O__O(tmp14, jrt.NN(jrt.Field_Cast(f__2)).GetName__String().Ref(), desc__3) } else {
//line :168:1
			tmp10 = nil }
//line :162:1
	arg_343 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, desc__3, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10)); if linked_340 == nil { ifn_341.Invoke_O_O__O(arg_342, arg_343) } else { linked_340.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_339, arg_342, arg_343) }; i__28000047__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000047__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }










func A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_New_O_O(p0, p1 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_A{}; t.Ctor_O_O(p0, p1); return t }
//line :173:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_A) Ctor_O_O(c__n, c__manns any) { t.F_n = c__n; t.F_manns = c__manns }
//line :173:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_A) Invoke_O_O__O(self, s__28000056__1 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_New_O_O_O_O(t.F_n, t.F_manns, s__28000056__1, self); var tmp2 *jrt.Class; var fncls__554 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_fn_class; if fncls__554 == nil { var fncls__554d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_fn_class = fncls__554d; tmp2 = fncls__554d } else { tmp2 = fncls__554 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :173:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :173:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A) Ctor_O_O_O_O(c__n, c__manns, c__s__28000056, c__iter__28000055 any) { t.F_n = c__n; t.F_manns = c__manns; t.F_s__28000056 = c__s__28000056; t.F_iter__28000055 = c__iter__28000055 }
//line :173:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A) Invoke_O__O(self any) any { { var s__28000056__1 any; var t_ any = t.F_s__28000056; t.F_s__28000056 = nil; s__28000056__1 = t_; for { var temp__1927000414__auto____2 any; var root_407 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_407, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_409 lang.IFn; if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any = s__28000056__1; if linked_408 == nil { temp__1927000414__auto____2 = ifn_409.Invoke_O__O(arg_410) } else { temp__1927000414__auto____2 = linked_408.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_407, arg_410) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__28000056__3 any = temp__1927000414__auto____2; var tmp1 any; var root_411 any = A_arbace_classes_env_A_const_54.GetRawRoot__O(); var linked_412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_411, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_413 lang.IFn; if linked_412 == nil { ifn_413 = lang.IFn_Cast(root_411) } else { ifn_413 = nil }; var arg_414 any = s__28000056__3; if linked_412 == nil { tmp1 = ifn_413.Invoke_O__O(arg_414) } else { tmp1 = linked_412.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_411, arg_414) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_415 any = A_arbace_classes_env_A_const_55.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_415, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_417 lang.IFn; if linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; var arg_418 any = s__28000056__3; if linked_416 == nil { c__1927001037__auto____4 = ifn_417.Invoke_O__O(arg_418) } else { c__1927001037__auto____4 = linked_416.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_415, arg_418) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__28000058__6 any; var root_419 any = A_arbace_classes_env_A_const_56.GetRawRoot__O(); var linked_420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_419, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_421 lang.IFn; if linked_420 == nil { ifn_421 = lang.IFn_Cast(root_419) } else { ifn_421 = nil }; var arg_422 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_420 == nil { b__28000058__6 = ifn_421.Invoke_O__O(arg_422) } else { b__28000058__6 = linked_420.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_419, arg_422) }; var tmp2 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_New_O_O_O_I_O(t.F_n, b__28000058__6, t.F_manns, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__473 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_fn_class; if fncls__473 == nil { var fncls__473d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_fn_class = fncls__473d; tmp3 = fncls__473d } else { tmp3 = fncls__473 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_474 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_474, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_476 lang.IFn; if linked_475 == nil { ifn_476 = lang.IFn_Cast(root_474) } else { ifn_476 = nil }; var arg_477 any; var root_479 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_481 lang.IFn; if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any = b__28000058__6; if linked_480 == nil { arg_477 = ifn_481.Invoke_O__O(arg_482) } else { arg_477 = linked_480.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_479, arg_482) }; var arg_478 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__28000055); var tmp5 any; var root_483 any = A_arbace_classes_env_A_const_70.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_483, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_485 lang.IFn; if linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; var arg_486 any = s__28000056__3; if linked_484 == nil { tmp5 = ifn_485.Invoke_O__O(arg_486) } else { tmp5 = linked_484.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_483, arg_486) }; arg_478 = tmp4.Invoke_O__O(tmp5); if linked_475 == nil { return ifn_476.Invoke_O_O__O(arg_477, arg_478) } else { return linked_475.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_474, arg_477, arg_478) } } else { var root_487 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_487, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_489 lang.IFn; if linked_488 == nil { ifn_489 = lang.IFn_Cast(root_487) } else { ifn_489 = nil }; var arg_490 any; var root_492 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_492, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_494 lang.IFn; if linked_493 == nil { ifn_494 = lang.IFn_Cast(root_492) } else { ifn_494 = nil }; var arg_495 any = b__28000058__6; if linked_493 == nil { arg_490 = ifn_494.Invoke_O__O(arg_495) } else { arg_490 = linked_493.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_492, arg_495) }; var arg_491 any; if linked_488 == nil { return ifn_489.Invoke_O_O__O(arg_490, arg_491) } else { return linked_488.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_487, arg_490, arg_491) } } } else { var m__4 any; var root_496 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_496, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_498 lang.IFn; if linked_497 == nil { ifn_498 = lang.IFn_Cast(root_496) } else { ifn_498 = nil }; var arg_499 any = s__28000056__3; if linked_497 == nil { m__4 = ifn_498.Invoke_O__O(arg_499) } else { m__4 = linked_497.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_496, arg_499) }; var desc__5 any; var root_500 any = A_arbace_classes_env_A_const_79.GetRawRoot__O(); var linked_501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_500, aot_arbace_classes_types.A_arbace_classes_types_method_desc_A_fn_class); var ifn_502 lang.IFn
														if linked_501 == nil { ifn_502 = lang.IFn_Cast(root_500) } else { ifn_502 = nil }; var arg_503 any; var root_505 any = A_arbace_classes_env_A_const_80.GetRawRoot__O(); var linked_506 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_505, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_507 lang.IFn; if linked_506 == nil { ifn_507 = lang.IFn_Cast(root_505) } else { ifn_507 = nil }; var arg_508 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var arg_509 any = jrt.NN(jrt.Method_Cast(m__4)).GetParameterTypes__Class1().Ref(); if linked_506 == nil { arg_503 = ifn_507.Invoke_O_O__O(arg_508, arg_509) } else { arg_503 = linked_506.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_505, arg_508, arg_509) }; var arg_504 any; var root_510 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_510, aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A_fn_class); var ifn_512 lang.IFn
														if linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any = jrt.NN(jrt.Method_Cast(m__4)).GetReturnType__Class().Ref(); if linked_511 == nil { arg_504 = ifn_512.Invoke_O__O(arg_513) } else { arg_504 = linked_511.(*aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A).Invoke_O_O__O(root_510, arg_513) }
//line :174:1
	if linked_501 == nil { desc__5 = ifn_502.Invoke_O_O__O(arg_503, arg_504) } else { desc__5 = linked_501.(*aot_arbace_classes_types.A_arbace_classes_types_method_desc_A).Invoke_O_O_O__O(root_500, arg_503, arg_504) }
//line :173:1
	var root_514 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_514, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_516 lang.IFn; if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any; var tmp6 any = A_arbace_classes_env_A_const_42; var tmp7 any = jrt.NN(jrt.Method_Cast(m__4)).GetName__String().Ref(); var tmp8 any = A_arbace_classes_env_A_const_60; var tmp9 any = A_arbace_classes_env_A_const_43; var tmp10 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Method_Cast(m__4)).GetModifiers__I()).Ref(); var tmp11 any = A_arbace_classes_env_A_const_63; var tmp12 any = t.F_n; var tmp13 any = A_arbace_classes_env_A_const_81; var tmp14 any; var root_519 any = A_arbace_classes_env_A_const_47.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_519, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_521 lang.IFn





	if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = A_arbace_classes_env_A_const_35.GetRawRoot__O(); var arg_523 any = jrt.NN(jrt.Method_Cast(m__4)).GetExceptionTypes__Class1().Ref(); if linked_520 == nil { tmp14 = ifn_521.Invoke_O_O__O(arg_522, arg_523) } else { tmp14 = linked_520.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_519, arg_522, arg_523) }
//line :173:1
	var tmp15 any = tmp14; var tmp16 any = A_arbace_classes_env_A_const_82; var tmp17 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_New_O_O_O(m__4, desc__5, t.F_manns); var tmp18 *jrt.Class
	var fncls__533 /*line :173:1*/*jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_fn_class






	if fncls__533 == nil { var fncls__533d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_fn_class = fncls__533d; tmp18 = fncls__533d } else { tmp18 = fncls__533 }
//line :173:1
	var tmp19 any = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil)); var tmp20 any = A_arbace_classes_env_A_const_84; var tmp21 any; var root_534 any = A_arbace_classes_env_A_const_85.GetRawRoot__O(); var linked_535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_534, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_536 lang.IFn







	if linked_535 == nil { ifn_536 = lang.IFn_Cast(root_534) } else { ifn_536 = nil }; var arg_537 any; var tmp22 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_New_O_O_O(m__4, desc__5, t.F_manns); var tmp23 *jrt.Class; var fncls__549 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_fn_class
	if fncls__549 == nil { var fncls__549d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_fn_class = fncls__549d; tmp23 = fncls__549d } else { tmp23 = fncls__549 }; arg_537 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil)
//line :181:1
	var arg_538 any = jrt.NN(jrt.Method_Cast(m__4)).GetParameterTypes__Class1().Ref(); if linked_535 == nil { tmp21 = ifn_536.Invoke_O_O__O(arg_537, arg_538) } else { tmp21 = linked_535.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_534, arg_537, arg_538) }
//line :173:1
	arg_517 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7, tmp8, desc__5, tmp9, tmp10, tmp11, tmp12, tmp13, tmp15, tmp16, tmp19, tmp20, tmp21)); var arg_518 any; var tmp24 lang.IFn = lang.IFn_Cast(t.F_iter__28000055); var tmp25 any; var root_550 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_550, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_552 lang.IFn; if linked_551 == nil { ifn_552 = lang.IFn_Cast(root_550) } else { ifn_552 = nil }; var arg_553 any = s__28000056__3; if linked_551 == nil { tmp25 = ifn_552.Invoke_O__O(arg_553) } else { tmp25 = linked_551.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_550, arg_553) }; arg_518 = tmp24.Invoke_O__O(tmp25); if linked_515 == nil { return ifn_516.Invoke_O_O__O(arg_517, arg_518) } else { return linked_515.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_514, arg_517, arg_518) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :173:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :173:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A) Ctor_O_O_O_I_O(c__n, c__b__28000058, c__manns any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__28000058 = c__b__28000058; t.F_manns = c__manns; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :173:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A) Invoke_O__O(self any) any { { var i__28000057__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__28000057__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__28000057__1)); var desc__3 any; var root_423 any = A_arbace_classes_env_A_const_79.GetRawRoot__O(); var linked_424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_423, aot_arbace_classes_types.A_arbace_classes_types_method_desc_A_fn_class); var ifn_425 lang.IFn
																if linked_424 == nil { ifn_425 = lang.IFn_Cast(root_423) } else { ifn_425 = nil }; var arg_426 any; var root_428 any = A_arbace_classes_env_A_const_80.GetRawRoot__O(); var linked_429 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_428, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_430 lang.IFn; if linked_429 == nil { ifn_430 = lang.IFn_Cast(root_428) } else { ifn_430 = nil }; var arg_431 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var arg_432 any = jrt.NN(jrt.Method_Cast(m__2)).GetParameterTypes__Class1().Ref(); if linked_429 == nil { arg_426 = ifn_430.Invoke_O_O__O(arg_431, arg_432) } else { arg_426 = linked_429.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_428, arg_431, arg_432) }; var arg_427 any; var root_433 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var linked_434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_433, aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A_fn_class); var ifn_435 lang.IFn
																if linked_434 == nil { ifn_435 = lang.IFn_Cast(root_433) } else { ifn_435 = nil }; var arg_436 any = jrt.NN(jrt.Method_Cast(m__2)).GetReturnType__Class().Ref(); if linked_434 == nil { arg_427 = ifn_435.Invoke_O__O(arg_436) } else { arg_427 = linked_434.(*aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A).Invoke_O_O__O(root_433, arg_436) }
//line :174:1
	if linked_424 == nil { desc__3 = ifn_425.Invoke_O_O__O(arg_426, arg_427) } else { desc__3 = linked_424.(*aot_arbace_classes_types.A_arbace_classes_types_method_desc_A).Invoke_O_O_O__O(root_423, arg_426, arg_427) }
//line :173:1
	var root_437 any = A_arbace_classes_env_A_const_62.GetRawRoot__O(); var linked_438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_437, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_439 lang.IFn; if linked_438 == nil { ifn_439 = lang.IFn_Cast(root_437) } else { ifn_439 = nil }; var arg_440 any = t.F_b__28000058; var arg_441 any; var tmp2 any = A_arbace_classes_env_A_const_42; var tmp3 any = jrt.NN(jrt.Method_Cast(m__2)).GetName__String().Ref(); var tmp4 any = A_arbace_classes_env_A_const_60; var tmp5 any = A_arbace_classes_env_A_const_43; var tmp6 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Method_Cast(m__2)).GetModifiers__I()).Ref(); var tmp7 any = A_arbace_classes_env_A_const_63; var tmp8 any = t.F_n; var tmp9 any = A_arbace_classes_env_A_const_81; var tmp10 any; var root_442 any = A_arbace_classes_env_A_const_47.GetRawRoot__O(); var linked_443 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_442, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_444 lang.IFn





	if linked_443 == nil { ifn_444 = lang.IFn_Cast(root_442) } else { ifn_444 = nil }; var arg_445 any = A_arbace_classes_env_A_const_35.GetRawRoot__O(); var arg_446 any = jrt.NN(jrt.Method_Cast(m__2)).GetExceptionTypes__Class1().Ref(); if linked_443 == nil { tmp10 = ifn_444.Invoke_O_O__O(arg_445, arg_446) } else { tmp10 = linked_443.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_442, arg_445, arg_446) }
//line :173:1
	var tmp11 any = tmp10; var tmp12 any = A_arbace_classes_env_A_const_82; var tmp13 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_New_O_O_O(m__2, desc__3, t.F_manns); var tmp14 *jrt.Class
	var fncls__456 /*line :173:1*/*jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_fn_class






	if fncls__456 == nil { var fncls__456d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_fn_class = fncls__456d; tmp14 = fncls__456d } else { tmp14 = fncls__456 }
//line :173:1
	var tmp15 any = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil)); var tmp16 any = A_arbace_classes_env_A_const_84; var tmp17 any; var root_457 any = A_arbace_classes_env_A_const_85.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_457, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_459 lang.IFn







	if linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; var arg_460 any; var tmp18 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_New_O_O_O(m__2, desc__3, t.F_manns); var tmp19 *jrt.Class; var fncls__472 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_fn_class
	if fncls__472 == nil { var fncls__472d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_fn_class = fncls__472d; tmp19 = fncls__472d } else { tmp19 = fncls__472 }; arg_460 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil)
//line :181:1
	var arg_461 any = jrt.NN(jrt.Method_Cast(m__2)).GetParameterTypes__Class1().Ref(); if linked_458 == nil { tmp17 = ifn_459.Invoke_O_O__O(arg_460, arg_461) } else { tmp17 = linked_458.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_457, arg_460, arg_461) }
//line :173:1
	arg_441 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, desc__3, tmp5, tmp6, tmp7, tmp8, tmp9, tmp11, tmp12, tmp15, tmp16, tmp17)); if linked_438 == nil { ifn_439.Invoke_O_O__O(arg_440, arg_441) } else { linked_438.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_437, arg_440, arg_441) }; i__28000057__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000057__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :180:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A) Ctor_O_O_O(c__m, c__desc, c__manns any) { t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :180:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A) Invoke_O__O(self any) any { var root_447 any = A_arbace_classes_env_A_const_83.GetRawRoot__O(); var linked_448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_447, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_449 lang.IFn; if linked_448 == nil { ifn_449 = lang.IFn_Cast(root_447) } else { ifn_449 = nil }; var arg_450 any; var root_452 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_452, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_454 lang.IFn; if linked_453 == nil { ifn_454 = lang.IFn_Cast(root_452) } else { ifn_454 = nil }; var arg_455 any; var t_ any = t.F_manns; t.F_manns = nil; arg_455 = t_; if linked_453 == nil { arg_450 = ifn_454.Invoke_O__O(arg_455) } else { arg_450 = linked_453.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_452, arg_455) }; var arg_451 any; var tmp1 any; var t__2 any = t.F_m; t.F_m = nil; tmp1 = t__2; var tmp2 any = jrt.NN(jrt.Method_Cast(tmp1)).GetName__String().Ref(); var tmp3 any; var t__3 any = t.F_desc; t.F_desc = nil; tmp3 = t__3; arg_451 = lang.Tuple_Create_O_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3), A_arbace_classes_env_A_const_82); if linked_448 == nil { return ifn_449.Invoke_O_O__O(arg_450, arg_451) } else { return linked_448.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_447, arg_450, arg_451) } }
//line :180:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :180:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A) Ctor_O_O_O(c__m, c__desc, c__manns any) { t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :180:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A) Invoke_O__O(self any) any { var root_524 any = A_arbace_classes_env_A_const_83.GetRawRoot__O(); var linked_525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_524, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_526 lang.IFn; if linked_525 == nil { ifn_526 = lang.IFn_Cast(root_524) } else { ifn_526 = nil }; var arg_527 any; var root_529 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_529, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_531 lang.IFn; if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any; var t_ any = t.F_manns; t.F_manns = nil; arg_532 = t_; if linked_530 == nil { arg_527 = ifn_531.Invoke_O__O(arg_532) } else { arg_527 = linked_530.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_529, arg_532) }; var arg_528 any; var tmp1 any; var t__2 any = t.F_m; t.F_m = nil; tmp1 = t__2; var tmp2 any = jrt.NN(jrt.Method_Cast(tmp1)).GetName__String().Ref(); var tmp3 any; var t__3 any = t.F_desc; t.F_desc = nil; tmp3 = t__3; arg_528 = lang.Tuple_Create_O_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3), A_arbace_classes_env_A_const_82); if linked_525 == nil { return ifn_526.Invoke_O_O__O(arg_527, arg_528) } else { return linked_525.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_524, arg_527, arg_528) } }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :182:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A) Ctor_O_O_O(c__m, c__desc, c__manns any) { t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :182:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A) Invoke_O_O_O__O(self, i__1, ___2 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_New_O_O_O_O(i__1, t.F_m, t.F_desc, t.F_manns); var tmp2 *jrt.Class; var fncls__471 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_fn_class; if fncls__471 == nil { var fncls__471d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_fn_class = fncls__471d; tmp2 = fncls__471d } else { tmp2 = fncls__471 }; return lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :182:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :182:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A) Ctor_O_O_O_O(c__i, c__m, c__desc, c__manns any) { t.F_i = c__i; t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :182:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A) Invoke_O__O(self any) any { var root_462 any = A_arbace_classes_env_A_const_83.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_462, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_464 lang.IFn; if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any; var root_467 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_467, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_469 lang.IFn; if linked_468 == nil { ifn_469 = lang.IFn_Cast(root_467) } else { ifn_469 = nil }; var arg_470 any; var t_ any = t.F_manns; t.F_manns = nil; arg_470 = t_; if linked_468 == nil { arg_465 = ifn_469.Invoke_O__O(arg_470) } else { arg_465 = linked_468.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_467, arg_470) }; var arg_466 any; var tmp1 any; var t__2 any = t.F_m; t.F_m = nil; tmp1 = t__2; var tmp2 any = jrt.NN(jrt.Method_Cast(tmp1)).GetName__String().Ref(); var tmp3 any; var t__3 any = t.F_desc; t.F_desc = nil; tmp3 = t__3; var tmp4 any = lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3); var tmp5 any = A_arbace_classes_env_A_const_84; var tmp6 any; var t__4 any = t.F_i; t.F_i = nil; tmp6 = t__4; arg_466 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp4, tmp5, tmp6); if linked_463 == nil { return ifn_464.Invoke_O_O__O(arg_465, arg_466) } else { return linked_463.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_462, arg_465, arg_466) } }
//line :182:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :182:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A) Ctor_O_O_O(c__m, c__desc, c__manns any) { t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :182:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A) Invoke_O_O_O__O(self, i__1, ___2 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_New_O_O_O_O(i__1, t.F_m, t.F_desc, t.F_manns); var tmp2 *jrt.Class; var fncls__548 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_fn_class; if fncls__548 == nil { var fncls__548d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_fn_class = fncls__548d; tmp2 = fncls__548d } else { tmp2 = fncls__548 }; return lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :182:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :182:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A) Ctor_O_O_O_O(c__i, c__m, c__desc, c__manns any) { t.F_i = c__i; t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :182:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A) Invoke_O__O(self any) any { var root_539 any = A_arbace_classes_env_A_const_83.GetRawRoot__O(); var linked_540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_539, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_541 lang.IFn; if linked_540 == nil { ifn_541 = lang.IFn_Cast(root_539) } else { ifn_541 = nil }; var arg_542 any; var root_544 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_544, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_546 lang.IFn; if linked_545 == nil { ifn_546 = lang.IFn_Cast(root_544) } else { ifn_546 = nil }; var arg_547 any; var t_ any = t.F_manns; t.F_manns = nil; arg_547 = t_; if linked_545 == nil { arg_542 = ifn_546.Invoke_O__O(arg_547) } else { arg_542 = linked_545.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_544, arg_547) }; var arg_543 any; var tmp1 any; var t__2 any = t.F_m; t.F_m = nil; tmp1 = t__2; var tmp2 any = jrt.NN(jrt.Method_Cast(tmp1)).GetName__String().Ref(); var tmp3 any; var t__3 any = t.F_desc; t.F_desc = nil; tmp3 = t__3; var tmp4 any = lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3); var tmp5 any = A_arbace_classes_env_A_const_84; var tmp6 any; var t__4 any = t.F_i; t.F_i = nil; tmp6 = t__4; arg_543 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp4, tmp5, tmp6); if linked_540 == nil { return ifn_541.Invoke_O_O__O(arg_542, arg_543) } else { return linked_540.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_539, arg_542, arg_543) } }

func A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_New_O_O(p0, p1 any) *A_arbace_classes_env_reflect_info_iter__28000077__28000081_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000077__28000081_A{}; t.Ctor_O_O(p0, p1); return t }
//line :184:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_A) Ctor_O_O(c__c, c__n any) { t.F_c = c__c; t.F_n = c__n }
//line :184:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_A) Invoke_O_O__O(self, s__28000078__1 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_New_O_O_O_O(t.F_c, t.F_n, s__28000078__1, self); var tmp2 *jrt.Class; var fncls__667 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_fn_class; if fncls__667 == nil { var fncls__667d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_fn_class = fncls__667d; tmp2 = fncls__667d } else { tmp2 = fncls__667 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :184:1
func A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :184:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A) Ctor_O_O_O_O(c__c, c__n, c__s__28000078, c__iter__28000077 any) { t.F_c = c__c; t.F_n = c__n; t.F_s__28000078 = c__s__28000078; t.F_iter__28000077 = c__iter__28000077 }
//line :184:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A) Invoke_O__O(self any) any { { var s__28000078__1 any; var t_ any = t.F_s__28000078; t.F_s__28000078 = nil; s__28000078__1 = t_; for { var temp__1927000414__auto____2 any; var root_556 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_556, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_558 lang.IFn; if linked_557 == nil { ifn_558 = lang.IFn_Cast(root_556) } else { ifn_558 = nil }; var arg_559 any = s__28000078__1; if linked_557 == nil { temp__1927000414__auto____2 = ifn_558.Invoke_O__O(arg_559) } else { temp__1927000414__auto____2 = linked_557.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_556, arg_559) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__28000078__3 any = temp__1927000414__auto____2; var tmp1 any; var root_560 any = A_arbace_classes_env_A_const_54.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_560, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_562 lang.IFn; if linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any = s__28000078__3; if linked_561 == nil { tmp1 = ifn_562.Invoke_O__O(arg_563) } else { tmp1 = linked_561.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_560, arg_563) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_564 any = A_arbace_classes_env_A_const_55.GetRawRoot__O(); var linked_565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_564, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_566 lang.IFn; if linked_565 == nil { ifn_566 = lang.IFn_Cast(root_564) } else { ifn_566 = nil }; var arg_567 any = s__28000078__3; if linked_565 == nil { c__1927001037__auto____4 = ifn_566.Invoke_O__O(arg_567) } else { c__1927001037__auto____4 = linked_565.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_564, arg_567) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__28000080__6 any; var root_568 any = A_arbace_classes_env_A_const_56.GetRawRoot__O(); var linked_569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_568, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_570 lang.IFn; if linked_569 == nil { ifn_570 = lang.IFn_Cast(root_568) } else { ifn_570 = nil }; var arg_571 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_569 == nil { b__28000080__6 = ifn_570.Invoke_O__O(arg_571) } else { b__28000080__6 = linked_569.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_568, arg_571) }; var tmp2 any = A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_New_O_O_O_I_O(t.F_c, t.F_n, b__28000080__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__604 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_fn_class; if fncls__604 == nil { var fncls__604d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_fn_class = fncls__604d; tmp3 = fncls__604d } else { tmp3 = fncls__604 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_605 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_605, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_607 lang.IFn; if linked_606 == nil { ifn_607 = lang.IFn_Cast(root_605) } else { ifn_607 = nil }; var arg_608 any; var root_610 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_612 lang.IFn; if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any = b__28000080__6; if linked_611 == nil { arg_608 = ifn_612.Invoke_O__O(arg_613) } else { arg_608 = linked_611.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_610, arg_613) }; var arg_609 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__28000077); var tmp5 any; var root_614 any = A_arbace_classes_env_A_const_70.GetRawRoot__O(); var linked_615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_614, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_616 lang.IFn; if linked_615 == nil { ifn_616 = lang.IFn_Cast(root_614) } else { ifn_616 = nil }; var arg_617 any = s__28000078__3; if linked_615 == nil { tmp5 = ifn_616.Invoke_O__O(arg_617) } else { tmp5 = linked_615.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_614, arg_617) }; arg_609 = tmp4.Invoke_O__O(tmp5); if linked_606 == nil { return ifn_607.Invoke_O_O__O(arg_608, arg_609) } else { return linked_606.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_605, arg_608, arg_609) } } else { var root_618 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_618, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_620 lang.IFn; if linked_619 == nil { ifn_620 = lang.IFn_Cast(root_618) } else { ifn_620 = nil }; var arg_621 any; var root_623 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_623, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_625 lang.IFn; if linked_624 == nil { ifn_625 = lang.IFn_Cast(root_623) } else { ifn_625 = nil }; var arg_626 any = b__28000080__6; if linked_624 == nil { arg_621 = ifn_625.Invoke_O__O(arg_626) } else { arg_621 = linked_624.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_623, arg_626) }; var arg_622 any; if linked_619 == nil { return ifn_620.Invoke_O_O__O(arg_621, arg_622) } else { return linked_619.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_618, arg_621, arg_622) } } } else { var m__4 any; var root_627 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_627, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_629 lang.IFn; if linked_628 == nil { ifn_629 = lang.IFn_Cast(root_627) } else { ifn_629 = nil }; var arg_630 any = s__28000078__3; if linked_628 == nil { m__4 = ifn_629.Invoke_O__O(arg_630) } else { m__4 = linked_628.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_627, arg_630) }; var root_631 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_631, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_633 lang.IFn; if linked_632 == nil { ifn_633 = lang.IFn_Cast(root_631) } else { ifn_633 = nil }; var arg_634 any; var tmp6 any = A_arbace_classes_env_A_const_42; var tmp7 any = A_arbace_classes_env_A_const_60; var tmp8 any; var root_636 any = A_arbace_classes_env_A_const_79.GetRawRoot__O(); var linked_637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_636, aot_arbace_classes_types.A_arbace_classes_types_method_desc_A_fn_class); var ifn_638 lang.IFn

	if linked_637 == nil { ifn_638 = lang.IFn_Cast(root_636) } else { ifn_638 = nil }; var arg_639 any; var root_641 any = A_arbace_classes_env_A_const_80.GetRawRoot__O(); var linked_642 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_641, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_643 lang.IFn; if linked_642 == nil { ifn_643 = lang.IFn_Cast(root_641) } else { ifn_643 = nil }; var arg_644 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var arg_645 any; var G__28000086__5_ any; var root_646 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_646, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_648 lang.IFn; if linked_647 == nil { ifn_648 = lang.IFn_Cast(root_646) } else { ifn_648 = nil }; var arg_649 any = jrt.NN(jrt.Constructor_Cast(m__4)).GetParameterTypes__Class1().Ref(); if linked_647 == nil { G__28000086__5_ = ifn_648.Invoke_O__O(arg_649) } else { G__28000086__5_ = linked_647.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_646, arg_649) }; var tmp9 any; var root_650 any = A_arbace_classes_env_A_const_76.GetRawRoot__O(); var linked_651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_650, A_arbace_classes_env_inner_member_QMARK__A_fn_class); var ifn_652 lang.IFn
	if linked_651 == nil { ifn_652 = lang.IFn_Cast(root_650) } else { ifn_652 = nil }; var arg_653 any = t.F_c; if linked_651 == nil { tmp9 = ifn_652.Invoke_O__O(arg_653) } else { tmp9 = linked_651.(*A_arbace_classes_env_inner_member_QMARK__A).Invoke_O_O__O(root_650, arg_653) }
//line :186:1
	if jrt.J2g_Truth(tmp9) { var root_654 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_654, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_656 lang.IFn; if linked_655 == nil { ifn_656 = lang.IFn_Cast(root_654) } else { ifn_656 = nil }; var arg_657 any = G__28000086__5_; if linked_655 == nil { arg_645 = ifn_656.Invoke_O__O(arg_657) } else { arg_645 = linked_655.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_654, arg_657) } } else { arg_645 = G__28000086__5_ }; if linked_642 == nil { arg_639 = ifn_643.Invoke_O_O__O(arg_644, arg_645) } else { arg_639 = linked_642.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_641, arg_644, arg_645) }; var arg_640 any = Lit_52; if linked_637 == nil { tmp8 = ifn_638.Invoke_O_O__O(arg_639, arg_640) } else { tmp8 = linked_637.(*aot_arbace_classes_types.A_arbace_classes_types_method_desc_A).Invoke_O_O_O__O(root_636, arg_639, arg_640) }
//line :184:1
	var tmp10 any = tmp8; var tmp11 any = A_arbace_classes_env_A_const_43; var tmp12 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Constructor_Cast(m__4)).GetModifiers__I()).Ref(); var tmp13 any = A_arbace_classes_env_A_const_63; var tmp14 any = t.F_n; var tmp15 any = A_arbace_classes_env_A_const_81; var tmp16 any; var root_658 any = A_arbace_classes_env_A_const_47.GetRawRoot__O(); var linked_659 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_658, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_660 lang.IFn





	if linked_659 == nil { ifn_660 = lang.IFn_Cast(root_658) } else { ifn_660 = nil }; var arg_661 any = A_arbace_classes_env_A_const_35.GetRawRoot__O(); var arg_662 any = jrt.NN(jrt.Constructor_Cast(m__4)).GetExceptionTypes__Class1().Ref(); if linked_659 == nil { tmp16 = ifn_660.Invoke_O_O__O(arg_661, arg_662) } else { tmp16 = linked_659.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_658, arg_661, arg_662) }
//line :184:1
	arg_634 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, Lit_13, tmp7, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16)); var arg_635 any; var tmp17 lang.IFn = lang.IFn_Cast(t.F_iter__28000077); var tmp18 any; var root_663 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_663, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_665 lang.IFn; if linked_664 == nil { ifn_665 = lang.IFn_Cast(root_663) } else { ifn_665 = nil }; var arg_666 any = s__28000078__3; if linked_664 == nil { tmp18 = ifn_665.Invoke_O__O(arg_666) } else { tmp18 = linked_664.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_663, arg_666) }; arg_635 = tmp17.Invoke_O__O(tmp18); if linked_632 == nil { return ifn_633.Invoke_O_O__O(arg_634, arg_635) } else { return linked_632.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_631, arg_634, arg_635) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :184:1
func A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :184:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A) Ctor_O_O_O_I_O(c__c, c__n, c__b__28000080 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_c = c__c; t.F_n = c__n; t.F_b__28000080 = c__b__28000080; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :184:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A) Invoke_O__O(self any) any { { var i__28000079__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__28000079__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__28000079__1)); var root_572 any = A_arbace_classes_env_A_const_62.GetRawRoot__O(); var linked_573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_572, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_574 lang.IFn; if linked_573 == nil { ifn_574 = lang.IFn_Cast(root_572) } else { ifn_574 = nil }; var arg_575 any = t.F_b__28000080; var arg_576 any; var tmp2 any = A_arbace_classes_env_A_const_42; var tmp3 any = A_arbace_classes_env_A_const_60; var tmp4 any; var root_577 any = A_arbace_classes_env_A_const_79.GetRawRoot__O(); var linked_578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_577, aot_arbace_classes_types.A_arbace_classes_types_method_desc_A_fn_class); var ifn_579 lang.IFn

	if linked_578 == nil { ifn_579 = lang.IFn_Cast(root_577) } else { ifn_579 = nil }; var arg_580 any; var root_582 any = A_arbace_classes_env_A_const_80.GetRawRoot__O(); var linked_583 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_582, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_584 lang.IFn; if linked_583 == nil { ifn_584 = lang.IFn_Cast(root_582) } else { ifn_584 = nil }; var arg_585 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var arg_586 any; var G__28000084__3_ any; var root_587 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_587, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_589 lang.IFn; if linked_588 == nil { ifn_589 = lang.IFn_Cast(root_587) } else { ifn_589 = nil }; var arg_590 any = jrt.NN(jrt.Constructor_Cast(m__2)).GetParameterTypes__Class1().Ref(); if linked_588 == nil { G__28000084__3_ = ifn_589.Invoke_O__O(arg_590) } else { G__28000084__3_ = linked_588.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_587, arg_590) }; var tmp5 any; var root_591 any = A_arbace_classes_env_A_const_76.GetRawRoot__O(); var linked_592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_591, A_arbace_classes_env_inner_member_QMARK__A_fn_class); var ifn_593 lang.IFn
	if linked_592 == nil { ifn_593 = lang.IFn_Cast(root_591) } else { ifn_593 = nil }; var arg_594 any = t.F_c; if linked_592 == nil { tmp5 = ifn_593.Invoke_O__O(arg_594) } else { tmp5 = linked_592.(*A_arbace_classes_env_inner_member_QMARK__A).Invoke_O_O__O(root_591, arg_594) }
//line :186:1
	if jrt.J2g_Truth(tmp5) { var root_595 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_595, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_597 lang.IFn; if linked_596 == nil { ifn_597 = lang.IFn_Cast(root_595) } else { ifn_597 = nil }; var arg_598 any = G__28000084__3_; if linked_596 == nil { arg_586 = ifn_597.Invoke_O__O(arg_598) } else { arg_586 = linked_596.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_595, arg_598) } } else { arg_586 = G__28000084__3_ }; if linked_583 == nil { arg_580 = ifn_584.Invoke_O_O__O(arg_585, arg_586) } else { arg_580 = linked_583.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_582, arg_585, arg_586) }; var arg_581 any = Lit_52; if linked_578 == nil { tmp4 = ifn_579.Invoke_O_O__O(arg_580, arg_581) } else { tmp4 = linked_578.(*aot_arbace_classes_types.A_arbace_classes_types_method_desc_A).Invoke_O_O_O__O(root_577, arg_580, arg_581) }
//line :184:1
	var tmp6 any = tmp4; var tmp7 any = A_arbace_classes_env_A_const_43; var tmp8 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Constructor_Cast(m__2)).GetModifiers__I()).Ref(); var tmp9 any = A_arbace_classes_env_A_const_63; var tmp10 any = t.F_n; var tmp11 any = A_arbace_classes_env_A_const_81; var tmp12 any; var root_599 any = A_arbace_classes_env_A_const_47.GetRawRoot__O(); var linked_600 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_599, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_601 lang.IFn





	if linked_600 == nil { ifn_601 = lang.IFn_Cast(root_599) } else { ifn_601 = nil }; var arg_602 any = A_arbace_classes_env_A_const_35.GetRawRoot__O(); var arg_603 any = jrt.NN(jrt.Constructor_Cast(m__2)).GetExceptionTypes__Class1().Ref(); if linked_600 == nil { tmp12 = ifn_601.Invoke_O_O__O(arg_602, arg_603) } else { tmp12 = linked_600.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_599, arg_602, arg_603) }
//line :184:1
	arg_576 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, Lit_13, tmp3, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12)); if linked_573 == nil { ifn_574.Invoke_O_O__O(arg_575, arg_576) } else { linked_573.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_572, arg_575, arg_576) }; i__28000079__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000079__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }










func A_arbace_classes_env_reflect_info_fn__28000089_A_New() *A_arbace_classes_env_reflect_info_fn__28000089_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_fn__28000089_A{}; t.Ctor(); return t }
//line :195:1
func (t *A_arbace_classes_env_reflect_info_fn__28000089_A) Ctor() {}
//line :195:1
func (t *A_arbace_classes_env_reflect_info_fn__28000089_A) Invoke_O_O__O(self, p1__28000026_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_13, A_arbace_classes_env_A_const_42.Invoke_O__O(p1__28000026_SHARP___1))).Ref() }
func A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_New_O(p0 any) *A_arbace_classes_env_reflect_info_iter__28000091__28000095_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000091__28000095_A{}; t.Ctor_O(p0); return t }
//line :196:1
func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :196:1
func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_A) Invoke_O_O__O(self, s__28000092__1 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_New_O_O_O(t.F_n, s__28000092__1, self); var tmp2 *jrt.Class; var fncls__747 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_fn_class; if fncls__747 == nil { var fncls__747d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_fn_class = fncls__747d; tmp2 = fncls__747d } else { tmp2 = fncls__747 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :196:1
func A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :196:1
func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A) Ctor_O_O_O(c__n, c__s__28000092, c__iter__28000091 any) { t.F_n = c__n; t.F_s__28000092 = c__s__28000092; t.F_iter__28000091 = c__iter__28000091 }
//line :196:1
func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A) Invoke_O__O(self any) any { { var s__28000092__1 any; var t_ any = t.F_s__28000092; t.F_s__28000092 = nil; s__28000092__1 = t_; for { var temp__1927000414__auto____2 any; var root_690 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_690, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_692 lang.IFn; if linked_691 == nil { ifn_692 = lang.IFn_Cast(root_690) } else { ifn_692 = nil }; var arg_693 any = s__28000092__1; if linked_691 == nil { temp__1927000414__auto____2 = ifn_692.Invoke_O__O(arg_693) } else { temp__1927000414__auto____2 = linked_691.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_690, arg_693) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__28000092__3 any = temp__1927000414__auto____2; var tmp1 any; var root_694 any = A_arbace_classes_env_A_const_54.GetRawRoot__O(); var linked_695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_694, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_696 lang.IFn; if linked_695 == nil { ifn_696 = lang.IFn_Cast(root_694) } else { ifn_696 = nil }; var arg_697 any = s__28000092__3; if linked_695 == nil { tmp1 = ifn_696.Invoke_O__O(arg_697) } else { tmp1 = linked_695.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_694, arg_697) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_698 any = A_arbace_classes_env_A_const_55.GetRawRoot__O(); var linked_699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_698, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_700 lang.IFn; if linked_699 == nil { ifn_700 = lang.IFn_Cast(root_698) } else { ifn_700 = nil }; var arg_701 any = s__28000092__3; if linked_699 == nil { c__1927001037__auto____4 = ifn_700.Invoke_O__O(arg_701) } else { c__1927001037__auto____4 = linked_699.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_698, arg_701) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__28000094__6 any; var root_702 any = A_arbace_classes_env_A_const_56.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_702, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_704 lang.IFn; if linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_703 == nil { b__28000094__6 = ifn_704.Invoke_O__O(arg_705) } else { b__28000094__6 = linked_703.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_702, arg_705) }; var tmp2 any = A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_New_O_I_O_O(t.F_n, size__1927001038__auto____5, b__28000094__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__711 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_fn_class; if fncls__711 == nil { var fncls__711d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_fn_class = fncls__711d; tmp3 = fncls__711d } else { tmp3 = fncls__711 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_712 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_712, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_714 lang.IFn; if linked_713 == nil { ifn_714 = lang.IFn_Cast(root_712) } else { ifn_714 = nil }; var arg_715 any; var root_717 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_717, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_719 lang.IFn; if linked_718 == nil { ifn_719 = lang.IFn_Cast(root_717) } else { ifn_719 = nil }; var arg_720 any = b__28000094__6; if linked_718 == nil { arg_715 = ifn_719.Invoke_O__O(arg_720) } else { arg_715 = linked_718.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_717, arg_720) }; var arg_716 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__28000091); var tmp5 any; var root_721 any = A_arbace_classes_env_A_const_70.GetRawRoot__O(); var linked_722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_721, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_723 lang.IFn; if linked_722 == nil { ifn_723 = lang.IFn_Cast(root_721) } else { ifn_723 = nil }; var arg_724 any = s__28000092__3; if linked_722 == nil { tmp5 = ifn_723.Invoke_O__O(arg_724) } else { tmp5 = linked_722.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_721, arg_724) }; arg_716 = tmp4.Invoke_O__O(tmp5); if linked_713 == nil { return ifn_714.Invoke_O_O__O(arg_715, arg_716) } else { return linked_713.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_712, arg_715, arg_716) } } else { var root_725 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_725, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_727 lang.IFn; if linked_726 == nil { ifn_727 = lang.IFn_Cast(root_725) } else { ifn_727 = nil }; var arg_728 any; var root_730 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_730, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_732 lang.IFn; if linked_731 == nil { ifn_732 = lang.IFn_Cast(root_730) } else { ifn_732 = nil }; var arg_733 any = b__28000094__6; if linked_731 == nil { arg_728 = ifn_732.Invoke_O__O(arg_733) } else { arg_728 = linked_731.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_730, arg_733) }; var arg_729 any; if linked_726 == nil { return ifn_727.Invoke_O_O__O(arg_728, arg_729) } else { return linked_726.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_725, arg_728, arg_729) } } } else { var vec__28000102__4 any; var root_734 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_734, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_736 lang.IFn; if linked_735 == nil { ifn_736 = lang.IFn_Cast(root_734) } else { ifn_736 = nil }; var arg_737 any = s__28000092__3; if linked_735 == nil { vec__28000102__4 = ifn_736.Invoke_O__O(arg_737) } else { vec__28000102__4 = linked_735.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_734, arg_737) }; var d__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__28000102__4, lang.RT_IntCast_J__I_NoInit(0), nil); var f__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__28000102__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_738 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_738, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_740 lang.IFn; if linked_739 == nil { ifn_740 = lang.IFn_Cast(root_738) } else { ifn_740 = nil }; var arg_741 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_env_A_const_42, Lit_13, A_arbace_classes_env_A_const_60, d__5, A_arbace_classes_env_A_const_43, f__6, A_arbace_classes_env_A_const_63, t.F_n, A_arbace_classes_env_A_const_81, lang.PersistentVector_EMPTY.Ref())); var arg_742 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__28000091); var tmp7 any; var root_743 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_743, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_745 lang.IFn; if linked_744 == nil { ifn_745 = lang.IFn_Cast(root_743) } else { ifn_745 = nil }; var arg_746 any = s__28000092__3; if linked_744 == nil { tmp7 = ifn_745.Invoke_O__O(arg_746) } else { tmp7 = linked_744.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_743, arg_746) }; arg_742 = tmp6.Invoke_O__O(tmp7); if linked_739 == nil { return ifn_740.Invoke_O_O__O(arg_741, arg_742) } else { return linked_739.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_738, arg_741, arg_742) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :196:1
func A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :196:1
func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A) Ctor_O_I_O_O(c__n any, c__size__1927001038__auto__ int32, c__b__28000094, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__28000094 = c__b__28000094; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :196:1
func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A) Invoke_O__O(self any) any { { var i__28000093__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__28000093__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__28000098__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__28000093__1)); var d__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__28000098__2, lang.RT_IntCast_J__I_NoInit(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__28000098__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_706 any = A_arbace_classes_env_A_const_62.GetRawRoot__O(); var linked_707 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_706, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_708 lang.IFn; if linked_707 == nil { ifn_708 = lang.IFn_Cast(root_706) } else { ifn_708 = nil }; var arg_709 any = t.F_b__28000094; var arg_710 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_env_A_const_42, Lit_13, A_arbace_classes_env_A_const_60, d__3, A_arbace_classes_env_A_const_43, f__4, A_arbace_classes_env_A_const_63, t.F_n, A_arbace_classes_env_A_const_81, lang.PersistentVector_EMPTY.Ref())); if linked_707 == nil { ifn_708.Invoke_O_O__O(arg_709, arg_710) } else { linked_707.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_706, arg_709, arg_710) }; i__28000093__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000093__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_classes_env_info_A_New() *A_arbace_classes_env_info_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_info_A{}; t.Ctor(); return t }
//line :205:1
func (t *A_arbace_classes_env_info_A) Ctor() {}
//line :205:1
func (t *A_arbace_classes_env_info_A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any = n__0; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_753 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_754 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_753, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_755 lang.IFn; if linked_754 == nil { ifn_755 = lang.IFn_Cast(root_753) } else { ifn_755 = nil }; var arg_756 any; var root_757 any = A_arbace_classes_env_A_const_20.GetRawRoot__O(); var linked_758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_757, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_759 lang.IFn; if linked_758 == nil { ifn_759 = lang.IFn_Cast(root_757) } else { ifn_759 = nil }; var arg_760 any = n__0; var arg_761 any = Lit_11; if linked_758 == nil { arg_756 = ifn_759.Invoke_O_O__O(arg_760, arg_761) } else { arg_756 = linked_758.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_757, arg_760, arg_761) }; if linked_754 == nil { tmp1 = ifn_755.Invoke_O__O(arg_756) } else { tmp1 = linked_754.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_753, arg_756) } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var or__1927000174__auto____2 any; var G__28000108__2_ any = A_arbace_classes_env_A_const_90.Get__O(); var G__28000108__3_ any
		if lang.Util_Identical_O_O__Z_NoInit(G__28000108__2_, nil) { G__28000108__3_ = nil } else { var root_762 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_762, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_764 lang.IFn; if linked_763 == nil { ifn_764 = lang.IFn_Cast(root_762) } else { ifn_764 = nil }; var arg_765 any = G__28000108__2_; if linked_763 == nil { G__28000108__3_ = ifn_764.Invoke_O__O(arg_765) } else { G__28000108__3_ = linked_763.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_762, arg_765) } }; if lang.Util_Identical_O_O__Z_NoInit(G__28000108__3_, nil) { or__1927000174__auto____2 = nil } else { or__1927000174__auto____2 = lang.RT_Get_O_O__O_NoInit(G__28000108__3_, n__0) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else {
			if jrt.J2g_Truth(A_arbace_classes_env_A_const_19.Get__O()) {
				var tmp2 any; var root_766 any = A_arbace_classes_env_A_const_18.GetRawRoot__O(); var linked_767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_766, A_arbace_classes_env_from_source_QMARK__A_fn_class); var ifn_768 lang.IFn; if linked_767 == nil { ifn_768 = lang.IFn_Cast(root_766) } else { ifn_768 = nil }; var arg_769 any = n__0; if linked_767 == nil { tmp2 = ifn_768.Invoke_O__O(arg_769) } else { tmp2 = linked_767.(*A_arbace_classes_env_from_source_QMARK__A).Invoke_O_O__O(root_766, arg_769) }; if jrt.J2g_Truth(tmp2) { return nil } else { var tmp3 *lang.Keyword = A_arbace_classes_env_A_const_91; return tmp3.Invoke_O__O(lang.RT_Get_O_O__O_NoInit(A_arbace_classes_env_A_const_19.Get__O(), n__0)) } } else {
//line :210:1
					var temp__1927000414__auto____3 any; var root_770 any = A_arbace_classes_env_A_const_26.GetRawRoot__O(); var linked_771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_770, A_arbace_classes_env_load_class_A_fn_class); var ifn_772 lang.IFn

					if linked_771 == nil { ifn_772 = lang.IFn_Cast(root_770) } else { ifn_772 = nil }; var arg_773 any = n__0; if linked_771 == nil { temp__1927000414__auto____3 = ifn_772.Invoke_O__O(arg_773) } else { temp__1927000414__auto____3 = linked_771.(*A_arbace_classes_env_load_class_A).Invoke_O_O__O(root_770, arg_773) }; if jrt.J2g_Truth(temp__1927000414__auto____3) { var c__4 any = temp__1927000414__auto____3; var d__5 any; var tmp4 any; var root_774 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_774, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_776 lang.IFn
						if linked_775 == nil { ifn_776 = lang.IFn_Cast(root_774) } else { ifn_776 = nil }; var arg_777 any = A_arbace_classes_env_A_const_92.GetRawRoot__O(); if linked_775 == nil { tmp4 = ifn_776.Invoke_O__O(arg_777) } else { tmp4 = linked_775.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_774, arg_777) }; d__5 = lang.RT_Get_O_O__O_NoInit(tmp4, n__0)
						var tmp5 any; var and__1927000168__auto____6 any = d__5; if jrt.J2g_Truth(and__1927000168__auto____6) { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(A_arbace_classes_env_A_const_32.Invoke_O__O(d__5), c__4)).Ref() } else { tmp5 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp5) { return d__5 } else { var root_778 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_778, A_arbace_classes_env_reflect_info_A_fn_class); var ifn_780 lang.IFn; if linked_779 == nil { ifn_780 = lang.IFn_Cast(root_778) } else { ifn_780 = nil }; var arg_781 any = c__4; if linked_779 == nil { return ifn_780.Invoke_O__O(arg_781) } else { return linked_779.(*A_arbace_classes_env_reflect_info_A).Invoke_O_O__O(root_778, arg_781) } } } else {
//line :212:1
							return nil } } } } else {
//line :208:1
								return nil
							}
}





func A_arbace_classes_env_info_BANG__A_New() *A_arbace_classes_env_info_BANG__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_info_BANG__A{}; t.Ctor(); return t }
//line :216:1
func (t *A_arbace_classes_env_info_BANG__A) Ctor() {}
//line :216:1
func (t *A_arbace_classes_env_info_BANG__A) Invoke_O_O__O(self, n__0 any) any { var or__1927000174__auto____2 any; var root_782 any = A_arbace_classes_env_A_const_94.GetRawRoot__O(); var linked_783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_782, A_arbace_classes_env_info_A_fn_class); var ifn_784 lang.IFn; if
										linked_783 == nil { ifn_784 = lang.IFn_Cast(root_782) } else { ifn_784 = nil }; var arg_785 any = n__0; if linked_783 == nil { or__1927000174__auto____2 = ifn_784.Invoke_O__O(arg_785) } else { or__1927000174__auto____2 = linked_783.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_782, arg_785) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var tmp1 any; var root_786 any = A_arbace_classes_env_A_const_29.GetRawRoot__O(); var linked_787 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_786, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_788 lang.IFn; if linked_787 == nil { ifn_788 = lang.IFn_Cast(root_786) } else { ifn_788 = nil }; var arg_789 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_20, nil); var tmp3 any; var root_791 any = A_arbace_classes_env_A_const_12.GetRawRoot__O(); var linked_792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_791, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_793 lang.IFn; if linked_792 == nil { ifn_793 = lang.IFn_Cast(root_791) } else { ifn_793 = nil }; var arg_794 any; var root_797 any = A_arbace_classes_env_A_const_31.GetRawRoot__O(); var linked_798 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_797, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_799 lang.IFn; if linked_798 == nil { ifn_799 = lang.IFn_Cast(root_797) } else { ifn_799 = nil }; var arg_800 any = n__0; if linked_798 == nil { arg_794 = ifn_799.Invoke_O__O(arg_800) } else { arg_794 = linked_798.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_797, arg_800) }; var arg_795 any = Lit_21; var arg_796 any = Lit_22; if linked_792 == nil { tmp3 = ifn_793.Invoke_O_O_O__O(arg_794, arg_795, arg_796) } else { tmp3 = linked_792.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_791, arg_794, arg_795, arg_796) }; arg_789 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref(); var arg_790 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_env_A_const_32, n__0)); if linked_787 == nil { tmp1 = ifn_788.Invoke_O_O__O(arg_789, arg_790) } else { tmp1 = linked_787.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_786, arg_789, arg_790) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) } }

func A_arbace_classes_env_interface_QMARK__A_New() *A_arbace_classes_env_interface_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_interface_QMARK__A{}; t.Ctor(); return t }
//line :219:1
func (t *A_arbace_classes_env_interface_QMARK__A) Ctor() {}
//line :219:1
func (t *A_arbace_classes_env_interface_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var i__2 any; var root_801 any = A_arbace_classes_env_A_const_94.GetRawRoot__O(); var linked_802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_801, A_arbace_classes_env_info_A_fn_class); var ifn_803 lang.IFn; if
											linked_802 == nil { ifn_803 = lang.IFn_Cast(root_801) } else { ifn_803 = nil }; var arg_804 any = n__0; if linked_802 == nil { i__2 = ifn_803.Invoke_O__O(arg_804) } else { i__2 = linked_802.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_801, arg_804) }; var tmp1 any; var or__1927000174__auto____3 any = A_arbace_classes_env_A_const_44.Invoke_O__O(i__2); if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var G__28000111__4_ any = A_arbace_classes_env_A_const_43.Invoke_O__O(i__2); var G__28000111__5_ any; if lang.Util_Identical_O_O__Z_NoInit(G__28000111__4_, nil) { G__28000111__5_ = nil } else { var tmp2 int64; var na_805 any = G__28000111__4_; var na_806 int64 = 512; if jrt.Long_InstanceOf(na_805) { var n0_807 int64 = jrt.NN(jrt.Long_Cast(na_805)).LongValue__J(); var n1_808 int64 = na_806; tmp2 = n0_807 & n1_808 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_805, na_806) }; G__28000111__5_ = jrt.Long_ValueOf_J__Long_NoInit(tmp2).Ref() }; if lang.Util_Identical_O_O__Z_NoInit(G__28000111__5_, nil) { tmp1 = nil } else { var tmp3 bool; var na_810 any = G__28000111__5_; if jrt.Long_InstanceOf(na_810) { var n0_811 int64 = jrt.NN(jrt.Long_Cast(na_810)).LongValue__J(); tmp3 = n0_811 > 0 } else { if jrt.Double_InstanceOf(na_810) { var n0_811_2 float64 = jrt.NN(jrt.Double_Cast(na_810)).DoubleValue__D(); tmp3 = n0_811_2 > 0.0 } else { tmp3 = lang.Numbers_IsPos_O__Z_NoInit(na_810) } }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp3).Ref() } }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() }

func A_arbace_classes_env_const_value_A_New() *A_arbace_classes_env_const_value_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_const_value_A{}; t.Ctor(); return t }
//line :222:1
func (t *A_arbace_classes_env_const_value_A) Ctor() {}
//line :222:1
func (t *A_arbace_classes_env_const_value_A) Invoke_O_O__O(self, field__0 any) any { var c__2 any = A_arbace_classes_env_A_const_64.Invoke_O__O(field__0); var tmp1 any; var root_812 any = A_arbace_classes_env_A_const_95.GetRawRoot__O(); var linked_813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_812, aot_arbace_core.A_arbace_core_delay_QMARK__A_fn_class); var ifn_814 lang.IFn; if
											linked_813 == nil { ifn_814 = lang.IFn_Cast(root_812) } else { ifn_814 = nil }; var arg_815 any = c__2; if linked_813 == nil { tmp1 = ifn_814.Invoke_O__O(arg_815) } else { tmp1 = linked_813.(*aot_arbace_core.A_arbace_core_delay_QMARK__A).Invoke_O_O__O(root_812, arg_815) }; if jrt.J2g_Truth(tmp1) { var root_816 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_816, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_818 lang.IFn; if linked_817 == nil { ifn_818 = lang.IFn_Cast(root_816) } else { ifn_818 = nil }; var arg_819 any = c__2; if linked_817 == nil { return ifn_818.Invoke_O__O(arg_819) } else { return linked_817.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_816, arg_819) } } else { return c__2 } }

func A_arbace_classes_env_supertypes_A_New() *A_arbace_classes_env_supertypes_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_supertypes_A{}; t.Ctor(); return t }
//line :225:1
func (t *A_arbace_classes_env_supertypes_A) Ctor() {}
//line :225:1
func (t *A_arbace_classes_env_supertypes_A) Invoke_O_O__O(self, n__0 any) any { var i__2 any; var root_820 any = A_arbace_classes_env_A_const_96.GetRawRoot__O(); var linked_821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_820, A_arbace_classes_env_info_BANG__A_fn_class); var ifn_822 lang.IFn; if


	linked_821 == nil { ifn_822 = lang.IFn_Cast(root_820) } else { ifn_822 = nil }; var arg_823 any = n__0; if linked_821 == nil { i__2 = ifn_822.Invoke_O__O(arg_823) } else { i__2 = linked_821.(*A_arbace_classes_env_info_BANG__A).Invoke_O_O__O(root_820, arg_823) }; var G__28000114__3_ any; var root_824 any = /*line :225:1*/A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_825 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_824, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_826 lang.IFn; if


	linked_825 == nil { ifn_826 = lang.IFn_Cast(root_824) } else { ifn_826 = nil }; var arg_827 any = A_arbace_classes_env_A_const_46.Invoke_O__O(i__2); if linked_825 == nil { G__28000114__3_ = ifn_826.Invoke_O__O(arg_827) } else { G__28000114__3_ = linked_825.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_824, arg_827) }; if jrt.J2g_Truth(A_arbace_classes_env_A_const_45.Invoke_O__O(i__2)) { var root_828 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_828, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_830 lang.IFn; if linked_829 == nil { ifn_830 = lang.IFn_Cast(root_828) } else { ifn_830 = nil }; var arg_831 any; var root_832 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_832, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_834 lang.IFn; if linked_833 == nil { ifn_834 = lang.IFn_Cast(root_832) } else { ifn_834 = nil }; var arg_835 any = A_arbace_classes_env_A_const_45.Invoke_O__O(i__2); var arg_836 any = G__28000114__3_; if linked_833 == nil { arg_831 = ifn_834.Invoke_O_O__O(arg_835, arg_836) } else { arg_831 = linked_833.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_832, arg_835, arg_836) }; if linked_829 == nil { return ifn_830.Invoke_O__O(arg_831) } else { return linked_829.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_828, arg_831) } } else { return G__28000114__3_ } }

func A_arbace_classes_env_subclass_QMARK__A_New() *A_arbace_classes_env_subclass_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_subclass_QMARK__A{}; t.Ctor(); return t }
//line :230:1
func (t *A_arbace_classes_env_subclass_QMARK__A) Ctor() {}
//line :230:1
func (t *A_arbace_classes_env_subclass_QMARK__A) Invoke_O_O_O__O(self, a__0, b__1 any) any { var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(a__0, b__1); if or__1927000174__auto____3 {


	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var or__1927000174__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(b__1, Lit_4); if or__1927000174__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____4).Ref() } else {
		var tmp1 any; var root_837 any = A_arbace_classes_env_A_const_97.GetRawRoot__O(); var linked_838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_837, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_839 lang.IFn; if linked_838 == nil { ifn_839 = lang.IFn_Cast(root_837) } else { ifn_839 = nil }; var arg_840 any; var tmp2 any = A_arbace_classes_env_subclass_QMARK__fn__28000117_A_New_O(b__1); var tmp3 *jrt.Class; var fncls__847 *jrt.Class = A_arbace_classes_env_subclass_QMARK__fn__28000117_A_fn_class; if fncls__847 == nil { var fncls__847d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); A_arbace_classes_env_subclass_QMARK__fn__28000117_A_fn_class = fncls__847d; tmp3 = fncls__847d } else { tmp3 = fncls__847 }; arg_840 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_841 any; var temp__1927000414__auto____5 any; var root_848 any = A_arbace_classes_env_A_const_94.GetRawRoot__O(); var linked_849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_848, A_arbace_classes_env_info_A_fn_class); var ifn_850 lang.IFn; if linked_849 == nil { ifn_850 = lang.IFn_Cast(root_848) } else { ifn_850 = nil }; var arg_851 any = a__0; if linked_849 == nil { temp__1927000414__auto____5 = ifn_850.Invoke_O__O(arg_851) } else { temp__1927000414__auto____5 = linked_849.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_848, arg_851) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var i__6 any = temp__1927000414__auto____5; var G__28000119__7_ any; var root_852 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_852, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_854 lang.IFn
			if linked_853 == nil { ifn_854 = lang.IFn_Cast(root_852) } else { ifn_854 = nil }; var arg_855 any = A_arbace_classes_env_A_const_46.Invoke_O__O(i__6); if linked_853 == nil { G__28000119__7_ = ifn_854.Invoke_O__O(arg_855) } else { G__28000119__7_ = linked_853.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_852, arg_855) }; if jrt.J2g_Truth(A_arbace_classes_env_A_const_45.Invoke_O__O(i__6)) { var root_856 any = A_arbace_classes_env_A_const_10.GetRawRoot__O(); var linked_857 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_856, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_858 lang.IFn; if linked_857 == nil { ifn_858 = lang.IFn_Cast(root_856) } else { ifn_858 = nil }; var arg_859 any = G__28000119__7_; var arg_860 any = A_arbace_classes_env_A_const_45.Invoke_O__O(i__6); if linked_857 == nil { arg_841 = ifn_858.Invoke_O_O__O(arg_859, arg_860) } else { arg_841 = linked_857.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_856, arg_859, arg_860) } } else { arg_841 = G__28000119__7_ } } else {
//line :234:1
				arg_841 = nil }; if linked_838 == nil { tmp1 = ifn_839.Invoke_O_O__O(arg_840, arg_841) } else { tmp1 = linked_838.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_837, arg_840, arg_841) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() } } }
//line :234:1
func A_arbace_classes_env_subclass_QMARK__fn__28000117_A_New_O(p0 any) *A_arbace_classes_env_subclass_QMARK__fn__28000117_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_subclass_QMARK__fn__28000117_A{}; t.Ctor_O(p0); return t }
//line :234:1
func (t *A_arbace_classes_env_subclass_QMARK__fn__28000117_A) Ctor_O(c__b any) { t.F_b = c__b }
//line :234:1
func (t *A_arbace_classes_env_subclass_QMARK__fn__28000117_A) Invoke_O_O__O(self, p1__28000116_SHARP___1 any) any { var root_842 any = A_arbace_classes_env_A_const_98.GetRawRoot__O(); var linked_843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_842, A_arbace_classes_env_subclass_QMARK__A_fn_class); var ifn_844 lang.IFn; if linked_843 == nil { ifn_844 = lang.IFn_Cast(root_842) } else { ifn_844 = nil }; var arg_845 any = p1__28000116_SHARP___1; var arg_846 any = t.F_b; if linked_843 == nil { return ifn_844.Invoke_O_O__O(arg_845, arg_846) } else { return linked_843.(*A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(root_842, arg_845, arg_846) } }


func A_arbace_classes_env_assignable_QMARK__A_New() *A_arbace_classes_env_assignable_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_assignable_QMARK__A{}; t.Ctor(); return t }
//line :237:1
func (t *A_arbace_classes_env_assignable_QMARK__A) Ctor() {}
//line :237:1
func (t *A_arbace_classes_env_assignable_QMARK__A) Invoke_O_O_O__O(self, from__0, to__1 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(from__0, to__1) { return jrt.Boolean_TRUE.Ref() } else { if lang.Util_Equiv_O_O__Z_NoInit(from__0, A_arbace_classes_env_A_const_99) {

		var root_861 any = A_arbace_classes_env_A_const_100.GetRawRoot__O(); var linked_862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_861, aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A_fn_class); var ifn_863 lang.IFn; if linked_862 == nil { ifn_863 = lang.IFn_Cast(root_861) } else { ifn_863 = nil }; var arg_864 any = to__1; if linked_862 == nil { return ifn_863.Invoke_O__O(arg_864) } else { return linked_862.(*aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A).Invoke_O_O__O(root_861, arg_864) } } else {
//line :240:1
			var tmp1 any; var root_865 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_865, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_867 lang.IFn


			if linked_866 == nil { ifn_867 = lang.IFn_Cast(root_865) } else { ifn_867 = nil }; var arg_868 any; var and__1927000168__auto____3 any; var root_869 any = A_arbace_classes_env_A_const_100.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_869, aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A_fn_class); var ifn_871 lang.IFn; if linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any = from__0; if linked_870 == nil { and__1927000168__auto____3 = ifn_871.Invoke_O__O(arg_872) } else { and__1927000168__auto____3 = linked_870.(*aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A).Invoke_O_O__O(root_869, arg_872) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_873 any = A_arbace_classes_env_A_const_100.GetRawRoot__O(); var linked_874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_873, aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A_fn_class); var ifn_875 lang.IFn; if linked_874 == nil { ifn_875 = lang.IFn_Cast(root_873) } else { ifn_875 = nil }; var arg_876 any = to__1; if linked_874 == nil { arg_868 = ifn_875.Invoke_O__O(arg_876) } else { arg_868 = linked_874.(*aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A).Invoke_O_O__O(root_873, arg_876) } } else { arg_868 = and__1927000168__auto____3 }; if linked_866 == nil { tmp1 = ifn_867.Invoke_O__O(arg_868) } else { tmp1 = linked_866.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_865, arg_868) }
//line :240:1
			if jrt.J2g_Truth(tmp1) { return jrt.Boolean_FALSE.Ref() } else { if lang.Util_Equiv_O_O__Z_NoInit(to__1, A_arbace_classes_env_A_const_101.GetRawRoot__O()) { return jrt.Boolean_TRUE.Ref() } else { var tmp2 any; var root_877 any = A_arbace_classes_env_A_const_102.GetRawRoot__O(); var linked_878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_877, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_879 lang.IFn




				if linked_878 == nil { ifn_879 = lang.IFn_Cast(root_877) } else { ifn_879 = nil }; var arg_880 any = from__0; if linked_878 == nil { tmp2 = ifn_879.Invoke_O__O(arg_880) } else { tmp2 = linked_878.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_877, arg_880) }
//line :240:1
				if jrt.J2g_Truth(tmp2) {





					var tmp3 any; var root_881 any = A_arbace_classes_env_A_const_102.GetRawRoot__O(); var linked_882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_881, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_883 lang.IFn; if linked_882 == nil { ifn_883 = lang.IFn_Cast(root_881) } else { ifn_883 = nil }; var arg_884 any = to__1; if linked_882 == nil { tmp3 = ifn_883.Invoke_O__O(arg_884) } else { tmp3 = linked_882.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_881, arg_884) }; if jrt.J2g_Truth(tmp3) { var fe__3 any; var root_885 any = A_arbace_classes_env_A_const_103.GetRawRoot__O(); var linked_886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_885, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_887 lang.IFn; if linked_886 == nil { ifn_887 = lang.IFn_Cast(root_885) } else { ifn_887 = nil }; var arg_888 any = from__0; if linked_886 == nil { fe__3 = ifn_887.Invoke_O__O(arg_888) } else { fe__3 = linked_886.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_885, arg_888) }; var te__4 any; var root_889 any = A_arbace_classes_env_A_const_103.GetRawRoot__O(); var linked_890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_889, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_891 lang.IFn; if linked_890 == nil { ifn_891 = lang.IFn_Cast(root_889) } else { ifn_891 = nil }; var arg_892 any = to__1; if linked_890 == nil { te__4 = ifn_891.Invoke_O__O(arg_892) } else { te__4 = linked_890.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_889, arg_892) }; var and__1927000168__auto____5 any; var root_893 any = A_arbace_classes_env_A_const_100.GetRawRoot__O(); var linked_894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_893, aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A_fn_class); var ifn_895 lang.IFn
						if linked_894 == nil { ifn_895 = lang.IFn_Cast(root_893) } else { ifn_895 = nil }; var arg_896 any = fe__3; if linked_894 == nil { and__1927000168__auto____5 = ifn_895.Invoke_O__O(arg_896) } else { and__1927000168__auto____5 = linked_894.(*aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A).Invoke_O_O__O(root_893, arg_896) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_897 any = A_arbace_classes_env_A_const_100.GetRawRoot__O(); var linked_898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_897, aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A_fn_class); var ifn_899 lang.IFn; if linked_898 == nil { ifn_899 = lang.IFn_Cast(root_897) } else { ifn_899 = nil }; var arg_900 any = te__4; if linked_898 == nil { and__1927000168__auto____6 = ifn_899.Invoke_O__O(arg_900) } else { and__1927000168__auto____6 = linked_898.(*aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A).Invoke_O_O__O(root_897, arg_900) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_901 any = A_arbace_classes_env_A_const_104.GetRawRoot__O(); var linked_902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_901, A_arbace_classes_env_assignable_QMARK__A_fn_class); var ifn_903 lang.IFn; if linked_902 == nil { ifn_903 = lang.IFn_Cast(root_901) } else { ifn_903 = nil }; var arg_904 any = fe__3; var arg_905 any = te__4; if linked_902 == nil { return ifn_903.Invoke_O_O__O(arg_904, arg_905) } else { return linked_902.(*A_arbace_classes_env_assignable_QMARK__A).Invoke_O_O_O__O(root_901, arg_904, arg_905) } } else { return and__1927000168__auto____6 } } else { return and__1927000168__auto____5 } } else {
//line :246:1
							if A_arbace_classes_env_A_const_105 != nil {

								var root_906 any = A_arbace_classes_env_A_const_23.GetRawRoot__O(); var linked_907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_906, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_908 lang.IFn; if linked_907 == nil { ifn_908 = lang.IFn_Cast(root_906) } else { ifn_908 = nil }; var arg_909 any = A_arbace_classes_env_A_const_106; var arg_910 any = to__1; if linked_907 == nil { return ifn_908.Invoke_O_O__O(arg_909, arg_910) } else { return linked_907.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_906, arg_909, arg_910) } } else {
//line :246:1
									return nil } } } else {
//line :240:1
										var tmp4 any; var root_911 any = A_arbace_classes_env_A_const_102.GetRawRoot__O(); var linked_912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_911, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_913 lang.IFn








										if linked_912 == nil { ifn_913 = lang.IFn_Cast(root_911) } else { ifn_913 = nil }; var arg_914 any = to__1; if linked_912 == nil { tmp4 = ifn_913.Invoke_O__O(arg_914) } else { tmp4 = linked_912.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_911, arg_914) }
//line :240:1
										if jrt.J2g_Truth(tmp4) { return jrt.Boolean_FALSE.Ref() } else { if A_arbace_classes_env_A_const_105 != nil {









											var root_915 any = A_arbace_classes_env_A_const_98.GetRawRoot__O(); var linked_916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_915, A_arbace_classes_env_subclass_QMARK__A_fn_class); var ifn_917 lang.IFn; if linked_916 == nil { ifn_917 = lang.IFn_Cast(root_915) } else { ifn_917 = nil }; var arg_918 any; var root_920 any = A_arbace_classes_env_A_const_107.GetRawRoot__O(); var linked_921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_920, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_922 lang.IFn; if linked_921 == nil { ifn_922 = lang.IFn_Cast(root_920) } else { ifn_922 = nil }; var arg_923 any = from__0; if linked_921 == nil { arg_918 = ifn_922.Invoke_O__O(arg_923) } else { arg_918 = linked_921.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_920, arg_923) }; var arg_919 any; var root_924 any = A_arbace_classes_env_A_const_107.GetRawRoot__O(); var linked_925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_924, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_926 lang.IFn; if linked_925 == nil { ifn_926 = lang.IFn_Cast(root_924) } else { ifn_926 = nil }; var arg_927 any = to__1; if linked_925 == nil { arg_919 = ifn_926.Invoke_O__O(arg_927) } else { arg_919 = linked_925.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_924, arg_927) }; if linked_916 == nil { return ifn_917.Invoke_O_O__O(arg_918, arg_919) } else { return linked_916.(*A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(root_915, arg_918, arg_919) } } else {
//line :240:1
												return nil
											}
										}
									}
			}
			}
		}
	}
}



func A_arbace_classes_env_superclass_chain_A_New() *A_arbace_classes_env_superclass_chain_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_superclass_chain_A{}; t.Ctor(); return t }
//line :252:1
func (t *A_arbace_classes_env_superclass_chain_A) Ctor() {}
//line :252:1
func (t *A_arbace_classes_env_superclass_chain_A) Invoke_O_O__O(self, n__0 any) any {
	var root_928 any = A_arbace_classes_env_A_const_108.GetRawRoot__O(); var linked_929 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_928, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_930 lang.IFn; if linked_929 == nil { ifn_930 = lang.IFn_Cast(root_928) } else { ifn_930 = nil }; var arg_931 any = A_arbace_classes_env_A_const_25.GetRawRoot__O(); var arg_932 any; var root_933 any = A_arbace_classes_env_A_const_109.GetRawRoot__O(); var linked_934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_933, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_935 lang.IFn; if linked_934 == nil { ifn_935 = lang.IFn_Cast(root_933) } else { ifn_935 = nil }; var arg_936 any; var tmp1 any = A_arbace_classes_env_superclass_chain_fn__28000123_A_New(); var tmp2 *jrt.Class; var fncls__942 *jrt.Class = A_arbace_classes_env_superclass_chain_fn__28000123_A_fn_class; if fncls__942 == nil { var fncls__942d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_classes_env_superclass_chain_fn__28000123_A_fn_class = fncls__942d; tmp2 = fncls__942d } else { tmp2 = fncls__942 }; arg_936 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_937 any = n__0; if linked_934 == nil { arg_932 = ifn_935.Invoke_O_O__O(arg_936, arg_937) } else { arg_932 = linked_934.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_933, arg_936, arg_937) }; if linked_929 == nil { return ifn_930.Invoke_O_O__O(arg_931, arg_932) } else { return linked_929.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_928, arg_931, arg_932) } }
//line :253:1
func A_arbace_classes_env_superclass_chain_fn__28000123_A_New() *A_arbace_classes_env_superclass_chain_fn__28000123_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_superclass_chain_fn__28000123_A{}; t.Ctor(); return t }
//line :253:1
func (t *A_arbace_classes_env_superclass_chain_fn__28000123_A) Ctor() {}
//line :253:1
func (t *A_arbace_classes_env_superclass_chain_fn__28000123_A) Invoke_O_O__O(self, p1__28000122_SHARP___1 any) any { var G__28000124__2_ any = p1__28000122_SHARP___1; var G__28000124__3_ any; if lang.Util_Identical_O_O__Z_NoInit(G__28000124__2_, nil) { G__28000124__3_ = nil } else { var root_938 any = A_arbace_classes_env_A_const_94.GetRawRoot__O(); var linked_939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_938, A_arbace_classes_env_info_A_fn_class); var ifn_940 lang.IFn; if linked_939 == nil { ifn_940 = lang.IFn_Cast(root_938) } else { ifn_940 = nil }; var arg_941 any = G__28000124__2_; if linked_939 == nil { G__28000124__3_ = ifn_940.Invoke_O__O(arg_941) } else { G__28000124__3_ = linked_939.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_938, arg_941) } }; if lang.Util_Identical_O_O__Z_NoInit(G__28000124__3_, nil) { return nil } else { return A_arbace_classes_env_A_const_45.Invoke_O__O(G__28000124__3_) } }

func A_arbace_classes_env_common_super_A_New() *A_arbace_classes_env_common_super_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_common_super_A{}; t.Ctor(); return t }
//line :255:1
func (t *A_arbace_classes_env_common_super_A) Ctor() {}
//line :255:1
func (t *A_arbace_classes_env_common_super_A) Invoke_O_O_O__O(self, a__0, b__1 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(a__0, b__1) { return a__0 } else { var tmp1 any; var or__1927000174__auto____3 any; var root_943 any = A_arbace_classes_env_A_const_20.GetRawRoot__O(); var linked_944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_943, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_945 lang.IFn

		if linked_944 == nil { ifn_945 = lang.IFn_Cast(root_943) } else { ifn_945 = nil }; var arg_946 any = a__0; var arg_947 any = Lit_11; if linked_944 == nil { or__1927000174__auto____3 = ifn_945.Invoke_O_O__O(arg_946, arg_947) } else { or__1927000174__auto____3 = linked_944.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_943, arg_946, arg_947) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var root_948 any = A_arbace_classes_env_A_const_20.GetRawRoot__O(); var linked_949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_948, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_950 lang.IFn; if linked_949 == nil { ifn_950 = lang.IFn_Cast(root_948) } else { ifn_950 = nil }; var arg_951 any = b__1; var arg_952 any = Lit_11; if linked_949 == nil { tmp1 = ifn_950.Invoke_O_O__O(arg_951, arg_952) } else { tmp1 = linked_949.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_948, arg_951, arg_952) } }
//line :258:1
		if jrt.J2g_Truth(tmp1) { return Lit_4 } else { var tmp2 any; var root_953 any = A_arbace_classes_env_A_const_98.GetRawRoot__O(); var linked_954 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_953, A_arbace_classes_env_subclass_QMARK__A_fn_class); var ifn_955 lang.IFn


			if linked_954 == nil { ifn_955 = lang.IFn_Cast(root_953) } else { ifn_955 = nil }; var arg_956 any = a__0; var arg_957 any = b__1; if linked_954 == nil { tmp2 = ifn_955.Invoke_O_O__O(arg_956, arg_957) } else { tmp2 = linked_954.(*A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(root_953, arg_956, arg_957) }
//line :258:1
			if jrt.J2g_Truth(tmp2) {


				var tmp3 any; var root_958 any = A_arbace_classes_env_A_const_110.GetRawRoot__O(); var linked_959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_958, A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_960 lang.IFn; if linked_959 == nil { ifn_960 = lang.IFn_Cast(root_958) } else { ifn_960 = nil }; var arg_961 any = b__1; if linked_959 == nil { tmp3 = ifn_960.Invoke_O__O(arg_961) } else { tmp3 = linked_959.(*A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_958, arg_961) }; if jrt.J2g_Truth(tmp3) { return Lit_4 } else { return b__1 } } else {
//line :258:1
					var tmp4 any; var root_962 any = A_arbace_classes_env_A_const_98.GetRawRoot__O(); var linked_963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_962, A_arbace_classes_env_subclass_QMARK__A_fn_class); var ifn_964 lang.IFn



					if linked_963 == nil { ifn_964 = lang.IFn_Cast(root_962) } else { ifn_964 = nil }; var arg_965 any = b__1; var arg_966 any = a__0; if linked_963 == nil { tmp4 = ifn_964.Invoke_O_O__O(arg_965, arg_966) } else { tmp4 = linked_963.(*A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(root_962, arg_965, arg_966) }
//line :258:1
					if jrt.J2g_Truth(tmp4) {



						var tmp5 any; var root_967 any = A_arbace_classes_env_A_const_110.GetRawRoot__O(); var linked_968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_967, A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_969 lang.IFn; if linked_968 == nil { ifn_969 = lang.IFn_Cast(root_967) } else { ifn_969 = nil }; var arg_970 any = a__0; if linked_968 == nil { tmp5 = ifn_969.Invoke_O__O(arg_970) } else { tmp5 = linked_968.(*A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_967, arg_970) }; if jrt.J2g_Truth(tmp5) { return Lit_4 } else { return a__0 } } else {
//line :258:1
							var tmp6 any; var or__1927000174__auto____3_2 any; var root_971 any = A_arbace_classes_env_A_const_110.GetRawRoot__O(); var linked_972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_971, A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_973 lang.IFn




							if linked_972 == nil { ifn_973 = lang.IFn_Cast(root_971) } else { ifn_973 = nil }; var arg_974 any = a__0; if linked_972 == nil { or__1927000174__auto____3_2 = ifn_973.Invoke_O__O(arg_974) } else { or__1927000174__auto____3_2 = linked_972.(*A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_971, arg_974) }; if jrt.J2g_Truth(or__1927000174__auto____3_2) { tmp6 = or__1927000174__auto____3_2 } else { var root_975 any = A_arbace_classes_env_A_const_110.GetRawRoot__O(); var linked_976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_975, A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_977 lang.IFn; if linked_976 == nil { ifn_977 = lang.IFn_Cast(root_975) } else { ifn_977 = nil }; var arg_978 any = b__1; if linked_976 == nil { tmp6 = ifn_977.Invoke_O__O(arg_978) } else { tmp6 = linked_976.(*A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_975, arg_978) } }
//line :258:1
							if jrt.J2g_Truth(tmp6) { return Lit_4 } else { if A_arbace_classes_env_A_const_105 != nil { var bs__3 any; var root_979 any = A_arbace_classes_env_A_const_111.GetRawRoot__O(); var linked_980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_979, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_981 lang.IFn





								if linked_980 == nil { ifn_981 = lang.IFn_Cast(root_979) } else { ifn_981 = nil }; var arg_982 any; var root_983 any = A_arbace_classes_env_A_const_112.GetRawRoot__O(); var linked_984 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_983, A_arbace_classes_env_superclass_chain_A_fn_class); var ifn_985 lang.IFn; if linked_984 == nil { ifn_985 = lang.IFn_Cast(root_983) } else { ifn_985 = nil }; var arg_986 any = b__1; if linked_984 == nil { arg_982 = ifn_985.Invoke_O__O(arg_986) } else { arg_982 = linked_984.(*A_arbace_classes_env_superclass_chain_A).Invoke_O_O__O(root_983, arg_986) }; if linked_980 == nil { bs__3 = ifn_981.Invoke_O__O(arg_982) } else { bs__3 = linked_980.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_979, arg_982) }
//line :258:1
								var or__1927000174__auto____4 any; var root_987 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_988 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_987, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_989 lang.IFn






								if linked_988 == nil { ifn_989 = lang.IFn_Cast(root_987) } else { ifn_989 = nil }; var arg_990 any; var root_991 any = A_arbace_classes_env_A_const_87.GetRawRoot__O(); var linked_992 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_991, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_993 lang.IFn; if linked_992 == nil { ifn_993 = lang.IFn_Cast(root_991) } else { ifn_993 = nil }; var arg_994 any = bs__3; var arg_995 any; var root_996 any = A_arbace_classes_env_A_const_112.GetRawRoot__O(); var linked_997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_996, A_arbace_classes_env_superclass_chain_A_fn_class); var ifn_998 lang.IFn; if linked_997 == nil { ifn_998 = lang.IFn_Cast(root_996) } else { ifn_998 = nil }; var arg_999 any = a__0; if linked_997 == nil { arg_995 = ifn_998.Invoke_O__O(arg_999) } else { arg_995 = linked_997.(*A_arbace_classes_env_superclass_chain_A).Invoke_O_O__O(root_996, arg_999) }; if linked_992 == nil { arg_990 = ifn_993.Invoke_O_O__O(arg_994, arg_995) } else { arg_990 = linked_992.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_991, arg_994, arg_995) }; if linked_988 == nil { or__1927000174__auto____4 = ifn_989.Invoke_O__O(arg_990) } else { or__1927000174__auto____4 = linked_988.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_987, arg_990) }; if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { return Lit_4 } } else {
//line :258:1
									return nil
								}
							}
						}
				}
		}
	}
}

func A_arbace_classes_env_lub_A_New() *A_arbace_classes_env_lub_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_lub_A{}; t.Ctor(); return t }
//line :267:1
func (t *A_arbace_classes_env_lub_A) Ctor() {}
//line :267:1
func (t *A_arbace_classes_env_lub_A) Invoke_O_O_O__O(self, a__0, b__1 any) any {



	if lang.Util_Equiv_O_O__Z_NoInit(a__0, b__1) { return a__0 } else { if lang.Util_Equiv_O_O__Z_NoInit(a__0, A_arbace_classes_env_A_const_99) { return b__1 } else { if lang.Util_Equiv_O_O__Z_NoInit(b__1, A_arbace_classes_env_A_const_99) { return a__0 } else { var tmp1 any; var root_1000 any = A_arbace_classes_env_A_const_104.GetRawRoot__O(); var linked_1001 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1000, A_arbace_classes_env_assignable_QMARK__A_fn_class); var ifn_1002 lang.IFn


		if linked_1001 == nil { ifn_1002 = lang.IFn_Cast(root_1000) } else { ifn_1002 = nil }; var arg_1003 any = a__0; var arg_1004 any = b__1; if linked_1001 == nil { tmp1 = ifn_1002.Invoke_O_O__O(arg_1003, arg_1004) } else { tmp1 = linked_1001.(*A_arbace_classes_env_assignable_QMARK__A).Invoke_O_O_O__O(root_1000, arg_1003, arg_1004) }
//line :271:1
		if jrt.J2g_Truth(tmp1) { return b__1 } else { var tmp2 any; var root_1005 any = A_arbace_classes_env_A_const_104.GetRawRoot__O(); var linked_1006 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1005, A_arbace_classes_env_assignable_QMARK__A_fn_class); var ifn_1007 lang.IFn



			if linked_1006 == nil { ifn_1007 = lang.IFn_Cast(root_1005) } else { ifn_1007 = nil }; var arg_1008 any = b__1; var arg_1009 any = a__0; if linked_1006 == nil { tmp2 = ifn_1007.Invoke_O_O__O(arg_1008, arg_1009) } else { tmp2 = linked_1006.(*A_arbace_classes_env_assignable_QMARK__A).Invoke_O_O_O__O(root_1005, arg_1008, arg_1009) }
//line :271:1
			if jrt.J2g_Truth(tmp2) { return a__0 } else { var tmp3 any; var and__1927000168__auto____3 any; var root_1010 any = A_arbace_classes_env_A_const_113.GetRawRoot__O(); var linked_1011 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1010, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_1012 lang.IFn




				if linked_1011 == nil { ifn_1012 = lang.IFn_Cast(root_1010) } else { ifn_1012 = nil }; var arg_1013 any = a__0; if linked_1011 == nil { and__1927000168__auto____3 = ifn_1012.Invoke_O__O(arg_1013) } else { and__1927000168__auto____3 = linked_1011.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_1010, arg_1013) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_1014 any = A_arbace_classes_env_A_const_113.GetRawRoot__O(); var linked_1015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1014, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_1016 lang.IFn; if linked_1015 == nil { ifn_1016 = lang.IFn_Cast(root_1014) } else { ifn_1016 = nil }; var arg_1017 any = b__1; if linked_1015 == nil { tmp3 = ifn_1016.Invoke_O__O(arg_1017) } else { tmp3 = linked_1015.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_1014, arg_1017) } } else { tmp3 = and__1927000168__auto____3 }
//line :271:1
				if jrt.J2g_Truth(tmp3) { var c__3 any; var root_1018 any = A_arbace_classes_env_A_const_114.GetRawRoot__O(); var linked_1019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1018, A_arbace_classes_env_common_super_A_fn_class); var ifn_1020 lang.IFn





					if linked_1019 == nil { ifn_1020 = lang.IFn_Cast(root_1018) } else { ifn_1020 = nil }; var arg_1021 any; var root_1023 any = A_arbace_classes_env_A_const_107.GetRawRoot__O(); var linked_1024 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1023, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_1025 lang.IFn; if linked_1024 == nil { ifn_1025 = lang.IFn_Cast(root_1023) } else { ifn_1025 = nil }; var arg_1026 any = a__0; if linked_1024 == nil { arg_1021 = ifn_1025.Invoke_O__O(arg_1026) } else { arg_1021 = linked_1024.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_1023, arg_1026) }; var arg_1022 any; var root_1027 any = A_arbace_classes_env_A_const_107.GetRawRoot__O(); var linked_1028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1027, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_1029 lang.IFn; if linked_1028 == nil { ifn_1029 = lang.IFn_Cast(root_1027) } else { ifn_1029 = nil }; var arg_1030 any = b__1; if linked_1028 == nil { arg_1022 = ifn_1029.Invoke_O__O(arg_1030) } else { arg_1022 = linked_1028.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_1027, arg_1030) }; if linked_1019 == nil { c__3 = ifn_1020.Invoke_O_O__O(arg_1021, arg_1022) } else { c__3 = linked_1019.(*A_arbace_classes_env_common_super_A).Invoke_O_O_O__O(root_1018, arg_1021, arg_1022) }
					if lang.Util_Equiv_O_O__Z_NoInit(c__3, Lit_4) { var sups__4 any; var tmp4 any = A_arbace_classes_env_lub_sups__28000129_A_New(); var tmp5 *jrt.Class
						var fncls__1055 /*line :278:1*/*jrt.Class = A_arbace_classes_env_lub_sups__28000129_A_fn_class

						if fncls__1055 == nil { var fncls__1055d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_classes_env_lub_sups__28000129_A_fn_class = fncls__1055d; tmp5 = fncls__1055d } else { tmp5 = fncls__1055 }; sups__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)
//line :278:1
						var common__5 any; var root_1056 any = A_arbace_classes_env_A_const_87.GetRawRoot__O(); var linked_1057 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1056, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1058 lang.IFn




						if linked_1057 == nil { ifn_1058 = lang.IFn_Cast(root_1056) } else { ifn_1058 = nil }; var arg_1059 any = A_arbace_classes_env_A_const_110.GetRawRoot__O(); var arg_1060 any; var root_1061 any = A_arbace_classes_env_A_const_116.GetRawRoot__O(); var linked_1062 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1061, aot_arbace_set.A_arbace_set_intersection_A_fn_class); var ifn_1063 lang.IFn; if linked_1062 == nil { ifn_1063 = lang.IFn_Cast(root_1061) } else { ifn_1063 = nil }; var arg_1064 any; var tmp6 lang.IFn = lang.IFn_Cast(sups__4); var tmp7 any; var root_1066 any = A_arbace_classes_env_A_const_107.GetRawRoot__O(); var linked_1067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1066, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_1068 lang.IFn; if linked_1067 == nil { ifn_1068 = lang.IFn_Cast(root_1066) } else { ifn_1068 = nil }; var arg_1069 any = a__0; if linked_1067 == nil { tmp7 = ifn_1068.Invoke_O__O(arg_1069) } else { tmp7 = linked_1067.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_1066, arg_1069) }; arg_1064 = tmp6.Invoke_O__O(tmp7); var arg_1065 any; var tmp8 lang.IFn = lang.IFn_Cast(sups__4); var tmp9 any; var root_1070 any = A_arbace_classes_env_A_const_107.GetRawRoot__O(); var linked_1071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1070, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_1072 lang.IFn
						if linked_1071 == nil { ifn_1072 = lang.IFn_Cast(root_1070) } else { ifn_1072 = nil }; var arg_1073 any = b__1; if linked_1071 == nil { tmp9 = ifn_1072.Invoke_O__O(arg_1073) } else { tmp9 = linked_1071.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_1070, arg_1073) }; arg_1065 = tmp8.Invoke_O__O(tmp9)
//line :283:1
						if linked_1062 == nil { arg_1060 = ifn_1063.Invoke_O_O__O(arg_1064, arg_1065) } else { arg_1060 = linked_1062.(*aot_arbace_set.A_arbace_set_intersection_A).Invoke_O_O_O__O(root_1061, arg_1064, arg_1065) }; if linked_1057 == nil { common__5 = ifn_1058.Invoke_O_O__O(arg_1059, arg_1060) } else { common__5 = linked_1057.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1056, arg_1059, arg_1060) }
//line :278:1
						var minimal__6 any; var root_1074 any = A_arbace_classes_env_A_const_117.GetRawRoot__O(); var linked_1075 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1074, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1076 lang.IFn






						if linked_1075 == nil { ifn_1076 = lang.IFn_Cast(root_1074) } else { ifn_1076 = nil }; var arg_1077 any; var tmp10 any = A_arbace_classes_env_lub_fn__28000134_A_New_O(common__5); var tmp11 *jrt.Class; var fncls__1095 *jrt.Class = A_arbace_classes_env_lub_fn__28000134_A_fn_class; if fncls__1095 == nil { var fncls__1095d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_classes_env_lub_fn__28000134_A_fn_class = fncls__1095d; tmp11 = fncls__1095d } else { tmp11 = fncls__1095 }; arg_1077 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var arg_1078 any = common__5; if linked_1075 == nil { minimal__6 = ifn_1076.Invoke_O_O__O(arg_1077, arg_1078) } else { minimal__6 = linked_1075.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1074, arg_1077, arg_1078) }
						if lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(minimal__6))) { var root_1096 any = A_arbace_classes_env_A_const_119.GetRawRoot__O(); var linked_1097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1096, aot_arbace_classes_types.A_arbace_classes_types_internal__GT_desc_A_fn_class); var ifn_1098 lang.IFn; if linked_1097 == nil { ifn_1098 = lang.IFn_Cast(root_1096) } else { ifn_1098 = nil }; var arg_1099 any; var root_1100 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_1101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1100, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1102 lang.IFn; if linked_1101 == nil { ifn_1102 = lang.IFn_Cast(root_1100) } else { ifn_1102 = nil }; var arg_1103 any = minimal__6; if linked_1101 == nil { arg_1099 = ifn_1102.Invoke_O__O(arg_1103) } else { arg_1099 = linked_1101.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1100, arg_1103) }; if linked_1097 == nil { return ifn_1098.Invoke_O__O(arg_1099) } else { return linked_1097.(*aot_arbace_classes_types.A_arbace_classes_types_internal__GT_desc_A).Invoke_O_O__O(root_1096, arg_1099) } } else { return A_arbace_classes_env_A_const_101.GetRawRoot__O() } } else {
							var root_1104 any = A_arbace_classes_env_A_const_119.GetRawRoot__O(); var linked_1105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1104, aot_arbace_classes_types.A_arbace_classes_types_internal__GT_desc_A_fn_class); var ifn_1106 lang.IFn; if linked_1105 == nil { ifn_1106 = lang.IFn_Cast(root_1104) } else { ifn_1106 = nil }; var arg_1107 any = c__3; if linked_1105 == nil { return ifn_1106.Invoke_O__O(arg_1107) } else { return linked_1105.(*aot_arbace_classes_types.A_arbace_classes_types_internal__GT_desc_A).Invoke_O_O__O(root_1104, arg_1107) } } } else {
//line :271:1
								if A_arbace_classes_env_A_const_105 != nil { return A_arbace_classes_env_A_const_101.GetRawRoot__O() } else { return nil
								}
							}
			}
		}
	}
	}
	}
}
func A_arbace_classes_env_lub_sups__28000129_A_New() *A_arbace_classes_env_lub_sups__28000129_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_lub_sups__28000129_A{}; t.Ctor(); return t }
//line :280:1
func (t *A_arbace_classes_env_lub_sups__28000129_A) Ctor() {}
//line :280:1
func (t *A_arbace_classes_env_lub_sups__28000129_A) Invoke_O_O__O(self, n__1 any) any { var root_1031 any = A_arbace_classes_env_A_const_111.GetRawRoot__O(); var linked_1032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1031, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_1033 lang.IFn; if linked_1032 == nil { ifn_1033 = lang.IFn_Cast(root_1031) } else { ifn_1033 = nil }; var arg_1034 any; var root_1035 any = A_arbace_classes_env_A_const_115.GetRawRoot__O(); var linked_1036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1035, aot_arbace_core.A_arbace_core_tree_seq_A_fn_class); var ifn_1037 lang.IFn; if linked_1036 == nil { ifn_1037 = lang.IFn_Cast(root_1035) } else { ifn_1037 = nil }; var arg_1038 any = A_arbace_classes_env_A_const_25.GetRawRoot__O(); var arg_1039 any; var tmp1 any = A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_New(); var tmp2 *jrt.Class; var fncls__1054 *jrt.Class = A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_fn_class; if fncls__1054 == nil { var fncls__1054d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_fn_class = fncls__1054d; tmp2 = fncls__1054d } else { tmp2 = fncls__1054 }; arg_1039 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1040 any = n__1; if linked_1036 == nil { arg_1034 = ifn_1037.Invoke_O_O_O__O(arg_1038, arg_1039, arg_1040) } else { arg_1034 = linked_1036.(*aot_arbace_core.A_arbace_core_tree_seq_A).Invoke_O_O_O_O__O(root_1035, arg_1038, arg_1039, arg_1040) }; if linked_1032 == nil { return ifn_1033.Invoke_O__O(arg_1034) } else { return linked_1032.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1031, arg_1034) } }
//line :280:1
func A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_New() *A_arbace_classes_env_lub_sups__28000129_fn__28000130_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_lub_sups__28000129_fn__28000130_A{}; t.Ctor(); return t }
//line :280:1
func (t *A_arbace_classes_env_lub_sups__28000129_fn__28000130_A) Ctor() {}
//line :280:1
func (t *A_arbace_classes_env_lub_sups__28000129_fn__28000130_A) Invoke_O_O__O(self, x__1 any) any { var temp__1927000414__auto____2 any; var root_1041 any = A_arbace_classes_env_A_const_94.GetRawRoot__O(); var linked_1042 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1041, A_arbace_classes_env_info_A_fn_class); var ifn_1043 lang.IFn; if linked_1042 == nil { ifn_1043 = lang.IFn_Cast(root_1041) } else { ifn_1043 = nil }; var arg_1044 any = x__1; if linked_1042 == nil { temp__1927000414__auto____2 = ifn_1043.Invoke_O__O(arg_1044) } else { temp__1927000414__auto____2 = linked_1042.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1041, arg_1044) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var i__3 any = temp__1927000414__auto____2; var G__28000131__4_ any; var root_1045 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_1046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1045, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1047 lang.IFn
													if linked_1046 == nil { ifn_1047 = lang.IFn_Cast(root_1045) } else { ifn_1047 = nil }; var arg_1048 any = A_arbace_classes_env_A_const_46.Invoke_O__O(i__3); if linked_1046 == nil { G__28000131__4_ = ifn_1047.Invoke_O__O(arg_1048) } else { G__28000131__4_ = linked_1046.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1045, arg_1048) }; if jrt.J2g_Truth(A_arbace_classes_env_A_const_45.Invoke_O__O(i__3)) { var root_1049 any = A_arbace_classes_env_A_const_10.GetRawRoot__O(); var linked_1050 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1049, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1051 lang.IFn; if linked_1050 == nil { ifn_1051 = lang.IFn_Cast(root_1049) } else { ifn_1051 = nil }; var arg_1052 any = G__28000131__4_; var arg_1053 any = A_arbace_classes_env_A_const_45.Invoke_O__O(i__3); if linked_1050 == nil { return ifn_1051.Invoke_O_O__O(arg_1052, arg_1053) } else { return linked_1050.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1049, arg_1052, arg_1053) } } else { return G__28000131__4_ } } else {
//line :280:1
		return nil } }




func A_arbace_classes_env_lub_fn__28000134_A_New_O(p0 any) *A_arbace_classes_env_lub_fn__28000134_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_lub_fn__28000134_A{}; t.Ctor_O(p0); return t }
//line :285:1
func (t *A_arbace_classes_env_lub_fn__28000134_A) Ctor_O(c__common any) { t.F_common = c__common }
//line :285:1
func (t *A_arbace_classes_env_lub_fn__28000134_A) Invoke_O_O__O(self, i__1 any) any { var root_1079 any = A_arbace_classes_env_A_const_97.GetRawRoot__O(); var linked_1080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1079, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1081 lang.IFn; if linked_1080 == nil { ifn_1081 = lang.IFn_Cast(root_1079) } else { ifn_1081 = nil }; var arg_1082 any; var tmp1 any = A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_New_O(i__1); var tmp2 *jrt.Class; var fncls__1094 *jrt.Class = A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_fn_class; if fncls__1094 == nil { var fncls__1094d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_fn_class = fncls__1094d; tmp2 = fncls__1094d } else { tmp2 = fncls__1094 }; arg_1082 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1083 any = t.F_common; if linked_1080 == nil { return ifn_1081.Invoke_O_O__O(arg_1082, arg_1083) } else { return linked_1080.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1079, arg_1082, arg_1083) } }
//line :285:1
func A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_New_O(p0 any) *A_arbace_classes_env_lub_fn__28000134_fn__28000135_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_lub_fn__28000134_fn__28000135_A{}; t.Ctor_O(p0); return t }
//line :285:1
func (t *A_arbace_classes_env_lub_fn__28000134_fn__28000135_A) Ctor_O(c__i any) { t.F_i = c__i }
//line :285:1
func (t *A_arbace_classes_env_lub_fn__28000134_fn__28000135_A) Invoke_O_O__O(self, p1__28000128_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_1084 any = A_arbace_classes_env_A_const_118.GetRawRoot__O(); var linked_1085 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1084, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1086 lang.IFn; if linked_1085 == nil { ifn_1086 = lang.IFn_Cast(root_1084) } else { ifn_1086 = nil }; var arg_1087 any = p1__28000128_SHARP___1; var arg_1088 any = t.F_i; if linked_1085 == nil { and__1927000168__auto____2 = ifn_1086.Invoke_O_O__O(arg_1087, arg_1088) } else { and__1927000168__auto____2 = linked_1085.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1084, arg_1087, arg_1088) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_1089 any = A_arbace_classes_env_A_const_98.GetRawRoot__O(); var linked_1090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1089, A_arbace_classes_env_subclass_QMARK__A_fn_class); var ifn_1091 lang.IFn; if linked_1090 == nil { ifn_1091 = lang.IFn_Cast(root_1089) } else { ifn_1091 = nil }; var arg_1092 any = p1__28000128_SHARP___1; var arg_1093 any = t.F_i; if linked_1090 == nil { return ifn_1091.Invoke_O_O__O(arg_1092, arg_1093) } else { return linked_1090.(*A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(root_1089, arg_1092, arg_1093) } } else { return and__1927000168__auto____2 } }






func A_arbace_classes_env_nest_host_A_New() *A_arbace_classes_env_nest_host_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_nest_host_A{}; t.Ctor(); return t }
//line :292:1
func (t *A_arbace_classes_env_nest_host_A) Ctor() {}
//line :292:1
func (t *A_arbace_classes_env_nest_host_A) Invoke_O_O__O(self, n__0 any) any { var i__2 any; var root_1108 any = A_arbace_classes_env_A_const_94.GetRawRoot__O(); var linked_1109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1108, A_arbace_classes_env_info_A_fn_class); var ifn_1110 lang.IFn; if
										linked_1109 == nil { ifn_1110 = lang.IFn_Cast(root_1108) } else { ifn_1110 = nil }; var arg_1111 any = n__0; if linked_1109 == nil { i__2 = ifn_1110.Invoke_O__O(arg_1111) } else { i__2 = linked_1109.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1108, arg_1111) }; var or__1927000174__auto____3 any = /*line :292:1*/A_arbace_classes_env_A_const_48.Invoke_O__O(i__2); if

	jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var temp__1927000408__auto____4 any = A_arbace_classes_env_A_const_49.Invoke_O__O(i__2)
		if jrt.J2g_Truth(temp__1927000408__auto____4) { var o__5 any = temp__1927000408__auto____4; var root_1112 any = A_arbace_classes_env_A_const_120.GetRawRoot__O(); var linked_1113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1112, A_arbace_classes_env_nest_host_A_fn_class); var ifn_1114 lang.IFn; if linked_1113 == nil { ifn_1114 = lang.IFn_Cast(root_1112) } else { ifn_1114 = nil }; var arg_1115 any = o__5; if linked_1113 == nil { return ifn_1114.Invoke_O__O(arg_1115) } else { return linked_1113.(*A_arbace_classes_env_nest_host_A).Invoke_O_O__O(root_1112, arg_1115) } } else { return n__0 } } }

func A_arbace_classes_env_flag_QMARK__A_New() *A_arbace_classes_env_flag_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_flag_QMARK__A{}; t.Ctor(); return t }
//line :297:1
func (t *A_arbace_classes_env_flag_QMARK__A) Ctor() {}
//line :297:1
func (t *A_arbace_classes_env_flag_QMARK__A) Invoke_O_O_O__O(self, flags__0, f__1 any) any { var root_1116 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1116, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1118 lang.IFn; if linked_1117 == nil { ifn_1118 = lang.IFn_Cast(root_1116) } else { ifn_1118 = nil }; var arg_1119 any; var tmp1 int64; var na_1120 any = flags__0; var na_1121 any = f__1; var tmp2 bool; var tmp3 bool; tmp3 = jrt.Long_InstanceOf(na_1120); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_1121) }; tmp2 = tmp3; if tmp2 { var n0_1122 int64 = jrt.NN(jrt.Long_Cast(na_1120)).LongValue__J(); var n1_1123 int64 = jrt.NN(jrt.Long_Cast(na_1121)).LongValue__J(); tmp1 = n0_1122 & n1_1123 } else { tmp1 = lang.Numbers_And_O_O__J_NoInit(na_1120, na_1121) }; arg_1119 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(tmp1)).Ref(); if linked_1117 == nil { return ifn_1118.Invoke_O__O(arg_1119) } else { return linked_1117.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1116, arg_1119) } }

func A_arbace_classes_env_accessible_QMARK__A_New() *A_arbace_classes_env_accessible_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_accessible_QMARK__A{}; t.Ctor(); return t }
//line :299:1
func (t *A_arbace_classes_env_accessible_QMARK__A) Ctor() {}
//line :299:1
func (t *A_arbace_classes_env_accessible_QMARK__A) Invoke_O_O_O__O(self, from__0, m__1 any) any { var fl__3 any = A_arbace_classes_env_A_const_43.Invoke_O__O(m__1); var owner__4 any = A_arbace_classes_env_A_const_63.Invoke_O__O(m__1); var tmp1 any; var root_1125 any = A_arbace_classes_env_A_const_121.GetRawRoot__O(); var linked_1126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1125, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1127 lang.IFn; if




	linked_1126 == nil { ifn_1127 = lang.IFn_Cast(root_1125) } else { ifn_1127 = nil }; var arg_1128 any = fl__3; var arg_1129 any = A_arbace_classes_env_A_const_122; if linked_1126 == nil { tmp1 = ifn_1127.Invoke_O_O__O(arg_1128, arg_1129) } else { tmp1 = linked_1126.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1125, arg_1128, arg_1129) }; if /*line :303:1*/ jrt.J2g_Truth(tmp1) { return jrt.Boolean_TRUE.Ref() } else { var tmp2 any; var root_1130 any = A_arbace_classes_env_A_const_121.GetRawRoot__O(); var linked_1131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1130, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1132 lang.IFn

		if linked_1131 == nil { ifn_1132 = lang.IFn_Cast(root_1130) } else { ifn_1132 = nil }; var arg_1133 any = fl__3; var arg_1134 any = A_arbace_classes_env_A_const_123; if linked_1131 == nil { tmp2 = ifn_1132.Invoke_O_O__O(arg_1133, arg_1134) } else { tmp2 = linked_1131.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1130, arg_1133, arg_1134) }
//line :303:1
		if jrt.J2g_Truth(tmp2) {

			var tmp3 any; var root_1135 any = A_arbace_classes_env_A_const_120.GetRawRoot__O(); var linked_1136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1135, A_arbace_classes_env_nest_host_A_fn_class); var ifn_1137 lang.IFn; if linked_1136 == nil { ifn_1137 = lang.IFn_Cast(root_1135) } else { ifn_1137 = nil }; var arg_1138 any = from__0; if linked_1136 == nil { tmp3 = ifn_1137.Invoke_O__O(arg_1138) } else { tmp3 = linked_1136.(*A_arbace_classes_env_nest_host_A).Invoke_O_O__O(root_1135, arg_1138) }; var tmp4 any = tmp3; var tmp5 any; var root_1139 any = A_arbace_classes_env_A_const_120.GetRawRoot__O(); var linked_1140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1139, A_arbace_classes_env_nest_host_A_fn_class); var ifn_1141 lang.IFn; if linked_1140 == nil { ifn_1141 = lang.IFn_Cast(root_1139) } else { ifn_1141 = nil }; var arg_1142 any = owner__4; if linked_1140 == nil { tmp5 = ifn_1141.Invoke_O__O(arg_1142) } else { tmp5 = linked_1140.(*A_arbace_classes_env_nest_host_A).Invoke_O_O__O(root_1139, arg_1142) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5)).Ref() } else {
//line :303:1
				var tmp6 any; var root_1143 any = A_arbace_classes_env_A_const_124.GetRawRoot__O(); var linked_1144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1143, aot_arbace_classes_types.A_arbace_classes_types_package_of_A_fn_class); var ifn_1145 lang.IFn


				if linked_1144 == nil { ifn_1145 = lang.IFn_Cast(root_1143) } else { ifn_1145 = nil }; var arg_1146 any = from__0; if linked_1144 == nil { tmp6 = ifn_1145.Invoke_O__O(arg_1146) } else { tmp6 = linked_1144.(*aot_arbace_classes_types.A_arbace_classes_types_package_of_A).Invoke_O_O__O(root_1143, arg_1146) }
//line :303:1
				var tmp7 any = tmp6; var tmp8 any; var root_1147 any = A_arbace_classes_env_A_const_124.GetRawRoot__O(); var linked_1148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1147, aot_arbace_classes_types.A_arbace_classes_types_package_of_A_fn_class); var ifn_1149 lang.IFn


				if linked_1148 == nil { ifn_1149 = lang.IFn_Cast(root_1147) } else { ifn_1149 = nil }; var arg_1150 any = owner__4; if linked_1148 == nil { tmp8 = ifn_1149.Invoke_O__O(arg_1150) } else { tmp8 = linked_1148.(*aot_arbace_classes_types.A_arbace_classes_types_package_of_A).Invoke_O_O__O(root_1147, arg_1150) }
//line :303:1
				if lang.Util_Equiv_O_O__Z_NoInit(tmp7, tmp8) { return jrt.Boolean_TRUE.Ref() } else { var tmp9 any; var root_1151 any = A_arbace_classes_env_A_const_121.GetRawRoot__O(); var linked_1152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1151, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1153 lang.IFn



					if linked_1152 == nil { ifn_1153 = lang.IFn_Cast(root_1151) } else { ifn_1153 = nil }; var arg_1154 any = fl__3; var arg_1155 any = A_arbace_classes_env_A_const_125; if linked_1152 == nil { tmp9 = ifn_1153.Invoke_O_O__O(arg_1154, arg_1155) } else { tmp9 = linked_1152.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1151, arg_1154, arg_1155) }
//line :303:1
					if jrt.J2g_Truth(tmp9) {




						var tmp10 any; var root_1156 any = A_arbace_classes_env_A_const_97.GetRawRoot__O(); var linked_1157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1156, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1158 lang.IFn; if linked_1157 == nil { ifn_1158 = lang.IFn_Cast(root_1156) } else { ifn_1158 = nil }; var arg_1159 any; var tmp11 any = A_arbace_classes_env_accessible_QMARK__fn__28000143_A_New_O(owner__4); var tmp12 *jrt.Class; var fncls__1166 *jrt.Class = A_arbace_classes_env_accessible_QMARK__fn__28000143_A_fn_class; if fncls__1166 == nil { var fncls__1166d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_classes_env_accessible_QMARK__fn__28000143_A_fn_class = fncls__1166d; tmp12 = fncls__1166d } else { tmp12 = fncls__1166 }; arg_1159 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var arg_1160 any; var root_1167 any = A_arbace_classes_env_A_const_108.GetRawRoot__O(); var linked_1168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1167, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_1169 lang.IFn
						if linked_1168 == nil { ifn_1169 = lang.IFn_Cast(root_1167) } else { ifn_1169 = nil }; var arg_1170 any = A_arbace_classes_env_A_const_25.GetRawRoot__O(); var arg_1171 any; var root_1172 any = A_arbace_classes_env_A_const_109.GetRawRoot__O(); var linked_1173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1172, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_1174 lang.IFn; if linked_1173 == nil { ifn_1174 = lang.IFn_Cast(root_1172) } else { ifn_1174 = nil }; var arg_1175 any; var tmp13 any = A_arbace_classes_env_accessible_QMARK__fn__28000145_A_New(); var tmp14 *jrt.Class; var fncls__1181 *jrt.Class = A_arbace_classes_env_accessible_QMARK__fn__28000145_A_fn_class; if fncls__1181 == nil { var fncls__1181d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_classes_env_accessible_QMARK__fn__28000145_A_fn_class = fncls__1181d; tmp14 = fncls__1181d } else { tmp14 = fncls__1181 }; arg_1175 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); var arg_1176 any = from__0; if linked_1173 == nil { arg_1171 = ifn_1174.Invoke_O_O__O(arg_1175, arg_1176) } else { arg_1171 = linked_1173.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_1172, arg_1175, arg_1176) }; if linked_1168 == nil { arg_1160 = ifn_1169.Invoke_O_O__O(arg_1170, arg_1171) } else { arg_1160 = linked_1168.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_1167, arg_1170, arg_1171) }
//line :308:1
						if linked_1157 == nil { tmp10 = ifn_1158.Invoke_O_O__O(arg_1159, arg_1160) } else { tmp10 = linked_1157.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1156, arg_1159, arg_1160) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp10)).Ref() } else {
//line :303:1
							if A_arbace_classes_env_A_const_105 != nil { return jrt.Boolean_FALSE.Ref() } else { return nil } } } } } }




func A_arbace_classes_env_accessible_QMARK__fn__28000143_A_New_O(p0 any) *A_arbace_classes_env_accessible_QMARK__fn__28000143_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_accessible_QMARK__fn__28000143_A{}; t.Ctor_O(p0); return t }
//line :308:1
func (t *A_arbace_classes_env_accessible_QMARK__fn__28000143_A) Ctor_O(c__owner any) { t.F_owner = c__owner }
//line :308:1
func (t *A_arbace_classes_env_accessible_QMARK__fn__28000143_A) Invoke_O_O__O(self, p1__28000141_SHARP___1 any) any { var root_1161 any = A_arbace_classes_env_A_const_98.GetRawRoot__O(); var linked_1162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1161, A_arbace_classes_env_subclass_QMARK__A_fn_class); var ifn_1163 lang.IFn; if linked_1162 == nil { ifn_1163 = lang.IFn_Cast(root_1161) } else { ifn_1163 = nil }; var arg_1164 any = p1__28000141_SHARP___1; var arg_1165 any = t.F_owner; if linked_1162 == nil { return ifn_1163.Invoke_O_O__O(arg_1164, arg_1165) } else { return linked_1162.(*A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(root_1161, arg_1164, arg_1165) } }
func A_arbace_classes_env_accessible_QMARK__fn__28000145_A_New() *A_arbace_classes_env_accessible_QMARK__fn__28000145_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_accessible_QMARK__fn__28000145_A{}; t.Ctor(); return t }
//line :309:1
func (t *A_arbace_classes_env_accessible_QMARK__fn__28000145_A) Ctor() {}
//line :309:1
func (t *A_arbace_classes_env_accessible_QMARK__fn__28000145_A) Invoke_O_O__O(self, p1__28000142_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_classes_env_A_const_49; var tmp2 any; var root_1177 any = A_arbace_classes_env_A_const_94.GetRawRoot__O(); var linked_1178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1177, A_arbace_classes_env_info_A_fn_class); var ifn_1179 lang.IFn; if linked_1178 == nil { ifn_1179 = lang.IFn_Cast(root_1177) } else { ifn_1179 = nil }; var arg_1180 any = p1__28000142_SHARP___1; if linked_1178 == nil { tmp2 = ifn_1179.Invoke_O__O(arg_1180) } else { tmp2 = linked_1178.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1177, arg_1180) }; return tmp1.Invoke_O__O(tmp2) }


func A_arbace_classes_env_find_field_A_New() *A_arbace_classes_env_find_field_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_find_field_A{}; t.Ctor(); return t }
//line :312:1
func (t *A_arbace_classes_env_find_field_A) Ctor() {}
//line :312:1
func (t *A_arbace_classes_env_find_field_A) Invoke_O_O_O__O(self, n__0, name__1 any) any { var temp__1927000414__auto____3 any; var root_1182 any = A_arbace_classes_env_A_const_94.GetRawRoot__O(); var linked_1183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1182, A_arbace_classes_env_info_A_fn_class); var ifn_1184 lang.IFn; if



	linked_1183 == nil { ifn_1184 = lang.IFn_Cast(root_1182) } else { ifn_1184 = nil }; var arg_1185 any = n__0; if linked_1183 == nil { temp__1927000414__auto____3 = ifn_1184.Invoke_O__O(arg_1185) } else { temp__1927000414__auto____3 = linked_1183.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1182, arg_1185) }; if jrt.J2g_Truth(temp__1927000414__auto____3) { var i__4 any = temp__1927000414__auto____3; var or__1927000174__auto____5 any; var root_1186 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_1187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1186, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1188 lang.IFn
		if linked_1187 == nil { ifn_1188 = lang.IFn_Cast(root_1186) } else { ifn_1188 = nil }; var arg_1189 any; var root_1190 any = A_arbace_classes_env_A_const_87.GetRawRoot__O(); var linked_1191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1190, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1192 lang.IFn; if linked_1191 == nil { ifn_1192 = lang.IFn_Cast(root_1190) } else { ifn_1192 = nil }; var arg_1193 any; var tmp1 any = A_arbace_classes_env_find_field_fn__28000150_A_New_O(name__1); var tmp2 *jrt.Class; var fncls__1195 *jrt.Class = A_arbace_classes_env_find_field_fn__28000150_A_fn_class; if fncls__1195 == nil { var fncls__1195d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_classes_env_find_field_fn__28000150_A_fn_class = fncls__1195d; tmp2 = fncls__1195d } else { tmp2 = fncls__1195 }; arg_1193 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1194 any = A_arbace_classes_env_A_const_50.Invoke_O__O(i__4); if linked_1191 == nil { arg_1189 = ifn_1192.Invoke_O_O__O(arg_1193, arg_1194) } else { arg_1189 = linked_1191.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1190, arg_1193, arg_1194) }; if linked_1187 == nil { or__1927000174__auto____5 = ifn_1188.Invoke_O__O(arg_1189) } else { or__1927000174__auto____5 = linked_1187.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1186, arg_1189) }; if jrt.J2g_Truth(or__1927000174__auto____5) { return or__1927000174__auto____5 } else { var or__1927000174__auto____6 any; var root_1196 any = A_arbace_classes_env_A_const_97.GetRawRoot__O(); var linked_1197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1196, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1198 lang.IFn
			if linked_1197 == nil { ifn_1198 = lang.IFn_Cast(root_1196) } else { ifn_1198 = nil }; var arg_1199 any; var tmp3 any = A_arbace_classes_env_find_field_fn__28000152_A_New_O(name__1); var tmp4 *jrt.Class; var fncls__1206 *jrt.Class = A_arbace_classes_env_find_field_fn__28000152_A_fn_class; if fncls__1206 == nil { var fncls__1206d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_classes_env_find_field_fn__28000152_A_fn_class = fncls__1206d; tmp4 = fncls__1206d } else { tmp4 = fncls__1206 }; arg_1199 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_1200 any = A_arbace_classes_env_A_const_46.Invoke_O__O(i__4); if linked_1197 == nil { or__1927000174__auto____6 = ifn_1198.Invoke_O_O__O(arg_1199, arg_1200) } else { or__1927000174__auto____6 = linked_1197.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1196, arg_1199, arg_1200) }
//line :317:1
			if jrt.J2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else { var G__28000154__7_ any = A_arbace_classes_env_A_const_45.Invoke_O__O(i__4)

				if lang.Util_Identical_O_O__Z_NoInit(G__28000154__7_, nil) { return nil } else { var root_1207 any = A_arbace_classes_env_A_const_126.GetRawRoot__O(); var linked_1208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1207, A_arbace_classes_env_find_field_A_fn_class); var ifn_1209 lang.IFn; if linked_1208 == nil { ifn_1209 = lang.IFn_Cast(root_1207) } else { ifn_1209 = nil }; var arg_1210 any = G__28000154__7_; var arg_1211 any = name__1; if linked_1208 == nil { return ifn_1209.Invoke_O_O__O(arg_1210, arg_1211) } else { return linked_1208.(*A_arbace_classes_env_find_field_A).Invoke_O_O_O__O(root_1207, arg_1210, arg_1211) } } } } } else {
//line :316:1
					return nil } }
func A_arbace_classes_env_find_field_fn__28000150_A_New_O(p0 any) *A_arbace_classes_env_find_field_fn__28000150_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_find_field_fn__28000150_A{}; t.Ctor_O(p0); return t }
//line :317:1
func (t *A_arbace_classes_env_find_field_fn__28000150_A) Ctor_O(c__name any) { t.F_name = c__name }
//line :317:1
func (t *A_arbace_classes_env_find_field_fn__28000150_A) Invoke_O_O__O(self, p1__28000148_SHARP___1 any) any { var tmp1 any = t.F_name; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_classes_env_A_const_42.Invoke_O__O(p1__28000148_SHARP___1))).Ref() }
func A_arbace_classes_env_find_field_fn__28000152_A_New_O(p0 any) *A_arbace_classes_env_find_field_fn__28000152_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_find_field_fn__28000152_A{}; t.Ctor_O(p0); return t }
//line :318:1
func (t *A_arbace_classes_env_find_field_fn__28000152_A) Ctor_O(c__name any) { t.F_name = c__name }
//line :318:1
func (t *A_arbace_classes_env_find_field_fn__28000152_A) Invoke_O_O__O(self, p1__28000149_SHARP___1 any) any { var root_1201 any = A_arbace_classes_env_A_const_126.GetRawRoot__O(); var linked_1202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1201, A_arbace_classes_env_find_field_A_fn_class); var ifn_1203 lang.IFn; if linked_1202 == nil { ifn_1203 = lang.IFn_Cast(root_1201) } else { ifn_1203 = nil }; var arg_1204 any = p1__28000149_SHARP___1; var arg_1205 any = t.F_name; if linked_1202 == nil { return ifn_1203.Invoke_O_O__O(arg_1204, arg_1205) } else { return linked_1202.(*A_arbace_classes_env_find_field_A).Invoke_O_O_O__O(root_1201, arg_1204, arg_1205) } }


func A_arbace_classes_env_same_infos_QMARK__A_New() *A_arbace_classes_env_same_infos_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_same_infos_QMARK__A{}; t.Ctor(); return t }
//line :321:1
func (t *A_arbace_classes_env_same_infos_QMARK__A) Ctor() {}
//line :321:1
func (t *A_arbace_classes_env_same_infos_QMARK__A) Invoke_O_O_O__O(self, names__0, infos__1 any) any { { var n__3 int32 = lang.RT_Count_O__I_NoInit(names__0); var cs__4 any; var G__28000156__4_ any = A_arbace_classes_env_A_const_90.Get__O()



	if lang.Util_Identical_O_O__Z_NoInit(G__28000156__4_, nil) { cs__4 = nil } else { var root_1212 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_1213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1212, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1214 lang.IFn; if linked_1213 == nil { ifn_1214 = lang.IFn_Cast(root_1212) } else { ifn_1214 = nil }; var arg_1215 any = G__28000156__4_; if linked_1213 == nil { cs__4 = ifn_1214.Invoke_O__O(arg_1215) } else { cs__4 = linked_1213.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1212, arg_1215) } }
//line :321:1
	var i__5 int64 = 0; L1: for { var or__1927000174__auto____6 bool = lang.Util_Equiv_J_J__Z_NoInit(i__5, int64(n__3))





		if or__1927000174__auto____6 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____6).Ref() } else { var and__1927000168__auto____7 any; var c__7 any = lang.RT_Nth_O_I__O_NoInit(names__0, lang.RT_IntCast_J__I_NoInit(i__5)); var x__8 any = lang.RT_Aget_O1_I__O_NoInit(jrt.ObjectArray_Cast(infos__1), lang.RT_IntCast_J__I_NoInit(i__5)); var or__1927000174__auto____9 any; var and__1927000168__auto____9 any; var root_1216 any = A_arbace_classes_env_A_const_25.GetRawRoot__O(); var linked_1217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1216, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_1218 lang.IFn



			if linked_1217 == nil { ifn_1218 = lang.IFn_Cast(root_1216) } else { ifn_1218 = nil }; var arg_1219 any = x__8; if linked_1217 == nil { and__1927000168__auto____9 = ifn_1218.Invoke_O__O(arg_1219) } else { and__1927000168__auto____9 = linked_1217.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_1216, arg_1219) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 any; var root_1220 any = A_arbace_classes_env_A_const_25.GetRawRoot__O(); var linked_1221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1220, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_1222 lang.IFn; if linked_1221 == nil { ifn_1222 = lang.IFn_Cast(root_1220) } else { ifn_1222 = nil }; var arg_1223 any = cs__4; if linked_1221 == nil { and__1927000168__auto____10 = ifn_1222.Invoke_O__O(arg_1223) } else { and__1927000168__auto____10 = linked_1221.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_1220, arg_1223) }; if jrt.J2g_Truth(and__1927000168__auto____10) { var and__1927000168__auto____11 bool = lang.Util_Identical_O_O__Z_NoInit(x__8, lang.RT_Get_O_O__O_NoInit(cs__4, c__7)); if and__1927000168__auto____11 { var root_1224 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1224, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1226 lang.IFn; if linked_1225 == nil { ifn_1226 = lang.IFn_Cast(root_1224) } else { ifn_1226 = nil }; var arg_1227 any; var root_1228 any = A_arbace_classes_env_A_const_20.GetRawRoot__O(); var linked_1229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1228, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1230 lang.IFn; if linked_1229 == nil { ifn_1230 = lang.IFn_Cast(root_1228) } else { ifn_1230 = nil }; var arg_1231 any = c__7; var arg_1232 any = Lit_11; if linked_1229 == nil { arg_1227 = ifn_1230.Invoke_O_O__O(arg_1231, arg_1232) } else { arg_1227 = linked_1229.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1228, arg_1231, arg_1232) }; if linked_1225 == nil { or__1927000174__auto____9 = ifn_1226.Invoke_O__O(arg_1227) } else { or__1927000174__auto____9 = linked_1225.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1224, arg_1227) } } else { or__1927000174__auto____9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11).Ref() } } else { or__1927000174__auto____9 = and__1927000168__auto____10 } } else { or__1927000174__auto____9 = and__1927000168__auto____9 }; if jrt.J2g_Truth(or__1927000174__auto____9) { and__1927000168__auto____7 = or__1927000174__auto____9 } else {
				var tmp1 any; var root_1233 any = A_arbace_classes_env_A_const_94.GetRawRoot__O(); var linked_1234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1233, A_arbace_classes_env_info_A_fn_class); var ifn_1235 lang.IFn; if linked_1234 == nil { ifn_1235 = lang.IFn_Cast(root_1233) } else { ifn_1235 = nil }; var arg_1236 any = c__7; if linked_1234 == nil { tmp1 = ifn_1235.Invoke_O__O(arg_1236) } else { tmp1 = linked_1234.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1233, arg_1236) }; and__1927000168__auto____7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp1, x__8)).Ref() }
//line :328:1
			if jrt.J2g_Truth(and__1927000168__auto____7) {




				i__5 = lang.Numbers_Inc_J__J_NoInit(i__5); continue L1 } else {
//line :328:1
					return and__1927000168__auto____7 } } } }; /*line :321:1*/panic("j2g: unreachable") }













func A_arbace_classes_env_infos_now_A_New() *A_arbace_classes_env_infos_now_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_infos_now_A{}; t.Ctor(); return t }
//line :335:1
func (t *A_arbace_classes_env_infos_now_A) Ctor() {}
//line :335:1
func (t *A_arbace_classes_env_infos_now_A) Invoke_O_O__O(self, names__0 any) any { var a__2 any = lang.RT_Object_array_O__O1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(names__0)).Ref()).Ref(); var n__1927000701__auto____3 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_Count_O__I_NoInit(names__0)); var i__4 int64 = 0; L1: for {

	if lang.Numbers_Lt_J_J__Z_NoInit(i__4, n__1927000701__auto____3) { var tmp1 *jrt.RefArray = jrt.ObjectArray_Cast(a__2); var tmp2 int32 = lang.RT_IntCast_J__I_NoInit(i__4); var tmp3 any; var root_1237 any = A_arbace_classes_env_A_const_94.GetRawRoot__O(); var linked_1238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1237, A_arbace_classes_env_info_A_fn_class); var ifn_1239 lang.IFn; if linked_1238 == nil { ifn_1239 = lang.IFn_Cast(root_1237) } else { ifn_1239 = nil }; var arg_1240 any = lang.RT_Nth_O_I__O_NoInit(names__0, lang.RT_IntCast_J__I_NoInit(i__4)); if linked_1238 == nil { tmp3 = ifn_1239.Invoke_O__O(arg_1240) } else { tmp3 = linked_1238.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1237, arg_1240) }; lang.RT_Aset_O1_I_O__O_NoInit(tmp1, tmp2, tmp3); i__4 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__4); continue L1 }
//line :335:1
	break L1 }; return a__2 }
















func A_arbace_classes_env_all_supertypes_STAR__A_New() *A_arbace_classes_env_all_supertypes_STAR__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_all_supertypes_STAR__A{}; t.Ctor(); return t }
//line :352:1
func (t *A_arbace_classes_env_all_supertypes_STAR__A) Ctor() {}
//line :352:1
func (t *A_arbace_classes_env_all_supertypes_STAR__A) Invoke_O_O__O(self, n__0 any) any { { var chain__2 any; var root_1241 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_1242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1241, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1243 lang.IFn

	if linked_1242 == nil { ifn_1243 = lang.IFn_Cast(root_1241) } else { ifn_1243 = nil }; var arg_1244 any; var root_1245 any = A_arbace_classes_env_A_const_112.GetRawRoot__O(); var linked_1246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1245, A_arbace_classes_env_superclass_chain_A_fn_class); var ifn_1247 lang.IFn; if linked_1246 == nil { ifn_1247 = lang.IFn_Cast(root_1245) } else { ifn_1247 = nil }; var arg_1248 any = n__0; if linked_1246 == nil { arg_1244 = ifn_1247.Invoke_O__O(arg_1248) } else { arg_1244 = linked_1246.(*A_arbace_classes_env_superclass_chain_A).Invoke_O_O__O(root_1245, arg_1248) }; if linked_1242 == nil { chain__2 = ifn_1243.Invoke_O__O(arg_1244) } else { chain__2 = linked_1242.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1241, arg_1244) }
//line :352:1
	var out__3 any = chain__2; var seen__4 any; var root_1249 any = A_arbace_classes_env_A_const_111.GetRawRoot__O(); var linked_1250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1249, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_1251 lang.IFn


	if linked_1250 == nil { ifn_1251 = lang.IFn_Cast(root_1249) } else { ifn_1251 = nil }; var arg_1252 any = chain__2; if linked_1250 == nil { seen__4 = ifn_1251.Invoke_O__O(arg_1252) } else { seen__4 = linked_1250.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1249, arg_1252) }
//line :352:1
	var queue__5 any; var root_1253 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_1254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1253, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1255 lang.IFn


	if linked_1254 == nil { ifn_1255 = lang.IFn_Cast(root_1253) } else { ifn_1255 = nil }; var arg_1256 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_127.GetRawRoot__O()); var tmp2 any = A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A_New(); var tmp3 *jrt.Class; var fncls__1266 *jrt.Class = A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A_fn_class; if fncls__1266 == nil { var fncls__1266d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A_fn_class = fncls__1266d; tmp3 = fncls__1266d } else { tmp3 = fncls__1266 }; arg_1256 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), chain__2); if linked_1254 == nil { queue__5 = ifn_1255.Invoke_O__O(arg_1256) } else { queue__5 = linked_1254.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1253, arg_1256) }
//line :352:1
L1: for { var temp__1927000408__auto____6 any; var root_1267 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_1268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1267, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1269 lang.IFn



	if linked_1268 == nil { ifn_1269 = lang.IFn_Cast(root_1267) } else { ifn_1269 = nil }; var arg_1270 any = queue__5; if linked_1268 == nil { temp__1927000408__auto____6 = ifn_1269.Invoke_O__O(arg_1270) } else { temp__1927000408__auto____6 = linked_1268.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1267, arg_1270) }; if jrt.J2g_Truth(temp__1927000408__auto____6) { var vec__28000162__7 any = temp__1927000408__auto____6; var seq__28000163__8 any; var root_1271 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_1272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1271, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1273 lang.IFn; if linked_1272 == nil { ifn_1273 = lang.IFn_Cast(root_1271) } else { ifn_1273 = nil }; var arg_1274 any = vec__28000162__7; if linked_1272 == nil { seq__28000163__8 = ifn_1273.Invoke_O__O(arg_1274) } else { seq__28000163__8 = linked_1272.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1271, arg_1274) }; var first__28000164__9 any; var root_1275 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_1276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1275, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1277 lang.IFn; if linked_1276 == nil { ifn_1277 = lang.IFn_Cast(root_1275) } else { ifn_1277 = nil }; var arg_1278 any = seq__28000163__8; if linked_1276 == nil { first__28000164__9 = ifn_1277.Invoke_O__O(arg_1278) } else { first__28000164__9 = linked_1276.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1275, arg_1278) }; var seq__28000163__10 any; var root_1279 any = A_arbace_classes_env_A_const_57.GetRawRoot__O(); var linked_1280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1279, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1281 lang.IFn; if linked_1280 == nil { ifn_1281 = lang.IFn_Cast(root_1279) } else { ifn_1281 = nil }; var arg_1282 any = seq__28000163__8; if linked_1280 == nil { seq__28000163__10 = ifn_1281.Invoke_O__O(arg_1282) } else { seq__28000163__10 = linked_1280.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1279, arg_1282) }; var q__11 any = first__28000164__9; var more__12 any = seq__28000163__10
		if jrt.J2g_Truth(lang.IFn_Cast(seen__4).Invoke_O__O(q__11)) {
			var tmp4 any; var root_1296 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_1297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1296, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1298 lang.IFn; if linked_1297 == nil { ifn_1298 = lang.IFn_Cast(root_1296) } else { ifn_1298 = nil }; var arg_1299 any = more__12; if linked_1297 == nil { tmp4 = ifn_1298.Invoke_O__O(arg_1299) } else { tmp4 = linked_1297.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1296, arg_1299) }; out__3, seen__4, queue__5 = out__3, seen__4, tmp4; continue L1 } else {
				var tmp5 any; var root_1300 any = A_arbace_classes_env_A_const_10.GetRawRoot__O(); var linked_1301 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1300, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1302 lang.IFn; if linked_1301 == nil { ifn_1302 = lang.IFn_Cast(root_1300) } else { ifn_1302 = nil }; var arg_1303 any = out__3; var arg_1304 any = q__11; if linked_1301 == nil { tmp5 = ifn_1302.Invoke_O_O__O(arg_1303, arg_1304) } else { tmp5 = linked_1301.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1300, arg_1303, arg_1304) }; var tmp6 any = tmp5; var tmp7 any; var root_1305 any = A_arbace_classes_env_A_const_10.GetRawRoot__O(); var linked_1306 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1305, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1307 lang.IFn; if linked_1306 == nil { ifn_1307 = lang.IFn_Cast(root_1305) } else { ifn_1307 = nil }; var arg_1308 any = seen__4; var arg_1309 any = q__11; if linked_1306 == nil { tmp7 = ifn_1307.Invoke_O_O__O(arg_1308, arg_1309) } else { tmp7 = linked_1306.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1305, arg_1308, arg_1309) }; var tmp8 any = tmp7; var tmp9 any; var root_1310 any = A_arbace_classes_env_A_const_88.GetRawRoot__O(); var linked_1311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1310, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1312 lang.IFn; if linked_1311 == nil { ifn_1312 = lang.IFn_Cast(root_1310) } else { ifn_1312 = nil }; var arg_1313 any; var root_1315 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_1316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1315, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1317 lang.IFn; if linked_1316 == nil { ifn_1317 = lang.IFn_Cast(root_1315) } else { ifn_1317 = nil }; var arg_1318 any = more__12; if linked_1316 == nil { arg_1313 = ifn_1317.Invoke_O__O(arg_1318) } else { arg_1313 = linked_1316.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1315, arg_1318) }; var arg_1314 any; var tmp10 *lang.Keyword = A_arbace_classes_env_A_const_46; var tmp11 any; var root_1319 any = A_arbace_classes_env_A_const_94.GetRawRoot__O(); var linked_1320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1319, A_arbace_classes_env_info_A_fn_class); var ifn_1321 lang.IFn; if linked_1320 == nil { ifn_1321 = lang.IFn_Cast(root_1319) } else { ifn_1321 = nil }; var arg_1322 any = q__11; if linked_1320 == nil { tmp11 = ifn_1321.Invoke_O__O(arg_1322) } else { tmp11 = linked_1320.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1319, arg_1322) }; arg_1314 = tmp10.Invoke_O__O(tmp11); if linked_1311 == nil { tmp9 = ifn_1312.Invoke_O_O__O(arg_1313, arg_1314) } else { tmp9 = linked_1311.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1310, arg_1313, arg_1314) }; out__3, seen__4, queue__5 = tmp6, tmp8, tmp9; continue L1 } } else {
//line :356:1
					var G__28000165__7_ any = out__3; var tmp12 any; var and__1927000168__auto____8 any; var root_1283 any = A_arbace_classes_env_A_const_110.GetRawRoot__O(); var linked_1284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1283, A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_1285 lang.IFn



					if linked_1284 == nil { ifn_1285 = lang.IFn_Cast(root_1283) } else { ifn_1285 = nil }; var arg_1286 any = n__0; if linked_1284 == nil { and__1927000168__auto____8 = ifn_1285.Invoke_O__O(arg_1286) } else { and__1927000168__auto____8 = linked_1284.(*A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_1283, arg_1286) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_1287 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1287, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1289 lang.IFn; if linked_1288 == nil { ifn_1289 = lang.IFn_Cast(root_1287) } else { ifn_1289 = nil }; var arg_1290 any = lang.IFn_Cast(seen__4).Invoke_O__O(Lit_4); if linked_1288 == nil { tmp12 = ifn_1289.Invoke_O__O(arg_1290) } else { tmp12 = linked_1288.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1287, arg_1290) } } else { tmp12 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp12) { var root_1291 any = A_arbace_classes_env_A_const_10.GetRawRoot__O(); var linked_1292 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1291, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1293 lang.IFn; if linked_1292 == nil { ifn_1293 = lang.IFn_Cast(root_1291) } else { ifn_1293 = nil }; var arg_1294 any = G__28000165__7_; var arg_1295 any = Lit_4; if linked_1292 == nil { return ifn_1293.Invoke_O_O__O(arg_1294, arg_1295) } else { return linked_1292.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1291, arg_1294, arg_1295) } } else { return G__28000165__7_ } } } }; /*line :352:1*/panic("j2g: unreachable") }


func A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A_New() *A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A{}; t.Ctor(); return t }
//line :355:1
func (t *A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A) Ctor() {}
//line :355:1
func (t *A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A) Invoke_O_O__O(self, p1__28000159_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_classes_env_A_const_46; var tmp2 any; var root_1262 any = A_arbace_classes_env_A_const_94.GetRawRoot__O(); var linked_1263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1262, A_arbace_classes_env_info_A_fn_class); var ifn_1264 lang.IFn; if linked_1263 == nil { ifn_1264 = lang.IFn_Cast(root_1262) } else { ifn_1264 = nil }; var arg_1265 any = p1__28000159_SHARP___1; if linked_1263 == nil { tmp2 = ifn_1264.Invoke_O__O(arg_1265) } else { tmp2 = linked_1263.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1262, arg_1265) }; return tmp1.Invoke_O__O(tmp2) }






func A_arbace_classes_env_all_supertypes_A_New() *A_arbace_classes_env_all_supertypes_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_all_supertypes_A{}; t.Ctor(); return t }
//line :362:1
func (t *A_arbace_classes_env_all_supertypes_A) Ctor() {}
//line :362:1
func (t *A_arbace_classes_env_all_supertypes_A) Invoke_O_O__O(self, n__0 any) any { var e__2 any; if


	jrt.J2g_Truth(n__0) { e__2 = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_128.GetRawRoot__O())).Get_O__O(n__0) } else { e__2 = nil }; var tmp1 any; var and__1927000168__auto____3 any = e__2; if
	jrt.J2g_Truth(and__1927000168__auto____3) { var root_1323 any = A_arbace_classes_env_A_const_129.GetRawRoot__O(); var linked_1324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1323, A_arbace_classes_env_same_infos_QMARK__A_fn_class); var ifn_1325 lang.IFn; if linked_1324 == nil { ifn_1325 = lang.IFn_Cast(root_1323) } else { ifn_1325 = nil }; var arg_1326 any = lang.RT_Aget_O1_I__O_NoInit(jrt.ObjectArray_Cast(e__2), lang.RT_IntCast_J__I_NoInit(0)); var arg_1327 any = lang.RT_Aget_O1_I__O_NoInit(jrt.ObjectArray_Cast(e__2), lang.RT_IntCast_J__I_NoInit(1)); if linked_1324 == nil { tmp1 = ifn_1325.Invoke_O_O__O(arg_1326, arg_1327) } else { tmp1 = linked_1324.(*A_arbace_classes_env_same_infos_QMARK__A).Invoke_O_O_O__O(root_1323, arg_1326, arg_1327) } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		return lang.RT_Aget_O1_I__O_NoInit(jrt.ObjectArray_Cast(e__2), lang.RT_IntCast_J__I_NoInit(0)) } else {
//line :366:1
			var r__3 any; var root_1328 any = A_arbace_classes_env_A_const_130.GetRawRoot__O(); var linked_1329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1328, A_arbace_classes_env_all_supertypes_STAR__A_fn_class); var ifn_1330 lang.IFn

			if linked_1329 == nil { ifn_1330 = lang.IFn_Cast(root_1328) } else { ifn_1330 = nil }; var arg_1331 any = n__0; if linked_1329 == nil { r__3 = ifn_1330.Invoke_O__O(arg_1331) } else { r__3 = linked_1329.(*A_arbace_classes_env_all_supertypes_STAR__A).Invoke_O_O__O(root_1328, arg_1331) }
//line :366:1
			var infos__4 any; var root_1332 any = A_arbace_classes_env_A_const_131.GetRawRoot__O(); var linked_1333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1332, A_arbace_classes_env_infos_now_A_fn_class); var ifn_1334 lang.IFn


			if linked_1333 == nil { ifn_1334 = lang.IFn_Cast(root_1332) } else { ifn_1334 = nil }; var arg_1335 any = r__3; if linked_1333 == nil { infos__4 = ifn_1334.Invoke_O__O(arg_1335) } else { infos__4 = linked_1333.(*A_arbace_classes_env_infos_now_A).Invoke_O_O__O(root_1332, arg_1335)
			}
			var tmp2 any; var and__1927000168__auto____5 any = n__0; if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp3 any; var root_1336 any = A_arbace_classes_env_A_const_130.GetRawRoot__O(); var linked_1337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1336, A_arbace_classes_env_all_supertypes_STAR__A_fn_class); var ifn_1338 lang.IFn; if linked_1337 == nil { ifn_1338 = lang.IFn_Cast(root_1336) } else { ifn_1338 = nil }; var arg_1339 any = n__0; if linked_1337 == nil { tmp3 = ifn_1338.Invoke_O__O(arg_1339) } else { tmp3 = linked_1337.(*A_arbace_classes_env_all_supertypes_STAR__A).Invoke_O_O__O(root_1336, arg_1339) }; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(r__3, tmp3)).Ref() } else { tmp2 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp2) {
				jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_128.GetRawRoot__O())).Put_O_O__O(n__0, lang.RT_Object_array_O__O1_NoInit(lang.Tuple_Create_O_O__IPersistentVector(r__3, infos__4)).Ref()) }
//line :366:1
			return r__3 } }








func A_arbace_classes_env_params_key_A_New() *A_arbace_classes_env_params_key_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_params_key_A{}; t.Ctor(); return t }
//line :375:1
func (t *A_arbace_classes_env_params_key_A) Ctor() {}
//line :375:1
func (t *A_arbace_classes_env_params_key_A) Invoke_O_O__O(self, desc__0 any) any { var root_1340 any = A_arbace_classes_env_A_const_132.GetRawRoot__O(); var linked_1341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1340, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1342 lang.IFn; if linked_1341 == nil { ifn_1342 = lang.IFn_Cast(root_1340) } else { ifn_1342 = nil }; var arg_1343 any = desc__0; var arg_1344 any = A_arbace_classes_env_A_const_133; var arg_1345 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(jrt.NN(jrt.String_Cast(desc__0)).IndexOf_String__I(Lit_30)))).Ref(); if linked_1341 == nil { return ifn_1342.Invoke_O_O_O__O(arg_1343, arg_1344, arg_1345) } else { return linked_1341.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1340, arg_1343, arg_1344, arg_1345) } }

func A_arbace_classes_env_member_methods_STAR__A_New() *A_arbace_classes_env_member_methods_STAR__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_member_methods_STAR__A{}; t.Ctor(); return t }
//line :377:1
func (t *A_arbace_classes_env_member_methods_STAR__A) Ctor() {}
//line :377:1
func (t *A_arbace_classes_env_member_methods_STAR__A) Invoke_O_O_O_O__O(self, n__0, name__1, sups__2 any) any { { var G__28000172__4_ any = sups__2; var vec__28000173__5 any = G__28000172__4_; var seq__28000174__6 any; var root_1346 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_1347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1346, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1348 lang.IFn

	if linked_1347 == nil { ifn_1348 = lang.IFn_Cast(root_1346) } else { ifn_1348 = nil }; var arg_1349 any = vec__28000173__5; if linked_1347 == nil { seq__28000174__6 = ifn_1348.Invoke_O__O(arg_1349) } else { seq__28000174__6 = linked_1347.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1346, arg_1349) }
//line :377:1
	var first__28000175__7 any; var root_1350 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_1351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1350, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1352 lang.IFn

	if linked_1351 == nil { ifn_1352 = lang.IFn_Cast(root_1350) } else { ifn_1352 = nil }; var arg_1353 any = seq__28000174__6; if linked_1351 == nil { first__28000175__7 = ifn_1352.Invoke_O__O(arg_1353) } else { first__28000175__7 = linked_1351.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1350, arg_1353) }
//line :377:1
	var seq__28000174__8 any; var root_1354 any = A_arbace_classes_env_A_const_57.GetRawRoot__O(); var linked_1355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1354, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1356 lang.IFn

	if linked_1355 == nil { ifn_1356 = lang.IFn_Cast(root_1354) } else { ifn_1356 = nil }; var arg_1357 any = seq__28000174__6; if linked_1355 == nil { seq__28000174__8 = ifn_1356.Invoke_O__O(arg_1357) } else { seq__28000174__8 = linked_1355.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1354, arg_1357) }
//line :377:1
	var c__9 any = first__28000175__7; var more__10 any = seq__28000174__8; var seen__11 any = lang.PersistentHashSet_EMPTY.Ref(); var out__12 any = lang.PersistentVector_EMPTY.Ref(); var G__28000172__13_ any = G__28000172__4_; var seen__14 any = seen__11; var out__15 any = out__12; _ = c__9; _ = more__10; L1: for { var vec__28000176__16 any = G__28000172__13_; var seq__28000177__17 any; var root_1358 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_1359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1358, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1360 lang.IFn

		if linked_1359 == nil { ifn_1360 = lang.IFn_Cast(root_1358) } else { ifn_1360 = nil }; var arg_1361 any = vec__28000176__16; if linked_1359 == nil { seq__28000177__17 = ifn_1360.Invoke_O__O(arg_1361) } else { seq__28000177__17 = linked_1359.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1358, arg_1361) }
//line :377:1
		var first__28000178__18 any; var root_1362 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_1363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1362, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1364 lang.IFn

		if linked_1363 == nil { ifn_1364 = lang.IFn_Cast(root_1362) } else { ifn_1364 = nil }; var arg_1365 any = seq__28000177__17; if linked_1363 == nil { first__28000178__18 = ifn_1364.Invoke_O__O(arg_1365) } else { first__28000178__18 = linked_1363.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1362, arg_1365) }
//line :377:1
		var seq__28000177__19 any; var root_1366 any = A_arbace_classes_env_A_const_57.GetRawRoot__O(); var linked_1367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1366, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1368 lang.IFn

		if linked_1367 == nil { ifn_1368 = lang.IFn_Cast(root_1366) } else { ifn_1368 = nil }; var arg_1369 any = seq__28000177__17; if linked_1367 == nil { seq__28000177__19 = ifn_1368.Invoke_O__O(arg_1369) } else { seq__28000177__19 = linked_1367.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1366, arg_1369) }
//line :377:1
		var c__20 any = first__28000178__18; var more__21 any = seq__28000177__19; var seen__22 any = seen__14; var out__23 any = out__15; var tmp1 any; var root_1370 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1370, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1372 lang.IFn


		if linked_1371 == nil { ifn_1372 = lang.IFn_Cast(root_1370) } else { ifn_1372 = nil }; var arg_1373 any = c__20; if linked_1371 == nil { tmp1 = ifn_1372.Invoke_O__O(arg_1373) } else { tmp1 = linked_1371.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1370, arg_1373) }; if jrt.J2g_Truth(tmp1) { return out__23 } else { var ms__24 any; var iter__1927001039__auto____24 any; var tmp2 any = A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A_New_O_O_O_O(seen__22, name__1, n__0, c__20); var tmp3 *jrt.Class
			var fncls__1538 /*line :380:1*/*jrt.Class = A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A_fn_class

			if fncls__1538 == nil { var fncls__1538d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A_fn_class = fncls__1538d; tmp3 = fncls__1538d } else { tmp3 = fncls__1538 }; iter__1927001039__auto____24 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp4 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____24); var tmp5 *lang.Keyword = A_arbace_classes_env_A_const_77; var tmp6 any; var root_1539 any = A_arbace_classes_env_A_const_96.GetRawRoot__O(); var linked_1540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1539, A_arbace_classes_env_info_BANG__A_fn_class); var ifn_1541 lang.IFn; if linked_1540 == nil { ifn_1541 = lang.IFn_Cast(root_1539) } else { ifn_1541 = nil }; var arg_1542 any = c__20; if linked_1540 == nil { tmp6 = ifn_1541.Invoke_O__O(arg_1542) } else { tmp6 = linked_1540.(*A_arbace_classes_env_info_BANG__A).Invoke_O_O__O(root_1539, arg_1542) }; ms__24 = tmp4.Invoke_O__O(tmp5.Invoke_O__O(tmp6))






			var tmp7 any; var root_1543 any = A_arbace_classes_env_A_const_88.GetRawRoot__O(); var linked_1544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1543, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1545 lang.IFn; if linked_1544 == nil { ifn_1545 = lang.IFn_Cast(root_1543) } else { ifn_1545 = nil }; var arg_1546 any = seen__22; var arg_1547 any; var root_1548 any = A_arbace_classes_env_A_const_80.GetRawRoot__O(); var linked_1549 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1548, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1550 lang.IFn; if linked_1549 == nil { ifn_1550 = lang.IFn_Cast(root_1548) } else { ifn_1550 = nil }; var arg_1551 any; var root_1553 any = A_arbace_classes_env_A_const_137.GetRawRoot__O(); var linked_1554 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1553, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_1555 lang.IFn; if linked_1554 == nil { ifn_1555 = lang.IFn_Cast(root_1553) } else { ifn_1555 = nil }; var arg_1556 any = A_arbace_classes_env_A_const_136.GetRawRoot__O(); var arg_1557 any = A_arbace_classes_env_A_const_60; if linked_1554 == nil { arg_1551 = ifn_1555.Invoke_O_O__O(arg_1556, arg_1557) } else { arg_1551 = linked_1554.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_1553, arg_1556, arg_1557) }; var arg_1552 any = ms__24; if linked_1549 == nil { arg_1547 = ifn_1550.Invoke_O_O__O(arg_1551, arg_1552) } else { arg_1547 = linked_1549.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1548, arg_1551, arg_1552) }; if linked_1544 == nil { tmp7 = ifn_1545.Invoke_O_O__O(arg_1546, arg_1547) } else { tmp7 = linked_1544.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1543, arg_1546, arg_1547) }; var tmp8 any = tmp7; var tmp9 any; var root_1558 any = A_arbace_classes_env_A_const_88.GetRawRoot__O(); var linked_1559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1558, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1560 lang.IFn; if linked_1559 == nil { ifn_1560 = lang.IFn_Cast(root_1558) } else { ifn_1560 = nil }; var arg_1561 any = out__23; var arg_1562 any = ms__24; if linked_1559 == nil { tmp9 = ifn_1560.Invoke_O_O__O(arg_1561, arg_1562) } else { tmp9 = linked_1559.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1558, arg_1561, arg_1562) }; G__28000172__13_, seen__14, out__15 = more__21, tmp8, tmp9; continue L1 } } }; /*line :377:1*/panic("j2g: unreachable") }




func A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :382:1
func (t *A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A) Ctor_O_O_O_O(c__seen, c__name, c__n, c__c any) { t.F_seen = c__seen; t.F_name = c__name; t.F_n = c__n; t.F_c = c__c }
//line :382:1
func (t *A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A) Invoke_O_O__O(self, s__28000180__1 any) any { var tmp1 any = A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A_New_O_O_O_O_O_O(self, t.F_seen, t.F_name, t.F_n, t.F_c, s__28000180__1); var tmp2 *jrt.Class; var fncls__1537 *jrt.Class = A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A_fn_class; if fncls__1537 == nil { var fncls__1537d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A_fn_class = fncls__1537d; tmp2 = fncls__1537d } else { tmp2 = fncls__1537 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :382:1
func A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :382:1
func (t *A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A) Ctor_O_O_O_O_O_O(c__iter__28000179, c__seen, c__name, c__n, c__c, c__s__28000180 any) { t.F_iter__28000179 = c__iter__28000179; t.F_seen = c__seen; t.F_name = c__name; t.F_n = c__n; t.F_c = c__c; t.F_s__28000180 = c__s__28000180 }
//line :382:1
func (t *A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A) Invoke_O__O(self any) any { { var s__28000180__1 any; var t_ any = t.F_s__28000180; t.F_s__28000180 = nil; s__28000180__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1374 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_1375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1374, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1376 lang.IFn; if linked_1375 == nil { ifn_1376 = lang.IFn_Cast(root_1374) } else { ifn_1376 = nil }; var arg_1377 any = s__28000180__1; if linked_1375 == nil { temp__1927000414__auto____2 = ifn_1376.Invoke_O__O(arg_1377) } else { temp__1927000414__auto____2 = linked_1375.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1374, arg_1377) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__28000180__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1378 any = A_arbace_classes_env_A_const_54.GetRawRoot__O(); var linked_1379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1378, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1380 lang.IFn; if linked_1379 == nil { ifn_1380 = lang.IFn_Cast(root_1378) } else { ifn_1380 = nil }; var arg_1381 any = s__28000180__3; if linked_1379 == nil { tmp1 = ifn_1380.Invoke_O__O(arg_1381) } else { tmp1 = linked_1379.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1378, arg_1381) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1382 any = A_arbace_classes_env_A_const_55.GetRawRoot__O(); var linked_1383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1382, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1384 lang.IFn; if linked_1383 == nil { ifn_1384 = lang.IFn_Cast(root_1382) } else { ifn_1384 = nil }; var arg_1385 any = s__28000180__3; if linked_1383 == nil { c__1927001037__auto____4 = ifn_1384.Invoke_O__O(arg_1385) } else { c__1927001037__auto____4 = linked_1383.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1382, arg_1385) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__28000182__6 any; var root_1386 any = A_arbace_classes_env_A_const_56.GetRawRoot__O(); var linked_1387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1386, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1388 lang.IFn; if linked_1387 == nil { ifn_1388 = lang.IFn_Cast(root_1386) } else { ifn_1388 = nil }; var arg_1389 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1387 == nil { b__28000182__6 = ifn_1388.Invoke_O__O(arg_1389) } else { b__28000182__6 = linked_1387.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1386, arg_1389) }; var tmp2 any = A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A_New_O_O_O_O_I_O_O(t.F_seen, t.F_name, t.F_n, t.F_c, size__1927001038__auto____5, b__28000182__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1438 *jrt.Class = A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A_fn_class; if fncls__1438 == nil { var fncls__1438d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A_fn_class = fncls__1438d; tmp3 = fncls__1438d } else { tmp3 = fncls__1438 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1439 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_1440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1439, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1441 lang.IFn; if linked_1440 == nil { ifn_1441 = lang.IFn_Cast(root_1439) } else { ifn_1441 = nil }; var arg_1442 any; var root_1444 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_1445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1444, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1446 lang.IFn; if linked_1445 == nil { ifn_1446 = lang.IFn_Cast(root_1444) } else { ifn_1446 = nil }; var arg_1447 any = b__28000182__6; if linked_1445 == nil { arg_1442 = ifn_1446.Invoke_O__O(arg_1447) } else { arg_1442 = linked_1445.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1444, arg_1447) }; var arg_1443 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__28000179); var tmp5 any; var root_1448 any = A_arbace_classes_env_A_const_70.GetRawRoot__O(); var linked_1449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1448, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1450 lang.IFn; if linked_1449 == nil { ifn_1450 = lang.IFn_Cast(root_1448) } else { ifn_1450 = nil }; var arg_1451 any = s__28000180__3; if linked_1449 == nil { tmp5 = ifn_1450.Invoke_O__O(arg_1451) } else { tmp5 = linked_1449.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1448, arg_1451) }; arg_1443 = tmp4.Invoke_O__O(tmp5); if linked_1440 == nil { return ifn_1441.Invoke_O_O__O(arg_1442, arg_1443) } else { return linked_1440.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1439, arg_1442, arg_1443) } } else { var root_1452 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_1453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1452, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1454 lang.IFn; if linked_1453 == nil { ifn_1454 = lang.IFn_Cast(root_1452) } else { ifn_1454 = nil }; var arg_1455 any; var root_1457 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_1458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1457, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1459 lang.IFn; if linked_1458 == nil { ifn_1459 = lang.IFn_Cast(root_1457) } else { ifn_1459 = nil }; var arg_1460 any = b__28000182__6; if linked_1458 == nil { arg_1455 = ifn_1459.Invoke_O__O(arg_1460) } else { arg_1455 = linked_1458.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1457, arg_1460) }; var arg_1456 any; if linked_1453 == nil { return ifn_1454.Invoke_O_O__O(arg_1455, arg_1456) } else { return linked_1453.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1452, arg_1455, arg_1456) } } } else { var m__4 any; var root_1461 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_1462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1461, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1463 lang.IFn; if linked_1462 == nil { ifn_1463 = lang.IFn_Cast(root_1461) } else { ifn_1463 = nil }; var arg_1464 any = s__28000180__3; if linked_1462 == nil { m__4 = ifn_1463.Invoke_O__O(arg_1464) } else { m__4 = linked_1462.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1461, arg_1464) }; var tmp6 any = t.F_name; if lang.Util_Equiv_O_O__Z_NoInit(tmp6, A_arbace_classes_env_A_const_42.Invoke_O__O(m__4)) { var tmp7 any; var root_1465 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1465, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1467 lang.IFn

	if linked_1466 == nil { ifn_1467 = lang.IFn_Cast(root_1465) } else { ifn_1467 = nil }; var arg_1468 any; var root_1469 any = A_arbace_classes_env_A_const_121.GetRawRoot__O(); var linked_1470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1469, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1471 lang.IFn; if linked_1470 == nil { ifn_1471 = lang.IFn_Cast(root_1469) } else { ifn_1471 = nil }; var arg_1472 any = A_arbace_classes_env_A_const_43.Invoke_O__O(m__4); var arg_1473 any = A_arbace_classes_env_A_const_134; if linked_1470 == nil { arg_1468 = ifn_1471.Invoke_O_O__O(arg_1472, arg_1473) } else { arg_1468 = linked_1470.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1469, arg_1472, arg_1473) }; if linked_1466 == nil { tmp7 = ifn_1467.Invoke_O__O(arg_1468) } else { tmp7 = linked_1466.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1465, arg_1468) }
//line :382:1
	if jrt.J2g_Truth(tmp7) { var tmp8 any; var or__1927000174__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(t.F_c, t.F_n)


		if or__1927000174__auto____5 { tmp8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var root_1474 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1474, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1476 lang.IFn; if linked_1475 == nil { ifn_1476 = lang.IFn_Cast(root_1474) } else { ifn_1476 = nil }; var arg_1477 any; var root_1478 any = A_arbace_classes_env_A_const_121.GetRawRoot__O(); var linked_1479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1478, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1480 lang.IFn; if linked_1479 == nil { ifn_1480 = lang.IFn_Cast(root_1478) } else { ifn_1480 = nil }; var arg_1481 any = A_arbace_classes_env_A_const_43.Invoke_O__O(m__4); var arg_1482 any = A_arbace_classes_env_A_const_123; if linked_1479 == nil { arg_1477 = ifn_1480.Invoke_O_O__O(arg_1481, arg_1482) } else { arg_1477 = linked_1479.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1478, arg_1481, arg_1482) }; if linked_1475 == nil { tmp8 = ifn_1476.Invoke_O__O(arg_1477) } else { tmp8 = linked_1475.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1474, arg_1477) } }
//line :382:1
		if jrt.J2g_Truth(tmp8) { var tmp9 any; var or__1927000174__auto____5_2 bool = lang.Util_Equiv_O_O__Z_NoInit(t.F_c, t.F_n)



			if or__1927000174__auto____5_2 { tmp9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5_2).Ref() } else { var or__1927000174__auto____6 any; var root_1483 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1483, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1485 lang.IFn; if linked_1484 == nil { ifn_1485 = lang.IFn_Cast(root_1483) } else { ifn_1485 = nil }; var arg_1486 any; var root_1487 any = A_arbace_classes_env_A_const_110.GetRawRoot__O(); var linked_1488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1487, A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_1489 lang.IFn; if linked_1488 == nil { ifn_1489 = lang.IFn_Cast(root_1487) } else { ifn_1489 = nil }; var arg_1490 any = t.F_c; if linked_1488 == nil { arg_1486 = ifn_1489.Invoke_O__O(arg_1490) } else { arg_1486 = linked_1488.(*A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_1487, arg_1490) }; if linked_1484 == nil { or__1927000174__auto____6 = ifn_1485.Invoke_O__O(arg_1486) } else { or__1927000174__auto____6 = linked_1484.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1483, arg_1486) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp9 = or__1927000174__auto____6 } else { var root_1491 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1491, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1493 lang.IFn; if linked_1492 == nil { ifn_1493 = lang.IFn_Cast(root_1491) } else { ifn_1493 = nil }; var arg_1494 any; var root_1495 any = A_arbace_classes_env_A_const_121.GetRawRoot__O(); var linked_1496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1495, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1497 lang.IFn; if linked_1496 == nil { ifn_1497 = lang.IFn_Cast(root_1495) } else { ifn_1497 = nil }; var arg_1498 any = A_arbace_classes_env_A_const_43.Invoke_O__O(m__4); var arg_1499 any = A_arbace_classes_env_A_const_135; if linked_1496 == nil { arg_1494 = ifn_1497.Invoke_O_O__O(arg_1498, arg_1499) } else { arg_1494 = linked_1496.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1495, arg_1498, arg_1499) }; if linked_1492 == nil { tmp9 = ifn_1493.Invoke_O__O(arg_1494) } else { tmp9 = linked_1492.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1491, arg_1494) } } }
//line :382:1
			if jrt.J2g_Truth(tmp9) { var tmp10 any; var root_1500 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1500, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1502 lang.IFn




				if linked_1501 == nil { ifn_1502 = lang.IFn_Cast(root_1500) } else { ifn_1502 = nil }; var arg_1503 any; var tmp11 lang.IFn = lang.IFn_Cast(t.F_seen); var tmp12 any; var root_1504 any = A_arbace_classes_env_A_const_136.GetRawRoot__O(); var linked_1505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1504, A_arbace_classes_env_params_key_A_fn_class); var ifn_1506 lang.IFn; if linked_1505 == nil { ifn_1506 = lang.IFn_Cast(root_1504) } else { ifn_1506 = nil }; var arg_1507 any = A_arbace_classes_env_A_const_60.Invoke_O__O(m__4); if linked_1505 == nil { tmp12 = ifn_1506.Invoke_O__O(arg_1507) } else { tmp12 = linked_1505.(*A_arbace_classes_env_params_key_A).Invoke_O_O__O(root_1504, arg_1507) }; arg_1503 = tmp11.Invoke_O__O(tmp12); if linked_1501 == nil { tmp10 = ifn_1502.Invoke_O__O(arg_1503) } else { tmp10 = linked_1501.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1500, arg_1503) }
//line :382:1
				if jrt.J2g_Truth(tmp10) { var root_1508 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_1509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1508, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1510 lang.IFn; if linked_1509 == nil { ifn_1510 = lang.IFn_Cast(root_1508) } else { ifn_1510 = nil }; var arg_1511 any = m__4; var arg_1512 any; var tmp13 lang.IFn = lang.IFn_Cast(t.F_iter__28000179); var tmp14 any; var root_1513 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_1514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1513, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1515 lang.IFn; if linked_1514 == nil { ifn_1515 = lang.IFn_Cast(root_1513) } else { ifn_1515 = nil }; var arg_1516 any = s__28000180__3; if linked_1514 == nil { tmp14 = ifn_1515.Invoke_O__O(arg_1516) } else { tmp14 = linked_1514.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1513, arg_1516) }; arg_1512 = tmp13.Invoke_O__O(tmp14); if linked_1509 == nil { return ifn_1510.Invoke_O_O__O(arg_1511, arg_1512) } else { return linked_1509.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1508, arg_1511, arg_1512) } } else { var tmp15 any; var root_1517 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_1518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1517, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1519 lang.IFn; if linked_1518 == nil { ifn_1519 = lang.IFn_Cast(root_1517) } else { ifn_1519 = nil }; var arg_1520 any = s__28000180__3; if linked_1518 == nil { tmp15 = ifn_1519.Invoke_O__O(arg_1520) } else { tmp15 = linked_1518.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1517, arg_1520) }; s__28000180__1 = tmp15; continue L1 } } else { var tmp16 any; var root_1521 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_1522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1521, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1523 lang.IFn; if linked_1522 == nil { ifn_1523 = lang.IFn_Cast(root_1521) } else { ifn_1523 = nil }; var arg_1524 any = s__28000180__3; if linked_1522 == nil { tmp16 = ifn_1523.Invoke_O__O(arg_1524) } else { tmp16 = linked_1522.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1521, arg_1524) }; s__28000180__1 = tmp16; continue L1 } } else { var tmp17 any; var root_1525 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_1526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1525, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1527 lang.IFn; if linked_1526 == nil { ifn_1527 = lang.IFn_Cast(root_1525) } else { ifn_1527 = nil }; var arg_1528 any = s__28000180__3; if linked_1526 == nil { tmp17 = ifn_1527.Invoke_O__O(arg_1528) } else { tmp17 = linked_1526.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1525, arg_1528) }; s__28000180__1 = tmp17; continue L1 } } else { var tmp18 any; var root_1529 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_1530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1529, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1531 lang.IFn; if linked_1530 == nil { ifn_1531 = lang.IFn_Cast(root_1529) } else { ifn_1531 = nil }; var arg_1532 any = s__28000180__3; if linked_1530 == nil { tmp18 = ifn_1531.Invoke_O__O(arg_1532) } else { tmp18 = linked_1530.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1529, arg_1532) }; s__28000180__1 = tmp18; continue L1 } } else { var tmp19 any; var root_1533 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_1534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1533, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1535 lang.IFn; if linked_1534 == nil { ifn_1535 = lang.IFn_Cast(root_1533) } else { ifn_1535 = nil }; var arg_1536 any = s__28000180__3; if linked_1534 == nil { tmp19 = ifn_1535.Invoke_O__O(arg_1536) } else { tmp19 = linked_1534.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1533, arg_1536) }; s__28000180__1 = tmp19; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :382:1
func A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A_New_O_O_O_O_I_O_O(p0, p1, p2, p3 any, p4 int32, p5, p6 any) *A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A{}; t.Ctor_O_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :382:1
func (t *A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A) Ctor_O_O_O_O_I_O_O(c__seen, c__name, c__n, c__c any, c__size__1927001038__auto__ int32, c__b__28000182, c__c__1927001037__auto__ any) { t.F_seen = c__seen; t.F_name = c__name; t.F_n = c__n; t.F_c = c__c; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__28000182 = c__b__28000182; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :382:1
func (t *A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A) Invoke_O__O(self any) any { { var i__28000181__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__28000181__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__28000181__1)); var tmp2 any = t.F_name; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_classes_env_A_const_42.Invoke_O__O(m__2)) { var tmp3 any; var root_1390 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1390, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1392 lang.IFn

	if linked_1391 == nil { ifn_1392 = lang.IFn_Cast(root_1390) } else { ifn_1392 = nil }; var arg_1393 any; var root_1394 any = A_arbace_classes_env_A_const_121.GetRawRoot__O(); var linked_1395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1394, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1396 lang.IFn; if linked_1395 == nil { ifn_1396 = lang.IFn_Cast(root_1394) } else { ifn_1396 = nil }; var arg_1397 any = A_arbace_classes_env_A_const_43.Invoke_O__O(m__2); var arg_1398 any = A_arbace_classes_env_A_const_134; if linked_1395 == nil { arg_1393 = ifn_1396.Invoke_O_O__O(arg_1397, arg_1398) } else { arg_1393 = linked_1395.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1394, arg_1397, arg_1398) }; if linked_1391 == nil { tmp3 = ifn_1392.Invoke_O__O(arg_1393) } else { tmp3 = linked_1391.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1390, arg_1393) }
//line :382:1
	if jrt.J2g_Truth(tmp3) { var tmp4 any; var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(t.F_c, t.F_n)


		if or__1927000174__auto____3 { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var root_1399 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1399, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1401 lang.IFn; if linked_1400 == nil { ifn_1401 = lang.IFn_Cast(root_1399) } else { ifn_1401 = nil }; var arg_1402 any; var root_1403 any = A_arbace_classes_env_A_const_121.GetRawRoot__O(); var linked_1404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1403, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1405 lang.IFn; if linked_1404 == nil { ifn_1405 = lang.IFn_Cast(root_1403) } else { ifn_1405 = nil }; var arg_1406 any = A_arbace_classes_env_A_const_43.Invoke_O__O(m__2); var arg_1407 any = A_arbace_classes_env_A_const_123; if linked_1404 == nil { arg_1402 = ifn_1405.Invoke_O_O__O(arg_1406, arg_1407) } else { arg_1402 = linked_1404.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1403, arg_1406, arg_1407) }; if linked_1400 == nil { tmp4 = ifn_1401.Invoke_O__O(arg_1402) } else { tmp4 = linked_1400.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1399, arg_1402) } }
//line :382:1
		if jrt.J2g_Truth(tmp4) { var tmp5 any; var or__1927000174__auto____3_2 bool = lang.Util_Equiv_O_O__Z_NoInit(t.F_c, t.F_n)



			if or__1927000174__auto____3_2 { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3_2).Ref() } else { var or__1927000174__auto____4 any; var root_1408 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1408, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1410 lang.IFn; if linked_1409 == nil { ifn_1410 = lang.IFn_Cast(root_1408) } else { ifn_1410 = nil }; var arg_1411 any; var root_1412 any = A_arbace_classes_env_A_const_110.GetRawRoot__O(); var linked_1413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1412, A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_1414 lang.IFn; if linked_1413 == nil { ifn_1414 = lang.IFn_Cast(root_1412) } else { ifn_1414 = nil }; var arg_1415 any = t.F_c; if linked_1413 == nil { arg_1411 = ifn_1414.Invoke_O__O(arg_1415) } else { arg_1411 = linked_1413.(*A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_1412, arg_1415) }; if linked_1409 == nil { or__1927000174__auto____4 = ifn_1410.Invoke_O__O(arg_1411) } else { or__1927000174__auto____4 = linked_1409.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1408, arg_1411) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp5 = or__1927000174__auto____4 } else { var root_1416 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1416, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1418 lang.IFn; if linked_1417 == nil { ifn_1418 = lang.IFn_Cast(root_1416) } else { ifn_1418 = nil }; var arg_1419 any; var root_1420 any = A_arbace_classes_env_A_const_121.GetRawRoot__O(); var linked_1421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1420, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1422 lang.IFn; if linked_1421 == nil { ifn_1422 = lang.IFn_Cast(root_1420) } else { ifn_1422 = nil }; var arg_1423 any = A_arbace_classes_env_A_const_43.Invoke_O__O(m__2); var arg_1424 any = A_arbace_classes_env_A_const_135; if linked_1421 == nil { arg_1419 = ifn_1422.Invoke_O_O__O(arg_1423, arg_1424) } else { arg_1419 = linked_1421.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1420, arg_1423, arg_1424) }; if linked_1417 == nil { tmp5 = ifn_1418.Invoke_O__O(arg_1419) } else { tmp5 = linked_1417.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1416, arg_1419) } } }
//line :382:1
			if jrt.J2g_Truth(tmp5) { var tmp6 any; var root_1425 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1425, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1427 lang.IFn




				if linked_1426 == nil { ifn_1427 = lang.IFn_Cast(root_1425) } else { ifn_1427 = nil }; var arg_1428 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_seen); var tmp8 any; var root_1429 any = A_arbace_classes_env_A_const_136.GetRawRoot__O(); var linked_1430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1429, A_arbace_classes_env_params_key_A_fn_class); var ifn_1431 lang.IFn; if linked_1430 == nil { ifn_1431 = lang.IFn_Cast(root_1429) } else { ifn_1431 = nil }; var arg_1432 any = A_arbace_classes_env_A_const_60.Invoke_O__O(m__2); if linked_1430 == nil { tmp8 = ifn_1431.Invoke_O__O(arg_1432) } else { tmp8 = linked_1430.(*A_arbace_classes_env_params_key_A).Invoke_O_O__O(root_1429, arg_1432) }; arg_1428 = tmp7.Invoke_O__O(tmp8); if linked_1426 == nil { tmp6 = ifn_1427.Invoke_O__O(arg_1428) } else { tmp6 = linked_1426.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1425, arg_1428) }
//line :382:1
				if jrt.J2g_Truth(tmp6) { var root_1433 any = A_arbace_classes_env_A_const_62.GetRawRoot__O(); var linked_1434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1433, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1435 lang.IFn; if linked_1434 == nil { ifn_1435 = lang.IFn_Cast(root_1433) } else { ifn_1435 = nil }; var arg_1436 any = t.F_b__28000182; var arg_1437 any = m__2; if linked_1434 == nil { ifn_1435.Invoke_O_O__O(arg_1436, arg_1437) } else { linked_1434.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1433, arg_1436, arg_1437) }; i__28000181__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000181__1); continue L1 } else { i__28000181__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000181__1); continue L1 } } else { i__28000181__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000181__1); continue L1 } } else { i__28000181__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000181__1); continue L1 } } else { i__28000181__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000181__1); continue L1 } } else { i__28000181__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000181__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_classes_env_member_methods_A_New() *A_arbace_classes_env_member_methods_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_member_methods_A{}; t.Ctor(); return t }
//line :391:1
func (t *A_arbace_classes_env_member_methods_A) Ctor() {}
//line :391:1
func (t *A_arbace_classes_env_member_methods_A) Invoke_O_O_O__O(self, n__0, name__1 any) any {



	var tmp1 any; var root_1563 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1563, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1565 lang.IFn; if linked_1564 == nil { ifn_1565 = lang.IFn_Cast(root_1563) } else { ifn_1565 = nil }; var arg_1566 any; var and__1927000168__auto____3 any; var root_1567 any = A_arbace_classes_env_A_const_138.GetRawRoot__O(); var linked_1568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1567, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1569 lang.IFn; if linked_1568 == nil { ifn_1569 = lang.IFn_Cast(root_1567) } else { ifn_1569 = nil }; var arg_1570 any = n__0; if linked_1568 == nil { and__1927000168__auto____3 = ifn_1569.Invoke_O__O(arg_1570) } else { and__1927000168__auto____3 = linked_1568.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1567, arg_1570) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_1571 any = A_arbace_classes_env_A_const_138.GetRawRoot__O(); var linked_1572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1571, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1573 lang.IFn; if linked_1572 == nil { ifn_1573 = lang.IFn_Cast(root_1571) } else { ifn_1573 = nil }; var arg_1574 any = name__1; if linked_1572 == nil { arg_1566 = ifn_1573.Invoke_O__O(arg_1574) } else { arg_1566 = linked_1572.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1571, arg_1574) } } else { arg_1566 = and__1927000168__auto____3 }; if linked_1564 == nil { tmp1 = ifn_1565.Invoke_O__O(arg_1566) } else { tmp1 = linked_1564.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1563, arg_1566) }; if jrt.J2g_Truth(tmp1) {
		var root_1575 any = A_arbace_classes_env_A_const_139.GetRawRoot__O(); var linked_1576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1575, A_arbace_classes_env_member_methods_STAR__A_fn_class); var ifn_1577 lang.IFn; if linked_1576 == nil { ifn_1577 = lang.IFn_Cast(root_1575) } else { ifn_1577 = nil }; var arg_1578 any = n__0; var arg_1579 any = name__1; var arg_1580 any; var root_1581 any = A_arbace_classes_env_A_const_140.GetRawRoot__O(); var linked_1582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1581, A_arbace_classes_env_all_supertypes_A_fn_class); var ifn_1583 lang.IFn; if linked_1582 == nil { ifn_1583 = lang.IFn_Cast(root_1581) } else { ifn_1583 = nil }; var arg_1584 any = n__0; if linked_1582 == nil { arg_1580 = ifn_1583.Invoke_O__O(arg_1584) } else { arg_1580 = linked_1582.(*A_arbace_classes_env_all_supertypes_A).Invoke_O_O__O(root_1581, arg_1584) }; if linked_1576 == nil { return ifn_1577.Invoke_O_O_O__O(arg_1578, arg_1579, arg_1580) } else { return linked_1576.(*A_arbace_classes_env_member_methods_STAR__A).Invoke_O_O_O_O__O(root_1575, arg_1578, arg_1579, arg_1580) } } else {
//line :395:1
			var by_name__3 any; var or__1927000174__auto____3 any = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_141.GetRawRoot__O())).Get_O__O(n__0)


			if jrt.J2g_Truth(or__1927000174__auto____3) { by_name__3 = or__1927000174__auto____3 } else {
				jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_141.GetRawRoot__O())).PutIfAbsent_O_O__O(n__0, jrt.ConcurrentHashMap_New())
				by_name__3 = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_141.GetRawRoot__O())).Get_O__O(n__0) }
//line :395:1
			var e__4 any = jrt.NN(jrt.ConcurrentHashMap_Cast(by_name__3)).Get_O__O(name__1); var tmp2 any
			var and__1927000168__auto____5 any = e__4





			if jrt.J2g_Truth(and__1927000168__auto____5) { var root_1585 any = A_arbace_classes_env_A_const_129.GetRawRoot__O(); var linked_1586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1585, A_arbace_classes_env_same_infos_QMARK__A_fn_class); var ifn_1587 lang.IFn; if linked_1586 == nil { ifn_1587 = lang.IFn_Cast(root_1585) } else { ifn_1587 = nil }; var arg_1588 any = lang.RT_Aget_O1_I__O_NoInit(jrt.ObjectArray_Cast(e__4), lang.RT_IntCast_J__I_NoInit(1)); var arg_1589 any = lang.RT_Aget_O1_I__O_NoInit(jrt.ObjectArray_Cast(e__4), lang.RT_IntCast_J__I_NoInit(2)); if linked_1586 == nil { tmp2 = ifn_1587.Invoke_O_O__O(arg_1588, arg_1589) } else { tmp2 = linked_1586.(*A_arbace_classes_env_same_infos_QMARK__A).Invoke_O_O_O__O(root_1585, arg_1588, arg_1589) } } else { tmp2 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp2) {
				return lang.RT_Aget_O1_I__O_NoInit(jrt.ObjectArray_Cast(e__4), lang.RT_IntCast_J__I_NoInit(0)) } else {
//line :402:1
					var sups__5 any; var root_1590 any = A_arbace_classes_env_A_const_140.GetRawRoot__O(); var linked_1591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1590, A_arbace_classes_env_all_supertypes_A_fn_class); var ifn_1592 lang.IFn

					if linked_1591 == nil { ifn_1592 = lang.IFn_Cast(root_1590) } else { ifn_1592 = nil }; var arg_1593 any = n__0; if linked_1591 == nil { sups__5 = ifn_1592.Invoke_O__O(arg_1593) } else { sups__5 = linked_1591.(*A_arbace_classes_env_all_supertypes_A).Invoke_O_O__O(root_1590, arg_1593) }
//line :402:1
					var infos__6 any; var root_1594 any = A_arbace_classes_env_A_const_131.GetRawRoot__O(); var linked_1595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1594, A_arbace_classes_env_infos_now_A_fn_class); var ifn_1596 lang.IFn


					if linked_1595 == nil { ifn_1596 = lang.IFn_Cast(root_1594) } else { ifn_1596 = nil }; var arg_1597 any = sups__5; if linked_1595 == nil { infos__6 = ifn_1596.Invoke_O__O(arg_1597) } else { infos__6 = linked_1595.(*A_arbace_classes_env_infos_now_A).Invoke_O_O__O(root_1594, arg_1597) }
//line :402:1
					var r__7 any; var root_1598 any = A_arbace_classes_env_A_const_139.GetRawRoot__O(); var linked_1599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1598, A_arbace_classes_env_member_methods_STAR__A_fn_class); var ifn_1600 lang.IFn



					if linked_1599 == nil { ifn_1600 = lang.IFn_Cast(root_1598) } else { ifn_1600 = nil }; var arg_1601 any = n__0; var arg_1602 any = name__1; var arg_1603 any = sups__5; if linked_1599 == nil { r__7 = ifn_1600.Invoke_O_O_O__O(arg_1601, arg_1602, arg_1603) } else { r__7 = linked_1599.(*A_arbace_classes_env_member_methods_STAR__A).Invoke_O_O_O_O__O(root_1598, arg_1601, arg_1602, arg_1603)
					}
					var tmp3 any; var and__1927000168__auto____8 bool; var tmp4 any; var root_1604 any = A_arbace_classes_env_A_const_140.GetRawRoot__O(); var linked_1605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1604, A_arbace_classes_env_all_supertypes_A_fn_class); var ifn_1606 lang.IFn; if linked_1605 == nil { ifn_1606 = lang.IFn_Cast(root_1604) } else { ifn_1606 = nil }; var arg_1607 any = n__0; if linked_1605 == nil { tmp4 = ifn_1606.Invoke_O__O(arg_1607) } else { tmp4 = linked_1605.(*A_arbace_classes_env_all_supertypes_A).Invoke_O_O__O(root_1604, arg_1607) }; and__1927000168__auto____8 = lang.Util_Equiv_O_O__Z_NoInit(sups__5, tmp4); if and__1927000168__auto____8 { var root_1608 any = A_arbace_classes_env_A_const_129.GetRawRoot__O(); var linked_1609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1608, A_arbace_classes_env_same_infos_QMARK__A_fn_class); var ifn_1610 lang.IFn; if linked_1609 == nil { ifn_1610 = lang.IFn_Cast(root_1608) } else { ifn_1610 = nil }; var arg_1611 any = sups__5; var arg_1612 any = infos__6; if linked_1609 == nil { tmp3 = ifn_1610.Invoke_O_O__O(arg_1611, arg_1612) } else { tmp3 = linked_1609.(*A_arbace_classes_env_same_infos_QMARK__A).Invoke_O_O_O__O(root_1608, arg_1611, arg_1612) } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() }; if jrt.J2g_Truth(tmp3) {
						jrt.NN(jrt.ConcurrentHashMap_Cast(by_name__3)).Put_O_O__O(name__1, lang.RT_Object_array_O__O1_NoInit(lang.Tuple_Create_O_O_O__IPersistentVector(r__7, sups__5, infos__6)).Ref()) }
//line :402:1
					return r__7
				}
		}
}






func A_arbace_classes_env_constructors_A_New() *A_arbace_classes_env_constructors_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_constructors_A{}; t.Ctor(); return t }
//line :412:1
func (t *A_arbace_classes_env_constructors_A) Ctor() {}
//line :412:1
func (t *A_arbace_classes_env_constructors_A) Invoke_O_O__O(self, n__0 any) any {
	var root_1613 any = A_arbace_classes_env_A_const_87.GetRawRoot__O(); var linked_1614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1613, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1615 lang.IFn; if linked_1614 == nil { ifn_1615 = lang.IFn_Cast(root_1613) } else { ifn_1615 = nil }; var arg_1616 any; var tmp1 any = A_arbace_classes_env_constructors_fn__28000192_A_New(); var tmp2 *jrt.Class; var fncls__1618 *jrt.Class = A_arbace_classes_env_constructors_fn__28000192_A_fn_class; if fncls__1618 == nil { var fncls__1618d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_classes_env_constructors_fn__28000192_A_fn_class = fncls__1618d; tmp2 = fncls__1618d } else { tmp2 = fncls__1618 }; arg_1616 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1617 any; var tmp3 *lang.Keyword = A_arbace_classes_env_A_const_77; var tmp4 any; var root_1619 any = A_arbace_classes_env_A_const_96.GetRawRoot__O(); var linked_1620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1619, A_arbace_classes_env_info_BANG__A_fn_class); var ifn_1621 lang.IFn; if linked_1620 == nil { ifn_1621 = lang.IFn_Cast(root_1619) } else { ifn_1621 = nil }; var arg_1622 any = n__0; if linked_1620 == nil { tmp4 = ifn_1621.Invoke_O__O(arg_1622) } else { tmp4 = linked_1620.(*A_arbace_classes_env_info_BANG__A).Invoke_O_O__O(root_1619, arg_1622) }; arg_1617 = tmp3.Invoke_O__O(tmp4); if linked_1614 == nil { return ifn_1615.Invoke_O_O__O(arg_1616, arg_1617) } else { return linked_1614.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1613, arg_1616, arg_1617) } }
//line :413:1
func A_arbace_classes_env_constructors_fn__28000192_A_New() *A_arbace_classes_env_constructors_fn__28000192_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_constructors_fn__28000192_A{}; t.Ctor(); return t }
//line :413:1
func (t *A_arbace_classes_env_constructors_fn__28000192_A) Ctor() {}
//line :413:1
func (t *A_arbace_classes_env_constructors_fn__28000192_A) Invoke_O_O__O(self, p1__28000191_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_13, A_arbace_classes_env_A_const_42.Invoke_O__O(p1__28000191_SHARP___1))).Ref() }



































































































type A_arbace_classes_env_A struct{ jrt.Object }

var A_arbace_classes_env_A_const_pool *jrt.RefArray

var A_arbace_classes_env_A_const_0 *lang.Var

var A_arbace_classes_env_A_const_1 any

var A_arbace_classes_env_A_const_2 *lang.Var

var A_arbace_classes_env_A_const_3 any

var A_arbace_classes_env_A_const_4 any

var A_arbace_classes_env_A_const_5 any

var A_arbace_classes_env_A_const_6 any

var A_arbace_classes_env_A_const_7 *lang.Var

var A_arbace_classes_env_A_const_8 *lang.Var

var A_arbace_classes_env_A_const_9 *lang.Var

var A_arbace_classes_env_A_const_10 *lang.Var

var A_arbace_classes_env_A_const_11 any

var A_arbace_classes_env_A_const_12 *lang.Var

var A_arbace_classes_env_A_const_13 *lang.Var

var A_arbace_classes_env_A_const_14 *lang.Var

var A_arbace_classes_env_A_const_15 *lang.Var

var A_arbace_classes_env_A_const_16 *lang.Var

var A_arbace_classes_env_A_const_17 *lang.Var

var A_arbace_classes_env_A_const_18 *lang.Var

var A_arbace_classes_env_A_const_19 *lang.Var

var A_arbace_classes_env_A_const_20 *lang.Var

var A_arbace_classes_env_A_const_21 *lang.Var

var A_arbace_classes_env_A_const_22 *lang.Keyword

var A_arbace_classes_env_A_const_23 *lang.Var

var A_arbace_classes_env_A_const_24 *lang.Var

var A_arbace_classes_env_A_const_25 *lang.Var

var A_arbace_classes_env_A_const_26 *lang.Var

var A_arbace_classes_env_A_const_27 *lang.Var

var A_arbace_classes_env_A_const_28 *lang.Var

var A_arbace_classes_env_A_const_29 *lang.Var

var A_arbace_classes_env_A_const_30 *lang.Var

var A_arbace_classes_env_A_const_31 *lang.Var

var A_arbace_classes_env_A_const_32 *lang.Keyword

var A_arbace_classes_env_A_const_33 *lang.Keyword

var A_arbace_classes_env_A_const_34 *jrt.Class

var A_arbace_classes_env_A_const_35 *lang.Var

var A_arbace_classes_env_A_const_36 *lang.Var

var A_arbace_classes_env_A_const_37 *lang.Var

var A_arbace_classes_env_A_const_38 any

var A_arbace_classes_env_A_const_39 any

var A_arbace_classes_env_A_const_40 *lang.Var

var A_arbace_classes_env_A_const_41 *lang.Var

var A_arbace_classes_env_A_const_42 *lang.Keyword

var A_arbace_classes_env_A_const_43 *lang.Keyword

var A_arbace_classes_env_A_const_44 *lang.Keyword

var A_arbace_classes_env_A_const_45 *lang.Keyword

var A_arbace_classes_env_A_const_46 *lang.Keyword

var A_arbace_classes_env_A_const_47 *lang.Var

var A_arbace_classes_env_A_const_48 *lang.Keyword

var A_arbace_classes_env_A_const_49 *lang.Keyword

var A_arbace_classes_env_A_const_50 *lang.Keyword

var A_arbace_classes_env_A_const_51 *lang.Var

var A_arbace_classes_env_A_const_52 *lang.Var

var A_arbace_classes_env_A_const_53 *lang.Var

var A_arbace_classes_env_A_const_54 *lang.Var

var A_arbace_classes_env_A_const_55 *lang.Var

var A_arbace_classes_env_A_const_56 *lang.Var

var A_arbace_classes_env_A_const_57 *lang.Var

var A_arbace_classes_env_A_const_58 *lang.Var

var A_arbace_classes_env_A_const_59 *lang.Var

var A_arbace_classes_env_A_const_60 *lang.Keyword

var A_arbace_classes_env_A_const_61 *lang.Keyword

var A_arbace_classes_env_A_const_62 *lang.Var

var A_arbace_classes_env_A_const_63 *lang.Keyword

var A_arbace_classes_env_A_const_64 *lang.Keyword

var A_arbace_classes_env_A_const_65 *lang.Var

var A_arbace_classes_env_A_const_66 *lang.Var

var A_arbace_classes_env_A_const_67 *lang.Var

var A_arbace_classes_env_A_const_68 *lang.Var

var A_arbace_classes_env_A_const_69 *lang.Var

var A_arbace_classes_env_A_const_70 *lang.Var

var A_arbace_classes_env_A_const_71 *lang.Var

var A_arbace_classes_env_A_const_72 *lang.Var

var A_arbace_classes_env_A_const_73 *lang.Var

var A_arbace_classes_env_A_const_74 any

var A_arbace_classes_env_A_const_75 *lang.Keyword

var A_arbace_classes_env_A_const_76 *lang.Var

var A_arbace_classes_env_A_const_77 *lang.Keyword

var A_arbace_classes_env_A_const_78 *lang.Var

var A_arbace_classes_env_A_const_79 *lang.Var

var A_arbace_classes_env_A_const_80 *lang.Var

var A_arbace_classes_env_A_const_81 *lang.Keyword

var A_arbace_classes_env_A_const_82 *lang.Keyword

var A_arbace_classes_env_A_const_83 *lang.Var

var A_arbace_classes_env_A_const_84 *lang.Keyword

var A_arbace_classes_env_A_const_85 *lang.Var

var A_arbace_classes_env_A_const_86 *lang.Var

var A_arbace_classes_env_A_const_87 *lang.Var

var A_arbace_classes_env_A_const_88 *lang.Var

var A_arbace_classes_env_A_const_89 any

var A_arbace_classes_env_A_const_90 *lang.Var

var A_arbace_classes_env_A_const_91 *lang.Keyword

var A_arbace_classes_env_A_const_92 *lang.Var

var A_arbace_classes_env_A_const_93 *lang.Var

var A_arbace_classes_env_A_const_94 *lang.Var

var A_arbace_classes_env_A_const_95 *lang.Var

var A_arbace_classes_env_A_const_96 *lang.Var

var A_arbace_classes_env_A_const_97 *lang.Var

var A_arbace_classes_env_A_const_98 *lang.Var

var A_arbace_classes_env_A_const_99 *lang.Keyword

var A_arbace_classes_env_A_const_100 *lang.Var

var A_arbace_classes_env_A_const_101 *lang.Var

var A_arbace_classes_env_A_const_102 *lang.Var

var A_arbace_classes_env_A_const_103 *lang.Var

var A_arbace_classes_env_A_const_104 *lang.Var

var A_arbace_classes_env_A_const_105 *lang.Keyword

var A_arbace_classes_env_A_const_106 any

var A_arbace_classes_env_A_const_107 *lang.Var

var A_arbace_classes_env_A_const_108 *lang.Var

var A_arbace_classes_env_A_const_109 *lang.Var

var A_arbace_classes_env_A_const_110 *lang.Var

var A_arbace_classes_env_A_const_111 *lang.Var

var A_arbace_classes_env_A_const_112 *lang.Var

var A_arbace_classes_env_A_const_113 *lang.Var

var A_arbace_classes_env_A_const_114 *lang.Var

var A_arbace_classes_env_A_const_115 *lang.Var

var A_arbace_classes_env_A_const_116 *lang.Var

var A_arbace_classes_env_A_const_117 *lang.Var

var A_arbace_classes_env_A_const_118 *lang.Var

var A_arbace_classes_env_A_const_119 *lang.Var

var A_arbace_classes_env_A_const_120 *lang.Var

var A_arbace_classes_env_A_const_121 *lang.Var

var A_arbace_classes_env_A_const_122 any

var A_arbace_classes_env_A_const_123 any

var A_arbace_classes_env_A_const_124 *lang.Var

var A_arbace_classes_env_A_const_125 any

var A_arbace_classes_env_A_const_126 *lang.Var

var A_arbace_classes_env_A_const_127 *lang.Var

var A_arbace_classes_env_A_const_128 *lang.Var

var A_arbace_classes_env_A_const_129 *lang.Var

var A_arbace_classes_env_A_const_130 *lang.Var

var A_arbace_classes_env_A_const_131 *lang.Var

var A_arbace_classes_env_A_const_132 *lang.Var

var A_arbace_classes_env_A_const_133 any

var A_arbace_classes_env_A_const_134 any

var A_arbace_classes_env_A_const_135 any

var A_arbace_classes_env_A_const_136 *lang.Var

var A_arbace_classes_env_A_const_137 *lang.Var

var A_arbace_classes_env_A_const_138 *lang.Var

var A_arbace_classes_env_A_const_139 *lang.Var

var A_arbace_classes_env_A_const_140 *lang.Var

var A_arbace_classes_env_A_const_141 *lang.Var

var A_arbace_classes_env_A_init jrt.ClassInit

func A_arbace_classes_env_A_Init() { if !A_arbace_classes_env_A_init.Done() { A_arbace_classes_env_A_init.Run(A_arbace_classes_env_A_clinit) } }

func A_arbace_classes_env_A_clinit() { A_arbace_classes_env_A_clinit_p0(); A_arbace_classes_env_A_clinit_p1(); A_arbace_classes_env_A_clinit_p2(); A_arbace_classes_env_A_clinit_p3(); A_arbace_classes_env_A_clinit_p4(); A_arbace_classes_env_A_clinit_p5(); A_arbace_classes_env_A_clinit_p6(); A_arbace_classes_env_A_clinit_p7(); A_arbace_classes_env_A_clinit_p8(); A_arbace_classes_env_A_clinit_p9(); A_arbace_classes_env_A_clinit_p10(); A_arbace_classes_env_A_clinit_p11() }

func A_arbace_classes_env_A_clinit_p0() { jrt.StartCheck(); A_arbace_classes_env_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 179); A_arbace_classes_env_A_const_0 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[37]); A_arbace_classes_env_A_const_1 = A_arbace_classes_env_A_const_pool.A[38]; A_arbace_classes_env_A_const_2 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[39]); A_arbace_classes_env_A_const_3 = A_arbace_classes_env_A_const_pool.A[40]; A_arbace_classes_env_A_const_4 = A_arbace_classes_env_A_const_pool.A[41]; A_arbace_classes_env_A_const_5 = A_arbace_classes_env_A_const_pool.A[42]; A_arbace_classes_env_A_const_6 = A_arbace_classes_env_A_const_pool.A[43]; A_arbace_classes_env_A_const_7 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[44]); A_arbace_classes_env_A_const_8 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[45]); A_arbace_classes_env_A_const_9 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[46]); A_arbace_classes_env_A_const_10 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[47]); A_arbace_classes_env_A_const_11 = A_arbace_classes_env_A_const_pool.A[48] }

func A_arbace_classes_env_A_clinit_p1() { A_arbace_classes_env_A_const_12 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[49]); A_arbace_classes_env_A_const_13 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[50]); A_arbace_classes_env_A_const_14 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[51]); A_arbace_classes_env_A_const_15 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[52]); A_arbace_classes_env_A_const_16 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[53]); A_arbace_classes_env_A_const_17 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[54]); A_arbace_classes_env_A_const_18 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[55]); A_arbace_classes_env_A_const_19 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[56]); A_arbace_classes_env_A_const_20 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[57]); A_arbace_classes_env_A_const_21 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[58]); A_arbace_classes_env_A_const_22 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[59]); A_arbace_classes_env_A_const_23 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[60]) }

func A_arbace_classes_env_A_clinit_p2() { A_arbace_classes_env_A_const_24 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[61]); A_arbace_classes_env_A_const_25 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[62]); A_arbace_classes_env_A_const_26 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[63]); A_arbace_classes_env_A_const_27 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[64]); A_arbace_classes_env_A_const_28 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[65]); A_arbace_classes_env_A_const_29 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[66]); A_arbace_classes_env_A_const_30 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[67]); A_arbace_classes_env_A_const_31 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[68]); A_arbace_classes_env_A_const_32 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[69]); A_arbace_classes_env_A_const_33 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[70]); A_arbace_classes_env_A_const_34 = jrt.Class_Cast(A_arbace_classes_env_A_const_pool.A[71]); A_arbace_classes_env_A_const_35 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[72]) }

func A_arbace_classes_env_A_clinit_p3() { A_arbace_classes_env_A_const_36 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[73]); A_arbace_classes_env_A_const_37 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[74]); A_arbace_classes_env_A_const_38 = A_arbace_classes_env_A_const_pool.A[75]; A_arbace_classes_env_A_const_39 = A_arbace_classes_env_A_const_pool.A[76]; A_arbace_classes_env_A_const_40 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[77]); A_arbace_classes_env_A_const_41 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[78]); A_arbace_classes_env_A_const_42 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[79]); A_arbace_classes_env_A_const_43 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[80]); A_arbace_classes_env_A_const_44 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[81]); A_arbace_classes_env_A_const_45 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[82]); A_arbace_classes_env_A_const_46 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[83]); A_arbace_classes_env_A_const_47 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[84]) }

func A_arbace_classes_env_A_clinit_p4() { A_arbace_classes_env_A_const_48 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[85]); A_arbace_classes_env_A_const_49 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[86]); A_arbace_classes_env_A_const_50 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[87]); A_arbace_classes_env_A_const_51 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[88]); A_arbace_classes_env_A_const_52 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[89]); A_arbace_classes_env_A_const_53 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[90]); A_arbace_classes_env_A_const_54 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[91]); A_arbace_classes_env_A_const_55 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[92]); A_arbace_classes_env_A_const_56 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[93]); A_arbace_classes_env_A_const_57 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[94]); A_arbace_classes_env_A_const_58 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[95]); A_arbace_classes_env_A_const_59 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[96]) }

func A_arbace_classes_env_A_clinit_p5() { A_arbace_classes_env_A_const_60 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[97]); A_arbace_classes_env_A_const_61 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[98]); A_arbace_classes_env_A_const_62 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[99]); A_arbace_classes_env_A_const_63 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[100]); A_arbace_classes_env_A_const_64 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[101]); A_arbace_classes_env_A_const_65 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[102]); A_arbace_classes_env_A_const_66 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[103]); A_arbace_classes_env_A_const_67 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[104]); A_arbace_classes_env_A_const_68 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[105]); A_arbace_classes_env_A_const_69 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[106]); A_arbace_classes_env_A_const_70 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[107]); A_arbace_classes_env_A_const_71 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[108]) }

func A_arbace_classes_env_A_clinit_p6() { A_arbace_classes_env_A_const_72 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[109]); A_arbace_classes_env_A_const_73 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[110]); A_arbace_classes_env_A_const_74 = A_arbace_classes_env_A_const_pool.A[111]; A_arbace_classes_env_A_const_75 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[112]); A_arbace_classes_env_A_const_76 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[113]); A_arbace_classes_env_A_const_77 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[114]); A_arbace_classes_env_A_const_78 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[115]); A_arbace_classes_env_A_const_79 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[116]); A_arbace_classes_env_A_const_80 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[117]); A_arbace_classes_env_A_const_81 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[118]); A_arbace_classes_env_A_const_82 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[119]); A_arbace_classes_env_A_const_83 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[120]) }

func A_arbace_classes_env_A_clinit_p7() { A_arbace_classes_env_A_const_84 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[121]); A_arbace_classes_env_A_const_85 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[122]); A_arbace_classes_env_A_const_86 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[123]); A_arbace_classes_env_A_const_87 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[124]); A_arbace_classes_env_A_const_88 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[125]); A_arbace_classes_env_A_const_89 = A_arbace_classes_env_A_const_pool.A[126]; A_arbace_classes_env_A_const_90 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[127]); A_arbace_classes_env_A_const_91 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[128]); A_arbace_classes_env_A_const_92 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[129]); A_arbace_classes_env_A_const_93 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[130]); A_arbace_classes_env_A_const_94 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[131]); A_arbace_classes_env_A_const_95 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[132]) }

func A_arbace_classes_env_A_clinit_p8() { A_arbace_classes_env_A_const_96 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[133]); A_arbace_classes_env_A_const_97 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[134]); A_arbace_classes_env_A_const_98 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[135]); A_arbace_classes_env_A_const_99 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[136]); A_arbace_classes_env_A_const_100 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[137]); A_arbace_classes_env_A_const_101 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[138]); A_arbace_classes_env_A_const_102 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[139]); A_arbace_classes_env_A_const_103 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[140]); A_arbace_classes_env_A_const_104 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[141]); A_arbace_classes_env_A_const_105 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[142]); A_arbace_classes_env_A_const_106 = A_arbace_classes_env_A_const_pool.A[143]; A_arbace_classes_env_A_const_107 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[144]) }

func A_arbace_classes_env_A_clinit_p9() { A_arbace_classes_env_A_const_108 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[145]); A_arbace_classes_env_A_const_109 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[146]); A_arbace_classes_env_A_const_110 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[147]); A_arbace_classes_env_A_const_111 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[148]); A_arbace_classes_env_A_const_112 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[149]); A_arbace_classes_env_A_const_113 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[150]); A_arbace_classes_env_A_const_114 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[151]); A_arbace_classes_env_A_const_115 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[152]); A_arbace_classes_env_A_const_116 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[153]); A_arbace_classes_env_A_const_117 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[154]); A_arbace_classes_env_A_const_118 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[155]); A_arbace_classes_env_A_const_119 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[156]) }

func A_arbace_classes_env_A_clinit_p10() { A_arbace_classes_env_A_const_120 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[157]); A_arbace_classes_env_A_const_121 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[158]); A_arbace_classes_env_A_const_122 = A_arbace_classes_env_A_const_pool.A[159]; A_arbace_classes_env_A_const_123 = A_arbace_classes_env_A_const_pool.A[160]; A_arbace_classes_env_A_const_124 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[161]); A_arbace_classes_env_A_const_125 = A_arbace_classes_env_A_const_pool.A[162]; A_arbace_classes_env_A_const_126 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[163]); A_arbace_classes_env_A_const_127 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[164]); A_arbace_classes_env_A_const_128 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[165]); A_arbace_classes_env_A_const_129 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[166]); A_arbace_classes_env_A_const_130 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[167]); A_arbace_classes_env_A_const_131 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[168]) }

func A_arbace_classes_env_A_clinit_p11() { A_arbace_classes_env_A_const_132 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[169]); A_arbace_classes_env_A_const_133 = A_arbace_classes_env_A_const_pool.A[170]; A_arbace_classes_env_A_const_134 = A_arbace_classes_env_A_const_pool.A[171]; A_arbace_classes_env_A_const_135 = A_arbace_classes_env_A_const_pool.A[172]; A_arbace_classes_env_A_const_136 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[173]); A_arbace_classes_env_A_const_137 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[174]); A_arbace_classes_env_A_const_138 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[175]); A_arbace_classes_env_A_const_139 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[176]); A_arbace_classes_env_A_const_140 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[177]); A_arbace_classes_env_A_const_141 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[178]) }

func A_arbace_classes_env_A_New() *A_arbace_classes_env_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_env_A) Ctor() {}

func (t *A_arbace_classes_env_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_A_class }

func (t *A_arbace_classes_env_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_env_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_A); return ok }

func A_arbace_classes_env_A_Cast(x any) *A_arbace_classes_env_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_A_class)) }; return v }



type A_arbace_classes_env_accessible_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_accessible_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_accessible_QMARK__fn__28000143_A struct{ j2g_header uint64; F_owner any }

var A_arbace_classes_env_accessible_QMARK__fn__28000143_A_fn_class *jrt.Class



type A_arbace_classes_env_accessible_QMARK__fn__28000145_A struct{ j2g_header uint64 }

var A_arbace_classes_env_accessible_QMARK__fn__28000145_A_fn_class *jrt.Class



type A_arbace_classes_env_all_supertypes_A struct{ j2g_header uint64 }

var A_arbace_classes_env_all_supertypes_A_fn_class *jrt.Class



type A_arbace_classes_env_all_supertypes_STAR__A struct{ j2g_header uint64 }

var A_arbace_classes_env_all_supertypes_STAR__A_fn_class *jrt.Class



type A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A struct{ j2g_header uint64 }

var A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A_fn_class *jrt.Class



type A_arbace_classes_env_assignable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_assignable_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_class_file_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_class_file_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_coerce_const_A struct{ j2g_header uint64 }

var A_arbace_classes_env_coerce_const_A_fn_class *jrt.Class



type A_arbace_classes_env_common_super_A struct{ j2g_header uint64 }

var A_arbace_classes_env_common_super_A_fn_class *jrt.Class



type A_arbace_classes_env_const_value_A struct{ j2g_header uint64 }

var A_arbace_classes_env_const_value_A_fn_class *jrt.Class



type A_arbace_classes_env_constructors_A struct{ j2g_header uint64 }

var A_arbace_classes_env_constructors_A_fn_class *jrt.Class



type A_arbace_classes_env_constructors_fn__28000192_A struct{ j2g_header uint64 }

var A_arbace_classes_env_constructors_fn__28000192_A_fn_class *jrt.Class



type A_arbace_classes_env_eval28000004_A struct{ jrt.Object }

func A_arbace_classes_env_eval28000004_A_New() *A_arbace_classes_env_eval28000004_A { t := &A_arbace_classes_env_eval28000004_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_env_eval28000004_A) Ctor() {}

func (t *A_arbace_classes_env_eval28000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_eval28000004_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_eval28000004_A_class }

func (t *A_arbace_classes_env_eval28000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_eval28000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_env_eval28000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_eval28000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_eval28000004_A); return ok }

func A_arbace_classes_env_eval28000004_A_Cast(x any) *A_arbace_classes_env_eval28000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_eval28000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_eval28000004_A_class)) }; return v }



type A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A struct{ j2g_header uint64 }

var A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_fn_class *jrt.Class



type A_arbace_classes_env_eval28000008_A struct{ jrt.Object }

func A_arbace_classes_env_eval28000008_A_New() *A_arbace_classes_env_eval28000008_A { t := &A_arbace_classes_env_eval28000008_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_env_eval28000008_A) Ctor() {}

func (t *A_arbace_classes_env_eval28000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_eval28000008_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_eval28000008_A_class }

func (t *A_arbace_classes_env_eval28000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_eval28000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_env_eval28000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_eval28000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_eval28000008_A); return ok }

func A_arbace_classes_env_eval28000008_A_Cast(x any) *A_arbace_classes_env_eval28000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_eval28000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_eval28000008_A_class)) }; return v }



type A_arbace_classes_env_eval28000008_fn__28000009_A struct{ j2g_header uint64 }

var A_arbace_classes_env_eval28000008_fn__28000009_A_fn_class *jrt.Class



type A_arbace_classes_env_find_field_A struct{ j2g_header uint64 }

var A_arbace_classes_env_find_field_A_fn_class *jrt.Class



type A_arbace_classes_env_find_field_fn__28000150_A struct{ j2g_header uint64; F_name any }

var A_arbace_classes_env_find_field_fn__28000150_A_fn_class *jrt.Class



type A_arbace_classes_env_find_field_fn__28000152_A struct{ j2g_header uint64; F_name any }

var A_arbace_classes_env_find_field_fn__28000152_A_fn_class *jrt.Class



type A_arbace_classes_env_flag_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_flag_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_from_source_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_from_source_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_info_A struct{ j2g_header uint64 }

var A_arbace_classes_env_info_A_fn_class *jrt.Class



type A_arbace_classes_env_info_BANG__A struct{ j2g_header uint64 }

var A_arbace_classes_env_info_BANG__A_fn_class *jrt.Class



type A_arbace_classes_env_infos_now_A struct{ j2g_header uint64 }

var A_arbace_classes_env_infos_now_A_fn_class *jrt.Class



type A_arbace_classes_env_inner_member_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_inner_member_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_interface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_interface_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_internal_A struct{ j2g_header uint64 }

var A_arbace_classes_env_internal_A_fn_class *jrt.Class



type A_arbace_classes_env_known_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_known_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_load_class_A struct{ j2g_header uint64 }

var A_arbace_classes_env_load_class_A_fn_class *jrt.Class



type A_arbace_classes_env_lub_A struct{ j2g_header uint64 }

var A_arbace_classes_env_lub_A_fn_class *jrt.Class



type A_arbace_classes_env_lub_fn__28000134_A struct{ j2g_header uint64; F_common any }

var A_arbace_classes_env_lub_fn__28000134_A_fn_class *jrt.Class



type A_arbace_classes_env_lub_fn__28000134_fn__28000135_A struct{ j2g_header uint64; F_i any }

var A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_fn_class *jrt.Class



type A_arbace_classes_env_lub_sups__28000129_A struct{ j2g_header uint64 }

var A_arbace_classes_env_lub_sups__28000129_A_fn_class *jrt.Class



type A_arbace_classes_env_lub_sups__28000129_fn__28000130_A struct{ j2g_header uint64 }

var A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_fn_class *jrt.Class



type A_arbace_classes_env_member_methods_A struct{ j2g_header uint64 }

var A_arbace_classes_env_member_methods_A_fn_class *jrt.Class



type A_arbace_classes_env_member_methods_STAR__A struct{ j2g_header uint64 }

var A_arbace_classes_env_member_methods_STAR__A_fn_class *jrt.Class



type A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A struct{ j2g_header uint64; F_seen, F_name, F_n, F_c any }

var A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A_fn_class *jrt.Class



type A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A struct{ j2g_header uint64; F_iter__28000179, F_seen, F_name, F_n, F_c, F_s__28000180 any }

var A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A_fn_class *jrt.Class



type A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A struct{ j2g_header uint64; F_seen, F_name, F_n, F_c any; F_size__1927001038__auto__ int32; F_b__28000182, F_c__1927001037__auto__ any }

var A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A_fn_class *jrt.Class



type A_arbace_classes_env_nest_host_A struct{ j2g_header uint64 }

var A_arbace_classes_env_nest_host_A_fn_class *jrt.Class



type A_arbace_classes_env_params_key_A struct{ j2g_header uint64 }

var A_arbace_classes_env_params_key_A_fn_class *jrt.Class



type A_arbace_classes_env_read_fields_A struct{ j2g_header uint64 }

var A_arbace_classes_env_read_fields_A_fn_class *jrt.Class



type A_arbace_classes_env_read_method_annotations_A struct{ j2g_header uint64 }

var A_arbace_classes_env_read_method_annotations_A_fn_class *jrt.Class



type A_arbace_classes_env_record_BANG__A struct{ j2g_header uint64 }

var A_arbace_classes_env_record_BANG__A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_A struct{ j2g_header uint64 }

var A_arbace_classes_env_reflect_info_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_fn__28000027_A struct{ j2g_header uint64; F_c any }

var A_arbace_classes_env_reflect_info_fn__28000027_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_fn__28000089_A struct{ j2g_header uint64 }

var A_arbace_classes_env_reflect_info_fn__28000089_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000031__28000035_A struct{ j2g_header uint64; F_n any }

var A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A struct{ j2g_header uint64; F_n, F_s__28000032, F_iter__28000031 any }

var A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A struct{ j2g_header uint64; F_b__28000034, F_n any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000045__28000049_A struct{ j2g_header uint64; F_n any }

var A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A struct{ j2g_header uint64; F_n, F_s__28000046, F_iter__28000045 any }

var A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A struct{ j2g_header uint64; F_n, F_b__28000048 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_A struct{ j2g_header uint64; F_n, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A struct{ j2g_header uint64; F_n, F_manns, F_s__28000056, F_iter__28000055 any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A struct{ j2g_header uint64; F_n, F_b__28000058, F_manns any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A struct{ j2g_header uint64; F_m, F_desc, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A struct{ j2g_header uint64; F_m, F_desc, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A struct{ j2g_header uint64; F_i, F_m, F_desc, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A struct{ j2g_header uint64; F_m, F_desc, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A struct{ j2g_header uint64; F_m, F_desc, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A struct{ j2g_header uint64; F_i, F_m, F_desc, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000077__28000081_A struct{ j2g_header uint64; F_c, F_n any }

var A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A struct{ j2g_header uint64; F_c, F_n, F_s__28000078, F_iter__28000077 any }

var A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A struct{ j2g_header uint64; F_c, F_n, F_b__28000080 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000091__28000095_A struct{ j2g_header uint64; F_n any }

var A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A struct{ j2g_header uint64; F_n, F_s__28000092, F_iter__28000091 any }

var A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A struct{ j2g_header uint64; F_n any; F_size__1927001038__auto__ int32; F_b__28000094, F_c__1927001037__auto__ any }

var A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_fn_class *jrt.Class



type A_arbace_classes_env_reflected_A struct{ j2g_header uint64 }

var A_arbace_classes_env_reflected_A_fn_class *jrt.Class



type A_arbace_classes_env_same_infos_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_same_infos_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_subclass_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_subclass_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_subclass_QMARK__fn__28000117_A struct{ j2g_header uint64; F_b any }

var A_arbace_classes_env_subclass_QMARK__fn__28000117_A_fn_class *jrt.Class



type A_arbace_classes_env_superclass_chain_A struct{ j2g_header uint64 }

var A_arbace_classes_env_superclass_chain_A_fn_class *jrt.Class



type A_arbace_classes_env_superclass_chain_fn__28000123_A struct{ j2g_header uint64 }

var A_arbace_classes_env_superclass_chain_fn__28000123_A_fn_class *jrt.Class



type A_arbace_classes_env_supertypes_A struct{ j2g_header uint64 }

var A_arbace_classes_env_supertypes_A_fn_class *jrt.Class
