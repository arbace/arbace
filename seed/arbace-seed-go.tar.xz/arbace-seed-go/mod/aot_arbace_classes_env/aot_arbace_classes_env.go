//line aot_arbace_classes_env.ae:1
package aot_arbace_classes_env

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_New() *A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_classes_env_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_env_A_const_2); lang.IFn_Cast(A_arbace_classes_env_A_const_1.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_classes_env_A_const_3, A_arbace_classes_env_A_const_4, A_arbace_classes_env_A_const_5, A_arbace_classes_env_A_const_6); { var tmp4 *lang.Var; lang.RT_Init(); tmp4 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp4).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_14)); var tmp5 *lang.Var; lang.RT_Init(); tmp5 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp5).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_15)); var tmp6 *lang.Var; lang.RT_Init(); tmp6 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp6).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_16)); var tmp7 *lang.Var; lang.RT_Init(); tmp7 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp7).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_17)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp8 != nil { panic(tmp8) }; return tmp3 }
//line :1:1
func A_arbace_classes_env_eval28000008_fn__28000009_A_New() *A_arbace_classes_env_eval28000008_fn__28000009_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_eval28000008_fn__28000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_env_eval28000008_fn__28000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_env_eval28000008_fn__28000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_classes_env_A_const_7.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_8.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_env_A_const_11), A_arbace_classes_env_A_const_9.GetRawRoot__O(), A_arbace_classes_env_A_const_10) }



























func A_arbace_classes_env_internal_A_New() *A_arbace_classes_env_internal_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_internal_A{}; t.Ctor(); return t }
//line :29:1
func (t *A_arbace_classes_env_internal_A) Ctor() {}
//line :29:1
func (t *A_arbace_classes_env_internal_A) Invoke_O_O__O(self, c__0 any) any { return lang.IFn_Cast(A_arbace_classes_env_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref(), Lit_22, Lit_21) }







func A_arbace_classes_env_from_source_QMARK__A_New() *A_arbace_classes_env_from_source_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_from_source_QMARK__A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_classes_env_from_source_QMARK__A) Ctor() {}
//line :37:1
func (t *A_arbace_classes_env_from_source_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var tmp1 any; var and__1927000168__auto____2 any = A_arbace_classes_env_A_const_13.Get__O(); if jrt.A2g_Truth(and__1927000168__auto____2) { tmp1 = lang.IFn_Cast(A_arbace_classes_env_A_const_13.Get__O()).Invoke_O__O(n__0) } else { tmp1 = and__1927000168__auto____2 }; return jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(tmp1)).Ref() }


















func A_arbace_classes_env_record_BANG__A_New() *A_arbace_classes_env_record_BANG__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_record_BANG__A{}; t.Ctor(); return t }
//line :56:1
func (t *A_arbace_classes_env_record_BANG__A) Ctor() {}
//line :56:1
func (t *A_arbace_classes_env_record_BANG__A) Invoke_O_O_O_O__O(self, n__0, facet__1, v__2 any) any {


	if jrt.A2g_Truth(A_arbace_classes_env_A_const_14.Get__O()) { lang.IFn_Cast(A_arbace_classes_env_A_const_15.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_classes_env_A_const_14.Get__O(), A_arbace_classes_env_A_const_16.GetRawRoot__O(), n__0, A_arbace_classes_env_A_const_17.GetRawRoot__O(), facet__1, v__2) }
//line :56:1
	return v__2
}




func A_arbace_classes_env_load_class_A_New() *A_arbace_classes_env_load_class_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_load_class_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_classes_env_load_class_A) Ctor() {}
//line :62:1
func (t *A_arbace_classes_env_load_class_A) Invoke_O_O__O(self, n__0 any) any {



	var tmp1 any; var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_classes_env_A_const_18.GetRawRoot__O()).Invoke_O__O(n__0); if jrt.A2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { tmp1 = A_arbace_classes_env_A_const_19.Get__O() }; if jrt.A2g_Truth(tmp1) { return nil } else { var tmp2 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var cn__4 any

		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_env_A_const_20.GetRawRoot__O()).Invoke_O_O__O(n__0, Lit_11)) { cn__4 = lang.IFn_Cast(A_arbace_classes_env_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(n__0, Lit_21, Lit_22) } else { cn__4 = lang.IFn_Cast(A_arbace_classes_env_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(n__0, Lit_21, Lit_22) }
//line :66:1
		var c__5 any = lang.RT_ClassForNameNonLoading_String__Class(jrt.String_Cast(cn__4)).Ref(); var tmp3 any
		var and__1927000168__auto____6 any = c__5


		if jrt.A2g_Truth(and__1927000168__auto____6) { tmp3 = A_arbace_classes_env_A_const_14.Get__O() } else { tmp3 = and__1927000168__auto____6 }; if jrt.A2g_Truth(tmp3) { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_21.GetRawRoot__O()); var tmp5 any = A_arbace_classes_env_A_const_22; var tmp6 *jrt.Boolean; jrt.Boolean_Init(); tmp6 = jrt.Boolean_TRUE; tmp4.Invoke_O_O_O__O(n__0, tmp5, tmp6.Ref()) }
//line :66:1
		tmp2 = c__5 }; return nil }(); if tmp7 != nil { if jrt.ClassNotFoundException_InstanceOf(tmp7) { var ___4 *jrt.ClassNotFoundException = jrt.ClassNotFoundException_Cast(tmp7); _ = ___4; tmp2 = nil } else if jrt.NoClassDefFoundError_InstanceOf(tmp7) { var ___4_2 *jrt.NoClassDefFoundError = jrt.NoClassDefFoundError_Cast(tmp7); _ = ___4_2; tmp2 = nil } else { panic(tmp7) } }; return tmp2
	}
}






func A_arbace_classes_env_known_QMARK__A_New() *A_arbace_classes_env_known_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_known_QMARK__A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_classes_env_known_QMARK__A) Ctor() {}
//line :75:1
func (t *A_arbace_classes_env_known_QMARK__A) Invoke_O_O__O(self, n__0 any) any {


	if jrt.A2g_Truth(A_arbace_classes_env_A_const_19.Get__O()) { return lang.IFn_Cast(A_arbace_classes_env_A_const_23.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_env_A_const_19.Get__O(), n__0) } else { return lang.IFn_Cast(A_arbace_classes_env_A_const_24.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_25.GetRawRoot__O()).Invoke_O__O(n__0))
	} }
func A_arbace_classes_env_reflected_A_New() *A_arbace_classes_env_reflected_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflected_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_classes_env_reflected_A) Ctor() {}
//line :80:1
func (t *A_arbace_classes_env_reflected_A) Invoke_O_O_O_O__O(self, n__0, facet__1, f__2 any) any {




	if jrt.A2g_Truth(A_arbace_classes_env_A_const_19.Get__O()) { var temp__1927000414__auto____4 any = lang.RT_Get_O_O__O(A_arbace_classes_env_A_const_19.Get__O(), n__0)
		if jrt.A2g_Truth(temp__1927000414__auto____4) { var d__5 any = temp__1927000414__auto____4; var temp__1927000408__auto____6 any = lang.IFn_Cast(A_arbace_classes_env_A_const_26.GetRawRoot__O()).Invoke_O_O__O(d__5, facet__1)
			if jrt.A2g_Truth(temp__1927000408__auto____6) { var e__7 any = temp__1927000408__auto____6
				return lang.IFn_Cast(A_arbace_classes_env_A_const_27.GetRawRoot__O()).Invoke_O__O(e__7) } else {
//line :87:1
					panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_classes_env_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_57, nil, Lit_58, nil, Lit_59), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_classes_env_A_const_29.GetRawRoot__O()).Invoke_O__O(facet__1), nil, lang.IFn_Cast(A_arbace_classes_env_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_32.GetRawRoot__O()).Invoke_O__O(n__0), Lit_21, Lit_22), nil)).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_env_A_const_30, n__0, A_arbace_classes_env_A_const_31, facet__1)))))) } } else {
//line :86:1
						return nil } } else {
//line :85:1
							var temp__1927000414__auto____4_2 any = lang.IFn_Cast(A_arbace_classes_env_A_const_25.GetRawRoot__O()).Invoke_O__O(n__0)






							if jrt.A2g_Truth(temp__1927000414__auto____4_2) { var c__5 any = temp__1927000414__auto____4_2
								return lang.IFn_Cast(A_arbace_classes_env_A_const_21.GetRawRoot__O()).Invoke_O_O_O__O(n__0, facet__1, lang.IFn_Cast(f__2).Invoke_O__O(c__5)) } else {
//line :92:1
									return nil
								}
						} }
func A_arbace_classes_env_class_file_QMARK__A_New() *A_arbace_classes_env_class_file_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_class_file_QMARK__A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_classes_env_class_file_QMARK__A) Ctor() {}
//line :95:1
func (t *A_arbace_classes_env_class_file_QMARK__A) Invoke_O_O__O(self, c__0 any) any { var ld__2 any; var or__1927000174__auto____2 any = jrt.NN(jrt.Class_Cast(c__0)).GetClassLoader__ClassLoader(); if





	jrt.A2g_Truth(or__1927000174__auto____2) { ld__2 = or__1927000174__auto____2 } else { ld__2 = jrt.ClassLoader_GetSystemClassLoader__ClassLoader() }; var tmp1 /*line :95:1*/*jrt.Class = A_arbace_classes_env_A_const_33; var temp__1927000414__auto____3 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(ld__2, tmp1, Lit_5, jrt.RefArrayOf(jrt.Object_class, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_6), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_classes_env_A_const_34.GetRawRoot__O()).Invoke_O__O(c__0), nil)).Ref())); if






	jrt.A2g_Truth(temp__1927000414__auto____3) { var in__4 any = temp__1927000414__auto____3
		jrt.InputStream_Cast(in__4).Close__V()
//line :102:1
		jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { return nil } }



func A_arbace_classes_env_read_fields_A_New() *A_arbace_classes_env_read_fields_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_read_fields_A{}; t.Ctor(); return t }
//line :106:1
func (t *A_arbace_classes_env_read_fields_A) Ctor() {}
//line :106:1
func (t *A_arbace_classes_env_read_fields_A) Invoke_O_O__O(self, c__0 any) any {




	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_env_A_const_35.GetRawRoot__O()).Invoke_O__O(c__0)) {
		return lang.IFn_Cast(lang.IFn_Cast(A_arbace_classes_env_A_const_36.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_env_A_const_37)).Invoke_O__O(c__0) } else {
//line :111:1
			return nil
		}
}
func A_arbace_classes_env_read_method_annotations_A_New() *A_arbace_classes_env_read_method_annotations_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_read_method_annotations_A{}; t.Ctor(); return t }
//line :114:1
func (t *A_arbace_classes_env_read_method_annotations_A) Ctor() {}
//line :114:1
func (t *A_arbace_classes_env_read_method_annotations_A) Invoke_O_O__O(self, c__0 any) any {



	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_env_A_const_35.GetRawRoot__O()).Invoke_O__O(c__0)) {
		return lang.IFn_Cast(lang.IFn_Cast(A_arbace_classes_env_A_const_36.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_env_A_const_38)).Invoke_O__O(c__0) } else {
//line :118:1
			lang.PersistentArrayMap_Init(); return lang.PersistentArrayMap_EMPTY.Ref()
		}
}

func A_arbace_classes_env_coerce_const_A_New() *A_arbace_classes_env_coerce_const_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_coerce_const_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_classes_env_coerce_const_A) Ctor() {}
//line :122:1
func (t *A_arbace_classes_env_coerce_const_A) Invoke_O_O_O__O(self, desc__0, v__1 any) any { var G__28000023__3_ any = desc__0; switch
												lang.Util_Hash_O__I(G__28000023__3_) { case 66: if lang.Util_Equiv_O_O__Z(G__28000023__3_, Lit_7) {



		return jrt.Byte_ValueOf_B__Byte(lang.RT_ByteCast_O__B(v__1)).Ref() }
//line :123:1
	case 67: if lang.Util_Equiv_O_O__Z(G__28000023__3_, Lit_8) {

		return jrt.Character_ValueOf_C__Character(lang.RT_CharCast_I__C(lang.RT_IntCast_O__I(v__1))).Ref() }
//line :123:1
	case 83: if lang.Util_Equiv_O_O__Z(G__28000023__3_, Lit_9) {


		return jrt.Short_ValueOf_S__Short(lang.RT_ShortCast_O__S(v__1)).Ref() }
//line :123:1
	case 90: if lang.Util_Equiv_O_O__Z(G__28000023__3_, Lit_10) {
		return lang.IFn_Cast(A_arbace_classes_env_A_const_39.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsZero_J__Z(lang.RT_LongCast_O__J(v__1))).Ref()) }
//line :123:1
	default:}; return v__1 }











func A_arbace_classes_env_inner_member_QMARK__A_New() *A_arbace_classes_env_inner_member_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_inner_member_QMARK__A{}; t.Ctor(); return t }
//line :135:1
func (t *A_arbace_classes_env_inner_member_QMARK__A) Ctor() {}
//line :135:1
func (t *A_arbace_classes_env_inner_member_QMARK__A) Invoke_O_O__O(self, c__0 any) any {
	var tmp1 any; var and__1927000168__auto____2 any = jrt.NN(jrt.Class_Cast(c__0)).GetDeclaringClass__Class().Ref(); if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_classes_env_A_const_39.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(jrt.Modifier_IsStatic_I__Z(jrt.NN(jrt.Class_Cast(c__0)).GetModifiers__I())).Ref()); if jrt.A2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_classes_env_A_const_39.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.Class_Cast(c__0)).IsInterface__Z()).Ref()); if jrt.A2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_classes_env_A_const_39.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.Class_Cast(c__0)).IsEnum__Z()).Ref()); if jrt.A2g_Truth(and__1927000168__auto____5) {
		tmp1 = lang.IFn_Cast(A_arbace_classes_env_A_const_39.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.Class_Cast(c__0)).IsRecord__Z()).Ref()) } else {
//line :136:1
			tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; return jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(tmp1)).Ref()
}

func A_arbace_classes_env_reflect_info_A_New() *A_arbace_classes_env_reflect_info_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_classes_env_reflect_info_A) Ctor() {}
//line :139:1
func (t *A_arbace_classes_env_reflect_info_A) Invoke_O_O__O(self, c__0 any) any { var lockee__1927000360__auto____2 any = A_arbace_classes_env_A_const_40.GetRawRoot__O(); var locklocal__1927000361__auto____5 any = lockee__1927000360__auto____2; lang.Compiler_Evaluator_MonitorEnter_O__V(locklocal__1927000361__auto____5); var tmp1 any; tmp53 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var or__1927000174__auto____8 any = lang.Reflector_InvokeInstanceMethod_O_String_O1__O(A_arbace_classes_env_A_const_40.GetRawRoot__O(), Lit_31, jrt.RefArrayOf(jrt.Object_class, c__0))

	if jrt.A2g_Truth(or__1927000174__auto____8) { tmp1 = or__1927000174__auto____8 } else { var n__9 any = lang.IFn_Cast(A_arbace_classes_env_A_const_34.GetRawRoot__O()).Invoke_O__O(c__0); var manns__10 any; var tmp2 any = A_arbace_classes_env_reflect_info_fn__28000027_A_New_O(c__0); var tmp3 *jrt.Class
		var fncls__2 /*line :141:1*/*jrt.Class = A_arbace_classes_env_reflect_info_fn__28000027_A_fn_class

		if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_32, false); A_arbace_classes_env_reflect_info_fn__28000027_A_fn_class = fncls__2d; tmp3 = fncls__2d } else { tmp3 = fncls__2 }
//line :141:1
		manns__10 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var info__11 any; var tmp4 any = A_arbace_classes_env_A_const_42; var tmp5 any = A_arbace_classes_env_A_const_43; var tmp6 any = jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.Class_Cast(c__0)).GetModifiers__I()).Ref(); var tmp7 any = A_arbace_classes_env_A_const_44; var tmp8 any = jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.Class_Cast(c__0)).IsInterface__Z()).Ref(); var tmp9 any = A_arbace_classes_env_A_const_45; var tmp10 any; var G__28000029__11_ any = jrt.NN(jrt.Class_Cast(c__0)).GetSuperclass__Class().Ref()





		if lang.Util_Identical_O_O__Z(G__28000029__11_, nil) { tmp10 = nil } else { tmp10 = lang.IFn_Cast(A_arbace_classes_env_A_const_34.GetRawRoot__O()).Invoke_O__O(G__28000029__11_) }
//line :141:1
		var tmp11 any = tmp10; var tmp12 any = A_arbace_classes_env_A_const_46; var tmp13 any = lang.IFn_Cast(A_arbace_classes_env_A_const_47.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_env_A_const_34.GetRawRoot__O(), jrt.NN(jrt.Class_Cast(c__0)).GetInterfaces__Class1().Ref()); var tmp14 any = A_arbace_classes_env_A_const_48; var tmp15 any = lang.IFn_Cast(A_arbace_classes_env_A_const_34.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetNestHost__Class().Ref()); var tmp16 any = A_arbace_classes_env_A_const_49; var tmp17 any; var G__28000030__11_ any = jrt.NN(jrt.Class_Cast(c__0)).GetDeclaringClass__Class().Ref()








		if lang.Util_Identical_O_O__Z(G__28000030__11_, nil) { tmp17 = nil } else { tmp17 = lang.IFn_Cast(A_arbace_classes_env_A_const_34.GetRawRoot__O()).Invoke_O__O(G__28000030__11_) }
//line :141:1
		var tmp18 any = tmp17; var tmp19 any = A_arbace_classes_env_A_const_50; var tmp20 any; var temp__1927000408__auto____11 any = lang.IFn_Cast(A_arbace_classes_env_A_const_51.GetRawRoot__O()).Invoke_O__O(c__0)









		if jrt.A2g_Truth(temp__1927000408__auto____11) { var fs__12 any = temp__1927000408__auto____11; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_52.GetRawRoot__O()); var tmp22 any; var iter__1927001039__auto____13 any; var tmp23 any = A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_New_O(n__9); var tmp24 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_fn_class
			if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_33, false); A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_fn_class = fncls__5d; tmp24 = fncls__5d } else { tmp24 = fncls__5 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil); tmp22 = lang.IFn_Cast(iter__1927001039__auto____13).Invoke_O__O(fs__12); tmp20 = tmp21.Invoke_O__O(tmp22) } else {




				var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_52.GetRawRoot__O()); var tmp26 any; var iter__1927001039__auto____12 any; var tmp27 any = A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_New_O(n__9); var tmp28 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_34, false); A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_fn_class = fncls__8d; tmp28 = fncls__8d } else { tmp28 = fncls__8 }; iter__1927001039__auto____12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp27, tmp28, nil); tmp26 = lang.IFn_Cast(iter__1927001039__auto____12).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetDeclaredFields__Field1().Ref()); tmp20 = tmp25.Invoke_O__O(tmp26) }
//line :141:1
		var tmp29 any = tmp20; var tmp30 any = A_arbace_classes_env_A_const_53; var tmp31 any = lang.IFn_Cast(A_arbace_classes_env_A_const_54.GetRawRoot__O()).Invoke_O__O(c__0); var tmp32 any = A_arbace_classes_env_A_const_55; var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_52.GetRawRoot__O()); var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_78.GetRawRoot__O()); var tmp35 any; var iter__1927001039__auto____11 any; var tmp36 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_New_O_O(n__9, manns__10); var tmp37 *jrt.Class
		var fncls__17 /*line :141:1*/*jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_fn_class





















		if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_35, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_fn_class = fncls__17d; tmp37 = fncls__17d } else { tmp37 = fncls__17 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp36, tmp37, nil); tmp35 = lang.IFn_Cast(iter__1927001039__auto____11).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetDeclaredMethods__Method1().Ref())
//line :141:1
		var tmp38 any = tmp35; var tmp39 any; var iter__1927001039__auto____11_2 any; var tmp40 any = A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_New_O_O(c__0, n__9); var tmp41 *jrt.Class
		var fncls__20 /*line :141:1*/*jrt.Class = A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_fn_class
































		if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_36, false); A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_fn_class = fncls__20d; tmp41 = fncls__20d } else { tmp41 = fncls__20 }; iter__1927001039__auto____11_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp40, tmp41, nil); tmp39 = lang.IFn_Cast(iter__1927001039__auto____11_2).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetDeclaredConstructors__Constructor1().Ref())
//line :141:1
		info__11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, n__9, tmp5, tmp6, tmp7, tmp8, tmp9, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, tmp18, tmp19, tmp29, tmp30, tmp31, tmp32, tmp33.Invoke_O__O(tmp34.Invoke_O_O__O(tmp38, tmp39)), A_arbace_classes_env_A_const_30, c__0)); var info__12 any; var tmp42 any; var and__1927000168__auto____12 any = lang.IFn_Cast(A_arbace_classes_env_A_const_39.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.Class_Cast(c__0)).IsInterface__Z()).Ref())











































		if jrt.A2g_Truth(and__1927000168__auto____12) { var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_56.GetRawRoot__O()); var tmp44 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_86.GetRawRoot__O()); var tmp45 any = A_arbace_classes_env_reflect_info_fn__28000089_A_New(); var tmp46 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_classes_env_reflect_info_fn__28000089_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_37, false); A_arbace_classes_env_reflect_info_fn__28000089_A_fn_class = fncls__21d; tmp46 = fncls__21d } else { tmp46 = fncls__21 }; tmp42 = tmp43.Invoke_O__O(tmp44.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp45, tmp46, nil), A_arbace_classes_env_A_const_55.Invoke_O__O(info__11))) } else { tmp42 = and__1927000168__auto____12 }; if jrt.A2g_Truth(tmp42) {
			var tmp47 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_16.GetRawRoot__O()); var tmp48 any = A_arbace_classes_env_A_const_55; var tmp49 any = A_arbace_classes_env_A_const_87.GetRawRoot__O(); var tmp50 any; var iter__1927001039__auto____12_2 any; var tmp51 any = A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_New_O(n__9); var tmp52 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_38, false); A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_fn_class = fncls__24d; tmp52 = fncls__24d } else { tmp52 = fncls__24 }; iter__1927001039__auto____12_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp51, tmp52, nil); tmp50 = lang.IFn_Cast(iter__1927001039__auto____12_2).Invoke_O__O(lang.IFn_Cast(lang.IFn_Cast(A_arbace_classes_env_A_const_36.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_env_A_const_88)).Invoke_O__O(n__9)); info__12 = tmp47.Invoke_O_O_O_O__O(info__11, tmp48, tmp49, tmp50) } else {
//line :185:1
				info__12 = info__11
			}


		lang.Reflector_InvokeInstanceMethod_O_String_O1__O(A_arbace_classes_env_A_const_40.GetRawRoot__O(), Lit_39, jrt.RefArrayOf(jrt.Object_class, c__0, info__12))
//line :141:1
		tmp1 = info__12 } }; return nil }(); /*line :139:1*/lang.Compiler_Evaluator_MonitorExit_O__V(locklocal__1927000361__auto____5); if tmp53 != nil { panic(tmp53) }; return tmp1 }



func A_arbace_classes_env_reflect_info_fn__28000027_A_New_O(p0 any) *A_arbace_classes_env_reflect_info_fn__28000027_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_fn__28000027_A{}; t.Ctor_O(p0); return t }
//line :143:1
func (t *A_arbace_classes_env_reflect_info_fn__28000027_A) Ctor_O(c__c any) { t.F_c = c__c }
//line :143:1
func (t *A_arbace_classes_env_reflect_info_fn__28000027_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_41.GetRawRoot__O()); var tmp2 any; var t_ any = t.F_c; t.F_c = nil; tmp2 = t_; return tmp1.Invoke_O__O(tmp2) }








func A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_New_O(p0 any) *A_arbace_classes_env_reflect_info_iter__28000031__28000035_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000031__28000035_A{}; t.Ctor_O(p0); return t }
//line :152:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :152:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_A) Invoke_O_O__O(self, s__28000032__1 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_New_O_O_O(t.F_n, s__28000032__1, self); var tmp2 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_40, false); A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_fn_class = fncls__4d; tmp2 = fncls__4d } else { tmp2 = fncls__4 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :152:1
func A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :152:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A) Ctor_O_O_O(c__n, c__s__28000032, c__iter__28000031 any) { t.F_n = c__n; t.F_s__28000032 = c__s__28000032; t.F_iter__28000031 = c__iter__28000031 }
//line :152:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A) Invoke_O__O(self any) any { { var s__28000032__1 any; var t_ any = t.F_s__28000032; t.F_s__28000032 = nil; s__28000032__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_classes_env_A_const_57.GetRawRoot__O()).Invoke_O__O(s__28000032__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__28000032__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_env_A_const_58.GetRawRoot__O()).Invoke_O__O(s__28000032__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_classes_env_A_const_59.GetRawRoot__O()).Invoke_O__O(s__28000032__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__28000034__6 any = lang.IFn_Cast(A_arbace_classes_env_A_const_60.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_New_O_O_I_O(b__28000034__6, t.F_n, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_41, false); A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__28000031); return lang.IFn_Cast(A_arbace_classes_env_A_const_72.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_74.GetRawRoot__O()).Invoke_O__O(b__28000034__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_75.GetRawRoot__O()).Invoke_O__O(s__28000032__3))) } else { return lang.IFn_Cast(A_arbace_classes_env_A_const_72.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_74.GetRawRoot__O()).Invoke_O__O(b__28000034__6), nil) } } else { var map__28000041__4 any = lang.IFn_Cast(A_arbace_classes_env_A_const_63.GetRawRoot__O()).Invoke_O__O(s__28000032__3); var map__28000041__5 any; if lang.ISeq_InstanceOf(map__28000041__4) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_env_A_const_61.GetRawRoot__O()).Invoke_O__O(map__28000041__4)) { map__28000041__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_classes_env_A_const_62.GetRawRoot__O()).Invoke_O__O(map__28000041__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_env_A_const_57.GetRawRoot__O()).Invoke_O__O(map__28000041__4)) { map__28000041__5 = lang.IFn_Cast(A_arbace_classes_env_A_const_63.GetRawRoot__O()).Invoke_O__O(map__28000041__4) } else { lang.PersistentArrayMap_Init(); map__28000041__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__28000041__5 = map__28000041__4 }; var name__6 any = lang.RT_Get_O_O__O(map__28000041__5, A_arbace_classes_env_A_const_42); var desc__7 any = lang.RT_Get_O_O__O(map__28000041__5, A_arbace_classes_env_A_const_64); var flags__8 any = lang.RT_Get_O_O__O(map__28000041__5, A_arbace_classes_env_A_const_43); var value__9 any = lang.RT_Get_O_O__O(map__28000041__5, A_arbace_classes_env_A_const_65); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_73.GetRawRoot__O()); var tmp5 any = A_arbace_classes_env_A_const_42; var tmp6 any = A_arbace_classes_env_A_const_64; var tmp7 any = A_arbace_classes_env_A_const_43; var tmp8 any = A_arbace_classes_env_A_const_67; var tmp9 any = t.F_n; var tmp10 any = A_arbace_classes_env_A_const_68; var tmp11 any; var tmp12 any; var and__1927000168__auto____10 bool = jrt.Modifier_IsFinal_I__Z(lang.RT_IntCast_O__I(flags__8))

	if and__1927000168__auto____10 { var and__1927000168__auto____11 any = lang.IFn_Cast(A_arbace_classes_env_A_const_24.GetRawRoot__O()).Invoke_O__O(value__9); if jrt.A2g_Truth(and__1927000168__auto____11) { var or__1927000174__auto____12 any = lang.IFn_Cast(A_arbace_classes_env_A_const_69.GetRawRoot__O()).Invoke_O__O(desc__7)
		if jrt.A2g_Truth(or__1927000174__auto____12) { tmp12 = or__1927000174__auto____12 } else { tmp12 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(desc__7, A_arbace_classes_env_A_const_70.GetRawRoot__O())).Ref() } } else {
//line :154:1
			tmp12 = and__1927000168__auto____11 } } else { tmp12 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____10).Ref() }; if jrt.A2g_Truth(tmp12) {

				tmp11 = lang.IFn_Cast(A_arbace_classes_env_A_const_71.GetRawRoot__O()).Invoke_O_O__O(desc__7, value__9) } else {
//line :154:1
					tmp11 = nil }
//line :152:1
	var tmp13 lang.IFn = lang.IFn_Cast(t.F_iter__28000031); return tmp4.Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, name__6, tmp6, desc__7, tmp7, flags__8, tmp8, tmp9, tmp10, tmp11)), tmp13.Invoke_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_76.GetRawRoot__O()).Invoke_O__O(s__28000032__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :152:1
func A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :152:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A) Ctor_O_O_I_O(c__b__28000034, c__n any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__28000034 = c__b__28000034; t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :152:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A) Invoke_O__O(self any) any { { var i__28000033__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__28000033__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var map__28000038__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__28000033__1)); var map__28000038__3 any; if lang.ISeq_InstanceOf(map__28000038__2) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_env_A_const_61.GetRawRoot__O()).Invoke_O__O(map__28000038__2)) { map__28000038__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_classes_env_A_const_62.GetRawRoot__O()).Invoke_O__O(map__28000038__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_env_A_const_57.GetRawRoot__O()).Invoke_O__O(map__28000038__2)) { map__28000038__3 = lang.IFn_Cast(A_arbace_classes_env_A_const_63.GetRawRoot__O()).Invoke_O__O(map__28000038__2) } else { lang.PersistentArrayMap_Init(); map__28000038__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__28000038__3 = map__28000038__2 }; var name__4 any = lang.RT_Get_O_O__O(map__28000038__3, A_arbace_classes_env_A_const_42); var desc__5 any = lang.RT_Get_O_O__O(map__28000038__3, A_arbace_classes_env_A_const_64); var flags__6 any = lang.RT_Get_O_O__O(map__28000038__3, A_arbace_classes_env_A_const_43); var value__7 any = lang.RT_Get_O_O__O(map__28000038__3, A_arbace_classes_env_A_const_65); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_66.GetRawRoot__O()); var tmp3 any = t.F_b__28000034; var tmp4 any = A_arbace_classes_env_A_const_42; var tmp5 any = A_arbace_classes_env_A_const_64; var tmp6 any = A_arbace_classes_env_A_const_43; var tmp7 any = A_arbace_classes_env_A_const_67; var tmp8 any = t.F_n; var tmp9 any = A_arbace_classes_env_A_const_68; var tmp10 any; var tmp11 any; var and__1927000168__auto____8 bool = jrt.Modifier_IsFinal_I__Z(lang.RT_IntCast_O__I(flags__6))

	if and__1927000168__auto____8 { var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_classes_env_A_const_24.GetRawRoot__O()).Invoke_O__O(value__7); if jrt.A2g_Truth(and__1927000168__auto____9) { var or__1927000174__auto____10 any = lang.IFn_Cast(A_arbace_classes_env_A_const_69.GetRawRoot__O()).Invoke_O__O(desc__5)
		if jrt.A2g_Truth(or__1927000174__auto____10) { tmp11 = or__1927000174__auto____10 } else { tmp11 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(desc__5, A_arbace_classes_env_A_const_70.GetRawRoot__O())).Ref() } } else {
//line :154:1
			tmp11 = and__1927000168__auto____9 } } else { tmp11 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____8).Ref() }; if jrt.A2g_Truth(tmp11) {

				tmp10 = lang.IFn_Cast(A_arbace_classes_env_A_const_71.GetRawRoot__O()).Invoke_O_O__O(desc__5, value__7) } else {
//line :154:1
					tmp10 = nil }
//line :152:1
	tmp2.Invoke_O_O__O(tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, name__4, tmp5, desc__5, tmp6, flags__6, tmp7, tmp8, tmp9, tmp10))); i__28000033__1 = lang.Numbers_Unchecked_inc_J__J(i__28000033__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }




func A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_New_O(p0 any) *A_arbace_classes_env_reflect_info_iter__28000045__28000049_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000045__28000049_A{}; t.Ctor_O(p0); return t }
//line :157:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :157:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_A) Invoke_O_O__O(self, s__28000046__1 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_New_O_O_O(t.F_n, s__28000046__1, self); var tmp2 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_42, false); A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_fn_class = fncls__7d; tmp2 = fncls__7d } else { tmp2 = fncls__7 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :157:1
func A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :157:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A) Ctor_O_O_O(c__n, c__s__28000046, c__iter__28000045 any) { t.F_n = c__n; t.F_s__28000046 = c__s__28000046; t.F_iter__28000045 = c__iter__28000045 }
//line :157:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A) Invoke_O__O(self any) any { { var s__28000046__1 any; var t_ any = t.F_s__28000046; t.F_s__28000046 = nil; s__28000046__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_classes_env_A_const_57.GetRawRoot__O()).Invoke_O__O(s__28000046__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__28000046__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_env_A_const_58.GetRawRoot__O()).Invoke_O__O(s__28000046__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_classes_env_A_const_59.GetRawRoot__O()).Invoke_O__O(s__28000046__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__28000048__6 any = lang.IFn_Cast(A_arbace_classes_env_A_const_60.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_New_O_O_I_O(t.F_n, b__28000048__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_43, false); A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_fn_class = fncls__6d; tmp2 = fncls__6d } else { tmp2 = fncls__6 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__28000045); return lang.IFn_Cast(A_arbace_classes_env_A_const_72.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_74.GetRawRoot__O()).Invoke_O__O(b__28000048__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_75.GetRawRoot__O()).Invoke_O__O(s__28000046__3))) } else { return lang.IFn_Cast(A_arbace_classes_env_A_const_72.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_74.GetRawRoot__O()).Invoke_O__O(b__28000048__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_classes_env_A_const_63.GetRawRoot__O()).Invoke_O__O(s__28000046__3); var tmp4 any = A_arbace_classes_env_A_const_42; var tmp5 any = jrt.NN(jrt.Field_Cast(f__4)).GetName__String().Ref(); var tmp6 any = A_arbace_classes_env_A_const_64; var tmp7 any = lang.IFn_Cast(A_arbace_classes_env_A_const_77.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Field_Cast(f__4)).GetType__Class().Ref()); var tmp8 any = A_arbace_classes_env_A_const_43; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__28000045); return lang.IFn_Cast(A_arbace_classes_env_A_const_73.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp6, tmp7, tmp8, jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.Field_Cast(f__4)).GetModifiers__I()).Ref(), A_arbace_classes_env_A_const_67, t.F_n, A_arbace_classes_env_A_const_68, nil)), tmp9.Invoke_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_76.GetRawRoot__O()).Invoke_O__O(s__28000046__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :157:1
func A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :157:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A) Ctor_O_O_I_O(c__n, c__b__28000048 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__28000048 = c__b__28000048; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :157:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A) Invoke_O__O(self any) any { { var i__28000047__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__28000047__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__28000047__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_66.GetRawRoot__O()); var tmp3 any = t.F_b__28000048; var tmp4 any = A_arbace_classes_env_A_const_42; var tmp5 any = jrt.NN(jrt.Field_Cast(f__2)).GetName__String().Ref(); var tmp6 any = A_arbace_classes_env_A_const_64; var tmp7 any = lang.IFn_Cast(A_arbace_classes_env_A_const_77.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Field_Cast(f__2)).GetType__Class().Ref()); var tmp8 any = A_arbace_classes_env_A_const_43; tmp2.Invoke_O_O__O(tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp6, tmp7, tmp8, jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.Field_Cast(f__2)).GetModifiers__I()).Ref(), A_arbace_classes_env_A_const_67, t.F_n, A_arbace_classes_env_A_const_68, nil))); i__28000047__1 = lang.Numbers_Unchecked_inc_J__J(i__28000047__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }





func A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_New_O_O(p0, p1 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_A{}; t.Ctor_O_O(p0, p1); return t }
//line :163:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_A) Ctor_O_O(c__n, c__manns any) { t.F_n = c__n; t.F_manns = c__manns }
//line :163:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_A) Invoke_O_O__O(self, s__28000056__1 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_New_O_O_O_O(t.F_n, t.F_manns, s__28000056__1, self); var tmp2 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_44, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_fn_class = fncls__16d; tmp2 = fncls__16d } else { tmp2 = fncls__16 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :163:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :163:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A) Ctor_O_O_O_O(c__n, c__manns, c__s__28000056, c__iter__28000055 any) { t.F_n = c__n; t.F_manns = c__manns; t.F_s__28000056 = c__s__28000056; t.F_iter__28000055 = c__iter__28000055 }
//line :163:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A) Invoke_O__O(self any) any { { var s__28000056__1 any; var t_ any = t.F_s__28000056; t.F_s__28000056 = nil; s__28000056__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_classes_env_A_const_57.GetRawRoot__O()).Invoke_O__O(s__28000056__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__28000056__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_env_A_const_58.GetRawRoot__O()).Invoke_O__O(s__28000056__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_classes_env_A_const_59.GetRawRoot__O()).Invoke_O__O(s__28000056__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__28000058__6 any = lang.IFn_Cast(A_arbace_classes_env_A_const_60.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_New_O_O_O_I_O(t.F_n, b__28000058__6, t.F_manns, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_45, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_fn_class = fncls__12d; tmp2 = fncls__12d } else { tmp2 = fncls__12 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__28000055); return lang.IFn_Cast(A_arbace_classes_env_A_const_72.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_74.GetRawRoot__O()).Invoke_O__O(b__28000058__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_75.GetRawRoot__O()).Invoke_O__O(s__28000056__3))) } else { return lang.IFn_Cast(A_arbace_classes_env_A_const_72.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_74.GetRawRoot__O()).Invoke_O__O(b__28000058__6), nil) } } else { var m__4 any = lang.IFn_Cast(A_arbace_classes_env_A_const_63.GetRawRoot__O()).Invoke_O__O(s__28000056__3); var desc__5 any = lang.IFn_Cast(A_arbace_classes_env_A_const_79.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_80.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_env_A_const_77.GetRawRoot__O(), jrt.NN(jrt.Method_Cast(m__4)).GetParameterTypes__Class1().Ref()), lang.IFn_Cast(A_arbace_classes_env_A_const_77.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Method_Cast(m__4)).GetReturnType__Class().Ref())); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_73.GetRawRoot__O()); var tmp5 any = A_arbace_classes_env_A_const_42; var tmp6 any = jrt.NN(jrt.Method_Cast(m__4)).GetName__String().Ref(); var tmp7 any = A_arbace_classes_env_A_const_64; var tmp8 any = A_arbace_classes_env_A_const_43; var tmp9 any = jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.Method_Cast(m__4)).GetModifiers__I()).Ref(); var tmp10 any = A_arbace_classes_env_A_const_67; var tmp11 any = t.F_n; var tmp12 any = A_arbace_classes_env_A_const_81; var tmp13 any = lang.IFn_Cast(A_arbace_classes_env_A_const_47.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_env_A_const_34.GetRawRoot__O(), jrt.NN(jrt.Method_Cast(m__4)).GetExceptionTypes__Class1().Ref()); var tmp14 any = A_arbace_classes_env_A_const_82; var tmp15 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_New_O_O_O(m__4, desc__5, t.F_manns); var tmp16 *jrt.Class
														var fncls__13 /*line :163:1*/*jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_fn_class






	if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_46, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_fn_class = fncls__13d; tmp16 = fncls__13d } else { tmp16 = fncls__13 }
//line :163:1
	var tmp17 any = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil)); var tmp18 any = A_arbace_classes_env_A_const_84; var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_85.GetRawRoot__O()); var tmp20 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_New_O_O_O(m__4, desc__5, t.F_manns); var tmp21 *jrt.Class
	var fncls__15 /*line :163:1*/*jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_fn_class








	if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_47, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_fn_class = fncls__15d; tmp21 = fncls__15d } else { tmp21 = fncls__15 }
//line :163:1
	var tmp22 lang.IFn = lang.IFn_Cast(t.F_iter__28000055); return tmp4.Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, desc__5, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp17, tmp18, tmp19.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil), jrt.NN(jrt.Method_Cast(m__4)).GetParameterTypes__Class1().Ref()))), tmp22.Invoke_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_76.GetRawRoot__O()).Invoke_O__O(s__28000056__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :163:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :163:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A) Ctor_O_O_O_I_O(c__n, c__b__28000058, c__manns any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__28000058 = c__b__28000058; t.F_manns = c__manns; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :163:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A) Invoke_O__O(self any) any { { var i__28000057__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__28000057__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__28000057__1)); var desc__3 any = lang.IFn_Cast(A_arbace_classes_env_A_const_79.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_80.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_env_A_const_77.GetRawRoot__O(), jrt.NN(jrt.Method_Cast(m__2)).GetParameterTypes__Class1().Ref()), lang.IFn_Cast(A_arbace_classes_env_A_const_77.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Method_Cast(m__2)).GetReturnType__Class().Ref())); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_66.GetRawRoot__O()); var tmp3 any = t.F_b__28000058; var tmp4 any = A_arbace_classes_env_A_const_42; var tmp5 any = jrt.NN(jrt.Method_Cast(m__2)).GetName__String().Ref(); var tmp6 any = A_arbace_classes_env_A_const_64; var tmp7 any = A_arbace_classes_env_A_const_43; var tmp8 any = jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.Method_Cast(m__2)).GetModifiers__I()).Ref(); var tmp9 any = A_arbace_classes_env_A_const_67; var tmp10 any = t.F_n; var tmp11 any = A_arbace_classes_env_A_const_81; var tmp12 any = lang.IFn_Cast(A_arbace_classes_env_A_const_47.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_env_A_const_34.GetRawRoot__O(), jrt.NN(jrt.Method_Cast(m__2)).GetExceptionTypes__Class1().Ref()); var tmp13 any = A_arbace_classes_env_A_const_82; var tmp14 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_New_O_O_O(m__2, desc__3, t.F_manns); var tmp15 *jrt.Class
																var fncls__9 /*line :163:1*/*jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_fn_class






	if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_48, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_fn_class = fncls__9d; tmp15 = fncls__9d } else { tmp15 = fncls__9 }
//line :163:1
	var tmp16 any = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil)); var tmp17 any = A_arbace_classes_env_A_const_84; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_85.GetRawRoot__O()); var tmp19 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_New_O_O_O(m__2, desc__3, t.F_manns); var tmp20 *jrt.Class
	var fncls__11 /*line :163:1*/*jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_fn_class








	if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_49, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_fn_class = fncls__11d; tmp20 = fncls__11d } else { tmp20 = fncls__11 }
//line :163:1
	tmp2.Invoke_O_O__O(tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp6, desc__3, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13, tmp16, tmp17, tmp18.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil), jrt.NN(jrt.Method_Cast(m__2)).GetParameterTypes__Class1().Ref())))); i__28000057__1 = lang.Numbers_Unchecked_inc_J__J(i__28000057__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }






func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :170:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A) Ctor_O_O_O(c__m, c__desc, c__manns any) { t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :170:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_83.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_8.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_manns; t.F_manns = nil; tmp3 = t_; var tmp4 any = tmp2.Invoke_O__O(tmp3); var tmp5 any; var t__2 any = t.F_m; t.F_m = nil; tmp5 = t__2; var tmp6 any = jrt.NN(jrt.Method_Cast(tmp5)).GetName__String().Ref(); var tmp7 any; var t__3 any = t.F_desc; t.F_desc = nil; tmp7 = t__3; return tmp1.Invoke_O_O__O(tmp4, lang.Tuple_Create_O_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7), A_arbace_classes_env_A_const_82)) }
//line :170:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :170:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A) Ctor_O_O_O(c__m, c__desc, c__manns any) { t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :170:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_83.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_8.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_manns; t.F_manns = nil; tmp3 = t_; var tmp4 any = tmp2.Invoke_O__O(tmp3); var tmp5 any; var t__2 any = t.F_m; t.F_m = nil; tmp5 = t__2; var tmp6 any = jrt.NN(jrt.Method_Cast(tmp5)).GetName__String().Ref(); var tmp7 any; var t__3 any = t.F_desc; t.F_desc = nil; tmp7 = t__3; return tmp1.Invoke_O_O__O(tmp4, lang.Tuple_Create_O_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7), A_arbace_classes_env_A_const_82)) }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :172:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A) Ctor_O_O_O(c__m, c__desc, c__manns any) { t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :172:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A) Invoke_O_O_O__O(self, i__1, ___2 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_New_O_O_O_O(i__1, t.F_m, t.F_desc, t.F_manns); var tmp2 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_50, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_fn_class = fncls__10d; tmp2 = fncls__10d } else { tmp2 = fncls__10 }; return lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :172:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :172:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A) Ctor_O_O_O_O(c__i, c__m, c__desc, c__manns any) { t.F_i = c__i; t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :172:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_83.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_8.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_manns; t.F_manns = nil; tmp3 = t_; var tmp4 any = tmp2.Invoke_O__O(tmp3); var tmp5 any; var t__2 any = t.F_m; t.F_m = nil; tmp5 = t__2; var tmp6 any = jrt.NN(jrt.Method_Cast(tmp5)).GetName__String().Ref(); var tmp7 any; var t__3 any = t.F_desc; t.F_desc = nil; tmp7 = t__3; var tmp8 any = lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7); var tmp9 any = A_arbace_classes_env_A_const_84; var tmp10 any; var t__4 any = t.F_i; t.F_i = nil; tmp10 = t__4; return tmp1.Invoke_O_O__O(tmp4, lang.Tuple_Create_O_O_O__IPersistentVector(tmp8, tmp9, tmp10)) }
//line :172:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :172:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A) Ctor_O_O_O(c__m, c__desc, c__manns any) { t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :172:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A) Invoke_O_O_O__O(self, i__1, ___2 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_New_O_O_O_O(i__1, t.F_m, t.F_desc, t.F_manns); var tmp2 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_51, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_fn_class = fncls__14d; tmp2 = fncls__14d } else { tmp2 = fncls__14 }; return lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :172:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :172:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A) Ctor_O_O_O_O(c__i, c__m, c__desc, c__manns any) { t.F_i = c__i; t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :172:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_83.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_8.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_manns; t.F_manns = nil; tmp3 = t_; var tmp4 any = tmp2.Invoke_O__O(tmp3); var tmp5 any; var t__2 any = t.F_m; t.F_m = nil; tmp5 = t__2; var tmp6 any = jrt.NN(jrt.Method_Cast(tmp5)).GetName__String().Ref(); var tmp7 any; var t__3 any = t.F_desc; t.F_desc = nil; tmp7 = t__3; var tmp8 any = lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7); var tmp9 any = A_arbace_classes_env_A_const_84; var tmp10 any; var t__4 any = t.F_i; t.F_i = nil; tmp10 = t__4; return tmp1.Invoke_O_O__O(tmp4, lang.Tuple_Create_O_O_O__IPersistentVector(tmp8, tmp9, tmp10)) }

func A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_New_O_O(p0, p1 any) *A_arbace_classes_env_reflect_info_iter__28000077__28000081_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000077__28000081_A{}; t.Ctor_O_O(p0, p1); return t }
//line :174:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_A) Ctor_O_O(c__c, c__n any) { t.F_c = c__c; t.F_n = c__n }
//line :174:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_A) Invoke_O_O__O(self, s__28000078__1 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_New_O_O_O_O(t.F_c, t.F_n, s__28000078__1, self); var tmp2 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_52, false); A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_fn_class = fncls__19d; tmp2 = fncls__19d } else { tmp2 = fncls__19 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :174:1
func A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :174:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A) Ctor_O_O_O_O(c__c, c__n, c__s__28000078, c__iter__28000077 any) { t.F_c = c__c; t.F_n = c__n; t.F_s__28000078 = c__s__28000078; t.F_iter__28000077 = c__iter__28000077 }
//line :174:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A) Invoke_O__O(self any) any { { var s__28000078__1 any; var t_ any = t.F_s__28000078; t.F_s__28000078 = nil; s__28000078__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_classes_env_A_const_57.GetRawRoot__O()).Invoke_O__O(s__28000078__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__28000078__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_env_A_const_58.GetRawRoot__O()).Invoke_O__O(s__28000078__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_classes_env_A_const_59.GetRawRoot__O()).Invoke_O__O(s__28000078__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__28000080__6 any = lang.IFn_Cast(A_arbace_classes_env_A_const_60.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_New_O_O_O_I_O(t.F_c, t.F_n, b__28000080__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_53, false); A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_fn_class = fncls__18d; tmp2 = fncls__18d } else { tmp2 = fncls__18 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__28000077); return lang.IFn_Cast(A_arbace_classes_env_A_const_72.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_74.GetRawRoot__O()).Invoke_O__O(b__28000080__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_75.GetRawRoot__O()).Invoke_O__O(s__28000078__3))) } else { return lang.IFn_Cast(A_arbace_classes_env_A_const_72.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_74.GetRawRoot__O()).Invoke_O__O(b__28000080__6), nil) } } else { var m__4 any = lang.IFn_Cast(A_arbace_classes_env_A_const_63.GetRawRoot__O()).Invoke_O__O(s__28000078__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_73.GetRawRoot__O()); var tmp5 any = A_arbace_classes_env_A_const_42; var tmp6 any = A_arbace_classes_env_A_const_64; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_79.GetRawRoot__O()); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_80.GetRawRoot__O()); var tmp9 any = A_arbace_classes_env_A_const_77.GetRawRoot__O(); var tmp10 any; var G__28000086__5_ any = lang.IFn_Cast(A_arbace_classes_env_A_const_57.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Constructor_Cast(m__4)).GetParameterTypes__Class1().Ref())

	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_env_A_const_54.GetRawRoot__O()).Invoke_O__O(t.F_c)) { tmp10 = lang.IFn_Cast(A_arbace_classes_env_A_const_76.GetRawRoot__O()).Invoke_O__O(G__28000086__5_) } else { tmp10 = G__28000086__5_ }
//line :174:1
	var tmp11 any = tmp7.Invoke_O_O__O(tmp8.Invoke_O_O__O(tmp9, tmp10), Lit_54); var tmp12 any = A_arbace_classes_env_A_const_43; var tmp13 any = jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.Constructor_Cast(m__4)).GetModifiers__I()).Ref(); var tmp14 any = A_arbace_classes_env_A_const_67; var tmp15 any = t.F_n; var tmp16 any = A_arbace_classes_env_A_const_81; var tmp17 lang.IFn = lang.IFn_Cast(t.F_iter__28000077); return tmp4.Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, Lit_13, tmp6, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, lang.IFn_Cast(A_arbace_classes_env_A_const_47.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_env_A_const_34.GetRawRoot__O(), jrt.NN(jrt.Constructor_Cast(m__4)).GetExceptionTypes__Class1().Ref()))), tmp17.Invoke_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_76.GetRawRoot__O()).Invoke_O__O(s__28000078__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :174:1
func A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :174:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A) Ctor_O_O_O_I_O(c__c, c__n, c__b__28000080 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_c = c__c; t.F_n = c__n; t.F_b__28000080 = c__b__28000080; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :174:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A) Invoke_O__O(self any) any { { var i__28000079__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__28000079__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__28000079__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_66.GetRawRoot__O()); var tmp3 any = t.F_b__28000080; var tmp4 any = A_arbace_classes_env_A_const_42; var tmp5 any = A_arbace_classes_env_A_const_64; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_79.GetRawRoot__O()); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_80.GetRawRoot__O()); var tmp8 any = A_arbace_classes_env_A_const_77.GetRawRoot__O(); var tmp9 any; var G__28000084__3_ any = lang.IFn_Cast(A_arbace_classes_env_A_const_57.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Constructor_Cast(m__2)).GetParameterTypes__Class1().Ref())

	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_env_A_const_54.GetRawRoot__O()).Invoke_O__O(t.F_c)) { tmp9 = lang.IFn_Cast(A_arbace_classes_env_A_const_76.GetRawRoot__O()).Invoke_O__O(G__28000084__3_) } else { tmp9 = G__28000084__3_ }
//line :174:1
	var tmp10 any = tmp6.Invoke_O_O__O(tmp7.Invoke_O_O__O(tmp8, tmp9), Lit_54); var tmp11 any = A_arbace_classes_env_A_const_43; var tmp12 any = jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.Constructor_Cast(m__2)).GetModifiers__I()).Ref(); var tmp13 any = A_arbace_classes_env_A_const_67; var tmp14 any = t.F_n; var tmp15 any = A_arbace_classes_env_A_const_81; tmp2.Invoke_O_O__O(tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, Lit_13, tmp5, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, lang.IFn_Cast(A_arbace_classes_env_A_const_47.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_env_A_const_34.GetRawRoot__O(), jrt.NN(jrt.Constructor_Cast(m__2)).GetExceptionTypes__Class1().Ref())))); i__28000079__1 = lang.Numbers_Unchecked_inc_J__J(i__28000079__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }










func A_arbace_classes_env_reflect_info_fn__28000089_A_New() *A_arbace_classes_env_reflect_info_fn__28000089_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_fn__28000089_A{}; t.Ctor(); return t }
//line :185:1
func (t *A_arbace_classes_env_reflect_info_fn__28000089_A) Ctor() {}
//line :185:1
func (t *A_arbace_classes_env_reflect_info_fn__28000089_A) Invoke_O_O__O(self, p1__28000026_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_13, A_arbace_classes_env_A_const_42.Invoke_O__O(p1__28000026_SHARP___1))).Ref() }
func A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_New_O(p0 any) *A_arbace_classes_env_reflect_info_iter__28000091__28000095_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000091__28000095_A{}; t.Ctor_O(p0); return t }
//line :186:1
func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :186:1
func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_A) Invoke_O_O__O(self, s__28000092__1 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_New_O_O_O(t.F_n, s__28000092__1, self); var tmp2 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_55, false); A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_fn_class = fncls__23d; tmp2 = fncls__23d } else { tmp2 = fncls__23 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :186:1
func A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :186:1
func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A) Ctor_O_O_O(c__n, c__s__28000092, c__iter__28000091 any) { t.F_n = c__n; t.F_s__28000092 = c__s__28000092; t.F_iter__28000091 = c__iter__28000091 }
//line :186:1
func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A) Invoke_O__O(self any) any { { var s__28000092__1 any; var t_ any = t.F_s__28000092; t.F_s__28000092 = nil; s__28000092__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_classes_env_A_const_57.GetRawRoot__O()).Invoke_O__O(s__28000092__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__28000092__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_env_A_const_58.GetRawRoot__O()).Invoke_O__O(s__28000092__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_classes_env_A_const_59.GetRawRoot__O()).Invoke_O__O(s__28000092__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__28000094__6 any = lang.IFn_Cast(A_arbace_classes_env_A_const_60.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_New_O_I_O_O(t.F_n, size__1927001038__auto____5, b__28000094__6, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_56, false); A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_fn_class = fncls__22d; tmp2 = fncls__22d } else { tmp2 = fncls__22 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__28000091); return lang.IFn_Cast(A_arbace_classes_env_A_const_72.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_74.GetRawRoot__O()).Invoke_O__O(b__28000094__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_75.GetRawRoot__O()).Invoke_O__O(s__28000092__3))) } else { return lang.IFn_Cast(A_arbace_classes_env_A_const_72.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_74.GetRawRoot__O()).Invoke_O__O(b__28000094__6), nil) } } else { var vec__28000102__4 any = lang.IFn_Cast(A_arbace_classes_env_A_const_63.GetRawRoot__O()).Invoke_O__O(s__28000092__3); var d__5 any = lang.RT_Nth_O_I_O__O(vec__28000102__4, lang.RT_IntCast_J__I(0), nil); var f__6 any = lang.RT_Nth_O_I_O__O(vec__28000102__4, lang.RT_IntCast_J__I(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_73.GetRawRoot__O()); var tmp5 any = A_arbace_classes_env_A_const_42; var tmp6 any = A_arbace_classes_env_A_const_64; var tmp7 any = A_arbace_classes_env_A_const_43; var tmp8 any = A_arbace_classes_env_A_const_67; var tmp9 any = t.F_n; var tmp10 any = A_arbace_classes_env_A_const_81; var tmp11 *lang.PersistentVector; lang.PersistentVector_Init(); tmp11 = lang.PersistentVector_EMPTY; var tmp12 lang.IFn = lang.IFn_Cast(t.F_iter__28000091); return tmp4.Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, Lit_13, tmp6, d__5, tmp7, f__6, tmp8, tmp9, tmp10, tmp11.Ref())), tmp12.Invoke_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_76.GetRawRoot__O()).Invoke_O__O(s__28000092__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :186:1
func A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :186:1
func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A) Ctor_O_I_O_O(c__n any, c__size__1927001038__auto__ int32, c__b__28000094, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__28000094 = c__b__28000094; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :186:1
func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A) Invoke_O__O(self any) any { { var i__28000093__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__28000093__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__28000098__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__28000093__1)); var d__3 any = lang.RT_Nth_O_I_O__O(vec__28000098__2, lang.RT_IntCast_J__I(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O(vec__28000098__2, lang.RT_IntCast_J__I(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_66.GetRawRoot__O()); var tmp3 any = t.F_b__28000094; var tmp4 any = A_arbace_classes_env_A_const_42; var tmp5 any = A_arbace_classes_env_A_const_64; var tmp6 any = A_arbace_classes_env_A_const_43; var tmp7 any = A_arbace_classes_env_A_const_67; var tmp8 any = t.F_n; var tmp9 any = A_arbace_classes_env_A_const_81; var tmp10 *lang.PersistentVector; lang.PersistentVector_Init(); tmp10 = lang.PersistentVector_EMPTY; tmp2.Invoke_O_O__O(tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, Lit_13, tmp5, d__3, tmp6, f__4, tmp7, tmp8, tmp9, tmp10.Ref()))); i__28000093__1 = lang.Numbers_Unchecked_inc_J__J(i__28000093__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }








func A_arbace_classes_env_info_A_New() *A_arbace_classes_env_info_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_info_A{}; t.Ctor(); return t }
//line :195:1
func (t *A_arbace_classes_env_info_A) Ctor() {}
//line :195:1
func (t *A_arbace_classes_env_info_A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any = n__0; if jrt.A2g_Truth(and__1927000168__auto____2) { tmp1 = lang.IFn_Cast(A_arbace_classes_env_A_const_39.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_20.GetRawRoot__O()).Invoke_O_O__O(n__0, Lit_11)) } else { tmp1 = and__1927000168__auto____2 }; if jrt.A2g_Truth(tmp1) { var or__1927000174__auto____2 any; var G__28000108__2_ any = A_arbace_classes_env_A_const_89.Get__O(); var G__28000108__3_ any
		if lang.Util_Identical_O_O__Z(G__28000108__2_, nil) { G__28000108__3_ = nil } else { G__28000108__3_ = lang.IFn_Cast(A_arbace_classes_env_A_const_8.GetRawRoot__O()).Invoke_O__O(G__28000108__2_) }; if lang.Util_Identical_O_O__Z(G__28000108__3_, nil) { or__1927000174__auto____2 = nil } else { or__1927000174__auto____2 = lang.RT_Get_O_O__O(G__28000108__3_, n__0) }; if jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else {
			if jrt.A2g_Truth(A_arbace_classes_env_A_const_19.Get__O()) {
				if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_env_A_const_18.GetRawRoot__O()).Invoke_O__O(n__0)) { return nil } else { var tmp2 *lang.Keyword = A_arbace_classes_env_A_const_90; return tmp2.Invoke_O__O(lang.RT_Get_O_O__O(A_arbace_classes_env_A_const_19.Get__O(), n__0)) } } else {
//line :200:1
					var temp__1927000414__auto____3 any = lang.IFn_Cast(A_arbace_classes_env_A_const_25.GetRawRoot__O()).Invoke_O__O(n__0)

					if jrt.A2g_Truth(temp__1927000414__auto____3) { var c__4 any = temp__1927000414__auto____3; var d__5 any = lang.RT_Get_O_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_8.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_env_A_const_92.GetRawRoot__O()), n__0); var tmp3 any
						var and__1927000168__auto____6 any = d__5
						if jrt.A2g_Truth(and__1927000168__auto____6) { tmp3 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Identical_O_O__Z(A_arbace_classes_env_A_const_30.Invoke_O__O(d__5), c__4)).Ref() } else { tmp3 = and__1927000168__auto____6 }; if jrt.A2g_Truth(tmp3) { return d__5 } else { return lang.IFn_Cast(A_arbace_classes_env_A_const_91.GetRawRoot__O()).Invoke_O__O(c__4) } } else {
//line :202:1
							return nil } } } } else {
//line :198:1
								return nil
							}
}





func A_arbace_classes_env_info_BANG__A_New() *A_arbace_classes_env_info_BANG__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_info_BANG__A{}; t.Ctor(); return t }
//line :206:1
func (t *A_arbace_classes_env_info_BANG__A) Ctor() {}
//line :206:1
func (t *A_arbace_classes_env_info_BANG__A) Invoke_O_O__O(self, n__0 any) any { var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_classes_env_A_const_93.GetRawRoot__O()).Invoke_O__O(n__0); if
										jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_classes_env_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_20, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_classes_env_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_32.GetRawRoot__O()).Invoke_O__O(n__0), Lit_21, Lit_22))).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_env_A_const_30, n__0)))))) } }

func A_arbace_classes_env_interface_QMARK__A_New() *A_arbace_classes_env_interface_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_interface_QMARK__A{}; t.Ctor(); return t }
//line :209:1
func (t *A_arbace_classes_env_interface_QMARK__A) Ctor() {}
//line :209:1
func (t *A_arbace_classes_env_interface_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var i__2 any = lang.IFn_Cast(A_arbace_classes_env_A_const_93.GetRawRoot__O()).Invoke_O__O(n__0); var tmp1 any; var or__1927000174__auto____3 any = A_arbace_classes_env_A_const_44.Invoke_O__O(i__2); if
											jrt.A2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var G__28000111__4_ any = A_arbace_classes_env_A_const_43.Invoke_O__O(i__2); var G__28000111__5_ any; if lang.Util_Identical_O_O__Z(G__28000111__4_, nil) { G__28000111__5_ = nil } else { G__28000111__5_ = jrt.Long_ValueOf_J__Long(lang.Numbers_And_O_J__J(G__28000111__4_, 512)).Ref() }; if lang.Util_Identical_O_O__Z(G__28000111__5_, nil) { tmp1 = nil } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsPos_O__Z(G__28000111__5_)).Ref() } }; return jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(tmp1)).Ref() }

func A_arbace_classes_env_const_value_A_New() *A_arbace_classes_env_const_value_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_const_value_A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_classes_env_const_value_A) Ctor() {}
//line :212:1
func (t *A_arbace_classes_env_const_value_A) Invoke_O_O__O(self, field__0 any) any { var c__2 any = A_arbace_classes_env_A_const_68.Invoke_O__O(field__0); if
											jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_env_A_const_94.GetRawRoot__O()).Invoke_O__O(c__2)) { return lang.IFn_Cast(A_arbace_classes_env_A_const_8.GetRawRoot__O()).Invoke_O__O(c__2) } else { return c__2 } }

func A_arbace_classes_env_supertypes_A_New() *A_arbace_classes_env_supertypes_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_supertypes_A{}; t.Ctor(); return t }
//line :215:1
func (t *A_arbace_classes_env_supertypes_A) Ctor() {}
//line :215:1
func (t *A_arbace_classes_env_supertypes_A) Invoke_O_O__O(self, n__0 any) any { var i__2 any = lang.IFn_Cast(A_arbace_classes_env_A_const_95.GetRawRoot__O()).Invoke_O__O(n__0); var G__28000114__3_ any = lang.IFn_Cast(A_arbace_classes_env_A_const_52.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_env_A_const_46.Invoke_O__O(i__2)); if


	jrt.A2g_Truth(A_arbace_classes_env_A_const_45.Invoke_O__O(i__2)) { return lang.IFn_Cast(A_arbace_classes_env_A_const_52.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_73.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_env_A_const_45.Invoke_O__O(i__2), G__28000114__3_)) } else { return G__28000114__3_ } }

func A_arbace_classes_env_subclass_QMARK__A_New() *A_arbace_classes_env_subclass_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_subclass_QMARK__A{}; t.Ctor(); return t }
//line :220:1
func (t *A_arbace_classes_env_subclass_QMARK__A) Ctor() {}
//line :220:1
func (t *A_arbace_classes_env_subclass_QMARK__A) Invoke_O_O_O__O(self, a__0, b__1 any) any { var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z(a__0, b__1); if or__1927000174__auto____3 {


	return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____3).Ref() } else { var or__1927000174__auto____4 bool = lang.Util_Equiv_O_O__Z(b__1, Lit_4); if or__1927000174__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____4).Ref() } else {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_96.GetRawRoot__O()); var tmp2 any = A_arbace_classes_env_subclass_QMARK__fn__28000117_A_New_O(b__1); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_classes_env_subclass_QMARK__fn__28000117_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_60, false); A_arbace_classes_env_subclass_QMARK__fn__28000117_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; var tmp4 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp5 any; var temp__1927000414__auto____5 any = lang.IFn_Cast(A_arbace_classes_env_A_const_93.GetRawRoot__O()).Invoke_O__O(a__0); if jrt.A2g_Truth(temp__1927000414__auto____5) { var i__6 any = temp__1927000414__auto____5; var G__28000119__7_ any = lang.IFn_Cast(A_arbace_classes_env_A_const_52.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_env_A_const_46.Invoke_O__O(i__6))
			if jrt.A2g_Truth(A_arbace_classes_env_A_const_45.Invoke_O__O(i__6)) { tmp5 = lang.IFn_Cast(A_arbace_classes_env_A_const_9.GetRawRoot__O()).Invoke_O_O__O(G__28000119__7_, A_arbace_classes_env_A_const_45.Invoke_O__O(i__6)) } else { tmp5 = G__28000119__7_ } } else {
//line :224:1
				tmp5 = nil }; return jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(tmp1.Invoke_O_O__O(tmp4, tmp5))).Ref() } } }
//line :224:1
func A_arbace_classes_env_subclass_QMARK__fn__28000117_A_New_O(p0 any) *A_arbace_classes_env_subclass_QMARK__fn__28000117_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_subclass_QMARK__fn__28000117_A{}; t.Ctor_O(p0); return t }
//line :224:1
func (t *A_arbace_classes_env_subclass_QMARK__fn__28000117_A) Ctor_O(c__b any) { t.F_b = c__b }
//line :224:1
func (t *A_arbace_classes_env_subclass_QMARK__fn__28000117_A) Invoke_O_O__O(self, p1__28000116_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_classes_env_A_const_97.GetRawRoot__O()).Invoke_O_O__O(p1__28000116_SHARP___1, t.F_b) }


func A_arbace_classes_env_assignable_QMARK__A_New() *A_arbace_classes_env_assignable_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_assignable_QMARK__A{}; t.Ctor(); return t }
//line :227:1
func (t *A_arbace_classes_env_assignable_QMARK__A) Ctor() {}
//line :227:1
func (t *A_arbace_classes_env_assignable_QMARK__A) Invoke_O_O_O__O(self, from__0, to__1 any) any {


	if lang.Util_Equiv_O_O__Z(from__0, to__1) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { if lang.Util_Equiv_O_O__Z(from__0, A_arbace_classes_env_A_const_98) {

		return lang.IFn_Cast(A_arbace_classes_env_A_const_99.GetRawRoot__O()).Invoke_O__O(to__1) } else {
//line :230:1
			var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_39.GetRawRoot__O()); var tmp2 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_classes_env_A_const_99.GetRawRoot__O()).Invoke_O__O(from__0)


			if jrt.A2g_Truth(and__1927000168__auto____3) { tmp2 = lang.IFn_Cast(A_arbace_classes_env_A_const_99.GetRawRoot__O()).Invoke_O__O(to__1) } else { tmp2 = and__1927000168__auto____3 }
//line :230:1
			if jrt.A2g_Truth(tmp1.Invoke_O__O(tmp2)) { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { if lang.Util_Equiv_O_O__Z(to__1, A_arbace_classes_env_A_const_100.GetRawRoot__O()) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_env_A_const_101.GetRawRoot__O()).Invoke_O__O(from__0)) {





				if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_env_A_const_101.GetRawRoot__O()).Invoke_O__O(to__1)) { var fe__3 any = lang.IFn_Cast(A_arbace_classes_env_A_const_102.GetRawRoot__O()).Invoke_O__O(from__0); var te__4 any = lang.IFn_Cast(A_arbace_classes_env_A_const_102.GetRawRoot__O()).Invoke_O__O(to__1); var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_classes_env_A_const_99.GetRawRoot__O()).Invoke_O__O(fe__3)
					if jrt.A2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_classes_env_A_const_99.GetRawRoot__O()).Invoke_O__O(te__4); if jrt.A2g_Truth(and__1927000168__auto____6) { return lang.IFn_Cast(A_arbace_classes_env_A_const_103.GetRawRoot__O()).Invoke_O_O__O(fe__3, te__4) } else { return and__1927000168__auto____6 } } else { return and__1927000168__auto____5 } } else {
//line :236:1
						if A_arbace_classes_env_A_const_104 != nil {

							return lang.IFn_Cast(A_arbace_classes_env_A_const_23.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_env_A_const_105, to__1) } else {
//line :236:1
								return nil } } } else {
//line :230:1
									if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_env_A_const_101.GetRawRoot__O()).Invoke_O__O(to__1)) { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { if A_arbace_classes_env_A_const_104 != nil {









										return lang.IFn_Cast(A_arbace_classes_env_A_const_97.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_106.GetRawRoot__O()).Invoke_O__O(from__0), lang.IFn_Cast(A_arbace_classes_env_A_const_106.GetRawRoot__O()).Invoke_O__O(to__1)) } else {
//line :230:1
											return nil
										}
									}
								}
			}
			}
		}
	}
}



func A_arbace_classes_env_superclass_chain_A_New() *A_arbace_classes_env_superclass_chain_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_superclass_chain_A{}; t.Ctor(); return t }
//line :242:1
func (t *A_arbace_classes_env_superclass_chain_A) Ctor() {}
//line :242:1
func (t *A_arbace_classes_env_superclass_chain_A) Invoke_O_O__O(self, n__0 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_107.GetRawRoot__O()); var tmp2 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_108.GetRawRoot__O()); var tmp4 any = A_arbace_classes_env_superclass_chain_fn__28000123_A_New(); var tmp5 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_classes_env_superclass_chain_fn__28000123_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_61, false); A_arbace_classes_env_superclass_chain_fn__28000123_A_fn_class = fncls__26d; tmp5 = fncls__26d } else { tmp5 = fncls__26 }; return tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), n__0)) }
//line :243:1
func A_arbace_classes_env_superclass_chain_fn__28000123_A_New() *A_arbace_classes_env_superclass_chain_fn__28000123_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_superclass_chain_fn__28000123_A{}; t.Ctor(); return t }
//line :243:1
func (t *A_arbace_classes_env_superclass_chain_fn__28000123_A) Ctor() {}
//line :243:1
func (t *A_arbace_classes_env_superclass_chain_fn__28000123_A) Invoke_O_O__O(self, p1__28000122_SHARP___1 any) any { var G__28000124__2_ any = p1__28000122_SHARP___1; var G__28000124__3_ any; if lang.Util_Identical_O_O__Z(G__28000124__2_, nil) { G__28000124__3_ = nil } else { G__28000124__3_ = lang.IFn_Cast(A_arbace_classes_env_A_const_93.GetRawRoot__O()).Invoke_O__O(G__28000124__2_) }; if lang.Util_Identical_O_O__Z(G__28000124__3_, nil) { return nil } else { return A_arbace_classes_env_A_const_45.Invoke_O__O(G__28000124__3_) } }

func A_arbace_classes_env_common_super_A_New() *A_arbace_classes_env_common_super_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_common_super_A{}; t.Ctor(); return t }
//line :245:1
func (t *A_arbace_classes_env_common_super_A) Ctor() {}
//line :245:1
func (t *A_arbace_classes_env_common_super_A) Invoke_O_O_O__O(self, a__0, b__1 any) any {


	if lang.Util_Equiv_O_O__Z(a__0, b__1) { return a__0 } else { var tmp1 any; var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_classes_env_A_const_20.GetRawRoot__O()).Invoke_O_O__O(a__0, Lit_11)

		if jrt.A2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { tmp1 = lang.IFn_Cast(A_arbace_classes_env_A_const_20.GetRawRoot__O()).Invoke_O_O__O(b__1, Lit_11) }
//line :248:1
		if jrt.A2g_Truth(tmp1) { return Lit_4 } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_env_A_const_97.GetRawRoot__O()).Invoke_O_O__O(a__0, b__1)) {


			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_env_A_const_109.GetRawRoot__O()).Invoke_O__O(b__1)) { return Lit_4 } else { return b__1 } } else {
//line :248:1
				if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_env_A_const_97.GetRawRoot__O()).Invoke_O_O__O(b__1, a__0)) {



					if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_env_A_const_109.GetRawRoot__O()).Invoke_O__O(a__0)) { return Lit_4 } else { return a__0 } } else {
//line :248:1
						var tmp2 any; var or__1927000174__auto____3_2 any = lang.IFn_Cast(A_arbace_classes_env_A_const_109.GetRawRoot__O()).Invoke_O__O(a__0)




						if jrt.A2g_Truth(or__1927000174__auto____3_2) { tmp2 = or__1927000174__auto____3_2 } else { tmp2 = lang.IFn_Cast(A_arbace_classes_env_A_const_109.GetRawRoot__O()).Invoke_O__O(b__1) }
//line :248:1
						if jrt.A2g_Truth(tmp2) { return Lit_4 } else { if A_arbace_classes_env_A_const_104 != nil { var bs__3 any = lang.IFn_Cast(A_arbace_classes_env_A_const_110.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_111.GetRawRoot__O()).Invoke_O__O(b__1)); var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_classes_env_A_const_63.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_86.GetRawRoot__O()).Invoke_O_O__O(bs__3, lang.IFn_Cast(A_arbace_classes_env_A_const_111.GetRawRoot__O()).Invoke_O__O(a__0)))






							if jrt.A2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { return Lit_4 } } else {
//line :248:1
								return nil
							}
						}
					}
			}
		}
	}
}

func A_arbace_classes_env_lub_A_New() *A_arbace_classes_env_lub_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_lub_A{}; t.Ctor(); return t }
//line :257:1
func (t *A_arbace_classes_env_lub_A) Ctor() {}
//line :257:1
func (t *A_arbace_classes_env_lub_A) Invoke_O_O_O__O(self, a__0, b__1 any) any {



	if lang.Util_Equiv_O_O__Z(a__0, b__1) { return a__0 } else { if lang.Util_Equiv_O_O__Z(a__0, A_arbace_classes_env_A_const_98) { return b__1 } else { if lang.Util_Equiv_O_O__Z(b__1, A_arbace_classes_env_A_const_98) { return a__0 } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_env_A_const_103.GetRawRoot__O()).Invoke_O_O__O(a__0, b__1)) { return b__1 } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_env_A_const_103.GetRawRoot__O()).Invoke_O_O__O(b__1, a__0)) { return a__0 } else { var tmp1 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_classes_env_A_const_112.GetRawRoot__O()).Invoke_O__O(a__0)




		if jrt.A2g_Truth(and__1927000168__auto____3) { tmp1 = lang.IFn_Cast(A_arbace_classes_env_A_const_112.GetRawRoot__O()).Invoke_O__O(b__1) } else { tmp1 = and__1927000168__auto____3 }
//line :261:1
		if jrt.A2g_Truth(tmp1) { var c__3 any = lang.IFn_Cast(A_arbace_classes_env_A_const_113.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_106.GetRawRoot__O()).Invoke_O__O(a__0), lang.IFn_Cast(A_arbace_classes_env_A_const_106.GetRawRoot__O()).Invoke_O__O(b__1))






			if lang.Util_Equiv_O_O__Z(c__3, Lit_4) { var sups__4 any; var tmp2 any = A_arbace_classes_env_lub_sups__28000129_A_New(); var tmp3 *jrt.Class
				var fncls__28 /*line :268:1*/*jrt.Class = A_arbace_classes_env_lub_sups__28000129_A_fn_class

				if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_23, false); A_arbace_classes_env_lub_sups__28000129_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; sups__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)
//line :268:1
				var common__5 any = lang.IFn_Cast(A_arbace_classes_env_A_const_86.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_env_A_const_109.GetRawRoot__O(), lang.IFn_Cast(A_arbace_classes_env_A_const_117.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(sups__4).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_106.GetRawRoot__O()).Invoke_O__O(a__0)), lang.IFn_Cast(sups__4).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_106.GetRawRoot__O()).Invoke_O__O(b__1)))); var minimal__6 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_115.GetRawRoot__O()); var tmp5 any = A_arbace_classes_env_lub_fn__28000134_A_New_O(common__5); var tmp6 *jrt.Class
				var fncls__30 /*line :268:1*/*jrt.Class = A_arbace_classes_env_lub_fn__28000134_A_fn_class






				if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_24, false); A_arbace_classes_env_lub_fn__28000134_A_fn_class = fncls__30d; tmp6 = fncls__30d } else { tmp6 = fncls__30 }; minimal__6 = tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), common__5)
				if lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(minimal__6))) { return lang.IFn_Cast(A_arbace_classes_env_A_const_116.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_63.GetRawRoot__O()).Invoke_O__O(minimal__6)) } else { return A_arbace_classes_env_A_const_100.GetRawRoot__O() } } else {
					return lang.IFn_Cast(A_arbace_classes_env_A_const_116.GetRawRoot__O()).Invoke_O__O(c__3) } } else {
//line :261:1
						if A_arbace_classes_env_A_const_104 != nil { return A_arbace_classes_env_A_const_100.GetRawRoot__O() } else { return nil
						}
					}
	}
	}
	}
	}
	}
}
func A_arbace_classes_env_lub_sups__28000129_A_New() *A_arbace_classes_env_lub_sups__28000129_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_lub_sups__28000129_A{}; t.Ctor(); return t }
//line :270:1
func (t *A_arbace_classes_env_lub_sups__28000129_A) Ctor() {}
//line :270:1
func (t *A_arbace_classes_env_lub_sups__28000129_A) Invoke_O_O__O(self, n__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_110.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_114.GetRawRoot__O()); var tmp3 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var tmp4 any = A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_New(); var tmp5 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_26, false); A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_fn_class = fncls__27d; tmp5 = fncls__27d } else { tmp5 = fncls__27 }; return tmp1.Invoke_O__O(tmp2.Invoke_O_O_O__O(tmp3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), n__1)) }
//line :270:1
func A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_New() *A_arbace_classes_env_lub_sups__28000129_fn__28000130_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_lub_sups__28000129_fn__28000130_A{}; t.Ctor(); return t }
//line :270:1
func (t *A_arbace_classes_env_lub_sups__28000129_fn__28000130_A) Ctor() {}
//line :270:1
func (t *A_arbace_classes_env_lub_sups__28000129_fn__28000130_A) Invoke_O_O__O(self, x__1 any) any { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_classes_env_A_const_93.GetRawRoot__O()).Invoke_O__O(x__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var i__3 any = temp__1927000414__auto____2; var G__28000131__4_ any = lang.IFn_Cast(A_arbace_classes_env_A_const_52.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_env_A_const_46.Invoke_O__O(i__3))
													if jrt.A2g_Truth(A_arbace_classes_env_A_const_45.Invoke_O__O(i__3)) { return lang.IFn_Cast(A_arbace_classes_env_A_const_9.GetRawRoot__O()).Invoke_O_O__O(G__28000131__4_, A_arbace_classes_env_A_const_45.Invoke_O__O(i__3)) } else { return G__28000131__4_ } } else {
//line :270:1
		return nil } }




func A_arbace_classes_env_lub_fn__28000134_A_New_O(p0 any) *A_arbace_classes_env_lub_fn__28000134_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_lub_fn__28000134_A{}; t.Ctor_O(p0); return t }
//line :275:1
func (t *A_arbace_classes_env_lub_fn__28000134_A) Ctor_O(c__common any) { t.F_common = c__common }
//line :275:1
func (t *A_arbace_classes_env_lub_fn__28000134_A) Invoke_O_O__O(self, i__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_96.GetRawRoot__O()); var tmp2 any = A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_New_O(i__1); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_25, false); A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), t.F_common) }
//line :275:1
func A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_New_O(p0 any) *A_arbace_classes_env_lub_fn__28000134_fn__28000135_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_lub_fn__28000134_fn__28000135_A{}; t.Ctor_O(p0); return t }
//line :275:1
func (t *A_arbace_classes_env_lub_fn__28000134_fn__28000135_A) Ctor_O(c__i any) { t.F_i = c__i }
//line :275:1
func (t *A_arbace_classes_env_lub_fn__28000134_fn__28000135_A) Invoke_O_O__O(self, p1__28000128_SHARP___1 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_classes_env_A_const_118.GetRawRoot__O()).Invoke_O_O__O(p1__28000128_SHARP___1, t.F_i); if jrt.A2g_Truth(and__1927000168__auto____2) { return lang.IFn_Cast(A_arbace_classes_env_A_const_97.GetRawRoot__O()).Invoke_O_O__O(p1__28000128_SHARP___1, t.F_i) } else { return and__1927000168__auto____2 } }






func A_arbace_classes_env_nest_host_A_New() *A_arbace_classes_env_nest_host_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_nest_host_A{}; t.Ctor(); return t }
//line :282:1
func (t *A_arbace_classes_env_nest_host_A) Ctor() {}
//line :282:1
func (t *A_arbace_classes_env_nest_host_A) Invoke_O_O__O(self, n__0 any) any { var i__2 any = lang.IFn_Cast(A_arbace_classes_env_A_const_93.GetRawRoot__O()).Invoke_O__O(n__0); var or__1927000174__auto____3 any = A_arbace_classes_env_A_const_48.Invoke_O__O(i__2); if

	jrt.A2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var temp__1927000408__auto____4 any = A_arbace_classes_env_A_const_49.Invoke_O__O(i__2)
		if jrt.A2g_Truth(temp__1927000408__auto____4) { var o__5 any = temp__1927000408__auto____4; return lang.IFn_Cast(A_arbace_classes_env_A_const_119.GetRawRoot__O()).Invoke_O__O(o__5) } else { return n__0 } } }

func A_arbace_classes_env_flag_QMARK__A_New() *A_arbace_classes_env_flag_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_flag_QMARK__A{}; t.Ctor(); return t }
//line :287:1
func (t *A_arbace_classes_env_flag_QMARK__A) Ctor() {}
//line :287:1
func (t *A_arbace_classes_env_flag_QMARK__A) Invoke_O_O_O__O(self, flags__0, f__1 any) any { return lang.IFn_Cast(A_arbace_classes_env_A_const_39.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsZero_J__Z(lang.Numbers_And_O_O__J(flags__0, f__1))).Ref()) }

func A_arbace_classes_env_accessible_QMARK__A_New() *A_arbace_classes_env_accessible_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_accessible_QMARK__A{}; t.Ctor(); return t }
//line :289:1
func (t *A_arbace_classes_env_accessible_QMARK__A) Ctor() {}
//line :289:1
func (t *A_arbace_classes_env_accessible_QMARK__A) Invoke_O_O_O__O(self, from__0, m__1 any) any { var fl__3 any = A_arbace_classes_env_A_const_43.Invoke_O__O(m__1); var owner__4 any = A_arbace_classes_env_A_const_67.Invoke_O__O(m__1); if



	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_env_A_const_120.GetRawRoot__O()).Invoke_O_O__O(fl__3, A_arbace_classes_env_A_const_122)) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_env_A_const_120.GetRawRoot__O()).Invoke_O_O__O(fl__3, A_arbace_classes_env_A_const_123)) {

		return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_classes_env_A_const_119.GetRawRoot__O()).Invoke_O__O(from__0), lang.IFn_Cast(A_arbace_classes_env_A_const_119.GetRawRoot__O()).Invoke_O__O(owner__4))).Ref() } else {
//line :293:1
			if lang.Util_Equiv_O_O__Z(lang.IFn_Cast(A_arbace_classes_env_A_const_121.GetRawRoot__O()).Invoke_O__O(from__0), lang.IFn_Cast(A_arbace_classes_env_A_const_121.GetRawRoot__O()).Invoke_O__O(owner__4)) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_env_A_const_120.GetRawRoot__O()).Invoke_O_O__O(fl__3, A_arbace_classes_env_A_const_124)) {




				var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_96.GetRawRoot__O()); var tmp2 any = A_arbace_classes_env_accessible_QMARK__fn__28000143_A_New_O(owner__4); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_classes_env_accessible_QMARK__fn__28000143_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1, false); A_arbace_classes_env_accessible_QMARK__fn__28000143_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; var tmp4 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_107.GetRawRoot__O()); var tmp6 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_108.GetRawRoot__O()); var tmp8 any = A_arbace_classes_env_accessible_QMARK__fn__28000145_A_New(); var tmp9 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_classes_env_accessible_QMARK__fn__28000145_A_fn_class
				if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_2, false); A_arbace_classes_env_accessible_QMARK__fn__28000145_A_fn_class = fncls__32d; tmp9 = fncls__32d } else { tmp9 = fncls__32 }
//line :298:1
				return jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(tmp1.Invoke_O_O__O(tmp4, tmp5.Invoke_O_O__O(tmp6, tmp7.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), from__0))))).Ref() } else {
//line :293:1
					if A_arbace_classes_env_A_const_104 != nil { jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { return nil } } } } } }




func A_arbace_classes_env_accessible_QMARK__fn__28000143_A_New_O(p0 any) *A_arbace_classes_env_accessible_QMARK__fn__28000143_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_accessible_QMARK__fn__28000143_A{}; t.Ctor_O(p0); return t }
//line :298:1
func (t *A_arbace_classes_env_accessible_QMARK__fn__28000143_A) Ctor_O(c__owner any) { t.F_owner = c__owner }
//line :298:1
func (t *A_arbace_classes_env_accessible_QMARK__fn__28000143_A) Invoke_O_O__O(self, p1__28000141_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_classes_env_A_const_97.GetRawRoot__O()).Invoke_O_O__O(p1__28000141_SHARP___1, t.F_owner) }
func A_arbace_classes_env_accessible_QMARK__fn__28000145_A_New() *A_arbace_classes_env_accessible_QMARK__fn__28000145_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_accessible_QMARK__fn__28000145_A{}; t.Ctor(); return t }
//line :299:1
func (t *A_arbace_classes_env_accessible_QMARK__fn__28000145_A) Ctor() {}
//line :299:1
func (t *A_arbace_classes_env_accessible_QMARK__fn__28000145_A) Invoke_O_O__O(self, p1__28000142_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_classes_env_A_const_49; return tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_93.GetRawRoot__O()).Invoke_O__O(p1__28000142_SHARP___1)) }


func A_arbace_classes_env_find_field_A_New() *A_arbace_classes_env_find_field_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_find_field_A{}; t.Ctor(); return t }
//line :302:1
func (t *A_arbace_classes_env_find_field_A) Ctor() {}
//line :302:1
func (t *A_arbace_classes_env_find_field_A) Invoke_O_O_O__O(self, n__0, name__1 any) any { var temp__1927000414__auto____3 any = lang.IFn_Cast(A_arbace_classes_env_A_const_93.GetRawRoot__O()).Invoke_O__O(n__0); if



	jrt.A2g_Truth(temp__1927000414__auto____3) { var i__4 any = temp__1927000414__auto____3; var or__1927000174__auto____5 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_63.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_86.GetRawRoot__O()); var tmp3 any = A_arbace_classes_env_find_field_fn__28000150_A_New_O(name__1); var tmp4 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_classes_env_find_field_fn__28000150_A_fn_class
		if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_18, false); A_arbace_classes_env_find_field_fn__28000150_A_fn_class = fncls__33d; tmp4 = fncls__33d } else { tmp4 = fncls__33 }; or__1927000174__auto____5 = tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), A_arbace_classes_env_A_const_50.Invoke_O__O(i__4))); if jrt.A2g_Truth(or__1927000174__auto____5) { return or__1927000174__auto____5 } else { var or__1927000174__auto____6 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_96.GetRawRoot__O()); var tmp6 any = A_arbace_classes_env_find_field_fn__28000152_A_New_O(name__1); var tmp7 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_classes_env_find_field_fn__28000152_A_fn_class
			if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_19, false); A_arbace_classes_env_find_field_fn__28000152_A_fn_class = fncls__34d; tmp7 = fncls__34d } else { tmp7 = fncls__34 }; or__1927000174__auto____6 = tmp5.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), A_arbace_classes_env_A_const_46.Invoke_O__O(i__4))
//line :307:1
			if jrt.A2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else { var G__28000154__7_ any = A_arbace_classes_env_A_const_45.Invoke_O__O(i__4)

				if lang.Util_Identical_O_O__Z(G__28000154__7_, nil) { return nil } else { return lang.IFn_Cast(A_arbace_classes_env_A_const_125.GetRawRoot__O()).Invoke_O_O__O(G__28000154__7_, name__1) } } } } else {
//line :306:1
					return nil } }
func A_arbace_classes_env_find_field_fn__28000150_A_New_O(p0 any) *A_arbace_classes_env_find_field_fn__28000150_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_find_field_fn__28000150_A{}; t.Ctor_O(p0); return t }
//line :307:1
func (t *A_arbace_classes_env_find_field_fn__28000150_A) Ctor_O(c__name any) { t.F_name = c__name }
//line :307:1
func (t *A_arbace_classes_env_find_field_fn__28000150_A) Invoke_O_O__O(self, p1__28000148_SHARP___1 any) any { var tmp1 any = t.F_name; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp1, A_arbace_classes_env_A_const_42.Invoke_O__O(p1__28000148_SHARP___1))).Ref() }
func A_arbace_classes_env_find_field_fn__28000152_A_New_O(p0 any) *A_arbace_classes_env_find_field_fn__28000152_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_find_field_fn__28000152_A{}; t.Ctor_O(p0); return t }
//line :308:1
func (t *A_arbace_classes_env_find_field_fn__28000152_A) Ctor_O(c__name any) { t.F_name = c__name }
//line :308:1
func (t *A_arbace_classes_env_find_field_fn__28000152_A) Invoke_O_O__O(self, p1__28000149_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_classes_env_A_const_125.GetRawRoot__O()).Invoke_O_O__O(p1__28000149_SHARP___1, t.F_name) }


func A_arbace_classes_env_all_supertypes_A_New() *A_arbace_classes_env_all_supertypes_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_all_supertypes_A{}; t.Ctor(); return t }
//line :311:1
func (t *A_arbace_classes_env_all_supertypes_A) Ctor() {}
//line :311:1
func (t *A_arbace_classes_env_all_supertypes_A) Invoke_O_O__O(self, n__0 any) any { { var chain__2 any = lang.IFn_Cast(A_arbace_classes_env_A_const_52.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_111.GetRawRoot__O()).Invoke_O__O(n__0)); var out__3 any = chain__2; var seen__4 any = lang.IFn_Cast(A_arbace_classes_env_A_const_110.GetRawRoot__O()).Invoke_O__O(chain__2); var queue__5 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_52.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_126.GetRawRoot__O()); var tmp3 any = A_arbace_classes_env_all_supertypes_fn__28000157_A_New(); var tmp4 *jrt.Class
											var fncls__35 /*line :311:1*/*jrt.Class = A_arbace_classes_env_all_supertypes_fn__28000157_A_fn_class



	if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_3, false); A_arbace_classes_env_all_supertypes_fn__28000157_A_fn_class = fncls__35d; tmp4 = fncls__35d } else { tmp4 = fncls__35 }; queue__5 = tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), chain__2))
//line :311:1
L1: for { var temp__1927000408__auto____6 any = lang.IFn_Cast(A_arbace_classes_env_A_const_57.GetRawRoot__O()).Invoke_O__O(queue__5)




	if jrt.A2g_Truth(temp__1927000408__auto____6) { var vec__28000159__7 any = temp__1927000408__auto____6; var seq__28000160__8 any = lang.IFn_Cast(A_arbace_classes_env_A_const_57.GetRawRoot__O()).Invoke_O__O(vec__28000159__7); var first__28000161__9 any = lang.IFn_Cast(A_arbace_classes_env_A_const_63.GetRawRoot__O()).Invoke_O__O(seq__28000160__8); var seq__28000160__10 any = lang.IFn_Cast(A_arbace_classes_env_A_const_61.GetRawRoot__O()).Invoke_O__O(seq__28000160__8); var q__11 any = first__28000161__9; var more__12 any = seq__28000160__10
		if jrt.A2g_Truth(lang.IFn_Cast(seen__4).Invoke_O__O(q__11)) {
			out__3, seen__4, queue__5 = out__3, seen__4, lang.IFn_Cast(A_arbace_classes_env_A_const_52.GetRawRoot__O()).Invoke_O__O(more__12); continue L1 } else {
				var tmp5 *lang.Keyword = A_arbace_classes_env_A_const_46; out__3, seen__4, queue__5 = lang.IFn_Cast(A_arbace_classes_env_A_const_9.GetRawRoot__O()).Invoke_O_O__O(out__3, q__11), lang.IFn_Cast(A_arbace_classes_env_A_const_9.GetRawRoot__O()).Invoke_O_O__O(seen__4, q__11), lang.IFn_Cast(A_arbace_classes_env_A_const_87.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_52.GetRawRoot__O()).Invoke_O__O(more__12), tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_93.GetRawRoot__O()).Invoke_O__O(q__11))); continue L1 } } else {
//line :316:1
					var G__28000162__7_ any = out__3; var tmp6 any; var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_classes_env_A_const_109.GetRawRoot__O()).Invoke_O__O(n__0)



					if jrt.A2g_Truth(and__1927000168__auto____8) { tmp6 = lang.IFn_Cast(A_arbace_classes_env_A_const_39.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(seen__4).Invoke_O__O(Lit_4)) } else { tmp6 = and__1927000168__auto____8 }; if jrt.A2g_Truth(tmp6) { return lang.IFn_Cast(A_arbace_classes_env_A_const_9.GetRawRoot__O()).Invoke_O_O__O(G__28000162__7_, Lit_4) } else { return G__28000162__7_ } } } }; /*line :311:1*/panic("a2g: unreachable") }



func A_arbace_classes_env_all_supertypes_fn__28000157_A_New() *A_arbace_classes_env_all_supertypes_fn__28000157_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_all_supertypes_fn__28000157_A{}; t.Ctor(); return t }
//line :315:1
func (t *A_arbace_classes_env_all_supertypes_fn__28000157_A) Ctor() {}
//line :315:1
func (t *A_arbace_classes_env_all_supertypes_fn__28000157_A) Invoke_O_O__O(self, p1__28000156_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_classes_env_A_const_46; return tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_93.GetRawRoot__O()).Invoke_O__O(p1__28000156_SHARP___1)) }






func A_arbace_classes_env_params_key_A_New() *A_arbace_classes_env_params_key_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_params_key_A{}; t.Ctor(); return t }
//line :322:1
func (t *A_arbace_classes_env_params_key_A) Ctor() {}
//line :322:1
func (t *A_arbace_classes_env_params_key_A) Invoke_O_O__O(self, desc__0 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_127.GetRawRoot__O()); var tmp2 any = A_arbace_classes_env_A_const_128; return tmp1.Invoke_O_O_O__O(desc__0, tmp2, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(jrt.NN(jrt.String_Cast(desc__0)).IndexOf_String__I(Lit_30)))).Ref()) }

func A_arbace_classes_env_member_methods_A_New() *A_arbace_classes_env_member_methods_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_member_methods_A{}; t.Ctor(); return t }
//line :324:1
func (t *A_arbace_classes_env_member_methods_A) Ctor() {}
//line :324:1
func (t *A_arbace_classes_env_member_methods_A) Invoke_O_O_O__O(self, n__0, name__1 any) any { { var G__28000168__3_ any = lang.IFn_Cast(A_arbace_classes_env_A_const_129.GetRawRoot__O()).Invoke_O__O(n__0); var vec__28000169__4 any = G__28000168__3_; var seq__28000170__5 any = lang.IFn_Cast(A_arbace_classes_env_A_const_57.GetRawRoot__O()).Invoke_O__O(vec__28000169__4); var first__28000171__6 any = lang.IFn_Cast(A_arbace_classes_env_A_const_63.GetRawRoot__O()).Invoke_O__O(seq__28000170__5); var seq__28000170__7 any = lang.IFn_Cast(A_arbace_classes_env_A_const_61.GetRawRoot__O()).Invoke_O__O(seq__28000170__5); var c__8 any = first__28000171__6; var more__9 any = seq__28000170__7; var seen__10 any; _ = c__8; _ = more__9; lang.PersistentHashSet_Init(); seen__10 = lang.PersistentHashSet_EMPTY.Ref(); var out__11 any; lang.PersistentVector_Init(); out__11 = lang.PersistentVector_EMPTY.Ref(); var G__28000168__12_ any = G__28000168__3_; var seen__13 any = seen__10; var out__14 any = out__11; L1: for { var vec__28000172__15 any = G__28000168__12_; var seq__28000173__16 any = lang.IFn_Cast(A_arbace_classes_env_A_const_57.GetRawRoot__O()).Invoke_O__O(vec__28000172__15); var first__28000174__17 any = lang.IFn_Cast(A_arbace_classes_env_A_const_63.GetRawRoot__O()).Invoke_O__O(seq__28000173__16); var seq__28000173__18 any = lang.IFn_Cast(A_arbace_classes_env_A_const_61.GetRawRoot__O()).Invoke_O__O(seq__28000173__16)
												var c__19 any = first__28000174__17
												var more__20 any = seq__28000173__18
												var seen__21 any = seen__13
												var out__22 any = out__14
												if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_env_A_const_39.GetRawRoot__O()).Invoke_O__O(c__19)) { return out__22 } else { var ms__23 any; var iter__1927001039__auto____23 any; var tmp1 any = A_arbace_classes_env_member_methods_iter__28000175__28000179_A_New_O_O_O_O(seen__21, name__1, n__0, c__19); var tmp2 *jrt.Class
													var fncls__38 /*line :329:1*/*jrt.Class = A_arbace_classes_env_member_methods_iter__28000175__28000179_A_fn_class

		if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_27, false); A_arbace_classes_env_member_methods_iter__28000175__28000179_A_fn_class = fncls__38d; tmp2 = fncls__38d } else { tmp2 = fncls__38 }; iter__1927001039__auto____23 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 *lang.Keyword = A_arbace_classes_env_A_const_55; ms__23 = lang.IFn_Cast(iter__1927001039__auto____23).Invoke_O__O(tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_95.GetRawRoot__O()).Invoke_O__O(c__19)))






		G__28000168__12_, seen__13, out__14 = more__20, lang.IFn_Cast(A_arbace_classes_env_A_const_87.GetRawRoot__O()).Invoke_O_O__O(seen__21, lang.IFn_Cast(A_arbace_classes_env_A_const_80.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_133.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_env_A_const_132.GetRawRoot__O(), A_arbace_classes_env_A_const_64), ms__23)), lang.IFn_Cast(A_arbace_classes_env_A_const_87.GetRawRoot__O()).Invoke_O_O__O(out__22, ms__23); continue L1 } } }; /*line :324:1*/panic("a2g: unreachable") }






func A_arbace_classes_env_member_methods_iter__28000175__28000179_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_member_methods_iter__28000175__28000179_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_member_methods_iter__28000175__28000179_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :331:1
func (t *A_arbace_classes_env_member_methods_iter__28000175__28000179_A) Ctor_O_O_O_O(c__seen, c__name, c__n, c__c any) { t.F_seen = c__seen; t.F_name = c__name; t.F_n = c__n; t.F_c = c__c }
//line :331:1
func (t *A_arbace_classes_env_member_methods_iter__28000175__28000179_A) Invoke_O_O__O(self, s__28000176__1 any) any { var tmp1 any = A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_New_O_O_O_O_O_O(t.F_seen, t.F_name, t.F_n, t.F_c, s__28000176__1, self); var tmp2 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_28, false); A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_fn_class = fncls__37d; tmp2 = fncls__37d } else { tmp2 = fncls__37 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :331:1
func A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :331:1
func (t *A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A) Ctor_O_O_O_O_O_O(c__seen, c__name, c__n, c__c, c__s__28000176, c__iter__28000175 any) { t.F_seen = c__seen; t.F_name = c__name; t.F_n = c__n; t.F_c = c__c; t.F_s__28000176 = c__s__28000176; t.F_iter__28000175 = c__iter__28000175 }
//line :331:1
func (t *A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A) Invoke_O__O(self any) any { { var s__28000176__1 any; var t_ any = t.F_s__28000176; t.F_s__28000176 = nil; s__28000176__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_classes_env_A_const_57.GetRawRoot__O()).Invoke_O__O(s__28000176__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__28000176__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_env_A_const_58.GetRawRoot__O()).Invoke_O__O(s__28000176__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_classes_env_A_const_59.GetRawRoot__O()).Invoke_O__O(s__28000176__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__28000178__6 any = lang.IFn_Cast(A_arbace_classes_env_A_const_60.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_New_O_O_O_O_O_I_O(b__28000178__6, t.F_seen, t.F_name, t.F_n, t.F_c, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_29, false); A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_fn_class = fncls__36d; tmp2 = fncls__36d } else { tmp2 = fncls__36 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__28000175); return lang.IFn_Cast(A_arbace_classes_env_A_const_72.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_74.GetRawRoot__O()).Invoke_O__O(b__28000178__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_75.GetRawRoot__O()).Invoke_O__O(s__28000176__3))) } else { return lang.IFn_Cast(A_arbace_classes_env_A_const_72.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_74.GetRawRoot__O()).Invoke_O__O(b__28000178__6), nil) } } else { var m__4 any = lang.IFn_Cast(A_arbace_classes_env_A_const_63.GetRawRoot__O()).Invoke_O__O(s__28000176__3); var tmp4 any = t.F_name; if lang.Util_Equiv_O_O__Z(tmp4, A_arbace_classes_env_A_const_42.Invoke_O__O(m__4)) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_env_A_const_39.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_120.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_env_A_const_43.Invoke_O__O(m__4), A_arbace_classes_env_A_const_130))) { var tmp5 any; var or__1927000174__auto____5 bool = lang.Util_Equiv_O_O__Z(t.F_c, t.F_n)


	if or__1927000174__auto____5 { tmp5 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____5).Ref() } else { tmp5 = lang.IFn_Cast(A_arbace_classes_env_A_const_39.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_120.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_env_A_const_43.Invoke_O__O(m__4), A_arbace_classes_env_A_const_123)) }
//line :331:1
	if jrt.A2g_Truth(tmp5) { var tmp6 any; var or__1927000174__auto____5_2 bool = lang.Util_Equiv_O_O__Z(t.F_c, t.F_n)



		if or__1927000174__auto____5_2 { tmp6 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____5_2).Ref() } else { var or__1927000174__auto____6 any = lang.IFn_Cast(A_arbace_classes_env_A_const_39.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_109.GetRawRoot__O()).Invoke_O__O(t.F_c)); if jrt.A2g_Truth(or__1927000174__auto____6) { tmp6 = or__1927000174__auto____6 } else { tmp6 = lang.IFn_Cast(A_arbace_classes_env_A_const_39.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_120.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_env_A_const_43.Invoke_O__O(m__4), A_arbace_classes_env_A_const_131)) } }
//line :331:1
		if jrt.A2g_Truth(tmp6) { var tmp7 lang.IFn = lang.IFn_Cast(t.F_seen); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_env_A_const_39.GetRawRoot__O()).Invoke_O__O(tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_132.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_env_A_const_64.Invoke_O__O(m__4))))) { var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__28000175); return lang.IFn_Cast(A_arbace_classes_env_A_const_73.GetRawRoot__O()).Invoke_O_O__O(m__4, tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_76.GetRawRoot__O()).Invoke_O__O(s__28000176__3))) } else { s__28000176__1 = lang.IFn_Cast(A_arbace_classes_env_A_const_76.GetRawRoot__O()).Invoke_O__O(s__28000176__3); continue L1 } } else { s__28000176__1 = lang.IFn_Cast(A_arbace_classes_env_A_const_76.GetRawRoot__O()).Invoke_O__O(s__28000176__3); continue L1 } } else { s__28000176__1 = lang.IFn_Cast(A_arbace_classes_env_A_const_76.GetRawRoot__O()).Invoke_O__O(s__28000176__3); continue L1 } } else { s__28000176__1 = lang.IFn_Cast(A_arbace_classes_env_A_const_76.GetRawRoot__O()).Invoke_O__O(s__28000176__3); continue L1 } } else { s__28000176__1 = lang.IFn_Cast(A_arbace_classes_env_A_const_76.GetRawRoot__O()).Invoke_O__O(s__28000176__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :331:1
func A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_New_O_O_O_O_O_I_O(p0, p1, p2, p3, p4 any, p5 int32, p6 any) *A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A{}; t.Ctor_O_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :331:1
func (t *A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A) Ctor_O_O_O_O_O_I_O(c__b__28000178, c__seen, c__name, c__n, c__c any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__28000178 = c__b__28000178; t.F_seen = c__seen; t.F_name = c__name; t.F_n = c__n; t.F_c = c__c; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :331:1
func (t *A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A) Invoke_O__O(self any) any { { var i__28000177__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__28000177__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__28000177__1)); var tmp2 any = t.F_name; if lang.Util_Equiv_O_O__Z(tmp2, A_arbace_classes_env_A_const_42.Invoke_O__O(m__2)) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_env_A_const_39.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_120.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_env_A_const_43.Invoke_O__O(m__2), A_arbace_classes_env_A_const_130))) { var tmp3 any; var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z(t.F_c, t.F_n)


	if or__1927000174__auto____3 { tmp3 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____3).Ref() } else { tmp3 = lang.IFn_Cast(A_arbace_classes_env_A_const_39.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_120.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_env_A_const_43.Invoke_O__O(m__2), A_arbace_classes_env_A_const_123)) }
//line :331:1
	if jrt.A2g_Truth(tmp3) { var tmp4 any; var or__1927000174__auto____3_2 bool = lang.Util_Equiv_O_O__Z(t.F_c, t.F_n)



		if or__1927000174__auto____3_2 { tmp4 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____3_2).Ref() } else { var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_classes_env_A_const_39.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_109.GetRawRoot__O()).Invoke_O__O(t.F_c)); if jrt.A2g_Truth(or__1927000174__auto____4) { tmp4 = or__1927000174__auto____4 } else { tmp4 = lang.IFn_Cast(A_arbace_classes_env_A_const_39.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_120.GetRawRoot__O()).Invoke_O_O__O(A_arbace_classes_env_A_const_43.Invoke_O__O(m__2), A_arbace_classes_env_A_const_131)) } }
//line :331:1
		if jrt.A2g_Truth(tmp4) { var tmp5 lang.IFn = lang.IFn_Cast(t.F_seen); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_classes_env_A_const_39.GetRawRoot__O()).Invoke_O__O(tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_132.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_env_A_const_64.Invoke_O__O(m__2))))) { lang.IFn_Cast(A_arbace_classes_env_A_const_66.GetRawRoot__O()).Invoke_O_O__O(t.F_b__28000178, m__2); i__28000177__1 = lang.Numbers_Unchecked_inc_J__J(i__28000177__1); continue L1 } else { i__28000177__1 = lang.Numbers_Unchecked_inc_J__J(i__28000177__1); continue L1 } } else { i__28000177__1 = lang.Numbers_Unchecked_inc_J__J(i__28000177__1); continue L1 } } else { i__28000177__1 = lang.Numbers_Unchecked_inc_J__J(i__28000177__1); continue L1 } } else { i__28000177__1 = lang.Numbers_Unchecked_inc_J__J(i__28000177__1); continue L1 } } else { i__28000177__1 = lang.Numbers_Unchecked_inc_J__J(i__28000177__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }








func A_arbace_classes_env_constructors_A_New() *A_arbace_classes_env_constructors_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_constructors_A{}; t.Ctor(); return t }
//line :340:1
func (t *A_arbace_classes_env_constructors_A) Ctor() {}
//line :340:1
func (t *A_arbace_classes_env_constructors_A) Invoke_O_O__O(self, n__0 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_86.GetRawRoot__O()); var tmp2 any = A_arbace_classes_env_constructors_fn__28000187_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_classes_env_constructors_fn__28000187_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_12, false); A_arbace_classes_env_constructors_fn__28000187_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; var tmp4 *lang.Keyword = A_arbace_classes_env_A_const_55; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_classes_env_A_const_95.GetRawRoot__O()).Invoke_O__O(n__0))) }
//line :341:1
func A_arbace_classes_env_constructors_fn__28000187_A_New() *A_arbace_classes_env_constructors_fn__28000187_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_constructors_fn__28000187_A{}; t.Ctor(); return t }
//line :341:1
func (t *A_arbace_classes_env_constructors_fn__28000187_A) Ctor() {}
//line :341:1
func (t *A_arbace_classes_env_constructors_fn__28000187_A) Invoke_O_O__O(self, p1__28000186_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_13, A_arbace_classes_env_A_const_42.Invoke_O__O(p1__28000186_SHARP___1))).Ref() }














































































































































type A_arbace_classes_env_A struct{ jrt.Object }

var A_arbace_classes_env_A_const_pool *jrt.RefArray

var A_arbace_classes_env_A_const_0 *lang.Var

var A_arbace_classes_env_A_const_1 *lang.Var

var A_arbace_classes_env_A_const_2 any

var A_arbace_classes_env_A_const_3 any

var A_arbace_classes_env_A_const_4 any

var A_arbace_classes_env_A_const_5 any

var A_arbace_classes_env_A_const_6 any

var A_arbace_classes_env_A_const_7 *lang.Var

var A_arbace_classes_env_A_const_8 *lang.Var

var A_arbace_classes_env_A_const_9 *lang.Var

var A_arbace_classes_env_A_const_10 any

var A_arbace_classes_env_A_const_11 *lang.Var

var A_arbace_classes_env_A_const_12 *lang.Var

var A_arbace_classes_env_A_const_13 *lang.Var

var A_arbace_classes_env_A_const_14 *lang.Var

var A_arbace_classes_env_A_const_15 *lang.Var

var A_arbace_classes_env_A_const_16 *lang.Var

var A_arbace_classes_env_A_const_17 *lang.Var

var A_arbace_classes_env_A_const_18 *lang.Var

var A_arbace_classes_env_A_const_19 *lang.Var

var A_arbace_classes_env_A_const_20 *lang.Var

var A_arbace_classes_env_A_const_21 *lang.Var

var A_arbace_classes_env_A_const_22 *lang.Keyword

var A_arbace_classes_env_A_const_23 *lang.Var

var A_arbace_classes_env_A_const_24 *lang.Var

var A_arbace_classes_env_A_const_25 *lang.Var

var A_arbace_classes_env_A_const_26 *lang.Var

var A_arbace_classes_env_A_const_27 *lang.Var

var A_arbace_classes_env_A_const_28 *lang.Var

var A_arbace_classes_env_A_const_29 *lang.Var

var A_arbace_classes_env_A_const_30 *lang.Keyword

var A_arbace_classes_env_A_const_31 *lang.Keyword

var A_arbace_classes_env_A_const_32 *lang.Var

var A_arbace_classes_env_A_const_33 *jrt.Class

var A_arbace_classes_env_A_const_34 *lang.Var

var A_arbace_classes_env_A_const_35 *lang.Var

var A_arbace_classes_env_A_const_36 *lang.Var

var A_arbace_classes_env_A_const_37 any

var A_arbace_classes_env_A_const_38 any

var A_arbace_classes_env_A_const_39 *lang.Var

var A_arbace_classes_env_A_const_40 *lang.Var

var A_arbace_classes_env_A_const_41 *lang.Var

var A_arbace_classes_env_A_const_42 *lang.Keyword

var A_arbace_classes_env_A_const_43 *lang.Keyword

var A_arbace_classes_env_A_const_44 *lang.Keyword

var A_arbace_classes_env_A_const_45 *lang.Keyword

var A_arbace_classes_env_A_const_46 *lang.Keyword

var A_arbace_classes_env_A_const_47 *lang.Var

var A_arbace_classes_env_A_const_48 *lang.Keyword

var A_arbace_classes_env_A_const_49 *lang.Keyword

var A_arbace_classes_env_A_const_50 *lang.Keyword

var A_arbace_classes_env_A_const_51 *lang.Var

var A_arbace_classes_env_A_const_52 *lang.Var

var A_arbace_classes_env_A_const_53 *lang.Keyword

var A_arbace_classes_env_A_const_54 *lang.Var

var A_arbace_classes_env_A_const_55 *lang.Keyword

var A_arbace_classes_env_A_const_56 *lang.Var

var A_arbace_classes_env_A_const_57 *lang.Var

var A_arbace_classes_env_A_const_58 *lang.Var

var A_arbace_classes_env_A_const_59 *lang.Var

var A_arbace_classes_env_A_const_60 *lang.Var

var A_arbace_classes_env_A_const_61 *lang.Var

var A_arbace_classes_env_A_const_62 *lang.Var

var A_arbace_classes_env_A_const_63 *lang.Var

var A_arbace_classes_env_A_const_64 *lang.Keyword

var A_arbace_classes_env_A_const_65 *lang.Keyword

var A_arbace_classes_env_A_const_66 *lang.Var

var A_arbace_classes_env_A_const_67 *lang.Keyword

var A_arbace_classes_env_A_const_68 *lang.Keyword

var A_arbace_classes_env_A_const_69 *lang.Var

var A_arbace_classes_env_A_const_70 *lang.Var

var A_arbace_classes_env_A_const_71 *lang.Var

var A_arbace_classes_env_A_const_72 *lang.Var

var A_arbace_classes_env_A_const_73 *lang.Var

var A_arbace_classes_env_A_const_74 *lang.Var

var A_arbace_classes_env_A_const_75 *lang.Var

var A_arbace_classes_env_A_const_76 *lang.Var

var A_arbace_classes_env_A_const_77 *lang.Var

var A_arbace_classes_env_A_const_78 *lang.Var

var A_arbace_classes_env_A_const_79 *lang.Var

var A_arbace_classes_env_A_const_80 *lang.Var

var A_arbace_classes_env_A_const_81 *lang.Keyword

var A_arbace_classes_env_A_const_82 *lang.Keyword

var A_arbace_classes_env_A_const_83 *lang.Var

var A_arbace_classes_env_A_const_84 *lang.Keyword

var A_arbace_classes_env_A_const_85 *lang.Var

var A_arbace_classes_env_A_const_86 *lang.Var

var A_arbace_classes_env_A_const_87 *lang.Var

var A_arbace_classes_env_A_const_88 any

var A_arbace_classes_env_A_const_89 *lang.Var

var A_arbace_classes_env_A_const_90 *lang.Keyword

var A_arbace_classes_env_A_const_91 *lang.Var

var A_arbace_classes_env_A_const_92 *lang.Var

var A_arbace_classes_env_A_const_93 *lang.Var

var A_arbace_classes_env_A_const_94 *lang.Var

var A_arbace_classes_env_A_const_95 *lang.Var

var A_arbace_classes_env_A_const_96 *lang.Var

var A_arbace_classes_env_A_const_97 *lang.Var

var A_arbace_classes_env_A_const_98 *lang.Keyword

var A_arbace_classes_env_A_const_99 *lang.Var

var A_arbace_classes_env_A_const_100 *lang.Var

var A_arbace_classes_env_A_const_101 *lang.Var

var A_arbace_classes_env_A_const_102 *lang.Var

var A_arbace_classes_env_A_const_103 *lang.Var

var A_arbace_classes_env_A_const_104 *lang.Keyword

var A_arbace_classes_env_A_const_105 any

var A_arbace_classes_env_A_const_106 *lang.Var

var A_arbace_classes_env_A_const_107 *lang.Var

var A_arbace_classes_env_A_const_108 *lang.Var

var A_arbace_classes_env_A_const_109 *lang.Var

var A_arbace_classes_env_A_const_110 *lang.Var

var A_arbace_classes_env_A_const_111 *lang.Var

var A_arbace_classes_env_A_const_112 *lang.Var

var A_arbace_classes_env_A_const_113 *lang.Var

var A_arbace_classes_env_A_const_114 *lang.Var

var A_arbace_classes_env_A_const_115 *lang.Var

var A_arbace_classes_env_A_const_116 *lang.Var

var A_arbace_classes_env_A_const_117 *lang.Var

var A_arbace_classes_env_A_const_118 *lang.Var

var A_arbace_classes_env_A_const_119 *lang.Var

var A_arbace_classes_env_A_const_120 *lang.Var

var A_arbace_classes_env_A_const_121 *lang.Var

var A_arbace_classes_env_A_const_122 any

var A_arbace_classes_env_A_const_123 any

var A_arbace_classes_env_A_const_124 any

var A_arbace_classes_env_A_const_125 *lang.Var

var A_arbace_classes_env_A_const_126 *lang.Var

var A_arbace_classes_env_A_const_127 *lang.Var

var A_arbace_classes_env_A_const_128 any

var A_arbace_classes_env_A_const_129 *lang.Var

var A_arbace_classes_env_A_const_130 any

var A_arbace_classes_env_A_const_131 any

var A_arbace_classes_env_A_const_132 *lang.Var

var A_arbace_classes_env_A_const_133 *lang.Var

var A_arbace_classes_env_A_init jrt.ClassInit

func A_arbace_classes_env_A_Init() { if !A_arbace_classes_env_A_init.Done() { A_arbace_classes_env_A_init.Run(A_arbace_classes_env_A_clinit) } }

func A_arbace_classes_env_A_clinit() { A_arbace_classes_env_A_clinit_p0(); A_arbace_classes_env_A_clinit_p1(); A_arbace_classes_env_A_clinit_p2(); A_arbace_classes_env_A_clinit_p3(); A_arbace_classes_env_A_clinit_p4(); A_arbace_classes_env_A_clinit_p5(); A_arbace_classes_env_A_clinit_p6(); A_arbace_classes_env_A_clinit_p7(); A_arbace_classes_env_A_clinit_p8(); A_arbace_classes_env_A_clinit_p9(); A_arbace_classes_env_A_clinit_p10() }

func A_arbace_classes_env_A_clinit_p0() { A_arbace_classes_env_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 170); A_arbace_classes_env_A_const_0 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[36]); A_arbace_classes_env_A_const_1 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[37]); A_arbace_classes_env_A_const_2 = A_arbace_classes_env_A_const_pool.A[38]; A_arbace_classes_env_A_const_3 = A_arbace_classes_env_A_const_pool.A[39]; A_arbace_classes_env_A_const_4 = A_arbace_classes_env_A_const_pool.A[40]; A_arbace_classes_env_A_const_5 = A_arbace_classes_env_A_const_pool.A[41]; A_arbace_classes_env_A_const_6 = A_arbace_classes_env_A_const_pool.A[42]; A_arbace_classes_env_A_const_7 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[43]); A_arbace_classes_env_A_const_8 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[44]); A_arbace_classes_env_A_const_9 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[45]); A_arbace_classes_env_A_const_10 = A_arbace_classes_env_A_const_pool.A[46]; A_arbace_classes_env_A_const_11 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[47]); A_arbace_classes_env_A_const_12 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[48]) }

func A_arbace_classes_env_A_clinit_p1() { A_arbace_classes_env_A_const_13 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[49]); A_arbace_classes_env_A_const_14 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[50]); A_arbace_classes_env_A_const_15 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[51]); A_arbace_classes_env_A_const_16 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[52]); A_arbace_classes_env_A_const_17 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[53]); A_arbace_classes_env_A_const_18 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[54]); A_arbace_classes_env_A_const_19 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[55]); A_arbace_classes_env_A_const_20 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[56]); A_arbace_classes_env_A_const_21 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[57]); A_arbace_classes_env_A_const_22 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[58]); A_arbace_classes_env_A_const_23 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[59]); A_arbace_classes_env_A_const_24 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[60]) }

func A_arbace_classes_env_A_clinit_p2() { A_arbace_classes_env_A_const_25 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[61]); A_arbace_classes_env_A_const_26 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[62]); A_arbace_classes_env_A_const_27 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[63]); A_arbace_classes_env_A_const_28 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[64]); A_arbace_classes_env_A_const_29 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[65]); A_arbace_classes_env_A_const_30 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[66]); A_arbace_classes_env_A_const_31 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[67]); A_arbace_classes_env_A_const_32 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[68]); A_arbace_classes_env_A_const_33 = jrt.Class_Cast(A_arbace_classes_env_A_const_pool.A[69]); A_arbace_classes_env_A_const_34 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[70]); A_arbace_classes_env_A_const_35 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[71]); A_arbace_classes_env_A_const_36 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[72]) }

func A_arbace_classes_env_A_clinit_p3() { A_arbace_classes_env_A_const_37 = A_arbace_classes_env_A_const_pool.A[73]; A_arbace_classes_env_A_const_38 = A_arbace_classes_env_A_const_pool.A[74]; A_arbace_classes_env_A_const_39 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[75]); A_arbace_classes_env_A_const_40 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[76]); A_arbace_classes_env_A_const_41 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[77]); A_arbace_classes_env_A_const_42 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[78]); A_arbace_classes_env_A_const_43 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[79]); A_arbace_classes_env_A_const_44 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[80]); A_arbace_classes_env_A_const_45 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[81]); A_arbace_classes_env_A_const_46 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[82]); A_arbace_classes_env_A_const_47 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[83]); A_arbace_classes_env_A_const_48 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[84]) }

func A_arbace_classes_env_A_clinit_p4() { A_arbace_classes_env_A_const_49 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[85]); A_arbace_classes_env_A_const_50 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[86]); A_arbace_classes_env_A_const_51 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[87]); A_arbace_classes_env_A_const_52 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[88]); A_arbace_classes_env_A_const_53 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[89]); A_arbace_classes_env_A_const_54 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[90]); A_arbace_classes_env_A_const_55 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[91]); A_arbace_classes_env_A_const_56 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[92]); A_arbace_classes_env_A_const_57 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[93]); A_arbace_classes_env_A_const_58 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[94]); A_arbace_classes_env_A_const_59 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[95]); A_arbace_classes_env_A_const_60 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[96]) }

func A_arbace_classes_env_A_clinit_p5() { A_arbace_classes_env_A_const_61 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[97]); A_arbace_classes_env_A_const_62 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[98]); A_arbace_classes_env_A_const_63 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[99]); A_arbace_classes_env_A_const_64 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[100]); A_arbace_classes_env_A_const_65 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[101]); A_arbace_classes_env_A_const_66 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[102]); A_arbace_classes_env_A_const_67 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[103]); A_arbace_classes_env_A_const_68 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[104]); A_arbace_classes_env_A_const_69 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[105]); A_arbace_classes_env_A_const_70 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[106]); A_arbace_classes_env_A_const_71 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[107]); A_arbace_classes_env_A_const_72 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[108]) }

func A_arbace_classes_env_A_clinit_p6() { A_arbace_classes_env_A_const_73 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[109]); A_arbace_classes_env_A_const_74 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[110]); A_arbace_classes_env_A_const_75 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[111]); A_arbace_classes_env_A_const_76 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[112]); A_arbace_classes_env_A_const_77 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[113]); A_arbace_classes_env_A_const_78 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[114]); A_arbace_classes_env_A_const_79 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[115]); A_arbace_classes_env_A_const_80 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[116]); A_arbace_classes_env_A_const_81 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[117]); A_arbace_classes_env_A_const_82 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[118]); A_arbace_classes_env_A_const_83 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[119]); A_arbace_classes_env_A_const_84 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[120]) }

func A_arbace_classes_env_A_clinit_p7() { A_arbace_classes_env_A_const_85 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[121]); A_arbace_classes_env_A_const_86 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[122]); A_arbace_classes_env_A_const_87 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[123]); A_arbace_classes_env_A_const_88 = A_arbace_classes_env_A_const_pool.A[124]; A_arbace_classes_env_A_const_89 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[125]); A_arbace_classes_env_A_const_90 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[126]); A_arbace_classes_env_A_const_91 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[127]); A_arbace_classes_env_A_const_92 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[128]); A_arbace_classes_env_A_const_93 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[129]); A_arbace_classes_env_A_const_94 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[130]); A_arbace_classes_env_A_const_95 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[131]); A_arbace_classes_env_A_const_96 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[132]) }

func A_arbace_classes_env_A_clinit_p8() { A_arbace_classes_env_A_const_97 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[133]); A_arbace_classes_env_A_const_98 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[134]); A_arbace_classes_env_A_const_99 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[135]); A_arbace_classes_env_A_const_100 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[136]); A_arbace_classes_env_A_const_101 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[137]); A_arbace_classes_env_A_const_102 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[138]); A_arbace_classes_env_A_const_103 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[139]); A_arbace_classes_env_A_const_104 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[140]); A_arbace_classes_env_A_const_105 = A_arbace_classes_env_A_const_pool.A[141]; A_arbace_classes_env_A_const_106 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[142]); A_arbace_classes_env_A_const_107 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[143]); A_arbace_classes_env_A_const_108 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[144]) }

func A_arbace_classes_env_A_clinit_p9() { A_arbace_classes_env_A_const_109 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[145]); A_arbace_classes_env_A_const_110 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[146]); A_arbace_classes_env_A_const_111 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[147]); A_arbace_classes_env_A_const_112 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[148]); A_arbace_classes_env_A_const_113 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[149]); A_arbace_classes_env_A_const_114 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[150]); A_arbace_classes_env_A_const_115 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[151]); A_arbace_classes_env_A_const_116 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[152]); A_arbace_classes_env_A_const_117 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[153]); A_arbace_classes_env_A_const_118 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[154]); A_arbace_classes_env_A_const_119 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[155]); A_arbace_classes_env_A_const_120 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[156]) }

func A_arbace_classes_env_A_clinit_p10() { A_arbace_classes_env_A_const_121 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[157]); A_arbace_classes_env_A_const_122 = A_arbace_classes_env_A_const_pool.A[158]; A_arbace_classes_env_A_const_123 = A_arbace_classes_env_A_const_pool.A[159]; A_arbace_classes_env_A_const_124 = A_arbace_classes_env_A_const_pool.A[160]; A_arbace_classes_env_A_const_125 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[161]); A_arbace_classes_env_A_const_126 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[162]); A_arbace_classes_env_A_const_127 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[163]); A_arbace_classes_env_A_const_128 = A_arbace_classes_env_A_const_pool.A[164]; A_arbace_classes_env_A_const_129 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[165]); A_arbace_classes_env_A_const_130 = A_arbace_classes_env_A_const_pool.A[166]; A_arbace_classes_env_A_const_131 = A_arbace_classes_env_A_const_pool.A[167]; A_arbace_classes_env_A_const_132 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[168]); A_arbace_classes_env_A_const_133 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[169]) }

func A_arbace_classes_env_A_New() *A_arbace_classes_env_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_env_A) Ctor() {}

func (t *A_arbace_classes_env_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_A_class }

func (t *A_arbace_classes_env_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_A); return ok }

func A_arbace_classes_env_A_Cast(x any) *A_arbace_classes_env_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_A_class)) }; return v }



type A_arbace_classes_env_accessible_QMARK__A struct{ a2g_header uint64 }

var A_arbace_classes_env_accessible_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_accessible_QMARK__fn__28000143_A struct{ a2g_header uint64; F_owner any }

var A_arbace_classes_env_accessible_QMARK__fn__28000143_A_fn_class *jrt.Class



type A_arbace_classes_env_accessible_QMARK__fn__28000145_A struct{ a2g_header uint64 }

var A_arbace_classes_env_accessible_QMARK__fn__28000145_A_fn_class *jrt.Class



type A_arbace_classes_env_all_supertypes_A struct{ a2g_header uint64 }

var A_arbace_classes_env_all_supertypes_A_fn_class *jrt.Class



type A_arbace_classes_env_all_supertypes_fn__28000157_A struct{ a2g_header uint64 }

var A_arbace_classes_env_all_supertypes_fn__28000157_A_fn_class *jrt.Class



type A_arbace_classes_env_assignable_QMARK__A struct{ a2g_header uint64 }

var A_arbace_classes_env_assignable_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_class_file_QMARK__A struct{ a2g_header uint64 }

var A_arbace_classes_env_class_file_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_coerce_const_A struct{ a2g_header uint64 }

var A_arbace_classes_env_coerce_const_A_fn_class *jrt.Class



type A_arbace_classes_env_common_super_A struct{ a2g_header uint64 }

var A_arbace_classes_env_common_super_A_fn_class *jrt.Class



type A_arbace_classes_env_const_value_A struct{ a2g_header uint64 }

var A_arbace_classes_env_const_value_A_fn_class *jrt.Class



type A_arbace_classes_env_constructors_A struct{ a2g_header uint64 }

var A_arbace_classes_env_constructors_A_fn_class *jrt.Class



type A_arbace_classes_env_constructors_fn__28000187_A struct{ a2g_header uint64 }

var A_arbace_classes_env_constructors_fn__28000187_A_fn_class *jrt.Class



type A_arbace_classes_env_eval28000004_A struct{ jrt.Object }

func A_arbace_classes_env_eval28000004_A_New() *A_arbace_classes_env_eval28000004_A { t := &A_arbace_classes_env_eval28000004_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_env_eval28000004_A) Ctor() {}

func (t *A_arbace_classes_env_eval28000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_eval28000004_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_eval28000004_A_class }

func (t *A_arbace_classes_env_eval28000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_eval28000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_eval28000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_eval28000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_eval28000004_A); return ok }

func A_arbace_classes_env_eval28000004_A_Cast(x any) *A_arbace_classes_env_eval28000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_eval28000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_eval28000004_A_class)) }; return v }



type A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A struct{ a2g_header uint64 }

var A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_fn_class *jrt.Class



type A_arbace_classes_env_eval28000008_A struct{ jrt.Object }

func A_arbace_classes_env_eval28000008_A_New() *A_arbace_classes_env_eval28000008_A { t := &A_arbace_classes_env_eval28000008_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_env_eval28000008_A) Ctor() {}

func (t *A_arbace_classes_env_eval28000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_eval28000008_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_eval28000008_A_class }

func (t *A_arbace_classes_env_eval28000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_eval28000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env_eval28000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_eval28000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_eval28000008_A); return ok }

func A_arbace_classes_env_eval28000008_A_Cast(x any) *A_arbace_classes_env_eval28000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_eval28000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_eval28000008_A_class)) }; return v }



type A_arbace_classes_env_eval28000008_fn__28000009_A struct{ a2g_header uint64 }

var A_arbace_classes_env_eval28000008_fn__28000009_A_fn_class *jrt.Class



type A_arbace_classes_env_find_field_A struct{ a2g_header uint64 }

var A_arbace_classes_env_find_field_A_fn_class *jrt.Class



type A_arbace_classes_env_find_field_fn__28000150_A struct{ a2g_header uint64; F_name any }

var A_arbace_classes_env_find_field_fn__28000150_A_fn_class *jrt.Class



type A_arbace_classes_env_find_field_fn__28000152_A struct{ a2g_header uint64; F_name any }

var A_arbace_classes_env_find_field_fn__28000152_A_fn_class *jrt.Class



type A_arbace_classes_env_flag_QMARK__A struct{ a2g_header uint64 }

var A_arbace_classes_env_flag_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_from_source_QMARK__A struct{ a2g_header uint64 }

var A_arbace_classes_env_from_source_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_info_A struct{ a2g_header uint64 }

var A_arbace_classes_env_info_A_fn_class *jrt.Class



type A_arbace_classes_env_info_BANG__A struct{ a2g_header uint64 }

var A_arbace_classes_env_info_BANG__A_fn_class *jrt.Class



type A_arbace_classes_env_inner_member_QMARK__A struct{ a2g_header uint64 }

var A_arbace_classes_env_inner_member_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_interface_QMARK__A struct{ a2g_header uint64 }

var A_arbace_classes_env_interface_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_internal_A struct{ a2g_header uint64 }

var A_arbace_classes_env_internal_A_fn_class *jrt.Class



type A_arbace_classes_env_known_QMARK__A struct{ a2g_header uint64 }

var A_arbace_classes_env_known_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_load_class_A struct{ a2g_header uint64 }

var A_arbace_classes_env_load_class_A_fn_class *jrt.Class



type A_arbace_classes_env_lub_A struct{ a2g_header uint64 }

var A_arbace_classes_env_lub_A_fn_class *jrt.Class



type A_arbace_classes_env_lub_fn__28000134_A struct{ a2g_header uint64; F_common any }

var A_arbace_classes_env_lub_fn__28000134_A_fn_class *jrt.Class



type A_arbace_classes_env_lub_fn__28000134_fn__28000135_A struct{ a2g_header uint64; F_i any }

var A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_fn_class *jrt.Class



type A_arbace_classes_env_lub_sups__28000129_A struct{ a2g_header uint64 }

var A_arbace_classes_env_lub_sups__28000129_A_fn_class *jrt.Class



type A_arbace_classes_env_lub_sups__28000129_fn__28000130_A struct{ a2g_header uint64 }

var A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_fn_class *jrt.Class



type A_arbace_classes_env_member_methods_A struct{ a2g_header uint64 }

var A_arbace_classes_env_member_methods_A_fn_class *jrt.Class



type A_arbace_classes_env_member_methods_iter__28000175__28000179_A struct{ a2g_header uint64; F_seen, F_name, F_n, F_c any }

var A_arbace_classes_env_member_methods_iter__28000175__28000179_A_fn_class *jrt.Class



type A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A struct{ a2g_header uint64; F_seen, F_name, F_n, F_c, F_s__28000176, F_iter__28000175 any }

var A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_fn_class *jrt.Class



type A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A struct{ a2g_header uint64; F_b__28000178, F_seen, F_name, F_n, F_c any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_fn_class *jrt.Class



type A_arbace_classes_env_nest_host_A struct{ a2g_header uint64 }

var A_arbace_classes_env_nest_host_A_fn_class *jrt.Class



type A_arbace_classes_env_params_key_A struct{ a2g_header uint64 }

var A_arbace_classes_env_params_key_A_fn_class *jrt.Class



type A_arbace_classes_env_read_fields_A struct{ a2g_header uint64 }

var A_arbace_classes_env_read_fields_A_fn_class *jrt.Class



type A_arbace_classes_env_read_method_annotations_A struct{ a2g_header uint64 }

var A_arbace_classes_env_read_method_annotations_A_fn_class *jrt.Class



type A_arbace_classes_env_record_BANG__A struct{ a2g_header uint64 }

var A_arbace_classes_env_record_BANG__A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_A struct{ a2g_header uint64 }

var A_arbace_classes_env_reflect_info_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_fn__28000027_A struct{ a2g_header uint64; F_c any }

var A_arbace_classes_env_reflect_info_fn__28000027_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_fn__28000089_A struct{ a2g_header uint64 }

var A_arbace_classes_env_reflect_info_fn__28000089_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000031__28000035_A struct{ a2g_header uint64; F_n any }

var A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A struct{ a2g_header uint64; F_n, F_s__28000032, F_iter__28000031 any }

var A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A struct{ a2g_header uint64; F_b__28000034, F_n any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000045__28000049_A struct{ a2g_header uint64; F_n any }

var A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A struct{ a2g_header uint64; F_n, F_s__28000046, F_iter__28000045 any }

var A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A struct{ a2g_header uint64; F_n, F_b__28000048 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_A struct{ a2g_header uint64; F_n, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A struct{ a2g_header uint64; F_n, F_manns, F_s__28000056, F_iter__28000055 any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A struct{ a2g_header uint64; F_n, F_b__28000058, F_manns any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A struct{ a2g_header uint64; F_m, F_desc, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A struct{ a2g_header uint64; F_m, F_desc, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A struct{ a2g_header uint64; F_i, F_m, F_desc, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A struct{ a2g_header uint64; F_m, F_desc, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A struct{ a2g_header uint64; F_m, F_desc, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A struct{ a2g_header uint64; F_i, F_m, F_desc, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000077__28000081_A struct{ a2g_header uint64; F_c, F_n any }

var A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A struct{ a2g_header uint64; F_c, F_n, F_s__28000078, F_iter__28000077 any }

var A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A struct{ a2g_header uint64; F_c, F_n, F_b__28000080 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000091__28000095_A struct{ a2g_header uint64; F_n any }

var A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A struct{ a2g_header uint64; F_n, F_s__28000092, F_iter__28000091 any }

var A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A struct{ a2g_header uint64; F_n any; F_size__1927001038__auto__ int32; F_b__28000094, F_c__1927001037__auto__ any }

var A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_fn_class *jrt.Class



type A_arbace_classes_env_reflected_A struct{ a2g_header uint64 }

var A_arbace_classes_env_reflected_A_fn_class *jrt.Class



type A_arbace_classes_env_subclass_QMARK__A struct{ a2g_header uint64 }

var A_arbace_classes_env_subclass_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_subclass_QMARK__fn__28000117_A struct{ a2g_header uint64; F_b any }

var A_arbace_classes_env_subclass_QMARK__fn__28000117_A_fn_class *jrt.Class



type A_arbace_classes_env_superclass_chain_A struct{ a2g_header uint64 }

var A_arbace_classes_env_superclass_chain_A_fn_class *jrt.Class



type A_arbace_classes_env_superclass_chain_fn__28000123_A struct{ a2g_header uint64 }

var A_arbace_classes_env_superclass_chain_fn__28000123_A_fn_class *jrt.Class



type A_arbace_classes_env_supertypes_A struct{ a2g_header uint64 }

var A_arbace_classes_env_supertypes_A_fn_class *jrt.Class
