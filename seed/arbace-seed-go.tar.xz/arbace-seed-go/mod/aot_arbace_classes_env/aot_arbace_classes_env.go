//line aot_arbace_classes_env.ae:1
package aot_arbace_classes_env

import (
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_set"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_New() *A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_classes_env_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_env_A_const_1); lang.IFn_Cast(A_arbace_classes_env_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_classes_env_A_const_3, A_arbace_classes_env_A_const_4, A_arbace_classes_env_A_const_5, A_arbace_classes_env_A_const_6); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_14)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_15)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_16)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_17)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_classes_env_eval28000008_fn__28000009_A_New() *A_arbace_classes_env_eval28000008_fn__28000009_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_eval28000008_fn__28000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_env_eval28000008_fn__28000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_env_eval28000008_fn__28000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_7.GetRawRoot__O()); var tmp2 any; var root_18 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_19 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_18, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_20 lang.IFn; if linked_19 == nil { ifn_20 = lang.IFn_Cast(root_18) } else { ifn_20 = nil }; var arg_21 any = A_arbace_classes_env_A_const_9; if linked_19 == nil { tmp2 = ifn_20.Invoke_O__O(arg_21) } else { tmp2 = linked_19.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_18, arg_21) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_classes_env_A_const_10.GetRawRoot__O(), A_arbace_classes_env_A_const_11) }



























func A_arbace_classes_env_internal_A_New() *A_arbace_classes_env_internal_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_internal_A{}; t.Ctor(); return t }
//line :29:1
func (t *A_arbace_classes_env_internal_A) Ctor() {}
//line :29:1
func (t *A_arbace_classes_env_internal_A) Invoke_O_O__O(self, c__0 any) any { var root_22 any = A_arbace_classes_env_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref(); var arg_26 any = Lit_22; var arg_27 any = Lit_21; if linked_23 == nil { return ifn_24.Invoke_O_O_O__O(arg_25, arg_26, arg_27) } else { return linked_23.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_22, arg_25, arg_26, arg_27) } }







func A_arbace_classes_env_from_source_QMARK__A_New() *A_arbace_classes_env_from_source_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_from_source_QMARK__A{}; t.Ctor(); return t }
//line :37:1
func (t *A_arbace_classes_env_from_source_QMARK__A) Ctor() {}
//line :37:1
func (t *A_arbace_classes_env_from_source_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var tmp1 any; var and__1927000168__auto____2 any = A_arbace_classes_env_A_const_13.Get__O(); if jrt.J2g_Truth(and__1927000168__auto____2) { tmp1 = lang.IFn_Cast(A_arbace_classes_env_A_const_13.Get__O()).Invoke_O__O(n__0) } else { tmp1 = and__1927000168__auto____2 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() }


















func A_arbace_classes_env_record_BANG__A_New() *A_arbace_classes_env_record_BANG__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_record_BANG__A{}; t.Ctor(); return t }
//line :56:1
func (t *A_arbace_classes_env_record_BANG__A) Ctor() {}
//line :56:1
func (t *A_arbace_classes_env_record_BANG__A) Invoke_O_O_O_O__O(self, n__0, facet__1, v__2 any) any {


	if jrt.J2g_Truth(A_arbace_classes_env_A_const_14.Get__O()) { lang.IFn_Cast(A_arbace_classes_env_A_const_15.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_classes_env_A_const_14.Get__O(), A_arbace_classes_env_A_const_16.GetRawRoot__O(), n__0, A_arbace_classes_env_A_const_17.GetRawRoot__O(), facet__1, v__2) }
//line :56:1
	return v__2
}




func A_arbace_classes_env_load_class_A_New() *A_arbace_classes_env_load_class_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_load_class_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_classes_env_load_class_A) Ctor() {}
//line :62:1
func (t *A_arbace_classes_env_load_class_A) Invoke_O_O__O(self, n__0 any) any {



	var tmp1 any; var or__1927000174__auto____2 any; var root_37 any = A_arbace_classes_env_A_const_18.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_37, A_arbace_classes_env_from_source_QMARK__A_fn_class); var ifn_39 lang.IFn; if linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any = n__0; if linked_38 == nil { or__1927000174__auto____2 = ifn_39.Invoke_O__O(arg_40) } else { or__1927000174__auto____2 = linked_38.(*A_arbace_classes_env_from_source_QMARK__A).Invoke_O_O__O(root_37, arg_40) }; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { tmp1 = A_arbace_classes_env_A_const_19.Get__O() }; if jrt.J2g_Truth(tmp1) { return nil } else { var tmp2 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var cn__4 any; var tmp3 any; var root_41 any = A_arbace_classes_env_A_const_20.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_43 lang.IFn

		if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = n__0; var arg_45 any = Lit_11; if linked_42 == nil { tmp3 = ifn_43.Invoke_O_O__O(arg_44, arg_45) } else { tmp3 = linked_42.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_41, arg_44, arg_45) }; if jrt.J2g_Truth(tmp3) { var root_46 any = A_arbace_classes_env_A_const_12.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_48 lang.IFn; if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = n__0; var arg_50 any = Lit_21; var arg_51 any = Lit_22; if linked_47 == nil { cn__4 = ifn_48.Invoke_O_O_O__O(arg_49, arg_50, arg_51) } else { cn__4 = linked_47.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_46, arg_49, arg_50, arg_51) } } else { var root_52 any = A_arbace_classes_env_A_const_12.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_52, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_54 lang.IFn; if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any = n__0; var arg_56 any = Lit_21; var arg_57 any = Lit_22; if linked_53 == nil { cn__4 = ifn_54.Invoke_O_O_O__O(arg_55, arg_56, arg_57) } else { cn__4 = linked_53.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_52, arg_55, arg_56, arg_57) } }
//line :66:1
		var c__5 any = lang.RT_ClassForNameNonLoading_String__Class_NoInit(jrt.String_Cast(cn__4)).Ref(); var tmp4 any
		var and__1927000168__auto____6 any = c__5


		if jrt.J2g_Truth(and__1927000168__auto____6) { tmp4 = A_arbace_classes_env_A_const_14.Get__O() } else { tmp4 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp4) { var root_58 any = A_arbace_classes_env_A_const_21.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_58, A_arbace_classes_env_record_BANG__A_fn_class); var ifn_60 lang.IFn; if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = n__0; var arg_62 any = A_arbace_classes_env_A_const_22; var arg_63 any = jrt.Boolean_TRUE.Ref(); if linked_59 == nil { ifn_60.Invoke_O_O_O__O(arg_61, arg_62, arg_63) } else { linked_59.(*A_arbace_classes_env_record_BANG__A).Invoke_O_O_O_O__O(root_58, arg_61, arg_62, arg_63) } }
//line :66:1
		tmp2 = c__5 }; return nil }(); if tmp5 != nil { if jrt.ClassNotFoundException_InstanceOf(tmp5) { var ___4 *jrt.ClassNotFoundException = jrt.ClassNotFoundException_Cast(tmp5); _ = ___4; tmp2 = nil } else if jrt.NoClassDefFoundError_InstanceOf(tmp5) { var ___4_2 *jrt.NoClassDefFoundError = jrt.NoClassDefFoundError_Cast(tmp5); _ = ___4_2; tmp2 = nil } else { panic(tmp5) } }; return tmp2
	}
}






func A_arbace_classes_env_known_QMARK__A_New() *A_arbace_classes_env_known_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_known_QMARK__A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_classes_env_known_QMARK__A) Ctor() {}
//line :75:1
func (t *A_arbace_classes_env_known_QMARK__A) Invoke_O_O__O(self, n__0 any) any {





	if jrt.J2g_Truth(A_arbace_classes_env_A_const_19.Get__O()) { var and__1927000168__auto____2 any; var root_64 any = A_arbace_classes_env_A_const_23.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_66 lang.IFn; if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any = A_arbace_classes_env_A_const_19.Get__O(); var arg_68 any = n__0; if linked_65 == nil { and__1927000168__auto____2 = ifn_66.Invoke_O_O__O(arg_67, arg_68) } else { and__1927000168__auto____2 = linked_65.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_64, arg_67, arg_68) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_69 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_71 lang.IFn; if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any; var root_73 any = A_arbace_classes_env_A_const_18.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, A_arbace_classes_env_from_source_QMARK__A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = n__0; if linked_74 == nil { arg_72 = ifn_75.Invoke_O__O(arg_76) } else { arg_72 = linked_74.(*A_arbace_classes_env_from_source_QMARK__A).Invoke_O_O__O(root_73, arg_76) }; if linked_70 == nil { return ifn_71.Invoke_O__O(arg_72) } else { return linked_70.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_69, arg_72) } } else { return and__1927000168__auto____2 } } else { var root_77 any = A_arbace_classes_env_A_const_25.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_77, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_79 lang.IFn; if linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var arg_80 any; var root_81 any = A_arbace_classes_env_A_const_26.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, A_arbace_classes_env_load_class_A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = n__0; if linked_82 == nil { arg_80 = ifn_83.Invoke_O__O(arg_84) } else { arg_80 = linked_82.(*A_arbace_classes_env_load_class_A).Invoke_O_O__O(root_81, arg_84) }; if linked_78 == nil { return ifn_79.Invoke_O__O(arg_80) } else { return linked_78.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_77, arg_80)
	} } }
func A_arbace_classes_env_reflected_A_New() *A_arbace_classes_env_reflected_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflected_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_classes_env_reflected_A) Ctor() {}
//line :83:1
func (t *A_arbace_classes_env_reflected_A) Invoke_O_O_O_O__O(self, n__0, facet__1, f__2 any) any {




	if jrt.J2g_Truth(A_arbace_classes_env_A_const_19.Get__O()) { var temp__1927000414__auto____4 any = lang.RT_Get_O_O__O_NoInit(A_arbace_classes_env_A_const_19.Get__O(), n__0)
		if jrt.J2g_Truth(temp__1927000414__auto____4) { var d__5 any = temp__1927000414__auto____4; var temp__1927000408__auto____6 any; var root_85 any = A_arbace_classes_env_A_const_27.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_find_A_fn_class); var ifn_87 lang.IFn
			if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = d__5; var arg_89 any = facet__1; if linked_86 == nil { temp__1927000408__auto____6 = ifn_87.Invoke_O_O__O(arg_88, arg_89) } else { temp__1927000408__auto____6 = linked_86.(*aot_arbace_core.A_arbace_core_find_A).Invoke_O_O_O__O(root_85, arg_88, arg_89) }; if jrt.J2g_Truth(temp__1927000408__auto____6) { var e__7 any = temp__1927000408__auto____6; var root_90 any = A_arbace_classes_env_A_const_28.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_val_A_fn_class); var ifn_92 lang.IFn
				if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = e__7; if linked_91 == nil { return ifn_92.Invoke_O__O(arg_93) } else { return linked_91.(*aot_arbace_core.A_arbace_core_val_A).Invoke_O_O__O(root_90, arg_93) } } else {
//line :90:1
					var tmp1 any; var root_94 any = A_arbace_classes_env_A_const_29.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_96 lang.IFn

					if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_55, nil, Lit_56, nil, Lit_57); var tmp3 any; var root_99 any = A_arbace_classes_env_A_const_30.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_101 lang.IFn; if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any = facet__1; if linked_100 == nil { tmp3 = ifn_101.Invoke_O__O(arg_102) } else { tmp3 = linked_100.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_99, arg_102) }; var tmp4 any = tmp3; var tmp5 any; var root_103 any = A_arbace_classes_env_A_const_12.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_103, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_105 lang.IFn; if linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any; var root_109 any = A_arbace_classes_env_A_const_31.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_109, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_111 lang.IFn; if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any = n__0; if linked_110 == nil { arg_106 = ifn_111.Invoke_O__O(arg_112) } else { arg_106 = linked_110.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_109, arg_112) }; var arg_107 any = Lit_21; var arg_108 any = Lit_22; if linked_104 == nil { tmp5 = ifn_105.Invoke_O_O_O__O(arg_106, arg_107, arg_108) } else { tmp5 = linked_104.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_103, arg_106, arg_107, arg_108) }; arg_97 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp4, nil, tmp5, nil)).Ref(); var arg_98 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_env_A_const_32, n__0, A_arbace_classes_env_A_const_33, facet__1)); if linked_95 == nil { tmp1 = ifn_96.Invoke_O_O__O(arg_97, arg_98) } else { tmp1 = linked_95.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_94, arg_97, arg_98) }
//line :90:1
					panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) } } else {
//line :89:1
						return nil } } else {
//line :88:1
							var temp__1927000414__auto____4_2 any; var root_113 any = A_arbace_classes_env_A_const_26.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_113, A_arbace_classes_env_load_class_A_fn_class); var ifn_115 lang.IFn






							if linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any = n__0; if linked_114 == nil { temp__1927000414__auto____4_2 = ifn_115.Invoke_O__O(arg_116) } else { temp__1927000414__auto____4_2 = linked_114.(*A_arbace_classes_env_load_class_A).Invoke_O_O__O(root_113, arg_116) }; if jrt.J2g_Truth(temp__1927000414__auto____4_2) { var c__5 any = temp__1927000414__auto____4_2; var root_117 any = A_arbace_classes_env_A_const_21.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_117, A_arbace_classes_env_record_BANG__A_fn_class); var ifn_119 lang.IFn
								if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = n__0; var arg_121 any = facet__1; var arg_122 any = lang.IFn_Cast(f__2).Invoke_O__O(c__5); if linked_118 == nil { return ifn_119.Invoke_O_O_O__O(arg_120, arg_121, arg_122) } else { return linked_118.(*A_arbace_classes_env_record_BANG__A).Invoke_O_O_O_O__O(root_117, arg_120, arg_121, arg_122) } } else {
//line :95:1
									return nil
								}
						} }
func A_arbace_classes_env_class_file_QMARK__A_New() *A_arbace_classes_env_class_file_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_class_file_QMARK__A{}; t.Ctor(); return t }
//line :98:1
func (t *A_arbace_classes_env_class_file_QMARK__A) Ctor() {}
//line :98:1
func (t *A_arbace_classes_env_class_file_QMARK__A) Invoke_O_O__O(self, c__0 any) any { var ld__2 any; var or__1927000174__auto____2 any = jrt.NN(jrt.Class_Cast(c__0)).GetClassLoader__ClassLoader(); if





	jrt.J2g_Truth(or__1927000174__auto____2) { ld__2 = or__1927000174__auto____2 } else { ld__2 = jrt.ClassLoader_GetSystemClassLoader__ClassLoader() }; var temp__1927000414__auto____3 any; var tmp1 /*line :98:1*/*jrt.Class = A_arbace_classes_env_A_const_34; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_6); var tmp3 any; var root_123 any = A_arbace_classes_env_A_const_35.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, A_arbace_classes_env_internal_A_fn_class); var ifn_125 lang.IFn; if






	linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = c__0; if linked_124 == nil { tmp3 = ifn_125.Invoke_O__O(arg_126) } else { tmp3 = linked_124.(*A_arbace_classes_env_internal_A).Invoke_O_O__O(root_123, arg_126) }; temp__1927000414__auto____3 = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(ld__2, tmp1, Lit_5, jrt.RefArrayOf(jrt.Object_class, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil)).Ref())); if jrt.J2g_Truth(temp__1927000414__auto____3) { var in__4 any = temp__1927000414__auto____3
		jrt.InputStream_Cast(in__4).Close__V()
//line :105:1
		return jrt.Boolean_TRUE.Ref() } else { return nil } }



func A_arbace_classes_env_read_fields_A_New() *A_arbace_classes_env_read_fields_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_read_fields_A{}; t.Ctor(); return t }
//line :109:1
func (t *A_arbace_classes_env_read_fields_A) Ctor() {}
//line :109:1
func (t *A_arbace_classes_env_read_fields_A) Invoke_O_O__O(self, c__0 any) any {




	var tmp1 any; var root_127 any = A_arbace_classes_env_A_const_36.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, A_arbace_classes_env_class_file_QMARK__A_fn_class); var ifn_129 lang.IFn; if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = c__0; if linked_128 == nil { tmp1 = ifn_129.Invoke_O__O(arg_130) } else { tmp1 = linked_128.(*A_arbace_classes_env_class_file_QMARK__A).Invoke_O_O__O(root_127, arg_130) }; if jrt.J2g_Truth(tmp1) {
		var tmp2 any; var root_131 any = A_arbace_classes_env_A_const_37.GetRawRoot__O(); var linked_132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_131, aot_arbace_core.A_arbace_core_requiring_resolve_A_fn_class); var ifn_133 lang.IFn; if linked_132 == nil { ifn_133 = lang.IFn_Cast(root_131) } else { ifn_133 = nil }; var arg_134 any = A_arbace_classes_env_A_const_38; if linked_132 == nil { tmp2 = ifn_133.Invoke_O__O(arg_134) } else { tmp2 = linked_132.(*aot_arbace_core.A_arbace_core_requiring_resolve_A).Invoke_O_O__O(root_131, arg_134) }; return lang.IFn_Cast(tmp2).Invoke_O__O(c__0) } else {
//line :114:1
			return nil
		}
}
func A_arbace_classes_env_read_method_annotations_A_New() *A_arbace_classes_env_read_method_annotations_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_read_method_annotations_A{}; t.Ctor(); return t }
//line :117:1
func (t *A_arbace_classes_env_read_method_annotations_A) Ctor() {}
//line :117:1
func (t *A_arbace_classes_env_read_method_annotations_A) Invoke_O_O__O(self, c__0 any) any {



	var tmp1 any; var root_135 any = A_arbace_classes_env_A_const_36.GetRawRoot__O(); var linked_136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_135, A_arbace_classes_env_class_file_QMARK__A_fn_class); var ifn_137 lang.IFn; if linked_136 == nil { ifn_137 = lang.IFn_Cast(root_135) } else { ifn_137 = nil }; var arg_138 any = c__0; if linked_136 == nil { tmp1 = ifn_137.Invoke_O__O(arg_138) } else { tmp1 = linked_136.(*A_arbace_classes_env_class_file_QMARK__A).Invoke_O_O__O(root_135, arg_138) }; if jrt.J2g_Truth(tmp1) {
		var tmp2 any; var root_139 any = A_arbace_classes_env_A_const_37.GetRawRoot__O(); var linked_140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_139, aot_arbace_core.A_arbace_core_requiring_resolve_A_fn_class); var ifn_141 lang.IFn; if linked_140 == nil { ifn_141 = lang.IFn_Cast(root_139) } else { ifn_141 = nil }; var arg_142 any = A_arbace_classes_env_A_const_39; if linked_140 == nil { tmp2 = ifn_141.Invoke_O__O(arg_142) } else { tmp2 = linked_140.(*aot_arbace_core.A_arbace_core_requiring_resolve_A).Invoke_O_O__O(root_139, arg_142) }; return lang.IFn_Cast(tmp2).Invoke_O__O(c__0) } else {
//line :121:1
			return lang.PersistentArrayMap_EMPTY.Ref()
		}
}

func A_arbace_classes_env_coerce_const_A_New() *A_arbace_classes_env_coerce_const_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_coerce_const_A{}; t.Ctor(); return t }
//line :125:1
func (t *A_arbace_classes_env_coerce_const_A) Ctor() {}
//line :125:1
func (t *A_arbace_classes_env_coerce_const_A) Invoke_O_O_O__O(self, desc__0, v__1 any) any { var G__28000023__3_ any = desc__0; switch
												lang.Util_Hash_O__I_NoInit(G__28000023__3_) { case 66: if lang.Util_Equiv_O_O__Z_NoInit(G__28000023__3_, Lit_7) {



		return jrt.Byte_ValueOf_B__Byte_NoInit(lang.RT_ByteCast_O__B_NoInit(v__1)).Ref() }
//line :126:1
	case 67: if lang.Util_Equiv_O_O__Z_NoInit(G__28000023__3_, Lit_8) {

		return jrt.Character_ValueOf_C__Character_NoInit(lang.RT_CharCast_I__C_NoInit(lang.RT_IntCast_O__I_NoInit(v__1))).Ref() }
//line :126:1
	case 83: if lang.Util_Equiv_O_O__Z_NoInit(G__28000023__3_, Lit_9) {


		return jrt.Short_ValueOf_S__Short_NoInit(lang.RT_ShortCast_O__S_NoInit(v__1)).Ref() }
//line :126:1
	case 90: if lang.Util_Equiv_O_O__Z_NoInit(G__28000023__3_, Lit_10) {
		var root_144 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_144, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_146 lang.IFn; if linked_145 == nil { ifn_146 = lang.IFn_Cast(root_144) } else { ifn_146 = nil }; var arg_147 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(lang.RT_LongCast_O__J_NoInit(v__1))).Ref(); if linked_145 == nil { return ifn_146.Invoke_O__O(arg_147) } else { return linked_145.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_144, arg_147) } }
//line :126:1
	default:}; return v__1 }












func A_arbace_classes_env_inner_member_QMARK__A_New() *A_arbace_classes_env_inner_member_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_inner_member_QMARK__A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_classes_env_inner_member_QMARK__A) Ctor() {}
//line :139:1
func (t *A_arbace_classes_env_inner_member_QMARK__A) Invoke_O_O__O(self, c__0 any) any {
	var tmp1 any; var and__1927000168__auto____2 any = jrt.NN(jrt.Class_Cast(c__0)).GetDeclaringClass__Class().Ref(); if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_148 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_148, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_150 lang.IFn; if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Modifier_IsStatic_I__Z(jrt.NN(jrt.Class_Cast(c__0)).GetModifiers__I())).Ref(); if linked_149 == nil { and__1927000168__auto____3 = ifn_150.Invoke_O__O(arg_151) } else { and__1927000168__auto____3 = linked_149.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_148, arg_151) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var root_152 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_154 lang.IFn
		if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(c__0)).IsInterface__Z()).Ref(); if linked_153 == nil { and__1927000168__auto____4 = ifn_154.Invoke_O__O(arg_155) } else { and__1927000168__auto____4 = linked_153.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_152, arg_155) }
//line :140:1
		if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var root_156 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_158 lang.IFn
			if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(c__0)).IsEnum__Z()).Ref(); if linked_157 == nil { and__1927000168__auto____5 = ifn_158.Invoke_O__O(arg_159) } else { and__1927000168__auto____5 = linked_157.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_156, arg_159) }
//line :140:1
			if jrt.J2g_Truth(and__1927000168__auto____5) {
				var root_160 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(c__0)).IsRecord__Z()).Ref(); if linked_161 == nil { tmp1 = ifn_162.Invoke_O__O(arg_163) } else { tmp1 = linked_161.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_160, arg_163) } } else {
//line :140:1
					tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref()
}

func A_arbace_classes_env_reflect_info_A_New() *A_arbace_classes_env_reflect_info_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_A{}; t.Ctor(); return t }
//line :143:1
func (t *A_arbace_classes_env_reflect_info_A) Ctor() {}
//line :143:1
func (t *A_arbace_classes_env_reflect_info_A) Invoke_O_O__O(self, c__0 any) any { var or__1927000174__auto____2 any = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_40.GetRawRoot__O())).Get_O__O(c__0); if
										jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var lockee__1927000360__auto____3 any = A_arbace_classes_env_A_const_40.GetRawRoot__O(); var locklocal__1927000361__auto____6 any = lockee__1927000360__auto____3; lang.Compiler_Evaluator_MonitorEnter_O__V_NoInit(locklocal__1927000361__auto____6); var tmp1 any; tmp44 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var or__1927000174__auto____9 any = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_40.GetRawRoot__O())).Get_O__O(c__0)

		if jrt.J2g_Truth(or__1927000174__auto____9) { tmp1 = or__1927000174__auto____9 } else { var n__10 any; var root_164 any = A_arbace_classes_env_A_const_35.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, A_arbace_classes_env_internal_A_fn_class); var ifn_166 lang.IFn
			if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = c__0; if linked_165 == nil { n__10 = ifn_166.Invoke_O__O(arg_167) } else { n__10 = linked_165.(*A_arbace_classes_env_internal_A).Invoke_O_O__O(root_164, arg_167) }
//line :146:1
			var manns__11 any; var tmp2 any = A_arbace_classes_env_reflect_info_fn__28000027_A_New_O(c__0); var tmp3 *jrt.Class
			var fncls__172 /*line :146:1*/*jrt.Class = A_arbace_classes_env_reflect_info_fn__28000027_A_fn_class

			if fncls__172 == nil { var fncls__172d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_classes_env_reflect_info_fn__28000027_A_fn_class = fncls__172d; tmp3 = fncls__172d } else { tmp3 = fncls__172 }
//line :146:1
			manns__11 = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var info__12 any; var tmp4 any = A_arbace_classes_env_A_const_42; var tmp5 any = A_arbace_classes_env_A_const_43; var tmp6 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Class_Cast(c__0)).GetModifiers__I()).Ref(); var tmp7 any = A_arbace_classes_env_A_const_44; var tmp8 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(c__0)).IsInterface__Z()).Ref(); var tmp9 any = A_arbace_classes_env_A_const_45; var tmp10 any; var G__28000029__12_ any = jrt.NN(jrt.Class_Cast(c__0)).GetSuperclass__Class().Ref()





			if lang.Util_Identical_O_O__Z_NoInit(G__28000029__12_, nil) { tmp10 = nil } else { var root_173 any = A_arbace_classes_env_A_const_35.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, A_arbace_classes_env_internal_A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any = G__28000029__12_; if linked_174 == nil { tmp10 = ifn_175.Invoke_O__O(arg_176) } else { tmp10 = linked_174.(*A_arbace_classes_env_internal_A).Invoke_O_O__O(root_173, arg_176) } }
//line :146:1
			var tmp11 any = tmp10; var tmp12 any = A_arbace_classes_env_A_const_46; var tmp13 any; var root_177 any = A_arbace_classes_env_A_const_47.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_177, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_179 lang.IFn






			if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any = A_arbace_classes_env_A_const_35.GetRawRoot__O(); var arg_181 any = jrt.NN(jrt.Class_Cast(c__0)).GetInterfaces__Class1().Ref(); if linked_178 == nil { tmp13 = ifn_179.Invoke_O_O__O(arg_180, arg_181) } else { tmp13 = linked_178.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_177, arg_180, arg_181) }
//line :146:1
			var tmp14 any = tmp13; var tmp15 any = A_arbace_classes_env_A_const_48; var tmp16 any; var root_182 any = A_arbace_classes_env_A_const_35.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, A_arbace_classes_env_internal_A_fn_class); var ifn_184 lang.IFn







			if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = jrt.NN(jrt.Class_Cast(c__0)).GetNestHost__Class().Ref(); if linked_183 == nil { tmp16 = ifn_184.Invoke_O__O(arg_185) } else { tmp16 = linked_183.(*A_arbace_classes_env_internal_A).Invoke_O_O__O(root_182, arg_185) }
//line :146:1
			var tmp17 any = tmp16; var tmp18 any = A_arbace_classes_env_A_const_49; var tmp19 any; var G__28000030__12_ any = jrt.NN(jrt.Class_Cast(c__0)).GetDeclaringClass__Class().Ref()








			if lang.Util_Identical_O_O__Z_NoInit(G__28000030__12_, nil) { tmp19 = nil } else { var root_186 any = A_arbace_classes_env_A_const_35.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, A_arbace_classes_env_internal_A_fn_class); var ifn_188 lang.IFn; if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any = G__28000030__12_; if linked_187 == nil { tmp19 = ifn_188.Invoke_O__O(arg_189) } else { tmp19 = linked_187.(*A_arbace_classes_env_internal_A).Invoke_O_O__O(root_186, arg_189) } }
//line :146:1
			var tmp20 any = tmp19; var tmp21 any = A_arbace_classes_env_A_const_50; var tmp22 any; var temp__1927000408__auto____12 any; var root_190 any = A_arbace_classes_env_A_const_51.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, A_arbace_classes_env_read_fields_A_fn_class); var ifn_192 lang.IFn









			if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = c__0; if linked_191 == nil { temp__1927000408__auto____12 = ifn_192.Invoke_O__O(arg_193) } else { temp__1927000408__auto____12 = linked_191.(*A_arbace_classes_env_read_fields_A).Invoke_O_O__O(root_190, arg_193) }; if jrt.J2g_Truth(temp__1927000408__auto____12) { var fs__13 any = temp__1927000408__auto____12; var root_194 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_194, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_196 lang.IFn
				if linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any; var iter__1927001039__auto____14 any; var tmp23 any = A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_New_O(n__10); var tmp24 *jrt.Class; var fncls__314 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_fn_class; if fncls__314 == nil { var fncls__314d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_fn_class = fncls__314d; tmp24 = fncls__314d } else { tmp24 = fncls__314 }; iter__1927001039__auto____14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil); arg_197 = lang.IFn_Cast(iter__1927001039__auto____14).Invoke_O__O(fs__13); if linked_195 == nil { tmp22 = ifn_196.Invoke_O__O(arg_197) } else { tmp22 = linked_195.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_194, arg_197) } } else {




					var root_315 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_315, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_317 lang.IFn; if linked_316 == nil { ifn_317 = lang.IFn_Cast(root_315) } else { ifn_317 = nil }; var arg_318 any; var iter__1927001039__auto____13 any; var tmp25 any = A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_New_O(n__10); var tmp26 *jrt.Class; var fncls__385 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_fn_class; if fncls__385 == nil { var fncls__385d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_fn_class = fncls__385d; tmp26 = fncls__385d } else { tmp26 = fncls__385 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil); arg_318 = lang.IFn_Cast(iter__1927001039__auto____13).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetDeclaredFields__Field1().Ref()); if linked_316 == nil { tmp22 = ifn_317.Invoke_O__O(arg_318) } else { tmp22 = linked_316.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_315, arg_318) } }
//line :146:1
			var tmp27 any = tmp22; var tmp28 any = A_arbace_classes_env_A_const_74; var tmp29 any; var root_386 any = A_arbace_classes_env_A_const_75.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_386, A_arbace_classes_env_inner_member_QMARK__A_fn_class); var ifn_388 lang.IFn



















			if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any = c__0; if linked_387 == nil { tmp29 = ifn_388.Invoke_O__O(arg_389) } else { tmp29 = linked_387.(*A_arbace_classes_env_inner_member_QMARK__A).Invoke_O_O__O(root_386, arg_389) }
//line :146:1
			var tmp30 any = tmp29; var tmp31 any = A_arbace_classes_env_A_const_76; var tmp32 any; var root_390 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_390, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_392 lang.IFn




















			if linked_391 == nil { ifn_392 = lang.IFn_Cast(root_390) } else { ifn_392 = nil }; var arg_393 any; var root_394 any = A_arbace_classes_env_A_const_77.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_394, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_396 lang.IFn; if linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any; var iter__1927001039__auto____12 any; var tmp33 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_New_O_O(n__10, manns__11); var tmp34 *jrt.Class; var fncls__547 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_fn_class
			if fncls__547 == nil { var fncls__547d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_fn_class = fncls__547d; tmp34 = fncls__547d } else { tmp34 = fncls__547 }; iter__1927001039__auto____12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil); arg_397 = lang.IFn_Cast(iter__1927001039__auto____12).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetDeclaredMethods__Method1().Ref())
//line :167:1
			var arg_398 any; var iter__1927001039__auto____12_2 any; var tmp35 any = A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_New_O_O(c__0, n__10); var tmp36 *jrt.Class
			var fncls__660 /*line :167:1*/*jrt.Class = A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_fn_class











			if fncls__660 == nil { var fncls__660d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_fn_class = fncls__660d; tmp36 = fncls__660d } else { tmp36 = fncls__660 }; iter__1927001039__auto____12_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp35, tmp36, nil); arg_398 = lang.IFn_Cast(iter__1927001039__auto____12_2).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetDeclaredConstructors__Constructor1().Ref())
//line :167:1
			if linked_395 == nil { arg_393 = ifn_396.Invoke_O_O__O(arg_397, arg_398) } else { arg_393 = linked_395.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_394, arg_397, arg_398) }; if linked_391 == nil { tmp32 = ifn_392.Invoke_O__O(arg_393) } else { tmp32 = linked_391.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_390, arg_393) }
//line :146:1
			info__12 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, n__10, tmp5, tmp6, tmp7, tmp8, tmp9, tmp11, tmp12, tmp14, tmp15, tmp17, tmp18, tmp20, tmp21, tmp27, tmp28, tmp30, tmp31, tmp32, A_arbace_classes_env_A_const_32, c__0)); var info__13 any; var tmp37 any; var and__1927000168__auto____13 any; var root_661 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_661, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_663 lang.IFn











































			if linked_662 == nil { ifn_663 = lang.IFn_Cast(root_661) } else { ifn_663 = nil }; var arg_664 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(c__0)).IsInterface__Z()).Ref(); if linked_662 == nil { and__1927000168__auto____13 = ifn_663.Invoke_O__O(arg_664) } else { and__1927000168__auto____13 = linked_662.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_661, arg_664) }; if jrt.J2g_Truth(and__1927000168__auto____13) { var root_665 any = A_arbace_classes_env_A_const_85.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_665, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_667 lang.IFn; if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any; var root_669 any = A_arbace_classes_env_A_const_86.GetRawRoot__O(); var linked_670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_669, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_671 lang.IFn; if linked_670 == nil { ifn_671 = lang.IFn_Cast(root_669) } else { ifn_671 = nil }; var arg_672 any; var tmp38 any = A_arbace_classes_env_reflect_info_fn__28000089_A_New(); var tmp39 *jrt.Class; var fncls__674 *jrt.Class = A_arbace_classes_env_reflect_info_fn__28000089_A_fn_class; if fncls__674 == nil { var fncls__674d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_classes_env_reflect_info_fn__28000089_A_fn_class = fncls__674d; tmp39 = fncls__674d } else { tmp39 = fncls__674 }; arg_672 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp38, tmp39, nil); var arg_673 any = A_arbace_classes_env_A_const_76.Invoke_O__O(info__12); if linked_670 == nil { arg_668 = ifn_671.Invoke_O_O__O(arg_672, arg_673) } else { arg_668 = linked_670.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_669, arg_672, arg_673) }; if linked_666 == nil { tmp37 = ifn_667.Invoke_O__O(arg_668) } else { tmp37 = linked_666.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_665, arg_668) } } else { tmp37 = and__1927000168__auto____13 }; if jrt.J2g_Truth(tmp37) {
				var root_675 any = A_arbace_classes_env_A_const_16.GetRawRoot__O(); var linked_676 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_675, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_677 lang.IFn; if linked_676 == nil { ifn_677 = lang.IFn_Cast(root_675) } else { ifn_677 = nil }; var arg_678 any = info__12; var arg_679 any = A_arbace_classes_env_A_const_76; var arg_680 any = A_arbace_classes_env_A_const_87.GetRawRoot__O(); var arg_681 any; var iter__1927001039__auto____13_2 any; var tmp40 any = A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_New_O(n__10); var tmp41 *jrt.Class; var fncls__740 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_fn_class; if fncls__740 == nil { var fncls__740d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_fn_class = fncls__740d; tmp41 = fncls__740d } else { tmp41 = fncls__740 }; iter__1927001039__auto____13_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp40, tmp41, nil); var tmp42 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____13_2); var tmp43 any; var root_741 any = A_arbace_classes_env_A_const_37.GetRawRoot__O(); var linked_742 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_741, aot_arbace_core.A_arbace_core_requiring_resolve_A_fn_class); var ifn_743 lang.IFn; if linked_742 == nil { ifn_743 = lang.IFn_Cast(root_741) } else { ifn_743 = nil }; var arg_744 any = A_arbace_classes_env_A_const_88; if linked_742 == nil { tmp43 = ifn_743.Invoke_O__O(arg_744) } else { tmp43 = linked_742.(*aot_arbace_core.A_arbace_core_requiring_resolve_A).Invoke_O_O__O(root_741, arg_744) }; arg_681 = tmp42.Invoke_O__O(lang.IFn_Cast(tmp43).Invoke_O__O(n__10)); if linked_676 == nil { info__13 = ifn_677.Invoke_O_O_O_O__O(arg_678, arg_679, arg_680, arg_681) } else { info__13 = linked_676.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_675, arg_678, arg_679, arg_680, arg_681) } } else {
//line :190:1
					info__13 = info__12
				}


			jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_40.GetRawRoot__O())).Put_O_O__O(c__0, info__13)
//line :146:1
			tmp1 = info__13 } }; return nil }()
//line :144:1
		lang.Compiler_Evaluator_MonitorExit_O__V_NoInit(locklocal__1927000361__auto____6); if tmp44 != nil { panic(tmp44) }; return tmp1 } }



func A_arbace_classes_env_reflect_info_fn__28000027_A_New_O(p0 any) *A_arbace_classes_env_reflect_info_fn__28000027_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_fn__28000027_A{}; t.Ctor_O(p0); return t }
//line :148:1
func (t *A_arbace_classes_env_reflect_info_fn__28000027_A) Ctor_O(c__c any) { t.F_c = c__c }
//line :148:1
func (t *A_arbace_classes_env_reflect_info_fn__28000027_A) Invoke_O__O(self any) any { var root_168 any = A_arbace_classes_env_A_const_41.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, A_arbace_classes_env_read_method_annotations_A_fn_class); var ifn_170 lang.IFn; if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any; var t_ any = t.F_c; t.F_c = nil; arg_171 = t_; if linked_169 == nil { return ifn_170.Invoke_O__O(arg_171) } else { return linked_169.(*A_arbace_classes_env_read_method_annotations_A).Invoke_O_O__O(root_168, arg_171) } }








func A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_New_O(p0 any) *A_arbace_classes_env_reflect_info_iter__28000031__28000035_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000031__28000035_A{}; t.Ctor_O(p0); return t }
//line :157:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :157:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_A) Invoke_O_O__O(self, s__28000032__1 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_New_O_O_O(t.F_n, s__28000032__1, self); var tmp2 *jrt.Class; var fncls__313 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_fn_class; if fncls__313 == nil { var fncls__313d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_fn_class = fncls__313d; tmp2 = fncls__313d } else { tmp2 = fncls__313 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :157:1
func A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :157:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A) Ctor_O_O_O(c__n, c__s__28000032, c__iter__28000031 any) { t.F_n = c__n; t.F_s__28000032 = c__s__28000032; t.F_iter__28000031 = c__iter__28000031 }
//line :157:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A) Invoke_O__O(self any) any { { var s__28000032__1 any; var t_ any = t.F_s__28000032; t.F_s__28000032 = nil; s__28000032__1 = t_; for { var temp__1927000414__auto____2 any; var root_198 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_198, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_200 lang.IFn; if linked_199 == nil { ifn_200 = lang.IFn_Cast(root_198) } else { ifn_200 = nil }; var arg_201 any = s__28000032__1; if linked_199 == nil { temp__1927000414__auto____2 = ifn_200.Invoke_O__O(arg_201) } else { temp__1927000414__auto____2 = linked_199.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_198, arg_201) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__28000032__3 any = temp__1927000414__auto____2; var tmp1 any; var root_202 any = A_arbace_classes_env_A_const_54.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_204 lang.IFn; if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any = s__28000032__3; if linked_203 == nil { tmp1 = ifn_204.Invoke_O__O(arg_205) } else { tmp1 = linked_203.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_202, arg_205) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_206 any = A_arbace_classes_env_A_const_55.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_208 lang.IFn; if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any = s__28000032__3; if linked_207 == nil { c__1927001037__auto____4 = ifn_208.Invoke_O__O(arg_209) } else { c__1927001037__auto____4 = linked_207.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_206, arg_209) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__28000034__6 any; var root_210 any = A_arbace_classes_env_A_const_56.GetRawRoot__O(); var linked_211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_210, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_212 lang.IFn; if linked_211 == nil { ifn_212 = lang.IFn_Cast(root_210) } else { ifn_212 = nil }; var arg_213 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_211 == nil { b__28000034__6 = ifn_212.Invoke_O__O(arg_213) } else { b__28000034__6 = linked_211.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_210, arg_213) }; var tmp2 any = A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_New_O_O_I_O(b__28000034__6, t.F_n, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__248 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_fn_class; if fncls__248 == nil { var fncls__248d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_fn_class = fncls__248d; tmp3 = fncls__248d } else { tmp3 = fncls__248 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_249 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_251 lang.IFn; if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any; var root_254 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_256 lang.IFn; if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any = b__28000034__6; if linked_255 == nil { arg_252 = ifn_256.Invoke_O__O(arg_257) } else { arg_252 = linked_255.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_254, arg_257) }; var arg_253 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__28000031); var tmp5 any; var root_258 any = A_arbace_classes_env_A_const_70.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = s__28000032__3; if linked_259 == nil { tmp5 = ifn_260.Invoke_O__O(arg_261) } else { tmp5 = linked_259.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_258, arg_261) }; arg_253 = tmp4.Invoke_O__O(tmp5); if linked_250 == nil { return ifn_251.Invoke_O_O__O(arg_252, arg_253) } else { return linked_250.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_249, arg_252, arg_253) } } else { var root_262 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_264 lang.IFn; if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any; var root_267 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_267, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_269 lang.IFn; if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any = b__28000034__6; if linked_268 == nil { arg_265 = ifn_269.Invoke_O__O(arg_270) } else { arg_265 = linked_268.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_267, arg_270) }; var arg_266 any; if linked_263 == nil { return ifn_264.Invoke_O_O__O(arg_265, arg_266) } else { return linked_263.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_262, arg_265, arg_266) } } } else { var map__28000041__4 any; var root_271 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_273 lang.IFn; if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = s__28000032__3; if linked_272 == nil { map__28000041__4 = ifn_273.Invoke_O__O(arg_274) } else { map__28000041__4 = linked_272.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_271, arg_274) }; var map__28000041__5 any; if lang.ISeq_InstanceOf(map__28000041__4) { var tmp6 any; var root_275 any = A_arbace_classes_env_A_const_57.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_275, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_277 lang.IFn; if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any = map__28000041__4; if linked_276 == nil { tmp6 = ifn_277.Invoke_O__O(arg_278) } else { tmp6 = linked_276.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_275, arg_278) }; if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_279 any = A_arbace_classes_env_A_const_58.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = map__28000041__4; if linked_280 == nil { tmp7 = ifn_281.Invoke_O__O(arg_282) } else { tmp7 = linked_280.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_279, arg_282) }; map__28000041__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp7, jrt.Object_class.ArrayClass())).Ref() } else { var tmp8 any; var root_283 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_283, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_285 lang.IFn; if linked_284 == nil { ifn_285 = lang.IFn_Cast(root_283) } else { ifn_285 = nil }; var arg_286 any = map__28000041__4; if linked_284 == nil { tmp8 = ifn_285.Invoke_O__O(arg_286) } else { tmp8 = linked_284.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_283, arg_286) }; if jrt.J2g_Truth(tmp8) { var root_287 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_289 lang.IFn; if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any = map__28000041__4; if linked_288 == nil { map__28000041__5 = ifn_289.Invoke_O__O(arg_290) } else { map__28000041__5 = linked_288.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_287, arg_290) } } else { map__28000041__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__28000041__5 = map__28000041__4 }; var name__6 any = lang.RT_Get_O_O__O_NoInit(map__28000041__5, A_arbace_classes_env_A_const_42); var desc__7 any = lang.RT_Get_O_O__O_NoInit(map__28000041__5, A_arbace_classes_env_A_const_60); var flags__8 any = lang.RT_Get_O_O__O_NoInit(map__28000041__5, A_arbace_classes_env_A_const_43); var value__9 any = lang.RT_Get_O_O__O_NoInit(map__28000041__5, A_arbace_classes_env_A_const_61); var root_291 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_293 lang.IFn; if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any; var tmp9 any = A_arbace_classes_env_A_const_42; var tmp10 any = A_arbace_classes_env_A_const_60; var tmp11 any = A_arbace_classes_env_A_const_43; var tmp12 any = A_arbace_classes_env_A_const_63; var tmp13 any = t.F_n; var tmp14 any = A_arbace_classes_env_A_const_64; var tmp15 any; var tmp16 any; var and__1927000168__auto____10 bool = jrt.Modifier_IsFinal_I__Z(lang.RT_IntCast_O__I_NoInit(flags__8))

	if and__1927000168__auto____10 { var and__1927000168__auto____11 any; var root_296 any = A_arbace_classes_env_A_const_25.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_298 lang.IFn; if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = value__9; if linked_297 == nil { and__1927000168__auto____11 = ifn_298.Invoke_O__O(arg_299) } else { and__1927000168__auto____11 = linked_297.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_296, arg_299) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var or__1927000174__auto____12 any; var root_300 any = A_arbace_classes_env_A_const_65.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_302 lang.IFn
		if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = desc__7; if linked_301 == nil { or__1927000174__auto____12 = ifn_302.Invoke_O__O(arg_303) } else { or__1927000174__auto____12 = linked_301.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_300, arg_303) }; if jrt.J2g_Truth(or__1927000174__auto____12) { tmp16 = or__1927000174__auto____12 } else { tmp16 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(desc__7, A_arbace_classes_env_A_const_66.GetRawRoot__O())).Ref() } } else {
//line :159:1
			tmp16 = and__1927000168__auto____11 } } else { tmp16 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10).Ref() }; if jrt.J2g_Truth(tmp16) {

				var root_304 any = A_arbace_classes_env_A_const_67.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_304, A_arbace_classes_env_coerce_const_A_fn_class); var ifn_306 lang.IFn; if linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any = desc__7; var arg_308 any = value__9; if linked_305 == nil { tmp15 = ifn_306.Invoke_O_O__O(arg_307, arg_308) } else { tmp15 = linked_305.(*A_arbace_classes_env_coerce_const_A).Invoke_O_O_O__O(root_304, arg_307, arg_308) } } else {
//line :159:1
					tmp15 = nil }
//line :157:1
	arg_294 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, name__6, tmp10, desc__7, tmp11, flags__8, tmp12, tmp13, tmp14, tmp15)); var arg_295 any; var tmp17 lang.IFn = lang.IFn_Cast(t.F_iter__28000031); var tmp18 any; var root_309 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_309, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_311 lang.IFn; if linked_310 == nil { ifn_311 = lang.IFn_Cast(root_309) } else { ifn_311 = nil }; var arg_312 any = s__28000032__3; if linked_310 == nil { tmp18 = ifn_311.Invoke_O__O(arg_312) } else { tmp18 = linked_310.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_309, arg_312) }; arg_295 = tmp17.Invoke_O__O(tmp18); if linked_292 == nil { return ifn_293.Invoke_O_O__O(arg_294, arg_295) } else { return linked_292.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_291, arg_294, arg_295) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :157:1
func A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :157:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A) Ctor_O_O_I_O(c__b__28000034, c__n any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__28000034 = c__b__28000034; t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :157:1
func (t *A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A) Invoke_O__O(self any) any { { var i__28000033__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__28000033__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var map__28000038__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__28000033__1)); var map__28000038__3 any; if lang.ISeq_InstanceOf(map__28000038__2) { var tmp2 any; var root_214 any = A_arbace_classes_env_A_const_57.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_214, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_216 lang.IFn; if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = map__28000038__2; if linked_215 == nil { tmp2 = ifn_216.Invoke_O__O(arg_217) } else { tmp2 = linked_215.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_214, arg_217) }; if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_218 any = A_arbace_classes_env_A_const_58.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_218, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_220 lang.IFn; if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any = map__28000038__2; if linked_219 == nil { tmp3 = ifn_220.Invoke_O__O(arg_221) } else { tmp3 = linked_219.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_218, arg_221) }; map__28000038__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp3, jrt.Object_class.ArrayClass())).Ref() } else { var tmp4 any; var root_222 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_222, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_224 lang.IFn; if linked_223 == nil { ifn_224 = lang.IFn_Cast(root_222) } else { ifn_224 = nil }; var arg_225 any = map__28000038__2; if linked_223 == nil { tmp4 = ifn_224.Invoke_O__O(arg_225) } else { tmp4 = linked_223.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_222, arg_225) }; if jrt.J2g_Truth(tmp4) { var root_226 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_226, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_228 lang.IFn; if linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var arg_229 any = map__28000038__2; if linked_227 == nil { map__28000038__3 = ifn_228.Invoke_O__O(arg_229) } else { map__28000038__3 = linked_227.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_226, arg_229) } } else { map__28000038__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__28000038__3 = map__28000038__2 }; var name__4 any = lang.RT_Get_O_O__O_NoInit(map__28000038__3, A_arbace_classes_env_A_const_42); var desc__5 any = lang.RT_Get_O_O__O_NoInit(map__28000038__3, A_arbace_classes_env_A_const_60); var flags__6 any = lang.RT_Get_O_O__O_NoInit(map__28000038__3, A_arbace_classes_env_A_const_43); var value__7 any = lang.RT_Get_O_O__O_NoInit(map__28000038__3, A_arbace_classes_env_A_const_61); var root_230 any = A_arbace_classes_env_A_const_62.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_230, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_232 lang.IFn; if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = t.F_b__28000034; var arg_234 any; var tmp5 any = A_arbace_classes_env_A_const_42; var tmp6 any = A_arbace_classes_env_A_const_60; var tmp7 any = A_arbace_classes_env_A_const_43; var tmp8 any = A_arbace_classes_env_A_const_63; var tmp9 any = t.F_n; var tmp10 any = A_arbace_classes_env_A_const_64; var tmp11 any; var tmp12 any; var and__1927000168__auto____8 bool = jrt.Modifier_IsFinal_I__Z(lang.RT_IntCast_O__I_NoInit(flags__6))

	if and__1927000168__auto____8 { var and__1927000168__auto____9 any; var root_235 any = A_arbace_classes_env_A_const_25.GetRawRoot__O(); var linked_236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_235, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_237 lang.IFn; if linked_236 == nil { ifn_237 = lang.IFn_Cast(root_235) } else { ifn_237 = nil }; var arg_238 any = value__7; if linked_236 == nil { and__1927000168__auto____9 = ifn_237.Invoke_O__O(arg_238) } else { and__1927000168__auto____9 = linked_236.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_235, arg_238) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var or__1927000174__auto____10 any; var root_239 any = A_arbace_classes_env_A_const_65.GetRawRoot__O(); var linked_240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_239, aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A_fn_class); var ifn_241 lang.IFn
		if linked_240 == nil { ifn_241 = lang.IFn_Cast(root_239) } else { ifn_241 = nil }; var arg_242 any = desc__5; if linked_240 == nil { or__1927000174__auto____10 = ifn_241.Invoke_O__O(arg_242) } else { or__1927000174__auto____10 = linked_240.(*aot_arbace_classes_types.A_arbace_classes_types_prim_QMARK__A).Invoke_O_O__O(root_239, arg_242) }; if jrt.J2g_Truth(or__1927000174__auto____10) { tmp12 = or__1927000174__auto____10 } else { tmp12 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(desc__5, A_arbace_classes_env_A_const_66.GetRawRoot__O())).Ref() } } else {
//line :159:1
			tmp12 = and__1927000168__auto____9 } } else { tmp12 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() }; if jrt.J2g_Truth(tmp12) {

				var root_243 any = A_arbace_classes_env_A_const_67.GetRawRoot__O(); var linked_244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_243, A_arbace_classes_env_coerce_const_A_fn_class); var ifn_245 lang.IFn; if linked_244 == nil { ifn_245 = lang.IFn_Cast(root_243) } else { ifn_245 = nil }; var arg_246 any = desc__5; var arg_247 any = value__7; if linked_244 == nil { tmp11 = ifn_245.Invoke_O_O__O(arg_246, arg_247) } else { tmp11 = linked_244.(*A_arbace_classes_env_coerce_const_A).Invoke_O_O_O__O(root_243, arg_246, arg_247) } } else {
//line :159:1
					tmp11 = nil }
//line :157:1
	arg_234 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, name__4, tmp6, desc__5, tmp7, flags__6, tmp8, tmp9, tmp10, tmp11)); if linked_231 == nil { ifn_232.Invoke_O_O__O(arg_233, arg_234) } else { linked_231.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_230, arg_233, arg_234) }; i__28000033__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000033__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_New_O(p0 any) *A_arbace_classes_env_reflect_info_iter__28000045__28000049_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000045__28000049_A{}; t.Ctor_O(p0); return t }
//line :162:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :162:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_A) Invoke_O_O__O(self, s__28000046__1 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_New_O_O_O(t.F_n, s__28000046__1, self); var tmp2 *jrt.Class; var fncls__384 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_fn_class; if fncls__384 == nil { var fncls__384d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_fn_class = fncls__384d; tmp2 = fncls__384d } else { tmp2 = fncls__384 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :162:1
func A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :162:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A) Ctor_O_O_O(c__n, c__s__28000046, c__iter__28000045 any) { t.F_n = c__n; t.F_s__28000046 = c__s__28000046; t.F_iter__28000045 = c__iter__28000045 }
//line :162:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A) Invoke_O__O(self any) any { { var s__28000046__1 any; var t_ any = t.F_s__28000046; t.F_s__28000046 = nil; s__28000046__1 = t_; for { var temp__1927000414__auto____2 any; var root_319 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_319, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_321 lang.IFn; if linked_320 == nil { ifn_321 = lang.IFn_Cast(root_319) } else { ifn_321 = nil }; var arg_322 any = s__28000046__1; if linked_320 == nil { temp__1927000414__auto____2 = ifn_321.Invoke_O__O(arg_322) } else { temp__1927000414__auto____2 = linked_320.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_319, arg_322) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__28000046__3 any = temp__1927000414__auto____2; var tmp1 any; var root_323 any = A_arbace_classes_env_A_const_54.GetRawRoot__O(); var linked_324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_323, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_325 lang.IFn; if linked_324 == nil { ifn_325 = lang.IFn_Cast(root_323) } else { ifn_325 = nil }; var arg_326 any = s__28000046__3; if linked_324 == nil { tmp1 = ifn_325.Invoke_O__O(arg_326) } else { tmp1 = linked_324.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_323, arg_326) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_327 any = A_arbace_classes_env_A_const_55.GetRawRoot__O(); var linked_328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_327, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_329 lang.IFn; if linked_328 == nil { ifn_329 = lang.IFn_Cast(root_327) } else { ifn_329 = nil }; var arg_330 any = s__28000046__3; if linked_328 == nil { c__1927001037__auto____4 = ifn_329.Invoke_O__O(arg_330) } else { c__1927001037__auto____4 = linked_328.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_327, arg_330) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__28000048__6 any; var root_331 any = A_arbace_classes_env_A_const_56.GetRawRoot__O(); var linked_332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_331, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_333 lang.IFn; if linked_332 == nil { ifn_333 = lang.IFn_Cast(root_331) } else { ifn_333 = nil }; var arg_334 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_332 == nil { b__28000048__6 = ifn_333.Invoke_O__O(arg_334) } else { b__28000048__6 = linked_332.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_331, arg_334) }; var tmp2 any = A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_New_O_O_I_O(t.F_n, b__28000048__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__344 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_fn_class; if fncls__344 == nil { var fncls__344d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_fn_class = fncls__344d; tmp3 = fncls__344d } else { tmp3 = fncls__344 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_345 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_345, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_347 lang.IFn; if linked_346 == nil { ifn_347 = lang.IFn_Cast(root_345) } else { ifn_347 = nil }; var arg_348 any; var root_350 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any = b__28000048__6; if linked_351 == nil { arg_348 = ifn_352.Invoke_O__O(arg_353) } else { arg_348 = linked_351.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_350, arg_353) }; var arg_349 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__28000045); var tmp5 any; var root_354 any = A_arbace_classes_env_A_const_70.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_354, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_356 lang.IFn; if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any = s__28000046__3; if linked_355 == nil { tmp5 = ifn_356.Invoke_O__O(arg_357) } else { tmp5 = linked_355.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_354, arg_357) }; arg_349 = tmp4.Invoke_O__O(tmp5); if linked_346 == nil { return ifn_347.Invoke_O_O__O(arg_348, arg_349) } else { return linked_346.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_345, arg_348, arg_349) } } else { var root_358 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_360 lang.IFn; if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any; var root_363 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_363, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_365 lang.IFn; if linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any = b__28000048__6; if linked_364 == nil { arg_361 = ifn_365.Invoke_O__O(arg_366) } else { arg_361 = linked_364.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_363, arg_366) }; var arg_362 any; if linked_359 == nil { return ifn_360.Invoke_O_O__O(arg_361, arg_362) } else { return linked_359.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_358, arg_361, arg_362) } } } else { var f__4 any; var root_367 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_367, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_369 lang.IFn; if linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any = s__28000046__3; if linked_368 == nil { f__4 = ifn_369.Invoke_O__O(arg_370) } else { f__4 = linked_368.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_367, arg_370) }; var root_371 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_371, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_373 lang.IFn; if linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any; var tmp6 any = A_arbace_classes_env_A_const_42; var tmp7 any = jrt.NN(jrt.Field_Cast(f__4)).GetName__String().Ref(); var tmp8 any = A_arbace_classes_env_A_const_60; var tmp9 any; var root_376 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_376, aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A_fn_class); var ifn_378 lang.IFn
														if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any = jrt.NN(jrt.Field_Cast(f__4)).GetType__Class().Ref(); if linked_377 == nil { tmp9 = ifn_378.Invoke_O__O(arg_379) } else { tmp9 = linked_377.(*aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A).Invoke_O_O__O(root_376, arg_379) }
//line :162:1
	var tmp10 any = tmp9; var tmp11 any = A_arbace_classes_env_A_const_43; arg_374 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7, tmp8, tmp10, tmp11, jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Field_Cast(f__4)).GetModifiers__I()).Ref(), A_arbace_classes_env_A_const_63, t.F_n, A_arbace_classes_env_A_const_64, nil)); var arg_375 any; var tmp12 lang.IFn = lang.IFn_Cast(t.F_iter__28000045); var tmp13 any; var root_380 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_380, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_382 lang.IFn; if linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any = s__28000046__3; if linked_381 == nil { tmp13 = ifn_382.Invoke_O__O(arg_383) } else { tmp13 = linked_381.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_380, arg_383) }; arg_375 = tmp12.Invoke_O__O(tmp13); if linked_372 == nil { return ifn_373.Invoke_O_O__O(arg_374, arg_375) } else { return linked_372.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_371, arg_374, arg_375) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :162:1
func A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :162:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A) Ctor_O_O_I_O(c__n, c__b__28000048 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__28000048 = c__b__28000048; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :162:1
func (t *A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A) Invoke_O__O(self any) any { { var i__28000047__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__28000047__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__28000047__1)); var root_335 any = A_arbace_classes_env_A_const_62.GetRawRoot__O(); var linked_336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_335, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_337 lang.IFn; if linked_336 == nil { ifn_337 = lang.IFn_Cast(root_335) } else { ifn_337 = nil }; var arg_338 any = t.F_b__28000048; var arg_339 any; var tmp2 any = A_arbace_classes_env_A_const_42; var tmp3 any = jrt.NN(jrt.Field_Cast(f__2)).GetName__String().Ref(); var tmp4 any = A_arbace_classes_env_A_const_60; var tmp5 any; var root_340 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var linked_341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_340, aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A_fn_class); var ifn_342 lang.IFn
																if linked_341 == nil { ifn_342 = lang.IFn_Cast(root_340) } else { ifn_342 = nil }; var arg_343 any = jrt.NN(jrt.Field_Cast(f__2)).GetType__Class().Ref(); if linked_341 == nil { tmp5 = ifn_342.Invoke_O__O(arg_343) } else { tmp5 = linked_341.(*aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A).Invoke_O_O__O(root_340, arg_343) }
//line :162:1
	var tmp6 any = tmp5; var tmp7 any = A_arbace_classes_env_A_const_43; arg_339 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, tmp6, tmp7, jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Field_Cast(f__2)).GetModifiers__I()).Ref(), A_arbace_classes_env_A_const_63, t.F_n, A_arbace_classes_env_A_const_64, nil)); if linked_336 == nil { ifn_337.Invoke_O_O__O(arg_338, arg_339) } else { linked_336.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_335, arg_338, arg_339) }; i__28000047__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000047__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_New_O_O(p0, p1 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_A{}; t.Ctor_O_O(p0, p1); return t }
//line :168:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_A) Ctor_O_O(c__n, c__manns any) { t.F_n = c__n; t.F_manns = c__manns }
//line :168:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_A) Invoke_O_O__O(self, s__28000056__1 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_New_O_O_O_O(t.F_n, t.F_manns, s__28000056__1, self); var tmp2 *jrt.Class; var fncls__546 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_fn_class; if fncls__546 == nil { var fncls__546d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_fn_class = fncls__546d; tmp2 = fncls__546d } else { tmp2 = fncls__546 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :168:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :168:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A) Ctor_O_O_O_O(c__n, c__manns, c__s__28000056, c__iter__28000055 any) { t.F_n = c__n; t.F_manns = c__manns; t.F_s__28000056 = c__s__28000056; t.F_iter__28000055 = c__iter__28000055 }
//line :168:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A) Invoke_O__O(self any) any { { var s__28000056__1 any; var t_ any = t.F_s__28000056; t.F_s__28000056 = nil; s__28000056__1 = t_; for { var temp__1927000414__auto____2 any; var root_399 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_399, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_401 lang.IFn; if linked_400 == nil { ifn_401 = lang.IFn_Cast(root_399) } else { ifn_401 = nil }; var arg_402 any = s__28000056__1; if linked_400 == nil { temp__1927000414__auto____2 = ifn_401.Invoke_O__O(arg_402) } else { temp__1927000414__auto____2 = linked_400.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_399, arg_402) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__28000056__3 any = temp__1927000414__auto____2; var tmp1 any; var root_403 any = A_arbace_classes_env_A_const_54.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_403, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_405 lang.IFn; if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any = s__28000056__3; if linked_404 == nil { tmp1 = ifn_405.Invoke_O__O(arg_406) } else { tmp1 = linked_404.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_403, arg_406) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_407 any = A_arbace_classes_env_A_const_55.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_407, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_409 lang.IFn; if linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any = s__28000056__3; if linked_408 == nil { c__1927001037__auto____4 = ifn_409.Invoke_O__O(arg_410) } else { c__1927001037__auto____4 = linked_408.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_407, arg_410) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__28000058__6 any; var root_411 any = A_arbace_classes_env_A_const_56.GetRawRoot__O(); var linked_412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_411, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_413 lang.IFn; if linked_412 == nil { ifn_413 = lang.IFn_Cast(root_411) } else { ifn_413 = nil }; var arg_414 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_412 == nil { b__28000058__6 = ifn_413.Invoke_O__O(arg_414) } else { b__28000058__6 = linked_412.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_411, arg_414) }; var tmp2 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_New_O_O_O_I_O(t.F_n, b__28000058__6, t.F_manns, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__465 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_fn_class; if fncls__465 == nil { var fncls__465d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_fn_class = fncls__465d; tmp3 = fncls__465d } else { tmp3 = fncls__465 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_466 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_468 lang.IFn; if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any; var root_471 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_471, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_473 lang.IFn; if linked_472 == nil { ifn_473 = lang.IFn_Cast(root_471) } else { ifn_473 = nil }; var arg_474 any = b__28000058__6; if linked_472 == nil { arg_469 = ifn_473.Invoke_O__O(arg_474) } else { arg_469 = linked_472.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_471, arg_474) }; var arg_470 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__28000055); var tmp5 any; var root_475 any = A_arbace_classes_env_A_const_70.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_477 lang.IFn; if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = s__28000056__3; if linked_476 == nil { tmp5 = ifn_477.Invoke_O__O(arg_478) } else { tmp5 = linked_476.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_475, arg_478) }; arg_470 = tmp4.Invoke_O__O(tmp5); if linked_467 == nil { return ifn_468.Invoke_O_O__O(arg_469, arg_470) } else { return linked_467.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_466, arg_469, arg_470) } } else { var root_479 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_481 lang.IFn; if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any; var root_484 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_484, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_486 lang.IFn; if linked_485 == nil { ifn_486 = lang.IFn_Cast(root_484) } else { ifn_486 = nil }; var arg_487 any = b__28000058__6; if linked_485 == nil { arg_482 = ifn_486.Invoke_O__O(arg_487) } else { arg_482 = linked_485.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_484, arg_487) }; var arg_483 any; if linked_480 == nil { return ifn_481.Invoke_O_O__O(arg_482, arg_483) } else { return linked_480.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_479, arg_482, arg_483) } } } else { var m__4 any; var root_488 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_488, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_490 lang.IFn; if linked_489 == nil { ifn_490 = lang.IFn_Cast(root_488) } else { ifn_490 = nil }; var arg_491 any = s__28000056__3; if linked_489 == nil { m__4 = ifn_490.Invoke_O__O(arg_491) } else { m__4 = linked_489.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_488, arg_491) }; var desc__5 any; var root_492 any = A_arbace_classes_env_A_const_78.GetRawRoot__O(); var linked_493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_492, aot_arbace_classes_types.A_arbace_classes_types_method_desc_A_fn_class); var ifn_494 lang.IFn
														if linked_493 == nil { ifn_494 = lang.IFn_Cast(root_492) } else { ifn_494 = nil }; var arg_495 any; var root_497 any = A_arbace_classes_env_A_const_79.GetRawRoot__O(); var linked_498 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_497, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_499 lang.IFn; if linked_498 == nil { ifn_499 = lang.IFn_Cast(root_497) } else { ifn_499 = nil }; var arg_500 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var arg_501 any = jrt.NN(jrt.Method_Cast(m__4)).GetParameterTypes__Class1().Ref(); if linked_498 == nil { arg_495 = ifn_499.Invoke_O_O__O(arg_500, arg_501) } else { arg_495 = linked_498.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_497, arg_500, arg_501) }; var arg_496 any; var root_502 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var linked_503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_502, aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A_fn_class); var ifn_504 lang.IFn
														if linked_503 == nil { ifn_504 = lang.IFn_Cast(root_502) } else { ifn_504 = nil }; var arg_505 any = jrt.NN(jrt.Method_Cast(m__4)).GetReturnType__Class().Ref(); if linked_503 == nil { arg_496 = ifn_504.Invoke_O__O(arg_505) } else { arg_496 = linked_503.(*aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A).Invoke_O_O__O(root_502, arg_505) }
//line :169:1
	if linked_493 == nil { desc__5 = ifn_494.Invoke_O_O__O(arg_495, arg_496) } else { desc__5 = linked_493.(*aot_arbace_classes_types.A_arbace_classes_types_method_desc_A).Invoke_O_O_O__O(root_492, arg_495, arg_496) }
//line :168:1
	var root_506 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_506, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_508 lang.IFn; if linked_507 == nil { ifn_508 = lang.IFn_Cast(root_506) } else { ifn_508 = nil }; var arg_509 any; var tmp6 any = A_arbace_classes_env_A_const_42; var tmp7 any = jrt.NN(jrt.Method_Cast(m__4)).GetName__String().Ref(); var tmp8 any = A_arbace_classes_env_A_const_60; var tmp9 any = A_arbace_classes_env_A_const_43; var tmp10 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Method_Cast(m__4)).GetModifiers__I()).Ref(); var tmp11 any = A_arbace_classes_env_A_const_63; var tmp12 any = t.F_n; var tmp13 any = A_arbace_classes_env_A_const_80; var tmp14 any; var root_511 any = A_arbace_classes_env_A_const_47.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_511, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_513 lang.IFn





	if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any = A_arbace_classes_env_A_const_35.GetRawRoot__O(); var arg_515 any = jrt.NN(jrt.Method_Cast(m__4)).GetExceptionTypes__Class1().Ref(); if linked_512 == nil { tmp14 = ifn_513.Invoke_O_O__O(arg_514, arg_515) } else { tmp14 = linked_512.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_511, arg_514, arg_515) }
//line :168:1
	var tmp15 any = tmp14; var tmp16 any = A_arbace_classes_env_A_const_81; var tmp17 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_New_O_O_O(m__4, desc__5, t.F_manns); var tmp18 *jrt.Class
	var fncls__525 /*line :168:1*/*jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_fn_class






	if fncls__525 == nil { var fncls__525d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_fn_class = fncls__525d; tmp18 = fncls__525d } else { tmp18 = fncls__525 }
//line :168:1
	var tmp19 any = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil)); var tmp20 any = A_arbace_classes_env_A_const_83; var tmp21 any; var root_526 any = A_arbace_classes_env_A_const_84.GetRawRoot__O(); var linked_527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_526, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_528 lang.IFn







	if linked_527 == nil { ifn_528 = lang.IFn_Cast(root_526) } else { ifn_528 = nil }; var arg_529 any; var tmp22 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_New_O_O_O(m__4, desc__5, t.F_manns); var tmp23 *jrt.Class; var fncls__541 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_fn_class
	if fncls__541 == nil { var fncls__541d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_fn_class = fncls__541d; tmp23 = fncls__541d } else { tmp23 = fncls__541 }; arg_529 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil)
//line :176:1
	var arg_530 any = jrt.NN(jrt.Method_Cast(m__4)).GetParameterTypes__Class1().Ref(); if linked_527 == nil { tmp21 = ifn_528.Invoke_O_O__O(arg_529, arg_530) } else { tmp21 = linked_527.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_526, arg_529, arg_530) }
//line :168:1
	arg_509 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7, tmp8, desc__5, tmp9, tmp10, tmp11, tmp12, tmp13, tmp15, tmp16, tmp19, tmp20, tmp21)); var arg_510 any; var tmp24 lang.IFn = lang.IFn_Cast(t.F_iter__28000055); var tmp25 any; var root_542 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_542, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_544 lang.IFn; if linked_543 == nil { ifn_544 = lang.IFn_Cast(root_542) } else { ifn_544 = nil }; var arg_545 any = s__28000056__3; if linked_543 == nil { tmp25 = ifn_544.Invoke_O__O(arg_545) } else { tmp25 = linked_543.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_542, arg_545) }; arg_510 = tmp24.Invoke_O__O(tmp25); if linked_507 == nil { return ifn_508.Invoke_O_O__O(arg_509, arg_510) } else { return linked_507.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_506, arg_509, arg_510) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :168:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :168:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A) Ctor_O_O_O_I_O(c__n, c__b__28000058, c__manns any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__28000058 = c__b__28000058; t.F_manns = c__manns; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :168:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A) Invoke_O__O(self any) any { { var i__28000057__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__28000057__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__28000057__1)); var desc__3 any; var root_415 any = A_arbace_classes_env_A_const_78.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_415, aot_arbace_classes_types.A_arbace_classes_types_method_desc_A_fn_class); var ifn_417 lang.IFn
																if linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; var arg_418 any; var root_420 any = A_arbace_classes_env_A_const_79.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_420, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_422 lang.IFn; if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var arg_424 any = jrt.NN(jrt.Method_Cast(m__2)).GetParameterTypes__Class1().Ref(); if linked_421 == nil { arg_418 = ifn_422.Invoke_O_O__O(arg_423, arg_424) } else { arg_418 = linked_421.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_420, arg_423, arg_424) }; var arg_419 any; var root_425 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_425, aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A_fn_class); var ifn_427 lang.IFn
																if linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any = jrt.NN(jrt.Method_Cast(m__2)).GetReturnType__Class().Ref(); if linked_426 == nil { arg_419 = ifn_427.Invoke_O__O(arg_428) } else { arg_419 = linked_426.(*aot_arbace_classes_types.A_arbace_classes_types_class__GT_desc_A).Invoke_O_O__O(root_425, arg_428) }
//line :169:1
	if linked_416 == nil { desc__3 = ifn_417.Invoke_O_O__O(arg_418, arg_419) } else { desc__3 = linked_416.(*aot_arbace_classes_types.A_arbace_classes_types_method_desc_A).Invoke_O_O_O__O(root_415, arg_418, arg_419) }
//line :168:1
	var root_429 any = A_arbace_classes_env_A_const_62.GetRawRoot__O(); var linked_430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_429, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_431 lang.IFn; if linked_430 == nil { ifn_431 = lang.IFn_Cast(root_429) } else { ifn_431 = nil }; var arg_432 any = t.F_b__28000058; var arg_433 any; var tmp2 any = A_arbace_classes_env_A_const_42; var tmp3 any = jrt.NN(jrt.Method_Cast(m__2)).GetName__String().Ref(); var tmp4 any = A_arbace_classes_env_A_const_60; var tmp5 any = A_arbace_classes_env_A_const_43; var tmp6 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Method_Cast(m__2)).GetModifiers__I()).Ref(); var tmp7 any = A_arbace_classes_env_A_const_63; var tmp8 any = t.F_n; var tmp9 any = A_arbace_classes_env_A_const_80; var tmp10 any; var root_434 any = A_arbace_classes_env_A_const_47.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_434, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_436 lang.IFn





	if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = A_arbace_classes_env_A_const_35.GetRawRoot__O(); var arg_438 any = jrt.NN(jrt.Method_Cast(m__2)).GetExceptionTypes__Class1().Ref(); if linked_435 == nil { tmp10 = ifn_436.Invoke_O_O__O(arg_437, arg_438) } else { tmp10 = linked_435.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_434, arg_437, arg_438) }
//line :168:1
	var tmp11 any = tmp10; var tmp12 any = A_arbace_classes_env_A_const_81; var tmp13 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_New_O_O_O(m__2, desc__3, t.F_manns); var tmp14 *jrt.Class
	var fncls__448 /*line :168:1*/*jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_fn_class






	if fncls__448 == nil { var fncls__448d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_fn_class = fncls__448d; tmp14 = fncls__448d } else { tmp14 = fncls__448 }
//line :168:1
	var tmp15 any = lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil)); var tmp16 any = A_arbace_classes_env_A_const_83; var tmp17 any; var root_449 any = A_arbace_classes_env_A_const_84.GetRawRoot__O(); var linked_450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_449, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_451 lang.IFn







	if linked_450 == nil { ifn_451 = lang.IFn_Cast(root_449) } else { ifn_451 = nil }; var arg_452 any; var tmp18 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_New_O_O_O(m__2, desc__3, t.F_manns); var tmp19 *jrt.Class; var fncls__464 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_fn_class
	if fncls__464 == nil { var fncls__464d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_fn_class = fncls__464d; tmp19 = fncls__464d } else { tmp19 = fncls__464 }; arg_452 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil)
//line :176:1
	var arg_453 any = jrt.NN(jrt.Method_Cast(m__2)).GetParameterTypes__Class1().Ref(); if linked_450 == nil { tmp17 = ifn_451.Invoke_O_O__O(arg_452, arg_453) } else { tmp17 = linked_450.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_449, arg_452, arg_453) }
//line :168:1
	arg_433 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, desc__3, tmp5, tmp6, tmp7, tmp8, tmp9, tmp11, tmp12, tmp15, tmp16, tmp17)); if linked_430 == nil { ifn_431.Invoke_O_O__O(arg_432, arg_433) } else { linked_430.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_429, arg_432, arg_433) }; i__28000057__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000057__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :175:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A) Ctor_O_O_O(c__m, c__desc, c__manns any) { t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :175:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A) Invoke_O__O(self any) any { var root_439 any = A_arbace_classes_env_A_const_82.GetRawRoot__O(); var linked_440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_439, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_441 lang.IFn; if linked_440 == nil { ifn_441 = lang.IFn_Cast(root_439) } else { ifn_441 = nil }; var arg_442 any; var root_444 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_444, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_446 lang.IFn; if linked_445 == nil { ifn_446 = lang.IFn_Cast(root_444) } else { ifn_446 = nil }; var arg_447 any; var t_ any = t.F_manns; t.F_manns = nil; arg_447 = t_; if linked_445 == nil { arg_442 = ifn_446.Invoke_O__O(arg_447) } else { arg_442 = linked_445.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_444, arg_447) }; var arg_443 any; var tmp1 any; var t__2 any = t.F_m; t.F_m = nil; tmp1 = t__2; var tmp2 any = jrt.NN(jrt.Method_Cast(tmp1)).GetName__String().Ref(); var tmp3 any; var t__3 any = t.F_desc; t.F_desc = nil; tmp3 = t__3; arg_443 = lang.Tuple_Create_O_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3), A_arbace_classes_env_A_const_81); if linked_440 == nil { return ifn_441.Invoke_O_O__O(arg_442, arg_443) } else { return linked_440.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_439, arg_442, arg_443) } }
//line :175:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :175:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A) Ctor_O_O_O(c__m, c__desc, c__manns any) { t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :175:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A) Invoke_O__O(self any) any { var root_516 any = A_arbace_classes_env_A_const_82.GetRawRoot__O(); var linked_517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_516, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_518 lang.IFn; if linked_517 == nil { ifn_518 = lang.IFn_Cast(root_516) } else { ifn_518 = nil }; var arg_519 any; var root_521 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_521, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_523 lang.IFn; if linked_522 == nil { ifn_523 = lang.IFn_Cast(root_521) } else { ifn_523 = nil }; var arg_524 any; var t_ any = t.F_manns; t.F_manns = nil; arg_524 = t_; if linked_522 == nil { arg_519 = ifn_523.Invoke_O__O(arg_524) } else { arg_519 = linked_522.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_521, arg_524) }; var arg_520 any; var tmp1 any; var t__2 any = t.F_m; t.F_m = nil; tmp1 = t__2; var tmp2 any = jrt.NN(jrt.Method_Cast(tmp1)).GetName__String().Ref(); var tmp3 any; var t__3 any = t.F_desc; t.F_desc = nil; tmp3 = t__3; arg_520 = lang.Tuple_Create_O_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3), A_arbace_classes_env_A_const_81); if linked_517 == nil { return ifn_518.Invoke_O_O__O(arg_519, arg_520) } else { return linked_517.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_516, arg_519, arg_520) } }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :177:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A) Ctor_O_O_O(c__m, c__desc, c__manns any) { t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :177:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A) Invoke_O_O_O__O(self, i__1, ___2 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_New_O_O_O_O(i__1, t.F_m, t.F_desc, t.F_manns); var tmp2 *jrt.Class; var fncls__463 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_fn_class; if fncls__463 == nil { var fncls__463d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_fn_class = fncls__463d; tmp2 = fncls__463d } else { tmp2 = fncls__463 }; return lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :177:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :177:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A) Ctor_O_O_O_O(c__i, c__m, c__desc, c__manns any) { t.F_i = c__i; t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :177:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A) Invoke_O__O(self any) any { var root_454 any = A_arbace_classes_env_A_const_82.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_456 lang.IFn; if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any; var root_459 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_459, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_461 lang.IFn; if linked_460 == nil { ifn_461 = lang.IFn_Cast(root_459) } else { ifn_461 = nil }; var arg_462 any; var t_ any = t.F_manns; t.F_manns = nil; arg_462 = t_; if linked_460 == nil { arg_457 = ifn_461.Invoke_O__O(arg_462) } else { arg_457 = linked_460.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_459, arg_462) }; var arg_458 any; var tmp1 any; var t__2 any = t.F_m; t.F_m = nil; tmp1 = t__2; var tmp2 any = jrt.NN(jrt.Method_Cast(tmp1)).GetName__String().Ref(); var tmp3 any; var t__3 any = t.F_desc; t.F_desc = nil; tmp3 = t__3; var tmp4 any = lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3); var tmp5 any = A_arbace_classes_env_A_const_83; var tmp6 any; var t__4 any = t.F_i; t.F_i = nil; tmp6 = t__4; arg_458 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp4, tmp5, tmp6); if linked_455 == nil { return ifn_456.Invoke_O_O__O(arg_457, arg_458) } else { return linked_455.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_454, arg_457, arg_458) } }
//line :177:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :177:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A) Ctor_O_O_O(c__m, c__desc, c__manns any) { t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :177:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A) Invoke_O_O_O__O(self, i__1, ___2 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_New_O_O_O_O(i__1, t.F_m, t.F_desc, t.F_manns); var tmp2 *jrt.Class; var fncls__540 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_fn_class; if fncls__540 == nil { var fncls__540d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_fn_class = fncls__540d; tmp2 = fncls__540d } else { tmp2 = fncls__540 }; return lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :177:1
func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :177:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A) Ctor_O_O_O_O(c__i, c__m, c__desc, c__manns any) { t.F_i = c__i; t.F_m = c__m; t.F_desc = c__desc; t.F_manns = c__manns }
//line :177:1
func (t *A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A) Invoke_O__O(self any) any { var root_531 any = A_arbace_classes_env_A_const_82.GetRawRoot__O(); var linked_532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_531, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_533 lang.IFn; if linked_532 == nil { ifn_533 = lang.IFn_Cast(root_531) } else { ifn_533 = nil }; var arg_534 any; var root_536 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_536, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_538 lang.IFn; if linked_537 == nil { ifn_538 = lang.IFn_Cast(root_536) } else { ifn_538 = nil }; var arg_539 any; var t_ any = t.F_manns; t.F_manns = nil; arg_539 = t_; if linked_537 == nil { arg_534 = ifn_538.Invoke_O__O(arg_539) } else { arg_534 = linked_537.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_536, arg_539) }; var arg_535 any; var tmp1 any; var t__2 any = t.F_m; t.F_m = nil; tmp1 = t__2; var tmp2 any = jrt.NN(jrt.Method_Cast(tmp1)).GetName__String().Ref(); var tmp3 any; var t__3 any = t.F_desc; t.F_desc = nil; tmp3 = t__3; var tmp4 any = lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3); var tmp5 any = A_arbace_classes_env_A_const_83; var tmp6 any; var t__4 any = t.F_i; t.F_i = nil; tmp6 = t__4; arg_535 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp4, tmp5, tmp6); if linked_532 == nil { return ifn_533.Invoke_O_O__O(arg_534, arg_535) } else { return linked_532.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_531, arg_534, arg_535) } }

func A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_New_O_O(p0, p1 any) *A_arbace_classes_env_reflect_info_iter__28000077__28000081_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000077__28000081_A{}; t.Ctor_O_O(p0, p1); return t }
//line :179:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_A) Ctor_O_O(c__c, c__n any) { t.F_c = c__c; t.F_n = c__n }
//line :179:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_A) Invoke_O_O__O(self, s__28000078__1 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_New_O_O_O_O(t.F_c, t.F_n, s__28000078__1, self); var tmp2 *jrt.Class; var fncls__659 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_fn_class; if fncls__659 == nil { var fncls__659d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_fn_class = fncls__659d; tmp2 = fncls__659d } else { tmp2 = fncls__659 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :179:1
func A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :179:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A) Ctor_O_O_O_O(c__c, c__n, c__s__28000078, c__iter__28000077 any) { t.F_c = c__c; t.F_n = c__n; t.F_s__28000078 = c__s__28000078; t.F_iter__28000077 = c__iter__28000077 }
//line :179:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A) Invoke_O__O(self any) any { { var s__28000078__1 any; var t_ any = t.F_s__28000078; t.F_s__28000078 = nil; s__28000078__1 = t_; for { var temp__1927000414__auto____2 any; var root_548 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_548, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_550 lang.IFn; if linked_549 == nil { ifn_550 = lang.IFn_Cast(root_548) } else { ifn_550 = nil }; var arg_551 any = s__28000078__1; if linked_549 == nil { temp__1927000414__auto____2 = ifn_550.Invoke_O__O(arg_551) } else { temp__1927000414__auto____2 = linked_549.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_548, arg_551) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__28000078__3 any = temp__1927000414__auto____2; var tmp1 any; var root_552 any = A_arbace_classes_env_A_const_54.GetRawRoot__O(); var linked_553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_552, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_554 lang.IFn; if linked_553 == nil { ifn_554 = lang.IFn_Cast(root_552) } else { ifn_554 = nil }; var arg_555 any = s__28000078__3; if linked_553 == nil { tmp1 = ifn_554.Invoke_O__O(arg_555) } else { tmp1 = linked_553.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_552, arg_555) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_556 any = A_arbace_classes_env_A_const_55.GetRawRoot__O(); var linked_557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_556, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_558 lang.IFn; if linked_557 == nil { ifn_558 = lang.IFn_Cast(root_556) } else { ifn_558 = nil }; var arg_559 any = s__28000078__3; if linked_557 == nil { c__1927001037__auto____4 = ifn_558.Invoke_O__O(arg_559) } else { c__1927001037__auto____4 = linked_557.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_556, arg_559) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__28000080__6 any; var root_560 any = A_arbace_classes_env_A_const_56.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_560, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_562 lang.IFn; if linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_561 == nil { b__28000080__6 = ifn_562.Invoke_O__O(arg_563) } else { b__28000080__6 = linked_561.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_560, arg_563) }; var tmp2 any = A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_New_O_O_O_I_O(t.F_c, t.F_n, b__28000080__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__596 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_fn_class; if fncls__596 == nil { var fncls__596d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_fn_class = fncls__596d; tmp3 = fncls__596d } else { tmp3 = fncls__596 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_597 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_597, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_599 lang.IFn; if linked_598 == nil { ifn_599 = lang.IFn_Cast(root_597) } else { ifn_599 = nil }; var arg_600 any; var root_602 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_604 lang.IFn; if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = b__28000080__6; if linked_603 == nil { arg_600 = ifn_604.Invoke_O__O(arg_605) } else { arg_600 = linked_603.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_602, arg_605) }; var arg_601 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__28000077); var tmp5 any; var root_606 any = A_arbace_classes_env_A_const_70.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = s__28000078__3; if linked_607 == nil { tmp5 = ifn_608.Invoke_O__O(arg_609) } else { tmp5 = linked_607.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_606, arg_609) }; arg_601 = tmp4.Invoke_O__O(tmp5); if linked_598 == nil { return ifn_599.Invoke_O_O__O(arg_600, arg_601) } else { return linked_598.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_597, arg_600, arg_601) } } else { var root_610 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_612 lang.IFn; if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any; var root_615 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_615, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_617 lang.IFn; if linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any = b__28000080__6; if linked_616 == nil { arg_613 = ifn_617.Invoke_O__O(arg_618) } else { arg_613 = linked_616.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_615, arg_618) }; var arg_614 any; if linked_611 == nil { return ifn_612.Invoke_O_O__O(arg_613, arg_614) } else { return linked_611.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_610, arg_613, arg_614) } } } else { var m__4 any; var root_619 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_619, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_621 lang.IFn; if linked_620 == nil { ifn_621 = lang.IFn_Cast(root_619) } else { ifn_621 = nil }; var arg_622 any = s__28000078__3; if linked_620 == nil { m__4 = ifn_621.Invoke_O__O(arg_622) } else { m__4 = linked_620.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_619, arg_622) }; var root_623 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_623, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_625 lang.IFn; if linked_624 == nil { ifn_625 = lang.IFn_Cast(root_623) } else { ifn_625 = nil }; var arg_626 any; var tmp6 any = A_arbace_classes_env_A_const_42; var tmp7 any = A_arbace_classes_env_A_const_60; var tmp8 any; var root_628 any = A_arbace_classes_env_A_const_78.GetRawRoot__O(); var linked_629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_628, aot_arbace_classes_types.A_arbace_classes_types_method_desc_A_fn_class); var ifn_630 lang.IFn

	if linked_629 == nil { ifn_630 = lang.IFn_Cast(root_628) } else { ifn_630 = nil }; var arg_631 any; var root_633 any = A_arbace_classes_env_A_const_79.GetRawRoot__O(); var linked_634 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_633, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_635 lang.IFn; if linked_634 == nil { ifn_635 = lang.IFn_Cast(root_633) } else { ifn_635 = nil }; var arg_636 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var arg_637 any; var G__28000086__5_ any; var root_638 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_638, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_640 lang.IFn; if linked_639 == nil { ifn_640 = lang.IFn_Cast(root_638) } else { ifn_640 = nil }; var arg_641 any = jrt.NN(jrt.Constructor_Cast(m__4)).GetParameterTypes__Class1().Ref(); if linked_639 == nil { G__28000086__5_ = ifn_640.Invoke_O__O(arg_641) } else { G__28000086__5_ = linked_639.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_638, arg_641) }; var tmp9 any; var root_642 any = A_arbace_classes_env_A_const_75.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, A_arbace_classes_env_inner_member_QMARK__A_fn_class); var ifn_644 lang.IFn
	if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = t.F_c; if linked_643 == nil { tmp9 = ifn_644.Invoke_O__O(arg_645) } else { tmp9 = linked_643.(*A_arbace_classes_env_inner_member_QMARK__A).Invoke_O_O__O(root_642, arg_645) }
//line :181:1
	if jrt.J2g_Truth(tmp9) { var root_646 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_646, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_648 lang.IFn; if linked_647 == nil { ifn_648 = lang.IFn_Cast(root_646) } else { ifn_648 = nil }; var arg_649 any = G__28000086__5_; if linked_647 == nil { arg_637 = ifn_648.Invoke_O__O(arg_649) } else { arg_637 = linked_647.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_646, arg_649) } } else { arg_637 = G__28000086__5_ }; if linked_634 == nil { arg_631 = ifn_635.Invoke_O_O__O(arg_636, arg_637) } else { arg_631 = linked_634.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_633, arg_636, arg_637) }; var arg_632 any = Lit_52; if linked_629 == nil { tmp8 = ifn_630.Invoke_O_O__O(arg_631, arg_632) } else { tmp8 = linked_629.(*aot_arbace_classes_types.A_arbace_classes_types_method_desc_A).Invoke_O_O_O__O(root_628, arg_631, arg_632) }
//line :179:1
	var tmp10 any = tmp8; var tmp11 any = A_arbace_classes_env_A_const_43; var tmp12 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Constructor_Cast(m__4)).GetModifiers__I()).Ref(); var tmp13 any = A_arbace_classes_env_A_const_63; var tmp14 any = t.F_n; var tmp15 any = A_arbace_classes_env_A_const_80; var tmp16 any; var root_650 any = A_arbace_classes_env_A_const_47.GetRawRoot__O(); var linked_651 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_650, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_652 lang.IFn





	if linked_651 == nil { ifn_652 = lang.IFn_Cast(root_650) } else { ifn_652 = nil }; var arg_653 any = A_arbace_classes_env_A_const_35.GetRawRoot__O(); var arg_654 any = jrt.NN(jrt.Constructor_Cast(m__4)).GetExceptionTypes__Class1().Ref(); if linked_651 == nil { tmp16 = ifn_652.Invoke_O_O__O(arg_653, arg_654) } else { tmp16 = linked_651.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_650, arg_653, arg_654) }
//line :179:1
	arg_626 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, Lit_13, tmp7, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16)); var arg_627 any; var tmp17 lang.IFn = lang.IFn_Cast(t.F_iter__28000077); var tmp18 any; var root_655 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_655, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_657 lang.IFn; if linked_656 == nil { ifn_657 = lang.IFn_Cast(root_655) } else { ifn_657 = nil }; var arg_658 any = s__28000078__3; if linked_656 == nil { tmp18 = ifn_657.Invoke_O__O(arg_658) } else { tmp18 = linked_656.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_655, arg_658) }; arg_627 = tmp17.Invoke_O__O(tmp18); if linked_624 == nil { return ifn_625.Invoke_O_O__O(arg_626, arg_627) } else { return linked_624.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_623, arg_626, arg_627) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :179:1
func A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :179:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A) Ctor_O_O_O_I_O(c__c, c__n, c__b__28000080 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_c = c__c; t.F_n = c__n; t.F_b__28000080 = c__b__28000080; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :179:1
func (t *A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A) Invoke_O__O(self any) any { { var i__28000079__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__28000079__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__28000079__1)); var root_564 any = A_arbace_classes_env_A_const_62.GetRawRoot__O(); var linked_565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_564, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_566 lang.IFn; if linked_565 == nil { ifn_566 = lang.IFn_Cast(root_564) } else { ifn_566 = nil }; var arg_567 any = t.F_b__28000080; var arg_568 any; var tmp2 any = A_arbace_classes_env_A_const_42; var tmp3 any = A_arbace_classes_env_A_const_60; var tmp4 any; var root_569 any = A_arbace_classes_env_A_const_78.GetRawRoot__O(); var linked_570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_569, aot_arbace_classes_types.A_arbace_classes_types_method_desc_A_fn_class); var ifn_571 lang.IFn

	if linked_570 == nil { ifn_571 = lang.IFn_Cast(root_569) } else { ifn_571 = nil }; var arg_572 any; var root_574 any = A_arbace_classes_env_A_const_79.GetRawRoot__O(); var linked_575 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_574, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_576 lang.IFn; if linked_575 == nil { ifn_576 = lang.IFn_Cast(root_574) } else { ifn_576 = nil }; var arg_577 any = A_arbace_classes_env_A_const_73.GetRawRoot__O(); var arg_578 any; var G__28000084__3_ any; var root_579 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_579, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_581 lang.IFn; if linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any = jrt.NN(jrt.Constructor_Cast(m__2)).GetParameterTypes__Class1().Ref(); if linked_580 == nil { G__28000084__3_ = ifn_581.Invoke_O__O(arg_582) } else { G__28000084__3_ = linked_580.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_579, arg_582) }; var tmp5 any; var root_583 any = A_arbace_classes_env_A_const_75.GetRawRoot__O(); var linked_584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_583, A_arbace_classes_env_inner_member_QMARK__A_fn_class); var ifn_585 lang.IFn
	if linked_584 == nil { ifn_585 = lang.IFn_Cast(root_583) } else { ifn_585 = nil }; var arg_586 any = t.F_c; if linked_584 == nil { tmp5 = ifn_585.Invoke_O__O(arg_586) } else { tmp5 = linked_584.(*A_arbace_classes_env_inner_member_QMARK__A).Invoke_O_O__O(root_583, arg_586) }
//line :181:1
	if jrt.J2g_Truth(tmp5) { var root_587 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_587, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_589 lang.IFn; if linked_588 == nil { ifn_589 = lang.IFn_Cast(root_587) } else { ifn_589 = nil }; var arg_590 any = G__28000084__3_; if linked_588 == nil { arg_578 = ifn_589.Invoke_O__O(arg_590) } else { arg_578 = linked_588.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_587, arg_590) } } else { arg_578 = G__28000084__3_ }; if linked_575 == nil { arg_572 = ifn_576.Invoke_O_O__O(arg_577, arg_578) } else { arg_572 = linked_575.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_574, arg_577, arg_578) }; var arg_573 any = Lit_52; if linked_570 == nil { tmp4 = ifn_571.Invoke_O_O__O(arg_572, arg_573) } else { tmp4 = linked_570.(*aot_arbace_classes_types.A_arbace_classes_types_method_desc_A).Invoke_O_O_O__O(root_569, arg_572, arg_573) }
//line :179:1
	var tmp6 any = tmp4; var tmp7 any = A_arbace_classes_env_A_const_43; var tmp8 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Constructor_Cast(m__2)).GetModifiers__I()).Ref(); var tmp9 any = A_arbace_classes_env_A_const_63; var tmp10 any = t.F_n; var tmp11 any = A_arbace_classes_env_A_const_80; var tmp12 any; var root_591 any = A_arbace_classes_env_A_const_47.GetRawRoot__O(); var linked_592 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_591, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_593 lang.IFn





	if linked_592 == nil { ifn_593 = lang.IFn_Cast(root_591) } else { ifn_593 = nil }; var arg_594 any = A_arbace_classes_env_A_const_35.GetRawRoot__O(); var arg_595 any = jrt.NN(jrt.Constructor_Cast(m__2)).GetExceptionTypes__Class1().Ref(); if linked_592 == nil { tmp12 = ifn_593.Invoke_O_O__O(arg_594, arg_595) } else { tmp12 = linked_592.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_591, arg_594, arg_595) }
//line :179:1
	arg_568 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, Lit_13, tmp3, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12)); if linked_565 == nil { ifn_566.Invoke_O_O__O(arg_567, arg_568) } else { linked_565.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_564, arg_567, arg_568) }; i__28000079__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000079__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }










func A_arbace_classes_env_reflect_info_fn__28000089_A_New() *A_arbace_classes_env_reflect_info_fn__28000089_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_fn__28000089_A{}; t.Ctor(); return t }
//line :190:1
func (t *A_arbace_classes_env_reflect_info_fn__28000089_A) Ctor() {}
//line :190:1
func (t *A_arbace_classes_env_reflect_info_fn__28000089_A) Invoke_O_O__O(self, p1__28000026_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_13, A_arbace_classes_env_A_const_42.Invoke_O__O(p1__28000026_SHARP___1))).Ref() }
func A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_New_O(p0 any) *A_arbace_classes_env_reflect_info_iter__28000091__28000095_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000091__28000095_A{}; t.Ctor_O(p0); return t }
//line :191:1
func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :191:1
func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_A) Invoke_O_O__O(self, s__28000092__1 any) any { var tmp1 any = A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_New_O_O_O(t.F_n, s__28000092__1, self); var tmp2 *jrt.Class; var fncls__739 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_fn_class; if fncls__739 == nil { var fncls__739d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_fn_class = fncls__739d; tmp2 = fncls__739d } else { tmp2 = fncls__739 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :191:1
func A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_New_O_O_O(p0, p1, p2 any) *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :191:1
func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A) Ctor_O_O_O(c__n, c__s__28000092, c__iter__28000091 any) { t.F_n = c__n; t.F_s__28000092 = c__s__28000092; t.F_iter__28000091 = c__iter__28000091 }
//line :191:1
func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A) Invoke_O__O(self any) any { { var s__28000092__1 any; var t_ any = t.F_s__28000092; t.F_s__28000092 = nil; s__28000092__1 = t_; for { var temp__1927000414__auto____2 any; var root_682 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_682, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_684 lang.IFn; if linked_683 == nil { ifn_684 = lang.IFn_Cast(root_682) } else { ifn_684 = nil }; var arg_685 any = s__28000092__1; if linked_683 == nil { temp__1927000414__auto____2 = ifn_684.Invoke_O__O(arg_685) } else { temp__1927000414__auto____2 = linked_683.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_682, arg_685) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__28000092__3 any = temp__1927000414__auto____2; var tmp1 any; var root_686 any = A_arbace_classes_env_A_const_54.GetRawRoot__O(); var linked_687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_686, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_688 lang.IFn; if linked_687 == nil { ifn_688 = lang.IFn_Cast(root_686) } else { ifn_688 = nil }; var arg_689 any = s__28000092__3; if linked_687 == nil { tmp1 = ifn_688.Invoke_O__O(arg_689) } else { tmp1 = linked_687.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_686, arg_689) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_690 any = A_arbace_classes_env_A_const_55.GetRawRoot__O(); var linked_691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_690, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_692 lang.IFn; if linked_691 == nil { ifn_692 = lang.IFn_Cast(root_690) } else { ifn_692 = nil }; var arg_693 any = s__28000092__3; if linked_691 == nil { c__1927001037__auto____4 = ifn_692.Invoke_O__O(arg_693) } else { c__1927001037__auto____4 = linked_691.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_690, arg_693) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__28000094__6 any; var root_694 any = A_arbace_classes_env_A_const_56.GetRawRoot__O(); var linked_695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_694, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_696 lang.IFn; if linked_695 == nil { ifn_696 = lang.IFn_Cast(root_694) } else { ifn_696 = nil }; var arg_697 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_695 == nil { b__28000094__6 = ifn_696.Invoke_O__O(arg_697) } else { b__28000094__6 = linked_695.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_694, arg_697) }; var tmp2 any = A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_New_O_I_O_O(t.F_n, size__1927001038__auto____5, b__28000094__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__703 *jrt.Class = A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_fn_class; if fncls__703 == nil { var fncls__703d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_fn_class = fncls__703d; tmp3 = fncls__703d } else { tmp3 = fncls__703 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_704 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_705 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_704, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_706 lang.IFn; if linked_705 == nil { ifn_706 = lang.IFn_Cast(root_704) } else { ifn_706 = nil }; var arg_707 any; var root_709 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_709, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_711 lang.IFn; if linked_710 == nil { ifn_711 = lang.IFn_Cast(root_709) } else { ifn_711 = nil }; var arg_712 any = b__28000094__6; if linked_710 == nil { arg_707 = ifn_711.Invoke_O__O(arg_712) } else { arg_707 = linked_710.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_709, arg_712) }; var arg_708 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__28000091); var tmp5 any; var root_713 any = A_arbace_classes_env_A_const_70.GetRawRoot__O(); var linked_714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_713, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_715 lang.IFn; if linked_714 == nil { ifn_715 = lang.IFn_Cast(root_713) } else { ifn_715 = nil }; var arg_716 any = s__28000092__3; if linked_714 == nil { tmp5 = ifn_715.Invoke_O__O(arg_716) } else { tmp5 = linked_714.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_713, arg_716) }; arg_708 = tmp4.Invoke_O__O(tmp5); if linked_705 == nil { return ifn_706.Invoke_O_O__O(arg_707, arg_708) } else { return linked_705.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_704, arg_707, arg_708) } } else { var root_717 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_717, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_719 lang.IFn; if linked_718 == nil { ifn_719 = lang.IFn_Cast(root_717) } else { ifn_719 = nil }; var arg_720 any; var root_722 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_723 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_722, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_724 lang.IFn; if linked_723 == nil { ifn_724 = lang.IFn_Cast(root_722) } else { ifn_724 = nil }; var arg_725 any = b__28000094__6; if linked_723 == nil { arg_720 = ifn_724.Invoke_O__O(arg_725) } else { arg_720 = linked_723.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_722, arg_725) }; var arg_721 any; if linked_718 == nil { return ifn_719.Invoke_O_O__O(arg_720, arg_721) } else { return linked_718.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_717, arg_720, arg_721) } } } else { var vec__28000102__4 any; var root_726 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_726, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_728 lang.IFn; if linked_727 == nil { ifn_728 = lang.IFn_Cast(root_726) } else { ifn_728 = nil }; var arg_729 any = s__28000092__3; if linked_727 == nil { vec__28000102__4 = ifn_728.Invoke_O__O(arg_729) } else { vec__28000102__4 = linked_727.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_726, arg_729) }; var d__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__28000102__4, lang.RT_IntCast_J__I_NoInit(0), nil); var f__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__28000102__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_730 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_730, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_732 lang.IFn; if linked_731 == nil { ifn_732 = lang.IFn_Cast(root_730) } else { ifn_732 = nil }; var arg_733 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_env_A_const_42, Lit_13, A_arbace_classes_env_A_const_60, d__5, A_arbace_classes_env_A_const_43, f__6, A_arbace_classes_env_A_const_63, t.F_n, A_arbace_classes_env_A_const_80, lang.PersistentVector_EMPTY.Ref())); var arg_734 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__28000091); var tmp7 any; var root_735 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_735, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_737 lang.IFn; if linked_736 == nil { ifn_737 = lang.IFn_Cast(root_735) } else { ifn_737 = nil }; var arg_738 any = s__28000092__3; if linked_736 == nil { tmp7 = ifn_737.Invoke_O__O(arg_738) } else { tmp7 = linked_736.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_735, arg_738) }; arg_734 = tmp6.Invoke_O__O(tmp7); if linked_731 == nil { return ifn_732.Invoke_O_O__O(arg_733, arg_734) } else { return linked_731.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_730, arg_733, arg_734) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :191:1
func A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :191:1
func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A) Ctor_O_I_O_O(c__n any, c__size__1927001038__auto__ int32, c__b__28000094, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__28000094 = c__b__28000094; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :191:1
func (t *A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A) Invoke_O__O(self any) any { { var i__28000093__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__28000093__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__28000098__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__28000093__1)); var d__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__28000098__2, lang.RT_IntCast_J__I_NoInit(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__28000098__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_698 any = A_arbace_classes_env_A_const_62.GetRawRoot__O(); var linked_699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_698, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_700 lang.IFn; if linked_699 == nil { ifn_700 = lang.IFn_Cast(root_698) } else { ifn_700 = nil }; var arg_701 any = t.F_b__28000094; var arg_702 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_env_A_const_42, Lit_13, A_arbace_classes_env_A_const_60, d__3, A_arbace_classes_env_A_const_43, f__4, A_arbace_classes_env_A_const_63, t.F_n, A_arbace_classes_env_A_const_80, lang.PersistentVector_EMPTY.Ref())); if linked_699 == nil { ifn_700.Invoke_O_O__O(arg_701, arg_702) } else { linked_699.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_698, arg_701, arg_702) }; i__28000093__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000093__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_classes_env_info_A_New() *A_arbace_classes_env_info_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_info_A{}; t.Ctor(); return t }
//line :200:1
func (t *A_arbace_classes_env_info_A) Ctor() {}
//line :200:1
func (t *A_arbace_classes_env_info_A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any = n__0; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_745 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_745, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_747 lang.IFn; if linked_746 == nil { ifn_747 = lang.IFn_Cast(root_745) } else { ifn_747 = nil }; var arg_748 any; var root_749 any = A_arbace_classes_env_A_const_20.GetRawRoot__O(); var linked_750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_749, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_751 lang.IFn; if linked_750 == nil { ifn_751 = lang.IFn_Cast(root_749) } else { ifn_751 = nil }; var arg_752 any = n__0; var arg_753 any = Lit_11; if linked_750 == nil { arg_748 = ifn_751.Invoke_O_O__O(arg_752, arg_753) } else { arg_748 = linked_750.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_749, arg_752, arg_753) }; if linked_746 == nil { tmp1 = ifn_747.Invoke_O__O(arg_748) } else { tmp1 = linked_746.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_745, arg_748) } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var or__1927000174__auto____2 any; var G__28000108__2_ any = A_arbace_classes_env_A_const_89.Get__O(); var G__28000108__3_ any
		if lang.Util_Identical_O_O__Z_NoInit(G__28000108__2_, nil) { G__28000108__3_ = nil } else { var root_754 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_754, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_756 lang.IFn; if linked_755 == nil { ifn_756 = lang.IFn_Cast(root_754) } else { ifn_756 = nil }; var arg_757 any = G__28000108__2_; if linked_755 == nil { G__28000108__3_ = ifn_756.Invoke_O__O(arg_757) } else { G__28000108__3_ = linked_755.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_754, arg_757) } }; if lang.Util_Identical_O_O__Z_NoInit(G__28000108__3_, nil) { or__1927000174__auto____2 = nil } else { or__1927000174__auto____2 = lang.RT_Get_O_O__O_NoInit(G__28000108__3_, n__0) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else {
			if jrt.J2g_Truth(A_arbace_classes_env_A_const_19.Get__O()) {
				var tmp2 any; var root_758 any = A_arbace_classes_env_A_const_18.GetRawRoot__O(); var linked_759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_758, A_arbace_classes_env_from_source_QMARK__A_fn_class); var ifn_760 lang.IFn; if linked_759 == nil { ifn_760 = lang.IFn_Cast(root_758) } else { ifn_760 = nil }; var arg_761 any = n__0; if linked_759 == nil { tmp2 = ifn_760.Invoke_O__O(arg_761) } else { tmp2 = linked_759.(*A_arbace_classes_env_from_source_QMARK__A).Invoke_O_O__O(root_758, arg_761) }; if jrt.J2g_Truth(tmp2) { return nil } else { var tmp3 *lang.Keyword = A_arbace_classes_env_A_const_90; return tmp3.Invoke_O__O(lang.RT_Get_O_O__O_NoInit(A_arbace_classes_env_A_const_19.Get__O(), n__0)) } } else {
//line :205:1
					var temp__1927000414__auto____3 any; var root_762 any = A_arbace_classes_env_A_const_26.GetRawRoot__O(); var linked_763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_762, A_arbace_classes_env_load_class_A_fn_class); var ifn_764 lang.IFn

					if linked_763 == nil { ifn_764 = lang.IFn_Cast(root_762) } else { ifn_764 = nil }; var arg_765 any = n__0; if linked_763 == nil { temp__1927000414__auto____3 = ifn_764.Invoke_O__O(arg_765) } else { temp__1927000414__auto____3 = linked_763.(*A_arbace_classes_env_load_class_A).Invoke_O_O__O(root_762, arg_765) }; if jrt.J2g_Truth(temp__1927000414__auto____3) { var c__4 any = temp__1927000414__auto____3; var d__5 any; var tmp4 any; var root_766 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_766, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_768 lang.IFn
						if linked_767 == nil { ifn_768 = lang.IFn_Cast(root_766) } else { ifn_768 = nil }; var arg_769 any = A_arbace_classes_env_A_const_91.GetRawRoot__O(); if linked_767 == nil { tmp4 = ifn_768.Invoke_O__O(arg_769) } else { tmp4 = linked_767.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_766, arg_769) }; d__5 = lang.RT_Get_O_O__O_NoInit(tmp4, n__0)
						var tmp5 any; var and__1927000168__auto____6 any = d__5; if jrt.J2g_Truth(and__1927000168__auto____6) { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(A_arbace_classes_env_A_const_32.Invoke_O__O(d__5), c__4)).Ref() } else { tmp5 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp5) { return d__5 } else { var root_770 any = A_arbace_classes_env_A_const_92.GetRawRoot__O(); var linked_771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_770, A_arbace_classes_env_reflect_info_A_fn_class); var ifn_772 lang.IFn; if linked_771 == nil { ifn_772 = lang.IFn_Cast(root_770) } else { ifn_772 = nil }; var arg_773 any = c__4; if linked_771 == nil { return ifn_772.Invoke_O__O(arg_773) } else { return linked_771.(*A_arbace_classes_env_reflect_info_A).Invoke_O_O__O(root_770, arg_773) } } } else {
//line :207:1
							return nil } } } } else {
//line :203:1
								return nil
							}
}





func A_arbace_classes_env_info_BANG__A_New() *A_arbace_classes_env_info_BANG__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_info_BANG__A{}; t.Ctor(); return t }
//line :211:1
func (t *A_arbace_classes_env_info_BANG__A) Ctor() {}
//line :211:1
func (t *A_arbace_classes_env_info_BANG__A) Invoke_O_O__O(self, n__0 any) any { var or__1927000174__auto____2 any; var root_774 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_774, A_arbace_classes_env_info_A_fn_class); var ifn_776 lang.IFn; if
										linked_775 == nil { ifn_776 = lang.IFn_Cast(root_774) } else { ifn_776 = nil }; var arg_777 any = n__0; if linked_775 == nil { or__1927000174__auto____2 = ifn_776.Invoke_O__O(arg_777) } else { or__1927000174__auto____2 = linked_775.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_774, arg_777) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var tmp1 any; var root_778 any = A_arbace_classes_env_A_const_29.GetRawRoot__O(); var linked_779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_778, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_780 lang.IFn; if linked_779 == nil { ifn_780 = lang.IFn_Cast(root_778) } else { ifn_780 = nil }; var arg_781 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_20, nil); var tmp3 any; var root_783 any = A_arbace_classes_env_A_const_12.GetRawRoot__O(); var linked_784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_783, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_785 lang.IFn; if linked_784 == nil { ifn_785 = lang.IFn_Cast(root_783) } else { ifn_785 = nil }; var arg_786 any; var root_789 any = A_arbace_classes_env_A_const_31.GetRawRoot__O(); var linked_790 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_789, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_791 lang.IFn; if linked_790 == nil { ifn_791 = lang.IFn_Cast(root_789) } else { ifn_791 = nil }; var arg_792 any = n__0; if linked_790 == nil { arg_786 = ifn_791.Invoke_O__O(arg_792) } else { arg_786 = linked_790.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_789, arg_792) }; var arg_787 any = Lit_21; var arg_788 any = Lit_22; if linked_784 == nil { tmp3 = ifn_785.Invoke_O_O_O__O(arg_786, arg_787, arg_788) } else { tmp3 = linked_784.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_783, arg_786, arg_787, arg_788) }; arg_781 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref(); var arg_782 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_classes_env_A_const_32, n__0)); if linked_779 == nil { tmp1 = ifn_780.Invoke_O_O__O(arg_781, arg_782) } else { tmp1 = linked_779.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_778, arg_781, arg_782) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) } }

func A_arbace_classes_env_interface_QMARK__A_New() *A_arbace_classes_env_interface_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_interface_QMARK__A{}; t.Ctor(); return t }
//line :214:1
func (t *A_arbace_classes_env_interface_QMARK__A) Ctor() {}
//line :214:1
func (t *A_arbace_classes_env_interface_QMARK__A) Invoke_O_O__O(self, n__0 any) any { var i__2 any; var root_793 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_793, A_arbace_classes_env_info_A_fn_class); var ifn_795 lang.IFn; if
											linked_794 == nil { ifn_795 = lang.IFn_Cast(root_793) } else { ifn_795 = nil }; var arg_796 any = n__0; if linked_794 == nil { i__2 = ifn_795.Invoke_O__O(arg_796) } else { i__2 = linked_794.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_793, arg_796) }; var tmp1 any; var or__1927000174__auto____3 any = A_arbace_classes_env_A_const_44.Invoke_O__O(i__2); if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var G__28000111__4_ any = A_arbace_classes_env_A_const_43.Invoke_O__O(i__2); var G__28000111__5_ any; if lang.Util_Identical_O_O__Z_NoInit(G__28000111__4_, nil) { G__28000111__5_ = nil } else { var tmp2 int64; var na_797 any = G__28000111__4_; var na_798 int64 = 512; if jrt.Long_InstanceOf(na_797) { var n0_799 int64 = jrt.NN(jrt.Long_Cast(na_797)).LongValue__J(); var n1_800 int64 = na_798; tmp2 = n0_799 & n1_800 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_797, na_798) }; G__28000111__5_ = jrt.Long_ValueOf_J__Long_NoInit(tmp2).Ref() }; if lang.Util_Identical_O_O__Z_NoInit(G__28000111__5_, nil) { tmp1 = nil } else { var tmp3 bool; var na_802 any = G__28000111__5_; if jrt.Long_InstanceOf(na_802) { var n0_803 int64 = jrt.NN(jrt.Long_Cast(na_802)).LongValue__J(); tmp3 = n0_803 > 0 } else { if jrt.Double_InstanceOf(na_802) { var n0_803_2 float64 = jrt.NN(jrt.Double_Cast(na_802)).DoubleValue__D(); tmp3 = n0_803_2 > 0.0 } else { tmp3 = lang.Numbers_IsPos_O__Z_NoInit(na_802) } }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp3).Ref() } }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() }

func A_arbace_classes_env_const_value_A_New() *A_arbace_classes_env_const_value_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_const_value_A{}; t.Ctor(); return t }
//line :217:1
func (t *A_arbace_classes_env_const_value_A) Ctor() {}
//line :217:1
func (t *A_arbace_classes_env_const_value_A) Invoke_O_O__O(self, field__0 any) any { var c__2 any = A_arbace_classes_env_A_const_64.Invoke_O__O(field__0); var tmp1 any; var root_804 any = A_arbace_classes_env_A_const_94.GetRawRoot__O(); var linked_805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_804, aot_arbace_core.A_arbace_core_delay_QMARK__A_fn_class); var ifn_806 lang.IFn; if
											linked_805 == nil { ifn_806 = lang.IFn_Cast(root_804) } else { ifn_806 = nil }; var arg_807 any = c__2; if linked_805 == nil { tmp1 = ifn_806.Invoke_O__O(arg_807) } else { tmp1 = linked_805.(*aot_arbace_core.A_arbace_core_delay_QMARK__A).Invoke_O_O__O(root_804, arg_807) }; if jrt.J2g_Truth(tmp1) { var root_808 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_809 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_808, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_810 lang.IFn; if linked_809 == nil { ifn_810 = lang.IFn_Cast(root_808) } else { ifn_810 = nil }; var arg_811 any = c__2; if linked_809 == nil { return ifn_810.Invoke_O__O(arg_811) } else { return linked_809.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_808, arg_811) } } else { return c__2 } }

func A_arbace_classes_env_supertypes_A_New() *A_arbace_classes_env_supertypes_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_supertypes_A{}; t.Ctor(); return t }
//line :220:1
func (t *A_arbace_classes_env_supertypes_A) Ctor() {}
//line :220:1
func (t *A_arbace_classes_env_supertypes_A) Invoke_O_O__O(self, n__0 any) any { var i__2 any; var root_812 any = A_arbace_classes_env_A_const_95.GetRawRoot__O(); var linked_813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_812, A_arbace_classes_env_info_BANG__A_fn_class); var ifn_814 lang.IFn; if


	linked_813 == nil { ifn_814 = lang.IFn_Cast(root_812) } else { ifn_814 = nil }; var arg_815 any = n__0; if linked_813 == nil { i__2 = ifn_814.Invoke_O__O(arg_815) } else { i__2 = linked_813.(*A_arbace_classes_env_info_BANG__A).Invoke_O_O__O(root_812, arg_815) }; var G__28000114__3_ any; var root_816 any = /*line :220:1*/A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_816, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_818 lang.IFn; if


	linked_817 == nil { ifn_818 = lang.IFn_Cast(root_816) } else { ifn_818 = nil }; var arg_819 any = A_arbace_classes_env_A_const_46.Invoke_O__O(i__2); if linked_817 == nil { G__28000114__3_ = ifn_818.Invoke_O__O(arg_819) } else { G__28000114__3_ = linked_817.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_816, arg_819) }; if jrt.J2g_Truth(A_arbace_classes_env_A_const_45.Invoke_O__O(i__2)) { var root_820 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_820, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_822 lang.IFn; if linked_821 == nil { ifn_822 = lang.IFn_Cast(root_820) } else { ifn_822 = nil }; var arg_823 any; var root_824 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_825 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_824, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_826 lang.IFn; if linked_825 == nil { ifn_826 = lang.IFn_Cast(root_824) } else { ifn_826 = nil }; var arg_827 any = A_arbace_classes_env_A_const_45.Invoke_O__O(i__2); var arg_828 any = G__28000114__3_; if linked_825 == nil { arg_823 = ifn_826.Invoke_O_O__O(arg_827, arg_828) } else { arg_823 = linked_825.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_824, arg_827, arg_828) }; if linked_821 == nil { return ifn_822.Invoke_O__O(arg_823) } else { return linked_821.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_820, arg_823) } } else { return G__28000114__3_ } }

func A_arbace_classes_env_subclass_QMARK__A_New() *A_arbace_classes_env_subclass_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_subclass_QMARK__A{}; t.Ctor(); return t }
//line :225:1
func (t *A_arbace_classes_env_subclass_QMARK__A) Ctor() {}
//line :225:1
func (t *A_arbace_classes_env_subclass_QMARK__A) Invoke_O_O_O__O(self, a__0, b__1 any) any { var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(a__0, b__1); if or__1927000174__auto____3 {


	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var or__1927000174__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(b__1, Lit_4); if or__1927000174__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____4).Ref() } else {
		var tmp1 any; var root_829 any = A_arbace_classes_env_A_const_96.GetRawRoot__O(); var linked_830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_829, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_831 lang.IFn; if linked_830 == nil { ifn_831 = lang.IFn_Cast(root_829) } else { ifn_831 = nil }; var arg_832 any; var tmp2 any = A_arbace_classes_env_subclass_QMARK__fn__28000117_A_New_O(b__1); var tmp3 *jrt.Class; var fncls__839 *jrt.Class = A_arbace_classes_env_subclass_QMARK__fn__28000117_A_fn_class; if fncls__839 == nil { var fncls__839d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); A_arbace_classes_env_subclass_QMARK__fn__28000117_A_fn_class = fncls__839d; tmp3 = fncls__839d } else { tmp3 = fncls__839 }; arg_832 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_833 any; var temp__1927000414__auto____5 any; var root_840 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_840, A_arbace_classes_env_info_A_fn_class); var ifn_842 lang.IFn; if linked_841 == nil { ifn_842 = lang.IFn_Cast(root_840) } else { ifn_842 = nil }; var arg_843 any = a__0; if linked_841 == nil { temp__1927000414__auto____5 = ifn_842.Invoke_O__O(arg_843) } else { temp__1927000414__auto____5 = linked_841.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_840, arg_843) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var i__6 any = temp__1927000414__auto____5; var G__28000119__7_ any; var root_844 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_844, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_846 lang.IFn
			if linked_845 == nil { ifn_846 = lang.IFn_Cast(root_844) } else { ifn_846 = nil }; var arg_847 any = A_arbace_classes_env_A_const_46.Invoke_O__O(i__6); if linked_845 == nil { G__28000119__7_ = ifn_846.Invoke_O__O(arg_847) } else { G__28000119__7_ = linked_845.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_844, arg_847) }; if jrt.J2g_Truth(A_arbace_classes_env_A_const_45.Invoke_O__O(i__6)) { var root_848 any = A_arbace_classes_env_A_const_10.GetRawRoot__O(); var linked_849 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_848, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_850 lang.IFn; if linked_849 == nil { ifn_850 = lang.IFn_Cast(root_848) } else { ifn_850 = nil }; var arg_851 any = G__28000119__7_; var arg_852 any = A_arbace_classes_env_A_const_45.Invoke_O__O(i__6); if linked_849 == nil { arg_833 = ifn_850.Invoke_O_O__O(arg_851, arg_852) } else { arg_833 = linked_849.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_848, arg_851, arg_852) } } else { arg_833 = G__28000119__7_ } } else {
//line :229:1
				arg_833 = nil }; if linked_830 == nil { tmp1 = ifn_831.Invoke_O_O__O(arg_832, arg_833) } else { tmp1 = linked_830.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_829, arg_832, arg_833) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() } } }
//line :229:1
func A_arbace_classes_env_subclass_QMARK__fn__28000117_A_New_O(p0 any) *A_arbace_classes_env_subclass_QMARK__fn__28000117_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_subclass_QMARK__fn__28000117_A{}; t.Ctor_O(p0); return t }
//line :229:1
func (t *A_arbace_classes_env_subclass_QMARK__fn__28000117_A) Ctor_O(c__b any) { t.F_b = c__b }
//line :229:1
func (t *A_arbace_classes_env_subclass_QMARK__fn__28000117_A) Invoke_O_O__O(self, p1__28000116_SHARP___1 any) any { var root_834 any = A_arbace_classes_env_A_const_97.GetRawRoot__O(); var linked_835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_834, A_arbace_classes_env_subclass_QMARK__A_fn_class); var ifn_836 lang.IFn; if linked_835 == nil { ifn_836 = lang.IFn_Cast(root_834) } else { ifn_836 = nil }; var arg_837 any = p1__28000116_SHARP___1; var arg_838 any = t.F_b; if linked_835 == nil { return ifn_836.Invoke_O_O__O(arg_837, arg_838) } else { return linked_835.(*A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(root_834, arg_837, arg_838) } }


func A_arbace_classes_env_assignable_QMARK__A_New() *A_arbace_classes_env_assignable_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_assignable_QMARK__A{}; t.Ctor(); return t }
//line :232:1
func (t *A_arbace_classes_env_assignable_QMARK__A) Ctor() {}
//line :232:1
func (t *A_arbace_classes_env_assignable_QMARK__A) Invoke_O_O_O__O(self, from__0, to__1 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(from__0, to__1) { return jrt.Boolean_TRUE.Ref() } else { if lang.Util_Equiv_O_O__Z_NoInit(from__0, A_arbace_classes_env_A_const_98) {

		var root_853 any = A_arbace_classes_env_A_const_99.GetRawRoot__O(); var linked_854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_853, aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A_fn_class); var ifn_855 lang.IFn; if linked_854 == nil { ifn_855 = lang.IFn_Cast(root_853) } else { ifn_855 = nil }; var arg_856 any = to__1; if linked_854 == nil { return ifn_855.Invoke_O__O(arg_856) } else { return linked_854.(*aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A).Invoke_O_O__O(root_853, arg_856) } } else {
//line :235:1
			var tmp1 any; var root_857 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_857, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_859 lang.IFn


			if linked_858 == nil { ifn_859 = lang.IFn_Cast(root_857) } else { ifn_859 = nil }; var arg_860 any; var and__1927000168__auto____3 any; var root_861 any = A_arbace_classes_env_A_const_99.GetRawRoot__O(); var linked_862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_861, aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A_fn_class); var ifn_863 lang.IFn; if linked_862 == nil { ifn_863 = lang.IFn_Cast(root_861) } else { ifn_863 = nil }; var arg_864 any = from__0; if linked_862 == nil { and__1927000168__auto____3 = ifn_863.Invoke_O__O(arg_864) } else { and__1927000168__auto____3 = linked_862.(*aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A).Invoke_O_O__O(root_861, arg_864) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_865 any = A_arbace_classes_env_A_const_99.GetRawRoot__O(); var linked_866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_865, aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A_fn_class); var ifn_867 lang.IFn; if linked_866 == nil { ifn_867 = lang.IFn_Cast(root_865) } else { ifn_867 = nil }; var arg_868 any = to__1; if linked_866 == nil { arg_860 = ifn_867.Invoke_O__O(arg_868) } else { arg_860 = linked_866.(*aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A).Invoke_O_O__O(root_865, arg_868) } } else { arg_860 = and__1927000168__auto____3 }; if linked_858 == nil { tmp1 = ifn_859.Invoke_O__O(arg_860) } else { tmp1 = linked_858.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_857, arg_860) }
//line :235:1
			if jrt.J2g_Truth(tmp1) { return jrt.Boolean_FALSE.Ref() } else { if lang.Util_Equiv_O_O__Z_NoInit(to__1, A_arbace_classes_env_A_const_100.GetRawRoot__O()) { return jrt.Boolean_TRUE.Ref() } else { var tmp2 any; var root_869 any = A_arbace_classes_env_A_const_101.GetRawRoot__O(); var linked_870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_869, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_871 lang.IFn




				if linked_870 == nil { ifn_871 = lang.IFn_Cast(root_869) } else { ifn_871 = nil }; var arg_872 any = from__0; if linked_870 == nil { tmp2 = ifn_871.Invoke_O__O(arg_872) } else { tmp2 = linked_870.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_869, arg_872) }
//line :235:1
				if jrt.J2g_Truth(tmp2) {





					var tmp3 any; var root_873 any = A_arbace_classes_env_A_const_101.GetRawRoot__O(); var linked_874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_873, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_875 lang.IFn; if linked_874 == nil { ifn_875 = lang.IFn_Cast(root_873) } else { ifn_875 = nil }; var arg_876 any = to__1; if linked_874 == nil { tmp3 = ifn_875.Invoke_O__O(arg_876) } else { tmp3 = linked_874.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_873, arg_876) }; if jrt.J2g_Truth(tmp3) { var fe__3 any; var root_877 any = A_arbace_classes_env_A_const_102.GetRawRoot__O(); var linked_878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_877, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_879 lang.IFn; if linked_878 == nil { ifn_879 = lang.IFn_Cast(root_877) } else { ifn_879 = nil }; var arg_880 any = from__0; if linked_878 == nil { fe__3 = ifn_879.Invoke_O__O(arg_880) } else { fe__3 = linked_878.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_877, arg_880) }; var te__4 any; var root_881 any = A_arbace_classes_env_A_const_102.GetRawRoot__O(); var linked_882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_881, aot_arbace_classes_types.A_arbace_classes_types_elem_type_A_fn_class); var ifn_883 lang.IFn; if linked_882 == nil { ifn_883 = lang.IFn_Cast(root_881) } else { ifn_883 = nil }; var arg_884 any = to__1; if linked_882 == nil { te__4 = ifn_883.Invoke_O__O(arg_884) } else { te__4 = linked_882.(*aot_arbace_classes_types.A_arbace_classes_types_elem_type_A).Invoke_O_O__O(root_881, arg_884) }; var and__1927000168__auto____5 any; var root_885 any = A_arbace_classes_env_A_const_99.GetRawRoot__O(); var linked_886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_885, aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A_fn_class); var ifn_887 lang.IFn
						if linked_886 == nil { ifn_887 = lang.IFn_Cast(root_885) } else { ifn_887 = nil }; var arg_888 any = fe__3; if linked_886 == nil { and__1927000168__auto____5 = ifn_887.Invoke_O__O(arg_888) } else { and__1927000168__auto____5 = linked_886.(*aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A).Invoke_O_O__O(root_885, arg_888) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_889 any = A_arbace_classes_env_A_const_99.GetRawRoot__O(); var linked_890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_889, aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A_fn_class); var ifn_891 lang.IFn; if linked_890 == nil { ifn_891 = lang.IFn_Cast(root_889) } else { ifn_891 = nil }; var arg_892 any = te__4; if linked_890 == nil { and__1927000168__auto____6 = ifn_891.Invoke_O__O(arg_892) } else { and__1927000168__auto____6 = linked_890.(*aot_arbace_classes_types.A_arbace_classes_types_ref_QMARK__A).Invoke_O_O__O(root_889, arg_892) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_893 any = A_arbace_classes_env_A_const_103.GetRawRoot__O(); var linked_894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_893, A_arbace_classes_env_assignable_QMARK__A_fn_class); var ifn_895 lang.IFn; if linked_894 == nil { ifn_895 = lang.IFn_Cast(root_893) } else { ifn_895 = nil }; var arg_896 any = fe__3; var arg_897 any = te__4; if linked_894 == nil { return ifn_895.Invoke_O_O__O(arg_896, arg_897) } else { return linked_894.(*A_arbace_classes_env_assignable_QMARK__A).Invoke_O_O_O__O(root_893, arg_896, arg_897) } } else { return and__1927000168__auto____6 } } else { return and__1927000168__auto____5 } } else {
//line :241:1
							if A_arbace_classes_env_A_const_104 != nil {

								var root_898 any = A_arbace_classes_env_A_const_23.GetRawRoot__O(); var linked_899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_898, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_900 lang.IFn; if linked_899 == nil { ifn_900 = lang.IFn_Cast(root_898) } else { ifn_900 = nil }; var arg_901 any = A_arbace_classes_env_A_const_105; var arg_902 any = to__1; if linked_899 == nil { return ifn_900.Invoke_O_O__O(arg_901, arg_902) } else { return linked_899.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_898, arg_901, arg_902) } } else {
//line :241:1
									return nil } } } else {
//line :235:1
										var tmp4 any; var root_903 any = A_arbace_classes_env_A_const_101.GetRawRoot__O(); var linked_904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_903, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_905 lang.IFn








										if linked_904 == nil { ifn_905 = lang.IFn_Cast(root_903) } else { ifn_905 = nil }; var arg_906 any = to__1; if linked_904 == nil { tmp4 = ifn_905.Invoke_O__O(arg_906) } else { tmp4 = linked_904.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_903, arg_906) }
//line :235:1
										if jrt.J2g_Truth(tmp4) { return jrt.Boolean_FALSE.Ref() } else { if A_arbace_classes_env_A_const_104 != nil {









											var root_907 any = A_arbace_classes_env_A_const_97.GetRawRoot__O(); var linked_908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_907, A_arbace_classes_env_subclass_QMARK__A_fn_class); var ifn_909 lang.IFn; if linked_908 == nil { ifn_909 = lang.IFn_Cast(root_907) } else { ifn_909 = nil }; var arg_910 any; var root_912 any = A_arbace_classes_env_A_const_106.GetRawRoot__O(); var linked_913 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_912, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_914 lang.IFn; if linked_913 == nil { ifn_914 = lang.IFn_Cast(root_912) } else { ifn_914 = nil }; var arg_915 any = from__0; if linked_913 == nil { arg_910 = ifn_914.Invoke_O__O(arg_915) } else { arg_910 = linked_913.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_912, arg_915) }; var arg_911 any; var root_916 any = A_arbace_classes_env_A_const_106.GetRawRoot__O(); var linked_917 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_916, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_918 lang.IFn; if linked_917 == nil { ifn_918 = lang.IFn_Cast(root_916) } else { ifn_918 = nil }; var arg_919 any = to__1; if linked_917 == nil { arg_911 = ifn_918.Invoke_O__O(arg_919) } else { arg_911 = linked_917.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_916, arg_919) }; if linked_908 == nil { return ifn_909.Invoke_O_O__O(arg_910, arg_911) } else { return linked_908.(*A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(root_907, arg_910, arg_911) } } else {
//line :235:1
												return nil
											}
										}
									}
			}
			}
		}
	}
}



func A_arbace_classes_env_superclass_chain_A_New() *A_arbace_classes_env_superclass_chain_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_superclass_chain_A{}; t.Ctor(); return t }
//line :247:1
func (t *A_arbace_classes_env_superclass_chain_A) Ctor() {}
//line :247:1
func (t *A_arbace_classes_env_superclass_chain_A) Invoke_O_O__O(self, n__0 any) any {
	var root_920 any = A_arbace_classes_env_A_const_107.GetRawRoot__O(); var linked_921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_920, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_922 lang.IFn; if linked_921 == nil { ifn_922 = lang.IFn_Cast(root_920) } else { ifn_922 = nil }; var arg_923 any = A_arbace_classes_env_A_const_25.GetRawRoot__O(); var arg_924 any; var root_925 any = A_arbace_classes_env_A_const_108.GetRawRoot__O(); var linked_926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_925, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_927 lang.IFn; if linked_926 == nil { ifn_927 = lang.IFn_Cast(root_925) } else { ifn_927 = nil }; var arg_928 any; var tmp1 any = A_arbace_classes_env_superclass_chain_fn__28000123_A_New(); var tmp2 *jrt.Class; var fncls__934 *jrt.Class = A_arbace_classes_env_superclass_chain_fn__28000123_A_fn_class; if fncls__934 == nil { var fncls__934d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_classes_env_superclass_chain_fn__28000123_A_fn_class = fncls__934d; tmp2 = fncls__934d } else { tmp2 = fncls__934 }; arg_928 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_929 any = n__0; if linked_926 == nil { arg_924 = ifn_927.Invoke_O_O__O(arg_928, arg_929) } else { arg_924 = linked_926.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_925, arg_928, arg_929) }; if linked_921 == nil { return ifn_922.Invoke_O_O__O(arg_923, arg_924) } else { return linked_921.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_920, arg_923, arg_924) } }
//line :248:1
func A_arbace_classes_env_superclass_chain_fn__28000123_A_New() *A_arbace_classes_env_superclass_chain_fn__28000123_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_superclass_chain_fn__28000123_A{}; t.Ctor(); return t }
//line :248:1
func (t *A_arbace_classes_env_superclass_chain_fn__28000123_A) Ctor() {}
//line :248:1
func (t *A_arbace_classes_env_superclass_chain_fn__28000123_A) Invoke_O_O__O(self, p1__28000122_SHARP___1 any) any { var G__28000124__2_ any = p1__28000122_SHARP___1; var G__28000124__3_ any; if lang.Util_Identical_O_O__Z_NoInit(G__28000124__2_, nil) { G__28000124__3_ = nil } else { var root_930 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_930, A_arbace_classes_env_info_A_fn_class); var ifn_932 lang.IFn; if linked_931 == nil { ifn_932 = lang.IFn_Cast(root_930) } else { ifn_932 = nil }; var arg_933 any = G__28000124__2_; if linked_931 == nil { G__28000124__3_ = ifn_932.Invoke_O__O(arg_933) } else { G__28000124__3_ = linked_931.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_930, arg_933) } }; if lang.Util_Identical_O_O__Z_NoInit(G__28000124__3_, nil) { return nil } else { return A_arbace_classes_env_A_const_45.Invoke_O__O(G__28000124__3_) } }

func A_arbace_classes_env_common_super_A_New() *A_arbace_classes_env_common_super_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_common_super_A{}; t.Ctor(); return t }
//line :250:1
func (t *A_arbace_classes_env_common_super_A) Ctor() {}
//line :250:1
func (t *A_arbace_classes_env_common_super_A) Invoke_O_O_O__O(self, a__0, b__1 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(a__0, b__1) { return a__0 } else { var tmp1 any; var or__1927000174__auto____3 any; var root_935 any = A_arbace_classes_env_A_const_20.GetRawRoot__O(); var linked_936 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_935, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_937 lang.IFn

		if linked_936 == nil { ifn_937 = lang.IFn_Cast(root_935) } else { ifn_937 = nil }; var arg_938 any = a__0; var arg_939 any = Lit_11; if linked_936 == nil { or__1927000174__auto____3 = ifn_937.Invoke_O_O__O(arg_938, arg_939) } else { or__1927000174__auto____3 = linked_936.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_935, arg_938, arg_939) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var root_940 any = A_arbace_classes_env_A_const_20.GetRawRoot__O(); var linked_941 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_940, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_942 lang.IFn; if linked_941 == nil { ifn_942 = lang.IFn_Cast(root_940) } else { ifn_942 = nil }; var arg_943 any = b__1; var arg_944 any = Lit_11; if linked_941 == nil { tmp1 = ifn_942.Invoke_O_O__O(arg_943, arg_944) } else { tmp1 = linked_941.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_940, arg_943, arg_944) } }
//line :253:1
		if jrt.J2g_Truth(tmp1) { return Lit_4 } else { var tmp2 any; var root_945 any = A_arbace_classes_env_A_const_97.GetRawRoot__O(); var linked_946 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_945, A_arbace_classes_env_subclass_QMARK__A_fn_class); var ifn_947 lang.IFn


			if linked_946 == nil { ifn_947 = lang.IFn_Cast(root_945) } else { ifn_947 = nil }; var arg_948 any = a__0; var arg_949 any = b__1; if linked_946 == nil { tmp2 = ifn_947.Invoke_O_O__O(arg_948, arg_949) } else { tmp2 = linked_946.(*A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(root_945, arg_948, arg_949) }
//line :253:1
			if jrt.J2g_Truth(tmp2) {


				var tmp3 any; var root_950 any = A_arbace_classes_env_A_const_109.GetRawRoot__O(); var linked_951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_950, A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_952 lang.IFn; if linked_951 == nil { ifn_952 = lang.IFn_Cast(root_950) } else { ifn_952 = nil }; var arg_953 any = b__1; if linked_951 == nil { tmp3 = ifn_952.Invoke_O__O(arg_953) } else { tmp3 = linked_951.(*A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_950, arg_953) }; if jrt.J2g_Truth(tmp3) { return Lit_4 } else { return b__1 } } else {
//line :253:1
					var tmp4 any; var root_954 any = A_arbace_classes_env_A_const_97.GetRawRoot__O(); var linked_955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_954, A_arbace_classes_env_subclass_QMARK__A_fn_class); var ifn_956 lang.IFn



					if linked_955 == nil { ifn_956 = lang.IFn_Cast(root_954) } else { ifn_956 = nil }; var arg_957 any = b__1; var arg_958 any = a__0; if linked_955 == nil { tmp4 = ifn_956.Invoke_O_O__O(arg_957, arg_958) } else { tmp4 = linked_955.(*A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(root_954, arg_957, arg_958) }
//line :253:1
					if jrt.J2g_Truth(tmp4) {



						var tmp5 any; var root_959 any = A_arbace_classes_env_A_const_109.GetRawRoot__O(); var linked_960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_959, A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_961 lang.IFn; if linked_960 == nil { ifn_961 = lang.IFn_Cast(root_959) } else { ifn_961 = nil }; var arg_962 any = a__0; if linked_960 == nil { tmp5 = ifn_961.Invoke_O__O(arg_962) } else { tmp5 = linked_960.(*A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_959, arg_962) }; if jrt.J2g_Truth(tmp5) { return Lit_4 } else { return a__0 } } else {
//line :253:1
							var tmp6 any; var or__1927000174__auto____3_2 any; var root_963 any = A_arbace_classes_env_A_const_109.GetRawRoot__O(); var linked_964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_963, A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_965 lang.IFn




							if linked_964 == nil { ifn_965 = lang.IFn_Cast(root_963) } else { ifn_965 = nil }; var arg_966 any = a__0; if linked_964 == nil { or__1927000174__auto____3_2 = ifn_965.Invoke_O__O(arg_966) } else { or__1927000174__auto____3_2 = linked_964.(*A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_963, arg_966) }; if jrt.J2g_Truth(or__1927000174__auto____3_2) { tmp6 = or__1927000174__auto____3_2 } else { var root_967 any = A_arbace_classes_env_A_const_109.GetRawRoot__O(); var linked_968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_967, A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_969 lang.IFn; if linked_968 == nil { ifn_969 = lang.IFn_Cast(root_967) } else { ifn_969 = nil }; var arg_970 any = b__1; if linked_968 == nil { tmp6 = ifn_969.Invoke_O__O(arg_970) } else { tmp6 = linked_968.(*A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_967, arg_970) } }
//line :253:1
							if jrt.J2g_Truth(tmp6) { return Lit_4 } else { if A_arbace_classes_env_A_const_104 != nil { var bs__3 any; var root_971 any = A_arbace_classes_env_A_const_110.GetRawRoot__O(); var linked_972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_971, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_973 lang.IFn





								if linked_972 == nil { ifn_973 = lang.IFn_Cast(root_971) } else { ifn_973 = nil }; var arg_974 any; var root_975 any = A_arbace_classes_env_A_const_111.GetRawRoot__O(); var linked_976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_975, A_arbace_classes_env_superclass_chain_A_fn_class); var ifn_977 lang.IFn; if linked_976 == nil { ifn_977 = lang.IFn_Cast(root_975) } else { ifn_977 = nil }; var arg_978 any = b__1; if linked_976 == nil { arg_974 = ifn_977.Invoke_O__O(arg_978) } else { arg_974 = linked_976.(*A_arbace_classes_env_superclass_chain_A).Invoke_O_O__O(root_975, arg_978) }; if linked_972 == nil { bs__3 = ifn_973.Invoke_O__O(arg_974) } else { bs__3 = linked_972.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_971, arg_974) }
//line :253:1
								var or__1927000174__auto____4 any; var root_979 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_979, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_981 lang.IFn






								if linked_980 == nil { ifn_981 = lang.IFn_Cast(root_979) } else { ifn_981 = nil }; var arg_982 any; var root_983 any = A_arbace_classes_env_A_const_86.GetRawRoot__O(); var linked_984 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_983, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_985 lang.IFn; if linked_984 == nil { ifn_985 = lang.IFn_Cast(root_983) } else { ifn_985 = nil }; var arg_986 any = bs__3; var arg_987 any; var root_988 any = A_arbace_classes_env_A_const_111.GetRawRoot__O(); var linked_989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_988, A_arbace_classes_env_superclass_chain_A_fn_class); var ifn_990 lang.IFn; if linked_989 == nil { ifn_990 = lang.IFn_Cast(root_988) } else { ifn_990 = nil }; var arg_991 any = a__0; if linked_989 == nil { arg_987 = ifn_990.Invoke_O__O(arg_991) } else { arg_987 = linked_989.(*A_arbace_classes_env_superclass_chain_A).Invoke_O_O__O(root_988, arg_991) }; if linked_984 == nil { arg_982 = ifn_985.Invoke_O_O__O(arg_986, arg_987) } else { arg_982 = linked_984.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_983, arg_986, arg_987) }; if linked_980 == nil { or__1927000174__auto____4 = ifn_981.Invoke_O__O(arg_982) } else { or__1927000174__auto____4 = linked_980.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_979, arg_982) }; if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { return Lit_4 } } else {
//line :253:1
									return nil
								}
							}
						}
				}
		}
	}
}

func A_arbace_classes_env_lub_A_New() *A_arbace_classes_env_lub_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_lub_A{}; t.Ctor(); return t }
//line :262:1
func (t *A_arbace_classes_env_lub_A) Ctor() {}
//line :262:1
func (t *A_arbace_classes_env_lub_A) Invoke_O_O_O__O(self, a__0, b__1 any) any {



	if lang.Util_Equiv_O_O__Z_NoInit(a__0, b__1) { return a__0 } else { if lang.Util_Equiv_O_O__Z_NoInit(a__0, A_arbace_classes_env_A_const_98) { return b__1 } else { if lang.Util_Equiv_O_O__Z_NoInit(b__1, A_arbace_classes_env_A_const_98) { return a__0 } else { var tmp1 any; var root_992 any = A_arbace_classes_env_A_const_103.GetRawRoot__O(); var linked_993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_992, A_arbace_classes_env_assignable_QMARK__A_fn_class); var ifn_994 lang.IFn


		if linked_993 == nil { ifn_994 = lang.IFn_Cast(root_992) } else { ifn_994 = nil }; var arg_995 any = a__0; var arg_996 any = b__1; if linked_993 == nil { tmp1 = ifn_994.Invoke_O_O__O(arg_995, arg_996) } else { tmp1 = linked_993.(*A_arbace_classes_env_assignable_QMARK__A).Invoke_O_O_O__O(root_992, arg_995, arg_996) }
//line :266:1
		if jrt.J2g_Truth(tmp1) { return b__1 } else { var tmp2 any; var root_997 any = A_arbace_classes_env_A_const_103.GetRawRoot__O(); var linked_998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_997, A_arbace_classes_env_assignable_QMARK__A_fn_class); var ifn_999 lang.IFn



			if linked_998 == nil { ifn_999 = lang.IFn_Cast(root_997) } else { ifn_999 = nil }; var arg_1000 any = b__1; var arg_1001 any = a__0; if linked_998 == nil { tmp2 = ifn_999.Invoke_O_O__O(arg_1000, arg_1001) } else { tmp2 = linked_998.(*A_arbace_classes_env_assignable_QMARK__A).Invoke_O_O_O__O(root_997, arg_1000, arg_1001) }
//line :266:1
			if jrt.J2g_Truth(tmp2) { return a__0 } else { var tmp3 any; var and__1927000168__auto____3 any; var root_1002 any = A_arbace_classes_env_A_const_112.GetRawRoot__O(); var linked_1003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1002, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_1004 lang.IFn




				if linked_1003 == nil { ifn_1004 = lang.IFn_Cast(root_1002) } else { ifn_1004 = nil }; var arg_1005 any = a__0; if linked_1003 == nil { and__1927000168__auto____3 = ifn_1004.Invoke_O__O(arg_1005) } else { and__1927000168__auto____3 = linked_1003.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_1002, arg_1005) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_1006 any = A_arbace_classes_env_A_const_112.GetRawRoot__O(); var linked_1007 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1006, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_1008 lang.IFn; if linked_1007 == nil { ifn_1008 = lang.IFn_Cast(root_1006) } else { ifn_1008 = nil }; var arg_1009 any = b__1; if linked_1007 == nil { tmp3 = ifn_1008.Invoke_O__O(arg_1009) } else { tmp3 = linked_1007.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_1006, arg_1009) } } else { tmp3 = and__1927000168__auto____3 }
//line :266:1
				if jrt.J2g_Truth(tmp3) { var c__3 any; var root_1010 any = A_arbace_classes_env_A_const_113.GetRawRoot__O(); var linked_1011 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1010, A_arbace_classes_env_common_super_A_fn_class); var ifn_1012 lang.IFn





					if linked_1011 == nil { ifn_1012 = lang.IFn_Cast(root_1010) } else { ifn_1012 = nil }; var arg_1013 any; var root_1015 any = A_arbace_classes_env_A_const_106.GetRawRoot__O(); var linked_1016 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1015, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_1017 lang.IFn; if linked_1016 == nil { ifn_1017 = lang.IFn_Cast(root_1015) } else { ifn_1017 = nil }; var arg_1018 any = a__0; if linked_1016 == nil { arg_1013 = ifn_1017.Invoke_O__O(arg_1018) } else { arg_1013 = linked_1016.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_1015, arg_1018) }; var arg_1014 any; var root_1019 any = A_arbace_classes_env_A_const_106.GetRawRoot__O(); var linked_1020 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1019, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_1021 lang.IFn; if linked_1020 == nil { ifn_1021 = lang.IFn_Cast(root_1019) } else { ifn_1021 = nil }; var arg_1022 any = b__1; if linked_1020 == nil { arg_1014 = ifn_1021.Invoke_O__O(arg_1022) } else { arg_1014 = linked_1020.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_1019, arg_1022) }; if linked_1011 == nil { c__3 = ifn_1012.Invoke_O_O__O(arg_1013, arg_1014) } else { c__3 = linked_1011.(*A_arbace_classes_env_common_super_A).Invoke_O_O_O__O(root_1010, arg_1013, arg_1014) }
					if lang.Util_Equiv_O_O__Z_NoInit(c__3, Lit_4) { var sups__4 any; var tmp4 any = A_arbace_classes_env_lub_sups__28000129_A_New(); var tmp5 *jrt.Class
						var fncls__1047 /*line :273:1*/*jrt.Class = A_arbace_classes_env_lub_sups__28000129_A_fn_class

						if fncls__1047 == nil { var fncls__1047d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_classes_env_lub_sups__28000129_A_fn_class = fncls__1047d; tmp5 = fncls__1047d } else { tmp5 = fncls__1047 }; sups__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)
//line :273:1
						var common__5 any; var root_1048 any = A_arbace_classes_env_A_const_86.GetRawRoot__O(); var linked_1049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1048, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1050 lang.IFn




						if linked_1049 == nil { ifn_1050 = lang.IFn_Cast(root_1048) } else { ifn_1050 = nil }; var arg_1051 any = A_arbace_classes_env_A_const_109.GetRawRoot__O(); var arg_1052 any; var root_1053 any = A_arbace_classes_env_A_const_115.GetRawRoot__O(); var linked_1054 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1053, aot_arbace_set.A_arbace_set_intersection_A_fn_class); var ifn_1055 lang.IFn; if linked_1054 == nil { ifn_1055 = lang.IFn_Cast(root_1053) } else { ifn_1055 = nil }; var arg_1056 any; var tmp6 lang.IFn = lang.IFn_Cast(sups__4); var tmp7 any; var root_1058 any = A_arbace_classes_env_A_const_106.GetRawRoot__O(); var linked_1059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1058, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_1060 lang.IFn; if linked_1059 == nil { ifn_1060 = lang.IFn_Cast(root_1058) } else { ifn_1060 = nil }; var arg_1061 any = a__0; if linked_1059 == nil { tmp7 = ifn_1060.Invoke_O__O(arg_1061) } else { tmp7 = linked_1059.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_1058, arg_1061) }; arg_1056 = tmp6.Invoke_O__O(tmp7); var arg_1057 any; var tmp8 lang.IFn = lang.IFn_Cast(sups__4); var tmp9 any; var root_1062 any = A_arbace_classes_env_A_const_106.GetRawRoot__O(); var linked_1063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1062, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_1064 lang.IFn
						if linked_1063 == nil { ifn_1064 = lang.IFn_Cast(root_1062) } else { ifn_1064 = nil }; var arg_1065 any = b__1; if linked_1063 == nil { tmp9 = ifn_1064.Invoke_O__O(arg_1065) } else { tmp9 = linked_1063.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_1062, arg_1065) }; arg_1057 = tmp8.Invoke_O__O(tmp9)
//line :278:1
						if linked_1054 == nil { arg_1052 = ifn_1055.Invoke_O_O__O(arg_1056, arg_1057) } else { arg_1052 = linked_1054.(*aot_arbace_set.A_arbace_set_intersection_A).Invoke_O_O_O__O(root_1053, arg_1056, arg_1057) }; if linked_1049 == nil { common__5 = ifn_1050.Invoke_O_O__O(arg_1051, arg_1052) } else { common__5 = linked_1049.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1048, arg_1051, arg_1052) }
//line :273:1
						var minimal__6 any; var root_1066 any = A_arbace_classes_env_A_const_116.GetRawRoot__O(); var linked_1067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1066, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1068 lang.IFn






						if linked_1067 == nil { ifn_1068 = lang.IFn_Cast(root_1066) } else { ifn_1068 = nil }; var arg_1069 any; var tmp10 any = A_arbace_classes_env_lub_fn__28000134_A_New_O(common__5); var tmp11 *jrt.Class; var fncls__1087 *jrt.Class = A_arbace_classes_env_lub_fn__28000134_A_fn_class; if fncls__1087 == nil { var fncls__1087d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_classes_env_lub_fn__28000134_A_fn_class = fncls__1087d; tmp11 = fncls__1087d } else { tmp11 = fncls__1087 }; arg_1069 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var arg_1070 any = common__5; if linked_1067 == nil { minimal__6 = ifn_1068.Invoke_O_O__O(arg_1069, arg_1070) } else { minimal__6 = linked_1067.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1066, arg_1069, arg_1070) }
						if lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(minimal__6))) { var root_1088 any = A_arbace_classes_env_A_const_118.GetRawRoot__O(); var linked_1089 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1088, aot_arbace_classes_types.A_arbace_classes_types_internal__GT_desc_A_fn_class); var ifn_1090 lang.IFn; if linked_1089 == nil { ifn_1090 = lang.IFn_Cast(root_1088) } else { ifn_1090 = nil }; var arg_1091 any; var root_1092 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_1093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1092, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1094 lang.IFn; if linked_1093 == nil { ifn_1094 = lang.IFn_Cast(root_1092) } else { ifn_1094 = nil }; var arg_1095 any = minimal__6; if linked_1093 == nil { arg_1091 = ifn_1094.Invoke_O__O(arg_1095) } else { arg_1091 = linked_1093.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1092, arg_1095) }; if linked_1089 == nil { return ifn_1090.Invoke_O__O(arg_1091) } else { return linked_1089.(*aot_arbace_classes_types.A_arbace_classes_types_internal__GT_desc_A).Invoke_O_O__O(root_1088, arg_1091) } } else { return A_arbace_classes_env_A_const_100.GetRawRoot__O() } } else {
							var root_1096 any = A_arbace_classes_env_A_const_118.GetRawRoot__O(); var linked_1097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1096, aot_arbace_classes_types.A_arbace_classes_types_internal__GT_desc_A_fn_class); var ifn_1098 lang.IFn; if linked_1097 == nil { ifn_1098 = lang.IFn_Cast(root_1096) } else { ifn_1098 = nil }; var arg_1099 any = c__3; if linked_1097 == nil { return ifn_1098.Invoke_O__O(arg_1099) } else { return linked_1097.(*aot_arbace_classes_types.A_arbace_classes_types_internal__GT_desc_A).Invoke_O_O__O(root_1096, arg_1099) } } } else {
//line :266:1
								if A_arbace_classes_env_A_const_104 != nil { return A_arbace_classes_env_A_const_100.GetRawRoot__O() } else { return nil
								}
							}
			}
		}
	}
	}
	}
}
func A_arbace_classes_env_lub_sups__28000129_A_New() *A_arbace_classes_env_lub_sups__28000129_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_lub_sups__28000129_A{}; t.Ctor(); return t }
//line :275:1
func (t *A_arbace_classes_env_lub_sups__28000129_A) Ctor() {}
//line :275:1
func (t *A_arbace_classes_env_lub_sups__28000129_A) Invoke_O_O__O(self, n__1 any) any { var root_1023 any = A_arbace_classes_env_A_const_110.GetRawRoot__O(); var linked_1024 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1023, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_1025 lang.IFn; if linked_1024 == nil { ifn_1025 = lang.IFn_Cast(root_1023) } else { ifn_1025 = nil }; var arg_1026 any; var root_1027 any = A_arbace_classes_env_A_const_114.GetRawRoot__O(); var linked_1028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1027, aot_arbace_core.A_arbace_core_tree_seq_A_fn_class); var ifn_1029 lang.IFn; if linked_1028 == nil { ifn_1029 = lang.IFn_Cast(root_1027) } else { ifn_1029 = nil }; var arg_1030 any = A_arbace_classes_env_A_const_25.GetRawRoot__O(); var arg_1031 any; var tmp1 any = A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_New(); var tmp2 *jrt.Class; var fncls__1046 *jrt.Class = A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_fn_class; if fncls__1046 == nil { var fncls__1046d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_fn_class = fncls__1046d; tmp2 = fncls__1046d } else { tmp2 = fncls__1046 }; arg_1031 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1032 any = n__1; if linked_1028 == nil { arg_1026 = ifn_1029.Invoke_O_O_O__O(arg_1030, arg_1031, arg_1032) } else { arg_1026 = linked_1028.(*aot_arbace_core.A_arbace_core_tree_seq_A).Invoke_O_O_O_O__O(root_1027, arg_1030, arg_1031, arg_1032) }; if linked_1024 == nil { return ifn_1025.Invoke_O__O(arg_1026) } else { return linked_1024.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1023, arg_1026) } }
//line :275:1
func A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_New() *A_arbace_classes_env_lub_sups__28000129_fn__28000130_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_lub_sups__28000129_fn__28000130_A{}; t.Ctor(); return t }
//line :275:1
func (t *A_arbace_classes_env_lub_sups__28000129_fn__28000130_A) Ctor() {}
//line :275:1
func (t *A_arbace_classes_env_lub_sups__28000129_fn__28000130_A) Invoke_O_O__O(self, x__1 any) any { var temp__1927000414__auto____2 any; var root_1033 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_1034 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1033, A_arbace_classes_env_info_A_fn_class); var ifn_1035 lang.IFn; if linked_1034 == nil { ifn_1035 = lang.IFn_Cast(root_1033) } else { ifn_1035 = nil }; var arg_1036 any = x__1; if linked_1034 == nil { temp__1927000414__auto____2 = ifn_1035.Invoke_O__O(arg_1036) } else { temp__1927000414__auto____2 = linked_1034.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1033, arg_1036) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var i__3 any = temp__1927000414__auto____2; var G__28000131__4_ any; var root_1037 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_1038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1037, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1039 lang.IFn
													if linked_1038 == nil { ifn_1039 = lang.IFn_Cast(root_1037) } else { ifn_1039 = nil }; var arg_1040 any = A_arbace_classes_env_A_const_46.Invoke_O__O(i__3); if linked_1038 == nil { G__28000131__4_ = ifn_1039.Invoke_O__O(arg_1040) } else { G__28000131__4_ = linked_1038.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1037, arg_1040) }; if jrt.J2g_Truth(A_arbace_classes_env_A_const_45.Invoke_O__O(i__3)) { var root_1041 any = A_arbace_classes_env_A_const_10.GetRawRoot__O(); var linked_1042 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1041, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1043 lang.IFn; if linked_1042 == nil { ifn_1043 = lang.IFn_Cast(root_1041) } else { ifn_1043 = nil }; var arg_1044 any = G__28000131__4_; var arg_1045 any = A_arbace_classes_env_A_const_45.Invoke_O__O(i__3); if linked_1042 == nil { return ifn_1043.Invoke_O_O__O(arg_1044, arg_1045) } else { return linked_1042.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1041, arg_1044, arg_1045) } } else { return G__28000131__4_ } } else {
//line :275:1
		return nil } }




func A_arbace_classes_env_lub_fn__28000134_A_New_O(p0 any) *A_arbace_classes_env_lub_fn__28000134_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_lub_fn__28000134_A{}; t.Ctor_O(p0); return t }
//line :280:1
func (t *A_arbace_classes_env_lub_fn__28000134_A) Ctor_O(c__common any) { t.F_common = c__common }
//line :280:1
func (t *A_arbace_classes_env_lub_fn__28000134_A) Invoke_O_O__O(self, i__1 any) any { var root_1071 any = A_arbace_classes_env_A_const_96.GetRawRoot__O(); var linked_1072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1071, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1073 lang.IFn; if linked_1072 == nil { ifn_1073 = lang.IFn_Cast(root_1071) } else { ifn_1073 = nil }; var arg_1074 any; var tmp1 any = A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_New_O(i__1); var tmp2 *jrt.Class; var fncls__1086 *jrt.Class = A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_fn_class; if fncls__1086 == nil { var fncls__1086d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_fn_class = fncls__1086d; tmp2 = fncls__1086d } else { tmp2 = fncls__1086 }; arg_1074 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1075 any = t.F_common; if linked_1072 == nil { return ifn_1073.Invoke_O_O__O(arg_1074, arg_1075) } else { return linked_1072.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1071, arg_1074, arg_1075) } }
//line :280:1
func A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_New_O(p0 any) *A_arbace_classes_env_lub_fn__28000134_fn__28000135_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_lub_fn__28000134_fn__28000135_A{}; t.Ctor_O(p0); return t }
//line :280:1
func (t *A_arbace_classes_env_lub_fn__28000134_fn__28000135_A) Ctor_O(c__i any) { t.F_i = c__i }
//line :280:1
func (t *A_arbace_classes_env_lub_fn__28000134_fn__28000135_A) Invoke_O_O__O(self, p1__28000128_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_1076 any = A_arbace_classes_env_A_const_117.GetRawRoot__O(); var linked_1077 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1076, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1078 lang.IFn; if linked_1077 == nil { ifn_1078 = lang.IFn_Cast(root_1076) } else { ifn_1078 = nil }; var arg_1079 any = p1__28000128_SHARP___1; var arg_1080 any = t.F_i; if linked_1077 == nil { and__1927000168__auto____2 = ifn_1078.Invoke_O_O__O(arg_1079, arg_1080) } else { and__1927000168__auto____2 = linked_1077.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1076, arg_1079, arg_1080) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_1081 any = A_arbace_classes_env_A_const_97.GetRawRoot__O(); var linked_1082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1081, A_arbace_classes_env_subclass_QMARK__A_fn_class); var ifn_1083 lang.IFn; if linked_1082 == nil { ifn_1083 = lang.IFn_Cast(root_1081) } else { ifn_1083 = nil }; var arg_1084 any = p1__28000128_SHARP___1; var arg_1085 any = t.F_i; if linked_1082 == nil { return ifn_1083.Invoke_O_O__O(arg_1084, arg_1085) } else { return linked_1082.(*A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(root_1081, arg_1084, arg_1085) } } else { return and__1927000168__auto____2 } }






func A_arbace_classes_env_nest_host_A_New() *A_arbace_classes_env_nest_host_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_nest_host_A{}; t.Ctor(); return t }
//line :287:1
func (t *A_arbace_classes_env_nest_host_A) Ctor() {}
//line :287:1
func (t *A_arbace_classes_env_nest_host_A) Invoke_O_O__O(self, n__0 any) any { var i__2 any; var root_1100 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_1101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1100, A_arbace_classes_env_info_A_fn_class); var ifn_1102 lang.IFn; if
										linked_1101 == nil { ifn_1102 = lang.IFn_Cast(root_1100) } else { ifn_1102 = nil }; var arg_1103 any = n__0; if linked_1101 == nil { i__2 = ifn_1102.Invoke_O__O(arg_1103) } else { i__2 = linked_1101.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1100, arg_1103) }; var or__1927000174__auto____3 any = /*line :287:1*/A_arbace_classes_env_A_const_48.Invoke_O__O(i__2); if

	jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var temp__1927000408__auto____4 any = A_arbace_classes_env_A_const_49.Invoke_O__O(i__2)
		if jrt.J2g_Truth(temp__1927000408__auto____4) { var o__5 any = temp__1927000408__auto____4; var root_1104 any = A_arbace_classes_env_A_const_119.GetRawRoot__O(); var linked_1105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1104, A_arbace_classes_env_nest_host_A_fn_class); var ifn_1106 lang.IFn; if linked_1105 == nil { ifn_1106 = lang.IFn_Cast(root_1104) } else { ifn_1106 = nil }; var arg_1107 any = o__5; if linked_1105 == nil { return ifn_1106.Invoke_O__O(arg_1107) } else { return linked_1105.(*A_arbace_classes_env_nest_host_A).Invoke_O_O__O(root_1104, arg_1107) } } else { return n__0 } } }

func A_arbace_classes_env_flag_QMARK__A_New() *A_arbace_classes_env_flag_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_flag_QMARK__A{}; t.Ctor(); return t }
//line :292:1
func (t *A_arbace_classes_env_flag_QMARK__A) Ctor() {}
//line :292:1
func (t *A_arbace_classes_env_flag_QMARK__A) Invoke_O_O_O__O(self, flags__0, f__1 any) any { var root_1108 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1108, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1110 lang.IFn; if linked_1109 == nil { ifn_1110 = lang.IFn_Cast(root_1108) } else { ifn_1110 = nil }; var arg_1111 any; var tmp1 int64; var na_1112 any = flags__0; var na_1113 any = f__1; var tmp2 bool; var tmp3 bool; tmp3 = jrt.Long_InstanceOf(na_1112); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_1113) }; tmp2 = tmp3; if tmp2 { var n0_1114 int64 = jrt.NN(jrt.Long_Cast(na_1112)).LongValue__J(); var n1_1115 int64 = jrt.NN(jrt.Long_Cast(na_1113)).LongValue__J(); tmp1 = n0_1114 & n1_1115 } else { tmp1 = lang.Numbers_And_O_O__J_NoInit(na_1112, na_1113) }; arg_1111 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(tmp1)).Ref(); if linked_1109 == nil { return ifn_1110.Invoke_O__O(arg_1111) } else { return linked_1109.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1108, arg_1111) } }

func A_arbace_classes_env_accessible_QMARK__A_New() *A_arbace_classes_env_accessible_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_accessible_QMARK__A{}; t.Ctor(); return t }
//line :294:1
func (t *A_arbace_classes_env_accessible_QMARK__A) Ctor() {}
//line :294:1
func (t *A_arbace_classes_env_accessible_QMARK__A) Invoke_O_O_O__O(self, from__0, m__1 any) any { var fl__3 any = A_arbace_classes_env_A_const_43.Invoke_O__O(m__1); var owner__4 any = A_arbace_classes_env_A_const_63.Invoke_O__O(m__1); var tmp1 any; var root_1117 any = A_arbace_classes_env_A_const_120.GetRawRoot__O(); var linked_1118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1117, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1119 lang.IFn; if




	linked_1118 == nil { ifn_1119 = lang.IFn_Cast(root_1117) } else { ifn_1119 = nil }; var arg_1120 any = fl__3; var arg_1121 any = A_arbace_classes_env_A_const_121; if linked_1118 == nil { tmp1 = ifn_1119.Invoke_O_O__O(arg_1120, arg_1121) } else { tmp1 = linked_1118.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1117, arg_1120, arg_1121) }; if /*line :298:1*/ jrt.J2g_Truth(tmp1) { return jrt.Boolean_TRUE.Ref() } else { var tmp2 any; var root_1122 any = A_arbace_classes_env_A_const_120.GetRawRoot__O(); var linked_1123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1122, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1124 lang.IFn

		if linked_1123 == nil { ifn_1124 = lang.IFn_Cast(root_1122) } else { ifn_1124 = nil }; var arg_1125 any = fl__3; var arg_1126 any = A_arbace_classes_env_A_const_122; if linked_1123 == nil { tmp2 = ifn_1124.Invoke_O_O__O(arg_1125, arg_1126) } else { tmp2 = linked_1123.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1122, arg_1125, arg_1126) }
//line :298:1
		if jrt.J2g_Truth(tmp2) {

			var tmp3 any; var root_1127 any = A_arbace_classes_env_A_const_119.GetRawRoot__O(); var linked_1128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1127, A_arbace_classes_env_nest_host_A_fn_class); var ifn_1129 lang.IFn; if linked_1128 == nil { ifn_1129 = lang.IFn_Cast(root_1127) } else { ifn_1129 = nil }; var arg_1130 any = from__0; if linked_1128 == nil { tmp3 = ifn_1129.Invoke_O__O(arg_1130) } else { tmp3 = linked_1128.(*A_arbace_classes_env_nest_host_A).Invoke_O_O__O(root_1127, arg_1130) }; var tmp4 any = tmp3; var tmp5 any; var root_1131 any = A_arbace_classes_env_A_const_119.GetRawRoot__O(); var linked_1132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1131, A_arbace_classes_env_nest_host_A_fn_class); var ifn_1133 lang.IFn; if linked_1132 == nil { ifn_1133 = lang.IFn_Cast(root_1131) } else { ifn_1133 = nil }; var arg_1134 any = owner__4; if linked_1132 == nil { tmp5 = ifn_1133.Invoke_O__O(arg_1134) } else { tmp5 = linked_1132.(*A_arbace_classes_env_nest_host_A).Invoke_O_O__O(root_1131, arg_1134) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5)).Ref() } else {
//line :298:1
				var tmp6 any; var root_1135 any = A_arbace_classes_env_A_const_123.GetRawRoot__O(); var linked_1136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1135, aot_arbace_classes_types.A_arbace_classes_types_package_of_A_fn_class); var ifn_1137 lang.IFn


				if linked_1136 == nil { ifn_1137 = lang.IFn_Cast(root_1135) } else { ifn_1137 = nil }; var arg_1138 any = from__0; if linked_1136 == nil { tmp6 = ifn_1137.Invoke_O__O(arg_1138) } else { tmp6 = linked_1136.(*aot_arbace_classes_types.A_arbace_classes_types_package_of_A).Invoke_O_O__O(root_1135, arg_1138) }
//line :298:1
				var tmp7 any = tmp6; var tmp8 any; var root_1139 any = A_arbace_classes_env_A_const_123.GetRawRoot__O(); var linked_1140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1139, aot_arbace_classes_types.A_arbace_classes_types_package_of_A_fn_class); var ifn_1141 lang.IFn


				if linked_1140 == nil { ifn_1141 = lang.IFn_Cast(root_1139) } else { ifn_1141 = nil }; var arg_1142 any = owner__4; if linked_1140 == nil { tmp8 = ifn_1141.Invoke_O__O(arg_1142) } else { tmp8 = linked_1140.(*aot_arbace_classes_types.A_arbace_classes_types_package_of_A).Invoke_O_O__O(root_1139, arg_1142) }
//line :298:1
				if lang.Util_Equiv_O_O__Z_NoInit(tmp7, tmp8) { return jrt.Boolean_TRUE.Ref() } else { var tmp9 any; var root_1143 any = A_arbace_classes_env_A_const_120.GetRawRoot__O(); var linked_1144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1143, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1145 lang.IFn



					if linked_1144 == nil { ifn_1145 = lang.IFn_Cast(root_1143) } else { ifn_1145 = nil }; var arg_1146 any = fl__3; var arg_1147 any = A_arbace_classes_env_A_const_124; if linked_1144 == nil { tmp9 = ifn_1145.Invoke_O_O__O(arg_1146, arg_1147) } else { tmp9 = linked_1144.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1143, arg_1146, arg_1147) }
//line :298:1
					if jrt.J2g_Truth(tmp9) {




						var tmp10 any; var root_1148 any = A_arbace_classes_env_A_const_96.GetRawRoot__O(); var linked_1149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1148, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1150 lang.IFn; if linked_1149 == nil { ifn_1150 = lang.IFn_Cast(root_1148) } else { ifn_1150 = nil }; var arg_1151 any; var tmp11 any = A_arbace_classes_env_accessible_QMARK__fn__28000143_A_New_O(owner__4); var tmp12 *jrt.Class; var fncls__1158 *jrt.Class = A_arbace_classes_env_accessible_QMARK__fn__28000143_A_fn_class; if fncls__1158 == nil { var fncls__1158d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_classes_env_accessible_QMARK__fn__28000143_A_fn_class = fncls__1158d; tmp12 = fncls__1158d } else { tmp12 = fncls__1158 }; arg_1151 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var arg_1152 any; var root_1159 any = A_arbace_classes_env_A_const_107.GetRawRoot__O(); var linked_1160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1159, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_1161 lang.IFn
						if linked_1160 == nil { ifn_1161 = lang.IFn_Cast(root_1159) } else { ifn_1161 = nil }; var arg_1162 any = A_arbace_classes_env_A_const_25.GetRawRoot__O(); var arg_1163 any; var root_1164 any = A_arbace_classes_env_A_const_108.GetRawRoot__O(); var linked_1165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1164, aot_arbace_core.A_arbace_core_iterate_A_fn_class); var ifn_1166 lang.IFn; if linked_1165 == nil { ifn_1166 = lang.IFn_Cast(root_1164) } else { ifn_1166 = nil }; var arg_1167 any; var tmp13 any = A_arbace_classes_env_accessible_QMARK__fn__28000145_A_New(); var tmp14 *jrt.Class; var fncls__1173 *jrt.Class = A_arbace_classes_env_accessible_QMARK__fn__28000145_A_fn_class; if fncls__1173 == nil { var fncls__1173d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_classes_env_accessible_QMARK__fn__28000145_A_fn_class = fncls__1173d; tmp14 = fncls__1173d } else { tmp14 = fncls__1173 }; arg_1167 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); var arg_1168 any = from__0; if linked_1165 == nil { arg_1163 = ifn_1166.Invoke_O_O__O(arg_1167, arg_1168) } else { arg_1163 = linked_1165.(*aot_arbace_core.A_arbace_core_iterate_A).Invoke_O_O_O__O(root_1164, arg_1167, arg_1168) }; if linked_1160 == nil { arg_1152 = ifn_1161.Invoke_O_O__O(arg_1162, arg_1163) } else { arg_1152 = linked_1160.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_1159, arg_1162, arg_1163) }
//line :303:1
						if linked_1149 == nil { tmp10 = ifn_1150.Invoke_O_O__O(arg_1151, arg_1152) } else { tmp10 = linked_1149.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1148, arg_1151, arg_1152) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp10)).Ref() } else {
//line :298:1
							if A_arbace_classes_env_A_const_104 != nil { return jrt.Boolean_FALSE.Ref() } else { return nil } } } } } }




func A_arbace_classes_env_accessible_QMARK__fn__28000143_A_New_O(p0 any) *A_arbace_classes_env_accessible_QMARK__fn__28000143_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_accessible_QMARK__fn__28000143_A{}; t.Ctor_O(p0); return t }
//line :303:1
func (t *A_arbace_classes_env_accessible_QMARK__fn__28000143_A) Ctor_O(c__owner any) { t.F_owner = c__owner }
//line :303:1
func (t *A_arbace_classes_env_accessible_QMARK__fn__28000143_A) Invoke_O_O__O(self, p1__28000141_SHARP___1 any) any { var root_1153 any = A_arbace_classes_env_A_const_97.GetRawRoot__O(); var linked_1154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1153, A_arbace_classes_env_subclass_QMARK__A_fn_class); var ifn_1155 lang.IFn; if linked_1154 == nil { ifn_1155 = lang.IFn_Cast(root_1153) } else { ifn_1155 = nil }; var arg_1156 any = p1__28000141_SHARP___1; var arg_1157 any = t.F_owner; if linked_1154 == nil { return ifn_1155.Invoke_O_O__O(arg_1156, arg_1157) } else { return linked_1154.(*A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(root_1153, arg_1156, arg_1157) } }
func A_arbace_classes_env_accessible_QMARK__fn__28000145_A_New() *A_arbace_classes_env_accessible_QMARK__fn__28000145_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_accessible_QMARK__fn__28000145_A{}; t.Ctor(); return t }
//line :304:1
func (t *A_arbace_classes_env_accessible_QMARK__fn__28000145_A) Ctor() {}
//line :304:1
func (t *A_arbace_classes_env_accessible_QMARK__fn__28000145_A) Invoke_O_O__O(self, p1__28000142_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_classes_env_A_const_49; var tmp2 any; var root_1169 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_1170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1169, A_arbace_classes_env_info_A_fn_class); var ifn_1171 lang.IFn; if linked_1170 == nil { ifn_1171 = lang.IFn_Cast(root_1169) } else { ifn_1171 = nil }; var arg_1172 any = p1__28000142_SHARP___1; if linked_1170 == nil { tmp2 = ifn_1171.Invoke_O__O(arg_1172) } else { tmp2 = linked_1170.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1169, arg_1172) }; return tmp1.Invoke_O__O(tmp2) }


func A_arbace_classes_env_find_field_A_New() *A_arbace_classes_env_find_field_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_find_field_A{}; t.Ctor(); return t }
//line :307:1
func (t *A_arbace_classes_env_find_field_A) Ctor() {}
//line :307:1
func (t *A_arbace_classes_env_find_field_A) Invoke_O_O_O__O(self, n__0, name__1 any) any { var temp__1927000414__auto____3 any; var root_1174 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_1175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1174, A_arbace_classes_env_info_A_fn_class); var ifn_1176 lang.IFn; if



	linked_1175 == nil { ifn_1176 = lang.IFn_Cast(root_1174) } else { ifn_1176 = nil }; var arg_1177 any = n__0; if linked_1175 == nil { temp__1927000414__auto____3 = ifn_1176.Invoke_O__O(arg_1177) } else { temp__1927000414__auto____3 = linked_1175.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1174, arg_1177) }; if jrt.J2g_Truth(temp__1927000414__auto____3) { var i__4 any = temp__1927000414__auto____3; var or__1927000174__auto____5 any; var root_1178 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_1179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1178, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1180 lang.IFn
		if linked_1179 == nil { ifn_1180 = lang.IFn_Cast(root_1178) } else { ifn_1180 = nil }; var arg_1181 any; var root_1182 any = A_arbace_classes_env_A_const_86.GetRawRoot__O(); var linked_1183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1182, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1184 lang.IFn; if linked_1183 == nil { ifn_1184 = lang.IFn_Cast(root_1182) } else { ifn_1184 = nil }; var arg_1185 any; var tmp1 any = A_arbace_classes_env_find_field_fn__28000150_A_New_O(name__1); var tmp2 *jrt.Class; var fncls__1187 *jrt.Class = A_arbace_classes_env_find_field_fn__28000150_A_fn_class; if fncls__1187 == nil { var fncls__1187d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_classes_env_find_field_fn__28000150_A_fn_class = fncls__1187d; tmp2 = fncls__1187d } else { tmp2 = fncls__1187 }; arg_1185 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1186 any = A_arbace_classes_env_A_const_50.Invoke_O__O(i__4); if linked_1183 == nil { arg_1181 = ifn_1184.Invoke_O_O__O(arg_1185, arg_1186) } else { arg_1181 = linked_1183.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1182, arg_1185, arg_1186) }; if linked_1179 == nil { or__1927000174__auto____5 = ifn_1180.Invoke_O__O(arg_1181) } else { or__1927000174__auto____5 = linked_1179.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1178, arg_1181) }; if jrt.J2g_Truth(or__1927000174__auto____5) { return or__1927000174__auto____5 } else { var or__1927000174__auto____6 any; var root_1188 any = A_arbace_classes_env_A_const_96.GetRawRoot__O(); var linked_1189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1188, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1190 lang.IFn
			if linked_1189 == nil { ifn_1190 = lang.IFn_Cast(root_1188) } else { ifn_1190 = nil }; var arg_1191 any; var tmp3 any = A_arbace_classes_env_find_field_fn__28000152_A_New_O(name__1); var tmp4 *jrt.Class; var fncls__1198 *jrt.Class = A_arbace_classes_env_find_field_fn__28000152_A_fn_class; if fncls__1198 == nil { var fncls__1198d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_classes_env_find_field_fn__28000152_A_fn_class = fncls__1198d; tmp4 = fncls__1198d } else { tmp4 = fncls__1198 }; arg_1191 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_1192 any = A_arbace_classes_env_A_const_46.Invoke_O__O(i__4); if linked_1189 == nil { or__1927000174__auto____6 = ifn_1190.Invoke_O_O__O(arg_1191, arg_1192) } else { or__1927000174__auto____6 = linked_1189.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1188, arg_1191, arg_1192) }
//line :312:1
			if jrt.J2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else { var G__28000154__7_ any = A_arbace_classes_env_A_const_45.Invoke_O__O(i__4)

				if lang.Util_Identical_O_O__Z_NoInit(G__28000154__7_, nil) { return nil } else { var root_1199 any = A_arbace_classes_env_A_const_125.GetRawRoot__O(); var linked_1200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1199, A_arbace_classes_env_find_field_A_fn_class); var ifn_1201 lang.IFn; if linked_1200 == nil { ifn_1201 = lang.IFn_Cast(root_1199) } else { ifn_1201 = nil }; var arg_1202 any = G__28000154__7_; var arg_1203 any = name__1; if linked_1200 == nil { return ifn_1201.Invoke_O_O__O(arg_1202, arg_1203) } else { return linked_1200.(*A_arbace_classes_env_find_field_A).Invoke_O_O_O__O(root_1199, arg_1202, arg_1203) } } } } } else {
//line :311:1
					return nil } }
func A_arbace_classes_env_find_field_fn__28000150_A_New_O(p0 any) *A_arbace_classes_env_find_field_fn__28000150_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_find_field_fn__28000150_A{}; t.Ctor_O(p0); return t }
//line :312:1
func (t *A_arbace_classes_env_find_field_fn__28000150_A) Ctor_O(c__name any) { t.F_name = c__name }
//line :312:1
func (t *A_arbace_classes_env_find_field_fn__28000150_A) Invoke_O_O__O(self, p1__28000148_SHARP___1 any) any { var tmp1 any = t.F_name; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_classes_env_A_const_42.Invoke_O__O(p1__28000148_SHARP___1))).Ref() }
func A_arbace_classes_env_find_field_fn__28000152_A_New_O(p0 any) *A_arbace_classes_env_find_field_fn__28000152_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_find_field_fn__28000152_A{}; t.Ctor_O(p0); return t }
//line :313:1
func (t *A_arbace_classes_env_find_field_fn__28000152_A) Ctor_O(c__name any) { t.F_name = c__name }
//line :313:1
func (t *A_arbace_classes_env_find_field_fn__28000152_A) Invoke_O_O__O(self, p1__28000149_SHARP___1 any) any { var root_1193 any = A_arbace_classes_env_A_const_125.GetRawRoot__O(); var linked_1194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1193, A_arbace_classes_env_find_field_A_fn_class); var ifn_1195 lang.IFn; if linked_1194 == nil { ifn_1195 = lang.IFn_Cast(root_1193) } else { ifn_1195 = nil }; var arg_1196 any = p1__28000149_SHARP___1; var arg_1197 any = t.F_name; if linked_1194 == nil { return ifn_1195.Invoke_O_O__O(arg_1196, arg_1197) } else { return linked_1194.(*A_arbace_classes_env_find_field_A).Invoke_O_O_O__O(root_1193, arg_1196, arg_1197) } }


func A_arbace_classes_env_same_infos_QMARK__A_New() *A_arbace_classes_env_same_infos_QMARK__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_same_infos_QMARK__A{}; t.Ctor(); return t }
//line :316:1
func (t *A_arbace_classes_env_same_infos_QMARK__A) Ctor() {}
//line :316:1
func (t *A_arbace_classes_env_same_infos_QMARK__A) Invoke_O_O_O__O(self, names__0, infos__1 any) any { { var n__3 int32 = lang.RT_Count_O__I_NoInit(names__0); var cs__4 any; var G__28000156__4_ any = A_arbace_classes_env_A_const_89.Get__O()



	if lang.Util_Identical_O_O__Z_NoInit(G__28000156__4_, nil) { cs__4 = nil } else { var root_1204 any = A_arbace_classes_env_A_const_8.GetRawRoot__O(); var linked_1205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1204, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1206 lang.IFn; if linked_1205 == nil { ifn_1206 = lang.IFn_Cast(root_1204) } else { ifn_1206 = nil }; var arg_1207 any = G__28000156__4_; if linked_1205 == nil { cs__4 = ifn_1206.Invoke_O__O(arg_1207) } else { cs__4 = linked_1205.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1204, arg_1207) } }
//line :316:1
	var i__5 int64 = 0; L1: for { var or__1927000174__auto____6 bool = lang.Util_Equiv_J_J__Z_NoInit(i__5, int64(n__3))





		if or__1927000174__auto____6 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____6).Ref() } else { var and__1927000168__auto____7 any; var c__7 any = lang.RT_Nth_O_I__O_NoInit(names__0, lang.RT_IntCast_J__I_NoInit(i__5)); var x__8 any = lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](infos__1, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(i__5)); var or__1927000174__auto____9 any; var and__1927000168__auto____9 any; var root_1208 any = A_arbace_classes_env_A_const_25.GetRawRoot__O(); var linked_1209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1208, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_1210 lang.IFn



			if linked_1209 == nil { ifn_1210 = lang.IFn_Cast(root_1208) } else { ifn_1210 = nil }; var arg_1211 any = x__8; if linked_1209 == nil { and__1927000168__auto____9 = ifn_1210.Invoke_O__O(arg_1211) } else { and__1927000168__auto____9 = linked_1209.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_1208, arg_1211) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 any; var root_1212 any = A_arbace_classes_env_A_const_25.GetRawRoot__O(); var linked_1213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1212, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_1214 lang.IFn; if linked_1213 == nil { ifn_1214 = lang.IFn_Cast(root_1212) } else { ifn_1214 = nil }; var arg_1215 any = cs__4; if linked_1213 == nil { and__1927000168__auto____10 = ifn_1214.Invoke_O__O(arg_1215) } else { and__1927000168__auto____10 = linked_1213.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_1212, arg_1215) }; if jrt.J2g_Truth(and__1927000168__auto____10) { var and__1927000168__auto____11 bool = lang.Util_Identical_O_O__Z_NoInit(x__8, lang.RT_Get_O_O__O_NoInit(cs__4, c__7)); if and__1927000168__auto____11 { var root_1216 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1216, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1218 lang.IFn; if linked_1217 == nil { ifn_1218 = lang.IFn_Cast(root_1216) } else { ifn_1218 = nil }; var arg_1219 any; var root_1220 any = A_arbace_classes_env_A_const_20.GetRawRoot__O(); var linked_1221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1220, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1222 lang.IFn; if linked_1221 == nil { ifn_1222 = lang.IFn_Cast(root_1220) } else { ifn_1222 = nil }; var arg_1223 any = c__7; var arg_1224 any = Lit_11; if linked_1221 == nil { arg_1219 = ifn_1222.Invoke_O_O__O(arg_1223, arg_1224) } else { arg_1219 = linked_1221.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1220, arg_1223, arg_1224) }; if linked_1217 == nil { or__1927000174__auto____9 = ifn_1218.Invoke_O__O(arg_1219) } else { or__1927000174__auto____9 = linked_1217.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1216, arg_1219) } } else { or__1927000174__auto____9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____11).Ref() } } else { or__1927000174__auto____9 = and__1927000168__auto____10 } } else { or__1927000174__auto____9 = and__1927000168__auto____9 }; if jrt.J2g_Truth(or__1927000174__auto____9) { and__1927000168__auto____7 = or__1927000174__auto____9 } else {
				var tmp1 any; var root_1225 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_1226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1225, A_arbace_classes_env_info_A_fn_class); var ifn_1227 lang.IFn; if linked_1226 == nil { ifn_1227 = lang.IFn_Cast(root_1225) } else { ifn_1227 = nil }; var arg_1228 any = c__7; if linked_1226 == nil { tmp1 = ifn_1227.Invoke_O__O(arg_1228) } else { tmp1 = linked_1226.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1225, arg_1228) }; and__1927000168__auto____7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(tmp1, x__8)).Ref() }
//line :323:1
			if jrt.J2g_Truth(and__1927000168__auto____7) {




				i__5 = lang.Numbers_Inc_J__J_NoInit(i__5); continue L1 } else {
//line :323:1
					return and__1927000168__auto____7 } } } }; /*line :316:1*/panic("j2g: unreachable") }













func A_arbace_classes_env_infos_now_A_New() *A_arbace_classes_env_infos_now_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_infos_now_A{}; t.Ctor(); return t }
//line :330:1
func (t *A_arbace_classes_env_infos_now_A) Ctor() {}
//line :330:1
func (t *A_arbace_classes_env_infos_now_A) Invoke_O_O__O(self, names__0 any) any { var a__2 any = lang.RT_Object_array_O__O1_NoInit(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(names__0)).Ref()).Ref(); var n__1927000701__auto____3 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_Count_O__I_NoInit(names__0)); var i__4 int64 = 0; L1: for {

	if lang.Numbers_Lt_J_J__Z_NoInit(i__4, n__1927000701__auto____3) { var tmp1 *jrt.RefArray = jrt.J2g_CastArray[*jrt.RefArray](a__2, jrt.Object_class.ArrayClass()); var tmp2 int32 = lang.RT_IntCast_J__I_NoInit(i__4); var tmp3 any; var root_1229 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_1230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1229, A_arbace_classes_env_info_A_fn_class); var ifn_1231 lang.IFn; if linked_1230 == nil { ifn_1231 = lang.IFn_Cast(root_1229) } else { ifn_1231 = nil }; var arg_1232 any = lang.RT_Nth_O_I__O_NoInit(names__0, lang.RT_IntCast_J__I_NoInit(i__4)); if linked_1230 == nil { tmp3 = ifn_1231.Invoke_O__O(arg_1232) } else { tmp3 = linked_1230.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1229, arg_1232) }; lang.RT_Aset_O1_I_O__O_NoInit(tmp1, tmp2, tmp3); i__4 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__4); continue L1 }
//line :330:1
	break L1 }; return a__2 }
















func A_arbace_classes_env_all_supertypes_STAR__A_New() *A_arbace_classes_env_all_supertypes_STAR__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_all_supertypes_STAR__A{}; t.Ctor(); return t }
//line :347:1
func (t *A_arbace_classes_env_all_supertypes_STAR__A) Ctor() {}
//line :347:1
func (t *A_arbace_classes_env_all_supertypes_STAR__A) Invoke_O_O__O(self, n__0 any) any { { var chain__2 any; var root_1233 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_1234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1233, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1235 lang.IFn

	if linked_1234 == nil { ifn_1235 = lang.IFn_Cast(root_1233) } else { ifn_1235 = nil }; var arg_1236 any; var root_1237 any = A_arbace_classes_env_A_const_111.GetRawRoot__O(); var linked_1238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1237, A_arbace_classes_env_superclass_chain_A_fn_class); var ifn_1239 lang.IFn; if linked_1238 == nil { ifn_1239 = lang.IFn_Cast(root_1237) } else { ifn_1239 = nil }; var arg_1240 any = n__0; if linked_1238 == nil { arg_1236 = ifn_1239.Invoke_O__O(arg_1240) } else { arg_1236 = linked_1238.(*A_arbace_classes_env_superclass_chain_A).Invoke_O_O__O(root_1237, arg_1240) }; if linked_1234 == nil { chain__2 = ifn_1235.Invoke_O__O(arg_1236) } else { chain__2 = linked_1234.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1233, arg_1236) }
//line :347:1
	var out__3 any = chain__2; var seen__4 any; var root_1241 any = A_arbace_classes_env_A_const_110.GetRawRoot__O(); var linked_1242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1241, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_1243 lang.IFn


	if linked_1242 == nil { ifn_1243 = lang.IFn_Cast(root_1241) } else { ifn_1243 = nil }; var arg_1244 any = chain__2; if linked_1242 == nil { seen__4 = ifn_1243.Invoke_O__O(arg_1244) } else { seen__4 = linked_1242.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1241, arg_1244) }
//line :347:1
	var queue__5 any; var root_1245 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_1246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1245, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1247 lang.IFn


	if linked_1246 == nil { ifn_1247 = lang.IFn_Cast(root_1245) } else { ifn_1247 = nil }; var arg_1248 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_classes_env_A_const_126.GetRawRoot__O()); var tmp2 any = A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A_New(); var tmp3 *jrt.Class; var fncls__1258 *jrt.Class = A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A_fn_class; if fncls__1258 == nil { var fncls__1258d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A_fn_class = fncls__1258d; tmp3 = fncls__1258d } else { tmp3 = fncls__1258 }; arg_1248 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), chain__2); if linked_1246 == nil { queue__5 = ifn_1247.Invoke_O__O(arg_1248) } else { queue__5 = linked_1246.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1245, arg_1248) }
//line :347:1
L1: for { var temp__1927000408__auto____6 any; var root_1259 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_1260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1259, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1261 lang.IFn



	if linked_1260 == nil { ifn_1261 = lang.IFn_Cast(root_1259) } else { ifn_1261 = nil }; var arg_1262 any = queue__5; if linked_1260 == nil { temp__1927000408__auto____6 = ifn_1261.Invoke_O__O(arg_1262) } else { temp__1927000408__auto____6 = linked_1260.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1259, arg_1262) }; if jrt.J2g_Truth(temp__1927000408__auto____6) { var vec__28000162__7 any = temp__1927000408__auto____6; var seq__28000163__8 any; var root_1263 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_1264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1263, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1265 lang.IFn; if linked_1264 == nil { ifn_1265 = lang.IFn_Cast(root_1263) } else { ifn_1265 = nil }; var arg_1266 any = vec__28000162__7; if linked_1264 == nil { seq__28000163__8 = ifn_1265.Invoke_O__O(arg_1266) } else { seq__28000163__8 = linked_1264.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1263, arg_1266) }; var first__28000164__9 any; var root_1267 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_1268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1267, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1269 lang.IFn; if linked_1268 == nil { ifn_1269 = lang.IFn_Cast(root_1267) } else { ifn_1269 = nil }; var arg_1270 any = seq__28000163__8; if linked_1268 == nil { first__28000164__9 = ifn_1269.Invoke_O__O(arg_1270) } else { first__28000164__9 = linked_1268.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1267, arg_1270) }; var seq__28000163__10 any; var root_1271 any = A_arbace_classes_env_A_const_57.GetRawRoot__O(); var linked_1272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1271, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1273 lang.IFn; if linked_1272 == nil { ifn_1273 = lang.IFn_Cast(root_1271) } else { ifn_1273 = nil }; var arg_1274 any = seq__28000163__8; if linked_1272 == nil { seq__28000163__10 = ifn_1273.Invoke_O__O(arg_1274) } else { seq__28000163__10 = linked_1272.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1271, arg_1274) }; var q__11 any = first__28000164__9; var more__12 any = seq__28000163__10
		if jrt.J2g_Truth(lang.IFn_Cast(seen__4).Invoke_O__O(q__11)) {
			var tmp4 any; var root_1288 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_1289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1288, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1290 lang.IFn; if linked_1289 == nil { ifn_1290 = lang.IFn_Cast(root_1288) } else { ifn_1290 = nil }; var arg_1291 any = more__12; if linked_1289 == nil { tmp4 = ifn_1290.Invoke_O__O(arg_1291) } else { tmp4 = linked_1289.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1288, arg_1291) }; out__3, seen__4, queue__5 = out__3, seen__4, tmp4; continue L1 } else {
				var tmp5 any; var root_1292 any = A_arbace_classes_env_A_const_10.GetRawRoot__O(); var linked_1293 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1292, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1294 lang.IFn; if linked_1293 == nil { ifn_1294 = lang.IFn_Cast(root_1292) } else { ifn_1294 = nil }; var arg_1295 any = out__3; var arg_1296 any = q__11; if linked_1293 == nil { tmp5 = ifn_1294.Invoke_O_O__O(arg_1295, arg_1296) } else { tmp5 = linked_1293.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1292, arg_1295, arg_1296) }; var tmp6 any = tmp5; var tmp7 any; var root_1297 any = A_arbace_classes_env_A_const_10.GetRawRoot__O(); var linked_1298 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1297, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1299 lang.IFn; if linked_1298 == nil { ifn_1299 = lang.IFn_Cast(root_1297) } else { ifn_1299 = nil }; var arg_1300 any = seen__4; var arg_1301 any = q__11; if linked_1298 == nil { tmp7 = ifn_1299.Invoke_O_O__O(arg_1300, arg_1301) } else { tmp7 = linked_1298.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1297, arg_1300, arg_1301) }; var tmp8 any = tmp7; var tmp9 any; var root_1302 any = A_arbace_classes_env_A_const_87.GetRawRoot__O(); var linked_1303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1302, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1304 lang.IFn; if linked_1303 == nil { ifn_1304 = lang.IFn_Cast(root_1302) } else { ifn_1304 = nil }; var arg_1305 any; var root_1307 any = A_arbace_classes_env_A_const_52.GetRawRoot__O(); var linked_1308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1307, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1309 lang.IFn; if linked_1308 == nil { ifn_1309 = lang.IFn_Cast(root_1307) } else { ifn_1309 = nil }; var arg_1310 any = more__12; if linked_1308 == nil { arg_1305 = ifn_1309.Invoke_O__O(arg_1310) } else { arg_1305 = linked_1308.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1307, arg_1310) }; var arg_1306 any; var tmp10 *lang.Keyword = A_arbace_classes_env_A_const_46; var tmp11 any; var root_1311 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_1312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1311, A_arbace_classes_env_info_A_fn_class); var ifn_1313 lang.IFn; if linked_1312 == nil { ifn_1313 = lang.IFn_Cast(root_1311) } else { ifn_1313 = nil }; var arg_1314 any = q__11; if linked_1312 == nil { tmp11 = ifn_1313.Invoke_O__O(arg_1314) } else { tmp11 = linked_1312.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1311, arg_1314) }; arg_1306 = tmp10.Invoke_O__O(tmp11); if linked_1303 == nil { tmp9 = ifn_1304.Invoke_O_O__O(arg_1305, arg_1306) } else { tmp9 = linked_1303.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1302, arg_1305, arg_1306) }; out__3, seen__4, queue__5 = tmp6, tmp8, tmp9; continue L1 } } else {
//line :351:1
					var G__28000165__7_ any = out__3; var tmp12 any; var and__1927000168__auto____8 any; var root_1275 any = A_arbace_classes_env_A_const_109.GetRawRoot__O(); var linked_1276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1275, A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_1277 lang.IFn



					if linked_1276 == nil { ifn_1277 = lang.IFn_Cast(root_1275) } else { ifn_1277 = nil }; var arg_1278 any = n__0; if linked_1276 == nil { and__1927000168__auto____8 = ifn_1277.Invoke_O__O(arg_1278) } else { and__1927000168__auto____8 = linked_1276.(*A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_1275, arg_1278) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var root_1279 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1279, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1281 lang.IFn; if linked_1280 == nil { ifn_1281 = lang.IFn_Cast(root_1279) } else { ifn_1281 = nil }; var arg_1282 any = lang.IFn_Cast(seen__4).Invoke_O__O(Lit_4); if linked_1280 == nil { tmp12 = ifn_1281.Invoke_O__O(arg_1282) } else { tmp12 = linked_1280.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1279, arg_1282) } } else { tmp12 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp12) { var root_1283 any = A_arbace_classes_env_A_const_10.GetRawRoot__O(); var linked_1284 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1283, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1285 lang.IFn; if linked_1284 == nil { ifn_1285 = lang.IFn_Cast(root_1283) } else { ifn_1285 = nil }; var arg_1286 any = G__28000165__7_; var arg_1287 any = Lit_4; if linked_1284 == nil { return ifn_1285.Invoke_O_O__O(arg_1286, arg_1287) } else { return linked_1284.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1283, arg_1286, arg_1287) } } else { return G__28000165__7_ } } } }; /*line :347:1*/panic("j2g: unreachable") }


func A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A_New() *A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A{}; t.Ctor(); return t }
//line :350:1
func (t *A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A) Ctor() {}
//line :350:1
func (t *A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A) Invoke_O_O__O(self, p1__28000159_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_classes_env_A_const_46; var tmp2 any; var root_1254 any = A_arbace_classes_env_A_const_93.GetRawRoot__O(); var linked_1255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1254, A_arbace_classes_env_info_A_fn_class); var ifn_1256 lang.IFn; if linked_1255 == nil { ifn_1256 = lang.IFn_Cast(root_1254) } else { ifn_1256 = nil }; var arg_1257 any = p1__28000159_SHARP___1; if linked_1255 == nil { tmp2 = ifn_1256.Invoke_O__O(arg_1257) } else { tmp2 = linked_1255.(*A_arbace_classes_env_info_A).Invoke_O_O__O(root_1254, arg_1257) }; return tmp1.Invoke_O__O(tmp2) }






func A_arbace_classes_env_all_supertypes_A_New() *A_arbace_classes_env_all_supertypes_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_all_supertypes_A{}; t.Ctor(); return t }
//line :357:1
func (t *A_arbace_classes_env_all_supertypes_A) Ctor() {}
//line :357:1
func (t *A_arbace_classes_env_all_supertypes_A) Invoke_O_O__O(self, n__0 any) any { var e__2 any; if


	jrt.J2g_Truth(n__0) { e__2 = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_127.GetRawRoot__O())).Get_O__O(n__0) } else { e__2 = nil }; var tmp1 any; var and__1927000168__auto____3 any = e__2; if
	jrt.J2g_Truth(and__1927000168__auto____3) { var root_1315 any = A_arbace_classes_env_A_const_128.GetRawRoot__O(); var linked_1316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1315, A_arbace_classes_env_same_infos_QMARK__A_fn_class); var ifn_1317 lang.IFn; if linked_1316 == nil { ifn_1317 = lang.IFn_Cast(root_1315) } else { ifn_1317 = nil }; var arg_1318 any = lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](e__2, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0)); var arg_1319 any = lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](e__2, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(1)); if linked_1316 == nil { tmp1 = ifn_1317.Invoke_O_O__O(arg_1318, arg_1319) } else { tmp1 = linked_1316.(*A_arbace_classes_env_same_infos_QMARK__A).Invoke_O_O_O__O(root_1315, arg_1318, arg_1319) } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		return lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](e__2, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0)) } else {
//line :361:1
			var r__3 any; var root_1320 any = A_arbace_classes_env_A_const_129.GetRawRoot__O(); var linked_1321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1320, A_arbace_classes_env_all_supertypes_STAR__A_fn_class); var ifn_1322 lang.IFn

			if linked_1321 == nil { ifn_1322 = lang.IFn_Cast(root_1320) } else { ifn_1322 = nil }; var arg_1323 any = n__0; if linked_1321 == nil { r__3 = ifn_1322.Invoke_O__O(arg_1323) } else { r__3 = linked_1321.(*A_arbace_classes_env_all_supertypes_STAR__A).Invoke_O_O__O(root_1320, arg_1323) }
//line :361:1
			var infos__4 any; var root_1324 any = A_arbace_classes_env_A_const_130.GetRawRoot__O(); var linked_1325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1324, A_arbace_classes_env_infos_now_A_fn_class); var ifn_1326 lang.IFn


			if linked_1325 == nil { ifn_1326 = lang.IFn_Cast(root_1324) } else { ifn_1326 = nil }; var arg_1327 any = r__3; if linked_1325 == nil { infos__4 = ifn_1326.Invoke_O__O(arg_1327) } else { infos__4 = linked_1325.(*A_arbace_classes_env_infos_now_A).Invoke_O_O__O(root_1324, arg_1327)
			}
			var tmp2 any; var and__1927000168__auto____5 any = n__0; if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp3 any; var root_1328 any = A_arbace_classes_env_A_const_129.GetRawRoot__O(); var linked_1329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1328, A_arbace_classes_env_all_supertypes_STAR__A_fn_class); var ifn_1330 lang.IFn; if linked_1329 == nil { ifn_1330 = lang.IFn_Cast(root_1328) } else { ifn_1330 = nil }; var arg_1331 any = n__0; if linked_1329 == nil { tmp3 = ifn_1330.Invoke_O__O(arg_1331) } else { tmp3 = linked_1329.(*A_arbace_classes_env_all_supertypes_STAR__A).Invoke_O_O__O(root_1328, arg_1331) }; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(r__3, tmp3)).Ref() } else { tmp2 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp2) {
				jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_127.GetRawRoot__O())).Put_O_O__O(n__0, lang.RT_Object_array_O__O1_NoInit(lang.Tuple_Create_O_O__IPersistentVector(r__3, infos__4)).Ref()) }
//line :361:1
			return r__3 } }








func A_arbace_classes_env_params_key_A_New() *A_arbace_classes_env_params_key_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_params_key_A{}; t.Ctor(); return t }
//line :370:1
func (t *A_arbace_classes_env_params_key_A) Ctor() {}
//line :370:1
func (t *A_arbace_classes_env_params_key_A) Invoke_O_O__O(self, desc__0 any) any { var root_1332 any = A_arbace_classes_env_A_const_131.GetRawRoot__O(); var linked_1333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1332, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1334 lang.IFn; if linked_1333 == nil { ifn_1334 = lang.IFn_Cast(root_1332) } else { ifn_1334 = nil }; var arg_1335 any = desc__0; var arg_1336 any = A_arbace_classes_env_A_const_132; var arg_1337 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(jrt.NN(jrt.String_Cast(desc__0)).IndexOf_String__I(Lit_30)))).Ref(); if linked_1333 == nil { return ifn_1334.Invoke_O_O_O__O(arg_1335, arg_1336, arg_1337) } else { return linked_1333.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1332, arg_1335, arg_1336, arg_1337) } }

func A_arbace_classes_env_member_methods_STAR__A_New() *A_arbace_classes_env_member_methods_STAR__A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_member_methods_STAR__A{}; t.Ctor(); return t }
//line :372:1
func (t *A_arbace_classes_env_member_methods_STAR__A) Ctor() {}
//line :372:1
func (t *A_arbace_classes_env_member_methods_STAR__A) Invoke_O_O_O_O__O(self, n__0, name__1, sups__2 any) any { { var G__28000172__4_ any = sups__2; var vec__28000173__5 any = G__28000172__4_; var seq__28000174__6 any; var root_1338 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_1339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1338, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1340 lang.IFn

	if linked_1339 == nil { ifn_1340 = lang.IFn_Cast(root_1338) } else { ifn_1340 = nil }; var arg_1341 any = vec__28000173__5; if linked_1339 == nil { seq__28000174__6 = ifn_1340.Invoke_O__O(arg_1341) } else { seq__28000174__6 = linked_1339.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1338, arg_1341) }
//line :372:1
	var first__28000175__7 any; var root_1342 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_1343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1342, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1344 lang.IFn

	if linked_1343 == nil { ifn_1344 = lang.IFn_Cast(root_1342) } else { ifn_1344 = nil }; var arg_1345 any = seq__28000174__6; if linked_1343 == nil { first__28000175__7 = ifn_1344.Invoke_O__O(arg_1345) } else { first__28000175__7 = linked_1343.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1342, arg_1345) }
//line :372:1
	var seq__28000174__8 any; var root_1346 any = A_arbace_classes_env_A_const_57.GetRawRoot__O(); var linked_1347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1346, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1348 lang.IFn

	if linked_1347 == nil { ifn_1348 = lang.IFn_Cast(root_1346) } else { ifn_1348 = nil }; var arg_1349 any = seq__28000174__6; if linked_1347 == nil { seq__28000174__8 = ifn_1348.Invoke_O__O(arg_1349) } else { seq__28000174__8 = linked_1347.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1346, arg_1349) }
//line :372:1
	var c__9 any = first__28000175__7; var more__10 any = seq__28000174__8; var seen__11 any = lang.PersistentHashSet_EMPTY.Ref(); var out__12 any = lang.PersistentVector_EMPTY.Ref(); var G__28000172__13_ any = G__28000172__4_; var seen__14 any = seen__11; var out__15 any = out__12; _ = c__9; _ = more__10; L1: for { var vec__28000176__16 any = G__28000172__13_; var seq__28000177__17 any; var root_1350 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_1351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1350, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1352 lang.IFn

		if linked_1351 == nil { ifn_1352 = lang.IFn_Cast(root_1350) } else { ifn_1352 = nil }; var arg_1353 any = vec__28000176__16; if linked_1351 == nil { seq__28000177__17 = ifn_1352.Invoke_O__O(arg_1353) } else { seq__28000177__17 = linked_1351.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1350, arg_1353) }
//line :372:1
		var first__28000178__18 any; var root_1354 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_1355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1354, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1356 lang.IFn

		if linked_1355 == nil { ifn_1356 = lang.IFn_Cast(root_1354) } else { ifn_1356 = nil }; var arg_1357 any = seq__28000177__17; if linked_1355 == nil { first__28000178__18 = ifn_1356.Invoke_O__O(arg_1357) } else { first__28000178__18 = linked_1355.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1354, arg_1357) }
//line :372:1
		var seq__28000177__19 any; var root_1358 any = A_arbace_classes_env_A_const_57.GetRawRoot__O(); var linked_1359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1358, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1360 lang.IFn

		if linked_1359 == nil { ifn_1360 = lang.IFn_Cast(root_1358) } else { ifn_1360 = nil }; var arg_1361 any = seq__28000177__17; if linked_1359 == nil { seq__28000177__19 = ifn_1360.Invoke_O__O(arg_1361) } else { seq__28000177__19 = linked_1359.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1358, arg_1361) }
//line :372:1
		var c__20 any = first__28000178__18; var more__21 any = seq__28000177__19; var seen__22 any = seen__14; var out__23 any = out__15; var tmp1 any; var root_1362 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1362, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1364 lang.IFn


		if linked_1363 == nil { ifn_1364 = lang.IFn_Cast(root_1362) } else { ifn_1364 = nil }; var arg_1365 any = c__20; if linked_1363 == nil { tmp1 = ifn_1364.Invoke_O__O(arg_1365) } else { tmp1 = linked_1363.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1362, arg_1365) }; if jrt.J2g_Truth(tmp1) { return out__23 } else { var ms__24 any; var iter__1927001039__auto____24 any; var tmp2 any = A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A_New_O_O_O_O(seen__22, name__1, n__0, c__20); var tmp3 *jrt.Class
			var fncls__1530 /*line :375:1*/*jrt.Class = A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A_fn_class

			if fncls__1530 == nil { var fncls__1530d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A_fn_class = fncls__1530d; tmp3 = fncls__1530d } else { tmp3 = fncls__1530 }; iter__1927001039__auto____24 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp4 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____24); var tmp5 *lang.Keyword = A_arbace_classes_env_A_const_76; var tmp6 any; var root_1531 any = A_arbace_classes_env_A_const_95.GetRawRoot__O(); var linked_1532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1531, A_arbace_classes_env_info_BANG__A_fn_class); var ifn_1533 lang.IFn; if linked_1532 == nil { ifn_1533 = lang.IFn_Cast(root_1531) } else { ifn_1533 = nil }; var arg_1534 any = c__20; if linked_1532 == nil { tmp6 = ifn_1533.Invoke_O__O(arg_1534) } else { tmp6 = linked_1532.(*A_arbace_classes_env_info_BANG__A).Invoke_O_O__O(root_1531, arg_1534) }; ms__24 = tmp4.Invoke_O__O(tmp5.Invoke_O__O(tmp6))






			var tmp7 any; var root_1535 any = A_arbace_classes_env_A_const_87.GetRawRoot__O(); var linked_1536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1535, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1537 lang.IFn; if linked_1536 == nil { ifn_1537 = lang.IFn_Cast(root_1535) } else { ifn_1537 = nil }; var arg_1538 any = seen__22; var arg_1539 any; var root_1540 any = A_arbace_classes_env_A_const_79.GetRawRoot__O(); var linked_1541 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1540, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1542 lang.IFn; if linked_1541 == nil { ifn_1542 = lang.IFn_Cast(root_1540) } else { ifn_1542 = nil }; var arg_1543 any; var root_1545 any = A_arbace_classes_env_A_const_136.GetRawRoot__O(); var linked_1546 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1545, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_1547 lang.IFn; if linked_1546 == nil { ifn_1547 = lang.IFn_Cast(root_1545) } else { ifn_1547 = nil }; var arg_1548 any = A_arbace_classes_env_A_const_135.GetRawRoot__O(); var arg_1549 any = A_arbace_classes_env_A_const_60; if linked_1546 == nil { arg_1543 = ifn_1547.Invoke_O_O__O(arg_1548, arg_1549) } else { arg_1543 = linked_1546.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_1545, arg_1548, arg_1549) }; var arg_1544 any = ms__24; if linked_1541 == nil { arg_1539 = ifn_1542.Invoke_O_O__O(arg_1543, arg_1544) } else { arg_1539 = linked_1541.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1540, arg_1543, arg_1544) }; if linked_1536 == nil { tmp7 = ifn_1537.Invoke_O_O__O(arg_1538, arg_1539) } else { tmp7 = linked_1536.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1535, arg_1538, arg_1539) }; var tmp8 any = tmp7; var tmp9 any; var root_1550 any = A_arbace_classes_env_A_const_87.GetRawRoot__O(); var linked_1551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1550, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1552 lang.IFn; if linked_1551 == nil { ifn_1552 = lang.IFn_Cast(root_1550) } else { ifn_1552 = nil }; var arg_1553 any = out__23; var arg_1554 any = ms__24; if linked_1551 == nil { tmp9 = ifn_1552.Invoke_O_O__O(arg_1553, arg_1554) } else { tmp9 = linked_1551.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1550, arg_1553, arg_1554) }; G__28000172__13_, seen__14, out__15 = more__21, tmp8, tmp9; continue L1 } } }; /*line :372:1*/panic("j2g: unreachable") }




func A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :377:1
func (t *A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A) Ctor_O_O_O_O(c__seen, c__name, c__n, c__c any) { t.F_seen = c__seen; t.F_name = c__name; t.F_n = c__n; t.F_c = c__c }
//line :377:1
func (t *A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A) Invoke_O_O__O(self, s__28000180__1 any) any { var tmp1 any = A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A_New_O_O_O_O_O_O(self, t.F_seen, t.F_name, t.F_n, t.F_c, s__28000180__1); var tmp2 *jrt.Class; var fncls__1529 *jrt.Class = A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A_fn_class; if fncls__1529 == nil { var fncls__1529d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A_fn_class = fncls__1529d; tmp2 = fncls__1529d } else { tmp2 = fncls__1529 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :377:1
func A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :377:1
func (t *A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A) Ctor_O_O_O_O_O_O(c__iter__28000179, c__seen, c__name, c__n, c__c, c__s__28000180 any) { t.F_iter__28000179 = c__iter__28000179; t.F_seen = c__seen; t.F_name = c__name; t.F_n = c__n; t.F_c = c__c; t.F_s__28000180 = c__s__28000180 }
//line :377:1
func (t *A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A) Invoke_O__O(self any) any { { var s__28000180__1 any; var t_ any = t.F_s__28000180; t.F_s__28000180 = nil; s__28000180__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1366 any = A_arbace_classes_env_A_const_53.GetRawRoot__O(); var linked_1367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1366, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1368 lang.IFn; if linked_1367 == nil { ifn_1368 = lang.IFn_Cast(root_1366) } else { ifn_1368 = nil }; var arg_1369 any = s__28000180__1; if linked_1367 == nil { temp__1927000414__auto____2 = ifn_1368.Invoke_O__O(arg_1369) } else { temp__1927000414__auto____2 = linked_1367.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1366, arg_1369) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__28000180__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1370 any = A_arbace_classes_env_A_const_54.GetRawRoot__O(); var linked_1371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1370, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1372 lang.IFn; if linked_1371 == nil { ifn_1372 = lang.IFn_Cast(root_1370) } else { ifn_1372 = nil }; var arg_1373 any = s__28000180__3; if linked_1371 == nil { tmp1 = ifn_1372.Invoke_O__O(arg_1373) } else { tmp1 = linked_1371.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1370, arg_1373) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1374 any = A_arbace_classes_env_A_const_55.GetRawRoot__O(); var linked_1375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1374, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1376 lang.IFn; if linked_1375 == nil { ifn_1376 = lang.IFn_Cast(root_1374) } else { ifn_1376 = nil }; var arg_1377 any = s__28000180__3; if linked_1375 == nil { c__1927001037__auto____4 = ifn_1376.Invoke_O__O(arg_1377) } else { c__1927001037__auto____4 = linked_1375.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1374, arg_1377) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__28000182__6 any; var root_1378 any = A_arbace_classes_env_A_const_56.GetRawRoot__O(); var linked_1379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1378, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1380 lang.IFn; if linked_1379 == nil { ifn_1380 = lang.IFn_Cast(root_1378) } else { ifn_1380 = nil }; var arg_1381 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1379 == nil { b__28000182__6 = ifn_1380.Invoke_O__O(arg_1381) } else { b__28000182__6 = linked_1379.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1378, arg_1381) }; var tmp2 any = A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A_New_O_O_O_O_I_O_O(t.F_seen, t.F_name, t.F_n, t.F_c, size__1927001038__auto____5, b__28000182__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1430 *jrt.Class = A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A_fn_class; if fncls__1430 == nil { var fncls__1430d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A_fn_class = fncls__1430d; tmp3 = fncls__1430d } else { tmp3 = fncls__1430 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1431 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_1432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1431, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1433 lang.IFn; if linked_1432 == nil { ifn_1433 = lang.IFn_Cast(root_1431) } else { ifn_1433 = nil }; var arg_1434 any; var root_1436 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_1437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1436, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1438 lang.IFn; if linked_1437 == nil { ifn_1438 = lang.IFn_Cast(root_1436) } else { ifn_1438 = nil }; var arg_1439 any = b__28000182__6; if linked_1437 == nil { arg_1434 = ifn_1438.Invoke_O__O(arg_1439) } else { arg_1434 = linked_1437.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1436, arg_1439) }; var arg_1435 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__28000179); var tmp5 any; var root_1440 any = A_arbace_classes_env_A_const_70.GetRawRoot__O(); var linked_1441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1440, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1442 lang.IFn; if linked_1441 == nil { ifn_1442 = lang.IFn_Cast(root_1440) } else { ifn_1442 = nil }; var arg_1443 any = s__28000180__3; if linked_1441 == nil { tmp5 = ifn_1442.Invoke_O__O(arg_1443) } else { tmp5 = linked_1441.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1440, arg_1443) }; arg_1435 = tmp4.Invoke_O__O(tmp5); if linked_1432 == nil { return ifn_1433.Invoke_O_O__O(arg_1434, arg_1435) } else { return linked_1432.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1431, arg_1434, arg_1435) } } else { var root_1444 any = A_arbace_classes_env_A_const_68.GetRawRoot__O(); var linked_1445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1444, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1446 lang.IFn; if linked_1445 == nil { ifn_1446 = lang.IFn_Cast(root_1444) } else { ifn_1446 = nil }; var arg_1447 any; var root_1449 any = A_arbace_classes_env_A_const_69.GetRawRoot__O(); var linked_1450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1449, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1451 lang.IFn; if linked_1450 == nil { ifn_1451 = lang.IFn_Cast(root_1449) } else { ifn_1451 = nil }; var arg_1452 any = b__28000182__6; if linked_1450 == nil { arg_1447 = ifn_1451.Invoke_O__O(arg_1452) } else { arg_1447 = linked_1450.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1449, arg_1452) }; var arg_1448 any; if linked_1445 == nil { return ifn_1446.Invoke_O_O__O(arg_1447, arg_1448) } else { return linked_1445.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1444, arg_1447, arg_1448) } } } else { var m__4 any; var root_1453 any = A_arbace_classes_env_A_const_59.GetRawRoot__O(); var linked_1454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1453, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1455 lang.IFn; if linked_1454 == nil { ifn_1455 = lang.IFn_Cast(root_1453) } else { ifn_1455 = nil }; var arg_1456 any = s__28000180__3; if linked_1454 == nil { m__4 = ifn_1455.Invoke_O__O(arg_1456) } else { m__4 = linked_1454.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1453, arg_1456) }; var tmp6 any = t.F_name; if lang.Util_Equiv_O_O__Z_NoInit(tmp6, A_arbace_classes_env_A_const_42.Invoke_O__O(m__4)) { var tmp7 any; var root_1457 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1457, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1459 lang.IFn

	if linked_1458 == nil { ifn_1459 = lang.IFn_Cast(root_1457) } else { ifn_1459 = nil }; var arg_1460 any; var root_1461 any = A_arbace_classes_env_A_const_120.GetRawRoot__O(); var linked_1462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1461, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1463 lang.IFn; if linked_1462 == nil { ifn_1463 = lang.IFn_Cast(root_1461) } else { ifn_1463 = nil }; var arg_1464 any = A_arbace_classes_env_A_const_43.Invoke_O__O(m__4); var arg_1465 any = A_arbace_classes_env_A_const_133; if linked_1462 == nil { arg_1460 = ifn_1463.Invoke_O_O__O(arg_1464, arg_1465) } else { arg_1460 = linked_1462.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1461, arg_1464, arg_1465) }; if linked_1458 == nil { tmp7 = ifn_1459.Invoke_O__O(arg_1460) } else { tmp7 = linked_1458.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1457, arg_1460) }
//line :377:1
	if jrt.J2g_Truth(tmp7) { var tmp8 any; var or__1927000174__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(t.F_c, t.F_n)


		if or__1927000174__auto____5 { tmp8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var root_1466 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1466, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1468 lang.IFn; if linked_1467 == nil { ifn_1468 = lang.IFn_Cast(root_1466) } else { ifn_1468 = nil }; var arg_1469 any; var root_1470 any = A_arbace_classes_env_A_const_120.GetRawRoot__O(); var linked_1471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1470, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1472 lang.IFn; if linked_1471 == nil { ifn_1472 = lang.IFn_Cast(root_1470) } else { ifn_1472 = nil }; var arg_1473 any = A_arbace_classes_env_A_const_43.Invoke_O__O(m__4); var arg_1474 any = A_arbace_classes_env_A_const_122; if linked_1471 == nil { arg_1469 = ifn_1472.Invoke_O_O__O(arg_1473, arg_1474) } else { arg_1469 = linked_1471.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1470, arg_1473, arg_1474) }; if linked_1467 == nil { tmp8 = ifn_1468.Invoke_O__O(arg_1469) } else { tmp8 = linked_1467.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1466, arg_1469) } }
//line :377:1
		if jrt.J2g_Truth(tmp8) { var tmp9 any; var or__1927000174__auto____5_2 bool = lang.Util_Equiv_O_O__Z_NoInit(t.F_c, t.F_n)



			if or__1927000174__auto____5_2 { tmp9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5_2).Ref() } else { var or__1927000174__auto____6 any; var root_1475 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1475, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1477 lang.IFn; if linked_1476 == nil { ifn_1477 = lang.IFn_Cast(root_1475) } else { ifn_1477 = nil }; var arg_1478 any; var root_1479 any = A_arbace_classes_env_A_const_109.GetRawRoot__O(); var linked_1480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1479, A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_1481 lang.IFn; if linked_1480 == nil { ifn_1481 = lang.IFn_Cast(root_1479) } else { ifn_1481 = nil }; var arg_1482 any = t.F_c; if linked_1480 == nil { arg_1478 = ifn_1481.Invoke_O__O(arg_1482) } else { arg_1478 = linked_1480.(*A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_1479, arg_1482) }; if linked_1476 == nil { or__1927000174__auto____6 = ifn_1477.Invoke_O__O(arg_1478) } else { or__1927000174__auto____6 = linked_1476.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1475, arg_1478) }; if jrt.J2g_Truth(or__1927000174__auto____6) { tmp9 = or__1927000174__auto____6 } else { var root_1483 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1483, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1485 lang.IFn; if linked_1484 == nil { ifn_1485 = lang.IFn_Cast(root_1483) } else { ifn_1485 = nil }; var arg_1486 any; var root_1487 any = A_arbace_classes_env_A_const_120.GetRawRoot__O(); var linked_1488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1487, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1489 lang.IFn; if linked_1488 == nil { ifn_1489 = lang.IFn_Cast(root_1487) } else { ifn_1489 = nil }; var arg_1490 any = A_arbace_classes_env_A_const_43.Invoke_O__O(m__4); var arg_1491 any = A_arbace_classes_env_A_const_134; if linked_1488 == nil { arg_1486 = ifn_1489.Invoke_O_O__O(arg_1490, arg_1491) } else { arg_1486 = linked_1488.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1487, arg_1490, arg_1491) }; if linked_1484 == nil { tmp9 = ifn_1485.Invoke_O__O(arg_1486) } else { tmp9 = linked_1484.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1483, arg_1486) } } }
//line :377:1
			if jrt.J2g_Truth(tmp9) { var tmp10 any; var root_1492 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1492, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1494 lang.IFn




				if linked_1493 == nil { ifn_1494 = lang.IFn_Cast(root_1492) } else { ifn_1494 = nil }; var arg_1495 any; var tmp11 lang.IFn = lang.IFn_Cast(t.F_seen); var tmp12 any; var root_1496 any = A_arbace_classes_env_A_const_135.GetRawRoot__O(); var linked_1497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1496, A_arbace_classes_env_params_key_A_fn_class); var ifn_1498 lang.IFn; if linked_1497 == nil { ifn_1498 = lang.IFn_Cast(root_1496) } else { ifn_1498 = nil }; var arg_1499 any = A_arbace_classes_env_A_const_60.Invoke_O__O(m__4); if linked_1497 == nil { tmp12 = ifn_1498.Invoke_O__O(arg_1499) } else { tmp12 = linked_1497.(*A_arbace_classes_env_params_key_A).Invoke_O_O__O(root_1496, arg_1499) }; arg_1495 = tmp11.Invoke_O__O(tmp12); if linked_1493 == nil { tmp10 = ifn_1494.Invoke_O__O(arg_1495) } else { tmp10 = linked_1493.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1492, arg_1495) }
//line :377:1
				if jrt.J2g_Truth(tmp10) { var root_1500 any = A_arbace_classes_env_A_const_71.GetRawRoot__O(); var linked_1501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1500, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1502 lang.IFn; if linked_1501 == nil { ifn_1502 = lang.IFn_Cast(root_1500) } else { ifn_1502 = nil }; var arg_1503 any = m__4; var arg_1504 any; var tmp13 lang.IFn = lang.IFn_Cast(t.F_iter__28000179); var tmp14 any; var root_1505 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_1506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1505, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1507 lang.IFn; if linked_1506 == nil { ifn_1507 = lang.IFn_Cast(root_1505) } else { ifn_1507 = nil }; var arg_1508 any = s__28000180__3; if linked_1506 == nil { tmp14 = ifn_1507.Invoke_O__O(arg_1508) } else { tmp14 = linked_1506.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1505, arg_1508) }; arg_1504 = tmp13.Invoke_O__O(tmp14); if linked_1501 == nil { return ifn_1502.Invoke_O_O__O(arg_1503, arg_1504) } else { return linked_1501.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1500, arg_1503, arg_1504) } } else { var tmp15 any; var root_1509 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_1510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1509, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1511 lang.IFn; if linked_1510 == nil { ifn_1511 = lang.IFn_Cast(root_1509) } else { ifn_1511 = nil }; var arg_1512 any = s__28000180__3; if linked_1510 == nil { tmp15 = ifn_1511.Invoke_O__O(arg_1512) } else { tmp15 = linked_1510.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1509, arg_1512) }; s__28000180__1 = tmp15; continue L1 } } else { var tmp16 any; var root_1513 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_1514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1513, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1515 lang.IFn; if linked_1514 == nil { ifn_1515 = lang.IFn_Cast(root_1513) } else { ifn_1515 = nil }; var arg_1516 any = s__28000180__3; if linked_1514 == nil { tmp16 = ifn_1515.Invoke_O__O(arg_1516) } else { tmp16 = linked_1514.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1513, arg_1516) }; s__28000180__1 = tmp16; continue L1 } } else { var tmp17 any; var root_1517 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_1518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1517, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1519 lang.IFn; if linked_1518 == nil { ifn_1519 = lang.IFn_Cast(root_1517) } else { ifn_1519 = nil }; var arg_1520 any = s__28000180__3; if linked_1518 == nil { tmp17 = ifn_1519.Invoke_O__O(arg_1520) } else { tmp17 = linked_1518.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1517, arg_1520) }; s__28000180__1 = tmp17; continue L1 } } else { var tmp18 any; var root_1521 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_1522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1521, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1523 lang.IFn; if linked_1522 == nil { ifn_1523 = lang.IFn_Cast(root_1521) } else { ifn_1523 = nil }; var arg_1524 any = s__28000180__3; if linked_1522 == nil { tmp18 = ifn_1523.Invoke_O__O(arg_1524) } else { tmp18 = linked_1522.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1521, arg_1524) }; s__28000180__1 = tmp18; continue L1 } } else { var tmp19 any; var root_1525 any = A_arbace_classes_env_A_const_72.GetRawRoot__O(); var linked_1526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1525, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1527 lang.IFn; if linked_1526 == nil { ifn_1527 = lang.IFn_Cast(root_1525) } else { ifn_1527 = nil }; var arg_1528 any = s__28000180__3; if linked_1526 == nil { tmp19 = ifn_1527.Invoke_O__O(arg_1528) } else { tmp19 = linked_1526.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1525, arg_1528) }; s__28000180__1 = tmp19; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :377:1
func A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A_New_O_O_O_O_I_O_O(p0, p1, p2, p3 any, p4 int32, p5, p6 any) *A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A{}; t.Ctor_O_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :377:1
func (t *A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A) Ctor_O_O_O_O_I_O_O(c__seen, c__name, c__n, c__c any, c__size__1927001038__auto__ int32, c__b__28000182, c__c__1927001037__auto__ any) { t.F_seen = c__seen; t.F_name = c__name; t.F_n = c__n; t.F_c = c__c; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__28000182 = c__b__28000182; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :377:1
func (t *A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A) Invoke_O__O(self any) any { { var i__28000181__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__28000181__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__28000181__1)); var tmp2 any = t.F_name; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_classes_env_A_const_42.Invoke_O__O(m__2)) { var tmp3 any; var root_1382 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1382, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1384 lang.IFn

	if linked_1383 == nil { ifn_1384 = lang.IFn_Cast(root_1382) } else { ifn_1384 = nil }; var arg_1385 any; var root_1386 any = A_arbace_classes_env_A_const_120.GetRawRoot__O(); var linked_1387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1386, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1388 lang.IFn; if linked_1387 == nil { ifn_1388 = lang.IFn_Cast(root_1386) } else { ifn_1388 = nil }; var arg_1389 any = A_arbace_classes_env_A_const_43.Invoke_O__O(m__2); var arg_1390 any = A_arbace_classes_env_A_const_133; if linked_1387 == nil { arg_1385 = ifn_1388.Invoke_O_O__O(arg_1389, arg_1390) } else { arg_1385 = linked_1387.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1386, arg_1389, arg_1390) }; if linked_1383 == nil { tmp3 = ifn_1384.Invoke_O__O(arg_1385) } else { tmp3 = linked_1383.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1382, arg_1385) }
//line :377:1
	if jrt.J2g_Truth(tmp3) { var tmp4 any; var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(t.F_c, t.F_n)


		if or__1927000174__auto____3 { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var root_1391 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1391, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1393 lang.IFn; if linked_1392 == nil { ifn_1393 = lang.IFn_Cast(root_1391) } else { ifn_1393 = nil }; var arg_1394 any; var root_1395 any = A_arbace_classes_env_A_const_120.GetRawRoot__O(); var linked_1396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1395, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1397 lang.IFn; if linked_1396 == nil { ifn_1397 = lang.IFn_Cast(root_1395) } else { ifn_1397 = nil }; var arg_1398 any = A_arbace_classes_env_A_const_43.Invoke_O__O(m__2); var arg_1399 any = A_arbace_classes_env_A_const_122; if linked_1396 == nil { arg_1394 = ifn_1397.Invoke_O_O__O(arg_1398, arg_1399) } else { arg_1394 = linked_1396.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1395, arg_1398, arg_1399) }; if linked_1392 == nil { tmp4 = ifn_1393.Invoke_O__O(arg_1394) } else { tmp4 = linked_1392.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1391, arg_1394) } }
//line :377:1
		if jrt.J2g_Truth(tmp4) { var tmp5 any; var or__1927000174__auto____3_2 bool = lang.Util_Equiv_O_O__Z_NoInit(t.F_c, t.F_n)



			if or__1927000174__auto____3_2 { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3_2).Ref() } else { var or__1927000174__auto____4 any; var root_1400 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1400, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1402 lang.IFn; if linked_1401 == nil { ifn_1402 = lang.IFn_Cast(root_1400) } else { ifn_1402 = nil }; var arg_1403 any; var root_1404 any = A_arbace_classes_env_A_const_109.GetRawRoot__O(); var linked_1405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1404, A_arbace_classes_env_interface_QMARK__A_fn_class); var ifn_1406 lang.IFn; if linked_1405 == nil { ifn_1406 = lang.IFn_Cast(root_1404) } else { ifn_1406 = nil }; var arg_1407 any = t.F_c; if linked_1405 == nil { arg_1403 = ifn_1406.Invoke_O__O(arg_1407) } else { arg_1403 = linked_1405.(*A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(root_1404, arg_1407) }; if linked_1401 == nil { or__1927000174__auto____4 = ifn_1402.Invoke_O__O(arg_1403) } else { or__1927000174__auto____4 = linked_1401.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1400, arg_1403) }; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp5 = or__1927000174__auto____4 } else { var root_1408 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1408, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1410 lang.IFn; if linked_1409 == nil { ifn_1410 = lang.IFn_Cast(root_1408) } else { ifn_1410 = nil }; var arg_1411 any; var root_1412 any = A_arbace_classes_env_A_const_120.GetRawRoot__O(); var linked_1413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1412, A_arbace_classes_env_flag_QMARK__A_fn_class); var ifn_1414 lang.IFn; if linked_1413 == nil { ifn_1414 = lang.IFn_Cast(root_1412) } else { ifn_1414 = nil }; var arg_1415 any = A_arbace_classes_env_A_const_43.Invoke_O__O(m__2); var arg_1416 any = A_arbace_classes_env_A_const_134; if linked_1413 == nil { arg_1411 = ifn_1414.Invoke_O_O__O(arg_1415, arg_1416) } else { arg_1411 = linked_1413.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(root_1412, arg_1415, arg_1416) }; if linked_1409 == nil { tmp5 = ifn_1410.Invoke_O__O(arg_1411) } else { tmp5 = linked_1409.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1408, arg_1411) } } }
//line :377:1
			if jrt.J2g_Truth(tmp5) { var tmp6 any; var root_1417 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1417, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1419 lang.IFn




				if linked_1418 == nil { ifn_1419 = lang.IFn_Cast(root_1417) } else { ifn_1419 = nil }; var arg_1420 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_seen); var tmp8 any; var root_1421 any = A_arbace_classes_env_A_const_135.GetRawRoot__O(); var linked_1422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1421, A_arbace_classes_env_params_key_A_fn_class); var ifn_1423 lang.IFn; if linked_1422 == nil { ifn_1423 = lang.IFn_Cast(root_1421) } else { ifn_1423 = nil }; var arg_1424 any = A_arbace_classes_env_A_const_60.Invoke_O__O(m__2); if linked_1422 == nil { tmp8 = ifn_1423.Invoke_O__O(arg_1424) } else { tmp8 = linked_1422.(*A_arbace_classes_env_params_key_A).Invoke_O_O__O(root_1421, arg_1424) }; arg_1420 = tmp7.Invoke_O__O(tmp8); if linked_1418 == nil { tmp6 = ifn_1419.Invoke_O__O(arg_1420) } else { tmp6 = linked_1418.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1417, arg_1420) }
//line :377:1
				if jrt.J2g_Truth(tmp6) { var root_1425 any = A_arbace_classes_env_A_const_62.GetRawRoot__O(); var linked_1426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1425, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1427 lang.IFn; if linked_1426 == nil { ifn_1427 = lang.IFn_Cast(root_1425) } else { ifn_1427 = nil }; var arg_1428 any = t.F_b__28000182; var arg_1429 any = m__2; if linked_1426 == nil { ifn_1427.Invoke_O_O__O(arg_1428, arg_1429) } else { linked_1426.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1425, arg_1428, arg_1429) }; i__28000181__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000181__1); continue L1 } else { i__28000181__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000181__1); continue L1 } } else { i__28000181__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000181__1); continue L1 } } else { i__28000181__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000181__1); continue L1 } } else { i__28000181__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000181__1); continue L1 } } else { i__28000181__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__28000181__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_classes_env_member_methods_A_New() *A_arbace_classes_env_member_methods_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_member_methods_A{}; t.Ctor(); return t }
//line :386:1
func (t *A_arbace_classes_env_member_methods_A) Ctor() {}
//line :386:1
func (t *A_arbace_classes_env_member_methods_A) Invoke_O_O_O__O(self, n__0, name__1 any) any {



	var tmp1 any; var root_1555 any = A_arbace_classes_env_A_const_24.GetRawRoot__O(); var linked_1556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1555, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1557 lang.IFn; if linked_1556 == nil { ifn_1557 = lang.IFn_Cast(root_1555) } else { ifn_1557 = nil }; var arg_1558 any; var and__1927000168__auto____3 any; var root_1559 any = A_arbace_classes_env_A_const_137.GetRawRoot__O(); var linked_1560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1559, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1561 lang.IFn; if linked_1560 == nil { ifn_1561 = lang.IFn_Cast(root_1559) } else { ifn_1561 = nil }; var arg_1562 any = n__0; if linked_1560 == nil { and__1927000168__auto____3 = ifn_1561.Invoke_O__O(arg_1562) } else { and__1927000168__auto____3 = linked_1560.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1559, arg_1562) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_1563 any = A_arbace_classes_env_A_const_137.GetRawRoot__O(); var linked_1564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1563, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1565 lang.IFn; if linked_1564 == nil { ifn_1565 = lang.IFn_Cast(root_1563) } else { ifn_1565 = nil }; var arg_1566 any = name__1; if linked_1564 == nil { arg_1558 = ifn_1565.Invoke_O__O(arg_1566) } else { arg_1558 = linked_1564.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1563, arg_1566) } } else { arg_1558 = and__1927000168__auto____3 }; if linked_1556 == nil { tmp1 = ifn_1557.Invoke_O__O(arg_1558) } else { tmp1 = linked_1556.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1555, arg_1558) }; if jrt.J2g_Truth(tmp1) {
		var root_1567 any = A_arbace_classes_env_A_const_138.GetRawRoot__O(); var linked_1568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1567, A_arbace_classes_env_member_methods_STAR__A_fn_class); var ifn_1569 lang.IFn; if linked_1568 == nil { ifn_1569 = lang.IFn_Cast(root_1567) } else { ifn_1569 = nil }; var arg_1570 any = n__0; var arg_1571 any = name__1; var arg_1572 any; var root_1573 any = A_arbace_classes_env_A_const_139.GetRawRoot__O(); var linked_1574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1573, A_arbace_classes_env_all_supertypes_A_fn_class); var ifn_1575 lang.IFn; if linked_1574 == nil { ifn_1575 = lang.IFn_Cast(root_1573) } else { ifn_1575 = nil }; var arg_1576 any = n__0; if linked_1574 == nil { arg_1572 = ifn_1575.Invoke_O__O(arg_1576) } else { arg_1572 = linked_1574.(*A_arbace_classes_env_all_supertypes_A).Invoke_O_O__O(root_1573, arg_1576) }; if linked_1568 == nil { return ifn_1569.Invoke_O_O_O__O(arg_1570, arg_1571, arg_1572) } else { return linked_1568.(*A_arbace_classes_env_member_methods_STAR__A).Invoke_O_O_O_O__O(root_1567, arg_1570, arg_1571, arg_1572) } } else {
//line :390:1
			var by_name__3 any; var or__1927000174__auto____3 any = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_140.GetRawRoot__O())).Get_O__O(n__0)


			if jrt.J2g_Truth(or__1927000174__auto____3) { by_name__3 = or__1927000174__auto____3 } else {
				jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_140.GetRawRoot__O())).PutIfAbsent_O_O__O(n__0, jrt.ConcurrentHashMap_New())
				by_name__3 = jrt.NN(jrt.ConcurrentHashMap_Cast(A_arbace_classes_env_A_const_140.GetRawRoot__O())).Get_O__O(n__0) }
//line :390:1
			var e__4 any = jrt.NN(jrt.ConcurrentHashMap_Cast(by_name__3)).Get_O__O(name__1); var tmp2 any
			var and__1927000168__auto____5 any = e__4





			if jrt.J2g_Truth(and__1927000168__auto____5) { var root_1577 any = A_arbace_classes_env_A_const_128.GetRawRoot__O(); var linked_1578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1577, A_arbace_classes_env_same_infos_QMARK__A_fn_class); var ifn_1579 lang.IFn; if linked_1578 == nil { ifn_1579 = lang.IFn_Cast(root_1577) } else { ifn_1579 = nil }; var arg_1580 any = lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](e__4, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(1)); var arg_1581 any = lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](e__4, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(2)); if linked_1578 == nil { tmp2 = ifn_1579.Invoke_O_O__O(arg_1580, arg_1581) } else { tmp2 = linked_1578.(*A_arbace_classes_env_same_infos_QMARK__A).Invoke_O_O_O__O(root_1577, arg_1580, arg_1581) } } else { tmp2 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp2) {
				return lang.RT_Aget_O1_I__O_NoInit(jrt.J2g_CastArray[*jrt.RefArray](e__4, jrt.Object_class.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0)) } else {
//line :397:1
					var sups__5 any; var root_1582 any = A_arbace_classes_env_A_const_139.GetRawRoot__O(); var linked_1583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1582, A_arbace_classes_env_all_supertypes_A_fn_class); var ifn_1584 lang.IFn

					if linked_1583 == nil { ifn_1584 = lang.IFn_Cast(root_1582) } else { ifn_1584 = nil }; var arg_1585 any = n__0; if linked_1583 == nil { sups__5 = ifn_1584.Invoke_O__O(arg_1585) } else { sups__5 = linked_1583.(*A_arbace_classes_env_all_supertypes_A).Invoke_O_O__O(root_1582, arg_1585) }
//line :397:1
					var infos__6 any; var root_1586 any = A_arbace_classes_env_A_const_130.GetRawRoot__O(); var linked_1587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1586, A_arbace_classes_env_infos_now_A_fn_class); var ifn_1588 lang.IFn


					if linked_1587 == nil { ifn_1588 = lang.IFn_Cast(root_1586) } else { ifn_1588 = nil }; var arg_1589 any = sups__5; if linked_1587 == nil { infos__6 = ifn_1588.Invoke_O__O(arg_1589) } else { infos__6 = linked_1587.(*A_arbace_classes_env_infos_now_A).Invoke_O_O__O(root_1586, arg_1589) }
//line :397:1
					var r__7 any; var root_1590 any = A_arbace_classes_env_A_const_138.GetRawRoot__O(); var linked_1591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1590, A_arbace_classes_env_member_methods_STAR__A_fn_class); var ifn_1592 lang.IFn



					if linked_1591 == nil { ifn_1592 = lang.IFn_Cast(root_1590) } else { ifn_1592 = nil }; var arg_1593 any = n__0; var arg_1594 any = name__1; var arg_1595 any = sups__5; if linked_1591 == nil { r__7 = ifn_1592.Invoke_O_O_O__O(arg_1593, arg_1594, arg_1595) } else { r__7 = linked_1591.(*A_arbace_classes_env_member_methods_STAR__A).Invoke_O_O_O_O__O(root_1590, arg_1593, arg_1594, arg_1595)
					}
					var tmp3 any; var and__1927000168__auto____8 bool; var tmp4 any; var root_1596 any = A_arbace_classes_env_A_const_139.GetRawRoot__O(); var linked_1597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1596, A_arbace_classes_env_all_supertypes_A_fn_class); var ifn_1598 lang.IFn; if linked_1597 == nil { ifn_1598 = lang.IFn_Cast(root_1596) } else { ifn_1598 = nil }; var arg_1599 any = n__0; if linked_1597 == nil { tmp4 = ifn_1598.Invoke_O__O(arg_1599) } else { tmp4 = linked_1597.(*A_arbace_classes_env_all_supertypes_A).Invoke_O_O__O(root_1596, arg_1599) }; and__1927000168__auto____8 = lang.Util_Equiv_O_O__Z_NoInit(sups__5, tmp4); if and__1927000168__auto____8 { var root_1600 any = A_arbace_classes_env_A_const_128.GetRawRoot__O(); var linked_1601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1600, A_arbace_classes_env_same_infos_QMARK__A_fn_class); var ifn_1602 lang.IFn; if linked_1601 == nil { ifn_1602 = lang.IFn_Cast(root_1600) } else { ifn_1602 = nil }; var arg_1603 any = sups__5; var arg_1604 any = infos__6; if linked_1601 == nil { tmp3 = ifn_1602.Invoke_O_O__O(arg_1603, arg_1604) } else { tmp3 = linked_1601.(*A_arbace_classes_env_same_infos_QMARK__A).Invoke_O_O_O__O(root_1600, arg_1603, arg_1604) } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8).Ref() }; if jrt.J2g_Truth(tmp3) {
						jrt.NN(jrt.ConcurrentHashMap_Cast(by_name__3)).Put_O_O__O(name__1, lang.RT_Object_array_O__O1_NoInit(lang.Tuple_Create_O_O_O__IPersistentVector(r__7, sups__5, infos__6)).Ref()) }
//line :397:1
					return r__7
				}
		}
}






func A_arbace_classes_env_constructors_A_New() *A_arbace_classes_env_constructors_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_constructors_A{}; t.Ctor(); return t }
//line :407:1
func (t *A_arbace_classes_env_constructors_A) Ctor() {}
//line :407:1
func (t *A_arbace_classes_env_constructors_A) Invoke_O_O__O(self, n__0 any) any {
	var root_1605 any = A_arbace_classes_env_A_const_86.GetRawRoot__O(); var linked_1606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1605, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1607 lang.IFn; if linked_1606 == nil { ifn_1607 = lang.IFn_Cast(root_1605) } else { ifn_1607 = nil }; var arg_1608 any; var tmp1 any = A_arbace_classes_env_constructors_fn__28000192_A_New(); var tmp2 *jrt.Class; var fncls__1610 *jrt.Class = A_arbace_classes_env_constructors_fn__28000192_A_fn_class; if fncls__1610 == nil { var fncls__1610d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_classes_env_constructors_fn__28000192_A_fn_class = fncls__1610d; tmp2 = fncls__1610d } else { tmp2 = fncls__1610 }; arg_1608 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1609 any; var tmp3 *lang.Keyword = A_arbace_classes_env_A_const_76; var tmp4 any; var root_1611 any = A_arbace_classes_env_A_const_95.GetRawRoot__O(); var linked_1612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1611, A_arbace_classes_env_info_BANG__A_fn_class); var ifn_1613 lang.IFn; if linked_1612 == nil { ifn_1613 = lang.IFn_Cast(root_1611) } else { ifn_1613 = nil }; var arg_1614 any = n__0; if linked_1612 == nil { tmp4 = ifn_1613.Invoke_O__O(arg_1614) } else { tmp4 = linked_1612.(*A_arbace_classes_env_info_BANG__A).Invoke_O_O__O(root_1611, arg_1614) }; arg_1609 = tmp3.Invoke_O__O(tmp4); if linked_1606 == nil { return ifn_1607.Invoke_O_O__O(arg_1608, arg_1609) } else { return linked_1606.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1605, arg_1608, arg_1609) } }
//line :408:1
func A_arbace_classes_env_constructors_fn__28000192_A_New() *A_arbace_classes_env_constructors_fn__28000192_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_constructors_fn__28000192_A{}; t.Ctor(); return t }
//line :408:1
func (t *A_arbace_classes_env_constructors_fn__28000192_A) Ctor() {}
//line :408:1
func (t *A_arbace_classes_env_constructors_fn__28000192_A) Invoke_O_O__O(self, p1__28000191_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_13, A_arbace_classes_env_A_const_42.Invoke_O__O(p1__28000191_SHARP___1))).Ref() }








































































































type A_arbace_classes_env_A struct{ jrt.Object }

var A_arbace_classes_env_A_const_pool *jrt.RefArray

var A_arbace_classes_env_A_const_0 *lang.Var

var A_arbace_classes_env_A_const_1 any

var A_arbace_classes_env_A_const_2 *lang.Var

var A_arbace_classes_env_A_const_3 any

var A_arbace_classes_env_A_const_4 any

var A_arbace_classes_env_A_const_5 any

var A_arbace_classes_env_A_const_6 any

var A_arbace_classes_env_A_const_7 *lang.Var

var A_arbace_classes_env_A_const_8 *lang.Var

var A_arbace_classes_env_A_const_9 *lang.Var

var A_arbace_classes_env_A_const_10 *lang.Var

var A_arbace_classes_env_A_const_11 any

var A_arbace_classes_env_A_const_12 *lang.Var

var A_arbace_classes_env_A_const_13 *lang.Var

var A_arbace_classes_env_A_const_14 *lang.Var

var A_arbace_classes_env_A_const_15 *lang.Var

var A_arbace_classes_env_A_const_16 *lang.Var

var A_arbace_classes_env_A_const_17 *lang.Var

var A_arbace_classes_env_A_const_18 *lang.Var

var A_arbace_classes_env_A_const_19 *lang.Var

var A_arbace_classes_env_A_const_20 *lang.Var

var A_arbace_classes_env_A_const_21 *lang.Var

var A_arbace_classes_env_A_const_22 *lang.Keyword

var A_arbace_classes_env_A_const_23 *lang.Var

var A_arbace_classes_env_A_const_24 *lang.Var

var A_arbace_classes_env_A_const_25 *lang.Var

var A_arbace_classes_env_A_const_26 *lang.Var

var A_arbace_classes_env_A_const_27 *lang.Var

var A_arbace_classes_env_A_const_28 *lang.Var

var A_arbace_classes_env_A_const_29 *lang.Var

var A_arbace_classes_env_A_const_30 *lang.Var

var A_arbace_classes_env_A_const_31 *lang.Var

var A_arbace_classes_env_A_const_32 *lang.Keyword

var A_arbace_classes_env_A_const_33 *lang.Keyword

var A_arbace_classes_env_A_const_34 *jrt.Class

var A_arbace_classes_env_A_const_35 *lang.Var

var A_arbace_classes_env_A_const_36 *lang.Var

var A_arbace_classes_env_A_const_37 *lang.Var

var A_arbace_classes_env_A_const_38 any

var A_arbace_classes_env_A_const_39 any

var A_arbace_classes_env_A_const_40 *lang.Var

var A_arbace_classes_env_A_const_41 *lang.Var

var A_arbace_classes_env_A_const_42 *lang.Keyword

var A_arbace_classes_env_A_const_43 *lang.Keyword

var A_arbace_classes_env_A_const_44 *lang.Keyword

var A_arbace_classes_env_A_const_45 *lang.Keyword

var A_arbace_classes_env_A_const_46 *lang.Keyword

var A_arbace_classes_env_A_const_47 *lang.Var

var A_arbace_classes_env_A_const_48 *lang.Keyword

var A_arbace_classes_env_A_const_49 *lang.Keyword

var A_arbace_classes_env_A_const_50 *lang.Keyword

var A_arbace_classes_env_A_const_51 *lang.Var

var A_arbace_classes_env_A_const_52 *lang.Var

var A_arbace_classes_env_A_const_53 *lang.Var

var A_arbace_classes_env_A_const_54 *lang.Var

var A_arbace_classes_env_A_const_55 *lang.Var

var A_arbace_classes_env_A_const_56 *lang.Var

var A_arbace_classes_env_A_const_57 *lang.Var

var A_arbace_classes_env_A_const_58 *lang.Var

var A_arbace_classes_env_A_const_59 *lang.Var

var A_arbace_classes_env_A_const_60 *lang.Keyword

var A_arbace_classes_env_A_const_61 *lang.Keyword

var A_arbace_classes_env_A_const_62 *lang.Var

var A_arbace_classes_env_A_const_63 *lang.Keyword

var A_arbace_classes_env_A_const_64 *lang.Keyword

var A_arbace_classes_env_A_const_65 *lang.Var

var A_arbace_classes_env_A_const_66 *lang.Var

var A_arbace_classes_env_A_const_67 *lang.Var

var A_arbace_classes_env_A_const_68 *lang.Var

var A_arbace_classes_env_A_const_69 *lang.Var

var A_arbace_classes_env_A_const_70 *lang.Var

var A_arbace_classes_env_A_const_71 *lang.Var

var A_arbace_classes_env_A_const_72 *lang.Var

var A_arbace_classes_env_A_const_73 *lang.Var

var A_arbace_classes_env_A_const_74 *lang.Keyword

var A_arbace_classes_env_A_const_75 *lang.Var

var A_arbace_classes_env_A_const_76 *lang.Keyword

var A_arbace_classes_env_A_const_77 *lang.Var

var A_arbace_classes_env_A_const_78 *lang.Var

var A_arbace_classes_env_A_const_79 *lang.Var

var A_arbace_classes_env_A_const_80 *lang.Keyword

var A_arbace_classes_env_A_const_81 *lang.Keyword

var A_arbace_classes_env_A_const_82 *lang.Var

var A_arbace_classes_env_A_const_83 *lang.Keyword

var A_arbace_classes_env_A_const_84 *lang.Var

var A_arbace_classes_env_A_const_85 *lang.Var

var A_arbace_classes_env_A_const_86 *lang.Var

var A_arbace_classes_env_A_const_87 *lang.Var

var A_arbace_classes_env_A_const_88 any

var A_arbace_classes_env_A_const_89 *lang.Var

var A_arbace_classes_env_A_const_90 *lang.Keyword

var A_arbace_classes_env_A_const_91 *lang.Var

var A_arbace_classes_env_A_const_92 *lang.Var

var A_arbace_classes_env_A_const_93 *lang.Var

var A_arbace_classes_env_A_const_94 *lang.Var

var A_arbace_classes_env_A_const_95 *lang.Var

var A_arbace_classes_env_A_const_96 *lang.Var

var A_arbace_classes_env_A_const_97 *lang.Var

var A_arbace_classes_env_A_const_98 *lang.Keyword

var A_arbace_classes_env_A_const_99 *lang.Var

var A_arbace_classes_env_A_const_100 *lang.Var

var A_arbace_classes_env_A_const_101 *lang.Var

var A_arbace_classes_env_A_const_102 *lang.Var

var A_arbace_classes_env_A_const_103 *lang.Var

var A_arbace_classes_env_A_const_104 *lang.Keyword

var A_arbace_classes_env_A_const_105 any

var A_arbace_classes_env_A_const_106 *lang.Var

var A_arbace_classes_env_A_const_107 *lang.Var

var A_arbace_classes_env_A_const_108 *lang.Var

var A_arbace_classes_env_A_const_109 *lang.Var

var A_arbace_classes_env_A_const_110 *lang.Var

var A_arbace_classes_env_A_const_111 *lang.Var

var A_arbace_classes_env_A_const_112 *lang.Var

var A_arbace_classes_env_A_const_113 *lang.Var

var A_arbace_classes_env_A_const_114 *lang.Var

var A_arbace_classes_env_A_const_115 *lang.Var

var A_arbace_classes_env_A_const_116 *lang.Var

var A_arbace_classes_env_A_const_117 *lang.Var

var A_arbace_classes_env_A_const_118 *lang.Var

var A_arbace_classes_env_A_const_119 *lang.Var

var A_arbace_classes_env_A_const_120 *lang.Var

var A_arbace_classes_env_A_const_121 any

var A_arbace_classes_env_A_const_122 any

var A_arbace_classes_env_A_const_123 *lang.Var

var A_arbace_classes_env_A_const_124 any

var A_arbace_classes_env_A_const_125 *lang.Var

var A_arbace_classes_env_A_const_126 *lang.Var

var A_arbace_classes_env_A_const_127 *lang.Var

var A_arbace_classes_env_A_const_128 *lang.Var

var A_arbace_classes_env_A_const_129 *lang.Var

var A_arbace_classes_env_A_const_130 *lang.Var

var A_arbace_classes_env_A_const_131 *lang.Var

var A_arbace_classes_env_A_const_132 any

var A_arbace_classes_env_A_const_133 any

var A_arbace_classes_env_A_const_134 any

var A_arbace_classes_env_A_const_135 *lang.Var

var A_arbace_classes_env_A_const_136 *lang.Var

var A_arbace_classes_env_A_const_137 *lang.Var

var A_arbace_classes_env_A_const_138 *lang.Var

var A_arbace_classes_env_A_const_139 *lang.Var

var A_arbace_classes_env_A_const_140 *lang.Var

var A_arbace_classes_env_A_init jrt.ClassInit

func A_arbace_classes_env_A_Init() { if !A_arbace_classes_env_A_init.Done() { A_arbace_classes_env_A_init.Run(A_arbace_classes_env_A_clinit) } }

func A_arbace_classes_env_A_clinit() { A_arbace_classes_env_A_clinit_p0(); A_arbace_classes_env_A_clinit_p1(); A_arbace_classes_env_A_clinit_p2(); A_arbace_classes_env_A_clinit_p3(); A_arbace_classes_env_A_clinit_p4(); A_arbace_classes_env_A_clinit_p5(); A_arbace_classes_env_A_clinit_p6(); A_arbace_classes_env_A_clinit_p7(); A_arbace_classes_env_A_clinit_p8(); A_arbace_classes_env_A_clinit_p9(); A_arbace_classes_env_A_clinit_p10(); A_arbace_classes_env_A_clinit_p11() }

func A_arbace_classes_env_A_clinit_p0() { jrt.StartCheck(); A_arbace_classes_env_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 177); A_arbace_classes_env_A_const_0 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[36]); A_arbace_classes_env_A_const_1 = A_arbace_classes_env_A_const_pool.A[37]; A_arbace_classes_env_A_const_2 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[38]); A_arbace_classes_env_A_const_3 = A_arbace_classes_env_A_const_pool.A[39]; A_arbace_classes_env_A_const_4 = A_arbace_classes_env_A_const_pool.A[40]; A_arbace_classes_env_A_const_5 = A_arbace_classes_env_A_const_pool.A[41]; A_arbace_classes_env_A_const_6 = A_arbace_classes_env_A_const_pool.A[42]; A_arbace_classes_env_A_const_7 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[43]); A_arbace_classes_env_A_const_8 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[44]); A_arbace_classes_env_A_const_9 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[45]); A_arbace_classes_env_A_const_10 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[46]); A_arbace_classes_env_A_const_11 = A_arbace_classes_env_A_const_pool.A[47] }

func A_arbace_classes_env_A_clinit_p1() { A_arbace_classes_env_A_const_12 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[48]); A_arbace_classes_env_A_const_13 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[49]); A_arbace_classes_env_A_const_14 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[50]); A_arbace_classes_env_A_const_15 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[51]); A_arbace_classes_env_A_const_16 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[52]); A_arbace_classes_env_A_const_17 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[53]); A_arbace_classes_env_A_const_18 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[54]); A_arbace_classes_env_A_const_19 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[55]); A_arbace_classes_env_A_const_20 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[56]); A_arbace_classes_env_A_const_21 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[57]); A_arbace_classes_env_A_const_22 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[58]); A_arbace_classes_env_A_const_23 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[59]) }

func A_arbace_classes_env_A_clinit_p2() { A_arbace_classes_env_A_const_24 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[60]); A_arbace_classes_env_A_const_25 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[61]); A_arbace_classes_env_A_const_26 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[62]); A_arbace_classes_env_A_const_27 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[63]); A_arbace_classes_env_A_const_28 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[64]); A_arbace_classes_env_A_const_29 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[65]); A_arbace_classes_env_A_const_30 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[66]); A_arbace_classes_env_A_const_31 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[67]); A_arbace_classes_env_A_const_32 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[68]); A_arbace_classes_env_A_const_33 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[69]); A_arbace_classes_env_A_const_34 = jrt.Class_Cast(A_arbace_classes_env_A_const_pool.A[70]); A_arbace_classes_env_A_const_35 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[71]) }

func A_arbace_classes_env_A_clinit_p3() { A_arbace_classes_env_A_const_36 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[72]); A_arbace_classes_env_A_const_37 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[73]); A_arbace_classes_env_A_const_38 = A_arbace_classes_env_A_const_pool.A[74]; A_arbace_classes_env_A_const_39 = A_arbace_classes_env_A_const_pool.A[75]; A_arbace_classes_env_A_const_40 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[76]); A_arbace_classes_env_A_const_41 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[77]); A_arbace_classes_env_A_const_42 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[78]); A_arbace_classes_env_A_const_43 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[79]); A_arbace_classes_env_A_const_44 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[80]); A_arbace_classes_env_A_const_45 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[81]); A_arbace_classes_env_A_const_46 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[82]); A_arbace_classes_env_A_const_47 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[83]) }

func A_arbace_classes_env_A_clinit_p4() { A_arbace_classes_env_A_const_48 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[84]); A_arbace_classes_env_A_const_49 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[85]); A_arbace_classes_env_A_const_50 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[86]); A_arbace_classes_env_A_const_51 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[87]); A_arbace_classes_env_A_const_52 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[88]); A_arbace_classes_env_A_const_53 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[89]); A_arbace_classes_env_A_const_54 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[90]); A_arbace_classes_env_A_const_55 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[91]); A_arbace_classes_env_A_const_56 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[92]); A_arbace_classes_env_A_const_57 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[93]); A_arbace_classes_env_A_const_58 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[94]); A_arbace_classes_env_A_const_59 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[95]) }

func A_arbace_classes_env_A_clinit_p5() { A_arbace_classes_env_A_const_60 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[96]); A_arbace_classes_env_A_const_61 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[97]); A_arbace_classes_env_A_const_62 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[98]); A_arbace_classes_env_A_const_63 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[99]); A_arbace_classes_env_A_const_64 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[100]); A_arbace_classes_env_A_const_65 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[101]); A_arbace_classes_env_A_const_66 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[102]); A_arbace_classes_env_A_const_67 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[103]); A_arbace_classes_env_A_const_68 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[104]); A_arbace_classes_env_A_const_69 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[105]); A_arbace_classes_env_A_const_70 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[106]); A_arbace_classes_env_A_const_71 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[107]) }

func A_arbace_classes_env_A_clinit_p6() { A_arbace_classes_env_A_const_72 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[108]); A_arbace_classes_env_A_const_73 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[109]); A_arbace_classes_env_A_const_74 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[110]); A_arbace_classes_env_A_const_75 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[111]); A_arbace_classes_env_A_const_76 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[112]); A_arbace_classes_env_A_const_77 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[113]); A_arbace_classes_env_A_const_78 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[114]); A_arbace_classes_env_A_const_79 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[115]); A_arbace_classes_env_A_const_80 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[116]); A_arbace_classes_env_A_const_81 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[117]); A_arbace_classes_env_A_const_82 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[118]); A_arbace_classes_env_A_const_83 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[119]) }

func A_arbace_classes_env_A_clinit_p7() { A_arbace_classes_env_A_const_84 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[120]); A_arbace_classes_env_A_const_85 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[121]); A_arbace_classes_env_A_const_86 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[122]); A_arbace_classes_env_A_const_87 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[123]); A_arbace_classes_env_A_const_88 = A_arbace_classes_env_A_const_pool.A[124]; A_arbace_classes_env_A_const_89 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[125]); A_arbace_classes_env_A_const_90 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[126]); A_arbace_classes_env_A_const_91 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[127]); A_arbace_classes_env_A_const_92 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[128]); A_arbace_classes_env_A_const_93 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[129]); A_arbace_classes_env_A_const_94 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[130]); A_arbace_classes_env_A_const_95 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[131]) }

func A_arbace_classes_env_A_clinit_p8() { A_arbace_classes_env_A_const_96 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[132]); A_arbace_classes_env_A_const_97 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[133]); A_arbace_classes_env_A_const_98 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[134]); A_arbace_classes_env_A_const_99 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[135]); A_arbace_classes_env_A_const_100 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[136]); A_arbace_classes_env_A_const_101 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[137]); A_arbace_classes_env_A_const_102 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[138]); A_arbace_classes_env_A_const_103 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[139]); A_arbace_classes_env_A_const_104 = lang.Keyword_Cast(A_arbace_classes_env_A_const_pool.A[140]); A_arbace_classes_env_A_const_105 = A_arbace_classes_env_A_const_pool.A[141]; A_arbace_classes_env_A_const_106 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[142]); A_arbace_classes_env_A_const_107 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[143]) }

func A_arbace_classes_env_A_clinit_p9() { A_arbace_classes_env_A_const_108 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[144]); A_arbace_classes_env_A_const_109 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[145]); A_arbace_classes_env_A_const_110 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[146]); A_arbace_classes_env_A_const_111 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[147]); A_arbace_classes_env_A_const_112 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[148]); A_arbace_classes_env_A_const_113 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[149]); A_arbace_classes_env_A_const_114 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[150]); A_arbace_classes_env_A_const_115 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[151]); A_arbace_classes_env_A_const_116 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[152]); A_arbace_classes_env_A_const_117 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[153]); A_arbace_classes_env_A_const_118 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[154]); A_arbace_classes_env_A_const_119 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[155]) }

func A_arbace_classes_env_A_clinit_p10() { A_arbace_classes_env_A_const_120 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[156]); A_arbace_classes_env_A_const_121 = A_arbace_classes_env_A_const_pool.A[157]; A_arbace_classes_env_A_const_122 = A_arbace_classes_env_A_const_pool.A[158]; A_arbace_classes_env_A_const_123 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[159]); A_arbace_classes_env_A_const_124 = A_arbace_classes_env_A_const_pool.A[160]; A_arbace_classes_env_A_const_125 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[161]); A_arbace_classes_env_A_const_126 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[162]); A_arbace_classes_env_A_const_127 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[163]); A_arbace_classes_env_A_const_128 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[164]); A_arbace_classes_env_A_const_129 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[165]); A_arbace_classes_env_A_const_130 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[166]); A_arbace_classes_env_A_const_131 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[167]); A_arbace_classes_env_A_const_132 = A_arbace_classes_env_A_const_pool.A[168] }

func A_arbace_classes_env_A_clinit_p11() { A_arbace_classes_env_A_const_133 = A_arbace_classes_env_A_const_pool.A[169]; A_arbace_classes_env_A_const_134 = A_arbace_classes_env_A_const_pool.A[170]; A_arbace_classes_env_A_const_135 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[171]); A_arbace_classes_env_A_const_136 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[172]); A_arbace_classes_env_A_const_137 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[173]); A_arbace_classes_env_A_const_138 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[174]); A_arbace_classes_env_A_const_139 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[175]); A_arbace_classes_env_A_const_140 = lang.Var_Cast(A_arbace_classes_env_A_const_pool.A[176]) }

func A_arbace_classes_env_A_New() *A_arbace_classes_env_A { A_arbace_classes_env_A_Init(); t := &A_arbace_classes_env_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_env_A) Ctor() {}

func (t *A_arbace_classes_env_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_A_class }

func (t *A_arbace_classes_env_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_env_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_A); return ok }

func A_arbace_classes_env_A_Cast(x any) *A_arbace_classes_env_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_A_class)) }; return v }



type A_arbace_classes_env_accessible_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_accessible_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_accessible_QMARK__fn__28000143_A struct{ j2g_header uint64; F_owner any }

var A_arbace_classes_env_accessible_QMARK__fn__28000143_A_fn_class *jrt.Class



type A_arbace_classes_env_accessible_QMARK__fn__28000145_A struct{ j2g_header uint64 }

var A_arbace_classes_env_accessible_QMARK__fn__28000145_A_fn_class *jrt.Class



type A_arbace_classes_env_all_supertypes_A struct{ j2g_header uint64 }

var A_arbace_classes_env_all_supertypes_A_fn_class *jrt.Class



type A_arbace_classes_env_all_supertypes_STAR__A struct{ j2g_header uint64 }

var A_arbace_classes_env_all_supertypes_STAR__A_fn_class *jrt.Class



type A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A struct{ j2g_header uint64 }

var A_arbace_classes_env_all_supertypes_STAR__fn__28000160_A_fn_class *jrt.Class



type A_arbace_classes_env_assignable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_assignable_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_class_file_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_class_file_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_coerce_const_A struct{ j2g_header uint64 }

var A_arbace_classes_env_coerce_const_A_fn_class *jrt.Class



type A_arbace_classes_env_common_super_A struct{ j2g_header uint64 }

var A_arbace_classes_env_common_super_A_fn_class *jrt.Class



type A_arbace_classes_env_const_value_A struct{ j2g_header uint64 }

var A_arbace_classes_env_const_value_A_fn_class *jrt.Class



type A_arbace_classes_env_constructors_A struct{ j2g_header uint64 }

var A_arbace_classes_env_constructors_A_fn_class *jrt.Class



type A_arbace_classes_env_constructors_fn__28000192_A struct{ j2g_header uint64 }

var A_arbace_classes_env_constructors_fn__28000192_A_fn_class *jrt.Class



type A_arbace_classes_env_eval28000004_A struct{ jrt.Object }

func A_arbace_classes_env_eval28000004_A_New() *A_arbace_classes_env_eval28000004_A { t := &A_arbace_classes_env_eval28000004_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_env_eval28000004_A) Ctor() {}

func (t *A_arbace_classes_env_eval28000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_eval28000004_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_eval28000004_A_class }

func (t *A_arbace_classes_env_eval28000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_eval28000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_env_eval28000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_eval28000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_eval28000004_A); return ok }

func A_arbace_classes_env_eval28000004_A_Cast(x any) *A_arbace_classes_env_eval28000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_eval28000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_eval28000004_A_class)) }; return v }



type A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A struct{ j2g_header uint64 }

var A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_fn_class *jrt.Class



type A_arbace_classes_env_eval28000008_A struct{ jrt.Object }

func A_arbace_classes_env_eval28000008_A_New() *A_arbace_classes_env_eval28000008_A { t := &A_arbace_classes_env_eval28000008_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_env_eval28000008_A) Ctor() {}

func (t *A_arbace_classes_env_eval28000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env_eval28000008_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env_eval28000008_A_class }

func (t *A_arbace_classes_env_eval28000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env_eval28000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_env_eval28000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env_eval28000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env_eval28000008_A); return ok }

func A_arbace_classes_env_eval28000008_A_Cast(x any) *A_arbace_classes_env_eval28000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env_eval28000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env_eval28000008_A_class)) }; return v }



type A_arbace_classes_env_eval28000008_fn__28000009_A struct{ j2g_header uint64 }

var A_arbace_classes_env_eval28000008_fn__28000009_A_fn_class *jrt.Class



type A_arbace_classes_env_find_field_A struct{ j2g_header uint64 }

var A_arbace_classes_env_find_field_A_fn_class *jrt.Class



type A_arbace_classes_env_find_field_fn__28000150_A struct{ j2g_header uint64; F_name any }

var A_arbace_classes_env_find_field_fn__28000150_A_fn_class *jrt.Class



type A_arbace_classes_env_find_field_fn__28000152_A struct{ j2g_header uint64; F_name any }

var A_arbace_classes_env_find_field_fn__28000152_A_fn_class *jrt.Class



type A_arbace_classes_env_flag_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_flag_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_from_source_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_from_source_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_info_A struct{ j2g_header uint64 }

var A_arbace_classes_env_info_A_fn_class *jrt.Class



type A_arbace_classes_env_info_BANG__A struct{ j2g_header uint64 }

var A_arbace_classes_env_info_BANG__A_fn_class *jrt.Class



type A_arbace_classes_env_infos_now_A struct{ j2g_header uint64 }

var A_arbace_classes_env_infos_now_A_fn_class *jrt.Class



type A_arbace_classes_env_inner_member_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_inner_member_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_interface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_interface_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_internal_A struct{ j2g_header uint64 }

var A_arbace_classes_env_internal_A_fn_class *jrt.Class



type A_arbace_classes_env_known_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_known_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_load_class_A struct{ j2g_header uint64 }

var A_arbace_classes_env_load_class_A_fn_class *jrt.Class



type A_arbace_classes_env_lub_A struct{ j2g_header uint64 }

var A_arbace_classes_env_lub_A_fn_class *jrt.Class



type A_arbace_classes_env_lub_fn__28000134_A struct{ j2g_header uint64; F_common any }

var A_arbace_classes_env_lub_fn__28000134_A_fn_class *jrt.Class



type A_arbace_classes_env_lub_fn__28000134_fn__28000135_A struct{ j2g_header uint64; F_i any }

var A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_fn_class *jrt.Class



type A_arbace_classes_env_lub_sups__28000129_A struct{ j2g_header uint64 }

var A_arbace_classes_env_lub_sups__28000129_A_fn_class *jrt.Class



type A_arbace_classes_env_lub_sups__28000129_fn__28000130_A struct{ j2g_header uint64 }

var A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_fn_class *jrt.Class



type A_arbace_classes_env_member_methods_A struct{ j2g_header uint64 }

var A_arbace_classes_env_member_methods_A_fn_class *jrt.Class



type A_arbace_classes_env_member_methods_STAR__A struct{ j2g_header uint64 }

var A_arbace_classes_env_member_methods_STAR__A_fn_class *jrt.Class



type A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A struct{ j2g_header uint64; F_seen, F_name, F_n, F_c any }

var A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_A_fn_class *jrt.Class



type A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A struct{ j2g_header uint64; F_iter__28000179, F_seen, F_name, F_n, F_c, F_s__28000180 any }

var A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_A_fn_class *jrt.Class



type A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A struct{ j2g_header uint64; F_seen, F_name, F_n, F_c any; F_size__1927001038__auto__ int32; F_b__28000182, F_c__1927001037__auto__ any }

var A_arbace_classes_env_member_methods_STAR__iter__28000179__28000183_fn__28000184_fn__28000185_A_fn_class *jrt.Class



type A_arbace_classes_env_nest_host_A struct{ j2g_header uint64 }

var A_arbace_classes_env_nest_host_A_fn_class *jrt.Class



type A_arbace_classes_env_params_key_A struct{ j2g_header uint64 }

var A_arbace_classes_env_params_key_A_fn_class *jrt.Class



type A_arbace_classes_env_read_fields_A struct{ j2g_header uint64 }

var A_arbace_classes_env_read_fields_A_fn_class *jrt.Class



type A_arbace_classes_env_read_method_annotations_A struct{ j2g_header uint64 }

var A_arbace_classes_env_read_method_annotations_A_fn_class *jrt.Class



type A_arbace_classes_env_record_BANG__A struct{ j2g_header uint64 }

var A_arbace_classes_env_record_BANG__A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_A struct{ j2g_header uint64 }

var A_arbace_classes_env_reflect_info_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_fn__28000027_A struct{ j2g_header uint64; F_c any }

var A_arbace_classes_env_reflect_info_fn__28000027_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_fn__28000089_A struct{ j2g_header uint64 }

var A_arbace_classes_env_reflect_info_fn__28000089_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000031__28000035_A struct{ j2g_header uint64; F_n any }

var A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A struct{ j2g_header uint64; F_n, F_s__28000032, F_iter__28000031 any }

var A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A struct{ j2g_header uint64; F_b__28000034, F_n any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000045__28000049_A struct{ j2g_header uint64; F_n any }

var A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A struct{ j2g_header uint64; F_n, F_s__28000046, F_iter__28000045 any }

var A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A struct{ j2g_header uint64; F_n, F_b__28000048 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_A struct{ j2g_header uint64; F_n, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A struct{ j2g_header uint64; F_n, F_manns, F_s__28000056, F_iter__28000055 any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A struct{ j2g_header uint64; F_n, F_b__28000058, F_manns any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A struct{ j2g_header uint64; F_m, F_desc, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A struct{ j2g_header uint64; F_m, F_desc, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A struct{ j2g_header uint64; F_i, F_m, F_desc, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A struct{ j2g_header uint64; F_m, F_desc, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A struct{ j2g_header uint64; F_m, F_desc, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A struct{ j2g_header uint64; F_i, F_m, F_desc, F_manns any }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000077__28000081_A struct{ j2g_header uint64; F_c, F_n any }

var A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A struct{ j2g_header uint64; F_c, F_n, F_s__28000078, F_iter__28000077 any }

var A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A struct{ j2g_header uint64; F_c, F_n, F_b__28000080 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000091__28000095_A struct{ j2g_header uint64; F_n any }

var A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A struct{ j2g_header uint64; F_n, F_s__28000092, F_iter__28000091 any }

var A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_fn_class *jrt.Class



type A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A struct{ j2g_header uint64; F_n any; F_size__1927001038__auto__ int32; F_b__28000094, F_c__1927001037__auto__ any }

var A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_fn_class *jrt.Class



type A_arbace_classes_env_reflected_A struct{ j2g_header uint64 }

var A_arbace_classes_env_reflected_A_fn_class *jrt.Class



type A_arbace_classes_env_same_infos_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_same_infos_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_subclass_QMARK__A struct{ j2g_header uint64 }

var A_arbace_classes_env_subclass_QMARK__A_fn_class *jrt.Class



type A_arbace_classes_env_subclass_QMARK__fn__28000117_A struct{ j2g_header uint64; F_b any }

var A_arbace_classes_env_subclass_QMARK__fn__28000117_A_fn_class *jrt.Class



type A_arbace_classes_env_superclass_chain_A struct{ j2g_header uint64 }

var A_arbace_classes_env_superclass_chain_A_fn_class *jrt.Class



type A_arbace_classes_env_superclass_chain_fn__28000123_A struct{ j2g_header uint64 }

var A_arbace_classes_env_superclass_chain_fn__28000123_A_fn_class *jrt.Class



type A_arbace_classes_env_supertypes_A struct{ j2g_header uint64 }

var A_arbace_classes_env_supertypes_A_fn_class *jrt.Class
