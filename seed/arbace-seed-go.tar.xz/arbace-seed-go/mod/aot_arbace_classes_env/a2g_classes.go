//line a2g_classes.ae:1
package aot_arbace_classes_env

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_classes_env_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_A_New()}; return nil }

var A_arbace_classes_env_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_env_A_new}

var A_arbace_classes_env_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_A"})

func init() { i := A_arbace_classes_env_A_class.Info(); i.IsInstance = A_arbace_classes_env_A_InstanceOf; i.Init = A_arbace_classes_env_A_Init; i.Table = A_arbace_classes_env_A_members; jrt.RegisterGoType(A_arbace_classes_env_A_class, reflect.TypeFor[A_arbace_classes_env_A]()) }

func A_arbace_classes_env_accessible_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_accessible_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_env_accessible_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_accessible_QMARK__A_New()}; return nil }

func A_arbace_classes_env_accessible_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_accessible_QMARK__A_fn_class)}; return nil }

var A_arbace_classes_env_accessible_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_accessible_QMARK__A_invoke, New: A_arbace_classes_env_accessible_QMARK__A_new, Get: A_arbace_classes_env_accessible_QMARK__A_get}

var A_arbace_classes_env_accessible_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$accessible_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_env_A_class, Simple: "accessible_QMARK_", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_accessible_QMARK__A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_accessible_QMARK__A_class.Info(); i.IsInstance = A_arbace_classes_env_accessible_QMARK__A_InstanceOf; i.Init = A_arbace_classes_env_accessible_QMARK__A_Init; i.Table = A_arbace_classes_env_accessible_QMARK__A_members; jrt.RegisterGoType(A_arbace_classes_env_accessible_QMARK__A_class, reflect.TypeFor[A_arbace_classes_env_accessible_QMARK__A]()) }

func A_arbace_classes_env_accessible_QMARK__fn__28000143_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_accessible_QMARK__fn__28000143_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_accessible_QMARK__fn__28000143_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_accessible_QMARK__fn__28000143_A_New_O(args[0])}; return nil }

func A_arbace_classes_env_accessible_QMARK__fn__28000143_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_accessible_QMARK__fn__28000143_A_fn_class)}; return nil }

var A_arbace_classes_env_accessible_QMARK__fn__28000143_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_accessible_QMARK__fn__28000143_A_invoke, New: A_arbace_classes_env_accessible_QMARK__fn__28000143_A_new, Get: A_arbace_classes_env_accessible_QMARK__fn__28000143_A_get}

var A_arbace_classes_env_accessible_QMARK__fn__28000143_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$accessible_QMARK_$fn__28000143", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_accessible_QMARK__A_class, Simple: "fn__28000143", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_accessible_QMARK__fn__28000143_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_accessible_QMARK__fn__28000143_A_class.Info(); i.IsInstance = A_arbace_classes_env_accessible_QMARK__fn__28000143_A_InstanceOf; i.Init = A_arbace_classes_env_accessible_QMARK__fn__28000143_A_Init; i.Table = A_arbace_classes_env_accessible_QMARK__fn__28000143_A_members; jrt.RegisterGoType(A_arbace_classes_env_accessible_QMARK__fn__28000143_A_class, reflect.TypeFor[A_arbace_classes_env_accessible_QMARK__fn__28000143_A]()) }

func A_arbace_classes_env_accessible_QMARK__fn__28000145_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_accessible_QMARK__fn__28000145_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_accessible_QMARK__fn__28000145_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_accessible_QMARK__fn__28000145_A_New()}; return nil }

func A_arbace_classes_env_accessible_QMARK__fn__28000145_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_accessible_QMARK__fn__28000145_A_fn_class)}; return nil }

var A_arbace_classes_env_accessible_QMARK__fn__28000145_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_accessible_QMARK__fn__28000145_A_invoke, New: A_arbace_classes_env_accessible_QMARK__fn__28000145_A_new, Get: A_arbace_classes_env_accessible_QMARK__fn__28000145_A_get}

var A_arbace_classes_env_accessible_QMARK__fn__28000145_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$accessible_QMARK_$fn__28000145", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_accessible_QMARK__A_class, Simple: "fn__28000145", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_accessible_QMARK__fn__28000145_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_accessible_QMARK__fn__28000145_A_class.Info(); i.IsInstance = A_arbace_classes_env_accessible_QMARK__fn__28000145_A_InstanceOf; i.Init = A_arbace_classes_env_accessible_QMARK__fn__28000145_A_Init; i.Table = A_arbace_classes_env_accessible_QMARK__fn__28000145_A_members; jrt.RegisterGoType(A_arbace_classes_env_accessible_QMARK__fn__28000145_A_class, reflect.TypeFor[A_arbace_classes_env_accessible_QMARK__fn__28000145_A]()) }

func A_arbace_classes_env_all_supertypes_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_all_supertypes_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_all_supertypes_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_all_supertypes_A_New()}; return nil }

func A_arbace_classes_env_all_supertypes_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_all_supertypes_A_fn_class)}; return nil }

var A_arbace_classes_env_all_supertypes_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_all_supertypes_A_invoke, New: A_arbace_classes_env_all_supertypes_A_new, Get: A_arbace_classes_env_all_supertypes_A_get}

var A_arbace_classes_env_all_supertypes_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$all_supertypes", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_A_class, Simple: "all_supertypes", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_all_supertypes_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_all_supertypes_A_class.Info(); i.IsInstance = A_arbace_classes_env_all_supertypes_A_InstanceOf; i.Init = A_arbace_classes_env_all_supertypes_A_Init; i.Table = A_arbace_classes_env_all_supertypes_A_members; jrt.RegisterGoType(A_arbace_classes_env_all_supertypes_A_class, reflect.TypeFor[A_arbace_classes_env_all_supertypes_A]()) }

func A_arbace_classes_env_all_supertypes_fn__28000157_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_all_supertypes_fn__28000157_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_all_supertypes_fn__28000157_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_all_supertypes_fn__28000157_A_New()}; return nil }

func A_arbace_classes_env_all_supertypes_fn__28000157_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_all_supertypes_fn__28000157_A_fn_class)}; return nil }

var A_arbace_classes_env_all_supertypes_fn__28000157_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_all_supertypes_fn__28000157_A_invoke, New: A_arbace_classes_env_all_supertypes_fn__28000157_A_new, Get: A_arbace_classes_env_all_supertypes_fn__28000157_A_get}

var A_arbace_classes_env_all_supertypes_fn__28000157_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$all_supertypes$fn__28000157", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_all_supertypes_A_class, Simple: "fn__28000157", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_all_supertypes_fn__28000157_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_all_supertypes_fn__28000157_A_class.Info(); i.IsInstance = A_arbace_classes_env_all_supertypes_fn__28000157_A_InstanceOf; i.Init = A_arbace_classes_env_all_supertypes_fn__28000157_A_Init; i.Table = A_arbace_classes_env_all_supertypes_fn__28000157_A_members; jrt.RegisterGoType(A_arbace_classes_env_all_supertypes_fn__28000157_A_class, reflect.TypeFor[A_arbace_classes_env_all_supertypes_fn__28000157_A]()) }

func A_arbace_classes_env_assignable_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_assignable_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_env_assignable_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_assignable_QMARK__A_New()}; return nil }

func A_arbace_classes_env_assignable_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_assignable_QMARK__A_fn_class)}; return nil }

var A_arbace_classes_env_assignable_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_assignable_QMARK__A_invoke, New: A_arbace_classes_env_assignable_QMARK__A_new, Get: A_arbace_classes_env_assignable_QMARK__A_get}

var A_arbace_classes_env_assignable_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$assignable_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_env_A_class, Simple: "assignable_QMARK_", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_assignable_QMARK__A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_assignable_QMARK__A_class.Info(); i.IsInstance = A_arbace_classes_env_assignable_QMARK__A_InstanceOf; i.Init = A_arbace_classes_env_assignable_QMARK__A_Init; i.Table = A_arbace_classes_env_assignable_QMARK__A_members; jrt.RegisterGoType(A_arbace_classes_env_assignable_QMARK__A_class, reflect.TypeFor[A_arbace_classes_env_assignable_QMARK__A]()) }

func A_arbace_classes_env_class_file_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_class_file_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_class_file_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_class_file_QMARK__A_New()}; return nil }

func A_arbace_classes_env_class_file_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_class_file_QMARK__A_fn_class)}; return nil }

var A_arbace_classes_env_class_file_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_class_file_QMARK__A_invoke, New: A_arbace_classes_env_class_file_QMARK__A_new, Get: A_arbace_classes_env_class_file_QMARK__A_get}

var A_arbace_classes_env_class_file_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$class_file_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_A_class, Simple: "class_file_QMARK_", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_class_file_QMARK__A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_class_file_QMARK__A_class.Info(); i.IsInstance = A_arbace_classes_env_class_file_QMARK__A_InstanceOf; i.Init = A_arbace_classes_env_class_file_QMARK__A_Init; i.Table = A_arbace_classes_env_class_file_QMARK__A_members; jrt.RegisterGoType(A_arbace_classes_env_class_file_QMARK__A_class, reflect.TypeFor[A_arbace_classes_env_class_file_QMARK__A]()) }

func A_arbace_classes_env_coerce_const_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_coerce_const_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_env_coerce_const_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_coerce_const_A_New()}; return nil }

func A_arbace_classes_env_coerce_const_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_coerce_const_A_fn_class)}; return nil }

var A_arbace_classes_env_coerce_const_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_coerce_const_A_invoke, New: A_arbace_classes_env_coerce_const_A_new, Get: A_arbace_classes_env_coerce_const_A_get}

var A_arbace_classes_env_coerce_const_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$coerce_const", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_env_A_class, Simple: "coerce_const", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_coerce_const_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_coerce_const_A_class.Info(); i.IsInstance = A_arbace_classes_env_coerce_const_A_InstanceOf; i.Init = A_arbace_classes_env_coerce_const_A_Init; i.Table = A_arbace_classes_env_coerce_const_A_members; jrt.RegisterGoType(A_arbace_classes_env_coerce_const_A_class, reflect.TypeFor[A_arbace_classes_env_coerce_const_A]()) }

func A_arbace_classes_env_common_super_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_common_super_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_env_common_super_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_common_super_A_New()}; return nil }

func A_arbace_classes_env_common_super_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_common_super_A_fn_class)}; return nil }

var A_arbace_classes_env_common_super_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_common_super_A_invoke, New: A_arbace_classes_env_common_super_A_new, Get: A_arbace_classes_env_common_super_A_get}

var A_arbace_classes_env_common_super_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$common_super", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_env_A_class, Simple: "common_super", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_common_super_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_common_super_A_class.Info(); i.IsInstance = A_arbace_classes_env_common_super_A_InstanceOf; i.Init = A_arbace_classes_env_common_super_A_Init; i.Table = A_arbace_classes_env_common_super_A_members; jrt.RegisterGoType(A_arbace_classes_env_common_super_A_class, reflect.TypeFor[A_arbace_classes_env_common_super_A]()) }

func A_arbace_classes_env_const_value_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_const_value_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_const_value_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_const_value_A_New()}; return nil }

func A_arbace_classes_env_const_value_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_const_value_A_fn_class)}; return nil }

var A_arbace_classes_env_const_value_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_const_value_A_invoke, New: A_arbace_classes_env_const_value_A_new, Get: A_arbace_classes_env_const_value_A_get}

var A_arbace_classes_env_const_value_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$const_value", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_A_class, Simple: "const_value", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_const_value_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_const_value_A_class.Info(); i.IsInstance = A_arbace_classes_env_const_value_A_InstanceOf; i.Init = A_arbace_classes_env_const_value_A_Init; i.Table = A_arbace_classes_env_const_value_A_members; jrt.RegisterGoType(A_arbace_classes_env_const_value_A_class, reflect.TypeFor[A_arbace_classes_env_const_value_A]()) }

func A_arbace_classes_env_constructors_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_constructors_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_constructors_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_constructors_A_New()}; return nil }

func A_arbace_classes_env_constructors_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_constructors_A_fn_class)}; return nil }

var A_arbace_classes_env_constructors_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_constructors_A_invoke, New: A_arbace_classes_env_constructors_A_new, Get: A_arbace_classes_env_constructors_A_get}

var A_arbace_classes_env_constructors_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$constructors", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_A_class, Simple: "constructors", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_constructors_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_constructors_A_class.Info(); i.IsInstance = A_arbace_classes_env_constructors_A_InstanceOf; i.Init = A_arbace_classes_env_constructors_A_Init; i.Table = A_arbace_classes_env_constructors_A_members; jrt.RegisterGoType(A_arbace_classes_env_constructors_A_class, reflect.TypeFor[A_arbace_classes_env_constructors_A]()) }

func A_arbace_classes_env_constructors_fn__28000187_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_constructors_fn__28000187_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_constructors_fn__28000187_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_constructors_fn__28000187_A_New()}; return nil }

func A_arbace_classes_env_constructors_fn__28000187_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_constructors_fn__28000187_A_fn_class)}; return nil }

var A_arbace_classes_env_constructors_fn__28000187_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_constructors_fn__28000187_A_invoke, New: A_arbace_classes_env_constructors_fn__28000187_A_new, Get: A_arbace_classes_env_constructors_fn__28000187_A_get}

var A_arbace_classes_env_constructors_fn__28000187_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$constructors$fn__28000187", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_constructors_A_class, Simple: "fn__28000187", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_constructors_fn__28000187_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_constructors_fn__28000187_A_class.Info(); i.IsInstance = A_arbace_classes_env_constructors_fn__28000187_A_InstanceOf; i.Init = A_arbace_classes_env_constructors_fn__28000187_A_Init; i.Table = A_arbace_classes_env_constructors_fn__28000187_A_members; jrt.RegisterGoType(A_arbace_classes_env_constructors_fn__28000187_A_class, reflect.TypeFor[A_arbace_classes_env_constructors_fn__28000187_A]()) }

func A_arbace_classes_env_eval28000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_eval28000004_A_New()}; return nil }

var A_arbace_classes_env_eval28000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_env_eval28000004_A_new}

var A_arbace_classes_env_eval28000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$eval28000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_env_A_class, Simple: "eval28000004", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_eval28000004_A"})

func init() { i := A_arbace_classes_env_eval28000004_A_class.Info(); i.IsInstance = A_arbace_classes_env_eval28000004_A_InstanceOf; i.Table = A_arbace_classes_env_eval28000004_A_members; jrt.RegisterGoType(A_arbace_classes_env_eval28000004_A_class, reflect.TypeFor[A_arbace_classes_env_eval28000004_A]()) }

func A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_New()}; return nil }

func A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_fn_class)}; return nil }

var A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_invoke, New: A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_new, Get: A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_get}

var A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$eval28000004$loading__1927001464__auto____28000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_env_eval28000004_A_class, Simple: "loading__1927001464__auto____28000005", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_class.Info(); i.IsInstance = A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_InstanceOf; i.Init = A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_Init; i.Table = A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_members; jrt.RegisterGoType(A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_class, reflect.TypeFor[A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A]()) }

func A_arbace_classes_env_eval28000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_eval28000008_A_New()}; return nil }

var A_arbace_classes_env_eval28000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_env_eval28000008_A_new}

var A_arbace_classes_env_eval28000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$eval28000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_env_A_class, Simple: "eval28000008", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_eval28000008_A"})

func init() { i := A_arbace_classes_env_eval28000008_A_class.Info(); i.IsInstance = A_arbace_classes_env_eval28000008_A_InstanceOf; i.Table = A_arbace_classes_env_eval28000008_A_members; jrt.RegisterGoType(A_arbace_classes_env_eval28000008_A_class, reflect.TypeFor[A_arbace_classes_env_eval28000008_A]()) }

func A_arbace_classes_env_eval28000008_fn__28000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_eval28000008_fn__28000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_env_eval28000008_fn__28000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_eval28000008_fn__28000009_A_New()}; return nil }

func A_arbace_classes_env_eval28000008_fn__28000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_eval28000008_fn__28000009_A_fn_class)}; return nil }

var A_arbace_classes_env_eval28000008_fn__28000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_eval28000008_fn__28000009_A_invoke, New: A_arbace_classes_env_eval28000008_fn__28000009_A_new, Get: A_arbace_classes_env_eval28000008_fn__28000009_A_get}

var A_arbace_classes_env_eval28000008_fn__28000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$eval28000008$fn__28000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_env_eval28000008_A_class, Simple: "fn__28000009", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_eval28000008_fn__28000009_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_eval28000008_fn__28000009_A_class.Info(); i.IsInstance = A_arbace_classes_env_eval28000008_fn__28000009_A_InstanceOf; i.Init = A_arbace_classes_env_eval28000008_fn__28000009_A_Init; i.Table = A_arbace_classes_env_eval28000008_fn__28000009_A_members; jrt.RegisterGoType(A_arbace_classes_env_eval28000008_fn__28000009_A_class, reflect.TypeFor[A_arbace_classes_env_eval28000008_fn__28000009_A]()) }

func A_arbace_classes_env_find_field_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_find_field_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_env_find_field_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_find_field_A_New()}; return nil }

func A_arbace_classes_env_find_field_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_find_field_A_fn_class)}; return nil }

var A_arbace_classes_env_find_field_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_find_field_A_invoke, New: A_arbace_classes_env_find_field_A_new, Get: A_arbace_classes_env_find_field_A_get}

var A_arbace_classes_env_find_field_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$find_field", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_env_A_class, Simple: "find_field", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_find_field_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_find_field_A_class.Info(); i.IsInstance = A_arbace_classes_env_find_field_A_InstanceOf; i.Init = A_arbace_classes_env_find_field_A_Init; i.Table = A_arbace_classes_env_find_field_A_members; jrt.RegisterGoType(A_arbace_classes_env_find_field_A_class, reflect.TypeFor[A_arbace_classes_env_find_field_A]()) }

func A_arbace_classes_env_find_field_fn__28000150_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_find_field_fn__28000150_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_find_field_fn__28000150_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_find_field_fn__28000150_A_New_O(args[0])}; return nil }

func A_arbace_classes_env_find_field_fn__28000150_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_find_field_fn__28000150_A_fn_class)}; return nil }

var A_arbace_classes_env_find_field_fn__28000150_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_find_field_fn__28000150_A_invoke, New: A_arbace_classes_env_find_field_fn__28000150_A_new, Get: A_arbace_classes_env_find_field_fn__28000150_A_get}

var A_arbace_classes_env_find_field_fn__28000150_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$find_field$fn__28000150", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_find_field_A_class, Simple: "fn__28000150", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_find_field_fn__28000150_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_find_field_fn__28000150_A_class.Info(); i.IsInstance = A_arbace_classes_env_find_field_fn__28000150_A_InstanceOf; i.Init = A_arbace_classes_env_find_field_fn__28000150_A_Init; i.Table = A_arbace_classes_env_find_field_fn__28000150_A_members; jrt.RegisterGoType(A_arbace_classes_env_find_field_fn__28000150_A_class, reflect.TypeFor[A_arbace_classes_env_find_field_fn__28000150_A]()) }

func A_arbace_classes_env_find_field_fn__28000152_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_find_field_fn__28000152_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_find_field_fn__28000152_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_find_field_fn__28000152_A_New_O(args[0])}; return nil }

func A_arbace_classes_env_find_field_fn__28000152_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_find_field_fn__28000152_A_fn_class)}; return nil }

var A_arbace_classes_env_find_field_fn__28000152_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_find_field_fn__28000152_A_invoke, New: A_arbace_classes_env_find_field_fn__28000152_A_new, Get: A_arbace_classes_env_find_field_fn__28000152_A_get}

var A_arbace_classes_env_find_field_fn__28000152_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$find_field$fn__28000152", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_find_field_A_class, Simple: "fn__28000152", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_find_field_fn__28000152_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_find_field_fn__28000152_A_class.Info(); i.IsInstance = A_arbace_classes_env_find_field_fn__28000152_A_InstanceOf; i.Init = A_arbace_classes_env_find_field_fn__28000152_A_Init; i.Table = A_arbace_classes_env_find_field_fn__28000152_A_members; jrt.RegisterGoType(A_arbace_classes_env_find_field_fn__28000152_A_class, reflect.TypeFor[A_arbace_classes_env_find_field_fn__28000152_A]()) }

func A_arbace_classes_env_flag_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_flag_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_env_flag_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_flag_QMARK__A_New()}; return nil }

func A_arbace_classes_env_flag_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_flag_QMARK__A_fn_class)}; return nil }

var A_arbace_classes_env_flag_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_flag_QMARK__A_invoke, New: A_arbace_classes_env_flag_QMARK__A_new, Get: A_arbace_classes_env_flag_QMARK__A_get}

var A_arbace_classes_env_flag_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$flag_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_env_A_class, Simple: "flag_QMARK_", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_flag_QMARK__A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_flag_QMARK__A_class.Info(); i.IsInstance = A_arbace_classes_env_flag_QMARK__A_InstanceOf; i.Init = A_arbace_classes_env_flag_QMARK__A_Init; i.Table = A_arbace_classes_env_flag_QMARK__A_members; jrt.RegisterGoType(A_arbace_classes_env_flag_QMARK__A_class, reflect.TypeFor[A_arbace_classes_env_flag_QMARK__A]()) }

func A_arbace_classes_env_from_source_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_from_source_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_from_source_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_from_source_QMARK__A_New()}; return nil }

func A_arbace_classes_env_from_source_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_from_source_QMARK__A_fn_class)}; return nil }

var A_arbace_classes_env_from_source_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_from_source_QMARK__A_invoke, New: A_arbace_classes_env_from_source_QMARK__A_new, Get: A_arbace_classes_env_from_source_QMARK__A_get}

var A_arbace_classes_env_from_source_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$from_source_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_A_class, Simple: "from_source_QMARK_", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_from_source_QMARK__A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_from_source_QMARK__A_class.Info(); i.IsInstance = A_arbace_classes_env_from_source_QMARK__A_InstanceOf; i.Init = A_arbace_classes_env_from_source_QMARK__A_Init; i.Table = A_arbace_classes_env_from_source_QMARK__A_members; jrt.RegisterGoType(A_arbace_classes_env_from_source_QMARK__A_class, reflect.TypeFor[A_arbace_classes_env_from_source_QMARK__A]()) }

func A_arbace_classes_env_info_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_info_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_info_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_info_A_New()}; return nil }

func A_arbace_classes_env_info_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_info_A_fn_class)}; return nil }

var A_arbace_classes_env_info_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_info_A_invoke, New: A_arbace_classes_env_info_A_new, Get: A_arbace_classes_env_info_A_get}

var A_arbace_classes_env_info_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$info", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_A_class, Simple: "info", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_info_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_info_A_class.Info(); i.IsInstance = A_arbace_classes_env_info_A_InstanceOf; i.Init = A_arbace_classes_env_info_A_Init; i.Table = A_arbace_classes_env_info_A_members; jrt.RegisterGoType(A_arbace_classes_env_info_A_class, reflect.TypeFor[A_arbace_classes_env_info_A]()) }

func A_arbace_classes_env_info_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_info_BANG__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_info_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_info_BANG__A_New()}; return nil }

func A_arbace_classes_env_info_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_info_BANG__A_fn_class)}; return nil }

var A_arbace_classes_env_info_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_info_BANG__A_invoke, New: A_arbace_classes_env_info_BANG__A_new, Get: A_arbace_classes_env_info_BANG__A_get}

var A_arbace_classes_env_info_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$info_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_A_class, Simple: "info_BANG_", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_info_BANG__A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_info_BANG__A_class.Info(); i.IsInstance = A_arbace_classes_env_info_BANG__A_InstanceOf; i.Init = A_arbace_classes_env_info_BANG__A_Init; i.Table = A_arbace_classes_env_info_BANG__A_members; jrt.RegisterGoType(A_arbace_classes_env_info_BANG__A_class, reflect.TypeFor[A_arbace_classes_env_info_BANG__A]()) }

func A_arbace_classes_env_inner_member_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_inner_member_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_inner_member_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_inner_member_QMARK__A_New()}; return nil }

func A_arbace_classes_env_inner_member_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_inner_member_QMARK__A_fn_class)}; return nil }

var A_arbace_classes_env_inner_member_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_inner_member_QMARK__A_invoke, New: A_arbace_classes_env_inner_member_QMARK__A_new, Get: A_arbace_classes_env_inner_member_QMARK__A_get}

var A_arbace_classes_env_inner_member_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$inner_member_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_A_class, Simple: "inner_member_QMARK_", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_inner_member_QMARK__A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_inner_member_QMARK__A_class.Info(); i.IsInstance = A_arbace_classes_env_inner_member_QMARK__A_InstanceOf; i.Init = A_arbace_classes_env_inner_member_QMARK__A_Init; i.Table = A_arbace_classes_env_inner_member_QMARK__A_members; jrt.RegisterGoType(A_arbace_classes_env_inner_member_QMARK__A_class, reflect.TypeFor[A_arbace_classes_env_inner_member_QMARK__A]()) }

func A_arbace_classes_env_interface_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_interface_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_interface_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_interface_QMARK__A_New()}; return nil }

func A_arbace_classes_env_interface_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_interface_QMARK__A_fn_class)}; return nil }

var A_arbace_classes_env_interface_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_interface_QMARK__A_invoke, New: A_arbace_classes_env_interface_QMARK__A_new, Get: A_arbace_classes_env_interface_QMARK__A_get}

var A_arbace_classes_env_interface_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$interface_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_A_class, Simple: "interface_QMARK_", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_interface_QMARK__A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_interface_QMARK__A_class.Info(); i.IsInstance = A_arbace_classes_env_interface_QMARK__A_InstanceOf; i.Init = A_arbace_classes_env_interface_QMARK__A_Init; i.Table = A_arbace_classes_env_interface_QMARK__A_members; jrt.RegisterGoType(A_arbace_classes_env_interface_QMARK__A_class, reflect.TypeFor[A_arbace_classes_env_interface_QMARK__A]()) }

func A_arbace_classes_env_internal_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_internal_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_internal_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_internal_A_New()}; return nil }

func A_arbace_classes_env_internal_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_internal_A_fn_class)}; return nil }

var A_arbace_classes_env_internal_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_internal_A_invoke, New: A_arbace_classes_env_internal_A_new, Get: A_arbace_classes_env_internal_A_get}

var A_arbace_classes_env_internal_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$internal", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_A_class, Simple: "internal", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_internal_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_internal_A_class.Info(); i.IsInstance = A_arbace_classes_env_internal_A_InstanceOf; i.Init = A_arbace_classes_env_internal_A_Init; i.Table = A_arbace_classes_env_internal_A_members; jrt.RegisterGoType(A_arbace_classes_env_internal_A_class, reflect.TypeFor[A_arbace_classes_env_internal_A]()) }

func A_arbace_classes_env_known_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_known_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_known_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_known_QMARK__A_New()}; return nil }

func A_arbace_classes_env_known_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_known_QMARK__A_fn_class)}; return nil }

var A_arbace_classes_env_known_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_known_QMARK__A_invoke, New: A_arbace_classes_env_known_QMARK__A_new, Get: A_arbace_classes_env_known_QMARK__A_get}

var A_arbace_classes_env_known_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$known_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_A_class, Simple: "known_QMARK_", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_known_QMARK__A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_known_QMARK__A_class.Info(); i.IsInstance = A_arbace_classes_env_known_QMARK__A_InstanceOf; i.Init = A_arbace_classes_env_known_QMARK__A_Init; i.Table = A_arbace_classes_env_known_QMARK__A_members; jrt.RegisterGoType(A_arbace_classes_env_known_QMARK__A_class, reflect.TypeFor[A_arbace_classes_env_known_QMARK__A]()) }

func A_arbace_classes_env_load_class_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_load_class_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_load_class_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_load_class_A_New()}; return nil }

func A_arbace_classes_env_load_class_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_load_class_A_fn_class)}; return nil }

var A_arbace_classes_env_load_class_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_load_class_A_invoke, New: A_arbace_classes_env_load_class_A_new, Get: A_arbace_classes_env_load_class_A_get}

var A_arbace_classes_env_load_class_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$load_class", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_A_class, Simple: "load_class", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_load_class_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_load_class_A_class.Info(); i.IsInstance = A_arbace_classes_env_load_class_A_InstanceOf; i.Init = A_arbace_classes_env_load_class_A_Init; i.Table = A_arbace_classes_env_load_class_A_members; jrt.RegisterGoType(A_arbace_classes_env_load_class_A_class, reflect.TypeFor[A_arbace_classes_env_load_class_A]()) }

func A_arbace_classes_env_lub_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_lub_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_env_lub_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_lub_A_New()}; return nil }

func A_arbace_classes_env_lub_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_lub_A_fn_class)}; return nil }

var A_arbace_classes_env_lub_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_lub_A_invoke, New: A_arbace_classes_env_lub_A_new, Get: A_arbace_classes_env_lub_A_get}

var A_arbace_classes_env_lub_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$lub", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_env_A_class, Simple: "lub", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_lub_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_lub_A_class.Info(); i.IsInstance = A_arbace_classes_env_lub_A_InstanceOf; i.Init = A_arbace_classes_env_lub_A_Init; i.Table = A_arbace_classes_env_lub_A_members; jrt.RegisterGoType(A_arbace_classes_env_lub_A_class, reflect.TypeFor[A_arbace_classes_env_lub_A]()) }

func A_arbace_classes_env_lub_fn__28000134_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_lub_fn__28000134_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_lub_fn__28000134_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_lub_fn__28000134_A_New_O(args[0])}; return nil }

func A_arbace_classes_env_lub_fn__28000134_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_lub_fn__28000134_A_fn_class)}; return nil }

var A_arbace_classes_env_lub_fn__28000134_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_lub_fn__28000134_A_invoke, New: A_arbace_classes_env_lub_fn__28000134_A_new, Get: A_arbace_classes_env_lub_fn__28000134_A_get}

var A_arbace_classes_env_lub_fn__28000134_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$lub$fn__28000134", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_lub_A_class, Simple: "fn__28000134", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_lub_fn__28000134_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_lub_fn__28000134_A_class.Info(); i.IsInstance = A_arbace_classes_env_lub_fn__28000134_A_InstanceOf; i.Init = A_arbace_classes_env_lub_fn__28000134_A_Init; i.Table = A_arbace_classes_env_lub_fn__28000134_A_members; jrt.RegisterGoType(A_arbace_classes_env_lub_fn__28000134_A_class, reflect.TypeFor[A_arbace_classes_env_lub_fn__28000134_A]()) }

func A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_lub_fn__28000134_fn__28000135_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_New_O(args[0])}; return nil }

func A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_fn_class)}; return nil }

var A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_invoke, New: A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_new, Get: A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_get}

var A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$lub$fn__28000134$fn__28000135", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_lub_fn__28000134_A_class, Simple: "fn__28000135", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_lub_fn__28000134_fn__28000135_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_class.Info(); i.IsInstance = A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_InstanceOf; i.Init = A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_Init; i.Table = A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_members; jrt.RegisterGoType(A_arbace_classes_env_lub_fn__28000134_fn__28000135_A_class, reflect.TypeFor[A_arbace_classes_env_lub_fn__28000134_fn__28000135_A]()) }

func A_arbace_classes_env_lub_sups__28000129_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_lub_sups__28000129_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_lub_sups__28000129_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_lub_sups__28000129_A_New()}; return nil }

func A_arbace_classes_env_lub_sups__28000129_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_lub_sups__28000129_A_fn_class)}; return nil }

var A_arbace_classes_env_lub_sups__28000129_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_lub_sups__28000129_A_invoke, New: A_arbace_classes_env_lub_sups__28000129_A_new, Get: A_arbace_classes_env_lub_sups__28000129_A_get}

var A_arbace_classes_env_lub_sups__28000129_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$lub$sups__28000129", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_lub_A_class, Simple: "sups__28000129", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_lub_sups__28000129_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_lub_sups__28000129_A_class.Info(); i.IsInstance = A_arbace_classes_env_lub_sups__28000129_A_InstanceOf; i.Init = A_arbace_classes_env_lub_sups__28000129_A_Init; i.Table = A_arbace_classes_env_lub_sups__28000129_A_members; jrt.RegisterGoType(A_arbace_classes_env_lub_sups__28000129_A_class, reflect.TypeFor[A_arbace_classes_env_lub_sups__28000129_A]()) }

func A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_lub_sups__28000129_fn__28000130_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_New()}; return nil }

func A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_fn_class)}; return nil }

var A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_invoke, New: A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_new, Get: A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_get}

var A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$lub$sups__28000129$fn__28000130", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_lub_sups__28000129_A_class, Simple: "fn__28000130", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_lub_sups__28000129_fn__28000130_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_class.Info(); i.IsInstance = A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_InstanceOf; i.Init = A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_Init; i.Table = A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_members; jrt.RegisterGoType(A_arbace_classes_env_lub_sups__28000129_fn__28000130_A_class, reflect.TypeFor[A_arbace_classes_env_lub_sups__28000129_fn__28000130_A]()) }

func A_arbace_classes_env_member_methods_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_member_methods_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_env_member_methods_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_member_methods_A_New()}; return nil }

func A_arbace_classes_env_member_methods_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_member_methods_A_fn_class)}; return nil }

var A_arbace_classes_env_member_methods_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_member_methods_A_invoke, New: A_arbace_classes_env_member_methods_A_new, Get: A_arbace_classes_env_member_methods_A_get}

var A_arbace_classes_env_member_methods_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$member_methods", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_env_A_class, Simple: "member_methods", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_member_methods_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_member_methods_A_class.Info(); i.IsInstance = A_arbace_classes_env_member_methods_A_InstanceOf; i.Init = A_arbace_classes_env_member_methods_A_Init; i.Table = A_arbace_classes_env_member_methods_A_members; jrt.RegisterGoType(A_arbace_classes_env_member_methods_A_class, reflect.TypeFor[A_arbace_classes_env_member_methods_A]()) }

func A_arbace_classes_env_member_methods_iter__28000175__28000179_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_member_methods_iter__28000175__28000179_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_member_methods_iter__28000175__28000179_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_member_methods_iter__28000175__28000179_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_env_member_methods_iter__28000175__28000179_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_member_methods_iter__28000175__28000179_A_fn_class)}; return nil }

var A_arbace_classes_env_member_methods_iter__28000175__28000179_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_member_methods_iter__28000175__28000179_A_invoke, New: A_arbace_classes_env_member_methods_iter__28000175__28000179_A_new, Get: A_arbace_classes_env_member_methods_iter__28000175__28000179_A_get}

var A_arbace_classes_env_member_methods_iter__28000175__28000179_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$member_methods$iter__28000175__28000179", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_member_methods_A_class, Simple: "iter__28000175__28000179", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_member_methods_iter__28000175__28000179_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_member_methods_iter__28000175__28000179_A_class.Info(); i.IsInstance = A_arbace_classes_env_member_methods_iter__28000175__28000179_A_InstanceOf; i.Init = A_arbace_classes_env_member_methods_iter__28000175__28000179_A_Init; i.Table = A_arbace_classes_env_member_methods_iter__28000175__28000179_A_members; jrt.RegisterGoType(A_arbace_classes_env_member_methods_iter__28000175__28000179_A_class, reflect.TypeFor[A_arbace_classes_env_member_methods_iter__28000175__28000179_A]()) }

func A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_New_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_fn_class)}; return nil }

var A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_invoke, New: A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_new, Get: A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_get}

var A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$member_methods$iter__28000175__28000179$fn__28000180", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_env_member_methods_iter__28000175__28000179_A_class, Simple: "fn__28000180", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_class.Info(); i.IsInstance = A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_InstanceOf; i.Init = A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_Init; i.Table = A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_members; jrt.RegisterGoType(A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_class, reflect.TypeFor[A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A]()) }

func A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_New_O_O_O_O_O_I_O(args[0], args[1], args[2], args[3], args[4], args[5].(int32), args[6])}; return nil }

func A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_fn_class)}; return nil }

var A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_invoke, New: A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_new, Get: A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_get}

var A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$member_methods$iter__28000175__28000179$fn__28000180$fn__28000181", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_A_class, Simple: "fn__28000181", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_class.Info(); i.IsInstance = A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_InstanceOf; i.Init = A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_Init; i.Table = A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_members; jrt.RegisterGoType(A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A_class, reflect.TypeFor[A_arbace_classes_env_member_methods_iter__28000175__28000179_fn__28000180_fn__28000181_A]()) }

func A_arbace_classes_env_nest_host_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_nest_host_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_nest_host_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_nest_host_A_New()}; return nil }

func A_arbace_classes_env_nest_host_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_nest_host_A_fn_class)}; return nil }

var A_arbace_classes_env_nest_host_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_nest_host_A_invoke, New: A_arbace_classes_env_nest_host_A_new, Get: A_arbace_classes_env_nest_host_A_get}

var A_arbace_classes_env_nest_host_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$nest_host", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_A_class, Simple: "nest_host", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_nest_host_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_nest_host_A_class.Info(); i.IsInstance = A_arbace_classes_env_nest_host_A_InstanceOf; i.Init = A_arbace_classes_env_nest_host_A_Init; i.Table = A_arbace_classes_env_nest_host_A_members; jrt.RegisterGoType(A_arbace_classes_env_nest_host_A_class, reflect.TypeFor[A_arbace_classes_env_nest_host_A]()) }

func A_arbace_classes_env_params_key_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_params_key_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_params_key_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_params_key_A_New()}; return nil }

func A_arbace_classes_env_params_key_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_params_key_A_fn_class)}; return nil }

var A_arbace_classes_env_params_key_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_params_key_A_invoke, New: A_arbace_classes_env_params_key_A_new, Get: A_arbace_classes_env_params_key_A_get}

var A_arbace_classes_env_params_key_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$params_key", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_A_class, Simple: "params_key", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_params_key_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_params_key_A_class.Info(); i.IsInstance = A_arbace_classes_env_params_key_A_InstanceOf; i.Init = A_arbace_classes_env_params_key_A_Init; i.Table = A_arbace_classes_env_params_key_A_members; jrt.RegisterGoType(A_arbace_classes_env_params_key_A_class, reflect.TypeFor[A_arbace_classes_env_params_key_A]()) }

func A_arbace_classes_env_read_fields_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_read_fields_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_read_fields_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_read_fields_A_New()}; return nil }

func A_arbace_classes_env_read_fields_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_read_fields_A_fn_class)}; return nil }

var A_arbace_classes_env_read_fields_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_read_fields_A_invoke, New: A_arbace_classes_env_read_fields_A_new, Get: A_arbace_classes_env_read_fields_A_get}

var A_arbace_classes_env_read_fields_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$read_fields", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_A_class, Simple: "read_fields", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_read_fields_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_read_fields_A_class.Info(); i.IsInstance = A_arbace_classes_env_read_fields_A_InstanceOf; i.Init = A_arbace_classes_env_read_fields_A_Init; i.Table = A_arbace_classes_env_read_fields_A_members; jrt.RegisterGoType(A_arbace_classes_env_read_fields_A_class, reflect.TypeFor[A_arbace_classes_env_read_fields_A]()) }

func A_arbace_classes_env_read_method_annotations_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_read_method_annotations_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_read_method_annotations_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_read_method_annotations_A_New()}; return nil }

func A_arbace_classes_env_read_method_annotations_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_read_method_annotations_A_fn_class)}; return nil }

var A_arbace_classes_env_read_method_annotations_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_read_method_annotations_A_invoke, New: A_arbace_classes_env_read_method_annotations_A_new, Get: A_arbace_classes_env_read_method_annotations_A_get}

var A_arbace_classes_env_read_method_annotations_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$read_method_annotations", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_A_class, Simple: "read_method_annotations", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_read_method_annotations_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_read_method_annotations_A_class.Info(); i.IsInstance = A_arbace_classes_env_read_method_annotations_A_InstanceOf; i.Init = A_arbace_classes_env_read_method_annotations_A_Init; i.Table = A_arbace_classes_env_read_method_annotations_A_members; jrt.RegisterGoType(A_arbace_classes_env_read_method_annotations_A_class, reflect.TypeFor[A_arbace_classes_env_read_method_annotations_A]()) }

func A_arbace_classes_env_record_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_record_BANG__A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_env_record_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_record_BANG__A_New()}; return nil }

func A_arbace_classes_env_record_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_record_BANG__A_fn_class)}; return nil }

var A_arbace_classes_env_record_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_record_BANG__A_invoke, New: A_arbace_classes_env_record_BANG__A_new, Get: A_arbace_classes_env_record_BANG__A_get}

var A_arbace_classes_env_record_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$record_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_classes_env_A_class, Simple: "record_BANG_", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_record_BANG__A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_record_BANG__A_class.Info(); i.IsInstance = A_arbace_classes_env_record_BANG__A_InstanceOf; i.Init = A_arbace_classes_env_record_BANG__A_Init; i.Table = A_arbace_classes_env_record_BANG__A_members; jrt.RegisterGoType(A_arbace_classes_env_record_BANG__A_class, reflect.TypeFor[A_arbace_classes_env_record_BANG__A]()) }

func A_arbace_classes_env_reflect_info_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_reflect_info_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_reflect_info_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_reflect_info_A_New()}; return nil }

func A_arbace_classes_env_reflect_info_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_reflect_info_A_fn_class)}; return nil }

var A_arbace_classes_env_reflect_info_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_reflect_info_A_invoke, New: A_arbace_classes_env_reflect_info_A_new, Get: A_arbace_classes_env_reflect_info_A_get}

var A_arbace_classes_env_reflect_info_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$reflect_info", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_A_class, Simple: "reflect_info", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_reflect_info_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_reflect_info_A_class.Info(); i.IsInstance = A_arbace_classes_env_reflect_info_A_InstanceOf; i.Init = A_arbace_classes_env_reflect_info_A_Init; i.Table = A_arbace_classes_env_reflect_info_A_members; jrt.RegisterGoType(A_arbace_classes_env_reflect_info_A_class, reflect.TypeFor[A_arbace_classes_env_reflect_info_A]()) }

func A_arbace_classes_env_reflect_info_fn__28000027_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_reflect_info_fn__28000027_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_env_reflect_info_fn__28000027_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_reflect_info_fn__28000027_A_New_O(args[0])}; return nil }

func A_arbace_classes_env_reflect_info_fn__28000027_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_reflect_info_fn__28000027_A_fn_class)}; return nil }

var A_arbace_classes_env_reflect_info_fn__28000027_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_reflect_info_fn__28000027_A_invoke, New: A_arbace_classes_env_reflect_info_fn__28000027_A_new, Get: A_arbace_classes_env_reflect_info_fn__28000027_A_get}

var A_arbace_classes_env_reflect_info_fn__28000027_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$reflect_info$fn__28000027", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_env_reflect_info_A_class, Simple: "fn__28000027", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_reflect_info_fn__28000027_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_reflect_info_fn__28000027_A_class.Info(); i.IsInstance = A_arbace_classes_env_reflect_info_fn__28000027_A_InstanceOf; i.Init = A_arbace_classes_env_reflect_info_fn__28000027_A_Init; i.Table = A_arbace_classes_env_reflect_info_fn__28000027_A_members; jrt.RegisterGoType(A_arbace_classes_env_reflect_info_fn__28000027_A_class, reflect.TypeFor[A_arbace_classes_env_reflect_info_fn__28000027_A]()) }

func A_arbace_classes_env_reflect_info_fn__28000089_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_reflect_info_fn__28000089_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_reflect_info_fn__28000089_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_reflect_info_fn__28000089_A_New()}; return nil }

func A_arbace_classes_env_reflect_info_fn__28000089_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_reflect_info_fn__28000089_A_fn_class)}; return nil }

var A_arbace_classes_env_reflect_info_fn__28000089_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_reflect_info_fn__28000089_A_invoke, New: A_arbace_classes_env_reflect_info_fn__28000089_A_new, Get: A_arbace_classes_env_reflect_info_fn__28000089_A_get}

var A_arbace_classes_env_reflect_info_fn__28000089_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$reflect_info$fn__28000089", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_reflect_info_A_class, Simple: "fn__28000089", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_reflect_info_fn__28000089_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_reflect_info_fn__28000089_A_class.Info(); i.IsInstance = A_arbace_classes_env_reflect_info_fn__28000089_A_InstanceOf; i.Init = A_arbace_classes_env_reflect_info_fn__28000089_A_Init; i.Table = A_arbace_classes_env_reflect_info_fn__28000089_A_members; jrt.RegisterGoType(A_arbace_classes_env_reflect_info_fn__28000089_A_class, reflect.TypeFor[A_arbace_classes_env_reflect_info_fn__28000089_A]()) }

func A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_reflect_info_iter__28000031__28000035_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_New_O(args[0])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_fn_class)}; return nil }

var A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_invoke, New: A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_new, Get: A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_get}

var A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$reflect_info$iter__28000031__28000035", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_reflect_info_A_class, Simple: "iter__28000031__28000035", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_reflect_info_iter__28000031__28000035_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_class.Info(); i.IsInstance = A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_InstanceOf; i.Init = A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_Init; i.Table = A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_members; jrt.RegisterGoType(A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_class, reflect.TypeFor[A_arbace_classes_env_reflect_info_iter__28000031__28000035_A]()) }

func A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_fn_class)}; return nil }

var A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_invoke, New: A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_new, Get: A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_get}

var A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$reflect_info$iter__28000031__28000035$fn__28000036", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_env_reflect_info_iter__28000031__28000035_A_class, Simple: "fn__28000036", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_class.Info(); i.IsInstance = A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_InstanceOf; i.Init = A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_Init; i.Table = A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_members; jrt.RegisterGoType(A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_class, reflect.TypeFor[A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A]()) }

func A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_fn_class)}; return nil }

var A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_invoke, New: A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_new, Get: A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_get}

var A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$reflect_info$iter__28000031__28000035$fn__28000036$fn__28000037", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_A_class, Simple: "fn__28000037", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_class.Info(); i.IsInstance = A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_InstanceOf; i.Init = A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_Init; i.Table = A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_members; jrt.RegisterGoType(A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A_class, reflect.TypeFor[A_arbace_classes_env_reflect_info_iter__28000031__28000035_fn__28000036_fn__28000037_A]()) }

func A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_reflect_info_iter__28000045__28000049_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_New_O(args[0])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_fn_class)}; return nil }

var A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_invoke, New: A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_new, Get: A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_get}

var A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$reflect_info$iter__28000045__28000049", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_reflect_info_A_class, Simple: "iter__28000045__28000049", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_reflect_info_iter__28000045__28000049_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_class.Info(); i.IsInstance = A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_InstanceOf; i.Init = A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_Init; i.Table = A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_members; jrt.RegisterGoType(A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_class, reflect.TypeFor[A_arbace_classes_env_reflect_info_iter__28000045__28000049_A]()) }

func A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_fn_class)}; return nil }

var A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_invoke, New: A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_new, Get: A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_get}

var A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$reflect_info$iter__28000045__28000049$fn__28000050", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_env_reflect_info_iter__28000045__28000049_A_class, Simple: "fn__28000050", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_class.Info(); i.IsInstance = A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_InstanceOf; i.Init = A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_Init; i.Table = A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_members; jrt.RegisterGoType(A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_class, reflect.TypeFor[A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A]()) }

func A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_fn_class)}; return nil }

var A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_invoke, New: A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_new, Get: A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_get}

var A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$reflect_info$iter__28000045__28000049$fn__28000050$fn__28000051", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_A_class, Simple: "fn__28000051", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_class.Info(); i.IsInstance = A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_InstanceOf; i.Init = A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_Init; i.Table = A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_members; jrt.RegisterGoType(A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A_class, reflect.TypeFor[A_arbace_classes_env_reflect_info_iter__28000045__28000049_fn__28000050_fn__28000051_A]()) }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_reflect_info_iter__28000055__28000059_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_fn_class)}; return nil }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_invoke, New: A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_new, Get: A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_get}

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$reflect_info$iter__28000055__28000059", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_reflect_info_A_class, Simple: "iter__28000055__28000059", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_reflect_info_iter__28000055__28000059_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_class.Info(); i.IsInstance = A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_InstanceOf; i.Init = A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_Init; i.Table = A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_members; jrt.RegisterGoType(A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_class, reflect.TypeFor[A_arbace_classes_env_reflect_info_iter__28000055__28000059_A]()) }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_fn_class)}; return nil }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_invoke, New: A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_new, Get: A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_get}

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$reflect_info$iter__28000055__28000059$fn__28000060", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_env_reflect_info_iter__28000055__28000059_A_class, Simple: "fn__28000060", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_class.Info(); i.IsInstance = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_InstanceOf; i.Init = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_Init; i.Table = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_members; jrt.RegisterGoType(A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_class, reflect.TypeFor[A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A]()) }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_New_O_O_O_I_O(args[0], args[1], args[2], args[3].(int32), args[4])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_fn_class)}; return nil }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_invoke, New: A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_new, Get: A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_get}

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$reflect_info$iter__28000055__28000059$fn__28000060$fn__28000061", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_class, Simple: "fn__28000061", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_class.Info(); i.IsInstance = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_InstanceOf; i.Init = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_Init; i.Table = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_members; jrt.RegisterGoType(A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_class, reflect.TypeFor[A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A]()) }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_fn_class)}; return nil }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_invoke, New: A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_new, Get: A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_get}

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$reflect_info$iter__28000055__28000059$fn__28000060$fn__28000061$fn__28000062", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_class, Simple: "fn__28000062", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_class.Info(); i.IsInstance = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_InstanceOf; i.Init = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_Init; i.Table = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_members; jrt.RegisterGoType(A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A_class, reflect.TypeFor[A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000062_A]()) }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_fn_class)}; return nil }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_invoke, New: A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_new, Get: A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_get}

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$reflect_info$iter__28000055__28000059$fn__28000060$fn__28000061$fn__28000064", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_A_class, Simple: "fn__28000064", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_class.Info(); i.IsInstance = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_InstanceOf; i.Init = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_Init; i.Table = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_members; jrt.RegisterGoType(A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_class, reflect.TypeFor[A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A]()) }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_fn_class)}; return nil }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_invoke, New: A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_new, Get: A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_get}

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$reflect_info$iter__28000055__28000059$fn__28000060$fn__28000061$fn__28000064$fn__28000065", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_A_class, Simple: "fn__28000065", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_class.Info(); i.IsInstance = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_InstanceOf; i.Init = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_Init; i.Table = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_members; jrt.RegisterGoType(A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A_class, reflect.TypeFor[A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000061_fn__28000064_fn__28000065_A]()) }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_fn_class)}; return nil }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_invoke, New: A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_new, Get: A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_get}

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$reflect_info$iter__28000055__28000059$fn__28000060$fn__28000069", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_class, Simple: "fn__28000069", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_class.Info(); i.IsInstance = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_InstanceOf; i.Init = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_Init; i.Table = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_members; jrt.RegisterGoType(A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A_class, reflect.TypeFor[A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000069_A]()) }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_fn_class)}; return nil }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_invoke, New: A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_new, Get: A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_get}

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$reflect_info$iter__28000055__28000059$fn__28000060$fn__28000071", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_A_class, Simple: "fn__28000071", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_class.Info(); i.IsInstance = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_InstanceOf; i.Init = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_Init; i.Table = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_members; jrt.RegisterGoType(A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_class, reflect.TypeFor[A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A]()) }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_fn_class)}; return nil }

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_invoke, New: A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_new, Get: A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_get}

var A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$reflect_info$iter__28000055__28000059$fn__28000060$fn__28000071$fn__28000072", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_A_class, Simple: "fn__28000072", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_class.Info(); i.IsInstance = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_InstanceOf; i.Init = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_Init; i.Table = A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_members; jrt.RegisterGoType(A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A_class, reflect.TypeFor[A_arbace_classes_env_reflect_info_iter__28000055__28000059_fn__28000060_fn__28000071_fn__28000072_A]()) }

func A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_reflect_info_iter__28000077__28000081_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_fn_class)}; return nil }

var A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_invoke, New: A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_new, Get: A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_get}

var A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$reflect_info$iter__28000077__28000081", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_reflect_info_A_class, Simple: "iter__28000077__28000081", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_reflect_info_iter__28000077__28000081_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_class.Info(); i.IsInstance = A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_InstanceOf; i.Init = A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_Init; i.Table = A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_members; jrt.RegisterGoType(A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_class, reflect.TypeFor[A_arbace_classes_env_reflect_info_iter__28000077__28000081_A]()) }

func A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_fn_class)}; return nil }

var A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_invoke, New: A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_new, Get: A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_get}

var A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$reflect_info$iter__28000077__28000081$fn__28000082", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_env_reflect_info_iter__28000077__28000081_A_class, Simple: "fn__28000082", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_class.Info(); i.IsInstance = A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_InstanceOf; i.Init = A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_Init; i.Table = A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_members; jrt.RegisterGoType(A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_class, reflect.TypeFor[A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A]()) }

func A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_New_O_O_O_I_O(args[0], args[1], args[2], args[3].(int32), args[4])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_fn_class)}; return nil }

var A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_invoke, New: A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_new, Get: A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_get}

var A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$reflect_info$iter__28000077__28000081$fn__28000082$fn__28000083", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_A_class, Simple: "fn__28000083", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_class.Info(); i.IsInstance = A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_InstanceOf; i.Init = A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_Init; i.Table = A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_members; jrt.RegisterGoType(A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A_class, reflect.TypeFor[A_arbace_classes_env_reflect_info_iter__28000077__28000081_fn__28000082_fn__28000083_A]()) }

func A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_reflect_info_iter__28000091__28000095_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_New_O(args[0])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_fn_class)}; return nil }

var A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_invoke, New: A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_new, Get: A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_get}

var A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$reflect_info$iter__28000091__28000095", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_reflect_info_A_class, Simple: "iter__28000091__28000095", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_reflect_info_iter__28000091__28000095_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_class.Info(); i.IsInstance = A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_InstanceOf; i.Init = A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_Init; i.Table = A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_members; jrt.RegisterGoType(A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_class, reflect.TypeFor[A_arbace_classes_env_reflect_info_iter__28000091__28000095_A]()) }

func A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_fn_class)}; return nil }

var A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_invoke, New: A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_new, Get: A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_get}

var A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$reflect_info$iter__28000091__28000095$fn__28000096", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_env_reflect_info_iter__28000091__28000095_A_class, Simple: "fn__28000096", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_class.Info(); i.IsInstance = A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_InstanceOf; i.Init = A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_Init; i.Table = A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_members; jrt.RegisterGoType(A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_class, reflect.TypeFor[A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A]()) }

func A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_New_O_I_O_O(args[0], args[1].(int32), args[2], args[3])}; return nil }

func A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_fn_class)}; return nil }

var A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_invoke, New: A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_new, Get: A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_get}

var A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$reflect_info$iter__28000091__28000095$fn__28000096$fn__28000097", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_A_class, Simple: "fn__28000097", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_class.Info(); i.IsInstance = A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_InstanceOf; i.Init = A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_Init; i.Table = A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_members; jrt.RegisterGoType(A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A_class, reflect.TypeFor[A_arbace_classes_env_reflect_info_iter__28000091__28000095_fn__28000096_fn__28000097_A]()) }

func A_arbace_classes_env_reflected_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_reflected_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_classes_env_reflected_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_reflected_A_New()}; return nil }

func A_arbace_classes_env_reflected_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_reflected_A_fn_class)}; return nil }

var A_arbace_classes_env_reflected_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_reflected_A_invoke, New: A_arbace_classes_env_reflected_A_new, Get: A_arbace_classes_env_reflected_A_get}

var A_arbace_classes_env_reflected_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$reflected", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_classes_env_A_class, Simple: "reflected", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_reflected_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_reflected_A_class.Info(); i.IsInstance = A_arbace_classes_env_reflected_A_InstanceOf; i.Init = A_arbace_classes_env_reflected_A_Init; i.Table = A_arbace_classes_env_reflected_A_members; jrt.RegisterGoType(A_arbace_classes_env_reflected_A_class, reflect.TypeFor[A_arbace_classes_env_reflected_A]()) }

func A_arbace_classes_env_subclass_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_subclass_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_env_subclass_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_subclass_QMARK__A_New()}; return nil }

func A_arbace_classes_env_subclass_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_subclass_QMARK__A_fn_class)}; return nil }

var A_arbace_classes_env_subclass_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_subclass_QMARK__A_invoke, New: A_arbace_classes_env_subclass_QMARK__A_new, Get: A_arbace_classes_env_subclass_QMARK__A_get}

var A_arbace_classes_env_subclass_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$subclass_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_env_A_class, Simple: "subclass_QMARK_", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_subclass_QMARK__A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_subclass_QMARK__A_class.Info(); i.IsInstance = A_arbace_classes_env_subclass_QMARK__A_InstanceOf; i.Init = A_arbace_classes_env_subclass_QMARK__A_Init; i.Table = A_arbace_classes_env_subclass_QMARK__A_members; jrt.RegisterGoType(A_arbace_classes_env_subclass_QMARK__A_class, reflect.TypeFor[A_arbace_classes_env_subclass_QMARK__A]()) }

func A_arbace_classes_env_subclass_QMARK__fn__28000117_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_subclass_QMARK__fn__28000117_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_subclass_QMARK__fn__28000117_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_subclass_QMARK__fn__28000117_A_New_O(args[0])}; return nil }

func A_arbace_classes_env_subclass_QMARK__fn__28000117_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_subclass_QMARK__fn__28000117_A_fn_class)}; return nil }

var A_arbace_classes_env_subclass_QMARK__fn__28000117_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_subclass_QMARK__fn__28000117_A_invoke, New: A_arbace_classes_env_subclass_QMARK__fn__28000117_A_new, Get: A_arbace_classes_env_subclass_QMARK__fn__28000117_A_get}

var A_arbace_classes_env_subclass_QMARK__fn__28000117_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$subclass_QMARK_$fn__28000117", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_subclass_QMARK__A_class, Simple: "fn__28000117", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_subclass_QMARK__fn__28000117_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_subclass_QMARK__fn__28000117_A_class.Info(); i.IsInstance = A_arbace_classes_env_subclass_QMARK__fn__28000117_A_InstanceOf; i.Init = A_arbace_classes_env_subclass_QMARK__fn__28000117_A_Init; i.Table = A_arbace_classes_env_subclass_QMARK__fn__28000117_A_members; jrt.RegisterGoType(A_arbace_classes_env_subclass_QMARK__fn__28000117_A_class, reflect.TypeFor[A_arbace_classes_env_subclass_QMARK__fn__28000117_A]()) }

func A_arbace_classes_env_superclass_chain_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_superclass_chain_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_superclass_chain_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_superclass_chain_A_New()}; return nil }

func A_arbace_classes_env_superclass_chain_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_superclass_chain_A_fn_class)}; return nil }

var A_arbace_classes_env_superclass_chain_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_superclass_chain_A_invoke, New: A_arbace_classes_env_superclass_chain_A_new, Get: A_arbace_classes_env_superclass_chain_A_get}

var A_arbace_classes_env_superclass_chain_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$superclass_chain", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_A_class, Simple: "superclass_chain", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_superclass_chain_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_superclass_chain_A_class.Info(); i.IsInstance = A_arbace_classes_env_superclass_chain_A_InstanceOf; i.Init = A_arbace_classes_env_superclass_chain_A_Init; i.Table = A_arbace_classes_env_superclass_chain_A_members; jrt.RegisterGoType(A_arbace_classes_env_superclass_chain_A_class, reflect.TypeFor[A_arbace_classes_env_superclass_chain_A]()) }

func A_arbace_classes_env_superclass_chain_fn__28000123_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_superclass_chain_fn__28000123_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_superclass_chain_fn__28000123_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_superclass_chain_fn__28000123_A_New()}; return nil }

func A_arbace_classes_env_superclass_chain_fn__28000123_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_superclass_chain_fn__28000123_A_fn_class)}; return nil }

var A_arbace_classes_env_superclass_chain_fn__28000123_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_superclass_chain_fn__28000123_A_invoke, New: A_arbace_classes_env_superclass_chain_fn__28000123_A_new, Get: A_arbace_classes_env_superclass_chain_fn__28000123_A_get}

var A_arbace_classes_env_superclass_chain_fn__28000123_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$superclass_chain$fn__28000123", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_superclass_chain_A_class, Simple: "fn__28000123", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_superclass_chain_fn__28000123_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_superclass_chain_fn__28000123_A_class.Info(); i.IsInstance = A_arbace_classes_env_superclass_chain_fn__28000123_A_InstanceOf; i.Init = A_arbace_classes_env_superclass_chain_fn__28000123_A_Init; i.Table = A_arbace_classes_env_superclass_chain_fn__28000123_A_members; jrt.RegisterGoType(A_arbace_classes_env_superclass_chain_fn__28000123_A_class, reflect.TypeFor[A_arbace_classes_env_superclass_chain_fn__28000123_A]()) }

func A_arbace_classes_env_supertypes_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_env_supertypes_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_env_supertypes_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env_supertypes_A_New()}; return nil }

func A_arbace_classes_env_supertypes_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_env_supertypes_A_fn_class)}; return nil }

var A_arbace_classes_env_supertypes_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_env_supertypes_A_invoke, New: A_arbace_classes_env_supertypes_A_new, Get: A_arbace_classes_env_supertypes_A_get}

var A_arbace_classes_env_supertypes_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env$supertypes", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_env_A_class, Simple: "supertypes", Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env_supertypes_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env_supertypes_A_class.Info(); i.IsInstance = A_arbace_classes_env_supertypes_A_InstanceOf; i.Init = A_arbace_classes_env_supertypes_A_Init; i.Table = A_arbace_classes_env_supertypes_A_members; jrt.RegisterGoType(A_arbace_classes_env_supertypes_A_class, reflect.TypeFor[A_arbace_classes_env_supertypes_A]()) }

func A_arbace_classes_env__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_classes_env__init_A_Load__O(); case 1: return A_arbace_classes_env__init_A_Unit0__O(); case 2: return A_arbace_classes_env__init_A_Unit1__O(); case 3: return A_arbace_classes_env__init_A_Unit10__O(); case 4: return A_arbace_classes_env__init_A_Unit11__O(); case 5: return A_arbace_classes_env__init_A_Unit12__O(); case 6: return A_arbace_classes_env__init_A_Unit13__O(); case 7: return A_arbace_classes_env__init_A_Unit14__O(); case 8: return A_arbace_classes_env__init_A_Unit15__O(); case 9: return A_arbace_classes_env__init_A_Unit16__O(); case 10: return A_arbace_classes_env__init_A_Unit17__O(); case 11: return A_arbace_classes_env__init_A_Unit18__O(); case 12: return A_arbace_classes_env__init_A_Unit19__O(); case 13: return A_arbace_classes_env__init_A_Unit2__O(); case 14: return A_arbace_classes_env__init_A_Unit20__O(); case 15: return A_arbace_classes_env__init_A_Unit21__O(); case 16: return A_arbace_classes_env__init_A_Unit22__O(); case 17: return A_arbace_classes_env__init_A_Unit23__O(); case 18: return A_arbace_classes_env__init_A_Unit24__O(); case 19: return A_arbace_classes_env__init_A_Unit25__O(); case 20: return A_arbace_classes_env__init_A_Unit26__O(); case 21: return A_arbace_classes_env__init_A_Unit27__O(); case 22: return A_arbace_classes_env__init_A_Unit28__O(); case 23: return A_arbace_classes_env__init_A_Unit29__O(); case 24: return A_arbace_classes_env__init_A_Unit3__O(); case 25: return A_arbace_classes_env__init_A_Unit30__O(); case 26: return A_arbace_classes_env__init_A_Unit31__O(); case 27: return A_arbace_classes_env__init_A_Unit32__O(); case 28: return A_arbace_classes_env__init_A_Unit33__O(); case 29: return A_arbace_classes_env__init_A_Unit34__O(); case 30: return A_arbace_classes_env__init_A_Unit35__O(); case 31: return A_arbace_classes_env__init_A_Unit36__O(); case 32: return A_arbace_classes_env__init_A_Unit37__O(); case 33: return A_arbace_classes_env__init_A_Unit38__O(); case 34: return A_arbace_classes_env__init_A_Unit39__O(); case 35: return A_arbace_classes_env__init_A_Unit4__O(); case 36: return A_arbace_classes_env__init_A_Unit40__O(); case 37: return A_arbace_classes_env__init_A_Unit5__O(); case 38: return A_arbace_classes_env__init_A_Unit6__O(); case 39: return A_arbace_classes_env__init_A_Unit7__O(); case 40: return A_arbace_classes_env__init_A_Unit8__O(); case 41: return A_arbace_classes_env__init_A_Unit9__O()}; return nil }

func A_arbace_classes_env__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_env__init_A_New()}; return nil }

var A_arbace_classes_env__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit28 ()Ljava.lang.Object;\nM9 unit29 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit30 ()Ljava.lang.Object;\nM9 unit31 ()Ljava.lang.Object;\nM9 unit32 ()Ljava.lang.Object;\nM9 unit33 ()Ljava.lang.Object;\nM9 unit34 ()Ljava.lang.Object;\nM9 unit35 ()Ljava.lang.Object;\nM9 unit36 ()Ljava.lang.Object;\nM9 unit37 ()Ljava.lang.Object;\nM9 unit38 ()Ljava.lang.Object;\nM9 unit39 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit40 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_classes_env__init_A_invoke, New: A_arbace_classes_env__init_A_new}

var A_arbace_classes_env__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.env__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_classes_env.A_arbace_classes_env__init_A", Source: "env.ae"})

func init() { i := A_arbace_classes_env__init_A_class.Info(); i.IsInstance = A_arbace_classes_env__init_A_InstanceOf; i.Init = A_arbace_classes_env__init_A_Init; i.Table = A_arbace_classes_env__init_A_members; jrt.RegisterGoType(A_arbace_classes_env__init_A_class, reflect.TypeFor[A_arbace_classes_env__init_A]()) }
