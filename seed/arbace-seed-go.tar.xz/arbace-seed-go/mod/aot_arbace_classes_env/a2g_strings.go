//line a2g_strings.ae:1
package aot_arbace_classes_env

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("require")

var Lit_3 *jrt.String = jrt.Intern("arbace.string")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("str")

var Lit_6 *jrt.String = jrt.Intern("arbace.set")

var Lit_7 *jrt.String = jrt.Intern("arbace.classes.types")

var Lit_8 *jrt.String = jrt.Intern("t")

var Lit_9 *jrt.String = jrt.Intern("arbace.classes.opcodes")

var Lit_10 *jrt.String = jrt.Intern("Opcodes")

var Lit_11 *jrt.String = jrt.Intern("commute")

var Lit_12 *jrt.String = jrt.Intern("deref")

var Lit_13 *jrt.String = jrt.Intern("conj")

var Lit_14 *jrt.String = jrt.Intern("arbace.classes.env")

var Lit_15 *jrt.String = jrt.Intern("doc")

var Lit_16 *jrt.String = jrt.Intern("The class environment (SPEC §9.2): what the compiler knows about classes, from the class\n  forms being compiled, from classes it defined earlier, from the edge's declared classes (a2g)\n  and from the class path (by reflection; on a JVM, with constant values and annotations read\n  from class files by arbace.classes.jvm). Member lookup with Java's access rules (§5.6).")

var Lit_17 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_18 *jrt.String = jrt.Intern("replace")

var Lit_19 *jrt.String = jrt.Intern("*from-source*")

var Lit_20 *jrt.String = jrt.Intern("*recorded*")

var Lit_21 *jrt.String = jrt.Intern("swap!")

var Lit_22 *jrt.String = jrt.Intern("update")

var Lit_23 *jrt.String = jrt.Intern("assoc")

var Lit_24 *jrt.String = jrt.Intern("from-source?")

var Lit_25 *jrt.String = jrt.Intern("*declared*")

var Lit_26 *jrt.String = jrt.Intern("starts-with?")

var Lit_27 *jrt.String = jrt.Intern("record!")

var Lit_28 *jrt.String = jrt.Intern("exists")

var Lit_29 *jrt.String = jrt.Intern("contains?")

var Lit_30 *jrt.String = jrt.Intern("some?")

var Lit_31 *jrt.String = jrt.Intern("load-class")

var Lit_32 *jrt.String = jrt.Intern("find")

var Lit_33 *jrt.String = jrt.Intern("val")

var Lit_34 *jrt.String = jrt.Intern("ex-info")

var Lit_35 *jrt.String = jrt.Intern("name")

var Lit_36 *jrt.String = jrt.Intern("class")

var Lit_37 *jrt.String = jrt.Intern("facet")

var Lit_38 *jrt.String = jrt.Intern("java.lang.ClassLoader")

var Lit_39 *jrt.String = jrt.Intern("internal")

var Lit_40 *jrt.String = jrt.Intern("class-file?")

var Lit_41 *jrt.String = jrt.Intern("requiring-resolve")

var Lit_42 *jrt.String = jrt.Intern("arbace.classes.jvm")

var Lit_43 *jrt.String = jrt.Intern("read-fields")

var Lit_44 *jrt.String = jrt.Intern("read-method-annotations")

var Lit_45 *jrt.String = jrt.Intern("not")

var Lit_46 *jrt.String = jrt.Intern("reflect-cache")

var Lit_47 *jrt.String = jrt.Intern("flags")

var Lit_48 *jrt.String = jrt.Intern("interface?")

var Lit_49 *jrt.String = jrt.Intern("super")

var Lit_50 *jrt.String = jrt.Intern("interfaces")

var Lit_51 *jrt.String = jrt.Intern("mapv")

var Lit_52 *jrt.String = jrt.Intern("nest-host")

var Lit_53 *jrt.String = jrt.Intern("outer")

var Lit_54 *jrt.String = jrt.Intern("fields")

var Lit_55 *jrt.String = jrt.Intern("vec")

var Lit_56 *jrt.String = jrt.Intern("outer-instance?")

var Lit_57 *jrt.String = jrt.Intern("inner-member?")

var Lit_58 *jrt.String = jrt.Intern("methods")

var Lit_59 *jrt.String = jrt.Intern("empty?")

var Lit_60 *jrt.String = jrt.Intern("seq")

var Lit_61 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_62 *jrt.String = jrt.Intern("chunk-first")

var Lit_63 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_64 *jrt.String = jrt.Intern("next")

var Lit_65 *jrt.String = jrt.Intern("to-array")

var Lit_66 *jrt.String = jrt.Intern("first")

var Lit_67 *jrt.String = jrt.Intern("desc")

var Lit_68 *jrt.String = jrt.Intern("value")

var Lit_69 *jrt.String = jrt.Intern("chunk-append")

var Lit_70 *jrt.String = jrt.Intern("owner")

var Lit_71 *jrt.String = jrt.Intern("const")

var Lit_72 *jrt.String = jrt.Intern("prim?")

var Lit_73 *jrt.String = jrt.Intern("string-desc")

var Lit_74 *jrt.String = jrt.Intern("coerce-const")

var Lit_75 *jrt.String = jrt.Intern("chunk-cons")

var Lit_76 *jrt.String = jrt.Intern("cons")

var Lit_77 *jrt.String = jrt.Intern("chunk")

var Lit_78 *jrt.String = jrt.Intern("chunk-rest")

var Lit_79 *jrt.String = jrt.Intern("rest")

var Lit_80 *jrt.String = jrt.Intern("class->desc")

var Lit_81 *jrt.String = jrt.Intern("concat")

var Lit_82 *jrt.String = jrt.Intern("method-desc")

var Lit_83 *jrt.String = jrt.Intern("map")

var Lit_84 *jrt.String = jrt.Intern("throws")

var Lit_85 *jrt.String = jrt.Intern("annotations")

var Lit_86 *jrt.String = jrt.Intern("get-in")

var Lit_87 *jrt.String = jrt.Intern("param-annotations")

var Lit_88 *jrt.String = jrt.Intern("map-indexed")

var Lit_89 *jrt.String = jrt.Intern("filter")

var Lit_90 *jrt.String = jrt.Intern("into")

var Lit_91 *jrt.String = jrt.Intern("arbace.classes.go")

var Lit_92 *jrt.String = jrt.Intern("constructors")

var Lit_93 *jrt.String = jrt.Intern("*compile-set*")

var Lit_94 *jrt.String = jrt.Intern("info")

var Lit_95 *jrt.String = jrt.Intern("reflect-info")

var Lit_96 *jrt.String = jrt.Intern("defined")

var Lit_97 *jrt.String = jrt.Intern("delay?")

var Lit_98 *jrt.String = jrt.Intern("info!")

var Lit_99 *jrt.String = jrt.Intern("some")

var Lit_100 *jrt.String = jrt.Intern("subclass?")

var Lit_101 *jrt.String = jrt.Intern("null")

var Lit_102 *jrt.String = jrt.Intern("ref?")

var Lit_103 *jrt.String = jrt.Intern("object-desc")

var Lit_104 *jrt.String = jrt.Intern("array?")

var Lit_105 *jrt.String = jrt.Intern("elem-type")

var Lit_106 *jrt.String = jrt.Intern("assignable?")

var Lit_107 *jrt.String = jrt.Intern("else")

var Lit_108 *jrt.String = jrt.Intern("Ljava/io/Serializable;")

var Lit_109 *jrt.String = jrt.Intern("Ljava/lang/Cloneable;")

var Lit_110 *jrt.String = jrt.Intern("desc->internal")

var Lit_111 *jrt.String = jrt.Intern("take-while")

var Lit_112 *jrt.String = jrt.Intern("iterate")

var Lit_113 *jrt.String = jrt.Intern("set")

var Lit_114 *jrt.String = jrt.Intern("superclass-chain")

var Lit_115 *jrt.String = jrt.Intern("class-desc?")

var Lit_116 *jrt.String = jrt.Intern("common-super")

var Lit_117 *jrt.String = jrt.Intern("tree-seq")

var Lit_118 *jrt.String = jrt.Intern("remove")

var Lit_119 *jrt.String = jrt.Intern("internal->desc")

var Lit_120 *jrt.String = jrt.Intern("intersection")

var Lit_121 *jrt.String = jrt.Intern("not=")

var Lit_122 *jrt.String = jrt.Intern("flag?")

var Lit_123 *jrt.String = jrt.Intern("package-of")

var Lit_124 *jrt.String = jrt.Intern("find-field")

var Lit_125 *jrt.String = jrt.Intern("mapcat")

var Lit_126 *jrt.String = jrt.Intern("subs")

var Lit_127 *jrt.String = jrt.Intern("all-supertypes")

var Lit_128 *jrt.String = jrt.Intern("params-key")

var Lit_129 *jrt.String = jrt.Intern("comp")

var Lit_130 *jrt.String = jrt.Intern("arbace.classes.env$accessible_QMARK_")

var Lit_131 *jrt.String = jrt.Intern("arbace.classes.env$accessible_QMARK_$fn__28000143")

var Lit_132 *jrt.String = jrt.Intern("arbace.classes.env$accessible_QMARK_$fn__28000145")

var Lit_133 *jrt.String = jrt.Intern("arbace.classes.env$all_supertypes")

var Lit_134 *jrt.String = jrt.Intern("java/lang/Object")

var Lit_135 *jrt.String = jrt.Intern("arbace.classes.env$all_supertypes$fn__28000157")

var Lit_136 *jrt.String = jrt.Intern("arbace.classes.env$assignable_QMARK_")

var Lit_137 *jrt.String = jrt.Intern("arbace.classes.env$class_file_QMARK_")

var Lit_138 *jrt.String = jrt.Intern("getResourceAsStream")

var Lit_139 *jrt.String = jrt.Intern(".class")

var Lit_140 *jrt.String = jrt.Intern("arbace.classes.env$coerce_const")

var Lit_141 *jrt.String = jrt.Intern("B")

var Lit_142 *jrt.String = jrt.Intern("C")

var Lit_143 *jrt.String = jrt.Intern("S")

var Lit_144 *jrt.String = jrt.Intern("Z")

var Lit_145 *jrt.String = jrt.Intern("arbace.classes.env$common_super")

var Lit_146 *jrt.String = jrt.Intern("[")

var Lit_147 *jrt.String = jrt.Intern("arbace.classes.env$const_value")

var Lit_148 *jrt.String = jrt.Intern("arbace.classes.env$constructors")

var Lit_149 *jrt.String = jrt.Intern("arbace.classes.env$constructors$fn__28000187")

var Lit_150 *jrt.String = jrt.Intern("<init>")

var Lit_151 *jrt.String = jrt.Intern("arbace.classes.env$eval28000004$loading__1927001464__auto____28000005")

var Lit_152 *jrt.String = jrt.Intern("java.lang.reflect.Field")

var Lit_153 *jrt.String = jrt.Intern("java.lang.reflect.Method")

var Lit_154 *jrt.String = jrt.Intern("java.lang.reflect.Constructor")

var Lit_155 *jrt.String = jrt.Intern("java.lang.reflect.Modifier")

var Lit_156 *jrt.String = jrt.Intern("arbace.classes.env$eval28000008$fn__28000009")

var Lit_157 *jrt.String = jrt.Intern("arbace.classes.env$find_field")

var Lit_158 *jrt.String = jrt.Intern("arbace.classes.env$find_field$fn__28000150")

var Lit_159 *jrt.String = jrt.Intern("arbace.classes.env$find_field$fn__28000152")

var Lit_160 *jrt.String = jrt.Intern("arbace.classes.env$flag_QMARK_")

var Lit_161 *jrt.String = jrt.Intern("arbace.classes.env$from_source_QMARK_")

var Lit_162 *jrt.String = jrt.Intern("arbace.classes.env$info")

var Lit_163 *jrt.String = jrt.Intern("arbace.classes.env$info_BANG_")

var Lit_164 *jrt.String = jrt.Intern("Unknown class: ")

var Lit_165 *jrt.String = jrt.Intern("/")

var Lit_166 *jrt.String = jrt.Intern(".")

var Lit_167 *jrt.String = jrt.Intern("arbace.classes.env$inner_member_QMARK_")

var Lit_168 *jrt.String = jrt.Intern("arbace.classes.env$interface_QMARK_")

var Lit_169 *jrt.String = jrt.Intern("arbace.classes.env$internal")

var Lit_170 *jrt.String = jrt.Intern("arbace.classes.env$known_QMARK_")

var Lit_171 *jrt.String = jrt.Intern("arbace.classes.env$load_class")

var Lit_172 *jrt.String = jrt.Intern("arbace.classes.env$lub")

var Lit_173 *jrt.String = jrt.Intern("arbace.classes.env$lub$fn__28000134")

var Lit_174 *jrt.String = jrt.Intern("arbace.classes.env$lub$fn__28000134$fn__28000135")

var Lit_175 *jrt.String = jrt.Intern("arbace.classes.env$lub$sups__28000129")

var Lit_176 *jrt.String = jrt.Intern("arbace.classes.env$lub$sups__28000129$fn__28000130")

var Lit_177 *jrt.String = jrt.Intern("arbace.classes.env$member_methods")

var Lit_178 *jrt.String = jrt.Intern("arbace.classes.env$member_methods$iter__28000175__28000179")

var Lit_179 *jrt.String = jrt.Intern("arbace.classes.env$member_methods$iter__28000175__28000179$fn__28000180")

var Lit_180 *jrt.String = jrt.Intern("arbace.classes.env$member_methods$iter__28000175__28000179$fn__28000180$fn__28000181")

var Lit_181 *jrt.String = jrt.Intern("arbace.classes.env$nest_host")

var Lit_182 *jrt.String = jrt.Intern("arbace.classes.env$params_key")

var Lit_183 *jrt.String = jrt.Intern(")")

var Lit_184 *jrt.String = jrt.Intern("arbace.classes.env$read_fields")

var Lit_185 *jrt.String = jrt.Intern("arbace.classes.env$read_method_annotations")

var Lit_186 *jrt.String = jrt.Intern("arbace.classes.env$record_BANG_")

var Lit_187 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info")

var Lit_188 *jrt.String = jrt.Intern("get")

var Lit_189 *jrt.String = jrt.Intern("put")

var Lit_190 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$fn__28000027")

var Lit_191 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$fn__28000089")

var Lit_192 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000031__28000035")

var Lit_193 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000031__28000035$fn__28000036")

var Lit_194 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000031__28000035$fn__28000036$fn__28000037")

var Lit_195 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000045__28000049")

var Lit_196 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000045__28000049$fn__28000050")

var Lit_197 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000045__28000049$fn__28000050$fn__28000051")

var Lit_198 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000055__28000059")

var Lit_199 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000055__28000059$fn__28000060")

var Lit_200 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000055__28000059$fn__28000060$fn__28000061")

var Lit_201 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000055__28000059$fn__28000060$fn__28000061$fn__28000062")

var Lit_202 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000055__28000059$fn__28000060$fn__28000061$fn__28000064")

var Lit_203 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000055__28000059$fn__28000060$fn__28000061$fn__28000064$fn__28000065")

var Lit_204 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000055__28000059$fn__28000060$fn__28000069")

var Lit_205 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000055__28000059$fn__28000060$fn__28000071")

var Lit_206 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000055__28000059$fn__28000060$fn__28000071$fn__28000072")

var Lit_207 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000077__28000081")

var Lit_208 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000077__28000081$fn__28000082")

var Lit_209 *jrt.String = jrt.Intern("V")

var Lit_210 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000077__28000081$fn__28000082$fn__28000083")

var Lit_211 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000091__28000095")

var Lit_212 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000091__28000095$fn__28000096")

var Lit_213 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000091__28000095$fn__28000096$fn__28000097")

var Lit_214 *jrt.String = jrt.Intern("arbace.classes.env$reflected")

var Lit_215 *jrt.String = jrt.Intern("Undeclared ")

var Lit_216 *jrt.String = jrt.Intern(" of class ")

var Lit_217 *jrt.String = jrt.Intern(": not in the declared edge (bin/a2g-edge update)")

var Lit_218 *jrt.String = jrt.Intern("arbace.classes.env$subclass_QMARK_")

var Lit_219 *jrt.String = jrt.Intern("arbace.classes.env$subclass_QMARK_$fn__28000117")

var Lit_220 *jrt.String = jrt.Intern("arbace.classes.env$superclass_chain")

var Lit_221 *jrt.String = jrt.Intern("arbace.classes.env$superclass_chain$fn__28000123")

var Lit_222 *jrt.String = jrt.Intern("arbace.classes.env$supertypes")

var Lit_223 *jrt.String = jrt.Intern("in-ns")

var Lit_224 *jrt.String = jrt.Intern("dynamic")

var Lit_225 *jrt.String = jrt.Intern("line")

var Lit_226 *jrt.String = jrt.Intern("column")

var Lit_227 *jrt.String = jrt.Intern("file")

var Lit_228 *jrt.String = jrt.Intern("arbace/classes/env.ae")

var Lit_229 *jrt.String = jrt.Intern("An atom: internal name -> class declaration, the classes of the current compilation.")

var Lit_230 *jrt.String = jrt.Intern("internal name -> class info of the classes this compiler defined or wrote.")

var Lit_231 *jrt.String = jrt.Intern("atom")

var Lit_232 *jrt.String = jrt.Intern("private")

var Lit_233 *jrt.String = jrt.Intern("arglists")

var Lit_234 *jrt.String = jrt.Intern("c")

var Lit_235 *jrt.String = jrt.Intern("tag")

var Lit_236 *jrt.String = jrt.Intern("Class")

var Lit_237 *jrt.String = jrt.Intern("nil, or a predicate on internal names: classes that are compiled from their sources and never\n  taken from the class path, even when a class of that name is loaded (a stage recompiling\n  itself: the runtime's own classes are the ones being compiled, SPEC §9.6).")

var Lit_238 *jrt.String = jrt.Intern("n")

var Lit_239 *jrt.String = jrt.Intern("source-imports")

var Lit_240 *jrt.String = jrt.Intern("An atom: namespace name -> {simple name symbol -> internal name}, the imports of classes that\n  are not on the class path (yet) or are compiled from source, which namespaces cannot map.")

var Lit_241 *jrt.String = jrt.Intern("nil, or the classes outside the forms as data, in place of the class path: {internal name ->\n  {:info class-info, facet value ...}} (a2g's edge, jdk/edge.edn: doc/STANDALONE-NOTES.md, S2).\n  Bound, no class is loaded and nothing is reflected: a class neither compiled nor declared does\n  not exist, and a facet a declared class lacks is an error.")

var Lit_242 *jrt.String = jrt.Intern("nil, or an atom of what the class path answered: {internal name -> {facet value}} (:exists\n  true for a class loaded), from which a2g writes its edge.")

var Lit_243 *jrt.String = jrt.Intern("v")

var Lit_244 *jrt.String = jrt.Intern("Records facet value v of class n (when *recorded*); returns v.")

var Lit_245 *jrt.String = jrt.Intern("The Class of an internal name or array descriptor, without initializing it, or nil. nil for\n  classes compiled from source (*from-source*), and for every class when *declared* is bound.")

var Lit_246 *jrt.String = jrt.Intern("known?")

var Lit_247 *jrt.String = jrt.Intern("Is n a class outside the compilation: on the class path, or declared (*declared*)?")

var Lit_248 *jrt.String = jrt.Intern("reflected")

var Lit_249 *jrt.String = jrt.Intern("f")

var Lit_250 *jrt.String = jrt.Intern("Facet `facet` of class n, which is not compiled from source: (f Class) by reflection on the\n  class path, recorded (*recorded*); with *declared* bound, the declared value (an error when n\n  is declared without it). nil when there is no class n.")

var Lit_251 *jrt.String = jrt.Intern("Does c come from a class file (on a JVM; the Go build has none)? Its fields' constants and its\n  methods' annotations are then read from it, by arbace.classes.jvm (ASM's ClassReader, which\n  the frozen jar of arbace-for-java-26 holds: a2g's --record-edge and --jvm-reflection),\n  loaded on demand.")

var Lit_252 *jrt.String = jrt.Intern("The fields of the class file of c: [{:name :desc :flags :value}], or nil without a class\n  file. (Reflection hides some fields of the JDK's own classes, jdk.internal.reflect.Reflection's\n  filters.)")

var Lit_253 *jrt.String = jrt.Intern("[name desc] -> {:annotations [...] :param-annotations [[...] ...]} of the methods of the\n  class file of c (the declaration annotations javac copies to bridges); {} without one.")

var Lit_254 *jrt.String = jrt.Intern("The class info of an internal name, or nil.")

var Lit_255 *jrt.String = jrt.Intern("const-value")

var Lit_256 *jrt.String = jrt.Intern("field")

var Lit_257 *jrt.String = jrt.Intern("supertypes")

var Lit_258 *jrt.String = jrt.Intern("Direct supertypes of class n (superclass first).")

var Lit_259 *jrt.String = jrt.Intern("a")

var Lit_260 *jrt.String = jrt.Intern("b")

var Lit_261 *jrt.String = jrt.Intern("Is class a (internal name) a subtype of class b?")

var Lit_262 *jrt.String = jrt.Intern("from")

var Lit_263 *jrt.String = jrt.Intern("to")

var Lit_264 *jrt.String = jrt.Intern("Is a value of reference type `from` (a descriptor or :null) assignable to `to`?")

var Lit_265 *jrt.String = jrt.Intern("The common superclass of two internal names, for stack map frames.")

var Lit_266 *jrt.String = jrt.Intern("lub")

var Lit_267 *jrt.String = jrt.Intern("A least upper bound of two reference descriptors (only the class chain; interfaces give\n  Object unless one type is assignable to the other).")

var Lit_268 *jrt.String = jrt.Intern("accessible?")

var Lit_269 *jrt.String = jrt.Intern("m")

var Lit_270 *jrt.String = jrt.Intern("Can code in class `from` access member m (with :owner and :flags)?")

var Lit_271 *jrt.String = jrt.Intern("The field `name` of class n as JLS 8.3 finds it (declared, then superinterfaces, then\n  superclass), or nil.")

var Lit_272 *jrt.String = jrt.Intern("n and all its supertypes, classes first (the superclass chain), then interfaces breadth first.")

var Lit_273 *jrt.String = jrt.Intern("String")

var Lit_274 *jrt.String = jrt.Intern("member-methods")

var Lit_275 *jrt.String = jrt.Intern("The methods named `name` that are members of class n (inherited ones included, overridden\n  and synthetic ones excluded), in order: most specific declaring class first.")
