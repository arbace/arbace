//line j2g_strings.ae:1
package aot_arbace_classes_env

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn10,arbace.setyn20,arbace.classes.typesyn1,tyn22,arbace.classes.opcodesyn7,Opcodeskn3,dockn6,existskn5,classkn5,facetys18,arbace.classes.jvm11,read-fieldsys18,arbace.classes.jvm23,read-method-annotationskn4,namekn5,flagskn10,interface?kn5,superkn10,interfaceskn9,nest-hostkn5,outerkn6,fieldskn4,desckn5,valuekn5,ownerkn5,constys17,arbace.classes.go11,world-constkn15,outer-instance?kn7,methodskn6,throwskn11,annotationskn17,param-annotationsys17,arbace.classes.go12,constructorskn4,infokn4,nullkn4,elsev11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V1,R4,V3,R5,R2,R6,V3,R7,R2,R8,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn18,arbace.classes.envm2,R9,s368,The class environment (SPEC §9.2): what the compiler knows about classes, from the class\n  forms being compiled, from classes it defined earlier, from the edge's declared classes (j2g)\n  and from the class path (by reflection; on a JVM, with constant values and annotations read\n  from class files by arbace.classes.jvm). Member lookup with Java's access rules (§5.6).v13,arbace.string7,replacev18,arbace.classes.env13,*from-source*v18,arbace.classes.env10,*recorded*v11,arbace.core5,swap!v11,arbace.core6,updatev11,arbace.core5,assocv18,arbace.classes.env12,from-source?v18,arbace.classes.env10,*declared*v13,arbace.string12,starts-with?v18,arbace.classes.env7,record!R10,v11,arbace.core9,contains?v11,arbace.core3,notv11,arbace.core5,some?v18,arbace.classes.env10,load-classv11,arbace.core4,findv11,arbace.core3,valv11,arbace.core7,ex-infov11,arbace.core4,namev11,arbace.core3,strR11,R12,C21,java.lang.ClassLoaderv18,arbace.classes.env8,internalv18,arbace.classes.env11,class-file?v11,arbace.core17,requiring-resolveR13,R14,v18,arbace.classes.env13,reflect-cachev18,arbace.classes.env23,read-method-annotationsR15,R16,R17,R18,R19,v11,arbace.core4,mapvR20,R21,R22,v18,arbace.classes.env11,read-fieldsv11,arbace.core3,vecv11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core5,firstR23,R24,v11,arbace.core12,chunk-appendR25,R26,v20,arbace.classes.types5,prim?v20,arbace.classes.types11,string-descv18,arbace.classes.env12,coerce-constv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv11,arbace.core4,restv20,arbace.classes.types11,class->descR27,R28,v18,arbace.classes.env13,inner-member?R29,v11,arbace.core6,concatv20,arbace.classes.types11,method-descv11,arbace.core3,mapR30,R31,v11,arbace.core6,get-inR32,v11,arbace.core11,map-indexedv11,arbace.core6,empty?v11,arbace.core6,filterv11,arbace.core4,intoR33,v18,arbace.classes.env13,*compile-set*R34,v18,arbace.classes.env7,definedv18,arbace.classes.env12,reflect-infov18,arbace.classes.env4,infov11,arbace.core6,delay?v18,arbace.classes.env5,info!v11,arbace.core4,somev18,arbace.classes.env9,subclass?R35,v20,arbace.classes.types4,ref?v20,arbace.classes.types11,object-descv20,arbace.classes.types6,array?v20,arbace.classes.types9,elem-typev18,arbace.classes.env11,assignable?R36,S2,s22,Ljava/io/Serializable;s21,Ljava/lang/Cloneable;v20,arbace.classes.types14,desc->internalv11,arbace.core10,take-whilev11,arbace.core7,iteratev18,arbace.classes.env10,interface?v11,arbace.core3,setv18,arbace.classes.env16,superclass-chainv20,arbace.classes.types11,class-desc?v18,arbace.classes.env12,common-superv11,arbace.core8,tree-seqv10,arbace.set12,intersectionv11,arbace.core6,removev11,arbace.core4,not=v20,arbace.classes.types14,internal->descv18,arbace.classes.env9,nest-hostv18,arbace.classes.env5,flag?i1,i2,v20,arbace.classes.types10,package-ofi4,v18,arbace.classes.env10,find-fieldv11,arbace.core6,mapcatv18,arbace.classes.env15,supertypes-memov18,arbace.classes.env11,same-infos?v18,arbace.classes.env15,all-supertypes*v18,arbace.classes.env9,infos-nowv11,arbace.core4,subsl0,i4096,i8,v18,arbace.classes.env10,params-keyv11,arbace.core4,compv11,arbace.core7,string?v18,arbace.classes.env15,member-methods*v18,arbace.classes.env14,all-supertypesv18,arbace.classes.env19,member-methods-memo")

var Lit_1 *jrt.String = jrt.Intern("arbace.classes.env$accessible_QMARK_$fn__28000143")

var Lit_2 *jrt.String = jrt.Intern("arbace.classes.env$accessible_QMARK_$fn__28000145")

var Lit_3 *jrt.String = jrt.Intern("arbace.classes.env$all_supertypes_STAR_$fn__28000160")

var Lit_4 *jrt.String = jrt.Intern("java/lang/Object")

var Lit_5 *jrt.String = jrt.Intern("getResourceAsStream")

var Lit_6 *jrt.String = jrt.Intern(".class")

var Lit_7 *jrt.String = jrt.Intern("B")

var Lit_8 *jrt.String = jrt.Intern("C")

var Lit_9 *jrt.String = jrt.Intern("S")

var Lit_10 *jrt.String = jrt.Intern("Z")

var Lit_11 *jrt.String = jrt.Intern("[")

var Lit_12 *jrt.String = jrt.Intern("arbace.classes.env$constructors$fn__28000192")

var Lit_13 *jrt.String = jrt.Intern("<init>")

var Lit_14 *jrt.String = jrt.Intern("java.lang.reflect.Field")

var Lit_15 *jrt.String = jrt.Intern("java.lang.reflect.Method")

var Lit_16 *jrt.String = jrt.Intern("java.lang.reflect.Constructor")

var Lit_17 *jrt.String = jrt.Intern("java.lang.reflect.Modifier")

var Lit_18 *jrt.String = jrt.Intern("arbace.classes.env$find_field$fn__28000150")

var Lit_19 *jrt.String = jrt.Intern("arbace.classes.env$find_field$fn__28000152")

var Lit_20 *jrt.String = jrt.Intern("Unknown class: ")

var Lit_21 *jrt.String = jrt.Intern("/")

var Lit_22 *jrt.String = jrt.Intern(".")

var Lit_23 *jrt.String = jrt.Intern("arbace.classes.env$lub$sups__28000129")

var Lit_24 *jrt.String = jrt.Intern("arbace.classes.env$lub$fn__28000134")

var Lit_25 *jrt.String = jrt.Intern("arbace.classes.env$lub$fn__28000134$fn__28000135")

var Lit_26 *jrt.String = jrt.Intern("arbace.classes.env$lub$sups__28000129$fn__28000130")

var Lit_27 *jrt.String = jrt.Intern("arbace.classes.env$member_methods_STAR_$iter__28000179__28000183")

var Lit_28 *jrt.String = jrt.Intern("arbace.classes.env$member_methods_STAR_$iter__28000179__28000183$fn__28000184")

var Lit_29 *jrt.String = jrt.Intern("arbace.classes.env$member_methods_STAR_$iter__28000179__28000183$fn__28000184$fn__28000185")

var Lit_30 *jrt.String = jrt.Intern(")")

var Lit_31 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$fn__28000027")

var Lit_32 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000031__28000035")

var Lit_33 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000045__28000049")

var Lit_34 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000055__28000059")

var Lit_35 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000077__28000081")

var Lit_36 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$fn__28000089")

var Lit_37 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000091__28000095")

var Lit_38 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000031__28000035$fn__28000036")

var Lit_39 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000031__28000035$fn__28000036$fn__28000037")

var Lit_40 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000045__28000049$fn__28000050")

var Lit_41 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000045__28000049$fn__28000050$fn__28000051")

var Lit_42 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000055__28000059$fn__28000060")

var Lit_43 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000055__28000059$fn__28000060$fn__28000061")

var Lit_44 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000055__28000059$fn__28000060$fn__28000069")

var Lit_45 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000055__28000059$fn__28000060$fn__28000071")

var Lit_46 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000055__28000059$fn__28000060$fn__28000061$fn__28000062")

var Lit_47 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000055__28000059$fn__28000060$fn__28000061$fn__28000064")

var Lit_48 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000055__28000059$fn__28000060$fn__28000061$fn__28000064$fn__28000065")

var Lit_49 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000055__28000059$fn__28000060$fn__28000071$fn__28000072")

var Lit_50 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000077__28000081$fn__28000082")

var Lit_51 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000077__28000081$fn__28000082$fn__28000083")

var Lit_52 *jrt.String = jrt.Intern("V")

var Lit_53 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000091__28000095$fn__28000096")

var Lit_54 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info$iter__28000091__28000095$fn__28000096$fn__28000097")

var Lit_55 *jrt.String = jrt.Intern("Undeclared ")

var Lit_56 *jrt.String = jrt.Intern(" of class ")

var Lit_57 *jrt.String = jrt.Intern(": not in the declared edge (bin/j2g-edge update)")

var Lit_58 *jrt.String = jrt.Intern("arbace.classes.env$subclass_QMARK_$fn__28000117")

var Lit_59 *jrt.String = jrt.Intern("arbace.classes.env$superclass_chain$fn__28000123")

var Lit_60 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,dynamickn4,linekn6,columnkn4,filekn7,privatekn8,arglistskn3,tagyn5,Classyn1,nyn5,facetyn1,vyn1,fyn4,descyn5,fieldyn1,ayn1,byn4,fromyn2,toyn5,flagsyn1,myn4,nameyn5,namesyn7,objectsyn6,Stringyn4,supsv11,arbace.core5,in-nsMyn18,arbace.classes.envm2,R0,s368,The class environment (SPEC §9.2): what the compiler knows about classes, from the class\n  forms being compiled, from classes it defined earlier, from the edge's declared classes (j2g)\n  and from the class path (by reflection; on a JVM, with constant values and annotations read\n  from class files by arbace.classes.jvm). Member lookup with Java's access rules (§5.6).m2,R0,s368,The class environment (SPEC §9.2): what the compiler knows about classes, from the class\n  forms being compiled, from classes it defined earlier, from the edge's declared classes (j2g)\n  and from the class path (by reflection; on a JVM, with constant values and annotations read\n  from class files by arbace.classes.jvm). Member lookup with Java's access rules (§5.6).R1,v18,arbace.classes.env13,*compile-set*m10,R2,TR3,i19,R4,i1,R5,s21,arbace/classes/env.aeR0,s84,An atom: internal name -> class declaration, the classes of the current compilation.v18,arbace.classes.env7,definedm8,R0,s74,internal name -> class info of the classes this compiler defined or wrote.R3,i23,R4,i1,R5,s21,arbace/classes/env.aev11,arbace.core4,atomm8,R0,s74,internal name -> class info of the classes this compiler defined or wrote.R3,i23,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env8,internalm10,R6,TR7,L1,V1,Myn1,cm2,R8,R9,R3,i29,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env13,*from-source*m10,R2,TR3,i31,R4,i1,R5,s21,arbace/classes/env.aeR0,s261,nil, or a predicate on internal names: classes that are compiled from their sources and never\n  taken from the class path, even when a class of that name is loaded (a stage recompiling\n  itself: the runtime's own classes are the ones being compiled, SPEC §9.6).v18,arbace.classes.env12,from-source?m8,R7,L1,V1,R10,R3,i37,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env14,source-importsm8,R3,i39,R4,i1,R5,s21,arbace/classes/env.aeR0,s185,An atom: namespace name -> {simple name symbol -> internal name}, the imports of classes that\n  are not on the class path (yet) or are compiled from source, which namespaces cannot map.v18,arbace.classes.env10,*declared*m10,R2,TR3,i44,R4,i1,R5,s21,arbace/classes/env.aeR0,s346,nil, or the classes outside the forms as data, in place of the class path: {internal name ->\n  {:info class-info, facet value ...}} (j2g's edge, jdk/edge.edn: doc/STANDALONE-NOTES.md, S2).\n  Bound, no class is loaded and nothing is reflected: a class neither compiled nor declared does\n  not exist, and a facet a declared class lacks is an error.v18,arbace.classes.env10,*recorded*m10,R2,TR3,i51,R4,i1,R5,s21,arbace/classes/env.aeR0,s150,nil, or an atom of what the class path answered: {internal name -> {facet value}} (:exists\n  true for a class loaded), from which j2g writes its edge.v18,arbace.classes.env7,record!m10,R7,L1,V3,R10,R11,R12,R0,s62,Records facet value v of class n (when *recorded*); returns v.R3,i56,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env10,load-classm10,R7,L1,V1,R10,R0,s185,The Class of an internal name or array descriptor, without initializing it, or nil. nil for\n  classes compiled from source (*from-source*), and for every class when *declared* is bound.R3,i62,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env6,known?m10,R7,L1,V1,R10,R0,s373,Is n a class outside the compilation: on the class path, or declared (*declared*)? Not a\n  class compiled from source (*from-source*), even when the declared edge also has it: a world\n  that holds forms of a class the shipped edge declares (javac's tool build's java.io.DataOutput,\n  doc/classes/JAVA-FRONTEND-SURVEY.md, \"As built: JN3\") asks its forms, as load-class does.R3,i75,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env9,reflectedm10,R7,L1,V3,R10,R11,R13,R0,s244,Facet `facet` of class n, which is not compiled from source: (f Class) by reflection on the\n  class path, recorded (*recorded*); with *declared* bound, the declared value (an error when n\n  is declared without it). nil when there is no class n.R3,i83,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env11,class-file?m12,R6,TR7,L1,V1,Myn1,cm2,R8,R9,R0,s297,Does c come from a class file (on a JVM; the Go build has none)? Its fields' constants and its\n  methods' annotations are then read from it, by arbace.classes.jvm (ASM's ClassReader, which\n  the frozen jar of arbace-for-java-26 holds: j2g's --record-edge and --jvm-reflection),\n  loaded on demand.R3,i98,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env11,read-fieldsm12,R6,TR7,L1,V1,Myn1,cm2,R8,R9,R0,s198,The fields of the class file of c: [{:name :desc :flags :value}], or nil without a class\n  file. (Reflection hides some fields of the JDK's own classes, jdk.internal.reflect.Reflection's\n  filters.)R3,i109,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env23,read-method-annotationsm10,R7,L1,V1,Myn1,cm2,R8,R9,R0,s177,[name desc] -> {:annotations [...] :param-annotations [[...] ...]} of the methods of the\n  class file of c (the declaration annotations javac copies to bridges); {} without one.R3,i117,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env12,coerce-constm10,R6,TR7,L1,V2,R14,R12,R3,i125,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env13,reflect-cachem10,R8,C38,java.util.concurrent.ConcurrentHashMapR6,TR3,i133,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env13,inner-member?m10,R6,TR7,L1,V1,Myn1,cm2,R8,R9,R3,i139,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env12,reflect-infom8,R7,L1,V1,Myn1,cm2,R8,R9,R3,i143,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env4,infom10,R7,L1,V1,R10,R0,s43,The class info of an internal name, or nil.R3,i205,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env5,info!m8,R7,L1,V1,R10,R3,i216,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env10,interface?m8,R7,L1,V1,R10,R3,i219,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env11,const-valuem8,R7,L1,V1,R15,R3,i222,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env10,supertypesm10,R7,L1,V1,R10,R0,s48,Direct supertypes of class n (superclass first).R3,i225,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env9,subclass?m10,R7,L1,V2,R16,R17,R0,s48,Is class a (internal name) a subtype of class b?R3,i230,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env11,assignable?m10,R7,L1,V2,R18,R19,R0,s79,Is a value of reference type `from` (a descriptor or :null) assignable to `to`?R3,i237,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env16,superclass-chainm8,R7,L1,V1,R10,R3,i252,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env12,common-superm10,R7,L1,V2,R16,R17,R0,s66,The common superclass of two internal names, for stack map frames.R3,i255,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env3,lubm10,R7,L1,V2,R16,R17,R0,s141,A least upper bound of two reference descriptors (only the class chain; interfaces give\n  Object unless one type is assignable to the other).R3,i267,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env9,nest-hostm8,R7,L1,V1,R10,R3,i292,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env5,flag?m10,R6,TR7,L1,V2,R20,R13,R3,i297,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env11,accessible?m10,R7,L1,V2,R18,R21,R0,s66,Can code in class `from` access member m (with :owner and :flags)?R3,i299,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env10,find-fieldm10,R7,L1,V2,R10,R22,R0,s108,The field `name` of class n as JLS 8.3 finds it (declared, then superinterfaces, then\n  superclass), or nil.R3,i312,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env11,same-infos?m12,R6,TR7,L1,V2,R23,Myn5,infosm2,R8,R24,R0,s76,Are the class infos of names (a vector) still infos (identical, one by one)?R3,i321,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env9,infos-nowm10,R6,TR7,L1,MV1,R23,m2,R8,R24,R3,i335,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env15,supertypes-memom10,R8,C38,java.util.concurrent.ConcurrentHashMapR6,TR3,i346,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env19,member-methods-memom10,R8,C38,java.util.concurrent.ConcurrentHashMapR6,TR3,i349,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env15,all-supertypes*m10,R6,TR7,L1,V1,R10,R3,i352,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env14,all-supertypesm10,R7,L1,V1,R10,R0,s94,n and all its supertypes, classes first (the superclass chain), then interfaces breadth first.R3,i362,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env10,params-keym10,R6,TR7,L1,V1,Myn4,descm2,R8,R25,R3,i375,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env15,member-methods*m10,R6,TR7,L1,V3,R10,R22,R26,R3,i377,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env14,member-methodsm10,R7,L1,V2,R10,R22,R0,s168,The methods named `name` that are members of class n (inherited ones included, overridden\n  and synthetic ones excluded), in order: most specific declaring class first.R3,i391,R4,i1,R5,s21,arbace/classes/env.aev18,arbace.classes.env12,constructorsm8,R7,L1,V1,R10,R3,i412,R4,i1,R5,s21,arbace/classes/env.ae")

var Lit_61 *jrt.String = jrt.Intern("arbace.classes.env$eval28000004$loading__1927001464__auto____28000005")

var Lit_62 *jrt.String = jrt.Intern("arbace.classes.env$eval28000008$fn__28000009")

var Lit_63 *jrt.String = jrt.Intern("arbace.classes.env$internal")

var Lit_64 *jrt.String = jrt.Intern("arbace.classes.env$from_source_QMARK_")

var Lit_65 *jrt.String = jrt.Intern("arbace.classes.env$record_BANG_")

var Lit_66 *jrt.String = jrt.Intern("arbace.classes.env$load_class")

var Lit_67 *jrt.String = jrt.Intern("arbace.classes.env$known_QMARK_")

var Lit_68 *jrt.String = jrt.Intern("arbace.classes.env$reflected")

var Lit_69 *jrt.String = jrt.Intern("arbace.classes.env$class_file_QMARK_")

var Lit_70 *jrt.String = jrt.Intern("arbace.classes.env$read_fields")

var Lit_71 *jrt.String = jrt.Intern("arbace.classes.env$read_method_annotations")

var Lit_72 *jrt.String = jrt.Intern("arbace.classes.env$coerce_const")

var Lit_73 *jrt.String = jrt.Intern("arbace.classes.env$inner_member_QMARK_")

var Lit_74 *jrt.String = jrt.Intern("arbace.classes.env$reflect_info")

var Lit_75 *jrt.String = jrt.Intern("arbace.classes.env$info")

var Lit_76 *jrt.String = jrt.Intern("arbace.classes.env$info_BANG_")

var Lit_77 *jrt.String = jrt.Intern("arbace.classes.env$interface_QMARK_")

var Lit_78 *jrt.String = jrt.Intern("arbace.classes.env$const_value")

var Lit_79 *jrt.String = jrt.Intern("arbace.classes.env$supertypes")

var Lit_80 *jrt.String = jrt.Intern("arbace.classes.env$subclass_QMARK_")

var Lit_81 *jrt.String = jrt.Intern("arbace.classes.env$assignable_QMARK_")

var Lit_82 *jrt.String = jrt.Intern("arbace.classes.env$superclass_chain")

var Lit_83 *jrt.String = jrt.Intern("arbace.classes.env$common_super")

var Lit_84 *jrt.String = jrt.Intern("arbace.classes.env$lub")

var Lit_85 *jrt.String = jrt.Intern("arbace.classes.env$nest_host")

var Lit_86 *jrt.String = jrt.Intern("arbace.classes.env$flag_QMARK_")

var Lit_87 *jrt.String = jrt.Intern("arbace.classes.env$accessible_QMARK_")

var Lit_88 *jrt.String = jrt.Intern("arbace.classes.env$find_field")

var Lit_89 *jrt.String = jrt.Intern("arbace.classes.env$same_infos_QMARK_")

var Lit_90 *jrt.String = jrt.Intern("arbace.classes.env$infos_now")

var Lit_91 *jrt.String = jrt.Intern("arbace.classes.env$all_supertypes_STAR_")

var Lit_92 *jrt.String = jrt.Intern("arbace.classes.env$all_supertypes")

var Lit_93 *jrt.String = jrt.Intern("arbace.classes.env$params_key")

var Lit_94 *jrt.String = jrt.Intern("arbace.classes.env$member_methods_STAR_")

var Lit_95 *jrt.String = jrt.Intern("arbace.classes.env$member_methods")

var Lit_96 *jrt.String = jrt.Intern("arbace.classes.env$constructors")
