//line aot_arbace_classes_env__init.ae:1
package aot_arbace_classes_env

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_env__init_A_Unit0__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_classes_env__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_env__init_A_const_1) }
//line :1:1
func A_arbace_classes_env__init_A_Unit1__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_classes_env__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_2)) }
//line :1:1
func A_arbace_classes_env__init_A_Unit2__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 any = A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_61, false); A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_classes_env__init_A_Unit3__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_classes_env__init_A_const_1)).Equals_O__Z(A_arbace_classes_env__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_classes_env_eval28000008_fn__28000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_classes_env_eval28000008_fn__28000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); A_arbace_classes_env_eval28000008_fn__28000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_classes_env__init_A_Load__O() any { A_arbace_classes_env__init_A_Init(); jrt.StartCheck(); A_arbace_classes_env__init_A_Unit0__O(); A_arbace_classes_env__init_A_Unit1__O(); A_arbace_classes_env__init_A_Unit2__O(); A_arbace_classes_env__init_A_Unit3__O(); A_arbace_classes_env__init_A_Unit4__O(); A_arbace_classes_env__init_A_Unit5__O(); A_arbace_classes_env__init_A_Unit6__O(); A_arbace_classes_env__init_A_Unit7__O(); A_arbace_classes_env__init_A_Unit8__O(); A_arbace_classes_env__init_A_Unit9__O(); A_arbace_classes_env__init_A_Unit10__O(); A_arbace_classes_env__init_A_Unit11__O(); A_arbace_classes_env__init_A_Unit12__O(); A_arbace_classes_env__init_A_Unit13__O(); A_arbace_classes_env__init_A_Unit14__O(); A_arbace_classes_env__init_A_Unit15__O(); A_arbace_classes_env__init_A_Unit16__O(); A_arbace_classes_env__init_A_Unit17__O(); A_arbace_classes_env__init_A_Unit18__O(); A_arbace_classes_env__init_A_Unit19__O(); A_arbace_classes_env__init_A_Unit20__O(); A_arbace_classes_env__init_A_Unit21__O(); A_arbace_classes_env__init_A_Unit22__O(); A_arbace_classes_env__init_A_Unit23__O(); A_arbace_classes_env__init_A_Unit24__O(); A_arbace_classes_env__init_A_Unit25__O(); A_arbace_classes_env__init_A_Unit26__O(); A_arbace_classes_env__init_A_Unit27__O(); A_arbace_classes_env__init_A_Unit28__O(); A_arbace_classes_env__init_A_Unit29__O(); A_arbace_classes_env__init_A_Unit30__O(); A_arbace_classes_env__init_A_Unit31__O(); A_arbace_classes_env__init_A_Unit32__O(); A_arbace_classes_env__init_A_Unit33__O(); A_arbace_classes_env__init_A_Unit34__O(); A_arbace_classes_env__init_A_Unit35__O(); A_arbace_classes_env__init_A_Unit36__O(); A_arbace_classes_env__init_A_Unit37__O(); A_arbace_classes_env__init_A_Unit38__O(); A_arbace_classes_env__init_A_Unit39__O(); A_arbace_classes_env__init_A_Unit40__O(); A_arbace_classes_env__init_A_Unit41__O(); A_arbace_classes_env__init_A_Unit42__O(); A_arbace_classes_env__init_A_Unit43__O(); A_arbace_classes_env__init_A_Unit44__O(); A_arbace_classes_env__init_A_Unit45__O(); A_arbace_classes_env__init_A_Unit46__O(); return nil }













func A_arbace_classes_env__init_A_Unit4__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(19, 1); A_arbace_classes_env__init_A_const_4.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_5)); return A_arbace_classes_env__init_A_const_4.SetDynamic_Z__Var(true).Ref() }



func A_arbace_classes_env__init_A_Unit5__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(23, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_6; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_7)); v__1927001498__auto____1 = A_arbace_classes_env__init_A_const_6; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_classes_env__init_A_const_6; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_9)); var tmp3 *lang.Var = A_arbace_classes_env__init_A_const_6; var tmp4 any; var root_3 any = A_arbace_classes_env__init_A_const_8.GetRawRoot__O(); var linked_4 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_5 lang.IFn
							if linked_4 == nil { ifn_5 = lang.IFn_Cast(root_3) } else { ifn_5 = nil }; var arg_6 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_4 == nil { tmp4 = ifn_5.Invoke_O__O(arg_6) } else { tmp4 = linked_4.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_3, arg_6) }
//line :23:1
	tmp3.BindRoot_O__V(tmp4); return A_arbace_classes_env__init_A_const_6 } }





func A_arbace_classes_env__init_A_Unit6__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(29, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_10; var tmp2 any = A_arbace_classes_env_internal_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_classes_env_internal_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, false); A_arbace_classes_env_internal_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_11)); return A_arbace_classes_env__init_A_const_10 }

func A_arbace_classes_env__init_A_Unit7__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(31, 1); A_arbace_classes_env__init_A_const_12.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_12; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_13)); return A_arbace_classes_env__init_A_const_12.SetDynamic_Z__Var(true).Ref() }





func A_arbace_classes_env__init_A_Unit8__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(37, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_14; var tmp2 any = A_arbace_classes_env_from_source_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_classes_env_from_source_QMARK__A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_64, false); A_arbace_classes_env_from_source_QMARK__A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_15)); return A_arbace_classes_env__init_A_const_14 }

func A_arbace_classes_env__init_A_Unit9__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(39, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_16; var tmp2 any; var root_9 any = A_arbace_classes_env__init_A_const_8.GetRawRoot__O(); var linked_10 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_9, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_11 lang.IFn; if


	linked_10 == nil { ifn_11 = lang.IFn_Cast(root_9) } else { ifn_11 = nil }; var arg_12 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_10 == nil { tmp2 = ifn_11.Invoke_O__O(arg_12) } else { tmp2 = linked_10.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_9, arg_12) }; /*line :39:1*/tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_classes_env__init_A_const_16; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_17)); return A_arbace_classes_env__init_A_const_16 }




func A_arbace_classes_env__init_A_Unit10__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(44, 1); A_arbace_classes_env__init_A_const_18.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_18; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_19)); return A_arbace_classes_env__init_A_const_18.SetDynamic_Z__Var(true).Ref() }






func A_arbace_classes_env__init_A_Unit11__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(51, 1); A_arbace_classes_env__init_A_const_20.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_20; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_21)); return A_arbace_classes_env__init_A_const_20.SetDynamic_Z__Var(true).Ref() }




func A_arbace_classes_env__init_A_Unit12__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(56, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_22; var tmp2 any = A_arbace_classes_env_record_BANG__A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_classes_env_record_BANG__A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_classes_env_record_BANG__A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_23)); return A_arbace_classes_env__init_A_const_22 }





func A_arbace_classes_env__init_A_Unit13__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(62, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_24; var tmp2 any = A_arbace_classes_env_load_class_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_classes_env_load_class_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_classes_env_load_class_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_25)); return A_arbace_classes_env__init_A_const_24 }












func A_arbace_classes_env__init_A_Unit14__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(75, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_26; var tmp2 any = A_arbace_classes_env_known_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_classes_env_known_QMARK__A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); A_arbace_classes_env_known_QMARK__A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_27)); return A_arbace_classes_env__init_A_const_26 }







func A_arbace_classes_env__init_A_Unit15__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(83, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_28; var tmp2 any = A_arbace_classes_env_reflected_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_classes_env_reflected_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); A_arbace_classes_env_reflected_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_29)); return A_arbace_classes_env__init_A_const_28 }














func A_arbace_classes_env__init_A_Unit16__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(98, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_30; var tmp2 any = A_arbace_classes_env_class_file_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_classes_env_class_file_QMARK__A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_classes_env_class_file_QMARK__A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_31)); return A_arbace_classes_env__init_A_const_30 }










func A_arbace_classes_env__init_A_Unit17__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(109, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_32; var tmp2 any = A_arbace_classes_env_read_fields_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_classes_env_read_fields_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_classes_env_read_fields_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_33)); return A_arbace_classes_env__init_A_const_32 }







func A_arbace_classes_env__init_A_Unit18__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(117, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_34; var tmp2 any = A_arbace_classes_env_read_method_annotations_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_classes_env_read_method_annotations_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_classes_env_read_method_annotations_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_35)); return A_arbace_classes_env__init_A_const_34 }







func A_arbace_classes_env__init_A_Unit19__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(125, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_36; var tmp2 any = A_arbace_classes_env_coerce_const_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_classes_env_coerce_const_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_classes_env_coerce_const_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_37)); return A_arbace_classes_env__init_A_const_36 }







func A_arbace_classes_env__init_A_Unit20__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(133, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_38; tmp1.BindRoot_O__V(jrt.ConcurrentHashMap_New()); var tmp2 *lang.Var = A_arbace_classes_env__init_A_const_38; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_39)); return A_arbace_classes_env__init_A_const_38 }





func A_arbace_classes_env__init_A_Unit21__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(139, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_40; var tmp2 any = A_arbace_classes_env_inner_member_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_classes_env_inner_member_QMARK__A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_classes_env_inner_member_QMARK__A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_41)); return A_arbace_classes_env__init_A_const_40 }



func A_arbace_classes_env__init_A_Unit22__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(143, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_42; var tmp2 any = A_arbace_classes_env_reflect_info_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_classes_env_reflect_info_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_classes_env_reflect_info_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_43)); return A_arbace_classes_env__init_A_const_42 }





























































func A_arbace_classes_env__init_A_Unit23__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(205, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_44; var tmp2 any = A_arbace_classes_env_info_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_classes_env_info_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_classes_env_info_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_45)); return A_arbace_classes_env__init_A_const_44 }










func A_arbace_classes_env__init_A_Unit24__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(216, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_46; var tmp2 any = A_arbace_classes_env_info_BANG__A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_classes_env_info_BANG__A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_classes_env_info_BANG__A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_47)); return A_arbace_classes_env__init_A_const_46 }


func A_arbace_classes_env__init_A_Unit25__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(219, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_48; var tmp2 any = A_arbace_classes_env_interface_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_classes_env_interface_QMARK__A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); A_arbace_classes_env_interface_QMARK__A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_49)); return A_arbace_classes_env__init_A_const_48 }


func A_arbace_classes_env__init_A_Unit26__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(222, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_50; var tmp2 any = A_arbace_classes_env_const_value_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_classes_env_const_value_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); A_arbace_classes_env_const_value_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_51)); return A_arbace_classes_env__init_A_const_50 }


func A_arbace_classes_env__init_A_Unit27__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(225, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_52; var tmp2 any = A_arbace_classes_env_supertypes_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_classes_env_supertypes_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_79, false); A_arbace_classes_env_supertypes_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_53)); return A_arbace_classes_env__init_A_const_52 }




func A_arbace_classes_env__init_A_Unit28__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(230, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_54; var tmp2 any = A_arbace_classes_env_subclass_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_classes_env_subclass_QMARK__A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_classes_env_subclass_QMARK__A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_55)); return A_arbace_classes_env__init_A_const_54 }






func A_arbace_classes_env__init_A_Unit29__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(237, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_56; var tmp2 any = A_arbace_classes_env_assignable_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_classes_env_assignable_QMARK__A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_classes_env_assignable_QMARK__A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_57)); return A_arbace_classes_env__init_A_const_56 }














func A_arbace_classes_env__init_A_Unit30__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(252, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_58; var tmp2 any = A_arbace_classes_env_superclass_chain_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_classes_env_superclass_chain_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_82, false); A_arbace_classes_env_superclass_chain_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_59)); return A_arbace_classes_env__init_A_const_58 }


func A_arbace_classes_env__init_A_Unit31__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(255, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_60; var tmp2 any = A_arbace_classes_env_common_super_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_classes_env_common_super_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, false); A_arbace_classes_env_common_super_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_61)); return A_arbace_classes_env__init_A_const_60 }











func A_arbace_classes_env__init_A_Unit32__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(267, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_62; var tmp2 any = A_arbace_classes_env_lub_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_classes_env_lub_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_84, false); A_arbace_classes_env_lub_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_63)); return A_arbace_classes_env__init_A_const_62 }
























func A_arbace_classes_env__init_A_Unit33__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(292, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_64; var tmp2 any = A_arbace_classes_env_nest_host_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_classes_env_nest_host_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_85, false); A_arbace_classes_env_nest_host_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_65)); return A_arbace_classes_env__init_A_const_64 }




func A_arbace_classes_env__init_A_Unit34__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(297, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_66; var tmp2 any = A_arbace_classes_env_flag_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_classes_env_flag_QMARK__A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, false); A_arbace_classes_env_flag_QMARK__A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_67)); return A_arbace_classes_env__init_A_const_66 }

func A_arbace_classes_env__init_A_Unit35__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(299, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_68; var tmp2 any = A_arbace_classes_env_accessible_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_classes_env_accessible_QMARK__A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_87, false); A_arbace_classes_env_accessible_QMARK__A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_69)); return A_arbace_classes_env__init_A_const_68 }












func A_arbace_classes_env__init_A_Unit36__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(312, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_70; var tmp2 any = A_arbace_classes_env_find_field_A_New(); var tmp3 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_classes_env_find_field_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_88, false); A_arbace_classes_env_find_field_A_fn_class = fncls__36d; tmp3 = fncls__36d } else { tmp3 = fncls__36 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_71)); return A_arbace_classes_env__init_A_const_70 }








func A_arbace_classes_env__init_A_Unit37__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(321, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_72; var tmp2 any = A_arbace_classes_env_same_infos_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_classes_env_same_infos_QMARK__A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_89, false); A_arbace_classes_env_same_infos_QMARK__A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_73)); return A_arbace_classes_env__init_A_const_72 }













func A_arbace_classes_env__init_A_Unit38__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(335, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_74; var tmp2 any = A_arbace_classes_env_infos_now_A_New(); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_classes_env_infos_now_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_90, false); A_arbace_classes_env_infos_now_A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_75)); return A_arbace_classes_env__init_A_const_74 }










func A_arbace_classes_env__init_A_Unit39__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(346, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_76; tmp1.BindRoot_O__V(jrt.ConcurrentHashMap_New()); var tmp2 *lang.Var = A_arbace_classes_env__init_A_const_76; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_77)); return A_arbace_classes_env__init_A_const_76 }


func A_arbace_classes_env__init_A_Unit40__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(349, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_78; tmp1.BindRoot_O__V(jrt.ConcurrentHashMap_New()); var tmp2 *lang.Var = A_arbace_classes_env__init_A_const_78; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_79)); return A_arbace_classes_env__init_A_const_78 }


func A_arbace_classes_env__init_A_Unit41__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(352, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_80; var tmp2 any = A_arbace_classes_env_all_supertypes_STAR__A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_classes_env_all_supertypes_STAR__A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_91, false); A_arbace_classes_env_all_supertypes_STAR__A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_81)); return A_arbace_classes_env__init_A_const_80 }









func A_arbace_classes_env__init_A_Unit42__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(362, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_82; var tmp2 any = A_arbace_classes_env_all_supertypes_A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_classes_env_all_supertypes_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_92, false); A_arbace_classes_env_all_supertypes_A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_83)); return A_arbace_classes_env__init_A_const_82 }












func A_arbace_classes_env__init_A_Unit43__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(375, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_84; var tmp2 any = A_arbace_classes_env_params_key_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_classes_env_params_key_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_93, false); A_arbace_classes_env_params_key_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_85)); return A_arbace_classes_env__init_A_const_84 }

func A_arbace_classes_env__init_A_Unit44__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(377, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_86; var tmp2 any = A_arbace_classes_env_member_methods_STAR__A_New(); var tmp3 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_classes_env_member_methods_STAR__A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_94, false); A_arbace_classes_env_member_methods_STAR__A_fn_class = fncls__42d; tmp3 = fncls__42d } else { tmp3 = fncls__42 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_87)); return A_arbace_classes_env__init_A_const_86 }













func A_arbace_classes_env__init_A_Unit45__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(391, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_88; var tmp2 any = A_arbace_classes_env_member_methods_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_classes_env_member_methods_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_95, false); A_arbace_classes_env_member_methods_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_88; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_89)); return A_arbace_classes_env__init_A_const_88 }




















func A_arbace_classes_env__init_A_Unit46__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(412, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_90; var tmp2 any = A_arbace_classes_env_constructors_A_New(); var tmp3 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_classes_env_constructors_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_96, false); A_arbace_classes_env_constructors_A_fn_class = fncls__44d; tmp3 = fncls__44d } else { tmp3 = fncls__44 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_90; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_91)); return A_arbace_classes_env__init_A_const_90 }



type A_arbace_classes_env__init_A struct{ jrt.Object }

var A_arbace_classes_env__init_A_const_pool *jrt.RefArray

var A_arbace_classes_env__init_A_const_0 *lang.Var

var A_arbace_classes_env__init_A_const_1 any

var A_arbace_classes_env__init_A_const_2 any

var A_arbace_classes_env__init_A_const_3 any

var A_arbace_classes_env__init_A_const_4 *lang.Var

var A_arbace_classes_env__init_A_const_5 any

var A_arbace_classes_env__init_A_const_6 *lang.Var

var A_arbace_classes_env__init_A_const_7 any

var A_arbace_classes_env__init_A_const_8 *lang.Var

var A_arbace_classes_env__init_A_const_9 any

var A_arbace_classes_env__init_A_const_10 *lang.Var

var A_arbace_classes_env__init_A_const_11 any

var A_arbace_classes_env__init_A_const_12 *lang.Var

var A_arbace_classes_env__init_A_const_13 any

var A_arbace_classes_env__init_A_const_14 *lang.Var

var A_arbace_classes_env__init_A_const_15 any

var A_arbace_classes_env__init_A_const_16 *lang.Var

var A_arbace_classes_env__init_A_const_17 any

var A_arbace_classes_env__init_A_const_18 *lang.Var

var A_arbace_classes_env__init_A_const_19 any

var A_arbace_classes_env__init_A_const_20 *lang.Var

var A_arbace_classes_env__init_A_const_21 any

var A_arbace_classes_env__init_A_const_22 *lang.Var

var A_arbace_classes_env__init_A_const_23 any

var A_arbace_classes_env__init_A_const_24 *lang.Var

var A_arbace_classes_env__init_A_const_25 any

var A_arbace_classes_env__init_A_const_26 *lang.Var

var A_arbace_classes_env__init_A_const_27 any

var A_arbace_classes_env__init_A_const_28 *lang.Var

var A_arbace_classes_env__init_A_const_29 any

var A_arbace_classes_env__init_A_const_30 *lang.Var

var A_arbace_classes_env__init_A_const_31 any

var A_arbace_classes_env__init_A_const_32 *lang.Var

var A_arbace_classes_env__init_A_const_33 any

var A_arbace_classes_env__init_A_const_34 *lang.Var

var A_arbace_classes_env__init_A_const_35 any

var A_arbace_classes_env__init_A_const_36 *lang.Var

var A_arbace_classes_env__init_A_const_37 any

var A_arbace_classes_env__init_A_const_38 *lang.Var

var A_arbace_classes_env__init_A_const_39 any

var A_arbace_classes_env__init_A_const_40 *lang.Var

var A_arbace_classes_env__init_A_const_41 any

var A_arbace_classes_env__init_A_const_42 *lang.Var

var A_arbace_classes_env__init_A_const_43 any

var A_arbace_classes_env__init_A_const_44 *lang.Var

var A_arbace_classes_env__init_A_const_45 any

var A_arbace_classes_env__init_A_const_46 *lang.Var

var A_arbace_classes_env__init_A_const_47 any

var A_arbace_classes_env__init_A_const_48 *lang.Var

var A_arbace_classes_env__init_A_const_49 any

var A_arbace_classes_env__init_A_const_50 *lang.Var

var A_arbace_classes_env__init_A_const_51 any

var A_arbace_classes_env__init_A_const_52 *lang.Var

var A_arbace_classes_env__init_A_const_53 any

var A_arbace_classes_env__init_A_const_54 *lang.Var

var A_arbace_classes_env__init_A_const_55 any

var A_arbace_classes_env__init_A_const_56 *lang.Var

var A_arbace_classes_env__init_A_const_57 any

var A_arbace_classes_env__init_A_const_58 *lang.Var

var A_arbace_classes_env__init_A_const_59 any

var A_arbace_classes_env__init_A_const_60 *lang.Var

var A_arbace_classes_env__init_A_const_61 any

var A_arbace_classes_env__init_A_const_62 *lang.Var

var A_arbace_classes_env__init_A_const_63 any

var A_arbace_classes_env__init_A_const_64 *lang.Var

var A_arbace_classes_env__init_A_const_65 any

var A_arbace_classes_env__init_A_const_66 *lang.Var

var A_arbace_classes_env__init_A_const_67 any

var A_arbace_classes_env__init_A_const_68 *lang.Var

var A_arbace_classes_env__init_A_const_69 any

var A_arbace_classes_env__init_A_const_70 *lang.Var

var A_arbace_classes_env__init_A_const_71 any

var A_arbace_classes_env__init_A_const_72 *lang.Var

var A_arbace_classes_env__init_A_const_73 any

var A_arbace_classes_env__init_A_const_74 *lang.Var

var A_arbace_classes_env__init_A_const_75 any

var A_arbace_classes_env__init_A_const_76 *lang.Var

var A_arbace_classes_env__init_A_const_77 any

var A_arbace_classes_env__init_A_const_78 *lang.Var

var A_arbace_classes_env__init_A_const_79 any

var A_arbace_classes_env__init_A_const_80 *lang.Var

var A_arbace_classes_env__init_A_const_81 any

var A_arbace_classes_env__init_A_const_82 *lang.Var

var A_arbace_classes_env__init_A_const_83 any

var A_arbace_classes_env__init_A_const_84 *lang.Var

var A_arbace_classes_env__init_A_const_85 any

var A_arbace_classes_env__init_A_const_86 *lang.Var

var A_arbace_classes_env__init_A_const_87 any

var A_arbace_classes_env__init_A_const_88 *lang.Var

var A_arbace_classes_env__init_A_const_89 any

var A_arbace_classes_env__init_A_const_90 *lang.Var

var A_arbace_classes_env__init_A_const_91 any

var A_arbace_classes_env__init_A_init jrt.ClassInit

func A_arbace_classes_env__init_A_Init() { if !A_arbace_classes_env__init_A_init.Done() { A_arbace_classes_env__init_A_init.Run(A_arbace_classes_env__init_A_clinit) } }

func A_arbace_classes_env__init_A_clinit() { A_arbace_classes_env__init_A_clinit_p0(); A_arbace_classes_env__init_A_clinit_p1(); A_arbace_classes_env__init_A_clinit_p2(); A_arbace_classes_env__init_A_clinit_p3(); A_arbace_classes_env__init_A_clinit_p4(); A_arbace_classes_env__init_A_clinit_p5(); A_arbace_classes_env__init_A_clinit_p6(); A_arbace_classes_env__init_A_clinit_p7() }

func A_arbace_classes_env__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_classes_env__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_60, 119); A_arbace_classes_env__init_A_const_0 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[27]); A_arbace_classes_env__init_A_const_1 = A_arbace_classes_env__init_A_const_pool.A[28]; A_arbace_classes_env__init_A_const_2 = A_arbace_classes_env__init_A_const_pool.A[29]; A_arbace_classes_env__init_A_const_3 = A_arbace_classes_env__init_A_const_pool.A[30]; A_arbace_classes_env__init_A_const_4 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[31]); A_arbace_classes_env__init_A_const_5 = A_arbace_classes_env__init_A_const_pool.A[32]; A_arbace_classes_env__init_A_const_6 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[33]); A_arbace_classes_env__init_A_const_7 = A_arbace_classes_env__init_A_const_pool.A[34]; A_arbace_classes_env__init_A_const_8 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[35]); A_arbace_classes_env__init_A_const_9 = A_arbace_classes_env__init_A_const_pool.A[36]; A_arbace_classes_env__init_A_const_10 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[37]); A_arbace_classes_env__init_A_const_11 = A_arbace_classes_env__init_A_const_pool.A[38]; A_arbace_classes_env__init_A_const_12 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[39]) }

func A_arbace_classes_env__init_A_clinit_p1() { A_arbace_classes_env__init_A_const_13 = A_arbace_classes_env__init_A_const_pool.A[40]; A_arbace_classes_env__init_A_const_14 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[41]); A_arbace_classes_env__init_A_const_15 = A_arbace_classes_env__init_A_const_pool.A[42]; A_arbace_classes_env__init_A_const_16 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[43]); A_arbace_classes_env__init_A_const_17 = A_arbace_classes_env__init_A_const_pool.A[44]; A_arbace_classes_env__init_A_const_18 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[45]); A_arbace_classes_env__init_A_const_19 = A_arbace_classes_env__init_A_const_pool.A[46]; A_arbace_classes_env__init_A_const_20 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[47]); A_arbace_classes_env__init_A_const_21 = A_arbace_classes_env__init_A_const_pool.A[48]; A_arbace_classes_env__init_A_const_22 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[49]); A_arbace_classes_env__init_A_const_23 = A_arbace_classes_env__init_A_const_pool.A[50]; A_arbace_classes_env__init_A_const_24 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[51]); A_arbace_classes_env__init_A_const_25 = A_arbace_classes_env__init_A_const_pool.A[52] }

func A_arbace_classes_env__init_A_clinit_p2() { A_arbace_classes_env__init_A_const_26 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[53]); A_arbace_classes_env__init_A_const_27 = A_arbace_classes_env__init_A_const_pool.A[54]; A_arbace_classes_env__init_A_const_28 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[55]); A_arbace_classes_env__init_A_const_29 = A_arbace_classes_env__init_A_const_pool.A[56]; A_arbace_classes_env__init_A_const_30 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[57]); A_arbace_classes_env__init_A_const_31 = A_arbace_classes_env__init_A_const_pool.A[58]; A_arbace_classes_env__init_A_const_32 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[59]); A_arbace_classes_env__init_A_const_33 = A_arbace_classes_env__init_A_const_pool.A[60]; A_arbace_classes_env__init_A_const_34 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[61]); A_arbace_classes_env__init_A_const_35 = A_arbace_classes_env__init_A_const_pool.A[62]; A_arbace_classes_env__init_A_const_36 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[63]); A_arbace_classes_env__init_A_const_37 = A_arbace_classes_env__init_A_const_pool.A[64]; A_arbace_classes_env__init_A_const_38 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[65]) }

func A_arbace_classes_env__init_A_clinit_p3() { A_arbace_classes_env__init_A_const_39 = A_arbace_classes_env__init_A_const_pool.A[66]; A_arbace_classes_env__init_A_const_40 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[67]); A_arbace_classes_env__init_A_const_41 = A_arbace_classes_env__init_A_const_pool.A[68]; A_arbace_classes_env__init_A_const_42 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[69]); A_arbace_classes_env__init_A_const_43 = A_arbace_classes_env__init_A_const_pool.A[70]; A_arbace_classes_env__init_A_const_44 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[71]); A_arbace_classes_env__init_A_const_45 = A_arbace_classes_env__init_A_const_pool.A[72]; A_arbace_classes_env__init_A_const_46 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[73]); A_arbace_classes_env__init_A_const_47 = A_arbace_classes_env__init_A_const_pool.A[74]; A_arbace_classes_env__init_A_const_48 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[75]); A_arbace_classes_env__init_A_const_49 = A_arbace_classes_env__init_A_const_pool.A[76]; A_arbace_classes_env__init_A_const_50 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[77]); A_arbace_classes_env__init_A_const_51 = A_arbace_classes_env__init_A_const_pool.A[78] }

func A_arbace_classes_env__init_A_clinit_p4() { A_arbace_classes_env__init_A_const_52 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[79]); A_arbace_classes_env__init_A_const_53 = A_arbace_classes_env__init_A_const_pool.A[80]; A_arbace_classes_env__init_A_const_54 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[81]); A_arbace_classes_env__init_A_const_55 = A_arbace_classes_env__init_A_const_pool.A[82]; A_arbace_classes_env__init_A_const_56 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[83]); A_arbace_classes_env__init_A_const_57 = A_arbace_classes_env__init_A_const_pool.A[84]; A_arbace_classes_env__init_A_const_58 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[85]); A_arbace_classes_env__init_A_const_59 = A_arbace_classes_env__init_A_const_pool.A[86]; A_arbace_classes_env__init_A_const_60 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[87]); A_arbace_classes_env__init_A_const_61 = A_arbace_classes_env__init_A_const_pool.A[88]; A_arbace_classes_env__init_A_const_62 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[89]); A_arbace_classes_env__init_A_const_63 = A_arbace_classes_env__init_A_const_pool.A[90]; A_arbace_classes_env__init_A_const_64 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[91]) }

func A_arbace_classes_env__init_A_clinit_p5() { A_arbace_classes_env__init_A_const_65 = A_arbace_classes_env__init_A_const_pool.A[92]; A_arbace_classes_env__init_A_const_66 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[93]); A_arbace_classes_env__init_A_const_67 = A_arbace_classes_env__init_A_const_pool.A[94]; A_arbace_classes_env__init_A_const_68 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[95]); A_arbace_classes_env__init_A_const_69 = A_arbace_classes_env__init_A_const_pool.A[96]; A_arbace_classes_env__init_A_const_70 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[97]); A_arbace_classes_env__init_A_const_71 = A_arbace_classes_env__init_A_const_pool.A[98]; A_arbace_classes_env__init_A_const_72 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[99]); A_arbace_classes_env__init_A_const_73 = A_arbace_classes_env__init_A_const_pool.A[100]; A_arbace_classes_env__init_A_const_74 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[101]); A_arbace_classes_env__init_A_const_75 = A_arbace_classes_env__init_A_const_pool.A[102]; A_arbace_classes_env__init_A_const_76 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[103]); A_arbace_classes_env__init_A_const_77 = A_arbace_classes_env__init_A_const_pool.A[104] }

func A_arbace_classes_env__init_A_clinit_p6() { A_arbace_classes_env__init_A_const_78 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[105]); A_arbace_classes_env__init_A_const_79 = A_arbace_classes_env__init_A_const_pool.A[106]; A_arbace_classes_env__init_A_const_80 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[107]); A_arbace_classes_env__init_A_const_81 = A_arbace_classes_env__init_A_const_pool.A[108]; A_arbace_classes_env__init_A_const_82 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[109]); A_arbace_classes_env__init_A_const_83 = A_arbace_classes_env__init_A_const_pool.A[110]; A_arbace_classes_env__init_A_const_84 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[111]); A_arbace_classes_env__init_A_const_85 = A_arbace_classes_env__init_A_const_pool.A[112]; A_arbace_classes_env__init_A_const_86 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[113]); A_arbace_classes_env__init_A_const_87 = A_arbace_classes_env__init_A_const_pool.A[114]; A_arbace_classes_env__init_A_const_88 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[115]); A_arbace_classes_env__init_A_const_89 = A_arbace_classes_env__init_A_const_pool.A[116]; A_arbace_classes_env__init_A_const_90 = lang.Var_Cast(A_arbace_classes_env__init_A_const_pool.A[117]) }

func A_arbace_classes_env__init_A_clinit_p7() { A_arbace_classes_env__init_A_const_91 = A_arbace_classes_env__init_A_const_pool.A[118] }

func A_arbace_classes_env__init_A_New() *A_arbace_classes_env__init_A { A_arbace_classes_env__init_A_Init(); t := &A_arbace_classes_env__init_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_env__init_A) Ctor() {}

func (t *A_arbace_classes_env__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env__init_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env__init_A_class }

func (t *A_arbace_classes_env__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_env__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env__init_A); return ok }

func A_arbace_classes_env__init_A_Cast(x any) *A_arbace_classes_env__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env__init_A_class)) }; return v }
