//line aot_arbace_classes_env__init.ae:1
package aot_arbace_classes_env

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_env__init_A_Unit0__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(jrt.NN(A_arbace_classes_env__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_classes_env__init_A_const_1) }
//line :1:1
func A_arbace_classes_env__init_A_Unit1__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_classes_env__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_2)) }
//line :1:1
func A_arbace_classes_env__init_A_Unit2__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_New(); var tmp2 *jrt.Class; A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_Init(); tmp2 = A_arbace_classes_env_eval28000004_loading__1927001464__auto____28000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_classes_env__init_A_Unit3__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_classes_env__init_A_const_1)).Equals_O__Z(A_arbace_classes_env__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_classes_env_eval28000008_fn__28000009_A_New(); var tmp2 *jrt.Class; A_arbace_classes_env_eval28000008_fn__28000009_A_Init(); tmp2 = A_arbace_classes_env_eval28000008_fn__28000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_classes_env__init_A_Load__O() any { A_arbace_classes_env__init_A_Init(); A_arbace_classes_env__init_A_Unit0__O(); A_arbace_classes_env__init_A_Unit1__O(); A_arbace_classes_env__init_A_Unit2__O(); A_arbace_classes_env__init_A_Unit3__O(); A_arbace_classes_env__init_A_Unit4__O(); A_arbace_classes_env__init_A_Unit5__O(); A_arbace_classes_env__init_A_Unit6__O(); A_arbace_classes_env__init_A_Unit7__O(); A_arbace_classes_env__init_A_Unit8__O(); A_arbace_classes_env__init_A_Unit9__O(); A_arbace_classes_env__init_A_Unit10__O(); A_arbace_classes_env__init_A_Unit11__O(); A_arbace_classes_env__init_A_Unit12__O(); A_arbace_classes_env__init_A_Unit13__O(); A_arbace_classes_env__init_A_Unit14__O(); A_arbace_classes_env__init_A_Unit15__O(); A_arbace_classes_env__init_A_Unit16__O(); A_arbace_classes_env__init_A_Unit17__O(); A_arbace_classes_env__init_A_Unit18__O(); A_arbace_classes_env__init_A_Unit19__O(); A_arbace_classes_env__init_A_Unit20__O(); A_arbace_classes_env__init_A_Unit21__O(); A_arbace_classes_env__init_A_Unit22__O(); A_arbace_classes_env__init_A_Unit23__O(); A_arbace_classes_env__init_A_Unit24__O(); A_arbace_classes_env__init_A_Unit25__O(); A_arbace_classes_env__init_A_Unit26__O(); A_arbace_classes_env__init_A_Unit27__O(); A_arbace_classes_env__init_A_Unit28__O(); A_arbace_classes_env__init_A_Unit29__O(); A_arbace_classes_env__init_A_Unit30__O(); A_arbace_classes_env__init_A_Unit31__O(); A_arbace_classes_env__init_A_Unit32__O(); A_arbace_classes_env__init_A_Unit33__O(); A_arbace_classes_env__init_A_Unit34__O(); A_arbace_classes_env__init_A_Unit35__O(); A_arbace_classes_env__init_A_Unit36__O(); A_arbace_classes_env__init_A_Unit37__O(); A_arbace_classes_env__init_A_Unit38__O(); A_arbace_classes_env__init_A_Unit39__O(); A_arbace_classes_env__init_A_Unit40__O(); return nil }













func A_arbace_classes_env__init_A_Unit4__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(19, 1); jrt.NN(A_arbace_classes_env__init_A_const_4).BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_4; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_5)); return jrt.NN(A_arbace_classes_env__init_A_const_4).SetDynamic_Z__Var(true).Ref() }



func A_arbace_classes_env__init_A_Unit5__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(23, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_6; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_7)); v__1927001498__auto____1 = A_arbace_classes_env__init_A_const_6.Ref(); if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_classes_env__init_A_const_6; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_9)); var tmp3 *lang.Var = A_arbace_classes_env__init_A_const_6; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_classes_env__init_A_const_8).GetRawRoot__O()); var tmp5 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp5 = lang.PersistentArrayMap_EMPTY; jrt.NN(tmp3).BindRoot_O__V(tmp4.Invoke_O__O(tmp5.Ref())); return A_arbace_classes_env__init_A_const_6.Ref() } }





func A_arbace_classes_env__init_A_Unit6__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(29, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_10; var tmp2 any = A_arbace_classes_env_internal_A_New(); var tmp3 *jrt.Class; A_arbace_classes_env_internal_A_Init(); tmp3 = A_arbace_classes_env_internal_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_10; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_11)); return A_arbace_classes_env__init_A_const_10.Ref() }

func A_arbace_classes_env__init_A_Unit7__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(31, 1); jrt.NN(A_arbace_classes_env__init_A_const_12).BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_12; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_13)); return jrt.NN(A_arbace_classes_env__init_A_const_12).SetDynamic_Z__Var(true).Ref() }





func A_arbace_classes_env__init_A_Unit8__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(37, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_14; var tmp2 any = A_arbace_classes_env_from_source_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_classes_env_from_source_QMARK__A_Init(); tmp3 = A_arbace_classes_env_from_source_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_14; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_15)); return A_arbace_classes_env__init_A_const_14.Ref() }

func A_arbace_classes_env__init_A_Unit9__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(39, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_classes_env__init_A_const_8).GetRawRoot__O()); var tmp3 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp3 = lang.PersistentArrayMap_EMPTY; jrt.NN(tmp1).BindRoot_O__V(tmp2.Invoke_O__O(tmp3.Ref())); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_16; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_17)); return A_arbace_classes_env__init_A_const_16.Ref() }




func A_arbace_classes_env__init_A_Unit10__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(44, 1); jrt.NN(A_arbace_classes_env__init_A_const_18).BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_18; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_19)); return jrt.NN(A_arbace_classes_env__init_A_const_18).SetDynamic_Z__Var(true).Ref() }






func A_arbace_classes_env__init_A_Unit11__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(51, 1); jrt.NN(A_arbace_classes_env__init_A_const_20).BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_20; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_21)); return jrt.NN(A_arbace_classes_env__init_A_const_20).SetDynamic_Z__Var(true).Ref() }




func A_arbace_classes_env__init_A_Unit12__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(56, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_22; var tmp2 any = A_arbace_classes_env_record_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_classes_env_record_BANG__A_Init(); tmp3 = A_arbace_classes_env_record_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_22; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_23)); return A_arbace_classes_env__init_A_const_22.Ref() }





func A_arbace_classes_env__init_A_Unit13__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(62, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_24; var tmp2 any = A_arbace_classes_env_load_class_A_New(); var tmp3 *jrt.Class; A_arbace_classes_env_load_class_A_Init(); tmp3 = A_arbace_classes_env_load_class_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_24; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_25)); return A_arbace_classes_env__init_A_const_24.Ref() }












func A_arbace_classes_env__init_A_Unit14__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(75, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_26; var tmp2 any = A_arbace_classes_env_known_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_classes_env_known_QMARK__A_Init(); tmp3 = A_arbace_classes_env_known_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_26; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_27)); return A_arbace_classes_env__init_A_const_26.Ref() }




func A_arbace_classes_env__init_A_Unit15__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(80, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_28; var tmp2 any = A_arbace_classes_env_reflected_A_New(); var tmp3 *jrt.Class; A_arbace_classes_env_reflected_A_Init(); tmp3 = A_arbace_classes_env_reflected_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_28; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_29)); return A_arbace_classes_env__init_A_const_28.Ref() }














func A_arbace_classes_env__init_A_Unit16__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(95, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_30; var tmp2 any = A_arbace_classes_env_class_file_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_classes_env_class_file_QMARK__A_Init(); tmp3 = A_arbace_classes_env_class_file_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_30; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_31)); return A_arbace_classes_env__init_A_const_30.Ref() }










func A_arbace_classes_env__init_A_Unit17__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(106, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_32; var tmp2 any = A_arbace_classes_env_read_fields_A_New(); var tmp3 *jrt.Class; A_arbace_classes_env_read_fields_A_Init(); tmp3 = A_arbace_classes_env_read_fields_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_32; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_33)); return A_arbace_classes_env__init_A_const_32.Ref() }







func A_arbace_classes_env__init_A_Unit18__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(114, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_34; var tmp2 any = A_arbace_classes_env_read_method_annotations_A_New(); var tmp3 *jrt.Class; A_arbace_classes_env_read_method_annotations_A_Init(); tmp3 = A_arbace_classes_env_read_method_annotations_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_34; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_35)); return A_arbace_classes_env__init_A_const_34.Ref() }







func A_arbace_classes_env__init_A_Unit19__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(122, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_36; var tmp2 any = A_arbace_classes_env_coerce_const_A_New(); var tmp3 *jrt.Class; A_arbace_classes_env_coerce_const_A_Init(); tmp3 = A_arbace_classes_env_coerce_const_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_36; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_37)); return A_arbace_classes_env__init_A_const_36.Ref() }







func A_arbace_classes_env__init_A_Unit20__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(130, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_38; jrt.NN(tmp1).BindRoot_O__V(jrt.HashMap_New()); var tmp2 *lang.Var = A_arbace_classes_env__init_A_const_38; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_39)); return A_arbace_classes_env__init_A_const_38.Ref() }




func A_arbace_classes_env__init_A_Unit21__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(135, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_40; var tmp2 any = A_arbace_classes_env_inner_member_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_classes_env_inner_member_QMARK__A_Init(); tmp3 = A_arbace_classes_env_inner_member_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_40; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_41)); return A_arbace_classes_env__init_A_const_40.Ref() }



func A_arbace_classes_env__init_A_Unit22__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(139, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_42; var tmp2 any = A_arbace_classes_env_reflect_info_A_New(); var tmp3 *jrt.Class; A_arbace_classes_env_reflect_info_A_Init(); tmp3 = A_arbace_classes_env_reflect_info_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_42; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_43)); return A_arbace_classes_env__init_A_const_42.Ref() }























































func A_arbace_classes_env__init_A_Unit23__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(195, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_44; var tmp2 any = A_arbace_classes_env_info_A_New(); var tmp3 *jrt.Class; A_arbace_classes_env_info_A_Init(); tmp3 = A_arbace_classes_env_info_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_44; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_45)); return A_arbace_classes_env__init_A_const_44.Ref() }










func A_arbace_classes_env__init_A_Unit24__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(206, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_46; var tmp2 any = A_arbace_classes_env_info_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_classes_env_info_BANG__A_Init(); tmp3 = A_arbace_classes_env_info_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_46; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_47)); return A_arbace_classes_env__init_A_const_46.Ref() }


func A_arbace_classes_env__init_A_Unit25__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(209, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_48; var tmp2 any = A_arbace_classes_env_interface_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_classes_env_interface_QMARK__A_Init(); tmp3 = A_arbace_classes_env_interface_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_48; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_49)); return A_arbace_classes_env__init_A_const_48.Ref() }


func A_arbace_classes_env__init_A_Unit26__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(212, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_50; var tmp2 any = A_arbace_classes_env_const_value_A_New(); var tmp3 *jrt.Class; A_arbace_classes_env_const_value_A_Init(); tmp3 = A_arbace_classes_env_const_value_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_50; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_51)); return A_arbace_classes_env__init_A_const_50.Ref() }


func A_arbace_classes_env__init_A_Unit27__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(215, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_52; var tmp2 any = A_arbace_classes_env_supertypes_A_New(); var tmp3 *jrt.Class; A_arbace_classes_env_supertypes_A_Init(); tmp3 = A_arbace_classes_env_supertypes_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_52; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_53)); return A_arbace_classes_env__init_A_const_52.Ref() }




func A_arbace_classes_env__init_A_Unit28__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(220, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_54; var tmp2 any = A_arbace_classes_env_subclass_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_classes_env_subclass_QMARK__A_Init(); tmp3 = A_arbace_classes_env_subclass_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_54; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_55)); return A_arbace_classes_env__init_A_const_54.Ref() }






func A_arbace_classes_env__init_A_Unit29__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(227, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_56; var tmp2 any = A_arbace_classes_env_assignable_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_classes_env_assignable_QMARK__A_Init(); tmp3 = A_arbace_classes_env_assignable_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_56; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_57)); return A_arbace_classes_env__init_A_const_56.Ref() }














func A_arbace_classes_env__init_A_Unit30__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(242, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_58; var tmp2 any = A_arbace_classes_env_superclass_chain_A_New(); var tmp3 *jrt.Class; A_arbace_classes_env_superclass_chain_A_Init(); tmp3 = A_arbace_classes_env_superclass_chain_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_58; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_59)); return A_arbace_classes_env__init_A_const_58.Ref() }


func A_arbace_classes_env__init_A_Unit31__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(245, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_60; var tmp2 any = A_arbace_classes_env_common_super_A_New(); var tmp3 *jrt.Class; A_arbace_classes_env_common_super_A_Init(); tmp3 = A_arbace_classes_env_common_super_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_60; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_61)); return A_arbace_classes_env__init_A_const_60.Ref() }











func A_arbace_classes_env__init_A_Unit32__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(257, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_62; var tmp2 any = A_arbace_classes_env_lub_A_New(); var tmp3 *jrt.Class; A_arbace_classes_env_lub_A_Init(); tmp3 = A_arbace_classes_env_lub_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_62; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_63)); return A_arbace_classes_env__init_A_const_62.Ref() }
























func A_arbace_classes_env__init_A_Unit33__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(282, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_64; var tmp2 any = A_arbace_classes_env_nest_host_A_New(); var tmp3 *jrt.Class; A_arbace_classes_env_nest_host_A_Init(); tmp3 = A_arbace_classes_env_nest_host_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_64; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_65)); return A_arbace_classes_env__init_A_const_64.Ref() }




func A_arbace_classes_env__init_A_Unit34__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(287, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_66; var tmp2 any = A_arbace_classes_env_flag_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_classes_env_flag_QMARK__A_Init(); tmp3 = A_arbace_classes_env_flag_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_66; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_67)); return A_arbace_classes_env__init_A_const_66.Ref() }

func A_arbace_classes_env__init_A_Unit35__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(289, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_68; var tmp2 any = A_arbace_classes_env_accessible_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_classes_env_accessible_QMARK__A_Init(); tmp3 = A_arbace_classes_env_accessible_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_68; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_69)); return A_arbace_classes_env__init_A_const_68.Ref() }












func A_arbace_classes_env__init_A_Unit36__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(302, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_70; var tmp2 any = A_arbace_classes_env_find_field_A_New(); var tmp3 *jrt.Class; A_arbace_classes_env_find_field_A_Init(); tmp3 = A_arbace_classes_env_find_field_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_70; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_71)); return A_arbace_classes_env__init_A_const_70.Ref() }








func A_arbace_classes_env__init_A_Unit37__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(311, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_72; var tmp2 any = A_arbace_classes_env_all_supertypes_A_New(); var tmp3 *jrt.Class; A_arbace_classes_env_all_supertypes_A_Init(); tmp3 = A_arbace_classes_env_all_supertypes_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_72; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_73)); return A_arbace_classes_env__init_A_const_72.Ref() }










func A_arbace_classes_env__init_A_Unit38__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(322, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_74; var tmp2 any = A_arbace_classes_env_params_key_A_New(); var tmp3 *jrt.Class; A_arbace_classes_env_params_key_A_Init(); tmp3 = A_arbace_classes_env_params_key_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_74; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_75)); return A_arbace_classes_env__init_A_const_74.Ref() }

func A_arbace_classes_env__init_A_Unit39__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(324, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_76; var tmp2 any = A_arbace_classes_env_member_methods_A_New(); var tmp3 *jrt.Class; A_arbace_classes_env_member_methods_A_Init(); tmp3 = A_arbace_classes_env_member_methods_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_76; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_77)); return A_arbace_classes_env__init_A_const_76.Ref() }















func A_arbace_classes_env__init_A_Unit40__O() any { A_arbace_classes_env__init_A_Init(); lang.Compiler_AOT_At_I_I__V(340, 1); var tmp1 *lang.Var = A_arbace_classes_env__init_A_const_78; var tmp2 any = A_arbace_classes_env_constructors_A_New(); var tmp3 *jrt.Class; A_arbace_classes_env_constructors_A_Init(); tmp3 = A_arbace_classes_env_constructors_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_env__init_A_const_78; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_env__init_A_const_79)); return A_arbace_classes_env__init_A_const_78.Ref() }



type A_arbace_classes_env__init_A struct{ jrt.Object }

var A_arbace_classes_env__init_A_const_0 *lang.Var

var A_arbace_classes_env__init_A_const_1 any

var A_arbace_classes_env__init_A_const_2 any

var A_arbace_classes_env__init_A_const_3 any

var A_arbace_classes_env__init_A_const_4 *lang.Var

var A_arbace_classes_env__init_A_const_5 any

var A_arbace_classes_env__init_A_const_6 *lang.Var

var A_arbace_classes_env__init_A_const_7 any

var A_arbace_classes_env__init_A_const_8 *lang.Var

var A_arbace_classes_env__init_A_const_9 any

var A_arbace_classes_env__init_A_const_10 *lang.Var

var A_arbace_classes_env__init_A_const_11 any

var A_arbace_classes_env__init_A_const_12 *lang.Var

var A_arbace_classes_env__init_A_const_13 any

var A_arbace_classes_env__init_A_const_14 *lang.Var

var A_arbace_classes_env__init_A_const_15 any

var A_arbace_classes_env__init_A_const_16 *lang.Var

var A_arbace_classes_env__init_A_const_17 any

var A_arbace_classes_env__init_A_const_18 *lang.Var

var A_arbace_classes_env__init_A_const_19 any

var A_arbace_classes_env__init_A_const_20 *lang.Var

var A_arbace_classes_env__init_A_const_21 any

var A_arbace_classes_env__init_A_const_22 *lang.Var

var A_arbace_classes_env__init_A_const_23 any

var A_arbace_classes_env__init_A_const_24 *lang.Var

var A_arbace_classes_env__init_A_const_25 any

var A_arbace_classes_env__init_A_const_26 *lang.Var

var A_arbace_classes_env__init_A_const_27 any

var A_arbace_classes_env__init_A_const_28 *lang.Var

var A_arbace_classes_env__init_A_const_29 any

var A_arbace_classes_env__init_A_const_30 *lang.Var

var A_arbace_classes_env__init_A_const_31 any

var A_arbace_classes_env__init_A_const_32 *lang.Var

var A_arbace_classes_env__init_A_const_33 any

var A_arbace_classes_env__init_A_const_34 *lang.Var

var A_arbace_classes_env__init_A_const_35 any

var A_arbace_classes_env__init_A_const_36 *lang.Var

var A_arbace_classes_env__init_A_const_37 any

var A_arbace_classes_env__init_A_const_38 *lang.Var

var A_arbace_classes_env__init_A_const_39 any

var A_arbace_classes_env__init_A_const_40 *lang.Var

var A_arbace_classes_env__init_A_const_41 any

var A_arbace_classes_env__init_A_const_42 *lang.Var

var A_arbace_classes_env__init_A_const_43 any

var A_arbace_classes_env__init_A_const_44 *lang.Var

var A_arbace_classes_env__init_A_const_45 any

var A_arbace_classes_env__init_A_const_46 *lang.Var

var A_arbace_classes_env__init_A_const_47 any

var A_arbace_classes_env__init_A_const_48 *lang.Var

var A_arbace_classes_env__init_A_const_49 any

var A_arbace_classes_env__init_A_const_50 *lang.Var

var A_arbace_classes_env__init_A_const_51 any

var A_arbace_classes_env__init_A_const_52 *lang.Var

var A_arbace_classes_env__init_A_const_53 any

var A_arbace_classes_env__init_A_const_54 *lang.Var

var A_arbace_classes_env__init_A_const_55 any

var A_arbace_classes_env__init_A_const_56 *lang.Var

var A_arbace_classes_env__init_A_const_57 any

var A_arbace_classes_env__init_A_const_58 *lang.Var

var A_arbace_classes_env__init_A_const_59 any

var A_arbace_classes_env__init_A_const_60 *lang.Var

var A_arbace_classes_env__init_A_const_61 any

var A_arbace_classes_env__init_A_const_62 *lang.Var

var A_arbace_classes_env__init_A_const_63 any

var A_arbace_classes_env__init_A_const_64 *lang.Var

var A_arbace_classes_env__init_A_const_65 any

var A_arbace_classes_env__init_A_const_66 *lang.Var

var A_arbace_classes_env__init_A_const_67 any

var A_arbace_classes_env__init_A_const_68 *lang.Var

var A_arbace_classes_env__init_A_const_69 any

var A_arbace_classes_env__init_A_const_70 *lang.Var

var A_arbace_classes_env__init_A_const_71 any

var A_arbace_classes_env__init_A_const_72 *lang.Var

var A_arbace_classes_env__init_A_const_73 any

var A_arbace_classes_env__init_A_const_74 *lang.Var

var A_arbace_classes_env__init_A_const_75 any

var A_arbace_classes_env__init_A_const_76 *lang.Var

var A_arbace_classes_env__init_A_const_77 any

var A_arbace_classes_env__init_A_const_78 *lang.Var

var A_arbace_classes_env__init_A_const_79 any

var A_arbace_classes_env__init_A_init jrt.ClassInit

func A_arbace_classes_env__init_A_Init() { if !A_arbace_classes_env__init_A_init.Done() { A_arbace_classes_env__init_A_init.Run(A_arbace_classes_env__init_A_clinit) } }

func A_arbace_classes_env__init_A_clinit() { A_arbace_classes_env__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_223); A_arbace_classes_env__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_14)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16))); A_arbace_classes_env__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16)); A_arbace_classes_env__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_classes_env__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_14, Lit_93); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_224).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_classes_env__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(19).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228, lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_229)); A_arbace_classes_env__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_14, Lit_96); A_arbace_classes_env__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_230, lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(23).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228)); A_arbace_classes_env__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_231); A_arbace_classes_env__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_230, lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(23).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228)); A_arbace_classes_env__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_14, Lit_39); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_232).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_classes_env__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_234)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_235).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_236).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(29).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228)); A_arbace_classes_env__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_14, Lit_19); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_224).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_classes_env__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(31).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228, lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_237)); A_arbace_classes_env__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_14, Lit_24); A_arbace_classes_env__init_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_238).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(37).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228)); A_arbace_classes_env__init_A_const_16 = lang.RT_Var_String_String__Var(Lit_14, Lit_239); A_arbace_classes_env__init_A_const_17 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(39).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228, lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_240)); A_arbace_classes_env__init_A_const_18 = lang.RT_Var_String_String__Var(Lit_14, Lit_25); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_224).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_classes_env__init_A_const_19 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(44).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228, lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_241)); A_arbace_classes_env__init_A_const_20 = lang.RT_Var_String_String__Var(Lit_14, Lit_20); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_224).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_classes_env__init_A_const_21 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(51).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228, lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_242)); A_arbace_classes_env__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_14, Lit_27); A_arbace_classes_env__init_A_const_23 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_238).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_37).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_243).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_244, lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(56).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228)); A_arbace_classes_env__init_A_const_24 = lang.RT_Var_String_String__Var(Lit_14, Lit_31); A_arbace_classes_env__init_A_const_25 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_238).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_245, lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(62).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228)); A_arbace_classes_env__init_A_const_26 = lang.RT_Var_String_String__Var(Lit_14, Lit_246); A_arbace_classes_env__init_A_const_27 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_238).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_247, lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(75).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228)); A_arbace_classes_env__init_A_const_28 = lang.RT_Var_String_String__Var(Lit_14, Lit_248); A_arbace_classes_env__init_A_const_29 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_238).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_37).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_249).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_250, lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(80).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228)); A_arbace_classes_env__init_A_const_30 = lang.RT_Var_String_String__Var(Lit_14, Lit_40); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_232).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_classes_env__init_A_const_31 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_234)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_235).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_236).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_251, lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(95).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228)); A_arbace_classes_env__init_A_const_32 = lang.RT_Var_String_String__Var(Lit_14, Lit_43); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_232).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_classes_env__init_A_const_33 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_234)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_235).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_236).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_252, lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(106).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228)); A_arbace_classes_env__init_A_const_34 = lang.RT_Var_String_String__Var(Lit_14, Lit_44); A_arbace_classes_env__init_A_const_35 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_234)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_235).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_236).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_253, lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(114).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228)); A_arbace_classes_env__init_A_const_36 = lang.RT_Var_String_String__Var(Lit_14, Lit_74); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_232).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_classes_env__init_A_const_37 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_67).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_243).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(122).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228)); A_arbace_classes_env__init_A_const_38 = lang.RT_Var_String_String__Var(Lit_14, Lit_46); var tmp25 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_232).Ref(); var tmp26 *jrt.Boolean; jrt.Boolean_Init(); tmp26 = jrt.Boolean_TRUE; var tmp27 any = tmp26.Ref(); A_arbace_classes_env__init_A_const_39 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25, tmp27, lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(130).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228)); A_arbace_classes_env__init_A_const_40 = lang.RT_Var_String_String__Var(Lit_14, Lit_57); var tmp28 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_232).Ref(); var tmp29 *jrt.Boolean; jrt.Boolean_Init(); tmp29 = jrt.Boolean_TRUE; var tmp30 any = tmp29.Ref(); A_arbace_classes_env__init_A_const_41 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp28, tmp30, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_234)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_235).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_236).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(135).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228)); A_arbace_classes_env__init_A_const_42 = lang.RT_Var_String_String__Var(Lit_14, Lit_95); A_arbace_classes_env__init_A_const_43 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_234)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_235).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_236).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(139).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228)); A_arbace_classes_env__init_A_const_44 = lang.RT_Var_String_String__Var(Lit_14, Lit_94); A_arbace_classes_env__init_A_const_45 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_238).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_254, lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(195).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228)); A_arbace_classes_env__init_A_const_46 = lang.RT_Var_String_String__Var(Lit_14, Lit_98); A_arbace_classes_env__init_A_const_47 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_238).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(206).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228)); A_arbace_classes_env__init_A_const_48 = lang.RT_Var_String_String__Var(Lit_14, Lit_48); A_arbace_classes_env__init_A_const_49 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_238).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(209).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228)); A_arbace_classes_env__init_A_const_50 = lang.RT_Var_String_String__Var(Lit_14, Lit_255); A_arbace_classes_env__init_A_const_51 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_256).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(212).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228)); A_arbace_classes_env__init_A_const_52 = lang.RT_Var_String_String__Var(Lit_14, Lit_257); A_arbace_classes_env__init_A_const_53 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_238).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_258, lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(215).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228)); A_arbace_classes_env__init_A_const_54 = lang.RT_Var_String_String__Var(Lit_14, Lit_100); A_arbace_classes_env__init_A_const_55 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_259).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_260).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_261, lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(220).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228)); A_arbace_classes_env__init_A_const_56 = lang.RT_Var_String_String__Var(Lit_14, Lit_106); A_arbace_classes_env__init_A_const_57 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_262).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_263).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_264, lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(227).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228)); A_arbace_classes_env__init_A_const_58 = lang.RT_Var_String_String__Var(Lit_14, Lit_114); A_arbace_classes_env__init_A_const_59 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_238).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(242).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228)); A_arbace_classes_env__init_A_const_60 = lang.RT_Var_String_String__Var(Lit_14, Lit_116); A_arbace_classes_env__init_A_const_61 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_259).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_260).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_265, lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(245).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228)); A_arbace_classes_env__init_A_const_62 = lang.RT_Var_String_String__Var(Lit_14, Lit_266); A_arbace_classes_env__init_A_const_63 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_259).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_260).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_267, lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(257).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228)); A_arbace_classes_env__init_A_const_64 = lang.RT_Var_String_String__Var(Lit_14, Lit_52); A_arbace_classes_env__init_A_const_65 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_238).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(282).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228)); A_arbace_classes_env__init_A_const_66 = lang.RT_Var_String_String__Var(Lit_14, Lit_122); var tmp31 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_232).Ref(); var tmp32 *jrt.Boolean; jrt.Boolean_Init(); tmp32 = jrt.Boolean_TRUE; var tmp33 any = tmp32.Ref(); A_arbace_classes_env__init_A_const_67 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp31, tmp33, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_47).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_249).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(287).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228)); A_arbace_classes_env__init_A_const_68 = lang.RT_Var_String_String__Var(Lit_14, Lit_268); A_arbace_classes_env__init_A_const_69 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_262).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_269).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_270, lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(289).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228)); A_arbace_classes_env__init_A_const_70 = lang.RT_Var_String_String__Var(Lit_14, Lit_124); A_arbace_classes_env__init_A_const_71 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_238).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_35).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_271, lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(302).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228)); A_arbace_classes_env__init_A_const_72 = lang.RT_Var_String_String__Var(Lit_14, Lit_127); A_arbace_classes_env__init_A_const_73 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_238).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_272, lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(311).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228)); A_arbace_classes_env__init_A_const_74 = lang.RT_Var_String_String__Var(Lit_14, Lit_128); var tmp34 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_232).Ref(); var tmp35 *jrt.Boolean; jrt.Boolean_Init(); tmp35 = jrt.Boolean_TRUE; var tmp36 any = tmp35.Ref(); A_arbace_classes_env__init_A_const_75 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp34, tmp36, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_67)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_235).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_273).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(322).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228)); A_arbace_classes_env__init_A_const_76 = lang.RT_Var_String_String__Var(Lit_14, Lit_274); A_arbace_classes_env__init_A_const_77 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_238).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_35).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_275, lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(324).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228)); A_arbace_classes_env__init_A_const_78 = lang.RT_Var_String_String__Var(Lit_14, Lit_92); A_arbace_classes_env__init_A_const_79 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_233).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_238).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_225).Ref(), jrt.Integer_ValueOf_I__Integer(340).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_226).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_227).Ref(), Lit_228)) }

func A_arbace_classes_env__init_A_New() *A_arbace_classes_env__init_A { A_arbace_classes_env__init_A_Init(); t := &A_arbace_classes_env__init_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_env__init_A) Ctor() {}

func (t *A_arbace_classes_env__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_env__init_A) GetClass__Class() *jrt.Class { return A_arbace_classes_env__init_A_class }

func (t *A_arbace_classes_env__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_env__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_env__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_env__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_env__init_A); return ok }

func A_arbace_classes_env__init_A_Cast(x any) *A_arbace_classes_env__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_env__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_env__init_A_class)) }; return v }
