//line j2g_classes.ae:1
package aot_arbace_c_check

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_c_check_align_of_A_class, Name: "arbace.c.check$align_of", Modifiers: 25, Simple: "align_of", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_align_of_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_align_of_STAR__A_class, Name: "arbace.c.check$align_of_STAR_", Modifiers: 25, Simple: "align_of_STAR_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_align_of_STAR__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_align_up_A_class, Name: "arbace.c.check$align_up", Modifiers: 25, Simple: "align_up", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_align_up_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_aligned_value_A_class, Name: "arbace.c.check$aligned_value", Modifiers: 25, Simple: "aligned_value", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_aligned_value_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_ann_BANG__A_class, Name: "arbace.c.check$ann_BANG_", Modifiers: 25, Simple: "ann_BANG_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_ann_BANG__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_arith_result_A_class, Name: "arbace.c.check$arith_result", Modifiers: 25, Simple: "arith_result", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_arith_result_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_arith_type_QMARK__A_class, Name: "arbace.c.check$arith_type_QMARK_", Modifiers: 25, Simple: "arith_type_QMARK_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_arith_type_QMARK__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_arr_A_class, Name: "arbace.c.check$arr", Modifiers: 25, Simple: "arr", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_arr_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_asm_operands_BANG__A_class, Name: "arbace.c.check$asm_operands_BANG_", Modifiers: 25, Simple: "asm_operands_BANG_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_asm_operands_BANG__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_assign_check_A_class, Name: "arbace.c.check$assign_check", Modifiers: 25, Simple: "assign_check", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_assign_check_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_assoc_in_mode_A_class, Name: "arbace.c.check$assoc_in_mode", Modifiers: 25, Simple: "assoc_in_mode", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_assoc_in_mode_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_at_line_A_class, Name: "arbace.c.check$at_line", Modifiers: 25, Simple: "at_line", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_at_line_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR3_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_attr_args_BANG__A_class, Name: "arbace.c.check$attr_args_BANG_", Modifiers: 25, Simple: "attr_args_BANG_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_attr_args_BANG__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_attr_decl_check_BANG__A_class, Name: "arbace.c.check$attr_decl_check_BANG_", Modifiers: 25, Simple: "attr_decl_check_BANG_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_attr_decl_check_BANG__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_attr_items_A_class, Name: "arbace.c.check$attr_items", Modifiers: 25, Simple: "attr_items", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_attr_items_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_attr_items_fn__1876000139_A_class, Name: "arbace.c.check$attr_items$fn__1876000139", Modifiers: 25, Simple: "fn__1876000139", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_attr_items_fn__1876000139_A", Source: "check.ae", Declaring: &A_arbace_c_check_attr_items_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_attrs_of_A_class, Name: "arbace.c.check$attrs_of", Modifiers: 25, Simple: "attrs_of", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_attrs_of_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_attrs_of_fn__1876000143_A_class, Name: "arbace.c.check$attrs_of$fn__1876000143", Modifiers: 25, Simple: "fn__1876000143", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_attrs_of_fn__1876000143_A", Source: "check.ae", Declaring: &A_arbace_c_check_attrs_of_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_auto_type_QMARK__A_class, Name: "arbace.c.check$auto_type_QMARK_", Modifiers: 25, Simple: "auto_type_QMARK_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_auto_type_QMARK__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_base_fn_type_QMARK__A_class, Name: "arbace.c.check$base_fn_type_QMARK_", Modifiers: 25, Simple: "base_fn_type_QMARK_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_base_fn_type_QMARK__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_base_fn_type_QMARK__fn__1876000196_A_class, Name: "arbace.c.check$base_fn_type_QMARK_$fn__1876000196", Modifiers: 25, Simple: "fn__1876000196", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_base_fn_type_QMARK__fn__1876000196_A", Source: "check.ae", Declaring: &A_arbace_c_check_base_fn_type_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_big_QMARK__A_class, Name: "arbace.c.check$big_QMARK_", Modifiers: 25, Simple: "big_QMARK_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_big_QMARK__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_binary_A_class, Name: "arbace.c.check$binary", Modifiers: 25, Simple: "binary", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_binary_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_binary_ex__1876000448_A_class, Name: "arbace.c.check$binary$ex__1876000448", Modifiers: 25, Simple: "ex__1876000448", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_binary_ex__1876000448_A", Source: "check.ae", Declaring: &A_arbace_c_check_binary_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_binary_index_type_A_class, Name: "arbace.c.check$binary_index_type", Modifiers: 25, Simple: "binary_index_type", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_binary_index_type_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_bit_field_QMARK__A_class, Name: "arbace.c.check$bit_field_QMARK_", Modifiers: 25, Simple: "bit_field_QMARK_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_bit_field_QMARK__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_bitint_size_A_class, Name: "arbace.c.check$bitint_size", Modifiers: 25, Simple: "bitint_size", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_bitint_size_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_bitint_width_A_class, Name: "arbace.c.check$bitint_width", Modifiers: 25, Simple: "bitint_width", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_bitint_width_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_byte_string_len_A_class, Name: "arbace.c.check$byte_string_len", Modifiers: 25, Simple: "byte_string_len", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_byte_string_len_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_byte_string_len_fn__1876000428_A_class, Name: "arbace.c.check$byte_string_len$fn__1876000428", Modifiers: 25, Simple: "fn__1876000428", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_byte_string_len_fn__1876000428_A", Source: "check.ae", Declaring: &A_arbace_c_check_byte_string_len_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_c23_QMARK__A_class, Name: "arbace.c.check$c23_QMARK_", Modifiers: 25, Simple: "c23_QMARK_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_c23_QMARK__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_c99_QMARK__A_class, Name: "arbace.c.check$c99_QMARK_", Modifiers: 25, Simple: "c99_QMARK_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_c99_QMARK__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_call_A_class, Name: "arbace.c.check$call", Modifiers: 25, Simple: "call", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_call_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_call_builtin_A_class, Name: "arbace.c.check$call_builtin", Modifiers: 25, Simple: "call_builtin", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_call_builtin_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_callee_fn_A_class, Name: "arbace.c.check$callee_fn", Modifiers: 25, Simple: "callee_fn", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_callee_fn_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_char_signed_QMARK__A_class, Name: "arbace.c.check$char_signed_QMARK_", Modifiers: 25, Simple: "char_signed_QMARK_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_char_signed_QMARK__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_block_items_A_class, Name: "arbace.c.check$check_block_items", Modifiers: 25, Simple: "check_block_items", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_block_items_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_block_items_fn__1876000773_A_class, Name: "arbace.c.check$check_block_items$fn__1876000773", Modifiers: 25, Simple: "fn__1876000773", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_block_items_fn__1876000773_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_block_items_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_block_items_fn__1876000778_A_class, Name: "arbace.c.check$check_block_items$fn__1876000778", Modifiers: 25, Simple: "fn__1876000778", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_block_items_fn__1876000778_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_block_items_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_decl_A_class, Name: "arbace.c.check$check_decl", Modifiers: 25, Simple: "check_decl", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_decl_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_declare_A_class, Name: "arbace.c.check$check_declare", Modifiers: 25, Simple: "check_declare", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_declare_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_defn_A_class, Name: "arbace.c.check$check_defn", Modifiers: 25, Simple: "check_defn", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_defn_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_defn_fn__1876000694_A_class, Name: "arbace.c.check$check_defn$fn__1876000694", Modifiers: 25, Simple: "fn__1876000694", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_defn_fn__1876000694_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_defn_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_defn_fn__1876000706_A_class, Name: "arbace.c.check$check_defn$fn__1876000706", Modifiers: 25, Simple: "fn__1876000706", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_defn_fn__1876000706_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_defn_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_defn_fn__1876000711_A_class, Name: "arbace.c.check$check_defn$fn__1876000711", Modifiers: 25, Simple: "fn__1876000711", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_defn_fn__1876000711_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_defn_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_enum_A_class, Name: "arbace.c.check$check_enum", Modifiers: 25, Simple: "check_enum", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_enum_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_enum_fn__1876000384_A_class, Name: "arbace.c.check$check_enum$fn__1876000384", Modifiers: 25, Simple: "fn__1876000384", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_enum_fn__1876000384_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_enum_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_enum_fn__1876000389_A_class, Name: "arbace.c.check$check_enum$fn__1876000389", Modifiers: 25, Simple: "fn__1876000389", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_enum_fn__1876000389_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_enum_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_enum_fn__1876000391_A_class, Name: "arbace.c.check$check_enum$fn__1876000391", Modifiers: 25, Simple: "fn__1876000391", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_enum_fn__1876000391_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_enum_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_enum_fn__1876000393_A_class, Name: "arbace.c.check$check_enum$fn__1876000393", Modifiers: 25, Simple: "fn__1876000393", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_enum_fn__1876000393_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_enum_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_forms_A_class, Name: "arbace.c.check$check_forms", Modifiers: 25, Simple: "check_forms", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_forms_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_init_A_class, Name: "arbace.c.check$check_init", Modifiers: 25, Simple: "check_init", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_init_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_stmt_A_class, Name: "arbace.c.check$check_stmt", Modifiers: 25, Simple: "check_stmt", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_stmt_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_stmt_fn__1876000783_A_class, Name: "arbace.c.check$check_stmt$fn__1876000783", Modifiers: 25, Simple: "fn__1876000783", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_stmt_fn__1876000783_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_stmt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_stmt_fn__1876000785_A_class, Name: "arbace.c.check$check_stmt$fn__1876000785", Modifiers: 25, Simple: "fn__1876000785", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_stmt_fn__1876000785_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_stmt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_stmt_fn__1876000790_A_class, Name: "arbace.c.check$check_stmt$fn__1876000790", Modifiers: 25, Simple: "fn__1876000790", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_stmt_fn__1876000790_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_stmt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_stmt_fn__1876000795_A_class, Name: "arbace.c.check$check_stmt$fn__1876000795", Modifiers: 25, Simple: "fn__1876000795", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_stmt_fn__1876000795_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_stmt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_stmt_fn__1876000797_A_class, Name: "arbace.c.check$check_stmt$fn__1876000797", Modifiers: 25, Simple: "fn__1876000797", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_stmt_fn__1876000797_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_stmt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_stmt_fn__1876000802_A_class, Name: "arbace.c.check$check_stmt$fn__1876000802", Modifiers: 25, Simple: "fn__1876000802", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_stmt_fn__1876000802_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_stmt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_stmt_fn__1876000804_A_class, Name: "arbace.c.check$check_stmt$fn__1876000804", Modifiers: 25, Simple: "fn__1876000804", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_stmt_fn__1876000804_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_stmt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_stmt_fn__1876000806_A_class, Name: "arbace.c.check$check_stmt$fn__1876000806", Modifiers: 25, Simple: "fn__1876000806", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_stmt_fn__1876000806_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_stmt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_stmt_fn__1876000816_A_class, Name: "arbace.c.check$check_stmt$fn__1876000816", Modifiers: 25, Simple: "fn__1876000816", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_stmt_fn__1876000816_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_stmt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_stmt_iv__1876000813_A_class, Name: "arbace.c.check$check_stmt$iv__1876000813", Modifiers: 25, Simple: "iv__1876000813", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_stmt_iv__1876000813_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_stmt_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_struct_A_class, Name: "arbace.c.check$check_struct", Modifiers: 25, Simple: "check_struct", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_struct_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_struct_fn__1876000342_A_class, Name: "arbace.c.check$check_struct$fn__1876000342", Modifiers: 25, Simple: "fn__1876000342", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_struct_fn__1876000342_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_struct_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_struct_fn__1876000344_A_class, Name: "arbace.c.check$check_struct$fn__1876000344", Modifiers: 25, Simple: "fn__1876000344", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_struct_fn__1876000344_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_struct_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_struct_fn__1876000346_A_class, Name: "arbace.c.check$check_struct$fn__1876000346", Modifiers: 25, Simple: "fn__1876000346", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_struct_fn__1876000346_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_struct_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_struct_fn__1876000348_A_class, Name: "arbace.c.check$check_struct$fn__1876000348", Modifiers: 25, Simple: "fn__1876000348", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_struct_fn__1876000348_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_struct_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_top_A_class, Name: "arbace.c.check$check_top", Modifiers: 25, Simple: "check_top", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_top_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_top_fn__1876000844_A_class, Name: "arbace.c.check$check_top$fn__1876000844", Modifiers: 25, Simple: "fn__1876000844", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_top_fn__1876000844_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_top_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_top_fn__1876000854_A_class, Name: "arbace.c.check$check_top$fn__1876000854", Modifiers: 25, Simple: "fn__1876000854", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_top_fn__1876000854_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_top_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_top_fn__1876000856_A_class, Name: "arbace.c.check$check_top$fn__1876000856", Modifiers: 25, Simple: "fn__1876000856", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_top_fn__1876000856_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_top_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_top_fn__1876000875_A_class, Name: "arbace.c.check$check_top$fn__1876000875", Modifiers: 25, Simple: "fn__1876000875", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_top_fn__1876000875_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_top_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_top_fn__1876000880_A_class, Name: "arbace.c.check$check_top$fn__1876000880", Modifiers: 25, Simple: "fn__1876000880", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_top_fn__1876000880_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_top_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_top_info_of__1876000858_A_class, Name: "arbace.c.check$check_top$info_of__1876000858", Modifiers: 25, Simple: "info_of__1876000858", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_top_info_of__1876000858_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_top_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_top_info_of__1876000858_fn__1876000859_A_class, Name: "arbace.c.check$check_top$info_of__1876000858$fn__1876000859", Modifiers: 25, Simple: "fn__1876000859", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_top_info_of__1876000858_fn__1876000859_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_top_info_of__1876000858_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_top_no_pragma__1876000864_A_class, Name: "arbace.c.check$check_top$no_pragma__1876000864", Modifiers: 25, Simple: "no_pragma__1876000864", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_top_no_pragma__1876000864_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_top_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_top_no_pragma__1876000864_fn__1876000865_A_class, Name: "arbace.c.check$check_top$no_pragma__1876000864$fn__1876000865", Modifiers: 25, Simple: "fn__1876000865", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_top_no_pragma__1876000864_fn__1876000865_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_top_no_pragma__1876000864_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_top_norm__1876000852_A_class, Name: "arbace.c.check$check_top$norm__1876000852", Modifiers: 25, Simple: "norm__1876000852", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_top_norm__1876000852_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_top_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_top_read_info__1876000846_A_class, Name: "arbace.c.check$check_top$read_info__1876000846", Modifiers: 25, Simple: "read_info__1876000846", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_top_read_info__1876000846_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_top_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_top_read_info__1876000846_fn__1876000847_A_class, Name: "arbace.c.check$check_top$read_info__1876000846$fn__1876000847", Modifiers: 25, Simple: "fn__1876000847", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_top_read_info__1876000846_fn__1876000847_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_top_read_info__1876000846_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_top_read_info__1876000846_fn__1876000849_A_class, Name: "arbace.c.check$check_top$read_info__1876000846$fn__1876000849", Modifiers: 25, Simple: "fn__1876000849", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_top_read_info__1876000846_fn__1876000849_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_top_read_info__1876000846_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_top_sys_of__1876000862_A_class, Name: "arbace.c.check$check_top$sys_of__1876000862", Modifiers: 25, Simple: "sys_of__1876000862", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_top_sys_of__1876000862_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_top_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_typedef_A_class, Name: "arbace.c.check$check_typedef", Modifiers: 25, Simple: "check_typedef", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_typedef_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_typedef_fn__1876000722_A_class, Name: "arbace.c.check$check_typedef$fn__1876000722", Modifiers: 25, Simple: "fn__1876000722", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_typedef_fn__1876000722_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_typedef_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_unit_A_class, Name: "arbace.c.check$check_unit", Modifiers: 25, Simple: "check_unit", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_unit_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR3_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_unit_fn__1876000903_A_class, Name: "arbace.c.check$check_unit$fn__1876000903", Modifiers: 25, Simple: "fn__1876000903", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_unit_fn__1876000903_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_unit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_unit_fn__1876000903_fn__1876000908_A_class, Name: "arbace.c.check$check_unit$fn__1876000903$fn__1876000908", Modifiers: 25, Simple: "fn__1876000908", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_unit_fn__1876000903_fn__1876000908_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_unit_fn__1876000903_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_unit_fn__1876000903_fn__1876000910_A_class, Name: "arbace.c.check$check_unit$fn__1876000903$fn__1876000910", Modifiers: 25, Simple: "fn__1876000910", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_unit_fn__1876000903_fn__1876000910_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_unit_fn__1876000903_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_unit_fn__1876000917_A_class, Name: "arbace.c.check$check_unit$fn__1876000917", Modifiers: 25, Simple: "fn__1876000917", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_unit_fn__1876000917_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_unit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_unit_fn__1876000919_A_class, Name: "arbace.c.check$check_unit$fn__1876000919", Modifiers: 25, Simple: "fn__1876000919", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_unit_fn__1876000919_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_unit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_unit_iter__1876000887__1876000891_A_class, Name: "arbace.c.check$check_unit$iter__1876000887__1876000891", Modifiers: 25, Simple: "iter__1876000887__1876000891", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_unit_iter__1876000887__1876000891_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_unit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_unit_iter__1876000887__1876000891_fn__1876000892_A_class, Name: "arbace.c.check$check_unit$iter__1876000887__1876000891$fn__1876000892", Modifiers: 25, Simple: "fn__1876000892", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_unit_iter__1876000887__1876000891_fn__1876000892_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_unit_iter__1876000887__1876000891_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_unit_iter__1876000887__1876000891_fn__1876000892_fn__1876000893_A_class, Name: "arbace.c.check$check_unit$iter__1876000887__1876000891$fn__1876000892$fn__1876000893", Modifiers: 25, Simple: "fn__1876000893", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_unit_iter__1876000887__1876000891_fn__1876000892_fn__1876000893_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_unit_iter__1876000887__1876000891_fn__1876000892_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_var_A_class, Name: "arbace.c.check$check_var", Modifiers: 25, Simple: "check_var", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_var_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_var_fn__1876000668_A_class, Name: "arbace.c.check$check_var$fn__1876000668", Modifiers: 25, Simple: "fn__1876000668", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_var_fn__1876000668_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_var_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_check_var_fn__1876000670_A_class, Name: "arbace.c.check$check_var$fn__1876000670", Modifiers: 25, Simple: "fn__1876000670", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_check_var_fn__1876000670_A", Source: "check.ae", Declaring: &A_arbace_c_check_check_var_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_cmp_val_A_class, Name: "arbace.c.check$cmp_val", Modifiers: 25, Simple: "cmp_val", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_cmp_val_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_code_unit_count_A_class, Name: "arbace.c.check$code_unit_count", Modifiers: 25, Simple: "code_unit_count", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_code_unit_count_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_code_unit_count_fn__1876000433_A_class, Name: "arbace.c.check$code_unit_count$fn__1876000433", Modifiers: 25, Simple: "fn__1876000433", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_code_unit_count_fn__1876000433_A", Source: "check.ae", Declaring: &A_arbace_c_check_code_unit_count_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_compatible_QMARK__A_class, Name: "arbace.c.check$compatible_QMARK_", Modifiers: 25, Simple: "compatible_QMARK_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_compatible_QMARK__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_compatible_QMARK__fn__1876000091_A_class, Name: "arbace.c.check$compatible_QMARK_$fn__1876000091", Modifiers: 25, Simple: "fn__1876000091", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_compatible_QMARK__fn__1876000091_A", Source: "check.ae", Declaring: &A_arbace_c_check_compatible_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_compatible_QMARK__fn__1876000093_A_class, Name: "arbace.c.check$compatible_QMARK_$fn__1876000093", Modifiers: 25, Simple: "fn__1876000093", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_compatible_QMARK__fn__1876000093_A", Source: "check.ae", Declaring: &A_arbace_c_check_compatible_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_compatible_QMARK__fn__1876000095_A_class, Name: "arbace.c.check$compatible_QMARK_$fn__1876000095", Modifiers: 25, Simple: "fn__1876000095", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_compatible_QMARK__fn__1876000095_A", Source: "check.ae", Declaring: &A_arbace_c_check_compatible_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_compatible_QMARK__fn__1876000097_A_class, Name: "arbace.c.check$compatible_QMARK_$fn__1876000097", Modifiers: 25, Simple: "fn__1876000097", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_compatible_QMARK__fn__1876000097_A", Source: "check.ae", Declaring: &A_arbace_c_check_compatible_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_compatible_ptr_targets_QMARK__A_class, Name: "arbace.c.check$compatible_ptr_targets_QMARK_", Modifiers: 25, Simple: "compatible_ptr_targets_QMARK_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_compatible_ptr_targets_QMARK__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_complete_array_A_class, Name: "arbace.c.check$complete_array", Modifiers: 25, Simple: "complete_array", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_complete_array_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_complex_type_QMARK__A_class, Name: "arbace.c.check$complex_type_QMARK_", Modifiers: 25, Simple: "complex_type_QMARK_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_complex_type_QMARK__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_composite_A_class, Name: "arbace.c.check$composite", Modifiers: 25, Simple: "composite", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_composite_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_cond_expr_A_class, Name: "arbace.c.check$cond_expr", Modifiers: 25, Simple: "cond_expr", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_cond_expr_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_cond_type_A_class, Name: "arbace.c.check$cond_type", Modifiers: 25, Simple: "cond_type", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_cond_type_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_const_int_A_class, Name: "arbace.c.check$const_int", Modifiers: 25, Simple: "const_int", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_const_int_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_const_int_fn__1876000615_A_class, Name: "arbace.c.check$const_int$fn__1876000615", Modifiers: 25, Simple: "fn__1876000615", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_const_int_fn__1876000615_A", Source: "check.ae", Declaring: &A_arbace_c_check_const_int_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_constexpr_check_BANG__A_class, Name: "arbace.c.check$constexpr_check_BANG_", Modifiers: 25, Simple: "constexpr_check_BANG_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_constexpr_check_BANG__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_constexpr_check_BANG__fn__1876000653_A_class, Name: "arbace.c.check$constexpr_check_BANG_$fn__1876000653", Modifiers: 25, Simple: "fn__1876000653", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_constexpr_check_BANG__fn__1876000653_A", Source: "check.ae", Declaring: &A_arbace_c_check_constexpr_check_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_constexpr_check_BANG__fn__1876000662_A_class, Name: "arbace.c.check$constexpr_check_BANG_$fn__1876000662", Modifiers: 25, Simple: "fn__1876000662", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_constexpr_check_BANG__fn__1876000662_A", Source: "check.ae", Declaring: &A_arbace_c_check_constexpr_check_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_constexpr_float_bad_A_class, Name: "arbace.c.check$constexpr_float_bad", Modifiers: 25, Simple: "constexpr_float_bad", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_constexpr_float_bad_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_conv_val_A_class, Name: "arbace.c.check$conv_val", Modifiers: 25, Simple: "conv_val", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_conv_val_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_cx_A_class, Name: "arbace.c.check$cx", Modifiers: 25, Simple: "cx", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_cx_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_dec_fits_QMARK__A_class, Name: "arbace.c.check$dec_fits_QMARK_", Modifiers: 25, Simple: "dec_fits_QMARK_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_dec_fits_QMARK__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_decay_A_class, Name: "arbace.c.check$decay", Modifiers: 25, Simple: "decay", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_decay_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_decl_form_QMARK__A_class, Name: "arbace.c.check$decl_form_QMARK_", Modifiers: 25, Simple: "decl_form_QMARK_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_decl_form_QMARK__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_decl_position_attrs_BANG__A_class, Name: "arbace.c.check$decl_position_attrs_BANG_", Modifiers: 25, Simple: "decl_position_attrs_BANG_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_decl_position_attrs_BANG__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_declare_BANG__A_class, Name: "arbace.c.check$declare_BANG_", Modifiers: 25, Simple: "declare_BANG_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_declare_BANG__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_declare_object_BANG__A_class, Name: "arbace.c.check$declare_object_BANG_", Modifiers: 25, Simple: "declare_object_BANG_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_declare_object_BANG__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF6_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_declare_object_BANG__fn__1876000626_A_class, Name: "arbace.c.check$declare_object_BANG_$fn__1876000626", Modifiers: 25, Simple: "fn__1876000626", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_declare_object_BANG__fn__1876000626_A", Source: "check.ae", Declaring: &A_arbace_c_check_declare_object_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_declare_object_BANG__tyof_QMARK___1876000624_A_class, Name: "arbace.c.check$declare_object_BANG_$tyof_QMARK___1876000624", Modifiers: 25, Simple: "tyof_QMARK___1876000624", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_declare_object_BANG__tyof_QMARK___1876000624_A", Source: "check.ae", Declaring: &A_arbace_c_check_declare_object_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_deref_type_A_class, Name: "arbace.c.check$deref_type", Modifiers: 25, Simple: "deref_type", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_deref_type_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_emit_BANG__A_class, Name: "arbace.c.check$emit_BANG_", Modifiers: 25, Simple: "emit_BANG_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_emit_BANG__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_enum_type_of_A_class, Name: "arbace.c.check$enum_type_of", Modifiers: 25, Simple: "enum_type_of", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_enum_type_of_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_enum_type_of_fits__1876000356_A_class, Name: "arbace.c.check$enum_type_of$fits__1876000356", Modifiers: 25, Simple: "fits__1876000356", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_enum_type_of_fits__1876000356_A", Source: "check.ae", Declaring: &A_arbace_c_check_enum_type_of_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_enum_type_of_fits__1876000356_fn__1876000357_A_class, Name: "arbace.c.check$enum_type_of$fits__1876000356$fn__1876000357", Modifiers: 25, Simple: "fn__1876000357", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_enum_type_of_fits__1876000356_fn__1876000357_A", Source: "check.ae", Declaring: &A_arbace_c_check_enum_type_of_fits__1876000356_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_enum_under_A_class, Name: "arbace.c.check$enum_under", Modifiers: 25, Simple: "enum_under", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_enum_under_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_err_BANG__A_class, Name: "arbace.c.check$err_BANG_", Modifiers: 25, Simple: "err_BANG_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_err_BANG__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_eval1876000004_loading__1927001464__auto____1876000005_A_class, Name: "arbace.c.check$eval1876000004$loading__1927001464__auto____1876000005", Modifiers: 25, Simple: "loading__1927001464__auto____1876000005", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_eval1876000004_loading__1927001464__auto____1876000005_A", Source: "check.ae", Declaring: &A_arbace_c_check_eval1876000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_eval1876000008_fn__1876000009_A_class, Name: "arbace.c.check$eval1876000008$fn__1876000009", Modifiers: 25, Simple: "fn__1876000009", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_eval1876000008_fn__1876000009_A", Source: "check.ae", Declaring: &A_arbace_c_check_eval1876000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_eval_type_A_class, Name: "arbace.c.check$eval_type", Modifiers: 25, Simple: "eval_type", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_eval_type_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_ex_A_class, Name: "arbace.c.check$ex", Modifiers: 25, Simple: "ex", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_ex_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_ex_STAR__A_class, Name: "arbace.c.check$ex_STAR_", Modifiers: 25, Simple: "ex_STAR_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_ex_STAR__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_ex_STAR__fn__1876000576_A_class, Name: "arbace.c.check$ex_STAR_$fn__1876000576", Modifiers: 25, Simple: "fn__1876000576", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_ex_STAR__fn__1876000576_A", Source: "check.ae", Declaring: &A_arbace_c_check_ex_STAR__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_ex_STAR__fn__1876000592_A_class, Name: "arbace.c.check$ex_STAR_$fn__1876000592", Modifiers: 25, Simple: "fn__1876000592", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_ex_STAR__fn__1876000592_A", Source: "check.ae", Declaring: &A_arbace_c_check_ex_STAR__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_ex_STAR__fn__1876000611_A_class, Name: "arbace.c.check$ex_STAR_$fn__1876000611", Modifiers: 25, Simple: "fn__1876000611", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_ex_STAR__fn__1876000611_A", Source: "check.ae", Declaring: &A_arbace_c_check_ex_STAR__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_exi_A_class, Name: "arbace.c.check$exi", Modifiers: 25, Simple: "exi", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_exi_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_feat_BANG__A_class, Name: "arbace.c.check$feat_BANG_", Modifiers: 25, Simple: "feat_BANG_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_feat_BANG__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_file_declare_BANG__A_class, Name: "arbace.c.check$file_declare_BANG_", Modifiers: 25, Simple: "file_declare_BANG_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_file_declare_BANG__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_file_scope_QMARK__A_class, Name: "arbace.c.check$file_scope_QMARK_", Modifiers: 25, Simple: "file_scope_QMARK_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_file_scope_QMARK__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_fits_binary_QMARK__A_class, Name: "arbace.c.check$fits_binary_QMARK_", Modifiers: 25, Simple: "fits_binary_QMARK_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_fits_binary_QMARK__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_float_of_A_class, Name: "arbace.c.check$float_of", Modifiers: 25, Simple: "float_of", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_float_of_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_float_of_exact_A_class, Name: "arbace.c.check$float_of_exact", Modifiers: 25, Simple: "float_of_exact", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_float_of_exact_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_float_op_A_class, Name: "arbace.c.check$float_op", Modifiers: 25, Simple: "float_op", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_float_op_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_float_tie_A_class, Name: "arbace.c.check$float_tie", Modifiers: 25, Simple: "float_tie", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_float_tie_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_float_type_QMARK__A_class, Name: "arbace.c.check$float_type_QMARK_", Modifiers: 25, Simple: "float_type_QMARK_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_float_type_QMARK__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_fn__1876000014_A_class, Name: "arbace.c.check$fn__1876000014", Modifiers: 25, Simple: "fn__1876000014", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_fn__1876000014_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_generic_select_A_class, Name: "arbace.c.check$generic_select", Modifiers: 25, Simple: "generic_select", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_generic_select_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_generic_select_iter__1876000501__1876000505_A_class, Name: "arbace.c.check$generic_select$iter__1876000501__1876000505", Modifiers: 25, Simple: "iter__1876000501__1876000505", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_generic_select_iter__1876000501__1876000505_A", Source: "check.ae", Declaring: &A_arbace_c_check_generic_select_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_generic_select_iter__1876000501__1876000505_fn__1876000506_A_class, Name: "arbace.c.check$generic_select$iter__1876000501__1876000505$fn__1876000506", Modifiers: 25, Simple: "fn__1876000506", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_generic_select_iter__1876000501__1876000505_fn__1876000506_A", Source: "check.ae", Declaring: &A_arbace_c_check_generic_select_iter__1876000501__1876000505_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_generic_select_iter__1876000501__1876000505_fn__1876000506_fn__1876000507_A_class, Name: "arbace.c.check$generic_select$iter__1876000501__1876000505$fn__1876000506$fn__1876000507", Modifiers: 25, Simple: "fn__1876000507", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_generic_select_iter__1876000501__1876000505_fn__1876000506_fn__1876000507_A", Source: "check.ae", Declaring: &A_arbace_c_check_generic_select_iter__1876000501__1876000505_fn__1876000506_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_head_name_A_class, Name: "arbace.c.check$head_name", Modifiers: 25, Simple: "head_name", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_head_name_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_ident_A_class, Name: "arbace.c.check$ident", Modifiers: 25, Simple: "ident", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_ident_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_ident_expr_A_class, Name: "arbace.c.check$ident_expr", Modifiers: 25, Simple: "ident_expr", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_ident_expr_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_ignored_BANG__A_class, Name: "arbace.c.check$ignored_BANG_", Modifiers: 25, Simple: "ignored_BANG_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_ignored_BANG__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_implicit_fn_BANG__A_class, Name: "arbace.c.check$implicit_fn_BANG_", Modifiers: 25, Simple: "implicit_fn_BANG_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_implicit_fn_BANG__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_incomplete_type_QMARK__A_class, Name: "arbace.c.check$incomplete_type_QMARK_", Modifiers: 25, Simple: "incomplete_type_QMARK_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_incomplete_type_QMARK__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_init_count_A_class, Name: "arbace.c.check$init_count", Modifiers: 25, Simple: "init_count", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_init_count_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_init_count_per__1876000519_A_class, Name: "arbace.c.check$init_count$per__1876000519", Modifiers: 25, Simple: "per__1876000519", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_init_count_per__1876000519_A", Source: "check.ae", Declaring: &A_arbace_c_check_init_count_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_init_count_per__1876000519_fn__1876000521_A_class, Name: "arbace.c.check$init_count$per__1876000519$fn__1876000521", Modifiers: 25, Simple: "fn__1876000521", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_init_count_per__1876000519_fn__1876000521_A", Source: "check.ae", Declaring: &A_arbace_c_check_init_count_per__1876000519_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_int_bits_A_class, Name: "arbace.c.check$int_bits", Modifiers: 25, Simple: "int_bits", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_int_bits_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_int_op_A_class, Name: "arbace.c.check$int_op", Modifiers: 25, Simple: "int_op", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_int_op_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_int_type_QMARK__A_class, Name: "arbace.c.check$int_type_QMARK_", Modifiers: 25, Simple: "int_type_QMARK_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_int_type_QMARK__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_layout_BANG__A_class, Name: "arbace.c.check$layout_BANG_", Modifiers: 25, Simple: "layout_BANG_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_layout_BANG__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF5_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_layout_BANG__fn__1876000262_A_class, Name: "arbace.c.check$layout_BANG_$fn__1876000262", Modifiers: 25, Simple: "fn__1876000262", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_layout_BANG__fn__1876000262_A", Source: "check.ae", Declaring: &A_arbace_c_check_layout_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_layout_BANG__fn__1876000264_A_class, Name: "arbace.c.check$layout_BANG_$fn__1876000264", Modifiers: 25, Simple: "fn__1876000264", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_layout_BANG__fn__1876000264_A", Source: "check.ae", Declaring: &A_arbace_c_check_layout_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_layout_BANG__fn__1876000266_A_class, Name: "arbace.c.check$layout_BANG_$fn__1876000266", Modifiers: 25, Simple: "fn__1876000266", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_layout_BANG__fn__1876000266_A", Source: "check.ae", Declaring: &A_arbace_c_check_layout_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_layout_BANG__fn__1876000268_A_class, Name: "arbace.c.check$layout_BANG_$fn__1876000268", Modifiers: 25, Simple: "fn__1876000268", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_layout_BANG__fn__1876000268_A", Source: "check.ae", Declaring: &A_arbace_c_check_layout_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_layout_BANG__fn__1876000270_A_class, Name: "arbace.c.check$layout_BANG_$fn__1876000270", Modifiers: 25, Simple: "fn__1876000270", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_layout_BANG__fn__1876000270_A", Source: "check.ae", Declaring: &A_arbace_c_check_layout_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_layout_BANG__fn__1876000272_A_class, Name: "arbace.c.check$layout_BANG_$fn__1876000272", Modifiers: 25, Simple: "fn__1876000272", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_layout_BANG__fn__1876000272_A", Source: "check.ae", Declaring: &A_arbace_c_check_layout_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_ld_of_A_class, Name: "arbace.c.check$ld_of", Modifiers: 25, Simple: "ld_of", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_ld_of_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_ldouble_size_A_class, Name: "arbace.c.check$ldouble_size", Modifiers: 25, Simple: "ldouble_size", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_ldouble_size_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_let_bindings_A_class, Name: "arbace.c.check$let_bindings", Modifiers: 25, Simple: "let_bindings", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_let_bindings_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_line_of_A_class, Name: "arbace.c.check$line_of", Modifiers: 25, Simple: "line_of", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_line_of_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_linkage_of_A_class, Name: "arbace.c.check$linkage_of", Modifiers: 25, Simple: "linkage_of", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_linkage_of_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_lit_form_A_class, Name: "arbace.c.check$lit_form", Modifiers: 25, Simple: "lit_form", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_lit_form_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_lit_type_A_class, Name: "arbace.c.check$lit_type", Modifiers: 25, Simple: "lit_type", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_lit_type_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_lname_A_class, Name: "arbace.c.check$lname", Modifiers: 25, Simple: "lname", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_lname_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_lookup_A_class, Name: "arbace.c.check$lookup", Modifiers: 25, Simple: "lookup", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_lookup_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_lookup_tag_A_class, Name: "arbace.c.check$lookup_tag", Modifiers: 25, Simple: "lookup_tag", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_lookup_tag_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_mcompat_QMARK__A_class, Name: "arbace.c.check$mcompat_QMARK_", Modifiers: 25, Simple: "mcompat_QMARK_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_mcompat_QMARK__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_mcompat_QMARK__fn__1876000085_A_class, Name: "arbace.c.check$mcompat_QMARK_$fn__1876000085", Modifiers: 25, Simple: "fn__1876000085", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_mcompat_QMARK__fn__1876000085_A", Source: "check.ae", Declaring: &A_arbace_c_check_mcompat_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_member_A_class, Name: "arbace.c.check$member", Modifiers: 25, Simple: "member", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_member_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_member_fn__1876000275_A_class, Name: "arbace.c.check$member$fn__1876000275", Modifiers: 25, Simple: "fn__1876000275", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_member_fn__1876000275_A", Source: "check.ae", Declaring: &A_arbace_c_check_member_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_member_align_A_class, Name: "arbace.c.check$member_align", Modifiers: 25, Simple: "member_align", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_member_align_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_member_forms_A_class, Name: "arbace.c.check$member_forms", Modifiers: 25, Simple: "member_forms", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_member_forms_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_member_forms_fn__1876000298_A_class, Name: "arbace.c.check$member_forms$fn__1876000298", Modifiers: 25, Simple: "fn__1876000298", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_member_forms_fn__1876000298_A", Source: "check.ae", Declaring: &A_arbace_c_check_member_forms_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_member_forms_fn__1876000298_fn__1876000302_A_class, Name: "arbace.c.check$member_forms$fn__1876000298$fn__1876000302", Modifiers: 25, Simple: "fn__1876000302", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_member_forms_fn__1876000298_fn__1876000302_A", Source: "check.ae", Declaring: &A_arbace_c_check_member_forms_fn__1876000298_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_member_forms_fn__1876000298_fn__1876000304_A_class, Name: "arbace.c.check$member_forms$fn__1876000298$fn__1876000304", Modifiers: 25, Simple: "fn__1876000304", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_member_forms_fn__1876000298_fn__1876000304_A", Source: "check.ae", Declaring: &A_arbace_c_check_member_forms_fn__1876000298_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_member_forms_fn__1876000298_fn__1876000306_A_class, Name: "arbace.c.check$member_forms$fn__1876000298$fn__1876000306", Modifiers: 25, Simple: "fn__1876000306", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_member_forms_fn__1876000298_fn__1876000306_A", Source: "check.ae", Declaring: &A_arbace_c_check_member_forms_fn__1876000298_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_member_forms_fn__1876000298_fn__1876000308_A_class, Name: "arbace.c.check$member_forms$fn__1876000298$fn__1876000308", Modifiers: 25, Simple: "fn__1876000308", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_member_forms_fn__1876000298_fn__1876000308_A", Source: "check.ae", Declaring: &A_arbace_c_check_member_forms_fn__1876000298_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_member_forms_fn__1876000298_fn__1876000310_A_class, Name: "arbace.c.check$member_forms$fn__1876000298$fn__1876000310", Modifiers: 25, Simple: "fn__1876000310", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_member_forms_fn__1876000298_fn__1876000310_A", Source: "check.ae", Declaring: &A_arbace_c_check_member_forms_fn__1876000298_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_member_forms_fn__1876000298_fn__1876000313_A_class, Name: "arbace.c.check$member_forms$fn__1876000298$fn__1876000313", Modifiers: 25, Simple: "fn__1876000313", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_member_forms_fn__1876000298_fn__1876000313_A", Source: "check.ae", Declaring: &A_arbace_c_check_member_forms_fn__1876000298_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_member_of_A_class, Name: "arbace.c.check$member_of", Modifiers: 25, Simple: "member_of", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_member_of_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_nested_arrow_A_class, Name: "arbace.c.check$nested_arrow", Modifiers: 25, Simple: "nested_arrow", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_nested_arrow_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_new_cx_A_class, Name: "arbace.c.check$new_cx", Modifiers: 25, Simple: "new_cx", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_new_cx_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_new_rec_A_class, Name: "arbace.c.check$new_rec", Modifiers: 25, Simple: "new_rec", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_new_rec_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_null_const_QMARK__A_class, Name: "arbace.c.check$null_const_QMARK_", Modifiers: 25, Simple: "null_const_QMARK_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_null_const_QMARK__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_null_const_npc_QMARK__A_class, Name: "arbace.c.check$null_const_npc_QMARK_", Modifiers: 25, Simple: "null_const_npc_QMARK_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_null_const_npc_QMARK__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_num_val_A_class, Name: "arbace.c.check$num_val", Modifiers: 25, Simple: "num_val", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_num_val_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_params_of_A_class, Name: "arbace.c.check$params_of", Modifiers: 25, Simple: "params_of", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_params_of_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_params_of_adj__1876000676_A_class, Name: "arbace.c.check$params_of$adj__1876000676", Modifiers: 25, Simple: "adj__1876000676", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_params_of_adj__1876000676_A", Source: "check.ae", Declaring: &A_arbace_c_check_params_of_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_params_of_fn__1876000673_A_class, Name: "arbace.c.check$params_of$fn__1876000673", Modifiers: 25, Simple: "fn__1876000673", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_params_of_fn__1876000673_A", Source: "check.ae", Declaring: &A_arbace_c_check_params_of_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_parse_type_A_class, Name: "arbace.c.check$parse_type", Modifiers: 25, Simple: "parse_type", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_parse_type_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_parse_type_fn__1876000288_A_class, Name: "arbace.c.check$parse_type$fn__1876000288", Modifiers: 25, Simple: "fn__1876000288", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_parse_type_fn__1876000288_A", Source: "check.ae", Declaring: &A_arbace_c_check_parse_type_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_parse_type_fn__1876000288_fn__1876000289_A_class, Name: "arbace.c.check$parse_type$fn__1876000288$fn__1876000289", Modifiers: 25, Simple: "fn__1876000289", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_parse_type_fn__1876000288_fn__1876000289_A", Source: "check.ae", Declaring: &A_arbace_c_check_parse_type_fn__1876000288_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_pedwarn_BANG__A_class, Name: "arbace.c.check$pedwarn_BANG_", Modifiers: 25, Simple: "pedwarn_BANG_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_pedwarn_BANG__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_pedwarn_c2y_BANG__A_class, Name: "arbace.c.check$pedwarn_c2y_BANG_", Modifiers: 25, Simple: "pedwarn_c2y_BANG_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_pedwarn_c2y_BANG__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_pop_scope_BANG__A_class, Name: "arbace.c.check$pop_scope_BANG_", Modifiers: 25, Simple: "pop_scope_BANG_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_pop_scope_BANG__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_pragma_pack_BANG__A_class, Name: "arbace.c.check$pragma_pack_BANG_", Modifiers: 25, Simple: "pragma_pack_BANG_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_pragma_pack_BANG__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_pragma_pack_BANG__fn__1876000823_A_class, Name: "arbace.c.check$pragma_pack_BANG_$fn__1876000823", Modifiers: 25, Simple: "fn__1876000823", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_pragma_pack_BANG__fn__1876000823_A", Source: "check.ae", Declaring: &A_arbace_c_check_pragma_pack_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_pragma_pack_BANG__fn__1876000825_A_class, Name: "arbace.c.check$pragma_pack_BANG_$fn__1876000825", Modifiers: 25, Simple: "fn__1876000825", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_pragma_pack_BANG__fn__1876000825_A", Source: "check.ae", Declaring: &A_arbace_c_check_pragma_pack_BANG__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_promote_A_class, Name: "arbace.c.check$promote", Modifiers: 25, Simple: "promote", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_promote_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_ptr_A_class, Name: "arbace.c.check$ptr", Modifiers: 25, Simple: "ptr", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_ptr_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_ptr_conv_BANG__A_class, Name: "arbace.c.check$ptr_conv_BANG_", Modifiers: 25, Simple: "ptr_conv_BANG_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_ptr_conv_BANG__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_ptr_type_QMARK__A_class, Name: "arbace.c.check$ptr_type_QMARK_", Modifiers: 25, Simple: "ptr_type_QMARK_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_ptr_type_QMARK__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_push_scope_BANG__A_class, Name: "arbace.c.check$push_scope_BANG_", Modifiers: 25, Simple: "push_scope_BANG_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_push_scope_BANG__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_qual_A_class, Name: "arbace.c.check$qual", Modifiers: 25, Simple: "qual", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_qual_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_quals_A_class, Name: "arbace.c.check$quals", Modifiers: 25, Simple: "quals", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_quals_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_rank_A_class, Name: "arbace.c.check$rank", Modifiers: 25, Simple: "rank", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_rank_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_rec_of_A_class, Name: "arbace.c.check$rec_of", Modifiers: 25, Simple: "rec_of", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_rec_of_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_rec_same_QMARK__A_class, Name: "arbace.c.check$rec_same_QMARK_", Modifiers: 25, Simple: "rec_same_QMARK_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_rec_same_QMARK__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_rec_same_QMARK__fn__1876000331_A_class, Name: "arbace.c.check$rec_same_QMARK_$fn__1876000331", Modifiers: 25, Simple: "fn__1876000331", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_rec_same_QMARK__fn__1876000331_A", Source: "check.ae", Declaring: &A_arbace_c_check_rec_same_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_rec_same_QMARK__fn__1876000333_A_class, Name: "arbace.c.check$rec_same_QMARK_$fn__1876000333", Modifiers: 25, Simple: "fn__1876000333", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_rec_same_QMARK__fn__1876000333_A", Source: "check.ae", Declaring: &A_arbace_c_check_rec_same_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_rec_same_QMARK__fn__1876000335_A_class, Name: "arbace.c.check$rec_same_QMARK_$fn__1876000335", Modifiers: 25, Simple: "fn__1876000335", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_rec_same_QMARK__fn__1876000335_A", Source: "check.ae", Declaring: &A_arbace_c_check_rec_same_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_record_BANG__A_class, Name: "arbace.c.check$record_BANG_", Modifiers: 25, Simple: "record_BANG_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_record_BANG__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_record_type_QMARK__A_class, Name: "arbace.c.check$record_type_QMARK_", Modifiers: 25, Simple: "record_type_QMARK_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_record_type_QMARK__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_res_A_class, Name: "arbace.c.check$res", Modifiers: 25, Simple: "res", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_res_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_round_big_A_class, Name: "arbace.c.check$round_big", Modifiers: 25, Simple: "round_big", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_round_big_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_round_dec_A_class, Name: "arbace.c.check$round_dec", Modifiers: 25, Simple: "round_dec", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_round_dec_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_round_exact_A_class, Name: "arbace.c.check$round_exact", Modifiers: 25, Simple: "round_exact", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_round_exact_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_round_exact_fn__1876000410_A_class, Name: "arbace.c.check$round_exact$fn__1876000410", Modifiers: 25, Simple: "fn__1876000410", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_round_exact_fn__1876000410_A", Source: "check.ae", Declaring: &A_arbace_c_check_round_exact_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_round_exact_two__1876000408_A_class, Name: "arbace.c.check$round_exact$two__1876000408", Modifiers: 25, Simple: "two__1876000408", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_round_exact_two__1876000408_A", Source: "check.ae", Declaring: &A_arbace_c_check_round_exact_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_round_ldouble_A_class, Name: "arbace.c.check$round_ldouble", Modifiers: 25, Simple: "round_ldouble", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_round_ldouble_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_round_sig_A_class, Name: "arbace.c.check$round_sig", Modifiers: 25, Simple: "round_sig", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_round_sig_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_round_to_format_A_class, Name: "arbace.c.check$round_to_format", Modifiers: 25, Simple: "round_to_format", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_round_to_format_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_scalar_type_QMARK__A_class, Name: "arbace.c.check$scalar_type_QMARK_", Modifiers: 25, Simple: "scalar_type_QMARK_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_scalar_type_QMARK__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_size_of_A_class, Name: "arbace.c.check$size_of", Modifiers: 25, Simple: "size_of", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_size_of_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_sizeof_res_A_class, Name: "arbace.c.check$sizeof_res", Modifiers: 25, Simple: "sizeof_res", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_sizeof_res_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_spec_attrs_packed_A_class, Name: "arbace.c.check$spec_attrs_packed", Modifiers: 25, Simple: "spec_attrs_packed", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_spec_attrs_packed_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_spec_attrs_packed_fn__1876000280_A_class, Name: "arbace.c.check$spec_attrs_packed$fn__1876000280", Modifiers: 25, Simple: "fn__1876000280", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_spec_attrs_packed_fn__1876000280_A", Source: "check.ae", Declaring: &A_arbace_c_check_spec_attrs_packed_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_std_attr_check_BANG__A_class, Name: "arbace.c.check$std_attr_check_BANG_", Modifiers: 25, Simple: "std_attr_check_BANG_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_std_attr_check_BANG__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_std_attr_misc_BANG__A_class, Name: "arbace.c.check$std_attr_misc_BANG_", Modifiers: 25, Simple: "std_attr_misc_BANG_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_std_attr_misc_BANG__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_std_names_A_class, Name: "arbace.c.check$std_names", Modifiers: 25, Simple: "std_names", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_std_names_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_std_names_iter__1876000157__1876000161_A_class, Name: "arbace.c.check$std_names$iter__1876000157__1876000161", Modifiers: 25, Simple: "iter__1876000157__1876000161", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_std_names_iter__1876000157__1876000161_A", Source: "check.ae", Declaring: &A_arbace_c_check_std_names_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_std_names_iter__1876000157__1876000161_fn__1876000162_A_class, Name: "arbace.c.check$std_names$iter__1876000157__1876000161$fn__1876000162", Modifiers: 25, Simple: "fn__1876000162", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_std_names_iter__1876000157__1876000161_fn__1876000162_A", Source: "check.ae", Declaring: &A_arbace_c_check_std_names_iter__1876000157__1876000161_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_std_names_iter__1876000157__1876000161_fn__1876000162_fn__1876000163_A_class, Name: "arbace.c.check$std_names$iter__1876000157__1876000161$fn__1876000162$fn__1876000163", Modifiers: 25, Simple: "fn__1876000163", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_std_names_iter__1876000157__1876000161_fn__1876000162_fn__1876000163_A", Source: "check.ae", Declaring: &A_arbace_c_check_std_names_iter__1876000157__1876000161_fn__1876000162_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_std_num_A_class, Name: "arbace.c.check$std_num", Modifiers: 25, Simple: "std_num", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_std_num_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_stmt_attrs_BANG__A_class, Name: "arbace.c.check$stmt_attrs_BANG_", Modifiers: 25, Simple: "stmt_attrs_BANG_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_stmt_attrs_BANG__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_storage_A_class, Name: "arbace.c.check$storage", Modifiers: 25, Simple: "storage", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_storage_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_string_bytes_A_class, Name: "arbace.c.check$string_bytes", Modifiers: 25, Simple: "string_bytes", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_string_bytes_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_string_bytes_bs__1876000632_A_class, Name: "arbace.c.check$string_bytes$bs__1876000632", Modifiers: 25, Simple: "bs__1876000632", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_string_bytes_bs__1876000632_A", Source: "check.ae", Declaring: &A_arbace_c_check_string_bytes_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_string_bytes_bs__1876000632_fn__1876000633_A_class, Name: "arbace.c.check$string_bytes$bs__1876000632$fn__1876000633", Modifiers: 25, Simple: "fn__1876000633", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_string_bytes_bs__1876000632_fn__1876000633_A", Source: "check.ae", Declaring: &A_arbace_c_check_string_bytes_bs__1876000632_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_string_bytes_bs__1876000632_fn__1876000633_fn__1876000634_A_class, Name: "arbace.c.check$string_bytes$bs__1876000632$fn__1876000633$fn__1876000634", Modifiers: 25, Simple: "fn__1876000634", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_string_bytes_bs__1876000632_fn__1876000633_fn__1876000634_A", Source: "check.ae", Declaring: &A_arbace_c_check_string_bytes_bs__1876000632_fn__1876000633_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_sys_at_A_class, Name: "arbace.c.check$sys_at", Modifiers: 25, Simple: "sys_at", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_sys_at_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_sys_at_fn__1876000829_A_class, Name: "arbace.c.check$sys_at$fn__1876000829", Modifiers: 25, Simple: "fn__1876000829", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_sys_at_fn__1876000829_A", Source: "check.ae", Declaring: &A_arbace_c_check_sys_at_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_tag_attrs_BANG__A_class, Name: "arbace.c.check$tag_attrs_BANG_", Modifiers: 25, Simple: "tag_attrs_BANG_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_tag_attrs_BANG__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_tag_ref_A_class, Name: "arbace.c.check$tag_ref", Modifiers: 25, Simple: "tag_ref", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_tag_ref_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_top_scope_A_class, Name: "arbace.c.check$top_scope", Modifiers: 25, Simple: "top_scope", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_top_scope_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_tstr_A_class, Name: "arbace.c.check$tstr", Modifiers: 25, Simple: "tstr", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_tstr_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_tstr_w__1876000070_A_class, Name: "arbace.c.check$tstr$w__1876000070", Modifiers: 25, Simple: "w__1876000070", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_tstr_w__1876000070_A", Source: "check.ae", Declaring: &A_arbace_c_check_tstr_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_type_eq_A_class, Name: "arbace.c.check$type_eq", Modifiers: 25, Simple: "type_eq", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_type_eq_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_type_pos_attrs_BANG__A_class, Name: "arbace.c.check$type_pos_attrs_BANG_", Modifiers: 25, Simple: "type_pos_attrs_BANG_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_type_pos_attrs_BANG__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_unq_A_class, Name: "arbace.c.check$unq", Modifiers: 25, Simple: "unq", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_unq_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_unq_STAR__A_class, Name: "arbace.c.check$unq_STAR_", Modifiers: 25, Simple: "unq_STAR_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_unq_STAR__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_unq_elem_A_class, Name: "arbace.c.check$unq_elem", Modifiers: 25, Simple: "unq_elem", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_unq_elem_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_unsigned_of_A_class, Name: "arbace.c.check$unsigned_of", Modifiers: 25, Simple: "unsigned_of", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_unsigned_of_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_usual_A_class, Name: "arbace.c.check$usual", Modifiers: 25, Simple: "usual", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_usual_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_vectorize_A_class, Name: "arbace.c.check$vectorize", Modifiers: 25, Simple: "vectorize", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_vectorize_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_vectorize_fn__1876000230_A_class, Name: "arbace.c.check$vectorize$fn__1876000230", Modifiers: 25, Simple: "fn__1876000230", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_vectorize_fn__1876000230_A", Source: "check.ae", Declaring: &A_arbace_c_check_vectorize_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_vectorize_fn__1876000239_A_class, Name: "arbace.c.check$vectorize$fn__1876000239", Modifiers: 25, Simple: "fn__1876000239", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_vectorize_fn__1876000239_A", Source: "check.ae", Declaring: &A_arbace_c_check_vectorize_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_vla_QMARK__A_class, Name: "arbace.c.check$vla_QMARK_", Modifiers: 25, Simple: "vla_QMARK_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_vla_QMARK__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_vla_struct_QMARK__A_class, Name: "arbace.c.check$vla_struct_QMARK_", Modifiers: 25, Simple: "vla_struct_QMARK_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_vla_struct_QMARK__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_vla_struct_QMARK__fn__1876000326_A_class, Name: "arbace.c.check$vla_struct_QMARK_$fn__1876000326", Modifiers: 25, Simple: "fn__1876000326", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_vla_struct_QMARK__fn__1876000326_A", Source: "check.ae", Declaring: &A_arbace_c_check_vla_struct_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_vm_type_QMARK__A_class, Name: "arbace.c.check$vm_type_QMARK_", Modifiers: 25, Simple: "vm_type_QMARK_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_vm_type_QMARK__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_vm_type_QMARK__fn__1876000321_A_class, Name: "arbace.c.check$vm_type_QMARK_$fn__1876000321", Modifiers: 25, Simple: "fn__1876000321", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_vm_type_QMARK__fn__1876000321_A", Source: "check.ae", Declaring: &A_arbace_c_check_vm_type_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_vm_type_QMARK__fn__1876000323_A_class, Name: "arbace.c.check$vm_type_QMARK_$fn__1876000323", Modifiers: 25, Simple: "fn__1876000323", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_vm_type_QMARK__fn__1876000323_A", Source: "check.ae", Declaring: &A_arbace_c_check_vm_type_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_void_type_QMARK__A_class, Name: "arbace.c.check$void_type_QMARK_", Modifiers: 25, Simple: "void_type_QMARK_", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_void_type_QMARK__A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_with_scope_A_class, Name: "arbace.c.check$with_scope", Modifiers: 25, Simple: "with_scope", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_with_scope_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}, jrt.CodeDecl{Out: &A_arbace_c_check_wrap_A_class, Name: "arbace.c.check$wrap", Modifiers: 25, Simple: "wrap", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_wrap_A", Source: "check.ae", Declaring: &A_arbace_c_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_c_check_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c_check_A_New()}; return nil }

var A_arbace_c_check_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c_check_A_new}

var A_arbace_c_check_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c.check", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_c_check.A_arbace_c_check_A"})

func init() { i := A_arbace_c_check_A_class.Info(); i.IsInstance = A_arbace_c_check_A_InstanceOf; i.Init = A_arbace_c_check_A_Init; i.Table = A_arbace_c_check_A_members }

var A_arbace_c_check_align_of_A_class *jrt.Class

var A_arbace_c_check_align_of_STAR__A_class *jrt.Class

var A_arbace_c_check_align_up_A_class *jrt.Class

var A_arbace_c_check_aligned_value_A_class *jrt.Class

var A_arbace_c_check_ann_BANG__A_class *jrt.Class

var A_arbace_c_check_arith_result_A_class *jrt.Class

var A_arbace_c_check_arith_type_QMARK__A_class *jrt.Class

var A_arbace_c_check_arr_A_class *jrt.Class

var A_arbace_c_check_asm_operands_BANG__A_class *jrt.Class

var A_arbace_c_check_assign_check_A_class *jrt.Class

var A_arbace_c_check_assoc_in_mode_A_class *jrt.Class

var A_arbace_c_check_at_line_A_class *jrt.Class

var A_arbace_c_check_attr_args_BANG__A_class *jrt.Class

var A_arbace_c_check_attr_decl_check_BANG__A_class *jrt.Class

var A_arbace_c_check_attr_items_A_class *jrt.Class

var A_arbace_c_check_attr_items_fn__1876000139_A_class *jrt.Class

var A_arbace_c_check_attrs_of_A_class *jrt.Class

var A_arbace_c_check_attrs_of_fn__1876000143_A_class *jrt.Class

var A_arbace_c_check_auto_type_QMARK__A_class *jrt.Class

var A_arbace_c_check_base_fn_type_QMARK__A_class *jrt.Class

var A_arbace_c_check_base_fn_type_QMARK__fn__1876000196_A_class *jrt.Class

var A_arbace_c_check_big_QMARK__A_class *jrt.Class

var A_arbace_c_check_binary_A_class *jrt.Class

var A_arbace_c_check_binary_ex__1876000448_A_class *jrt.Class

var A_arbace_c_check_binary_index_type_A_class *jrt.Class

var A_arbace_c_check_bit_field_QMARK__A_class *jrt.Class

var A_arbace_c_check_bitint_size_A_class *jrt.Class

var A_arbace_c_check_bitint_width_A_class *jrt.Class

var A_arbace_c_check_byte_string_len_A_class *jrt.Class

var A_arbace_c_check_byte_string_len_fn__1876000428_A_class *jrt.Class

var A_arbace_c_check_c23_QMARK__A_class *jrt.Class

var A_arbace_c_check_c99_QMARK__A_class *jrt.Class

var A_arbace_c_check_call_A_class *jrt.Class

var A_arbace_c_check_call_builtin_A_class *jrt.Class

var A_arbace_c_check_callee_fn_A_class *jrt.Class

var A_arbace_c_check_char_signed_QMARK__A_class *jrt.Class

var A_arbace_c_check_check_block_items_A_class *jrt.Class

var A_arbace_c_check_check_block_items_fn__1876000773_A_class *jrt.Class

var A_arbace_c_check_check_block_items_fn__1876000778_A_class *jrt.Class

var A_arbace_c_check_check_decl_A_class *jrt.Class

var A_arbace_c_check_check_declare_A_class *jrt.Class

var A_arbace_c_check_check_defn_A_class *jrt.Class

var A_arbace_c_check_check_defn_fn__1876000694_A_class *jrt.Class

var A_arbace_c_check_check_defn_fn__1876000706_A_class *jrt.Class

var A_arbace_c_check_check_defn_fn__1876000711_A_class *jrt.Class

var A_arbace_c_check_check_enum_A_class *jrt.Class

var A_arbace_c_check_check_enum_fn__1876000384_A_class *jrt.Class

var A_arbace_c_check_check_enum_fn__1876000389_A_class *jrt.Class

var A_arbace_c_check_check_enum_fn__1876000391_A_class *jrt.Class

var A_arbace_c_check_check_enum_fn__1876000393_A_class *jrt.Class

var A_arbace_c_check_check_forms_A_class *jrt.Class

var A_arbace_c_check_check_init_A_class *jrt.Class

var A_arbace_c_check_check_stmt_A_class *jrt.Class

var A_arbace_c_check_check_stmt_fn__1876000783_A_class *jrt.Class

var A_arbace_c_check_check_stmt_fn__1876000785_A_class *jrt.Class

var A_arbace_c_check_check_stmt_fn__1876000790_A_class *jrt.Class

var A_arbace_c_check_check_stmt_fn__1876000795_A_class *jrt.Class

var A_arbace_c_check_check_stmt_fn__1876000797_A_class *jrt.Class

var A_arbace_c_check_check_stmt_fn__1876000802_A_class *jrt.Class

var A_arbace_c_check_check_stmt_fn__1876000804_A_class *jrt.Class

var A_arbace_c_check_check_stmt_fn__1876000806_A_class *jrt.Class

var A_arbace_c_check_check_stmt_fn__1876000816_A_class *jrt.Class

var A_arbace_c_check_check_stmt_iv__1876000813_A_class *jrt.Class

var A_arbace_c_check_check_struct_A_class *jrt.Class

var A_arbace_c_check_check_struct_fn__1876000342_A_class *jrt.Class

var A_arbace_c_check_check_struct_fn__1876000344_A_class *jrt.Class

var A_arbace_c_check_check_struct_fn__1876000346_A_class *jrt.Class

var A_arbace_c_check_check_struct_fn__1876000348_A_class *jrt.Class

var A_arbace_c_check_check_top_A_class *jrt.Class

var A_arbace_c_check_check_top_fn__1876000844_A_class *jrt.Class

var A_arbace_c_check_check_top_fn__1876000854_A_class *jrt.Class

var A_arbace_c_check_check_top_fn__1876000856_A_class *jrt.Class

var A_arbace_c_check_check_top_fn__1876000875_A_class *jrt.Class

var A_arbace_c_check_check_top_fn__1876000880_A_class *jrt.Class

var A_arbace_c_check_check_top_info_of__1876000858_A_class *jrt.Class

var A_arbace_c_check_check_top_info_of__1876000858_fn__1876000859_A_class *jrt.Class

var A_arbace_c_check_check_top_no_pragma__1876000864_A_class *jrt.Class

var A_arbace_c_check_check_top_no_pragma__1876000864_fn__1876000865_A_class *jrt.Class

var A_arbace_c_check_check_top_norm__1876000852_A_class *jrt.Class

var A_arbace_c_check_check_top_read_info__1876000846_A_class *jrt.Class

var A_arbace_c_check_check_top_read_info__1876000846_fn__1876000847_A_class *jrt.Class

var A_arbace_c_check_check_top_read_info__1876000846_fn__1876000849_A_class *jrt.Class

var A_arbace_c_check_check_top_sys_of__1876000862_A_class *jrt.Class

var A_arbace_c_check_check_typedef_A_class *jrt.Class

var A_arbace_c_check_check_typedef_fn__1876000722_A_class *jrt.Class

var A_arbace_c_check_check_unit_A_class *jrt.Class

var A_arbace_c_check_check_unit_fn__1876000903_A_class *jrt.Class

var A_arbace_c_check_check_unit_fn__1876000903_fn__1876000908_A_class *jrt.Class

var A_arbace_c_check_check_unit_fn__1876000903_fn__1876000910_A_class *jrt.Class

var A_arbace_c_check_check_unit_fn__1876000917_A_class *jrt.Class

var A_arbace_c_check_check_unit_fn__1876000919_A_class *jrt.Class

var A_arbace_c_check_check_unit_iter__1876000887__1876000891_A_class *jrt.Class

var A_arbace_c_check_check_unit_iter__1876000887__1876000891_fn__1876000892_A_class *jrt.Class

var A_arbace_c_check_check_unit_iter__1876000887__1876000891_fn__1876000892_fn__1876000893_A_class *jrt.Class

var A_arbace_c_check_check_var_A_class *jrt.Class

var A_arbace_c_check_check_var_fn__1876000668_A_class *jrt.Class

var A_arbace_c_check_check_var_fn__1876000670_A_class *jrt.Class

var A_arbace_c_check_cmp_val_A_class *jrt.Class

var A_arbace_c_check_code_unit_count_A_class *jrt.Class

var A_arbace_c_check_code_unit_count_fn__1876000433_A_class *jrt.Class

var A_arbace_c_check_compatible_QMARK__A_class *jrt.Class

var A_arbace_c_check_compatible_QMARK__fn__1876000091_A_class *jrt.Class

var A_arbace_c_check_compatible_QMARK__fn__1876000093_A_class *jrt.Class

var A_arbace_c_check_compatible_QMARK__fn__1876000095_A_class *jrt.Class

var A_arbace_c_check_compatible_QMARK__fn__1876000097_A_class *jrt.Class

var A_arbace_c_check_compatible_ptr_targets_QMARK__A_class *jrt.Class

var A_arbace_c_check_complete_array_A_class *jrt.Class

var A_arbace_c_check_complex_type_QMARK__A_class *jrt.Class

var A_arbace_c_check_composite_A_class *jrt.Class

var A_arbace_c_check_cond_expr_A_class *jrt.Class

var A_arbace_c_check_cond_type_A_class *jrt.Class

var A_arbace_c_check_const_int_A_class *jrt.Class

var A_arbace_c_check_const_int_fn__1876000615_A_class *jrt.Class

var A_arbace_c_check_constexpr_check_BANG__A_class *jrt.Class

var A_arbace_c_check_constexpr_check_BANG__fn__1876000653_A_class *jrt.Class

var A_arbace_c_check_constexpr_check_BANG__fn__1876000662_A_class *jrt.Class

var A_arbace_c_check_constexpr_float_bad_A_class *jrt.Class

var A_arbace_c_check_conv_val_A_class *jrt.Class

var A_arbace_c_check_cx_A_class *jrt.Class

var A_arbace_c_check_dec_fits_QMARK__A_class *jrt.Class

var A_arbace_c_check_decay_A_class *jrt.Class

var A_arbace_c_check_decl_form_QMARK__A_class *jrt.Class

var A_arbace_c_check_decl_position_attrs_BANG__A_class *jrt.Class

var A_arbace_c_check_declare_BANG__A_class *jrt.Class

var A_arbace_c_check_declare_object_BANG__A_class *jrt.Class

var A_arbace_c_check_declare_object_BANG__fn__1876000626_A_class *jrt.Class

var A_arbace_c_check_declare_object_BANG__tyof_QMARK___1876000624_A_class *jrt.Class

var A_arbace_c_check_deref_type_A_class *jrt.Class

var A_arbace_c_check_emit_BANG__A_class *jrt.Class

var A_arbace_c_check_enum_type_of_A_class *jrt.Class

var A_arbace_c_check_enum_type_of_fits__1876000356_A_class *jrt.Class

var A_arbace_c_check_enum_type_of_fits__1876000356_fn__1876000357_A_class *jrt.Class

var A_arbace_c_check_enum_under_A_class *jrt.Class

var A_arbace_c_check_err_BANG__A_class *jrt.Class

func A_arbace_c_check_eval1876000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c_check_eval1876000004_A_New()}; return nil }

var A_arbace_c_check_eval1876000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c_check_eval1876000004_A_new}

var A_arbace_c_check_eval1876000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c.check$eval1876000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_c_check_A_class, Simple: "eval1876000004", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_eval1876000004_A"})

func init() { i := A_arbace_c_check_eval1876000004_A_class.Info(); i.IsInstance = A_arbace_c_check_eval1876000004_A_InstanceOf; i.Table = A_arbace_c_check_eval1876000004_A_members }

var A_arbace_c_check_eval1876000004_loading__1927001464__auto____1876000005_A_class *jrt.Class

func A_arbace_c_check_eval1876000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c_check_eval1876000008_A_New()}; return nil }

var A_arbace_c_check_eval1876000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c_check_eval1876000008_A_new}

var A_arbace_c_check_eval1876000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c.check$eval1876000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_c_check_A_class, Simple: "eval1876000008", Go: "arbace/aot_arbace_c_check.A_arbace_c_check_eval1876000008_A"})

func init() { i := A_arbace_c_check_eval1876000008_A_class.Info(); i.IsInstance = A_arbace_c_check_eval1876000008_A_InstanceOf; i.Table = A_arbace_c_check_eval1876000008_A_members }

var A_arbace_c_check_eval1876000008_fn__1876000009_A_class *jrt.Class

var A_arbace_c_check_eval_type_A_class *jrt.Class

var A_arbace_c_check_ex_A_class *jrt.Class

var A_arbace_c_check_ex_STAR__A_class *jrt.Class

var A_arbace_c_check_ex_STAR__fn__1876000576_A_class *jrt.Class

var A_arbace_c_check_ex_STAR__fn__1876000592_A_class *jrt.Class

var A_arbace_c_check_ex_STAR__fn__1876000611_A_class *jrt.Class

var A_arbace_c_check_exi_A_class *jrt.Class

var A_arbace_c_check_feat_BANG__A_class *jrt.Class

var A_arbace_c_check_file_declare_BANG__A_class *jrt.Class

var A_arbace_c_check_file_scope_QMARK__A_class *jrt.Class

var A_arbace_c_check_fits_binary_QMARK__A_class *jrt.Class

var A_arbace_c_check_float_of_A_class *jrt.Class

var A_arbace_c_check_float_of_exact_A_class *jrt.Class

var A_arbace_c_check_float_op_A_class *jrt.Class

var A_arbace_c_check_float_tie_A_class *jrt.Class

var A_arbace_c_check_float_type_QMARK__A_class *jrt.Class

var A_arbace_c_check_fn__1876000014_A_class *jrt.Class

var A_arbace_c_check_generic_select_A_class *jrt.Class

var A_arbace_c_check_generic_select_iter__1876000501__1876000505_A_class *jrt.Class

var A_arbace_c_check_generic_select_iter__1876000501__1876000505_fn__1876000506_A_class *jrt.Class

var A_arbace_c_check_generic_select_iter__1876000501__1876000505_fn__1876000506_fn__1876000507_A_class *jrt.Class

var A_arbace_c_check_head_name_A_class *jrt.Class

var A_arbace_c_check_ident_A_class *jrt.Class

var A_arbace_c_check_ident_expr_A_class *jrt.Class

var A_arbace_c_check_ignored_BANG__A_class *jrt.Class

var A_arbace_c_check_implicit_fn_BANG__A_class *jrt.Class

var A_arbace_c_check_incomplete_type_QMARK__A_class *jrt.Class

var A_arbace_c_check_init_count_A_class *jrt.Class

var A_arbace_c_check_init_count_per__1876000519_A_class *jrt.Class

var A_arbace_c_check_init_count_per__1876000519_fn__1876000521_A_class *jrt.Class

var A_arbace_c_check_int_bits_A_class *jrt.Class

var A_arbace_c_check_int_op_A_class *jrt.Class

var A_arbace_c_check_int_type_QMARK__A_class *jrt.Class

var A_arbace_c_check_layout_BANG__A_class *jrt.Class

var A_arbace_c_check_layout_BANG__fn__1876000262_A_class *jrt.Class

var A_arbace_c_check_layout_BANG__fn__1876000264_A_class *jrt.Class

var A_arbace_c_check_layout_BANG__fn__1876000266_A_class *jrt.Class

var A_arbace_c_check_layout_BANG__fn__1876000268_A_class *jrt.Class

var A_arbace_c_check_layout_BANG__fn__1876000270_A_class *jrt.Class

var A_arbace_c_check_layout_BANG__fn__1876000272_A_class *jrt.Class

var A_arbace_c_check_ld_of_A_class *jrt.Class

var A_arbace_c_check_ldouble_size_A_class *jrt.Class

var A_arbace_c_check_let_bindings_A_class *jrt.Class

var A_arbace_c_check_line_of_A_class *jrt.Class

var A_arbace_c_check_linkage_of_A_class *jrt.Class

var A_arbace_c_check_lit_form_A_class *jrt.Class

var A_arbace_c_check_lit_type_A_class *jrt.Class

var A_arbace_c_check_lname_A_class *jrt.Class

var A_arbace_c_check_lookup_A_class *jrt.Class

var A_arbace_c_check_lookup_tag_A_class *jrt.Class

var A_arbace_c_check_mcompat_QMARK__A_class *jrt.Class

var A_arbace_c_check_mcompat_QMARK__fn__1876000085_A_class *jrt.Class

var A_arbace_c_check_member_A_class *jrt.Class

var A_arbace_c_check_member_fn__1876000275_A_class *jrt.Class

var A_arbace_c_check_member_align_A_class *jrt.Class

var A_arbace_c_check_member_forms_A_class *jrt.Class

var A_arbace_c_check_member_forms_fn__1876000298_A_class *jrt.Class

var A_arbace_c_check_member_forms_fn__1876000298_fn__1876000302_A_class *jrt.Class

var A_arbace_c_check_member_forms_fn__1876000298_fn__1876000304_A_class *jrt.Class

var A_arbace_c_check_member_forms_fn__1876000298_fn__1876000306_A_class *jrt.Class

var A_arbace_c_check_member_forms_fn__1876000298_fn__1876000308_A_class *jrt.Class

var A_arbace_c_check_member_forms_fn__1876000298_fn__1876000310_A_class *jrt.Class

var A_arbace_c_check_member_forms_fn__1876000298_fn__1876000313_A_class *jrt.Class

var A_arbace_c_check_member_of_A_class *jrt.Class

var A_arbace_c_check_nested_arrow_A_class *jrt.Class

var A_arbace_c_check_new_cx_A_class *jrt.Class

var A_arbace_c_check_new_rec_A_class *jrt.Class

var A_arbace_c_check_null_const_QMARK__A_class *jrt.Class

var A_arbace_c_check_null_const_npc_QMARK__A_class *jrt.Class

var A_arbace_c_check_num_val_A_class *jrt.Class

var A_arbace_c_check_params_of_A_class *jrt.Class

var A_arbace_c_check_params_of_adj__1876000676_A_class *jrt.Class

var A_arbace_c_check_params_of_fn__1876000673_A_class *jrt.Class

var A_arbace_c_check_parse_type_A_class *jrt.Class

var A_arbace_c_check_parse_type_fn__1876000288_A_class *jrt.Class

var A_arbace_c_check_parse_type_fn__1876000288_fn__1876000289_A_class *jrt.Class

var A_arbace_c_check_pedwarn_BANG__A_class *jrt.Class

var A_arbace_c_check_pedwarn_c2y_BANG__A_class *jrt.Class

var A_arbace_c_check_pop_scope_BANG__A_class *jrt.Class

var A_arbace_c_check_pragma_pack_BANG__A_class *jrt.Class

var A_arbace_c_check_pragma_pack_BANG__fn__1876000823_A_class *jrt.Class

var A_arbace_c_check_pragma_pack_BANG__fn__1876000825_A_class *jrt.Class

var A_arbace_c_check_promote_A_class *jrt.Class

var A_arbace_c_check_ptr_A_class *jrt.Class

var A_arbace_c_check_ptr_conv_BANG__A_class *jrt.Class

var A_arbace_c_check_ptr_type_QMARK__A_class *jrt.Class

var A_arbace_c_check_push_scope_BANG__A_class *jrt.Class

var A_arbace_c_check_qual_A_class *jrt.Class

var A_arbace_c_check_quals_A_class *jrt.Class

var A_arbace_c_check_rank_A_class *jrt.Class

var A_arbace_c_check_rec_of_A_class *jrt.Class

var A_arbace_c_check_rec_same_QMARK__A_class *jrt.Class

var A_arbace_c_check_rec_same_QMARK__fn__1876000331_A_class *jrt.Class

var A_arbace_c_check_rec_same_QMARK__fn__1876000333_A_class *jrt.Class

var A_arbace_c_check_rec_same_QMARK__fn__1876000335_A_class *jrt.Class

var A_arbace_c_check_record_BANG__A_class *jrt.Class

var A_arbace_c_check_record_type_QMARK__A_class *jrt.Class

var A_arbace_c_check_res_A_class *jrt.Class

var A_arbace_c_check_round_big_A_class *jrt.Class

var A_arbace_c_check_round_dec_A_class *jrt.Class

var A_arbace_c_check_round_exact_A_class *jrt.Class

var A_arbace_c_check_round_exact_fn__1876000410_A_class *jrt.Class

var A_arbace_c_check_round_exact_two__1876000408_A_class *jrt.Class

var A_arbace_c_check_round_ldouble_A_class *jrt.Class

var A_arbace_c_check_round_sig_A_class *jrt.Class

var A_arbace_c_check_round_to_format_A_class *jrt.Class

var A_arbace_c_check_scalar_type_QMARK__A_class *jrt.Class

var A_arbace_c_check_size_of_A_class *jrt.Class

var A_arbace_c_check_sizeof_res_A_class *jrt.Class

var A_arbace_c_check_spec_attrs_packed_A_class *jrt.Class

var A_arbace_c_check_spec_attrs_packed_fn__1876000280_A_class *jrt.Class

var A_arbace_c_check_std_attr_check_BANG__A_class *jrt.Class

var A_arbace_c_check_std_attr_misc_BANG__A_class *jrt.Class

var A_arbace_c_check_std_names_A_class *jrt.Class

var A_arbace_c_check_std_names_iter__1876000157__1876000161_A_class *jrt.Class

var A_arbace_c_check_std_names_iter__1876000157__1876000161_fn__1876000162_A_class *jrt.Class

var A_arbace_c_check_std_names_iter__1876000157__1876000161_fn__1876000162_fn__1876000163_A_class *jrt.Class

var A_arbace_c_check_std_num_A_class *jrt.Class

var A_arbace_c_check_stmt_attrs_BANG__A_class *jrt.Class

var A_arbace_c_check_storage_A_class *jrt.Class

var A_arbace_c_check_string_bytes_A_class *jrt.Class

var A_arbace_c_check_string_bytes_bs__1876000632_A_class *jrt.Class

var A_arbace_c_check_string_bytes_bs__1876000632_fn__1876000633_A_class *jrt.Class

var A_arbace_c_check_string_bytes_bs__1876000632_fn__1876000633_fn__1876000634_A_class *jrt.Class

var A_arbace_c_check_sys_at_A_class *jrt.Class

var A_arbace_c_check_sys_at_fn__1876000829_A_class *jrt.Class

var A_arbace_c_check_tag_attrs_BANG__A_class *jrt.Class

var A_arbace_c_check_tag_ref_A_class *jrt.Class

var A_arbace_c_check_top_scope_A_class *jrt.Class

var A_arbace_c_check_tstr_A_class *jrt.Class

var A_arbace_c_check_tstr_w__1876000070_A_class *jrt.Class

var A_arbace_c_check_type_eq_A_class *jrt.Class

var A_arbace_c_check_type_pos_attrs_BANG__A_class *jrt.Class

var A_arbace_c_check_unq_A_class *jrt.Class

var A_arbace_c_check_unq_STAR__A_class *jrt.Class

var A_arbace_c_check_unq_elem_A_class *jrt.Class

var A_arbace_c_check_unsigned_of_A_class *jrt.Class

var A_arbace_c_check_usual_A_class *jrt.Class

var A_arbace_c_check_vectorize_A_class *jrt.Class

var A_arbace_c_check_vectorize_fn__1876000230_A_class *jrt.Class

var A_arbace_c_check_vectorize_fn__1876000239_A_class *jrt.Class

var A_arbace_c_check_vla_QMARK__A_class *jrt.Class

var A_arbace_c_check_vla_struct_QMARK__A_class *jrt.Class

var A_arbace_c_check_vla_struct_QMARK__fn__1876000326_A_class *jrt.Class

var A_arbace_c_check_vm_type_QMARK__A_class *jrt.Class

var A_arbace_c_check_vm_type_QMARK__fn__1876000321_A_class *jrt.Class

var A_arbace_c_check_vm_type_QMARK__fn__1876000323_A_class *jrt.Class

var A_arbace_c_check_void_type_QMARK__A_class *jrt.Class

var A_arbace_c_check_with_scope_A_class *jrt.Class

var A_arbace_c_check_wrap_A_class *jrt.Class

func A_arbace_c_check__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_c_check__init_A_Load__O()}; return nil }

func A_arbace_c_check__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c_check__init_A_New()}; return nil }

var A_arbace_c_check__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_c_check__init_A_invoke, New: A_arbace_c_check__init_A_new}

var A_arbace_c_check__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c.check__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_c_check.A_arbace_c_check__init_A", Source: "check.ae"})

func init() { i := A_arbace_c_check__init_A_class.Info(); i.IsInstance = A_arbace_c_check__init_A_InstanceOf; i.Table = A_arbace_c_check__init_A_members }

var A_arbace_c_check__init_part0_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c.check__init$part0", Modifiers: 24, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_c_check__init_A_class, Simple: "part0", Go: "arbace/aot_arbace_c_check.A_arbace_c_check__init_part0_A", Source: "check.ae"})

func init() { i := A_arbace_c_check__init_part0_A_class.Info(); i.IsInstance = A_arbace_c_check__init_part0_A_InstanceOf; i.Init = A_arbace_c_check__init_part0_A_Init }

var A_arbace_c_check__init_part1_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c.check__init$part1", Modifiers: 24, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_c_check__init_A_class, Simple: "part1", Go: "arbace/aot_arbace_c_check.A_arbace_c_check__init_part1_A", Source: "check.ae"})

func init() { i := A_arbace_c_check__init_part1_A_class.Info(); i.IsInstance = A_arbace_c_check__init_part1_A_InstanceOf; i.Init = A_arbace_c_check__init_part1_A_Init }

var A_arbace_c_check__init_part2_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c.check__init$part2", Modifiers: 24, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_c_check__init_A_class, Simple: "part2", Go: "arbace/aot_arbace_c_check.A_arbace_c_check__init_part2_A", Source: "check.ae"})

func init() { i := A_arbace_c_check__init_part2_A_class.Info(); i.IsInstance = A_arbace_c_check__init_part2_A_InstanceOf; i.Init = A_arbace_c_check__init_part2_A_Init }
