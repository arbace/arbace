//line j2g_strings.ae:1
package aot_arbace_c_check

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,strkn3,dockn3,extkn6,pragmakn5,annotkn10,annotatingkn5,featskn12,vector-typeskn6,errorskn8,pedantickn9,ext-lineskn4,linekn7,resultsys11,arbace.core7,bindingys14,arbace.c.check6,*line*ys14,arbace.c.check7,line-ofkn3,stdkn5,gnu11kn3,c17kn3,c89kn3,c99kn5,gnu17kn5,gnu2ykn3,c2ykn3,c11kn3,c94kn5,gnu89kn5,gnu99kn13,no-c2y-compatkn4,bitskn2,lvkn1,kkn3,ptrkn2,tokn5,arraykn2,ofkn1,nkn8,float128kn7,float32kn6,dec64xkn8,float32xkn7,float64kn9,float128xkn8,float64xkn6,dec128kn1,qkn13,unsigned-charkn3,reckn5,underkn6,bitintkn4,enumkn7,complexkn7,nullptrkn5,unionkn6,structkn4,voidkn4,charkn1,ukn4,boolkn12,ldouble-sizekn4,elsekn5,dec32kn4,bf16kn4,longkn3,intkn8,completekn4,sizekn7,float16kn7,ldoublekn3,vlakn6,ushortkn2,fnkn6,vectorkn6,int128kn5,llongkn5,ucharkn5,ulongkn5,scharkn6,doublekn5,floatkn6,ullongkn5,dec64kn5,shortkn7,uint128kn4,uintkn6,talignkn5,alignkn3,tagkn6,paramskn5,protokn8,variadickn10,empty-listkn3,retkn7,invalidkn7,memberskn4,namekn1,tkn6,constskn5,fixedkn7,mpackedkn5,scopekn12,cc-enum-typekn21,cc-bitfield-promotionkn6,scopeskn3,ordkn4,tagsyn2,doys14,arbace.c.check11,push-scope!yn3,tryyn7,finallyys14,arbace.c.check10,pop-scope!ys1,c2,idyn13,__attribute__yn11,byte-stringks1,c6,aparenkn8,functionyn8,restrictyn8,volatileyn6,atomicyn1,*yn2,fnyn8,_Nonnullyn5,arrayyn5,constkn7,typedefkn4,kindyn18,typeof-unqual-typeyn6,typeofyn13,typeof-unqualyn11,typeof-typeks1,c10,decl-attrsks1,c5,attrsks1,c8,after-atks1,c11,after-attrsks1,c10,type-attrskn4,typeks1,c10,list-attrsks1,c14,decl-end-attrsks1,c9,end-attrsks1,c9,def-attrskn9,attr-modekn12,cc-attr-modekn9,min-alignkn3,offkn6,bitoffkn1,vkn13,no-c23-compatkn3,objys1,c4,baseyn3,intks1,c2,kryn1,&ks1,c12,implicit-intkn5,paramks1,c4,speckn7,linkageyn4,enumyn8,__seg_gskn6,atomickn8,restrictyn7,bit-intkn9,cc-bitintyn8,__seg_fsyn5,unionkn5,constyn6,structyn7,complexkn8,volatilekn8,vla-expryn16,unsigned-bit-intys1,c13,static-assertys1,c4,bitsys1,c5,groupkn6,memberks1,c4,bitsks1,c7,alignasks1,c12,alignas-typeys14,arbace.c.check10,check-declkn8,definingkn10,redefiningkn4,packkn14,cc-attr-layoutkn18,cc-bitfield-layoutks1,c10,underlyingkn11,nested-seenkn9,enumconstkn2,avkn13,cc-float-foldkn3,strkn16,cc-c23-constantsyn10,code-unitsyn6,bit-oryn1,%yn7,bit-andyn1,+yn1,-yn1,/yn7,bit-xoryn2,==yn2,<=yn2,>=yn1,<yn1,>yn2,!=kn3,nfpyn2,>>yn2,<<kn2,ldyn2,oryn3,andkn10,permissivekn1,xkn8,implicitkn2,idkn10,file-scopekn7,fn-namekn7,builtinkn5,entrykn12,cc-constexprkn16,cc-builtin-typeskn6,malignkn21,cc-undeclared-builtinkn5,partskn4,snankn15,cc-builtin-foldyn9,imaginarykn3,deckn18,cc-prefixed-stringks1,c4,typekn7,defaultkn6,chosenyn4,inityn3,lityn2,atyn12,compound-litys1,c5,embedkn4,inityn6,va-argyn4,imagyn1,?yn8,offsetofyn4,agetkn16,cc-builtin-macroyn4,set!yn7,alignofyn13,classify-typeyn4,dec!yn6,sizeofyn3,notyn8,bit-castyn4,inc!yn7,genericyn13,convertvectoryn4,addrkn4,addryn14,has-attribute?kn9,constexpryn5,commays1,c4,callyn4,asetyn10,label-addrys1,c4,expryn4,convyn7,bit-notyn17,types-compatible?yn2,->yn12,alignof-typeyn8,pre-dec!yn4,realyn11,sizeof-typeyn8,pre-inc!yn9,stmt-exprys11,arbace.core5,derefkn6,statickn6,externkn1,ikn10,cc-linkagekn13,cc-redeclaredks1,c9,auto-typekn4,autokn1,mks1,c9,bad-specsyn13,unsigned-charkn6,columnkn12,thread_localkn4,defskn7,cc-autokn6,fn-retys1,c7,declareys1,c9,attr-declkn3,topys1,c4,defnys1,c4,enumys1,c7,typedefys1,c3,varys1,c5,unionkn12,exec-charsetys1,c12,local-labelsys1,c6,structys1,c13,declare-specskn5,blockyn7,defaultyn4,caseyn5,labelyn1,_yn4,condyn8,continueyn6,switchyn3,forkn4,seenyn5,goto*ys1,c6,defineys1,c6,pragmays1,c9,directiveyn6,returnyn2,ifyn3,letyn8,do-whileks1,c8,sel-declys1,c3,asmys1,c7,includekn3,asmyn4,gotoyn5,whileyn5,breakyn4,whenys1,c5,undefkn10,pack-statekn5,stackys1,c6,headerkn5,pack1ys1,c4,filekn4,unitkn10,done-unitskn5,unitskn4,basekn6,systemkn4,pathkn8,sys-dirskn5,fileskn10,form-fileskn11,sys-changeskn9,form-offskn5,formskn8,annotatekn5,noteskn5,itemsv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn14,arbace.c.checkm2,R4,s1792,The checker over C forms (doc/c/SPEC.md §11.2; doc/C23-SURVEY.md, C4, \"As built: C4\"): every\n  expression's type and constant value, the integer promotions and the usual arithmetic conversions\n  (6.3), lvalue, array and function conversions, null pointer constants, constant expressions and their\n  values (6.6: enumerators, sizeof, alignof, constexpr objects, case labels, array sizes), layout by the\n  SysV x86-64 psABI as gcc 15.2 lays out (sizes, alignments, members' offsets, bit-fields, packed,\n  aligned), linkage (6.2.2), arrays completed by their initializers, `auto`'s, `__auto_type`'s and\n  `typeof`'s types, `_Generic`'s selection, `_BitInt`. Arbace's own (CS8 (a)); cc's checker is its oracle\n  where it succeeds (bin/ci annotations, arbace.repr.c.annot).\n\n  `check-unit` checks a read's forms (arbace.repr.c/read-c's) and returns its errors (the reference's\n  errors the checker diagnoses: only those gcc 15.2 gives, as errors) and, when asked, the annotations\n  of every main-file item in tools/ccdump's types format. A header unit's forms are checked where their\n  c/include stands, without annotations. Moved from arbace/repr/c/ as arbace.c.check in C5 (CS90 (a)),\n  with ci's namespaces; `:results` gives ci's builder each form's result (CS95 (a)).\n\n  Types are maps: {:k KIND} for the base types (:void :bool :char :schar :uchar :short :ushort :int :uint\n  :long :ulong :llong :ullong :int128 :uint128 :float :double :ldouble and the other floating types),\n  {:k :bitint :n N :u bool}, {:k :complex :of T}, {:k :ptr :to T}, {:k :array :of T :n N-or-nil :vla bool},\n  {:k :fn :ret T :params [T] :variadic bool :proto bool}, {:k :struct|:union|:enum :rec R} (R a mutable\n  record of the tag: its members, layout, completeness), {:k :nullptr}, {:k :invalid}; qualifiers in :q.R5,R6,v14,arbace.c.check4,*cx*v14,arbace.c.check2,cxR7,R8,R9,R10,R11,v14,arbace.c.check6,*unit*v14,arbace.c.check6,*line*R12,v11,arbace.core3,notv14,arbace.c.check13,*system-unit*v14,arbace.c.check11,*unit-info*v11,arbace.core9,contains?v14,arbace.c.check12,*unit-line?*R13,v14,arbace.c.check4,err!R14,R15,v11,arbace.core4,seq?v11,arbace.core7,symbol?v11,arbace.core7,vector?v11,arbace.core3,seqv11,arbace.core6,concatv11,arbace.core4,listR16,v11,arbace.core5,applyv11,arbace.core6,vectorR17,R18,R19,R20,l111,R21,l117,R22,l89,R23,l99,l123,R24,R25,l124,R26,R27,R28,R29,R30,v14,arbace.c.check7,std-numR31,v14,arbace.c.check8,pedwarn!R32,R33,R34,R35,R36,R37,R38,R39,R40,l3,R41,R42,l1,R43,l2,R44,R45,R46,R47,R48,v11,arbace.core6,dissocv11,arbace.core5,assocv14,arbace.c.check4,qualv11,arbace.core6,updatev11,arbace.core4,fnilv14,arbace.c.check5,qualsR49,R50,R51,v14,arbace.c.check6,t-uintv14,arbace.c.check8,int-infoR52,R53,v14,arbace.c.check10,float-rankR54,v14,arbace.c.check9,int-type?v14,arbace.c.check11,float-type?v14,arbace.c.check13,complex-type?v14,arbace.c.check11,arith-type?v14,arbace.c.check9,ptr-type?R55,S2,R56,R57,R58,R59,v14,arbace.c.check8,int-bitsv14,arbace.c.check10,enum-underl8,v14,arbace.c.check12,char-signed?R60,l32,v14,arbace.c.check4,rankl325,v11,arbace.core5,some?R61,v14,arbace.c.check3,unql0,v11,arbace.core10,bigintegerv11,arbace.core6,bigintR62,l16,l4,R63,R64,R65,v14,arbace.c.check7,size-ofR66,R67,R56,R68,R69,R57,R70,R71,v14,arbace.c.check12,ldouble-sizeR72,R73,R74,R75,R76,R77,R78,R79,R80,R81,R82,R83,R84,R85,v14,arbace.c.check11,bitint-sizeR86,R87,R88,v14,arbace.c.check9,align-of*v14,arbace.c.check8,align-ofR89,v11,arbace.core3,strv11,arbace.core4,nameR90,R91,R92,v11,arbace.core6,empty?R93,R94,v11,arbace.core11,map-indexedv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core5,firstv11,arbace.core10,chunk-restv11,arbace.core4,nextR95,R96,S2,R56,R57,R97,v11,arbace.core6,every?v11,arbace.core5,true?v11,arbace.core3,mapR98,v14,arbace.c.check8,mcompat?R99,v14,arbace.c.check11,compatible?v11,arbace.core4,not=S1,R59,R100,R101,v14,arbace.c.check14,*compat-depth*R102,v11,arbace.core19,pop-thread-bindingsR103,v11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv14,arbace.c.check3,ptrv14,arbace.c.check7,promotev14,arbace.c.check5,t-intv14,arbace.c.check5,feat!R104,R105,m2,R34,R78,m2,R34,R83,m2,R34,R78,v14,arbace.c.check7,t-ulongm2,R34,R86,m2,R34,R73,v14,arbace.c.check8,float-ofv14,arbace.c.check5,usualS2,R70,R65,S2,R70,R65,v14,arbace.c.check9,float-tiev14,arbace.c.check11,unsigned-ofR106,R107,R108,R109,R110,R111,R112,R113,v14,arbace.c.check9,top-scopeR114,v11,arbace.core6,secondv11,arbace.core6,mapcatR115,v14,arbace.c.check10,attr-itemsv11,arbace.core4,restv13,arbace.string7,replacep7,^__|__$v11,arbace.core9,namespacev11,arbace.core3,vecp7,^__|__$v14,arbace.c.check8,attrs-ofv14,arbace.c.check13,all-attr-keysv14,arbace.c.check16,std-no-arg-attrsv14,arbace.c.check16,std-string-attrsv11,arbace.core7,string?R116,v11,arbace.core6,ffirstR117,v11,arbace.core12,chunk-bufferv14,arbace.c.check18,std-position-attrsv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core4,consv14,arbace.c.check8,ignored!v14,arbace.c.check9,std-namesv14,arbace.c.check14,std-attr-misc!S2,s9,_Noreturns8,noreturnS2,s9,_Noreturns8,noreturnR118,v14,arbace.c.check13,fn-type-attrsS8,R119,R120,R121,R122,R123,R124,R125,R126,v11,arbace.core4,lastv14,arbace.c.check9,base-symsv14,arbace.c.check6,lookupR127,R128,S4,R129,R130,R131,R132,R133,R134,R135,R136,v11,arbace.core3,setR137,v14,arbace.c.check15,type-pos-attrs!v14,arbace.c.check13,base-fn-type?R138,V5,R134,R133,R139,R140,R141,R142,S2,s9,_Noreturns8,noreturnS2,s9,_Noreturns8,noreturnv14,arbace.c.check15,std-attr-check!v14,arbace.c.check2,exv14,arbace.c.check4,ann!v11,arbace.core7,number?v11,arbace.core5,char?R143,v11,arbace.core6,filterp7,^__|__$V2,l0,Tv14,arbace.c.check13,assoc-in-modem2,R34,R85,m2,R34,R73,v14,arbace.c.check8,t-doublev14,arbace.c.check6,t-longm2,R34,R80,m2,R34,R78,v14,arbace.c.check7,t-floatm2,R34,R76,m2,R34,R86,m2,R34,R80,m2,R34,R78,v14,arbace.c.check9,const-intv11,arbace.core8,integer?R144,v11,arbace.core4,atomR145,v14,arbace.c.check8,align-upv14,arbace.c.check12,member-alignR146,R147,v11,arbace.core5,swap!v11,arbace.core3,maxv11,arbace.core2,+'v11,arbace.core6,reset!v11,arbace.core4,somev14,arbace.c.check12,record-type?v14,arbace.c.check6,memberv11,arbace.core1,+v14,arbace.c.check10,lookup-tagv14,arbace.c.check7,new-recv14,arbace.c.check11,*auto-init*R148,R149,R150,v14,arbace.c.check6,t-charR151,v14,arbace.c.check6,*base*v14,arbace.c.check9,t-invalidR114,R123,v14,arbace.c.check10,parse-typeR152,R153,R154,v11,arbace.core7,butlastv14,arbace.c.check11,push-scope!v11,arbace.core4,keepv14,arbace.c.check5,identR155,R152,R114,v14,arbace.c.check20,decl-position-attrs!R156,R157,v14,arbace.c.check4,tstrv14,arbace.c.check8,declare!R158,v14,arbace.c.check10,pop-scope!v14,arbace.c.check4,c23?R122,R114,v11,arbace.core6,symbolR159,v14,arbace.c.check10,check-enumR160,R121,R161,R119,R162,R163,v14,arbace.c.check12,bitint-widthR129,R164,R165,R131,R166,v14,arbace.c.check12,check-structv11,arbace.core7,keywordv14,arbace.c.check10,bit-field?R126,R167,R124,R168,R169,R130,R120,R170,R132,R125,R122,v14,arbace.c.check3,arrR171,v14,arbace.c.check4,vla?R172,v11,arbace.core6,pr-strR173,R174,v14,arbace.c.check3,exiR175,v14,arbace.c.check12,member-formsv11,arbace.core4,dropS2,R166,R168,v14,arbace.c.check10,attr-args!v14,arbace.c.check9,vectorizeR176,R177,v14,arbace.c.check13,aligned-valueR178,R179,v11,arbace.core7,resolveR180,v14,arbace.c.check9,rec-same?v14,arbace.c.check7,type-eqv14,arbace.c.check8,vm-type?S2,R56,R57,v14,arbace.c.check11,vla-struct?v11,arbace.core8,not-any?v14,arbace.c.check10,tag-attrs!v14,arbace.c.check7,tag-refR181,R182,R183,R184,v14,arbace.c.check7,layout!R185,v11,arbace.core4,neg?l4294967295,l-2147483648,l2147483647,R186,R187,v14,arbace.c.check4,wrapv11,arbace.core2,<=l-2147483648,l2147483647,v14,arbace.c.check12,enum-type-ofl-2147483648,l2147483647,R188,v11,arbace.core6,zipmapv11,arbace.core8,to-arrayv11,arbace.core5,mergev14,arbace.c.check5,decayR189,C14,java.lang.Mathd4607182418800017408,v14,arbace.c.check9,round-sigl11,l-14,l15,l-126,l127,v14,arbace.c.check11,round-exactl64,l-16382,v14,arbace.c.check13,round-ldoublev14,arbace.c.check14,binary-formatsl24,S2,R70,R65,S4,R70,R41,R82,R65,v14,arbace.c.check9,round-bigv14,arbace.c.check15,round-to-formatR190,l-2147483648,l2147483647,v14,arbace.c.check4,big?r21,18446744073709551615Nm2,R34,R76,v11,arbace.core6,ratio?R191,v14,arbace.c.check6,t-boolv14,arbace.c.check9,t-nullptrR192,v11,arbace.core6,reduceR193,v14,arbace.c.check15,code-unit-countR116,v14,arbace.c.check15,byte-string-lenR194,R195,R196,R122,R197,R198,R199,R200,R122,R197,R198,R199,R201,R202,R203,R204,R205,R206,v14,arbace.c.check10,void-type?v14,arbace.c.check11,null-const?R207,S2,R206,R201,v14,arbace.c.check3,resS4,R204,R202,R205,R203,S10,R200,R122,R195,R198,R196,R208,R199,R194,R197,R209,S2,R96,R75,S2,R96,R75,v14,arbace.c.check7,cmp-opsv14,arbace.c.check9,eval-typeR210,S4,R45,R46,R71,R40,v14,arbace.c.check7,cmp-valv14,arbace.c.check8,conv-valS2,R211,R212,R212,R211,R212,R211,S2,R208,R209,R209,R197,R197,R198,R198,v14,arbace.c.check6,int-opv14,arbace.c.check8,float-opv14,arbace.c.check15,null-const-npc?v14,arbace.c.check12,scalar-type?S4,R200,R195,R196,R194,S2,R56,R57,v14,arbace.c.check8,unq-elemv14,arbace.c.check9,int-classS2,R96,R58,S2,R96,R58,v14,arbace.c.check6,t-voidv11,arbace.core4,disjv11,arbace.core4,intov14,arbace.c.check23,compatible-ptr-targets?R213,R214,R215,R216,R217,v14,arbace.c.check13,file-declare!R218,v13,arbace.string12,starts-with?R219,R220,R221,R222,R223,v14,arbace.c.check4,c99?v14,arbace.c.check13,builtin-typesv14,arbace.c.check12,implicit-fn!v14,arbace.c.check5,emit!v14,arbace.c.check7,record!v14,arbace.c.check9,callee-fnv11,arbace.core4,mapvv14,arbace.c.check12,call-builtinR224,v14,arbace.c.check9,ptr-conv!R225,v11,arbace.core10,re-matchesp36,__builtin_(inf|nan|nans)d(32|64|128)R226,S9,s18,__builtin_huge_vals14,__builtin_inffs20,__builtin_constant_ps13,__builtin_infs16,__builtin_expects19,__builtin_huge_valfs19,__builtin_huge_valls21,__builtin_choose_exprs14,__builtin_inflR227,m2,R34,R71,m2,R34,R71,S2,R193,R116,R228,v14,arbace.c.check9,dec-kindsR229,v14,arbace.c.check5,ld-ofS2,R70,R65,v14,arbace.c.check14,float-of-exactR230,v14,arbace.c.check16,incomplete-type?R231,v14,arbace.c.check12,pedwarn-c2y!v11,arbace.core5,doallR232,R233,R116,R234,S6,R73,R67,R87,R78,R59,R80,R116,R235,v14,arbace.c.check10,init-countR234,R236,v11,arbace.core8,keyword?R234,S1,R237,R235,v11,arbace.core5,nnextR234,R238,R236,v14,arbace.c.check10,check-initv14,arbace.c.check4,unq*S5,R55,R96,R75,R61,R35,S2,R55,R96,R239,v14,arbace.c.check9,member-ofv14,arbace.c.check3,ex*v14,arbace.c.check10,ident-exprv14,arbace.c.check4,callR240,R195,v14,arbace.c.check6,binaryR241,R122,R197,R198,v11,arbace.core4,subsv14,arbace.c.check8,lit-typev14,arbace.c.check7,line-ofR197,S2,R96,R75,R197,R198,S2,R96,R75,R199,S2,R96,R75,R204,S2,R96,R75,R205,R242,v14,arbace.c.check9,cond-typeR228,R206,R200,R243,S2,R96,R75,R244,v14,arbace.c.check10,deref-typev14,arbace.c.check17,binary-index-typeR245,R194,R246,S2,R96,R75,R247,v14,arbace.c.check12,assign-checkR235,v14,arbace.c.check8,lit-formR248,R249,R250,v14,arbace.c.check10,sizeof-resR116,R251,R212,R252,S2,R96,R75,R253,R254,v14,arbace.c.check14,generic-selectR255,R256,R257,R237,R234,S3,R238,R234,R236,R258,R234,R259,v14,arbace.c.check16,constexpr-check!R114,R260,v11,arbace.core4,peekR261,R262,R263,R196,R209,S2,R96,R75,R264,R202,R265,S2,R55,R96,S5,R55,R96,R58,R61,R35,R266,R267,S2,R96,R75,R268,v14,arbace.c.check12,nested-arrowR201,R269,R270,R208,R203,R271,R272,R234,R273,R211,R274,v14,arbace.c.check17,check-block-itemsS2,R96,R75,R275,R276,R277,v14,arbace.c.check11,file-scope?R278,S2,R214,R278,S2,R214,R278,S2,R214,R278,R279,v14,arbace.c.check10,linkage-ofS2,R74,R150,R280,S2,R74,R150,S2,R74,R150,R281,R282,S4,R129,R130,R131,R132,v11,arbace.core8,tree-seqv11,arbace.core5,coll?R283,S2,R74,R150,v14,arbace.c.check9,compositeR284,v14,arbace.c.check5,lnameR116,R235,R285,R116,R235,R285,v14,arbace.c.check10,dec-limitsv14,arbace.c.check9,dec-fits?v14,arbace.c.check9,round-decC20,java.math.BigDecimalv14,arbace.c.check12,fits-binary?v14,arbace.c.check19,constexpr-float-badv14,arbace.c.check12,string-bytesR234,V2,l-128,l127,V2,l0,l255,V2,l0,l255,V2,l-128,l127,v14,arbace.c.check10,auto-type?v14,arbace.c.check15,declare-object!R152,ML1,R234,m4,R14,i2110,R286,i45,S4,R129,R130,R131,R132,R234,R287,R288,v14,arbace.c.check14,complete-arrayR289,R234,S4,R81,R55,R82,R35,R154,R152,v11,arbace.core4,compv11,arbace.core6,re-seqp59,\\\"([=+&%]*[a-zA-Z]*r[a-zA-Z]*)\\\"\\s*\\(\\s*([A-Za-z_]\\w*)\\s*\\)S1,R150,v11,arbace.core7,re-findp10,[mogVX0-9]S1,R150,R152,v14,arbace.c.check9,params-ofR290,R123,R152,R291,v14,arbace.c.check13,check-declareR175,R292,v14,arbace.c.check16,attr-decl-check!R293,R294,v14,arbace.c.check10,check-defnv14,arbace.c.check10,check-declR295,v11,arbace.core9,with-metaR159,R296,v14,arbace.c.check13,check-typedefR297,v14,arbace.c.check9,check-varR298,v11,arbace.core9,vary-metaR173,R299,R300,R301,R302,R292,v14,arbace.c.check10,decl-headsv14,arbace.c.check10,decl-form?R297,R303,v14,arbace.c.check11,*in-switch*S2,R304,R305,S2,R304,R305,R292,S3,R304,R306,R305,S2,s11,fallthroughs10,deprecatedS3,s9,nodiscards9,_Noreturns8,noreturnS2,s11,fallthroughs10,deprecatedS3,s9,nodiscards9,_Noreturns8,noreturnV1,nv14,arbace.c.check10,check-stmtR292,v14,arbace.c.check11,stmt-attrs!R307,R308,R309,R292,R310,R311,v14,arbace.c.check8,*switch*R312,R313,v14,arbace.c.check12,let-bindingsv14,arbace.c.check9,cond-exprR314,R315,R316,R317,R306,R318,R304,R319,R320,R321,R322,R323,R324,v14,arbace.c.check13,asm-operands!R109,R325,R326,R327,R328,R300,R329,R305,v13,arbace.string4,joinp8,\\bpack\\bp33,pack\\s*\\(\\s*(?:push\\s*,\\s*)?(\\d+)p14,pack\\s*\\(\\s*\\)R330,p3,popR331,v11,arbace.core3,popp4,pushv14,arbace.c.check9,check-topR332,R314,R316,R329,R333,R334,R322,R323,v11,arbace.core10,drop-whileR335,R336,R337,R338,v13,arbace.string11,split-linesv11,arbace.core12,keep-indexedp38,^\\s*#\\s*pragma\\s+GCC\\s+system_header\\bR339,R340,v11,arbace.core10,make-arrayC16,java.lang.StringR341,R342,R343,R344,R345,R346,R315,v14,arbace.c.check12,pragma-pack!v14,arbace.c.check6,sys-atR347,R348,v14,arbace.c.check6,new-cxR349,S5,R323,R316,R314,R329,R315,S5,R323,R316,R314,R329,R315,")

var Lit_1 *jrt.String = jrt.Intern("vector(")

var Lit_2 *jrt.String = jrt.Intern("impossible constraint in 'asm'")

var Lit_3 *jrt.String = jrt.Intern("assignment of read-only location")

var Lit_4 *jrt.String = jrt.Intern("e int")

var Lit_5 *jrt.String = jrt.Intern("fallthrough")

var Lit_6 *jrt.String = jrt.Intern("'fallthrough' attribute at top level")

var Lit_7 *jrt.String = jrt.Intern("invalid use of attribute 'fallthrough'")

var Lit_8 *jrt.String = jrt.Intern("attribute 'fallthrough' not preceding a case label or default label")

var Lit_9 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_10 *jrt.String = jrt.Intern("arbace.c.check$attr_items$fn__1876000139")

var Lit_11 *jrt.String = jrt.Intern("")

var Lit_12 *jrt.String = jrt.Intern("gnu")

var Lit_13 *jrt.String = jrt.Intern("arbace.c.check$attrs_of$fn__1876000143")

var Lit_14 *jrt.String = jrt.Intern("arbace.c.check$base_fn_type_QMARK_$fn__1876000196")

var Lit_15 *jrt.String = jrt.Intern("invalid operands to binary ")

var Lit_16 *jrt.String = jrt.Intern("ordered comparison of pointer with null pointer")

var Lit_17 *jrt.String = jrt.Intern("arbace.c.check$binary$ex__1876000448")

var Lit_18 *jrt.String = jrt.Intern("invalid operands to binary shift")

var Lit_19 *jrt.String = jrt.Intern("ISO C does not support '")

var Lit_20 *jrt.String = jrt.Intern("_BitInt(")

var Lit_21 *jrt.String = jrt.Intern(")' before C23")

var Lit_22 *jrt.String = jrt.Intern("unsigned ")

var Lit_23 *jrt.String = jrt.Intern("'_BitInt' argument is not an integer constant expression")

var Lit_24 *jrt.String = jrt.Intern("'_BitInt' argument '")

var Lit_25 *jrt.String = jrt.Intern("' is not a positive integer constant expression")

var Lit_26 *jrt.String = jrt.Intern("'signed _BitInt' argument must be at least 2")

var Lit_27 *jrt.String = jrt.Intern("' is larger than 'BITINT_MAXWIDTH' '65535'")

var Lit_28 *jrt.String = jrt.Intern("arbace.c.check$byte_string_len$fn__1876000428")

var Lit_29 *jrt.String = jrt.Intern("UTF-8")

var Lit_30 *jrt.String = jrt.Intern("__builtin_")

var Lit_31 *jrt.String = jrt.Intern("implicit declaration of function '")

var Lit_32 *jrt.String = jrt.Intern("'")

var Lit_33 *jrt.String = jrt.Intern("__func__")

var Lit_34 *jrt.String = jrt.Intern("__sync_")

var Lit_35 *jrt.String = jrt.Intern("__atomic_")

var Lit_36 *jrt.String = jrt.Intern("__builtin_has_attribute")

var Lit_37 *jrt.String = jrt.Intern("called object is not a function or function pointer")

var Lit_38 *jrt.String = jrt.Intern("too many arguments to function")

var Lit_39 *jrt.String = jrt.Intern("too few arguments to function")

var Lit_40 *jrt.String = jrt.Intern("passing argument ")

var Lit_41 *jrt.String = jrt.Intern("__builtin_huge_val")

var Lit_42 *jrt.String = jrt.Intern("__builtin_constant_p")

var Lit_43 *jrt.String = jrt.Intern("__builtin_complex")

var Lit_44 *jrt.String = jrt.Intern("__builtin_choose_expr")

var Lit_45 *jrt.String = jrt.Intern("__builtin_nans")

var Lit_46 *jrt.String = jrt.Intern("__builtin_nansf")

var Lit_47 *jrt.String = jrt.Intern("__builtin_huge_valf")

var Lit_48 *jrt.String = jrt.Intern("__builtin_huge_vall")

var Lit_49 *jrt.String = jrt.Intern("__builtin_nansl")

var Lit_50 *jrt.String = jrt.Intern("__builtin_inf")

var Lit_51 *jrt.String = jrt.Intern("__builtin_inff")

var Lit_52 *jrt.String = jrt.Intern("__builtin_infl")

var Lit_53 *jrt.String = jrt.Intern("__builtin_expect")

var Lit_54 *jrt.String = jrt.Intern("32")

var Lit_55 *jrt.String = jrt.Intern("64")

var Lit_56 *jrt.String = jrt.Intern("nans")

var Lit_57 *jrt.String = jrt.Intern("arbace.c.check$check_block_items$fn__1876000773")

var Lit_58 *jrt.String = jrt.Intern("arbace.c.check$check_block_items$fn__1876000778")

var Lit_59 *jrt.String = jrt.Intern("static assertion failed")

var Lit_60 *jrt.String = jrt.Intern("two or more data types in declaration specifiers")

var Lit_61 *jrt.String = jrt.Intern("storage class specifier '_Thread_local' in a function declaration")

var Lit_62 *jrt.String = jrt.Intern("arbace.c.check$check_defn$fn__1876000694")

var Lit_63 *jrt.String = jrt.Intern("arbace.c.check$check_defn$fn__1876000706")

var Lit_64 *jrt.String = jrt.Intern("arbace.c.check$check_defn$fn__1876000711")

var Lit_65 *jrt.String = jrt.Intern("old-style function definition")

var Lit_66 *jrt.String = jrt.Intern("invalid 'enum' underlying type")

var Lit_67 *jrt.String = jrt.Intern("'enum' declared both with and without fixed underlying type")

var Lit_68 *jrt.String = jrt.Intern("'enum' declared with but defined without fixed underlying type")

var Lit_69 *jrt.String = jrt.Intern("nested redefinition of 'enum ")

var Lit_70 *jrt.String = jrt.Intern("arbace.c.check$check_enum$fn__1876000384")

var Lit_71 *jrt.String = jrt.Intern("enumerator value outside the range of the underlying type")

var Lit_72 *jrt.String = jrt.Intern("overflow in enumeration values")

var Lit_73 *jrt.String = jrt.Intern("n ")

var Lit_74 *jrt.String = jrt.Intern(" ")

var Lit_75 *jrt.String = jrt.Intern("?")

var Lit_76 *jrt.String = jrt.Intern("arbace.c.check$check_enum$fn__1876000389")

var Lit_77 *jrt.String = jrt.Intern("redefinition of 'enum ")

var Lit_78 *jrt.String = jrt.Intern("arbace.c.check$check_enum$fn__1876000391")

var Lit_79 *jrt.String = jrt.Intern("enumeration values exceed range of largest integer")

var Lit_80 *jrt.String = jrt.Intern("arbace.c.check$check_enum$fn__1876000393")

var Lit_81 *jrt.String = jrt.Intern("redeclaration of enumerator '")

var Lit_82 *jrt.String = jrt.Intern("initialization")

var Lit_83 *jrt.String = jrt.Intern("arbace.c.check$check_stmt$fn__1876000783")

var Lit_84 *jrt.String = jrt.Intern("' statement with an identifier operand before C2Y")

var Lit_85 *jrt.String = jrt.Intern("switch quantity not an integer")

var Lit_86 *jrt.String = jrt.Intern("arbace.c.check$check_stmt$fn__1876000785")

var Lit_87 *jrt.String = jrt.Intern("arbace.c.check$check_stmt$fn__1876000790")

var Lit_88 *jrt.String = jrt.Intern("return")

var Lit_89 *jrt.String = jrt.Intern("arbace.c.check$check_stmt$fn__1876000795")

var Lit_90 *jrt.String = jrt.Intern("arbace.c.check$check_stmt$fn__1876000797")

var Lit_91 *jrt.String = jrt.Intern("ISO C does not support if declarations before C2Y")

var Lit_92 *jrt.String = jrt.Intern("arbace.c.check$check_stmt$fn__1876000802")

var Lit_93 *jrt.String = jrt.Intern("arbace.c.check$check_stmt$fn__1876000804")

var Lit_94 *jrt.String = jrt.Intern("arbace.c.check$check_stmt$fn__1876000806")

var Lit_95 *jrt.String = jrt.Intern("arbace.c.check$check_stmt$iv__1876000813")

var Lit_96 *jrt.String = jrt.Intern("arbace.c.check$check_stmt$fn__1876000816")

var Lit_97 *jrt.String = jrt.Intern("duplicate case value")

var Lit_98 *jrt.String = jrt.Intern("ISO C does not support range expressions in switch statements before C2Y")

var Lit_99 *jrt.String = jrt.Intern("nested redefinition of '")

var Lit_100 *jrt.String = jrt.Intern("arbace.c.check$check_struct$fn__1876000342")

var Lit_101 *jrt.String = jrt.Intern("arbace.c.check$check_struct$fn__1876000344")

var Lit_102 *jrt.String = jrt.Intern("redefinition of '")

var Lit_103 *jrt.String = jrt.Intern("s ")

var Lit_104 *jrt.String = jrt.Intern("arbace.c.check$check_struct$fn__1876000346")

var Lit_105 *jrt.String = jrt.Intern("arbace.c.check$check_struct$fn__1876000348")

var Lit_106 *jrt.String = jrt.Intern("#anon")

var Lit_107 *jrt.String = jrt.Intern("packed")

var Lit_108 *jrt.String = jrt.Intern("aligned")

var Lit_109 *jrt.String = jrt.Intern("arbace.c.check$check_top$fn__1876000844")

var Lit_110 *jrt.String = jrt.Intern("arbace.c.check$check_top$read_info__1876000846")

var Lit_111 *jrt.String = jrt.Intern("arbace.c.check$check_top$norm__1876000852")

var Lit_112 *jrt.String = jrt.Intern("arbace.c.check$check_top$fn__1876000854")

var Lit_113 *jrt.String = jrt.Intern("arbace.c.check$check_top$fn__1876000856")

var Lit_114 *jrt.String = jrt.Intern("arbace.c.check$check_top$info_of__1876000858")

var Lit_115 *jrt.String = jrt.Intern("arbace.c.check$check_top$sys_of__1876000862")

var Lit_116 *jrt.String = jrt.Intern("arbace.c.check$check_top$no_pragma__1876000864")

var Lit_117 *jrt.String = jrt.Intern("arbace.c.check$check_top$fn__1876000875")

var Lit_118 *jrt.String = jrt.Intern("arbace.c.check$check_top$fn__1876000880")

var Lit_119 *jrt.String = jrt.Intern("/")

var Lit_120 *jrt.String = jrt.Intern("arbace.c.check$check_top$info_of__1876000858$fn__1876000859")

var Lit_121 *jrt.String = jrt.Intern("arbace.c.check$check_top$no_pragma__1876000864$fn__1876000865")

var Lit_122 *jrt.String = jrt.Intern("ISO-8859-1")

var Lit_123 *jrt.String = jrt.Intern("arbace.c.check$check_top$read_info__1876000846$fn__1876000847")

var Lit_124 *jrt.String = jrt.Intern("arbace.c.check$check_top$read_info__1876000846$fn__1876000849")

var Lit_125 *jrt.String = jrt.Intern("__extension__")

var Lit_126 *jrt.String = jrt.Intern("arbace.c.check$check_typedef$fn__1876000722")

var Lit_127 *jrt.String = jrt.Intern("_Bool")

var Lit_128 *jrt.String = jrt.Intern("bool")

var Lit_129 *jrt.String = jrt.Intern("' cannot be defined via 'typedef'")

var Lit_130 *jrt.String = jrt.Intern("conflicting types for '")

var Lit_131 *jrt.String = jrt.Intern("d ")

var Lit_132 *jrt.String = jrt.Intern(" n ")

var Lit_133 *jrt.String = jrt.Intern("arbace.c.check$check_unit$iter__1876000887__1876000891")

var Lit_134 *jrt.String = jrt.Intern("arbace.c.check$check_unit$fn__1876000903")

var Lit_135 *jrt.String = jrt.Intern("arbace.c.check$check_unit$fn__1876000917")

var Lit_136 *jrt.String = jrt.Intern("arbace.c.check$check_unit$fn__1876000919")

var Lit_137 *jrt.String = jrt.Intern(": ")

var Lit_138 *jrt.String = jrt.Intern("arbace.c.check$check_unit$fn__1876000903$fn__1876000908")

var Lit_139 *jrt.String = jrt.Intern("arbace.c.check$check_unit$fn__1876000903$fn__1876000910")

var Lit_140 *jrt.String = jrt.Intern("arbace.c.check$check_unit$iter__1876000887__1876000891$fn__1876000892")

var Lit_141 *jrt.String = jrt.Intern("arbace.c.check$check_unit$iter__1876000887__1876000891$fn__1876000892$fn__1876000893")

var Lit_142 *jrt.String = jrt.Intern("arbace.c.check$check_var$fn__1876000668")

var Lit_143 *jrt.String = jrt.Intern("zero or negative size array")

var Lit_144 *jrt.String = jrt.Intern("variable-sized object may not be initialized except with an empty initializer")

var Lit_145 *jrt.String = jrt.Intern("array initialized from a string literal with type array of unsigned char")

var Lit_146 *jrt.String = jrt.Intern("array size missing in '")

var Lit_147 *jrt.String = jrt.Intern("storage size of '")

var Lit_148 *jrt.String = jrt.Intern("' isn't known")

var Lit_149 *jrt.String = jrt.Intern("arbace.c.check$check_var$fn__1876000670")

var Lit_150 *jrt.String = jrt.Intern("arbace.c.check$code_unit_count$fn__1876000433")

var Lit_151 *jrt.String = jrt.Intern("arbace.c.check$compatible_QMARK_$fn__1876000091")

var Lit_152 *jrt.String = jrt.Intern("arbace.c.check$compatible_QMARK_$fn__1876000093")

var Lit_153 *jrt.String = jrt.Intern("arbace.c.check$compatible_QMARK_$fn__1876000095")

var Lit_154 *jrt.String = jrt.Intern("arbace.c.check$compatible_QMARK_$fn__1876000097")

var Lit_155 *jrt.String = jrt.Intern("type mismatch in conditional expression")

var Lit_156 *jrt.String = jrt.Intern("pointer type mismatch in conditional expression")

var Lit_157 *jrt.String = jrt.Intern("arbace.c.check$const_int$fn__1876000615")

var Lit_158 *jrt.String = jrt.Intern("arbace.c.check$constexpr_check_BANG_$fn__1876000653")

var Lit_159 *jrt.String = jrt.Intern("arbace.c.check$constexpr_check_BANG_$fn__1876000662")

var Lit_160 *jrt.String = jrt.Intern("'constexpr' initializer not representable in type of object")

var Lit_161 *jrt.String = jrt.Intern("'constexpr' integer initializer is not an integer constant expression")

var Lit_162 *jrt.String = jrt.Intern("'constexpr' initializer for a binary floating-point type is of decimal type")

var Lit_163 *jrt.String = jrt.Intern("' attribute can only be applied to functions")

var Lit_164 *jrt.String = jrt.Intern("nodiscard")

var Lit_165 *jrt.String = jrt.Intern("'nodiscard' attribute can only be applied to functions or to structure, union or enumeration types")

var Lit_166 *jrt.String = jrt.Intern("standard '")

var Lit_167 *jrt.String = jrt.Intern("' attribute can only be applied to function declarators or type specifiers with function type")

var Lit_168 *jrt.String = jrt.Intern("' cannot be used here")

var Lit_169 *jrt.String = jrt.Intern("arbace.c.check$declare_object_BANG_$tyof_QMARK___1876000624")

var Lit_170 *jrt.String = jrt.Intern("arbace.c.check$declare_object_BANG_$fn__1876000626")

var Lit_171 *jrt.String = jrt.Intern("invalid type argument of unary '*'")

var Lit_172 *jrt.String = jrt.Intern("e ")

var Lit_173 *jrt.String = jrt.Intern(" = ")

var Lit_174 *jrt.String = jrt.Intern("arbace.c.check$enum_type_of$fits__1876000356")

var Lit_175 *jrt.String = jrt.Intern("arbace.c.check$enum_type_of$fits__1876000356$fn__1876000357")

var Lit_176 *jrt.String = jrt.Intern(":")

var Lit_177 *jrt.String = jrt.Intern("java.util.ArrayList")

var Lit_178 *jrt.String = jrt.Intern("java.util.HashMap")

var Lit_179 *jrt.String = jrt.Intern("java.util.HashSet")

var Lit_180 *jrt.String = jrt.Intern("java.util.IdentityHashMap")

var Lit_181 *jrt.String = jrt.Intern("_")

var Lit_182 *jrt.String = jrt.Intern("e *fn()int")

var Lit_183 *jrt.String = jrt.Intern("wrong type argument to unary ")

var Lit_184 *jrt.String = jrt.Intern("imaginary constants are a C2Y feature or GCC extension")

var Lit_185 *jrt.String = jrt.Intern("arbace.c.check$ex_STAR_$fn__1876000576")

var Lit_186 *jrt.String = jrt.Intern("assignment")

var Lit_187 *jrt.String = jrt.Intern("'_Alignof' applied to a bit-field")

var Lit_188 *jrt.String = jrt.Intern("ISO C does not support '++' and '--' on complex types before C2Y")

var Lit_189 *jrt.String = jrt.Intern("'sizeof' applied to a bit-field")

var Lit_190 *jrt.String = jrt.Intern("cannot take address of bit-field")

var Lit_191 *jrt.String = jrt.Intern("array of unknown size with empty initializer")

var Lit_192 *jrt.String = jrt.Intern("compound literal has variable size")

var Lit_193 *jrt.String = jrt.Intern("arbace.c.check$ex_STAR_$fn__1876000592")

var Lit_194 *jrt.String = jrt.Intern("conversion of ")

var Lit_195 *jrt.String = jrt.Intern(" to nullptr_t")

var Lit_196 *jrt.String = jrt.Intern("conversion of nullptr_t to ")

var Lit_197 *jrt.String = jrt.Intern("wrong type argument to bit-complement")

var Lit_198 *jrt.String = jrt.Intern("invalid application of 'alignof' to incomplete type")

var Lit_199 *jrt.String = jrt.Intern("arbace.c.check$ex_STAR_$fn__1876000611")

var Lit_200 *jrt.String = jrt.Intern(".-")

var Lit_201 *jrt.String = jrt.Intern("not an integer constant expression")

var Lit_202 *jrt.String = jrt.Intern("compareTo")

var Lit_203 *jrt.String = jrt.Intern("abs")

var Lit_204 *jrt.String = jrt.Intern("doubleValue")

var Lit_205 *jrt.String = jrt.Intern("ISO C does not support use of type name as the controlling operand of '_Generic' before C2Y")

var Lit_206 *jrt.String = jrt.Intern("arbace.c.check$generic_select$iter__1876000501__1876000505")

var Lit_207 *jrt.String = jrt.Intern("arbace.c.check$generic_select$iter__1876000501__1876000505$fn__1876000506")

var Lit_208 *jrt.String = jrt.Intern("arbace.c.check$generic_select$iter__1876000501__1876000505$fn__1876000506$fn__1876000507")

var Lit_209 *jrt.String = jrt.Intern("ISO C does not support '_Generic' association with function type before C2Y")

var Lit_210 *jrt.String = jrt.Intern("ISO C does not support '_Generic' association with incomplete type before C2Y")

var Lit_211 *jrt.String = jrt.Intern("' undeclared")

var Lit_212 *jrt.String = jrt.Intern("unexpected type name '")

var Lit_213 *jrt.String = jrt.Intern("' attribute ignored")

var Lit_214 *jrt.String = jrt.Intern("arbace.c.check$init_count$per__1876000519")

var Lit_215 *jrt.String = jrt.Intern("arbace.c.check$init_count$per__1876000519$fn__1876000521")

var Lit_216 *jrt.String = jrt.Intern("arbace.c.check$layout_BANG_$fn__1876000262")

var Lit_217 *jrt.String = jrt.Intern("arbace.c.check$layout_BANG_$fn__1876000264")

var Lit_218 *jrt.String = jrt.Intern("arbace.c.check$layout_BANG_$fn__1876000266")

var Lit_219 *jrt.String = jrt.Intern("arbace.c.check$layout_BANG_$fn__1876000268")

var Lit_220 *jrt.String = jrt.Intern("arbace.c.check$layout_BANG_$fn__1876000270")

var Lit_221 *jrt.String = jrt.Intern("arbace.c.check$layout_BANG_$fn__1876000272")

var Lit_222 *jrt.String = jrt.Intern("non-standard suffix on floating constant")

var Lit_223 *jrt.String = jrt.Intern("arbace.c.check$mcompat_QMARK_$fn__1876000085")

var Lit_224 *jrt.String = jrt.Intern("arbace.c.check$member$fn__1876000275")

var Lit_225 *jrt.String = jrt.Intern("arbace.c.check$member_forms$fn__1876000298")

var Lit_226 *jrt.String = jrt.Intern("arbace.c.check$member_forms$fn__1876000298$fn__1876000302")

var Lit_227 *jrt.String = jrt.Intern("arbace.c.check$member_forms$fn__1876000298$fn__1876000304")

var Lit_228 *jrt.String = jrt.Intern("arbace.c.check$member_forms$fn__1876000298$fn__1876000306")

var Lit_229 *jrt.String = jrt.Intern("arbace.c.check$member_forms$fn__1876000298$fn__1876000308")

var Lit_230 *jrt.String = jrt.Intern("arbace.c.check$member_forms$fn__1876000298$fn__1876000310")

var Lit_231 *jrt.String = jrt.Intern("arbace.c.check$member_forms$fn__1876000298$fn__1876000313")

var Lit_232 *jrt.String = jrt.Intern("invalid use of incomplete type '")

var Lit_233 *jrt.String = jrt.Intern("no member named '")

var Lit_234 *jrt.String = jrt.Intern("' in '")

var Lit_235 *jrt.String = jrt.Intern("request for member '")

var Lit_236 *jrt.String = jrt.Intern("' in something not a structure or union")

var Lit_237 *jrt.String = jrt.Intern("arbace.c.check$params_of$fn__1876000673")

var Lit_238 *jrt.String = jrt.Intern("arbace.c.check$params_of$adj__1876000676")

var Lit_239 *jrt.String = jrt.Intern("unknown type name '")

var Lit_240 *jrt.String = jrt.Intern("ISO C requires a named argument before '...'")

var Lit_241 *jrt.String = jrt.Intern("arbace.c.check$parse_type$fn__1876000288")

var Lit_242 *jrt.String = jrt.Intern("'typeof_unqual' applied to a bit-field")

var Lit_243 *jrt.String = jrt.Intern("'typeof' applied to a bit-field")

var Lit_244 *jrt.String = jrt.Intern("unknown type form ")

var Lit_245 *jrt.String = jrt.Intern("arbace.c.check$parse_type$fn__1876000288$fn__1876000289")

var Lit_246 *jrt.String = jrt.Intern("arbace.c.check$pragma_pack_BANG_$fn__1876000823")

var Lit_247 *jrt.String = jrt.Intern("arbace.c.check$pragma_pack_BANG_$fn__1876000825")

var Lit_248 *jrt.String = jrt.Intern("incompatible types when converting nullptr_t to ")

var Lit_249 *jrt.String = jrt.Intern(" in ")

var Lit_250 *jrt.String = jrt.Intern("incompatible types when converting ")

var Lit_251 *jrt.String = jrt.Intern(" to nullptr_t in ")

var Lit_252 *jrt.String = jrt.Intern(" discards qualifier from pointer target type")

var Lit_253 *jrt.String = jrt.Intern(": incompatible pointer type ")

var Lit_254 *jrt.String = jrt.Intern(" to ")

var Lit_255 *jrt.String = jrt.Intern("arbace.c.check$rec_same_QMARK_$fn__1876000331")

var Lit_256 *jrt.String = jrt.Intern("arbace.c.check$rec_same_QMARK_$fn__1876000333")

var Lit_257 *jrt.String = jrt.Intern("arbace.c.check$rec_same_QMARK_$fn__1876000335")

var Lit_258 *jrt.String = jrt.Intern("arbace.c.check$round_exact$two__1876000408")

var Lit_259 *jrt.String = jrt.Intern("arbace.c.check$round_exact$fn__1876000410")

var Lit_260 *jrt.String = jrt.Intern("scalb")

var Lit_261 *jrt.String = jrt.Intern("arbace.c.check$spec_attrs_packed$fn__1876000280")

var Lit_262 *jrt.String = jrt.Intern("' attribute does not take any arguments")

var Lit_263 *jrt.String = jrt.Intern("parentheses must be omitted if attribute argument list is empty")

var Lit_264 *jrt.String = jrt.Intern("expected string-literal in the '")

var Lit_265 *jrt.String = jrt.Intern("' attribute")

var Lit_266 *jrt.String = jrt.Intern("ISO C does not support '[[]]' attributes before C23")

var Lit_267 *jrt.String = jrt.Intern("arbace.c.check$std_names$iter__1876000157__1876000161")

var Lit_268 *jrt.String = jrt.Intern("arbace.c.check$std_names$iter__1876000157__1876000161$fn__1876000162")

var Lit_269 *jrt.String = jrt.Intern("arbace.c.check$std_names$iter__1876000157__1876000161$fn__1876000162$fn__1876000163")

var Lit_270 *jrt.String = jrt.Intern("' attribute can only be applied to declarations other than labels")

var Lit_271 *jrt.String = jrt.Intern("arbace.c.check$string_bytes$bs__1876000632")

var Lit_272 *jrt.String = jrt.Intern("arbace.c.check$string_bytes$bs__1876000632$fn__1876000633")

var Lit_273 *jrt.String = jrt.Intern("arbace.c.check$string_bytes$bs__1876000632$fn__1876000633$fn__1876000634")

var Lit_274 *jrt.String = jrt.Intern("arbace.c.check$sys_at$fn__1876000829")

var Lit_275 *jrt.String = jrt.Intern("' declared in underspecified object initializer")

var Lit_276 *jrt.String = jrt.Intern("arbace.c.check$tstr$w__1876000070")

var Lit_277 *jrt.String = jrt.Intern("nullptr_t")

var Lit_278 *jrt.String = jrt.Intern("fn(")

var Lit_279 *jrt.String = jrt.Intern(",")

var Lit_280 *jrt.String = jrt.Intern("...")

var Lit_281 *jrt.String = jrt.Intern("void")

var Lit_282 *jrt.String = jrt.Intern(")")

var Lit_283 *jrt.String = jrt.Intern("[*]")

var Lit_284 *jrt.String = jrt.Intern("[]")

var Lit_285 *jrt.String = jrt.Intern("[")

var Lit_286 *jrt.String = jrt.Intern("]")

var Lit_287 *jrt.String = jrt.Intern("_Complex ")

var Lit_288 *jrt.String = jrt.Intern("*")

var Lit_289 *jrt.String = jrt.Intern("unsigned _BitInt(")

var Lit_290 *jrt.String = jrt.Intern("signed char")

var Lit_291 *jrt.String = jrt.Intern("long long")

var Lit_292 *jrt.String = jrt.Intern("double")

var Lit_293 *jrt.String = jrt.Intern("char")

var Lit_294 *jrt.String = jrt.Intern("_Decimal32")

var Lit_295 *jrt.String = jrt.Intern("_Float64x")

var Lit_296 *jrt.String = jrt.Intern("_Float32x")

var Lit_297 *jrt.String = jrt.Intern("__bf16")

var Lit_298 *jrt.String = jrt.Intern("_Float32")

var Lit_299 *jrt.String = jrt.Intern("unsigned char")

var Lit_300 *jrt.String = jrt.Intern("unsigned __int128")

var Lit_301 *jrt.String = jrt.Intern("unsigned short")

var Lit_302 *jrt.String = jrt.Intern("_Float128")

var Lit_303 *jrt.String = jrt.Intern("_Float64")

var Lit_304 *jrt.String = jrt.Intern("float")

var Lit_305 *jrt.String = jrt.Intern("unsigned long long")

var Lit_306 *jrt.String = jrt.Intern("unsigned long")

var Lit_307 *jrt.String = jrt.Intern("_Decimal64x")

var Lit_308 *jrt.String = jrt.Intern("_Float16")

var Lit_309 *jrt.String = jrt.Intern("_Decimal64")

var Lit_310 *jrt.String = jrt.Intern("long")

var Lit_311 *jrt.String = jrt.Intern("int")

var Lit_312 *jrt.String = jrt.Intern("long double")

var Lit_313 *jrt.String = jrt.Intern("_Float128x")

var Lit_314 *jrt.String = jrt.Intern("_Decimal128")

var Lit_315 *jrt.String = jrt.Intern("unsigned")

var Lit_316 *jrt.String = jrt.Intern("__int128")

var Lit_317 *jrt.String = jrt.Intern("short")

var Lit_318 *jrt.String = jrt.Intern("arbace.c.check$vectorize$fn__1876000230")

var Lit_319 *jrt.String = jrt.Intern("HI")

var Lit_320 *jrt.String = jrt.Intern("DF")

var Lit_321 *jrt.String = jrt.Intern("DI")

var Lit_322 *jrt.String = jrt.Intern("byte")

var Lit_323 *jrt.String = jrt.Intern("word")

var Lit_324 *jrt.String = jrt.Intern("SF")

var Lit_325 *jrt.String = jrt.Intern("TI")

var Lit_326 *jrt.String = jrt.Intern("SI")

var Lit_327 *jrt.String = jrt.Intern("QI")

var Lit_328 *jrt.String = jrt.Intern("pointer")

var Lit_329 *jrt.String = jrt.Intern("arbace.c.check$vectorize$fn__1876000239")

var Lit_330 *jrt.String = jrt.Intern("invalid vector type for attribute 'vector_size'")

var Lit_331 *jrt.String = jrt.Intern("mode")

var Lit_332 *jrt.String = jrt.Intern("vector_size")

var Lit_333 *jrt.String = jrt.Intern("arbace.c.check$vla_struct_QMARK_$fn__1876000326")

var Lit_334 *jrt.String = jrt.Intern("arbace.c.check$vm_type_QMARK_$fn__1876000321")

var Lit_335 *jrt.String = jrt.Intern("arbace.c.check$vm_type_QMARK_$fn__1876000323")

var Lit_336 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,dynamickn4,linekn6,columnkn4,filekn7,privatekn8,arglistsyn1,kkn3,tagyn6,Stringyn1,fyn1,ryn1,&yn4,bodykn1,kkn4,voidkn4,boolkn4,charkn3,intkn4,uintkn4,longkn5,ulongkn5,llongkn6,doublekn5,floatkn7,invalidkn7,nullptryn1,tyn1,nyn10,_Decimal32kn5,dec32yn11,long-doublekn7,ldoubleyn8,unsignedyn10,_Float128xkn9,float128xyn11,_Decimal128kn6,dec128yn13,unsigned-charkn5,ucharyn4,charyn13,unsigned-longyn8,_Float16kn7,float16yn11,_Decimal64xkn6,dec64xyn4,longyn6,doubleyn5,shortkn5,shortyn9,_Float32xkn8,float32xyn3,intyn18,unsigned-long-longkn6,ullongyn5,floatyn8,_Float32kn7,float32yn8,_Float64kn7,float64yn9,long-longyn9,_Float128kn8,float128yn9,_Float64xkn8,float64xyn4,voidyn11,signed-charkn5,scharyn5,_Boolyn8,__int128kn6,int128yn10,_Decimal64kn5,dec64yn6,__bf16kn4,bf16yn14,unsigned-shortkn6,ushortyn17,unsigned-__int128kn7,uint128yn1,qyn1,vkn8,declaredyn16,java.lang.Stringyn1,ayn1,byn4,bitsyn1,eyn1,xys1,c12,local-labelsys1,c3,varys1,c13,static-assertys1,c6,structys1,c5,unionys1,c4,enumys1,c7,declareys1,c7,typedefys1,c5,groupys1,c4,defnys1,c9,attr-declys1,c13,declare-specsys1,c7,includeys1,c14,expr-directiveys1,c9,directiveys1,c3,asmys1,c6,defineys1,c5,undefys1,c6,pragmayn3,gnuyn1,myn2,ksks1,c5,attrsks1,c10,decl-attrsks1,c11,after-attrsks1,c10,list-attrsks1,c14,decl-end-attrsks1,c9,def-attrsks1,c9,end-attrsks1,c9,gnu-attrsv11,arbace.core5,in-nsMyn14,arbace.c.checkm2,R0,s1792,The checker over C forms (doc/c/SPEC.md §11.2; doc/C23-SURVEY.md, C4, \"As built: C4\"): every\n  expression's type and constant value, the integer promotions and the usual arithmetic conversions\n  (6.3), lvalue, array and function conversions, null pointer constants, constant expressions and their\n  values (6.6: enumerators, sizeof, alignof, constexpr objects, case labels, array sizes), layout by the\n  SysV x86-64 psABI as gcc 15.2 lays out (sizes, alignments, members' offsets, bit-fields, packed,\n  aligned), linkage (6.2.2), arrays completed by their initializers, `auto`'s, `__auto_type`'s and\n  `typeof`'s types, `_Generic`'s selection, `_BitInt`. Arbace's own (CS8 (a)); cc's checker is its oracle\n  where it succeeds (bin/ci annotations, arbace.repr.c.annot).\n\n  `check-unit` checks a read's forms (arbace.repr.c/read-c's) and returns its errors (the reference's\n  errors the checker diagnoses: only those gcc 15.2 gives, as errors) and, when asked, the annotations\n  of every main-file item in tools/ccdump's types format. A header unit's forms are checked where their\n  c/include stands, without annotations. Moved from arbace/repr/c/ as arbace.c.check in C5 (CS90 (a)),\n  with ci's namespaces; `:results` gives ci's builder each form's result (CS95 (a)).\n\n  Types are maps: {:k KIND} for the base types (:void :bool :char :schar :uchar :short :ushort :int :uint\n  :long :ulong :llong :ullong :int128 :uint128 :float :double :ldouble and the other floating types),\n  {:k :bitint :n N :u bool}, {:k :complex :of T}, {:k :ptr :to T}, {:k :array :of T :n N-or-nil :vla bool},\n  {:k :fn :ret T :params [T] :variadic bool :proto bool}, {:k :struct|:union|:enum :rec R} (R a mutable\n  record of the tag: its members, layout, completeness), {:k :nullptr}, {:k :invalid}; qualifiers in :q.m2,R0,s1792,The checker over C forms (doc/c/SPEC.md §11.2; doc/C23-SURVEY.md, C4, \"As built: C4\"): every\n  expression's type and constant value, the integer promotions and the usual arithmetic conversions\n  (6.3), lvalue, array and function conversions, null pointer constants, constant expressions and their\n  values (6.6: enumerators, sizeof, alignof, constexpr objects, case labels, array sizes), layout by the\n  SysV x86-64 psABI as gcc 15.2 lays out (sizes, alignments, members' offsets, bit-fields, packed,\n  aligned), linkage (6.2.2), arrays completed by their initializers, `auto`'s, `__auto_type`'s and\n  `typeof`'s types, `_Generic`'s selection, `_BitInt`. Arbace's own (CS8 (a)); cc's checker is its oracle\n  where it succeeds (bin/ci annotations, arbace.repr.c.annot).\n\n  `check-unit` checks a read's forms (arbace.repr.c/read-c's) and returns its errors (the reference's\n  errors the checker diagnoses: only those gcc 15.2 gives, as errors) and, when asked, the annotations\n  of every main-file item in tools/ccdump's types format. A header unit's forms are checked where their\n  c/include stands, without annotations. Moved from arbace/repr/c/ as arbace.c.check in C5 (CS90 (a)),\n  with ci's namespaces; `:results` gives ci's builder each form's result (CS95 (a)).\n\n  Types are maps: {:k KIND} for the base types (:void :bool :char :schar :uchar :short :ushort :int :uint\n  :long :ulong :llong :ullong :int128 :uint128 :float :double :ldouble and the other floating types),\n  {:k :bitint :n N :u bool}, {:k :complex :of T}, {:k :ptr :to T}, {:k :array :of T :n N-or-nil :vla bool},\n  {:k :fn :ret T :params [T] :variadic bool :proto bool}, {:k :struct|:union|:enum :rec R} (R a mutable\n  record of the tag: its members, layout, completeness), {:k :nullptr}, {:k :invalid}; qualifiers in :q.R1,v11,arbace.core20,*warn-on-reflection*v14,arbace.c.check4,*cx*m8,R2,TR3,i30,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check6,*line*l0,m8,R2,TR3,i31,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check6,*unit*m8,R2,TR3,i34,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check11,*unit-info*m10,R2,TR3,i35,R4,i1,R5,s17,arbace/c/check.aeR0,s302,CS214 (R5): a delay of the unit being checked (*unit*) read from its file when it can be: {:ext the lines with `__extension__`\n  :pragma whether it has a `#pragma GCC system_header` line (review 031's finding F)}; read only when a pedwarn is judged. The\n  main file's ext lines are the cx's :ext-lines.v14,arbace.c.check12,*unit-line?*m10,R2,TR3,i39,R4,i1,R5,s17,arbace/c/check.aeR0,s218,CS214 (R5): whether *line* is the line of a form in its own unit's file (a reread unit's forms carry :line); the forms\n  read from C carry none in a unit, and *line* is then the line of the `#include` in the main file.v14,arbace.c.check13,*system-unit*m10,R2,TR3,i42,R4,i1,R5,s17,arbace/c/check.aeR0,s147,CS214 (R5): whether the unit being checked is a system header (its file under a directory of the host's search list):\n  gcc gives no pedwarn there.v14,arbace.c.check8,*switch*m8,R2,TR3,i45,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check2,cxm10,R6,TR7,L1,V1,R8,R3,i47,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check4,ann!m12,R6,TR7,L1,V1,Myn1,sm2,R9,R10,R0,s63,An annotation line of the item being checked (when annotating).R3,i49,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check5,feat!m12,R6,TR7,L1,V1,R8,R0,s161,A feature of the item being checked that cc's checker is known not to handle as gcc does (the classes\n  of bin/ci annotations' differences, arbace.repr.c.annot).R3,i58,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check4,err!m12,R6,TR7,L1,V1,Myn3,msgm2,R9,R10,R0,s55,An error of the reference's that the checker diagnoses.R3,i64,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check8,pedwarn!m12,R6,TR7,L1,V1,Myn3,msgm2,R9,R10,R0,s145,A pedwarn of gcc's, an error under -pedantic-errors (CS132): only when the file's options ask for that, and not\n  on a line with `__extension__`.R3,i71,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check7,line-ofm10,R6,TR7,L1,V1,R11,R3,i81,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check7,record!m12,R6,TR7,L1,V2,R11,R12,R0,s187,CS95 (a): the result of the form `f` (an expression's {:t :v :lv :bits ...}, a declarator's entry) in\n  the identity map of a check-unit asked for :results (ci's builder, arbace.c.build).R3,i83,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check7,at-linem10,R6,TR7,L1,V3,R11,R13,R14,R3,i91,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check7,std-numm12,R6,TR7,L1,V0,R0,s65,The file's standard as a year: 89, 99, 11, 17, 23 (and 94 as 89).R3,i94,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check4,c23?m10,R6,TR7,L1,V0,R3,i99,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check4,c99?m10,R6,TR7,L1,V0,R3,i100,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check12,pedwarn-c2y!m12,R6,TR7,L1,V1,Myn3,msgm2,R9,R10,R0,s94,A pedwarn about a C2y feature used in C23 (Wc23-c2y-compat; -Wno-c23-c2y-compat turns it off).R3,i102,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check10,bit-field?m12,R6,TR7,L1,V1,R12,R0,s248,An expression's result that designates a bit-field: a member access (an lvalue) of one. An assignment's or an increment's\n  result keeps the width for its promotions but is no lvalue, so sizeof, typeof and _Alignof take it (review 027's finding 7).R3,i110,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check6,t-voidm2,R15,R16,m6,R3,i116,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check6,t-boolm2,R15,R17,m6,R3,i117,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check6,t-charm2,R15,R18,m6,R3,i118,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check5,t-intm2,R15,R19,m6,R3,i119,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check6,t-uintm2,R15,R20,m6,R3,i120,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check6,t-longm2,R15,R21,m6,R3,i121,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check7,t-ulongm2,R15,R22,m6,R3,i122,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check7,t-llongm2,R15,R23,m6,R3,i123,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check8,t-doublem2,R15,R24,m6,R3,i124,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check7,t-floatm2,R15,R25,m6,R3,i125,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check9,t-invalidm2,R15,R26,m6,R3,i126,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check9,t-nullptrm2,R15,R27,m6,R3,i127,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check3,ptrm8,R7,L1,V1,R28,R3,i129,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check3,arrm8,R7,L1,V2,R28,R29,R3,i130,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check9,base-symsm60,R30,R31,R32,R33,R34,R20,R35,R36,R37,R38,R39,R40,R41,R18,R42,R22,R43,R44,R45,R46,R47,R21,R48,R24,R49,R50,R51,R52,R53,R19,R54,R55,R56,R25,R57,R58,R59,R60,R61,R23,R62,R63,R64,R65,R66,R16,R67,R68,R69,R17,R70,R71,R72,R73,R74,R75,R76,R77,R78,R79,m8,R6,TR3,i132,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check8,int-infom28,R17,V3,l1,Fl10,R18,V3,l8,Tl85,R68,V3,l8,Tl85,R40,V3,l8,Fl85,R50,V3,l16,Tl165,R77,V3,l16,Fl165,R19,V3,l32,Tl325,R20,V3,l32,Fl325,R21,V3,l64,Tl645,R22,V3,l64,Fl645,R23,V3,l64,Tl646,R55,V3,l64,Fl646,R71,V3,l128,Tl1285,R79,V3,l128,Fl1285,m8,R6,TR3,i140,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check10,float-rankm30,R44,l1,R75,l1,R25,l2,R58,l2,R24,l3,R60,l3,R52,l3,R33,l4,R65,l4,R63,l5,R36,l5,R31,l1,R73,l2,R38,l3,R46,l3,m8,R6,TR3,i146,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check9,float-tiem8,R6,TR3,i150,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check3,unqm8,R7,L1,V1,R28,R3,i154,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check4,qualm8,R7,L1,V2,R28,R80,R3,i155,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check5,qualsm8,R7,L1,V1,R28,R3,i156,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check12,char-signed?m10,R6,TR7,L1,V0,R3,i158,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check10,enum-underm10,R7,L1,V1,R28,R0,s45,An enumerated type's compatible integer type.R3,i160,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check9,int-type?m8,R7,L1,V1,R28,R3,i165,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check11,float-type?m8,R7,L1,V1,R28,R3,i166,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check13,complex-type?m8,R7,L1,V1,R28,R3,i167,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check11,arith-type?m8,R7,L1,V1,R28,R3,i168,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check9,ptr-type?m8,R7,L1,V1,R28,R3,i169,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check12,scalar-type?m8,R7,L1,V1,R28,R3,i170,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check12,record-type?m8,R7,L1,V1,R28,R3,i171,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check10,void-type?m8,R7,L1,V1,R28,R3,i172,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check8,int-bitsm10,R7,L1,V1,R28,R0,s54,An integer type's width and signedness: [bits signed].R3,i174,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check4,rankm10,R6,TR7,L1,V1,R28,R3,i183,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check4,wrapm10,R7,L1,V2,R81,R28,R0,s88,An integer value converted to the integer type `t` (two's complement, modulo its width).R3,i189,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check12,ldouble-sizem10,R6,TR7,L1,V0,R3,i202,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check7,size-ofm8,R82,TR3,i204,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check8,align-ofm8,R82,TR3,i204,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check16,complete-record!m8,R82,TR3,i204,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check4,vla?m8,R82,TR3,i204,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check11,bitint-sizem10,R6,TR7,L1,V1,R29,R3,i206,R4,i1,R5,s17,arbace/c/check.aem10,R7,L1,V1,R28,R0,s51,A type's size in bytes, or nil (incomplete, a VLA).R3,i208,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check9,align-of*m8,R82,TR3,i230,R4,i1,R5,s17,arbace/c/check.aem10,R7,L1,V1,R28,R0,s69,A type's alignment (a typedef's aligned attribute's when it has one).R3,i232,R4,i1,R5,s17,arbace/c/check.aem10,R6,TR7,L1,V1,R28,R3,i237,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check6,rec-ofm10,R6,TR7,L1,V1,R28,R3,i250,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check4,tstrm10,R7,L1,MV1,R28,m2,R9,R83,R0,s62,A type as tools/ccdump's types mode writes it (no qualifiers).R3,i252,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check14,*compat-depth*m8,R2,TR3,i293,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check11,compatible?m8,R82,TR3,i295,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check8,mcompat?m12,R6,TR7,L1,V2,R84,R85,R0,s187,Compatibility of two struct members' types (C23 6.2.7 with GNU's variable and zero-length arrays): tagless records by\n  their members, variable-length arrays by their elements, [] as [0].R3,i297,R4,i1,R5,s17,arbace/c/check.aem10,R7,L1,V2,R84,R85,R0,s48,Type compatibility (6.2.7), qualifiers compared.R3,i314,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check5,decaym10,R7,L1,V1,R28,R0,s51,Lvalue conversion's array and function conversions.R3,i354,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check7,promotem10,R7,L2,V1,R28,V2,R28,R86,R0,s63,The integer promotions (6.3.1.1), of a bit-field of `bits` too.R3,i362,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check11,unsigned-ofm10,R6,TR7,L1,V1,R28,R3,i379,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check8,float-ofm10,R6,TR7,L1,V1,R28,R3,i385,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check5,usualm10,R7,L1,V2,R84,R85,R0,s103,The usual arithmetic conversions (6.3.1.8) of two operands' types (promoted, bit-fields' widths given).R3,i387,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check11,push-scope!m10,R6,TR7,L1,V0,R3,i422,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check10,pop-scope!m10,R6,TR7,L1,V0,R3,i423,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check9,top-scopem10,R6,TR7,L1,V0,R3,i424,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check11,file-scope?m10,R6,TR7,L1,V0,R3,i425,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check10,with-scopem10,R6,TR7,L1,V2,R13,R14,R3,i427,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check6,lookupm12,R6,TR7,L1,V1,Myn1,nm2,R9,R10,R0,s57,The innermost declaration of the ordinary identifier `n`.R3,i430,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check10,lookup-tagm10,R6,TR7,L1,V1,Myn1,nm2,R9,R10,R3,i438,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check8,declare!m10,R6,TR7,L1,V2,Myn1,nm2,R9,R10,R87,R3,i444,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check13,file-declare!m10,R6,TR7,L1,V2,Myn1,nm2,R9,R10,R87,R3,i446,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check5,identm12,R6,TR7,L1,V1,R88,R0,s57,The C identifier a form names: a symbol, or (c/id \"...\").R3,i452,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check10,decl-headsS12,R89,R90,R91,R92,R93,R94,R95,R96,R97,R98,R99,R100,m8,R6,TR3,i460,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check15,directive-headsS7,R101,R102,R103,R104,R105,R106,R107,m8,R6,TR3,i463,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check10,attr-itemsm12,R6,TR7,L2,V1,R81,V2,R81,R108,R0,s234,The attributes of a metadata vector, each [name args parens ns gnu] (GNU's (__attribute__ a ...) spread): `parens`\n  when the attribute is written with an argument list (even an empty one), `ns` its prefix, `gnu` for the GNU spelling.R3,i468,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check8,attrs-ofm10,R6,TR7,L1,V3,R109,R13,R110,R3,i484,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check13,all-attr-keysV8,R111,R112,R113,R114,R115,R116,R117,R118,m8,R6,TR3,i486,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check2,exm8,R82,TR3,i488,R4,i1,R5,s17,arbace/c/check.ae")

var Lit_337 *jrt.String = jrt.Intern("arbace.c.check$eval1876000004$loading__1927001464__auto____1876000005")

var Lit_338 *jrt.String = jrt.Intern("arbace.c.check$eval1876000008$fn__1876000009")

var Lit_339 *jrt.String = jrt.Intern("arbace.c.check$fn__1876000014")

var Lit_340 *jrt.String = jrt.Intern("arbace.c.check$cx")

var Lit_341 *jrt.String = jrt.Intern("arbace.c.check$ann_BANG_")

var Lit_342 *jrt.String = jrt.Intern("arbace.c.check$feat_BANG_")

var Lit_343 *jrt.String = jrt.Intern("arbace.c.check$err_BANG_")

var Lit_344 *jrt.String = jrt.Intern("arbace.c.check$pedwarn_BANG_")

var Lit_345 *jrt.String = jrt.Intern("arbace.c.check$line_of")

var Lit_346 *jrt.String = jrt.Intern("arbace.c.check$record_BANG_")

var Lit_347 *jrt.String = jrt.Intern("arbace.c.check$at_line")

var Lit_348 *jrt.String = jrt.Intern("arbace.c.check$std_num")

var Lit_349 *jrt.String = jrt.Intern("arbace.c.check$c23_QMARK_")

var Lit_350 *jrt.String = jrt.Intern("arbace.c.check$c99_QMARK_")

var Lit_351 *jrt.String = jrt.Intern("arbace.c.check$pedwarn_c2y_BANG_")

var Lit_352 *jrt.String = jrt.Intern("arbace.c.check$bit_field_QMARK_")

var Lit_353 *jrt.String = jrt.Intern("arbace.c.check$ptr")

var Lit_354 *jrt.String = jrt.Intern("arbace.c.check$arr")

var Lit_355 *jrt.String = jrt.Intern("arbace.c.check$float_tie")

var Lit_356 *jrt.String = jrt.Intern("arbace.c.check$unq")

var Lit_357 *jrt.String = jrt.Intern("arbace.c.check$qual")

var Lit_358 *jrt.String = jrt.Intern("arbace.c.check$quals")

var Lit_359 *jrt.String = jrt.Intern("arbace.c.check$char_signed_QMARK_")

var Lit_360 *jrt.String = jrt.Intern("arbace.c.check$enum_under")

var Lit_361 *jrt.String = jrt.Intern("arbace.c.check$int_type_QMARK_")

var Lit_362 *jrt.String = jrt.Intern("arbace.c.check$float_type_QMARK_")

var Lit_363 *jrt.String = jrt.Intern("arbace.c.check$complex_type_QMARK_")

var Lit_364 *jrt.String = jrt.Intern("arbace.c.check$arith_type_QMARK_")

var Lit_365 *jrt.String = jrt.Intern("arbace.c.check$ptr_type_QMARK_")

var Lit_366 *jrt.String = jrt.Intern("arbace.c.check$scalar_type_QMARK_")

var Lit_367 *jrt.String = jrt.Intern("arbace.c.check$record_type_QMARK_")

var Lit_368 *jrt.String = jrt.Intern("arbace.c.check$void_type_QMARK_")

var Lit_369 *jrt.String = jrt.Intern("arbace.c.check$int_bits")

var Lit_370 *jrt.String = jrt.Intern("arbace.c.check$rank")

var Lit_371 *jrt.String = jrt.Intern("arbace.c.check$wrap")

var Lit_372 *jrt.String = jrt.Intern("arbace.c.check$ldouble_size")

var Lit_373 *jrt.String = jrt.Intern("arbace.c.check$bitint_size")

var Lit_374 *jrt.String = jrt.Intern("arbace.c.check$size_of")

var Lit_375 *jrt.String = jrt.Intern("arbace.c.check$align_of")

var Lit_376 *jrt.String = jrt.Intern("arbace.c.check$align_of_STAR_")

var Lit_377 *jrt.String = jrt.Intern("arbace.c.check$rec_of")

var Lit_378 *jrt.String = jrt.Intern("arbace.c.check$tstr")

var Lit_379 *jrt.String = jrt.Intern("arbace.c.check$mcompat_QMARK_")

var Lit_380 *jrt.String = jrt.Intern("arbace.c.check$compatible_QMARK_")

var Lit_381 *jrt.String = jrt.Intern("arbace.c.check$decay")

var Lit_382 *jrt.String = jrt.Intern("arbace.c.check$promote")

var Lit_383 *jrt.String = jrt.Intern("arbace.c.check$unsigned_of")

var Lit_384 *jrt.String = jrt.Intern("arbace.c.check$float_of")

var Lit_385 *jrt.String = jrt.Intern("arbace.c.check$usual")

var Lit_386 *jrt.String = jrt.Intern("arbace.c.check$push_scope_BANG_")

var Lit_387 *jrt.String = jrt.Intern("arbace.c.check$pop_scope_BANG_")

var Lit_388 *jrt.String = jrt.Intern("arbace.c.check$top_scope")

var Lit_389 *jrt.String = jrt.Intern("arbace.c.check$file_scope_QMARK_")

var Lit_390 *jrt.String = jrt.Intern("arbace.c.check$with_scope")

var Lit_391 *jrt.String = jrt.Intern("arbace.c.check$lookup")

var Lit_392 *jrt.String = jrt.Intern("arbace.c.check$lookup_tag")

var Lit_393 *jrt.String = jrt.Intern("arbace.c.check$declare_BANG_")

var Lit_394 *jrt.String = jrt.Intern("arbace.c.check$file_declare_BANG_")

var Lit_395 *jrt.String = jrt.Intern("arbace.c.check$ident")

var Lit_396 *jrt.String = jrt.Intern("arbace.c.check$attr_items")

var Lit_397 *jrt.String = jrt.Intern("arbace.c.check$attrs_of")

var Lit_398 *jrt.String = jrt.Intern("kn8,declaredkn4,linekn6,columnkn4,filekn7,privatekn8,arglistsyn1,mkn3,docyn1,vyn1,nyn11,enumerator?yn5,whereyn1,fyn4,kindyn1,tyn4,argsyn1,xyn3,tagyn1,ayn6,packedyn9,max-alignkn3,tagyn7,HashMapyn7,membersyn6,Stringkn7,dynamicyn4,hereyn8,unsignedyn2,msyn1,byn5,depthyn4,valsyn1,&kn2,asyn1,ryn1,dyn1,pyn4,eminyn4,emaxyn1,kyn20,java.math.BigDecimalkn5,floatkn7,float32kn6,doublekn7,float64kn8,float32xkn7,float16kn4,bf16yn5,partsyn3,eltyn1,syn2,opyn2,tayn2,tbyn1,<yn2,<=yn1,>yn2,>=yn2,!=yn2,==yn2,rayn2,rbyn2,uayn2,ubyn1,hyn5,arrowyn4,formyn3,rasyn2,ftkn5,dec64kn5,dec32kn6,dec64xkn6,dec128yn1,_yn2,tfyn2,etyn4,initv14,arbace.c.check9,const-intm8,R0,TR1,i488,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check10,check-typem8,R0,TR1,i488,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check10,parse-typem8,R0,TR1,i488,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check16,std-no-arg-attrsS6,s12,maybe_unuseds11,unsequenceds9,_Noreturns11,fallthroughs8,noreturns12,reproduciblem8,R4,TR1,i490,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check16,std-string-attrsS2,s9,nodiscards10,deprecatedm8,R4,TR1,i491,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check15,std-attr-check!m12,R4,TR5,L1,V1,R6,R7,s246,C23 6.7.13.2's attribute argument rules for the standard attributes written as [[...]]: those that take no\n  argument given a (possibly empty) argument list, deprecated and nodiscard given an empty list or anything but one\n  plain string literal.R1,i493,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check18,std-position-attrsS8,s12,maybe_unuseds9,nodiscards11,unsequenceds9,_Noreturns11,fallthroughs10,deprecateds8,noreturns12,reproduciblem8,R4,TR1,i511,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check13,fn-type-attrsS2,s11,unsequenceds12,reproduciblem8,R4,TR1,i512,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check9,std-namesm12,R4,TR5,L1,V1,R8,R7,s84,The standard (unprefixed, not GNU) attributes of a vector that have a position rule.R1,i514,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check8,ignored!m12,R4,TR5,L1,V1,R9,R7,s185,gcc's -Wattributes error for an attribute it ignores, under -pedantic-errors; `__extension__` on the line does not\n  silence it (CS150: gcc errs on `[[__extension__ vector_size (4)]]`).R1,i519,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check14,std-attr-misc!m12,R4,TR5,L1,V1,R8,R7,s234,CS150, the standard-syntax attributes `[[...]]` of an attribute vector under -pedantic-errors: any of them before C23\n  is a pedwarn (not on a line with `__extension__`), and an unprefixed one that is no standard attribute is ignored.R1,i525,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check10,tag-attrs!m12,R4,TR5,L1,V2,R8,R10,R7,s167,A struct, union or enum specifier's (or an enumerator's) attributes: noreturn applies to functions only; a\n  enumerator is no type, so nodiscard does not apply either.R1,i533,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check15,type-pos-attrs!m12,R4,TR5,L1,V2,R8,R11,R7,s167,Standard attributes written after a type (specifiers, an array declarator, a function declarator): ignored, but a\n  function declarator's reproducible and unsequenced.R1,i543,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check13,base-fn-type?m12,R4,TR5,L1,V1,R12,R7,s120,Whether the specifiers of a declaration whose type form is `f` give a function type: a typedef name of one, or a typeof.R1,i552,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check20,decl-position-attrs!m12,R4,TR5,L1,V3,R6,R13,R14,R7,s122,A declaration's attributes by where they stood, and the entity they stand with (`kind` :fn, :obj, :typedef, :member, ...).R1,i560,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check10,attr-args!m12,R4,TR5,L1,V1,R6,R7,s189,The arguments of the attributes in metadata `m` checked as expressions (cc's checker types them: an\n  identifier among them that names nothing, a parameter of the attribute's own, skipped).R1,i578,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check13,assoc-in-modem12,R4,TR5,L1,V1,R14,R7,s86,A type made by GNU's mode attribute, marked (its uses are cc's gap :cc-attr-mode too).R1,i592,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check9,vectorizem12,R4,TR5,L1,V2,R14,R6,R7,s156,A type whose attributes in `m` hold GNU's vector_size(N): the vector type of N bytes (read and checked,\n  out of eval and AOT by design, doc/c/SPEC.md §14).R1,i597,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check13,aligned-valuem12,R4,TR5,L1,V1,R15,R7,s87,The alignment an `aligned` attribute's arguments give (none: the target's largest, 16).R1,i627,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check4,big?m10,R4,TR5,L1,V1,R16,R1,i637,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check7,num-valm10,R4,TR5,L1,V1,R8,R1,i639,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check7,new-recm10,R4,TR5,L1,V2,R13,R17,R1,i644,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check8,align-upm10,R4,TR5,L1,V2,R9,R18,R1,i649,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check12,member-alignm12,R4,TR5,L1,V3,R6,R19,R20,R7,s106,A member's alignment: its type's (1 when packed), raised by its aligned attribute, capped by #pragma pack.R1,i651,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check7,layout!m12,R4,TR5,L1,V5,Myn1,rm2,R21,R22,R23,R13,R19,R20,R7,s95,Lays out the record `r`'s members [{:name :t :bits :align :packed}] as gcc 15.2 does on x86-64.R1,i659,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check6,memberm12,R4,TR5,L1,V2,R14,Myn1,nm2,R21,R24,R7,s99,The member `n` of the record type `t` (anonymous members' members too): {:t :off :bits ...} or nil.R1,i714,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check6,*base*m8,R25,TR1,i729,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check11,*auto-init*m10,R25,TR1,i731,R2,i1,R3,s17,arbace/c/check.aeR7,s103,Whether the initializer of a C23 `auto` object is being checked: a tag it declares is an error (CS152).v14,arbace.c.check7,tag-refm12,R4,TR5,L1,V3,R13,Myn3,tagm2,R21,R24,R26,R7,s95,The tag `kind tag` referenced, declared in the current scope when not visible (or when `here`).R1,i735,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check12,check-structm8,R0,TR1,i744,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check10,check-enumm8,R0,TR1,i744,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check17,spec-attrs-packedm10,R4,TR5,L1,V1,R6,R1,i746,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check12,bitint-widthm12,R4,TR5,L1,V2,R18,R27,R7,s182,The width of _BitInt(a) (6.7.3.1): gcc's errors for a width that is not positive, below 2 for the signed type, or\n  above BITINT_MAXWIDTH (x86-64: 65535), and the pedwarn before C23.R1,i748,R2,i1,R3,s17,arbace/c/check.aem10,R5,L1,V1,R12,R7,s145,A type form's type (§5.1); struct, union and enum definitions in it defined where they stand,\n  their annotations and their expressions' written.R1,i764,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check3,exim12,R4,TR5,L1,V1,R16,R7,s165,An expression that must be an integer constant expression's operand (a width, an alignment, an enumerator's value,\n  a case label, a designator): nullptr is not one.R1,i843,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check12,member-formsm12,R4,TR5,L1,V1,R28,R7,s86,A member list's members: [{:name :t :bits :align}] (anonymous members with :name nil).R1,i851,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check9,rec-same?m8,R0,TR1,i883,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check7,type-eqm12,R4,TR5,L1,V2,R18,R29,R7,s62,The same type (not just compatible): tagged types by identity.R1,i885,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check8,vm-type?m12,R4,TR5,L2,V1,R14,V2,R14,R30,R7,s139,Whether a type is variably modified: a variable-length array, a pointer to or array of one (a struct with such a member\n  too, to a depth).R1,i901,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check11,vla-struct?m10,R4,TR5,L2,V1,R14,V2,R14,R30,R1,i915,R2,i1,R3,s17,arbace/c/check.aem12,R4,TR5,L1,V2,Myn1,am2,R21,R22,Myn1,bm2,R21,R22,R7,s290,Whether the new definition `b` of a tag repeats the definition `a` (C23 6.2.7): the same members in order, with the\n  same names, types, widths and alignments. A definition with a variably modified member is never the same (CS152:\n  gcc's \"redefinition\" for `struct f { int a[n]; }` twice).R1,i924,R2,i1,R3,s17,arbace/c/check.aem12,R4,TR5,L1,V2,R12,R13,R7,s57,A struct or union type form: a reference or a definition.R1,i939,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check12,enum-type-ofm12,R4,TR5,L1,V1,R31,R7,s68,gcc's compatible type of an enumerated type from its values (§12.3).R1,i992,R2,i1,R3,s17,arbace/c/check.aem10,R4,TR5,L1,V1,R12,R1,i1003,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check3,resm10,R4,TR5,L1,V3,R14,R32,m2,R33,R6,R1,i1095,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check5,emit!m12,R4,TR5,L1,V1,R34,R7,s139,The annotation of an expression node (its type decayed, its integer value when constant; a bit-field\n  its type promoted, as cc writes it).R1,i1097,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check9,round-sigm12,R4,TR5,L1,V4,R35,R36,R37,R38,R7,s224,The double `d` rounded (half to even) to a binary format of `p` significant bits whose smallest normal exponent is `emin`\n  and largest `emax`: subnormals keep emin's quantum, a value past the largest finite one is infinite.R1,i1107,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check15,round-to-formatm12,R4,TR5,L1,V2,R35,R39,R7,s191,The double `d` rounded to the format of the floating kind `k` (review 031's finding A): float and _Float32 to float,\n  _Float16 to IEEE binary16, __bf16 to bfloat16; any other kind keeps `d`.R1,i1120,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check11,round-exactm12,R4,TR5,L1,V3,Myn1,xm2,R21,R40,R36,R37,R7,s329,The BigDecimal `x` rounded (half to even) to a binary format of `p` significant bits whose smallest normal exponent is\n  `emin` (subnormals keep that quantum), as an exact BigDecimal; no overflow rule (see `fits-binary?`). The binary exponent is\n  found exactly, however far `x` is from the double range (review 053's finding 4).R1,i1130,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check13,round-ldoublem12,R4,TR5,L1,V1,Myn1,xm2,R21,R40,R7,s99,The BigDecimal `x` rounded to x87's 64-bit significand (exponents down to -16382), as a BigDecimal.R1,i1151,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check5,ld-ofm12,R4,TR5,L1,V1,Myn1,xm2,R21,R40,R7,s176,A long double constant's exact value (`round-ldouble`), or nil when it rounds past x87's range (an infinity: gcc and clang\n  accept it, with a warning; review 057's finding 2).R1,i1156,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check14,binary-formatsm14,R41,V3,l24,l-126,l127,R42,V3,l24,l-126,l127,R43,V3,l53,l-1022,l1023,R44,V3,l53,l-1022,l1023,R45,V3,l53,l-1022,l1023,R46,V3,l11,l-14,l15,R47,V3,l8,l-126,l127,m8,R4,TR1,i1163,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check12,fits-binary?m12,R4,TR5,L1,V2,Myn1,xm2,R21,R40,R39,R7,s125,Whether the exact decimal `x` is a value of the binary kind `k`: rounding it to the format changes nothing, and it is finite.R1,i1168,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check9,round-bigm12,R4,TR5,L1,V2,Myn1,xm2,R21,R40,R39,R7,s120,The exact decimal `x` rounded once to the binary kind `k` (half to even; infinite past the format's range), as a double.R1,i1176,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check14,float-of-exactm12,R4,TR5,L1,V1,Myn1,xm2,R21,R40,R7,s225,The float nearest the exact decimal `x`, as a double (infinite past float's range): a _Float16 or __bf16 constant's value\n  where, as in gcc on x86-64 (FLT_EVAL_METHOD 0), they are evaluated in float (review 053's finding 1).R1,i1185,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check9,eval-typem12,R4,TR5,L1,V1,R14,R7,s212,The type an arithmetic operation on `t` is evaluated in: _Float16 and __bf16 operate in float (C23 Annex H, FLT_EVAL_METHOD 0),\n  the result keeping the type and the excess precision until a conversion rounds it.R1,i1194,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check8,conv-valm12,R4,TR5,L1,V2,R8,R14,R7,s33,A constant converted to type `t`.R1,i1200,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check8,lit-typem12,R4,TR5,L1,V1,R16,R7,s37,A bare literal's type and value (§8).R1,i1220,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check15,byte-string-lenm10,R4,TR5,L1,V1,R48,R1,i1235,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check15,code-unit-countm10,R4,TR5,L1,V2,R49,R50,R1,i1238,R2,i1,R3,s17,arbace/c/check.aem8,R0,TR1,i1248,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check10,check-initm8,R0,TR1,i1248,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check12,call-builtinm8,R0,TR1,i1248,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check17,check-block-itemsm8,R0,TR1,i1248,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check17,binary-index-typem8,R0,TR1,i1248,R2,i1,R3,s17,arbace/c/check.aem8,R0,TR1,i1248,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check12,arith-resultm10,R4,TR5,L1,V3,R51,R52,R53,R1,i1250,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check7,cmp-opsS6,R54,R55,R56,R57,R58,R59,m8,R4,TR1,i1253,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check6,int-opm12,R4,TR5,L1,V4,R51,R18,R29,R14,R7,s28,An integer operator's value.R1,i1255,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check8,float-opm10,R4,TR5,L1,V3,R51,R18,R29,R1,i1272,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check7,cmp-valm10,R4,TR5,L1,V3,R51,R18,R29,R1,i1277,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check11,null-const?m10,R4,TR5,L1,V1,R34,R1,i1283,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check15,null-const-npc?m12,R4,TR5,L1,V1,R34,R7,s148,A null pointer constant for nullptr_t conversions: an integer constant expression of value 0 without a floating\n  conversion in it, or a (void *) 0.R1,i1288,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check6,binarym12,R4,TR5,L1,V3,R51,R60,R61,R7,s54,A binary operator's result from its operands' results.R1,i1294,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check8,unq-elemm12,R4,TR5,L1,V1,R14,R7,s97,A type without the qualifiers of its own or of an array's elements (a pointer's target, 6.7.4.3).R1,i1374,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check9,int-classm8,R0,TR1,i1379,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check23,compatible-ptr-targets?m12,R4,TR5,L1,V2,R62,R63,R7,s116,Pointer targets compatible but for the integer classes gcc only warns about (signedness), as `ptr-conv!` takes them.R1,i1381,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check9,cond-typem12,R4,TR5,L1,V2,R60,R61,R7,s31,The type of c ? a : b (6.5.15).R1,i1390,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check9,callee-fnm10,R4,TR5,L1,V1,R14,R1,i1423,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check12,implicit-fn!m10,R4,TR5,L1,V1,Myn1,nm2,R21,R24,R1,i1429,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check9,head-namem10,R4,TR5,L1,V1,R64,R1,i1435,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check10,ident-exprm10,R4,TR5,L1,V1,Myn1,nm2,R21,R24,R1,i1437,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check10,deref-typem10,R4,TR5,L1,V1,R14,R1,i1453,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check9,member-ofm10,R4,TR5,L1,V3,R34,Myn1,mm2,R21,R24,R65,R1,i1457,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check13,builtin-typesm8,R4,TR1,i1472,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check9,ptr-conv!m8,R0,TR1,i1487,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check16,constexpr-check!m8,R0,TR1,i1487,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check16,attr-decl-check!m8,R0,TR1,i1487,R2,i1,R3,s17,arbace/c/check.aem8,R0,TR1,i1487,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check4,callm12,R4,TR5,L1,V3,R12,R15,R66,R7,s60,A call's result: the callee's result, its arguments checked.R1,i1489,R2,i1,R3,s17,arbace/c/check.aem10,R4,TR5,L1,V3,Myn1,bm2,R21,R24,R67,R68,R1,i1522,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check9,dec-kindsS4,R69,R70,R71,R72,m8,R4,TR1,i1545,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check8,lit-formm12,R4,TR5,L1,V1,V3,R73,R74,R8,R7,s32,(lit T v): a constant of type T.R1,i1547,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check16,incomplete-type?m12,R4,TR5,L1,V1,R14,R7,s76,An array of unknown size (not variable-length) or a record not yet complete.R1,i1573,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check10,sizeof-resm10,R4,TR5,L1,V1,R14,R1,i1582,R2,i1,R3,s17,arbace/c/check.aem10,R4,TR5,L1,V1,R14,R1,i1586,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check14,generic-selectm10,R4,TR5,L1,V1,R12,R1,i1588,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check10,init-countm12,R4,TR5,L1,V2,R75,R76,R7,s83,The number of elements an initializer gives an array of element type `et` (6.7.11).R1,i1616,R2,i1,R3,s17,arbace/c/check.aem8,R0,TR1,i1664,R2,i1,R3,s17,arbace/c/check.aem12,R4,TR5,L2,V1,R76,V2,R76,R75,R7,s231,An initializer's expressions checked (its values' types are the object's, converted). `et`, the element type of a\n  one-dimensional array of scalars, has the plain elements converted as an initialization (nullptr_t's rules, CS141).R1,i1666,R2,i1,R3,s17,arbace/c/check.ae")

var Lit_399 *jrt.String = jrt.Intern("arbace.c.check$std_attr_check_BANG_")

var Lit_400 *jrt.String = jrt.Intern("arbace.c.check$std_names")

var Lit_401 *jrt.String = jrt.Intern("arbace.c.check$ignored_BANG_")

var Lit_402 *jrt.String = jrt.Intern("arbace.c.check$std_attr_misc_BANG_")

var Lit_403 *jrt.String = jrt.Intern("arbace.c.check$tag_attrs_BANG_")

var Lit_404 *jrt.String = jrt.Intern("arbace.c.check$type_pos_attrs_BANG_")

var Lit_405 *jrt.String = jrt.Intern("arbace.c.check$base_fn_type_QMARK_")

var Lit_406 *jrt.String = jrt.Intern("arbace.c.check$decl_position_attrs_BANG_")

var Lit_407 *jrt.String = jrt.Intern("arbace.c.check$attr_args_BANG_")

var Lit_408 *jrt.String = jrt.Intern("arbace.c.check$assoc_in_mode")

var Lit_409 *jrt.String = jrt.Intern("arbace.c.check$vectorize")

var Lit_410 *jrt.String = jrt.Intern("arbace.c.check$aligned_value")

var Lit_411 *jrt.String = jrt.Intern("arbace.c.check$big_QMARK_")

var Lit_412 *jrt.String = jrt.Intern("arbace.c.check$num_val")

var Lit_413 *jrt.String = jrt.Intern("arbace.c.check$new_rec")

var Lit_414 *jrt.String = jrt.Intern("arbace.c.check$align_up")

var Lit_415 *jrt.String = jrt.Intern("arbace.c.check$member_align")

var Lit_416 *jrt.String = jrt.Intern("arbace.c.check$layout_BANG_")

var Lit_417 *jrt.String = jrt.Intern("arbace.c.check$member")

var Lit_418 *jrt.String = jrt.Intern("arbace.c.check$tag_ref")

var Lit_419 *jrt.String = jrt.Intern("arbace.c.check$spec_attrs_packed")

var Lit_420 *jrt.String = jrt.Intern("arbace.c.check$bitint_width")

var Lit_421 *jrt.String = jrt.Intern("arbace.c.check$parse_type")

var Lit_422 *jrt.String = jrt.Intern("arbace.c.check$exi")

var Lit_423 *jrt.String = jrt.Intern("arbace.c.check$member_forms")

var Lit_424 *jrt.String = jrt.Intern("arbace.c.check$type_eq")

var Lit_425 *jrt.String = jrt.Intern("arbace.c.check$vm_type_QMARK_")

var Lit_426 *jrt.String = jrt.Intern("arbace.c.check$vla_struct_QMARK_")

var Lit_427 *jrt.String = jrt.Intern("arbace.c.check$rec_same_QMARK_")

var Lit_428 *jrt.String = jrt.Intern("arbace.c.check$check_struct")

var Lit_429 *jrt.String = jrt.Intern("arbace.c.check$enum_type_of")

var Lit_430 *jrt.String = jrt.Intern("arbace.c.check$check_enum")

var Lit_431 *jrt.String = jrt.Intern("arbace.c.check$res")

var Lit_432 *jrt.String = jrt.Intern("arbace.c.check$emit_BANG_")

var Lit_433 *jrt.String = jrt.Intern("arbace.c.check$round_sig")

var Lit_434 *jrt.String = jrt.Intern("arbace.c.check$round_to_format")

var Lit_435 *jrt.String = jrt.Intern("arbace.c.check$round_exact")

var Lit_436 *jrt.String = jrt.Intern("arbace.c.check$round_ldouble")

var Lit_437 *jrt.String = jrt.Intern("arbace.c.check$ld_of")

var Lit_438 *jrt.String = jrt.Intern("arbace.c.check$fits_binary_QMARK_")

var Lit_439 *jrt.String = jrt.Intern("arbace.c.check$round_big")

var Lit_440 *jrt.String = jrt.Intern("arbace.c.check$float_of_exact")

var Lit_441 *jrt.String = jrt.Intern("arbace.c.check$eval_type")

var Lit_442 *jrt.String = jrt.Intern("arbace.c.check$conv_val")

var Lit_443 *jrt.String = jrt.Intern("arbace.c.check$lit_type")

var Lit_444 *jrt.String = jrt.Intern("arbace.c.check$byte_string_len")

var Lit_445 *jrt.String = jrt.Intern("arbace.c.check$code_unit_count")

var Lit_446 *jrt.String = jrt.Intern("arbace.c.check$arith_result")

var Lit_447 *jrt.String = jrt.Intern("arbace.c.check$int_op")

var Lit_448 *jrt.String = jrt.Intern("arbace.c.check$float_op")

var Lit_449 *jrt.String = jrt.Intern("arbace.c.check$cmp_val")

var Lit_450 *jrt.String = jrt.Intern("arbace.c.check$null_const_QMARK_")

var Lit_451 *jrt.String = jrt.Intern("arbace.c.check$null_const_npc_QMARK_")

var Lit_452 *jrt.String = jrt.Intern("arbace.c.check$binary")

var Lit_453 *jrt.String = jrt.Intern("arbace.c.check$unq_elem")

var Lit_454 *jrt.String = jrt.Intern("arbace.c.check$compatible_ptr_targets_QMARK_")

var Lit_455 *jrt.String = jrt.Intern("arbace.c.check$cond_type")

var Lit_456 *jrt.String = jrt.Intern("arbace.c.check$callee_fn")

var Lit_457 *jrt.String = jrt.Intern("arbace.c.check$implicit_fn_BANG_")

var Lit_458 *jrt.String = jrt.Intern("arbace.c.check$head_name")

var Lit_459 *jrt.String = jrt.Intern("arbace.c.check$ident_expr")

var Lit_460 *jrt.String = jrt.Intern("arbace.c.check$deref_type")

var Lit_461 *jrt.String = jrt.Intern("arbace.c.check$member_of")

var Lit_462 *jrt.String = jrt.Intern("__builtin_isnormal")

var Lit_463 *jrt.String = jrt.Intern("__builtin_c23_va_start")

var Lit_464 *jrt.String = jrt.Intern("__builtin_classify_type")

var Lit_465 *jrt.String = jrt.Intern("__builtin_unreachable")

var Lit_466 *jrt.String = jrt.Intern("__builtin_parityll")

var Lit_467 *jrt.String = jrt.Intern("__builtin_ffsl")

var Lit_468 *jrt.String = jrt.Intern("__builtin_isnan")

var Lit_469 *jrt.String = jrt.Intern("__builtin_popcount")

var Lit_470 *jrt.String = jrt.Intern("__builtin_trap")

var Lit_471 *jrt.String = jrt.Intern("__builtin_memmove")

var Lit_472 *jrt.String = jrt.Intern("__builtin_ctzll")

var Lit_473 *jrt.String = jrt.Intern("__builtin_parity")

var Lit_474 *jrt.String = jrt.Intern("__builtin_prefetch")

var Lit_475 *jrt.String = jrt.Intern("__builtin_parityl")

var Lit_476 *jrt.String = jrt.Intern("__builtin_malloc")

var Lit_477 *jrt.String = jrt.Intern("__builtin_signbit")

var Lit_478 *jrt.String = jrt.Intern("__builtin_ffs")

var Lit_479 *jrt.String = jrt.Intern("__builtin_popcountll")

var Lit_480 *jrt.String = jrt.Intern("__builtin_islessequal")

var Lit_481 *jrt.String = jrt.Intern("__builtin_popcountl")

var Lit_482 *jrt.String = jrt.Intern("__builtin_clzll")

var Lit_483 *jrt.String = jrt.Intern("__builtin_memset")

var Lit_484 *jrt.String = jrt.Intern("__builtin_clrsbll")

var Lit_485 *jrt.String = jrt.Intern("__builtin_alloca")

var Lit_486 *jrt.String = jrt.Intern("__builtin_return_address")

var Lit_487 *jrt.String = jrt.Intern("__builtin_clrsb")

var Lit_488 *jrt.String = jrt.Intern("__builtin_isinf")

var Lit_489 *jrt.String = jrt.Intern("__builtin_ffsll")

var Lit_490 *jrt.String = jrt.Intern("__builtin_isless")

var Lit_491 *jrt.String = jrt.Intern("__builtin_islessgreater")

var Lit_492 *jrt.String = jrt.Intern("__builtin_isinf_sign")

var Lit_493 *jrt.String = jrt.Intern("__builtin_abort")

var Lit_494 *jrt.String = jrt.Intern("__builtin_frame_address")

var Lit_495 *jrt.String = jrt.Intern("__builtin_isfinite")

var Lit_496 *jrt.String = jrt.Intern("__builtin_strlen")

var Lit_497 *jrt.String = jrt.Intern("__builtin_fpclassify")

var Lit_498 *jrt.String = jrt.Intern("__builtin_va_end")

var Lit_499 *jrt.String = jrt.Intern("__builtin_memcpy")

var Lit_500 *jrt.String = jrt.Intern("__builtin_clrsbl")

var Lit_501 *jrt.String = jrt.Intern("__builtin_assume_aligned")

var Lit_502 *jrt.String = jrt.Intern("__builtin_exit")

var Lit_503 *jrt.String = jrt.Intern("__builtin_isgreater")

var Lit_504 *jrt.String = jrt.Intern("__builtin_va_start")

var Lit_505 *jrt.String = jrt.Intern("__builtin_isgreaterequal")

var Lit_506 *jrt.String = jrt.Intern("arbace.c.check$call")

var Lit_507 *jrt.String = jrt.Intern("arbace.c.check$call_builtin")

var Lit_508 *jrt.String = jrt.Intern("arbace.c.check$lit_form")

var Lit_509 *jrt.String = jrt.Intern("arbace.c.check$incomplete_type_QMARK_")

var Lit_510 *jrt.String = jrt.Intern("arbace.c.check$sizeof_res")

var Lit_511 *jrt.String = jrt.Intern("arbace.c.check$vla_QMARK_")

var Lit_512 *jrt.String = jrt.Intern("arbace.c.check$generic_select")

var Lit_513 *jrt.String = jrt.Intern("arbace.c.check$init_count")

var Lit_514 *jrt.String = jrt.Intern("arbace.c.check$check_init")

var Lit_515 *jrt.String = jrt.Intern("kn7,privatekn8,arglistsyn1,tkn3,dockn4,linekn6,columnkn4,filekn4,boolkn4,charkn5,scharkn5,ucharkn5,shortkn6,ushortkn3,intkn4,uintkn4,longkn5,ulongkn5,llongkn6,ullongkn6,int128kn4,i128kn7,uint128yn3,dstyn2,rsyn3,ctxyn2,rlyn2,rryn1,pyn2,mskn8,declaredyn1,fyn2,rayn2,riyn1,mkn3,tagyn6,Stringyn3,fn?yn5,paramyn1,lyn4,inityn3,oldyn3,newyn4,kindkn5,dec32kn5,dec64kn6,dec128kn6,dec64xyn20,java.math.BigDecimalyn1,kyn6,strictyn2,pryn2,ekyn7,dec-objyn1,ryn2,psyn3,retyn4,textyn1,xyn2,bvkn7,dynamicyn4,nextyn5,whereyn1,syn5,itemsyn1,eyn4,baseyn2,csyn3,offyn5,formsyn3,stdyn4,optsyn2,rdyn8,builtinsyn1,&kn4,keysyn8,annotateyn12,ldouble-sizeyn13,unsigned-charyn7,resultsyn8,pedanticyn9,ext-linesyn8,sys-dirsyn5,notesyn13,no-c2y-compatyn13,no-c23-compatyn12,exec-charsetyn10,permissivev14,arbace.c.check4,unq*m12,R0,TR1,L1,V1,R2,R3,s78,A type without the qualifiers at its top (and, for an array, on its elements).R4,i1685,R5,i1,R6,s17,arbace/c/check.aem28,R7,R7,R8,R8,R9,R8,R10,R8,R11,R11,R12,R11,R13,R13,R14,R13,R15,R15,R16,R15,R17,R17,R18,R17,R19,R20,R21,R20,m8,R0,TR4,i1690,R5,i1,R6,s17,arbace/c/check.aem12,R0,TR1,L1,V3,R22,R23,R24,R3,s331,6.5.17.2 / 6.5.2.2 / 6.8.7.4: the pointer result `rs` converted to the pointer type `dst` in `ctx` (assignment,\n  initialization, argument or return): gcc 14+ gives an error for pointee types that are not compatible (types of\n  one integer class differing in signedness are only a warning), and a pedwarn for a discarded qualifier.R4,i1694,R5,i1,R6,s17,arbace/c/check.aev14,arbace.c.check12,assign-checkm10,R0,TR1,L1,V2,R25,R26,R4,i1726,R5,i1,R6,s17,arbace/c/check.aev14,arbace.c.check12,nested-arrowm10,R0,TR1,L1,V2,R27,R28,R4,i1730,R5,i1,R6,s17,arbace/c/check.aev14,arbace.c.check3,ex*m8,R29,TR4,i1734,R5,i1,R6,s17,arbace/c/check.aem10,R1,L1,V1,R30,R3,s78,An expression form's result, its annotations written (and recorded, CS95 (a)).R4,i1736,R5,i1,R6,s17,arbace/c/check.aem10,R0,TR1,L1,V1,R30,R4,i1741,R5,i1,R6,s17,arbace/c/check.aem10,R0,TR1,L1,V2,R31,R32,R4,i1901,R5,i1,R6,s17,arbace/c/check.aem10,R1,L1,V1,R30,R3,s77,An integer constant expression's value (its annotations not written), or nil.R4,i1907,R5,i1,R6,s17,arbace/c/check.aev14,arbace.c.check7,storagem10,R0,TR1,L1,V1,R33,R4,i1919,R5,i1,R6,s17,arbace/c/check.aev14,arbace.c.check10,linkage-ofm12,R0,TR1,L1,V4,Myn1,nm2,R34,R35,R33,R36,R37,R3,s46,An identifier's linkage (6.2.2): :x, :i or :n.R4,i1922,R5,i1,R6,s17,arbace/c/check.aev14,arbace.c.check5,lnamem10,R0,TR1,L1,V1,R38,R4,i1934,R5,i1,R6,s17,arbace/c/check.aev14,arbace.c.check14,complete-arraym10,R0,TR1,L1,V2,R2,R39,R4,i1936,R5,i1,R6,s17,arbace/c/check.aev14,arbace.c.check9,compositem12,R0,TR1,L1,V2,R40,R41,R3,s98,The composite of a redeclaration's type with the earlier one's (6.2.7): arrays' sizes, prototypes.R4,i1941,R5,i1,R6,s17,arbace/c/check.aev14,arbace.c.check15,declare-object!m12,R0,TR1,L1,V6,Myn1,nm2,R34,R35,R2,R33,R42,R39,R37,R3,s78,A declared object or function: entered in its scope, its d annotation written.R4,i1949,R5,i1,R6,s17,arbace/c/check.aev14,arbace.c.check10,auto-type?m10,R0,TR1,L1,V1,R33,R4,i1988,R5,i1,R6,s17,arbace/c/check.aev14,arbace.c.check12,string-bytesm12,R0,TR1,L1,V1,R39,R3,s104,The bytes of a string form's value and whether it is a u8 literal: [bytes u8?], or nil for another form.R4,i1991,R5,i1,R6,s17,arbace/c/check.aev14,arbace.c.check10,dec-limitsm8,R43,V3,l7,l-101,l90,R44,V3,l16,l-398,l369,R45,V3,l34,l-6176,l6111,R46,V3,l34,l-6176,l6111,m8,R0,TR4,i2005,R5,i1,R6,s17,arbace/c/check.aev14,arbace.c.check9,round-decm12,R0,TR1,L1,V2,Myn1,xm2,R34,R47,R48,R3,s118,The decimal `x` rounded (half to even) to the digits of the decimal format `k`; `x` itself for a kind the table lacks.R4,i2009,R5,i1,R6,s17,arbace/c/check.aev14,arbace.c.check9,dec-fits?m12,R0,TR1,L1,V3,Myn1,xm2,R34,R47,R48,R49,R3,s247,Whether the decimal `x` is a value of the format `k`. A constant of a decimal type (`strict`) must keep its coefficient and\n  quantum; a value of another kind may be written with the trailing zeros stripped and its exponent raised to the format's.R4,i2016,R5,i1,R6,s17,arbace/c/check.aev14,arbace.c.check19,constexpr-float-badm12,R0,TR1,L1,V3,R50,R51,R52,R3,s355,CS174 (b), C23 6.7.2: the message when the constexpr floating (or decimal) object of element kind `ek` cannot hold the\n  initializer's part `pr` exactly, else nil: a binary object given a decimal value, a signaling NaN of another type, a value\n  float cannot hold, an integer beyond the significand, a decimal beyond the format's digits and quantum range.R4,i2028,R5,i1,R6,s17,arbace/c/check.aem12,R0,TR1,L1,V3,R2,R39,R53,R3,s227,C23 6.7.2's constraints on a constexpr object's initializer that gcc diagnoses: a floating or complex value for an\n  integer object, and a string whose elements the element type cannot represent (a plain literal's are `char`s).R4,i2069,R5,i1,R6,s17,arbace/c/check.aev14,arbace.c.check9,check-varm12,R0,TR1,L1,V1,R30,R3,s19,(c/var name init?).R4,i2095,R5,i1,R6,s17,arbace/c/check.aev14,arbace.c.check9,params-ofm12,R0,TR1,L1,V2,R54,R55,R3,s78,A definition's parameter vector: [[name type meta] ...] and the function type.R4,i2148,R5,i1,R6,s17,arbace/c/check.aev14,arbace.c.check10,check-stmtm8,R29,TR4,i2168,R5,i1,R6,s17,arbace/c/check.aev14,arbace.c.check13,asm-operands!m12,R0,TR1,L1,V1,R56,R3,s230,CS160: an asm operand with a register constraint (`\"r\"`, `\"+r\"`, ...) that is an object of a _BitInt wider than a\n  register pair (128 bits) has no register to live in: gcc's \"impossible constraint\". The statement is kept as text.R4,i2170,R5,i1,R6,s17,arbace/c/check.aev14,arbace.c.check10,check-defnm10,R0,TR1,L1,V1,R30,R4,i2181,R5,i1,R6,s17,arbace/c/check.aev14,arbace.c.check13,check-declarem10,R0,TR1,L1,V1,R30,R4,i2206,R5,i1,R6,s17,arbace/c/check.aev14,arbace.c.check13,check-typedefm10,R0,TR1,L1,V1,R30,R4,i2217,R5,i1,R6,s17,arbace/c/check.aev14,arbace.c.check10,check-declm10,R1,L1,V1,R30,R3,s24,A declaration form (§6).R4,i2234,R5,i1,R6,s17,arbace/c/check.aev14,arbace.c.check10,decl-form?m10,R0,TR1,L1,V1,R57,R4,i2262,R5,i1,R6,s17,arbace/c/check.aev14,arbace.c.check12,let-bindingsm12,R0,TR1,L1,V1,R58,R3,s54,A let's binding vector checked into the current scope.R4,i2264,R5,i1,R6,s17,arbace/c/check.aev14,arbace.c.check11,*in-switch*m8,R59,TR4,i2274,R5,i1,R6,s17,arbace/c/check.aem12,R0,TR1,L1,V3,R30,R60,R61,R3,s221,An attribute declaration `[[...]];` (C23 6.7.13.1): the standard attributes in it are ignored (a pedwarn), except\n  fallthrough, which is an error at top level, outside a switch and where no case or default label follows.R4,i2276,R5,i1,R6,s17,arbace/c/check.aev14,arbace.c.check11,stmt-attrs!m12,R0,TR1,L1,V1,R62,R3,s179,The standard attributes a statement or label stood with (CS140): ignored on a statement, and on a label for\n  deprecated and fallthrough; nodiscard and noreturn apply to no label.R4,i2293,R5,i1,R6,s17,arbace/c/check.aem12,R0,TR1,L1,V1,R63,R3,s95,A statement list; the result of its last expression statement (a statement expression's value).R4,i2306,R5,i1,R6,s17,arbace/c/check.aev14,arbace.c.check9,cond-exprm10,R0,TR1,L1,V1,R64,R4,i2316,R5,i1,R6,s17,arbace/c/check.aem10,R1,L1,V1,R62,R3,s51,A statement form; an expression statement's result.R4,i2318,R5,i1,R6,s17,arbace/c/check.aev14,arbace.c.check12,pragma-pack!m12,R0,TR1,L1,V1,R30,R3,s49,#pragma pack's state from a c/pragma form's text.R4,i2388,R5,i1,R6,s17,arbace/c/check.aev14,arbace.c.check9,check-topm8,R29,TR4,i2400,R5,i1,R6,s17,arbace/c/check.aev14,arbace.c.check6,sys-atm12,R0,TR1,L1,V3,R65,R66,R67,R3,s349,queue 136 (review 130's findings 2, 3): a header form's system status: `base` (its file's entry's) as the preprocessor's\n  changes `cs` of its file ([[off system?] ...] in offset order: a `#pragma GCC system_header`, a linemarker) before the form's\n  offset `off` leave it (libcpp: a pragma or a linemarker changes the status from the next line on).R4,i2402,R5,i1,R6,s17,arbace/c/check.aev14,arbace.c.check11,check-formsm10,R0,TR1,L1,V1,R68,R4,i2411,R5,i1,R6,s17,arbace/c/check.aem10,R1,L1,V1,R30,R3,s27,A top-level form of a unit.R4,i2414,R5,i1,R6,s17,arbace/c/check.aev14,arbace.c.check6,new-cxm10,R0,TR1,L1,V2,R69,R70,R4,i2484,R5,i1,R6,s17,arbace/c/check.aev14,arbace.c.check10,check-unitm10,R1,L1,V5,R71,R69,R72,R73,m2,R74,V13,R75,R76,R77,R78,R79,R80,R81,R65,R82,R83,R84,R85,R86,R3,s221,Checks a read (arbace.repr.c/read-c's {:forms :units}) at the standard `std` (a keyword), the\n  builtins' forms `builtins` declared first: {:errors [...] :items [[line [annotation...]] ...]} (the\n  items when `annotate`).R4,i2490,R5,i1,R6,s17,arbace/c/check.ae")

var Lit_516 *jrt.String = jrt.Intern("arbace.c.check$unq_STAR_")

var Lit_517 *jrt.String = jrt.Intern("arbace.c.check$ptr_conv_BANG_")

var Lit_518 *jrt.String = jrt.Intern("arbace.c.check$assign_check")

var Lit_519 *jrt.String = jrt.Intern("arbace.c.check$nested_arrow")

var Lit_520 *jrt.String = jrt.Intern("arbace.c.check$ex")

var Lit_521 *jrt.String = jrt.Intern("arbace.c.check$ex_STAR_")

var Lit_522 *jrt.String = jrt.Intern("arbace.c.check$binary_index_type")

var Lit_523 *jrt.String = jrt.Intern("arbace.c.check$const_int")

var Lit_524 *jrt.String = jrt.Intern("arbace.c.check$storage")

var Lit_525 *jrt.String = jrt.Intern("arbace.c.check$linkage_of")

var Lit_526 *jrt.String = jrt.Intern("arbace.c.check$lname")

var Lit_527 *jrt.String = jrt.Intern("arbace.c.check$complete_array")

var Lit_528 *jrt.String = jrt.Intern("arbace.c.check$composite")

var Lit_529 *jrt.String = jrt.Intern("arbace.c.check$declare_object_BANG_")

var Lit_530 *jrt.String = jrt.Intern("arbace.c.check$auto_type_QMARK_")

var Lit_531 *jrt.String = jrt.Intern("arbace.c.check$string_bytes")

var Lit_532 *jrt.String = jrt.Intern("arbace.c.check$round_dec")

var Lit_533 *jrt.String = jrt.Intern("arbace.c.check$dec_fits_QMARK_")

var Lit_534 *jrt.String = jrt.Intern("arbace.c.check$constexpr_float_bad")

var Lit_535 *jrt.String = jrt.Intern("arbace.c.check$constexpr_check_BANG_")

var Lit_536 *jrt.String = jrt.Intern("arbace.c.check$check_var")

var Lit_537 *jrt.String = jrt.Intern("arbace.c.check$params_of")

var Lit_538 *jrt.String = jrt.Intern("arbace.c.check$asm_operands_BANG_")

var Lit_539 *jrt.String = jrt.Intern("arbace.c.check$check_defn")

var Lit_540 *jrt.String = jrt.Intern("arbace.c.check$check_declare")

var Lit_541 *jrt.String = jrt.Intern("arbace.c.check$check_typedef")

var Lit_542 *jrt.String = jrt.Intern("arbace.c.check$check_decl")

var Lit_543 *jrt.String = jrt.Intern("arbace.c.check$decl_form_QMARK_")

var Lit_544 *jrt.String = jrt.Intern("arbace.c.check$let_bindings")

var Lit_545 *jrt.String = jrt.Intern("arbace.c.check$attr_decl_check_BANG_")

var Lit_546 *jrt.String = jrt.Intern("arbace.c.check$stmt_attrs_BANG_")

var Lit_547 *jrt.String = jrt.Intern("arbace.c.check$check_block_items")

var Lit_548 *jrt.String = jrt.Intern("arbace.c.check$cond_expr")

var Lit_549 *jrt.String = jrt.Intern("arbace.c.check$check_stmt")

var Lit_550 *jrt.String = jrt.Intern("arbace.c.check$pragma_pack_BANG_")

var Lit_551 *jrt.String = jrt.Intern("arbace.c.check$sys_at")

var Lit_552 *jrt.String = jrt.Intern("arbace.c.check$check_forms")

var Lit_553 *jrt.String = jrt.Intern("arbace.c.check$check_top")

var Lit_554 *jrt.String = jrt.Intern("arbace.c.check$new_cx")

var Lit_555 *jrt.String = jrt.Intern("arbace.c.check$check_unit")
