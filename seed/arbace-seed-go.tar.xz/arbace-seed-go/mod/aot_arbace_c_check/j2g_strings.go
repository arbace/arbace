//line j2g_strings.ae:1
package aot_arbace_c_check

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,strkn3,dockn3,extkn6,pragmakn5,annotkn10,annotatingkn5,featskn12,vector-typeskn6,errorskn8,pedantickn9,ext-lineskn4,linekn7,resultsys11,arbace.core7,bindingys14,arbace.c.check6,*line*ys14,arbace.c.check7,line-ofkn3,stdkn5,gnu11kn3,c17kn3,c89kn3,c99kn5,gnu17kn5,gnu2ykn3,c2ykn3,c11kn3,c94kn5,gnu89kn5,gnu99kn13,no-c2y-compatkn4,bitskn2,lvkn1,kkn3,ptrkn2,tokn5,arraykn2,ofkn1,nkn8,float128kn7,float32kn6,dec64xkn8,float32xkn7,float64kn9,float128xkn8,float64xkn6,dec128kn1,qkn13,unsigned-charkn3,reckn5,underkn6,bitintkn4,enumkn7,complexkn7,nullptrkn5,unionkn6,structkn4,voidkn4,charkn1,ukn4,boolkn12,ldouble-sizekn4,elsekn5,dec32kn4,bf16kn4,longkn3,intkn8,completekn4,sizekn7,float16kn7,ldoublekn3,vlakn6,ushortkn2,fnkn6,vectorkn6,int128kn5,llongkn5,ucharkn5,ulongkn5,scharkn6,doublekn5,floatkn6,ullongkn5,dec64kn5,shortkn7,uint128kn4,uintkn6,talignkn5,alignkn3,tagkn6,paramskn5,protokn8,variadickn10,empty-listkn3,retkn7,invalidkn7,memberskn4,namekn1,tkn12,typedef-namekn11,transparentkn6,constskn5,fixedkn7,mpackedkn5,scopekn12,cc-enum-typekn21,cc-bitfield-promotionkn6,scopeskn3,ordkn4,tagsyn2,doys14,arbace.c.check11,push-scope!yn3,tryyn7,finallyys14,arbace.c.check10,pop-scope!ys1,c2,idyn13,__attribute__yn11,byte-stringks1,c6,aparenkn8,functionyn8,restrictyn8,volatileyn6,atomicyn1,*yn2,fnyn8,_Nonnullyn5,arrayyn5,constkn7,typedefkn4,kindyn18,typeof-unqual-typeyn6,typeofyn13,typeof-unqualyn11,typeof-typeks1,c10,decl-attrsks1,c5,attrsks1,c8,after-atks1,c11,after-attrsks1,c10,type-attrskn4,typeks1,c10,list-attrsks1,c14,decl-end-attrsks1,c9,end-attrsks1,c9,def-attrskn9,attr-modekn12,cc-attr-modekn9,min-alignkn3,offkn6,bitoffkn3,blkkn2,ldkn2,sfkn2,dfkn2,hfkn2,bfkn2,tfkn3,deckn4,nonekn1,vkn13,no-c23-compatkn3,objys1,c4,baseyn3,intks1,c2,kryn1,&ks1,c12,implicit-intkn5,paramks1,c4,speckn7,linkageyn4,enumyn8,__seg_gskn6,atomickn8,restrictyn7,bit-intkn9,cc-bitintyn8,__seg_fsyn5,unionkn5,constyn6,structyn7,complexkn8,volatilekn8,vla-expryn16,unsigned-bit-intys1,c13,static-assertys1,c4,bitsys1,c5,groupkn6,memberks1,c4,bitsks1,c7,alignasks1,c12,alignas-typeys14,arbace.c.check10,check-declkn8,definingkn10,redefiningkn4,packkn14,cc-attr-layoutkn18,cc-bitfield-layoutks1,c10,underlyingkn11,nested-seenkn9,enumconstkn2,avkn13,cc-float-foldkn3,strkn16,cc-c23-constantsyn10,code-unitsyn6,bit-oryn1,%yn7,bit-andyn1,+yn1,-yn1,/yn7,bit-xoryn2,==yn2,<=yn2,>=yn1,<yn1,>yn2,!=kn3,nfpyn2,>>yn2,<<yn2,oryn3,andkn10,permissivekn1,xkn8,implicitkn2,idkn10,file-scopekn7,fn-namekn7,builtinkn5,entrykn12,cc-constexprkn16,cc-builtin-typeskn6,malignkn5,fff-fkn4,ff-fkn5,f-intkn3,f-fkn6,f-longkn4,fi-fkn7,f-llongkn21,cc-undeclared-builtinkn4,snankn15,cc-builtin-foldkn5,partsyn9,imaginaryyn10,__float128yn9,__float80kn18,cc-prefixed-stringks1,c4,typekn7,defaultkn6,chosenyn4,inityn3,lityn2,atyn12,compound-litys1,c5,embedkn4,inityn6,va-argyn4,imagyn1,?yn8,offsetofyn4,agetkn16,cc-builtin-macroyn4,set!yn7,alignofyn13,classify-typeyn4,dec!yn6,sizeofyn3,notyn8,bit-castyn4,inc!yn7,genericyn13,convertvectoryn4,addrkn4,addryn14,has-attribute?kn9,constexpryn5,commays1,c4,callyn4,asetyn10,label-addrys1,c4,expryn4,convyn7,bit-notyn17,types-compatible?yn2,->yn12,alignof-typeyn8,pre-dec!yn4,realyn11,sizeof-typekn2,ttyn8,pre-inc!yn9,stmt-exprys11,arbace.core5,derefkn6,statickn6,externkn1,ikn10,cc-linkagekn13,cc-redeclaredks1,c9,auto-typekn4,autokn1,mks1,c9,bad-specsyn13,unsigned-charks1,c14,declared-alignkn6,columnkn12,thread_localkn4,defskn7,cc-autokn6,fn-retys1,c7,declareys1,c9,attr-declkn3,topys1,c4,defnys1,c4,enumys1,c7,typedefys1,c3,varys1,c5,unionkn12,exec-charsetys1,c12,local-labelsys1,c6,structys1,c13,declare-specskn5,blockyn7,defaultyn4,caseyn5,labelyn1,_yn4,condyn8,continueyn6,switchyn3,forkn4,seenyn5,goto*ys1,c6,defineys1,c6,pragmays1,c9,directiveyn6,returnyn2,ifyn3,letyn8,do-whileks1,c8,sel-declys1,c3,asmys1,c7,includekn3,asmyn4,gotoyn5,whileyn5,breakyn4,whenys1,c5,undefkn10,pack-statekn5,stackys1,c6,headerkn5,pack1ys1,c4,filekn4,unitkn10,done-unitskn5,unitskn4,basekn6,systemkn4,pathkn8,sys-dirskn8,form-syskn5,formskn8,annotatekn5,noteskn5,itemsv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn14,arbace.c.checkm2,R4,s1792,The checker over C forms (doc/c/SPEC.md §11.2; doc/C23-SURVEY.md, C4, \"As built: C4\"): every\n  expression's type and constant value, the integer promotions and the usual arithmetic conversions\n  (6.3), lvalue, array and function conversions, null pointer constants, constant expressions and their\n  values (6.6: enumerators, sizeof, alignof, constexpr objects, case labels, array sizes), layout by the\n  SysV x86-64 psABI as gcc 15.2 lays out (sizes, alignments, members' offsets, bit-fields, packed,\n  aligned), linkage (6.2.2), arrays completed by their initializers, `auto`'s, `__auto_type`'s and\n  `typeof`'s types, `_Generic`'s selection, `_BitInt`. Arbace's own (CS8 (a)); cc's checker is its oracle\n  where it succeeds (bin/ci annotations, arbace.repr.c.annot).\n\n  `check-unit` checks a read's forms (arbace.repr.c/read-c's) and returns its errors (the reference's\n  errors the checker diagnoses: only those gcc 15.2 gives, as errors) and, when asked, the annotations\n  of every main-file item in tools/ccdump's types format. A header unit's forms are checked where their\n  c/include stands, without annotations. Moved from arbace/repr/c/ as arbace.c.check in C5 (CS90 (a)),\n  with ci's namespaces; `:results` gives ci's builder each form's result (CS95 (a)).\n\n  Types are maps: {:k KIND} for the base types (:void :bool :char :schar :uchar :short :ushort :int :uint\n  :long :ulong :llong :ullong :int128 :uint128 :float :double :ldouble and the other floating types),\n  {:k :bitint :n N :u bool}, {:k :complex :of T}, {:k :ptr :to T}, {:k :array :of T :n N-or-nil :vla bool},\n  {:k :fn :ret T :params [T] :variadic bool :proto bool}, {:k :struct|:union|:enum :rec R} (R a mutable\n  record of the tag: its members, layout, completeness), {:k :nullptr}, {:k :invalid}; qualifiers in :q.R5,R6,v14,arbace.c.check4,*cx*v14,arbace.c.check2,cxR7,R8,R9,R10,R11,v14,arbace.c.check6,*unit*v14,arbace.c.check6,*line*R12,v11,arbace.core3,notv14,arbace.c.check13,*system-unit*v14,arbace.c.check11,*unit-info*v11,arbace.core9,contains?v14,arbace.c.check12,*unit-line?*R13,v14,arbace.c.check4,err!R14,R15,v11,arbace.core4,seq?v11,arbace.core7,symbol?v11,arbace.core7,vector?v11,arbace.core3,seqv11,arbace.core6,concatv11,arbace.core4,listR16,v11,arbace.core5,applyv11,arbace.core6,vectorR17,R18,R19,R20,l111,R21,l117,R22,l89,R23,l99,l123,R24,R25,l124,R26,R27,R28,R29,R30,v14,arbace.c.check7,std-numR31,v14,arbace.c.check8,pedwarn!R32,R33,R34,R35,R36,R37,R38,R39,R40,l3,R41,R42,l1,R43,l2,R44,R45,R46,R47,R48,v11,arbace.core6,dissocv11,arbace.core5,assocv14,arbace.c.check4,qualv11,arbace.core6,updatev11,arbace.core4,fnilv14,arbace.c.check5,qualsR49,R50,R51,v14,arbace.c.check6,t-uintv14,arbace.c.check8,int-infoR52,R53,v14,arbace.c.check10,float-rankR54,v14,arbace.c.check9,int-type?v14,arbace.c.check11,float-type?v14,arbace.c.check13,complex-type?v14,arbace.c.check11,arith-type?v14,arbace.c.check9,ptr-type?R55,S2,R56,R57,R58,R59,v14,arbace.c.check8,int-bitsv14,arbace.c.check10,enum-underl8,v14,arbace.c.check12,char-signed?R60,l32,v14,arbace.c.check4,rankl325,v11,arbace.core5,some?R61,v14,arbace.c.check3,unql0,v11,arbace.core10,bigintegerv11,arbace.core6,bigintR62,l16,l4,R63,R64,R65,v14,arbace.c.check7,size-ofR66,R67,R56,R68,R69,R57,R70,R71,v14,arbace.c.check12,ldouble-sizeR72,R73,R74,R75,R76,R77,R78,R79,R80,R81,R82,R83,R84,R85,v14,arbace.c.check11,bitint-sizeR86,R87,R88,v14,arbace.c.check9,align-of*v14,arbace.c.check8,align-ofR89,v11,arbace.core3,strv11,arbace.core4,nameR90,R91,R92,v11,arbace.core6,empty?R93,R94,v11,arbace.core11,map-indexedv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core5,firstv11,arbace.core10,chunk-restv11,arbace.core4,nextR95,R96,S2,R56,R57,R97,v11,arbace.core6,every?v11,arbace.core5,true?v11,arbace.core3,mapR98,v14,arbace.c.check8,mcompat?R99,v14,arbace.c.check11,compatible?R100,R101,v11,arbace.core4,somev11,arbace.core4,not=S1,R59,R102,R103,v14,arbace.c.check14,*compat-depth*R104,v11,arbace.core19,pop-thread-bindingsR105,v11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv14,arbace.c.check18,union-param-match?v14,arbace.c.check3,ptrv14,arbace.c.check7,promotev14,arbace.c.check5,t-intv14,arbace.c.check5,feat!R106,R107,m2,R34,R78,m2,R34,R83,m2,R34,R78,v14,arbace.c.check7,t-ulongm2,R34,R86,m2,R34,R73,v14,arbace.c.check8,float-ofv14,arbace.c.check5,usualS2,R70,R65,S2,R70,R65,v14,arbace.c.check9,float-tiev14,arbace.c.check11,unsigned-ofR108,R109,R110,R111,R112,R113,R114,R115,v14,arbace.c.check9,top-scopeR116,v11,arbace.core6,secondv11,arbace.core6,mapcatR117,v14,arbace.c.check10,attr-itemsv11,arbace.core4,restv13,arbace.string7,replacep7,^__|__$v11,arbace.core9,namespacev11,arbace.core3,vecp7,^__|__$v14,arbace.c.check8,attrs-ofv14,arbace.c.check13,all-attr-keysv14,arbace.c.check16,std-no-arg-attrsv14,arbace.c.check16,std-string-attrsv11,arbace.core7,string?R118,v11,arbace.core6,ffirstR119,v11,arbace.core12,chunk-bufferv14,arbace.c.check18,std-position-attrsv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core4,consv14,arbace.c.check8,ignored!v14,arbace.c.check9,std-namesv14,arbace.c.check14,std-attr-misc!S2,s9,_Noreturns8,noreturnS2,s9,_Noreturns8,noreturnR120,v14,arbace.c.check13,fn-type-attrsS8,R121,R122,R123,R124,R125,R126,R127,R128,v11,arbace.core4,lastv14,arbace.c.check9,base-symsv14,arbace.c.check6,lookupR129,R130,S4,R131,R132,R133,R134,R135,R136,R137,R138,v11,arbace.core3,setR139,v14,arbace.c.check15,type-pos-attrs!v14,arbace.c.check13,base-fn-type?R140,V5,R136,R135,R141,R142,R143,R144,S2,s9,_Noreturns8,noreturnS2,s9,_Noreturns8,noreturnv14,arbace.c.check15,std-attr-check!v14,arbace.c.check2,exv14,arbace.c.check4,ann!v11,arbace.core7,number?v11,arbace.core5,char?R145,v11,arbace.core6,filterp7,^__|__$V2,l0,Tv14,arbace.c.check13,assoc-in-modem2,R34,R85,m2,R34,R73,v14,arbace.c.check8,t-doublev14,arbace.c.check6,t-longm2,R34,R80,m2,R34,R78,v14,arbace.c.check7,t-floatm2,R34,R76,m2,R34,R86,m2,R34,R80,m2,R34,R78,v14,arbace.c.check9,const-intv11,arbace.core8,integer?R146,v11,arbace.core4,atomR147,v14,arbace.c.check8,align-upv14,arbace.c.check12,member-alignR148,R149,v11,arbace.core5,swap!v11,arbace.core3,maxv11,arbace.core2,+'v11,arbace.core6,reset!v14,arbace.c.check12,record-type?v14,arbace.c.check6,memberv11,arbace.core1,+v14,arbace.c.check10,lookup-tagv14,arbace.c.check7,new-recv14,arbace.c.check11,*auto-init*S5,l1,l4,l2,l16,l8,R150,V2,R82,R151,m2,R34,R71,l80,l64,m10,R152,l32,R153,l64,R154,l16,R155,l16,R156,l128,R157,m8,R64,l32,R84,l64,R47,l128,R42,l128,v14,arbace.c.check14,mode-precisionV2,R82,R155,v14,arbace.c.check8,int-modev11,arbace.core6,reducev14,arbace.c.check9,type-modeR158,v11,arbace.core7,reducedS2,R150,R158,v14,arbace.c.check9,int-mode?S2,R150,R158,V2,R82,R154,V2,R82,R151,V2,R82,R156,V2,R82,R152,V2,R82,R151,V2,R82,R156,V2,R82,R153,V2,R82,R153,V2,R82,R152,V2,R82,R153,R159,R160,R161,v14,arbace.c.check6,t-charR162,v14,arbace.c.check6,*base*v14,arbace.c.check9,t-invalidR116,R125,v14,arbace.c.check10,parse-typeR163,R164,R165,v11,arbace.core7,butlastv14,arbace.c.check11,push-scope!v11,arbace.core4,keepv14,arbace.c.check5,identR166,R163,R116,v14,arbace.c.check20,decl-position-attrs!R167,R168,v14,arbace.c.check4,tstrv14,arbace.c.check8,declare!R169,v14,arbace.c.check10,pop-scope!v14,arbace.c.check4,c23?R124,R116,v11,arbace.core6,symbolR170,v14,arbace.c.check10,check-enumR171,R123,R172,R121,R173,R174,v14,arbace.c.check12,bitint-widthR131,R175,R176,R133,R177,v14,arbace.c.check12,check-structv11,arbace.core7,keywordv14,arbace.c.check10,bit-field?R128,R178,R126,R179,R180,R132,R122,R181,R134,R127,R124,v14,arbace.c.check3,arrR182,v14,arbace.c.check4,vla?R183,v11,arbace.core6,pr-strR184,R185,v14,arbace.c.check3,exiR186,v14,arbace.c.check12,member-formsv11,arbace.core4,dropS2,R177,R179,v14,arbace.c.check10,attr-args!v14,arbace.c.check9,vectorizeR187,R188,v14,arbace.c.check13,aligned-valueR189,R190,v11,arbace.core7,resolveR191,v14,arbace.c.check9,rec-same?v14,arbace.c.check7,type-eqv14,arbace.c.check8,vm-type?S2,R56,R57,v14,arbace.c.check11,vla-struct?v11,arbace.core8,not-any?v14,arbace.c.check10,tag-attrs!v14,arbace.c.check7,tag-refR192,R193,R194,R195,v14,arbace.c.check7,layout!v14,arbace.c.check15,transparent-ok?R196,v11,arbace.core4,neg?l4294967295,l-2147483648,l2147483647,R197,R198,v14,arbace.c.check4,wrapv11,arbace.core2,<=l-2147483648,l2147483647,v14,arbace.c.check12,enum-type-ofl-2147483648,l2147483647,R199,v11,arbace.core6,zipmapv11,arbace.core8,to-arrayv11,arbace.core5,mergev14,arbace.c.check5,decayR200,C14,java.lang.Mathd4607182418800017408,v14,arbace.c.check9,round-sigl11,l-14,l15,l-126,l127,v14,arbace.c.check12,wide-formatsv14,arbace.c.check11,round-exactv14,arbace.c.check14,binary-formatsl24,S2,R70,R65,S4,R70,R41,R82,R65,v14,arbace.c.check9,round-bigv14,arbace.c.check15,round-to-formatR201,l-2147483648,l2147483647,v14,arbace.c.check4,big?r21,18446744073709551615Nm2,R34,R76,v11,arbace.core6,ratio?R202,v14,arbace.c.check6,t-boolv14,arbace.c.check9,t-nullptrR203,R204,v14,arbace.c.check15,code-unit-countR118,v14,arbace.c.check15,byte-string-lenR205,R206,R207,R124,R208,R209,R210,R211,R124,R208,R209,R210,R212,R213,R214,R215,R216,R217,v14,arbace.c.check10,void-type?v14,arbace.c.check11,null-const?R218,S2,R217,R212,v14,arbace.c.check3,resS4,R215,R213,R216,R214,S10,R211,R124,R206,R209,R207,R219,R210,R205,R208,R220,S2,R96,R75,S2,R96,R75,v14,arbace.c.check7,cmp-opsv14,arbace.c.check9,eval-typeR151,v14,arbace.c.check10,wide-kindsv14,arbace.c.check8,exact-ofv14,arbace.c.check7,cmp-valv14,arbace.c.check8,conv-valS2,R221,R222,R222,R221,R222,R221,S2,R219,R220,R220,R208,R208,R209,R209,v14,arbace.c.check6,int-opv14,arbace.c.check8,float-opv14,arbace.c.check15,null-const-npc?v14,arbace.c.check12,scalar-type?S4,R211,R206,R207,R205,S2,R56,R57,v14,arbace.c.check8,unq-elemv14,arbace.c.check9,int-classS2,R96,R58,S2,R96,R58,v14,arbace.c.check6,t-voidv11,arbace.core4,disjv11,arbace.core4,intov14,arbace.c.check23,compatible-ptr-targets?R223,R224,R225,R226,R227,v14,arbace.c.check13,file-declare!R228,v13,arbace.string12,starts-with?R229,R230,R231,R232,R233,v11,arbace.core3,modm2,R34,R71,R234,R235,R236,R237,R238,R239,R240,v14,arbace.c.check7,t-llongV7,V2,V10,s4,log2s4,exp2s5,truncs5,rounds4,rints9,nearbyints4,cbrts5,expm1s5,log1ps4,logbR237,V2,V5,s4,fmins4,fmaxs5,hypots4,fdims9,remainderR235,V2,V1,s3,fmaR234,V2,V1,s5,ilogbR236,V2,V2,s6,lrounds5,lrintR238,V2,V2,s7,llrounds6,llrintR240,V2,V1,s6,scalbnR239,v14,arbace.c.check4,c99?v14,arbace.c.check16,math-builtin-fnsv14,arbace.c.check13,builtin-typesv14,arbace.c.check12,implicit-fn!v14,arbace.c.check5,emit!v14,arbace.c.check7,record!v14,arbace.c.check9,callee-fnv11,arbace.core4,mapvv14,arbace.c.check12,call-builtinR241,v14,arbace.c.check9,ptr-conv!v13,arbace.string10,ends-with?v13,arbace.string9,includes?v11,arbace.core10,re-matchesp36,__builtin_(inf|nan|nans)d(32|64|128)R242,S9,s18,__builtin_huge_vals14,__builtin_inffs20,__builtin_constant_ps13,__builtin_infs16,__builtin_expects19,__builtin_huge_valfs19,__builtin_huge_valls21,__builtin_choose_exprs14,__builtin_inflR243,v11,arbace.core4,subsl10,S4,s17,stdc_rotate_rights14,stdc_bit_floors13,stdc_bit_ceils16,stdc_rotate_leftS2,s17,stdc_rotate_rights16,stdc_rotate_leftv14,arbace.c.check8,bit-foldS2,s4,ctzgs4,clzgS4,s17,stdc_rotate_rights14,stdc_bit_floors13,stdc_bit_ceils16,stdc_rotate_leftS2,s17,stdc_rotate_rights16,stdc_rotate_leftS2,s4,ctzgs4,clzgR244,S4,s17,stdc_rotate_rights14,stdc_bit_floors13,stdc_bit_ceils16,stdc_rotate_leftS2,s17,stdc_rotate_rights16,stdc_rotate_leftS2,s4,ctzgs4,clzgS4,s17,stdc_rotate_rights14,stdc_bit_floors13,stdc_bit_ceils16,stdc_rotate_leftS2,s17,stdc_rotate_rights16,stdc_rotate_leftS2,s4,ctzgs4,clzgS4,s17,stdc_rotate_rights14,stdc_bit_floors13,stdc_bit_ceils16,stdc_rotate_leftS2,s17,stdc_rotate_rights16,stdc_rotate_leftS2,s4,ctzgs4,clzgS4,s17,stdc_rotate_rights14,stdc_bit_floors13,stdc_bit_ceils16,stdc_rotate_leftS2,s17,stdc_rotate_rights16,stdc_rotate_leftS2,s4,ctzgs4,clzgv14,arbace.c.check13,overflow-foldl13,S4,s17,stdc_rotate_rights14,stdc_bit_floors13,stdc_bit_ceils16,stdc_rotate_leftS2,s17,stdc_rotate_rights16,stdc_rotate_leftS2,s4,ctzgs4,clzgm2,R34,R71,S4,s17,stdc_rotate_rights14,stdc_bit_floors13,stdc_bit_ceils16,stdc_rotate_leftS2,s17,stdc_rotate_rights16,stdc_rotate_leftS2,s4,ctzgs4,clzgS4,s17,stdc_rotate_rights14,stdc_bit_floors13,stdc_bit_ceils16,stdc_rotate_leftS2,s17,stdc_rotate_rights16,stdc_rotate_leftS2,s4,ctzgs4,clzgS4,s17,stdc_rotate_rights14,stdc_bit_floors13,stdc_bit_ceils16,stdc_rotate_leftS2,s17,stdc_rotate_rights16,stdc_rotate_leftS2,s4,ctzgs4,clzgS4,s17,stdc_rotate_rights14,stdc_bit_floors13,stdc_bit_ceils16,stdc_rotate_leftS2,s17,stdc_rotate_rights16,stdc_rotate_leftS2,s4,ctzgs4,clzgS4,s17,stdc_rotate_rights14,stdc_bit_floors13,stdc_bit_ceils16,stdc_rotate_leftS2,s17,stdc_rotate_rights16,stdc_rotate_leftS2,s4,ctzgs4,clzgS4,s17,stdc_rotate_rights14,stdc_bit_floors13,stdc_bit_ceils16,stdc_rotate_leftS2,s17,stdc_rotate_rights16,stdc_rotate_leftS2,s4,ctzgs4,clzgS4,l1,l4,l2,l8,S4,s17,stdc_rotate_rights14,stdc_bit_floors13,stdc_bit_ceils16,stdc_rotate_leftS2,s17,stdc_rotate_rights16,stdc_rotate_leftS2,s4,ctzgs4,clzgS4,s17,stdc_rotate_rights14,stdc_bit_floors13,stdc_bit_ceils16,stdc_rotate_leftS2,s17,stdc_rotate_rights16,stdc_rotate_leftS2,s4,ctzgs4,clzgS4,s17,stdc_rotate_rights14,stdc_bit_floors13,stdc_bit_ceils16,stdc_rotate_leftS2,s17,stdc_rotate_rights16,stdc_rotate_leftS2,s4,ctzgs4,clzgS4,s17,stdc_rotate_rights14,stdc_bit_floors13,stdc_bit_ceils16,stdc_rotate_leftS2,s17,stdc_rotate_rights16,stdc_rotate_leftS2,s4,ctzgs4,clzgS4,l1,l4,l2,l8,S4,s17,stdc_rotate_rights14,stdc_bit_floors13,stdc_bit_ceils16,stdc_rotate_leftS2,s17,stdc_rotate_rights16,stdc_rotate_leftS2,s4,ctzgs4,clzgS4,s17,stdc_rotate_rights14,stdc_bit_floors13,stdc_bit_ceils16,stdc_rotate_leftS2,s17,stdc_rotate_rights16,stdc_rotate_leftS2,s4,ctzgs4,clzgS4,s17,stdc_rotate_rights14,stdc_bit_floors13,stdc_bit_ceils16,stdc_rotate_leftS2,s17,stdc_rotate_rights16,stdc_rotate_leftS2,s4,ctzgs4,clzgm2,R34,R71,S4,s17,stdc_rotate_rights14,stdc_bit_floors13,stdc_bit_ceils16,stdc_rotate_leftS2,s17,stdc_rotate_rights16,stdc_rotate_leftS2,s4,ctzgs4,clzgS4,s17,stdc_rotate_rights14,stdc_bit_floors13,stdc_bit_ceils16,stdc_rotate_leftS2,s17,stdc_rotate_rights16,stdc_rotate_leftS2,s4,ctzgs4,clzgS2,R204,R118,R245,v14,arbace.c.check9,dec-kindsS2,R70,R65,v14,arbace.c.check14,float-of-exactS2,R246,R247,R248,v14,arbace.c.check16,incomplete-type?R249,v14,arbace.c.check12,pedwarn-c2y!v11,arbace.core5,doallR250,R251,R118,R252,S6,R73,R67,R87,R78,R59,R80,R118,R253,v14,arbace.c.check10,init-countR252,R254,v11,arbace.core8,keyword?R252,S1,R255,R253,v11,arbace.core5,nnextR252,R256,R254,v14,arbace.c.check10,check-initv14,arbace.c.check4,unq*S5,R55,R96,R75,R61,R35,S2,R55,R96,R257,v14,arbace.c.check9,member-ofv14,arbace.c.check3,ex*v14,arbace.c.check10,ident-exprv14,arbace.c.check4,callR258,R206,v14,arbace.c.check6,binaryR259,R124,R208,R209,v14,arbace.c.check8,lit-typev14,arbace.c.check7,line-ofR208,S2,R96,R75,R208,R209,S2,R96,R75,R210,S2,R96,R75,R215,S2,R96,R75,R216,R260,v14,arbace.c.check9,cond-typeR245,R217,R211,R261,S2,R96,R75,R262,v14,arbace.c.check10,deref-typev14,arbace.c.check17,binary-index-typeR263,R205,R264,S2,R96,R75,R265,v14,arbace.c.check12,assign-checkR253,v14,arbace.c.check8,lit-formR266,R267,R268,v14,arbace.c.check10,sizeof-resR118,R269,R222,R270,S2,R96,R75,R271,R272,v14,arbace.c.check14,generic-selectR273,R274,R275,R255,R252,S3,R256,R252,R254,R276,R252,R277,v14,arbace.c.check16,constexpr-check!R116,R278,v11,arbace.core4,peekR279,R280,R281,R207,R220,S2,R96,R75,R282,R213,R283,S2,R55,R96,S5,R55,R96,R58,R61,R35,R284,R285,S2,R96,R75,R286,v14,arbace.c.check12,nested-arrowR212,R287,R288,R219,R214,R289,R290,R291,R252,R292,R221,R293,v14,arbace.c.check17,check-block-itemsS2,R96,R75,R294,R295,R296,v14,arbace.c.check11,file-scope?R297,S2,R224,R297,S2,R224,R297,S2,R224,R297,R298,v14,arbace.c.check10,linkage-ofS2,R74,R161,R299,S2,R74,R161,S2,R74,R161,R300,R301,S4,R131,R132,R133,R134,v11,arbace.core8,tree-seqv11,arbace.core5,coll?R302,S2,R74,R161,v14,arbace.c.check9,compositeR303,v14,arbace.c.check5,lnameR118,R253,R304,R118,R253,R304,v14,arbace.c.check10,dec-limitsv14,arbace.c.check9,dec-fits?v14,arbace.c.check9,round-decC20,java.math.BigDecimalv14,arbace.c.check12,fits-binary?v14,arbace.c.check19,constexpr-float-badv14,arbace.c.check12,string-bytesR252,V2,l-128,l127,V2,l0,l255,V2,l0,l255,V2,l-128,l127,v14,arbace.c.check10,auto-type?v14,arbace.c.check15,declare-object!R163,R305,ML1,R252,m4,R14,i2378,R306,i45,S4,R131,R132,R133,R134,R252,R307,R308,v14,arbace.c.check14,complete-arrayR309,R252,S4,R81,R55,R82,R35,R165,R163,v11,arbace.core4,compv11,arbace.core6,re-seqp59,\\\"([=+&%]*[a-zA-Z]*r[a-zA-Z]*)\\\"\\s*\\(\\s*([A-Za-z_]\\w*)\\s*\\)S1,R161,v11,arbace.core7,re-findp10,[mogVX0-9]S1,R161,R163,v14,arbace.c.check9,params-ofR310,R125,R163,R311,v14,arbace.c.check13,check-declareR186,R312,v14,arbace.c.check16,attr-decl-check!R313,R314,v14,arbace.c.check10,check-defnv14,arbace.c.check10,check-declR315,v11,arbace.core9,with-metaR170,R316,v14,arbace.c.check13,check-typedefR317,v14,arbace.c.check9,check-varR318,v11,arbace.core9,vary-metaR184,R319,R320,R321,R322,R312,v14,arbace.c.check10,decl-headsv14,arbace.c.check10,decl-form?R317,R323,v14,arbace.c.check11,*in-switch*S2,R324,R325,S2,R324,R325,R312,S3,R324,R326,R325,S2,s11,fallthroughs10,deprecatedS3,s9,nodiscards9,_Noreturns8,noreturnS2,s11,fallthroughs10,deprecatedS3,s9,nodiscards9,_Noreturns8,noreturnV1,nv14,arbace.c.check10,check-stmtR312,v14,arbace.c.check11,stmt-attrs!R327,R328,R329,R312,R330,R331,v14,arbace.c.check8,*switch*R332,R333,v14,arbace.c.check12,let-bindingsv14,arbace.c.check9,cond-exprR334,R335,R336,R337,R326,R338,R324,R339,R340,R341,R342,R343,R344,v14,arbace.c.check13,asm-operands!R111,R345,R346,R347,R348,R320,R349,R325,v13,arbace.string4,joinp8,\\bpack\\bp33,pack\\s*\\(\\s*(?:push\\s*,\\s*)?(\\d+)p14,pack\\s*\\(\\s*\\)R350,p3,popR351,v11,arbace.core3,popp4,pushv14,arbace.c.check9,check-topR352,R334,R336,R349,R353,R354,R342,R343,v11,arbace.core10,drop-whileR355,R356,R357,R358,v13,arbace.string11,split-linesv11,arbace.core12,keep-indexedp38,^\\s*#\\s*pragma\\s+GCC\\s+system_header\\bR359,R360,v11,arbace.core10,make-arrayC16,java.lang.StringR361,R362,R363,R335,v14,arbace.c.check12,pragma-pack!R364,R365,v14,arbace.c.check6,new-cxR366,S5,R343,R336,R334,R349,R335,S5,R343,R336,R334,R349,R335,")

var Lit_1 *jrt.String = jrt.Intern("vector(")

var Lit_2 *jrt.String = jrt.Intern("impossible constraint in 'asm'")

var Lit_3 *jrt.String = jrt.Intern("assignment of read-only location")

var Lit_4 *jrt.String = jrt.Intern("e int")

var Lit_5 *jrt.String = jrt.Intern("fallthrough")

var Lit_6 *jrt.String = jrt.Intern("'fallthrough' attribute at top level")

var Lit_7 *jrt.String = jrt.Intern("invalid use of attribute 'fallthrough'")

var Lit_8 *jrt.String = jrt.Intern("attribute 'fallthrough' not preceding a case label or default label")

var Lit_9 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_10 *jrt.String = jrt.Intern("arbace.c.check$attr_items$fn__1876000140")

var Lit_11 *jrt.String = jrt.Intern("")

var Lit_12 *jrt.String = jrt.Intern("gnu")

var Lit_13 *jrt.String = jrt.Intern("arbace.c.check$attrs_of$fn__1876000144")

var Lit_14 *jrt.String = jrt.Intern("arbace.c.check$base_fn_type_QMARK_$fn__1876000197")

var Lit_15 *jrt.String = jrt.Intern("invalid operands to binary ")

var Lit_16 *jrt.String = jrt.Intern("ordered comparison of pointer with null pointer")

var Lit_17 *jrt.String = jrt.Intern("arbace.c.check$binary$ex__1876000464")

var Lit_18 *jrt.String = jrt.Intern("invalid operands to binary shift")

var Lit_19 *jrt.String = jrt.Intern("arbace.c.check$bit_fold$none_QMARK___1876000481")

var Lit_20 *jrt.String = jrt.Intern("arbace.c.check$bit_fold$len__1876000483")

var Lit_21 *jrt.String = jrt.Intern("arbace.c.check$bit_fold$tz__1876000485")

var Lit_22 *jrt.String = jrt.Intern("arbace.c.check$bit_fold$ones__1876000487")

var Lit_23 *jrt.String = jrt.Intern("ffsg")

var Lit_24 *jrt.String = jrt.Intern("clrsbg")

var Lit_25 *jrt.String = jrt.Intern("stdc_bit_width")

var Lit_26 *jrt.String = jrt.Intern("stdc_rotate_left")

var Lit_27 *jrt.String = jrt.Intern("clzg")

var Lit_28 *jrt.String = jrt.Intern("ctzg")

var Lit_29 *jrt.String = jrt.Intern("stdc_trailing_zeros")

var Lit_30 *jrt.String = jrt.Intern("stdc_first_leading_zero")

var Lit_31 *jrt.String = jrt.Intern("stdc_rotate_right")

var Lit_32 *jrt.String = jrt.Intern("stdc_bit_floor")

var Lit_33 *jrt.String = jrt.Intern("stdc_count_zeros")

var Lit_34 *jrt.String = jrt.Intern("stdc_first_trailing_zero")

var Lit_35 *jrt.String = jrt.Intern("parityg")

var Lit_36 *jrt.String = jrt.Intern("stdc_leading_ones")

var Lit_37 *jrt.String = jrt.Intern("stdc_trailing_ones")

var Lit_38 *jrt.String = jrt.Intern("stdc_bit_ceil")

var Lit_39 *jrt.String = jrt.Intern("stdc_first_leading_one")

var Lit_40 *jrt.String = jrt.Intern("popcountg")

var Lit_41 *jrt.String = jrt.Intern("stdc_has_single_bit")

var Lit_42 *jrt.String = jrt.Intern("stdc_first_trailing_one")

var Lit_43 *jrt.String = jrt.Intern("stdc_leading_zeros")

var Lit_44 *jrt.String = jrt.Intern("stdc_count_ones")

var Lit_45 *jrt.String = jrt.Intern("ISO C does not support '")

var Lit_46 *jrt.String = jrt.Intern("_BitInt(")

var Lit_47 *jrt.String = jrt.Intern(")' before C23")

var Lit_48 *jrt.String = jrt.Intern("unsigned ")

var Lit_49 *jrt.String = jrt.Intern("'_BitInt' argument is not an integer constant expression")

var Lit_50 *jrt.String = jrt.Intern("'_BitInt' argument '")

var Lit_51 *jrt.String = jrt.Intern("' is not a positive integer constant expression")

var Lit_52 *jrt.String = jrt.Intern("'signed _BitInt' argument must be at least 2")

var Lit_53 *jrt.String = jrt.Intern("' is larger than 'BITINT_MAXWIDTH' '65535'")

var Lit_54 *jrt.String = jrt.Intern("arbace.c.check$byte_string_len$fn__1876000444")

var Lit_55 *jrt.String = jrt.Intern("UTF-8")

var Lit_56 *jrt.String = jrt.Intern("__builtin_")

var Lit_57 *jrt.String = jrt.Intern("implicit declaration of function '")

var Lit_58 *jrt.String = jrt.Intern("'")

var Lit_59 *jrt.String = jrt.Intern("__func__")

var Lit_60 *jrt.String = jrt.Intern("__sync_")

var Lit_61 *jrt.String = jrt.Intern("__atomic_")

var Lit_62 *jrt.String = jrt.Intern("__builtin_has_attribute")

var Lit_63 *jrt.String = jrt.Intern("called object is not a function or function pointer")

var Lit_64 *jrt.String = jrt.Intern("too many arguments to function")

var Lit_65 *jrt.String = jrt.Intern("too few arguments to function")

var Lit_66 *jrt.String = jrt.Intern("passing argument ")

var Lit_67 *jrt.String = jrt.Intern("__builtin_huge_val")

var Lit_68 *jrt.String = jrt.Intern("__builtin_constant_p")

var Lit_69 *jrt.String = jrt.Intern("__builtin_finite")

var Lit_70 *jrt.String = jrt.Intern("f")

var Lit_71 *jrt.String = jrt.Intern("isinf")

var Lit_72 *jrt.String = jrt.Intern("isnan")

var Lit_73 *jrt.String = jrt.Intern("__builtin_isinff")

var Lit_74 *jrt.String = jrt.Intern("__builtin_isinfl")

var Lit_75 *jrt.String = jrt.Intern("__builtin_stdc_rotate_right")

var Lit_76 *jrt.String = jrt.Intern("stdc_")

var Lit_77 *jrt.String = jrt.Intern("__builtin_stdc_bit_width")

var Lit_78 *jrt.String = jrt.Intern("__builtin_complex")

var Lit_79 *jrt.String = jrt.Intern("__builtin_stdc_bit_ceil")

var Lit_80 *jrt.String = jrt.Intern("__builtin_stdc_has_single_bit")

var Lit_81 *jrt.String = jrt.Intern("__builtin_stdc_first_trailing_one")

var Lit_82 *jrt.String = jrt.Intern("__builtin_stdc_count_zeros")

var Lit_83 *jrt.String = jrt.Intern("__builtin_choose_expr")

var Lit_84 *jrt.String = jrt.Intern("__builtin_clear_padding")

var Lit_85 *jrt.String = jrt.Intern("__builtin_nans")

var Lit_86 *jrt.String = jrt.Intern("__builtin_nansf")

var Lit_87 *jrt.String = jrt.Intern("__builtin_add_overflow_p")

var Lit_88 *jrt.String = jrt.Intern("__builtin_stdc_first_leading_zero")

var Lit_89 *jrt.String = jrt.Intern("__builtin_huge_valf")

var Lit_90 *jrt.String = jrt.Intern("__builtin_huge_vall")

var Lit_91 *jrt.String = jrt.Intern("__builtin_ffsg")

var Lit_92 *jrt.String = jrt.Intern("__builtin_finitef")

var Lit_93 *jrt.String = jrt.Intern("__builtin_parityg")

var Lit_94 *jrt.String = jrt.Intern("__builtin_finitel")

var Lit_95 *jrt.String = jrt.Intern("__builtin_clrsbg")

var Lit_96 *jrt.String = jrt.Intern("__builtin_nansl")

var Lit_97 *jrt.String = jrt.Intern("__builtin_stdc_rotate_left")

var Lit_98 *jrt.String = jrt.Intern("__builtin_popcountg")

var Lit_99 *jrt.String = jrt.Intern("__builtin_ctzg")

var Lit_100 *jrt.String = jrt.Intern("__atomic_is_lock_free")

var Lit_101 *jrt.String = jrt.Intern("__atomic_always_lock_free")

var Lit_102 *jrt.String = jrt.Intern("__builtin_inf")

var Lit_103 *jrt.String = jrt.Intern("__builtin_stdc_first_trailing_zero")

var Lit_104 *jrt.String = jrt.Intern("__builtin_stdc_first_leading_one")

var Lit_105 *jrt.String = jrt.Intern("__builtin_mul_overflow_p")

var Lit_106 *jrt.String = jrt.Intern("__builtin_sub_overflow_p")

var Lit_107 *jrt.String = jrt.Intern("__builtin_isnanf")

var Lit_108 *jrt.String = jrt.Intern("__builtin_isnanl")

var Lit_109 *jrt.String = jrt.Intern("__builtin_stdc_trailing_zeros")

var Lit_110 *jrt.String = jrt.Intern("__builtin_stdc_leading_zeros")

var Lit_111 *jrt.String = jrt.Intern("__builtin_assoc_barrier")

var Lit_112 *jrt.String = jrt.Intern("__builtin_stdc_leading_ones")

var Lit_113 *jrt.String = jrt.Intern("__builtin_stdc_bit_floor")

var Lit_114 *jrt.String = jrt.Intern("__builtin_stdc_count_ones")

var Lit_115 *jrt.String = jrt.Intern("__builtin_inff")

var Lit_116 *jrt.String = jrt.Intern("__builtin_infl")

var Lit_117 *jrt.String = jrt.Intern("__builtin_stdc_trailing_ones")

var Lit_118 *jrt.String = jrt.Intern("__builtin_clzg")

var Lit_119 *jrt.String = jrt.Intern("__builtin_expect")

var Lit_120 *jrt.String = jrt.Intern("32")

var Lit_121 *jrt.String = jrt.Intern("64")

var Lit_122 *jrt.String = jrt.Intern("nans")

var Lit_123 *jrt.String = jrt.Intern("arbace.c.check$check_block_items$fn__1876000878")

var Lit_124 *jrt.String = jrt.Intern("arbace.c.check$check_block_items$fn__1876000883")

var Lit_125 *jrt.String = jrt.Intern("static assertion failed")

var Lit_126 *jrt.String = jrt.Intern("two or more data types in declaration specifiers")

var Lit_127 *jrt.String = jrt.Intern("storage class specifier '_Thread_local' in a function declaration")

var Lit_128 *jrt.String = jrt.Intern("arbace.c.check$check_defn$fn__1876000796")

var Lit_129 *jrt.String = jrt.Intern("arbace.c.check$check_defn$fn__1876000808")

var Lit_130 *jrt.String = jrt.Intern("arbace.c.check$check_defn$fn__1876000813")

var Lit_131 *jrt.String = jrt.Intern("old-style function definition")

var Lit_132 *jrt.String = jrt.Intern("invalid 'enum' underlying type")

var Lit_133 *jrt.String = jrt.Intern("'enum' declared both with and without fixed underlying type")

var Lit_134 *jrt.String = jrt.Intern("'enum' declared with but defined without fixed underlying type")

var Lit_135 *jrt.String = jrt.Intern("nested redefinition of 'enum ")

var Lit_136 *jrt.String = jrt.Intern("arbace.c.check$check_enum$fn__1876000398")

var Lit_137 *jrt.String = jrt.Intern("enumerator value outside the range of the underlying type")

var Lit_138 *jrt.String = jrt.Intern("overflow in enumeration values")

var Lit_139 *jrt.String = jrt.Intern("n ")

var Lit_140 *jrt.String = jrt.Intern(" ")

var Lit_141 *jrt.String = jrt.Intern("?")

var Lit_142 *jrt.String = jrt.Intern("arbace.c.check$check_enum$fn__1876000403")

var Lit_143 *jrt.String = jrt.Intern("redefinition of 'enum ")

var Lit_144 *jrt.String = jrt.Intern("arbace.c.check$check_enum$fn__1876000405")

var Lit_145 *jrt.String = jrt.Intern("enumeration values exceed range of largest integer")

var Lit_146 *jrt.String = jrt.Intern("arbace.c.check$check_enum$fn__1876000407")

var Lit_147 *jrt.String = jrt.Intern("redeclaration of enumerator '")

var Lit_148 *jrt.String = jrt.Intern("initialization")

var Lit_149 *jrt.String = jrt.Intern("arbace.c.check$check_stmt$fn__1876000888")

var Lit_150 *jrt.String = jrt.Intern("' statement with an identifier operand before C2Y")

var Lit_151 *jrt.String = jrt.Intern("switch quantity not an integer")

var Lit_152 *jrt.String = jrt.Intern("arbace.c.check$check_stmt$fn__1876000890")

var Lit_153 *jrt.String = jrt.Intern("arbace.c.check$check_stmt$fn__1876000895")

var Lit_154 *jrt.String = jrt.Intern("return")

var Lit_155 *jrt.String = jrt.Intern("arbace.c.check$check_stmt$fn__1876000900")

var Lit_156 *jrt.String = jrt.Intern("arbace.c.check$check_stmt$fn__1876000902")

var Lit_157 *jrt.String = jrt.Intern("ISO C does not support if declarations before C2Y")

var Lit_158 *jrt.String = jrt.Intern("arbace.c.check$check_stmt$fn__1876000907")

var Lit_159 *jrt.String = jrt.Intern("arbace.c.check$check_stmt$fn__1876000909")

var Lit_160 *jrt.String = jrt.Intern("arbace.c.check$check_stmt$fn__1876000911")

var Lit_161 *jrt.String = jrt.Intern("arbace.c.check$check_stmt$iv__1876000918")

var Lit_162 *jrt.String = jrt.Intern("arbace.c.check$check_stmt$fn__1876000921")

var Lit_163 *jrt.String = jrt.Intern("duplicate case value")

var Lit_164 *jrt.String = jrt.Intern("ISO C does not support range expressions in switch statements before C2Y")

var Lit_165 *jrt.String = jrt.Intern("nested redefinition of '")

var Lit_166 *jrt.String = jrt.Intern("arbace.c.check$check_struct$fn__1876000354")

var Lit_167 *jrt.String = jrt.Intern("arbace.c.check$check_struct$fn__1876000356")

var Lit_168 *jrt.String = jrt.Intern("arbace.c.check$check_struct$fn__1876000358")

var Lit_169 *jrt.String = jrt.Intern("redefinition of '")

var Lit_170 *jrt.String = jrt.Intern("s ")

var Lit_171 *jrt.String = jrt.Intern("arbace.c.check$check_struct$fn__1876000360")

var Lit_172 *jrt.String = jrt.Intern("arbace.c.check$check_struct$fn__1876000362")

var Lit_173 *jrt.String = jrt.Intern("#anon")

var Lit_174 *jrt.String = jrt.Intern("packed")

var Lit_175 *jrt.String = jrt.Intern("aligned")

var Lit_176 *jrt.String = jrt.Intern("transparent_union")

var Lit_177 *jrt.String = jrt.Intern("arbace.c.check$check_top$fn__1876000942")

var Lit_178 *jrt.String = jrt.Intern("arbace.c.check$check_top$read_info__1876000944")

var Lit_179 *jrt.String = jrt.Intern("arbace.c.check$check_top$norm__1876000950")

var Lit_180 *jrt.String = jrt.Intern("arbace.c.check$check_top$fn__1876000952")

var Lit_181 *jrt.String = jrt.Intern("arbace.c.check$check_top$fn__1876000954")

var Lit_182 *jrt.String = jrt.Intern("arbace.c.check$check_top$fn__1876000956")

var Lit_183 *jrt.String = jrt.Intern("arbace.c.check$check_top$fn__1876000965")

var Lit_184 *jrt.String = jrt.Intern("arbace.c.check$check_top$fn__1876000970")

var Lit_185 *jrt.String = jrt.Intern("/")

var Lit_186 *jrt.String = jrt.Intern("ISO-8859-1")

var Lit_187 *jrt.String = jrt.Intern("arbace.c.check$check_top$read_info__1876000944$fn__1876000945")

var Lit_188 *jrt.String = jrt.Intern("arbace.c.check$check_top$read_info__1876000944$fn__1876000947")

var Lit_189 *jrt.String = jrt.Intern("__extension__")

var Lit_190 *jrt.String = jrt.Intern("arbace.c.check$check_typedef$fn__1876000825")

var Lit_191 *jrt.String = jrt.Intern("arbace.c.check$check_typedef$fn__1876000827")

var Lit_192 *jrt.String = jrt.Intern("_Bool")

var Lit_193 *jrt.String = jrt.Intern("bool")

var Lit_194 *jrt.String = jrt.Intern("' cannot be defined via 'typedef'")

var Lit_195 *jrt.String = jrt.Intern("conflicting types for '")

var Lit_196 *jrt.String = jrt.Intern("d ")

var Lit_197 *jrt.String = jrt.Intern(" n ")

var Lit_198 *jrt.String = jrt.Intern("arbace.c.check$check_unit$iter__1876000977__1876000981")

var Lit_199 *jrt.String = jrt.Intern("arbace.c.check$check_unit$fn__1876000993")

var Lit_200 *jrt.String = jrt.Intern("arbace.c.check$check_unit$fn__1876001007")

var Lit_201 *jrt.String = jrt.Intern("arbace.c.check$check_unit$fn__1876001009")

var Lit_202 *jrt.String = jrt.Intern(": ")

var Lit_203 *jrt.String = jrt.Intern("arbace.c.check$check_unit$fn__1876000993$fn__1876000998")

var Lit_204 *jrt.String = jrt.Intern("arbace.c.check$check_unit$fn__1876000993$fn__1876001000")

var Lit_205 *jrt.String = jrt.Intern("arbace.c.check$check_unit$iter__1876000977__1876000981$fn__1876000982")

var Lit_206 *jrt.String = jrt.Intern("arbace.c.check$check_unit$iter__1876000977__1876000981$fn__1876000982$fn__1876000983")

var Lit_207 *jrt.String = jrt.Intern("arbace.c.check$check_var$fn__1876000770")

var Lit_208 *jrt.String = jrt.Intern("zero or negative size array")

var Lit_209 *jrt.String = jrt.Intern("variable-sized object may not be initialized except with an empty initializer")

var Lit_210 *jrt.String = jrt.Intern("array initialized from a string literal with type array of unsigned char")

var Lit_211 *jrt.String = jrt.Intern("array size missing in '")

var Lit_212 *jrt.String = jrt.Intern("storage size of '")

var Lit_213 *jrt.String = jrt.Intern("' isn't known")

var Lit_214 *jrt.String = jrt.Intern("arbace.c.check$check_var$fn__1876000772")

var Lit_215 *jrt.String = jrt.Intern("arbace.c.check$code_unit_count$fn__1876000449")

var Lit_216 *jrt.String = jrt.Intern("arbace.c.check$compatible_QMARK_$fn__1876000092")

var Lit_217 *jrt.String = jrt.Intern("arbace.c.check$compatible_QMARK_$fn__1876000094")

var Lit_218 *jrt.String = jrt.Intern("arbace.c.check$compatible_QMARK_$fn__1876000096")

var Lit_219 *jrt.String = jrt.Intern("arbace.c.check$compatible_QMARK_$fn__1876000098")

var Lit_220 *jrt.String = jrt.Intern("arbace.c.check$composite$mv__1876000716")

var Lit_221 *jrt.String = jrt.Intern("arbace.c.check$composite$pick__1876000718")

var Lit_222 *jrt.String = jrt.Intern("arbace.c.check$composite$pick__1876000718$memb_QMARK___1876000719")

var Lit_223 *jrt.String = jrt.Intern("function types not truly compatible in ISO C")

var Lit_224 *jrt.String = jrt.Intern("arbace.c.check$composite$pick__1876000718$memb_QMARK___1876000719$fn__1876000720")

var Lit_225 *jrt.String = jrt.Intern("type mismatch in conditional expression")

var Lit_226 *jrt.String = jrt.Intern("pointer type mismatch in conditional expression")

var Lit_227 *jrt.String = jrt.Intern("arbace.c.check$const_int$fn__1876000708")

var Lit_228 *jrt.String = jrt.Intern("arbace.c.check$constexpr_check_BANG_$fn__1876000755")

var Lit_229 *jrt.String = jrt.Intern("arbace.c.check$constexpr_check_BANG_$fn__1876000764")

var Lit_230 *jrt.String = jrt.Intern("'constexpr' initializer not representable in type of object")

var Lit_231 *jrt.String = jrt.Intern("'constexpr' integer initializer is not an integer constant expression")

var Lit_232 *jrt.String = jrt.Intern("'constexpr' initializer for a binary floating-point type is of decimal type")

var Lit_233 *jrt.String = jrt.Intern("' attribute can only be applied to functions")

var Lit_234 *jrt.String = jrt.Intern("nodiscard")

var Lit_235 *jrt.String = jrt.Intern("'nodiscard' attribute can only be applied to functions or to structure, union or enumeration types")

var Lit_236 *jrt.String = jrt.Intern("standard '")

var Lit_237 *jrt.String = jrt.Intern("' attribute can only be applied to function declarators or type specifiers with function type")

var Lit_238 *jrt.String = jrt.Intern("' cannot be used here")

var Lit_239 *jrt.String = jrt.Intern("arbace.c.check$declare_object_BANG_$tyof_QMARK___1876000726")

var Lit_240 *jrt.String = jrt.Intern("arbace.c.check$declare_object_BANG_$fn__1876000728")

var Lit_241 *jrt.String = jrt.Intern("invalid type argument of unary '*'")

var Lit_242 *jrt.String = jrt.Intern("e ")

var Lit_243 *jrt.String = jrt.Intern(" = ")

var Lit_244 *jrt.String = jrt.Intern("arbace.c.check$enum_type_of$fits__1876000370")

var Lit_245 *jrt.String = jrt.Intern("arbace.c.check$enum_type_of$fits__1876000370$fn__1876000371")

var Lit_246 *jrt.String = jrt.Intern(":")

var Lit_247 *jrt.String = jrt.Intern("java.util.ArrayList")

var Lit_248 *jrt.String = jrt.Intern("java.util.HashMap")

var Lit_249 *jrt.String = jrt.Intern("java.util.HashSet")

var Lit_250 *jrt.String = jrt.Intern("java.util.IdentityHashMap")

var Lit_251 *jrt.String = jrt.Intern("_")

var Lit_252 *jrt.String = jrt.Intern("e *fn()int")

var Lit_253 *jrt.String = jrt.Intern("wrong type argument to unary ")

var Lit_254 *jrt.String = jrt.Intern("imaginary constants are a C2Y feature or GCC extension")

var Lit_255 *jrt.String = jrt.Intern("arbace.c.check$ex_STAR_$fn__1876000669")

var Lit_256 *jrt.String = jrt.Intern("assignment")

var Lit_257 *jrt.String = jrt.Intern("'_Alignof' applied to a bit-field")

var Lit_258 *jrt.String = jrt.Intern("ISO C does not support '++' and '--' on complex types before C2Y")

var Lit_259 *jrt.String = jrt.Intern("'sizeof' applied to a bit-field")

var Lit_260 *jrt.String = jrt.Intern("cannot take address of bit-field")

var Lit_261 *jrt.String = jrt.Intern("array of unknown size with empty initializer")

var Lit_262 *jrt.String = jrt.Intern("compound literal has variable size")

var Lit_263 *jrt.String = jrt.Intern("arbace.c.check$ex_STAR_$fn__1876000685")

var Lit_264 *jrt.String = jrt.Intern("conversion of ")

var Lit_265 *jrt.String = jrt.Intern(" to nullptr_t")

var Lit_266 *jrt.String = jrt.Intern("conversion of nullptr_t to ")

var Lit_267 *jrt.String = jrt.Intern("wrong type argument to bit-complement")

var Lit_268 *jrt.String = jrt.Intern("invalid application of 'alignof' to incomplete type")

var Lit_269 *jrt.String = jrt.Intern("arbace.c.check$ex_STAR_$fn__1876000704")

var Lit_270 *jrt.String = jrt.Intern(".-")

var Lit_271 *jrt.String = jrt.Intern("abs")

var Lit_272 *jrt.String = jrt.Intern("compareTo")

var Lit_273 *jrt.String = jrt.Intern("not an integer constant expression")

var Lit_274 *jrt.String = jrt.Intern("doubleValue")

var Lit_275 *jrt.String = jrt.Intern("arbace.c.check$fn__1876000493$iter__1876000494__1876000502")

var Lit_276 *jrt.String = jrt.Intern("arbace.c.check$fn__1876000493$iter__1876000494__1876000502$fn__1876000503")

var Lit_277 *jrt.String = jrt.Intern("arbace.c.check$fn__1876000493$iter__1876000494__1876000502$fn__1876000503$iter__1876000496__1876000507")

var Lit_278 *jrt.String = jrt.Intern("arbace.c.check$fn__1876000493$iter__1876000494__1876000502$fn__1876000503$iter__1876000496__1876000507$fn__1876000508")

var Lit_279 *jrt.String = jrt.Intern("arbace.c.check$fn__1876000493$iter__1876000494__1876000502$fn__1876000503$iter__1876000496__1876000507$fn__1876000508$iter__1876000498__1876000509")

var Lit_280 *jrt.String = jrt.Intern("l")

var Lit_281 *jrt.String = jrt.Intern("arbace.c.check$fn__1876000493$iter__1876000494__1876000502$fn__1876000503$iter__1876000496__1876000507$fn__1876000508$iter__1876000498__1876000509$fn__1876000510")

var Lit_282 *jrt.String = jrt.Intern("arbace.c.check$fn__1876000493$iter__1876000494__1876000502$fn__1876000503$iter__1876000496__1876000507$fn__1876000508$iter__1876000498__1876000509$fn__1876000510$fn__1876000511")

var Lit_283 *jrt.String = jrt.Intern("ISO C does not support use of type name as the controlling operand of '_Generic' before C2Y")

var Lit_284 *jrt.String = jrt.Intern("arbace.c.check$generic_select$iter__1876000594__1876000598")

var Lit_285 *jrt.String = jrt.Intern("arbace.c.check$generic_select$iter__1876000594__1876000598$fn__1876000599")

var Lit_286 *jrt.String = jrt.Intern("arbace.c.check$generic_select$iter__1876000594__1876000598$fn__1876000599$fn__1876000600")

var Lit_287 *jrt.String = jrt.Intern("ISO C does not support '_Generic' association with function type before C2Y")

var Lit_288 *jrt.String = jrt.Intern("ISO C does not support '_Generic' association with incomplete type before C2Y")

var Lit_289 *jrt.String = jrt.Intern("' undeclared")

var Lit_290 *jrt.String = jrt.Intern("unexpected type name '")

var Lit_291 *jrt.String = jrt.Intern("' attribute ignored")

var Lit_292 *jrt.String = jrt.Intern("arbace.c.check$init_count$per__1876000612")

var Lit_293 *jrt.String = jrt.Intern("arbace.c.check$init_count$per__1876000612$fn__1876000614")

var Lit_294 *jrt.String = jrt.Intern("arbace.c.check$layout_BANG_$fn__1876000263")

var Lit_295 *jrt.String = jrt.Intern("arbace.c.check$layout_BANG_$fn__1876000265")

var Lit_296 *jrt.String = jrt.Intern("arbace.c.check$layout_BANG_$fn__1876000267")

var Lit_297 *jrt.String = jrt.Intern("arbace.c.check$layout_BANG_$fn__1876000269")

var Lit_298 *jrt.String = jrt.Intern("arbace.c.check$layout_BANG_$fn__1876000271")

var Lit_299 *jrt.String = jrt.Intern("arbace.c.check$layout_BANG_$fn__1876000273")

var Lit_300 *jrt.String = jrt.Intern("non-standard suffix on floating constant")

var Lit_301 *jrt.String = jrt.Intern("arbace.c.check$mcompat_QMARK_$fn__1876000085")

var Lit_302 *jrt.String = jrt.Intern("arbace.c.check$member$fn__1876000276")

var Lit_303 *jrt.String = jrt.Intern("arbace.c.check$member_forms$fn__1876000309")

var Lit_304 *jrt.String = jrt.Intern("arbace.c.check$member_forms$fn__1876000309$fn__1876000313")

var Lit_305 *jrt.String = jrt.Intern("arbace.c.check$member_forms$fn__1876000309$fn__1876000315")

var Lit_306 *jrt.String = jrt.Intern("arbace.c.check$member_forms$fn__1876000309$fn__1876000317")

var Lit_307 *jrt.String = jrt.Intern("arbace.c.check$member_forms$fn__1876000309$fn__1876000319")

var Lit_308 *jrt.String = jrt.Intern("arbace.c.check$member_forms$fn__1876000309$fn__1876000321")

var Lit_309 *jrt.String = jrt.Intern("arbace.c.check$member_forms$fn__1876000309$fn__1876000324")

var Lit_310 *jrt.String = jrt.Intern("invalid use of incomplete type '")

var Lit_311 *jrt.String = jrt.Intern("no member named '")

var Lit_312 *jrt.String = jrt.Intern("' in '")

var Lit_313 *jrt.String = jrt.Intern("request for member '")

var Lit_314 *jrt.String = jrt.Intern("' in something not a structure or union")

var Lit_315 *jrt.String = jrt.Intern("sub")

var Lit_316 *jrt.String = jrt.Intern("add")

var Lit_317 *jrt.String = jrt.Intern("arbace.c.check$params_of$fn__1876000775")

var Lit_318 *jrt.String = jrt.Intern("arbace.c.check$params_of$adj__1876000778")

var Lit_319 *jrt.String = jrt.Intern("unknown type name '")

var Lit_320 *jrt.String = jrt.Intern("ISO C requires a named argument before '...'")

var Lit_321 *jrt.String = jrt.Intern("arbace.c.check$parse_type$fn__1876000299")

var Lit_322 *jrt.String = jrt.Intern("'typeof_unqual' applied to a bit-field")

var Lit_323 *jrt.String = jrt.Intern("'typeof' applied to a bit-field")

var Lit_324 *jrt.String = jrt.Intern("unknown type form ")

var Lit_325 *jrt.String = jrt.Intern("arbace.c.check$parse_type$fn__1876000299$fn__1876000300")

var Lit_326 *jrt.String = jrt.Intern("arbace.c.check$pragma_pack_BANG_$fn__1876000928")

var Lit_327 *jrt.String = jrt.Intern("arbace.c.check$pragma_pack_BANG_$fn__1876000930")

var Lit_328 *jrt.String = jrt.Intern("incompatible types when converting nullptr_t to ")

var Lit_329 *jrt.String = jrt.Intern(" in ")

var Lit_330 *jrt.String = jrt.Intern("incompatible types when converting ")

var Lit_331 *jrt.String = jrt.Intern(" to nullptr_t in ")

var Lit_332 *jrt.String = jrt.Intern(" discards qualifier from pointer target type")

var Lit_333 *jrt.String = jrt.Intern(": incompatible pointer type ")

var Lit_334 *jrt.String = jrt.Intern(" to ")

var Lit_335 *jrt.String = jrt.Intern("arbace.c.check$rec_same_QMARK_$fn__1876000342")

var Lit_336 *jrt.String = jrt.Intern("arbace.c.check$rec_same_QMARK_$fn__1876000344")

var Lit_337 *jrt.String = jrt.Intern("arbace.c.check$rec_same_QMARK_$fn__1876000346")

var Lit_338 *jrt.String = jrt.Intern("arbace.c.check$round_exact$two__1876000422")

var Lit_339 *jrt.String = jrt.Intern("arbace.c.check$round_exact$fn__1876000424")

var Lit_340 *jrt.String = jrt.Intern("scalb")

var Lit_341 *jrt.String = jrt.Intern("arbace.c.check$spec_attrs_packed$fn__1876000291")

var Lit_342 *jrt.String = jrt.Intern("' attribute does not take any arguments")

var Lit_343 *jrt.String = jrt.Intern("parentheses must be omitted if attribute argument list is empty")

var Lit_344 *jrt.String = jrt.Intern("expected string-literal in the '")

var Lit_345 *jrt.String = jrt.Intern("' attribute")

var Lit_346 *jrt.String = jrt.Intern("ISO C does not support '[[]]' attributes before C23")

var Lit_347 *jrt.String = jrt.Intern("arbace.c.check$std_names$iter__1876000158__1876000162")

var Lit_348 *jrt.String = jrt.Intern("arbace.c.check$std_names$iter__1876000158__1876000162$fn__1876000163")

var Lit_349 *jrt.String = jrt.Intern("arbace.c.check$std_names$iter__1876000158__1876000162$fn__1876000163$fn__1876000164")

var Lit_350 *jrt.String = jrt.Intern("' attribute can only be applied to declarations other than labels")

var Lit_351 *jrt.String = jrt.Intern("arbace.c.check$string_bytes$bs__1876000734")

var Lit_352 *jrt.String = jrt.Intern("arbace.c.check$string_bytes$bs__1876000734$fn__1876000735")

var Lit_353 *jrt.String = jrt.Intern("arbace.c.check$string_bytes$bs__1876000734$fn__1876000735$fn__1876000736")

var Lit_354 *jrt.String = jrt.Intern("' declared in underspecified object initializer")

var Lit_355 *jrt.String = jrt.Intern("arbace.c.check$tstr$w__1876000070")

var Lit_356 *jrt.String = jrt.Intern("nullptr_t")

var Lit_357 *jrt.String = jrt.Intern("fn(")

var Lit_358 *jrt.String = jrt.Intern(",")

var Lit_359 *jrt.String = jrt.Intern("...")

var Lit_360 *jrt.String = jrt.Intern("void")

var Lit_361 *jrt.String = jrt.Intern(")")

var Lit_362 *jrt.String = jrt.Intern("[*]")

var Lit_363 *jrt.String = jrt.Intern("[]")

var Lit_364 *jrt.String = jrt.Intern("[")

var Lit_365 *jrt.String = jrt.Intern("]")

var Lit_366 *jrt.String = jrt.Intern("_Complex ")

var Lit_367 *jrt.String = jrt.Intern("*")

var Lit_368 *jrt.String = jrt.Intern("unsigned _BitInt(")

var Lit_369 *jrt.String = jrt.Intern("signed char")

var Lit_370 *jrt.String = jrt.Intern("long long")

var Lit_371 *jrt.String = jrt.Intern("double")

var Lit_372 *jrt.String = jrt.Intern("char")

var Lit_373 *jrt.String = jrt.Intern("_Decimal32")

var Lit_374 *jrt.String = jrt.Intern("_Float64x")

var Lit_375 *jrt.String = jrt.Intern("_Float32x")

var Lit_376 *jrt.String = jrt.Intern("__bf16")

var Lit_377 *jrt.String = jrt.Intern("_Float32")

var Lit_378 *jrt.String = jrt.Intern("unsigned char")

var Lit_379 *jrt.String = jrt.Intern("unsigned __int128")

var Lit_380 *jrt.String = jrt.Intern("unsigned short")

var Lit_381 *jrt.String = jrt.Intern("_Float128")

var Lit_382 *jrt.String = jrt.Intern("_Float64")

var Lit_383 *jrt.String = jrt.Intern("float")

var Lit_384 *jrt.String = jrt.Intern("unsigned long long")

var Lit_385 *jrt.String = jrt.Intern("unsigned long")

var Lit_386 *jrt.String = jrt.Intern("_Decimal64x")

var Lit_387 *jrt.String = jrt.Intern("_Float16")

var Lit_388 *jrt.String = jrt.Intern("_Decimal64")

var Lit_389 *jrt.String = jrt.Intern("long")

var Lit_390 *jrt.String = jrt.Intern("int")

var Lit_391 *jrt.String = jrt.Intern("long double")

var Lit_392 *jrt.String = jrt.Intern("_Float128x")

var Lit_393 *jrt.String = jrt.Intern("_Decimal128")

var Lit_394 *jrt.String = jrt.Intern("unsigned")

var Lit_395 *jrt.String = jrt.Intern("__int128")

var Lit_396 *jrt.String = jrt.Intern("short")

var Lit_397 *jrt.String = jrt.Intern("arbace.c.check$type_mode$fn__1876000284")

var Lit_398 *jrt.String = jrt.Intern("arbace.c.check$type_mode$fn__1876000286")

var Lit_399 *jrt.String = jrt.Intern("arbace.c.check$union_param_match_QMARK_$fn__1876000088")

var Lit_400 *jrt.String = jrt.Intern("arbace.c.check$vectorize$fn__1876000231")

var Lit_401 *jrt.String = jrt.Intern("HI")

var Lit_402 *jrt.String = jrt.Intern("DF")

var Lit_403 *jrt.String = jrt.Intern("DI")

var Lit_404 *jrt.String = jrt.Intern("byte")

var Lit_405 *jrt.String = jrt.Intern("word")

var Lit_406 *jrt.String = jrt.Intern("SF")

var Lit_407 *jrt.String = jrt.Intern("TI")

var Lit_408 *jrt.String = jrt.Intern("SI")

var Lit_409 *jrt.String = jrt.Intern("QI")

var Lit_410 *jrt.String = jrt.Intern("pointer")

var Lit_411 *jrt.String = jrt.Intern("arbace.c.check$vectorize$fn__1876000240")

var Lit_412 *jrt.String = jrt.Intern("invalid vector type for attribute 'vector_size'")

var Lit_413 *jrt.String = jrt.Intern("mode")

var Lit_414 *jrt.String = jrt.Intern("vector_size")

var Lit_415 *jrt.String = jrt.Intern("arbace.c.check$vla_struct_QMARK_$fn__1876000337")

var Lit_416 *jrt.String = jrt.Intern("arbace.c.check$vm_type_QMARK_$fn__1876000332")

var Lit_417 *jrt.String = jrt.Intern("arbace.c.check$vm_type_QMARK_$fn__1876000334")

var Lit_418 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,dynamickn4,linekn6,columnkn4,filekn7,privatekn8,arglistsyn1,kkn3,tagyn6,Stringyn1,fyn1,ryn1,&yn4,bodykn1,kkn4,voidkn4,boolkn4,charkn3,intkn4,uintkn4,longkn5,ulongkn5,llongkn6,doublekn5,floatkn7,invalidkn7,nullptryn1,tyn1,nyn10,_Decimal32kn5,dec32yn11,long-doublekn7,ldoubleyn8,unsignedyn10,_Float128xkn9,float128xyn11,_Decimal128kn6,dec128yn13,unsigned-charkn5,ucharyn4,charyn13,unsigned-longyn10,__float128kn8,float128yn8,_Float16kn7,float16yn11,_Decimal64xkn6,dec64xyn4,longyn6,doubleyn5,shortkn5,shortyn9,_Float32xkn8,float32xyn3,intyn18,unsigned-long-longkn6,ullongyn5,floatyn8,_Float32kn7,float32yn8,_Float64kn7,float64yn9,long-longyn9,__float80yn9,_Float128yn9,_Float64xkn8,float64xyn4,voidyn11,signed-charkn5,scharyn5,_Boolyn8,__int128kn6,int128yn10,_Decimal64kn5,dec64yn6,__bf16kn4,bf16yn14,unsigned-shortkn6,ushortyn17,unsigned-__int128kn7,uint128yn1,qyn1,vkn8,declaredyn16,java.lang.Stringyn1,ayn1,byn1,uyn1,oyn4,bitsyn1,eyn1,xys1,c12,local-labelsys1,c3,varys1,c13,static-assertys1,c6,structys1,c5,unionys1,c4,enumys1,c7,declareys1,c7,typedefys1,c5,groupys1,c4,defnys1,c9,attr-declys1,c13,declare-specsys1,c7,includeys1,c14,expr-directiveys1,c9,directiveys1,c3,asmys1,c6,defineys1,c5,undefys1,c6,pragmayn3,gnuyn1,myn2,ksks1,c5,attrsks1,c10,decl-attrsks1,c11,after-attrsks1,c10,list-attrsks1,c14,decl-end-attrsks1,c9,def-attrsks1,c9,end-attrsks1,c9,gnu-attrsv11,arbace.core5,in-nsMyn14,arbace.c.checkm2,R0,s1792,The checker over C forms (doc/c/SPEC.md §11.2; doc/C23-SURVEY.md, C4, \"As built: C4\"): every\n  expression's type and constant value, the integer promotions and the usual arithmetic conversions\n  (6.3), lvalue, array and function conversions, null pointer constants, constant expressions and their\n  values (6.6: enumerators, sizeof, alignof, constexpr objects, case labels, array sizes), layout by the\n  SysV x86-64 psABI as gcc 15.2 lays out (sizes, alignments, members' offsets, bit-fields, packed,\n  aligned), linkage (6.2.2), arrays completed by their initializers, `auto`'s, `__auto_type`'s and\n  `typeof`'s types, `_Generic`'s selection, `_BitInt`. Arbace's own (CS8 (a)); cc's checker is its oracle\n  where it succeeds (bin/ci annotations, arbace.repr.c.annot).\n\n  `check-unit` checks a read's forms (arbace.repr.c/read-c's) and returns its errors (the reference's\n  errors the checker diagnoses: only those gcc 15.2 gives, as errors) and, when asked, the annotations\n  of every main-file item in tools/ccdump's types format. A header unit's forms are checked where their\n  c/include stands, without annotations. Moved from arbace/repr/c/ as arbace.c.check in C5 (CS90 (a)),\n  with ci's namespaces; `:results` gives ci's builder each form's result (CS95 (a)).\n\n  Types are maps: {:k KIND} for the base types (:void :bool :char :schar :uchar :short :ushort :int :uint\n  :long :ulong :llong :ullong :int128 :uint128 :float :double :ldouble and the other floating types),\n  {:k :bitint :n N :u bool}, {:k :complex :of T}, {:k :ptr :to T}, {:k :array :of T :n N-or-nil :vla bool},\n  {:k :fn :ret T :params [T] :variadic bool :proto bool}, {:k :struct|:union|:enum :rec R} (R a mutable\n  record of the tag: its members, layout, completeness), {:k :nullptr}, {:k :invalid}; qualifiers in :q.m2,R0,s1792,The checker over C forms (doc/c/SPEC.md §11.2; doc/C23-SURVEY.md, C4, \"As built: C4\"): every\n  expression's type and constant value, the integer promotions and the usual arithmetic conversions\n  (6.3), lvalue, array and function conversions, null pointer constants, constant expressions and their\n  values (6.6: enumerators, sizeof, alignof, constexpr objects, case labels, array sizes), layout by the\n  SysV x86-64 psABI as gcc 15.2 lays out (sizes, alignments, members' offsets, bit-fields, packed,\n  aligned), linkage (6.2.2), arrays completed by their initializers, `auto`'s, `__auto_type`'s and\n  `typeof`'s types, `_Generic`'s selection, `_BitInt`. Arbace's own (CS8 (a)); cc's checker is its oracle\n  where it succeeds (bin/ci annotations, arbace.repr.c.annot).\n\n  `check-unit` checks a read's forms (arbace.repr.c/read-c's) and returns its errors (the reference's\n  errors the checker diagnoses: only those gcc 15.2 gives, as errors) and, when asked, the annotations\n  of every main-file item in tools/ccdump's types format. A header unit's forms are checked where their\n  c/include stands, without annotations. Moved from arbace/repr/c/ as arbace.c.check in C5 (CS90 (a)),\n  with ci's namespaces; `:results` gives ci's builder each form's result (CS95 (a)).\n\n  Types are maps: {:k KIND} for the base types (:void :bool :char :schar :uchar :short :ushort :int :uint\n  :long :ulong :llong :ullong :int128 :uint128 :float :double :ldouble and the other floating types),\n  {:k :bitint :n N :u bool}, {:k :complex :of T}, {:k :ptr :to T}, {:k :array :of T :n N-or-nil :vla bool},\n  {:k :fn :ret T :params [T] :variadic bool :proto bool}, {:k :struct|:union|:enum :rec R} (R a mutable\n  record of the tag: its members, layout, completeness), {:k :nullptr}, {:k :invalid}; qualifiers in :q.R1,v11,arbace.core20,*warn-on-reflection*v14,arbace.c.check4,*cx*m8,R2,TR3,i30,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check6,*line*l0,m8,R2,TR3,i31,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check6,*unit*m8,R2,TR3,i34,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check11,*unit-info*m10,R2,TR3,i35,R4,i1,R5,s17,arbace/c/check.aeR0,s302,CS214 (R5): a delay of the unit being checked (*unit*) read from its file when it can be: {:ext the lines with `__extension__`\n  :pragma whether it has a `#pragma GCC system_header` line (review 031's finding F)}; read only when a pedwarn is judged. The\n  main file's ext lines are the cx's :ext-lines.v14,arbace.c.check12,*unit-line?*m10,R2,TR3,i39,R4,i1,R5,s17,arbace/c/check.aeR0,s218,CS214 (R5): whether *line* is the line of a form in its own unit's file (a reread unit's forms carry :line); the forms\n  read from C carry none in a unit, and *line* is then the line of the `#include` in the main file.v14,arbace.c.check13,*system-unit*m10,R2,TR3,i42,R4,i1,R5,s17,arbace/c/check.aeR0,s147,CS214 (R5): whether the unit being checked is a system header (its file under a directory of the host's search list):\n  gcc gives no pedwarn there.v14,arbace.c.check8,*switch*m8,R2,TR3,i45,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check2,cxm10,R6,TR7,L1,V1,R8,R3,i47,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check4,ann!m12,R6,TR7,L1,V1,Myn1,sm2,R9,R10,R0,s63,An annotation line of the item being checked (when annotating).R3,i49,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check5,feat!m12,R6,TR7,L1,V1,R8,R0,s161,A feature of the item being checked that cc's checker is known not to handle as gcc does (the classes\n  of bin/ci annotations' differences, arbace.repr.c.annot).R3,i58,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check4,err!m12,R6,TR7,L1,V1,Myn3,msgm2,R9,R10,R0,s55,An error of the reference's that the checker diagnoses.R3,i64,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check8,pedwarn!m12,R6,TR7,L1,V1,Myn3,msgm2,R9,R10,R0,s145,A pedwarn of gcc's, an error under -pedantic-errors (CS132): only when the file's options ask for that, and not\n  on a line with `__extension__`.R3,i71,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check7,line-ofm10,R6,TR7,L1,V1,R11,R3,i81,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check7,record!m12,R6,TR7,L1,V2,R11,R12,R0,s187,CS95 (a): the result of the form `f` (an expression's {:t :v :lv :bits ...}, a declarator's entry) in\n  the identity map of a check-unit asked for :results (ci's builder, arbace.c.build).R3,i83,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check7,at-linem10,R6,TR7,L1,V3,R11,R13,R14,R3,i91,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check7,std-numm12,R6,TR7,L1,V0,R0,s65,The file's standard as a year: 89, 99, 11, 17, 23 (and 94 as 89).R3,i94,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check4,c23?m10,R6,TR7,L1,V0,R3,i99,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check4,c99?m10,R6,TR7,L1,V0,R3,i100,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check12,pedwarn-c2y!m12,R6,TR7,L1,V1,Myn3,msgm2,R9,R10,R0,s94,A pedwarn about a C2y feature used in C23 (Wc23-c2y-compat; -Wno-c23-c2y-compat turns it off).R3,i102,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check10,bit-field?m12,R6,TR7,L1,V1,R12,R0,s248,An expression's result that designates a bit-field: a member access (an lvalue) of one. An assignment's or an increment's\n  result keeps the width for its promotions but is no lvalue, so sizeof, typeof and _Alignof take it (review 027's finding 7).R3,i110,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check6,t-voidm2,R15,R16,m6,R3,i116,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check6,t-boolm2,R15,R17,m6,R3,i117,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check6,t-charm2,R15,R18,m6,R3,i118,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check5,t-intm2,R15,R19,m6,R3,i119,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check6,t-uintm2,R15,R20,m6,R3,i120,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check6,t-longm2,R15,R21,m6,R3,i121,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check7,t-ulongm2,R15,R22,m6,R3,i122,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check7,t-llongm2,R15,R23,m6,R3,i123,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check8,t-doublem2,R15,R24,m6,R3,i124,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check7,t-floatm2,R15,R25,m6,R3,i125,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check9,t-invalidm2,R15,R26,m6,R3,i126,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check9,t-nullptrm2,R15,R27,m6,R3,i127,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check3,ptrm8,R7,L1,V1,R28,R3,i129,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check3,arrm8,R7,L1,V2,R28,R29,R3,i130,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check9,base-symsm64,R30,R31,R32,R33,R34,R20,R35,R36,R37,R38,R39,R40,R41,R18,R42,R22,R43,R44,R45,R46,R47,R48,R49,R21,R50,R24,R51,R52,R53,R54,R55,R19,R56,R57,R58,R25,R59,R60,R61,R62,R63,R23,R64,R33,R65,R44,R66,R67,R68,R16,R69,R70,R71,R17,R72,R73,R74,R75,R76,R77,R78,R79,R80,R81,m8,R6,TR3,i132,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check8,int-infom28,R17,V3,l1,Fl10,R18,V3,l8,Tl85,R70,V3,l8,Tl85,R40,V3,l8,Fl85,R52,V3,l16,Tl165,R79,V3,l16,Fl165,R19,V3,l32,Tl325,R20,V3,l32,Fl325,R21,V3,l64,Tl645,R22,V3,l64,Fl645,R23,V3,l64,Tl646,R57,V3,l64,Fl646,R73,V3,l128,Tl1285,R81,V3,l128,Fl1285,m8,R6,TR3,i143,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check10,float-rankm30,R46,l1,R77,l1,R25,l2,R60,l2,R24,l3,R62,l3,R54,l3,R33,l4,R67,l4,R44,l5,R36,l5,R31,l1,R75,l2,R38,l3,R48,l3,m8,R6,TR3,i149,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check9,float-tiem8,R6,TR3,i153,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check3,unqm8,R7,L1,V1,R28,R3,i157,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check4,qualm8,R7,L1,V2,R28,R82,R3,i158,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check5,qualsm8,R7,L1,V1,R28,R3,i159,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check12,char-signed?m10,R6,TR7,L1,V0,R3,i161,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check10,enum-underm10,R7,L1,V1,R28,R0,s45,An enumerated type's compatible integer type.R3,i163,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check9,int-type?m8,R7,L1,V1,R28,R3,i168,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check11,float-type?m8,R7,L1,V1,R28,R3,i169,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check13,complex-type?m8,R7,L1,V1,R28,R3,i170,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check11,arith-type?m8,R7,L1,V1,R28,R3,i171,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check9,ptr-type?m8,R7,L1,V1,R28,R3,i172,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check12,scalar-type?m8,R7,L1,V1,R28,R3,i173,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check12,record-type?m8,R7,L1,V1,R28,R3,i174,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check10,void-type?m8,R7,L1,V1,R28,R3,i175,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check8,int-bitsm10,R7,L1,V1,R28,R0,s54,An integer type's width and signedness: [bits signed].R3,i177,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check4,rankm10,R6,TR7,L1,V1,R28,R3,i186,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check4,wrapm10,R7,L1,V2,R83,R28,R0,s88,An integer value converted to the integer type `t` (two's complement, modulo its width).R3,i192,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check12,ldouble-sizem10,R6,TR7,L1,V0,R3,i205,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check7,size-ofm8,R84,TR3,i207,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check8,align-ofm8,R84,TR3,i207,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check16,complete-record!m8,R84,TR3,i207,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check4,vla?m8,R84,TR3,i207,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check11,bitint-sizem10,R6,TR7,L1,V1,R29,R3,i209,R4,i1,R5,s17,arbace/c/check.aem10,R7,L1,V1,R28,R0,s51,A type's size in bytes, or nil (incomplete, a VLA).R3,i211,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check9,align-of*m8,R84,TR3,i233,R4,i1,R5,s17,arbace/c/check.aem10,R7,L1,V1,R28,R0,s69,A type's alignment (a typedef's aligned attribute's when it has one).R3,i235,R4,i1,R5,s17,arbace/c/check.aem10,R6,TR7,L1,V1,R28,R3,i240,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check6,rec-ofm10,R6,TR7,L1,V1,R28,R3,i253,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check4,tstrm10,R7,L1,MV1,R28,m2,R9,R85,R0,s62,A type as tools/ccdump's types mode writes it (no qualifiers).R3,i255,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check14,*compat-depth*m8,R2,TR3,i296,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check11,compatible?m8,R84,TR3,i298,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check8,mcompat?m12,R6,TR7,L1,V2,R86,R87,R0,s187,Compatibility of two struct members' types (C23 6.2.7 with GNU's variable and zero-length arrays): tagless records by\n  their members, variable-length arrays by their elements, [] as [0].R3,i300,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check18,union-param-match?m12,R6,TR7,L1,V2,R88,R89,R0,s508,gcc's leniency in a prototype's parameter lists (c-typeck.cc's type_lists_compatible_p): a parameter `u` of a\n  transparent union type, or of a union type with no name (neither a tag nor spelled by a typedef), is compatible with the other's `o` when their sizes are equal and a member's type\n  (unqualified unless an array) is compatible with `o` (`wait (union {union wait *u; int *i} *)` and\n  `wait (union wait *)`; `sendto (__CONST_SOCKADDR_ARG)` and `sendto (const struct sockaddr *)`). Both unqualified.R3,i317,R4,i1,R5,s17,arbace/c/check.aem10,R7,L1,V2,R86,R87,R0,s48,Type compatibility (6.2.7), qualifiers compared.R3,i331,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check5,decaym10,R7,L1,V1,R28,R0,s51,Lvalue conversion's array and function conversions.R3,i373,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check7,promotem10,R7,L2,V1,R28,V2,R28,R90,R0,s63,The integer promotions (6.3.1.1), of a bit-field of `bits` too.R3,i381,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check11,unsigned-ofm10,R6,TR7,L1,V1,R28,R3,i398,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check8,float-ofm10,R6,TR7,L1,V1,R28,R3,i404,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check5,usualm10,R7,L1,V2,R86,R87,R0,s103,The usual arithmetic conversions (6.3.1.8) of two operands' types (promoted, bit-fields' widths given).R3,i406,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check11,push-scope!m10,R6,TR7,L1,V0,R3,i441,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check10,pop-scope!m10,R6,TR7,L1,V0,R3,i442,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check9,top-scopem10,R6,TR7,L1,V0,R3,i443,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check11,file-scope?m10,R6,TR7,L1,V0,R3,i444,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check10,with-scopem10,R6,TR7,L1,V2,R13,R14,R3,i446,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check6,lookupm12,R6,TR7,L1,V1,Myn1,nm2,R9,R10,R0,s57,The innermost declaration of the ordinary identifier `n`.R3,i449,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check10,lookup-tagm10,R6,TR7,L1,V1,Myn1,nm2,R9,R10,R3,i457,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check8,declare!m10,R6,TR7,L1,V2,Myn1,nm2,R9,R10,R91,R3,i463,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check13,file-declare!m10,R6,TR7,L1,V2,Myn1,nm2,R9,R10,R91,R3,i465,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check5,identm12,R6,TR7,L1,V1,R92,R0,s57,The C identifier a form names: a symbol, or (c/id \"...\").R3,i471,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check10,decl-headsS12,R93,R94,R95,R96,R97,R98,R99,R100,R101,R102,R103,R104,m8,R6,TR3,i479,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check15,directive-headsS7,R105,R106,R107,R108,R109,R110,R111,m8,R6,TR3,i482,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check10,attr-itemsm12,R6,TR7,L2,V1,R83,V2,R83,R112,R0,s234,The attributes of a metadata vector, each [name args parens ns gnu] (GNU's (__attribute__ a ...) spread): `parens`\n  when the attribute is written with an argument list (even an empty one), `ns` its prefix, `gnu` for the GNU spelling.R3,i487,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check8,attrs-ofm10,R6,TR7,L1,V3,R113,R13,R114,R3,i503,R4,i1,R5,s17,arbace/c/check.aev14,arbace.c.check13,all-attr-keysV8,R115,R116,R117,R118,R119,R120,R121,R122,m8,R6,TR3,i505,R4,i1,R5,s17,arbace/c/check.ae")

var Lit_419 *jrt.String = jrt.Intern("arbace.c.check$eval1876000004$loading__1927001464__auto____1876000005")

var Lit_420 *jrt.String = jrt.Intern("arbace.c.check$eval1876000008$fn__1876000009")

var Lit_421 *jrt.String = jrt.Intern("arbace.c.check$fn__1876000014")

var Lit_422 *jrt.String = jrt.Intern("arbace.c.check$cx")

var Lit_423 *jrt.String = jrt.Intern("arbace.c.check$ann_BANG_")

var Lit_424 *jrt.String = jrt.Intern("arbace.c.check$feat_BANG_")

var Lit_425 *jrt.String = jrt.Intern("arbace.c.check$err_BANG_")

var Lit_426 *jrt.String = jrt.Intern("arbace.c.check$pedwarn_BANG_")

var Lit_427 *jrt.String = jrt.Intern("arbace.c.check$line_of")

var Lit_428 *jrt.String = jrt.Intern("arbace.c.check$record_BANG_")

var Lit_429 *jrt.String = jrt.Intern("arbace.c.check$at_line")

var Lit_430 *jrt.String = jrt.Intern("arbace.c.check$std_num")

var Lit_431 *jrt.String = jrt.Intern("arbace.c.check$c23_QMARK_")

var Lit_432 *jrt.String = jrt.Intern("arbace.c.check$c99_QMARK_")

var Lit_433 *jrt.String = jrt.Intern("arbace.c.check$pedwarn_c2y_BANG_")

var Lit_434 *jrt.String = jrt.Intern("arbace.c.check$bit_field_QMARK_")

var Lit_435 *jrt.String = jrt.Intern("arbace.c.check$ptr")

var Lit_436 *jrt.String = jrt.Intern("arbace.c.check$arr")

var Lit_437 *jrt.String = jrt.Intern("arbace.c.check$float_tie")

var Lit_438 *jrt.String = jrt.Intern("arbace.c.check$unq")

var Lit_439 *jrt.String = jrt.Intern("arbace.c.check$qual")

var Lit_440 *jrt.String = jrt.Intern("arbace.c.check$quals")

var Lit_441 *jrt.String = jrt.Intern("arbace.c.check$char_signed_QMARK_")

var Lit_442 *jrt.String = jrt.Intern("arbace.c.check$enum_under")

var Lit_443 *jrt.String = jrt.Intern("arbace.c.check$int_type_QMARK_")

var Lit_444 *jrt.String = jrt.Intern("arbace.c.check$float_type_QMARK_")

var Lit_445 *jrt.String = jrt.Intern("arbace.c.check$complex_type_QMARK_")

var Lit_446 *jrt.String = jrt.Intern("arbace.c.check$arith_type_QMARK_")

var Lit_447 *jrt.String = jrt.Intern("arbace.c.check$ptr_type_QMARK_")

var Lit_448 *jrt.String = jrt.Intern("arbace.c.check$scalar_type_QMARK_")

var Lit_449 *jrt.String = jrt.Intern("arbace.c.check$record_type_QMARK_")

var Lit_450 *jrt.String = jrt.Intern("arbace.c.check$void_type_QMARK_")

var Lit_451 *jrt.String = jrt.Intern("arbace.c.check$int_bits")

var Lit_452 *jrt.String = jrt.Intern("arbace.c.check$rank")

var Lit_453 *jrt.String = jrt.Intern("arbace.c.check$wrap")

var Lit_454 *jrt.String = jrt.Intern("arbace.c.check$ldouble_size")

var Lit_455 *jrt.String = jrt.Intern("arbace.c.check$bitint_size")

var Lit_456 *jrt.String = jrt.Intern("arbace.c.check$size_of")

var Lit_457 *jrt.String = jrt.Intern("arbace.c.check$align_of")

var Lit_458 *jrt.String = jrt.Intern("arbace.c.check$align_of_STAR_")

var Lit_459 *jrt.String = jrt.Intern("arbace.c.check$rec_of")

var Lit_460 *jrt.String = jrt.Intern("arbace.c.check$tstr")

var Lit_461 *jrt.String = jrt.Intern("arbace.c.check$mcompat_QMARK_")

var Lit_462 *jrt.String = jrt.Intern("arbace.c.check$union_param_match_QMARK_")

var Lit_463 *jrt.String = jrt.Intern("arbace.c.check$compatible_QMARK_")

var Lit_464 *jrt.String = jrt.Intern("arbace.c.check$decay")

var Lit_465 *jrt.String = jrt.Intern("arbace.c.check$promote")

var Lit_466 *jrt.String = jrt.Intern("arbace.c.check$unsigned_of")

var Lit_467 *jrt.String = jrt.Intern("arbace.c.check$float_of")

var Lit_468 *jrt.String = jrt.Intern("arbace.c.check$usual")

var Lit_469 *jrt.String = jrt.Intern("arbace.c.check$push_scope_BANG_")

var Lit_470 *jrt.String = jrt.Intern("arbace.c.check$pop_scope_BANG_")

var Lit_471 *jrt.String = jrt.Intern("arbace.c.check$top_scope")

var Lit_472 *jrt.String = jrt.Intern("arbace.c.check$file_scope_QMARK_")

var Lit_473 *jrt.String = jrt.Intern("arbace.c.check$with_scope")

var Lit_474 *jrt.String = jrt.Intern("arbace.c.check$lookup")

var Lit_475 *jrt.String = jrt.Intern("arbace.c.check$lookup_tag")

var Lit_476 *jrt.String = jrt.Intern("arbace.c.check$declare_BANG_")

var Lit_477 *jrt.String = jrt.Intern("arbace.c.check$file_declare_BANG_")

var Lit_478 *jrt.String = jrt.Intern("arbace.c.check$ident")

var Lit_479 *jrt.String = jrt.Intern("arbace.c.check$attr_items")

var Lit_480 *jrt.String = jrt.Intern("arbace.c.check$attrs_of")

var Lit_481 *jrt.String = jrt.Intern("kn8,declaredkn4,linekn6,columnkn4,filekn7,privatekn8,arglistsyn1,mkn3,docyn1,vyn1,nyn11,enumerator?yn5,whereyn1,fyn4,kindyn1,tyn4,argsyn1,xyn3,tagyn1,ayn6,packedyn9,max-alignkn3,tagyn7,HashMapyn7,membersyn6,Stringkn7,dynamicyn4,hereyn8,unsignedyn2,msyn1,byn5,depthyn4,valsyn1,&kn2,asyn1,ryn1,dyn1,pyn4,eminyn4,emaxyn1,kyn20,java.math.BigDecimalkn7,ldoublekn8,float64xkn8,float128kn9,float128xkn5,floatkn7,float32kn6,doublekn7,float64kn8,float32xkn7,float16kn4,bf16yn5,partsyn3,eltyn1,syn2,opyn2,tayn2,tbyn1,<yn2,<=yn1,>yn2,>=yn2,!=yn2,==yn2,rayn2,rbyn2,uayn2,ubyn1,hyn5,arrowyn4,bitsyn1,zyn1,cyn6,signedyn4,formv14,arbace.c.check2,exm8,R0,TR1,i507,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check9,const-intm8,R0,TR1,i507,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check10,check-typem8,R0,TR1,i507,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check10,parse-typem8,R0,TR1,i507,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check16,std-no-arg-attrsS6,s12,maybe_unuseds11,unsequenceds9,_Noreturns11,fallthroughs8,noreturns12,reproduciblem8,R4,TR1,i509,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check16,std-string-attrsS2,s9,nodiscards10,deprecatedm8,R4,TR1,i510,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check15,std-attr-check!m12,R4,TR5,L1,V1,R6,R7,s246,C23 6.7.13.2's attribute argument rules for the standard attributes written as [[...]]: those that take no\n  argument given a (possibly empty) argument list, deprecated and nodiscard given an empty list or anything but one\n  plain string literal.R1,i512,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check18,std-position-attrsS8,s12,maybe_unuseds9,nodiscards11,unsequenceds9,_Noreturns11,fallthroughs10,deprecateds8,noreturns12,reproduciblem8,R4,TR1,i530,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check13,fn-type-attrsS2,s11,unsequenceds12,reproduciblem8,R4,TR1,i531,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check9,std-namesm12,R4,TR5,L1,V1,R8,R7,s84,The standard (unprefixed, not GNU) attributes of a vector that have a position rule.R1,i533,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check8,ignored!m12,R4,TR5,L1,V1,R9,R7,s185,gcc's -Wattributes error for an attribute it ignores, under -pedantic-errors; `__extension__` on the line does not\n  silence it (CS150: gcc errs on `[[__extension__ vector_size (4)]]`).R1,i538,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check14,std-attr-misc!m12,R4,TR5,L1,V1,R8,R7,s234,CS150, the standard-syntax attributes `[[...]]` of an attribute vector under -pedantic-errors: any of them before C23\n  is a pedwarn (not on a line with `__extension__`), and an unprefixed one that is no standard attribute is ignored.R1,i544,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check10,tag-attrs!m12,R4,TR5,L1,V2,R8,R10,R7,s167,A struct, union or enum specifier's (or an enumerator's) attributes: noreturn applies to functions only; a\n  enumerator is no type, so nodiscard does not apply either.R1,i552,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check15,type-pos-attrs!m12,R4,TR5,L1,V2,R8,R11,R7,s167,Standard attributes written after a type (specifiers, an array declarator, a function declarator): ignored, but a\n  function declarator's reproducible and unsequenced.R1,i562,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check13,base-fn-type?m12,R4,TR5,L1,V1,R12,R7,s120,Whether the specifiers of a declaration whose type form is `f` give a function type: a typedef name of one, or a typeof.R1,i571,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check20,decl-position-attrs!m12,R4,TR5,L1,V3,R6,R13,R14,R7,s122,A declaration's attributes by where they stood, and the entity they stand with (`kind` :fn, :obj, :typedef, :member, ...).R1,i579,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check10,attr-args!m12,R4,TR5,L1,V1,R6,R7,s189,The arguments of the attributes in metadata `m` checked as expressions (cc's checker types them: an\n  identifier among them that names nothing, a parameter of the attribute's own, skipped).R1,i597,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check13,assoc-in-modem12,R4,TR5,L1,V1,R14,R7,s86,A type made by GNU's mode attribute, marked (its uses are cc's gap :cc-attr-mode too).R1,i611,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check9,vectorizem12,R4,TR5,L1,V2,R14,R6,R7,s156,A type whose attributes in `m` hold GNU's vector_size(N): the vector type of N bytes (read and checked,\n  out of eval and AOT by design, doc/c/SPEC.md §14).R1,i616,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check13,aligned-valuem12,R4,TR5,L1,V1,R15,R7,s87,The alignment an `aligned` attribute's arguments give (none: the target's largest, 16).R1,i646,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check4,big?m10,R4,TR5,L1,V1,R16,R1,i656,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check7,num-valm10,R4,TR5,L1,V1,R8,R1,i658,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check7,new-recm10,R4,TR5,L1,V2,R13,R17,R1,i663,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check8,align-upm10,R4,TR5,L1,V2,R9,R18,R1,i668,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check12,member-alignm12,R4,TR5,L1,V3,R6,R19,R20,R7,s106,A member's alignment: its type's (1 when packed), raised by its aligned attribute, capped by #pragma pack.R1,i670,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check7,layout!m12,R4,TR5,L1,V5,Myn1,rm2,R21,R22,R23,R13,R19,R20,R7,s95,Lays out the record `r`'s members [{:name :t :bits :align :packed}] as gcc 15.2 does on x86-64.R1,i678,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check6,memberm12,R4,TR5,L1,V2,R14,Myn1,nm2,R21,R24,R7,s99,The member `n` of the record type `t` (anonymous members' members too): {:t :off :bits ...} or nil.R1,i733,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check6,*base*m8,R25,TR1,i748,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check11,*auto-init*m10,R25,TR1,i750,R2,i1,R3,s17,arbace/c/check.aeR7,s103,Whether the initializer of a C23 `auto` object is being checked: a tag it declares is an error (CS152).v14,arbace.c.check7,tag-refm12,R4,TR5,L1,V3,R13,Myn3,tagm2,R21,R24,R26,R7,s95,The tag `kind tag` referenced, declared in the current scope when not visible (or when `here`).R1,i754,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check12,check-structm8,R0,TR1,i763,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check10,check-enumm8,R0,TR1,i763,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check8,int-modem12,R4,TR5,L1,V1,R9,R7,s102,mode_for_size_tree (size, MODE_INT, limit): the integer mode of `n` bytes, up to TImode, else BLKmode.R1,i765,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check9,int-mode?m10,R4,TR5,L1,V1,R6,R1,i770,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check14,mode-precisionm12,R4,TR5,L1,V1,R6,R7,s34,GET_MODE_PRECISION of a type-mode.R1,i772,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check9,type-modem12,R4,TR5,L1,V1,R14,R7,s285,A model of gcc's TYPE_MODE (x86-64; aarch64 alike for what transparent_union asks): [:int bytes] for the integer\n  classes (pointers too), a float mode per format, a complex or vector mode of its parts, :blk; records by\n  stor-layout.cc's compute_record_mode, arrays by mode_for_array.R1,i784,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check15,transparent-ok?m12,R4,TR5,L1,V1,Myn1,rm2,R21,R22,R7,s454,Whether gcc keeps transparent_union on the complete union `r` (c-attribs.cc's handle_transparent_union_attribute,\n  c-decl.cc's finish_struct): a first member whose mode (DECL_MODE) is the union's (TYPE_MODE): compute_record_mode\n  gives a union the mode of its widest member as wide as itself only when that mode is an integer one, else the\n  integer mode of its size; so a first member of floating type, or narrower than the union, drops the attribute.R1,i830,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check17,spec-attrs-packedm10,R4,TR5,L1,V1,R6,R1,i843,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check12,bitint-widthm12,R4,TR5,L1,V2,R18,R27,R7,s182,The width of _BitInt(a) (6.7.3.1): gcc's errors for a width that is not positive, below 2 for the signed type, or\n  above BITINT_MAXWIDTH (x86-64: 65535), and the pedwarn before C23.R1,i845,R2,i1,R3,s17,arbace/c/check.aem10,R5,L1,V1,R12,R7,s145,A type form's type (§5.1); struct, union and enum definitions in it defined where they stand,\n  their annotations and their expressions' written.R1,i861,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check3,exim12,R4,TR5,L1,V1,R16,R7,s165,An expression that must be an integer constant expression's operand (a width, an alignment, an enumerator's value,\n  a case label, a designator): nullptr is not one.R1,i940,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check12,member-formsm12,R4,TR5,L1,V1,R28,R7,s86,A member list's members: [{:name :t :bits :align}] (anonymous members with :name nil).R1,i948,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check9,rec-same?m8,R0,TR1,i980,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check7,type-eqm12,R4,TR5,L1,V2,R18,R29,R7,s62,The same type (not just compatible): tagged types by identity.R1,i982,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check8,vm-type?m12,R4,TR5,L2,V1,R14,V2,R14,R30,R7,s139,Whether a type is variably modified: a variable-length array, a pointer to or array of one (a struct with such a member\n  too, to a depth).R1,i998,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check11,vla-struct?m10,R4,TR5,L2,V1,R14,V2,R14,R30,R1,i1012,R2,i1,R3,s17,arbace/c/check.aem12,R4,TR5,L1,V2,Myn1,am2,R21,R22,Myn1,bm2,R21,R22,R7,s290,Whether the new definition `b` of a tag repeats the definition `a` (C23 6.2.7): the same members in order, with the\n  same names, types, widths and alignments. A definition with a variably modified member is never the same (CS152:\n  gcc's \"redefinition\" for `struct f { int a[n]; }` twice).R1,i1021,R2,i1,R3,s17,arbace/c/check.aem12,R4,TR5,L1,V2,R12,R13,R7,s57,A struct or union type form: a reference or a definition.R1,i1036,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check12,enum-type-ofm12,R4,TR5,L1,V1,R31,R7,s68,gcc's compatible type of an enumerated type from its values (§12.3).R1,i1092,R2,i1,R3,s17,arbace/c/check.aem10,R4,TR5,L1,V1,R12,R1,i1103,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check3,resm10,R4,TR5,L1,V3,R14,R32,m2,R33,R6,R1,i1195,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check5,emit!m12,R4,TR5,L1,V1,R34,R7,s139,The annotation of an expression node (its type decayed, its integer value when constant; a bit-field\n  its type promoted, as cc writes it).R1,i1197,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check9,round-sigm12,R4,TR5,L1,V4,R35,R36,R37,R38,R7,s224,The double `d` rounded (half to even) to a binary format of `p` significant bits whose smallest normal exponent is `emin`\n  and largest `emax`: subnormals keep emin's quantum, a value past the largest finite one is infinite.R1,i1207,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check15,round-to-formatm12,R4,TR5,L1,V2,R35,R39,R7,s191,The double `d` rounded to the format of the floating kind `k` (review 031's finding A): float and _Float32 to float,\n  _Float16 to IEEE binary16, __bf16 to bfloat16; any other kind keeps `d`.R1,i1220,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check11,round-exactm12,R4,TR5,L1,V3,Myn1,xm2,R21,R40,R36,R37,R7,s329,The BigDecimal `x` rounded (half to even) to a binary format of `p` significant bits whose smallest normal exponent is\n  `emin` (subnormals keep that quantum), as an exact BigDecimal; no overflow rule (see `fits-binary?`). The binary exponent is\n  found exactly, however far `x` is from the double range (review 053's finding 4).R1,i1230,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check12,wide-formatsm6,R41,V3,l64,l-16382,l16383,R42,V3,l64,l-16382,l16383,R43,V3,l113,l-16382,l16383,m8,R4,TR1,i1251,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check10,wide-kindsS4,R44,R42,R41,R43,m8,R4,TR1,i1257,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check8,exact-ofm12,R4,TR5,L1,V2,Myn1,xm2,R21,R40,R39,R7,s223,The exact decimal `x` rounded to the format of the wide kind `k` (`wide-formats`), or nil when it rounds past the format's\n  range (an infinity: gcc and clang accept such a constant, with a warning; review 057's finding 2).R1,i1261,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check14,binary-formatsm14,R45,V3,l24,l-126,l127,R46,V3,l24,l-126,l127,R47,V3,l53,l-1022,l1023,R48,V3,l53,l-1022,l1023,R49,V3,l53,l-1022,l1023,R50,V3,l11,l-14,l15,R51,V3,l8,l-126,l127,m8,R4,TR1,i1269,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check12,fits-binary?m12,R4,TR5,L1,V2,Myn1,xm2,R21,R40,R39,R7,s125,Whether the exact decimal `x` is a value of the binary kind `k`: rounding it to the format changes nothing, and it is finite.R1,i1274,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check9,round-bigm12,R4,TR5,L1,V2,Myn1,xm2,R21,R40,R39,R7,s120,The exact decimal `x` rounded once to the binary kind `k` (half to even; infinite past the format's range), as a double.R1,i1282,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check14,float-of-exactm12,R4,TR5,L1,V1,Myn1,xm2,R21,R40,R7,s225,The float nearest the exact decimal `x`, as a double (infinite past float's range): a _Float16 or __bf16 constant's value\n  where, as in gcc on x86-64 (FLT_EVAL_METHOD 0), they are evaluated in float (review 053's finding 1).R1,i1291,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check9,eval-typem12,R4,TR5,L1,V1,R14,R7,s212,The type an arithmetic operation on `t` is evaluated in: _Float16 and __bf16 operate in float (C23 Annex H, FLT_EVAL_METHOD 0),\n  the result keeping the type and the excess precision until a conversion rounds it.R1,i1300,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check8,conv-valm12,R4,TR5,L1,V2,R8,R14,R7,s33,A constant converted to type `t`.R1,i1306,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check8,lit-typem12,R4,TR5,L1,V1,R16,R7,s37,A bare literal's type and value (§8).R1,i1330,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check15,byte-string-lenm10,R4,TR5,L1,V1,R52,R1,i1345,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check15,code-unit-countm10,R4,TR5,L1,V2,R53,R54,R1,i1348,R2,i1,R3,s17,arbace/c/check.aem8,R0,TR1,i1358,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check10,check-initm8,R0,TR1,i1358,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check12,call-builtinm8,R0,TR1,i1358,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check17,check-block-itemsm8,R0,TR1,i1358,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check17,binary-index-typem8,R0,TR1,i1358,R2,i1,R3,s17,arbace/c/check.aem8,R0,TR1,i1358,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check12,arith-resultm10,R4,TR5,L1,V3,R55,R56,R57,R1,i1360,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check7,cmp-opsS6,R58,R59,R60,R61,R62,R63,m8,R4,TR1,i1363,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check6,int-opm12,R4,TR5,L1,V4,R55,R18,R29,R14,R7,s28,An integer operator's value.R1,i1365,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check8,float-opm10,R4,TR5,L1,V3,R55,R18,R29,R1,i1382,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check7,cmp-valm10,R4,TR5,L1,V3,R55,R18,R29,R1,i1387,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check11,null-const?m10,R4,TR5,L1,V1,R34,R1,i1393,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check15,null-const-npc?m12,R4,TR5,L1,V1,R34,R7,s148,A null pointer constant for nullptr_t conversions: an integer constant expression of value 0 without a floating\n  conversion in it, or a (void *) 0.R1,i1398,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check6,binarym12,R4,TR5,L1,V3,R55,R64,R65,R7,s54,A binary operator's result from its operands' results.R1,i1404,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check8,unq-elemm12,R4,TR5,L1,V1,R14,R7,s97,A type without the qualifiers of its own or of an array's elements (a pointer's target, 6.7.4.3).R1,i1488,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check9,int-classm8,R0,TR1,i1493,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check23,compatible-ptr-targets?m12,R4,TR5,L1,V2,R66,R67,R7,s116,Pointer targets compatible but for the integer classes gcc only warns about (signedness), as `ptr-conv!` takes them.R1,i1495,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check9,cond-typem12,R4,TR5,L1,V2,R64,R65,R7,s31,The type of c ? a : b (6.5.15).R1,i1504,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check9,callee-fnm10,R4,TR5,L1,V1,R14,R1,i1537,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check12,implicit-fn!m10,R4,TR5,L1,V1,Myn1,nm2,R21,R24,R1,i1543,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check9,head-namem10,R4,TR5,L1,V1,R68,R1,i1549,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check10,ident-exprm10,R4,TR5,L1,V1,Myn1,nm2,R21,R24,R1,i1551,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check10,deref-typem10,R4,TR5,L1,V1,R14,R1,i1567,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check9,member-ofm10,R4,TR5,L1,V3,R34,Myn1,mm2,R21,R24,R69,R1,i1571,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check8,bit-foldm10,R5,L1,V5,Myn1,bm2,R21,R24,R8,R70,R71,R72,R7,s254,The value of the bit builtin b (its name less __builtin_: \"popcountg\" ... \"clrsbg\", \"stdc_leading_zeros\" ...\n  \"stdc_rotate_right\") of the constant v, an integer of `bits` bits; z the value clzg and ctzg give for 0 (nil:\n  the width), c a rotate's count.R1,i1590,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check13,overflow-foldm10,R5,L1,V5,Myn2,opm2,R21,R24,R18,R29,R70,R73,R7,s189,__builtin_OP_overflow_p's value (OP \"add\", \"sub\" or \"mul\") for the constant operands a and b: 1 when the exact\n  result does not fit an integer of `bits` bits, signed when `signed`, else 0.R1,i1630,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check13,builtin-typesm8,R4,TR1,i1642,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check9,ptr-conv!m8,R0,TR1,i1657,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check16,constexpr-check!m8,R0,TR1,i1657,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check16,attr-decl-check!m8,R0,TR1,i1657,R2,i1,R3,s17,arbace/c/check.aem8,R0,TR1,i1657,R2,i1,R3,s17,arbace/c/check.aev14,arbace.c.check16,math-builtin-fnsm10,R4,TR1,i1659,R2,i1,R3,s17,arbace/c/check.aeR7,s348,Queue 178: <math.h>'s functions whose __builtin_ spelling cc's Builtin does not declare, with their prototypes (gcc's,\n  C23 7.12), for the double, float (f) and long double (l) spellings: an undeclared builtin's int result and unpromoted\n  arguments made __builtin_log2(2.75) 0 (CX8). The builder calls musl's function of the name less __builtin_.v14,arbace.c.check4,callm12,R4,TR5,L1,V3,R12,R15,R74,R7,s60,A call's result: the callee's result, its arguments checked.R1,i1680,R2,i1,R3,s17,arbace/c/check.ae")

var Lit_482 *jrt.String = jrt.Intern("arbace.c.check$std_attr_check_BANG_")

var Lit_483 *jrt.String = jrt.Intern("arbace.c.check$std_names")

var Lit_484 *jrt.String = jrt.Intern("arbace.c.check$ignored_BANG_")

var Lit_485 *jrt.String = jrt.Intern("arbace.c.check$std_attr_misc_BANG_")

var Lit_486 *jrt.String = jrt.Intern("arbace.c.check$tag_attrs_BANG_")

var Lit_487 *jrt.String = jrt.Intern("arbace.c.check$type_pos_attrs_BANG_")

var Lit_488 *jrt.String = jrt.Intern("arbace.c.check$base_fn_type_QMARK_")

var Lit_489 *jrt.String = jrt.Intern("arbace.c.check$decl_position_attrs_BANG_")

var Lit_490 *jrt.String = jrt.Intern("arbace.c.check$attr_args_BANG_")

var Lit_491 *jrt.String = jrt.Intern("arbace.c.check$assoc_in_mode")

var Lit_492 *jrt.String = jrt.Intern("arbace.c.check$vectorize")

var Lit_493 *jrt.String = jrt.Intern("arbace.c.check$aligned_value")

var Lit_494 *jrt.String = jrt.Intern("arbace.c.check$big_QMARK_")

var Lit_495 *jrt.String = jrt.Intern("arbace.c.check$num_val")

var Lit_496 *jrt.String = jrt.Intern("arbace.c.check$new_rec")

var Lit_497 *jrt.String = jrt.Intern("arbace.c.check$align_up")

var Lit_498 *jrt.String = jrt.Intern("arbace.c.check$member_align")

var Lit_499 *jrt.String = jrt.Intern("arbace.c.check$layout_BANG_")

var Lit_500 *jrt.String = jrt.Intern("arbace.c.check$member")

var Lit_501 *jrt.String = jrt.Intern("arbace.c.check$tag_ref")

var Lit_502 *jrt.String = jrt.Intern("arbace.c.check$int_mode")

var Lit_503 *jrt.String = jrt.Intern("arbace.c.check$int_mode_QMARK_")

var Lit_504 *jrt.String = jrt.Intern("arbace.c.check$mode_precision")

var Lit_505 *jrt.String = jrt.Intern("arbace.c.check$type_mode")

var Lit_506 *jrt.String = jrt.Intern("arbace.c.check$transparent_ok_QMARK_")

var Lit_507 *jrt.String = jrt.Intern("arbace.c.check$spec_attrs_packed")

var Lit_508 *jrt.String = jrt.Intern("arbace.c.check$bitint_width")

var Lit_509 *jrt.String = jrt.Intern("arbace.c.check$parse_type")

var Lit_510 *jrt.String = jrt.Intern("arbace.c.check$exi")

var Lit_511 *jrt.String = jrt.Intern("arbace.c.check$member_forms")

var Lit_512 *jrt.String = jrt.Intern("arbace.c.check$type_eq")

var Lit_513 *jrt.String = jrt.Intern("arbace.c.check$vm_type_QMARK_")

var Lit_514 *jrt.String = jrt.Intern("arbace.c.check$vla_struct_QMARK_")

var Lit_515 *jrt.String = jrt.Intern("arbace.c.check$rec_same_QMARK_")

var Lit_516 *jrt.String = jrt.Intern("arbace.c.check$check_struct")

var Lit_517 *jrt.String = jrt.Intern("arbace.c.check$enum_type_of")

var Lit_518 *jrt.String = jrt.Intern("arbace.c.check$check_enum")

var Lit_519 *jrt.String = jrt.Intern("arbace.c.check$res")

var Lit_520 *jrt.String = jrt.Intern("arbace.c.check$emit_BANG_")

var Lit_521 *jrt.String = jrt.Intern("arbace.c.check$round_sig")

var Lit_522 *jrt.String = jrt.Intern("arbace.c.check$round_to_format")

var Lit_523 *jrt.String = jrt.Intern("arbace.c.check$round_exact")

var Lit_524 *jrt.String = jrt.Intern("arbace.c.check$exact_of")

var Lit_525 *jrt.String = jrt.Intern("arbace.c.check$fits_binary_QMARK_")

var Lit_526 *jrt.String = jrt.Intern("arbace.c.check$round_big")

var Lit_527 *jrt.String = jrt.Intern("arbace.c.check$float_of_exact")

var Lit_528 *jrt.String = jrt.Intern("arbace.c.check$eval_type")

var Lit_529 *jrt.String = jrt.Intern("arbace.c.check$conv_val")

var Lit_530 *jrt.String = jrt.Intern("arbace.c.check$lit_type")

var Lit_531 *jrt.String = jrt.Intern("arbace.c.check$byte_string_len")

var Lit_532 *jrt.String = jrt.Intern("arbace.c.check$code_unit_count")

var Lit_533 *jrt.String = jrt.Intern("arbace.c.check$arith_result")

var Lit_534 *jrt.String = jrt.Intern("arbace.c.check$int_op")

var Lit_535 *jrt.String = jrt.Intern("arbace.c.check$float_op")

var Lit_536 *jrt.String = jrt.Intern("arbace.c.check$cmp_val")

var Lit_537 *jrt.String = jrt.Intern("arbace.c.check$null_const_QMARK_")

var Lit_538 *jrt.String = jrt.Intern("arbace.c.check$null_const_npc_QMARK_")

var Lit_539 *jrt.String = jrt.Intern("arbace.c.check$binary")

var Lit_540 *jrt.String = jrt.Intern("arbace.c.check$unq_elem")

var Lit_541 *jrt.String = jrt.Intern("arbace.c.check$compatible_ptr_targets_QMARK_")

var Lit_542 *jrt.String = jrt.Intern("arbace.c.check$cond_type")

var Lit_543 *jrt.String = jrt.Intern("arbace.c.check$callee_fn")

var Lit_544 *jrt.String = jrt.Intern("arbace.c.check$implicit_fn_BANG_")

var Lit_545 *jrt.String = jrt.Intern("arbace.c.check$head_name")

var Lit_546 *jrt.String = jrt.Intern("arbace.c.check$ident_expr")

var Lit_547 *jrt.String = jrt.Intern("arbace.c.check$deref_type")

var Lit_548 *jrt.String = jrt.Intern("arbace.c.check$member_of")

var Lit_549 *jrt.String = jrt.Intern("arbace.c.check$bit_fold")

var Lit_550 *jrt.String = jrt.Intern("arbace.c.check$overflow_fold")

var Lit_551 *jrt.String = jrt.Intern("__builtin_isnormal")

var Lit_552 *jrt.String = jrt.Intern("__builtin_c23_va_start")

var Lit_553 *jrt.String = jrt.Intern("__builtin_classify_type")

var Lit_554 *jrt.String = jrt.Intern("__builtin_unreachable")

var Lit_555 *jrt.String = jrt.Intern("__builtin_parityll")

var Lit_556 *jrt.String = jrt.Intern("__builtin_ffsl")

var Lit_557 *jrt.String = jrt.Intern("__builtin_isnan")

var Lit_558 *jrt.String = jrt.Intern("__builtin_popcount")

var Lit_559 *jrt.String = jrt.Intern("__builtin_trap")

var Lit_560 *jrt.String = jrt.Intern("__builtin_memmove")

var Lit_561 *jrt.String = jrt.Intern("__builtin_ctzll")

var Lit_562 *jrt.String = jrt.Intern("__builtin_parity")

var Lit_563 *jrt.String = jrt.Intern("__builtin_prefetch")

var Lit_564 *jrt.String = jrt.Intern("__builtin_parityl")

var Lit_565 *jrt.String = jrt.Intern("__builtin_malloc")

var Lit_566 *jrt.String = jrt.Intern("__builtin_signbit")

var Lit_567 *jrt.String = jrt.Intern("__builtin_ffs")

var Lit_568 *jrt.String = jrt.Intern("__builtin_popcountll")

var Lit_569 *jrt.String = jrt.Intern("__builtin_islessequal")

var Lit_570 *jrt.String = jrt.Intern("__builtin_popcountl")

var Lit_571 *jrt.String = jrt.Intern("__builtin_clzll")

var Lit_572 *jrt.String = jrt.Intern("__builtin_memset")

var Lit_573 *jrt.String = jrt.Intern("__builtin_clrsbll")

var Lit_574 *jrt.String = jrt.Intern("__builtin_alloca")

var Lit_575 *jrt.String = jrt.Intern("__builtin_return_address")

var Lit_576 *jrt.String = jrt.Intern("__builtin_clrsb")

var Lit_577 *jrt.String = jrt.Intern("__builtin_isinf")

var Lit_578 *jrt.String = jrt.Intern("__builtin_ffsll")

var Lit_579 *jrt.String = jrt.Intern("__builtin_isless")

var Lit_580 *jrt.String = jrt.Intern("__builtin_islessgreater")

var Lit_581 *jrt.String = jrt.Intern("__builtin_isinf_sign")

var Lit_582 *jrt.String = jrt.Intern("__builtin_abort")

var Lit_583 *jrt.String = jrt.Intern("__builtin_frame_address")

var Lit_584 *jrt.String = jrt.Intern("__builtin_isfinite")

var Lit_585 *jrt.String = jrt.Intern("__builtin_strlen")

var Lit_586 *jrt.String = jrt.Intern("__builtin_fpclassify")

var Lit_587 *jrt.String = jrt.Intern("__builtin_va_end")

var Lit_588 *jrt.String = jrt.Intern("__builtin_memcpy")

var Lit_589 *jrt.String = jrt.Intern("__builtin_clrsbl")

var Lit_590 *jrt.String = jrt.Intern("__builtin_assume_aligned")

var Lit_591 *jrt.String = jrt.Intern("__builtin_exit")

var Lit_592 *jrt.String = jrt.Intern("__builtin_isgreater")

var Lit_593 *jrt.String = jrt.Intern("__builtin_va_start")

var Lit_594 *jrt.String = jrt.Intern("__builtin_isgreaterequal")

var Lit_595 *jrt.String = jrt.Intern("arbace.c.check$fn__1876000493")

var Lit_596 *jrt.String = jrt.Intern("arbace.c.check$call")

var Lit_597 *jrt.String = jrt.Intern("kn7,privatekn8,arglistskn3,tagyn6,Stringyn3,rasyn2,ftkn4,linekn6,columnkn4,filekn5,dec64kn5,dec32kn6,dec64xkn6,dec128yn1,_yn2,tfyn1,vkn3,docyn1,tyn1,fyn2,etyn4,initkn8,declaredkn4,boolkn4,charkn5,scharkn5,ucharkn5,shortkn6,ushortkn3,intkn4,uintkn4,longkn5,ulongkn5,llongkn6,ullongkn6,int128kn4,i128kn7,uint128yn3,dstyn2,rsyn3,ctxyn2,rlyn2,rryn1,pyn2,msyn2,rayn2,riyn1,myn3,fn?yn5,paramyn1,lyn3,oldyn3,newyn4,kindyn20,java.math.BigDecimalyn1,kyn6,strictyn2,pryn2,ekyn7,dec-objyn1,ryn2,psyn3,retyn4,textyn1,xyn2,bvkn7,dynamicyn4,nextyn5,whereyn1,syn5,itemsyn1,eyn5,formsyn3,stdyn4,optsyn2,rdyn8,builtinsyn1,&kn4,keysyn8,annotateyn12,ldouble-sizeyn13,unsigned-charyn7,resultsyn8,pedanticyn9,ext-linesyn8,sys-dirsyn4,baseyn5,notesyn13,no-c2y-compatyn13,no-c23-compatyn12,exec-charsetyn10,permissivem10,R0,TR1,L1,V3,Myn1,bm2,R2,R3,R4,R5,R6,i1713,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check9,dec-kindsS4,R9,R10,R11,R12,m8,R0,TR6,i1786,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check8,lit-formm12,R0,TR1,L1,V1,V3,R13,R14,R15,R16,s32,(lit T v): a constant of type T.R6,i1788,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check16,incomplete-type?m12,R0,TR1,L1,V1,R17,R16,s76,An array of unknown size (not variable-length) or a record not yet complete.R6,i1815,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check10,sizeof-resm10,R0,TR1,L1,V1,R17,R6,i1824,R7,i1,R8,s17,arbace/c/check.aem10,R0,TR1,L1,V1,R17,R6,i1828,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check14,generic-selectm10,R0,TR1,L1,V1,R18,R6,i1830,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check10,init-countm12,R0,TR1,L1,V2,R19,R20,R16,s83,The number of elements an initializer gives an array of element type `et` (6.7.11).R6,i1858,R7,i1,R8,s17,arbace/c/check.aem8,R21,TR6,i1906,R7,i1,R8,s17,arbace/c/check.aem12,R0,TR1,L2,V1,R20,V2,R20,R19,R16,s231,An initializer's expressions checked (its values' types are the object's, converted). `et`, the element type of a\n  one-dimensional array of scalars, has the plain elements converted as an initialization (nullptr_t's rules, CS141).R6,i1908,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check4,unq*m12,R0,TR1,L1,V1,R17,R16,s78,A type without the qualifiers at its top (and, for an array, on its elements).R6,i1927,R7,i1,R8,s17,arbace/c/check.aem28,R22,R22,R23,R23,R24,R23,R25,R23,R26,R26,R27,R26,R28,R28,R29,R28,R30,R30,R31,R30,R32,R32,R33,R32,R34,R35,R36,R35,m8,R0,TR6,i1932,R7,i1,R8,s17,arbace/c/check.aem12,R0,TR1,L1,V3,R37,R38,R39,R16,s331,6.5.17.2 / 6.5.2.2 / 6.8.7.4: the pointer result `rs` converted to the pointer type `dst` in `ctx` (assignment,\n  initialization, argument or return): gcc 14+ gives an error for pointee types that are not compatible (types of\n  one integer class differing in signedness are only a warning), and a pedwarn for a discarded qualifier.R6,i1936,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check12,assign-checkm10,R0,TR1,L1,V2,R40,R41,R6,i1968,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check12,nested-arrowm10,R0,TR1,L1,V2,R42,R43,R6,i1972,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check3,ex*m8,R21,TR6,i1976,R7,i1,R8,s17,arbace/c/check.aem10,R1,L1,V1,R18,R16,s78,An expression form's result, its annotations written (and recorded, CS95 (a)).R6,i1978,R7,i1,R8,s17,arbace/c/check.aem10,R0,TR1,L1,V1,R18,R6,i1983,R7,i1,R8,s17,arbace/c/check.aem10,R0,TR1,L1,V2,R44,R45,R6,i2147,R7,i1,R8,s17,arbace/c/check.aem10,R1,L1,V1,R18,R16,s77,An integer constant expression's value (its annotations not written), or nil.R6,i2153,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check7,storagem10,R0,TR1,L1,V1,R46,R6,i2165,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check10,linkage-ofm12,R0,TR1,L1,V4,Myn1,nm2,R2,R3,R46,R47,R48,R16,s46,An identifier's linkage (6.2.2): :x, :i or :n.R6,i2168,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check5,lnamem10,R0,TR1,L1,V1,R49,R6,i2180,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check14,complete-arraym10,R0,TR1,L1,V2,R17,R20,R6,i2182,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check9,compositem12,R0,TR1,L1,V2,R50,R51,R16,s98,The composite of a redeclaration's type with the earlier one's (6.2.7): arrays' sizes, prototypes.R6,i2187,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check15,declare-object!m12,R0,TR1,L1,V6,Myn1,nm2,R2,R3,R17,R46,R52,R20,R48,R16,s78,A declared object or function: entered in its scope, its d annotation written.R6,i2209,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check10,auto-type?m10,R0,TR1,L1,V1,R46,R6,i2248,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check12,string-bytesm12,R0,TR1,L1,V1,R20,R16,s104,The bytes of a string form's value and whether it is a u8 literal: [bytes u8?], or nil for another form.R6,i2251,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check10,dec-limitsm8,R10,V3,l7,l-101,l90,R9,V3,l16,l-398,l369,R12,V3,l34,l-6176,l6111,R11,V3,l34,l-6176,l6111,m8,R0,TR6,i2265,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check9,round-decm12,R0,TR1,L1,V2,Myn1,xm2,R2,R53,R54,R16,s118,The decimal `x` rounded (half to even) to the digits of the decimal format `k`; `x` itself for a kind the table lacks.R6,i2269,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check9,dec-fits?m12,R0,TR1,L1,V3,Myn1,xm2,R2,R53,R54,R55,R16,s247,Whether the decimal `x` is a value of the format `k`. A constant of a decimal type (`strict`) must keep its coefficient and\n  quantum; a value of another kind may be written with the trailing zeros stripped and its exponent raised to the format's.R6,i2276,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check19,constexpr-float-badm12,R0,TR1,L1,V3,R56,R57,R58,R16,s355,CS174 (b), C23 6.7.2: the message when the constexpr floating (or decimal) object of element kind `ek` cannot hold the\n  initializer's part `pr` exactly, else nil: a binary object given a decimal value, a signaling NaN of another type, a value\n  float cannot hold, an integer beyond the significand, a decimal beyond the format's digits and quantum range.R6,i2288,R7,i1,R8,s17,arbace/c/check.aem12,R0,TR1,L1,V3,R17,R20,R59,R16,s227,C23 6.7.2's constraints on a constexpr object's initializer that gcc diagnoses: a floating or complex value for an\n  integer object, and a string whose elements the element type cannot represent (a plain literal's are `char`s).R6,i2334,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check9,check-varm12,R0,TR1,L1,V1,R18,R16,s19,(c/var name init?).R6,i2360,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check9,params-ofm12,R0,TR1,L1,V2,R60,R61,R16,s78,A definition's parameter vector: [[name type meta] ...] and the function type.R6,i2416,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check10,check-stmtm8,R21,TR6,i2436,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check13,asm-operands!m12,R0,TR1,L1,V1,R62,R16,s230,CS160: an asm operand with a register constraint (`\"r\"`, `\"+r\"`, ...) that is an object of a _BitInt wider than a\n  register pair (128 bits) has no register to live in: gcc's \"impossible constraint\". The statement is kept as text.R6,i2438,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check10,check-defnm10,R0,TR1,L1,V1,R18,R6,i2449,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check13,check-declarem10,R0,TR1,L1,V1,R18,R6,i2474,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check13,check-typedefm10,R0,TR1,L1,V1,R18,R6,i2485,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check10,check-declm10,R1,L1,V1,R18,R16,s24,A declaration form (§6).R6,i2509,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check10,decl-form?m10,R0,TR1,L1,V1,R63,R6,i2537,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check12,let-bindingsm12,R0,TR1,L1,V1,R64,R16,s54,A let's binding vector checked into the current scope.R6,i2539,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check11,*in-switch*m8,R65,TR6,i2549,R7,i1,R8,s17,arbace/c/check.aem12,R0,TR1,L1,V3,R18,R66,R67,R16,s221,An attribute declaration `[[...]];` (C23 6.7.13.1): the standard attributes in it are ignored (a pedwarn), except\n  fallthrough, which is an error at top level, outside a switch and where no case or default label follows.R6,i2551,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check11,stmt-attrs!m12,R0,TR1,L1,V1,R68,R16,s179,The standard attributes a statement or label stood with (CS140): ignored on a statement, and on a label for\n  deprecated and fallthrough; nodiscard and noreturn apply to no label.R6,i2568,R7,i1,R8,s17,arbace/c/check.aem12,R0,TR1,L1,V1,R69,R16,s95,A statement list; the result of its last expression statement (a statement expression's value).R6,i2581,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check9,cond-exprm10,R0,TR1,L1,V1,R70,R6,i2591,R7,i1,R8,s17,arbace/c/check.aem10,R1,L1,V1,R68,R16,s51,A statement form; an expression statement's result.R6,i2593,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check12,pragma-pack!m12,R0,TR1,L1,V1,R18,R16,s49,#pragma pack's state from a c/pragma form's text.R6,i2663,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check9,check-topm8,R21,TR6,i2675,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check11,check-formsm10,R0,TR1,L1,V1,R71,R6,i2677,R7,i1,R8,s17,arbace/c/check.aem10,R1,L1,V1,R18,R16,s27,A top-level form of a unit.R6,i2680,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check6,new-cxm10,R0,TR1,L1,V2,R72,R73,R6,i2729,R7,i1,R8,s17,arbace/c/check.aev14,arbace.c.check10,check-unitm10,R1,L1,V5,R74,R72,R75,R76,m2,R77,V13,R78,R79,R80,R81,R82,R83,R84,R85,R86,R87,R88,R89,R90,R16,s221,Checks a read (arbace.repr.c/read-c's {:forms :units}) at the standard `std` (a keyword), the\n  builtins' forms `builtins` declared first: {:errors [...] :items [[line [annotation...]] ...]} (the\n  items when `annotate`).R6,i2735,R7,i1,R8,s17,arbace/c/check.ae")

var Lit_598 *jrt.String = jrt.Intern("arbace.c.check$call_builtin")

var Lit_599 *jrt.String = jrt.Intern("arbace.c.check$lit_form")

var Lit_600 *jrt.String = jrt.Intern("arbace.c.check$incomplete_type_QMARK_")

var Lit_601 *jrt.String = jrt.Intern("arbace.c.check$sizeof_res")

var Lit_602 *jrt.String = jrt.Intern("arbace.c.check$vla_QMARK_")

var Lit_603 *jrt.String = jrt.Intern("arbace.c.check$generic_select")

var Lit_604 *jrt.String = jrt.Intern("arbace.c.check$init_count")

var Lit_605 *jrt.String = jrt.Intern("arbace.c.check$check_init")

var Lit_606 *jrt.String = jrt.Intern("arbace.c.check$unq_STAR_")

var Lit_607 *jrt.String = jrt.Intern("arbace.c.check$ptr_conv_BANG_")

var Lit_608 *jrt.String = jrt.Intern("arbace.c.check$assign_check")

var Lit_609 *jrt.String = jrt.Intern("arbace.c.check$nested_arrow")

var Lit_610 *jrt.String = jrt.Intern("arbace.c.check$ex")

var Lit_611 *jrt.String = jrt.Intern("arbace.c.check$ex_STAR_")

var Lit_612 *jrt.String = jrt.Intern("arbace.c.check$binary_index_type")

var Lit_613 *jrt.String = jrt.Intern("arbace.c.check$const_int")

var Lit_614 *jrt.String = jrt.Intern("arbace.c.check$storage")

var Lit_615 *jrt.String = jrt.Intern("arbace.c.check$linkage_of")

var Lit_616 *jrt.String = jrt.Intern("arbace.c.check$lname")

var Lit_617 *jrt.String = jrt.Intern("arbace.c.check$complete_array")

var Lit_618 *jrt.String = jrt.Intern("arbace.c.check$composite")

var Lit_619 *jrt.String = jrt.Intern("arbace.c.check$declare_object_BANG_")

var Lit_620 *jrt.String = jrt.Intern("arbace.c.check$auto_type_QMARK_")

var Lit_621 *jrt.String = jrt.Intern("arbace.c.check$string_bytes")

var Lit_622 *jrt.String = jrt.Intern("arbace.c.check$round_dec")

var Lit_623 *jrt.String = jrt.Intern("arbace.c.check$dec_fits_QMARK_")

var Lit_624 *jrt.String = jrt.Intern("arbace.c.check$constexpr_float_bad")

var Lit_625 *jrt.String = jrt.Intern("arbace.c.check$constexpr_check_BANG_")

var Lit_626 *jrt.String = jrt.Intern("arbace.c.check$check_var")

var Lit_627 *jrt.String = jrt.Intern("arbace.c.check$params_of")

var Lit_628 *jrt.String = jrt.Intern("arbace.c.check$asm_operands_BANG_")

var Lit_629 *jrt.String = jrt.Intern("arbace.c.check$check_defn")

var Lit_630 *jrt.String = jrt.Intern("arbace.c.check$check_declare")

var Lit_631 *jrt.String = jrt.Intern("arbace.c.check$check_typedef")

var Lit_632 *jrt.String = jrt.Intern("arbace.c.check$check_decl")

var Lit_633 *jrt.String = jrt.Intern("arbace.c.check$decl_form_QMARK_")

var Lit_634 *jrt.String = jrt.Intern("arbace.c.check$let_bindings")

var Lit_635 *jrt.String = jrt.Intern("arbace.c.check$attr_decl_check_BANG_")

var Lit_636 *jrt.String = jrt.Intern("arbace.c.check$stmt_attrs_BANG_")

var Lit_637 *jrt.String = jrt.Intern("arbace.c.check$check_block_items")

var Lit_638 *jrt.String = jrt.Intern("arbace.c.check$cond_expr")

var Lit_639 *jrt.String = jrt.Intern("arbace.c.check$check_stmt")

var Lit_640 *jrt.String = jrt.Intern("arbace.c.check$pragma_pack_BANG_")

var Lit_641 *jrt.String = jrt.Intern("arbace.c.check$check_forms")

var Lit_642 *jrt.String = jrt.Intern("arbace.c.check$check_top")

var Lit_643 *jrt.String = jrt.Intern("arbace.c.check$new_cx")

var Lit_644 *jrt.String = jrt.Intern("arbace.c.check$check_unit")
